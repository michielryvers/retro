/**
 * The strict response checker: validates a decoded response against its
 * output AST without Effect Schema.
 *
 * Generated output schemas are lite nodes (`schema-lite-impl.ts`); the
 * checker accepts what Effect Schema's decoder accepted for the schema
 * `toEffect` built from them (`response-validation-strict.test.ts` compares
 * the two on random schemas and values). Each AST node compiles once to a
 * closure, so a check walks the value only.
 *
 * Two modes: `additionalProperties` lets keys an object does not model
 * through (Effect's default), `strict` (`exact`) rejects them (Effect's
 * `onExcessProperty: "error"`). In both, an index signature covers only the
 * keys the object does not declare (OpenAPI `additionalProperties`), and an
 * empty struct accepts any object (generated code's opaque output).
 *
 * Hand-written protocols may pass real Effect ASTs. Their structure is
 * checked the same way; refinement `checks` run, but a real `Declaration`
 * with type parameters and `TemplateLiteral` contents are not checked.
 */
import type * as AST from "effect/SchemaAST";
/** A response that does not match its output schema (the `cause` of a strict `<Sdk>ParseError`). */
export declare class SchemaMismatch extends Error {
    readonly name = "SchemaError";
    /** Where in the response the mismatch is, outermost key first. */
    readonly path: ReadonlyArray<PropertyKey>;
    /** What the schema expected there, e.g. `string`. */
    readonly expected: string;
    readonly actual: unknown;
    constructor(path: ReadonlyArray<PropertyKey>, expected: string, actual: unknown);
}
/**
 * `mismatch` with its offending value replaced by `"[REDACTED]"`, for a parse
 * error that withholds the body (the value may be a secret).
 */
export declare const withholdActual: (mismatch: SchemaMismatch) => SchemaMismatch;
/**
 * Validate `input` synchronously: `undefined` when it matches, else the
 * mismatch.
 */
export type Decode = (input: unknown) => SchemaMismatch | undefined;
/**
 * The checker for an output AST: compiled once per node and mode, then
 * reused. `exact` also rejects keys an object does not model (the `strict`
 * mode); without it they pass (`additionalProperties`).
 */
export declare const decoderFor: (ast: AST.AST, exact?: boolean) => Decode;
//# sourceMappingURL=response-validation-strict.d.ts.map