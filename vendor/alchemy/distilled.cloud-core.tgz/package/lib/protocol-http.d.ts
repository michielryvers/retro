import * as HttpClientRequest from "effect/http/HttpClientRequest";
/**
 * Generic REST protocol machinery, shared by SDK protocol layers.
 *
 * Everything here is driven purely by the trait annotations in
 * `core/trait.ts` -- nothing is provider-specific. An SDK protocol (e.g.
 * cloudflare's) supplies credentials/base-URL, calls {@link buildRequest} to
 * encode, and layers its own response-envelope handling on top of the
 * decode-side helpers ({@link getProps}/{@link mapKeys}/
 * {@link matchTypedError}).
 */
import type * as AST from "effect/SchemaAST";
import { isOpaqueValue } from "./plain-values.ts";
import { type ErrorMatcher, type HttpTrait, type KeyDictionaryEntries } from "./trait.ts";
export declare const getProps: (ast: AST.AST) => readonly AST.PropertySignature[];
export declare const getAnn: (ast: AST.AST, symbol: symbol) => unknown;
export declare const getPropAnn: (prop: AST.PropertySignature, symbol: symbol) => unknown;
export declare const hasPropAnn: (prop: AST.PropertySignature, symbol: symbol) => boolean;
export declare const nameOf: (prop: AST.PropertySignature, symbol: symbol) => string;
/** Resolve wrappers to the real node: Suspend, encoding, optional/null unions. */
export declare const resolveNode: (ast: AST.AST) => AST.AST;
/** An output member read from a response header (`T.Header`). */
export interface ResponseHeaderMember {
    readonly key: string;
    /** Lowercase header name. */
    readonly wire: string;
    /** The member is a number; the header's text is parsed. */
    readonly number: boolean;
}
/** The output's header-bound members, read from the schema once. */
export declare const responseHeaderMembers: (outputAst: AST.AST) => ReadonlyArray<ResponseHeaderMember>;
/**
 * Copy the response headers an output declares onto its decoded body. A
 * number member gets the header parsed; text that is not a number is kept
 * as sent, so strict validation reports it. A body that is not an object
 * (a raw root) is returned as is -- generators bind no headers there.
 */
export declare const withResponseHeaders: (members: ReadonlyArray<ResponseHeaderMember>, body: unknown, headers: Record<string, string | undefined>) => unknown;
export { isOpaqueValue };
/**
 * Deep-rename keys via a plain dictionary (see `T.KeyDictionary`). An entry
 * may list several wire spellings; encode uses the first (canonical) one and
 * decode maps every listed spelling back to the TS name.
 */
export declare const mapKeysByDictionary: (dict: KeyDictionaryEntries, value: unknown, direction: "encode" | "decode") => unknown;
/**
 * Whether {@link mapKeys} returns every value of `root` unchanged (as a deep
 * copy) in `direction` with no fallback dictionary: no member is renamed,
 * string-encoded (encode) or picked by `T.UnionCases` (decode), and no
 * `T.KeyDictionary` is in scope anywhere below `root`. Protocols use it to
 * skip the walk. Computed once per schema node and direction.
 */
export declare const mapsVerbatim: (root: AST.AST, direction: "encode" | "decode") => boolean;
export declare const mapKeys: (ast: AST.AST, value: unknown, direction: "encode" | "decode", fallback?: KeyDictionaryEntries) => unknown;
export interface BuildRequestOptions {
    readonly input: unknown;
    readonly inputAst: AST.AST;
    /** Base URL the operation's URI template is appended to. */
    readonly baseUrl: string;
    /** Headers applied before member-bound headers (credentials etc.). */
    readonly headers?: Record<string, string>;
    /**
     * Transform a member-bound header value before it is set (e.g.
     * Bearer-prefixing a raw token supplied as an Authorization member).
     */
    readonly mapMemberHeader?: (name: string, value: string) => string;
    /**
     * Wire name for input keys the schema doesn't declare (spec drift --
     * unknown keys pass through as body fields rather than being dropped).
     * Defaults to the key verbatim.
     */
    readonly unknownKeyToWire?: (key: string) => string;
}
/**
 * Encode a greedy `{name+}` label: the value may span several path
 * segments (e.g. an Azure scope `/subscriptions/{id}/resourceGroups/{rg}`),
 * so each segment is encoded on its own and the `/` separators are kept.
 * Leading slashes are dropped because the URI template already supplies one.
 */
export declare const encodeGreedyLabel: (value: string) => string;
/**
 * `HttpClientRequest.make(method)(url)` with `headers` set, in one object:
 * the same request as `make(...).pipe(setHeaders(headers))` without the
 * intermediate copies. `url` may carry a query string.
 */
export declare const makeRequest: (method: HttpTrait["method"], url: string, headers: Record<string, string>) => HttpClientRequest.HttpClientRequest;
/**
 * Build an HTTP request from an operation input and its schema, driven by
 * the trait annotations: `Http()` supplies method + URI template, `Label()`
 * members fill URI placeholders, `Header()`/`Query()` members bind to
 * headers/query params, `DeepQuery()` struct members expand into dotted
 * query params, `HttpBody()` sends the member as the whole body,
 * `FormDataFile()` members become multipart file parts, and everything else
 * is a JSON body field (wire-named via `Body()` / `KeyDictionary`).
 *
 * The schema is read once per input schema (see `planFor`); later calls only
 * walk the input value.
 *
 * Throws when the input schema is missing the `Http()` trait -- a codegen
 * bug -- and, before anything is sent, when a label is `.` or `..` (for a
 * greedy `{name+}` label, when any of its segments is). Each surfaces as a
 * defect by the calling protocol's Effect context.
 */
export declare const buildRequest: ({ input, inputAst, baseUrl, headers: baseHeaders, mapMemberHeader, unknownKeyToWire, }: BuildRequestOptions) => HttpClientRequest.HttpClientRequest;
/** Parsed response metadata supplied by a protocol after it detects a failure. */
export interface ErrorResponse {
    readonly body?: unknown;
    readonly headers?: Readonly<Record<string, string | undefined>>;
}
/** Every supplied constraint must match; an unconstrained matcher matches nothing. */
export declare const matchesExpression: (m: ErrorMatcher, code: number | undefined, status: number, message: string, response?: ErrorResponse) => boolean;
/**
 * Pick the operation's typed error class for a failed response: among all
 * declared classes whose matchers (see `applyErrorMatchers`) match the wire
 * failure, the most specific matcher wins (ties break by declaration order).
 * Empty error lists use an HTTP-status message so body/header-only failures can
 * still match. The constructor receives the raw body and headers as well as
 * code/message; error schemas can declare these fields to expose them to callers.
 */
export declare const matchTypedError: (errorClasses: ReadonlyArray<unknown>, status: number, errors: ReadonlyArray<{
    code?: number;
    message: string;
}>, response?: ErrorResponse) => unknown | undefined;
//# sourceMappingURL=protocol-http.d.ts.map