/**
 * Response validation mode, shared by every distilled SDK.
 *
 * Generated SDKs carry a schema for every operation's output. What a
 * protocol does with it on a 2xx response depends on the mode:
 *
 *   lenient (default): the response is returned as the protocol read it.
 *                      A body that does not match the declared output type
 *                      (a missing member, a wrong primitive, a non-JSON
 *                      body) still succeeds, except that core's REST
 *                      protocol, Stripe and Fly.io fail a non-JSON body for
 *                      an output with sensitive members in every mode.
 *   additionalProperties: the response is checked against the output
 *                      schema, and a mismatch fails the call with the SDK's
 *                      `<Sdk>ParseError` (AWS: `ParseError`). Keys the
 *                      schema does not model are allowed and kept.
 *   strict:            as `additionalProperties`, and a key the schema does
 *                      not model also fails the call, at any depth. Open
 *                      objects (an index signature, e.g. OpenAPI
 *                      `additionalProperties`) and empty structs (opaque
 *                      outputs) still accept any key.
 *
 * The mode is one {@link ResponseValidation} reference keyed by a string, so
 * a single `Layer` switches every distilled SDK in a program -- AWS,
 * Cloudflare, Neon, ... -- at once, and nests like any other Effect service:
 *
 * ```ts
 * import { ResponseValidation } from "@distilled.cloud/core";
 *
 * // whole program
 * program.pipe(Effect.provide(ResponseValidation.strict));
 *
 * // one call back to lenient inside a strict program
 * Neon.getProject({ projectId }).pipe(Effect.provide(ResponseValidation.lenient));
 * ```
 *
 * The mode is set only by these layers; without one, every call is lenient.
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type * as AST from "effect/SchemaAST";
import { type Decode, type SchemaMismatch } from "./response-validation-strict.ts";
export { SchemaMismatch, withholdActual } from "./response-validation-strict.ts";
export type Mode = "lenient" | "additionalProperties" | "strict";
/**
 * The active validation mode. Read by protocols at call time on the calling
 * fiber; `lenient` unless an {@link additionalProperties} or {@link strict}
 * layer is provided.
 */
export declare const ResponseValidation: Context.Reference<Mode>;
/**
 * The checker the validating modes use (`exact`: reject unmodeled keys). The
 * `additionalProperties` and `strict` layers provide it, so the checker is
 * bundled only with programs that validate.
 */
export declare const StrictDecoder: Context.Reference<((ast: AST.AST, exact: boolean) => Decode) | undefined>;
/**
 * Check every 2xx response against its output schema and fail on a
 * mismatch, including any key the schema does not model.
 */
export declare const strict: Layer.Layer<never>;
/**
 * Check every 2xx response against its output schema and fail on a
 * mismatch; keys the schema does not model are allowed.
 */
export declare const additionalProperties: Layer.Layer<never>;
/** Return 2xx responses as read, without checking them against the schema. */
export declare const lenient: Layer.Layer<never>;
/** Whether the calling fiber validates responses (any mode but lenient). */
export declare const isValidating: Effect.Effect<boolean>;
/**
 * For a 2xx body the protocol could not read into the shape it transforms
 * (e.g. invalid JSON): fail with `error` when validating, succeed with
 * `asRead` (usually the body text) in lenient mode.
 */
export declare const failUnlessLenient: <A, E>(error: E, asRead: A) => Effect.Effect<A, E>;
/**
 * The schema error for `value` against `outputAst` when validating,
 * `undefined` when it matches or the mode is lenient. Synchronous, for
 * protocols that already hold the calling fiber's context.
 */
export declare const checkResponse: (context: Context.Context<any>, outputAst: AST.AST, value: unknown) => SchemaMismatch | undefined;
export declare const validateResponse: <E>(outputAst: AST.AST, value: unknown, onError: (cause: SchemaMismatch) => E) => Effect.Effect<unknown, E>;
//# sourceMappingURL=response-validation.d.ts.map