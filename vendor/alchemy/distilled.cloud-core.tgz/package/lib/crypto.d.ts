/**
 * Hashing and HMAC for request signing, as a swappable service.
 *
 * SDKs that sign requests (AWS SigV4, webhook verification, ...) read
 * {@link Crypto} from the context. It is a reference with a default, so it
 * never appears in an operation's requirements: by default it uses
 * `node:crypto` when the runtime has it (Node, Bun, Deno -- synchronous, and
 * several times faster than WebCrypto for small inputs) and WebCrypto
 * (`crypto.subtle`) everywhere else.
 *
 * Provide a layer to choose or replace the implementation:
 *
 * ```ts
 * import { Crypto } from "@distilled.cloud/core";
 * program.pipe(Effect.provide(Crypto.webCrypto)); // force WebCrypto
 * program.pipe(Effect.provide(Crypto.layer(myHsmBackedCrypto)));
 * ```
 *
 * HMAC keys are imported once into an implementation-specific handle
 * ({@link HmacKey}) so callers can cache them: preparing a raw key is most of
 * an HMAC's cost in both `node:crypto` and WebCrypto.
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
declare const CryptoError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "CryptoError";
} & Readonly<A>;
/** A hashing or HMAC operation failed in the crypto implementation. */
export declare class CryptoError extends /*@__PURE__*/ CryptoError_base<{
    readonly operation: "hmac" | "sha256" | "importKey";
    readonly cause: unknown;
}> {
}
/** An imported HMAC-SHA256 key. Opaque: only the implementation that made it can use it. */
export interface HmacKey {
    readonly "~distilled/HmacKey": unique symbol;
}
export type Bytes = Uint8Array | string;
export interface CryptoImpl {
    /** Name for diagnostics, e.g. "node:crypto" or "webcrypto". */
    readonly name: string;
    readonly sha256: (data: Bytes) => Effect.Effect<Uint8Array, CryptoError>;
    readonly importHmacKey: (key: Bytes) => Effect.Effect<HmacKey, CryptoError>;
    readonly hmacSha256: (key: HmacKey, data: Bytes) => Effect.Effect<Uint8Array, CryptoError>;
    /**
     * The same operations as plain functions, for implementations that are
     * synchronous (node:crypto). They throw on failure. Signers use them to
     * skip the per-operation effects when present.
     */
    readonly sync?: {
        readonly sha256: (data: Bytes) => Uint8Array;
        readonly importHmacKey: (key: Bytes) => HmacKey;
        readonly hmacSha256: (key: HmacKey, data: Bytes) => Uint8Array;
        /** `hex(sha256(data))`, when the implementation can produce hex itself. */
        readonly sha256Hex?: (data: Bytes) => string;
        /** `hex(hmacSha256(key, data))`, when the implementation can produce hex itself. */
        readonly hmacSha256Hex?: (key: HmacKey, data: Bytes) => string;
    };
}
/** `node:crypto` implementation, or undefined when the runtime has no `node:crypto`. */
export declare const makeNodeCrypto: () => CryptoImpl | undefined;
/** WebCrypto (`crypto.subtle`) implementation. */
export declare const makeWebCrypto: () => CryptoImpl;
/** The crypto implementation signing code uses. Defaults to `node:crypto` when available, else WebCrypto. */
export declare const Crypto: Context.Reference<CryptoImpl>;
/** Use a custom implementation. */
export declare const layer: (impl: CryptoImpl) => Layer.Layer<never>;
/** Force WebCrypto, even where `node:crypto` exists. */
export declare const webCrypto: Layer.Layer<never>;
/** Force `node:crypto`; fails at layer build when the runtime has none. */
export declare const nodeCrypto: Layer.Layer<never, CryptoError>;
/** Lowercase hex of bytes. */
export declare const hex: (bytes: Uint8Array) => string;
export {};
//# sourceMappingURL=crypto.d.ts.map