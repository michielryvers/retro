/**
 * GraphQL Query algebra -- the runtime generated GraphQL SDKs target.
 *
 * U+2500U+2500 Why this exists U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500
 * A GraphQL document is a *selection*, not an RPC. Distilled used to bake a
 * max-depth selection into every operation (`Railway.me({})` downloaded the
 * world). This module instead treats every field as a lazy `Query<Value>`:
 * reading `user.email` records that field, and nothing is posted until
 * `Query.fn` evaluates the plan you returned.
 *
 * U+2500U+2500 The two phases U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500
 * 1. Build (your function). `Railway.me()` / `user.email` / `Query.map` do
 *    not talk to the network. They construct an expression tree:
 *      Of | Map | Filter | FlatMap | Prop | Root
 *    The inner function of `Query.fn` is therefore a *builder*, not an
 *    Effect generator. No `yield*` inside it.
 *
 * 2. Evaluate (`Query.fn`). Walk the returned plan, paint every GraphQL
 *    field that appears onto one selection forest, POST that document
 *    once through {@link GqlTransport}, then interpret Map/Filter/FlatMap
 *    against the JSON. Effects reached via FlatMap (e.g.
 *    `usernameIsAvailable(name)`) run *after* the POST, with real values.
 *
 * U+2500U+2500 Combinators U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500
 * - `Query.of(x)` -- a literal; never selected.
 * - `Query.map` on a list -- callback receives `Query<Item>` so `p.name` is
 *   still a Query (selected). On a scalar, callback receives the value
 *   after extract (`stars => stars > 5`). Relay connections (`edges { node }`)
 *   are lists of the node type, so `projects({ first: 20 }).pipe(Query.map)`
 *   maps projects, not edges.
 * - `Query.filter` -- predicate is `Query<Item> => Query<boolean>`; the
 *   boolean Query is walked for fields, then run per row after the POST.
 * - `Query.flatMap` -- after extract, run `(value) => Effect | Query`.
 * - `Query.pages` / `Query.items` -- a Stream over every page / node of a
 *   Relay connection, one POST per page (see "Pagination").
 *
 * U+2500U+2500 Types U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500
 * `Query<Value>` is `QueryNode<Value>` plus the GraphQL fields of `Value`,
 * so `user.name` type-checks. That copy is a circular type alias
 * (`Query<User>` contains `Query<Project[]>` which contains `Query<User>`
 * again). TypeScript leaves the cycle lazy; there is no depth cap.
 *
 * U+2500U+2500 Transport U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500U+2500
 * {@link GqlTransport.execute} posts `{ query, variables, operationName }`.
 * The Effect it returns may require Credentials / HttpClient; those leak
 * into `Query.fn`'s requirements. It returns the parsed `data` and raw
 * `errors`; `Query.fn` classifies the errors (see "Errors" below). Compile
 * failures are {@link GqlError} defects.
 *
 * Generated SDKs export *roots* (`Railway.me`, `Railway.project`).
 * Combinators live in `@distilled.cloud/core/query`.
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as S from "effect/Schema";
import * as Stream from "effect/Stream";
export declare const QuerySymbol: unique symbol;
declare const inspect: unique symbol;
/** A plan that cannot be compiled (a programming error, raised as a defect). */
export declare class GqlError {
    readonly _tag: "GqlError";
    readonly message: string;
    constructor(message: string);
}
/** Fields every classified GraphQL error carries. */
export declare const errorFields: {
    message: S.String;
    code: S.optional<S.String>;
    path: S.optional<S.$Array<S.Union<readonly [S.String, S.Number]>>>;
    locations: S.optional<S.$Array<S.Struct<{
        readonly line: S.Number;
        readonly column: S.Number;
    }>>>;
    extensions: S.optional<S.Unknown>;
    traceId: S.optional<S.String>;
    status: S.optional<S.Number>;
    /** Server retry hint in seconds. */
    retryAfter: S.optional<S.Number>;
};
/** The shape shared by every classified GraphQL error. */
export interface GraphQLIssue {
    readonly _tag: string;
    readonly message: string;
    readonly code?: string;
    readonly path?: ReadonlyArray<string | number>;
    readonly locations?: ReadonlyArray<{
        readonly line: number;
        readonly column: number;
    }>;
    readonly extensions?: unknown;
    readonly traceId?: string;
    readonly status?: number;
    readonly retryAfter?: number;
}
export type GraphQLIssueProps = Omit<GraphQLIssue, "_tag">;
declare const UnknownGraphQLError_base: S.Class<UnknownGraphQLError, S.TaggedStruct<"UnknownGraphQLError", {
    readonly message: S.String;
    readonly code: S.optional<S.String>;
    readonly path: S.optional<S.$Array<S.Union<readonly [S.String, S.Number]>>>;
    readonly locations: S.optional<S.$Array<S.Struct<{
        readonly line: S.Number;
        readonly column: S.Number;
    }>>>;
    readonly extensions: S.optional<S.Unknown>;
    readonly traceId: S.optional<S.String>;
    readonly status: S.optional<S.Number>;
    readonly retryAfter: S.optional<S.Number>;
    /** Root field the error path points at, when the path is known. */
    readonly coordinate: S.optional<S.String>;
}>, import("effect/Cause").YieldableError>;
/** A GraphQL error no declared matcher recognizes. */
export declare class UnknownGraphQLError extends /*@__PURE__*/ UnknownGraphQLError_base {
}
declare const GraphQLFailure_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "GraphQLFailure";
} & Readonly<A>;
/** One response carried errors with different tags; none is hidden. */
export declare class GraphQLFailure<E extends GraphQLIssue = GraphQLIssue> extends /*@__PURE__*/ GraphQLFailure_base<{
    readonly errors: readonly [E, ...E[]];
    /** The partial response data, with sensitive fields wrapped in `Redacted`. */
    readonly data: unknown;
    readonly status?: number;
}> {
    get message(): string;
}
declare const GraphQLTransportError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "GraphQLTransportError";
} & Readonly<A>;
/** The request never produced a GraphQL response (network, HTTP, non-JSON). */
export declare class GraphQLTransportError extends /*@__PURE__*/ GraphQLTransportError_base<{
    readonly message: string;
    readonly status?: number;
    /** Server retry hint in seconds. */
    readonly retryAfter?: number;
    readonly cause?: unknown;
}> {
}
declare const GraphQLPaginationError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "GraphQLPaginationError";
} & Readonly<A>;
/** A paginated connection reported more pages without a new cursor. */
export declare class GraphQLPaginationError extends /*@__PURE__*/ GraphQLPaginationError_base<{
    readonly message: string;
    readonly cursor: string | null;
}> {
}
/** Recognizes a raw GraphQL error. Every present property must match. */
export interface ErrorMatcher {
    readonly code?: string;
    readonly message?: string;
    readonly messageIncludes?: string;
}
/** Runtime description of one generated error class. */
export interface ErrorSpec<E extends GraphQLIssue = GraphQLIssue> {
    readonly tag: E["_tag"];
    readonly make: (props: GraphQLIssueProps) => E;
    readonly matchers: ReadonlyArray<ErrorMatcher>;
    /** Queries failing only with retryable errors are retried. */
    readonly retryable: boolean;
    /** Applies to every root, including errors that carry no path. */
    readonly global: boolean;
}
export declare const errorSpec: <E extends GraphQLIssue>(make: new (props: GraphQLIssueProps) => E, tag: E["_tag"], matchers: ReadonlyArray<ErrorMatcher>, options?: {
    readonly retryable?: boolean;
    readonly global?: boolean;
}) => ErrorSpec<E>;
/** An entry of a GraphQL response's `errors` array, as sent on the wire. */
export interface RawGraphQLError {
    readonly message: string;
    readonly path?: ReadonlyArray<string | number>;
    readonly locations?: ReadonlyArray<{
        readonly line: number;
        readonly column: number;
    }>;
    readonly extensions?: Record<string, unknown>;
    readonly [key: string]: unknown;
}
/** What a transport returns once it has a GraphQL response body. */
export interface GraphQLResponse {
    readonly data?: unknown;
    readonly errors?: ReadonlyArray<RawGraphQLError>;
    readonly status?: number;
    readonly headers?: Readonly<Record<string, string | undefined>>;
}
export type ArgMeta = Record<string, string>;
export type FieldMeta = {
    readonly name: string;
    readonly kind: "scalar" | "object" | "list" | "connection";
    readonly of?: TypeMeta;
    readonly argTypes?: ArgMeta;
    /** The value is a secret: extracted strings are wrapped in `Redacted`. */
    readonly sensitive?: boolean;
};
export type TypeMeta = {
    readonly name: string;
    readonly fields: Record<string, FieldMeta>;
};
export declare const scalarField: (name: string, options?: {
    readonly sensitive?: boolean;
}) => FieldMeta;
export declare const objectField: (name: string, objectType: TypeMeta) => FieldMeta;
export declare const listField: (name: string, itemType: TypeMeta, argTypes?: ArgMeta) => FieldMeta;
/** Relay connection: GraphQL `edges { node }` presented as `Query<Item[]>`. */
export declare const connectionField: (name: string, nodeType: TypeMeta, argTypes?: ArgMeta) => FieldMeta;
export type TypeRef = {
    readonly tag: "scalar";
} | {
    readonly tag: "object";
    readonly meta: TypeMeta;
} | {
    readonly tag: "list";
    readonly of: TypeRef;
};
export interface SelNode {
    field: string;
    alias: string | undefined;
    args: Record<string, string> | undefined;
    children: Map<string, SelNode>;
    isScalar: boolean;
    isList: boolean;
    /** The value is a secret: its strings are wrapped in `Redacted`. */
    sensitive?: boolean;
}
export interface CompiledOperation {
    readonly document: string;
    readonly operationName: string;
    readonly variables: Record<string, unknown>;
    readonly kind: "query" | "mutation";
    readonly tree: SelNode;
}
declare const GqlTransport_base: Context.ServiceClass<GqlTransport, "@distilled.cloud/graphql/Transport", {
    readonly execute: (req: CompiledOperation) => Effect.Effect<GraphQLResponse, GraphQLTransportError, any>;
}>;
export declare class GqlTransport extends /*@__PURE__*/ GqlTransport_base {
}
/**
 * GraphQL fields copied onto a Query so `user.name` type-checks.
 * `Query<User>` contains `projects: Query<Project[]>`, which contains
 * `owner: Query<User>` again -- TypeScript leaves the cycle lazy. Fields
 * inherit the errors of the root they were read from.
 */
type QueryFields<Value, Error> = [NonNullable<Value>] extends [ReadonlyArray<infer Item>] ? {
    readonly [Field in keyof NonNullable<Item>]: Query<NonNullable<Item>[Field] | Nullish<Item>, Error>;
} & {
    (args: Record<string, unknown>): Query<Value, Error>;
} : [NonNullable<Value>] extends [object] ? {
    readonly [Field in keyof NonNullable<Value>]: Query<NonNullable<Value>[Field] | Nullish<Value>, Error>;
} : {};
/** A field read through a `null` parent is `null`. */
type Nullish<Value> = Extract<Value, null | undefined>;
/**
 * A lazy GraphQL selection. `Value` is the plain data after `Query.fn` runs;
 * `Error` is the union of typed errors the roots it reads can return.
 */
export type Query<Value, Error = never> = QueryNode<Value, Error> & QueryFields<Value, Error>;
/** Strip Query/Effect wrappers from a returned plan down to plain data. */
export type UnwrapPlan<Plan> = Plan extends QueryNode<infer Value, any> ? Value : Plan extends Effect.Effect<infer Success, any, any> ? Success : Plan extends ReadonlyArray<infer Element> ? ReadonlyArray<UnwrapPlan<Element>> : Plan extends object ? {
    readonly [Key in keyof Plan]: UnwrapPlan<Plan[Key]>;
} : Plan;
/** Typed errors of every Query and Effect in a returned plan. */
export type PlanError<Plan> = Plan extends QueryNode<any, infer Error> ? Error : Plan extends Effect.Effect<any, infer Error, any> ? Error : Plan extends ReadonlyArray<infer Element> ? PlanError<Element> : Plan extends object ? {
    readonly [Key in keyof Plan]: PlanError<Plan[Key]>;
}[keyof Plan] : never;
/** Failures of evaluating a plan whose roots declare `Error`. */
export type QueryError<Error> = Error | GraphQLFailure<Extract<Error, GraphQLIssue> | UnknownGraphQLError> | UnknownGraphQLError | GraphQLTransportError;
type Expr = RootExpr | PropExpr | ItemExpr | MapValueExpr | MapItemsExpr | FilterExpr | FlatMapExpr | LiteralExpr;
type RootExpr = {
    readonly _tag: "Root";
    readonly op: "query" | "mutation";
    readonly field: string;
    readonly args: Record<string, unknown> | undefined;
    readonly argTypes: ArgMeta | undefined;
    readonly type: TypeRef;
    /** Relay connection: paint `edges { node }`, extract an array of nodes. */
    readonly connection?: boolean;
    /** Errors this root field can return, including global errors. */
    readonly errors: ReadonlyArray<ErrorSpec>;
    /** Leaf root whose value is a secret: extracted strings are wrapped in `Redacted`. */
    readonly sensitive?: boolean;
};
type PropExpr = {
    readonly _tag: "Prop";
    readonly parent: Expr;
    readonly field: FieldMeta;
    readonly type: TypeRef;
    readonly args?: Record<string, unknown>;
};
type ItemExpr = {
    readonly _tag: "Item";
    readonly list: Expr;
    readonly type: TypeRef;
};
type MapValueExpr = {
    readonly _tag: "MapValue";
    readonly parent: Expr;
    readonly mapFn: (value: unknown) => unknown;
    readonly type: TypeRef;
};
type MapItemsExpr = {
    readonly _tag: "MapItems";
    readonly parent: Expr;
    readonly mapped: unknown;
    /** Map one object (`null` stays `null`) instead of every list item. */
    readonly single?: boolean;
    readonly type: TypeRef;
};
type FilterExpr = {
    readonly _tag: "Filter";
    readonly parent: Expr;
    readonly predicate: Expr;
    readonly type: TypeRef;
};
type FlatMapExpr = {
    readonly _tag: "FlatMap";
    readonly parent: Expr;
    readonly flatMapFn: (value: unknown) => unknown;
    readonly type: TypeRef;
};
type LiteralExpr = {
    readonly _tag: "Literal";
    readonly value: unknown;
    readonly type: TypeRef;
};
export declare class QueryNode<out Value = unknown, out Error = never> {
    readonly [QuerySymbol]: symbol;
    readonly valueType: Value;
    readonly errorType: Error;
    readonly expr: Expr;
    constructor(expr: Expr);
    pipe<Self>(this: Self): Self;
    pipe<Self, Out1>(this: Self, step1: (_: Self) => Out1): Out1;
    pipe<Self, Out1, Out2>(this: Self, step1: (_: Self) => Out1, step2: (_: Out1) => Out2): Out2;
    pipe<Self, Out1, Out2, Out3>(this: Self, step1: (_: Self) => Out1, step2: (_: Out1) => Out2, step3: (_: Out2) => Out3): Out3;
    pipe<Self, Out1, Out2, Out3, Out4>(this: Self, step1: (_: Self) => Out1, step2: (_: Out1) => Out2, step3: (_: Out2) => Out3, step4: (_: Out3) => Out4): Out4;
    pipe<Self, Out1, Out2, Out3, Out4, Out5>(this: Self, step1: (_: Self) => Out1, step2: (_: Out1) => Out2, step3: (_: Out2) => Out3, step4: (_: Out3) => Out4, step5: (_: Out4) => Out5): Out5;
    pipe<Self, Out1, Out2, Out3, Out4, Out5, Out6>(this: Self, step1: (_: Self) => Out1, step2: (_: Out1) => Out2, step3: (_: Out2) => Out3, step4: (_: Out3) => Out4, step5: (_: Out4) => Out5, step6: (_: Out5) => Out6): Out6;
    pipe<Self, Out1, Out2, Out3, Out4, Out5, Out6, Out7>(this: Self, step1: (_: Self) => Out1, step2: (_: Out1) => Out2, step3: (_: Out2) => Out3, step4: (_: Out3) => Out4, step5: (_: Out4) => Out5, step6: (_: Out5) => Out6, step7: (_: Out6) => Out7): Out7;
    pipe<Self, Out1, Out2, Out3, Out4, Out5, Out6, Out7, Out8>(this: Self, step1: (_: Self) => Out1, step2: (_: Out1) => Out2, step3: (_: Out2) => Out3, step4: (_: Out3) => Out4, step5: (_: Out4) => Out5, step6: (_: Out5) => Out6, step7: (_: Out6) => Out7, step8: (_: Out7) => Out8): Out8;
    [inspect](): string;
    toString(): string;
}
export declare const isQuery: (value: unknown) => value is Query<unknown>;
export declare const root: <Value, Error = never>(op: "query" | "mutation", field: string, meta: TypeMeta, args?: Record<string, unknown>, argTypes?: ArgMeta, errors?: ReadonlyArray<ErrorSpec>) => Query<Value, Error>;
export declare const rootList: <Item, Error = never>(op: "query" | "mutation", field: string, meta: TypeMeta, args?: Record<string, unknown>, argTypes?: ArgMeta, errors?: ReadonlyArray<ErrorSpec>) => Query<ReadonlyArray<Item>, Error>;
/** Root Relay connection: typed as `Query<Item[]>`, document uses `edges { node }`. */
export declare const rootConnection: <Item, Error = never>(op: "query" | "mutation", field: string, meta: TypeMeta, args?: Record<string, unknown>, argTypes?: ArgMeta, errors?: ReadonlyArray<ErrorSpec>) => Query<ReadonlyArray<Item>, Error>;
/** Root field whose GraphQL type is a scalar, enum, or list of those. */
export declare const rootLeaf: <Value, Error = never>(op: "query" | "mutation", field: string, list: boolean, args?: Record<string, unknown>, argTypes?: ArgMeta, errors?: ReadonlyArray<ErrorSpec>, options?: {
    readonly sensitive?: boolean;
}) => Query<Value, Error>;
/** `Query.of` / pure. */
export declare const ofQuery: <Value>(value: Value) => Query<Value>;
export declare function filterQuery<Item, Error = never>(predicate: (item: Query<Item>) => QueryNode<boolean, any>): (source: QueryNode<readonly Item[] | null, Error>) => Query<readonly Item[], Error>;
export declare function filterQuery<Item, Error = never>(source: QueryNode<readonly Item[] | null, Error>, predicate: (item: Query<Item>) => QueryNode<boolean, any>): Query<readonly Item[], Error>;
/**
 * What `Query.map`'s callback receives: a Query per item for lists, a Query
 * for an object (so its fields get selected), the plain value for scalars.
 */
type MapInput<Value> = [NonNullable<Value>] extends [ReadonlyArray<infer Item>] ? Query<Item> : [NonNullable<Value>] extends [object] ? Query<NonNullable<Value>> : Value;
/** An object mapped through a `null` value stays `null`. */
type MapOutput<Value, Mapped> = [NonNullable<Value>] extends [ReadonlyArray<unknown>] ? ReadonlyArray<UnwrapPlan<Mapped>> : [NonNullable<Value>] extends [object] ? UnwrapPlan<Mapped> | Nullish<Value> : Mapped;
export declare function mapQuery<Value, Mapped, Error = never>(mapFn: (value: NoInfer<MapInput<Value>>) => Mapped): (source: QueryNode<Value, Error>) => Query<MapOutput<Value, Mapped>, Error>;
export declare function mapQuery<Value, Mapped, Error = never>(source: QueryNode<Value, Error>, mapFn: (value: NoInfer<MapInput<Value>>) => Mapped): Query<MapOutput<Value, Mapped>, Error>;
export declare function flatMapQuery<Value, Result, Error, Requirements, SourceError = never>(flatMapFn: (value: Value) => Effect.Effect<Result, Error, Requirements> | QueryNode<Result, Error>): (source: QueryNode<Value, SourceError>) => Query<Result, SourceError | Error>;
export declare function flatMapQuery<Value, Result, Error, Requirements, SourceError = never>(source: QueryNode<Value, SourceError>, flatMapFn: (value: Value) => Effect.Effect<Result, Error, Requirements> | QueryNode<Result, Error>): Query<Result, SourceError | Error>;
/**
 * Builder -> Effect. The inner function is *not* a generator; it returns a
 * plan of Query/Effect values. Query.fn visits the plan, POSTs one document,
 * then interprets Map/Filter/FlatMap/Of.
 */
export declare const queryFn: <Arguments extends Array<unknown>, Plan>(build: (...args: Arguments) => Plan) => ((...args: Arguments) => Effect.Effect<UnwrapPlan<Plan>, QueryError<PlanError<Plan>>, GqlTransport>);
/**
 * Every page of a Relay connection, one request per page. `query` is a
 * connection lens (root or nested under objects), optionally mapped or
 * filtered: `Query.pages(Railway.project({ id }).services({ first: 50 }))`.
 * Starts from the query's own `after` argument, if any.
 */
export declare const pagesQuery: <Item, Error>(query: QueryNode<ReadonlyArray<Item> | null, Error>) => Stream.Stream<ReadonlyArray<Item>, QueryError<Error> | GraphQLPaginationError, GqlTransport>;
/** Every node of a Relay connection, across all pages. */
export declare const itemsQuery: <Item, Error>(query: QueryNode<ReadonlyArray<Item> | null, Error>) => Stream.Stream<Item, QueryError<Error> | GraphQLPaginationError, GqlTransport>;
export {};
//# sourceMappingURL=graphql.d.ts.map