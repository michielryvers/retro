export declare const annotationMetaSymbol: unique symbol;
export type Annotatable = {
    annotate(annotations: any): Annotatable;
};
export interface Annotation {
    <A extends Annotatable>(schema: A): A;
    readonly [annotationMetaSymbol]: Array<{
        symbol: symbol | string;
        value: unknown;
    }>;
    readonly [key: symbol]: unknown;
    readonly [key: string]: unknown;
}
/**
 * Build a pipeable schema annotation carrying `value` under `sym`. Exported
 * so SDK packages can define their own protocol traits (e.g. cloudflare's
 * envelope traits, aws's smithy traits) with the same mechanics as the
 * generic ones here. Keys may be symbols or plain strings -- effect Schema
 * annotation dictionaries accept both.
 */
export declare function makeAnnotation<T>(sym: symbol | string, value: T): Annotation;
/**
 * Combine several annotations into one -- needed where only a single
 * annotations object can be supplied (e.g. the second argument of
 * `S.Class`).
 */
export declare function all(...annotations: Annotation[]): Annotation;
export interface HttpTrait {
    readonly method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE" | "HEAD" | "OPTIONS";
    /** URI template relative to the service base URL, e.g. `/accounts/{account_id}/foo`. */
    readonly uri: string;
    /** Default success status code (a `ResponseCode()` member can still read the actual code). */
    readonly code?: number;
    /**
     * Request body encoding. Default is JSON; `"multipart"` sends
     * multipart/form-data -- body members become form parts (objects
     * JSON-encoded) and members marked `FormDataFile()` append their files.
     * `"form-urlencoded"` sends application/x-www-form-urlencoded with
     * Stripe-style bracket notation for nested objects and arrays (see
     * `buildRequest`).
     */
    readonly contentType?: "multipart" | "form-urlencoded";
    /**
     * Explicit `Content-Type` for a whole-body (`HttpBody()`) member carrying a
     * preserialized payload, when the API requires a specific media type rather
     * than JSON (e.g. `application/x-ndjson` for Vectorize insert/upsert). The
     * member value is sent verbatim (string/bytes) under this media type.
     */
    readonly bodyMediaType?: string;
    /**
     * Explicit `Accept` for the operation, when the API serves more than one
     * response media type. Atlas pins an API version this way (e.g.
     * `application/vnd.atlas.2024-05-30+json` -- `application/json` alone is a
     * 406). Protocols that don't read it fall back to their own default.
     */
    readonly accept?: string;
}
export declare const httpSymbol: unique symbol;
/**
 * Operation-level HTTP binding: the request method + URI template. Stamped on
 * the input schema so the protocol can build the request line. URI `{labels}`
 * are filled from members marked with `Label()`.
 */
export declare const Http: (trait: HttpTrait) => Annotation;
export declare const labelSymbol: unique symbol;
/** Bind a member to a `{name}` placeholder in the operation's URI template. */
export declare const Label: (name?: string) => Annotation;
export declare const labelEncodingSymbol: unique symbol;
/** Preserve selected RFC 3986 pchar delimiters inside a single URI label. */
export declare const LabelEncoding: (options: {
    readonly preserve: string;
}) => Annotation;
export declare const responseCodeSymbol: unique symbol;
export declare const ResponseCode: () => Annotation;
export declare const headerSymbol: unique symbol;
export declare const Header: (name?: string) => Annotation;
export declare const bodySymbol: unique symbol;
export declare const Body: (name?: string) => Annotation;
export declare const querySymbol: unique symbol;
export declare const Query: (name?: string) => Annotation;
export declare const deepQuerySymbol: unique symbol;
/**
 * Binds a struct-valued input member to a family of DOTTED query parameters:
 * `{ account: { id, name } }` with `DeepQuery("account")` serializes as
 * `?account.id=...&account.name=...` (null/undefined entries skipped). This is
 * how several list endpoints model their filters on the wire (e.g.
 * Cloudflare zones list `account.id` / `account.name`) while the TS surface
 * keeps the nested-object shape (v0 parity).
 */
export declare const DeepQuery: (name?: string) => Annotation;
export declare const httpBodySymbol: unique symbol;
/**
 * Marks the input member whose value IS the entire request body (raw arrays/
 * scalars -- e.g. endpoints that POST a bare JSON array). Mirrors
 * `smithy.api#httpPayload`.
 */
export declare const HttpBody: () => Annotation;
export declare const stringEncodedSymbol: unique symbol;
/**
 * Marks a member the API only accepts as the STRING spelling of its value --
 * `true` travels as `"true"`, `3` as `"3"` -- while the TS surface keeps the
 * natural type (e.g. Cloudflare's multipart `validation_enabled`, which the
 * docs model as the enum `"true" | "false"`). The protocol stringifies body
 * members on encode, element-wise for lists; `null` is left alone. Query and
 * header bindings already serialize their values as strings, so the trait is
 * documentation there.
 */
export declare const StringEncoded: () => Annotation;
export declare const formDataFileSymbol: unique symbol;
/**
 * Marks an input member holding `File`/`Blob` parts for a multipart upload
 * (`Http({ contentType: "multipart" })`). Each file is appended to the form
 * under its own filename.
 */
export declare const FormDataFile: () => Annotation;
export declare const keyDictionarySymbol: unique symbol;
/**
 * Deep TS-name->wire-name key dictionary for members whose full structure is
 * not modeled (opaque `Document` content). The protocol renames any matching
 * key at any depth on encode (and the reverse on decode); keys not in the
 * dictionary pass through verbatim.
 *
 * A value may be an array of wire names when the API itself is inconsistent
 * (e.g. queues consumer responses name the worker script `script_name` on
 * create/update but `script` on get/list): the first entry is the canonical
 * wire name used on encode; decode maps every listed spelling back to the
 * TS name.
 */
export type KeyDictionaryEntries = Record<string, string | ReadonlyArray<string>>;
export declare const KeyDictionary: (dict: KeyDictionaryEntries) => Annotation;
export declare const unionCasesSymbol: unique symbol;
/**
 * The literal member every case of a union fixes to its own value -- what the
 * docs call the resource `type` or the action `id`. `values[i]` is the value
 * case `i` carries.
 */
export interface UnionDiscriminator {
    readonly key: string;
    readonly values: ReadonlyArray<string>;
}
/**
 * Marks an opaque schema standing in for a discriminated union of object
 * cases, carrying each case's TS-facing key set. For APIs that return every
 * case's keys with `null` for the inactive ones, the protocol uses these key
 * sets to pick the active case and drop the others, so consumers' `"key" in
 * value` discrimination works.
 *
 * Key sets alone cannot tell apart cases that share them -- the 41 resource
 * kinds of `resource_tagging`, the 34 page-rule actions -- so when the union
 * has a discriminator the protocol reads the case off it and only falls back
 * to key-set scoring for a value whose tag is missing or unknown.
 */
export declare const UnionCases: (cases: ReadonlyArray<ReadonlyArray<string>>, discriminator?: UnionDiscriminator) => Annotation;
export declare const errorMatchersSymbol: unique symbol;
/** Exact text, or the conjunction of substring and regular-expression constraints. */
export type ErrorTextMatcher = string | {
    readonly includes?: string;
    readonly matches?: string;
};
/**
 * One wire-matching rule. All supplied constraints must match; separate
 * matchers on a class are alternatives. Empty matchers match nothing.
 *
 * `body` maps RFC 6901 JSON Pointers to scalar constraints. For example,
 * `{ "/success": false, "/result/status": "error" }`. Strings also accept
 * `includes` / `matches`. Missing fields never match, including against null.
 * The empty pointer addresses the entire body; array indices are supported.
 * Header names are case-insensitive; their value constraints are case-sensitive.
 * Each body path and header adds one specificity point, like code/status/message.
 * Protocols evaluate these rules only after identifying a failed response.
 *
 * @example
 * ```ts
 * { status: 200, body: { "/success": false, "/result/status": "error" } }
 * { status: 409, headers: { "x-error-type": { includes: "Conflict" } } }
 * ```
 */
export interface ErrorMatcher {
    readonly code?: number;
    readonly status?: number;
    readonly message?: ErrorTextMatcher;
    readonly body?: Readonly<Record<string, ErrorTextMatcher | number | boolean | null>>;
    readonly headers?: Readonly<Record<string, ErrorTextMatcher>>;
}
/**
 * Stamp wire-matching rules onto a generated error class. Protocols consult
 * these to decide which of an operation's declared error classes a failed
 * response should surface as (most specific matcher wins; ties break by
 * declaration order -- see `matchTypedError` in `core/protocol-http`).
 */
export declare const applyErrorMatchers: <C>(cls: C, matchers: ReadonlyArray<ErrorMatcher>) => C;
/** Read the matchers stamped on an error class, if any. */
export declare const getErrorMatchers: (cls: unknown) => ReadonlyArray<ErrorMatcher> | undefined;
//# sourceMappingURL=trait.d.ts.map