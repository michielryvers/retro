import * as Effect from "effect/Effect";
import * as Option from "effect/Option";
import * as Redact from "effect/Redacted";
declare const ConfigMissing_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ConfigError";
} & Readonly<A>;
/** A required configuration value is missing. */
export declare class ConfigMissing extends /*@__PURE__*/ ConfigMissing_base<{
    readonly name: string;
    readonly message: string;
}> {
}
/** The string value of environment variable `name`. */
export declare const String: (name: string) => Effect.Effect<string, ConfigMissing>;
/** The value of `name`, redacted. */
export declare const Redacted: (name: string) => Effect.Effect<Redact.Redacted<string>, ConfigMissing>;
/** The value as an `Option`: `None` when missing. */
export declare const option: <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<Option.Option<A>, never, R>;
/** Use `value` when missing. */
export declare const withDefault: <B>(value: B) => <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A | B, never, R>;
/** Try `that` when missing. */
export declare const orElse: <A2, E2, R2>(that: () => Effect.Effect<A2, E2, R2>) => <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A | A2, E2, R | R2>;
export declare const map: <A, B>(f: (a: A) => B) => <E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<B, E, R>;
/** Read every value of a struct of readers. */
export declare const all: <const T extends Record<string, Effect.Effect<any, any, any>>>(readers: T) => Effect.Effect<{ -readonly [K in keyof T]: Effect.Success<T[K]>; }, Effect.Error<T[keyof T]>, Effect.Services<T[keyof T]>>;
export {};
//# sourceMappingURL=config.d.ts.map