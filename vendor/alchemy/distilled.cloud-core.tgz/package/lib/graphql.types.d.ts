/** Compile-only: Query.fn unwraps Query/Effect fields on the returned plan. */
import type { Query } from "./query.ts";
declare class NotFound {
    readonly _tag: "NotFound";
    readonly message: string;
}
declare const services: Query<ReadonlyArray<{
    name: string;
}>, NotFound>;
export type _Services = typeof services;
export {};
//# sourceMappingURL=graphql.types.d.ts.map