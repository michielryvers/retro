/**
 * Minimal schemas for generated SDK code: plain objects shaped like Effect
 * Schema ASTs (`_tag`, `annotations`, `propertySignatures`, `types`,
 * `thunk`, `encoding`), without Effect Schema's parser, issue and
 * transformation machinery.
 *
 * Request encoding and lenient response decoding only walk the AST: they
 * read wire names, HTTP bindings and the shape of the value. Importing
 * `effect/Schema` to build those ASTs put about 37 KB gzip of decode
 * machinery into every bundle that never decodes. These nodes carry the
 * same fields protocol code reads, so it runs unchanged.
 *
 * When a caller asks for real validation (`ResponseValidation.strict` or
 * `additionalProperties`), {@link toEffect} rebuilds the equivalent Effect
 * schema from a lite node, loading `effect/Schema` only then.
 *
 * Every value here has the members generated code uses on schemas: `.ast`,
 * `.pipe(...)`, `.annotate(...)`, `.fields` (structs) and `.key`/`.value`
 * (records).
 */
import type * as Cause from "effect/Cause";
import { type Pipeable } from "effect/Pipeable";
import type * as EffectSchema from "effect/Schema";
export type Annotations = Record<string | symbol, unknown>;
/** A lite AST node. Field names match Effect's SchemaAST where protocols read them. */
export interface Node {
    readonly _tag: string;
    readonly annotations?: Annotations;
    /**
     * The wire-side node, for nodes whose value changes on the wire (AWS
     * timestamps, blobs, sensitive values). Same shape as Effect's encoding
     * chain, so code that follows `encoding[0].to` reads the wire type.
     */
    readonly encoding?: ReadonlyArray<{
        readonly to: Node;
    }>;
    /** Declaration: the type guard strict validation applies (Unknown without one). */
    readonly check?: (u: unknown) => boolean;
    readonly context?: {
        readonly isOptional: boolean;
    };
    /** Objects */
    readonly propertySignatures?: ReadonlyArray<PropertySignature>;
    readonly indexSignatures?: ReadonlyArray<{
        readonly parameter: Node;
        readonly type: Node;
    }>;
    /** Union */
    readonly types?: ReadonlyArray<Node>;
    /** Arrays */
    readonly elements?: ReadonlyArray<Node>;
    readonly rest?: ReadonlyArray<Node>;
    /** Suspend */
    readonly thunk?: () => Node;
    /** Literal */
    readonly literal?: unknown;
    /** Declaration */
    readonly typeParameters?: ReadonlyArray<Node>;
}
export interface PropertySignature {
    readonly name: PropertyKey;
    readonly type: Node;
}
/** A lite schema value: what generated code holds and passes around. */
export interface Lite {
    readonly ast: Node;
    readonly "~lite": true;
    pipe(...fns: ReadonlyArray<(s: any) => any>): any;
    annotate(annotations: Annotations): Lite;
}
/** Marks lite nodes so strict validation knows to convert them. */
export declare const liteKey = "~lite";
/** A lite schema for a hand-built node (SDK-specific declarations). */
export declare const fromNode: (n: Node) => Lite;
export declare const isLite: (u: unknown) => u is Lite;
export declare const String: Lite;
export declare const Number: Lite;
export declare const Boolean: Lite;
export declare const Unknown: Lite;
export declare const Any: Lite;
export declare const Null: Lite;
export declare const Void: Lite;
export declare const Undefined: Lite;
export declare const Literal: (value: unknown) => Lite;
export declare const Literals: (values: ReadonlyArray<unknown>) => Lite;
export declare const optional: (s: Lite) => Lite;
export declare const NullOr: (s: Lite) => Lite;
export declare const Union: (members: ReadonlyArray<Lite>) => Lite;
export declare const Array: (item: Lite) => Lite;
export declare const Tuple: (elements: ReadonlyArray<Lite>) => Lite;
export declare const Record: (key: Lite, value: Lite) => Lite;
export declare const Struct: (fields: Readonly<Record<string, Lite>>) => Lite;
/**
 * A struct that also allows keys it does not declare (OpenAPI
 * `additionalProperties` next to `properties`): the struct's property
 * signatures plus each record's index signature, as Effect's
 * `StructWithRest` builds them.
 */
export declare const StructWithRest: (struct: Lite, records: ReadonlyArray<Lite>) => Lite;
/** A lazily resolved schema; `.ast` is a Suspend node whose thunk resolves the target. */
export declare const suspend: (f: () => Lite) => Lite;
/** Rename struct keys on the wire: `{ typeKey: "wire_key" }`. */
export declare const encodeKeys: (mapping: Readonly<Record<string, string>>) => (s: Lite) => Lite;
export declare const encodeKeysKey = "@distilled.cloud/core/schema-lite/encodeKeys";
export declare const Date: Lite;
export declare const Duration: Lite;
export declare const Redacted: (value: Lite) => Lite;
export declare const instanceOf: (cls: Function, annotations?: Annotations) => Lite;
export declare const declare: (_is: (u: unknown) => boolean, annotations?: Annotations) => Lite;
/**
 * The type of a lite tagged error class: what the class really has. It is
 * not an Effect Schema, so `Schema.is(E)`, `Schema.decode(E)` and friends do
 * not compile against it -- at runtime they would fail on the lite `.ast`.
 * Match errors with `_tag` (`Effect.catchTag`) or `instanceof`.
 */
export interface TaggedErrorClass<Tag extends string, Fields extends EffectSchema.Struct.Fields> extends Pipeable {
    new (...args: {} extends EffectSchema.Struct.MakeIn<Fields> ? [props?: EffectSchema.Struct.MakeIn<Fields>] : [props: EffectSchema.Struct.MakeIn<Fields>]): Cause.YieldableError & {
        readonly _tag: Tag;
    } & EffectSchema.Struct.Type<Fields>;
    /** `new this(props)`. */
    make<C extends abstract new (...args: any) => any>(this: C, ...args: ConstructorParameters<C>): InstanceType<C>;
    /**
     * Whether `u` is an error of this class, by `_tag`, so it holds across
     * duplicate copies of a package (`instanceof` does not). Errors of another
     * service with the same tag also match.
     */
    is<C extends abstract new (...args: any) => any>(this: C, u: unknown): u is InstanceType<C>;
    readonly fields: Fields;
    readonly identifier: Tag;
    /** The lite struct node (not an Effect Schema AST). */
    readonly ast: Node;
}
/**
 * `TaggedError<Self>()(tag, fields)`, typed by the field schemas. `Self` is
 * accepted for source compatibility with `Schema.TaggedError` and unused.
 */
export type TaggedErrorFactory = <_Self = never>(identifier?: string) => <Tag extends string, const Fields extends EffectSchema.Struct.Fields = {}>(tag: Tag, fields?: Fields, annotations?: object) => TaggedErrorClass<Tag, Fields>;
/**
 * A tagged error class without Effect Schema. It does not validate on
 * construction. Carries `.fields` and `.identifier`, and a static `.pipe`
 * for category decorators.
 */
export declare const TaggedError: (_identifier?: string) => (tag: string, fields?: Readonly<Record<string, Lite>>, annotations?: object) => any;
/**
 * Schema `j` of builder `build`, made on first use (the lite `chunks.at`).
 * Its `.ast` is the built schema's own node, not a Suspend around it, so
 * protocol code sees the same node shapes as with eager schemas.
 */
export declare const at: (build: (j: number) => unknown, j: number) => any;
/**
 * The Effect schema equivalent to a lite node, for strict decoding. Loaded
 * on demand so `effect/Schema` is only bundled/imported by callers that
 * validate.
 */
/** The Effect Schema functions the bridge uses (passed in, so callers import only these). */
export type EffectSchemaApi = Pick<typeof import("effect/Schema"), "Any" | "Array" | "Boolean" | "Literal" | "Null" | "Number" | "Record" | "String" | "Struct" | "StructWithRest" | "Tuple" | "Undefined" | "Union" | "Unknown" | "Void" | "declare" | "make" | "optional" | "suspend">;
export declare const toEffect: (S: EffectSchemaApi, ast: Node) => unknown;
//# sourceMappingURL=schema-lite-impl.d.ts.map