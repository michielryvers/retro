import { Effect } from "effect";
/** Run a dev-time tool, failing the generate run if it does. */
export declare const runTool: (argv: readonly string[]) => Effect.Effect<void, never, never>;
/** Format a generated directory in place. */
export declare const formatGenerated: (dir: string) => Effect.Effect<void, never, never>;
/**
 * Lint-fix then format. `oxlint --fix` can leave its rewrites unformatted,
 * so the formatter has to run after it, not before.
 */
export declare const lintAndFormatGenerated: (dir: string) => Effect.Effect<void, never, never>;
//# sourceMappingURL=format.d.ts.map