/** `code` with every non-Latin-1 character escaped (literals) or spelled in ASCII (elsewhere). */
export declare const toLatin1: (code: string, filename?: string) => string;
//# sourceMappingURL=latin1.d.ts.map