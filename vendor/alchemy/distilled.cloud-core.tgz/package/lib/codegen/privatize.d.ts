type Node = {
    readonly type: string;
    readonly start: number;
    readonly end: number;
} & Record<string, unknown>;
/** Value-position identifier names under `node` (type annotations, keys and member names excluded). */
export declare const valueRefs: (node: unknown, out: Set<string>, parent?: Node, parentKey?: string) => Set<string>;
export declare const privatizeSchemas: (code: string, filename?: string) => {
    code: string;
    privatized: number;
    removed: number;
};
/**
 * `import * as X` whose namespace is used only in type positions becomes
 * `import type * as X`. The generator's `oxlint --fix` otherwise deletes it
 * as unused once the schema consts that used it as a value are gone, and the
 * types that still name it stop compiling.
 */
export declare const typeOnlyNamespaceImports: (code: string, filename?: string) => string;
export {};
//# sourceMappingURL=privatize.d.ts.map