/**
 * Shared GraphQL → Smithy 2.0 converter (dev-time only).
 *
 * A GraphQL endpoint has no per-operation URLs, no path/query/header bindings
 * and no response shapes to speak of: there is one POST, one request envelope
 * (`{ query, operationName, variables }`) and one response envelope
 * (`{ data, errors }`). What varies per operation is the *document* — which
 * root field is called, which variables it takes, and which selection set
 * comes back. This module turns an introspection schema into a Smithy model
 * carrying exactly that:
 *
 *   • operation      → `smithy.api#http` (POST <endpoint>) + the op shape
 *   • input struct   → `<traits.operation>` { query, operationName, type } —
 *                      the baked GraphQL document for the op
 *   • output struct  → `<traits.responsePath>` ("account.byId") — the path
 *                      under `data` the protocol unwraps
 *   • nullability    → `<traits.nullable>` on members,
 *                      `<traits.nullableItems>` on list shapes (GraphQL
 *                      nullability is not Smithy optionality: a selected
 *                      field is always *delivered*, it just may be `null`)
 *   • bare results   → `<traits.payload>` on the sole `result` member when
 *                      the leaf returns a list/scalar (the response IS that
 *                      value)
 *   • connections    → `smithy.api#paginated` when a root field looks like a
 *                      Relay connection (see {@link RelayOptions})
 *
 * Trait *ids* are caller-supplied so each SDK keeps its own vocabulary
 * namespace; the generator side maps them back to that SDK's trait module.
 *
 * ─── Operation discovery ────────────────────────────────────────────────────
 * Most schemas put operations directly on Query/Mutation, but some namespace
 * them behind objects whose fields are the real operations (`account.byId`).
 * `maxNamespaceDepth` bounds how far that expansion goes; set it to 1 for a
 * flat schema. Selection sets are expanded to `maxDepth` levels, cycles
 * short-circuit, and fields that themselves take arguments are not selected
 * (we have no value to pass them).
 *
 * Originally distilled v0's `core/scripts/generate-graphql.ts`, generalized
 * out of packages/expo-eas.
 */
export type TypeKind = "SCALAR" | "OBJECT" | "INTERFACE" | "UNION" | "ENUM" | "INPUT_OBJECT" | "LIST" | "NON_NULL";
export interface TypeRef {
    kind: TypeKind;
    name?: string | null;
    ofType?: TypeRef | null;
}
export interface InputValue {
    name: string;
    description?: string | null;
    type: TypeRef;
    defaultValue?: string | null;
}
export interface Field {
    name: string;
    description?: string | null;
    args: InputValue[];
    type: TypeRef;
    isDeprecated?: boolean;
}
export interface IntrospectionType {
    kind: TypeKind;
    name: string;
    description?: string | null;
    fields?: Field[] | null;
    inputFields?: InputValue[] | null;
    enumValues?: Array<{
        name: string;
        isDeprecated?: boolean;
    }> | null;
    possibleTypes?: TypeRef[] | null;
}
export interface IntrospectionSchema {
    queryType: {
        name: string;
    };
    mutationType?: {
        name: string;
    } | null;
    subscriptionType?: {
        name: string;
    } | null;
    types: IntrospectionType[];
}
/**
 * Pull the `__schema` out of an introspection response, accepting either the
 * bare schema, `{ __schema }`, or a full `{ data: { __schema } }` envelope —
 * all three are shipped by real mirrors.
 */
export declare const readIntrospection: (json: unknown) => IntrospectionSchema;
export declare const PRELUDE: {
    readonly String: "smithy.api#String";
    readonly Boolean: "smithy.api#Boolean";
    readonly Integer: "smithy.api#Integer";
    readonly Long: "smithy.api#Long";
    readonly Double: "smithy.api#Double";
    readonly Timestamp: "smithy.api#Timestamp";
    readonly Document: "smithy.api#Document";
};
/**
 * The Smithy trait ids this converter stamps. Each SDK owns its own trait
 * namespace (`com.expo.graphql#operation`, `com.railway.graphql#operation`,
 * …) and maps them back to its trait module in its `generate.ts`.
 */
export interface GraphQLTraitIds {
    /** On the input struct: the baked `{ query, operationName, type }`. */
    readonly operation: string;
    /** On the output struct: the dotted path under `data` to unwrap. */
    readonly responsePath: string;
    /** On members: the GraphQL type was nullable. */
    readonly nullable: string;
    /** On list shapes: the GraphQL *element* type was nullable. */
    readonly nullableItems: string;
    /** On the sole `result` member: the response IS this value. */
    readonly payload: string;
}
/**
 * Relay connection detection. A root field paginates when its return type
 * looks like a connection (an `edges` list of objects with a `node`, plus a
 * `pageInfo`) AND it accepts the forward-pagination arguments.
 *
 * The emitted `smithy.api#paginated` trait drives `.pages()` / `.items()` in
 * the generated SDK; `items` deliberately points *through* the edges
 * (`edges.node`) so `.items()` streams nodes rather than edge wrappers.
 */
export interface RelayOptions {
    /** Cursor argument fed the previous page's `endCursor`. Default `"after"`. */
    readonly after?: string;
    /** Page-size argument. Default `"first"`. */
    readonly first?: string;
    /** Connection field holding the edge list. Default `"edges"`. */
    readonly edges?: string;
    /** Edge field holding the item. Default `"node"`. */
    readonly node?: string;
    /** Connection field holding the cursor/termination block. Default `"pageInfo"`. */
    readonly pageInfo?: string;
    /** `pageInfo` field holding the next cursor. Default `"endCursor"`. */
    readonly endCursor?: string;
    /** `pageInfo` field saying whether more pages exist. Default `"hasNextPage"`. */
    readonly hasNextPage?: string;
    /** Pagination mode written into the trait. Default `"relay"`. */
    readonly mode?: string;
}
export interface GraphQLConvertOptions {
    /** The introspection schema (see {@link readIntrospection}). */
    readonly schema: IntrospectionSchema;
    /** Smithy namespace for every generated shape, e.g. `"com.railway.api"`. */
    readonly namespace: string;
    /** Local name of the service shape, e.g. `"Railway"`. */
    readonly serviceName: string;
    /** `smithy.api#title` on the service shape. */
    readonly serviceTitle: string;
    /** `smithy.api#documentation` on the service shape. */
    readonly serviceDocumentation?: string;
    /** Service `version` field. Default `"1.0"`. */
    readonly serviceVersion?: string;
    /** HTTP path every operation POSTs to, e.g. `"/graphql/v2"`. */
    readonly endpoint: string;
    /** Trait ids to stamp (see {@link GraphQLTraitIds}). */
    readonly traits: GraphQLTraitIds;
    /** How many levels of selection set to expand. Default `3`. */
    readonly maxDepth?: number;
    /**
     * How many namespace objects an operation may sit behind. `1` means the
     * schema is flat (every operation is a direct Query/Mutation field).
     * Default `3`.
     */
    readonly maxNamespaceDepth?: number;
    /** Skip `@deprecated` root fields and namespace subfields. Default `true`. */
    readonly skipDeprecated?: boolean;
    /** Drop root fields by name (placeholders like `_doNotUse`). */
    readonly skipRootField?: (name: string) => boolean;
    /**
     * Custom (non-builtin) scalar name → Smithy prelude target. Unmapped
     * customs fall back to `smithy.api#Document` so nothing hard-fails, but
     * mapping them keeps the generated types honest.
     */
    readonly customScalars?: Record<string, string>;
    /** Relay connection pagination. Omit (or `false`) to emit no `paginated`. */
    readonly relay?: RelayOptions | false;
    /**
     * SDK operation name style. Default `"verbNoun"` (`projectCreate` →
     * `createProject`). The GraphQL document's `operationName` stays the
     * schema field name.
     */
    readonly operationNaming?: "as-is" | "verbNoun";
}
export interface GraphQLConvertResult {
    /** The Smithy 2.0 model, ready to `JSON.stringify`. */
    readonly model: {
        smithy: "2.0";
        metadata: Record<string, unknown>;
        shapes: Record<string, any>;
    };
    readonly converted: number;
    readonly failed: number;
    readonly paginated: number;
    readonly shapeCount: number;
}
/**
 * Turn a GraphQL introspection schema into a Smithy 2.0 model.
 *
 * Subscriptions are ignored: they are a streaming transport, not a
 * `POST /graphql` request/response pair, and nothing in the generated SDK
 * could speak them.
 */
export declare const convertGraphQLToSmithy: (options: GraphQLConvertOptions) => GraphQLConvertResult;
//# sourceMappingURL=graphql.d.ts.map