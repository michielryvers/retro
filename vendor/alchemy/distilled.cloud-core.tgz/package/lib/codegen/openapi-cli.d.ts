import { type OpenApiConvertOptions } from "./openapi.ts";
export interface OpenApiSpecEntry {
    /** Output model name — written to `<outDir>/<name>.json`. */
    readonly name: string;
    /** Spec file path, relative to `root` (or absolute). */
    readonly specPath: string;
    /**
     * Hook between reading and conversion (e.g. path prefixing, server
     * rewrites). May mutate the spec in place or return a replacement.
     */
    readonly preprocess?: (spec: any) => unknown | void | Promise<unknown | void>;
    /** Per-spec converter option overrides (merged over the shared options). */
    readonly options?: Partial<OpenApiConvertOptions>;
}
export interface RunOpenApiConvertOptions {
    /** Absolute package root (usually `path.resolve(import.meta.dirname, "..")`). */
    readonly root: string;
    readonly specs: readonly OpenApiSpecEntry[];
    /**
     * RFC-6902 patch root, relative to `root`. Default `"patches"`; `false`
     * disables. Layout: `<patchesDir>/<name>/*.json` when the per-spec
     * directory exists; for single-spec providers a flat `<patchesDir>/*.json`
     * also works. Every op targets the Smithy model (`/shapes`, `/metadata`).
     */
    readonly patchesDir?: string | false;
    /** Output directory, relative to `root`. Default `".generated-specs"`. */
    readonly outDir?: string;
    /**
     * Spec text parser. Default `JSON.parse` — the seam for YAML specs
     * (`parse: (text) => YAML.parse(text)`).
     */
    readonly parse?: (text: string, specPath: string) => unknown;
    /** Shared converter options (per-spec `options` merge over these). */
    readonly options: OpenApiConvertOptions;
    /**
     * What to do when a patch JSON pointer does not resolve. Default `"fail"`:
     * silent skip is how a whole patch chain can vanish after an upstream path
     * prefix change. `"warn"` restores the old skip-and-continue behaviour.
     */
    readonly onStalePatch?: "fail" | "warn";
    /**
     * Run {@link finalizeConvert} on the written models (Smithy patches,
     * deferred names, reference check, finalized marker). Default true. Pass
     * false when the caller finalizes once after several convert steps (Fly
     * machines + sprites + addons); its finalizeConvert must then apply the
     * Smithy patches, from `patches/<name>/`.
     */
    readonly finalize?: boolean;
}
/** Run the OpenAPI→Smithy conversion pipeline (plain async — call from a script). */
export declare const runOpenApiConvert: (o: RunOpenApiConvertOptions) => Promise<void>;
//# sourceMappingURL=openapi-cli.d.ts.map