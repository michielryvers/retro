/**
 * Shared naming utilities for the SDK generators (dev-time only — imported by
 * `packages/<sdk>/scripts/generate.ts`, never by runtime code).
 */
/** JSON-string-quote a value for emission into generated source. */
export declare const q: (s: string) => string;
/** Smithy shape id → local name (`ns#Shape` → `Shape`). */
export declare const local: (id: string) => string;
/** Whether a shape id is a smithy prelude shape (`smithy.api#…`). */
export declare const isPrelude: (id: string) => boolean;
/** Emit a TS object key: bare when a valid identifier, quoted otherwise. */
export declare const tsKey: (s: string) => string;
/** snake_case / kebab-case wire name → camelCase TS-facing name. */
export declare const camel: (s: string) => string;
/** Reserved words that can't be `const` names. */
export declare const RESERVED: Set<string>;
/**
 * Lower-case the first character for an exported operation name — unless the
 * result is a reserved word, in which case the original casing is kept.
 */
export declare const lowerFirst: (s: string) => string;
/** Upper-case the first character. */
export declare const upperFirst: (s: string) => string;
/**
 * Collapse a smithy documentation string to a single safe line for a
 * `/** … *​/` comment.
 */
export declare const oneLine: (s: string | undefined) => string | undefined;
//# sourceMappingURL=naming.d.ts.map