import type { ShapeMap } from "./graph.ts";
export interface OpEntry {
    id: string;
    def: any;
}
/** All operation shapes, sorted by local name. */
export declare const collectOperations: (shapes: ShapeMap) => OpEntry[];
/** The model's shape namespace (from the first operation, else any shape). */
export declare const modelNamespace: (operations: readonly OpEntry[], shapes: ShapeMap, fallback: string) => string;
/**
 * Resolve an operation's input/output targets, synthesizing an empty named
 * structure for `smithy.api#Unit` so every operation has a shape that can
 * carry operation-level traits (mutates `shapes`).
 */
export declare const ensureNamedIo: (shapes: ShapeMap, op: OpEntry, ns: string) => {
    input: string;
    output: string;
};
/**
 * Every error shape id referenced by the operations' `errors` lists —
 * deduplicated, existing in the model, sorted by local name.
 */
export declare const collectOpErrorIds: (operations: readonly OpEntry[], shapes: ShapeMap) => string[];
//# sourceMappingURL=operations.d.ts.map