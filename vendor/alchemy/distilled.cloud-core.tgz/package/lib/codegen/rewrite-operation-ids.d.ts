/**
 * Operation naming (dev-time only).
 *
 * Distilled SDK operations are verbNoun (`listApps`, `getApp`,
 * `createMachine`). Upstream ids come in a handful of shapes and
 * {@link toVerbNoun} only reorders the ones it can recognise with confidence:
 *
 *   - go-swagger `Resource_action` / `Resource_Sub_action` (`Apps_list`)
 *   - REST `NounsAction` with a trailing CRUD verb (`ConfigsList`,
 *     `ContainerCreate`, `ServiceMembers_getMetrics`)
 *   - GraphQL `nounAction` (`projectCreate`)
 *   - `show` → `get`, `index` → `list`, `retrieve` → `get`
 *
 * Anything else is left as-is (lowerFirst only). Reordering a verb out of
 * the middle of an id (`WatchCoreV1PodList` → `listWatch…`) produced worse
 * names than the input, so it is not attempted; per-package
 * {@link OperationIdRewrite} maps cover the tail.
 *
 * RFC-6902 patches that target `/paths/~1foo/get/operationId` break the
 * moment upstream prefixes paths. Naming is a convert policy, not a patch.
 */
export interface OperationIdContext {
    readonly path: string;
    readonly method: string;
}
/**
 * Return the new operation name, or `undefined` to leave the current value.
 * A `Record` is looked up by `"METHOD path"` first, then the spec's
 * `operationId` — same id on PUT vs PATCH needs the path key.
 */
export type OperationIdRewrite = Readonly<Record<string, string>> | ((operationId: string, ctx: OperationIdContext) => string | undefined);
export declare const operationNameKey: (ctx: OperationIdContext) => string;
/** Resolve {@link OperationIdRewrite} against method+path, then operationId. */
export declare const resolveOperationName: (rewrite: OperationIdRewrite, operationId: string, ctx: OperationIdContext) => string | undefined;
/**
 * Conservative singular. Only strips a trailing `s` when the word is a
 * regular plural we are confident about; anything ambiguous is returned
 * unchanged, because `getAlia` is worse than `getAliases`.
 */
export declare const singularize: (raw: string) => string;
/**
 * Distilled SDK names are verbNoun (`listApps`, `getApp`, `createMachine`).
 *
 * - Already verb-first (`listSprites`, `GetObject`, `showContact`,
 *   `WatchPodList`) stays, with `show`/`index`/`retrieve` aliased.
 * - Trailing action (`ConfigsList`, `PlansGet`, `ContainerCreate`,
 *   `VirtualMachinesStart`, `ReleaseGet`) moves the verb first and
 *   singularises the resource for non-list verbs.
 * - go-swagger / autorest `Apps_list`, `App_Certificates_show`,
 *   `Machines_list_events`, `ServiceMembers_getMetrics`: the verb heads the
 *   first `_` segment after the resource.
 * - Anything else (`AppGetOrCreate`, `VirtualMachines_createOrUpdate`,
 *   `DnsRecordsBatch`, `accountById`) is returned unchanged apart from
 *   lowerFirst. Use {@link OperationIdRewrite} for those.
 */
export declare const toVerbNoun: (operationId: string) => string;
/**
 * `metadata` key of a model whose final names are deferred (the OpenAPI
 * converter's `deferNaming`): upstream shape id → final shape id.
 * `finalizeConvert` applies it after the Smithy patches and removes it.
 */
export declare const RENAME_METADATA_KEY = "distilled.rename";
/**
 * Apply and remove a model's deferred rename ({@link RENAME_METADATA_KEY}).
 * Returns how many shapes it renamed.
 */
export declare const applyDeferredRename: (model: {
    metadata?: Record<string, any>;
    shapes?: Record<string, any>;
}) => number;
/**
 * Rename shapes by id and rewrite every `target` that points at a renamed
 * one, keeping the model's shape order. All renames happen at once, so a
 * mapping may swap names. Throws when a new id is already taken by a shape
 * that keeps its name, or two shapes would land on one id.
 */
export declare const renameShapes: (model: {
    shapes?: Record<string, any>;
}, mapping: ReadonlyMap<string, string>) => void;
/**
 * Whether an OpenAPI `operationId` carries no information beyond the
 * method and path: absent, or a mechanical restatement of the route such
 * as `get-api-card`, `post_v1_users_id`, `getApiV1AnnotationLayer`. A
 * hand-chosen id that merely starts with the method (`delete-artifact` for
 * `/repos/{owner}/{repo}/actions/artifacts/{id}`) is NOT mechanical — it
 * names a subset of the route on purpose — so the id must cover every
 * literal path segment, and every id token must come from the route.
 */
/**
 * A stricter subclass of mechanical ids: nothing in the id was chosen by
 * a person. Either there is no id, or the id is the route spelled out —
 * `postV1AppsByAppIdPromote`, `get_v1_users_id`, `get-api-card`,
 * `getCustomerById`. Such names are derived from the route alone.
 *
 * A `By…` clause counts as verbatim only when it names a whole parameter
 * (`ByAppId` for `{appId}`) or is a bare `ById`. `get_webhook_by_token`
 * for `/webhooks/{webhook_id}/{webhook_token}` is a chosen
 * disambiguation, so its nouns are kept; likewise `deleteScheduledJob`.
 */
export declare const isVerbatimRouteId: (operationId: string | undefined, ctx: OperationIdContext) => boolean;
export declare const isMechanicalOperationId: (operationId: string | undefined, ctx: OperationIdContext) => boolean;
/**
 * Derive `verbNoun` from `METHOD /path` for operations whose operationId
 * is missing or mechanical:
 *
 *   GET    /users            → listUsers       (when the 200 body is a
 *                                               collection; else getUsers)
 *   GET    /users/{id}       → getUser
 *   POST   /users            → createUser
 *   POST   /users/{id}       → updateUser      (Stripe-style POST-to-update)
 *   PUT    /users/{id}       → putUser         (replace semantics kept)
 *   PATCH  /users/{id}       → updateUser
 *   DELETE /users/{id}       → deleteUser
 *   POST   /users/{id}/reset → resetUser       (trailing action segment)
 *   GET    /orgs/{o}/repos   → listOrgRepos    (parents, singular, keep order)
 *
 * `/api`, `/v1`-style roots are dropped. Path parameters contribute nothing
 * to the name; only literal segments do.
 */
export interface PathNamingHints {
    /**
     * Whether the success response is a collection (array body, or an
     * object whose only/primary member is an array). Decides `list` vs
     * `get` for a GET on a route with no trailing parameter.
     */
    readonly returnsCollection?: boolean;
    /**
     * A mechanical operationId (`get-feeds`, `delete_v1_users_id`) whose
     * noun tokens, after the method, should be used verbatim instead of
     * being re-derived (and re-singularised) from the route.
     */
    readonly nouns?: string;
    /**
     * `nouns` is the route spelled out (`postV1AppsByAppIdPromote`), so
     * parameter tokens embedded without a `By` (`get_v1_users_id`) and
     * every `By…` clause are dropped, and the resource is singularised
     * when a parameter follows it.
     */
    readonly verbatim?: boolean;
}
export declare const pathToVerbNoun: (ctx: OperationIdContext, hints?: PathNamingHints) => string;
/**
 * Rename operations (and every shape whose name starts with the operation
 * name — `FooRequest`, `FooResponse`, `FooRequestBody`, `FooResponseItemsList`)
 * in a Smithy model to verbNoun PascalCase. Mutates `model.shapes`.
 * Colliding names keep the original id and are reported.
 */
export declare const verbNounSmithyModel: (model: {
    shapes?: Record<string, any>;
}) => {
    renamed: number;
    collisions: string[];
};
//# sourceMappingURL=rewrite-operation-ids.d.ts.map