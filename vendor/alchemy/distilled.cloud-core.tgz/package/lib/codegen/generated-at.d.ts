/** A date in UTC, `YYYY-MM-DD`. */
export declare const generatedAtDate: (now?: Date) => string;
/**
 * Date of the newest commit at or before `HEAD` of the repository at `cwd`
 * that changed `pathspec`. Mirrors are checked out `--depth=1`, so this
 * deepens the history (commits and trees only, no file content) until the
 * answer is a real commit and not the shallow boundary.
 */
export declare const lastChangeDate: (cwd: string, pathspec: string) => string;
/**
 * When the package's spec last changed, or `undefined` if that cannot be
 * known here: no `specs/` directory (a hand-written SDK), the mirror is not
 * checked out, or specs come from the untracked `specs/.local` copy.
 */
export declare const specUpdatedAt: (root: string) => string | undefined;
export interface GeneratedAtStamp {
    readonly generatedAt: string;
    /** `undefined` when unknown; the existing value in `package.json` is kept. */
    readonly specUpdatedAt: string | undefined;
}
/**
 * Set `distilled.generatedAt` and `distilled.specUpdatedAt` in
 * `<root>/package.json`; returns the dates written.
 */
export declare const stampGeneratedAt: (root: string, options?: {
    readonly now?: Date;
    readonly specUpdatedAt?: string | undefined;
}) => GeneratedAtStamp;
//# sourceMappingURL=generated-at.d.ts.map