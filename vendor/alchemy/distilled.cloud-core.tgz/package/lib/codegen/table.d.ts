export declare const tableSchemas: (code: string, filename?: string) => {
    code: string;
    tabled: number;
};
//# sourceMappingURL=table.d.ts.map