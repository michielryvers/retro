export declare const dedupeSchemas: (code: string, filename?: string) => {
    code: string;
    merged: number;
};
//# sourceMappingURL=dedupe.d.ts.map