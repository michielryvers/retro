/**
 * OpenAPI → Smithy 2.0 JSON converter (dev-time only, provider-agnostic).
 *
 * Turns a Swagger 2.0 / OAS 3.0 / OAS 3.1 document into the same Smithy JSON
 * model shape the other spec converters produce (`{ smithy: "2.0", metadata,
 * shapes }`), so every OpenAPI-sourced provider flows through the one shared
 * `generateService` compiler. Conversion fidelity follows distilled v0's
 * `generate-openapi.ts` feature matrix:
 *
 *   • one operation per (path × get/post/put/patch/delete — plus head/options
 *     when a provider opts in via `extraHttpMethods`), deprecated skipped by
 *     default; op shape name = PascalCase(operationId), or verbNoun
 *     (`Apps_list` → `ListApps`) when {@link OpenApiConvertOptions.operationNaming}
 *     is `"verbNoun"`
 *   • input `<Op>Request`: path params → `smithy.api#httpLabel` (+required),
 *     query params → `smithy.api#httpQuery`, header params →
 *     `smithy.api#httpHeader` when `headerParams` is on (dropped otherwise,
 *     as cookie params always are),
 *     body properties flattened alongside
 *     (labels win, then query, then headers, then body);
 *     non-object bodies become a sole `body` member with `smithy.api#httpPayload`
 *   • `$ref`s become NAMED shapes (`components/schemas/X` → `<ns>#X`), reused
 *     across operations; anonymous nested objects synthesize names from the
 *     parent + member path
 *   • responses: 200 → 201 → 204 precedence (`successStatuses` overrides),
 *     JSON or opt-in binary `application/octet-stream`; object
 *     results become `<Op>Response` structures (a sole `$ref` reuses the named
 *     shape); bare array/scalar results wrap in a structure whose single
 *     member carries `com.distilled.openapi#rawResponse` (the SdkSpec maps it
 *     to a root pipe); no schema → `smithy.api#Unit`; `head` is always
 *     `smithy.api#Unit`, whatever content the spec declares
 *   • nullability (3.0 `nullable`, 3.1 `type: [..., "null"]`, 2.0
 *     `x-nullable`, `oneOf`/`anyOf` null branches) → member-level
 *     `com.distilled.openapi#nullable` trait
 *   • sensitive string members (x-sensitive or name-pattern match) →
 *     `smithy.api#sensitive` on the member (direction-agnostic; the SdkSpec
 *     decides the input/output treatment)
 *   • per-op non-2xx statuses (outside `defaultErrorStatuses`) → typed error
 *     shapes with `smithy.api#error`/`smithy.api#httpError` and
 *     `com.distilled.openapi#errorMatchers` status matchers
 *   • v0 pagination detection (`pagination.cursor` / `.next` / `.next_page`,
 *     `next_token`/`NextToken`/`nextToken`, `next_page` + input alias lists +
 *     first top-level array property) → `smithy.api#paginated` on the op
 *     (with the non-standard `mode` member the core runtime dispatches on)
 */
import { RENAME_METADATA_KEY, type OperationIdRewrite } from "./rewrite-operation-ids.ts";
/** Member-level nullability (`S.NullOr` + `| null` via `SdkSpec.nullableTrait`). */
export declare const NULLABLE_TRAIT = "com.distilled.openapi#nullable";
/**
 * Marks the sole member of a synthesized response wrapper for bare
 * array/scalar response bodies. SdkSpecs bind it with a `rootPipe`
 * (`T.RawResponseRoot()` from `core/protocol-rest`), so the emitted response
 * type IS the payload type.
 */
export declare const RAW_RESPONSE_TRAIT = "com.distilled.openapi#rawResponse";
/**
 * Wire-matching rules for a generated error class (see
 * `SdkSpec.errorMatchersTrait` + `applyErrorMatchers`). The converter stamps
 * `[{ status }]` from the response status the class was mapped from.
 */
export declare const ERROR_MATCHERS_TRAIT = "com.distilled.openapi#errorMatchers";
/**
 * Non-JSON request body encoding chosen by the v0 content-type precedence
 * (json > form-urlencoded > multipart). Value: `"form-urlencoded"` |
 * `"multipart"`. `"multipart"` is also merged into the `smithy.api#http`
 * trait's `contentType` (which core's `buildRequest` understands);
 * form-urlencoded is left to provider SdkSpecs/protocols.
 */
export declare const CONTENT_TYPE_TRAIT = "com.distilled.openapi#contentType";
/**
 * The `apiVersion` recorded on every operation when
 * {@link OpenApiConvertOptions.apiVersion} is set (Azure ARM style). The
 * matching `api-version` query parameter is dropped from inputs; the
 * provider's protocol injects it at request time.
 */
export declare const API_VERSION_TRAIT = "com.distilled.openapi#apiVersion";
export declare const SENSITIVE_FIELD_PATTERNS: readonly RegExp[];
export interface OpenApiConvertOptions {
    /** Shape namespace, e.g. `"com.neon.api"`. */
    readonly namespace: string;
    /** Service shape name (PascalCased), e.g. `"Neon"`. */
    readonly serviceName: string;
    /** Service shape `version`. Default: the spec's `info.version`, else "1.0". */
    readonly serviceVersion?: string;
    /**
     * Non-2xx response status → error class name. Statuses in
     * {@link defaultErrorStatuses} never produce per-op errors. Default:
     * `{400: BadRequest, 403: Forbidden, 404: NotFound, 409: Conflict,
     * 422: UnprocessableEntity}` (the v0 default).
     */
    readonly statusToErrorClass?: Readonly<Record<string, string>>;
    /**
     * Statuses covered by the SDK's common errors, excluded from per-op error
     * lists. Default: `{"401","429","500","503"}` (the v0 default).
     */
    readonly defaultErrorStatuses?: Iterable<string>;
    /** Skip operations marked `deprecated: true`. Default true. */
    readonly skipDeprecated?: boolean;
    /**
     * HTTP methods to convert IN ADDITION to get/post/put/patch/delete —
     * currently `"head"` and `"options"`. Opt-in, so a provider that models
     * them (Vercel probes cache artifacts and sandbox files with HEAD) gets
     * them without every other provider silently gaining operations.
     *
     * `head` operations always output `smithy.api#Unit` — see the output-shape
     * comment in {@link convertOpenApiToSmithy} for why a declared response
     * body on a HEAD can never arrive.
     */
    readonly extraHttpMethods?: readonly ("head" | "options")[];
    /**
     * Emit `in: header` parameters as `smithy.api#httpHeader` members instead
     * of dropping them. Opt-in for the same reason as
     * {@link extraHttpMethods}: turning it on adds input members to every
     * operation whose spec declares a header parameter, and most providers
     * declare ones the protocol already sends itself (Accept, Authorization,
     * an API-version pin). Providers whose headers are real per-call inputs
     * — Vercel's `x-Artifact-*` remote-cache metadata, `x-Vercel-Digest` —
     * ask for them.
     */
    readonly headerParams?: boolean;
    /**
     * Convert `format: binary` strings to blobs and include binary
     * `application/octet-stream` responses. Opt in only when the provider's
     * generator and protocol support binary inputs and outputs. Default false.
     */
    readonly binaryTypes?: boolean;
    /**
     * Response statuses to read the operation's output shape from, most
     * preferred first. Default `["200", "201", "204"]`. Extend it for an API
     * that answers asynchronous work with a body under another status — Vercel
     * returns `202 Accepted` with a payload from nine endpoints (artifact
     * upload, account deletion, VCR blob/manifest writes), which would
     * otherwise generate as a `void` output.
     */
    readonly successStatuses?: readonly string[];
    /**
     * Response headers (matched case-insensitively) to add to an operation's
     * output as optional `smithy.api#httpHeader` members wherever one of its
     * 2xx responses declares them -- bodiless ones such as `202 Accepted`
     * included. An allowlist for the same reason as {@link headerParams}:
     * specs declare noise headers (request ids, ETags) on most responses.
     * Azure lists its long-running-operation status monitor
     * (`Azure-AsyncOperation`, `Location`, `Retry-After`), which callers need
     * to follow the operation themselves.
     *
     * An operation whose output reuses a named component gets its own output
     * structure (the component's members plus the headers), so the headers
     * never leak into other operations sharing that component. A header whose
     * member name a body member already uses is suffixed `Header`
     * (`Location` → `locationHeader` next to ARM's `location` region).
     */
    readonly responseHeaders?: readonly string[];
    /**
     * Azure-style fixed `api-version`: drops `api-version` query params and
     * stamps {@link API_VERSION_TRAIT} on every operation.
     */
    readonly apiVersion?: string;
    /**
     * Name patterns marking string members sensitive. Default
     * {@link SENSITIVE_FIELD_PATTERNS}. Pass `[]` to disable name-based
     * detection (explicit `x-sensitive: true` still applies).
     */
    readonly sensitivePatterns?: readonly RegExp[];
    /**
     * Optional full shape-definition overrides for emitted error classes
     * (keyed by class name) — e.g. custom members. The converter's default is
     * an empty structure with `smithy.api#error` + `smithy.api#httpError` +
     * {@link ERROR_MATCHERS_TRAIT} traits; overrides are merged over it.
     */
    readonly errorShapes?: Readonly<Record<string, any>>;
    /**
     * How to turn an OpenAPI `operationId` into the Smithy/SDK operation name.
     * This is a convert policy, not a spec patch — the OpenAPI document is
     * left alone.
     *
     * - `"verbNoun"` (default): `Apps_list` / `ConfigsList` / `showContact` →
     *   `listApps` / `listConfigs` / `getApp`. Already verb-first ids stay.
     *   An operation with no `operationId`, or a mechanical one that only
     *   restates the method and path (`get-api-card`, `post_v1_users`), is
     *   named from the route instead: `GET /users` → `listUsers`,
     *   `GET /users/{id}` → `getUser`, `POST /users/{id}/reset` →
     *   `resetUser`.
     * - `"as-is"`: `PascalCase(operationId)` (`Apps_list` → `AppsList`).
     *
     * {@link operationNames} overrides win (lookup by `"METHOD path"`, then
     * operationId).
     */
    readonly operationNaming?: "as-is" | "verbNoun";
    /**
     * Per-operation name overrides for {@link operationNaming}. Use
     * `"METHOD path"` keys when two methods share an `operationId`.
     */
    readonly operationNames?: OperationIdRewrite;
    /**
     * Name shapes from the spec (`PascalCase(operationId)`, no overrides) and
     * record the {@link operationNaming} names in
     * `metadata[RENAME_METADATA_KEY]`; `finalizeConvert` renames after the
     * Smithy patches, so patches target upstream names.
     */
    readonly deferNaming?: boolean;
}
export interface SmithyModel {
    smithy: "2.0";
    metadata: any;
    shapes: Record<string, any>;
}
export { RENAME_METADATA_KEY };
export declare const convertOpenApiToSmithy: (spec: unknown, options: OpenApiConvertOptions) => SmithyModel;
//# sourceMappingURL=openapi.d.ts.map