export declare const datafyOperations: (code: string, filename?: string, 
/**
 * Short module-level aliases for namespace members (`const __4 = S.Struct`).
 * A bundler that is about to rename imports anyway does not need them.
 */
{ aliases: aliased }?: {
    aliases?: boolean;
}) => {
    code: string;
    operations: number;
    holders: number;
    errors: number;
};
//# sourceMappingURL=datafy.d.ts.map