import { diffModels, type Models } from "./model-diff.ts";
export { diffModels, type Models };
export type Run = {
    readonly ok: true;
    readonly models: Models;
} | {
    readonly ok: false;
    readonly error: string;
};
/** Builds the patched model, optionally with a skip-list entry left out. */
export interface ModelBuilder {
    readonly build: (skip?: string) => Run;
    readonly restore: (baseline: Models) => void;
}
export interface PatchFileInfo {
    /** Path relative to the package's `patches/` — the skip-list entry. */
    readonly key: string;
    readonly ops: number;
    /** Whether every op targets the Smithy model (`/shapes`, `/metadata`, …). */
    readonly smithyOnly: boolean;
}
export type Verdict = {
    readonly kind: "unused";
} | {
    readonly kind: "needed";
    readonly diff: readonly string[];
} | {
    readonly kind: "depended";
    readonly error: string;
};
export interface FileVerdict {
    readonly file: PatchFileInfo;
    readonly verdict: Verdict;
    /** With `ops`: indices of ops inside a needed file that change nothing alone. */
    readonly deadOps: readonly number[];
}
export type PackageAudit = {
    readonly kind: "audited";
    readonly files: readonly FileVerdict[];
    /** Files under `patches/` without a `patches` array (e.g. AWS typed configs). */
    readonly notAudited: readonly string[];
    /** How many files were judged in memory, and how many by one convert each. */
    readonly judged: {
        readonly inMemory: number;
        readonly perFile: number;
    };
} | {
    readonly kind: "skipped";
    readonly reason: string;
};
/** RFC-6902 files under `patchesDir`; anything without a `patches` array is returned separately. */
export declare const listPatchFiles: (patchesDir: string) => {
    files: PatchFileInfo[];
    other: string[];
};
export interface AuditOptions {
    /** Also judge every op inside each needed file. */
    readonly ops?: boolean;
    /** Only files whose key contains this substring. */
    readonly only?: string;
    /** Scratch copies converting at once; default from cores and free memory. */
    readonly jobs?: number;
    /** `false` judges every file by one convert each (the slow path; for comparing). */
    readonly inMemory?: boolean;
    /** Called after each file's verdict, in completion order. */
    readonly onFile?: (verdict: FileVerdict) => void;
    /** Called as each file is judged, before its verdict is final. */
    readonly onProgress?: () => void;
}
/** Audit one package directory. Never throws for a broken baseline — that is `skipped`. */
export declare const auditPackage: (pkgDir: string, options?: AuditOptions) => Promise<PackageAudit>;
/**
 * Each model's deferred rename — upstream shape id → the final id in
 * `.generated-specs` — from one convert on a scratch copy. Smithy patches
 * apply before the rename, so they use the upstream ids.
 */
export declare const renameMaps: (pkgDir: string) => Promise<{
    ok: true;
    maps: Record<string, Record<string, string>>;
} | {
    ok: false;
    error: string;
}>;
//# sourceMappingURL=patch-audit.d.ts.map