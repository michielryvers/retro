/**
 * Boolean-valued string enums on request members (dev-time only).
 *
 * Plenty of APIs document a flag as the string enum `"true" | "false"`
 * rather than a JSON boolean — Cloudflare's `validation_enabled`, Clerk's
 * `include_invalid`, GrowthBook's `deleteMissing`, and so on. Taken
 * literally that surfaces as `"true" | "false" | (string & {})` and every
 * caller writes the ternary itself.
 *
 * {@link generateService} runs this pass over the loaded model before
 * emitting: REQUEST members of such an enum are retargeted to a real
 * `smithy.api#Boolean` and stamped {@link STRING_ENCODED_TRAIT}, which the
 * generator emits as `T.StringEncoded()` and the protocol honors by sending
 * the value's string spelling. The TS surface becomes `boolean` with the
 * wire unchanged. The model on disk keeps the string enum the description
 * documents.
 *
 * Deliberately narrow:
 *
 *   • request-only shapes — an operation input, or a structure or list the
 *     inputs reach and no output or error does. A member a response can
 *     deliver would need the mirror-image decode, which the protocol does
 *     not do, so a shape used both ways keeps its documented string type;
 *   • the enum must be exactly `{"true", "false"}` — a three-value enum
 *     that happens to include them is left alone.
 */
/** Synthetic trait: send this member's value as its string spelling. */
export declare const STRING_ENCODED_TRAIT = "distilled.protocols#stringEncoded";
export interface BooleanStringEnumResult {
    /** Request members retargeted to a real boolean. */
    members: number;
    /** List shapes whose element type was retargeted. */
    lists: number;
}
export declare const booleanStringEnums: (model: any) => BooleanStringEnumResult;
//# sourceMappingURL=boolean-string-enums.d.ts.map