import { type JsonPatchOperation } from "../json-patch.ts";
export type OnStalePatch = "fail" | "warn";
export interface ApplyPatchesResult {
    files: number;
    applied: number;
    stale: number;
    errors: string[];
}
/** Smithy-model JSON pointers — OpenAPI has no `/shapes` tree. */
export declare const isSmithyPatchPath: (pointer: string) => boolean;
/**
 * Leave patches out of one convert run (dev-time only; the seam
 * `scripts/patches.ts audit` uses to find patches the spec no longer
 * needs). Comma-separated entries:
 *
 *   all                    skip every patch file
 *   <file>                 skip a file — its basename, or a path suffix
 *                          (`svc/a.json`) when basenames repeat
 *   <file>:<index>         skip one op of a file, by its index in `patches`
 *
 * Like `DISTILLED_SPECS_LOCAL`, it lives in one command's environment: a
 * model written under it is announced on stderr and must not be committed.
 */
export declare const SKIP_PATCHES_ENV = "DISTILLED_SKIP_PATCHES";
/**
 * RFC-6902 files in `dir`: every `*.json`, `*.manual.json` last (those
 * usually target post-rename shape names). Missing dir → `[]`. Files named
 * by {@link SKIP_PATCHES_ENV} are left out.
 */
export declare const listRfc6902PatchFiles: (dir: string) => Promise<string[]>;
export declare const applyRfc6902Files: (target: unknown, files: readonly string[], opts?: {
    readonly onStalePatch?: OnStalePatch;
    readonly include?: (op: JsonPatchOperation) => boolean;
    readonly label?: (file: string) => string;
}) => Promise<ApplyPatchesResult>;
/**
 * An RFC-6902 `move` that renames an operation shape leaves the service's
 * `operations` list pointing at the old id. Drop entries whose target no
 * longer exists and append operation shapes the list is missing, keeping
 * the existing order. Returns the number of services whose list changed.
 */
export declare const syncServiceOperations: (model: {
    shapes?: Record<string, any>;
}) => number;
/**
 * Every `target` in a Smithy model must resolve to a shape or a prelude
 * (`smithy.api#…`) id. Returns the dangling ones as `"<owner> → <target>"`.
 * A convert that produces any is broken — generate would emit references
 * to types that do not exist.
 */
export declare const danglingTargets: (model: {
    shapes?: Record<string, any>;
}) => string[];
export interface FinalizeOptions {
    readonly root: string;
    readonly outDir?: string;
    readonly patchesDir?: string | false;
    /**
     * The directory holding a model's patches, relative to `patchesDir`.
     * Default `<resource>`; `""` for a single-model package whose patches sit
     * at the root of `patchesDir`; `undefined` for none.
     */
    readonly patchesFor?: (resource: string) => string | undefined;
    readonly exclude?: (file: string) => boolean;
    readonly include?: (resource: string) => boolean;
    readonly transform?: (model: any, resource: string) => string | void;
    readonly operationNaming?: "as-is" | "verbNoun";
    readonly onStalePatch?: OnStalePatch;
}
/**
 * Last step of every convert: Smithy RFC-6902 patches, then verbNoun
 * operation names, then an optional model transform, then a reference
 * check. Writes models back so `.generated-specs` is what generate
 * compiles. `outDir` may be nested (GCP `stable/` / `unstable/`).
 *
 * Input must be FRESHLY converted models. Smithy patches are `move`/`add`
 * ops that are not idempotent, and a `transform` may not be either, so
 * running this over a model that already went through it is an error —
 * re-run the package's `convert` instead.
 *
 * Under {@link PATCH_AUDIT_ENV} it also judges the requested patch files
 * in memory (see `./patch-audit.ts`).
 */
export declare const finalizeConvert: (o: FinalizeOptions) => Promise<void>;
/**
 * Path of a JSON file finalizeConvert adds each model's deferred rename to
 * (`{ <model>: { <upstream id>: <final id> } }`). Set by
 * `pnpm patches:names`, which tells a patch author the upstream name of a
 * shape they see in `.generated-specs`.
 */
export declare const RENAME_MAP_ENV = "DISTILLED_RENAME_MAP";
/**
 * Path of a JSON request (`{ keys: string[], ops: boolean }`) asking
 * finalizeConvert to judge those patch files in memory. Set only by
 * `pnpm patches:audit` on a scratch copy of the package; the models it
 * writes are the normal, fully patched ones.
 *
 * Each verdict is printed to stdout as one line, {@link PATCH_AUDIT_MARKER}
 * followed by JSON. A requested key no finalizeConvert call owns (its ops
 * are applied somewhere else, e.g. before conversion) gets no line, and the
 * audit judges it by re-running convert.
 */
export declare const PATCH_AUDIT_ENV = "DISTILLED_PATCH_AUDIT";
export declare const PATCH_AUDIT_MARKER = "@@distilled-patch-audit ";
/** One finalizeConvert's answer for one patch file. */
export interface InMemoryVerdict {
    readonly key: string;
    /** Path of the model relative to the package's `.generated-specs`. */
    readonly model: string;
    readonly verdict: {
        readonly kind: "unused";
    } | {
        readonly kind: "needed";
        readonly diff: readonly string[];
    } | {
        readonly kind: "depended";
        readonly error: string;
    } | {
        readonly kind: "baseline";
        readonly error: string;
    };
    readonly deadOps: readonly number[];
}
/**
 * Metadata marker stamped by {@link finalizeConvert}. Guards against a
 * second pass over the same file (see the note on finalizeConvert).
 */
export declare const FINALIZED_KEY = "distilled.finalized";
//# sourceMappingURL=patches.d.ts.map