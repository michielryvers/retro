/**
 * Returns `code` with a PURE marker before every unmarked call in a
 * top-level `const`/`let`/`var` initializer or class `extends` clause.
 */
export declare const annotateNestedCalls: (code: string, filename?: string) => string;
//# sourceMappingURL=pure.d.ts.map