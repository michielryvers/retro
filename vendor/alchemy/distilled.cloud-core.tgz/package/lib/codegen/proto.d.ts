/**
 * Proto3 → Smithy 2.0 JSON converter (dev-time only, provider-agnostic).
 *
 * Turns one or more `.proto` files (a package of messages, enums, and gRPC
 * services) into the same Smithy JSON model shape the other spec converters
 * produce (`{ smithy: "2.0", metadata, shapes }`), so a proto-sourced
 * provider flows through the shared `generateService` compiler.
 *
 * Mapping (proto3 JSON encoding on the wire):
 *
 *   • each selected unary `rpc` → a Smithy operation, `POST /<package>.<Service>/<Method>`
 *   • request/response messages → structures; members are camelCase (proto3 JSON)
 *   • `repeated` → list, `map<k,v>` → map (JSON object keys are strings)
 *   • `oneof` fields flatten onto the parent (proto3 JSON is untagged)
 *   • enums → string enums (proto3 JSON emits the name)
 *   • 64-bit integers → `smithy.api#String` (proto3 JSON encodes them as strings)
 *   • `bytes` → `smithy.api#Blob` (base64 on the JSON wire)
 *   • `google.protobuf.Empty` I/O → `smithy.api#Unit`
 *   • streaming RPCs are skipped by default (they are not request/response POSTs)
 *
 * The converter does not speak binary protobuf. Generated SDKs send proto3
 * JSON at the gRPC method path — Connect-JSON / grpc-JSON transcoding shape.
 */
export declare const PRELUDE: {
    readonly String: "smithy.api#String";
    readonly Boolean: "smithy.api#Boolean";
    readonly Integer: "smithy.api#Integer";
    readonly Long: "smithy.api#Long";
    readonly Float: "smithy.api#Float";
    readonly Double: "smithy.api#Double";
    readonly Timestamp: "smithy.api#Timestamp";
    readonly Blob: "smithy.api#Blob";
    readonly Document: "smithy.api#Document";
    readonly Unit: "smithy.api#Unit";
};
export interface ProtoField {
    readonly name: string;
    readonly type: string;
    readonly repeated: boolean;
    readonly optional: boolean;
    readonly mapKey?: string;
    readonly mapValue?: string;
    readonly jsonName?: string;
    readonly deprecated: boolean;
    readonly documentation?: string;
}
export interface ProtoEnumValue {
    readonly name: string;
    readonly number: number;
    readonly deprecated: boolean;
    readonly documentation?: string;
}
export interface ProtoEnum {
    readonly name: string;
    readonly fullName: string;
    readonly values: ProtoEnumValue[];
    readonly documentation?: string;
}
export interface ProtoMessage {
    readonly name: string;
    readonly fullName: string;
    readonly fields: ProtoField[];
    readonly messages: ProtoMessage[];
    readonly enums: ProtoEnum[];
    readonly documentation?: string;
}
export interface ProtoRpc {
    readonly name: string;
    readonly requestType: string;
    readonly responseType: string;
    readonly requestStream: boolean;
    readonly responseStream: boolean;
    readonly deprecated: boolean;
    readonly documentation?: string;
}
export interface ProtoService {
    readonly name: string;
    readonly fullName: string;
    readonly rpcs: ProtoRpc[];
    readonly documentation?: string;
}
export interface ProtoFile {
    readonly filename: string;
    readonly package: string;
    readonly syntax: string;
    readonly imports: string[];
    readonly messages: ProtoMessage[];
    readonly enums: ProtoEnum[];
    readonly services: ProtoService[];
}
export interface ProtoConvertOptions {
    readonly files: readonly ProtoFile[];
    readonly namespace: string;
    readonly serviceName: string;
    readonly serviceTitle?: string;
    readonly serviceDocumentation?: string;
    readonly serviceVersion?: string;
    /** Fully-qualified proto service (`modal.client.ModalClient`). */
    readonly protoService: string;
    /** Keep only these RPC names. Default: every unary RPC. */
    readonly rpcNames?: ReadonlySet<string>;
    readonly skipStreaming?: boolean;
    readonly skipDeprecated?: boolean;
}
export interface ProtoConvertResult {
    readonly model: {
        smithy: "2.0";
        metadata: Record<string, unknown>;
        shapes: Record<string, any>;
    };
    readonly converted: number;
    readonly skippedStreaming: number;
    readonly skippedDeprecated: number;
    readonly shapeCount: number;
}
/** Parse a proto3 source file into an AST. */
export declare const parseProto: (text: string, filename?: string) => ProtoFile;
/** Leading PascalCase token of an RPC name (`AppCreate` → `App`). */
export declare const rpcGroupName: (rpcName: string) => string;
export declare const convertProtoToSmithy: (options: ProtoConvertOptions) => ProtoConvertResult;
//# sourceMappingURL=proto.d.ts.map