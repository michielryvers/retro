/** Schemas per builder function: smaller chunks compile less on first use. */
export declare const CHUNK_SIZE = 32;
export declare const chunkSchemas: (code: string, filename?: string, chunkSize?: number) => {
    code: string;
    chunked: number;
};
//# sourceMappingURL=chunk.d.ts.map