/**
 * Human-readable delta between two Smithy model snapshots (dev-time only),
 * as JSON pointers. Used by the patch audit to say what a patch changes.
 */
/** Model files keyed by path relative to `.generated-specs`, as text. */
export type Models = Map<string, string>;
export declare const MAX_DIFF_LINES = 12;
/** Human-readable delta between two model snapshots, `[]` when identical. */
export declare const diffModels: (withPatch: Models, without: Models) => string[];
//# sourceMappingURL=model-diff.d.ts.map