/**
 * Test helpers for SDK packages: a canned-response `HttpClient` and a runner
 * that executes one operation under every response-validation mode.
 *
 * ```ts
 * const { lenient, strict } = await runValidationModes(
 *   Pkg.getThing({ id: "a" }).pipe(Retry.none, Effect.provide(TestCredentials)),
 *   { body: "{}" },
 * );
 * expect(lenient).toMatchObject({ _tag: "Success", success: {} });
 * expect(strict).toMatchObject({ _tag: "Failure" });
 * ```
 */
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import type * as HttpClientRequest from "effect/http/HttpClientRequest";
import * as Layer from "effect/Layer";
import type * as Result from "effect/Result";
export interface MockResponse {
    /** Default 200. */
    readonly status?: number;
    /** Default `application/json`. */
    readonly headers?: Record<string, string>;
    readonly body: string;
}
/**
 * An `HttpClient` that answers every request with `response` (or with what
 * `response(request)` returns, for protocols that make more than one call).
 */
export declare const mockHttpClient: (response: MockResponse | ((request: HttpClientRequest.HttpClientRequest) => MockResponse)) => Layer.Layer<HttpClient.HttpClient>;
/**
 * Run `effect` against `mockHttpClient(response)` once in lenient mode and
 * once in each validating mode (`additionalProperties`, `strict`).
 */
export declare const runValidationModes: <A, E>(effect: Effect.Effect<A, E, HttpClient.HttpClient>, response: Parameters<typeof mockHttpClient>[0]) => Promise<{
    readonly lenient: Result.Result<A, E>;
    readonly additionalProperties: Result.Result<A, E>;
    readonly strict: Result.Result<A, E>;
}>;
//# sourceMappingURL=testing.d.ts.map