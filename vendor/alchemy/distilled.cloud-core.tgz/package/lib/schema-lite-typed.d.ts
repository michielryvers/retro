/**
 * `schema-lite` with Effect Schema's types, for hand-written modules.
 *
 * Generated services import `schema-lite`, whose builders are typed `any`
 * because every generated schema is cast to its declared interface. Hand-
 * written error classes have no such cast: built from untyped builders,
 * their fields declare as `any` (`ValidationError.message: any`), which
 * erases the field types for every consumer. This module exposes the same
 * lite runtime values with the Effect Schema types, so `S.TaggedError` field
 * types infer as they did with Effect Schema.
 */
import type * as S from "effect/Schema";
import * as L from "./schema-lite-impl.ts";
export type * from "effect/Schema";
export declare const optional: typeof S.optional;
export declare const Struct: typeof S.Struct;
export declare const StructWithRest: typeof S.StructWithRest;
export declare const suspend: typeof S.suspend;
export declare const Array: typeof S.Array;
export declare const Record: typeof S.Record;
export declare const Union: typeof S.Union;
export declare const Literal: typeof S.Literal;
export declare const Literals: typeof S.Literals;
export declare const NullOr: typeof S.NullOr;
export declare const Tuple: typeof S.Tuple;
export declare const declare: typeof S.declare;
export declare const instanceOf: typeof S.instanceOf;
export declare const Redacted: typeof S.Redacted;
export declare const String: typeof S.String;
export declare const Number: typeof S.Number;
export declare const Int: typeof S.Int;
export declare const Boolean: typeof S.Boolean;
export declare const Date: typeof S.Date;
export declare const Duration: typeof S.Duration;
export declare const Unknown: typeof S.Unknown;
export declare const Null: typeof S.Null;
export declare const Void: typeof S.Void;
export declare const Any: typeof S.Any;
export declare const TaggedError: L.TaggedErrorFactory;
export type { TaggedErrorClass, TaggedErrorFactory } from "./schema-lite-impl.ts";
//# sourceMappingURL=schema-lite-typed.d.ts.map