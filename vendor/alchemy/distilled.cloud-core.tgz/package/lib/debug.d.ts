export declare const debugHttp: () => boolean;
//# sourceMappingURL=debug.d.ts.map