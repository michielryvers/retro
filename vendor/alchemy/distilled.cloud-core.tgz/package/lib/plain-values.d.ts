/** Binary/opaque values that must never be treated as key-value objects. */
export declare const isOpaqueValue: (v: unknown) => boolean;
/**
 * Deep-unwrap `Redacted` values in an input (plain objects/arrays only --
 * class instances, files, and binary payloads pass through untouched).
 * Sensitive input members accept `string | Redacted<string>`; the wire wants
 * the raw string.
 */
export declare const unwrapRedactedDeep: (value: unknown) => unknown;
//# sourceMappingURL=plain-values.d.ts.map