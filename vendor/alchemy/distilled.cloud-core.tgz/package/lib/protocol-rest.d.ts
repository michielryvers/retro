/**
 * Generic REST protocol factory for simple bearer/header-auth JSON APIs
 * (Neon, Fly.io, PlanetScale, Supabase, Turso, ...).
 *
 * `makeRestProtocol(options)` builds a core {@link API.Protocol} layer:
 *
 *   request:  credentials resolved from the CALLING fiber's context on every
 *             request (the layer itself is memoized per process -- see
 *             `core/api`), auth headers + base URL from the provider's
 *             options, request built by `buildRequest` from
 *             `core/protocol-http` (deep-unwrapping any `Redacted` input
 *             values first)
 *
 *   response: 2xx JSON -> optional `transformResponse` -> recursive wire->TS
 *             key mapping (`mapKeys`) -> in strict mode, a schema check
 *             failing with the provider's `parseError` (see
 *             `core/response-validation`) -> `Redacted` wrapping of members
 *             marked with {@link SensitiveValue}; non-2xx -> typed error:
 *             per-op matcher classes (`matchTypedError`), then the status
 *             map (default `HTTP_STATUS_MAP`), then an `InternalServerError`
 *             for unmapped 5xx, then the provider's `unknownError` fallback
 *             -- with `retryAfter` durations stamped from the standard hint
 *             headers on retryable statuses.
 *
 * Anything provider-specific (envelope quirks, bespoke error codes) belongs
 * in the provider package -- via these options or a hand-written protocol.
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type * as AST from "effect/SchemaAST";
import * as API from "./api.ts";
import { unwrapRedactedDeep } from "./plain-values.ts";
export declare const sensitiveValueSymbol: unique symbol;
/**
 * Marks a string member as sensitive (mirrors `smithy.api#sensitive`).
 * The REST protocol wraps decoded values in `Redacted` on the way out and
 * accepts `string | Redacted<string>` on the way in (unwrapped before
 * serialization). Takes an ignored argument so generators can inline the
 * smithy trait value (`T.SensitiveValue({})`).
 */
export declare const SensitiveValue: (_value?: unknown) => import("./trait.ts").Annotation;
export declare const rawResponseSymbol: unique symbol;
/**
 * Marks the sole output member that carries a bare (array/scalar) response
 * body (mirrors `com.distilled.openapi#rawResponse`).
 */
export declare const RawResponse: (_value?: unknown) => import("./trait.ts").Annotation;
export declare const rawResponseRootSymbol: unique symbol;
/**
 * Marks a response schema whose ENTIRE value is the response body (the
 * generator's `rootPipe` for synthesized bare-payload wrappers): the emitted
 * response type IS the payload type and the protocol returns the mapped body
 * directly.
 */
export declare const RawResponseRoot: () => import("./trait.ts").Annotation;
export declare const binaryResponseSymbol: unique symbol;
/** Decode a successful raw binary response as bytes, without text conversion. */
export declare const BinaryResponse: () => import("./trait.ts").Annotation;
export { unwrapRedactedDeep };
/**
 * Walk a decoded (TS-named) value alongside its schema AST, wrapping members
 * marked {@link SensitiveValue} in `Redacted`. Keys the schema doesn't model
 * pass through verbatim.
 */
export declare const wrapSensitive: (ast: AST.AST, value: unknown) => unknown;
/**
 * Whether any member reachable from `ast` is marked {@link SensitiveValue}.
 * Parse errors for such an output withhold the response body (see
 * {@link RestParseErrorInfo}); hand-written protocols use this to do the same.
 */
export declare const hasSensitiveMember: (ast: AST.AST) => boolean;
/** What the wire said about a failure, for the `unknownError` fallback. */
export interface RestErrorInfo {
    readonly status: number;
    /** Error code from the envelope (services vary between string and number). */
    readonly code?: string | number;
    readonly message: string;
    /** Parsed JSON body, or the raw text when the body wasn't JSON. */
    readonly body: unknown;
    readonly headers: Record<string, string | undefined>;
}
/**
 * A 2xx body that failed strict validation, or a non-JSON 2xx body for an
 * output with sensitive members, for the `parseError` option.
 */
export interface RestParseErrorInfo {
    /** `"[REDACTED]"` when the output has sensitive members. */
    readonly body: unknown;
    readonly cause: unknown;
}
export interface RestErrorEnvelope {
    readonly code?: string | number;
    readonly message?: string;
}
export interface RestProtocolOptions<C> {
    /**
     * Resolve credentials ON THE CALLING FIBER -- evaluated per request, never
     * at layer build time, so context-provided credentials and token refreshes
     * are picked up. Either an effect, or -- for the distilled
     * credentials-service convention -- the `Credentials` service key whose
     * value is that effect (read from the calling fiber's context; an
     * already-resolved `Effect.succeed` value costs no extra fiber step). Its
     * error/requirement channels are
     * erased at the protocol boundary (Protocol effects carry none) and
     * reintroduced for callers by the generated `<Sdk>OpError` /
     * `<Sdk>OpContext` annotations.
     */
    readonly credentials: Effect.Effect<C, any, any> | Context.Key<any, Effect.Effect<C, any, any>>;
    /**
     * API base URL from the resolved credentials. Receives the operation's
     * route so APIs with more than one endpoint (e.g. S2's account vs
     * per-basin hosts, chosen by path) can route per request; single-endpoint
     * providers ignore the argument. A THROWN error (e.g. a required scope
     * missing from the credentials) is caught and surfaced on the calling
     * effect's error channel rather than dying as a defect.
     */
    readonly baseUrl: (credentials: C, target: {
        readonly uri: string;
        readonly method: string;
    }) => string;
    /** Auth (and any fixed) headers from the resolved credentials. */
    readonly headers: (credentials: C) => Record<string, string>;
    /**
     * Extract `{ code?, message? }` from a parsed non-2xx JSON body. Default:
     * lenient `{ code?, message? | error? }` (covers the common REST error
     * envelopes).
     */
    readonly errorEnvelope?: (body: unknown) => RestErrorEnvelope | undefined;
    /**
     * HTTP status -> error class constructed as `new Cls({ message, retryAfter
     * })`. Default: core `HTTP_STATUS_MAP`. Consulted after per-op typed error
     * matching; unmapped 5xx fall back to `InternalServerError`, everything
     * else to {@link unknownError}.
     */
    readonly statusMap?: Readonly<Record<number, new (args: any) => any>>;
    /** Fallback error for failures nothing else matched. */
    readonly unknownError: (info: RestErrorInfo) => unknown;
    /**
     * The SDK's `<Sdk>ParseError`, raised when a 2xx body does not match the
     * operation's output schema in strict mode (see
     * `core/response-validation`), and in every mode when a 2xx body for an
     * output with sensitive members is not JSON. `body` is the parsed JSON, or
     * the raw text when the body wasn't JSON, and `"[REDACTED]"` for an output
     * with sensitive members; `cause` is the schema error, or `"Invalid JSON
     * response"`.
     */
    readonly parseError: (info: RestParseErrorInfo) => unknown;
    /** Transform the parsed 2xx JSON before decoding (e.g. stripNulls). */
    readonly transformResponse?: (body: unknown) => unknown;
    /** Passed through to `buildRequest` (member-header transforms). */
    readonly mapMemberHeader?: (name: string, value: string) => string;
    /** Passed through to `buildRequest` (wire names for unmodeled input keys). */
    readonly unknownKeyToWire?: (key: string) => string;
}
/** Whether {@link wrapSensitive} can change any value of `root`. Cached per schema. */
export declare const hasSensitive: (root: AST.AST) => boolean;
/**
 * Build a `Layer<Protocol>` for a simple REST JSON API. Assign the result to
 * a module-level const in the provider's `protocol.ts` -- `API.make` memoizes
 * protocol layers by value identity.
 */
export declare const makeRestProtocol: <C>(options: RestProtocolOptions<C>) => Layer.Layer<API.Protocol>;
//# sourceMappingURL=protocol-rest.d.ts.map