/**
 * Effect Schema's API surface for generated code, backed by lite schemas
 * (see `schema-lite-impl.ts`): the same names and types as
 * `@distilled.cloud/core/schema`, without importing Effect Schema at runtime.
 */
import type * as S from "effect/Schema";
import * as L from "./schema-lite-impl.ts";
export type * from "effect/Schema";
export type AnyFn = (...args: any[]) => any;
export declare const optional: AnyFn;
export declare const Struct: AnyFn;
export declare const StructWithRest: AnyFn;
export declare const suspend: AnyFn;
export declare const Array: AnyFn;
export declare const Record: AnyFn;
export declare const Union: AnyFn;
export declare const Literal: AnyFn;
export declare const Literals: AnyFn;
export declare const NullOr: AnyFn;
export declare const Tuple: AnyFn;
export declare const encodeKeys: AnyFn;
export declare const declare: typeof S.declare;
export declare const instanceOf: AnyFn;
export declare const Redacted: AnyFn;
export declare const String: any;
export declare const Number: any;
export declare const Int: any;
export declare const Boolean: any;
export declare const Date: any;
export declare const Duration: any;
export declare const Unknown: any;
export declare const Null: any;
export declare const Void: any;
export declare const Any: any;
export declare const TaggedError: L.TaggedErrorFactory;
export type { TaggedErrorClass, TaggedErrorFactory } from "./schema-lite-impl.ts";
/** Lite `chunks.at`: generated services name this module `__L`. */
export declare const at: typeof L.at;
export { liteKey, toEffect } from "./schema-lite-impl.ts";
//# sourceMappingURL=schema-lite.d.ts.map