import * as Effect from "effect/Effect";
export type XmlValue = string | XmlObject | XmlValue[];
export interface XmlObject {
    [name: string]: XmlValue;
}
declare const XmlParseError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "XmlParseError";
} & Readonly<A>;
export declare class XmlParseError extends /*@__PURE__*/ XmlParseError_base<{
    readonly message: string;
    /** UTF-16 offset in the original input; line and column are one-based. */
    readonly offset: number;
    readonly line: number;
    readonly column: number;
}> {
}
export interface XmlParseOptions {
    /** Maximum open elements, including the root. Defaults to 256. */
    readonly maxDepth?: number;
    /** Maximum input length in UTF-16 code units. Defaults to 64 Mi. */
    readonly maxLength?: number;
}
/**
 * Parse DTD-free XML 1.0. Values remain strings;
 * repeated children become arrays, attributes use @_ and mixed text uses #text.
 * Names are preserved verbatim (no namespace resolution). Comments and PIs are
 * ignored. Text whitespace is preserved, except layout-only text in containers.
 * Empty HTTP bodies produce {}. This is not a DOM or a validating DTD processor.
 * Throws XmlParseError for malformed input or exceeded limits.
 * The iterative scanner allocates no Effects while traversing the document.
 */
export declare function parseXmlSync(xml: string, options?: XmlParseOptions): XmlObject;
/** Parse XML lazily, reporting malformed documents in the typed error channel. */
export declare const parseXml: (xml: string, options?: XmlParseOptions) => Effect.Effect<XmlObject, XmlParseError>;
/**
 * Escape special XML characters in a string.
 */
export declare const escapeXml: (s: string) => string;
/**
 * Wrap content in an XML tag with optional xmlns attribute.
 */
export declare const wrapTag: (tag: string, content: string, xmlns?: string) => string;
export {};
//# sourceMappingURL=xml.d.ts.map