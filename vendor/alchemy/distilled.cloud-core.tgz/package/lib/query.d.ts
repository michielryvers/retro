/**
 * Query combinators for GraphQL SDKs.
 *
 * Import this module next to a generated client:
 *
 *   import { Query } from "@distilled.cloud/core/query"
 *   import { Railway } from "@distilled.cloud/railway"
 *
 * `Query.fn` takes a **builder** (plain function, not `Effect.gen`) that
 * returns a plan of `Query<Value>` and `Effect` values. It walks Map /
 * Filter / FlatMap / Of, posts one GraphQL document, then interprets the
 * plan. Roots (`Railway.me`) come from the generated SDK; they are not
 * combinators.
 *
 * @see {@link file://./graphql.ts} for the algebra, compiler, and transport.
 */
import { filterQuery, flatMapQuery, itemsQuery, mapQuery, ofQuery, pagesQuery, queryFn, type Query as QueryType } from "./graphql.ts";
export type Query<Value, Error = never> = QueryType<Value, Error>;
export type { PlanError, QueryError, UnwrapPlan } from "./graphql.ts";
export declare const Query: {
    fn: typeof queryFn;
    filter: typeof filterQuery;
    map: typeof mapQuery;
    flatMap: typeof flatMapQuery;
    of: typeof ofQuery;
    pages: typeof pagesQuery;
    items: typeof itemsQuery;
};
//# sourceMappingURL=query.d.ts.map