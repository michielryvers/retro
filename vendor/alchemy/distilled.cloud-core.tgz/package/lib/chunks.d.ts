/** Schema `j` of the chunk `build`, built on first use. */
export declare const at: (build: (j: number) => unknown, j: number) => any;
//# sourceMappingURL=chunks.d.ts.map