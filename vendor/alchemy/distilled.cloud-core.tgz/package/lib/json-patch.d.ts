/**
 * JSON Patch (RFC 6902) Implementation
 *
 * The patch engine for every SDK. Patches are Smithy ops applied in
 * `convert` (`finalizeConvert`), so `.generated-specs` is the patched Smithy
 * model; generate does not patch. Operation names are convert policy
 * (`operationNames`), never a patch.
 *
 * Pure functions only -- callers load patch files themselves (the generators
 * use Effect's FileSystem) and hand the parsed operations to `applyPatch`.
 */
export interface JsonPatchOperation {
    op: "add" | "remove" | "replace" | "move" | "copy" | "test";
    path: string;
    value?: unknown;
    from?: string;
    /**
     * Extension for `add` and `move`: when the op creates a new object key,
     * insert it just before this sibling key instead of at the end, so the
     * patched model keeps the order the converter would have written. A `move`
     * whose `from` equals `path` reorders a key. Ignored when the key already
     * exists, the parent is an array, or the sibling is absent.
     */
    before?: string;
}
export type JsonPatch = JsonPatchOperation[];
export interface PatchFile {
    description?: string;
    patches: JsonPatch;
}
/** Parse a JSON Pointer (RFC 6901) path into segments. */
export declare function parseJsonPointer(pointer: string): string[];
/** Get a value at a JSON Pointer path. */
/**
 * The target location of a patch operation is absent from the document --
 * spec drift (renamed/removed upstream), not a malformed patch.
 */
export declare class StaleTargetError extends Error {
    readonly name = "StaleTargetError";
}
export declare function getValueAtPath(obj: unknown, pointer: string): unknown;
/** Set a value at a JSON Pointer path. */
export declare function setValueAtPath(obj: unknown, pointer: string, value: unknown, mode?: "add" | "replace", before?: string): void;
/** Remove a value at a JSON Pointer path. */
export declare function removeValueAtPath(obj: unknown, pointer: string): void;
/** Apply a single JSON Patch operation (mutates `obj` in place). */
export declare function applyOperation(obj: unknown, operation: JsonPatchOperation): void;
/** Apply a JSON Patch to an object (mutates in place). */
export declare function applyPatch(obj: unknown, patch: JsonPatch): void;
/**
 * Whether a per-operation failure is a {@link StaleTargetError} (the
 * operation/shape the patch targets was renamed or removed upstream) as
 * opposed to a malformed patch. Accepts the thrown value or its message.
 * Convert fails the run on these by default (`onStalePatch: "fail"`);
 * `"warn"` restores skip-and-continue.
 */
export declare function isStaleTargetError(error: unknown): boolean;
//# sourceMappingURL=json-patch.d.ts.map