/**
 * Retry Policy System
 *
 * Provides configurable retry policies for API operations.
 * Each SDK creates its own `Retry` Context.Service tag (via
 * `makeRetryService`) and threads it into `makeAPI({ retry: <SDK>.Retry })`
 * so that callers can install a blanket retry policy at the layer level
 * for that SDK without wrapping every call with `Effect.retry`.
 */
import * as Context from "effect/Context";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Ref from "effect/Ref";
import * as Schedule from "effect/Schedule";
/**
 * Retry policy options that match the Effect.retry contract.
 */
/**
 * Capped exponential backoff, as plain data: the built-in policies use this
 * instead of an Effect `Schedule`, so bundles do not carry the Schedule
 * machinery unless a caller supplies a schedule of their own.
 *
 * Delay before retry `n` (0-based): `min(baseMs * factor^n, capMs)`; a
 * server `retryAfter` hint replaces it when `serverHint` is set (capped by
 * {@link ServerRetryHintCapMs}); otherwise throttling errors wait at least
 * `minThrottleMs`. Then up to `jitterMs` of random jitter is added.
 */
export interface Backoff {
    readonly baseMs: number;
    readonly factor: number;
    readonly capMs: number;
    /** Stop after this many retries; unlimited when absent. */
    readonly maxRetries?: number;
    readonly jitterMs?: number;
    readonly minThrottleMs?: number;
    readonly serverHint?: boolean;
}
export interface Options {
    /**
     * Predicate to determine if an error should trigger a retry.
     */
    readonly while?: (error: unknown) => boolean;
    /**
     * The schedule to use for retrying.
     */
    readonly schedule?: Schedule.Schedule<unknown>;
    /** Used when no `schedule` is given. */
    readonly backoff?: Backoff;
}
/**
 * A factory function that creates retry policy options with access to the last error ref.
 * This allows dynamic policies that can inspect the last error for retry-after headers, etc.
 */
export type Factory = (lastError: Ref.Ref<unknown>) => Options;
/**
 * A retry policy can be either static options or a factory that receives the last error ref.
 */
export type Policy = Options | Factory;
/**
 * Create a typed Retry service class for an SDK.
 * Each SDK creates its own Retry service using this factory; the SDK's
 * client wraps `makeAPI` with `retry: <SDK>.Retry` so the policy applies
 * to every API call below it.
 *
 * @example
 * ```ts
 * // packages/<sdk>/src/retry.ts
 * export class Retry extends makeRetryService("PlanetScaleRetry") {}
 * ```
 */
export declare const makeRetryService: (name: string) => Context.ServiceClass<any, string, Policy>;
/**
 * Custom jittered schedule helper.
 * Adds random jitter between 0-50ms to avoid thundering herd.
 */
export declare const jittered: <Error, Env>(self: Schedule.Schedule<unknown, unknown, Error, Env>) => Schedule.Schedule<unknown, unknown, Error, Env>;
/**
 * Cap delay at a maximum duration.
 */
export declare const capped: (max: Duration.Duration) => <Error, Env>(self: Schedule.Schedule<unknown, unknown, Error, Env>) => Schedule.Schedule<unknown, unknown, Error, Env>;
/**
 * Default cap (milliseconds) on how long we'll honor a server-provided
 * `Retry-After` / `RateLimit` hint. A misbehaving server can otherwise park
 * us forever.
 */
export declare const DEFAULT_SERVER_RETRY_HINT_CAP_MS = 60000;
/**
 * Optional override for the server-hint cap, in milliseconds. When provided
 * via `Layer.succeed(ServerRetryHintCapMs, n)`, that value wins over the
 * environment.
 *
 * @example
 * ```ts
 * Effect.retry(op, policy).pipe(
 *   Effect.provide(serverRetryHintCapLayer(120_000)),
 * )
 * ```
 */
export declare const ServerRetryHintCapMs: Context.Service<number, number>;
/**
 * Layer that pins the server `retryAfter` cap to a fixed value (milliseconds).
 */
export declare const serverRetryHintCapLayer: (capMs: number) => Layer.Layer<number, never, never>;
/**
 * Effective cap when neither {@link ServerRetryHintCapMs} nor
 * `DISTILLED_SERVER_RETRY_HINT_CAP_MS` is set: {@link DEFAULT_SERVER_RETRY_HINT_CAP_MS}.
 *
 * Reads the `DISTILLED_SERVER_RETRY_HINT_CAP_MS` environment variable (must
 * be a non-negative finite number; invalid values fall back to the default).
 * It reads `process.env` directly: Effect's `Config` would add about 5 KB
 * gzip to every bundle for this one optional knob. Use
 * {@link ServerRetryHintCapMs} to set the cap from code.
 */
export declare const readServerRetryHintCapMsFromEnv: () => number;
export declare const resolveServerRetryHintCapMs: () => Effect.Effect<number, never, never>;
/**
 * Extract a server-provided retry hint (in milliseconds) from an error's
 * optional `retryAfter` field, capped by the effective server-hint cap
 * (see {@link ServerRetryHintCapMs} and {@link readServerRetryHintCapMsFromEnv}).
 *
 * Returns `undefined` when the error doesn't carry a hint.
 */
export declare const serverHintMillis: (error: unknown, capMs: number) => number | undefined;
/**
 * Creates the default retry policy.
 *
 * This policy:
 * - Retries transient errors (throttling, server, network, locked errors)
 * - Honors `error.retryAfter` (server-provided hint) with precedence, capped
 *   by {@link DEFAULT_SERVER_RETRY_HINT_CAP_MS} by default; override with
 *   `DISTILLED_SERVER_RETRY_HINT_CAP_MS` or {@link ServerRetryHintCapMs}
 * - Otherwise uses exponential backoff starting at 250ms with a factor of 2,
 *   capped at 5s per delay
 * - Ensures at least 500ms delay for throttling errors
 * - Limits to 8 retry attempts
 * - Applies jitter to avoid thundering herd
 *
 * The 250ms/5s-cap/8-attempt shape (~20s of total patience) comes from
 * alchemy's Cloudflare provider suite, where transient auth blips under
 * high request concurrency routinely outlast a short 5-attempt/3s policy
 * while a genuinely broken credential still fails within seconds.
 */
/** The policy used when the context provides none. */
export declare const defaultOptions: Options;
export declare const makeDefault: Factory;
export declare const throttlingFactory: Factory;
export declare const throttlingOptions: Options;
export declare const transientFactory: Factory;
export declare const transientOptions: Options;
//# sourceMappingURL=retry.d.ts.map