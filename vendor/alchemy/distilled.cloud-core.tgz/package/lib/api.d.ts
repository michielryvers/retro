import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import type * as HttpClientError from "effect/http/HttpClientError";
import type * as HttpClientRequest from "effect/http/HttpClientRequest";
import type * as HttpClientResponse from "effect/http/HttpClientResponse";
import * as Layer from "effect/Layer";
import * as S from "effect/Schema";
import type * as AST from "effect/SchemaAST";
import type * as Stream from "effect/Stream";
import * as Pagination from "./pagination.ts";
import { type Policy as RetryPolicy } from "./retry.ts";
/**
 * The view of an operation's config that protocols receive on every
 * encode/decode call. The object is the same memoized config instance for
 * every call to a given operation, so protocols can key per-operation
 * preprocessing (handler construction, error maps) off its identity in a
 * WeakMap.
 */
export interface ProtocolOperationConfig {
    readonly input?: S.Top;
    readonly output?: S.Top;
    readonly errors?: ReadonlyArray<ApiErrorClass>;
    /**
     * The wire operation name (e.g. the Smithy operation shape name). RPC-style
     * protocols address operations by name (AWS JSON's `X-Amz-Target`, AWS
     * Query's `Action=`) and unwrap responses by it; REST protocols ignore it.
     */
    readonly operationName?: string;
    /**
     * The smithy `smithy.api#endpoint` hostPrefix (e.g. `sync-` for Step
     * Functions' StartSyncExecution). Protocols prepend it to the resolved
     * endpoint host, substituting `{memberName}` labels from the input.
     */
    readonly endpointHostPrefix?: string;
    readonly pagination?: Pagination.PaginatedTrait;
}
declare const Protocol_base: Context.ServiceClass<Protocol, "Protocol", {
    readonly encode: (args: {
        readonly input: unknown;
        readonly inputAst: AST.AST;
        /** The operation's config (memoized per operation -- see {@link ProtocolOperationConfig}). */
        readonly config: ProtocolOperationConfig;
    }) => Effect.Effect<HttpClientRequest.HttpClientRequest>;
    readonly decode: (args: {
        readonly response: HttpClientResponse.HttpClientResponse;
        readonly outputAst: AST.AST;
        /**
         * The operation's declared error classes (from `OperationConfig.errors`).
         * Protocols use these to surface wire failures as the operation's typed
         * errors -- e.g. by consulting matcher metadata stamped on the class.
         */
        readonly errors: ReadonlyArray<ApiErrorClass>;
        /** The operation's config (memoized per operation -- see {@link ProtocolOperationConfig}). */
        readonly config: ProtocolOperationConfig;
    }) => Effect.Effect<unknown>;
    /**
     * Optional whole-call implementation. When present, `API.make` runs a
     * call as `call(operation, input)` instead of encode -> HttpClient ->
     * decode, so a protocol can read the context once, build the request
     * synchronously and decode the response without intermediate effects.
     * It must read the `HttpClient` from the calling fiber's context and
     * produce the same request, result and errors as encode/decode.
     */
    readonly call?: (operation: PreparedOperation, input: unknown) => Effect.Effect<unknown>;
}>;
/**
 * The Protocol service knows how to turn a value into an HTTP request using
 * only the input schema's trait annotations, and how to turn a response back
 * into an output value using the output schema's trait annotations.
 *
 * Swap implementations by providing a different `Layer<Protocol>`.
 */
export declare class Protocol extends /*@__PURE__*/ Protocol_base {
}
/** The service a protocol layer provides. */
export type ProtocolShape = (typeof Protocol)["Service"];
/**
 * One operation as a protocol's {@link Protocol.call} sees it. Built once per
 * operation on its first call; the same object is passed on every call.
 */
export interface PreparedOperation {
    readonly config: ProtocolOperationConfig;
    readonly inputAst: AST.AST;
    readonly outputAst: AST.AST;
    readonly errors: ReadonlyArray<ApiErrorClass>;
    /** Per-operation slot owned by the operation's protocol (compiled codecs). */
    compiled?: unknown;
}
/**
 * Run `f` on the value of `effect` -- directly when `effect` is already a
 * successful `Exit` (e.g. a `Credentials` service holding
 * `Effect.succeed(config)`), so a resolved value costs no fiber step.
 */
export declare const withValue: <A, B>(effect: Effect.Effect<A, any, any>, f: (a: A) => Effect.Effect<B, any, any>) => Effect.Effect<B, any, any>;
export type ApiErrorClass = {
    new (...args: any[]): {
        readonly _tag: string;
        readonly message: string;
    };
};
/**
 * The shape of a generated SDK operation -- usable two ways (mirrors the
 * distilled repo's OperationMethod):
 *
 * 1. Direct call: `yield* operation(input)` -- an Effect with requirements.
 * 2. Yield first: `const fn = yield* operation` -- captures the current
 *    context and returns a requirement-free call function.
 *
 * Generated service files annotate every exported operation with this type
 * explicitly (against their hand-emitted interfaces), so the compiler never
 * has to infer it back out of the schema generics.
 */
export type OperationMethod<I, O, E, R> = Effect.Effect<(input: I) => Effect.Effect<O, E, never>, never, R> & ((input: I) => Effect.Effect<O, E, R>) & OperationSchemas<I, O>;
/**
 * An operation's request and response schemas, built on first access.
 * Generated modules export operations, errors and types; the schemas
 * themselves are module-private, so this is how to reach them as values.
 */
export interface OperationSchemas<I, O> {
    readonly input: S.Codec<I, any>;
    readonly output: S.Codec<O, any>;
}
export interface OperationConfig<I extends S.Top, O extends S.Top, PE, PR, E extends readonly ApiErrorClass[] = readonly ApiErrorClass[]> {
    input?: I;
    output?: O;
    errors?: E;
    /**
     * The protocol layer that knows how to encode/decode this operation's wire
     * format. Built once per process and shared across all operations that
     * reference the same layer value -- it must resolve call-dependent services
     * (credentials etc.) inside encode/decode, not at build time.
     */
    protocol: Layer.Layer<Protocol, PE, PR>;
    /**
     * SDK-specific retry service tag (see `core/retry`). When provided and the
     * caller's context carries a policy under this tag, every call is retried
     * per that policy (e.g. `Layer.succeed(Cloudflare.Retry.Retry, factory)`).
     */
    retry?: Context.Key<any, RetryPolicy>;
    /**
     * The wire operation name for RPC-style protocols (see
     * {@link ProtocolOperationConfig.operationName}).
     */
    operationName?: string;
    /**
     * Host prefix from the smithy endpoint trait (see
     * {@link ProtocolOperationConfig.endpointHostPrefix}).
     */
    endpointHostPrefix?: string;
}
export declare function make<I extends S.Top, O extends S.Top, PE, PR, const E extends readonly ApiErrorClass[] = readonly []>(configFn: () => OperationConfig<I, O, PE, PR, E>): OperationMethod<S.Schema.Type<I>, S.Schema.Type<O>, InstanceType<E[number]> | PE | HttpClientError.HttpClientError, PR | HttpClient.HttpClient>;
/**
 * STRUCTURAL fallback for the element type `.items()` yields: the array
 * element of the page response itself, or of its `result` member.
 *
 * It can only see shapes it was taught, so any other envelope
 * (`{ branches: [...] }`, `{ data: [...] }`, ...) lands on `unknown` -- which is
 * why generators pass the item type EXPLICITLY as
 * {@link PaginatedOperationMethod}'s `Item` argument, resolved from the
 * pagination trait's `items` path against the response shape. This default
 * only applies to hand-written operations.
 */
export type PaginatedItem<A> = A extends ReadonlyArray<infer Item> ? Item : A extends {
    result: ReadonlyArray<infer Item>;
} ? Item : A extends {
    result?: ReadonlyArray<infer Item> | null | undefined;
} ? Item : unknown;
/**
 * The callable half of a paginated operation: the operation call itself, plus
 * `.pages(input)` streaming every page response and `.items(input)` streaming
 * the individual items across pages.
 *
 * Used twice in {@link PaginatedOperationMethod} -- once with the operation's
 * requirements (`R`) for the direct-call style, once with `R = never` for the
 * value `yield* operation` hands back, which has the caller's context baked in.
 */
export interface PaginatedCall<I, O, E, R, Item> {
    (input: I): Effect.Effect<O, E, R>;
    readonly pages: (input: I) => Stream.Stream<O, E, R>;
    readonly items: (input: I) => Stream.Stream<Item, E, R>;
}
/**
 * A paginated operation: usable both ways an {@link OperationMethod} is, with
 * `.pages` / `.items` on BOTH -- the operation object for
 * `yield* op.items(input)`, and the requirement-free call function for
 * `const op = yield* operation; yield* op.items(input)` (distilled #145).
 */
export type PaginatedOperationMethod<I, O, E, R, Item = PaginatedItem<O>> = Effect.Effect<PaginatedCall<I, O, E, never, Item>, never, R> & PaginatedCall<I, O, E, R, Item> & OperationSchemas<I, O>;
export interface PaginatedOperationConfig<I extends S.Top, O extends S.Top, PE, PR, E extends readonly ApiErrorClass[] = readonly ApiErrorClass[]> extends OperationConfig<I, O, PE, PR, E> {
    /** How to advance between pages (mirrors the `smithy.api#paginated` trait). */
    pagination: Pagination.PaginatedTrait;
}
/**
 * Like {@link make}, plus `.pages()` / `.items()` streaming built on the
 * operation's pagination trait. The SDK can pass a provider-specific
 * {@link Pagination.PaginationStrategy} (e.g. Cloudflare stops page-mode
 * traversal on the first empty page); the default dispatches on
 * `pagination.mode`.
 */
export declare function makePaginated<I extends S.Top, O extends S.Top, PE, PR, const E extends readonly ApiErrorClass[] = readonly []>(configFn: () => PaginatedOperationConfig<I, O, PE, PR, E>, strategy?: Pagination.PaginationStrategy): PaginatedOperationMethod<S.Schema.Type<I>, S.Schema.Type<O>, InstanceType<E[number]> | PE | HttpClientError.HttpClientError, PR | HttpClient.HttpClient>;
/**
 * Generated operations described by data instead of code.
 *
 * A service module holds each operation as one arrow that is both the
 * callable operation and the holder of its description:
 *
 *   export const getFile = API.op((i) => i === API.D ? ['{input:#1,...};__more', [__0, __4, ...]] : API.call(getFile, i));
 *
 * Called with {@link D}, it returns `[data, refs]`: `;`-separated entries
 * in a small expression language (below) and the values they name. `refs[0]`
 * is the schema-lite `at` (lazy schema wrapper). Schemas reached by more
 * than one operation live in shared holders, `function __d3() { return
 * [data, refs]; }`, named in `refs` so a bundler keeps only the holders an
 * operation reaches. Entry 0 of an operation is its config; the rest are
 * schemas and thunk bodies. Evaluating an entry calls the same
 * constructors the code form called, in the same order, so the result is
 * the same schema.
 *
 * Importing a module allocates one function per operation and one per
 * holder; the data stays text in the module source until first use. A
 * holder's refs may also be values built from module code on first use
 * (service traits, endpoint rules), which its value entries name.
 *
 * Grammar (`;` never appears outside an entry separator; strings escape it):
 *
 *   $N        refs[N]
 *   #N  #R:N  schema entry N of this holder / of the holder refs[R] (lazy, memoized)
 *   ~N  ~R:N  value entry N of this holder / of refs[R] (a constant, evaluated once)
 *   >N        thunk `() => entry N`
 *   "..." -1.5 true false null   JSON literal   u  undefined
 *   {k:e,"k":e}  object   [e,e]  array
 *   e(a,b)    call   e.name  member   e.name(a,b)  method call   e@"X"  e.annotate({ identifier: "X" })
 */
export declare const D: unique symbol;
type DataFn = (i?: unknown) => any;
/** A schema of a holder, for module-level code (error classes) that names one at import. */
export declare const schema: (fn: DataFn, j: number) => any;
/**
 * The data of an operation whose name recurs in its strings: `%` in them
 * stands for `stem` (a literal `%` is escaped).
 */
export declare const named: (stem: string, data: string, refs: unknown) => [string, unknown];
/** An operation described by data (see the region header). */
export declare const op: (fn: DataFn) => any;
/** A paginated operation described by data; its config may name a `strategy`. */
export declare const opPaginated: (fn: DataFn) => any;
/** The call path of a data operation. */
export declare const call: (op: unknown, input: unknown) => Effect.Effect<any, any, any>;
/** An error class described by data (see {@link errorBase}). */
export declare const error: (fn: DataFn) => any;
/**
 * The body of a data error class: with `new`, an instance of the built
 * base whose prototype is `newTarget`'s; called plainly, the class's data.
 */
export declare const newError: (props: unknown, newTarget: Function | undefined, data: unknown) => any;
/**
 * The placeholders of a lazy service module (see the region header): `o()`
 * and `e()` make the next operation / error class. A placeholder finds its
 * data by its index; it closes over nothing of its own, so it costs one
 * function.
 */
export declare const lazyService: (url: string, spec: string, kinds: string, ns?: readonly any[], at?: number, len?: number) => {
    readonly o: () => any;
    readonly e: (name: string) => any;
    readonly E: any;
};
export declare const lazyNamespace: (url: string, spec: string) => any;
export {};
//# sourceMappingURL=api.d.ts.map