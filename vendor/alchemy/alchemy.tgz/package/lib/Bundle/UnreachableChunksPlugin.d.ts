import type * as rolldown from "rolldown";
/**
 * Drop the chunks no entry reaches, with their source maps, before the bundle
 * is returned or written.
 *
 * Rolldown decides a dynamic chunk is live when the statement holding its
 * `import()` is included, and a cycle can keep that true on its own: Vite's
 * `node.js` sets up `createCachedImport(() => import("./build.js"))` at
 * module level, and `build.js` imports `node.js` back. So a Worker that only
 * reaches `import("vite")` through deploy-time code tree-shaking removes
 * still got ~1 MB of chunks (Vite, rolldown, esbuild, postcss, …) that
 * nothing loads, and every output file is uploaded.
 *
 * `dynamicImports` is computed before constant inlining, so it can list an
 * `import()` the final code no longer contains: only dynamic imports the
 * importer's code still references are followed.
 */
export declare const unreachableChunksPlugin: () => rolldown.Plugin;
//# sourceMappingURL=UnreachableChunksPlugin.d.ts.map