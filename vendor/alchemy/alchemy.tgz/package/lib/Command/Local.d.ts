/**
 * The `Command.Dev` provider group served by the dev sidecar (see
 * `Local/Sidecar.ts`), so a dev server process outlives exec-child reloads.
 */
import * as Layer from "effect/Layer";
declare const _default: Layer.Layer<import("../Provider.ts").Provider<import("./Dev.ts").Dev>, never, import("../AlchemyContext.ts").AlchemyContext | import("../Artifacts.ts").ArtifactStore | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("../Stack.ts").Stack | import("../Stage.ts").Stage>;
export default _default;
//# sourceMappingURL=Local.d.ts.map