declare const _default: import("effect/Layer").Layer<import("../Provider.ts").Provider<import("./Server.ts").Server>, never, import("../AlchemyContext.ts").AlchemyContext | import("../Artifacts.ts").ArtifactStore | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("../Stack.ts").Stack>;
export default _default;
//# sourceMappingURL=ServerLocal.d.ts.map