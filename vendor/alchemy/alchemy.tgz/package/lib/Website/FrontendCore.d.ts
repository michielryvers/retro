import * as Effect from "effect/Effect";
/**
 * Loads `@alchemy.run/frontend-frameworks/core` when a website is built or
 * served. The package is an optional peer dependency, so provider entrypoints
 * that re-export their `Website` namespace (e.g. `@alchemy.run/prisma`) must not
 * import it statically — that would break every consumer that never deploys a
 * website and so never installed it.
 */
export declare const loadFrontendCore: Effect.Effect<{
    parseBuildOutput: (content: string) => import("@alchemy.run/frontend-frameworks/core").BuildOutput;
    readBuildOutput: (path: string) => Effect.Effect<import("@alchemy.run/frontend-frameworks/core").BuildOutput, import("effect/PlatformError").PlatformError, import("effect/FileSystem").FileSystem>;
    sortServerModules: (modules: Array<import("@alchemy.run/frontend-frameworks/core").OutputFile>, entry: string | undefined) => Array<import("@alchemy.run/frontend-frameworks/core").OutputFile>;
    stringifyBuildOutput: (output: import("@alchemy.run/frontend-frameworks/core").BuildOutput) => string;
    toOutputFile: (name: string, content: string | Uint8Array) => Effect.Effect<import("@alchemy.run/frontend-frameworks/core").OutputFile>;
    writeBuildOutput: (filePath: string, output: import("@alchemy.run/frontend-frameworks/core").BuildOutput) => Effect.Effect<void, import("effect/PlatformError").PlatformError, import("effect/FileSystem").FileSystem | import("effect/Path").Path>;
    collectExternalWorkspaces: (directories: Iterable<string>) => Effect.Effect<Set<string>, import("@alchemy.run/frontend-frameworks/core").CollectorError, import("effect/FileSystem").FileSystem>;
    CollectorError: typeof import("@alchemy.run/frontend-frameworks/core").CollectorError;
    DEFAULT_TEXT_FILE_REGEX: RegExp;
    makeBuildOutputCollector: (options?: import("@alchemy.run/frontend-frameworks/core").CollectorOptions) => Effect.Effect<import("@alchemy.run/frontend-frameworks/core").BuildOutputCollector, never, import("effect/FileSystem").FileSystem>;
    readServerModulesFromDisk: (options: import("@alchemy.run/frontend-frameworks/core").ReadServerModulesOptions) => Effect.Effect<Array<import("@alchemy.run/frontend-frameworks/core").OutputFile>, import("@alchemy.run/frontend-frameworks/core").CollectorError, import("effect/FileSystem").FileSystem>;
    selectEntryByFacade: (entryPath: string) => ((chunk: import("@alchemy.run/frontend-frameworks/core").ServerEntryChunk) => boolean);
    WORKER_ENTRY_PREFIX: "\0distilled:worker-entry:";
    applyDeployTargetFinish: (target: import("@alchemy.run/frontend-frameworks/core").DeployTarget | undefined, output: import("@alchemy.run/frontend-frameworks/core").BuildOutput, context: import("@alchemy.run/frontend-frameworks/core").DeployTargetFinishContext) => Effect.Effect<import("@alchemy.run/frontend-frameworks/core").BuildOutput, import("@alchemy.run/frontend-frameworks/core").DeployTargetError, import("@alchemy.run/frontend-frameworks/core").DeployTargetServices>;
    DeployTargetError: typeof import("@alchemy.run/frontend-frameworks/core").DeployTargetError;
    isDeployTarget: (value: unknown) => value is import("@alchemy.run/frontend-frameworks/core").DeployTarget;
    makeDeployTarget: <T extends import("@alchemy.run/frontend-frameworks/core").DeployTarget>(target: T) => T;
    resolveDeployTarget: <T extends import("@alchemy.run/frontend-frameworks/core").DeployTarget, Config>(root: string, input: import("@alchemy.run/frontend-frameworks/core").DeployTargetInput<T, Config>, config: Config) => Effect.Effect<T, import("@alchemy.run/frontend-frameworks/core").DeployTargetError>;
    resolveDeployTargetEntry: (target: Pick<import("@alchemy.run/frontend-frameworks/core").DeployTarget, "entry"> | undefined, context: {
        readonly root: string;
    }) => string | undefined;
    isInsideDevChild: () => boolean;
    isJsonSerializable: (value: unknown) => boolean;
    runDevChild: (options: import("@alchemy.run/frontend-frameworks/core").DevChildOptions) => Effect.Effect<import("@alchemy.run/frontend-frameworks/core").FrameworkDevServer, import("@alchemy.run/frontend-frameworks/core").FrameworkError, import("effect/Scope").Scope>;
    findEphemeralPort: (host?: string) => Effect.Effect<number, import("@alchemy.run/frontend-frameworks/core").FrameworkError>;
    resolveViteDevPort: (viteVersion: string | null | undefined, explicitPort?: number | undefined) => Effect.Effect<number, import("@alchemy.run/frontend-frameworks/core").FrameworkError>;
    NODE_BUNDLE_CONDITIONS: readonly ["node", "import", "module", "default"];
    NODE_DEFAULT_PORT: 3000;
    NODE_SERVE_ENTRY_FILE_NAME: "serve-node.mjs";
    makeNodeServeEntrySource: (options: import("@alchemy.run/frontend-frameworks/core").NodeServeEntryOptions) => string;
    pinNodeServeModule: (output: import("@alchemy.run/frontend-frameworks/core").BuildOutput, serveModule: import("@alchemy.run/frontend-frameworks/core").OutputFile) => import("@alchemy.run/frontend-frameworks/core").BuildOutput;
    relativeClientDirExpression: (fromFile: string, clientDirectory: string) => string;
    writeNodeServeEntry: (options: import("@alchemy.run/frontend-frameworks/core").WriteNodeServeEntryOptions) => Effect.Effect<import("@alchemy.run/frontend-frameworks/core").BuildOutput, import("@alchemy.run/frontend-frameworks/core").DeployTargetError, import("effect/FileSystem").FileSystem | import("effect/Path").Path>;
    NEON_SERVE_ENTRY_FILE_NAME: "serve-neon.mjs";
    makeNeonServeEntrySource: (options: import("@alchemy.run/frontend-frameworks/core").NodeServeEntryOptions) => string;
    finishNeonOutput: (output: import("@alchemy.run/frontend-frameworks/core").BuildOutput) => Effect.Effect<import("@alchemy.run/frontend-frameworks/core").BuildOutput, import("@alchemy.run/frontend-frameworks/core").DeployTargetError, import("effect/FileSystem").FileSystem | import("effect/Path").Path>;
    makeNeonTarget: <T extends import("@alchemy.run/frontend-frameworks/core").DeployTarget>(node: T) => T;
    Framework: typeof import("@alchemy.run/frontend-frameworks/core").Framework;
    FrameworkError: typeof import("@alchemy.run/frontend-frameworks/core").FrameworkError;
    loadProjectModule: <T = unknown>(root: string, specifier: string) => Effect.Effect<T, import("@alchemy.run/frontend-frameworks/core").ModuleLoadError>;
    ModuleLoadError: typeof import("@alchemy.run/frontend-frameworks/core").ModuleLoadError;
    resolveInstalledPackageVersion: (fromDirectory: string, packageName: string) => Effect.Effect<string | undefined>;
    resolveProjectPackageDirectory: (root: string, packageName: string) => Effect.Effect<string, import("@alchemy.run/frontend-frameworks/core").ModuleLoadError>;
    default: typeof import("@alchemy.run/frontend-frameworks/core");
}, never, never>;
//# sourceMappingURL=FrontendCore.d.ts.map