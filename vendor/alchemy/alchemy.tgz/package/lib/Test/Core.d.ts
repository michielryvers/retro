/** @effect-diagnostics anyUnknownInErrorContext:off */
import * as Config from "effect/Config";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Scope from "effect/Scope";
import { AlchemyContext } from "../AlchemyContext.ts";
import { ArtifactStore } from "../Artifacts.ts";
import type { Input } from "../Input.ts";
import * as Interaction from "../Interaction.ts";
import * as RpcProviderProxy from "../Local/RpcProviderProxy.ts";
import * as RpcSpawner from "../Local/RpcSpawner.ts";
import * as Plan from "../Plan.ts";
import type { ResourceSelection, SelectionOutput } from "../ResourceSelection.ts";
import { type CompiledStack, Stack, type StackEffect, type StackServices } from "../Stack.ts";
import { Stage } from "../Stage.ts";
import * as State from "../State/index.ts";
/**
 * Configuration shared by every test in a file. Pass to `Test.make(...)`.
 */
export interface MakeOptions<ROut = any> {
    /** Provider layer for the stack — e.g. `AWS.providers()`, `Cloudflare.providers()`. */
    providers: Layer.Layer<ROut, never, StackServices>;
    /** State store for top-level `deploy(Stack)` / `destroy(Stack)`; defaults to {@link State.localState}. */
    state?: Layer.Layer<State.State, never, StackServices>;
    /** Override the current profile; otherwise resolved from env or the built-in `default`. */
    profile?: string;
    /**
     * Default stage for deploy/destroy. Defaults to `test_$USER` (or
     * `test_$USERNAME` on Windows, `test_unknown` if neither is set) so two
     * people running the same suite against one account don't collide.
     * Does **not** read `$ALCHEMY_STAGE` — that is the CLI deploy/dev stage.
     */
    stage?: string;
    /**
     * Engine-level adoption policy for this test run. When `true`, resources
     * without prior state will be adopted from the cloud via `provider.read`
     * (matching the CLI's `--adopt` flag). Defaults to `false`.
     */
    adopt?: boolean;
    /**
     * Run providers in local-dev mode (matching the CLI's `alchemy dev` flag).
     * When `true`, resources like Cloudflare Workers run locally via workerd
     * instead of being deployed to the cloud. When omitted, falls back to the
     * `ALCHEMY_DEV` environment variable (`"1"` / `"true"` enable it).
     *
     * {@link ALCHEMY_TEST_DEV} (`ALCHEMY_TEST_DEV=1`) overrides this — use it
     * to force an entire existing live suite through local providers without
     * editing each `Test.make({ dev: true })`.
     */
    dev?: boolean;
    /**
     * Run local providers behind the RPC sidecar proxy, matching the process
     * topology of the real `alchemy dev` command: an {@link RpcProviderProxy}
     * is installed, so `RpcProvider.providerServicesEffect` layers (e.g.
     * Cloudflare's `localRuntimeServices()`) are EMPTY in the test process and
     * RPC-backed providers run their lifecycle in a spawned sidecar process.
     *
     * Defaults to the resolved `dev` flag — dev tests run the real `alchemy
     * dev` topology unless they opt out. In-process dev (`sidecar: false`)
     * masks missing main-process lifecycle dependencies (the class of bug
     * behind #1007, where D1's local migrations only failed under `alchemy
     * dev`); it remains available because it IS still a real production path —
     * a plain `alchemy deploy` deleting a `providerMode: "local"` state row
     * runs the local provider in-process — and because in-process runs are
     * easier to debug.
     *
     * Fully lazy: only the proxy facade is installed up front. The spawner
     * HTTP server starts — and a sidecar child process is forked — on the
     * first provider session request (a deploy/destroy building an RPC-backed
     * local provider); a dev file that never does starts no processes at all.
     * Once started, the sidecar lives for the whole test file (its own scope,
     * closed by the adapter's final cleanup hook), so `beforeAll(deploy(Stack))`
     * + per-test requests work the same way they do under a real `alchemy dev`
     * session.
     *
     * Pass an object to run the sidecar with options: `omitEnv` lists prefixes
     * of environment variables the sidecar must not inherit (e.g.
     * `["CLOUDFLARE_"]` to exercise credential-free dev while the shell
     * exports credentials).
     */
    sidecar?: boolean | SidecarOptions;
}
/** Options for the dev sidecar process — see {@link MakeOptions.sidecar}. */
export interface SidecarOptions {
    /** Prefixes of environment variables withheld from the sidecar. */
    readonly omitEnv?: ReadonlyArray<string>;
}
/**
 * The RPC sidecar topology used by the real `alchemy dev` command, in one
 * process-local layer: an {@link RpcSpawner} HTTP server that forks sidecar
 * processes on demand, and an {@link RpcProviderProxy} pointed at it.
 */
export declare const sidecarProxy: (options: {
    profile?: string;
    omitEnv?: ReadonlyArray<string>;
}) => Layer.Layer<RpcProviderProxy.RpcProviderProxy | RpcSpawner.RpcSpawner, import("effect/http/HttpServerError").ServeError, import("effect/process/ChildProcessSpawner").ChildProcessSpawner | HttpClient.HttpClient>;
/**
 * Force every `Test.make` into (or out of) local-dev mode, regardless of
 * the file's `dev` option. Unset leaves the option / `ALCHEMY_DEV` fallback
 * in place. Accepts the usual truthy/falsey strings (`true`/`1`/`yes`/`on`,
 * `false`/`0`/`no`/`off`).
 */
export declare const ALCHEMY_TEST_DEV: Config.Config<Option.Option<boolean>>;
/** The `ALCHEMY_TEST_DEV` override, if the env var is set. */
export declare const alchemyTestDevOverride: () => Option.Option<boolean>;
/** Resolve the effective `dev` flag: `ALCHEMY_TEST_DEV`, then options, then `ALCHEMY_DEV`. */
export declare const resolveDev: (options: {
    dev?: boolean;
}) => boolean;
/** Resolve the effective `sidecar` flag: defaults to the resolved `dev` flag. */
export declare const resolveSidecar: (options: MakeOptions) => boolean;
/**
 * Default test stage: `ALCHEMY_TEST_STAGE`, then `test_$USER` (or
 * `test_$USERNAME` / `test_unknown`). Set an explicit test stage to isolate
 * concurrent worktrees that share a cloud account.
 * Matches the CLI's `live_$USER` / `dev_$USER` per-developer isolation.
 */
export declare const defaultStage: () => string;
/** File-level stage: a string override, otherwise {@link defaultStage}. */
export declare const resolveStage: (options: {
    stage?: string;
}) => string;
/**
 * The sidecar runtime handed to each adapter's `make(...)`.
 *
 * `provide` installs a lazy {@link RpcProviderProxy} facade into an effect.
 * Installing the facade is free: the spawner HTTP server only starts (and,
 * downstream of it, a sidecar child process is only forked) when a provider
 * actually requests a session — i.e. when a deploy/destroy builds an
 * RPC-backed local provider. A dev file that never does starts nothing.
 *
 * The spawner (and the sidecar children it forks) is a PROCESS-WIDE
 * SINGLETON shared by every test file, refcounted per handle: all files run
 * in one bun process, and a per-file sidecar means a per-file bun child that
 * imports the entire alchemy + distilled module graph — dozens of concurrent
 * files at hundreds of MB each OOMs the machine. Stack isolation is
 * preserved because each RPC session carries its own stack environment (see
 * `SESSION_ENV_PARAM` in Local/RpcServerEnvironment.ts) and the child builds
 * a provider context per stack. The singleton's scope closes when the LAST
 * handle closes; `Test.make` runs at collection time (before any test), so
 * the refcount cannot dip to zero while later files still need it. Adapters
 * run `close` from the same final cleanup hook that closes the shared scope.
 */
export interface SidecarHandle {
    readonly provide: <A, E, R>(eff: Effect.Effect<A, E, R>) => Effect.Effect<A, any, any>;
    readonly close: Effect.Effect<void>;
}
/** Payload-free counts; observing them never starts the singleton. */
export declare const sidecarDiagnostics: Effect.Effect<{
    sessions: number;
    testSessions: number;
    owners: number;
    connections: number;
    singletons: number;
    reservations: number;
    started: number;
}, never, never>;
export declare const makeSidecarHandle: <ROut = any>(options: MakeOptions<ROut>) => SidecarHandle | undefined;
export type TestEffect<A, Req = never> = StackEffect<A, any, Req>;
/**
 * Build the per-test runtime and return a self-contained Effect.
 *
 * Mirrors {@link "../bin/alchemy.js"} composition: ConfigProvider via
 * `loadConfigProvider` + `withProfileOverride`, an empty `AuthProviders`
 * registry that the user's `providers` layer populates, the platform layers,
 * and the configured state store. Adapters wrap this into runner-specific
 * thunks (`bun.test` -> `runPromise`, `it.live` -> as-is).
 *
 * When `scope` is provided, scoped resources (like the Cloudflare dev
 * sidecar) survive past this effect and are tied to the lifetime of the
 * provided scope instead. The runner is responsible for closing it.
 *
 * When `scope` is omitted, the effect runs with `Effect.scoped` and any
 * scoped resources are torn down as soon as it resolves.
 */
export declare const toEffect: <A, ROut = any>(effect: TestEffect<A>, options: MakeOptions<ROut>, scope?: Scope.Scope, sidecar?: SidecarHandle) => Effect.Effect<A, any, never>;
/** Promise wrapper around {@link toEffect} for `bun.test`-style runners. */
export declare const run: <A, ROut = any>(effect: TestEffect<A>, options: MakeOptions<ROut>, scope?: Scope.Scope, sidecar?: SidecarHandle) => Promise<A>;
/**
 * Wrap an effect so it runs with `options.providers` + a placeholder Stack +
 * Stage in scope. Used by `test.provider` so user code can call provider SDK
 * APIs (e.g. `DynamoDB.describeTable`) directly inside the test body.
 */
export declare const withProviders: <A, E, R, ROut>(effect: Effect.Effect<A, E, R>, options: MakeOptions<ROut>, stackName: string) => Effect.Effect<A, E, Exclude<R, ROut | Stack | Stage>>;
/**
 * Curried `deploy` for the test factory: bakes in the configured stage and
 * adds the telemetry layer the CLI uses, so `beforeAll(deploy(Stack))` works
 * the same way as `alchemy deploy`.
 *
 * `scope`, when supplied, is forwarded down so the dev sidecar (and other
 * scoped resources) lives until the caller closes it instead of dying as
 * soon as `deploy` resolves. The test harness uses this to keep workerd
 * alive across `beforeAll` → tests → `afterAll`.
 */
export interface DeployCallOptions extends Plan.MakePlanOptions {
    stage?: string;
    scope?: Scope.Scope;
}
export type DeployResult<A> = Effect.Effect<Input.Resolve<A>, Effect.Error<ReturnType<typeof deployStack<A>>>, Effect.Services<ReturnType<typeof deployStack<A>>>>;
export interface FilteredDeployCallOptions extends Omit<DeployCallOptions, keyof ResourceSelection>, ResourceSelection {
}
type FullDeployCall = [options?: DeployCallOptions];
/**
 * Filtered deploys return void; the whole declaration still evaluates.
 * With an explicit output type, filtering also requires the Call tuple type.
 */
export interface Deploy {
    <A, Call extends [options?: FilteredDeployCallOptions] = FullDeployCall>(stack: TestEffect<CompiledStack<A>, Stage | AlchemyContext>, ...call: Call): DeployResult<SelectionOutput<A, Call[0]>>;
}
export declare function deploy<A, Call extends [options?: FilteredDeployCallOptions] = FullDeployCall>(options: MakeOptions, stack: TestEffect<CompiledStack<A>, Stage | AlchemyContext>, ...call: Call): DeployResult<SelectionOutput<A, Call[0]>>;
declare const deployStack: <A>(options: MakeOptions, stack: TestEffect<CompiledStack<A>, Stage | AlchemyContext>, callOptions?: FilteredDeployCallOptions) => Effect.Effect<Input.Resolve<A> | undefined, import("../Auth/AuthProvider.ts").AuthError | Config.ConfigError | import("../Auth/Demand.ts").CredentialsRequired | import("../Apply.ts").DestroyError | import("../Output.ts").InvalidReferenceError | import("../Output.ts").MissingSourceError | import("../Auth/AuthProvider.ts").NeedsReauth | import("effect/PlatformError").PlatformError | State.StateStoreError, AlchemyContext | ArtifactStore | import("effect/FileSystem").FileSystem | Interaction.Interaction | import("effect/Path").Path | State.State>;
/** Bind test-file options and the shared runtime scope without erasing output types. */
export declare const makeDeploy: (options: MakeOptions, scope: Scope.Scope) => Deploy;
export declare const destroy: (options: MakeOptions, stack: TestEffect<CompiledStack, Stage | AlchemyContext>, callOptions?: {
    stage?: string;
    scope?: Scope.Scope;
    include?: never;
    exclude?: never;
}) => Effect.Effect<undefined, import("../Auth/AuthProvider.ts").AuthError | Config.ConfigError | import("../Auth/Demand.ts").CredentialsRequired | import("../Apply.ts").DestroyError | import("../Output.ts").InvalidReferenceError | import("../Output.ts").MissingSourceError | import("../Auth/AuthProvider.ts").NeedsReauth | import("effect/PlatformError").PlatformError | State.StateStoreError, AlchemyContext | ArtifactStore | import("effect/FileSystem").FileSystem | Interaction.Interaction | import("effect/Path").Path | State.State>;
/**
 * In-test scratch stack handed to `test.provider(name, (stack) => ...)`.
 *
 * Each scratch stack owns a private state store that is shared between
 * successive `deploy`/`destroy` calls AND visible to the user's test body
 * (so `yield* State` / `state.get(...)` see the same store the deploys
 * mutated). This makes create / update / replace / delete paths exercisable
 * without polluting other tests in the same file.
 *
 * When the adapter can name the test file (the alchemy-test runner), the
 * store is DURABLE — rows live under `.alchemy/state/{file}-{test}/{stage}`
 * on disk. Durability is what makes an interrupted destroy recoverable: the
 * engine persists a `deleting` row before every `provider.delete` and only
 * drops it on success, so a run killed mid-delete (e.g. the runner's
 * teardown-abandonment after a test timeout) leaves resumable rows that the
 * NEXT run's leading `stack.destroy()` (or the `Effect.ensuring` teardown)
 * picks up and drains. An in-memory scratch dies with the process, silently
 * orphaning every cloud resource whose delete was still in flight.
 */
export interface ScratchStack<ROut = any> {
    readonly name: string;
    /** Stage this scratch deploys to ({@link resolveStage} of the file options). */
    readonly stage: string;
    /** The shared in-memory state Layer for this scratch. @internal */
    readonly state: Layer.Layer<State.State, never, never>;
    /** Filters leave other rows and stack outputs untouched; declaration still runs. */
    deploy<A, E, R, Call extends [options?: Plan.FilteredPlanOptions] = []>(effect: Effect.Effect<A, E, R>, ...call: Call): Effect.Effect<SelectionOutput<Input.Resolve<A>, Call[0]>, any, Exclude<R, ROut | StackServices>>;
    /**
     * Build a plan against the scratch's shared state WITHOUT applying it.
     *
     * Use this to assert on the planned action for a resource (e.g. that a
     * downstream dependency stays `noop` when only an upstream resource
     * changes) without mutating the cloud. Plans run against whatever state
     * prior `deploy(...)` calls persisted.
     */
    plan<A, E, R, Call extends [options?: Plan.FilteredPlanOptions] = []>(effect: Effect.Effect<A, E, R>, ...call: Call): Effect.Effect<Plan.Plan<SelectionOutput<A, Call[0]>>, any, Exclude<R, ROut | StackServices>>;
    destroy(options?: {
        include?: never;
        exclude?: never;
    }): Effect.Effect<void, any, never>;
}
/**
 * Build a fresh `ScratchStack` for `test.provider`.
 *
 * With `file` (the registration-time test file, supplied by the
 * alchemy-test adapter): the store is the durable `.alchemy/state` local
 * store and the stack name is namespaced by file so interrupted destroys
 * leave resumable rows for the next run (see {@link ScratchStack}).
 *
 * Without `file` (bun/vitest adapters, which cannot name their file at
 * registration time): falls back to a private in-memory store — isolated,
 * but discarded with the process.
 */
export declare const scratchStack: <ROut>(options: MakeOptions<ROut>, name: string, file?: string) => ScratchStack<ROut>;
export {};
//# sourceMappingURL=Core.d.ts.map