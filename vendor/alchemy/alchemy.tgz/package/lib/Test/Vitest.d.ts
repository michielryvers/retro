import * as Effect from "effect/Effect";
import type { AlchemyContext } from "../AlchemyContext.ts";
import type { CompiledStack } from "../Stack.ts";
import type { Stage } from "../Stage.ts";
import * as Core from "./Core.ts";
export { executeWhenReady, getWhenReady, guardContentType, guardedFetchLayer, rpcClientLayer, WorkerNotReady, type EdgeGuardOptions, type WhenReadyOptions, } from "./Http.ts";
export type MakeOptions<ROut = any> = Core.MakeOptions<ROut>;
export type ScratchStack = Core.ScratchStack;
export type TestEffect<A, R = never> = Core.TestEffect<A, R>;
export declare const defaultStage: typeof Core.defaultStage;
export declare const resolveStage: typeof Core.resolveStage;
type TestOptions = number | {
    timeout?: number;
};
interface TestFn {
    (name: string, eff: TestEffect<void>, options?: TestOptions): void;
    skip: (name: string, eff: TestEffect<void>, options?: TestOptions) => void;
    skipIf: (condition: boolean) => (name: string, eff: TestEffect<void>, options?: TestOptions) => void;
    only: (name: string, eff: TestEffect<void>, options?: TestOptions) => void;
    todo: (name: string, eff: TestEffect<void>, options?: TestOptions) => void;
    provider: ProviderFn;
}
interface ProviderFn {
    (name: string, fn: (stack: ScratchStack) => Effect.Effect<void, any, any>, options?: TestOptions): void;
    skip: (name: string, fn: (stack: ScratchStack) => Effect.Effect<void, any, any>, options?: TestOptions) => void;
    skipIf: (condition: boolean) => (name: string, fn: (stack: ScratchStack) => Effect.Effect<void, any, any>, options?: TestOptions) => void;
}
interface BeforeAllFn {
    <A>(eff: TestEffect<A>, options?: TestOptions): Effect.Effect<A>;
}
interface BeforeEachFn {
    (eff: TestEffect<void>, options?: TestOptions): void;
}
interface AfterAllFn {
    (eff: TestEffect<any>, options?: TestOptions): void;
    skipIf: (predicate: boolean) => (eff: TestEffect<any>, options?: TestOptions) => void;
}
interface AfterEachFn {
    (eff: TestEffect<void>, options?: TestOptions): void;
}
export interface TestApi {
    test: TestFn;
    beforeAll: BeforeAllFn;
    beforeEach: BeforeEachFn;
    afterAll: AfterAllFn;
    afterEach: AfterEachFn;
    deploy: Core.Deploy;
    destroy: (stack: TestEffect<CompiledStack, Stage | AlchemyContext>, options?: {
        stage?: string;
        include?: never;
        exclude?: never;
    }) => ReturnType<typeof Core.destroy>;
}
/**
 * Build the per-file test API. See {@link "./Bun.ts"} for the same shape
 * over `bun:test`. Vitest variant uses `@effect/vitest`'s `it.live` so
 * Effect-aware tests stay first-class.
 */
export declare const make: <ROut = any>(options: MakeOptions<ROut>) => TestApi;
//# sourceMappingURL=Vitest.d.ts.map