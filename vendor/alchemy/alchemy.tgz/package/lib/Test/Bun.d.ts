/** @effect-diagnostics anyUnknownInErrorContext:off */
import bun from "bun:test";
import type { HookOptions } from "node:test";
import * as Effect from "effect/Effect";
import type { AlchemyContext } from "../AlchemyContext.ts";
import type { CompiledStack } from "../Stack.ts";
import type { Stage } from "../Stage.ts";
import * as Core from "./Core.ts";
export { executeWhenReady, getWhenReady, guardContentType, guardedFetchLayer, rpcClientLayer, WorkerNotReady, type EdgeGuardOptions, type WhenReadyOptions, } from "./Http.ts";
export type MakeOptions<ROut = any> = Core.MakeOptions<ROut>;
export type ScratchStack = Core.ScratchStack;
export type TestEffect<A, R = never> = Core.TestEffect<A, R>;
export declare const defaultStage: typeof Core.defaultStage;
export declare const resolveStage: typeof Core.resolveStage;
export interface TestApi {
    test: TestFn;
    beforeAll: BeforeAllFn;
    beforeEach: BeforeEachFn;
    afterAll: AfterAllFn;
    afterEach: AfterEachFn;
    deploy: Core.Deploy;
    destroy: (stack: TestEffect<CompiledStack, Stage | AlchemyContext>, options?: {
        stage?: string;
        include?: never;
        exclude?: never;
    }) => ReturnType<typeof Core.destroy>;
}
interface TestFn {
    (name: string, eff: TestEffect<void>, options?: bun.TestOptions): void;
    skip: (name: string, eff: TestEffect<void>, options?: bun.TestOptions) => void;
    skipIf: (condition: boolean) => (name: string, eff: TestEffect<void>, options?: bun.TestOptions) => void;
    only: (name: string, eff: TestEffect<void>, options?: bun.TestOptions) => void;
    todo: (name: string, eff: TestEffect<void>, options?: bun.TestOptions) => void;
    provider: ProviderFn;
}
interface ProviderFn {
    (name: string, fn: (stack: ScratchStack) => Effect.Effect<void, any, any>, options?: bun.TestOptions): void;
    skip: (name: string, fn: (stack: ScratchStack) => Effect.Effect<void, any, any>, options?: bun.TestOptions) => void;
    skipIf: (condition: boolean) => (name: string, fn: (stack: ScratchStack) => Effect.Effect<void, any, any>, options?: bun.TestOptions) => void;
}
interface BeforeAllFn {
    <A>(eff: TestEffect<A>, options?: HookOptions): Effect.Effect<A>;
}
interface BeforeEachFn {
    (eff: TestEffect<void>, options?: HookOptions): void;
}
interface AfterAllFn {
    (eff: TestEffect<any>, options?: HookOptions): void;
    skipIf: (predicate: boolean) => (eff: TestEffect<any>, options?: HookOptions) => void;
}
interface AfterEachFn {
    (eff: TestEffect<void>, options?: HookOptions): void;
}
/**
 * Build the per-file test API. Configure providers / state once at the top of
 * the test file:
 *
 * ```ts
 * import * as Test from "alchemy/Test/Bun";
 * import * as Cloudflare from "@alchemy.run/cloudflare";
 *
 * const { test, deploy, destroy, beforeAll, afterAll } = Test.make({
 *   providers: Cloudflare.providers(),
 *   state: Cloudflare.state(),
 * });
 * ```
 */
export declare const make: <ROut = any>(options: MakeOptions<ROut>) => TestApi;
//# sourceMappingURL=Bun.d.ts.map