/** @effect-diagnostics anyUnknownInErrorContext:off */
/**
 * Test adapter for the `alchemy-test` runner (see `packages/alchemy-test`).
 *
 * Same shape as {@link "./Vitest.ts"} / {@link "./Bun.ts"}, but registers
 * tests as raw Effects with the alchemy-test harness so the single-process
 * runner can inject a buffering Logger/Console per test and manage
 * concurrency + timeouts itself.
 */
import { type TestOptions } from "@alchemy.run/test";
import * as Effect from "effect/Effect";
import type { AlchemyContext } from "../AlchemyContext.ts";
import type { CompiledStack } from "../Stack.ts";
import type { Stage } from "../Stage.ts";
import * as Core from "./Core.ts";
export { executeWhenReady, getWhenReady, guardContentType, guardedFetchLayer, rpcClientLayer, WorkerNotReady, type EdgeGuardOptions, type WhenReadyOptions, } from "./Http.ts";
export type MakeOptions<ROut = any> = Core.MakeOptions<ROut>;
export type ScratchStack = Core.ScratchStack;
export type TestEffect<A, R = never> = Core.TestEffect<A, R>;
export declare const ALCHEMY_TEST_DEV: import("effect/Config").Config<import("effect/Option").Option<boolean>>;
export declare const resolveDev: typeof Core.resolveDev;
export declare const defaultStage: typeof Core.defaultStage;
export declare const resolveStage: typeof Core.resolveStage;
interface TestFn {
    (name: string, eff: TestEffect<void>, options?: TestOptions): void;
    skip: (name: string, eff: TestEffect<void>, options?: TestOptions) => void;
    skipIf: (condition: boolean) => (name: string, eff: TestEffect<void>, options?: TestOptions) => void;
    only: (name: string, eff: TestEffect<void>, options?: TestOptions) => void;
    todo: (name: string, eff: TestEffect<void>, options?: TestOptions) => void;
    provider: ProviderFn;
}
interface ProviderFn {
    (name: string, fn: (stack: ScratchStack) => Effect.Effect<void, any, any>, options?: TestOptions): void;
    skip: (name: string, fn: (stack: ScratchStack) => Effect.Effect<void, any, any>, options?: TestOptions) => void;
    skipIf: (condition: boolean) => (name: string, fn: (stack: ScratchStack) => Effect.Effect<void, any, any>, options?: TestOptions) => void;
    todo: (name: string, fn: (stack: ScratchStack) => Effect.Effect<void, any, any>, options?: TestOptions) => void;
}
interface BeforeAllFn {
    <A>(eff: TestEffect<A>, options?: TestOptions): Effect.Effect<A>;
}
interface BeforeEachFn {
    (eff: TestEffect<void>, options?: TestOptions): void;
}
interface AfterAllFn {
    (eff: TestEffect<any>, options?: TestOptions): void;
    skipIf: (predicate: boolean) => (eff: TestEffect<any>, options?: TestOptions) => void;
}
interface AfterEachFn {
    (eff: TestEffect<void>, options?: TestOptions): void;
}
export interface TestApi {
    test: TestFn;
    beforeAll: BeforeAllFn;
    beforeEach: BeforeEachFn;
    afterAll: AfterAllFn;
    afterEach: AfterEachFn;
    deploy: Core.Deploy;
    destroy: (stack: TestEffect<CompiledStack, Stage | AlchemyContext>, options?: {
        stage?: string;
        include?: never;
        exclude?: never;
    }) => ReturnType<typeof Core.destroy>;
}
/**
 * Build the per-file test API. Configure providers / state once at the top of
 * the test file:
 *
 * ```ts
 * import * as Test from "@/Test/Alchemy";
 * import * as Cloudflare from "@alchemy.run/cloudflare";
 *
 * const { test, deploy, destroy, beforeAll, afterAll } = Test.make({
 *   providers: Cloudflare.providers(),
 *   state: Cloudflare.state(),
 * });
 * ```
 */
export declare const make: <ROut = any>(options: MakeOptions<ROut>) => TestApi;
//# sourceMappingURL=Alchemy.d.ts.map