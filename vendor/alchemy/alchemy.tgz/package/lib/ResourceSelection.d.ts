import * as Effect from "effect/Effect";
/** Selection applies after the whole stack declaration evaluates. */
export interface ResourceSelection {
    /** Exact FQNs, unique logical IDs, or FQN globs; dependencies are included. */
    readonly include?: ReadonlyArray<string>;
    /** Hard exclusions. A selected node depending on an excluded node fails planning. */
    readonly exclude?: ReadonlyArray<string>;
}
/** Required filters return no output; possibly supplied filters make output optional. */
export type SelectionOutput<A, Options> = Options extends {
    include: ReadonlyArray<string>;
} | {
    exclude: ReadonlyArray<string>;
} ? undefined : Options extends undefined ? A : Extract<Options[keyof Options & keyof ResourceSelection], ReadonlyArray<string>> extends never ? A : A | undefined;
declare const InvalidResourceSelection_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "InvalidResourceSelection";
} & Readonly<A>;
export declare class InvalidResourceSelection extends InvalidResourceSelection_base<{
    message: string;
}> {
}
declare const UnsafeSelectionBoundary_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnsafeSelectionBoundary";
} & Readonly<A>;
export declare class UnsafeSelectionBoundary extends UnsafeSelectionBoundary_base<{
    message: string;
}> {
}
/** Resolve and close the selection before accessing state or providers. */
export declare const selectResources: <Node extends {
    FQN: string;
    LogicalId: string;
}>(declared: ReadonlyArray<Node>, upstream: (node: Node) => ReadonlyArray<string>, options: ResourceSelection) => Effect.Effect<Set<string> | undefined, never, never>;
export {};
//# sourceMappingURL=ResourceSelection.d.ts.map