import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Exit from "effect/Exit";
import * as Schema from "effect/Schema";
import { Workflow } from "effect/workflow";
/**
 * Activity and deferred exits arrive with their values already encoded; a
 * void value is stored as null, since undefined isn't JSON.
 */
export declare const encodeExit: (exit: Exit.Exit<unknown, unknown>) => Effect.Effect<string, never, never>;
export declare const decodeExit: (text: string) => Effect.Effect<Exit.Exit<unknown, unknown>, never, never>;
/**
 * The schemas a workflow's payload and result are stored through. Concrete
 * `Workflow`s don't assign to Effect's own `Workflow.AnyWithProps` (its
 * `execute` options), so accept just what encoding reads.
 */
export type WorkflowSchemas = Pick<Workflow.AnyWithProps, "payloadSchema" | "successSchema" | "errorSchema">;
export declare const payloadCodec: (workflow: WorkflowSchemas) => Schema.Codec<unknown, unknown>;
/** A workflow's own result is stored through its success and error schemas. */
export declare const encodeResult: (workflow: WorkflowSchemas, exit: Exit.Exit<unknown, unknown>) => Effect.Effect<string, never, never>;
export declare const decodeResult: (workflow: WorkflowSchemas, text: string) => Effect.Effect<Workflow.Complete<unknown, unknown>, never, never>;
declare const CurrentActivity_base: Context.ServiceClass<CurrentActivity, "alchemy/Workflow/CurrentActivity", {
    readonly workflow: string;
    readonly executionId: string;
    readonly activity: string;
    /** The next id in this step's sequence, restarting on every attempt. */
    readonly next: () => string;
}>;
/**
 * The step a workflow engine is running: provided around each `Activity` so
 * the step's own work can derive stable ids from it. A step that runs again,
 * after a retry or a crash, sees the same values.
 *
 * @internal
 */
export declare class CurrentActivity extends CurrentActivity_base {
}
/** @internal */
export declare const makeCurrentActivity: (workflow: string, executionId: string, activity: string) => CurrentActivity["Service"];
export {};
//# sourceMappingURL=WorkflowEncoding.d.ts.map