/**
 * Canonicalizes an IPv4 or IPv6 CIDR to its network address.
 * Invalid input is returned unchanged; this function is not a validator.
 */
export declare const canonicalCidr: (cidr: string | undefined) => string | undefined;
//# sourceMappingURL=ip-address.d.ts.map