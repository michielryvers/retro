import { ConfigError } from "effect/Config";
import * as ConfigProvider from "effect/ConfigProvider";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import type { StackSecrets, StackServices } from "../Stack.ts";
/**
 * Command-line settings that shape a stack's configuration.
 *
 * @internal
 */
export interface StackConfigOverrides {
    /**
     * The `--env-file` flag: the file the CLI reads instead of
     * `.env`. A stack that declares its own `secrets` cannot be combined with
     * it; the list is the single place that decides what loads.
     */
    readonly envFile?: string;
    /** The `--profile` flag. */
    readonly profile?: string;
}
/** @internal */
export declare const StackConfigOverrides: Context.Reference<StackConfigOverrides>;
/**
 * Build the ConfigProvider a stack runs under from its `secrets` list.
 * When omitted, leave the caller's configuration unchanged.
 *
 * Each provider is a layer that requires the configuration assembled so far
 * and provides the merged result, so the list folds with `Layer.provide`:
 * later providers override earlier ones. With an explicit list, `ALCHEMY_PROFILE` is taken
 * from `--profile` or the real process environment only, never from a
 * provider, so a dotenv file or a secrets manager cannot redirect which
 * credentials every other provider uses.
 *
 * @internal
 */
export declare const stackConfigLayer: (secrets?: StackSecrets) => Layer.Layer<never, ConfigError, StackServices>;
/**
 * The ConfigProvider a CLI command runs under before any stack is loaded:
 * an explicit `--env-file` overrides the process environment. Without that
 * flag, the process environment overrides an optional `.env` file.
 */
export declare const loadConfigProvider: (envFile: Option.Option<string>) => Effect.Effect<ConfigProvider.ConfigProvider, import("effect/PlatformError").PlatformError, FileSystem.FileSystem>;
//# sourceMappingURL=ConfigProvider.d.ts.map