/**
 * INTERNAL — one implementation of ignore-file filtering for every place that
 * walks a directory and skips what an ignore file excludes.
 *
 * Two dialects, because the tools they imitate disagree:
 *
 * - `gitignore` (`.gitignore`, `.assetsignore`): a pattern without a slash
 *   matches at any depth, and nothing below an excluded directory can be
 *   re-included.
 * - `dockerignore` (`.dockerignore`, `<Dockerfile>.dockerignore`): patterns
 *   are rooted at the context, and a later `!` rule can re-include a path
 *   below an excluded directory.
 *
 * {@link walkIgnoring} lists a tree one level at a time and skips directories
 * the rules prune, so an excluded `node_modules` is never read and an
 * unreadable excluded folder never fails the walk. Directory symlinks are
 * reported as links and never followed.
 */
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
export type IgnoreDialect = "gitignore" | "dockerignore";
export interface IgnoreRules {
    readonly dialect: IgnoreDialect;
    /**
     * Whether a path is excluded. Paths are relative to the directory the
     * ignore file applies to and use `/` separators.
     */
    readonly ignores: (relativePath: string, isDirectory?: boolean) => boolean;
    /**
     * Whether a directory and everything below it is excluded, so a walk can
     * skip reading it. Conservative: `false` only costs a directory read.
     */
    readonly prunes: (relativeDirectory: string) => boolean;
}
/** Normalize to the `/`-separated, `./`-free form the matchers expect. */
export declare const normalizeRelativePath: (value: string) => string;
export interface ParseIgnoreRulesOptions {
    /**
     * gitignore only: the walk root's path relative to the directory the
     * ignore file sits in (e.g. `"packages/app"` for the repository root's
     * `.gitignore` when walking `packages/app`). Rules see full paths, but
     * only directories below the walk root can exclude their contents, so an
     * ignore file that excludes the walk root itself still lets it be listed.
     * @default ""
     */
    readonly prefix?: string;
}
/** Parse ignore-file content (or its lines) in the given dialect. */
export declare const parseIgnoreRules: (content: string | ReadonlyArray<string>, dialect: IgnoreDialect, options?: ParseIgnoreRulesOptions) => IgnoreRules;
/** Rules that exclude nothing. */
export declare const noIgnoreRules: (dialect: IgnoreDialect) => IgnoreRules;
export type WalkEntryType = "File" | "Directory" | "SymbolicLink" | "Other";
export interface WalkEntry {
    /** Path relative to the walk root, `/`-separated. */
    readonly path: string;
    readonly type: WalkEntryType;
}
export interface WalkIgnoringOptions<E, R> {
    /**
     * List one directory (relative to the walk root, `""` for the root). Each
     * child's type must describe the entry itself: a symlink is a
     * `SymbolicLink`, never its target.
     */
    readonly list: (relativeDirectory: string) => Effect.Effect<ReadonlyArray<{
        readonly name: string;
        readonly type: WalkEntryType;
    }>, E, R>;
    /** @default no rules */
    readonly rules?: IgnoreRules;
    /**
     * Paths always listed even when excluded (Docker always sends the
     * Dockerfile and its ignore file). Their parent directories are never
     * pruned.
     */
    readonly force?: ReadonlyArray<string>;
}
/**
 * List every entry under a root that the rules keep, sorted by path.
 * Directories are listed too (Docker sends empty directories). Excluded
 * directories are only read when a later rule could re-include something
 * below them; symlinked directories are listed as links and not followed.
 */
export declare const walkIgnoring: <E, R>({ list, rules, force, }: WalkIgnoringOptions<E, R>) => Effect.Effect<WalkEntry[], E, R>;
/**
 * A {@link WalkIgnoringOptions.list} over the real file system rooted at
 * `root`. Symlinks are probed before `stat`, which follows them.
 */
export declare const listFileSystemDirectory: (root: string) => Effect.Effect<(relativeDirectory: string) => Effect.Effect<({
    name: string;
    type: "SymbolicLink";
} | {
    name: string;
    type: "Directory" | "File" | "Other";
})[], import("effect/PlatformError").PlatformError, never>, never, FileSystem.FileSystem | Path.Path>;
/**
 * Combine rule sets, e.g. the `.gitignore` files from a working directory up
 * to the repository root (each parsed with its own `prefix`). A path is
 * excluded when any rule set excludes it.
 */
export declare const combineIgnoreRules: (dialect: IgnoreDialect, rules: ReadonlyArray<IgnoreRules>) => IgnoreRules;
//# sourceMappingURL=Ignore.d.ts.map