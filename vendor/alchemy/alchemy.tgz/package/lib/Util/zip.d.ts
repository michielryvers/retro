import { Buffer } from "node:buffer";
import * as Effect from "effect/Effect";
export interface ZipFile {
    path: string;
    content: string | Uint8Array<ArrayBufferLike>;
    /**
     * Unix file mode to record in the archive entry (e.g. `0o755` to keep an
     * executable bit). Omit to use the archiver's default.
     */
    mode?: number;
}
export declare const zipCode: (content: string | Uint8Array<ArrayBufferLike>, files?: readonly ZipFile[] | undefined) => Effect.Effect<Buffer<ArrayBuffer>, never, never>;
/**
 * Package `files` into a deterministic zip archive: entries are sorted by
 * path and stamped with a fixed timestamp so identical inputs always produce
 * identical bytes.
 */
export declare const zipFiles: (files: readonly ZipFile[]) => Effect.Effect<Buffer<ArrayBuffer>, never, never>;
/**
 * Expand a zip archive into its file entries. Directory entries are dropped,
 * so every returned path addresses real content.
 */
export declare const unzipFiles: (archive: Uint8Array<ArrayBufferLike>) => Effect.Effect<Record<string, Uint8Array<ArrayBufferLike>>, import("effect/Cause").UnknownError, never>;
//# sourceMappingURL=zip.d.ts.map