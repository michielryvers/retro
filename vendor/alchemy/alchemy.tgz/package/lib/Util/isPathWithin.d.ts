/**
 * Test lexical containment, including equality, using an explicit absolute base
 * for relative paths. Does not follow symlinks or consult the working directory.
 */
export declare const isPathWithin: (directory: string, candidate: string, base: string) => boolean;
//# sourceMappingURL=isPathWithin.d.ts.map