import * as Stream from "effect/Stream";
/**
 * Removing secrets from text that may echo them: API error bodies, Helm
 * stderr, command output. Secrets come from the `Redacted` values a caller
 * sent; each is matched raw, base64-encoded and JSON-escaped, since those are
 * the forms an echo usually takes.
 */
/** Marker written in place of a secret unless a caller picks another. */
export declare const DEFAULT_REDACTION_MARKER = "<redacted>";
/**
 * Plaintext strings wrapped in {@link Redacted} anywhere in `value`, including
 * strings nested inside a redacted object or array. Plain values are ignored.
 */
export declare const collectRedactedSecrets: (value: unknown) => string[];
/**
 * A marker that cannot reproduce any secret: `preferred`, unless a secret
 * appears inside it, then a private-use character absent from every secret.
 */
export declare const redactionMarker: (secrets: ReadonlyArray<string>, preferred?: string) => string;
/** Replace every form of every secret in plain text with `marker`. */
export declare const redactText: (text: string, secrets: ReadonlyArray<string>, marker?: string) => string;
/**
 * Like {@link redactText}, but a JSON document is redacted leaf by leaf, so a
 * secret that only appears JSON-escaped inside a string is still caught.
 * Text that is not JSON falls back to {@link redactText}.
 */
export declare const redactJson: (text: string, secrets: ReadonlyArray<string>, marker?: string) => string;
/**
 * Redact a text stream without leaking a secret split across chunks. Every
 * form of every secret matches as a substring; the earliest match wins, and
 * the longest form wins a tie. A match is only replaced once no form starting
 * at or before it can still grow in the next chunk, so the output does not
 * depend on where the chunks split.
 */
export declare const redactStream: <E, R>(stream: Stream.Stream<string, E, R>, secrets: ReadonlyArray<string>, marker?: string) => Stream.Stream<string, E, R>;
//# sourceMappingURL=Redaction.d.ts.map