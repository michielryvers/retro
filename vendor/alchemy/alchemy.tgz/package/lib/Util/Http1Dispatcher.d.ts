import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
/** The ambient `HttpClient`, forced onto HTTP/1.1 where `fetch` would negotiate HTTP/2. */
export declare const Http1FetchHttpClient: Layer.Layer<HttpClient.HttpClient, never, HttpClient.HttpClient>;
//# sourceMappingURL=Http1Dispatcher.d.ts.map