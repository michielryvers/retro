export * from "./Adapter.ts";
//# sourceMappingURL=index.d.ts.map