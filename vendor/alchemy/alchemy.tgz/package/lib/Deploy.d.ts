import type { ConfigError } from "effect/Config";
import * as Effect from "effect/Effect";
import type * as Scope from "effect/Scope";
import { AlchemyContext } from "./AlchemyContext.ts";
import * as Apply from "./Apply.ts";
import type { Input } from "./Input.ts";
import * as Plan from "./Plan.ts";
import type { ResourceSelection, SelectionOutput } from "./ResourceSelection.ts";
import { type CompiledStack, type StackEffect } from "./Stack.ts";
import { Stage } from "./Stage.ts";
export interface DeployOptions<A> extends Plan.MakePlanOptions {
    stack: StackEffect<CompiledStack<A>, ConfigError, Stage | AlchemyContext>;
    stage: string;
    dev?: boolean;
    /** See {@link evalStack} — when set, scoped resources outlive `deploy`. */
    scope?: Scope.Scope;
}
export type DeployResult<A> = Effect.Effect<Input.Resolve<A>, Effect.Error<ReturnType<typeof deployStack<A>>>, Effect.Services<ReturnType<typeof deployStack<A>>>>;
export interface FilteredDeployOptions<A> extends Omit<DeployOptions<A>, keyof ResourceSelection>, ResourceSelection {
}
/**
 * Reconcile a stack. Filters select nodes and their transitive dependencies,
 * not declaration evaluation: the whole stack program still runs. Filtered
 * deployments return void and leave persisted full-stack outputs unchanged.
 */
export declare function deploy<A, Options extends FilteredDeployOptions<A> = DeployOptions<A>>(options: FilteredDeployOptions<A> & Options): DeployResult<SelectionOutput<A, Options>>;
declare const deployStack: <A>({ stack, stage, dev, scope, force, include, exclude, }: FilteredDeployOptions<A>) => Effect.Effect<Input.Resolve<A> | undefined, import("./Auth/AuthProvider.ts").AuthError | ConfigError | import("./Auth/Demand.ts").CredentialsRequired | Apply.DestroyError | import("./Output.ts").InvalidReferenceError | import("./Output.ts").MissingSourceError | import("./Auth/AuthProvider.ts").NeedsReauth | import("effect/PlatformError").PlatformError | import("./State/State.ts").StateStoreError, AlchemyContext | import("./Artifacts.ts").ArtifactStore | import("effect/FileSystem").FileSystem | import("./Interaction.ts").Interaction | import("effect/Path").Path | import("./State/State.ts").State>;
export {};
//# sourceMappingURL=Deploy.d.ts.map