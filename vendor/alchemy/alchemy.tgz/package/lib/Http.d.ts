import * as Config from "effect/Config";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Etag from "effect/http/Etag";
import type { HttpBodyError } from "effect/http/HttpBody";
import * as HttpPlatform from "effect/http/HttpPlatform";
import { type HttpServerError } from "effect/http/HttpServerError";
import { HttpServerRequest } from "effect/http/HttpServerRequest";
import * as HttpServerResponse from "effect/http/HttpServerResponse";
import * as Layer from "effect/Layer";
import * as Path from "effect/Path";
import * as Scope from "effect/Scope";
export type HttpEffect<Req = never> = Effect.Effect<HttpServerResponse.HttpServerResponse, HttpServerError | HttpBodyError, HttpServerRequest | Scope.Scope | Req>;
/**
 * `effect`'s HttpEffect brands a request scope as "ejected" when ownership
 * is transferred to a consumer that outlives the handler's return — a
 * streaming response body, a WebSocket upgrade, an RPC stream. Bridges check
 * this before their close-on-return path: an ejected scope is closed by its
 * new owner when it finishes, not by the bridge.
 */
declare const scopeEjected: unique symbol;
export declare const isScopeEjected: (scope: Scope.Scope) => scope is Scope.Scope & Record<typeof scopeEjected, unknown>;
export declare const serve: <Req = never>(handler: Effect.Effect<HttpServerResponse.HttpServerResponse, HttpServerError | HttpBodyError, HttpServerRequest | Scope.Scope | Req>) => Effect.Effect<void, never, Scope.Scope | Exclude<Req, HttpServerRequest>>;
declare const HttpServer_base: Context.ServiceClass<HttpServer, "HttpServer", {
    serve: <Req = never>(handler: Effect.Effect<HttpServerResponse.HttpServerResponse, HttpServerError | HttpBodyError, Req>, options?: {
        port?: number;
    }) => Effect.Effect<void, never, Exclude<Req, HttpServerRequest> | Scope.Scope>;
}>;
export declare class HttpServer extends HttpServer_base {
}
export declare const safeHttpEffect: <Req = never>(handler: HttpEffect<Req> | Effect.Effect<HttpEffect<Req>>) => Effect.Effect<HttpServerResponse.HttpServerResponse, never, Req | HttpServerRequest | Scope.Scope>;
export declare const resolvePort: (options: {
    port?: number;
} | undefined) => Config.Config<number> | Effect.Effect<number, never, never>;
export interface BunHttpServerOptions {
    /**
     * Network interface on which the Bun HTTP server listens.
     *
     * Always passed explicitly to `Bun.serve` so container bootstraps bind a
     * predictable IPv4 wildcard regardless of the platform default
     * (`@effect/platform-bun` ≥ 4.0.0-rc.115 defaults to `::`; rc.113/114
     * crash-looped on the omitted-hostname case).
     *
     * @default "0.0.0.0"
     */
    hostname?: string;
}
export declare const BunHttpServer: (serverOptions?: BunHttpServerOptions) => Layer.Layer<HttpServer, never, never>;
export interface NodeHttpServerOptions {
    /**
     * Address the Node HTTP server binds. Fly / Hetzner / Railway machines
     * need `0.0.0.0`; omit to use that default.
     * @default "0.0.0.0"
     */
    hostname?: string;
    /**
     * Port the Node HTTP server binds when the handler is served without an
     * explicit port. Omit to read `PORT` (default `3000`).
     */
    port?: number;
}
export declare const NodeHttpServer: (serverOptions?: NodeHttpServerOptions) => Layer.Layer<HttpServer, never, never>;
/**
 * The `HttpPlatform`, `Etag`, `Path`, and no-op `FileSystem` services `HttpApiBuilder.layer`
 * wants, for runtimes without a filesystem: Workers, Lambda. File responses
 * die, compression never engages.
 *
 * Provide it to `HttpApiBuilder.layer(api)` in a Worker or a Lambda:
 *
 * ```typescript
 * HttpApiBuilder.layer(Api).pipe(
 *   Layer.provide(handlers),
 *   Layer.provide(Http.Platform),
 *   HttpRouter.toHttpEffect,
 * )
 * ```
 */
export declare const Platform: Layer.Layer<Etag.Generator | HttpPlatform.HttpPlatform | Path.Path | FileSystem.FileSystem>;
export {};
//# sourceMappingURL=Http.d.ts.map