import * as Config from "effect/Config";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import { AlchemyContext } from "../AlchemyContext.ts";
import type { ProviderService } from "../Provider.ts";
import type { ResourceLike } from "../Resource.ts";
import { Stack } from "../Stack.ts";
import type { SessionProviderCounts } from "./RpcServer.ts";
/** A test file's leases on the sessions it actually uses. */
export interface SessionOwner {
    closed: boolean;
    readonly sessions: Map<object, Effect.Effect<void>>;
}
export declare const makeSessionOwner: () => SessionOwner;
export declare const closeSessionOwner: (owner: SessionOwner) => Effect.Effect<void, never, never>;
export interface SessionCounts {
    readonly sessions: number;
    readonly testSessions: number;
    readonly owners: number;
    readonly connections: number;
}
declare const RpcProviderProxy_base: Context.ServiceClass<RpcProviderProxy, "alchemy/Local/RpcProviderProxy", {
    /**
     * The provider for `providerName`, served by the dev sidecar. `providersUrl`
     * is the URL of the module whose default export is the provider group's
     * layer (see `Local/Sidecar.ts`); the sidecar imports it on first use.
     */
    readonly get: <R extends ResourceLike>(providersUrl: string, providerName: R["Type"], owner?: SessionOwner) => Effect.Effect<ProviderService<R>, never, AlchemyContext | Stack>;
    /** Counts only; does not connect to or start the sidecar. */
    readonly diagnostics: Effect.Effect<SessionCounts>;
    /** Inspect an existing connection only; never spawn or reconnect. */
    readonly serverDiagnostics: Effect.Effect<SessionProviderCounts | undefined, unknown>;
}>;
export declare class RpcProviderProxy extends RpcProviderProxy_base {
}
export declare const SPAWNER_URL_ENV_KEY: "ALCHEMY_RPC_SPAWNER_URL";
/**
 * The one sidecar entry every RPC-backed provider is served from.
 * Resolve through package exports. The active export conditions select `src/`
 * under Bun or the dev loader and `lib/` in a published Node install.
 */
export declare const SIDECAR_ENTRY_URL: string;
export declare const layer: (url: string) => Layer.Layer<RpcProviderProxy, never, HttpClient.HttpClient>;
export declare const fromEnv: () => Layer.Layer<RpcProviderProxy, Config.ConfigError, HttpClient.HttpClient>;
export {};
//# sourceMappingURL=RpcProviderProxy.d.ts.map