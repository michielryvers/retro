import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Fiber from "effect/Fiber";
import type { HttpClient } from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import * as Scope from "effect/Scope";
import { ArtifactStore } from "../Artifacts.ts";
import type { ProviderService } from "../Provider.ts";
import type { ResourceLike } from "../Resource.ts";
import { PlatformServices } from "../Util/PlatformServices.ts";
import * as RpcSerialization from "./RpcSerialization.ts";
import * as RpcServerEnvironment from "./RpcServerEnvironment.ts";
import { type ServerRpcSession, type ServerWebSocketLike } from "./RpcServerSession.ts";
declare const RpcServer_base: Context.ServiceClass<RpcServer, "alchemy/Local/RpcServer", never>;
/**
 * A service that exposes one or more resource providers over RPC.
 * This returns `never` because it is meant to be used with `Layer.launch` (see {@link launch}).
 */
export declare class RpcServer extends RpcServer_base {
}
/**
 * The provider shape served over RPC. The `mode`/`modes` variant machinery
 * (lazy Layer-built Effects, see `ProviderLayer.dual`) is process-local and
 * cannot cross the RPC boundary — the sidecar serves the concrete provider
 * implementation, never the mode-dispatching wrapper.
 */
export type RpcProviderService<R extends ResourceLike> = Omit<ProviderService<R>, "mode" | "modes">;
/**
 * The RPC API that is implemented by the server and consumed by {@link RpcProviderProxy}.
 */
export interface RpcProxyApi {
    /**
     * Retrieves a provider from the RPC server context.
     * The consumer must unwrap the provider using {@link RpcSerialization.unwrapRpcHandlers} before using it.
     *
     * `group` names the provider group the type belongs to: for a server
     * launched with a group loader (the dev sidecar, see `Local/Sidecar.ts`)
     * it is the URL of the module whose default export is that group's
     * provider layer, imported and built on first use per session. A server
     * launched with a static layer ignores it.
     */
    readonly getProvider: <R extends ResourceLike>(type: R["Type"], group: string, testOwned?: boolean) => Promise<RpcSerialization.RpcWrapped<RpcProviderService<R>>>;
    /** Release only this connection's test-owned provider contexts. */
    readonly releaseSession: () => Promise<void>;
    /** Bounded, payload-free counts; does not build any provider contexts. */
    readonly getDiagnostics: () => Promise<SessionProviderCounts>;
}
export interface SessionProviderCounts {
    readonly sessions: number;
    readonly testSessions: number;
    readonly contexts: number;
    readonly building: number;
    readonly artifactBags: number;
    readonly artifacts: number;
}
/** The layer shape a served provider group must have. */
export type ProviderLayer = Layer.Layer<any, any, Scope.Scope | RpcServerEnvironment.RpcEnvironmentServices | PlatformServices | HttpClient | ArtifactStore>;
/**
 * Resolves a provider group to its layer. Receives the `group` the client
 * passed to {@link RpcProxyApi.getProvider}.
 */
export type ProviderGroupLoader = (group: string) => Effect.Effect<ProviderLayer, unknown>;
/** Test leases are connection-local; dev contexts remain keyed by environment. */
interface SessionLease {
    closed: boolean;
    closing?: Promise<void>;
    readonly calls: Set<Fiber.Fiber<unknown, unknown>>;
}
declare const SessionProviders_base: Context.ServiceClass<SessionProviders, "alchemy/Local/SessionProviders", {
    readonly get: (sessionEnv: string | undefined, type: string, group: string, lease?: SessionLease) => Promise<RpcSerialization.RpcWrapped<RpcProviderService<any>>>;
    readonly release: (lease: SessionLease) => Promise<void>;
    readonly diagnostics: () => SessionProviderCounts;
}>;
/** Each provider group is built with its own MemoMap and session scope. */
export declare class SessionProviders extends SessionProviders_base {
}
/**
 * Launches an RPC server that serves providers.
 * Alchemy globals such as `AlchemyContext`, `Profile`, and `Stack` are inherited from the parent via {@link RpcServerEnvironment.fromEnv} and should not be provided manually.
 * `PlatformServices` and `HttpClient` are also included.
 *
 * Pass a layer to serve a fixed set of providers, or a
 * {@link ProviderGroupLoader} to resolve the group each client names — the
 * dev sidecar (`Local/Sidecar.ts`) imports the group module on demand, so
 * one process serves every provider group without loading the ones a run
 * never touches.
 *
 * @example
 * ```ts
 * RpcServer.launch(
 *   Layer.merge(
 *     FunctionProvider,
 *     QueueProvider,
 *   ),
 * );
 * ```
 *
 * @param providers - A layer containing the providers to serve, or a loader
 *   from group to layer.
 */
export declare const launch: (providers: ProviderLayer | ProviderGroupLoader) => void;
/**
 * Constructs an `RpcServer` layer using the given server implementation.
 * @param serve - A function that spawns a websocket server and returns its URL.
 * @returns An `RpcServer` layer.
 */
export declare const layerServer: (serve: (handlers: {
    /**
     * Creates a new RPC session over the given websocket. `sessionEnv` is
     * the raw {@link SessionEnvironment} JSON from the websocket URL's
     * `SESSION_ENV_PARAM` query parameter, when the client sent one.
     */
    createRpcSession: (ws: ServerWebSocketLike, sessionEnv?: string) => ServerRpcSession<RpcProxyApi>;
    /** Called when the parent connection, indicated by the `/parent` path, is established. */
    parentConnected: () => void;
    /** Called when the parent disconnects. The server will shut down when this is called. */
    parentDisconnected: () => void;
}) => Effect.Effect<{
    readonly url: string;
}, never, Scope.Scope>) => Layer.Layer<RpcServer, import("effect/Cause").TimeoutError, SessionProviders>;
export {};
//# sourceMappingURL=RpcServer.d.ts.map