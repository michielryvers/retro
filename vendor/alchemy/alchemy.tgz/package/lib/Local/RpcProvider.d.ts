import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type { Scope } from "effect/Scope";
import { AlchemyContext } from "../AlchemyContext.ts";
import { Artifacts, ArtifactStore } from "../Artifacts.ts";
import type { Platform } from "../Platform.ts";
import * as Provider from "../Provider.ts";
import type { ResourceClassLike, ResourceLike } from "../Resource.ts";
import { ResourceContext } from "../ResourceContext.ts";
import { Stack } from "../Stack.ts";
/**
 * Constructs an RpcProvider for a given resource.
 *
 * An RpcProvider is a resource provider that can run in a separate process.
 * This is used for local development so that the resource provider and its state can outlive the user's code when it is hot-reloaded.
 * If the {@link RpcProviderProxy} is provided, the provider is run in a separate process, which we communicate with here using a websocket.
 * Otherwise, the given effect is used to construct the provider directly.
 *
 * @note If the provider is running in a separate process, you may not need to construct all of its layers in this process.
 *       You can use {@link providerServices} or {@link providerServicesEffect} to construct such layers only when they are needed.
 *
 * @example
 * ```ts
 * export const MyProvider = RpcProvider.effect(
 *   MyResource,
 *   import.meta.resolve("./my-rpc-provider-server.ts"),
 *   Effect.gen(function* () {
 *     return {
 *       diff: ...,
 *       reconcile: ...,
 *       delete: ...,
 *     }
 *   })
 * )
 * ```
 *
 * @param cls - The tag of the resource class to construct a provider for.
 * @param providersUrl - URL of the module whose default export is the provider group's layer (the layer this provider is registered in). When the provider runs in the dev sidecar, the sidecar imports that module on first use — see `Local/Sidecar.ts`. Typically `import.meta.resolve("./Local.ts")`.
 * @param eff - The Effect to use to construct the provider.
 * @returns A layer containing the RpcProvider.
 */
/**
 * The provider shape accepted by {@link effect}. It is identical to
 * {@link Provider.ProviderService} except that `list` is **optional**: local /
 * dev RPC providers frequently have no cloud enumeration API, so the factory
 * supplies a safe `() => Effect.succeed([])` default when one is not given. A
 * provider that *can* enumerate its in-memory/local runtime state (e.g.
 * `LocalWorkerProvider` enumerating its running instances) just defines `list`
 * and the factory threads it straight through.
 */
type RpcProviderService<R extends ResourceLike, ReadReq = never, DiffReq = never, PrecreateReq = never, ReconcileReq = never, DeleteReq = never, TailReq = never, LogsReq = never, ListReq = never> = Omit<Provider.ProviderService<R, ReadReq, DiffReq, PrecreateReq, ReconcileReq, DeleteReq, TailReq, LogsReq, ListReq>, "list"> & Partial<Pick<Provider.ProviderService<R, ReadReq, DiffReq, PrecreateReq, ReconcileReq, DeleteReq, TailReq, LogsReq, ListReq>, "list">>;
export declare const effect: <R extends ResourceLike, Req = never, ReadReq = never, DiffReq = never, PrecreateReq = never, ReconcileReq = never, DeleteReq = never, TailReq = never, LogsReq = never, ListReq = never>(cls: ResourceClassLike<R> | Platform<R, any, any, any, any, any>, providersUrl: string, eff: Effect.Effect<RpcProviderService<R, ReadReq, DiffReq, PrecreateReq, ReconcileReq, DeleteReq, TailReq, LogsReq, ListReq>, never, Req>) => Layer.Layer<Provider.Provider<R>, never, AlchemyContext | ArtifactStore | Stack | Exclude<DeleteReq, Artifacts | ResourceContext | import("../State/State.ts").State> | Exclude<DiffReq, Artifacts | ResourceContext | import("../State/State.ts").State> | Exclude<ListReq, Artifacts | ResourceContext | import("../State/State.ts").State> | Exclude<PrecreateReq, Artifacts | ResourceContext | import("../State/State.ts").State> | Exclude<ReadReq, Artifacts | ResourceContext | import("../State/State.ts").State> | Exclude<ReconcileReq, Artifacts | ResourceContext | import("../State/State.ts").State> | Exclude<Req, Artifacts | ResourceContext | import("../State/State.ts").State>>;
/**
 * Conditionally constructs a layer for use by an RpcProvider.
 * If the {@link RpcProviderProxy} is present in context, the layer is empty because it will not be used in this process.
 * Otherwise, the given layer is returned.
 * @param self - The layer that is used by the RpcProvider.
 * @returns A layer that is empty if the {@link RpcProviderProxy} is present in context, otherwise the given layer.
 */
export declare const providerServices: <ROut, E, RIn>(self: Layer.Layer<ROut, E, RIn>) => Layer.Layer<ROut, E, RIn | AlchemyContext>;
/**
 * Conditionally constructs a layer for use by an RpcProvider.
 * If the {@link RpcProviderProxy} is present in context, the layer is empty because it will not be used in this process.
 * Otherwise, the given layer is returned.
 *
 * Note that unlike earlier versions this is no longer gated on
 * `AlchemyContext.dev`: local providers are registered via
 * `ProviderLayer.dual` and their dependency layers are composed inside the
 * *lazily built* local variant, so in a live run these services are only
 * constructed when the local provider is actually demanded (e.g. deleting a
 * `providerMode: "local"` state row during `alchemy deploy`).
 * @param self - An effect which returns a layer that is used by the RpcProvider.
 */
export declare const providerServicesEffect: <A, E1, R1, E, R>(self: Effect.Effect<Layer.Layer<A, E1, R1>, E, R>) => Layer.Layer<A, E | E1, R1 | Exclude<R, Scope> | AlchemyContext>;
export {};
//# sourceMappingURL=RpcProvider.d.ts.map