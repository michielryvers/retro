export {};
//# sourceMappingURL=Sidecar.d.ts.map