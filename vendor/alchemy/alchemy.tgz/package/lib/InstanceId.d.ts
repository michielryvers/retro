import * as Effect from "effect/Effect";
/**
 * Generate an instance ID: a 16-byte (128-bit) random hex-encoded string that
 * identifies one physical instance of a logical resource. The running
 * resource's instance ID is available as `ResourceContext.instanceId`.
 * @returns Hex-encoded instance ID (16 random bytes)
 */
export declare const generateInstanceId: () => Effect.Effect<string, never, never>;
//# sourceMappingURL=InstanceId.d.ts.map