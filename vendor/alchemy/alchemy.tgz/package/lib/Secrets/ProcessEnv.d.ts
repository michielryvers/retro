import { type SecretsLayer, type SecretsOption } from "./Provider.ts";
export interface ProcessEnvOptions {
    /**
     * Leave the process environment out of this stack entirely. The entry
     * stays in the list but contributes nothing.
     * @default false
     */
    disabled?: boolean;
}
declare const ProcessEnvProvider_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Readonly<A> & {
    readonly _tag: "alchemy/SecretProvider::ProcessEnv";
} & import("effect/Pipeable").Pipeable;
/** A `secrets` entry that loads the process environment. */
export declare class ProcessEnvProvider extends ProcessEnvProvider_base<{
    readonly layer: SecretsLayer;
}> {
}
/**
 * The process environment as a secrets provider.
 *
 * It is implicit: every stack ends its `secrets` list with the shell, so a
 * variable exported in the terminal or by CI overrides every provider. List
 * it yourself to put it elsewhere, typically first so it becomes a fallback
 * that a secrets manager overrides, or pass `disabled: true` to leave it out:
 *
 * ```ts
 * secrets: [Secrets.ProcessEnv(), Doppler.Secrets({ project: "app", config: "prd" })]
 * secrets: [Doppler.Secrets({ project: "app", config: "prd" }), Secrets.ProcessEnv({ disabled: true })]
 * ```
 */
export declare const ProcessEnv: (options?: SecretsOption<ProcessEnvOptions>) => ProcessEnvProvider;
export {};
//# sourceMappingURL=ProcessEnv.d.ts.map