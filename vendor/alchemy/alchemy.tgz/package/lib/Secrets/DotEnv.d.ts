import { type SecretsLayer, type SecretsOption } from "./Provider.ts";
export interface DotEnvOptions {
    /**
     * File or ordered files to load. Later files override earlier files.
     * Every explicitly supplied path must exist; an empty array loads no files.
     * @default ".env"
     */
    path?: string | readonly string[];
    /**
     * Expand `${VAR}` references within the file.
     * @default false
     */
    expandVariables?: boolean;
}
declare const DotEnvProvider_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Readonly<A> & {
    readonly _tag: "alchemy/SecretProvider::DotEnv";
} & import("effect/Pipeable").Pipeable;
/** A `secrets` entry that loads dotenv files. */
export declare class DotEnvProvider extends DotEnvProvider_base<{
    readonly layer: SecretsLayer;
}> {
}
/**
 * Add dotenv files to Effect's ConfigProvider without touching `process.env`.
 *
 * Keys missing from every file fall back to the previous provider; an empty
 * value in a file is a real value and overrides it. With no explicit `path`,
 * a missing `.env` is silently ignored.
 *
 * Options may be a callback so a stack can pick files by stage:
 *
 * ```ts
 * secrets: [Secrets.DotEnv(({ stage }) => ({ path: [".env", `.env.${stage}`] }))]
 * ```
 */
export declare const DotEnv: (options?: SecretsOption<DotEnvOptions>) => DotEnvProvider;
export {};
//# sourceMappingURL=DotEnv.d.ts.map