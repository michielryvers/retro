import * as ConfigProvider from "effect/ConfigProvider";
import * as Effect from "effect/Effect";
/**
 * The variable names an env-style ConfigProvider knows, for debug logging.
 *
 * `fromEnv`/`fromDotEnv` index variables as a trie split on `_`
 * (`APP_DB_URL` lives at `["APP", "DB", "URL"]`), so the names are rebuilt
 * by walking that trie and joining the segments again. A node carrying a
 * value is a variable even when it also has children (`APP` and `APP_DB`).
 * Values are never read.
 */
export declare const envKeys: (provider: ConfigProvider.ConfigProvider) => Effect.Effect<never[] | readonly string[], never, never>;
/** `Loaded 3 secrets from <source>: A, B, C` at debug level. Names are sorted. */
export declare const logLoadedKeys: (source: string, keys: ReadonlyArray<string>) => Effect.Effect<void, never, never>;
//# sourceMappingURL=Log.d.ts.map