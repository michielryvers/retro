import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Stream from "effect/Stream";
import { AuthProviders } from "../../Auth/AuthProvider.ts";
import * as Contributions from "../../Contributions.ts";
import * as State from "../../State/index.ts";
import { type Target } from "../Session.ts";
/** Which store a state request addresses. */
export type StateSource = 
/** `.alchemy/` on this machine, ignoring whatever the project configures. */
{
    readonly _tag: "Local";
}
/** Whatever the project's entrypoint configures. */
 | ({
    readonly _tag: "Configured";
} & Target)
/** A provider's state store, without loading a project entrypoint. */
 | ({
    readonly _tag: "Provider";
    readonly backend: string;
    /** A store other than the account's default. */
    readonly name?: string;
} & Pick<Target, "profile" | "envFile">);
/** What lifecycle operations act on. */
export type ProviderSource = Extract<StateSource, {
    readonly _tag: "Provider";
}>;
/**
 * What a provider's store runs under, its layer and lifecycle alike: the
 * profile's config and an auth registry with the provider's auth.
 *
 * @internal exported for tests.
 */
export declare const providerContext: (provider: Contributions.Contributions, target: Pick<Target, "envFile" | "profile">) => Effect.Effect<Layer.Layer<AuthProviders, never, Contributions.HostServices>, Contributions.ContributionError | import("effect/PlatformError").PlatformError, import("effect/FileSystem").FileSystem>;
/**
 * Resolve the state service a source addresses, in the caller's `Scope`: the
 * store's resources live until that scope closes. The tree operations
 * (`State.listState`, `State.readState`, `State.deleteState`) take `State`
 * from context — provide the resolved service (or {@link layer}) to run
 * them against the chosen store:
 *
 * ```ts
 * const state = yield* Alchemist.State.store({ _tag: "Local" });
 * const items = yield* State.listState({ path }).pipe(
 *   Effect.provideService(State.State, Effect.succeed(state)),
 * );
 * ```
 */
export declare const store: (source: StateSource) => Effect.Effect<State.StateService, unknown, import("effect/Scope").Scope | Contributions.HostServices>;
/** The chosen store as a `State` layer. */
export declare const layer: (source: StateSource) => Layer.Layer<State.State, unknown, Contributions.HostServices>;
/** Provision (or adopt) a state store. */
export declare const bootstrap: (source: {
    readonly _tag: "Provider";
    readonly backend: string;
    /** A store other than the account's default. */
    readonly name?: string;
} & Pick<Target, "envFile" | "profile"> & {
    readonly force?: boolean;
}) => Effect.Effect<Contributions.StateStoreBootstrap, Contributions.ContributionFailure, Contributions.HostServices>;
/** Delete a state store and its backing resources. */
export declare const teardown: (source: {
    readonly _tag: "Provider";
    readonly backend: string;
    /** A store other than the account's default. */
    readonly name?: string;
} & Pick<Target, "envFile" | "profile">) => Effect.Effect<Contributions.StateStoreTeardown, Contributions.ContributionFailure, Contributions.HostServices>;
/** Past log entries from a state store, oldest first. */
export declare const logs: (source: {
    readonly _tag: "Provider";
    readonly backend: string;
    /** A store other than the account's default. */
    readonly name?: string;
} & Pick<Target, "envFile" | "profile"> & {
    readonly limit?: number;
    readonly since?: Date;
}) => Effect.Effect<readonly Contributions.StateStoreLogEntry[], Contributions.ContributionFailure, Contributions.HostServices>;
/** Live log entries from a state store. */
export declare const tailLogs: (source: ProviderSource) => Stream.Stream<Contributions.StateStoreLogEntry, Contributions.ContributionError | Contributions.ContributionFailure | import("effect/PlatformError").PlatformError, Contributions.HostServices>;
//# sourceMappingURL=state.d.ts.map