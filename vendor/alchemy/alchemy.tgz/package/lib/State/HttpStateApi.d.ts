import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as HttpApi from "effect/http-api/HttpApi";
import * as HttpApiEndpoint from "effect/http-api/HttpApiEndpoint";
import * as HttpApiError from "effect/http-api/HttpApiError";
import * as HttpApiGroup from "effect/http-api/HttpApiGroup";
import * as HttpApiMiddleware from "effect/http-api/HttpApiMiddleware";
import * as HttpApiSchema from "effect/http-api/HttpApiSchema";
import * as HttpApiSecurity from "effect/http-api/HttpApiSecurity";
import * as Layer from "effect/Layer";
import * as Schema from "effect/Schema";
import { UserFacingError } from "../UserFacingError.ts";
/**
 * Resource-state payload shape on the wire.
 *
 * Pinned to JSON encoding via {@link HttpApiSchema.asJson} so that both
 * sides of the API agree on `Content-Type: application/json`. With a
 * bare `Schema.Any` the server's payload-decoder map is keyed off the
 * default content type only — any client request that arrives with a
 * differently-shaped body (or a transport that drops the
 * `Content-Type` header entirely) falls into the `payloadBy.get(
 * contentType)` miss branch in `HttpApiBuilder.decodePayload` and
 * surfaces as a confusing `415 Unsupported Media Type`. Annotating
 * the schema makes the encoding explicit on both endpoints and the
 * client encoder, so the wire format is unambiguous.
 */
export declare const ResourceStateSchema: Schema.Any;
declare const BearerTokenValidator_base: Context.ServiceClass<BearerTokenValidator, "alchemy/State/BearerTokenValidator", {
    readonly validate: (token: string) => Effect.Effect<void, HttpApiError.Unauthorized>;
}>;
export declare class BearerTokenValidator extends BearerTokenValidator_base {
}
declare const StateAuth_base: HttpApiMiddleware.ServiceClass<StateAuth, "alchemy/State/StateAuth", {
    requires: BearerTokenValidator;
    provides: never;
    error: HttpApiSchema.asNoContent<typeof HttpApiError.Unauthorized>;
    clientError: never;
    requiredForClient: false;
    security: {
        readonly bearer: HttpApiSecurity.Http;
    };
}, HttpApiMiddleware.HttpApiMiddlewareSecurity<{
    readonly bearer: HttpApiSecurity.Http;
}, never, HttpApiSchema.asNoContent<typeof HttpApiError.Unauthorized>, BearerTokenValidator>>;
export declare class StateAuth extends StateAuth_base {
}
export declare const StateAuthLive: Layer.Layer<StateAuth, never, BearerTokenValidator>;
declare const StateStoreFailure_base: Schema.Class<StateStoreFailure, Schema.TaggedStruct<"StateStoreFailure", {
    readonly operation: Schema.String;
    readonly reason: Schema.String;
}>, import("effect/Cause").YieldableError>;
/**
 * The store failed to serve a request: which operation, and the kind of
 * failure (its tag). Never the failure's message, which can carry state; the
 * Worker logs the full cause. Without it, any failure behind the auth
 * middleware was encoded as its `Unauthorized` and surfaced as a bare 500.
 */
export declare class StateStoreFailure extends StateStoreFailure_base {
    readonly [UserFacingError] = true;
    get message(): string;
}
export declare const ListStacks: HttpApiEndpoint.HttpApiEndpoint<"listStacks", "GET", "/state/stacks", never, never, never, never, Schema.toCodecJson<Schema.$Array<Schema.String>>, Schema.toCodecJson<typeof StateStoreFailure>, never, never>;
export declare const ListStages: HttpApiEndpoint.HttpApiEndpoint<"listStages", "GET", "/state/stacks/:stack/stages", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.$Array<Schema.String>>, Schema.toCodecJson<typeof StateStoreFailure>, never, never>;
export declare const ListResources: HttpApiEndpoint.HttpApiEndpoint<"listResources", "GET", "/state/stacks/:stack/stages/:stage/resources", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.$Array<Schema.String>>, Schema.toCodecJson<typeof StateStoreFailure>, never, never>;
export declare const GetState: HttpApiEndpoint.HttpApiEndpoint<"getState", "GET", "/state/stacks/:stack/stages/:stage/resources/:fqn", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
    readonly fqn: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.UndefinedOr<Schema.Any>>, Schema.toCodecJson<typeof StateStoreFailure>, never, never>;
export declare const SetState: HttpApiEndpoint.HttpApiEndpoint<"setState", "PUT", "/state/stacks/:stack/stages/:stage/resources/:fqn", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
    readonly fqn: Schema.String;
}>>, never, Schema.toCodecJson<Schema.Any>, never, Schema.toCodecJson<Schema.Any>, Schema.toCodecJson<typeof StateStoreFailure>, never, never>;
export declare const DeleteState: HttpApiEndpoint.HttpApiEndpoint<"deleteState", "DELETE", "/state/stacks/:stack/stages/:stage/resources/:fqn", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
    readonly fqn: Schema.String;
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof StateStoreFailure>, never, never>;
export declare const DeleteStack: HttpApiEndpoint.HttpApiEndpoint<"deleteStack", "DELETE", "/state/stacks/:stack", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly stage: Schema.optional<Schema.String>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof StateStoreFailure>, never, never>;
export declare const GetReplacedResources: HttpApiEndpoint.HttpApiEndpoint<"getReplacedResources", "GET", "/state/stacks/:stack/stages/:stage/replaced-resources", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.$Array<Schema.Any>>, Schema.toCodecJson<typeof StateStoreFailure>, never, never>;
export declare const GetStackOutput: HttpApiEndpoint.HttpApiEndpoint<"getStackOutput", "GET", "/state/stacks/:stack/stages/:stage/output", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.UndefinedOr<Schema.Any>>, Schema.toCodecJson<typeof StateStoreFailure>, never, never>;
export declare const SetStackOutput: HttpApiEndpoint.HttpApiEndpoint<"setStackOutput", "PUT", "/state/stacks/:stack/stages/:stage/output", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
}>>, never, Schema.toCodecJson<Schema.Any>, never, Schema.toCodecJson<Schema.Any>, Schema.toCodecJson<typeof StateStoreFailure>, never, never>;
/**
 * Version of the State Store wire / behavioural contract.
 *
 * Bump this whenever the wire format or runtime behaviour of an HTTP
 * state-store changes in a way that an older deployed copy can no
 * longer satisfy. Clients query `/version` on the deployed worker and
 * compare against this constant; a mismatch (or 404) triggers a
 * forced redeploy via the bootstrap flow.
 */
export declare const STATE_STORE_VERSION: 5;
/** Response shape for the unauthenticated `/version` probe. */
export declare const VersionResponse: Schema.Struct<{
    readonly version: Schema.Number;
}>;
/**
 * Unauthenticated probe so clients can detect a stale (or absent)
 * deployed worker without holding a valid bearer token. The returned
 * version is bumped whenever the wire / behavioural contract changes
 * in a way that requires a redeploy.
 */
export declare const GetVersion: HttpApiEndpoint.HttpApiEndpoint<"getVersion", "GET", "/version", never, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly version: Schema.Number;
}>>, never, never, never>;
declare const StateGroup_base: HttpApiGroup.HttpApiGroup<"state", HttpApiEndpoint.HttpApiEndpoint<"deleteStack", "DELETE", "/state/stacks/:stack", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly stage: Schema.optional<Schema.String>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof StateStoreFailure>, StateAuth, BearerTokenValidator> | HttpApiEndpoint.HttpApiEndpoint<"deleteState", "DELETE", "/state/stacks/:stack/stages/:stage/resources/:fqn", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
    readonly fqn: Schema.String;
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof StateStoreFailure>, StateAuth, BearerTokenValidator> | HttpApiEndpoint.HttpApiEndpoint<"getReplacedResources", "GET", "/state/stacks/:stack/stages/:stage/replaced-resources", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.$Array<Schema.Any>>, Schema.toCodecJson<typeof StateStoreFailure>, StateAuth, BearerTokenValidator> | HttpApiEndpoint.HttpApiEndpoint<"getStackOutput", "GET", "/state/stacks/:stack/stages/:stage/output", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.UndefinedOr<Schema.Any>>, Schema.toCodecJson<typeof StateStoreFailure>, StateAuth, BearerTokenValidator> | HttpApiEndpoint.HttpApiEndpoint<"getState", "GET", "/state/stacks/:stack/stages/:stage/resources/:fqn", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
    readonly fqn: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.UndefinedOr<Schema.Any>>, Schema.toCodecJson<typeof StateStoreFailure>, StateAuth, BearerTokenValidator> | HttpApiEndpoint.HttpApiEndpoint<"listResources", "GET", "/state/stacks/:stack/stages/:stage/resources", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.$Array<Schema.String>>, Schema.toCodecJson<typeof StateStoreFailure>, StateAuth, BearerTokenValidator> | HttpApiEndpoint.HttpApiEndpoint<"listStacks", "GET", "/state/stacks", never, never, never, never, Schema.toCodecJson<Schema.$Array<Schema.String>>, Schema.toCodecJson<typeof StateStoreFailure>, StateAuth, BearerTokenValidator> | HttpApiEndpoint.HttpApiEndpoint<"listStages", "GET", "/state/stacks/:stack/stages", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.$Array<Schema.String>>, Schema.toCodecJson<typeof StateStoreFailure>, StateAuth, BearerTokenValidator> | HttpApiEndpoint.HttpApiEndpoint<"setStackOutput", "PUT", "/state/stacks/:stack/stages/:stage/output", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
}>>, never, Schema.toCodecJson<Schema.Any>, never, Schema.toCodecJson<Schema.Any>, Schema.toCodecJson<typeof StateStoreFailure>, StateAuth, BearerTokenValidator> | HttpApiEndpoint.HttpApiEndpoint<"setState", "PUT", "/state/stacks/:stack/stages/:stage/resources/:fqn", Schema.toCodecStringTree<Schema.Struct<{
    readonly stack: Schema.String;
    readonly stage: Schema.String;
    readonly fqn: Schema.String;
}>>, never, Schema.toCodecJson<Schema.Any>, never, Schema.toCodecJson<Schema.Any>, Schema.toCodecJson<typeof StateStoreFailure>, StateAuth, BearerTokenValidator>, false>;
export declare class StateGroup extends StateGroup_base {
}
declare const VersionGroup_base: HttpApiGroup.HttpApiGroup<"version", HttpApiEndpoint.HttpApiEndpoint<"getVersion", "GET", "/version", never, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly version: Schema.Number;
}>>, never, never, never>, false>;
export declare class VersionGroup extends VersionGroup_base {
}
declare const StateApi_base: HttpApi.HttpApi<"alchemy-state", typeof StateGroup | typeof VersionGroup>;
export declare class StateApi extends StateApi_base {
}
export {};
//# sourceMappingURL=HttpStateApi.d.ts.map