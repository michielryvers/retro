import * as Config from "effect/Config";
import * as Effect from "effect/Effect";
import { StateStoreError } from "./State.ts";
/** A logical store name; stores derive physical names from it. */
export declare const storeName: (name: string) => Effect.Effect<string, never, never> | Effect.Effect<never, StateStoreError, never>;
export interface StoreRef {
    readonly backend: string;
    readonly name?: string;
    /** e.g. `Cloudflare State Store 'alchemy-state-store'`. */
    readonly label: string;
}
/** Deploy a missing (or half-bootstrapped) store; in CI, only with `--yes`. */
export declare const deployMissing: <A, E, R>(store: StoreRef & {
    readonly incomplete?: boolean;
}, deploy: Effect.Effect<A, E, R>) => Effect.Effect<A, E | Config.ConfigError | StateStoreError, R>;
/** Upgrade an outdated store with `--yes` or on confirmation; in CI, only with `--yes`. */
export declare const upgradeOutdated: <A, E, R>(store: StoreRef & {
    readonly observed: number | undefined;
    readonly expected: number;
}, upgrade: Effect.Effect<A, E, R>) => Effect.Effect<A, E | Config.ConfigError | StateStoreError, R>;
//# sourceMappingURL=Provisioning.d.ts.map