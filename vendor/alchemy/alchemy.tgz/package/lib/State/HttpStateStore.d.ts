import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import * as HttpClientError from "effect/http/HttpClientError";
import * as HttpClientRequest from "effect/http/HttpClientRequest";
import * as Schema from "effect/Schema";
import { StateStoreFailure } from "./HttpStateApi.ts";
import { type StateService } from "./State.ts";
/**
 * Persisted shape of an HTTP state store endpoint — `{ url, authToken }`.
 * Stored in the credentials file alongside other per-profile secrets.
 * Deliberately separate from {@link HttpStateStoreProps}: `id` and
 * `transformClient` are deployment-time choices, not credentials.
 */
export interface HttpStateStoreCredentials {
    url: string;
    /** Bearer token used to authenticate every request. */
    authToken: string;
}
export interface HttpStateStoreProps extends HttpStateStoreCredentials {
    /**
     * `StateService.id` slug for telemetry — e.g. `"http"` for a bare
     * HTTP store, `"cloudflare-http"` for the Cloudflare-deployed
     * variant. Required so every concrete deployment of this state-store
     * shape shows up distinctly on the adoption dashboard.
     */
    id: string;
    transformClient?: (client: HttpClientRequest.HttpClientRequest) => HttpClientRequest.HttpClientRequest;
}
export declare const checkHttpStateStoreAuth: ({ url, authToken }: {
    url: string;
    authToken: string;
}) => Effect.Effect<boolean, HttpClientError.HttpClientError | Schema.SchemaError | StateStoreFailure, HttpClient.HttpClient>;
export declare const makeHttpStateStore: ({ url, authToken, transformClient, id }: HttpStateStoreProps) => Effect.Effect<StateService, never, HttpClient.HttpClient>;
/**
 * Describe a state-store failure using only its known kind and HTTP status.
 * Client/decoder messages and causes can contain serialized state, including
 * secrets unwrapped by encodeState, so they must not become diagnostics.
 */
export declare const describeStateStoreFailure: (e: unknown, profileCommand?: string) => string;
//# sourceMappingURL=HttpStateStore.d.ts.map