import * as Effect from "effect/Effect";
import * as Scope from "effect/Scope";
import { StateStoreError, type StateService } from "./State.ts";
/** A write condition, in terms of the backend's version token. */
export type WriteCondition = 
/** Only create the object; fail if it exists. */
{
    readonly ifAbsent: true;
}
/** Only overwrite the object at exactly this version. */
 | {
    readonly ifVersion: string;
};
/**
 * The object operations a bucket backend implements. Every operation is
 * self-contained (`R = never`) and fails with {@link StateStoreError}.
 */
export interface BucketObjects {
    /** Every key under `prefix`, across pagination. */
    readonly listKeys: (prefix: string) => Effect.Effect<ReadonlyArray<string>, StateStoreError>;
    /**
     * The immediate "directory" names under `prefix` (delimiter `/`), without
     * the prefix or the trailing slash.
     */
    readonly listChildren: (prefix: string) => Effect.Effect<ReadonlyArray<string>, StateStoreError>;
    /** An object's text and version, or `undefined` when it doesn't exist. */
    readonly read: (key: string) => Effect.Effect<{
        readonly text: string;
        readonly version: string;
    } | undefined, StateStoreError>;
    /**
     * Write an object. Returns its new version, or `undefined` when
     * `condition` did not hold.
     */
    readonly write: (key: string, body: string, condition?: WriteCondition) => Effect.Effect<string | undefined, StateStoreError>;
    /**
     * Delete an object, only at `ifVersion` when given. Deleting a missing
     * object, or one at another version, succeeds without deleting.
     */
    readonly delete: (key: string, ifVersion?: string) => Effect.Effect<void, StateStoreError>;
    /** Delete many objects. Missing objects are ignored. */
    readonly deleteMany: (keys: ReadonlyArray<string>) => Effect.Effect<void, StateStoreError>;
}
export interface BucketStateOptions {
    /** The store's id, e.g. `"s3"` or `"gcs"`. */
    readonly id: string;
    /** How errors name the store, e.g. `"S3"` or `"Cloud Storage"`. */
    readonly label: string;
    /** Key prefix within the bucket. A trailing `/` is added. */
    readonly prefix?: string;
    /**
     * The bucket's objects. Runs once, on the first state operation, and is
     * cached: ensure the bucket exists here, never at construction.
     */
    readonly objects: Effect.Effect<BucketObjects, StateStoreError>;
}
/**
 * Construct a bucket-backed {@link StateService}. Leases are bound to the
 * ambient scope; callers that need them to outlive the first operation
 * bind this effect to a longer scope with `Scope.provide`.
 */
export declare const makeBucketState: (options: BucketStateOptions) => Effect.Effect<StateService, never, Scope.Scope>;
//# sourceMappingURL=BucketState.d.ts.map