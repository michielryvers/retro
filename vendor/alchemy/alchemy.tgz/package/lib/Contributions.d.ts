import type * as Command from "effect/cli/Command";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import type { HttpClient } from "effect/http/HttpClient";
import type * as HttpClientRequest from "effect/http/HttpClientRequest";
import type * as Layer from "effect/Layer";
import * as Path from "effect/Path";
import type * as Stream from "effect/Stream";
import type { AlchemyContext } from "./AlchemyContext.ts";
import type { ArtifactStore } from "./Artifacts.ts";
import type { AuthProviders } from "./Auth/AuthProvider.ts";
import type { CredentialsStore } from "./Auth/Credentials.ts";
import type { ProfileStore } from "./Auth/Profile.ts";
import type { CliKit } from "./Cli/CliKit/CliKit.ts";
import type { Interaction } from "./Interaction.ts";
import type { State } from "./State/State.ts";
import { UserFacingError } from "./UserFacingError.ts";
import type { PlatformServices } from "./Util/PlatformServices.ts";
/**
 * What a provider contributes to Alchemy outside a stack: the parts the CLI,
 * the Alchemist API and the test harness need before (or without) importing
 * the user's `alchemy.run.ts`.
 *
 * A contributions module is imported on every CLI start, so it holds
 * metadata and lazy `import()`s only; the provider's code loads when a field
 * is used.
 *
 * A package declares what it contributes in `package.json`:
 *
 * ```json
 * { "alchemy": { "contributes": ["@alchemy.run/aws/Contributions"] } }
 * ```
 *
 * {@link load} reads that field from `alchemy` itself and from the project's
 * dependencies.
 */
export interface Contributions {
    /** Unique across loaded providers, e.g. `"aws"`. */
    readonly name: string;
    /**
     * Registers the provider's `AuthProvider` into `AuthProviders`, so
     * `alchemy profile` and login work without a stack that uses the provider.
     */
    readonly auth?: Lazy<Layer.Layer<never, never, ContributionServices>>;
    /**
     * The provider's state stores by `--backend` name, e.g. `{ aws: ... }`,
     * each reachable from a profile alone as `alchemy state --backend <name>`.
     * Names are global: two providers contributing one name is an error.
     */
    readonly stateStores?: Readonly<Record<string, StateStore>>;
    /** CLI commands the provider adds. */
    readonly cli?: Cli;
    /**
     * Services the test harness runs tests under when `ALCHEMY_TEST_DEV` is
     * set, e.g. a local emulator for the provider's SDK clients.
     */
    readonly testServices?: Lazy<TestServices>;
    /**
     * Environment variables `alchemy dev` sets on itself before it starts, so
     * its sidecars and the processes they launch inherit them, e.g. a local
     * emulator's CA bundle. A variable that is already set wins.
     */
    readonly devEnv?: Lazy<Effect.Effect<Readonly<Record<string, string>>, never, FileSystem.FileSystem | Path.Path>>;
}
/**
 * The services every host of provider code provides: the CLI and the Alchemist
 * API both run it under them. A provider supplies anything else it needs
 * itself, so a field can never require a service no host provides.
 */
export type HostServices = PlatformServices | HttpClient | AlchemyContext | ProfileStore | CredentialsStore | ArtifactStore | Interaction;
/** What auth layers and state stores run under: the host's services and the auth registry. */
export type ContributionServices = HostServices | AuthProviders;
/** What a CLI command runs under: the host's services and the terminal. */
export type CliServices = HostServices | CliKit;
/** A provider's own failure: any tagged error with a message for the user. */
export type ContributionFailure = {
    readonly _tag: string;
    readonly message: string;
};
/**
 * A field loaded when used, so importing a provider module stays cheap. Build
 * one with {@link lazy}.
 */
export type Lazy<A> = Effect.Effect<A, ContributionError>;
/**
 * A {@link Lazy} field from a module of the provider's, imported on first
 * use:
 *
 * ```ts
 * auth: Contributions.lazy(() => import("./AuthProvider.ts"), (module) => module.AwsAuth),
 * ```
 */
export declare const lazy: <M, A>(load: () => Promise<M>, pick: (module: M) => A) => Lazy<A>;
export interface StateStore {
    /** Shown when listing stores; no provider code loads to show it. */
    readonly description: string;
    /** The store itself, loaded when it's used. */
    readonly load: Lazy<StateStoreImpl>;
}
export interface StateStoreImpl {
    /** The store's `State` layer: the provider's own `state` function. */
    readonly layer: (options: StateStoreOptions) => Layer.Layer<State, ContributionFailure, ContributionServices>;
    /** Provisioning, teardown and logs, for the operations the store supports. */
    readonly lifecycle?: StateStoreLifecycle;
}
/** The options every state store's `state(...)` takes. */
export interface StateStoreOptions {
    /** A store other than the account's default, by logical name. */
    readonly name?: string;
}
/** Which store a lifecycle operation acts on, under the profile core resolved. */
export interface StateStoreTarget {
    /** A store other than the account's default, by logical name. */
    readonly name?: string;
}
export interface StateStoreLifecycle {
    /** Provision the store, or adopt it when it exists. Idempotent. */
    readonly bootstrap?: (input: StateStoreTarget & {
        /** Redeploy an existing store instead of adopting it. */
        readonly force?: boolean;
    }) => Effect.Effect<StateStoreBootstrap, ContributionFailure, ContributionServices>;
    /** Delete the store and its backing resources. Idempotent. */
    readonly teardown?: (input: StateStoreTarget) => Effect.Effect<StateStoreTeardown, ContributionFailure, ContributionServices>;
    /** The store's past log entries, oldest first. */
    readonly logs?: (input: StateStoreTarget & {
        readonly limit?: number;
        readonly since?: Date;
    }) => Effect.Effect<ReadonlyArray<StateStoreLogEntry>, ContributionFailure, ContributionServices>;
    /** The store's log entries as they happen. */
    readonly tailLogs?: (input: StateStoreTarget) => Stream.Stream<StateStoreLogEntry, ContributionFailure, ContributionServices>;
}
export interface StateStoreBootstrap {
    readonly status: "created" | "adopted" | "redeployed";
    /** The store's physical name: its Worker, its bucket. */
    readonly store: string;
    /** Where it lives, e.g. `{ account: "…", region: "us-east-1" }`. */
    readonly location: Readonly<Record<string, string>>;
}
export interface StateStoreTeardown {
    /** What was deleted, by physical name. */
    readonly deleted: ReadonlyArray<string>;
}
export interface StateStoreLogEntry {
    readonly timestamp: Date;
    readonly message: string;
}
export interface Cli {
    /**
     * The `alchemy provider <provider name>` subcommand. Its description lists it
     * in help; the command itself loads only when it runs.
     */
    readonly provider?: {
        readonly description: string;
        readonly load: Lazy<AnyCommand>;
    };
}
export type AnyCommand = Command.Command<any, any, any, ContributionFailure, CliServices>;
export interface TestServices {
    /** Provided to test bodies and stack programs, closest wins. */
    readonly layer: Layer.Layer<any, ContributionFailure, never>;
    /** Rewrites the test's outbound HTTP, e.g. onto the emulator's gateway. */
    readonly mapRequest?: (request: HttpClientRequest.HttpClientRequest) => HttpClientRequest.HttpClientRequest;
    /** Set on the test process before anything forks, unless already set. */
    readonly env?: Readonly<Record<string, string>>;
}
/** Declare a provider; the identity function, keeping its literal type. */
export declare const make: <const P extends Contributions>(provider: P) => P;
declare const ContributionError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ContributionError";
} & Readonly<A>;
export declare class ContributionError extends ContributionError_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
    readonly [UserFacingError] = true;
}
/** `--backend` names alchemy handles itself, so no provider may take them. */
export declare const RESERVED_BACKENDS: ReadonlyArray<string>;
/** The providers reachable from the project in `cwd`, loaded once per process. */
export declare const load: (cwd?: string | undefined) => Effect.Effect<readonly Contributions[], ContributionError, FileSystem.FileSystem | Path.Path>;
/** The environment every provider contributes to `alchemy dev` (see {@link Contributions.devEnv}). */
export declare const devEnv: () => Effect.Effect<Record<string, string>, ContributionError, FileSystem.FileSystem | Path.Path>;
/** Every provider's state stores, by `--backend` name, with their provider. */
export declare const stateStores: () => Effect.Effect<Map<string, {
    readonly provider: Contributions;
    readonly store: StateStore;
}>, ContributionError, FileSystem.FileSystem | Path.Path>;
/** Load one lazy field, failing with a {@link ContributionError} naming the provider. */
export declare const resolve: <A>(provider: Contributions, field: string, value: Lazy<A>) => Effect.Effect<A, ContributionError, never>;
export {};
//# sourceMappingURL=Contributions.d.ts.map