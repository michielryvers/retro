import * as Command from "effect/cli/Command";
export declare const compatibilityCommands: {
    readonly login: "alchemy profile";
    readonly tail: "alchemy logs --tail";
    readonly sync: "alchemy drift --repair";
    readonly aws: "alchemy provider aws";
    readonly cloudflare: "alchemy provider cloudflare";
    readonly prisma: "alchemy provider prisma";
};
export type CompatibilityCommand = keyof typeof compatibilityCommands;
/**
 * An unlisted command that only points at its replacement and exits 1, so a
 * script still invoking the old command fails loudly instead of silently
 * doing nothing.
 */
export declare const movedCommand: (name: string, path: string, replacement: string) => Command.Command<string, {}, {}, never, never>;
export declare const compatibilityCommand: (name: CompatibilityCommand) => Command.Command<string, {}, {}, never, never>;
//# sourceMappingURL=compat.d.ts.map