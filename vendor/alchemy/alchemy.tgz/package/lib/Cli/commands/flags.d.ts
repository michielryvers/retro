import * as Argument from "effect/cli/Argument";
import * as Flag from "effect/cli/Flag";
import * as Config from "effect/Config";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Option from "effect/Option";
import { UserInputError } from "./errors.ts";
export declare const USER: Config.Config<string>;
/**
 * `live_$USER`, `dev_$USER`, or `test_$USER` (falls back to `*_unknown`).
 * Characters a stage can't hold (`first.last`, `John Smith`) become `-`, so
 * the default always passes the `--stage` pattern and works in physical names.
 */
export declare const userStage: (kind: "live" | "dev" | "test") => Effect.Effect<string, never, never>;
export declare const ALCHEMY_STAGE: Effect.Effect<string | undefined, Config.ConfigError, never>;
/** `--stage` for deploy / destroy / plan / logs / drift. Default: `live_$USER`. */
export declare const stage: Flag.Flag<string | undefined>;
/** `--stage` for `alchemy dev`. Default: `dev_$USER`. */
export declare const devStage: Flag.Flag<string | undefined>;
/**
 * Resolve the target stage after the command's dotenv provider is known.
 * `--stage` wins; otherwise `$ALCHEMY_STAGE` from process env / `--env-file`
 * / `.env`; otherwise `live_$USER` or `dev_$USER`.
 *
 * `$STAGE` is not consulted. Use `$ALCHEMY_STAGE` so stage selection
 * matches `$ALCHEMY_PROFILE`.
 */
export declare const resolveStage: (kind: "dev" | "live", override: string | undefined, envFile: Option.Option<string>) => Effect.Effect<string, import("effect/PlatformError").PlatformError | UserInputError, FileSystem.FileSystem>;
export declare const envFile: Flag.Flag<Option.Option<string>>;
export declare const dryRun: Flag.Flag<boolean>;
export declare const yes: Flag.Flag<boolean>;
export declare const force: Flag.Flag<boolean>;
export declare const include: Flag.Flag<readonly string[] | undefined>;
export declare const exclude: Flag.Flag<readonly string[] | undefined>;
export declare const validateSelectionOptions: (options: {
    readonly include?: ReadonlyArray<string>;
    readonly exclude?: ReadonlyArray<string>;
    readonly destroy?: boolean;
    readonly detectDrift?: boolean;
}) => Effect.Effect<void, never, never> | Effect.Effect<never, UserInputError, never>;
export declare const config: Flag.Flag<string>;
export declare const optionalConfig: Flag.Flag<string | undefined>;
export declare const configPath: Argument.Argument<string | undefined>;
export declare const resolveConfig: <A extends {
    readonly config: string | undefined;
    readonly configPath: string | undefined;
}>(args: A) => Effect.Effect<A & {
    main: string;
}, UserInputError, never>;
export declare const resolveStackArgs: (kind: "live" | "dev") => <A extends {
    readonly config: string | undefined;
    readonly configPath: string | undefined;
    readonly stage: string | undefined;
    readonly envFile: Option.Option<string>;
}>(args: A) => Effect.Effect<A & {
    main: string;
    stage: string;
}, import("effect/PlatformError").PlatformError | UserInputError, FileSystem.FileSystem>;
export declare const profile: Flag.Flag<string | undefined>;
export declare const parseSince: (value: string) => Effect.Effect<Date, UserInputError, never>;
//# sourceMappingURL=flags.d.ts.map