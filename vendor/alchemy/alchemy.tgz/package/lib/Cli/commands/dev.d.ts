import * as Command from "effect/cli/Command";
import * as Option from "effect/Option";
import * as Schema from "effect/Schema";
/**
 * Trust the Floci emulator CA in `alchemy dev` so cross-cloud data planes
 * terminated by the emulator's self-signed cert (e.g. an AWS Lambda MicroVM
 * bound to a local Cloudflare Worker) are reachable from local workerd. workerd
 * reads its trusted certificates from `NODE_EXTRA_CA_CERTS` at runtime init, so
 * this must be present in the env of every spawned child (the exec worker, the
 * RPC sidecar, and the workerd instances they start). `ensureFloci` refreshes
 * the bundle at this stable path (and sets the variable itself once written);
 * never clobber a value the caller set, and don't point at a missing file —
 * Node/Bun warn about it on every startup.
 */
export declare const devCommand: Command.Command<"dev", {
    readonly force: boolean;
    readonly include: readonly string[] | undefined;
    readonly exclude: readonly string[] | undefined;
    readonly config: string | undefined;
    readonly configPath: string | undefined;
    readonly envFile: Option.Option<string>;
    readonly stage: string | undefined;
    readonly profile: string | undefined;
}, {}, import("effect/PlatformError").PlatformError | Schema.SchemaError | import("effect/http/HttpServerError").ServeError | import("../../Alchemist/Entrypoint.ts").StackEntrypointError | import("./errors.ts").UserInputError, import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("effect/FileSystem").FileSystem | import("effect/Path").Path>;
//# sourceMappingURL=dev.d.ts.map