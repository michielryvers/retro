import { Command } from "effect/cli";
import * as Contributions from "../../Contributions.ts";
/**
 * `alchemy provider`: `check-env` plus each provider's provider subcommand. A
 * provider whose CLI fails to load never blocks another's: it runs as a
 * command failing with its error.
 */
export declare const providerCommand: (providers: ReadonlyArray<Contributions.Contributions>) => Promise<Command.Command<"provider", {} | {}, {}, import("../../Alchemist/Errors.ts").AlchemistInvalidInput | import("../../Auth/AuthProvider.ts").AuthError | Contributions.ContributionError | Contributions.ContributionFailure | import("effect/PlatformError").PlatformError | import("../../Auth/Profile.ts").ProfileError, import("effect/Scope").Scope | Contributions.CliServices>>;
//# sourceMappingURL=provider.d.ts.map