import { Command } from "effect/cli";
import * as Option from "effect/Option";
import * as CliKit from "../../Cli/CliKit/index.ts";
export declare const stateCommand: Command.Command<"state", {
    readonly main: string;
    readonly envFile: Option.Option<string>;
    readonly profile: string | undefined;
    readonly backend: string;
    readonly name: string | undefined;
} | {}, {}, unknown, CliKit.CliKit | import("effect/Scope").Scope | import("../../Contributions.ts").HostServices>;
//# sourceMappingURL=state.d.ts.map