/** @jsxRuntime automatic */
/** @jsxImportSource @alchemy.run/sigil */
import { Box as SigilBox, type DOMElement } from "@alchemy.run/sigil";
import type { ComponentProps, ForwardRefExoticComponent, PropsWithoutRef, ReactNode, RefAttributes } from "react";
export { VirtualList } from "@alchemy.run/sigil";
export type BoxProps = ComponentProps<typeof SigilBox>;
/** Theme-aware Sigil container used by CliKit layouts. */
export declare const Box: ForwardRefExoticComponent<PropsWithoutRef<BoxProps> & RefAttributes<DOMElement>>;
export interface StackProps extends Omit<BoxProps, "flexDirection"> {
    readonly gap?: number;
}
/** Vertical layout primitive. */
export declare function Stack({ children, gap, ...props }: StackProps): import("react").JSX.Element;
export interface RowProps extends Omit<BoxProps, "flexDirection" | "alignItems" | "justifyContent"> {
    readonly gap?: number;
    readonly align?: "flex-start" | "center" | "flex-end";
    readonly justify?: "flex-start" | "center" | "flex-end" | "space-between" | "space-around";
}
/** Horizontal layout primitive. */
export declare function Row({ children, gap, align, justify, ...props }: RowProps): import("react").JSX.Element;
type HeadingProps = {
    readonly children?: ReactNode;
    /** Set false to drop the section glyph prefix (e.g. help-screen headings). */
    readonly glyph?: boolean;
};
export declare function Heading({ children, glyph }: HeadingProps): import("react").JSX.Element;
type SectionHeadingProps = {
    readonly children?: ReactNode;
    readonly annotation?: ReactNode;
};
export declare function SectionHeading({ children, annotation }: SectionHeadingProps): import("react").JSX.Element;
type GutterProps = {
    readonly depth?: number;
    readonly children?: ReactNode;
};
export declare function Gutter({ depth, children }: GutterProps): import("react").JSX.Element;
/**
 * The centering clamp shared by every windowed list: a window of `count` rows
 * over `length` items keeping `cursor` as close to the middle as the list
 * bounds allow.
 */
export declare const listWindow: (length: number, cursor: number, count: number) => {
    readonly start: number;
    readonly end: number;
};
/**
 * Horizontal window over variable-width items (tab chips): expands around
 * `active` — alternating right/left so the selection stays roughly centered —
 * until `available` columns are exhausted. Returns `[start, end)` like
 * {@link listWindow}; `active` is always inside the window.
 */
export declare const tabsWindow: (widths: ReadonlyArray<number>, active: number, available: number, gap?: number) => {
    readonly start: number;
    readonly end: number;
};
/**
 * Window for prompt lists that render "↑ N more"/"↓ N more" indicator rows:
 * reserves two of `visibleCount`'s rows for the indicators when overflowing so
 * the widget stays within the requested height.
 */
export declare const overflowListWindow: (length: number, cursor: number, visibleCount: number) => {
    readonly start: number;
    readonly end: number;
};
/** Windowed list keeping `cursor` centered; each item renders as a block. */
type ViewportProps<Item> = {
    readonly items: ReadonlyArray<Item>;
    readonly cursor?: number;
    readonly height: number;
    readonly renderItem: (item: Item, index: number) => ReactNode;
    readonly getKey: (item: Item, index: number) => string;
    readonly empty?: ReactNode;
};
export declare function Viewport<Item>({ items, cursor, height, renderItem, getKey, empty, }: ViewportProps<Item>): import("react").JSX.Element;
//# sourceMappingURL=Layout.d.ts.map