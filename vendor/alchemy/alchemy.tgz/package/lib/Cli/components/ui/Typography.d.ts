/** @jsxRuntime automatic */
/** @jsxImportSource @alchemy.run/sigil */
import { Text as SigilText } from "@alchemy.run/sigil";
import type { ComponentProps } from "react";
export type TextTone = "default" | "muted" | "emphasis" | "brand" | "accent" | "info" | "success" | "warning" | "danger";
export interface TextProps extends Omit<ComponentProps<typeof SigilText>, "color"> {
    readonly tone?: TextTone;
    readonly color?: ComponentProps<typeof SigilText>["color"];
}
/** CliKit typography primitive. Consumers never import Sigil directly. */
export declare function Text({ tone, color, backgroundColor, bold, dimColor, italic, underline, strikethrough, inverse, ...props }: TextProps): import("react").JSX.Element;
type LinkProps = {
    readonly href: string;
    readonly children?: string;
};
export declare function Link({ href, children }: LinkProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Typography.d.ts.map