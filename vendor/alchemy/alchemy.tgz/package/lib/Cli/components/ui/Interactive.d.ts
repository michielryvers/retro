import type { JSX, ReactNode } from "react";
import type { AwaitExternalOptions, Choice, CycleChoice } from "../types.ts";
export interface TerminalKey {
    readonly up: boolean;
    readonly down: boolean;
    readonly left: boolean;
    readonly right: boolean;
    readonly home: boolean;
    readonly end: boolean;
    readonly pageUp: boolean;
    readonly pageDown: boolean;
    readonly enter: boolean;
    readonly escape: boolean;
    readonly backspace: boolean;
    readonly delete: boolean;
    readonly tab: boolean;
    readonly shift: boolean;
    readonly ctrl: boolean;
    readonly meta: boolean;
}
/** Backend facade for custom screens; callers never need to import Sigil. */
export declare const useTerminalInput: (handler: (input: string, key: TerminalKey) => void, options?: {
    readonly active?: boolean;
}) => void;
/** Bracketed-paste input scoped the same way as {@link useTerminalInput}. */
export declare const useTerminalPaste: (handler: (text: string) => void, options?: {
    readonly active?: boolean;
}) => void;
export declare const useTerminalSize: () => {
    columns: number;
    rows: number;
};
export declare const useListNavigation: (length: number, initialIndex?: number) => {
    readonly cursor: number;
    readonly move: (delta: number) => void;
    readonly setCursor: import("react").Dispatch<import("react").SetStateAction<number>>;
};
/** Step `delta` rows from `cursor`, wrapping and skipping disabled rows. */
export declare const moveSkippingDisabled: (disabled: ReadonlyArray<boolean>, cursor: number, delta: number) => number;
/**
 * Jump to `target` (clamped, no wrap), settling on the nearest enabled row in
 * the jump direction and falling back to the other direction. Used for
 * Home/End and PageUp/PageDown in list prompts.
 */
export declare const jumpSkippingDisabled: (disabled: ReadonlyArray<boolean>, cursor: number, target: number) => number;
/**
 * List-cursor column shared by every focusable row (prompt lists, the
 * edit-accounts list, the profile dashboard): the focused row carries the
 * pointer glyph, every other row a same-width blank so labels stay aligned.
 * Focus is a shape, not a tint, so it survives ASCII and no-colour terminals.
 */
export declare function Pointer({ focused }: {
    readonly focused: boolean;
}): JSX.Element;
export interface MenuProps<Value> {
    readonly choices: ReadonlyArray<Choice<Value>>;
    readonly cursor: number;
    readonly selected?: ReadonlySet<number>;
    readonly visibleCount?: number;
    readonly empty?: string;
    readonly descriptionPlacement?: "below" | "inline";
}
/** Pure menu presentation used by select prompts and custom applications. */
export declare function Menu<Value>({ choices, cursor, selected, visibleCount, empty, descriptionPlacement, }: MenuProps<Value>): JSX.Element;
export interface TextFieldProps {
    readonly placeholder?: string;
    /** Text Tab fills into the empty field, e.g. the prompt's default. */
    readonly completion?: string;
    readonly initialValue?: string;
    readonly value?: string;
    readonly mask?: string;
    readonly onSubmit: (value: string) => void;
    readonly onChange?: (value: string) => void;
    readonly onCancel?: () => void;
    readonly active?: boolean;
    readonly ariaLabel?: string;
}
/**
 * Normalize text before inserting it into a single-line field. Sigil reports
 * bracketed paste separately, but pasted content can still contain newlines,
 * tabs or other control characters that do not belong in the value.
 */
export declare const sanitizeTextInsert: (input: string) => string;
/**
 * Single-line editor with insertion, deletion, home/end, word-wise movement
 * and the common readline kill bindings (Ctrl+U/K/W, Alt+Backspace). Long
 * values scroll horizontally instead of wrapping, so the terminal cursor
 * always sits on the field's own row.
 */
export declare function TextField({ placeholder, completion, initialValue, value: controlledValue, mask, onSubmit, onChange, onCancel, active, ariaLabel, }: TextFieldProps): JSX.Element;
export interface CycleListProps<State> {
    readonly choices: ReadonlyArray<CycleChoice<State>>;
    readonly cursor: number;
    readonly indices: ReadonlyArray<number>;
    readonly visibleCount?: number;
}
export declare function CycleList<State>({ choices, cursor, indices, visibleCount, }: CycleListProps<State>): JSX.Element;
export declare const useCycleNavigation: (stateCounts: ReadonlyArray<number>) => {
    readonly cursor: number;
    readonly indices: readonly number[];
    readonly move: (delta: number) => void;
    readonly setCursor: import("react").Dispatch<import("react").SetStateAction<number>>;
    readonly cycle: (delta: number) => void;
};
export interface ExternalWaitProps extends AwaitExternalOptions {
    readonly onSubmit: (value: string) => void;
    readonly onCancel: () => void;
}
/**
 * Yes/no keyboard handling shared by `InlineConfirm` and the confirm prompt
 * screen: arrows/tab toggle, Enter commits, y/n answer directly.
 */
export declare const useConfirmKeys: ({ initialValue, active, onSubmit, onCancel, }: {
    readonly initialValue?: boolean;
    readonly active?: boolean;
    readonly onSubmit: (value: boolean) => void;
    readonly onCancel?: () => void;
}) => boolean;
type InlineConfirmProps = {
    readonly message: string;
    readonly initialValue?: boolean;
    readonly confirmLabel?: string;
    readonly cancelLabel?: string;
    readonly active?: boolean;
    readonly onSubmit: (value: boolean) => void;
    readonly onCancel?: () => void;
};
export declare function InlineConfirm({ message, initialValue, confirmLabel, cancelLabel, active, onSubmit, onCancel, }: InlineConfirmProps): JSX.Element;
export interface ChoiceGroupProps<Value> {
    readonly choices: ReadonlyArray<{
        readonly value: Value;
        readonly label: string;
        readonly description?: string;
    }>;
    readonly value: Value;
    readonly orientation?: "horizontal" | "vertical";
    readonly active?: boolean;
    readonly onChange?: (value: Value) => void;
}
export declare function ChoiceGroup<Value>({ choices, value, orientation, active, onChange, }: ChoiceGroupProps<Value>): JSX.Element;
/** Browser/OAuth waiting screen with URL controls and manual-entry fallback. */
export declare function ExternalWait({ message, waitingLabel, url, code, openFailed, onOpen, allowManualInput, inputLabel, placeholder, validate, onSubmit, onCancel, }: ExternalWaitProps): JSX.Element;
export type PromptFrameProps = {
    readonly message: string;
    readonly description?: ReactNode;
    readonly children: JSX.Element;
    readonly layout?: "inline" | "stacked";
    readonly error?: string;
    readonly keys?: ReadonlyArray<readonly [string, string]>;
};
export declare function PromptFrame({ message, description, children, layout, error, keys, }: PromptFrameProps): JSX.Element;
export declare const filterChoices: <Value>(choices: ReadonlyArray<Choice<Value>>, query: string) => {
    choice: Choice<Value>;
    index: number;
}[];
/** Stable selected-index set for multiselect widgets. */
export declare const useSelectedChoices: <Value>(choices: ReadonlyArray<Choice<Value>>, initialValues: ReadonlyArray<Value>) => [ReadonlySet<number>, import("react").Dispatch<import("react").SetStateAction<ReadonlySet<number>>>];
export {};
//# sourceMappingURL=Interactive.d.ts.map