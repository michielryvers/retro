/** @jsxRuntime automatic */
/** @jsxImportSource @alchemy.run/sigil */
import type { ReactNode } from "react";
import { type StatusVariant } from "../../../Util/Theme.ts";
export interface ProgressBarProps {
    /** Completion ratio. Values outside 0..1 are clamped. */
    readonly value: number;
    /** Width in terminal cells (default: 24). */
    readonly width?: number;
    readonly showPercent?: boolean;
    readonly label?: ReactNode;
    readonly detail?: ReactNode;
    readonly variant?: StatusVariant;
}
/** Left-to-right progress using half/full Braille cells and an ASCII fallback. */
export declare function ProgressBar({ value, width, showPercent, label, detail, variant, }: ProgressBarProps): import("react").JSX.Element;
//# sourceMappingURL=ProgressBar.d.ts.map