import type { ReactNode } from "react";
import { type KeyHint } from "../../../Util/Theme.ts";
import type { CliKitCapabilities } from "../types.ts";
type CliEnvironmentProps = {
    readonly capabilities: CliKitCapabilities;
    /** Follow Sigil's terminal resize subscription for a live renderer. */
    readonly observeWindow?: boolean;
    readonly children?: ReactNode;
};
export declare function CliEnvironment({ capabilities, observeWindow, children, }: CliEnvironmentProps): import("react").JSX.Element;
export declare const useCliEnvironment: () => CliKitCapabilities;
export declare const useGlyphs: () => {
    readonly active: string;
    readonly add: string;
    readonly adopt: string;
    readonly bar: string;
    readonly bullet: string;
    readonly checked: string;
    readonly delete: string;
    readonly edit: string;
    readonly error: string;
    readonly info: string;
    readonly mask: string;
    readonly orphan: string;
    readonly overflowDown: string;
    readonly overflowLeft: string;
    readonly overflowRight: string;
    readonly overflowUp: string;
    readonly pointer: string;
    readonly refresh: string;
    readonly replace: string;
    readonly run: string;
    readonly section: string;
    readonly selected: string;
    readonly success: string;
    readonly unchecked: string;
    readonly unselected: string;
    readonly warning: string;
};
/** Border style matching the terminal's Unicode capability. */
export declare const useBorderStyle: () => "classic" | "single";
/** Key-hint labels for `KeyBar` footers, honoring the ASCII fallback. */
export declare const useKeyGlyphs: () => KeyHint;
export {};
//# sourceMappingURL=Environment.d.ts.map