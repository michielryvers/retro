import type { ReactNode } from "react";
export interface TaskRowProps {
    /** Status glyph. Ignored while `spinning`; defaults to the bullet glyph. */
    readonly icon?: string;
    /** Color for the glyph (and the spinner while `spinning`). */
    readonly iconColor?: string;
    /** Render an animated spinner frame in the glyph slot. */
    readonly spinning?: boolean;
    readonly label: ReactNode;
    /** Muted annotation directly after the label. */
    readonly detail?: ReactNode;
    /** Indentation in 2-space units. */
    readonly depth?: number;
    /** Extra trailing cells (status labels, chips). */
    readonly children?: ReactNode;
}
/**
 * The one status row shape shared by TaskTree and the plan/apply views:
 * glyph-or-spinner, bold label, muted detail, then any trailing cells.
 */
export declare function TaskRow({ icon, iconColor, spinning, label, detail, depth, children, }: TaskRowProps): import("react").JSX.Element;
export interface ProgressGroupRow {
    readonly id: string;
    readonly label: ReactNode;
    readonly completed: number;
    readonly total: number;
    readonly failed?: number;
    readonly detail?: ReactNode;
}
type ProgressGroupProps = {
    readonly rows: ReadonlyArray<ProgressGroupRow>;
    readonly width?: number;
    /** Fixed label column (truncated) so the count cells align across rows. */
    readonly labelWidth?: number;
};
export declare function ProgressGroup({ rows, width, labelWidth }: ProgressGroupProps): import("react").JSX.Element;
export declare class LiveStore<Value> {
    private value;
    private readonly listeners;
    constructor(initial: Value);
    readonly subscribe: (listener: () => void) => () => boolean;
    readonly snapshot: () => Value;
    readonly set: (value: Value) => void;
    readonly update: (f: (value: Value) => Value) => void;
}
export declare const useLiveStore: <Value>(store: LiveStore<Value>) => Value;
export {};
//# sourceMappingURL=Live.d.ts.map