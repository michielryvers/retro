/** @jsxRuntime automatic */
/** @jsxImportSource @alchemy.run/sigil */
import type { ReactNode } from "react";
export interface DescriptionItem {
    readonly label: ReactNode;
    readonly value: ReactNode;
}
type DescriptionListProps = {
    readonly items: ReadonlyArray<DescriptionItem>;
    readonly labelWidth?: number;
    /** Put values on their own line when horizontal space must not truncate them. */
    readonly stacked?: boolean;
};
export declare function DescriptionList({ items, labelWidth, stacked }: DescriptionListProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Data.d.ts.map