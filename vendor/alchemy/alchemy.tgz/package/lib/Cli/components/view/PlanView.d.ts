import type { JSX, ReactNode } from "react";
import { PlanTree } from "./PlanTree.ts";
export { PlanTree } from "./PlanTree.ts";
export type { PlanOutcome, PlanProgress, PlanRow, PlanTreeOptions, PlanTreeState, PlanView, PlanViewport, RowState, } from "./PlanTree.ts";
export type { PlanSummaryCounts } from "../../NamespaceTree.ts";
export interface PlanProps {
    /** Reactive tree containing rows, statuses, label, and presentation state. */
    tree: PlanTree;
    /** Allow the tree to collapse behind `p`. */
    collapsible?: boolean;
    /** Widget rendered before the summary block. */
    before?: ReactNode;
    /** Widget rendered on the summary row before the summary. */
    summaryBefore?: ReactNode;
    /** Widget rendered on the summary row after the summary. */
    summaryAfter?: ReactNode;
    /** Widget rendered below the virtualized rows. */
    footer?: ReactNode;
    /** Widget rendered after the complete Plan. */
    after?: ReactNode;
}
export declare function Plan(props: PlanProps): JSX.Element;
//# sourceMappingURL=PlanView.d.ts.map