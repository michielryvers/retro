import * as Effect from "effect/Effect";
import type { JSX } from "react";
import { CliKit, type NonInteractiveTerminal } from "../../CliKit/index.ts";
import { LiveStore } from "../ui/index.ts";
import { type ProfileProviderDisplay } from "./Profile.tsx";
export interface DashboardEntry {
    readonly name: string;
    readonly isActive: boolean;
    readonly isDefault: boolean;
}
export interface ProfileDetailsPayload {
    readonly providers: ReadonlyArray<ProfileProviderDisplay>;
    /** Registry providers not yet connected to this profile. */
    readonly available: ReadonlyArray<string>;
}
export type PureAction = {
    kind: "create";
    name: string;
} | {
    kind: "rename";
    name: string;
    newName: string;
} | {
    kind: "delete";
    name: string;
};
export type FlowAction = {
    kind: "edit-apply";
    name: string;
    add: string[];
    reconfigure: string[];
    remove: string[];
} | {
    kind: "refresh";
    name: string;
    provider?: string;
};
export type ExternalAction = FlowAction | {
    kind: "exit";
};
export interface ExecuteResult {
    readonly ok: boolean;
    readonly message: string;
    readonly entries: ReadonlyArray<DashboardEntry>;
    /** Profile to focus after the action (e.g. the new name of a rename). */
    readonly selected?: string;
}
export type Details = {
    state: "loading";
} | ({
    state: "ready";
} & ProfileDetailsPayload) | {
    state: "failed";
    message: string;
};
interface Notice {
    readonly ok: boolean;
    readonly message: string;
}
interface Flow {
    readonly kind: FlowAction["kind"];
    readonly name: string;
    readonly provider?: string;
    /** Inline flows render within the overview (refresh spinner). */
    readonly inline: boolean;
}
interface DashState {
    readonly entries: ReadonlyArray<DashboardEntry>;
    readonly details: ReadonlyMap<string, Details>;
    readonly notice: Notice | undefined;
    readonly busy: boolean;
    /** One-shot tab focus request (e.g. follow a rename to its new name). */
    readonly focus: string | undefined;
    /** Active in-app flow; `inline` flows render within the overview. */
    readonly flow: Flow | undefined;
}
/**
 * Immutable-snapshot store on top of `LiveStore`, so every mutation notifies
 * the mounted dashboard. The resolver bridge and the notice auto-dismiss
 * timer live outside the snapshot — they carry no visual state.
 */
export declare class DashStore extends LiveStore<DashState> {
    private resolver;
    constructor(entries: ReadonlyArray<DashboardEntry>);
    detailsFor(name: string): Details;
    detailNames(): ReadonlySet<string>;
    setDetails(name: string, details: Details): void;
    setFlow(flow: Flow | undefined): void;
    clearFocus(): void;
    dispose(): void;
    clearNotice(): void;
    applyResult(result: ExecuteResult): void;
    bindResolver(resolve: (action: PureAction | ExternalAction) => void): void;
    readonly dispatch: (action: PureAction | ExternalAction) => void;
}
type DashboardProps = {
    store: DashStore;
    initialSelected: number;
};
export declare function Dashboard({ store, initialSelected }: DashboardProps): JSX.Element;
export interface DashboardSessionOptions<R> {
    readonly entries: ReadonlyArray<DashboardEntry>;
    readonly selected: string | undefined;
    /**
     * Resolves a profile's provider details. A typed failure renders as the
     * detail pane's `failed` state, showing the error's message.
     */
    readonly loadDetails: (name: string) => Effect.Effect<ProfileDetailsPayload, {
        readonly message: string;
    }, R>;
    /** Executes a pure store action and returns the refreshed state. */
    readonly execute: (action: PureAction) => Effect.Effect<ExecuteResult, never, R>;
    /**
     * Runs an edit/refresh flow. Its prompts render inside the dashboard via
     * the embedded session; resolves with a toast outcome — `ok: false`
     * renders as a persistent error notice instead of an auto-dismissing
     * success toast.
     */
    readonly runFlow: (action: FlowAction, events: {
        readonly onProviderStart: (provider: string) => Effect.Effect<void>;
    }) => Effect.Effect<{
        ok: boolean;
        message: string;
    }, never, R>;
    /** Re-reads entries after a flow (the active profile may have changed). */
    readonly reloadEntries: Effect.Effect<ReadonlyArray<DashboardEntry>, never, R>;
}
/**
 * Runs the dashboard inside CliKit's application renderer. Pure actions and
 * edit/refresh flows share the same frame, and the application clears it on
 * exit.
 */
export declare const runProfileDashboardSession: <R>(options: DashboardSessionOptions<R>) => Effect.Effect<void, NonInteractiveTerminal, R | CliKit>;
export {};
//# sourceMappingURL=ProfileDashboard.d.ts.map