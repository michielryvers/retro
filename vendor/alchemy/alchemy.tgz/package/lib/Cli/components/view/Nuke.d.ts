/** @jsxRuntime automatic */
/** @jsxImportSource @alchemy.run/sigil */
import * as Effect from "effect/Effect";
import type { Result as NukeResult, Target } from "../../../Nuke.ts";
import type { ProviderMode } from "../../../ProviderMode.ts";
import { type ProgressEvent } from "../../../Report.ts";
import { CliKit } from "../../CliKit/index.ts";
import { LiveStore } from "../ui/index.ts";
import type { PlanTreeData } from "./PlanTree.ts";
interface NukeProgressState {
    readonly total: number;
    readonly completed: number;
    readonly resources: number;
    readonly inFlight: ReadonlyArray<string>;
}
export declare class NukeProgressStore extends LiveStore<NukeProgressState> {
    constructor();
    emit(event: ProgressEvent): void;
}
export declare function NukeProgress({ store }: {
    store: NukeProgressStore;
}): import("react").JSX.Element;
/** Scan progress stays separate until the inventory is ready to review. */
export declare const renderNukeScan: () => <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, CliKit | import("effect/Scope").Scope | Exclude<R, never>>;
/** Drive the same resource rows used by the preview through their deletion lifecycle. */
export declare const renderNukeDelete: (targets: ReadonlyArray<Pick<Target, "providerId" | "displayName">>, mode: ProviderMode) => <A extends NukeResult, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, CliKit | import("effect/Scope").Scope | Exclude<R, never>>;
/** Cloud inventory rows carry display identity only, never fabricated stack state. */
export declare const nukePlan: (targets: ReadonlyArray<Pick<Target, "providerId" | "displayName">>, options: {
    mode: ProviderMode;
}) => PlanTreeData;
export declare const reviewNuke: (targets: readonly Pick<Target, "displayName" | "providerId">[], options: {
    mode: ProviderMode;
    yes: boolean;
    dryRun: boolean;
}) => Effect.Effect<boolean, import("../types.ts").InteractionError, CliKit>;
export {};
//# sourceMappingURL=Nuke.d.ts.map