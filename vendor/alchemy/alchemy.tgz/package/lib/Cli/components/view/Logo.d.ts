import type { JSX } from "react";
type LogoProps = {
    cols: number;
};
export declare function Logo({ cols }: LogoProps): JSX.Element | null;
export {};
//# sourceMappingURL=Logo.d.ts.map