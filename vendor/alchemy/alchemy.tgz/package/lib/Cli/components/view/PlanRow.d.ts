/** @jsxRuntime automatic */
/** @jsxImportSource @alchemy.run/sigil */
/**
 * Shared rows for the Plan tree. Review and apply modes both render
 * namespaces through this component so they look like the same tree.
 */
import type { JSX } from "react";
import { actionStyle, type PlanAction } from "./statusStyle.ts";
export declare const namespaceStyle: (action: string) => (typeof actionStyle)[PlanAction];
/** A namespace node: rolled-up action icon + accent-colored id. */
type NamespaceRowProps = {
    readonly id: string;
    readonly depth: number;
    readonly action: string;
};
export declare function NamespaceRow({ id, depth, action }: NamespaceRowProps): JSX.Element;
export {};
//# sourceMappingURL=PlanRow.d.ts.map