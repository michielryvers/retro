/**
 * Provider-specific rules for migrating the released v0 profile store: one
 * central `profiles.json` with each provider's saved credentials in a
 * `credentials/<name>.json` sidecar. `ProfileStore` runs the migration once
 * and moves the original files into a `.profiles-v0-*` backup.
 *
 * This is a frozen snapshot of the v0 layout, not provider configuration:
 * the migration runs before any provider package is loaded and rewrites the
 * whole store, so every provider's old filenames must be known here. Delete
 * this module once v0 stores no longer need to roll forward.
 */
import * as Schema from "effect/Schema";
import type { ProviderConfig } from "./Profile.ts";
/** The v0 central manifest. */
export declare const V0ManifestSchema: Schema.StructWithRest<Schema.Struct<{
    readonly version: Schema.Literal<0>;
    readonly profiles: Schema.$Record<Schema.String, Schema.Unknown>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
/**
 * How to migrate one provider's v0 values: keep them as they are
 * (`Inline`), or fold in the first sidecar found among `candidates`
 * (sidecar names without `.json`), using `fallback` when none is readable.
 */
export type SidecarPlan = {
    readonly _tag: "Inline";
    readonly values: ProviderConfig;
} | {
    readonly _tag: "Sidecar";
    readonly candidates: ReadonlyArray<string>;
    readonly fallback: ProviderConfig;
};
export declare const planSidecar: (provider: string, values: ProviderConfig) => SidecarPlan;
/** Fold a decoded sidecar into the provider's v0 manifest values. */
export declare const mergeSidecar: (provider: string, values: ProviderConfig, sidecar: ProviderConfig) => ProviderConfig;
/**
 * Values to write for a provider whose v0 entry can't be decoded, or
 * `undefined` to skip it (it stays in the v0 backup). Cloudflare gets an
 * empty profile so `alchemy login` prompts for fresh credentials.
 */
export declare const undecodableValues: (provider: string) => ProviderConfig | undefined;
//# sourceMappingURL=ProfileMigrationV0.d.ts.map