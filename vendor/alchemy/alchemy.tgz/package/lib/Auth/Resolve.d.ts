import * as Config from "effect/Config";
import * as ConfigProvider from "effect/ConfigProvider";
import * as Effect from "effect/Effect";
import * as Option from "effect/Option";
import * as Schema from "effect/Schema";
import { UserFacingError } from "../UserFacingError.ts";
import { AuthError } from "./AuthProvider.ts";
import { ProfileStore } from "./Profile.ts";
/**
 * Resolve the selected Alchemy profile after the command's dotenv provider is
 * known. An omitted explicit override remains absent so it does not shadow
 * `ALCHEMY_PROFILE` from `.env` / `--env-file`.
 */
export declare const resolveProfileSelection: (envFile: Option.Option<string>, override: string | undefined) => Effect.Effect<{
    name: string;
    source: "command-line" | "configuration" | "default";
}, import("effect/PlatformError").PlatformError | import("./Profile.ts").ProfileError, import("effect/FileSystem").FileSystem | ProfileStore>;
export declare const resolveProfileName: (envFile: Option.Option<string>, override: string | undefined) => Effect.Effect<string, import("effect/PlatformError").PlatformError | import("./Profile.ts").ProfileError, import("effect/FileSystem").FileSystem | ProfileStore>;
/**
 * The shared preamble of every per-cloud `fromAuthProvider` /
 * `fromEnvironment` layer. Precedence: environment credentials (process
 * environment plus `.env` / `--env-file`) whenever the provider's declared
 * contract is fully present — CI or not, selected profile or not — then, in
 * CI, the provider's environment resolution alone (profiles do not exist
 * there), otherwise the selected profile.
 */
export declare const resolveProviderConfig: <C extends {
    method: string;
} = any, Credentials = any>(providerName: string) => Effect.Effect<{
    auth: import("./AuthProvider.ts").AuthProvider<C, Credentials>;
    profileName: undefined;
    config: undefined;
    resolve: Effect.Effect<Credentials, AuthError, never>;
    source: "environment";
} | {
    auth: import("./AuthProvider.ts").AuthProvider<C, Credentials>;
    profileName: string;
    config: C;
    resolve: Effect.Effect<Credentials, AuthError | import("./AuthProvider.ts").NeedsReauth, never>;
    source: "profile";
}, AuthError | Config.ConfigError | import("./Profile.ts").MissingProviderConfig | import("effect/PlatformError").PlatformError | import("./Profile.ts").ProfileError, import("./AuthProvider.ts").AuthProviders | ProfileStore>;
/**
 * Defer an effect that a layer hands out as its service value. The effect
 * runs on first use, outside the layer build, so the services it needs are
 * captured now and provided to it. Building the layer then never runs the
 * effect, e.g. never requires a configured profile.
 *
 * The `ConfigProvider` is a reference, so it is not part of `R`; capture it
 * too. Otherwise the first use reads config through whatever provider is
 * ambient there — e.g. a Function's init, which binds every key it loads into
 * the Function's env and would ship the deployer's credentials (#1842).
 */
export declare const deferUntilFirstUse: <A, E, R>(resolve: Effect.Effect<A, E, R>) => Effect.Effect<Effect.Effect<A, E, Exclude<Exclude<R, never>, R>>, never, R>;
declare const CredentialsUnavailable_base: Schema.Class<CredentialsUnavailable, Schema.TaggedStruct<"CredentialsUnavailable", {
    readonly provider: Schema.String;
    readonly message: Schema.String;
    readonly cause: Schema.optional<Schema.Defect>;
}>, import("effect/Cause").YieldableError>;
/**
 * A provider's credentials could not be resolved when a cloud operation first
 * needed them: no profile, the provider is not configured in it, or the
 * stored credentials can no longer be read or refreshed.
 */
export declare class CredentialsUnavailable extends CredentialsUnavailable_base {
    readonly [UserFacingError] = true;
}
/**
 * Credential services are `Effect<Config>` with no error channel, so a
 * failed resolution can only leave them as a defect. Die with
 * {@link CredentialsUnavailable} so the engine can tell it apart from a
 * provider crash and fail the operation with `CredentialsRequired`.
 */
export declare const orDieCredentialsUnavailable: (provider: string) => <A, E extends {
    readonly message: string;
}, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A, never, R>;
/** Let an explicit profile override configured selection without disturbing other keys. */
export declare const withProfileOverride: (base: ConfigProvider.ConfigProvider, profile: string | undefined) => ConfigProvider.ConfigProvider;
export {};
//# sourceMappingURL=Resolve.d.ts.map