/**
 * Shared browser-OAuth ceremony for auth providers: open the authorization
 * URL, then race the provider's local callback listener against the branded
 * "waiting for browser" prompt (spinner + URL; Enter switches to
 * manual code entry, `o` opens the browser again, and `c` copies the URL).
 *
 * {@link deviceOAuth} is the device-code (RFC 8628) counterpart.
 *
 * Built-in providers (Planetscale, Cloudflare) and custom stack-provided
 * auth providers should all route their browser flows through these so the
 * login UX stays uniform.
 */
import * as Effect from "effect/Effect";
import type { ChildProcessSpawner } from "effect/process/ChildProcessSpawner";
import * as Interaction from "../Interaction.ts";
import { CallbackServerStartError, type DeviceAuthorization } from "./OAuthFlow.ts";
export interface BrowserOAuthOptions<A, E1, R1, E2, R2> {
    /** Display name, e.g. "Cloudflare" — used in the prompt title. */
    provider: string;
    /** The authorization URL the browser was pointed at. */
    url: string;
    /** Resolves when the local callback listener receives the redirect. */
    callback: Effect.Effect<A, E1, R1>;
    /** Exchanges a manually pasted code / callback URL for credentials. */
    exchange: (input: string) => Effect.Effect<A, E2, R2>;
    /** Spinner label. @default "waiting for browser authorization (up to 5 minutes)…" */
    waitingLabel?: string;
}
export declare const browserOAuth: <A, E1, R1, E2, R2>(options: BrowserOAuthOptions<A, E1, R1, E2, R2>) => Effect.Effect<A, E2 | Exclude<E1, E1 & CallbackServerStartError> | Interaction.InteractionError, R1 | R2 | ChildProcessSpawner | Interaction.Interaction>;
export interface DeviceOAuthOptions<A, E, R> {
    /** Display name, e.g. "Cloudflare" — used in the prompt title. */
    provider: string;
    /** The pending device authorization to show the user. */
    authorization: DeviceAuthorization;
    /** Polls until the user approves; usually `client.deviceToken(authorization)`. */
    token: Effect.Effect<A, E, R>;
}
/**
 * Shared device-authorization (RFC 8628) ceremony: open the verification
 * URL, show the user code, and wait for the token poll. The prompt only
 * renders the URL/code and re-opens the browser; the poll always wins.
 */
export declare const deviceOAuth: <A, E, R>(options: DeviceOAuthOptions<A, E, R>) => Effect.Effect<A, E | Interaction.InteractionError, R | ChildProcessSpawner | Interaction.Interaction>;
//# sourceMappingURL=BrowserOAuth.d.ts.map