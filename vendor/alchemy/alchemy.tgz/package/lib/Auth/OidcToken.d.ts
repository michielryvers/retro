import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import * as Redacted from "effect/Redacted";
/**
 * Platform-issued OIDC tokens, for exchanging with a secrets manager's OIDC
 * identity auth (Doppler service account identities, Infisical machine
 * identities) so CI never holds a long-lived credential.
 *
 * | Platform       | Marker variable   | Token source                               |
 * | -------------- | ----------------- | ------------------------------------------ |
 * | explicit       | the caller's env  | the variable itself                        |
 * | Vercel         | `VERCEL`          | `VERCEL_OIDC_TOKEN`                        |
 * | GitHub Actions | `GITHUB_ACTIONS`  | `ACTIONS_ID_TOKEN_REQUEST_URL` + token     |
 * | GitLab CI      | `GITLAB_CI`       | `SIGSTORE_ID_TOKEN` from `id_tokens`        |
 * | GCP            | `K_SERVICE` etc.  | the metadata server's identity endpoint    |
 */
export type OidcPlatform = "explicit" | "vercel" | "github-actions" | "gitlab" | "gcp";
export interface OidcToken {
    readonly platform: OidcPlatform;
    readonly token: Redacted.Redacted<string>;
}
/** Which env vars a provider reserves for its explicit token and audience. */
export interface OidcTokenEnv {
    /** Explicit override for platforms that are not auto-detected. */
    readonly token: string;
    /** Optional `aud` claim to request where the platform supports it. */
    readonly audience: string;
}
/** The platforms {@link detectOidcToken} knows, for error messages. */
export declare const SUPPORTED_OIDC_PLATFORMS = "Vercel, GitHub Actions (needs `permissions: id-token: write`), GitLab CI (needs `id_tokens`), and GCP";
/**
 * Find the OIDC token of the platform this process is running on. The
 * caller's explicit variable wins; otherwise platforms are probed in
 * order and the first token wins. A probe that fails or hangs counts as
 * "not this platform". `undefined` means nothing was detected.
 */
export declare const detectOidcToken: (env: OidcTokenEnv) => Effect.Effect<OidcToken | undefined, import("./AuthProvider.ts").AuthError, HttpClient.HttpClient>;
//# sourceMappingURL=OidcToken.d.ts.map