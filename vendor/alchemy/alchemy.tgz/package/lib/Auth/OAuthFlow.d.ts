import * as Crypto from "effect/Crypto";
import * as Effect from "effect/Effect";
import * as Redacted from "effect/Redacted";
import * as Schema from "effect/Schema";
declare const OAuthError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OAuthError";
} & Readonly<A>;
/**
 * The authorization server rejected a request with an OAuth error code
 * (RFC 6749 §5.2, RFC 8628 §3.5). `error` is the server's code verbatim.
 */
export declare class OAuthError extends OAuthError_base<{
    error: string;
    errorDescription: string;
}> {
    get message(): string;
}
declare const OAuthNetworkError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OAuthNetworkError";
} & Readonly<A>;
/** A request to the authorization server could not be sent or answered. */
export declare class OAuthNetworkError extends OAuthNetworkError_base<{
    endpoint: string;
    cause: unknown;
}> {
    get message(): string;
}
declare const OAuthServerUnavailable_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OAuthServerUnavailable";
} & Readonly<A>;
/**
 * The authorization server answered 429/5xx without an OAuth error body
 * (typically an edge error page). Transient.
 */
export declare class OAuthServerUnavailable extends OAuthServerUnavailable_base<{
    endpoint: string;
    status: number;
}> {
    get message(): string;
}
declare const OAuthInvalidResponse_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OAuthInvalidResponse";
} & Readonly<A>;
/** The authorization server's response could not be interpreted. */
export declare class OAuthInvalidResponse extends OAuthInvalidResponse_base<{
    endpoint: string;
    status: number;
    reason: string;
}> {
    get message(): string;
}
/** Every way a request to the authorization server can fail. */
export type OAuthRequestError = OAuthError | OAuthNetworkError | OAuthServerUnavailable | OAuthInvalidResponse;
declare const OAuthCryptoError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OAuthCryptoError";
} & Readonly<A>;
/** Secure random generation or hashing for state/PKCE failed. */
export declare class OAuthCryptoError extends OAuthCryptoError_base<{
    operation: string;
    cause: unknown;
}> {
    get message(): string;
}
declare const UnsupportedOAuthFlowError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnsupportedOAuthFlowError";
} & Readonly<A>;
/** The client spec lacks the endpoints/URIs a flow needs. */
export declare class UnsupportedOAuthFlowError extends UnsupportedOAuthFlowError_base<{
    flow: "browser" | "device";
}> {
    get message(): string;
}
declare const OAuthCallbackError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OAuthCallbackError";
} & Readonly<A>;
/** A callback redirect or pasted code lacks a code or carries the wrong state. */
export declare class OAuthCallbackError extends OAuthCallbackError_base<{
    reason: "missing_code" | "state_mismatch";
}> {
    get message(): string;
}
declare const OAuthCallbackTimeout_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OAuthCallbackTimeout";
} & Readonly<A>;
/** No browser callback arrived within 5 minutes. */
export declare class OAuthCallbackTimeout extends OAuthCallbackTimeout_base {
    get message(): string;
}
declare const UntrustedVerificationUriError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UntrustedVerificationUriError";
} & Readonly<A>;
/**
 * The device authorization endpoint pointed the user at a URL outside the
 * authorization server's host (RFC 8628 §5.4, remote phishing).
 */
export declare class UntrustedVerificationUriError extends UntrustedVerificationUriError_base<{
    url: string;
    expectedHost: string;
}> {
    get message(): string;
}
declare const DeviceAuthorizationDenied_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DeviceAuthorizationDenied";
} & Readonly<A>;
/** The user denied the device authorization. */
export declare class DeviceAuthorizationDenied extends DeviceAuthorizationDenied_base {
    get message(): string;
}
declare const DeviceAuthorizationExpired_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DeviceAuthorizationExpired";
} & Readonly<A>;
/** The device code expired (or the 5 minute cap passed) before approval. */
export declare class DeviceAuthorizationExpired extends DeviceAuthorizationExpired_base {
    get message(): string;
}
declare const CallbackServerStartError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "CallbackServerStartError";
} & Readonly<A>;
/**
 * The local loopback callback server could not start (typically the port is
 * already taken). Distinct from {@link CallbackServerError} so callers can
 * fall back to manual code entry instead of failing the whole flow.
 */
export declare class CallbackServerStartError extends CallbackServerStartError_base<{
    message: string;
}> {
}
declare const CallbackServerError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "CallbackServerError";
} & Readonly<A>;
/** The loopback callback server failed after it started listening. */
export declare class CallbackServerError extends CallbackServerError_base<{
    message: string;
}> {
}
/**
 * On-disk shape of OAuth credentials persisted under
 * `~/.alchemy/credentials/{profile}/<provider>-oauth.json`.
 *
 * `clientId` is optional because files written before the client id was
 * recorded must still parse — {@link OAuthClient.usesCurrentClient} treats a
 * missing id as "issued to a previous client", which triggers a clean
 * re-login.
 */
export declare const OAuthCredentials: Schema.Struct<{
    readonly type: Schema.Literal<"oauth">;
    readonly clientId: Schema.optional<Schema.String>;
    readonly access: Schema.RedactedFromValue<Schema.String>;
    readonly refresh: Schema.RedactedFromValue<Schema.String>;
    readonly expires: Schema.Number;
    readonly scopes: Schema.mutable<Schema.$Array<Schema.String>>;
}>;
export type OAuthCredentials = typeof OAuthCredentials.Type;
/**
 * A pending OAuth 2.0 Device Authorization Grant (RFC 8628): the user
 * approves `userCode` at `verificationUri` while the CLI polls for tokens.
 */
export interface DeviceAuthorization {
    deviceCode: string;
    userCode: string;
    verificationUri: string;
    /** Verification URL with the user code pre-filled. */
    verificationUriComplete: string;
    /** Seconds until the device code expires. */
    expiresIn: number;
    /** Seconds between token polls. */
    interval: number;
}
export interface Authorization {
    url: string;
    state: string;
    /** PKCE verifier; present only for `auth: { kind: "pkce" }` clients. */
    verifier?: string;
}
/**
 * The provider-specific facts an OAuth flow needs. Everything else —
 * state/PKCE generation, the loopback callback server, hosted-relay code
 * extraction, device-code polling, token exchange, refresh, revoke — is
 * shared.
 *
 * The browser (authorization-code) flow needs `endpoints.authorize`,
 * `redirectUri` and `localCallbackUri`; the device flow needs
 * `endpoints.deviceAuthorization`. A client that only refreshes and revokes
 * existing grants needs neither.
 */
export interface OAuthClientSpec {
    readonly clientId: string;
    readonly endpoints: {
        readonly authorize?: string;
        /** RFC 8628 device authorization endpoint. */
        readonly deviceAuthorization?: string;
        readonly token: string;
        /** Providers without a revocation endpoint omit it; `revoke` then no-ops. */
        readonly revoke?: string;
    };
    /** Hosted relay redirect URI registered with the OAuth application. */
    readonly redirectUri?: string;
    /** Loopback URI the local callback server listens on. */
    readonly localCallbackUri?: string;
    /**
     * Client authentication. `pkce` for public clients; `clientSecret` for
     * providers whose token endpoint requires client authentication for every
     * grant (the secret ships in the CLI — same exposure posture as a public
     * client id, rotated by cutting a release).
     */
    readonly auth: {
        readonly kind: "pkce";
    } | {
        readonly kind: "clientSecret";
        readonly clientSecret: Redacted.Redacted<string>;
    };
    /**
     * How token-request parameters travel: URL-encoded POST body (the OAuth 2
     * standard, default) or the query string (PlanetScale's documented form).
     */
    readonly tokenTransport?: "body" | "query";
}
export interface OAuthClient {
    readonly clientId: string;
    /** Whether persisted credentials were issued to this client. */
    readonly usesCurrentClient: (credentials: {
        readonly clientId?: unknown;
    }) => boolean;
    /**
     * Generate an authorization URL. Pass `scopes` only for providers that
     * take them per-authorization; omit for providers whose scopes are
     * configured on the application.
     */
    readonly authorize: (scopes?: ReadonlyArray<string>) => Effect.Effect<Authorization, OAuthCryptoError | UnsupportedOAuthFlowError, Crypto.Crypto>;
    /**
     * Exchange an authorization code directly. `authorization` supplies the
     * PKCE verifier; omit for non-PKCE clients (tests, relay-less flows).
     */
    readonly exchange: (code: string, authorization?: Authorization) => Effect.Effect<OAuthCredentials, OAuthRequestError | UnsupportedOAuthFlowError, never>;
    /**
     * Exchange a code copied from the hosted relay page, or extract the code
     * from either the hosted or loopback callback URL.
     */
    readonly exchangeCallbackInput: (input: string, authorization: Authorization) => Effect.Effect<OAuthCredentials, OAuthRequestError | OAuthCallbackError | UnsupportedOAuthFlowError, never>;
    /**
     * Start a local HTTP server to listen for the OAuth callback, exchange
     * the authorization code, and return the credentials. Times out after 5
     * minutes.
     */
    readonly callback: (authorization: Authorization) => Effect.Effect<OAuthCredentials, OAuthRequestError | OAuthCallbackError | OAuthCallbackTimeout | CallbackServerStartError | CallbackServerError | UnsupportedOAuthFlowError, never>;
    /** Start an RFC 8628 device authorization for `scopes`. */
    readonly deviceAuthorize: (scopes?: ReadonlyArray<string>) => Effect.Effect<DeviceAuthorization, OAuthRequestError | UnsupportedOAuthFlowError | UntrustedVerificationUriError, never>;
    /**
     * Poll the token endpoint until the user approves (or denies) the device
     * authorization. Times out when the device code expires, capped at 5
     * minutes.
     */
    readonly deviceToken: (authorization: DeviceAuthorization) => Effect.Effect<OAuthCredentials, OAuthRequestError | DeviceAuthorizationDenied | DeviceAuthorizationExpired, never>;
    /** Refresh expired OAuth credentials with the stored refresh token. */
    readonly refresh: (credentials: OAuthCredentials) => Effect.Effect<OAuthCredentials, OAuthRequestError, never>;
    /** Revoke the refresh token; no-op when the spec has no revoke endpoint. */
    readonly revoke: (credentials: OAuthCredentials) => Effect.Effect<void, OAuthNetworkError>;
}
export declare const makeOAuthClient: (spec: OAuthClientSpec) => OAuthClient;
export {};
//# sourceMappingURL=OAuthFlow.d.ts.map