import type { PlatformError } from "effect/PlatformError";
declare const DockerRegistryBlobUnknown_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DockerRegistryBlobUnknown";
} & Readonly<A>;
export declare class DockerRegistryBlobUnknown extends DockerRegistryBlobUnknown_base<{
    readonly cause: PlatformError;
}> {
    get message(): string;
}
declare const DockerRegistryUnavailable_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DockerRegistryUnavailable";
} & Readonly<A>;
export declare class DockerRegistryUnavailable extends DockerRegistryUnavailable_base<{
    readonly cause: PlatformError;
}> {
    get message(): string;
}
export type DockerImagePublicationError = PlatformError | DockerRegistryBlobUnknown | DockerRegistryUnavailable;
export declare const classifyDockerRegistryError: (error: PlatformError) => DockerImagePublicationError;
export {};
//# sourceMappingURL=RegistryError.d.ts.map