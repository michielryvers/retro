import { AlchemyContext } from "alchemy/AlchemyContext";
import * as Bundle from "alchemy/Bundle/Bundle";
import * as Effect from "effect/Effect";
import { Docker } from "./Docker.ts";
/**
 * INTERNAL — image machinery for the effectful `Docker.Service` platform.
 *
 * NOT exported from the Docker barrel. Bundles a `main` Effect program with
 * rolldown, bakes it into a generated bun Dockerfile, and builds the image
 * with the Docker CLI against the service's Docker context — so the image is
 * present in the exact engine the Swarm service schedules from. There is no
 * registry push: the built image is content-addressed (`<name>:<hash>`) and
 * only rebuilt when the bundle, Dockerfile, or environment image changes.
 *
 * Multi-node swarms need the image on every node; for those, build with
 * `Docker.Image` + a `registry` and pass the pushed ref as `image` instead.
 */
/** The props subset that describes a bundled `main` service image. */
export interface BundledServiceSource {
    main: string;
    image?: string;
    handler?: string;
    port?: number;
    /**
     * Bundler configuration for `main`. Unused code is tree-shaken.
     * `effect`, alchemy, and `@distilled.cloud` are marked pure so unused
     * parts prune more aggressively. List extra packages with
     * `pure.packages`, or disable with `pure: false`.
     */
    build?: Bundle.BundleConfig;
}
/** The resolved (built) local image. */
export interface ResolvedServiceImage {
    /** Full image reference, `<name>:<codeHash>`. */
    imageRef: string;
    /** Content hash identifying the image (also the image tag). */
    codeHash: string;
}
/**
 * The generated entry for `Docker.Service` containers: a shim importing only
 * `@alchemy.run/docker/Bootstrap` plus the user's `main` — see that
 * module for why the entry never imports alchemy's own dependencies.
 */
export declare const makeServiceBunBootstrap: (handler: string) => (importPath: string) => string;
/**
 * Init-time constructor for the service-image resolver. Resolves the services
 * that are only available at provider-layer construction (Docker, the
 * `.alchemy` directory, the rolldown virtual-entry plugin) and returns
 * `resolve` (build the image if its content hash isn't present in the target
 * engine) and `hash` (content hash only, for `diff`).
 */
export declare const makeServiceImage: Effect.Effect<{
    resolve: (options: {
        /** Logical resource id — keys the stable build-context directory. */
        id: string;
        source: BundledServiceSource;
        /** Image repository name (the service's physical name). */
        name: string;
        /** Docker context the swarm service is deployed to. */
        context: string | undefined;
        isExternal?: boolean;
        /** Plan-status session used to emit build progress notes. */
        session: {
            note: (message: string) => Effect.Effect<void>;
        };
    }) => Effect.Effect<{
        imageRef: string;
        codeHash: string;
    }, Bundle.BundleError | import("./RegistryError.ts").DockerImagePublicationError, import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage>;
    hash: (options: {
        source: BundledServiceSource;
        isExternal?: boolean;
    }) => Effect.Effect<string, Bundle.BundleError | import("effect/PlatformError").PlatformError, import("effect/FileSystem").FileSystem | import("effect/Path").Path>;
}, never, AlchemyContext | Docker | import("effect/Path").Path>;
/** The resolver service returned by {@link makeServiceImage}. */
export interface ServiceImage extends Effect.Success<typeof makeServiceImage> {
}
//# sourceMappingURL=ServiceImage.d.ts.map