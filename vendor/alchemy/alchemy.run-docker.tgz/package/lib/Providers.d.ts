import * as Provider from "alchemy/Provider";
import * as Layer from "effect/Layer";
import { type DockerOptions } from "./Docker.ts";
declare const Providers_base: Provider.ProviderCollection<Providers, "Docker">;
export declare class Providers extends Providers_base {
}
export type ProviderRequirements = Layer.Services<ReturnType<typeof providers>>;
/**
 * Registers all Docker resource providers.
 *
 * Docker providers use the active Docker CLI context and are intentionally
 * separate from `Cloudflare.Container`. Pass `bin` to run a Docker-compatible
 * CLI such as Podman; the `DOCKER_BIN` environment variable overrides it.
 *
 * ```typescript
 * providers: Docker.providers({ bin: "podman" }),
 * ```
 */
export declare const providers: (options?: DockerOptions) => Layer.Layer<import("./Docker.ts").Docker | Providers, never, import("alchemy/AlchemyContext").AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage>;
export {};
//# sourceMappingURL=Providers.d.ts.map