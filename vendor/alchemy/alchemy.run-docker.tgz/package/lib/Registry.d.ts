import type * as Redacted from "effect/Redacted";
export interface ImageRegistry {
    /** Registry host, e.g. `ghcr.io`. */
    server: string;
    /** Registry username. */
    username: string;
    /** Registry password. Use `Redacted.make(...)` or `Config.Redacted(...)`. */
    password: Redacted.Redacted<string>;
}
/** Strips the tag and digest from an image reference, leaving the repository. */
export declare const repositoryFromImageRef: (imageRef: string) => string;
/**
 * Prefixes an image reference with the registry host unless the reference
 * already carries a registry prefix (a dotted host, a host:port, or `localhost`).
 */
export declare const withRegistryHost: (imageRef: string, registry: {
    server: string;
}) => string;
/** Extracts the `repository@sha256:...` digest from `docker push` output. */
export declare const parseRepoDigest: (imageRef: string, output: string) => string | undefined;
/**
 * Picks the `repository@digest` that inspect reports for this image.
 *
 * A fallback when push output has no `digest:` line. Podman pushes report the
 * published digest through `--digestfile` instead, because Podman can list a
 * pulled image's source digest under the pushed name here.
 */
export declare const repoDigestFromInspect: (imageRef: string, repoDigests: ReadonlyArray<string> | null | undefined) => string | undefined;
/**
 * Digest from push output when the engine prints one, otherwise the matching
 * `RepoDigests` entry. `registryRef` is the host-qualified name when it
 * differs from the local reference that was pushed.
 */
export declare const publishedRepoDigest: (imageRef: string, output: {
    stdout: string;
    stderr: string;
}, repoDigests: ReadonlyArray<string> | null | undefined, registryRef?: string) => string | undefined;
/**
 * Parses an image's RFC 3339 `Created` timestamp into epoch milliseconds.
 *
 * Docker only reports `Created` when the image config carries a creation time:
 * API >= 1.44 omits it, older APIs backfill the year-1 zero value
 * (`0001-01-01T00:00:00Z`), and 25.0.0–25.0.3 returned an empty string. In any
 * of those cases there is no real build time, so we fall back to the wall clock.
 */
export declare const parseCreatedAt: (created: string | undefined) => number;
//# sourceMappingURL=Registry.d.ts.map