import { AlchemyContext } from "alchemy/AlchemyContext";
import * as Bundle from "alchemy/Bundle/Bundle";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import type * as rolldown from "rolldown";
import { Docker, type RegistryCredentials } from "./Docker.ts";
import { type InlineDockerfile } from "./Dockerfile.ts";
/**
 * INTERNAL — registry-agnostic container image-source machinery shared by
 * the container platforms (`AWS.ECS.*`, `AWS.EKS.*` via ECR, and
 * `Kubernetes.*` workloads pushing to any registry).
 *
 * NOT exported from any barrel. Consumers import the module path directly.
 *
 * A platform's props separate the ENVIRONMENT (what the container is) from
 * the PROGRAM (`main` — "and run my bundled Effect program in it"):
 *
 * - environment (at most one): `image` (registry ref) | `context` +
 *   `dockerfile`-as-path (docker build) | inline `dockerfile` content
 *   (`Dockerfile.inline`) | the default bun base when `main` stands alone.
 * - `main` present → the bundle is injected into the environment (COPY +
 *   ENTRYPOINT) and pushed as a derived image. `main` absent → the
 *   environment runs verbatim: `image` is mirrored (docker pull → tag →
 *   push, content-addressed on the ref), a Dockerfile builds as-is.
 *
 * Where images land is an {@link ImageRegistryTarget}: ECR supplies one that
 * auto-creates a private repository; a plain registry (a local `registry`
 * container, GHCR, Docker Hub, …) supplies one that pushes to
 * `<server>/<name>`.
 */
/**
 * Bundle an Effect program into a generated image. Alchemy bundles `main`
 * with rolldown and bakes it into a Dockerfile generated from the
 * environment (`image`, `dockerfile`, or the default bun base).
 */
export interface BundledImageSource {
    /**
     * Module entrypoint for the bundled program. This should typically be
     * `import.meta.url` from an inline Effect program.
     */
    main: string;
    /**
     * Environment image: used as the generated Dockerfile's `FROM`. Any
     * registry ref works (private non-ECR registries require docker
     * credentials on the build machine); the image must be able to run the
     * bun runtime. Exclusive with {@link dockerfile} / {@link context}.
     * @default "oven/bun:1"
     */
    image?: string;
    /**
     * Environment Dockerfile: a string is a PATH (built in {@link context},
     * then the bundle is layered on top in a second stage); an
     * {@link InlineDockerfile} is inline content used as the environment
     * preamble (built with no context — its own `COPY`s are unsupported).
     * The resulting environment must be able to run the bun runtime.
     * Exclusive with {@link image}.
     */
    dockerfile?: string | InlineDockerfile;
    /**
     * Build context for a path {@link dockerfile} environment. Exclusive
     * with {@link image} and inline dockerfiles.
     */
    context?: string;
    /**
     * Named export to load from `main`.
     * @default "default"
     */
    handler?: string;
    /**
     * Bundler configuration for the entrypoint. Unused code is tree-shaken.
     * `effect`, alchemy, and `@distilled.cloud` are marked pure so unused
     * parts prune more aggressively. List extra packages with
     * `pure.packages`, or disable with `pure: false`.
     */
    build?: Bundle.BundleConfig;
}
/**
 * Build the image from the user's own Dockerfile and build context — no
 * Effect program is bundled.
 */
export interface DockerfileImageSource {
    /**
     * Docker build context directory. Optional when {@link dockerfile} is
     * inline content (which builds with an empty context).
     */
    context?: string;
    /**
     * Path to the Dockerfile relative to the cwd (NOT the context), or
     * {@link InlineDockerfile} content. The Dockerfile must define its own
     * `CMD`/`ENTRYPOINT` (no program is injected).
     * @default `${context}/Dockerfile`
     */
    dockerfile?: string | InlineDockerfile;
}
/**
 * Run a pre-built registry image. Registry-backed platforms may mirror it
 * into their own registry (ECR: docker pull → tag → push).
 */
export interface RegistryImageSource {
    /**
     * A pre-built image reference, e.g.
     * `public.ecr.aws/docker/library/busybox:stable`.
     */
    image: string;
}
/**
 * The image-source union. Discriminated by presence: exactly one of
 * `main`, `context`, or `image`.
 */
export type ImageSourceProps = BundledImageSource | DockerfileImageSource | RegistryImageSource;
/** Loose bag shape used to sniff which source variant a props object is. */
export interface ImageSourceLike {
    main?: string;
    handler?: string;
    build?: BundledImageSource["build"];
    context?: string;
    dockerfile?: string | InlineDockerfile;
    image?: string;
}
export type ImageSourceKind = "main" | "context" | "image";
/**
 * Which image source a props bag declares. `main` always wins (the other
 * fields then describe its ENVIRONMENT); without `main`, `image` is the
 * mirrored-verbatim source and any `context`/`dockerfile` (path or inline)
 * is an external docker build.
 */
export declare const imageSourceKind: (source: ImageSourceLike) => ImageSourceKind | undefined;
/**
 * Validate environment-source exclusivity. Dies (plan-time defect) on
 * `image`+`dockerfile`, `image`+`context`, or inline-`dockerfile`+`context`.
 */
export declare const validateImageSource: (id: string, source: ImageSourceLike) => Effect.Effect<void>;
/**
 * Where a resolved image is pushed. Each field is an Effect so a target can
 * create resources lazily (ECR creates the repository on first use).
 */
export interface ImageRegistryTarget<R = never> {
    /** The repository URI images are tagged into (`<repositoryUri>:<hash>`). */
    readonly repositoryUri: Effect.Effect<string, any, R>;
    /**
     * Whether the content-addressed tag is already in the registry. `true`
     * skips the build and push entirely.
     */
    readonly hasTag: (tag: string) => Effect.Effect<boolean, any, R>;
    /**
     * Push credentials. `undefined` pushes with the build machine's own
     * Docker configuration (`docker login`, credential helpers).
     */
    readonly credentials: Effect.Effect<RegistryCredentials | undefined, any, R>;
}
export interface ResolveContainerImageOptions {
    /** Logical resource id — keys the stable build-context directory. */
    id: string;
    /**
     * The props bag carrying the image source fields (`main` / `context` /
     * `image` plus their modifiers).
     */
    source: ImageSourceLike;
    /**
     * Target image platform.
     * @default "linux/amd64"
     */
    platform?: string;
    /**
     * Port the generated Dockerfile should `ENV PORT=` + `EXPOSE`
     * (`main` source only).
     */
    port?: number;
    /**
     * True when the resource was declared without an inline Effect impl —
     * `main` is then bundled as-is without the virtual-entry bootstrap.
     */
    isExternal?: boolean;
    /**
     * The virtual-entry bootstrap wrapped around `main` for Effect-native
     * programs: receives the resolved entry import path and returns the
     * generated entry module source.
     */
    bootstrap: (importPath: string) => string;
    /** Plan-status session used to emit build/push progress notes. */
    session: {
        note: (message: string) => Effect.Effect<void>;
    };
}
/**
 * Content hash for the sources whose identity is computable WITHOUT running
 * a bundler:
 *
 * - `context` — hash of the build-context directory + Dockerfile content +
 *   platform.
 * - `image` — hash of the image reference + platform (re-mirror only when
 *   the ref changes).
 * - `main` — `undefined`: the hash comes from the bundle output, so it is
 *   only known inside `resolve`.
 *
 * Providers use this in `diff` to surface content drift (files changed under
 * an unchanged `context` path) as an update.
 */
export declare const computeStaticSourceHash: (source: ImageSourceLike, platform?: string | undefined) => Effect.Effect<string | undefined, import("effect/PlatformError").PlatformError, FileSystem.FileSystem | Path.Path>;
/**
 * Init-time constructor for the image-source resolver. Resolves the services
 * that are only available at provider-layer construction (Docker, the
 * `.alchemy` directory, the rolldown virtual-entry plugin) and returns
 * `resolve` (build/mirror + push to an {@link ImageRegistryTarget}), `hash`,
 * and `watchMain`.
 */
export declare const makeContainerImageSource: Effect.Effect<{
    resolve: <R>(options: ResolveContainerImageOptions, target: ImageRegistryTarget<R>) => Effect.Effect<{
        imageUri: string;
        repositoryUri: string;
        codeHash: string;
    }, any, R | FileSystem.FileSystem | Path.Path | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage>;
    hash: (options: {
        source: ImageSourceLike;
        platform?: string;
        port?: number;
        isExternal?: boolean;
        bootstrap: (importPath: string) => string;
    }) => Effect.Effect<string | undefined, Bundle.BundleError | import("effect/PlatformError").PlatformError, FileSystem.FileSystem | Path.Path>;
    watchMain: (options: {
        source: BundledImageSource;
        isExternal?: boolean;
        bootstrap: (importPath: string) => string;
    }) => Effect.Effect<{
        inputOptions: rolldown.InputOptions;
        outputOptions: rolldown.OutputOptions;
        extra: Bundle.BundleConfig | undefined;
    }, import("effect/PlatformError").PlatformError, FileSystem.FileSystem | Path.Path>;
}, never, AlchemyContext | Docker | Path.Path>;
/** The resolver service returned by {@link makeContainerImageSource}. */
export interface ContainerImageSource extends Effect.Success<typeof makeContainerImageSource> {
}
//# sourceMappingURL=ImageSource.d.ts.map