/**
 * Renders a healthcheck `cmd` as the single string Docker's `--health-cmd`
 * flag takes. The flag always runs its value through the container's shell, so
 * the Docker API's exec form has to be flattened:
 *
 * - `"cmd"`: used as is.
 * - `["CMD-SHELL", "cmd"]`: the shell command, without the marker.
 * - `["CMD", "pg_isready", "-U", "app"]`: the arguments, each quoted so it
 *   reaches the program as one argument.
 * - `["NONE"]`: no command (the caller disables the healthcheck).
 * - any other array: joined with spaces and run in the shell, as before, so
 *   `["curl -f localhost || exit 1"]` keeps working.
 */
export declare const healthcheckCommand: (cmd: string[] | string) => string | undefined;
/** True when `cmd` is Docker's `["NONE"]` form, which disables the healthcheck. */
export declare const isHealthcheckDisabled: (cmd: string[] | string) => boolean;
//# sourceMappingURL=HealthcheckCommand.d.ts.map