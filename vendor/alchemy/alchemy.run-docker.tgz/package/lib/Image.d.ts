import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import { Docker } from "./Docker.ts";
import type { Providers } from "./Providers.ts";
import { type ImageRegistry } from "./Registry.ts";
export interface DockerBuildOptions {
    /**
     * Build context directory.
     *
     * @default Current working directory.
     */
    context?: string;
    /**
     * Dockerfile path, relative to the context unless absolute.
     *
     * @default "Dockerfile"
     */
    dockerfile?: string;
    /** Target platform, e.g. `"linux/amd64"`. */
    platform?: string;
    /** Docker build arguments. */
    args?: Record<string, string>;
    /** Multi-stage build target. */
    target?: string;
    /** Cache sources passed as `--cache-from`. */
    cacheFrom?: string[];
    /** Cache destinations passed as `--cache-to`. */
    cacheTo?: string[];
    /** Additional Docker build options. */
    options?: string[];
}
export interface ImageProps {
    /**
     * Repository/name for the built image.
     *
     * @default Generated from stack, stage, logical id, and instance id.
     */
    name?: string;
    /** Image tag. @default "latest" */
    tag?: string;
    /**
     * Registry credentials. The image is pushed to this registry (unless
     * `skipPush`), and the build itself authenticates with them, so private
     * base images and `type=registry` caches hosted there resolve without a
     * host `docker login`. Credentials already in `DOCKER_AUTH_CONFIG` for
     * other registries are kept. Build-time authentication needs Buildx 0.26+
     * (Docker Desktop 4.44+) or the legacy builder; older Buildx plugins ignore
     * it, so a private base image there still needs `docker login`.
     */
    registry?: ImageRegistry;
    /** Skip registry push even when `registry` is set. @default false */
    skipPush?: boolean;
    /** Docker context name or context resource. */
    context?: Docker.ContextRef;
    /** Docker build configuration. */
    build: DockerBuildOptions;
}
export interface Image extends Resource<"Docker.Image", ImageProps, {
    /** Image repository/name without tag. */
    name: string;
    /** Final image reference. Includes registry host when pushed there. */
    imageRef: string;
    /** Local image id after build/tag. */
    imageId: string;
    /** Registry digest after push when available. */
    repoDigest?: string;
    /** Tag used for the local image. */
    tag: string;
    /** Build timestamp in milliseconds since epoch. */
    builtAt: number;
}, never, Providers> {
}
/**
 * Builds, tags, and optionally pushes Docker images through the active Docker
 * context.
 *
 * This resource uses the Docker CLI and whatever daemon or remote context the
 * CLI is configured to target. It is separate from `Cloudflare.Container`;
 * registry image references are the boundary between Docker-managed images and
 * cloud container platforms.
 *
 * `Image` always builds from a Dockerfile. To pull (and optionally re-tag and
 * push) an existing registry image, use `Docker.RemoteImage`.
 *
 *
 * ### Building Images
 * **Example:** Build from a Dockerfile
 * ```typescript
 * const image = yield* Docker.Image("app", {
 *   name: "my-app",
 *   tag: "latest",
 *   build: {
 *     context: "./app",
 *     dockerfile: "Dockerfile",
 *     args: { NODE_ENV: "production" },
 *   },
 * });
 * ```
 *
 * ### Registry Push
 * **Example:** Push with Redacted credentials
 * ```typescript
 * const image = yield* Docker.Image("app", {
 *   name: "my-app",
 *   build: { context: "./app" },
 *   registry: {
 *     server: "ghcr.io",
 *     username: "octocat",
 *     password: Config.Redacted("GITHUB_TOKEN"),
 *   },
 * });
 * ```
 *
 * ### Private Base Images and Registry Caches
 * **Example:** Build FROM a private base image with a registry cache
 * ```typescript
 * // Dockerfile: FROM registry.example.com/base:v1
 * const image = yield* Docker.Image("app", {
 *   name: "registry.example.com/app",
 *   build: {
 *     context: "./app",
 *     cacheFrom: ["type=registry,ref=registry.example.com/app:buildcache"],
 *     cacheTo: ["type=registry,ref=registry.example.com/app:buildcache,mode=max"],
 *   },
 *   // Authenticates the base-image pull and cache import/export, then the push.
 *   registry: {
 *     server: "registry.example.com",
 *     username: "deploy",
 *     password: Config.Redacted("REGISTRY_PASSWORD"),
 *   },
 * });
 * ```
 *
 * ### Docker Context
 * **Example:** Build in a named Docker context
 * ```typescript
 * const image = yield* Docker.Image("app", {
 *   name: "my-app",
 *   context: "remote-build",
 *   build: { context: "./app" },
 * });
 * ```
 *
 * @resource
 * @product Image
 */
export declare const Image: import("alchemy/Resource").ResourceClass<Image>;
export declare const ImageProvider: () => import("effect/Layer").Layer<Provider.Provider<Image>, never, Docker | FileSystem.FileSystem | Path.Path | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage>;
//# sourceMappingURL=Image.d.ts.map