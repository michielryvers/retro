import * as Rpc from "effect/rpc/Rpc";
import * as Schema from "effect/Schema";
import type * as Aggregate from "./Aggregate.ts";
import type * as Event from "./Event.ts";
import type * as Read from "./Read.ts";
import type * as DomainStream from "./Stream.ts";
import type * as View from "./View.ts";
/**
 * The RPCs of the views and aggregates an Api exposes. Shared by the Api
 * (which serves them) and the platforms (which push their stream messages
 * over WebSockets), so both encode exactly the same wire values.
 *
 * @internal
 */
export declare const EnvelopeSchema: Schema.Struct<{
    readonly id: Schema.String;
    readonly stream: Schema.String;
    readonly seq: Schema.Number;
    readonly at: Schema.DateTimeUtc;
    readonly commandId: Schema.String;
}>;
/** Something an Api can expose for reading. */
export type Readable = View.Any | Aggregate.Any | DomainStream.Any;
export declare const nameOf: (entry: Readable) => string;
export declare const union: (members: ReadonlyArray<Schema.Top>) => Schema.Never | Schema.Union<readonly Schema.Top[]>;
/** The events a view emits: its declared events, or the events it applies. */
export declare const outputEvents: (view: View.Any) => ReadonlyArray<Event.Any>;
export interface ReadRpcs {
    /** `get` for views and aggregates; `peek` for streams. */
    readonly get: Rpc.Any;
    readonly watch: Rpc.Any;
    readonly events: Rpc.Any;
    readonly list?: Rpc.Any;
}
export declare const contractOf: (entry: Readable) => Read.AnyContract;
/** The RPCs of a view or aggregate exposed in an Api. */
export declare const readRpcs: (entry: Readable) => ReadRpcs;
//# sourceMappingURL=ReadRpcs.d.ts.map