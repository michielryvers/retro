import * as Context from "effect/Context";
import * as Layer from "effect/Layer";
import * as Aggregate from "./Aggregate.ts";
import * as Kernel from "./Kernel.ts";
import { type AggregateStore, Platform, type StreamStore, type ViewStore } from "./Platform.ts";
import type * as Policy from "./Policy.ts";
import * as Projection from "./Projection.ts";
import * as Saga from "./Saga.ts";
import type * as DomainStream from "./Stream.ts";
import * as Telemetry from "./Telemetry.ts";
import * as View from "./View.ts";
type Identifier<T> = T extends Context.Key<infer I, unknown> ? I : never;
declare const Internals_base: Context.ServiceClass<Internals, "alchemy/Domain/ModelInternals", {
    readonly kernel: Kernel.Kernel;
    readonly aggregates: ReadonlyMap<string, AggregateStore>;
    readonly views: ReadonlyMap<string, ViewStore>;
    readonly streams: ReadonlyMap<string, StreamStore>;
    /** The client of the aggregate that handles each command, by command tag. */
    readonly commands: ReadonlyMap<string, Aggregate.ClientImpl>;
    /** Each view's read API, by view name. */
    readonly viewHosts: ReadonlyMap<string, View.Host<unknown, Aggregate.Any, unknown>>;
    /** Each stream's API, by stream name. */
    readonly streamHosts: ReadonlyMap<string, DomainStream.Host<Aggregate.Any, unknown>>;
}>;
/**
 * Low-level access to a built Model's kernel and stores (story runner,
 * diagnostics).
 *
 * @internal
 */
export declare class Internals extends Internals_base {
}
/**
 * The entities that make up a Model.
 */
export interface Members<A extends ReadonlyArray<Aggregate.Any>, V extends ReadonlyArray<View.Any>, P extends ReadonlyArray<Policy.Any>, J extends ReadonlyArray<Projection.Any>, S extends ReadonlyArray<DomainStream.Any>, G extends ReadonlyArray<Saga.Any> = readonly []> {
    readonly aggregates: A;
    readonly views?: V;
    readonly policies?: P;
    readonly projections?: J;
    readonly streams?: S;
    readonly sagas?: G;
}
/**
 * The class type returned by {@link make}.
 *
 * `Provided` is every aggregate, view, stream and projection-progress service
 * the Model provides; `Policies` is every policy and projection whose
 * implementation `layer` requires.
 */
export interface ModelClass<Name extends string, Provided, Policies> {
    new (_: never): {};
    readonly kind: "Model";
    readonly modelName: Name;
    readonly definitions: Kernel.Definitions;
    /**
     * Host every entity on the ambient {@link Platform}. The policy and
     * projection Layers (`handlers`) are built after the aggregates, views and
     * streams exist, so a handler can resolve them while it is constructed.
     * `options` tune how it's hosted, such as what it records in traces.
     */
    layer<E = never, R = never>(handlers: Layer.Layer<Policies, E, R>, options?: LayerOptions): Layer.Layer<Provided | Internals, E, Platform | Exclude<R, Provided>>;
}
/**
 * Structural constraint satisfied by every Model class.
 */
export interface Any {
    readonly kind: "Model";
    readonly modelName: string;
    readonly definitions: Kernel.Definitions;
}
type ProvidedBy<A extends ReadonlyArray<Aggregate.Any>, V extends ReadonlyArray<View.Any>, J extends ReadonlyArray<Projection.Any>, S extends ReadonlyArray<DomainStream.Any>, G extends ReadonlyArray<Saga.Any>> = Identifier<A[number]> | Identifier<V[number]> | Identifier<S[number]> | Saga.Identifier<G[number]> | Projection.ProgressIdentifier<J[number]>;
/** How a model's `layer` hosts it: tuning that doesn't change what the model means. */
export interface LayerOptions {
    /** What the hosted model records in traces. See {@link Telemetry.Options}. */
    readonly telemetry?: Telemetry.Options;
}
/** Every implementation a model's `layer` requires: its policies, projections and sagas. */
type HandledBy<P extends ReadonlyArray<Policy.Any>, J extends ReadonlyArray<Projection.Any>, G extends ReadonlyArray<Saga.Any>> = Identifier<P[number]> | Identifier<J[number]> | Saga.ImplementationIdentifier<G[number]>;
/**
 * The aggregates, views and policies you host together. `layer(policies)`
 * builds them all on the Platform you provide, and provides each aggregate
 * and view as a service.
 *
 * ### Declaring and hosting a model
 * **Example:** In memory, with its policies and external systems
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 * import * as Layer from "effect/Layer";
 * import { Account } from "./Account.ts";
 * import { AccountSummary } from "./AccountSummary.ts";
 * import { Customer } from "./Customer.ts";
 * import { MainAccountProvisioning, MainAccountProvisioningLive } from "./MainAccountProvisioning.ts";
 *
 * export class Bank extends Domain.Model("Bank", {
 *   aggregates: [Account, Customer],
 *   views: [AccountSummary],
 *   policies: [MainAccountProvisioning],
 * }) {}
 *
 * export const BankInMemory = Bank.layer(MainAccountProvisioningLive).pipe(
 *   Layer.provide(Domain.InMemory),
 * );
 * ```
 *
 * @primitive
 */
export declare const make: <const Name extends string, const A extends ReadonlyArray<Aggregate.Any>, const V extends ReadonlyArray<View.Any> = readonly [], const P extends ReadonlyArray<Policy.Any> = readonly [], const J extends ReadonlyArray<Projection.Any> = readonly [], const S extends ReadonlyArray<DomainStream.Any> = readonly [], const G extends ReadonlyArray<Saga.Any> = readonly []>(name: Name, members: Members<A, V, P, J, S, G>) => ModelClass<Name, ProvidedBy<A, V, J, S, G>, HandledBy<P, J, G>>;
export {};
//# sourceMappingURL=Model.d.ts.map