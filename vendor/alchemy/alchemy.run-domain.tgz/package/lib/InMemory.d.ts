import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { WorkflowEngine } from "effect/workflow";
import { Platform } from "./Platform.ts";
/**
 * Options for {@link make}.
 */
export interface Options {
    /**
     * When `true`, deliveries queue until {@link Control.drain} is called and
     * policy runs are tracked so a caller can wait for quiescence. Used by the
     * story runner. Defaults to `false` (deliver in the background).
     */
    readonly manual?: boolean;
    /** Clock used to time-stamp commands. Defaults to `Date.now`. */
    readonly now?: () => number;
}
/**
 * Control surface of an in-memory platform.
 */
export interface Control {
    /**
     * Send due scheduled commands, then deliver every queued delivery (and
     * those it produces) until the queue is empty.
     */
    readonly drain: Effect.Effect<void>;
    /** `true` when nothing is queued and every running policy is suspended. */
    readonly idle: Effect.Effect<boolean>;
    /** Mark the current policy run as suspended while `effect` runs (story external systems). */
    readonly suspended: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
    /** Defects raised by policy and projection runs. */
    readonly failures: ReadonlyArray<unknown>;
    /** Saga runs that ended with a defect, in the order they died. */
    readonly deaths: ReadonlyArray<{
        readonly saga: string;
        readonly executionId: string;
        readonly defect: unknown;
    }>;
}
/**
 * Build an in-memory platform and its control surface.
 */
export declare const make: (options?: Options) => {
    readonly layer: Layer.Layer<Platform | WorkflowEngine.WorkflowEngine>;
    readonly control: Control;
};
/**
 * Host a domain model in the current process: aggregates, views and policies,
 * with nothing to deploy. Use it in tests and single-process apps; swap it
 * for `DomainCloudflare.DurableObjects` and nothing else changes.
 *
 * ### Hosting in memory
 * **Example:** A model with its policies
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 * import * as Layer from "effect/Layer";
 * import { Bank, BankPolicies } from "./Bank.ts";
 *
 * export const BankInMemory = Bank.layer(BankPolicies).pipe(Layer.provide(Domain.InMemory));
 * ```
 *
 * @layer
 * @provides Domain.Platform
 * @provides WorkflowEngine
 */
export declare const InMemory: Layer.Layer<Platform | WorkflowEngine.WorkflowEngine>;
/** Is a stream write's origin after the last one applied? @internal */
export declare const isAfter: (origin: readonly [number, number], last: readonly [number, number]) => boolean;
/** The later of two sets of per-source checkpoints. @internal */
export declare const mergeCheckpoints: (a: Readonly<Record<string, number>>, b: Readonly<Record<string, number>>) => Record<string, number>;
//# sourceMappingURL=InMemory.d.ts.map