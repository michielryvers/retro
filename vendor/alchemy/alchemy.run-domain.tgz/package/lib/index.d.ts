/**
 * Model a domain from commands, events and rejections; aggregates that decide;
 * views that fold; and policies that react. Expose it to clients as an Api,
 * and host it on whichever Platform Layer is provided.
 *
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 *
 * export class MoneyDeposited extends Domain.Event("MoneyDeposited", {
 *   amount: Cents,
 *   balanceAfter: Cents,
 * }) {}
 * ```
 *
 * Every building block is `Domain.<Noun>(...)`, and its types live on the
 * same name: `Domain.Event.Any`, `Domain.Aggregate.StateOf<typeof Account>`.
 * Stories (given / when / then specifications) are in `@alchemy.run/domain/Story`;
 * the Cloudflare platform is in `@alchemy.run/cloudflare/Domain`.
 */
import * as AggregateModule from "./Aggregate.ts";
import * as ApiModule from "./Api.ts";
import * as CommandModule from "./Command.ts";
import * as EventModule from "./Event.ts";
import * as ExternalSystemModule from "./ExternalSystem.ts";
import * as ModelModule from "./Model.ts";
import * as PolicyModule from "./Policy.ts";
import * as ProjectionModule from "./Projection.ts";
import * as RejectionModule from "./Rejection.ts";
import * as RequestContextModule from "./RequestContext.ts";
import * as SagaModule from "./Saga.ts";
import * as StreamModule from "./Stream.ts";
import * as ViewModule from "./View.ts";
export declare namespace Event {
    /** Any Event class. */
    type Any = EventModule.Any;
    /** An event value: its `_tag` plus its data. */
    type Instance<Tag extends string, F extends EventModule.Fields> = EventModule.Instance<Tag, F>;
}
/** A fact the domain recorded. See {@link EventModule.make}. */
export declare const Event: typeof EventModule.make;
export declare namespace Command {
    /** Any Command class. */
    type Any = CommandModule.Any;
    type Instance<Tag extends string, F extends EventModule.Fields> = CommandModule.Instance<Tag, F>;
    /** The services a command's middleware provides to `decide`. */
    type ContextOf<C extends CommandModule.Any> = CommandModule.ContextOf<C>;
}
/** A request to change one aggregate. See {@link CommandModule.make}. */
export declare const Command: typeof CommandModule.make;
export declare namespace Rejection {
    /** Any Rejection class. */
    type Any = RejectionModule.Any;
    type Instance<Tag extends string, F extends EventModule.Fields> = RejectionModule.Instance<Tag, F>;
}
/** A typed reason a command or read was refused. See {@link RejectionModule.make}. */
export declare const Rejection: typeof RejectionModule.make;
export declare namespace Aggregate {
    /** Any Aggregate class. */
    type Any = AggregateModule.Any;
    type IdOf<A extends AggregateModule.Any> = AggregateModule.IdOf<A>;
    type StateOf<A extends AggregateModule.Any> = AggregateModule.StateOf<A>;
    type EventOf<A extends AggregateModule.Any> = AggregateModule.EventOf<A>;
    type CommandOf<A extends AggregateModule.Any> = AggregateModule.CommandOf<A>;
    /** A reference to one instance of an aggregate. */
    type Ref<A extends AggregateModule.Any = AggregateModule.Any> = AggregateModule.Ref<A>;
    /** What an accepted command returns: its stream, version, events and reply. */
    type Receipt<Ev = unknown, Reply = unknown> = AggregateModule.Receipt<Ev, Reply>;
    /** Where an event sits: its instance, stream, sequence, time and command. */
    type Envelope<Id = string> = AggregateModule.Envelope<Id>;
    type SendOptions = AggregateModule.SendOptions;
    type ScheduleOptions = AggregateModule.ScheduleOptions;
    /** The instance type of a class. */
    type Inst<C> = AggregateModule.Inst<C>;
}
/** A consistency boundary that decides commands. See {@link AggregateModule.make}. */
export declare const Aggregate: typeof AggregateModule.make;
export declare namespace View {
    /** Any View class. */
    type Any = ViewModule.Any;
    type StateOf<V extends ViewModule.Any> = ViewModule.StateOf<V>;
    type EventOf<V extends ViewModule.Any> = ViewModule.EventOf<V>;
    type KeyOf<V extends ViewModule.Any> = ViewModule.KeyOf<V>;
    /** An event a view emitted, with its state after it. */
    type Entry<S, E, Id = string> = ViewModule.Entry<S, E, Id>;
    type Page<E> = ViewModule.Page<E>;
}
/** A read model folded from events, per key. See {@link ViewModule.make}. */
export declare const View: typeof ViewModule.make;
/** A view read waited longer than allowed. */
export declare const WaitTimeout: typeof ViewModule.WaitTimeout;
export type WaitTimeout = ViewModule.WaitTimeout;
/** A view did not catch up to a write in time. */
export declare const ConsistencyTimeout: typeof ViewModule.ConsistencyTimeout;
export type ConsistencyTimeout = ViewModule.ConsistencyTimeout;
export declare namespace Policy {
    /** Any Policy class. */
    type Any = PolicyModule.Any;
    /** What a policy reacts to: the event, its source and the source's state. */
    type Trigger<From extends PolicyModule.From, E> = PolicyModule.Trigger<From, E>;
}
/** A standing business rule: on an event, decide what to do next. See {@link PolicyModule.make}. */
export declare const Policy: typeof PolicyModule.make;
export declare namespace Saga {
    /** Any Saga class. */
    type Any = SagaModule.Any;
    /** Where a saga run is. */
    type Status<A, E> = SagaModule.Status<A, E>;
    /** A saga's client. */
    type Client<Key, Input, A, E> = SagaModule.Client<Key, Input, A, E>;
}
/** A process that spans aggregates and takes time, run as an Effect workflow. See {@link SagaModule.make}. */
export declare const Saga: typeof SagaModule.make;
export declare namespace Projection {
    /** Any Projection class. */
    type Any = ProjectionModule.Any;
    /** One input a projection's handler receives. */
    type Input<Key extends AggregateModule.Any, S, E> = ProjectionModule.Input<Key, S, E>;
    /** How a projection's Layer tunes it. */
    type Options = ProjectionModule.Options;
}
/** Consumes events into a store you own, in order per key; replayable, never sends commands. See {@link ProjectionModule.make}. */
export declare const Projection: typeof ProjectionModule.make;
export declare namespace Stream {
    /** Any Stream class. */
    type Any = StreamModule.Any;
    type EventOf<S extends StreamModule.Any> = StreamModule.EventOf<S>;
    type KeyOf<S extends StreamModule.Any> = StreamModule.KeyOf<S>;
    /** One entry of a stream key. */
    type Entry<E, Id = string> = StreamModule.Entry<E, Id>;
}
/** A keyed, append-only, replayable log a projection writes and clients read. See {@link StreamModule.make}. */
export declare const Stream: typeof StreamModule.make;
export declare namespace ExternalSystem {
    /** Any ExternalSystem class. */
    type Any = ExternalSystemModule.Any;
    type Op<Args = unknown, Success = unknown> = ExternalSystemModule.Op<Args, Success>;
}
/** An outside system the model calls, as an Effect service. See {@link ExternalSystemModule.make}. */
export declare const ExternalSystem: typeof ExternalSystemModule.make;
export declare namespace Api {
    /** What an Api may expose: commands, views, and aggregates with a `read` contract. */
    type Entry = ApiModule.Entry;
    /** The typed client of an Api. */
    type Client<E extends ApiModule.Entry> = ApiModule.ApiClient<E>;
    /** Type-level identity of an Api's client service, e.g. `Domain.Api.ClientKey<"BankApi">`. */
    type ClientKey<Name extends string> = ApiModule.ClientKey<Name>;
    type ViewClient<V extends ViewModule.Any> = ApiModule.ViewClient<V>;
    type StreamClient<S extends StreamModule.Any> = ApiModule.StreamClient<S>;
    type AggregateClient<A extends AggregateModule.Any> = ApiModule.AggregateClient<A>;
    /** Everything a read can fail with. */
    type ReadError<D> = ApiModule.ReadError<D>;
}
/** The public surface of a domain for one client. See {@link ApiModule.make}. */
export declare const Api: typeof ApiModule.make;
/** An Api client protocol: everything over HTTP, live reads as streamed responses. */
export declare const protocolHttp: typeof ApiModule.protocolHttp;
/** An Api client protocol: calls over HTTP, each live read a WebSocket to the object that owns it. */
export declare const protocolWebSocket: typeof ApiModule.protocolWebSocket;
export declare namespace Model {
    /** Any Model class. */
    type Any = ModelModule.Any;
}
/** The aggregates, views, policies, projections and streams hosted together. See {@link ModelModule.make}. */
export declare const Model: typeof ModelModule.make;
/** A service middleware provides to a request, carried into the domain. See {@link RequestContextModule.make}. */
export declare const RequestContext: typeof RequestContextModule.make;
export type { Filter, OrderBy } from "./Filter.ts";
export { InMemory } from "./InMemory.ts";
export type * as Middleware from "./Middleware.ts";
export { Platform } from "./Platform.ts";
export type * as Read from "./Read.ts";
/** Trace attributes, hosting options and the metrics a model records. */
export * as Telemetry from "./Telemetry.ts";
//# sourceMappingURL=index.d.ts.map