import type { HttpEffect } from "alchemy/Http";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type * as Headers from "effect/http/Headers";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import * as Rpc from "effect/rpc/Rpc";
import * as RpcClient from "effect/rpc/RpcClient";
import * as RpcClientError from "effect/rpc/RpcClientError";
import * as RpcGroup from "effect/rpc/RpcGroup";
import type * as RpcMiddleware from "effect/rpc/RpcMiddleware";
import type * as Scope from "effect/Scope";
import * as Socket from "effect/socket/Socket";
import * as Stream from "effect/Stream";
import type * as Aggregate from "./Aggregate.ts";
import * as Command from "./Command.ts";
import { type Filter } from "./Filter.ts";
import * as Middleware from "./Middleware.ts";
import * as Model from "./Model.ts";
import type * as Read from "./Read.ts";
import type * as DomainStream from "./Stream.ts";
import type * as View from "./View.ts";
/**
 * What an Api exposes: commands (writes); views, streams, and aggregates that
 * declare a `read` contract (reads).
 */
export type Entry = Command.Any | View.Any | Aggregate.Any | DomainStream.Any;
type Commands<E extends Entry> = Extract<E, Command.Any>;
type Views<E extends Entry> = Extract<E, View.Any>;
type Streams<E extends Entry> = Extract<E, DomainStream.Any>;
type Aggregates<E extends Entry> = Exclude<E, Command.Any | View.Any | DomainStream.Any>;
type ContractOf<D> = D extends Read.AnyContract ? D : never;
type RejectsOf<D> = NonNullable<ContractOf<D>["rejects"]>[number];
type MiddlewareOf<D> = NonNullable<ContractOf<D>["middleware"]>;
/** Everything a read can fail with: the declared rejections, the middleware's errors, transport. */
export type ReadError<D> = Aggregate.Inst<RejectsOf<D>> | Middleware.Errors<MiddlewareOf<D>> | RpcClientError.RpcClientError;
interface CallOptions {
    readonly headers?: Headers.Input;
}
/** The typed client of a view exposed in an Api. */
export interface ViewClient<V extends View.Any> {
    /** The key's current state (`null` if it does not exist or the filter excludes it). */
    readonly get: (key: Aggregate.IdOf<View.KeyOf<V>>, options?: CallOptions & {
        /** Wait until the view has applied this write (a command's `stream` and `version`). */
        readonly atLeast?: {
            readonly stream: string;
            readonly version: number;
        };
        readonly where?: Filter<View.StateOf<V>>;
    }) => Effect.Effect<View.StateOf<V> | null, ReadError<V["definition"]>>;
    /** The key's state, then every change. Ends with a rejection when `validate` stops allowing it. */
    readonly watch: (key: Aggregate.IdOf<View.KeyOf<V>>, options?: CallOptions & {
        readonly where?: Filter<View.StateOf<V>>;
    }) => Stream.Stream<View.StateOf<V> | null, ReadError<V["definition"]>>;
    /** The events the key emitted, each with the state after it: history, then live. */
    readonly events: (key: Aggregate.IdOf<View.KeyOf<V>>, options?: CallOptions & {
        readonly after?: string;
        readonly where?: Filter<View.EventOf<V>>;
    }) => Stream.Stream<View.Entry<View.StateOf<V>, View.EventOf<V>, Aggregate.IdOf<View.KeyOf<V>>>, ReadError<V["definition"]>>;
    /** A page of the key's emitted events. */
    readonly list: (key: Aggregate.IdOf<View.KeyOf<V>>, options?: CallOptions & {
        readonly where?: Filter<View.EventOf<V>>;
        readonly order?: "asc" | "desc";
        readonly take?: number;
        readonly after?: string;
    }) => Effect.Effect<View.Page<View.Entry<View.StateOf<V>, View.EventOf<V>, Aggregate.IdOf<View.KeyOf<V>>>>, ReadError<V["definition"]>>;
}
/** The typed client of a stream exposed in an Api. */
export interface StreamClient<S extends DomainStream.Any> {
    /** The key's latest entry, or `null` if nothing was appended. */
    readonly peek: (key: Aggregate.IdOf<DomainStream.KeyOf<S>>, options?: CallOptions & {
        /** Wait until the stream's writer has handled this write (a command's `stream` and `version`). */
        readonly atLeast?: {
            readonly stream: string;
            readonly version: number;
        };
    }) => Effect.Effect<DomainStream.Entry<DomainStream.EventOf<S>, Aggregate.IdOf<DomainStream.KeyOf<S>>> | null, ReadError<S["definition"]>>;
    /** The key's latest entry, then each new one. Ends with a rejection when `validate` stops allowing it. */
    readonly watch: (key: Aggregate.IdOf<DomainStream.KeyOf<S>>, options?: CallOptions) => Stream.Stream<DomainStream.Entry<DomainStream.EventOf<S>, Aggregate.IdOf<DomainStream.KeyOf<S>>> | null, ReadError<S["definition"]>>;
    /** The key's entries from `after` (an entry `seq`), then live ones. */
    readonly events: (key: Aggregate.IdOf<DomainStream.KeyOf<S>>, options?: CallOptions & {
        readonly after?: number;
        readonly where?: Filter<DomainStream.EventOf<S>>;
    }) => Stream.Stream<DomainStream.Entry<DomainStream.EventOf<S>, Aggregate.IdOf<DomainStream.KeyOf<S>>>, ReadError<S["definition"]>>;
    /** A page of the key's entries. */
    readonly list: (key: Aggregate.IdOf<DomainStream.KeyOf<S>>, options?: CallOptions & {
        readonly where?: Filter<DomainStream.EventOf<S>>;
        readonly order?: "asc" | "desc";
        readonly take?: number;
        readonly after?: string;
    }) => Effect.Effect<View.Page<DomainStream.Entry<DomainStream.EventOf<S>, Aggregate.IdOf<DomainStream.KeyOf<S>>>>, ReadError<S["definition"]>>;
}
/** A committed event of an aggregate, as a client receives it. */
export interface Recorded<E, Id> {
    readonly event: E;
    readonly envelope: Aggregate.Envelope<Id>;
}
/** The typed client of an aggregate exposed in an Api (through its `read` contract). */
export interface AggregateClient<A extends Aggregate.Any> {
    /** The instance's current state. */
    readonly get: (key: Aggregate.IdOf<A>, options?: CallOptions) => Effect.Effect<Aggregate.StateOf<A>, ReadError<A["definition"]["read"]>>;
    /** The instance's state, then its state after every commit. */
    readonly watch: (key: Aggregate.IdOf<A>, options?: CallOptions) => Stream.Stream<Aggregate.StateOf<A>, ReadError<A["definition"]["read"]>>;
    /** The instance's committed events: history from `after` (a `seq`), then live. */
    readonly events: (key: Aggregate.IdOf<A>, options?: CallOptions & {
        readonly after?: number;
    }) => Stream.Stream<Recorded<Aggregate.EventOf<A>, Aggregate.IdOf<A>>, ReadError<A["definition"]["read"]>>;
}
/**
 * The typed client of an Api: commands as methods (`bank.WithdrawMoney(...)`),
 * views and aggregates as namespaces (`bank.AccountSummary.watch(...)`).
 */
export type ApiClient<E extends Entry> = RpcClient.RpcClient<Commands<E>["rpc"], RpcClientError.RpcClientError> & {
    readonly [V in Views<E> as V["viewName"]]: ViewClient<V>;
} & {
    readonly [S in Streams<E> as S["streamName"]]: StreamClient<S>;
} & {
    readonly [A in Aggregates<E> as A["aggregateName"]]: AggregateClient<A>;
};
/** Type-level identity of an Api's client service. */
export interface ClientKey<Name extends string> {
    readonly "~alchemy/Domain/Api/Client": Name;
}
/** What `yield* MyApi` gives a Worker: the Api served over HTTP. */
export interface ApiServer {
    /** Use as the Worker's `fetch`. Commands and reads over HTTP; live reads over WebSockets. */
    readonly fetch: HttpEffect;
}
/**
 * The class type returned by {@link make}. The class is itself an Effect:
 * `yield* MyApi` serves it, requiring the hosted Domain and the Layers of every
 * middleware its entries declare.
 */
export interface ApiClass<Name extends string, Entries extends ReadonlyArray<Entry>> extends Effect.Effect<ApiServer, never, Model.Internals | MiddlewareServices<Entries>> {
    new (_: never): {};
    readonly kind: "Api";
    readonly apiName: Name;
    /** The commands, views and aggregates this Api exposes. */
    readonly entries: Entries;
    /** The underlying Effect RPC group. */
    readonly group: RpcGroup.RpcGroup<Rpc.Any>;
    /**
     * Apply an `RpcMiddleware` to every entry (logging, rate limits). Middleware
     * that provides services, such as a session, is declared by each command,
     * view or aggregate instead, so what they may read stays typed.
     */
    middleware<M extends RpcMiddleware.AnyService>(middleware: [RpcMiddleware.Provides<M["Identifier"]>] extends [never] ? M : "Middleware that provides services is declared on each command, view or aggregate"): ApiClass<Name, Entries>;
    /** A typed client. Provide a protocol: {@link protocolWebSocket} or {@link protocolHttp}. */
    readonly client: Effect.Effect<ApiClient<Entries[number]>, never, Scope.Scope | RpcClient.Protocol | MiddlewareClients<Entries>>;
    /** The client as a service, for code that uses it without owning the connection. */
    readonly Client: Context.Service<ClientKey<Name>, ApiClient<Entries[number]>>;
    /** Build {@link Client} for the life of the Layer, over the protocol provided to it. */
    readonly layerClient: Layer.Layer<ClientKey<Name>, never, RpcClient.Protocol | MiddlewareClients<Entries>>;
    /**
     * An in-process client wired straight to the handlers, for tests. Server
     * middleware runs, so principals are provided by swapping middleware Layers.
     */
    readonly testClient: Effect.Effect<ApiClient<Entries[number]>, never, Scope.Scope | Model.Internals | MiddlewareServices<Entries> | MiddlewareClients<Entries>>;
}
type EntryMiddleware<E> = E extends Command.Any ? E["middleware"][number] : E extends View.Any | DomainStream.Any ? NonNullable<E["definition"]["middleware"]>[number] : E extends Aggregate.Any ? NonNullable<NonNullable<E["definition"]["read"]>["middleware"]>[number] : never;
/** The middleware services the server needs for every entry. */
type MiddlewareServices<Entries extends ReadonlyArray<Entry>> = EntryMiddleware<Entries[number]> extends infer M ? M extends RpcMiddleware.AnyService ? M["Identifier"] : never : never;
/** The client-side middleware every entry needs (e.g. attaching a session token). */
type MiddlewareClients<Entries extends ReadonlyArray<Entry>> = EntryMiddleware<Entries[number]> extends infer M ? M extends RpcMiddleware.AnyService ? M extends {
    readonly requiredForClient: true;
} ? RpcMiddleware.ForClient<M["Identifier"]> : never : never : never;
/**
 * The public surface of a domain for one kind of client: the commands it may
 * send, and the views and aggregates (with a `read` contract) it may read.
 * Nothing in an Api needs a handler. The class is an Effect: `yield* MyApi`
 * gives a Worker its `fetch`. Call it with a typed client over
 * `Domain.protocolWebSocket` or `Domain.protocolHttp`.
 *
 * ### Declaring an Api
 * **Example:** What customers may reach
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 * import { Account, DepositMoney, WithdrawMoney } from "./Account.ts";
 * import { AccountSummary } from "./AccountSummary.ts";
 *
 * export class CustomerApi extends Domain.Api(
 *   "CustomerApi",
 *   DepositMoney,
 *   WithdrawMoney,
 *   Account,
 *   AccountSummary,
 * ) {}
 * ```
 *
 * ### Serving it from a Worker
 * **Example:** The Api as a Worker's fetch
 * ```typescript
 * import * as Cloudflare from "@alchemy.run/cloudflare";
 * import * as DomainCloudflare from "@alchemy.run/cloudflare/Domain";
 * import * as Effect from "effect/Effect";
 * import * as Layer from "effect/Layer";
 * import { Bank, BankPolicies } from "./Bank.ts";
 * import { CustomerApi } from "./CustomerApi.ts";
 * import { SessionLive } from "./Session.ts";
 *
 * const BankLive = SessionLive.pipe(
 *   Layer.provideMerge(Bank.layer(BankPolicies)),
 *   Layer.provide(DomainCloudflare.DurableObjects),
 * );
 *
 * export default class BankWorker extends Cloudflare.Worker<BankWorker>()(
 *   "BankWorker",
 *   { main: import.meta.url },
 *   Effect.gen(function* () {
 *     const api = yield* CustomerApi;
 *     return { fetch: api.fetch };
 *   }).pipe(Effect.provide(BankLive)),
 * ) {}
 * ```
 *
 * ### Calling it
 * `Domain.protocolWebSocket` sends commands, `get` and `list` over HTTP, and
 * opens a WebSocket for each `watch` and `events`, pushed by the object that
 * owns the key. `Domain.protocolHttp` sends everything over HTTP.
 *
 * **Example:** A typed client
 * ```typescript
 * const bank = yield* CustomerApi.client;
 * const { reply } = yield* bank.DepositMoney({ target: accountId, amount: 1_000 });
 * const summary = yield* bank.AccountSummary.get(accountId);
 * yield* bank.AccountSummary.watch(accountId).pipe(
 *   Stream.runForEach((s) => Effect.log(s?.balance)),
 * );
 * ```
 *
 * @primitive
 */
export declare const make: <const Name extends string, const Entries extends ReadonlyArray<Entry>>(name: Name, ...entries: Entries) => ApiClass<Name, Entries>;
/**
 * The HTTP protocol for an Api client (NDJSON, so streams work). Live reads
 * are streamed responses, which the platform feeds by polling the key; use
 * {@link protocolWebSocket} to have them pushed instead. Requires an
 * `HttpClient`, e.g. `FetchHttpClient.layer`.
 */
export declare const protocolHttp: (url: string) => Layer.Layer<RpcClient.Protocol, never, HttpClient.HttpClient>;
/**
 * The WebSocket protocol for an Api client. Calls (commands, `get`, `list`)
 * go over HTTP like {@link protocolHttp}; every live read (`watch`,
 * `events`) opens its own WebSocket, which the Api hands to the object that
 * owns the key (on Cloudflare, its Durable Object). Each commit is pushed
 * down the socket, so nothing polls and the object hibernates in between. A
 * dropped socket reconnects and resumes after the last value it delivered.
 *
 * A browser cannot set headers on a WebSocket, and a URL ends up in logs,
 * so headers client middleware attaches apply to calls only. A live read
 * authenticates with what its upgrade request carries: in a browser, the
 * cookies of the Api's origin, so serve the app and the Api from one origin
 * and keep sessions in an `HttpOnly`, `SameSite` cookie. Requires an
 * `HttpClient` and a `Socket.WebSocketConstructor`
 * (`Socket.layerWebSocketConstructorGlobal` in browsers and Workers).
 *
 * **Example:** Watching a view over a WebSocket
 * ```typescript
 * const BankConnection = CustomerApi.layerClient.pipe(
 *   Layer.provide(Domain.protocolWebSocket("https://bank.example.com/api")),
 *   Layer.provide(Layer.mergeAll(FetchHttpClient.layer, Socket.layerWebSocketConstructorGlobal)),
 * );
 * ```
 */
export declare const protocolWebSocket: (url: string) => Layer.Layer<RpcClient.Protocol, never, HttpClient.HttpClient | Socket.WebSocketConstructor>;
export {};
//# sourceMappingURL=Api.d.ts.map