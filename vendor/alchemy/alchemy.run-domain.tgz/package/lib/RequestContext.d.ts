import * as EffectContext from "effect/Context";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
/** The JSON form of a request's context, by service key. */
export type Json = Readonly<Record<string, unknown>>;
/**
 * The class type returned by {@link make}.
 */
export interface RequestContextClass<Self, Key extends string, S extends Schema.Top> extends EffectContext.ServiceClass<Self, Key, S["Type"]> {
    /** Encodes the value so it can travel with a request into the domain. */
    readonly schema: S;
}
/**
 * A service middleware provides to a request, such as the current actor. It
 * belongs to the request: a command carries it to its aggregate's `decide`,
 * and a read carries it to `validate`. Both may run elsewhere, such as in a
 * Durable Object, so it has a schema. Policies provide it themselves when
 * they send commands.
 *
 * ### Declaring a request context
 * **Example:** The current actor
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 * import * as Schema from "effect/Schema";
 *
 * export class CurrentActor extends Domain.RequestContext<CurrentActor>()(
 *   "Bank/CurrentActor",
 *   Schema.Struct({ customerId: Schema.String }),
 * ) {}
 * ```
 *
 * ### Providing it from middleware
 * **Example:** A session middleware that provides it
 * ```typescript
 * import * as RpcMiddleware from "effect/rpc/RpcMiddleware";
 * import * as Schema from "effect/Schema";
 * import { CurrentActor } from "./CurrentActor.ts";
 *
 * export class Unauthorized extends Schema.TaggedError<Unauthorized>()("Unauthorized", {}) {}
 *
 * export class Session extends RpcMiddleware.Service<Session, { provides: CurrentActor }>()(
 *   "Bank/Session",
 *   { error: Unauthorized },
 * ) {}
 * ```
 *
 * @primitive
 */
export declare const make: <Self>() => <const Key extends string, S extends Schema.Top>(key: Key, schema: S) => RequestContextClass<Self, Key, S>;
/**
 * Encode every request context service present in the current fiber.
 *
 * @internal
 */
export declare const capture: Effect.Effect<Json>;
/**
 * Decode a request's context back into services, for `decide` or `validate`.
 *
 * @internal
 */
export declare const restore: (json: Json) => EffectContext.Context<never>;
//# sourceMappingURL=RequestContext.d.ts.map