import * as Cause from "effect/Cause";
import * as Effect from "effect/Effect";
import * as Aggregate from "./Aggregate.ts";
import type { Accepted, AggregateKit, Delivery, EnvelopeJson, Json, PolicyKit, ReceiptJson, StreamEntry, ViewEntry, ViewKit } from "./Platform.ts";
import type * as Policy from "./Policy.ts";
import type * as Projection from "./Projection.ts";
import type * as DomainStream from "./Stream.ts";
import * as Telemetry from "./Telemetry.ts";
import type * as View from "./View.ts";
/**
 * The entities of a Domain.
 */
export interface Definitions {
    readonly aggregates: ReadonlyArray<Aggregate.Any>;
    readonly views: ReadonlyArray<View.Any>;
    readonly policies: ReadonlyArray<Policy.Any>;
    readonly projections: ReadonlyArray<Projection.Any>;
    readonly streams: ReadonlyArray<DomainStream.Any>;
}
/**
 * What a projection input carries for `Stream.append`, out of sight of the
 * handler's types: who is writing, where in its input log, and the source
 * event being handled. Appends count up per input, so a re-run of the same
 * input makes exactly the same writes.
 *
 * @internal
 */
export declare const InputMeta: unique symbol;
/** @internal */
export interface InputMetaValue {
    readonly projection: string;
    readonly key: string;
    readonly position: number;
    readonly source: string;
    readonly sourceSeq: number;
    readonly at: number;
    readonly commandId: string;
    /** Appends made for this input so far in this run. */
    appends: number;
}
declare const DefinitionError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Cause.YieldableError & {
    readonly _tag: "DefinitionError";
} & Readonly<A>;
/**
 * A domain definition error (duplicate tag, missing `keyOf`, …), raised while
 * the kernel is built.
 */
export declare class DefinitionError extends DefinitionError_base<{
    readonly message: string;
}> {
    constructor(message: string);
}
/** @internal */
export declare const encodeEnvelope: (envelope: Aggregate.Envelope, trace?: Telemetry.TraceJson) => EnvelopeJson;
/** @internal */
export declare const decodeEnvelope: (json: EnvelopeJson) => Aggregate.Envelope;
/**
 * The pure semantics shared by every platform: decide, evolve, reply,
 * routing and view application, plus every codec.
 */
export interface Kernel {
    readonly aggregateKit: (aggregate: Aggregate.Any, deliver: (d: Delivery) => Effect.Effect<void>) => Omit<AggregateKit, "push">;
    readonly viewKit: (view: View.Any, deliver: (d: Delivery) => Effect.Effect<void>) => Omit<ViewKit, "push">;
    readonly policyKit: (policy: Policy.Any, handler: Policy.Handler<unknown>) => PolicyKit;
    /** Decode a run of a projection key's input log into handler inputs. */
    readonly projectionInputs: (projection: Projection.Any, key: string, batch: ReadonlyArray<Accepted>) => ReadonlyArray<unknown>;
    /** The keys of a projection an aggregate's committed event is routed to (empty if it is not consumed). */
    readonly projectionKeys: (projection: Projection.Any, aggregate: string, id: string, event: {
        readonly _tag: string;
    }, seq: number) => ReadonlyArray<string>;
    /** The projection that writes a stream, if any. */
    readonly writerOf: (stream: DomainStream.Any) => Projection.Any | undefined;
    readonly decodeStreamEntry: (entry: StreamEntry) => DomainStream.Entry<unknown, string>;
    readonly encodeCommand: (aggregate: Aggregate.Any, command: {
        readonly _tag: string;
    }) => Json;
    readonly decodeRejection: (aggregate: Aggregate.Any, json: Json) => unknown;
    readonly decodeReceipt: (aggregate: Aggregate.Any, commandTag: string, json: ReceiptJson) => Aggregate.Receipt;
    readonly decodeState: (aggregate: Aggregate.Any, json: Json | null) => unknown;
    readonly decodeViewState: (view: View.Any, json: Json) => unknown;
    readonly decodeViewEntry: (view: View.Any, entry: ViewEntry) => View.Entry<unknown, unknown>;
    readonly decodeEvent: (json: Json) => unknown;
    readonly encodeEvent: (event: {
        readonly _tag: string;
    }) => Json;
}
/**
 * Build the kernel for a set of definitions. Validates tags and routing.
 */
export declare const make: (definitions: Definitions, telemetry?: Telemetry.Resolved) => Kernel;
export {};
//# sourceMappingURL=Kernel.d.ts.map