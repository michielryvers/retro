/**
 * SigV4 request signing (header `Authorization` and query-string presigning).
 *
 * Effect-native port of `aws4fetch`'s `AwsV4Signer` (MIT, Michael Hart),
 * preserving its canonicalisation rules byte for byte: header/path/query
 * encoding, the unsignable-header set, S3's UNSIGNED-PAYLOAD defaults,
 * duplicate-query-key handling, the derived-key cache, and service/region
 * guessing from the host when they are not given.
 */
import * as CoreCrypto from "@distilled.cloud/core/crypto";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Redacted from "effect/Redacted";
export type SignableBody = string | ArrayBuffer | ArrayBufferView;
export interface SignOptions {
    /** HTTP method. Defaults to `POST` when a body is present, else `GET`. */
    readonly method?: string;
    /** Absolute URL to sign. */
    readonly url: string;
    /** Request headers. Keys are case-insensitive; `Host` is derived from the URL. */
    readonly headers?: Record<string, string>;
    /**
     * Request body used for the payload hash. Omit for UNSIGNED-PAYLOAD (set the
     * `X-Amz-Content-Sha256` header yourself) or for bodiless requests.
     */
    readonly body?: SignableBody;
    /** Public half of the key pair; it is written into the signed request. */
    readonly accessKeyId: string;
    readonly secretAccessKey: Redacted.Redacted<string>;
    readonly sessionToken?: Redacted.Redacted<string> | undefined;
    /** SigV4 signing name (e.g. `s3`, `execute-api`). {@link guessScope} fills it from the host. */
    readonly service: string;
    /** SigV4 signing region. {@link guessScope} fills it from the host. */
    readonly region: string;
    /** Fixed `YYYYMMDDTHHMMSSZ` signing time; defaults to now. */
    readonly datetime?: string;
    /** Sign into the query string (presigned URL) instead of headers. */
    readonly signQuery?: boolean;
    /** Include the normally unsignable headers (content-type, range, ...). */
    readonly allHeaders?: boolean;
    /**
     * Send and sign the body's SHA-256 as `X-Amz-Content-Sha256`, so services
     * signing as `s3` do not default to UNSIGNED-PAYLOAD.
     */
    readonly hashPayload?: boolean;
    /**
     * Add the session token to the query after signing, outside the signature.
     * Always on for `iotdevicegateway`.
     */
    readonly appendSessionToken?: boolean;
    /**
     * Encode the path once. By default non-S3 paths are encoded twice, as SigV4
     * requires for every AWS service except S3.
     */
    readonly singleEncode?: boolean;
}
export interface SignedRequest {
    readonly method: string;
    /** Normalised URL; carries the `X-Amz-*` params when `signQuery` is set. */
    readonly url: string;
    /** Lower-cased header names, including the added `x-amz-*` / `authorization`. */
    readonly headers: Record<string, string>;
}
declare const InvalidSigningUrl_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "AWS::SigV4::InvalidSigningUrl";
} & Readonly<A>;
/** `options.url` is not an absolute URL the `URL` constructor accepts. */
export declare class InvalidSigningUrl extends /*@__PURE__*/ InvalidSigningUrl_base<{
    readonly url: string;
    readonly cause: unknown;
}> {
}
declare const InvalidSigningHeaders_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "AWS::SigV4::InvalidSigningHeaders";
} & Readonly<A>;
/**
 * A header name or value is not valid HTTP (the `Headers` constructor
 * rejected it), so it cannot be canonicalised.
 */
export declare class InvalidSigningHeaders extends /*@__PURE__*/ InvalidSigningHeaders_base<{
    readonly cause: unknown;
}> {
}
declare const CryptoError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "AWS::SigV4::CryptoError";
} & Readonly<A>;
/** The crypto implementation (see `@distilled.cloud/core/crypto`) rejected an HMAC or SHA-256 operation. */
export declare class CryptoError extends /*@__PURE__*/ CryptoError_base<{
    readonly operation: "hmac" | "sha256";
    readonly cause: unknown;
}> {
}
export type SigningError = InvalidSigningUrl | InvalidSigningHeaders | CryptoError;
/**
 * Scope of a derived signing key. `Redacted` hashes and compares by its
 * underlying value, so the secret never has to be unwrapped into a cache key.
 */
export interface SigningKeyScope {
    readonly secretAccessKey: Redacted.Redacted<string>;
    readonly date: string;
    readonly region: string;
    readonly service: string;
    /** The implementation the key is imported into: a key from one cannot sign with another. */
    readonly crypto?: CoreCrypto.CryptoImpl;
}
/** A derived key imported into the implementation that will use it. */
export interface SigningKey {
    readonly key: CoreCrypto.HmacKey;
    readonly impl: CoreCrypto.CryptoImpl;
}
/** Where signing gets derived keys from, when a scope supplies its own. */
export interface SigningKeyStore {
    /** The key for `scope`. A failed derivation should not be retained. */
    readonly get: (scope: SigningKeyScope) => Effect.Effect<SigningKey, CryptoError>;
}
/**
 * A key store to use instead of the built-in one. Deriving a key costs four
 * HMACs; by default keys are kept per secret (by `Redacted` identity, so the
 * secret is never a map key), date, region and service, at most 16 scopes
 * per secret, so long-lived processes rotating temporary credentials do not
 * accumulate secret-derived material. Failed derivations are not retained.
 * Over an effect `Cache`: `{ get: (scope) => Cache.get(cache, scope) }`.
 */
export declare const SigningKeyCache: Context.Reference<SigningKeyStore | undefined>;
/**
 * {@link sign} without effects, for callers already running on a fiber.
 * Returns `undefined` when the
 * signature needs effects (WebCrypto, or a {@link SigningKeyCache} in the
 * context); use {@link sign} then. Throws a {@link SigningError}.
 */
export declare const signSync: (input: SignOptions, fiber: {
    readonly context: Context.Context<never>;
    getRef<A>(ref: Context.Reference<A>): A;
}) => SignedRequest | undefined;
/**
 * Sign a request with SigV4. Fails with a {@link SigningError} when the URL
 * or headers cannot be canonicalised or WebCrypto rejects an operation.
 *
 * With a synchronous crypto implementation (node:crypto, the default on
 * Node/Bun/Deno) and no {@link SigningKeyCache} override in the context, the
 * whole signature is computed in one step without intermediate effects.
 */
export declare const sign: (options: SignOptions) => Effect.Effect<SignedRequest, SigningError>;
export interface PresignOptions extends Omit<WithoutScope<SignOptions>, "signQuery" | "body" | "hashPayload"> {
    /** Seconds the URL stays valid (`X-Amz-Expires`). S3 defaults to 86400; AWS allows at most 604800. */
    readonly expiresIn?: number;
}
/**
 * A presigned URL: the signature is in the query string, so anyone holding
 * the URL can send the request until it expires.
 *
 * ```ts
 * const url = yield* Signer.presign({
 *   url: "https://my-bucket.s3.us-east-1.amazonaws.com/report.pdf",
 *   accessKeyId,
 *   secretAccessKey,
 *   expiresIn: 3600,
 * });
 * ```
 */
export declare const presign: (options: PresignOptions) => Effect.Effect<string, SigningError>;
/** `O` with `service` and `region` optional: {@link guessScope} fills them in. */
export type WithoutScope<O extends {
    readonly service: string;
    readonly region: string;
}> = Omit<O, "service" | "region"> & {
    readonly service?: string | undefined;
    readonly region?: string | undefined;
};
/**
 * `options` with a missing `service` or `region` taken from the URL's host
 * ({@link guessServiceRegion}); the region falls back to `us-east-1`. A URL
 * that does not parse is left for {@link sign} to reject.
 *
 * Kept apart from {@link sign}, so programs that always pass both (the AWS
 * SDK) do not bundle the host rules.
 */
export declare const guessScope: <O extends SignOptions>(options: WithoutScope<O>) => O;
/**
 * The signing `[service, region]` a URL implies, as `aws4fetch` guesses it:
 * `*.amazonaws.com` hosts (with their S3, IoT, FIPS and dual-stack forms),
 * Lambda function URLs, Cloudflare R2 (`s3`, `auto`) and Backblaze B2. Either
 * part is `""` when the host does not say.
 *
 * ```ts
 * guessServiceRegion(new URL("https://sqs.eu-west-1.amazonaws.com/"));       // ["sqs", "eu-west-1"]
 * guessServiceRegion(new URL("https://acct.r2.cloudflarestorage.com/bucket")); // ["s3", "auto"]
 * ```
 */
export declare const guessServiceRegion: (url: URL, headers?: Record<string, string>) => readonly [service: string, region: string];
export {};
//# sourceMappingURL=index.d.ts.map