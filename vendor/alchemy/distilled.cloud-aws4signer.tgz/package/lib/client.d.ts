import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import * as HttpClientRequest from "effect/http/HttpClientRequest";
import type * as Redacted from "effect/Redacted";
import * as Signer from "./index.ts";
/** An access key pair, plus the session token of temporary credentials. */
export interface Credentials {
    readonly accessKeyId: string;
    readonly secretAccessKey: Redacted.Redacted<string>;
    readonly sessionToken?: Redacted.Redacted<string> | undefined;
}
export interface Options<E = never, R = never> extends Pick<Signer.WithoutScope<Signer.SignOptions>, "service" | "region" | "signQuery" | "allHeaders" | "appendSessionToken" | "singleEncode"> {
    /**
     * The keys, or an effect that reads them. The effect runs once per
     * request, so it can refresh temporary credentials; cache it yourself
     * (`Effect.cachedWithTTL`) when reading them is expensive.
     */
    readonly credentials: Credentials | Effect.Effect<Credentials, E, R>;
}
declare const UnsignableBody_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "AWS::SigV4::UnsignableBody";
} & Readonly<A>;
/**
 * The request body is a stream or form data, which the signer cannot hash.
 * Set the `X-Amz-Content-Sha256` header (for example to `UNSIGNED-PAYLOAD`,
 * where the service accepts it) or send the body as bytes or text.
 */
export declare class UnsignableBody extends /*@__PURE__*/ UnsignableBody_base<{
    readonly body: "FormData" | "Stream" | "Raw";
}> {
}
export type SignRequestError = Signer.SigningError | UnsignableBody;
/**
 * `request` signed with SigV4: `aws4fetch`'s `AwsClient.sign`. The signature
 * goes into the `Authorization` header, or into the query string with
 * `signQuery`. The signing time is the effect `Clock`'s, so `TestClock`
 * controls it.
 */
export declare const signRequest: <E = never, R = never>(request: HttpClientRequest.HttpClientRequest, options: Options<E, R>) => Effect.Effect<HttpClientRequest.HttpClientRequest, SignRequestError | E, R>;
/**
 * A client that signs each request before `client` sends it.
 *
 * ```ts
 * const s3 = (yield* HttpClient.HttpClient).pipe(
 *   AwsClient.sign({ credentials, service: "s3", region: "eu-west-1" }),
 *   HttpClient.retryTransient({ times: 3 }),
 * );
 * ```
 */
export declare const sign: <E = never, R = never>(options: Options<E, R>) => <E2, R2>(client: HttpClient.HttpClient.With<E2, R2>) => HttpClient.HttpClient.With<E | E2 | SignRequestError, R | R2>;
/** The context's `HttpClient`, signing every request: `aws4fetch`'s `new AwsClient(...)`. */
export declare const make: <E = never, R = never>(options: Options<E, R>) => Effect.Effect<HttpClient.HttpClient.With<E | import("effect/http/HttpClientError").HttpClientError | SignRequestError, R>, never, HttpClient.HttpClient>;
/**
 * A presigned URL for `url` with these credentials.
 *
 * ```ts
 * const url = yield* AwsClient.presign("https://my-bucket.s3.amazonaws.com/a.txt", {
 *   credentials,
 *   expiresIn: 600,
 * });
 * ```
 */
export declare const presign: <E = never, R = never>(url: string, options: Options<E, R> & {
    readonly method?: string;
    readonly headers?: Record<string, string>;
    readonly expiresIn?: number;
}) => Effect.Effect<string, Signer.SigningError | E, R>;
export {};
//# sourceMappingURL=client.d.ts.map