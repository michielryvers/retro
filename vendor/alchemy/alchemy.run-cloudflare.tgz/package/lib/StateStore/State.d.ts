import * as SecretsStore from "@distilled.cloud/cloudflare/secrets-store";
import * as workers from "@distilled.cloud/cloudflare/workers";
import { AuthError } from "alchemy/Auth/AuthProvider";
import { CredentialsStore } from "alchemy/Auth/Credentials";
import * as Interaction from "alchemy/Interaction";
import * as Output from "alchemy/Output";
import { State, type StateService, StateStoreError } from "alchemy/State/State";
import * as Config from "effect/Config";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import * as Access from "../Access.ts";
import * as CloudflareEnvironment from "../CloudflareEnvironment.ts";
export interface CloudflareStateOptions {
    /**
     * A store other than the account's default `alchemy-state-store`, by
     * logical name: its Worker is `alchemy-state-store-<name>`.
     */
    readonly name?: string;
}
/** The state-store Worker of a store: the default's, or `alchemy-state-store-<name>`. */
export declare const stateStoreScriptName: (name: string | undefined) => string;
export declare const state: (options?: CloudflareStateOptions) => Layer.Layer<State, never, import("alchemy/AlchemyContext").AlchemyContext | import("alchemy/Artifacts").ArtifactStore | import("alchemy/Auth/AuthProvider").AuthProviders | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("effect/FileSystem").FileSystem | HttpClient.HttpClient | Interaction.Interaction | import("effect/Path").Path>;
export interface BootstrapOptions {
    /** @default "alchemy-state-store" */
    workerName?: string;
    /** @default false */
    force?: boolean;
    /** @default "default" */
    profile?: string;
}
export declare const bootstrap: (options?: BootstrapOptions) => Effect.Effect<StateService, Access.AccessError | AuthError | import("@distilled.cloud/iceberg").BadGateway | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | Config.ConfigError | import("@distilled.cloud/iceberg").ConfigError | import("alchemy/Auth/Demand").CredentialsRequired | import("alchemy/Apply").DestroyError | workers.Forbidden | import("@distilled.cloud/iceberg").GatewayTimeout | import("effect/http/HttpClientError").HttpClientError | import("@distilled.cloud/iceberg").InternalServerError | SecretsStore.InvalidAccountId | Output.InvalidReferenceError | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | workers.InvalidRoute | Output.MissingSourceError | import("alchemy/Auth/AuthProvider").NeedsReauth | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("effect/PlatformError").PlatformError | import("alchemy/Auth/Profile").ProfileError | import("@distilled.cloud/iceberg").ServiceUnavailable | StateStoreError | StateStoreVersionNotReady | workers.SubdomainNotFound | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError, Access.Access | import("alchemy/AlchemyContext").AlchemyContext | import("alchemy/Artifacts").ArtifactStore | CloudflareEnvironment.CloudflareEnvironment | CredentialsStore | import("effect/FileSystem").FileSystem | Interaction.Interaction | import("effect/Path").Path | import("alchemy/Auth/Profile").ProfileStore | SecretsStore.CloudflareOpContext>;
export interface TeardownOptions {
    /** @default "alchemy-state-store" */
    workerName?: string;
    /** @default "default" */
    profile?: string;
    /**
     * Delete the account Secrets Store too, but only once the state-store
     * secrets have been removed and no other secrets remain in it. A store that
     * still holds foreign secrets is left in place.
     * @default true
     */
    deleteEmptySecretsStore?: boolean;
}
/**
 * The inverse of {@link bootstrap}: tear down the Cloudflare-deployed state
 * store. Deletes the state-store Worker and the secrets it created in the
 * account Secrets Store (the bearer token + the encryption key), then deletes
 * the Secrets Store itself if it is left empty, and drops the locally cached
 * state-store credentials for the profile.
 *
 * Idempotent — missing resources are treated as already-gone, so it is safe to
 * re-run. Intended for reclaiming a throwaway account after testing; on a
 * shared account it only removes resources alchemy created.
 */
export declare const teardownStateStore: (options?: TeardownOptions) => Effect.Effect<void, import("effect/PlatformError").PlatformError | import("alchemy/Auth/Profile").ProfileError | workers.QueueConsumerConflict | workers.ServiceBindingConflict | SecretsStore.CloudflareOpError, CloudflareEnvironment.CloudflareEnvironment | CredentialsStore | import("effect/FileSystem").FileSystem | Interaction.Interaction | import("effect/Path").Path | import("alchemy/Auth/Profile").ProfileStore | SecretsStore.CloudflareOpContext>;
/**
 * Writes against a *just-deployed* state-store worker can fail
 * transiently while Cloudflare propagates the script, its route, and
 * its Secrets Store bindings to the edge:
 *
 * - 404 — the workers.dev route isn't serving the new script yet
 * - 401 — the worker is up but its auth-token secret binding hasn't
 *   propagated, so token validation reads a stale/absent value
 * - 5xx — the Store DO dies while its encryption-key secret binding
 *   is still propagating
 * - transport errors (no response) — cold workers.dev host blips
 *
 * @internal exported for unit testing.
 */
export declare const isTransientBootstrapWriteError: (error: Pick<StateStoreError, "http">) => boolean;
/**
 * Log in to a Cloudflare-deployed HTTP state-store.
 *
 * 1. Find the single account-wide Secrets Store.
 * 2. Upload a short-lived edge-preview worker that binds the
 *    auth-token secret and returns its value.
 * 3. Derive the state-store worker URL from
 *    {@link STATE_STORE_SCRIPT_NAME} and the account's workers.dev
 *    subdomain.
 * 4. Persist `{ url, token }` under the `http-state-store`
 *    credentials file.
 *
 * Requirements are covered by the Cloudflare provider stack —
 * `CloudflareEnvironment`, `Credentials`, `HttpClient`, and
 * `FileSystem`.
 */
export declare const loginWithCloudflare: (profileName: string, force: boolean, scriptName?: string | undefined) => Effect.Effect<{
    readonly url: string;
    readonly authToken: string;
    readonly accountId?: string | undefined;
}, AuthError | import("@distilled.cloud/iceberg").BadGateway | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | Config.ConfigError | import("@distilled.cloud/iceberg").ConfigError | workers.Forbidden | import("@distilled.cloud/iceberg").GatewayTimeout | import("effect/http/HttpClientError").HttpClientError | import("@distilled.cloud/iceberg").InternalServerError | SecretsStore.InvalidAccountId | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | workers.InvalidRoute | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("@distilled.cloud/iceberg").ServiceUnavailable | workers.SubdomainNotFound | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError, Access.Access | CloudflareEnvironment.CloudflareEnvironment | CredentialsStore | import("effect/FileSystem").FileSystem | Interaction.Interaction | import("effect/Path").Path | SecretsStore.CloudflareOpContext>;
declare const StateStoreVersionNotReady_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "StateStoreVersionNotReady";
} & Readonly<A>;
export declare class StateStoreVersionNotReady extends StateStoreVersionNotReady_base<{
    readonly expected: number;
    readonly observed: number | undefined;
}> {
    get message(): string;
}
/**
 * Edge-preview reads are flaky in ways that clear up on their own:
 * the workers.dev edge can serve a generic Cloudflare 400/502 HTML
 * page while preview routing propagates ("Secret probe returned
 * ..."), the session-create call can hit transient API blips, and the
 * probe fetch can fail at the transport level ("fetch failed").
 * Retry everything except causes that are clearly permanent
 * (bad credentials, invalid routes).
 *
 * @internal exported for unit testing.
 */
export declare const isTransientEdgeSessionError: (error: unknown) => boolean;
export {};
//# sourceMappingURL=State.d.ts.map