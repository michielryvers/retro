import type { AuthError } from "alchemy/Auth/AuthProvider";
import type { CredentialsStoreService } from "alchemy/Auth/Credentials";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
/**
 * Cache of the Cloudflare-deployed HTTP state stores' endpoints + bearer
 * tokens, at `~/.alchemy/profiles/{profile}/state-stores/cloudflare.json`.
 *
 * Kept in this leaf module (rather than `StateStore/State.ts`) so the
 * Cloudflare auth provider can invalidate the cache on
 * `profile edit` / provider logout without importing the heavy state-store
 * module and creating an import cycle
 * (`StateStore/State.ts` -> `Providers.ts` -> `Auth/AuthProvider.ts`).
 */
export declare const CREDENTIALS_FILE = "cloudflare";
/**
 * The single-store cache earlier releases keep at
 * `~/.alchemy/credentials/{profile}/cloudflare-state-store.json`. Copied into
 * {@link CREDENTIALS_FILE} once and never written, so those releases keep
 * working.
 */
export declare const LEGACY_CREDENTIALS_FILE = "cloudflare-state-store";
/**
 * On-disk shape of the cached Cloudflare state-store credentials.
 *
 * Extends the generic `HttpStateStoreCredentials` (`{ url, authToken }`)
 * with the `accountId` the credentials were minted against. The `url` already
 * encodes the account (via the `*.workers.dev` subdomain), so a cache written
 * while logged into account A keeps pointing at account A's state store even
 * after the user re-authenticates against account B. Persisting `accountId`
 * lets `state()` detect that mismatch and re-derive.
 *
 * `accountId` is optional so legacy files written before this field existed
 * still parse — they are treated as stale (see
 * {@link isStateStoreCredentialsStale}) and re-derived on next use.
 */
export declare const StoredStateStoreCredentials: Schema.Struct<{
    readonly url: Schema.String;
    /** Bearer token used to authenticate every request. */
    readonly authToken: Schema.String;
    /** Cloudflare account ID the `url`/`authToken` were minted against. */
    readonly accountId: Schema.optional<Schema.String>;
}>;
export type StoredStateStoreCredentials = typeof StoredStateStoreCredentials.Type;
/**
 * `true` when cached state-store credentials must not be trusted for the
 * current account:
 *
 * - the file predates the `accountId` field (legacy cache — exactly the
 *   artifact that caused deploys to silently target the wrong account), or
 * - it was minted against a different account than the one now in use.
 *
 * A stale cache is discarded and re-derived from the current account.
 */
export declare const isStateStoreCredentialsStale: (credentials: StoredStateStoreCredentials, currentAccountId: string) => boolean;
/** One state store's cached credentials, if any. */
export declare const readStoreCredentials: (store: CredentialsStoreService, profile: string, storeName: string) => Effect.Effect<{
    readonly url: string;
    readonly authToken: string;
    readonly accountId?: string | undefined;
}, AuthError, import("effect/FileSystem").FileSystem | import("effect/Path").Path>;
/** Cache one state store's credentials beside the profile's other stores. */
export declare const writeStoreCredentials: (store: CredentialsStoreService, profile: string, storeName: string, credentials: StoredStateStoreCredentials) => Effect.Effect<void, AuthError, import("effect/FileSystem").FileSystem | import("effect/Path").Path>;
/** Drop one state store's cached credentials. */
export declare const deleteStoreCredentials: (store: CredentialsStoreService, profile: string, storeName: string) => Effect.Effect<void, AuthError, import("effect/FileSystem").FileSystem | import("effect/Path").Path>;
/**
 * Drop every state store's cached credentials for a profile. Leaves an empty
 * file rather than none, so the legacy cache is not migrated again. One
 * atomic write, so it needs no lock.
 */
export declare const clearStoreCredentials: (store: CredentialsStoreService, profile: string) => Effect.Effect<void, AuthError, never>;
//# sourceMappingURL=CredentialsFile.d.ts.map