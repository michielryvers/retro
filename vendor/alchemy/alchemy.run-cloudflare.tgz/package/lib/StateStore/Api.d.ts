import { RuntimeContext } from "alchemy/RuntimeContext";
import * as Effect from "effect/Effect";
export declare const STATE_STORE_SCRIPT_NAME: "alchemy-state-store";
/**
 * Version of the deployed Cloudflare State Store worker contract.
 *
 * Bump this whenever the wire format or runtime behaviour of the
 * worker changes in a way that an older deployed copy can no longer
 * satisfy. Clients query `/version` on the deployed worker and
 * compare against this constant; a mismatch (or 404) triggers a
 * forced redeploy via the bootstrap flow.
 */
export declare const STATE_STORE_VERSION: 7;
declare const _default: Effect.Effect<import("effect/Pipeable").Pipeable & import("alchemy/Resource").ResourceLike<"Cloudflare.Worker", import("../index.ts").WorkerProps<any, import("../index.ts").WorkerAssetsConfig | undefined>, {
    workerId: string;
    workerName: string;
    namespace: string | undefined;
    logpush: boolean | undefined;
    url: string | undefined;
    urls: string[];
    domain: {
        name: string;
        aliases: string[];
        redirects: string[];
        zone?: import("../Zone/lookup.ts").Reference;
        previews?: boolean;
    } | undefined;
    tags: string[] | undefined;
    durableObjectNamespaces: Record<string, string>;
    accountId: string;
    routes: {
        id: string;
        pattern: string;
        zoneId: string;
        url?: string;
    }[];
    crons: string[];
    tailConsumers?: {
        service: string;
    }[] | undefined;
    streamingTailConsumers?: {
        service: string;
    }[] | undefined;
    versionOf?: string | undefined;
    previewOf?: string | undefined;
    previewId?: string | undefined;
    previewName?: string | undefined;
    previewSlug?: string | undefined;
    previewDoClasses?: string[] | undefined;
    versionId?: string | undefined;
    versionAlias?: string | undefined;
    deploymentId?: string | undefined;
    affinityZoneIds?: string[] | undefined;
    hash?: {
        assets: string | undefined;
        bundle: string | undefined;
        input: string | undefined;
        additionalWorkspaces: string[] | undefined;
        metadata?: string | undefined;
    };
}, {
    bindings?: import("../index.ts").WorkerBinding[];
    env?: Record<string, any>;
    cache?: import("../index.ts").WorkerCache;
    observability?: Pick<import("../index.ts").WorkerObservability, "traces">;
    containers?: {
        className: string;
        attachedBy?: "binding";
        name?: string;
        images?: Record<string, string>;
        devImages?: Record<string, import("../index.ts").DevContainerImage>;
        dev: import("../index.ts").DevContainerImage | undefined;
        hash: string | undefined;
    }[];
    crons?: string[];
    hyperdrives?: Record<string, Required<import("../Hyperdrive/Connection.ts").DevOrigin>>;
    devRemote?: Record<string, boolean>;
}, import("../Providers.ts").Providers> & {
    bind(sid: import("alchemy/Input").Input<string>, binding: import("alchemy/Input").Input<{
        bindings?: import("../index.ts").WorkerBinding[];
        env?: Record<string, any>;
        cache?: import("../index.ts").WorkerCache;
        observability?: Pick<import("../index.ts").WorkerObservability, "traces">;
        containers?: {
            className: string;
            attachedBy?: "binding";
            name?: string;
            images?: Record<string, string>;
            devImages?: Record<string, import("../index.ts").DevContainerImage>;
            dev: import("../index.ts").DevContainerImage | undefined;
            hash: string | undefined;
        }[];
        crons?: string[];
        hyperdrives?: Record<string, Required<import("../Hyperdrive/Connection.ts").DevOrigin>>;
        devRemote?: Record<string, boolean>;
    }>): Effect.Effect<void>;
    bind(template: TemplateStringsArray, ...args: any[]): (binding: import("alchemy/Input").Input<{
        bindings?: import("../index.ts").WorkerBinding[];
        env?: Record<string, any>;
        cache?: import("../index.ts").WorkerCache;
        observability?: Pick<import("../index.ts").WorkerObservability, "traces">;
        containers?: {
            className: string;
            attachedBy?: "binding";
            name?: string;
            images?: Record<string, string>;
            devImages?: Record<string, import("../index.ts").DevContainerImage>;
            dev: import("../index.ts").DevContainerImage | undefined;
            hash: string | undefined;
        }[];
        crons?: string[];
        hyperdrives?: Record<string, Required<import("../Hyperdrive/Connection.ts").DevOrigin>>;
        devRemote?: Record<string, boolean>;
    }>) => Effect.Effect<void>;
} & {
    workerId: import("alchemy/Output").Output<string, never>;
    workerName: import("alchemy/Output").Output<string, never>;
    namespace: import("alchemy/Output").Output<string | undefined, never>;
    logpush: import("alchemy/Output").Output<boolean | undefined, never>;
    url: import("alchemy/Output").Output<string | undefined, never>;
    urls: import("alchemy/Output").Output<string[], never>;
    domain: import("alchemy/Output").Output<{
        name: string;
        aliases: string[];
        redirects: string[];
        zone?: import("../Zone/lookup.ts").Reference;
        previews?: boolean;
    } | undefined, never>;
    tags: import("alchemy/Output").Output<string[] | undefined, never>;
    durableObjectNamespaces: import("alchemy/Output").ObjectExpr<Record<string, string>, never>;
    accountId: import("alchemy/Output").Output<string, never>;
    routes: import("alchemy/Output").Output<{
        id: string;
        pattern: string;
        zoneId: string;
        url?: string;
    }[], never>;
    crons: import("alchemy/Output").Output<string[], never>;
    tailConsumers: import("alchemy/Output").Output<{
        service: string;
    }[] | undefined, never>;
    streamingTailConsumers: import("alchemy/Output").Output<{
        service: string;
    }[] | undefined, never>;
    versionOf: import("alchemy/Output").Output<string | undefined, never>;
    previewOf: import("alchemy/Output").Output<string | undefined, never>;
    previewId: import("alchemy/Output").Output<string | undefined, never>;
    previewName: import("alchemy/Output").Output<string | undefined, never>;
    previewSlug: import("alchemy/Output").Output<string | undefined, never>;
    previewDoClasses: import("alchemy/Output").Output<string[] | undefined, never>;
    versionId: import("alchemy/Output").Output<string | undefined, never>;
    versionAlias: import("alchemy/Output").Output<string | undefined, never>;
    deploymentId: import("alchemy/Output").Output<string | undefined, never>;
    affinityZoneIds: import("alchemy/Output").Output<string[] | undefined, never>;
    hash: import("alchemy/Output").Output<{
        assets: string | undefined;
        bundle: string | undefined;
        input: string | undefined;
        additionalWorkspaces: string[] | undefined;
        metadata?: string | undefined;
    } | undefined, never>;
} & import("alchemy/Rpc").Rpc<{
    fetch: Effect.Effect<Effect.Effect<import("effect/http/HttpServerResponse").HttpServerResponse, import("effect/http/HttpServerError").HttpServerError, import("effect/http/HttpServerRequest").HttpServerRequest | RuntimeContext | import("effect/Scope").Scope>, never, import("effect/FileSystem").FileSystem | import("effect/Scope").Scope>;
}>, never, import("../Providers.ts").Providers> & import("alchemy/Named").Named<"Api"> & import("alchemy/Platform").PlatformIdentity<"Api">;
export default _default;
//# sourceMappingURL=Api.d.ts.map