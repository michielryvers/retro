import * as basin from "@distilled.cloud/cloudflare/basin_catalog";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Duration from "effect/Duration";
import * as Layer from "effect/Layer";
import type * as Redacted from "effect/Redacted";
import * as S from "effect/Schema";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
import type { DataCatalog } from "../R2/DataCatalog.ts";
export { BasinTableSchemaUnsupported } from "./internal/schema.ts";
declare const TypeId: "Cloudflare.Basin.Table";
type TypeId = typeof TypeId;
/**
 * An Iceberg primitive type. Decimals are written `decimal(P, S)` and
 * fixed-length binaries `fixed[N]`.
 */
export type TablePrimitiveType = "boolean" | "int" | "long" | "float" | "double" | "date" | "time" | "timestamp" | "timestamptz" | "timestamp_ns" | "timestamptz_ns" | "string" | "uuid" | "binary" | `decimal(${number}, ${number})` | `decimal(${number},${number})` | `fixed[${number}]`;
/** A nested Iceberg struct column type. */
export interface TableStructType {
    type: "struct";
    /** Columns of the struct. */
    fields: TableColumn[];
}
/** An Iceberg list column type. */
export interface TableListType {
    type: "list";
    /** Type of each element. */
    element: TableColumnType;
    /**
     * Whether elements are non-null.
     * @default false
     */
    elementRequired?: boolean;
}
/** An Iceberg map column type. */
export interface TableMapType {
    type: "map";
    /** Type of the keys. */
    key: TableColumnType;
    /** Type of the values. */
    value: TableColumnType;
    /**
     * Whether values are non-null.
     * @default false
     */
    valueRequired?: boolean;
}
/** Any Iceberg column type. */
export type TableColumnType = TablePrimitiveType | TableStructType | TableListType | TableMapType;
/** One column of a table schema. Field ids are assigned by Alchemy. */
export interface TableColumn {
    /** Column name. */
    name: string;
    /** Column type. */
    type: TableColumnType;
    /**
     * Whether the column is non-null.
     * @default false
     */
    required?: boolean;
    /** Column documentation stored in the Iceberg schema. */
    doc?: string;
}
/**
 * A plain Iceberg schema descriptor: the table's top-level columns.
 */
export interface TableSchema {
    /** Top-level columns. */
    fields: TableColumn[];
}
/**
 * A table schema: an Effect Schema `Struct` or `Class`, or a plain
 * {@link TableSchema} descriptor (for types Effect Schema cannot express,
 * like `float`, `decimal(P, S)`, or `date`).
 */
export type TableSchemaInput = S.Schema<any> | TableSchema;
/**
 * What happens to the Iceberg table when the resource is removed from the
 * stack or the stack is destroyed.
 *
 * - `"retain"` — leave the table and its data in the catalog.
 * - `"drop"` — drop the table from the catalog without purging its files.
 * - `"purge"` — drop the table and ask the catalog to purge its data and
 *   metadata files.
 */
export type TableDeletePolicy = "retain" | "drop" | "purge";
/** Target output file size, in MB, of compaction. */
export type TableCompactionTargetSizeMb = "64" | "128" | "256" | "512";
/** Per-table maintenance managed by the Basin catalog. */
export interface TableMaintenance {
    /**
     * Compaction rewrites small data files into larger ones. Omit to leave
     * the table's compaction settings unmanaged.
     */
    compaction?: {
        /**
         * Whether compaction runs.
         * @default true
         */
        enabled?: boolean;
        /** Target output file size, in MB. */
        targetSizeMb?: TableCompactionTargetSizeMb;
    };
    /**
     * Snapshot expiration removes old snapshots. Omit to leave the table's
     * snapshot expiration settings unmanaged.
     */
    snapshotExpiration?: {
        /**
         * Whether snapshot expiration runs.
         * @default true
         */
        enabled?: boolean;
        /**
         * Expire snapshots older than this, e.g. `"7 days"` or
         * `Duration.hours(36)`. Sent to Cloudflare in whole days, hours, or
         * minutes.
         */
        olderThan?: Duration.Input;
        /** Always keep at least this many snapshots. */
        retainLast?: number;
    };
}
export interface TableProps {
    /**
     * The catalog that owns the table: a `Cloudflare.Basin.Catalog` resource
     * (orders the table after the catalog) or the name of the bucket the
     * catalog is enabled on. The table is created in its warehouse. Changing
     * the catalog fails the plan.
     */
    catalog: string | DataCatalog;
    /**
     * Iceberg namespace of the table. Created if it does not exist; never
     * deleted (other tables may share it). Changing the namespace fails the
     * plan.
     */
    namespace: string;
    /**
     * Table name. Changing it fails the plan (Iceberg renames would orphan
     * readers and writers).
     * @default ${app}_${id}_${stage}_${suffix} (lowercase, underscores)
     */
    name?: string;
    /**
     * Table schema. Additive changes (new optional columns, relaxing
     * `required`, `int`→`long`, `float`→`double`, wider decimals, docs,
     * column order) evolve the table in place. Destructive changes (dropping
     * a column, adding a required column, narrowing or changing a type) fail
     * the plan — Alchemy never drops data to replace a table.
     */
    schema: TableSchemaInput;
    /**
     * Partition spec as Iceberg transform terms: a bare column (`"region"`,
     * identity), `"year(at)"`, `"month(at)"`, `"day(at)"`, `"hour(at)"`,
     * `"bucket[16](id)"`, `"truncate[4](name)"`. Immutable: changing it fails
     * the plan.
     */
    partitionBy?: string[];
    /**
     * Iceberg table properties. Synced in place; keys removed from this map
     * are removed from the table. Properties set by the catalog or other
     * writers are left alone.
     */
    properties?: Record<string, string>;
    /**
     * Per-table maintenance (compaction and snapshot expiration). Only the
     * settings you specify are enforced. Enabling a job on a table requires
     * the same job to be enabled on the catalog (`compaction` /
     * `snapshotExpiration` with `state: "enabled"` on the DataCatalog).
     */
    maintenance?: TableMaintenance;
    /**
     * What happens to the table when it is removed from the stack.
     * @default "retain"
     */
    delete?: TableDeletePolicy;
    /**
     * Bearer token for the Iceberg REST catalog. Defaults to the deploying
     * Cloudflare credentials (API token or OAuth access token), which need
     * R2 Data Catalog access.
     */
    token?: Redacted.Redacted<string>;
}
export interface TableAttributes {
    /** Iceberg namespace of the table. */
    namespace: string;
    /** Table name. */
    tableName: string;
    /** `namespace.tableName`, as engines like Spark and DuckDB address it. */
    identifier: string;
    /** Iceberg table UUID. Stable across in-place schema evolution. */
    tableUuid: string;
    /** Base location of the table's files in R2. */
    location: string | undefined;
    /** Location of the current metadata file. */
    metadataLocation: string | undefined;
    /** Iceberg REST catalog URI of the warehouse. */
    catalogUri: string;
    /** Warehouse name (`{accountId}_{bucketName}`). */
    warehouse: string;
    /** The Cloudflare account that owns the catalog. */
    accountId: string;
    /** R2 bucket that backs the catalog. */
    bucketName: string;
    /** Iceberg table format version. */
    formatVersion: number;
    /** Id of the table's current schema. */
    currentSchemaId: number | undefined;
}
export type Table = Resource<TypeId, TableProps, TableAttributes, never, Providers>;
declare const BasinTableChangeRejected_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Cloudflare.Basin.TableChangeRejected";
} & Readonly<A>;
/**
 * A plan-time rejection: the change cannot be applied in place and Alchemy
 * will not replace (drop) an Iceberg table to apply it.
 */
export declare class BasinTableChangeRejected extends BasinTableChangeRejected_base<{
    message: string;
    table: string;
    reasons: string[];
}> {
}
declare const BasinTableCredentialsUnavailable_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Cloudflare.Basin.TableCredentialsUnavailable";
} & Readonly<A>;
/**
 * The deploying Cloudflare credentials cannot authenticate against the
 * Iceberg REST catalog (global API keys are not bearer tokens).
 */
export declare class BasinTableCredentialsUnavailable extends BasinTableCredentialsUnavailable_base<{
    message: string;
}> {
}
declare const TableResource: import("alchemy/Resource").ResourceClass<Table>;
/**
 * An Apache Iceberg table in a Cloudflare Basin (R2 Data) catalog.
 *
 * Declare the table's schema with Effect Schema; Alchemy derives the Iceberg
 * schema (`String`→`string`, `Boolean`→`boolean`, `Int`→`long` (`int` when
 * bounded to 32 bits), `Number`→`double`, `Date`→`timestamptz`,
 * `Uint8Array`→`binary`, arrays→`list`, `Struct`/`Class`→`struct`,
 * `Record`→`map`, optional/nullable→not required). Additive schema changes
 * evolve the table in place, keeping its UUID and field ids; destructive
 * changes fail the plan. By default the table is retained when removed
 * from the stack.
 *
 * Writing to a table from a Pipelines sink and querying it with Basin SQL
 * are not part of this resource yet.
 * ### Creating a table
 * **Example:** Table from an Effect Schema
 * ```typescript
 * const Order = Schema.Struct({
 *   id: Schema.String,
 *   amount: Schema.Number,
 *   at: Schema.Date,
 *   note: Schema.optional(Schema.String),
 * });
 *
 * const bucket = yield* Cloudflare.R2.Bucket("Analytics");
 * const catalog = yield* Cloudflare.R2.DataCatalog("Catalog", {
 *   bucket,
 * });
 * const orders = yield* Cloudflare.Basin.Table("Orders", {
 *   catalog,
 *   namespace: "sales",
 *   schema: Order,
 *   partitionBy: ["day(at)"],
 * });
 * // orders.identifier → "sales.<generated name>"
 * ```
 *
 * **Example:** Plain Iceberg column descriptors
 * ```typescript
 * const prices = yield* Cloudflare.Basin.Table("Prices", {
 *   catalog,
 *   namespace: "sales",
 *   name: "prices",
 *   schema: {
 *     fields: [
 *       { name: "sku", type: "string", required: true },
 *       { name: "price", type: "decimal(10, 2)" },
 *       { name: "day", type: "date" },
 *     ],
 *   },
 * });
 * ```
 *
 * ### Evolving the schema
 * **Example:** Add an optional column in place
 * ```typescript
 * const Order = Schema.Struct({
 *   id: Schema.String,
 *   amount: Schema.Number,
 *   at: Schema.Date,
 *   note: Schema.optional(Schema.String),
 *   coupon: Schema.optional(Schema.String), // new: evolves the table
 * });
 * ```
 *
 * ### Properties and maintenance
 * **Example:** Table properties, compaction, and snapshot expiration
 * ```typescript
 * // Table maintenance needs the jobs enabled on the catalog first.
 * const catalog = yield* Cloudflare.R2.DataCatalog("Catalog", {
 *   bucket,
 *   compaction: { state: "enabled" },
 *   snapshotExpiration: { state: "enabled" },
 *   token: maintenanceToken,
 * });
 * const orders = yield* Cloudflare.Basin.Table("Orders", {
 *   catalog,
 *   namespace: "sales",
 *   schema: Order,
 *   properties: { "write.parquet.compression-codec": "zstd" },
 *   maintenance: {
 *     compaction: { targetSizeMb: "256" },
 *     snapshotExpiration: { olderThan: "7 days", retainLast: 10 },
 *   },
 * });
 * ```
 *
 * ### Deleting
 * **Example:** Purge the table's data on destroy
 * ```typescript
 * const scratch = yield* Cloudflare.Basin.Table("Scratch", {
 *   catalog,
 *   namespace: "tmp",
 *   schema: Order,
 *   delete: "purge",
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/r2/data-catalog/
 *
 * @resource
 * @product Basin
 * @category Storage & Databases
 */
export declare const Table: typeof TableResource;
/**
 * Returns true if the given value is a Basin Table resource.
 */
export declare const isTable: (value: unknown) => value is Table;
export declare const TableProvider: () => Layer.Layer<Provider.Provider<Table>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | basin.CloudflareOpContext>;
//# sourceMappingURL=Table.d.ts.map