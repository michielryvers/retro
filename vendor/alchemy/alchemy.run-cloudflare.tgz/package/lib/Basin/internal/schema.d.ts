import type * as Iceberg from "@distilled.cloud/iceberg";
import type { TableColumn, TableColumnType, TableSchema, TableSchemaInput } from "../Table.ts";
declare const BasinTableSchemaUnsupported_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Cloudflare.Basin.TableSchemaUnsupported";
} & Readonly<A>;
/**
 * An Effect Schema (or column) that has no Iceberg representation.
 */
export declare class BasinTableSchemaUnsupported extends BasinTableSchemaUnsupported_base<{
    message: string;
    path: string;
}> {
}
/**
 * Convert an Effect Schema struct (or `Schema.Class`) into the plain column
 * descriptor persisted in Table props. Plain descriptors pass through.
 */
export declare const toTableSchema: (schema: TableSchemaInput) => TableSchema;
/** Fill defaults so two descriptors compare structurally. */
export declare const normalizeColumnType: (t: TableColumnType) => TableColumnType;
export declare const normalizeColumns: (fields: readonly TableColumn[]) => TableColumn[];
/** Iceberg wire struct fields → column descriptors. */
export declare const fromIcebergFields: (fields: readonly Iceberg.StructField[]) => TableColumn[];
/**
 * Compare an observed (or previously declared) schema with the desired one
 * and list every change Iceberg cannot apply without rewriting or losing
 * data: dropped columns, new required columns, required-ness tightened, and
 * type changes other than Iceberg's promotions (int→long, float→double,
 * decimal precision widening).
 */
export declare const destructiveChanges: (observed: readonly TableColumn[], desired: readonly TableColumn[]) => string[];
/**
 * Build the Iceberg wire schema for `desired`, reusing the field ids of
 * columns that already exist in `observed` (matched by name at the same
 * nesting) and assigning fresh ids from `nextId` to new columns. Ids at one
 * struct level are assigned before descending, like Iceberg's own clients.
 */
export declare const assignFieldIds: (desired: readonly TableColumn[], observed: readonly Iceberg.StructField[] | undefined, nextId: () => number) => Iceberg.StructField[];
/** Highest field id anywhere in a wire schema. */
export declare const maxFieldId: (fields: readonly Iceberg.StructField[]) => number;
/** Dotted column path → field id, for partition source resolution. */
export declare const fieldIdsByPath: (fields: readonly Iceberg.StructField[]) => Map<string, number>;
export interface PartitionTerm {
    /** Dotted source column path. */
    column: string;
    /** Iceberg transform, e.g. `identity`, `day`, `bucket[16]`. */
    transform: string;
}
/**
 * Parse a `partitionBy` term: `col`, `identity(col)`, `year|month|day|hour(col)`,
 * `bucket[N](col)` / `bucket(N, col)`, `truncate[N](col)` / `truncate(N, col)`.
 */
export declare const parsePartitionTerm: (term: string) => PartitionTerm;
export declare const partitionFieldName: ({ column, transform }: PartitionTerm) => string;
export declare const samePartitionTerms: (a: readonly PartitionTerm[], b: readonly PartitionTerm[]) => boolean;
export {};
//# sourceMappingURL=schema.d.ts.map