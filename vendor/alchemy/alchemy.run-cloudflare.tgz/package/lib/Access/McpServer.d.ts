import * as zeroTrust from "@distilled.cloud/cloudflare/zero-trust";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Redacted from "effect/Redacted";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
declare const TypeId: "Cloudflare.Access.McpServer";
type TypeId = typeof TypeId;
/**
 * Authentication method the gateway uses to reach the upstream MCP server.
 */
export type McpServerAuthType = "oauth" | "bearer" | "unauthenticated";
/**
 * Capability sync state reported by Cloudflare for an MCP server.
 */
export type McpServerStatus = "waiting" | "ready" | "stale" | "error";
/**
 * Whether administrative authentication is required before the server's
 * capabilities can be synced.
 */
export type McpServerAuthenticationStatus = "not_required" | "required" | "connected" | "stale" | "manual";
/**
 * A server-wide override for a single tool or prompt exposed by the
 * upstream MCP server.
 */
export interface McpServerCapabilityOverride {
    /**
     * Name of the tool or prompt capability to override.
     */
    name: string;
    /**
     * Custom name exposed for the capability.
     */
    alias?: string;
    /**
     * Custom description exposed for the capability.
     */
    description?: string;
    /**
     * Whether the capability is available through the MCP server.
     */
    enabled?: boolean;
}
/**
 * A tool or prompt discovered from the upstream MCP server by a capability
 * sync. The shape is whatever the upstream advertises (typically `name`,
 * `description`, and an input schema).
 */
export type McpServerCapability = Record<string, unknown>;
export interface McpServerProps {
    /**
     * The client-supplied server identifier. Immutable — changing it
     * triggers a replacement. If omitted, a deterministic id is generated
     * from the stack, stage, logical ID, and resource instance, capped at
     * the API's 32-character limit.
     * @default a generated ID of at most 32 characters
     */
    serverId?: string;
    /**
     * Display name of the server. If omitted, the server id is reused.
     * @default the server id
     */
    name?: string;
    /**
     * URL of the upstream MCP endpoint, e.g. `https://mcp.example.com/mcp`.
     * Create-only on the API: changing it triggers a delete-first replacement.
     */
    hostname: string;
    /**
     * Authentication method used to connect to the upstream MCP server.
     * Create-only on the API: changing it triggers a delete-first replacement.
     */
    authType: McpServerAuthType;
    /**
     * Static credential for the upstream MCP server. For `bearer`, either a
     * raw token (sent as `Authorization: Bearer <token>`) or a JSON-encoded
     * `{"headers":{...}}` object for custom or multiple static headers, e.g.
     * a Cloudflare Access service token. For `oauth`, the JSON-encoded OAuth
     * configuration. Write-only — the API never returns it, so rotation is
     * detected by comparing against the previously deployed value.
     */
    authCredentials?: Redacted.Redacted<string>;
    /**
     * Pre-registered OAuth `client_secret` for manually configured OAuth
     * servers. Write-only — never returned by the API.
     */
    clientSecret?: Redacted.Redacted<string>;
    /**
     * Optional description of the server.
     */
    description?: string;
    /**
     * Route outbound traffic to this server through the Zero Trust Secure
     * Web Gateway.
     * @default false
     */
    secureWebGateway?: boolean;
    /**
     * Use the shared Cloudflare-owned OAuth callback endpoint as the
     * `redirect_uri` for upstream on-behalf OAuth instead of the portal
     * hostname.
     * @default false
     */
    isSharedOauthCallbackEnabled?: boolean;
    /**
     * Server-wide tool overrides: disable, rename, or re-describe tools the
     * upstream advertises. When omitted, the observed overrides are kept.
     */
    updatedTools?: McpServerCapabilityOverride[];
    /**
     * Server-wide prompt overrides: disable, rename, or re-describe prompts
     * the upstream advertises. When omitted, the observed overrides are kept.
     */
    updatedPrompts?: McpServerCapabilityOverride[];
    /**
     * Run a capability sync (tool and prompt discovery against the upstream)
     * after the server is created, its configuration changes, or sync is
     * enabled after being disabled. Discovery
     * problems are reported on the `status` and `error` attributes and never
     * fail the deploy. Skipped while the server still requires an
     * administrator to complete its OAuth authentication. Cloudflare may
     * independently discover capabilities even when this option is false.
     * @default true
     */
    sync?: boolean;
}
export type McpServerAttributes = {
    /** The server id. */
    serverId: string;
    /** Account that owns the server. */
    accountId: string;
    /** Observed display name. */
    name: string;
    /** Observed upstream MCP endpoint URL. */
    hostname: string;
    /** Observed authentication method. */
    authType: McpServerAuthType;
    /** Observed description, if any. */
    description: string | undefined;
    /** Whether outbound traffic routes through the gateway. */
    secureWebGateway: boolean;
    /** Whether the shared Cloudflare OAuth callback is used. */
    isSharedOauthCallbackEnabled: boolean;
    /** Observed server-wide tool overrides. */
    updatedTools: McpServerCapabilityOverride[];
    /** Observed server-wide prompt overrides. */
    updatedPrompts: McpServerCapabilityOverride[];
    /** Tools discovered by the last successful capability sync. */
    tools: McpServerCapability[];
    /** Prompts discovered by the last successful capability sync. */
    prompts: McpServerCapability[];
    /** Current capability sync state, if reported. */
    status: McpServerStatus | undefined;
    /** Whether administrative OAuth authentication is still required. */
    authenticationStatus: McpServerAuthenticationStatus | undefined;
    /** Error from the last capability sync, if any. */
    error: string | undefined;
    /** RFC 3339 timestamp of the last sync attempt, if reported. */
    lastSynced: string | undefined;
    /** RFC 3339 timestamp of the last successful sync, if reported. */
    lastSuccessfulSync: string | undefined;
    /** RFC 3339 timestamp of when the server was created, if reported. */
    createdAt: string | undefined;
};
export type McpServer = Resource<TypeId, McpServerProps, McpServerAttributes, never, Providers>;
/**
 * A Cloudflare Zero Trust **AI Controls MCP server** — an upstream MCP
 * endpoint registered on the account so its tools and prompts can be
 * discovered, governed, and exposed to users through an MCP portal.
 *
 * Use {@link McpPortal} to create the gateway. Creating a server does not
 * attach it to a portal; portal membership is managed outside Alchemy.
 *
 * The product surface is in beta and requires the AI Controls
 * entitlement; accounts without it receive the typed `Forbidden` error
 * on all writes. The upstream `hostname` and `authType` are create-only
 * on the API — changing either triggers a delete-first replacement.
 * Credentials are write-only: the API never returns them, so a rotation
 * is detected by comparing against the previously deployed value.
 * Existing servers without saved stack state require explicit adoption;
 * their IDs alone do not prove ownership.
 *
 * ### Registering an MCP server
 * **Example:** Public server without authentication
 * ```typescript
 * const docs = yield* Cloudflare.Access.McpServer("CloudflareDocs", {
 *   hostname: "https://docs.mcp.cloudflare.com/mcp",
 *   authType: "unauthenticated",
 * });
 * ```
 *
 * **Example:** Server behind a static bearer token
 * ```typescript
 * const internal = yield* Cloudflare.Access.McpServer("InternalTools", {
 *   hostname: "https://mcp.internal.example.com/mcp",
 *   authType: "bearer",
 *   authCredentials: yield* Config.Redacted("MCP_BEARER_TOKEN"),
 *   description: "Internal engineering tools",
 *   secureWebGateway: true,
 * });
 * ```
 *
 * **Example:** Server protected by a Cloudflare Access service token
 * ```typescript
 * const token = yield* Cloudflare.Access.ServiceToken("McpToken", {});
 *
 * const guarded = yield* Cloudflare.Access.McpServer("GuardedTools", {
 *   hostname: "https://mcp.example.com/mcp",
 *   authType: "bearer",
 *   authCredentials: Output.all(token.clientId, token.clientSecret).pipe(
 *     Output.map(([clientId, clientSecret]) =>
 *       Redacted.make(JSON.stringify({
 *         headers: {
 *           "cf-access-client-id": clientId,
 *           "cf-access-client-secret": Redacted.value(clientSecret!),
 *         },
 *       })),
 *     ),
 *   ),
 * });
 * ```
 *
 * ### Governing capabilities
 * **Example:** Disable one tool and rename another
 * ```typescript
 * const curated = yield* Cloudflare.Access.McpServer("Curated", {
 *   hostname: "https://docs.mcp.cloudflare.com/mcp",
 *   authType: "unauthenticated",
 *   updatedTools: [
 *     { name: "migrate_pages_to_workers_guide", enabled: false },
 *     { name: "search_cloudflare_documentation", alias: "search_docs" },
 *   ],
 * });
 * ```
 *
 * **Example:** Register without an explicit capability sync
 * ```typescript
 * const deferred = yield* Cloudflare.Access.McpServer("Deferred", {
 *   hostname: "https://mcp.example.com/mcp",
 *   authType: "bearer",
 *   authCredentials: yield* Config.Redacted("MCP_BEARER_TOKEN"),
 *   sync: false,
 * });
 * ```
 *
 * ### Adopting an existing server
 * **Example:** Take ownership of a server registered outside Alchemy
 * ```typescript
 * const server = yield* Cloudflare.Access.McpServer("Existing", {
 *   serverId: "existing-server",
 *   hostname: "https://mcp.example.com/mcp",
 *   authType: "unauthenticated",
 * }).pipe(adopt(true));
 * ```
 *
 * @see https://developers.cloudflare.com/cloudflare-one/access-controls/ai-controls/
 *
 * @resource
 * @product Access
 * @category Cloudflare One (Zero Trust)
 */
export declare const McpServer: import("alchemy/Resource").ResourceClass<McpServer>;
/**
 * Returns true if the given value is an McpServer resource.
 */
export declare const isMcpServer: (value: unknown) => value is McpServer;
export declare const McpServerProvider: () => import("effect/Layer").Layer<Provider.Provider<McpServer>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | zeroTrust.CloudflareOpContext>;
export {};
//# sourceMappingURL=McpServer.d.ts.map