import * as Layer from "effect/Layer";
/**
 * Implementation of the {@link StreamSink} service over the stream's HTTP ingest endpoint with the **current credentials** ({@link WriteStreamLocal}) — for draining an Effect Stream into a Pipelines stream from an Action, with no Worker host. The stream needs `http` enabled.
 * ### Providing the Layer
 * **Example:** Provide the sink layer
 * ```typescript
 * const Seed = Alchemy.Action(
 *   "Seed",
 *   Effect.gen(function* () {
 *     const sink = yield* Cloudflare.Basin.StreamSink(PageViews);
 *     return Effect.fn(function* () {
 *       yield* EffectStream.fromIterable(views).pipe(EffectStream.run(sink));
 *     });
 *   }).pipe(Effect.provide(Cloudflare.Basin.StreamSinkLocal)),
 * );
 * ```
 *
 * @layer
 * @provides Cloudflare.Pipelines.StreamSink
 * @product Pipelines
 * @category Storage & Databases
 */
export declare const StreamSinkLocal: Layer.Layer<import("./StreamSink.ts").StreamSink, never, import("@distilled.cloud/cloudflare/Credentials").Credentials | import("effect/http/HttpClient").HttpClient>;
//# sourceMappingURL=StreamSinkLocal.d.ts.map