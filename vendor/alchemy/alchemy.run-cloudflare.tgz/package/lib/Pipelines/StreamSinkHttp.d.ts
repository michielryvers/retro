import * as Layer from "effect/Layer";
/**
 * Implementation of the {@link StreamSink} service over the stream's HTTP ingest endpoint ({@link WriteStreamHttp}), authenticated with a scoped `Pipelines Send` API token bound into the host. The stream needs `http` enabled.
 * ### Providing the Layer
 * **Example:** Provide the sink layer
 * ```typescript
 * Effect.gen(function* () {
 *   const sink = yield* Cloudflare.Basin.StreamSink(PageViews);
 *   // ...
 * }).pipe(Effect.provide(Cloudflare.Basin.StreamSinkHttp));
 * ```
 *
 * @layer
 * @provides Cloudflare.Pipelines.StreamSink
 * @product Pipelines
 * @category Storage & Databases
 */
export declare const StreamSinkHttp: Layer.Layer<import("./StreamSink.ts").StreamSink, never, import("alchemy/Self").Self<{
    Type: string;
    LogicalId: string;
}>>;
//# sourceMappingURL=StreamSinkHttp.d.ts.map