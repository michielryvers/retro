import * as pipelines from "@distilled.cloud/cloudflare/pipelines";
import type { PropsInput } from "alchemy/Input";
import * as Provider from "alchemy/Provider";
import { Resource, type ResourceClass } from "alchemy/Resource";
import * as Effect from "effect/Effect";
import type * as Schema from "effect/Schema";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
import { type StreamFieldsSchema } from "./StreamSchema.ts";
declare const StreamTypeId: "Cloudflare.Pipelines.Stream";
type StreamTypeId = typeof StreamTypeId;
/**
 * Input format of events ingested by the stream.
 */
export interface StreamFormat {
    /** Only JSON ingestion is supported. */
    type: "json";
    /**
     * Accept events of any shape (no schema enforcement).
     */
    unstructured?: boolean;
    /**
     * How timestamps are rendered in ingested JSON.
     * @default "rfc3339"
     */
    timestampFormat?: "rfc3339" | "unix_millis";
    /** How decimals are encoded in ingested JSON. */
    decimalEncoding?: "number" | "string" | "bytes";
}
/**
 * HTTP ingest endpoint configuration. Mutable in place.
 */
export interface StreamHttp {
    /**
     * Whether the stream exposes an HTTP ingest endpoint.
     * @default true
     */
    enabled?: boolean;
    /**
     * Whether requests to the HTTP endpoint must carry a Cloudflare API
     * token with the `Pipelines Send` permission.
     * @default false
     */
    authentication?: boolean;
    /** CORS configuration for browser-originated ingestion. */
    cors?: {
        /** Allowed origins, e.g. `["https://app.example.com"]` or `["*"]`. */
        origins?: string[];
    };
}
export interface StreamProps {
    /**
     * Name of the stream. Unique per account; must be alphanumeric and
     * underscores only (it is referenced as a SQL table name). If omitted,
     * a unique name is generated from the app, stage, and logical ID.
     * Changing the name triggers a replacement.
     * @default ${app}_${id}_${stage}_${suffix}
     */
    name?: string;
    /**
     * Structured schema of ingested events — either an explicit field list
     * or an Effect Schema (`Schema.Struct` / `Schema.Class`), which is
     * converted to the field list and also types and encodes the records
     * sent through `WriteStream` / `StreamSink`.
     *
     * Immutable — changing the (derived) field list triggers a replacement,
     * which drops buffered events and dependent pipelines. Equivalent
     * spellings (a field list ⇄ the matching Effect Schema) are a no-op.
     * When omitted, the stream accepts unstructured JSON events.
     */
    schema?: StreamFieldsSchema | Schema.Top;
    /**
     * Input format configuration. Immutable — changing it triggers a
     * replacement.
     * @default { type: "json" }
     */
    format?: StreamFormat;
    /**
     * HTTP ingest endpoint configuration. Mutable in place.
     *
     * - omitted / `false` — no public HTTP endpoint (`{ enabled: false }`)
     * - `true` — endpoint enabled, API-token authentication required
     * - an object — explicit settings
     * @default false
     */
    http?: boolean | StreamHttp;
    /**
     * Whether Workers can send events to this stream via a `pipelines`
     * binding. Mutable in place.
     * @default { enabled: true }
     */
    workerBinding?: {
        /** Whether the Worker binding is enabled. */
        enabled: boolean;
    };
}
export interface StreamAttributes {
    /** Cloudflare-assigned stream identifier. */
    streamId: string;
    /** Account that owns the stream. */
    accountId: string;
    /** Stream name (unique per account). */
    name: string;
    /** HTTP ingest endpoint URL, when HTTP ingestion is enabled. */
    endpoint: string | undefined;
    /** Whether the HTTP ingest endpoint is enabled. */
    httpEnabled: boolean;
    /** Whether the HTTP ingest endpoint requires authentication. */
    httpAuthentication: boolean;
    /** Allowed CORS origins of the HTTP ingest endpoint. */
    corsOrigins: string[] | undefined;
    /** Whether Workers can send events via a `pipelines` binding. */
    workerBindingEnabled: boolean;
    /** Current version of the stream. */
    version: number;
    /** When the stream was created. */
    createdAt: string;
    /** When the stream was last modified. */
    modifiedAt: string;
}
/**
 * A Pipelines stream. `A` is the record type sent through `WriteStream` /
 * `StreamSink` — the Effect Schema's `Type` when the stream was declared
 * with one.
 */
export interface Stream<A = unknown> extends Resource<StreamTypeId, StreamProps, StreamAttributes, never, Providers> {
    /**
     * The Effect Schema the stream was declared with, if any. Used by the
     * producer clients to encode records; never persisted.
     */
    readonly RecordSchema: Schema.Top | undefined;
    /** Phantom record type. */
    readonly "~record"?: A;
}
/**
 * The record type a producer sends to a `Stream<A>`: the declared Effect
 * Schema's `Type`, or an untyped JSON object.
 */
export type StreamRecord<A> = unknown extends A ? Record<string, unknown> : A;
/**
 * Props of a stream declared with an Effect Schema.
 */
export type StreamSchemaProps<S extends Schema.Top> = PropsInput<Omit<StreamProps, "schema">> & {
    schema: S;
};
/**
 * The Stream constructor: the plain resource constructor plus an overload
 * that infers the record type from an Effect Schema `schema`.
 */
export type StreamClass = {
    <const S extends Schema.Top>(id: string, props: StreamSchemaProps<S>): Effect.Effect<Stream<S["Type"]>, never, Providers>;
} & ResourceClass<Stream>;
/**
 * A Cloudflare Pipelines stream — the ingestion endpoint of the Pipelines
 * product (also exported as `Cloudflare.Basin.Stream`). Events are sent to
 * a stream from Workers (`WriteStream` / `StreamSink`) or over HTTP,
 * transformed by a SQL {@link Pipeline}, and written to a {@link Sink}.
 *
 * The stream's `schema` and `format` are fixed at creation (changing them
 * triggers a replacement, which drops buffered events and dependent
 * pipelines); the HTTP endpoint and Worker-binding toggles are mutable in
 * place.
 *
 * Pipelines is ingest-only — there is no event source on a stream. To
 * process data after it lands, subscribe to the sink's bucket with
 * `Cloudflare.R2.BucketEventNotification`.
 *
 * Cloudflare accepts records that violate a structured stream's schema
 * (they are dropped later, during processing). Declare the schema as an
 * Effect Schema to have the producer clients validate and encode every
 * record before it is sent.
 *
 * :::caution
 * A stream declared without `http` has **no** public ingest endpoint
 * (`http: { enabled: false }`). Earlier versions sent nothing, and
 * Cloudflare's default is a public, unauthenticated endpoint. Existing
 * streams are updated in place on the next deploy; set `http: true`
 * (authenticated) or `http: { enabled: true }` to keep an endpoint.
 * :::
 *
 * ### Creating a Stream
 * **Example:** Unstructured stream with default settings
 * ```typescript
 * const stream = yield* Cloudflare.Basin.Stream("events", {});
 * ```
 *
 * **Example:** Structured stream from an Effect Schema
 * ```typescript
 * class PageView extends Schema.Class<PageView>("PageView")({
 *   url: Schema.String,
 *   at: Schema.Date,
 *   tags: Schema.Array(Schema.String),
 *   user: Schema.optional(Schema.Struct({ id: Schema.String })),
 * }) {}
 *
 * // Stream<PageView>: WriteStream / StreamSink are typed and encode records
 * const stream = yield* Cloudflare.Basin.Stream("PageViews", {
 *   schema: PageView,
 * });
 * ```
 *
 * **Example:** Structured stream with an explicit field list
 * ```typescript
 * const stream = yield* Cloudflare.Basin.Stream("clicks", {
 *   schema: {
 *     fields: [
 *       { type: "string", name: "url", required: true },
 *       { type: "timestamp", name: "ts", unit: "millisecond" },
 *       { type: "list", name: "tags", items: { type: "string" } },
 *       {
 *         type: "struct",
 *         name: "user",
 *         fields: [{ type: "string", name: "id" }],
 *       },
 *     ],
 *   },
 * });
 * ```
 *
 * ### HTTP ingestion
 * **Example:** Authenticated endpoint
 * ```typescript
 * const stream = yield* Cloudflare.Basin.Stream("events", { http: true });
 * // POST a JSON array to stream.endpoint with a `Pipelines Send` token,
 * // or use Cloudflare.Basin.WriteStreamHttp / WriteStreamLocal.
 * ```
 *
 * **Example:** Public endpoint with CORS
 * ```typescript
 * const stream = yield* Cloudflare.Basin.Stream("beacons", {
 *   http: {
 *     enabled: true,
 *     authentication: false,
 *     cors: { origins: ["https://app.example.com"] },
 *   },
 * });
 * ```
 *
 * ### Wiring into a Pipeline
 * **Example:** Stream → SQL Pipeline → Sink
 * ```typescript
 * const pipeline = yield* Cloudflare.Basin.Pipeline("etl", {
 *   sql: Output.interpolate`INSERT INTO ${sink.name} SELECT * FROM ${stream.name}`,
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/pipelines/
 *
 * @resource
 * @product Pipelines
 * @category Storage & Databases
 */
export declare const Stream: StreamClass;
/**
 * Returns true if the given value is a Stream resource.
 */
export declare const isStream: (value: unknown) => value is Stream;
export declare const StreamProvider: () => import("effect/Layer").Layer<Provider.Provider<Stream<unknown>>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | pipelines.CloudflareOpContext>;
export {};
//# sourceMappingURL=Stream.d.ts.map