import * as Layer from "effect/Layer";
import { StreamSink, type StreamSinkClient } from "./StreamSink.ts";
import { WriteStream, type WriteStreamClient } from "./WriteStream.ts";
/**
 * Batch packing for {@link StreamSink}. Internal — not exported from the
 * Pipelines barrel.
 */
/** Pipelines' limit on one ingest request (5 MB), minus the array brackets. */
export declare const MAX_REQUEST_BYTES: number;
/**
 * Build the sink over a `WriteStream` client: each chunk is encoded, then
 * packed into `<= MAX_REQUEST_BYTES` requests (order preserved) and sent
 * one `sendEncoded` per request.
 */
export declare const makeStreamSink: <A>(client: WriteStreamClient<A>) => StreamSinkClient<A>;
/**
 * {@link StreamSink} over whichever {@link WriteStream} implementation is
 * provided. Composed with each `WriteStream` layer in
 * `StreamSinkBinding`, `StreamSinkHttp` and `StreamSinkLocal`.
 */
export declare const StreamSinkFromWriteStream: Layer.Layer<StreamSink, never, WriteStream>;
//# sourceMappingURL=StreamSinkBatch.d.ts.map