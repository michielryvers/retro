import type { RuntimeContext } from "alchemy/RuntimeContext";
import { Self } from "alchemy/Self";
import * as Effect from "effect/Effect";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../Credentials.ts";
import { type LegacyPipeline } from "./LegacyPipeline.ts";
import type { Stream } from "./Stream.ts";
import { type WriteStreamClient } from "./WriteStream.ts";
/**
 * Shared scaffolding for the HTTP-ingest Pipelines clients
 * (`WriteStreamHttp`, `WriteStreamLocal` and the matching StreamSink
 * layers). Internal — not exported from the Pipelines barrel.
 */
/**
 * Injectable auth: runs a raw distilled op (which needs
 * `Credentials | HttpClient`) and discharges those requirements down to
 * {@link RuntimeContext}. The HTTP variant provides a minted token; the
 * Local variant provides the ambient current-credentials context.
 */
export interface StreamAuth {
    authorize: <A, E>(eff: Effect.Effect<A, E, Credentials | HttpClient.HttpClient>) => Effect.Effect<A, E, RuntimeContext>;
}
/** Legacy pipelines have their own ingest endpoint; only streams are supported. */
export declare const legacyPipelineUnsupported: (layer: string) => Effect.Effect<never, never, never>;
/**
 * Build the producer client over the stream's HTTP ingest endpoint
 * (`POST https://{stream_id}.ingest.cloudflare.com`, at most 5 MB per
 * request). The stream needs `http` enabled.
 */
export declare const makeWriteStreamHttpClient: (auth: StreamAuth, stream: Stream<any>, streamId: Effect.Effect<string>) => WriteStreamClient<any>;
/**
 * Mint (or reuse) the host's scoped {@link AccountApiToken}, grant it
 * `Pipelines Send`, bind its value into the host at deploy time, and
 * build the client with it.
 */
export declare const makeHttpStreamBinding: <Client>(options: {
    layer: string;
    makeClient: (client: WriteStreamClient<any>) => Client;
}) => Effect.Effect<(stream: Stream<any> | LegacyPipeline) => Effect.Effect<Client, never, never>, never, Self<{
    Type: string;
    LogicalId: string;
}>>;
/**
 * Build the client with the **current credentials** captured at layer
 * build (no Worker host, no minted token).
 */
export declare const makeLocalStreamBinding: <Client>(options: {
    layer: string;
    makeClient: (client: WriteStreamClient<any>) => Client;
}) => Effect.Effect<(stream: Stream<any> | LegacyPipeline) => Effect.Effect<Client, never, never>, never, Credentials | HttpClient.HttpClient>;
//# sourceMappingURL=StreamHttp.d.ts.map