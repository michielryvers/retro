import * as pipelines from "@distilled.cloud/cloudflare/pipelines";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Redacted from "effect/Redacted";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
declare const TypeId: "Cloudflare.Pipelines.LegacyPipeline";
type TypeId = typeof TypeId;
/**
 * HTTP ingest source — events are POSTed as JSON to the pipeline's
 * `endpoint` URL.
 */
export interface LegacyPipelineHttpSource {
    /** Accept events over HTTP at the pipeline endpoint. */
    type: "http";
    /**
     * Require Cloudflare API-token authentication on the ingest endpoint.
     * @default false
     */
    authentication?: boolean;
    /**
     * CORS configuration for browser-originated ingestion.
     */
    cors?: {
        /** Allowed origins, e.g. `["https://example.com"]` or `["*"]`. */
        origins?: string[];
    };
}
/**
 * Worker binding ingest source — events are sent from a Worker via a
 * `pipelines` binding.
 */
export interface LegacyPipelineBindingSource {
    /** Accept events from a Worker `pipelines` binding. */
    type: "binding";
}
/**
 * An ingest source of a legacy pipeline.
 */
export type LegacyPipelineSource = LegacyPipelineHttpSource | LegacyPipelineBindingSource;
/**
 * R2 destination configuration of a legacy pipeline.
 */
export interface LegacyPipelineDestination {
    /**
     * Name of the destination R2 bucket. The bucket must already exist.
     */
    bucket: string;
    /**
     * R2 S3-compatible credentials the pipeline uses to write objects.
     * Write-only — Cloudflare never echoes them back.
     */
    credentials: {
        /** R2 access key id (the API token id). */
        accessKeyId: Redacted.Redacted<string>;
        /** R2 secret access key (SHA-256 hex of the API token value). */
        secretAccessKey: Redacted.Redacted<string>;
        /**
         * S3-compatible endpoint of the R2 bucket.
         * @default https://{accountId}.r2.cloudflarestorage.com
         */
        endpoint?: string;
    };
    /**
     * Batching policy controlling when the pipeline flushes a batch of
     * events to R2.
     */
    batch?: {
        /** Flush once the batch reaches this size in bytes. */
        maxBytes?: number;
        /** Flush at most this many seconds after the batch was opened. */
        maxDurationS?: number;
        /** Flush once the batch reaches this many events. */
        maxRows?: number;
    };
    /**
     * Compression applied to output files.
     * @default "gzip"
     */
    compression?: "none" | "gzip" | "deflate";
    /**
     * Key prefix under which output objects are written.
     */
    prefix?: string;
    /**
     * Time-partitioned directory layout of output object keys
     * (strftime-style, e.g. `event_date=%F/hr=%H`).
     */
    filepath?: string;
    /**
     * Name template of output files within a partition.
     */
    filename?: string;
}
export interface LegacyPipelineProps {
    /**
     * Name of the pipeline. Unique per account; the legacy API addresses
     * pipelines by name, so changing it triggers a replacement. If
     * omitted, a unique name is generated from the app, stage, and
     * logical ID.
     * @default ${app}-${id}-${stage}-${suffix}
     */
    name?: string;
    /**
     * Ingest sources accepted by the pipeline.
     * @default [{ type: "http" }, { type: "binding" }]
     */
    source?: LegacyPipelineSource[];
    /**
     * R2 destination the pipeline batches events into.
     */
    destination: LegacyPipelineDestination;
}
export interface LegacyPipelineAttributes {
    /** Cloudflare-assigned pipeline identifier. */
    pipelineId: string;
    /** Account that owns the pipeline. */
    accountId: string;
    /** Pipeline name (unique per account; the API identifier). */
    name: string;
    /** HTTP endpoint URL events can be POSTed to. */
    endpoint: string;
    /** Destination R2 bucket name. */
    bucket: string;
    /** Version number of the last saved configuration. */
    version: number;
}
export type LegacyPipeline = Resource<TypeId, LegacyPipelineProps, LegacyPipelineAttributes, never, Providers>;
/**
 * A **legacy** Cloudflare Pipeline — the original HTTP-ingest → R2 batch
 * product (`/accounts/{account}/pipelines`).
 *
 * :::caution
 * This is the **deprecated, legacy** Pipelines API. Cloudflare has
 * superseded it with the SQL-based product — prefer
 * {@link Stream}, {@link Sink}, and {@link Pipeline}
 * for new infrastructure. This resource exists only to manage
 * pre-existing legacy pipelines.
 * :::
 *
 * A legacy pipeline accepts JSON events over HTTP (and/or a Worker
 * `pipelines` binding) and batches them into an R2 bucket using
 * S3-compatible credentials.
 * ### Creating a Legacy Pipeline
 * **Example:** HTTP ingest into R2
 * The S3-compatible credentials are derived from a Cloudflare API token:
 * the access key id is the token id and the secret is the SHA-256 hex
 * digest of the token value.
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("events", {});
 *
 * const pipeline = yield* Cloudflare.Pipelines.LegacyPipeline("ingest", {
 *   destination: {
 *     bucket: bucket.bucketName,
 *     credentials: {
 *       accessKeyId: yield* Config.Redacted("R2_ACCESS_KEY_ID"),
 *       secretAccessKey: yield* Config.Redacted("R2_SECRET_ACCESS_KEY"),
 *     },
 *   },
 * });
 * // POST events to pipeline.endpoint
 * ```
 *
 * **Example:** Tuned batching and CORS
 * ```typescript
 * const pipeline = yield* Cloudflare.Pipelines.LegacyPipeline("ingest", {
 *   source: [
 *     { type: "http", cors: { origins: ["https://example.com"] } },
 *   ],
 *   destination: {
 *     bucket: bucket.bucketName,
 *     credentials,
 *     batch: { maxDurationS: 10, maxRows: 1000 },
 *     compression: "gzip",
 *     prefix: "ingest",
 *   },
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/pipelines/
 *
 * @resource
 * @product Pipelines
 * @category Storage & Databases
 */
export declare const LegacyPipeline: import("alchemy/Resource").ResourceClass<LegacyPipeline>;
/**
 * Returns true if the given value is a LegacyPipeline resource.
 */
export declare const isLegacyPipeline: (value: unknown) => value is LegacyPipeline;
export declare const LegacyPipelineProvider: () => import("effect/Layer").Layer<Provider.Provider<LegacyPipeline>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | pipelines.CloudflareOpContext>;
export {};
//# sourceMappingURL=LegacyPipeline.d.ts.map