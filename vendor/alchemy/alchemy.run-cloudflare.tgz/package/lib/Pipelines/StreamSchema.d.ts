import * as Schema from "effect/Schema";
/**
 * Scalar field types accepted by a structured stream schema.
 */
export type StreamFieldType = "int32" | "int64" | "float32" | "float64" | "bool" | "string" | "binary" | "json";
/**
 * Timestamp precision of a `timestamp` stream field.
 */
export type StreamTimestampUnit = "second" | "millisecond" | "microsecond" | "nanosecond";
/**
 * The type of a stream field (or list element), without its name.
 */
export type StreamFieldItem = {
    /** Scalar field type. */
    type: StreamFieldType;
    /** Whether the value must be present. */
    required?: boolean;
} | {
    /** Timestamp field type. */
    type: "timestamp";
    /** Whether the value must be present. */
    required?: boolean;
    /**
     * Precision of numeric timestamps.
     * @default "millisecond"
     */
    unit?: StreamTimestampUnit;
} | {
    /** List (array) field type. */
    type: "list";
    /** Whether the value must be present. */
    required?: boolean;
    /** Type of every element of the list. */
    items: StreamFieldItem;
} | {
    /** Nested object field type. */
    type: "struct";
    /** Whether the value must be present. */
    required?: boolean;
    /** Fields of the nested object. */
    fields: StreamField[];
};
/**
 * A single named field of a structured stream schema. `timestamp` fields
 * additionally accept a `unit`, `list` fields an `items` type and
 * `struct` fields nested `fields`.
 */
export type StreamField = StreamFieldItem & {
    /** Field name as it appears in ingested events. */
    name: string;
    /** Whether the field must be present in every event. */
    required?: boolean;
    /** Name to expose to SQL when it differs from `name`. */
    sqlName?: string;
    /** Metadata key the field is populated from instead of the event body. */
    metadataKey?: string;
};
/**
 * A structured stream schema as an explicit field list.
 */
export interface StreamFieldsSchema {
    /** Fields of the structured schema. */
    fields: StreamField[];
}
/**
 * Annotation key that overrides the stream field type derived from an
 * Effect Schema, e.g. to store a number as `int32` or `float32`:
 *
 * ```typescript
 * Schema.Number.annotate({ [StreamFieldTypeAnnotation]: "float32" })
 * ```
 */
export declare const StreamFieldTypeAnnotation: "pipelinesFieldType";
declare const StreamSchemaUnsupported_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Cloudflare.Pipelines.StreamSchemaUnsupported";
} & Readonly<A>;
/**
 * Raised when an Effect Schema passed as a stream `schema` has no
 * Pipelines representation (e.g. a union of different types).
 */
export declare class StreamSchemaUnsupported extends StreamSchemaUnsupported_base<{
    message: string;
    path: string;
}> {
}
/**
 * Returns true if `value` is an Effect Schema (rather than a field list).
 */
export declare const isEffectSchema: (value: unknown) => value is Schema.Top;
/**
 * Convert an Effect Schema (`Schema.Struct` / `Schema.Class`) into the
 * Pipelines stream field list. The schema's **encoded** side is used, so
 * transformations (e.g. `NumberFromString`) map to their wire type, and
 * records are sent with `Schema.toCodecJson(schema)`:
 *
 * - `String` → `string`, `Boolean` → `bool`
 * - `Number` → `float64`, `Int` → `int64` (`int32` when bounded to 32 bits)
 * - `Date` → `timestamp`, `Uint8Array` → `binary`
 * - `Array` → `list`, `Struct` / `Class` → `struct`
 * - `Record` / `Unknown` / `Json` → `json`
 * - optional or nullable fields → `required: false`
 *
 * Unions of different types, tuples and recursive schemas have no stream
 * representation and throw {@link StreamSchemaUnsupported}. Override any
 * field's type with the {@link StreamFieldTypeAnnotation} annotation.
 */
export declare const streamFieldsFromSchema: (schema: Schema.Top) => StreamField[];
/**
 * Resolve a stream `schema` prop (field list or Effect Schema) to the
 * field-list form persisted in state and sent to Cloudflare.
 */
export declare const resolveStreamSchema: (schema: StreamFieldsSchema | Schema.Top | undefined) => StreamFieldsSchema | undefined;
/**
 * Canonical form of a field list: defaults filled in (`required: false`,
 * `unit: "millisecond"`), absent optional keys dropped.
 */
export declare const canonicalStreamFields: (fields: ReadonlyArray<StreamField>) => unknown[];
export {};
//# sourceMappingURL=StreamSchema.d.ts.map