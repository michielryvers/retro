import type { RuntimeContext } from "alchemy/RuntimeContext";
import type { Pipeline, PipelineRecord } from "cloudflare:pipelines";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
import { type LegacyPipeline } from "./LegacyPipeline.ts";
import type { Stream } from "./Stream.ts";
import { StreamSendError, type WriteStreamClient } from "./WriteStream.ts";
/**
 * Shared record encoding + client assembly for the WriteStream / StreamSink
 * implementations. Internal — not exported from the Pipelines barrel.
 */
/**
 * The Effect Schema a stream was declared with, if any. Legacy pipelines
 * have none.
 */
export declare const recordSchemaOf: (stream: Stream<any> | LegacyPipeline) => Schema.Top | undefined;
/**
 * Build the batch encoder: `Schema.toCodecJson(schema)` per record when
 * the stream has an Effect Schema, identity otherwise.
 */
export declare const makeRecordEncoder: (schema: Schema.Top | undefined) => ((records: ReadonlyArray<unknown>) => Effect.Effect<ReadonlyArray<PipelineRecord>, StreamSendError>);
/** Wrap any transport failure as a `SendFailed` {@link StreamSendError}. */
export declare const toStreamSendError: (error: unknown) => StreamSendError;
/** Assemble a {@link WriteStreamClient} from an encoder and a transport. */
export declare const makeStreamClient: (options: {
    schema: Schema.Top | undefined;
    raw: Effect.Effect<Pipeline, never, RuntimeContext>;
    sendEncoded: (records: ReadonlyArray<PipelineRecord>) => Effect.Effect<void, StreamSendError, RuntimeContext>;
}) => WriteStreamClient<any>;
/**
 * Approximate wire size of one encoded record in the JSON array body:
 * its UTF-8 JSON plus the separating comma. Values JSON cannot encode
 * count as 1 byte; the send rejects them and the error surfaces.
 */
export declare const recordSize: (record: PipelineRecord) => number;
//# sourceMappingURL=StreamCodec.d.ts.map