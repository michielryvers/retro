import * as pipelines from "@distilled.cloud/cloudflare/pipelines";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Redacted from "effect/Redacted";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
import type { Bucket } from "../R2/Bucket.ts";
import type { DataCatalog } from "../R2/DataCatalog.ts";
declare const TypeId: "Cloudflare.Pipelines.Sink";
type TypeId = typeof TypeId;
/**
 * Batching policy controlling when the sink rolls (closes and uploads)
 * the current output file.
 */
export interface SinkRollingPolicy {
    /**
     * Roll the file once it reaches this size in bytes.
     */
    fileSizeBytes?: number;
    /**
     * Roll the file after this many seconds without new events.
     */
    inactivitySeconds?: number;
    /**
     * Roll the file at most this many seconds after it was opened.
     * @default 300
     */
    intervalSeconds?: number;
}
/**
 * Configuration of an `r2` sink writing raw files to an R2 bucket.
 */
export interface SinkR2Config {
    /**
     * The destination R2 bucket: a `Cloudflare.R2.Bucket` resource (orders the
     * sink after the bucket) or a bucket name. The bucket must already exist.
     */
    bucket: string | Bucket;
    /**
     * R2 S3-compatible credentials the sink uses to write objects.
     * Write-only — Cloudflare never echoes them back, and sinks cannot be
     * updated, so changing them does NOT replace the sink (see the
     * resource docs on rotating credentials).
     */
    credentials: {
        /** R2 access key id (the API token id). */
        accessKeyId: Redacted.Redacted<string>;
        /** R2 secret access key (SHA-256 hex of the API token value). */
        secretAccessKey: Redacted.Redacted<string>;
    };
    /**
     * Key prefix under which output objects are written.
     */
    path?: string;
    /**
     * Time-based partitioning of output object keys.
     */
    partitioning?: {
        /**
         * strftime-style pattern, e.g. `year=%Y/month=%m/day=%d`.
         */
        timePattern?: string;
    };
    /**
     * Naming of output files within a partition.
     */
    fileNaming?: {
        /** Prefix prepended to each file name. */
        prefix?: string;
        /** Suffix appended to each file name. */
        suffix?: string;
        /**
         * Strategy generating the unique part of each file name.
         * @default "uuid_v7"
         */
        strategy?: "serial" | "uuid" | "uuid_v7" | "ulid";
    };
    /**
     * When the sink rolls output files.
     */
    rollingPolicy?: SinkRollingPolicy;
    /**
     * Jurisdiction the bucket was created in (`eu`, `fedramp`), when not
     * the default.
     */
    jurisdiction?: string;
}
/**
 * Configuration of a catalog sink writing an Iceberg table via the Basin
 * (R2 Data) Catalog, spelled with the bucket name.
 */
export interface SinkR2DataCatalogConfig {
    /**
     * The R2 bucket backing the catalog: a `Cloudflare.R2.Bucket` resource or a
     * bucket name. The bucket must already exist and have the catalog enabled.
     */
    bucket: string | Bucket;
    /**
     * Name of the Iceberg table to write.
     */
    tableName: string;
    /**
     * Catalog namespace the table lives in.
     * @default "default"
     */
    namespace?: string;
    /**
     * Cloudflare API token with R2 Data Catalog permissions. Write-only —
     * Cloudflare never echoes it back, and changing it does NOT replace
     * the sink.
     */
    token: Redacted.Redacted<string>;
    /**
     * When the sink rolls output files.
     */
    rollingPolicy?: SinkRollingPolicy;
}
/**
 * The catalog a catalog sink writes to: a `Cloudflare.Basin.Catalog`
 * (`Cloudflare.R2.DataCatalog`) resource, which orders the sink after the
 * catalog, or the name of the bucket the catalog is enabled on.
 */
export type SinkCatalogReference = string | DataCatalog;
/**
 * The Iceberg table a catalog sink writes to.
 */
export interface SinkCatalogTable {
    /**
     * Catalog namespace the table lives in.
     * @default "default"
     */
    namespace?: string;
    /** Table name. */
    name: string;
}
/**
 * Sink type of a catalog sink. `basin_catalog` and `r2_data_catalog` are
 * the same destination; switching between them never replaces the sink.
 */
export type SinkCatalogType = "basin_catalog" | "r2_data_catalog";
/**
 * Output file format written by the sink.
 */
export type SinkFormat = {
    /** Newline-delimited JSON output. */
    type: "json";
} | {
    /** Parquet output. */
    type: "parquet";
    /**
     * Compression codec.
     * @default "zstd"
     */
    compression?: "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
    /** Target row-group size in bytes. */
    rowGroupBytes?: number;
};
interface SinkBaseProps {
    /**
     * Name of the sink. Unique per account; must be alphanumeric and
     * underscores only (it is referenced as a SQL table name). If omitted,
     * a unique name is generated from the app, stage, and logical ID.
     *
     * Sinks have no update API, so changing this (or any destination
     * property) triggers a replacement.
     * @default ${app}_${id}_${stage}_${suffix}
     */
    name?: string;
    /**
     * Output file format. Catalog sinks require Parquet.
     * @default { type: "json" } for `r2` sinks, { type: "parquet" } for catalog sinks
     */
    format?: SinkFormat;
}
export type SinkProps = (SinkBaseProps & {
    /**
     * Sink type — `r2` writes raw files to an R2 bucket.
     */
    type: "r2";
    /**
     * R2 destination configuration.
     */
    config: SinkR2Config;
}) | (SinkBaseProps & {
    /**
     * Sink type — writes an Iceberg table via the Basin (R2 Data)
     * Catalog.
     */
    type: SinkCatalogType;
    /**
     * Catalog destination configuration, spelled with the bucket name.
     * Equivalent to the `catalog` / `table` / `token` form.
     */
    config: SinkR2DataCatalogConfig;
}) | (SinkBaseProps & {
    /**
     * Sink type — writes an Iceberg table via the Basin (R2 Data)
     * Catalog.
     */
    type: SinkCatalogType;
    /**
     * The catalog to write to: a `Cloudflare.Basin.Catalog` resource or
     * the name of the bucket the catalog is enabled on.
     */
    catalog: SinkCatalogReference;
    /**
     * The Iceberg table to write. Cloudflare creates it with the
     * sink — sinks cannot be created for existing Iceberg tables.
     */
    table: SinkCatalogTable;
    /**
     * Cloudflare API token with R2 Data Catalog permissions. Write-only;
     * changing it does NOT replace the sink.
     */
    token: Redacted.Redacted<string>;
    /**
     * When the sink rolls output files.
     */
    rollingPolicy?: SinkRollingPolicy;
});
export interface SinkAttributes {
    /** Cloudflare-assigned sink identifier. */
    sinkId: string;
    /** Account that owns the sink. */
    accountId: string;
    /** Sink name (unique per account). */
    name: string;
    /** Sink type. */
    type: "r2" | SinkCatalogType;
    /** Destination R2 bucket name. */
    bucket: string;
    /** Key prefix output objects are written under (r2 sinks). */
    path: string | undefined;
    /** Catalog namespace of the destination table (catalog sinks). */
    namespace: string | undefined;
    /** Destination Iceberg table name (catalog sinks). */
    tableName: string | undefined;
    /** When the sink was created. */
    createdAt: string;
    /** When the sink was last modified. */
    modifiedAt: string;
}
export type Sink = Resource<TypeId, SinkProps, SinkAttributes, never, Providers>;
/**
 * A Cloudflare Pipelines sink — the destination of the Pipelines product
 * (also exported as `Cloudflare.Basin.Sink`). A SQL {@link Pipeline}
 * reads events from a {@link Stream} and writes them to a sink, which
 * stores them in R2 either as raw files (`r2`) or as an Iceberg table via
 * the Basin Catalog (`basin_catalog`, a.k.a. `r2_data_catalog`).
 *
 * Sinks have no update API: changing the destination (bucket, path,
 * table, format, partitioning, rolling policy) triggers a replacement.
 * Equivalent spellings never replace — `basin_catalog` ⇄
 * `r2_data_catalog`, the `config` form ⇄ the `catalog` / `table` form,
 * omitted ⇄ explicit defaults. With engine-generated names a replacement
 * is seamless (the new sink gets a fresh name before the old one is
 * deleted); with an explicit `name` it collides, so prefer generated
 * names.
 *
 * Credentials (`credentials`, `token`) are write-only and are not part of
 * the replacement diff, so rotating them never recreates the sink — a
 * catalog sink could not be recreated anyway, because Cloudflare refuses
 * to create sinks for existing Iceberg tables. The sink keeps the
 * credentials it was created with; to move it onto new ones, rename it
 * (which replaces it).
 *
 * Pipelines is ingest-only — to react to files the sink writes, subscribe
 * to its bucket with `Cloudflare.R2.BucketEventNotification`.
 *
 * ### Creating a Sink
 * **Example:** R2 sink with JSON output
 * The S3-compatible credentials are derived from a Cloudflare API token:
 * the access key id is the token id and the secret is the SHA-256 hex
 * digest of the token value.
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("events", {});
 *
 * const sink = yield* Cloudflare.Basin.Sink("events-sink", {
 *   type: "r2",
 *   config: {
 *     bucket,
 *     credentials: {
 *       accessKeyId: yield* Config.Redacted("R2_ACCESS_KEY_ID"),
 *       secretAccessKey: yield* Config.Redacted("R2_SECRET_ACCESS_KEY"),
 *     },
 *     path: "ingest",
 *     rollingPolicy: { intervalSeconds: 30 },
 *   },
 * });
 * ```
 *
 * **Example:** Parquet output
 * ```typescript
 * const sink = yield* Cloudflare.Basin.Sink("parquet-sink", {
 *   type: "r2",
 *   config: { bucket, credentials },
 *   format: { type: "parquet", compression: "zstd" },
 * });
 * ```
 *
 * ### Basin Catalog
 * **Example:** Iceberg table sink
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("Lakehouse", {});
 * const catalog = yield* Cloudflare.Basin.Catalog("Catalog", {
 *   bucket,
 * });
 *
 * const sink = yield* Cloudflare.Basin.Sink("PageViewTable", {
 *   type: "basin_catalog",
 *   catalog,
 *   table: { namespace: "web", name: "page_views" },
 *   token: yield* Config.Redacted("CATALOG_TOKEN"),
 * });
 * ```
 *
 * **Example:** Bucket-name form
 * ```typescript
 * const sink = yield* Cloudflare.Basin.Sink("iceberg-sink", {
 *   type: "r2_data_catalog",
 *   config: {
 *     bucket,
 *     tableName: "events",
 *     namespace: "default",
 *     token: yield* Config.Redacted("CATALOG_TOKEN"),
 *   },
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/pipelines/
 *
 * @resource
 * @product Pipelines
 * @category Storage & Databases
 */
export declare const Sink: import("alchemy/Resource").ResourceClass<Sink>;
/**
 * Returns true if the given value is a Sink resource.
 */
export declare const isSink: (value: unknown) => value is Sink;
export declare const SinkProvider: () => import("effect/Layer").Layer<Provider.Provider<Sink>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | pipelines.CloudflareOpContext>;
export {};
//# sourceMappingURL=Sink.d.ts.map