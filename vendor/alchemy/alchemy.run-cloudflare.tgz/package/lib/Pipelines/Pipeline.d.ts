import * as pipelines from "@distilled.cloud/cloudflare/pipelines";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
declare const TypeId: "Cloudflare.Pipelines.Pipeline";
type TypeId = typeof TypeId;
export interface PipelineProps {
    /**
     * Name of the pipeline. Unique per account; must be alphanumeric and
     * underscores only. If omitted, a unique name is generated from the
     * app, stage, and logical ID.
     *
     * Pipelines have no update API, so changing this (or the `sql`)
     * triggers a replacement.
     * @default ${app}_${id}_${stage}_${suffix}
     */
    name?: string;
    /**
     * SQL statement describing the processing flow, e.g.
     * `INSERT INTO my_sink SELECT * FROM my_stream`. Streams and sinks are
     * referenced by name — interpolate `stream.name` / `sink.name` outputs
     * so the engine orders the pipeline after them on deploy (and before
     * them on destroy).
     *
     * Immutable — changing the SQL triggers a replacement. Whitespace-only
     * changes are a no-op. A changed, fully-resolved statement is validated
     * during plan, so invalid SQL fails before anything is replaced.
     */
    sql: string;
}
declare const PipelineSqlInvalid_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Cloudflare.Pipelines.PipelineSqlInvalid";
} & Readonly<A>;
/**
 * Raised during plan when a pipeline's SQL is rejected by Cloudflare's
 * SQL validator (`InvalidSql`, code 1014). Nothing has been replaced or
 * deleted when this fails.
 */
export declare class PipelineSqlInvalid extends PipelineSqlInvalid_base<{
    message: string;
    sql: string;
}> {
}
export interface PipelineAttributes {
    /** Cloudflare-assigned pipeline identifier. */
    pipelineId: string;
    /** Account that owns the pipeline. */
    accountId: string;
    /** Pipeline name (unique per account). */
    name: string;
    /** SQL statement of the processing flow. */
    sql: string;
    /** Current status of the pipeline. */
    status: string;
    /** When the pipeline was created. */
    createdAt: string;
    /** When the pipeline was last modified. */
    modifiedAt: string;
}
export type Pipeline = Resource<TypeId, PipelineProps, PipelineAttributes, never, Providers>;
/**
 * A Cloudflare SQL Pipeline — the transform of the Pipelines product. A
 * pipeline is a single SQL statement that reads events from a
 * {@link Stream} and writes them to a {@link Sink}, both
 * referenced by name.
 *
 * Also exported as `Cloudflare.Basin.Pipeline`.
 *
 * The SQL is fixed at creation: changing it (or the name) triggers a
 * replacement. Nothing references a pipeline downstream, so replacements
 * are cheap. A changed statement is checked with Cloudflare's SQL
 * validator during plan, so a syntax error fails the plan (with
 * {@link PipelineSqlInvalid}) instead of deleting the running pipeline.
 * References to streams/sinks that do not exist yet are not an error at
 * plan time — they are created in the same deploy.
 *
 * Pipelines is ingest-only: to process data after the sink writes it,
 * subscribe to the sink's bucket with `Cloudflare.R2.BucketEventNotification`.
 * ### Creating a Pipeline
 * **Example:** Stream → Sink passthrough
 * ```typescript
 * const stream = yield* Cloudflare.Basin.Stream("events", {});
 * const sink = yield* Cloudflare.Basin.Sink("events-sink", {
 *   type: "r2",
 *   config: { bucket: bucket.bucketName, credentials },
 * });
 *
 * const pipeline = yield* Cloudflare.Basin.Pipeline("etl", {
 *   sql: Output.interpolate`INSERT INTO ${sink.name} SELECT * FROM ${stream.name}`,
 * });
 * ```
 *
 * **Example:** Filtering transform
 * ```typescript
 * const pipeline = yield* Cloudflare.Basin.Pipeline("errors-only", {
 *   sql: Output.interpolate`INSERT INTO ${sink.name} SELECT * FROM ${stream.name} WHERE level = 'error'`,
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/pipelines/
 *
 * @resource
 * @product Pipelines
 * @category Storage & Databases
 */
export declare const Pipeline: import("alchemy/Resource").ResourceClass<Pipeline>;
/**
 * Returns true if the given value is a Pipeline resource.
 */
export declare const isPipeline: (value: unknown) => value is Pipeline;
export declare const PipelineProvider: () => import("effect/Layer").Layer<Provider.Provider<Pipeline>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | pipelines.CloudflareOpContext>;
export {};
//# sourceMappingURL=Pipeline.d.ts.map