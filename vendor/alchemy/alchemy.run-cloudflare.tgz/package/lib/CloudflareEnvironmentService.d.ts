import * as Context from "effect/Context";
import type * as Effect from "effect/Effect";
import type { CloudflareResolvedCredentials } from "./Auth/AuthConfig.ts";
declare const CloudflareEnvironment_base: Context.ServiceClass<CloudflareEnvironment, "Cloudflare::CloudflareEnvironment", Effect.Effect<CloudflareResolvedCredentials, never, never>>;
export declare class CloudflareEnvironment extends CloudflareEnvironment_base {
    /**
     * The deploying account, for deploy-time code behind `__ALCHEMY_RUNTIME__`.
     * Its requirement is left off the type: the service is always present at
     * plan/deploy, and runtime hosts outside Cloudflare (e.g. an AWS Lambda
     * using an `*Http` binding) don't have it.
     */
    static current: Effect.Effect<CloudflareResolvedCredentials>;
    readonly kind: "Environment";
}
export {};
//# sourceMappingURL=CloudflareEnvironmentService.d.ts.map