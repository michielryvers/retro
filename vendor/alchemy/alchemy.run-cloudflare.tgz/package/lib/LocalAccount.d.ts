import * as Effect from "effect/Effect";
/** Fallback identity when local dev has no configured Cloudflare account. */
export declare const LOCAL_ACCOUNT_ID = "00000000000000000000000000000000";
export declare const localAccountId: Effect.Effect<string, never, never>;
//# sourceMappingURL=LocalAccount.d.ts.map