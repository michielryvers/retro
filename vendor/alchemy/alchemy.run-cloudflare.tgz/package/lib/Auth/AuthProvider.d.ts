import { CredentialsStore } from "alchemy/Auth/Credentials";
import * as Layer from "effect/Layer";
/**
 * Layer that registers the Cloudflare {@link AuthProvider} into the
 * {@link AuthProviders} registry when built. Include this in the Cloudflare
 * `providers()` layer so the alchemy CLI can discover it.
 */
export declare const CloudflareAuth: Layer.Layer<never, never, import("alchemy/Auth/AuthProvider").AuthProviders | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | CredentialsStore | import("effect/FileSystem").FileSystem | import("effect/Path").Path>;
//# sourceMappingURL=AuthProvider.d.ts.map