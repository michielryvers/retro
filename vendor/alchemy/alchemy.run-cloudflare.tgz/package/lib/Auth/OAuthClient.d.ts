import { type OAuthCredentials } from "alchemy/Auth/OAuthFlow";
/**
 * The `cf` CLI's public Cloudflare OAuth client (no secret), shared with
 * workers-sdk's `cf` login. New authorizations use the device flow
 * (RFC 8628) against it.
 */
export declare const OAUTH_CLIENT_ID = "cbca97e7-c331-4cdd-8fd8-e25a451b98bf";
/**
 * Alchemy's previous Cloudflare OAuth client. Grants issued to it keep
 * refreshing; a manual `profile refresh` re-authorizes them against
 * {@link OAUTH_CLIENT_ID}.
 */
export declare const LEGACY_OAUTH_CLIENT_ID = "e7e25ec474419def6ba38d2d2638b122";
export declare const OAUTH_ENDPOINTS: {
    deviceAuthorization: string;
    token: string;
    revoke: string;
};
export { OAuthCredentials, OAuthError, type DeviceAuthorization } from "alchemy/Auth/OAuthFlow";
/**
 * The client that can refresh and revoke `credentials`, or `undefined` when
 * they were issued to a client Alchemy no longer knows.
 */
export declare const clientFor: (credentials: Pick<OAuthCredentials, "clientId">) => import("alchemy/Auth/OAuthFlow").OAuthClient | undefined;
export declare const { deviceAuthorize, deviceToken, refresh, revoke, usesCurrentClient }: import("alchemy/Auth/OAuthFlow").OAuthClient;
//# sourceMappingURL=OAuthClient.d.ts.map