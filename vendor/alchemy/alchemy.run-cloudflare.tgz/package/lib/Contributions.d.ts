import * as Contributions from "alchemy/Contributions";
declare const _default: {
    readonly name: "cloudflare";
    readonly auth: Contributions.Lazy<import("effect/Layer").Layer<never, never, import("alchemy/Auth/AuthProvider").AuthProviders | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("alchemy/Auth/Credentials").CredentialsStore | import("effect/FileSystem").FileSystem | import("effect/Path").Path>>;
    readonly stateStores: {
        readonly cloudflare: {
            readonly description: "State-store Worker in the profile's Cloudflare account";
            readonly load: Contributions.Lazy<Contributions.StateStoreImpl>;
        };
    };
    readonly cli: {
        readonly provider: {
            readonly description: "Manage Cloudflare provider prerequisites";
            readonly load: Contributions.Lazy<import("effect/cli/Command").Command<"cloudflare", {} | {}, {}, import("alchemy/Alchemist/Errors").AlchemistInvalidInput | import("@distilled.cloud/iceberg").BadGateway | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | import("./Alchemist/Token.ts").CloudflareTokenError | import("effect/Config").ConfigError | import("@distilled.cloud/iceberg").ConfigError | import("alchemy/Cli/commands/confirm").ConfirmationDeclined | import("@distilled.cloud/iceberg").GatewayTimeout | import("effect/http/HttpClientError").HttpClientError | import("@distilled.cloud/iceberg").InternalServerError | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | import("@distilled.cloud/cloudflare/user").InvalidRoute | import("@distilled.cloud/cloudflare/user").InvalidTokenName | import("alchemy/Interaction").NonInteractiveTerminal | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("@distilled.cloud/cloudflare/user").PermissionGroupNotFound | import("effect/PlatformError").PlatformError | import("@distilled.cloud/iceberg").ServiceUnavailable | import("alchemy/Interaction").TerminalCancelled | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError, import("alchemy/Cli/CliKit/CliKit").CliKit | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient>>;
        };
    };
};
export default _default;
//# sourceMappingURL=Contributions.d.ts.map