import { type DnsSolver, type DnsSolverDescriptor } from "@alchemy.run/acme/DnsSolver";
import type { Credentials } from "@distilled.cloud/cloudflare/Credentials";
import type { Input } from "alchemy/Input";
import type { RuntimeContext } from "alchemy/RuntimeContext";
import type * as HttpClient from "effect/http/HttpClient";
import type { WriteDnsClient } from "./DNS/WriteDns.ts";
/** Solver descriptor: publish `_acme-challenge` TXT records in a Cloudflare zone. */
export interface CloudflareDnsSolver extends DnsSolverDescriptor {
    readonly type: "Cloudflare.DNS";
    readonly zoneId: string;
}
/**
 * DNS-01 through a Cloudflare zone's records, for `ACME.Certificate`.
 * `Cloudflare.providers()` registers its implementation.
 *
 * **Example:**
 * ```typescript
 * const account = yield* LetsEncrypt;
 * const zone = yield* Zone;
 * const wildcard = yield* ACME.Certificate("Wildcard", {
 *   account,
 *   identifiers: ["*.example.com"],
 *   solver: Cloudflare.ACME.ZoneSolver(zone),
 * });
 * ```
 */
export declare const ZoneSolver: <ZoneId extends Input<string>>(zone: {
    readonly zoneId: ZoneId;
}) => {
    type: "Cloudflare.DNS";
    zoneId: ZoneId;
};
/** Deploy-time solver over the distilled DNS SDK (zone id fixed). */
export declare const makeZoneSolver: (zoneId: string) => DnsSolver<Credentials | HttpClient.HttpClient>;
/**
 * Registers the `Cloudflare.DNS` solver type with the ACME provider, over the
 * Cloudflare credentials in context. `Cloudflare.providers()` includes it.
 */
export declare const ZoneSolverLive: import("effect/Layer").Layer<import("@alchemy.run/acme/DnsSolver").DnsSolverFactory, never, Credentials | HttpClient.HttpClient>;
/**
 * Runtime solver over a bound {@link WriteDnsClient}, for
 * `ACME.IssueCertificate` inside a Worker or Service.
 *
 * **Example:**
 * ```typescript
 * const dns = yield* Cloudflare.DNS.WriteDns(Zone);
 * const issued = yield* acme.issue({
 *   identifiers: ["*.tenant.example.com"],
 *   solver: Cloudflare.ACME.zoneSolver(dns),
 * });
 * ```
 */
export declare const zoneSolver: (client: WriteDnsClient) => DnsSolver<RuntimeContext>;
//# sourceMappingURL=ACME.d.ts.map