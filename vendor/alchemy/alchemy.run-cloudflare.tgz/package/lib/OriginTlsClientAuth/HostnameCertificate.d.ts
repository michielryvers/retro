import * as originTls from "@distilled.cloud/cloudflare/origin-tls-client-auth";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Redacted from "effect/Redacted";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
declare const TypeId: "Cloudflare.OriginTlsClientAuth.HostnameCertificate";
type TypeId = typeof TypeId;
/**
 * Deployment status of the certificate. Deploying and deleting are
 * asynchronous (`pending_deployment` → `active`, `pending_deletion` →
 * `deleted`), typically settling within minutes.
 */
export type HostnameCertificateStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out" | (string & {});
export type HostnameCertificateProps = {
    /**
     * Zone the certificate is uploaded to. Cannot be changed after upload —
     * updating this property triggers a replacement.
     */
    zoneId: string;
    /**
     * The per-hostname client certificate in PEM format, presented by
     * Cloudflare to your origin for hostnames associated with it via
     * {@link HostnameAssociation}. Cannot be changed after
     * upload — updating this property triggers a replacement.
     */
    certificate: string;
    /**
     * The certificate's private key in PEM format. Cannot be changed after
     * upload — updating this property triggers a replacement.
     */
    privateKey: Redacted.Redacted<string>;
};
export type HostnameCertificateAttributes = {
    /** Unique identifier of the uploaded certificate. */
    certificateId: string;
    /** Zone the certificate is uploaded to. */
    zoneId: string;
    /** Deployment status of the certificate. */
    status: HostnameCertificateStatus | undefined;
    /** When the certificate expires. */
    expiresOn: string | undefined;
    /** The certificate authority that issued the certificate. */
    issuer: string | undefined;
    /** The serial number on the uploaded certificate. */
    serialNumber: string | undefined;
    /** The type of hash used for the certificate signature. */
    signature: string | undefined;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn: string | undefined;
};
export type HostnameCertificate = Resource<TypeId, HostnameCertificateProps, HostnameCertificateAttributes, never, Providers>;
/**
 * A per-hostname Authenticated Origin Pulls (AOP) client certificate
 * (`/zones/{zone_id}/origin_tls_client_auth/hostnames/certificates`).
 *
 * Uploads a client certificate that Cloudflare presents to your origin for
 * specific hostnames. Hostnames opt in by referencing the certificate from an
 * {@link HostnameAssociation}, which pins the certificate
 * and enables hostname-level AOP.
 *
 * Certificates are immutable: there is no update API, so changing any
 * property triggers a replacement. Deployment is asynchronous — the
 * certificate starts in `pending_deployment` and becomes `active` within a
 * few minutes; deletion likewise passes through `pending_deletion`.
 * ### Uploading a hostname certificate
 * **Example:** Hostname client certificate
 * ```typescript
 * const cert = yield* Cloudflare.OriginTlsClientAuth.HostnameCertificate("AopHostCert", {
 *   zoneId: zone.zoneId,
 *   certificate: clientCertPem,
 *   privateKey: yield* Config.Redacted("AOP_CLIENT_KEY"),
 * });
 * ```
 *
 * ### Enabling AOP for a hostname
 * **Example:** Upload the certificate and associate a hostname
 * ```typescript
 * const cert = yield* Cloudflare.OriginTlsClientAuth.HostnameCertificate("AopHostCert", {
 *   zoneId: zone.zoneId,
 *   certificate: clientCertPem,
 *   privateKey: yield* Config.Redacted("AOP_CLIENT_KEY"),
 * });
 *
 * yield* Cloudflare.OriginTlsClientAuth.HostnameAssociation("AopHost", {
 *   zoneId: zone.zoneId,
 *   hostname: "api.example.com",
 *   certId: cert.certificateId,
 *   enabled: true,
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/ssl/origin-configuration/authenticated-origin-pull/set-up/per-hostname/
 *
 * @resource
 * @product Origin TLS Client Auth
 * @category SSL/TLS & Certificates
 */
export declare const HostnameCertificate: import("alchemy/Resource").ResourceClass<HostnameCertificate>;
/**
 * Returns true if the given value is an HostnameCertificate
 * resource.
 */
export declare const isHostnameCertificate: (value: unknown) => value is HostnameCertificate;
export declare const HostnameCertificateProvider: () => import("effect/Layer").Layer<Provider.Provider<HostnameCertificate>, never, CloudflareEnvironment | originTls.CloudflareOpContext>;
export {};
//# sourceMappingURL=HostnameCertificate.d.ts.map