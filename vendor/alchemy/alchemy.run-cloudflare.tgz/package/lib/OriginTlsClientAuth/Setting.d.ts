import * as originTls from "@distilled.cloud/cloudflare/origin-tls-client-auth";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
declare const TypeId: "Cloudflare.OriginTlsClientAuth.Setting";
type TypeId = typeof TypeId;
export type SettingProps = {
    /**
     * Zone the setting belongs to. Stable — changing the zone triggers a
     * replacement (the old zone's setting is restored to the value it had
     * before Alchemy managed it).
     */
    zoneId: string;
    /**
     * Whether zone-level Authenticated Origin Pulls is enabled. When enabled,
     * Cloudflare presents the zone's uploaded client certificate
     * ({@link Certificate}) to your origin on every pull.
     *
     * Mutable — updated in place.
     * @default false (Cloudflare's default)
     */
    enabled: boolean;
};
export type SettingAttributes = {
    /** Zone the setting belongs to. */
    zoneId: string;
    /** Whether zone-level Authenticated Origin Pulls is currently enabled. */
    enabled: boolean;
    /**
     * The value the setting had before Alchemy first managed it. Restored on
     * destroy, so deleting the resource puts the zone back the way it was
     * found.
     */
    initialEnabled: boolean;
};
export type Setting = Resource<TypeId, SettingProps, SettingAttributes, never, Providers>;
/**
 * The zone-level Authenticated Origin Pulls (AOP) toggle
 * (`/zones/{zone_id}/origin_tls_client_auth/settings`).
 *
 * The setting is a singleton — it always exists on every zone (Cloudflare
 * default `false`), so this resource never creates or deletes anything
 * physical. Reconcile flips the flag when the observed value differs from
 * the desired one; destroy restores the value the setting had before
 * Alchemy first managed it (captured as `initialEnabled`).
 *
 * Enabling AOP only has effect once a zone client certificate is uploaded
 * ({@link Certificate}) and your origin is configured to
 * verify it — enabling the flag alone does not break traffic unless the
 * origin enforces mTLS.
 * ### Enabling Authenticated Origin Pulls
 * **Example:** Enable zone-level AOP
 * ```typescript
 * const cert = yield* Cloudflare.OriginTlsClientAuth.Certificate("AopCert", {
 *   zoneId: zone.zoneId,
 *   certificate: clientCertPem,
 *   privateKey: yield* Config.Redacted("AOP_CLIENT_KEY"),
 * });
 *
 * yield* Cloudflare.OriginTlsClientAuth.Setting("Aop", {
 *   zoneId: zone.zoneId,
 *   enabled: true,
 * });
 * ```
 *
 * **Example:** Pin AOP off
 * ```typescript
 * yield* Cloudflare.OriginTlsClientAuth.Setting("Aop", {
 *   zoneId: zone.zoneId,
 *   enabled: false,
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/ssl/origin-configuration/authenticated-origin-pull/
 *
 * @resource
 * @product Origin TLS Client Auth
 * @category SSL/TLS & Certificates
 */
export declare const Setting: import("alchemy/Resource").ResourceClass<Setting>;
/**
 * Returns true if the given value is an Setting resource.
 */
export declare const isSetting: (value: unknown) => value is Setting;
export declare const SettingProvider: () => import("effect/Layer").Layer<Provider.Provider<Setting>, never, CloudflareEnvironment | originTls.CloudflareOpContext>;
export {};
//# sourceMappingURL=Setting.d.ts.map