import * as originTls from "@distilled.cloud/cloudflare/origin-tls-client-auth";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Redacted from "effect/Redacted";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
declare const TypeId: "Cloudflare.OriginTlsClientAuth.Certificate";
type TypeId = typeof TypeId;
/**
 * Deployment status of the certificate. Deploying and deleting are
 * asynchronous (`pending_deployment` → `active`, `pending_deletion` →
 * `deleted`), typically settling within minutes.
 */
export type CertificateStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out" | (string & {});
export type CertificateProps = {
    /**
     * Zone the certificate is uploaded to. Cannot be changed after upload —
     * updating this property triggers a replacement.
     */
    zoneId: string;
    /**
     * The zone's leaf client certificate in PEM format, presented by
     * Cloudflare to your origin when Authenticated Origin Pulls is enabled.
     * Cannot be changed after upload — updating this property triggers a
     * replacement.
     */
    certificate: string;
    /**
     * The certificate's private key in PEM format. Cannot be changed after
     * upload — updating this property triggers a replacement.
     */
    privateKey: Redacted.Redacted<string>;
};
export type CertificateAttributes = {
    /** Unique identifier of the uploaded certificate. */
    certificateId: string;
    /** Zone the certificate is uploaded to. */
    zoneId: string;
    /** Deployment status of the certificate. */
    status: CertificateStatus | undefined;
    /** When the certificate expires. */
    expiresOn: string | undefined;
    /** The certificate authority that issued the certificate. */
    issuer: string | undefined;
    /** The type of hash used for the certificate signature. */
    signature: string | undefined;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn: string | undefined;
};
export type Certificate = Resource<TypeId, CertificateProps, CertificateAttributes, never, Providers>;
/**
 * A zone-level Authenticated Origin Pulls (AOP) client certificate
 * (`/zones/{zone_id}/origin_tls_client_auth`).
 *
 * Uploads the client certificate Cloudflare presents to your origin when
 * zone-level Authenticated Origin Pulls is enabled
 * ({@link Setting}), letting the origin verify that
 * requests really come from Cloudflare via mTLS.
 *
 * Certificates are immutable: there is no update API, so changing any
 * property triggers a replacement. Deployment is asynchronous — the
 * certificate starts in `pending_deployment` and becomes `active` within a
 * few minutes; deletion likewise passes through `pending_deletion`.
 * ### Uploading a certificate
 * **Example:** Zone client certificate
 * ```typescript
 * const cert = yield* Cloudflare.OriginTlsClientAuth.Certificate("AopCert", {
 *   zoneId: zone.zoneId,
 *   certificate: clientCertPem,
 *   privateKey: yield* Config.Redacted("AOP_CLIENT_KEY"),
 * });
 * ```
 *
 * ### Enabling Authenticated Origin Pulls
 * **Example:** Upload the certificate and turn AOP on
 * ```typescript
 * const cert = yield* Cloudflare.OriginTlsClientAuth.Certificate("AopCert", {
 *   zoneId: zone.zoneId,
 *   certificate: clientCertPem,
 *   privateKey: yield* Config.Redacted("AOP_CLIENT_KEY"),
 * });
 *
 * yield* Cloudflare.OriginTlsClientAuth.Setting("Aop", {
 *   zoneId: zone.zoneId,
 *   enabled: true,
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/ssl/origin-configuration/authenticated-origin-pull/
 *
 * @resource
 * @product Origin TLS Client Auth
 * @category SSL/TLS & Certificates
 */
export declare const Certificate: import("alchemy/Resource").ResourceClass<Certificate>;
/**
 * Returns true if the given value is an Certificate
 * resource.
 */
export declare const isCertificate: (value: unknown) => value is Certificate;
export declare const CertificateProvider: () => import("effect/Layer").Layer<Provider.Provider<Certificate>, never, CloudflareEnvironment | originTls.CloudflareOpContext>;
export {};
//# sourceMappingURL=Certificate.d.ts.map