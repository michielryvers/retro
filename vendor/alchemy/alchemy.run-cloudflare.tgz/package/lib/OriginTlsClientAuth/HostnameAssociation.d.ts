import * as originTls from "@distilled.cloud/cloudflare/origin-tls-client-auth";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import type { Providers } from "../Providers.ts";
declare const TypeId: "Cloudflare.OriginTlsClientAuth.HostnameAssociation";
type TypeId = typeof TypeId;
/**
 * Deployment status of the association or its pinned certificate. Changes
 * propagate asynchronously (`pending_deployment` → `active`), typically
 * settling within seconds.
 */
export type HostnameAssociationStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out" | (string & {});
export type HostnameAssociationProps = {
    /**
     * Zone the hostname belongs to. Cannot be changed — updating this property
     * triggers a replacement.
     */
    zoneId: string;
    /**
     * The hostname on the origin for which the client certificate will be
     * presented. Must be a hostname of the zone. This is the association's
     * identity — updating it triggers a replacement (the old hostname's
     * association is voided).
     */
    hostname: string;
    /**
     * Identifier of the hostname client certificate
     * ({@link HostnameCertificate}) presented to the origin
     * for this hostname. Required by Cloudflare for every hostname AOP
     * configuration. Mutable — updated in place.
     */
    certId: string;
    /**
     * Whether hostname-level Authenticated Origin Pulls is enabled for this
     * hostname. Mutable — updated in place. On destroy the association is
     * voided (Cloudflare's `enabled: null`), restoring the hostname to
     * zone-level behavior.
     */
    enabled: boolean;
};
export type HostnameAssociationAttributes = {
    /** Zone the hostname belongs to. */
    zoneId: string;
    /** The hostname the association applies to. */
    hostname: string;
    /** Identifier of the pinned hostname client certificate. */
    certId: string;
    /** Whether hostname-level Authenticated Origin Pulls is enabled. */
    enabled: boolean;
    /** Deployment status of the association. */
    status: HostnameAssociationStatus | undefined;
    /** Deployment status of the pinned certificate. */
    certStatus: HostnameAssociationStatus | undefined;
};
export type HostnameAssociation = Resource<TypeId, HostnameAssociationProps, HostnameAssociationAttributes, never, Providers>;
/**
 * A per-hostname Authenticated Origin Pulls (AOP) association
 * (`/zones/{zone_id}/origin_tls_client_auth/hostnames`).
 *
 * Pins a hostname client certificate
 * ({@link HostnameCertificate}) to a hostname and toggles
 * hostname-level AOP for it. Cloudflare's API is a bulk upsert keyed by
 * hostname; this resource manages exactly one hostname per instance, so
 * separate instances for different hostnames are safe to deploy
 * concurrently. On destroy the association is voided (`enabled: null`),
 * which restores the hostname to zone-level AOP behavior.
 * ### Enabling AOP for a hostname
 * **Example:** Associate a hostname with a client certificate
 * ```typescript
 * const cert = yield* Cloudflare.OriginTlsClientAuth.HostnameCertificate("AopHostCert", {
 *   zoneId: zone.zoneId,
 *   certificate: clientCertPem,
 *   privateKey: yield* Config.Redacted("AOP_CLIENT_KEY"),
 * });
 *
 * yield* Cloudflare.OriginTlsClientAuth.HostnameAssociation("AopHost", {
 *   zoneId: zone.zoneId,
 *   hostname: "api.example.com",
 *   certId: cert.certificateId,
 *   enabled: true,
 * });
 * ```
 *
 * **Example:** Keep the certificate pinned but disable enforcement
 * ```typescript
 * yield* Cloudflare.OriginTlsClientAuth.HostnameAssociation("AopHost", {
 *   zoneId: zone.zoneId,
 *   hostname: "api.example.com",
 *   certId: cert.certificateId,
 *   enabled: false,
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/ssl/origin-configuration/authenticated-origin-pull/set-up/per-hostname/
 *
 * @resource
 * @product Origin TLS Client Auth
 * @category SSL/TLS & Certificates
 */
export declare const HostnameAssociation: import("alchemy/Resource").ResourceClass<HostnameAssociation>;
/**
 * Returns true if the given value is an HostnameAssociation
 * resource.
 */
export declare const isHostnameAssociation: (value: unknown) => value is HostnameAssociation;
export declare const HostnameAssociationProvider: () => import("effect/Layer").Layer<Provider.Provider<HostnameAssociation>, never, originTls.CloudflareOpContext>;
export {};
//# sourceMappingURL=HostnameAssociation.d.ts.map