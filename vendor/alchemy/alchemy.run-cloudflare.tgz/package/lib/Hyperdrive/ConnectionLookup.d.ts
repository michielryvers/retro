import * as Output from "alchemy/Output";
import type { DevOrigin } from "./Connection.ts";
export type ConnectionLookupProps = ({
    /**
     * The Cloudflare-assigned ID of the existing Hyperdrive configuration.
     */
    hyperdriveId: string;
} | {
    /**
     * The name of the existing Hyperdrive configuration.
     */
    name: string;
}) & {
    /**
     * Local development origin. The Cloudflare API never returns the origin
     * password of an existing configuration, so `alchemy dev` can only
     * emulate the binding when a `dev` origin is set. Without it, a locally
     * running Worker that binds the lookup fails with
     * `HyperdriveDevOriginUnsupported`.
     */
    dev?: DevOrigin | Output.Output<DevOrigin>;
};
declare const ConnectionLookupTypeId: unique symbol;
/**
 * The value of a {@link lookup}: a binding descriptor branded with the
 * Hyperdrive resource `Type`, so Worker binding classification and
 * {@link Connect} treat it exactly like a managed {@link Connection}.
 */
export interface ConnectionLookup {
    readonly [ConnectionLookupTypeId]: true;
    readonly Type: "Cloudflare.Hyperdrive";
    /**
     * The id passed to {@link lookup}; {@link Connect} uses it as the Worker
     * binding name.
     */
    readonly LogicalId: string;
    /** Cloudflare-assigned ID of the configuration. */
    readonly hyperdriveId: Output.Output<string>;
    /** Name of the configuration. */
    readonly name: Output.Output<string>;
    /** Account the configuration lives in. */
    readonly accountId: Output.Output<string>;
    /** The `dev` origin passed to {@link lookup}. */
    readonly dev: Output.Output<DevOrigin | undefined>;
}
export declare const isConnectionLookup: (value: unknown) => value is ConnectionLookup;
declare const HyperdriveConfigLookupNotFound_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "HyperdriveConfigLookupNotFound";
} & Readonly<A>;
/**
 * No Hyperdrive configuration with the looked-up name exists in the account.
 */
export declare class HyperdriveConfigLookupNotFound extends HyperdriveConfigLookupNotFound_base<{
    message: string;
    name: string;
    accountId: string;
}> {
}
/**
 * Look up an existing Cloudflare Hyperdrive configuration (created in the
 * dashboard or owned by another system) without managing its lifecycle —
 * the data-source form (what Terraform calls a data source and Pulumi an
 * invoke). The configuration is read by `hyperdriveId` or `name` during
 * plan/deploy and is never created, updated or deleted: there is no state
 * row, so `destroy` and `nuke` cannot touch it. Bind it to a Worker through
 * `env` or {@link Connect}, exactly like a {@link Connection}.
 *
 * The `id` names the binding inside the Worker, so it must be the same on
 * every deploy; the `name` or `hyperdriveId` may differ per stage.
 *
 * ### Looking up a configuration
 * **Example:** By ID
 * ```typescript
 * const db = Cloudflare.Hyperdrive.lookup("SharedDb", {
 *   hyperdriveId: "a76a99bc342644deb02c38d66082262a",
 * });
 * ```
 *
 * **Example:** By name
 * ```typescript
 * const db = Cloudflare.Hyperdrive.lookup("SharedDb", {
 *   name: "shared-postgres",
 * });
 * ```
 *
 * ### Binding to a Worker
 * **Example:** Async Worker `env`
 * ```typescript
 * const worker = yield* Cloudflare.Worker("Worker", {
 *   main: "./src/worker.ts",
 *   env: {
 *     HD: Cloudflare.Hyperdrive.lookup("SharedDb", { name: "shared-postgres" }),
 *   },
 * });
 * ```
 *
 * **Example:** Effect Worker
 * ```typescript
 * const hd = yield* Cloudflare.Hyperdrive.Connect(
 *   Cloudflare.Hyperdrive.lookup("SharedDb", { name: "shared-postgres" }),
 * );
 * const url = yield* hd.connectionString;
 * ```
 *
 * ### Local development
 * **Example:** Dev origin for `alchemy dev`
 * ```typescript
 * const db = Cloudflare.Hyperdrive.lookup("SharedDb", {
 *   name: "shared-postgres",
 *   dev: {
 *     scheme: "postgres",
 *     host: "localhost",
 *     port: 5432,
 *     database: "app",
 *     user: "postgres",
 *     password: yield* Config.redacted("DEV_DB_PASSWORD"),
 *   },
 * });
 * ```
 *
 * @resource
 * @product Hyperdrive
 * @category Storage & Databases
 */
export declare const lookup: (id: string, props: ConnectionLookupProps) => ConnectionLookup;
export {};
//# sourceMappingURL=ConnectionLookup.d.ts.map