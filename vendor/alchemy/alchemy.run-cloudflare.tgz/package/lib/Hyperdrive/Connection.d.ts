import * as hyperdrive from "@distilled.cloud/cloudflare/hyperdrive";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Redacted from "effect/Redacted";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
export type Scheme = "postgres" | "postgresql" | "mysql";
/**
 * Origin configuration for a public PostgreSQL or MySQL database.
 */
export type PublicOrigin = {
    scheme: Scheme;
    host: string;
    port?: number;
    database: string;
    user: string;
    /**
     * Database password.
     */
    password: Redacted.Redacted<string>;
};
/**
 * Origin configuration for a database fronted by Cloudflare Access.
 */
export type AccessOrigin = {
    scheme: Scheme;
    host: string;
    database: string;
    user: string;
    password: Redacted.Redacted<string>;
    accessClientId: Redacted.Redacted<string>;
    accessClientSecret: Redacted.Redacted<string>;
};
/**
 * Origin configuration for a private database reached through Workers VPC.
 *
 * Hyperdrive egresses through a TCP VPC Service
 * ({@link https://developers.cloudflare.com/workers-vpc/ Workers VPC}), which
 * routes over a Cloudflare Tunnel into the private network — e.g. an Aurora
 * or RDS instance inside an AWS VPC. The host and port live on the VPC
 * Service, so they are not repeated here. mTLS cannot be combined with a VPC
 * origin; TLS is managed on the VPC Service.
 */
export type VpcOrigin = {
    scheme: Scheme;
    /**
     * Identifier of the TCP VPC Service to connect through, e.g.
     * `service.serviceId` of a `Cloudflare.Connectivity.DirectoryService`
     * with `type: "tcp"`.
     */
    serviceId: string;
    database: string;
    user: string;
    /**
     * Database password.
     */
    password: Redacted.Redacted<string>;
};
export type Origin = PublicOrigin | AccessOrigin | VpcOrigin;
export type Caching = {
    /**
     * Whether caching is disabled.
     * @default false
     */
    disabled?: boolean;
    /**
     * Maximum duration items should persist in the cache, in seconds.
     * @default 60
     */
    maxAge?: number;
    /**
     * Number of seconds the cache may serve a stale response while revalidating.
     * @default 15
     */
    staleWhileRevalidate?: number;
};
export type Mtls = {
    caCertificateId?: string;
    mtlsCertificateId?: string;
    /**
     * @default "require"
     */
    sslmode?: "require" | "verify-ca" | "verify-full";
};
export type DevOrigin = PublicOrigin & {
    /**
     * @default "prefer"
     */
    sslmode?: "disable" | "prefer" | "require" | "verify-ca" | "verify-full";
};
export type Props = {
    /**
     * Name of the Hyperdrive configuration. If omitted, a unique name will be
     * generated.
     * @default ${app}-${stage}-${id}
     */
    name?: string;
    /**
     * Database connection origin. Hyperdrive supports public Postgres/MySQL
     * databases, databases fronted by Cloudflare Access, and private databases
     * reached through a Workers VPC Service.
     */
    origin: Origin;
    /**
     * Caching configuration.
     */
    caching?: Caching;
    /**
     * mTLS configuration.
     */
    mtls?: Mtls;
    /**
     * The (soft) maximum number of connections Hyperdrive is allowed to make to
     * the origin database.
     */
    originConnectionLimit?: number;
    /**
     * Local development overrides. When the stack runs in dev mode
     * connect to a locally running database
     */
    dev?: DevOrigin;
};
export type Connection = Resource<"Cloudflare.Hyperdrive", Props, {
    hyperdriveId: string;
    name: string;
    accountId: string;
    origin: Origin;
    mtls: Mtls;
    dev: DevOrigin | undefined;
}, never, Providers>;
/**
 * A Cloudflare Hyperdrive configuration.
 *
 * Hyperdrive accelerates and pools connections to existing PostgreSQL or
 * MySQL databases, exposing them to Workers via a binding. Create a config
 * as a resource, then bind it to a Worker to obtain a connection string.
 * ### Creating a Hyperdrive
 * **Example:** Public Postgres origin
 * ```typescript
 * const hd = yield* Cloudflare.Hyperdrive.Connection("my-pg", {
 *   origin: {
 *     scheme: "postgres",
 *     host: "db.example.com",
 *     port: 5432,
 *     database: "app",
 *     user: "app",
 *     password: yield* Config.Redacted("DB_PASSWORD"),
 *   },
 * });
 * ```
 *
 * ### Connecting to a private database
 * A database inside a private network (e.g. Aurora or RDS in an AWS VPC) is
 * reached through Workers VPC: run `cloudflared` inside the network with the
 * Tunnel's token, expose the database as a TCP VPC Service, and point
 * Hyperdrive at the service.
 *
 * **Example:** Aurora in an AWS VPC through Workers VPC
 * ```typescript
 * const tunnel = yield* Cloudflare.Tunnel.Tunnel("VpcTunnel");
 * const service = yield* Cloudflare.Connectivity.DirectoryService("Aurora", {
 *   type: "tcp",
 *   tcpPort: 5432,
 *   appProtocol: "postgresql",
 *   host: {
 *     hostname: "my-cluster.cluster-abc123.us-east-1.rds.amazonaws.com",
 *     resolverNetwork: { tunnelId: tunnel.tunnelId },
 *   },
 * });
 * const hd = yield* Cloudflare.Hyperdrive.Connection("Aurora", {
 *   origin: {
 *     scheme: "postgres",
 *     serviceId: service.serviceId,
 *     database: "app",
 *     user: "app",
 *     password: yield* Config.Redacted("DB_PASSWORD"),
 *   },
 * });
 * ```
 *
 * ### Binding to a Worker
 * **Example:** Using Hyperdrive inside a Worker
 * ```typescript
 * const hd = yield* Cloudflare.Hyperdrive.Connect(MyConnection);
 * const url = yield* hd.connectionString;
 * ```
 *
 * @resource
 * @product Hyperdrive
 * @category Storage & Databases
 */
export declare const Connection: import("alchemy/Resource").ResourceClass<Connection>;
export declare const isHyperdriveConnection: (value: unknown) => value is Connection;
export declare const ProviderLive: () => import("effect/Layer").Layer<Provider.Provider<Connection>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | hyperdrive.CloudflareOpContext>;
/**
 * Local (dev) provider — the config is purely virtual: reconcile mints a
 * `dev:` id and echoes the desired props into attributes, with no cloud API
 * calls. The actual local behavior lives in the Worker binding: the local
 * runtime's Hyperdrive plugin is an origin passthrough driven by the
 * `hyperdrives` record `ConnectBinding` lowers (the `dev` prop when set,
 * otherwise the real `origin`).
 */
export declare const ProviderLocal: () => import("effect/Layer").Layer<Provider.Provider<Connection>, never, import("alchemy/Stack").Stack | import("alchemy/Stage").Stage>;
export declare const ConnectionProvider: () => import("effect/Layer").Layer<Provider.Provider<Connection>, never, import("alchemy/AlchemyContext").AlchemyContext | CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | hyperdrive.CloudflareOpContext>;
export declare const defaultPort: (scheme: Scheme) => number;
//# sourceMappingURL=Connection.d.ts.map