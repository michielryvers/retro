import { type ProviderMode } from "alchemy/ProviderMode";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { Worker, WorkerEnvironment } from "../Workers/Worker.ts";
import { Connect } from "./Connect.ts";
import type { Connection } from "./Connection.ts";
import { type DevOrigin } from "./Connection.ts";
import { type ConnectionLookup } from "./ConnectionLookup.ts";
export declare const ConnectBinding: Layer.Layer<Connect, never, WorkerEnvironment | Worker<any>>;
/**
 * The `hyperdrives` dev channel for `connection` bound to `host`. Only the
 * local worker provider reads it, so it is contributed only when the host
 * runs locally — its registration-captured `Mode` (`Alchemy.remote()` →
 * `"live"`) or the run default (`alchemy dev` → `"local"`), the same
 * resolution the planner applies to the host. A live host (`alchemy deploy`,
 * or a `remote()` worker in dev) never evaluates the dev origin, so an
 * Access-protected origin without a `dev` override deploys.
 */
export declare const getHyperdriveDevOriginForHost: (connection: ConnectionLookup | Connection, host: {
    readonly Mode?: ProviderMode | undefined;
}) => Effect.Effect<Record<string, Required<DevOrigin>> | undefined, never, never>;
declare const HyperdriveDevOriginUnsupported_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "HyperdriveDevOriginUnsupported";
} & Readonly<A>;
/**
 * A Hyperdrive origin that `alchemy dev` cannot reach from the local
 * machine, bound without a `dev` override.
 */
export declare class HyperdriveDevOriginUnsupported extends HyperdriveDevOriginUnsupported_base<{
    message: string;
    logicalId: string;
    origin: "access" | "vpc" | "lookup";
}> {
}
export declare const getHyperdriveDevOrigin: (connection: Connection | ConnectionLookup) => Record<string, Required<DevOrigin>>;
export {};
//# sourceMappingURL=ConnectBinding.d.ts.map