import * as Layer from "effect/Layer";
import { WorkerEnvironment } from "../Workers/Worker.ts";
import { Fetch } from "./Fetch.ts";
/**
 * Implementation of {@link Fetch} over the native `mtls_certificate` Worker
 * binding. Provide it on the Worker's Effect.
 */
export declare const FetchBinding: Layer.Layer<Fetch, never, WorkerEnvironment>;
//# sourceMappingURL=FetchBinding.d.ts.map