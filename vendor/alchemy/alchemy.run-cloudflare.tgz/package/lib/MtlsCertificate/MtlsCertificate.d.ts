import * as mtls from "@distilled.cloud/cloudflare/mtls-certificates";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Redacted from "effect/Redacted";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
declare const TypeId: "Cloudflare.MtlsCertificate.MtlsCertificate";
type TypeId = typeof TypeId;
/**
 * How the certificate was created and who manages it. Certificates uploaded
 * through this resource are always `"custom"`.
 */
export type Type = "custom" | "gateway_managed" | "access_managed" | (string & {});
export type Props = {
    /**
     * Optional human-readable name for the certificate. If omitted, a unique
     * name will be generated. There is no update API, so changing the name
     * triggers a replacement. Names are unique per account, so replacing a
     * certificate that keeps an explicit name deletes the old certificate
     * before uploading the new one. Omit `name` to rotate create-first.
     * @default ${app}-${stage}-${id}
     */
    name?: string;
    /**
     * Indicates whether the certificate is a CA certificate (`true`) used to
     * validate client certificates, or a leaf certificate (`false`) presented
     * by Cloudflare to your origin. Cannot be changed after upload — updating
     * this property triggers a replacement.
     */
    ca: boolean;
    /**
     * The certificate in PEM format. A root CA certificate when `ca: true`,
     * or a leaf certificate (chain) when `ca: false`. Cannot be changed after
     * upload — updating this property triggers a replacement.
     */
    certificates: string;
    /**
     * The private key for the certificate in PEM format. Required when
     * uploading a leaf certificate (`ca: false`) that Cloudflare must present
     * to your origin. Cannot be changed after upload — updating this property
     * triggers a replacement.
     */
    privateKey?: Redacted.Redacted<string>;
};
export type Attributes = {
    /**
     * Unique identifier of the uploaded certificate.
     */
    mtlsCertificateId: string;
    /**
     * The Cloudflare account the certificate was uploaded to.
     */
    accountId: string;
    /**
     * Human-readable name of the certificate.
     */
    name: string | undefined;
    /**
     * Whether the certificate is a CA (`true`) or leaf (`false`) certificate.
     */
    ca: boolean;
    /**
     * The certificate authority that issued the certificate.
     */
    issuer: string | undefined;
    /**
     * The certificate serial number.
     */
    serialNumber: string | undefined;
    /**
     * The type of hash used for the certificate signature.
     */
    signature: string | undefined;
    /**
     * When the certificate expires.
     */
    expiresOn: string | undefined;
    /**
     * When the certificate was uploaded to Cloudflare.
     */
    uploadedOn: string | undefined;
    /**
     * How the certificate was created and who manages it.
     */
    type: Type | undefined;
};
export type MtlsCertificate = Resource<TypeId, Props, Attributes, never, Providers>;
/**
 * An account-level Cloudflare mTLS certificate.
 *
 * Uploads a certificate to the account-level mTLS certificate store. Upload a
 * CA certificate (`ca: true`) to validate client certificates (referenced by
 * certificate-authority hostname associations and Hyperdrive
 * `caCertificateId`), or a leaf certificate plus private key (`ca: false`)
 * that Cloudflare presents to your origin (referenced by Worker
 * `mtls_certificate` bindings and Hyperdrive `mtlsCertificateId`).
 *
 * Certificates are immutable: there is no update API, so changing any
 * property triggers a replacement.
 * ### Uploading Certificates
 * **Example:** CA certificate
 * ```typescript
 * const ca = yield* Cloudflare.MtlsCertificate.MtlsCertificate("client-ca", {
 *   ca: true,
 *   certificates: caPem,
 * });
 * ```
 *
 * **Example:** Leaf certificate with private key
 * ```typescript
 * const cert = yield* Cloudflare.MtlsCertificate.MtlsCertificate("origin-client-cert", {
 *   ca: false,
 *   certificates: leafPem,
 *   privateKey: yield* Config.Redacted("ORIGIN_CLIENT_KEY"),
 * });
 * ```
 *
 * **Example:** Named certificate
 * ```typescript
 * const ca = yield* Cloudflare.MtlsCertificate.MtlsCertificate("client-ca", {
 *   name: "my-client-ca",
 *   ca: true,
 *   certificates: caPem,
 * });
 * ```
 *
 * ### Referencing from Hyperdrive
 * **Example:** Verify the origin with an uploaded CA
 * ```typescript
 * const ca = yield* Cloudflare.MtlsCertificate.MtlsCertificate("db-ca", {
 *   ca: true,
 *   certificates: caPem,
 * });
 *
 * const hd = yield* Cloudflare.Hyperdrive.Connection("my-db", {
 *   origin: { ... },
 *   mtls: {
 *     caCertificateId: ca.mtlsCertificateId,
 *     sslmode: "verify-full",
 *   },
 * });
 * ```
 *
 * ### Binding to a Worker
 * **Example:** Present a leaf certificate on subrequests
 * ```typescript
 * const cert = yield* Cloudflare.MtlsCertificate.MtlsCertificate("origin-client-cert", {
 *   ca: false,
 *   certificates: leafPem,
 *   privateKey: yield* Config.Redacted("ORIGIN_CLIENT_KEY"),
 * });
 *
 * // `env.ORIGIN_CERT` is a `Fetcher`: `env.ORIGIN_CERT.fetch(url)` presents
 * // the certificate to the origin.
 * const worker = yield* Cloudflare.Worker("Worker", {
 *   main: "./src/worker.ts",
 *   env: { ORIGIN_CERT: cert },
 * });
 * ```
 *
 * **Example:** Present a leaf certificate from an Effect Worker
 * ```typescript
 * // Inside the Worker's Effect; provide `Cloudflare.MtlsCertificate.FetchBinding`.
 * const fetchOrigin = yield* Cloudflare.MtlsCertificate.Fetch(cert);
 * const response = yield* fetchOrigin(
 *   HttpClientRequest.get("https://origin.example.com/"),
 * );
 * ```
 *
 * @see https://developers.cloudflare.com/ssl/client-certificates/
 *
 * @resource
 * @product mTLS Certificates
 * @category SSL/TLS & Certificates
 */
export declare const MtlsCertificate: import("alchemy/Resource").ResourceClass<MtlsCertificate>;
/**
 * Returns true if the given value is a MtlsCertificate resource.
 */
export declare const isMtlsCertificate: (value: unknown) => value is MtlsCertificate;
export declare const MtlsCertificateProvider: () => import("effect/Layer").Layer<Provider.Provider<MtlsCertificate>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | mtls.CloudflareOpContext>;
export {};
//# sourceMappingURL=MtlsCertificate.d.ts.map