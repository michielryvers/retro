import { AlchemyContext } from "alchemy/AlchemyContext";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Path from "effect/Path";
import { CloudflareEnvironment } from "./CloudflareEnvironment.ts";
/**
 * A standalone local-runtime layer for gateway consumers OUTSIDE the
 * provider stack (e.g. capability `*Local` layers running in an Action,
 * whose ambient context has no workerd `Runtime`). Configured identically
 * to the providers' shared runtime — same `.alchemy/local` storage
 * directory — so it reads and writes the same simulator data.
 */
export declare const localGatewayRuntime: Layer.Layer<import("@alchemy.run/cloudflare-runtime/core/bindings/analytics-engine").AnalyticsEngine | import("@alchemy.run/cloudflare-runtime/core/bindings/assets/Assets").Assets | import("@alchemy.run/cloudflare-runtime/core/bindings/browser").Browser | import("@alchemy.run/cloudflare-runtime/core/bindings/cache").Cache | import("@alchemy.run/cloudflare-runtime/core/bindings/d1").D1 | import("@alchemy.run/cloudflare-runtime/core/bindings/dispatch-namespace").DispatchNamespace | import("@alchemy.run/cloudflare-runtime/core/bindings/hyperdrive").Hyperdrive | import("@alchemy.run/cloudflare-runtime/core/bindings/images").Images | import("@alchemy.run/cloudflare-runtime/core/bindings/kv-namespace").KvNamespace | import("@alchemy.run/cloudflare-runtime/core/globals/Loopback").Loopback | import("@alchemy.run/cloudflare-runtime/core/bindings/queue").Queue | import("@alchemy.run/cloudflare-runtime/core/bindings/r2-bucket").R2Bucket | import("@alchemy.run/cloudflare-runtime/core/bindings/rate-limit").RateLimit | import("@alchemy.run/cloudflare-runtime/core/registry/RegistryProxy").RegistryProxy | import("@alchemy.run/cloudflare-runtime/core/remote-bindings/RemoteBindings").RemoteBindings | import("@alchemy.run/cloudflare-runtime/core").Runtime | import("@alchemy.run/cloudflare-runtime/core/bindings/secrets-store").SecretsStore | import("@alchemy.run/cloudflare-runtime/core/bindings/send-email").SendEmail | import("@alchemy.run/cloudflare-runtime/core/bindings/stream").Stream | import("@alchemy.run/cloudflare-runtime/core/proxy/WorkerProxy").WorkerProxy | import("@alchemy.run/cloudflare-runtime/core/bindings/workflows").Workflows, import("effect/Config").ConfigError | import("@alchemy.run/cloudflare-runtime/core").ConfigError | import("effect/PlatformError").PlatformError | import("@alchemy.run/cloudflare-runtime/core").SystemError, AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | CloudflareEnvironment | import("@distilled.cloud/cloudflare/Credentials").Credentials | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | Path.Path>;
/** Sanitize an id into a workerd instance-name-safe suffix. */
export declare const gatewayName: (prefix: string, id: string) => string;
/**
 * Build a client whose every member resolves the resource id first and then
 * delegates: `dev:` ids to the (memoized) native-over-gateway client, real
 * ids to the HTTP client. Function members dispatch per call; Effect-valued
 * members (`raw`) dispatch on evaluation. Used by the `*Local` capability
 * scaffolding (KV, R2) where the id is a deferred accessor resolved at
 * apply time.
 */
export declare const dispatchByMode: <Client extends object>(resourceId: Effect.Effect<string>, httpClient: Client, makeNative: (id: string) => Client) => Client;
//# sourceMappingURL=LocalGateway.d.ts.map