import * as emailRouting from "@distilled.cloud/cloudflare/email-routing";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
import { type Reference } from "../Zone/index.ts";
export type Matcher = {
    type: "all";
} | {
    type: "literal";
    field: "to";
    value: string;
};
export type Action = {
    type: "drop";
} | {
    type: "forward";
    value: string[];
} | {
    type: "worker";
    value: string[];
};
export type RuleProps = {
    /**
     * Zone the rule lives on.
     */
    zone: Reference;
    /**
     * Display name for the rule.
     */
    name?: string;
    /**
     * Whether the rule is active. Disabled rules are evaluated last and
     * effectively skipped.
     *
     * @default true
     */
    enabled?: boolean;
    /**
     * Lower priority numbers run first.
     *
     * @default 0
     */
    priority?: number;
    /**
     * Matchers that define which inbound emails trigger this rule.
     *
     * A sole `{ type: "all" }` matcher is the zone catch-all, which is a
     * per-zone singleton owned by `Cloudflare.Email.CatchAll` — declaring
     * it here fails with `CatchAllRuleNotSupported`.
     */
    matchers: Matcher[];
    /**
     * Actions to take for matched emails.
     */
    actions: Action[];
};
export type Rule = Resource<"Cloudflare.Email.Rule", RuleProps, {
    ruleId: string;
    zoneId: string;
    name: string;
    enabled: boolean;
    priority: number;
    matchers: Matcher[];
    actions: Action[];
}, never, Providers>;
declare const CatchAllRuleNotSupported_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "CatchAllRuleNotSupported";
} & Readonly<A>;
/**
 * Raised when `Cloudflare.Email.Rule` is declared with a sole
 * `{ type: "all" }` matcher. Cloudflare models the zone catch-all as a
 * singleton behind `PUT /zones/{zone_id}/email/routing/rules/catch_all`
 * and rejects creating a second one through the ordinary rule endpoint
 * (`Conflict: Invalid rule operation`). Use `Cloudflare.Email.CatchAll`.
 */
export declare class CatchAllRuleNotSupported extends CatchAllRuleNotSupported_base<{
    message: string;
}> {
}
/**
 * A Cloudflare Email Routing rule.
 *
 * Rules forward inbound mail matching `matchers` to the listed actions
 * (forward to a verified destination, drop, or hand off to a Worker).
 *
 * Safety: routing rules carry no ownership markers. When there is no
 * prior state, `read` scans the zone for an existing non-catch-all rule
 * with the same matchers and reports it as `Unowned`, so the engine
 * refuses to take it over unless `--adopt` (or `adopt(true)`) is set.
 * The zone catch-all is excluded from that scan — it is owned by
 * `Email.CatchAll`.
 * ### Forwarding Mail
 * **Example:** Forward `info@` to a verified destination
 * ```typescript
 * const rule = yield* Cloudflare.Email.Rule("InfoForward", {
 *   zone: "example.com",
 *   matchers: [{ type: "literal", field: "to", value: "info@example.com" }],
 *   actions: [{ type: "forward", value: ["ops@example.com"] }],
 * });
 * ```
 *
 * ### Catch-all mail
 * The zone catch-all is a per-zone singleton managed by
 * `Cloudflare.Email.CatchAll` (PUT `/rules/catch_all`). Declaring
 * `matchers: [{ type: "all" }]` on a Rule fails with
 * `CatchAllRuleNotSupported` — Cloudflare rejects creating a second
 * catch-all through the ordinary rule endpoint.
 *
 * **Example:** Use CatchAll for unmatched mail
 * ```typescript
 * yield* Cloudflare.Email.CatchAll("CatchAll", {
 *   zone: "example.com",
 *   actions: [{ type: "drop" }],
 * });
 * ```
 *
 * @resource
 * @product Email
 * @category Email
 */
export declare const Rule: import("alchemy/Resource").ResourceClass<Rule>;
export declare const RuleProvider: () => import("effect/Layer").Layer<Provider.Provider<Rule>, never, CloudflareEnvironment | emailRouting.CloudflareOpContext>;
export {};
//# sourceMappingURL=Rule.d.ts.map