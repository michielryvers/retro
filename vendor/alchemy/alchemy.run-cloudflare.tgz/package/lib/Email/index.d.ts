export * from "./Address.ts";
export * from "./AllowPolicy.ts";
export * from "./BlockSender.ts";
export * from "./CatchAll.ts";
export * from "./DmarcReports.ts";
export * from "./Domain.ts";
export * from "./ImpersonationRegistryEntry.ts";
export * from "./Routing.ts";
export * from "./Rule.ts";
export * from "./Send.ts";
export * from "./SendBinding.ts";
export * from "./SendEmail.ts";
export * from "./SendingSubdomain.ts";
export * from "./TrustedDomain.ts";
//# sourceMappingURL=index.d.ts.map