export declare const uniqueTokens: <T extends {
    id?: string | null;
}>(tokens: ReadonlyArray<T>) => T[];
//# sourceMappingURL=internal.d.ts.map