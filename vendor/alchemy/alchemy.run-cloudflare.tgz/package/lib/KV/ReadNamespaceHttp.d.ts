import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { type KVAuth } from "./NamespaceHttp.ts";
import { ReadNamespace, type ReadNamespaceClient } from "./ReadNamespace.ts";
/**
 * HTTP-backed implementation of the {@link ReadNamespace} binding.
 *
 * It creates a scoped {@link AccountApiToken} with the `Workers KV Storage
 * Read` permission and reads values via the Cloudflare KV HTTP API.
 */
export declare const ReadNamespaceHttp: Layer.Layer<ReadNamespace, never, import("alchemy/Self").Self<{
    Type: string;
    LogicalId: string;
}>>;
export declare const makeReadKVHttpClient: (auth: KVAuth, namespaceId: Effect.Effect<string>) => ReadNamespaceClient;
//# sourceMappingURL=ReadNamespaceHttp.d.ts.map