export declare const createInstantNamespaceLocalId: () => string;
export declare const isInstantNamespaceLocalId: (id: string) => boolean;
//# sourceMappingURL=InstantNamespaceLocal.d.ts.map