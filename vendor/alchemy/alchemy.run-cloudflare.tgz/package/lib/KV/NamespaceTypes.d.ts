declare const NamespaceError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "NamespaceError";
} & Readonly<A>;
export declare class NamespaceError extends NamespaceError_base<{
    message: string;
    cause: Error;
}> {
}
declare const NamespaceModeMismatch_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "NamespaceModeMismatch";
} & Readonly<A>;
/** The API returned a namespace with a different storage mode. */
export declare class NamespaceModeMismatch extends NamespaceModeMismatch_base<{
    namespaceId: string;
    expected: "instant" | "classic";
}> {
    get message(): string;
}
export {};
//# sourceMappingURL=NamespaceTypes.d.ts.map