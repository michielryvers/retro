import * as kv from "@distilled.cloud/cloudflare/kv";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
export declare const isInstantNamespace: (value: unknown) => value is InstantNamespace;
export type InstantNamespaceProps = {
    /**
     * A human-readable string name for the namespace.
     * If omitted, a unique name will be generated.
     * @default ${app}-${stage}-${id}
     */
    title?: string;
};
export type InstantNamespace = Resource<"Cloudflare.KV.InstantNamespace", InstantNamespaceProps, {
    /** Namespace storage mode, fixed at creation. */
    mode: "instant";
    /** Human-readable namespace title. */
    title: string;
    /** Cloudflare namespace identifier, stable across title updates. */
    namespaceId: string;
    /** Whether keys written in URLs are URL-decoded before storage. */
    supportsUrlEncoding: boolean | undefined;
    /** Account that owns the namespace. */
    accountId: string;
}, never, Providers>;
/**
 * A Cloudflare Workers KV Instant namespace, powered by Quicksilver.
 *
 * Requires private beta access. Uses the same Worker binding as classic KV,
 * with fast global replication and no cold reads. Namespace mode is fixed at
 * creation; switching between Namespace and InstantNamespace replaces it.
 *
 * Metadata is unsupported. Use get instead of getWithMetadata, and do not
 * pass metadata to put. Listing returns all matching keys without pagination.
 * The beta limits namespaces to 1 MB and 10,000 pairs, keys to 300 bytes,
 * and writes to one per namespace per second.
 *
 * Storage and put/delete/list operations cost substantially more than classic
 * KV; reads cost less. See https://blog.cloudflare.com/workers-kv-instant/
 * for pricing and private beta availability.
 *
 * ### Creating an Instant Namespace
 * **Example:** Application configuration
 * ```typescript
 * const config = yield* Cloudflare.KV.InstantNamespace("Config");
 * ```
 *
 * ### Binding to a Worker
 * **Example:** Read configuration using the existing KV binding
 * ```typescript
 * const client = yield* Cloudflare.KV.ReadNamespace(config);
 * const enabled = yield* client.get("feature-enabled");
 * ```
 *
 * Provide ReadNamespaceBinding on the Worker runtime. WriteNamespace and
 * ReadWriteNamespace also accept Instant namespaces, as do their Http and
 * Local capability implementations.
 *
 * During `alchemy dev`, the namespace uses persistent local KV storage without
 * cloud credentials or beta access. Local mode rejects metadata and lists all
 * matching keys in one response. Local keys are limited to 300 UTF-8 bytes.
 * Namespace storage quotas, key-count limits, global replication, billing,
 * and write throttling are not emulated. Use Alchemy.remote()
 * to opt into a live namespace during development (requires beta access).
 *
 * @resource
 * @product KV
 * @category Storage & Databases
 */
export declare const InstantNamespace: import("alchemy/Resource").ResourceClass<InstantNamespace>;
export declare const InstantNamespaceProvider: () => import("effect/Layer").Layer<Provider.Provider<InstantNamespace>, never, import("alchemy/AlchemyContext").AlchemyContext | CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | kv.CloudflareOpContext>;
//# sourceMappingURL=InstantNamespace.d.ts.map