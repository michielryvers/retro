import * as Layer from "effect/Layer";
import { WriteNamespace } from "./WriteNamespace.ts";
/**
 * Local implementation of the {@link WriteNamespace} binding — writes KV
 * values over the Cloudflare HTTP API using the **current credentials**
 * instead of a native Worker binding (`WriteNamespaceBinding`) or a scoped API
 * token (`WriteNamespaceHttp`).
 *
 * Provide it on an {@link Action} (or any deploy-time Effect) so you can write
 * to a namespace with the same `put`/`delete` client you'd use inside a
 * Worker:
 *
 * @example Writing a value from an Action
 * ```typescript
 * const Seed = Alchemy.Action(
 *   "Seed",
 *   Effect.gen(function* () {
 *     const kv = yield* Cloudflare.KV.WriteNamespace(namespace);
 *     return Effect.fn(function* () {
 *       yield* kv.put("my-key", "hello world");
 *     });
 *   }).pipe(Effect.provide(Cloudflare.KV.WriteNamespaceLocal)),
 * );
 * ```
 */
export declare const WriteNamespaceLocal: Layer.Layer<WriteNamespace, never, import("../CloudflareEnvironmentService.ts").CloudflareEnvironment | import("@distilled.cloud/cloudflare/Credentials").Credentials | import("effect/http/HttpClient").HttpClient>;
//# sourceMappingURL=WriteNamespaceLocal.d.ts.map