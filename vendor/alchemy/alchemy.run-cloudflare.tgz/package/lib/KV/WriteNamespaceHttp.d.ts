import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { type KVAuth } from "./NamespaceHttp.ts";
import { WriteNamespace, type WriteNamespaceClient } from "./WriteNamespace.ts";
/**
 * HTTP-backed implementation of the {@link WriteNamespace} binding.
 *
 * It creates a scoped {@link AccountApiToken} with the `Workers KV Storage
 * Write` permission and writes values via the Cloudflare KV HTTP API.
 */
export declare const WriteNamespaceHttp: Layer.Layer<WriteNamespace, never, import("alchemy/Self").Self<{
    Type: string;
    LogicalId: string;
}>>;
export declare const makeWriteKVHttpClient: (auth: KVAuth, namespaceId: Effect.Effect<string>) => WriteNamespaceClient;
//# sourceMappingURL=WriteNamespaceHttp.d.ts.map