import * as k2 from "@distilled.cloud/cloudflare/k2";
import type { PropsInput } from "alchemy/Input";
import * as Provider from "alchemy/Provider";
import { Resource, type ResourceClass } from "alchemy/Resource";
import type * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
import type { ConsumedRecord, DecodedRecord, Record as K2Record, RecordSchema } from "./K2Types.ts";
declare const StreamTypeId: "Cloudflare.K2.Stream";
type StreamTypeId = typeof StreamTypeId;
/**
 * HTTP input configuration of a K2 stream.
 */
export interface StreamHttpInput {
    /**
     * Require an API token with the `K2 Produce` permission on `/produce`.
     * When `false` the endpoint is public.
     * @default true
     */
    authentication?: boolean;
    /**
     * Origins allowed to produce from a browser: `http(s)://host[:port]`
     * without a path, or `*` alone. Up to five.
     */
    cors?: string[];
}
export interface StreamProps {
    /**
     * Name of the stream: 1 to 128 letters, numbers, or underscores, unique in
     * the account (not case-sensitive). If omitted, a unique name is generated
     * from the app, stage, and logical ID. Changing the name replaces the
     * stream.
     * @default ${app}_${id}_${stage}_${suffix}
     */
    name?: string;
    /**
     * How long records are retained, from one hour to 30 days. Rounded to whole
     * seconds. Mutable in place.
     * @default "7 days"
     */
    retention?: Duration.Input;
    /**
     * The stream's HTTP input (`POST https://<id>.k2.cloudflarestorage.com/produce`).
     * `false` disables it, `true` enables it with token authentication, and an
     * object enables it with the given settings. Mutable in place.
     * @default false
     */
    http?: boolean | StreamHttpInput;
    /**
     * Whether Workers can produce to the stream through a `k2` binding
     * (`Cloudflare.K2.WriteStream` with `WriteStreamBinding`). Mutable in place.
     * At least one of `http` and `workerBinding` must be enabled.
     * @default true
     */
    workerBinding?: boolean;
}
export interface StreamAttributes {
    /** The stream ID: 32 lowercase hexadecimal characters. */
    streamId: string;
    /** The stream name (unique in the account). */
    streamName: string;
    /** The stream's HTTP endpoint, `https://<id>.k2.cloudflarestorage.com`. */
    endpoint: string;
    /** How long records are retained, in seconds. */
    retentionSeconds: number;
    /** Whether the HTTP input accepts records. */
    httpEnabled: boolean;
    /** Whether the HTTP input requires a `K2 Produce` API token. */
    httpAuthentication: boolean;
    /** Origins allowed to produce from a browser. */
    corsOrigins: string[] | undefined;
    /** Whether Workers can produce through a `k2` binding. */
    workerBindingEnabled: boolean;
    /** Account that owns the stream. */
    accountId: string;
    /** When the stream was created. */
    createdAt: string;
    /** When the stream was last modified. */
    modifiedAt: string;
}
/**
 * A K2 stream. `A` is the record type its producers send and its consumers
 * decode — the Effect Schema's `Type` when the stream was declared with
 * `schema`, unknown otherwise.
 */
export interface Stream<A = unknown> extends Resource<StreamTypeId, StreamProps, StreamAttributes, never, Providers> {
    /**
     * The Effect Schema the stream was declared with, if any. Producers encode
     * records with it and consumers decode them; it is never persisted, because
     * K2 itself stores bytes.
     */
    readonly RecordSchema: RecordSchema<any> | undefined;
    /** Phantom record type. */
    readonly "~record"?: A;
}
/**
 * The record a producer sends to a `Stream<A>`: the schema's type, or raw
 * bytes plus headers ({@link K2Record}) for a stream without a schema.
 */
export type StreamRecord<A> = unknown extends A ? K2Record : A;
/**
 * The record a consumer receives from a `Stream<A>`: decoded into `value` for
 * a stream with a schema, raw bytes otherwise.
 */
export type StreamConsumedRecord<A> = unknown extends A ? ConsumedRecord : DecodedRecord<A>;
/** Props of a stream declared with an Effect Schema. */
export type StreamSchemaProps<S extends RecordSchema<any>> = PropsInput<StreamProps> & {
    /**
     * Encode every record as JSON with this schema on the way in, and decode
     * it on the way out. A client-side codec only: K2 stores bytes, so
     * changing the schema never updates or replaces the stream.
     */
    schema: S;
};
/**
 * The Stream constructor: the plain resource constructor plus an overload
 * that types the stream's records from an Effect Schema `schema`.
 */
export type StreamClass = {
    <const S extends RecordSchema<any>>(id: string, props: StreamSchemaProps<S>): Effect.Effect<Stream<S["Type"]>, never, Providers>;
} & ResourceClass<Stream>;
/**
 * A Cloudflare K2 stream — a durable, ordered log of records. Producers
 * append records over HTTP or from Workers through a `k2` binding;
 * consumers read them through a {@link Subscription}, each with its own
 * position in the stream.
 *
 * The name is fixed at creation (changing it replaces the stream);
 * retention and the HTTP / Worker-binding inputs are mutable in place.
 * ### Creating a Stream
 * **Example:** Stream with default settings
 * ```typescript
 * // Worker-binding input enabled, HTTP input disabled, 7-day retention.
 * const orders = yield* Cloudflare.K2.Stream("Orders");
 * ```
 *
 * **Example:** Custom retention
 * ```typescript
 * const orders = yield* Cloudflare.K2.Stream("Orders", {
 *   retention: "30 days",
 * });
 * ```
 *
 * ### Typed Records
 * **Example:** Stream with an Effect Schema
 * ```typescript
 * const Order = Schema.Struct({ orderId: Schema.String, amountCents: Schema.Number });
 *
 * // Producers send `Order`s; consumers receive them decoded in `record.value`.
 * const orders = yield* Cloudflare.K2.Stream("Orders", { schema: Order });
 * ```
 *
 * ### HTTP Input
 * **Example:** Authenticated HTTP input
 * ```typescript
 * // POST records to orders.endpoint + "/produce" with a K2 Produce token.
 * const orders = yield* Cloudflare.K2.Stream("Orders", {
 *   http: true,
 * });
 * ```
 *
 * **Example:** Public HTTP input for browsers
 * ```typescript
 * const clicks = yield* Cloudflare.K2.Stream("Clicks", {
 *   http: { authentication: false, cors: ["https://app.example.com"] },
 *   workerBinding: false,
 * });
 * ```
 *
 * ### Producing from a Worker
 * **Example:** Send records through the Worker binding
 * ```typescript
 * export default Cloudflare.Worker(
 *   "Api",
 *   { main: import.meta.url },
 *   Effect.gen(function* () {
 *     const orders = yield* Cloudflare.K2.WriteStream(Orders);
 *     return {
 *       fetch: Effect.gen(function* () {
 *         yield* orders.send([{ content: JSON.stringify({ id: 1 }) }]);
 *         return HttpServerResponse.empty({ status: 202 });
 *       }),
 *     };
 *   }).pipe(Effect.provide(Cloudflare.K2.WriteStreamBinding)),
 * );
 * ```
 *
 * ### Consuming
 * **Example:** A subscription reading from the start of the stream
 * ```typescript
 * const analytics = yield* Cloudflare.K2.Subscription("Analytics", {
 *   stream: orders,
 *   startAt: "earliest",
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/k2/
 *
 * @resource
 * @product K2
 * @category Storage & Databases
 */
export declare const Stream: StreamClass;
/** Returns true if the given value is a K2 Stream resource. */
export declare const isStream: (value: unknown) => value is Stream;
export declare const StreamProvider: () => import("effect/Layer").Layer<Provider.Provider<Stream<unknown>>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | k2.CloudflareOpContext>;
export {};
//# sourceMappingURL=Stream.d.ts.map