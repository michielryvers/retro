import * as Layer from "effect/Layer";
/**
 * Implementation of the {@link StreamSink} service over the stream's HTTP
 * input ({@link WriteStreamHttp}), authenticated with a scoped `K2 Produce`
 * API token bound into the host. The stream needs `http: true`.
 * ### Providing the Layer
 * **Example:** Drain a Stream over HTTP
 * ```typescript
 * Effect.gen(function* () {
 *   const sink = yield* Cloudflare.K2.StreamSink(Orders);
 *   // ...
 * }).pipe(Effect.provide(Cloudflare.K2.StreamSinkHttp));
 * ```
 *
 * @layer
 * @provides Cloudflare.K2.StreamSink
 * @product K2
 * @category Storage & Databases
 */
export declare const StreamSinkHttp: Layer.Layer<import("./StreamSink.ts").StreamSink, never, import("alchemy/Self").Self<{
    Type: string;
    LogicalId: string;
}>>;
//# sourceMappingURL=StreamSinkHttp.d.ts.map