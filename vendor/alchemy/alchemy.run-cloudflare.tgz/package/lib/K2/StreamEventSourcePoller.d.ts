import { ServerHost } from "alchemy/Runtime/Process";
import * as Layer from "effect/Layer";
import { ReadSubscription } from "./ReadSubscription.ts";
import { StreamEventSource } from "./StreamEventSource.ts";
/**
 * Polling implementation of {@link StreamEventSource} for hosts with a
 * long-lived process (any host providing `ServerHost`: Fly, ECS, EC2,
 * Railway, Hetzner, Docker). Requires a `ReadSubscription` implementation.
 *
 * :::note
 * TODO: Workers cannot consume K2 yet — K2 has no push consumers (they are
 * on Cloudflare's roadmap), so no Worker layer ships.
 * :::
 * ### Providing the Layer
 * **Example:** Poll with a scoped token
 * ```typescript
 * Effect.gen(function* () {
 *   yield* Cloudflare.K2.consumeStreamRecords(Orders, handler);
 * }).pipe(
 *   Effect.provide(
 *     Layer.provideMerge(
 *       Cloudflare.K2.StreamEventSourcePolling,
 *       Cloudflare.K2.ReadSubscriptionHttp,
 *     ),
 *   ),
 * );
 * ```
 *
 * @layer
 * @provides Cloudflare.K2.StreamEventSource
 * @product K2
 * @category Storage & Databases
 */
export declare const StreamEventSourcePolling: Layer.Layer<StreamEventSource, never, ReadSubscription | ServerHost>;
//# sourceMappingURL=StreamEventSourcePoller.d.ts.map