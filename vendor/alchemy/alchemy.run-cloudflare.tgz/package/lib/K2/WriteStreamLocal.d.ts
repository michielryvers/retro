import * as Layer from "effect/Layer";
import { WriteStream } from "./WriteStream.ts";
/**
 * Local implementation of the {@link WriteStream} service — appends records
 * through the stream's HTTP input with the **current credentials** instead
 * of a native binding or a scoped token. Provide it on an Action (or any
 * deploy-time Effect) to seed a stream with the same client a Worker uses.
 *
 * The stream must have its HTTP input enabled (`http: true`). The stream id
 * is resolved at apply time, so the stream can be created in the same
 * deploy.
 * ### Providing the Layer
 * **Example:** Seed a stream from an Action
 * ```typescript
 * const Seed = Alchemy.Action(
 *   "Seed",
 *   Effect.gen(function* () {
 *     const orders = yield* Cloudflare.K2.WriteStream(Orders);
 *     return Effect.fn(function* () {
 *       yield* orders.send([{ content: "hello" }]);
 *     });
 *   }).pipe(Effect.provide(Cloudflare.K2.WriteStreamLocal)),
 * );
 * ```
 *
 * @layer
 * @provides Cloudflare.K2.WriteStream
 * @product K2
 * @category Storage & Databases
 */
export declare const WriteStreamLocal: Layer.Layer<WriteStream, never, import("@distilled.cloud/cloudflare/Credentials").Credentials | import("effect/http/HttpClient").HttpClient>;
//# sourceMappingURL=WriteStreamLocal.d.ts.map