import * as Layer from "effect/Layer";
import { ReadSubscription } from "./ReadSubscription.ts";
/**
 * Local implementation of the {@link ReadSubscription} service — leases
 * batches over the K2 subscription HTTP API with the **current
 * credentials** instead of a scoped token. Provide it on an Action (or any
 * deploy-time Effect), or on a polling event source run in-process.
 *
 * The subscription's ids are resolved at apply time, so the subscription
 * can be created in the same deploy.
 * ### Providing the Layer
 * **Example:** Drain a subscription from an Action
 * ```typescript
 * const Drain = Alchemy.Action(
 *   "Drain",
 *   Effect.gen(function* () {
 *     const inbox = yield* Cloudflare.K2.ReadSubscription(Analytics);
 *     return Effect.fn(function* () {
 *       const batch = yield* inbox.consume({ workerId: "drain" });
 *       if (Option.isSome(batch)) yield* inbox.ack(batch.value);
 *     });
 *   }).pipe(Effect.provide(Cloudflare.K2.ReadSubscriptionLocal)),
 * );
 * ```
 *
 * @layer
 * @provides Cloudflare.K2.ReadSubscription
 * @product K2
 * @category Storage & Databases
 */
export declare const ReadSubscriptionLocal: Layer.Layer<ReadSubscription, never, import("@distilled.cloud/cloudflare/Credentials").Credentials | import("effect/http/HttpClient").HttpClient>;
//# sourceMappingURL=ReadSubscriptionLocal.d.ts.map