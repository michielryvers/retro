import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { type K2Auth } from "./K2Http.ts";
import { ReadSubscription, type ReadSubscriptionClient } from "./ReadSubscription.ts";
/** Default `maxRecords` per `consume`. */
export declare const DEFAULT_MAX_RECORDS = 100;
/**
 * HTTP-backed implementation of the {@link ReadSubscription} service. Mints
 * a scoped `K2 Consume` {@link AccountApiToken}, binds it into the host, and
 * leases batches through the stream's data-plane API
 * (`https://<id>.k2.cloudflarestorage.com/subscriptions/...`).
 * ### Providing the Layer
 * **Example:** Pull from a container
 * ```typescript
 * Effect.gen(function* () {
 *   const inbox = yield* Cloudflare.K2.ReadSubscription(Analytics);
 *   // ...
 * }).pipe(Effect.provide(Cloudflare.K2.ReadSubscriptionHttp));
 * ```
 *
 * @layer
 * @provides Cloudflare.K2.ReadSubscription
 * @product K2
 * @category Storage & Databases
 */
export declare const ReadSubscriptionHttp: Layer.Layer<ReadSubscription, never, import("alchemy/Self").Self<{
    Type: string;
    LogicalId: string;
}>>;
/**
 * Build the pull client over the K2 subscription HTTP API. Shared by
 * {@link ReadSubscriptionHttp} and `ReadSubscriptionLocal`.
 */
export declare const makeReadSubscriptionClient: (auth: K2Auth, ids: {
    streamId: Effect.Effect<string>;
    subscriptionId: Effect.Effect<string>;
}) => ReadSubscriptionClient;
//# sourceMappingURL=ReadSubscriptionHttp.d.ts.map