import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { Worker, WorkerEnvironment } from "../Workers/Worker.ts";
import type { EncodedRecord, ProduceError } from "./K2Types.ts";
import { WriteStream } from "./WriteStream.ts";
/**
 * The runtime shape of a `k2` Worker binding — `env.ORDERS` for a
 * `K2.Stream` in a Worker's `env`. `@cloudflare/workers-types` does not
 * declare it yet. `send` resolves (does not throw) on API errors; a
 * rejected promise means the append outcome is unknown.
 */
export interface K2StreamBinding {
    send(records: Array<{
        content: ArrayBuffer | Uint8Array;
        headers?: {
            [key: string]: string;
        };
    }>): Promise<{
        success: true;
    } | {
        success: false;
        error: {
            code: number;
            message: string;
            retryable: boolean;
        };
    }>;
}
/**
 * Implementation of the {@link WriteStream} service over the native Worker
 * `k2` binding. The stream must have its Worker-binding input enabled (the
 * default).
 *
 * K2 has no local simulation, so a Worker using this layer cannot run under
 * `alchemy dev`.
 * ### Providing the Layer
 * **Example:** Produce from a Worker
 * ```typescript
 * export default Cloudflare.Worker(
 *   "Api",
 *   { main: import.meta.url },
 *   Effect.gen(function* () {
 *     const orders = yield* Cloudflare.K2.WriteStream(Orders);
 *     return {
 *       fetch: Effect.gen(function* () {
 *         yield* orders.send([{ content: "hello" }]);
 *         return HttpServerResponse.empty({ status: 202 });
 *       }),
 *     };
 *   }).pipe(Effect.provide(Cloudflare.K2.WriteStreamBinding)),
 * );
 * ```
 *
 * @layer
 * @provides Cloudflare.K2.WriteStream
 * @product K2
 * @category Storage & Databases
 */
export declare const WriteStreamBinding: Layer.Layer<WriteStream, never, WorkerEnvironment | Worker<any>>;
/**
 * Append through the native binding. API failures resolve (they do not
 * throw), so map their code onto the same typed tags the HTTP path produces.
 * A rejected promise means the append outcome is unknown.
 */
export declare const sendViaBinding: (binding: K2StreamBinding, records: ReadonlyArray<EncodedRecord>) => Effect.Effect<void, ProduceError>;
/** Map a binding error code onto the typed tag the HTTP API uses for it. */
export declare const toProduceError: (error: {
    code: number;
    message: string;
}) => ProduceError;
//# sourceMappingURL=WriteStreamBinding.d.ts.map