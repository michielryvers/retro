import type { ProviderMode } from "alchemy/ProviderMode";
import type { RuntimeContext } from "alchemy/RuntimeContext";
import { Self } from "alchemy/Self";
import * as Effect from "effect/Effect";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../Credentials.ts";
/**
 * Shared scaffolding for the HTTP-backed K2 services. Internal — not
 * exported from the K2 barrel.
 */
/**
 * Injectable auth for the K2 HTTP clients. The scoped-token variant
 * (`*Http`) and the current-credentials variant (`*Local`) share the same
 * request path and differ only in how credentials reach the SDK operation.
 * K2 data-plane operations are addressed by stream id, so no account id is
 * needed.
 */
export interface K2Auth {
    authorize: <A, E>(eff: Effect.Effect<A, E, Credentials | HttpClient.HttpClient>) => Effect.Effect<A, E, RuntimeContext>;
}
type K2PermissionGroup = "K2 Produce" | "K2 Consume";
/**
 * Mint (or extend) the host's scoped {@link AccountApiToken} with the given
 * K2 permission group, bind it into the host at deploy time, and return
 * the {@link K2Auth} that authorizes requests with it.
 */
export declare const makeK2HttpAuth: Effect.Effect<(resource: {
    readonly Type: string;
    readonly LogicalId: string;
    readonly Mode?: ProviderMode;
}, permissionGroup: K2PermissionGroup) => Effect.Effect<{
    authorize: <A, E>(eff: Effect.Effect<A, E, Credentials | HttpClient.HttpClient>) => Effect.Effect<A, E, RuntimeContext>;
}, never, never>, never, Self<{
    Type: string;
    LogicalId: string;
}>>;
/**
 * Capture the ambient credentials (the stack's providers layer during
 * stack-eval) so a client can run with the current credentials instead of a
 * scoped token — for Actions and other deploy-time Effects.
 */
export declare const makeK2LocalAuth: Effect.Effect<{
    authorize: <A, E>(eff: Effect.Effect<A, E, Credentials | HttpClient.HttpClient>) => Effect.Effect<A, E, never>;
}, never, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=K2Http.d.ts.map