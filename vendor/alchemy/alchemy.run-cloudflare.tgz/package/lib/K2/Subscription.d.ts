import * as k2 from "@distilled.cloud/cloudflare/k2";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import type { Providers } from "../Providers.ts";
import type { StartAt } from "./K2Types.ts";
import type { Stream } from "./Stream.ts";
declare const SubscriptionTypeId: "Cloudflare.K2.Subscription";
type SubscriptionTypeId = typeof SubscriptionTypeId;
export interface SubscriptionProps {
    /**
     * The stream to read from: a `Cloudflare.K2.Stream` resource (orders the
     * subscription after the stream) or a stream ID. Changing it replaces the
     * subscription.
     */
    stream: string | Stream<any>;
    /**
     * Name of the subscription: 1 to 128 letters, numbers, underscores, or
     * hyphens, unique within the stream (not case-sensitive). If omitted, a
     * unique name is generated from the app, stage, and logical ID. Changing
     * it replaces the subscription.
     * @default ${app}-${id}-${stage}-${suffix}
     */
    name?: string;
    /**
     * Where the subscription starts reading: `earliest` from the oldest
     * retained record, `latest` from after the newest one. Changing it
     * replaces the subscription.
     * @default "latest"
     */
    startAt?: StartAt;
}
export interface SubscriptionAttributes {
    /** The subscription ID. */
    subscriptionId: string;
    /** The subscription name (unique within the stream). */
    subscriptionName: string;
    /** ID of the stream the subscription reads from. */
    streamId: string;
    /** Where the subscription started reading. */
    startAt: StartAt;
    /** When the subscription was created. */
    createdAt: string;
    /** When the subscription was last modified. */
    modifiedAt: string;
}
export type Subscription = Resource<SubscriptionTypeId, SubscriptionProps, SubscriptionAttributes, never, Providers>;
/**
 * A K2 subscription — a named read position on a {@link Stream}. Consumers
 * lease batches of records from a subscription, then acknowledge them to
 * advance it. Every subscription on a stream reads every record
 * independently; consumers sharing one subscription compete for batches.
 *
 * Subscriptions are immutable: changing the stream, name, or start position
 * replaces the subscription.
 * ### Creating a Subscription
 * **Example:** Read new records
 * ```typescript
 * const orders = yield* Cloudflare.K2.Stream("Orders");
 * const analytics = yield* Cloudflare.K2.Subscription("Analytics", {
 *   stream: orders,
 * });
 * ```
 *
 * **Example:** Read from the oldest retained record
 * ```typescript
 * const backfill = yield* Cloudflare.K2.Subscription("Backfill", {
 *   stream: orders,
 *   startAt: "earliest",
 * });
 * ```
 *
 * ### Pulling Records
 * **Example:** Lease, process, and acknowledge a batch
 * ```typescript
 * const inbox = yield* Cloudflare.K2.ReadSubscription(analytics);
 * const batch = yield* inbox.consume({ workerId: "worker-1", maxRecords: 100 });
 * if (Option.isSome(batch)) {
 *   yield* Effect.forEach(batch.value.records, handle);
 *   yield* inbox.ack(batch.value);
 * }
 * ```
 *
 * @resource
 * @product K2
 * @category Storage & Databases
 */
export declare const Subscription: import("alchemy/Resource").ResourceClass<Subscription>;
/** Returns true if the given value is a K2 Subscription resource. */
export declare const isSubscription: (value: unknown) => value is Subscription;
export declare const SubscriptionProvider: () => import("effect/Layer").Layer<Provider.Provider<Subscription>, never, import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | k2.CloudflareOpContext>;
declare const SubscriptionStreamUnresolved_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "K2SubscriptionStreamUnresolved";
} & Readonly<A>;
/** The `stream` prop did not resolve to a stream ID. */
export declare class SubscriptionStreamUnresolved extends SubscriptionStreamUnresolved_base<{
    message: string;
}> {
}
export {};
//# sourceMappingURL=Subscription.d.ts.map