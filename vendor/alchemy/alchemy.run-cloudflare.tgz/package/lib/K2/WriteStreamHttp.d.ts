import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { type K2Auth } from "./K2Http.ts";
import type { RecordSchema } from "./K2Types.ts";
import { WriteStream } from "./WriteStream.ts";
/**
 * HTTP-backed implementation of the {@link WriteStream} service. Mints a
 * scoped `K2 Produce` {@link AccountApiToken}, binds it into the host, and
 * appends records through the stream's HTTP input
 * (`POST https://<id>.k2.cloudflarestorage.com/produce`).
 *
 * The stream must have its HTTP input enabled (`http: true`). Works on any
 * host — Workers, containers, Lambda.
 * ### Providing the Layer
 * **Example:** Produce over HTTP
 * ```typescript
 * const Orders = Cloudflare.K2.Stream("Orders", { http: true });
 *
 * Effect.gen(function* () {
 *   const orders = yield* Cloudflare.K2.WriteStream(Orders);
 *   // ...
 * }).pipe(Effect.provide(Cloudflare.K2.WriteStreamHttp));
 * ```
 *
 * @layer
 * @provides Cloudflare.K2.WriteStream
 * @product K2
 * @category Storage & Databases
 */
export declare const WriteStreamHttp: Layer.Layer<WriteStream, never, import("alchemy/Self").Self<{
    Type: string;
    LogicalId: string;
}>>;
/**
 * Build the producer client over the K2 `produce` HTTP API. Shared by
 * {@link WriteStreamHttp} and `WriteStreamLocal`.
 */
export declare const makeWriteStreamHttpClient: (auth: K2Auth, streamId: Effect.Effect<string>, schema: RecordSchema<any> | undefined) => import("./WriteStream.ts").WriteStreamClient<any>;
//# sourceMappingURL=WriteStreamHttp.d.ts.map