import * as Layer from "effect/Layer";
import type { EncodedRecord } from "./K2Types.ts";
import { StreamSink, type StreamSinkClient } from "./StreamSink.ts";
import { WriteStream, type WriteStreamClient } from "./WriteStream.ts";
/**
 * Batch packing for {@link StreamSink}. Internal — not exported from the K2
 * barrel.
 */
/** K2's limit on one produce request (1 MB = 1,000,000 bytes). */
export declare const MAX_REQUEST_BYTES = 5000000;
/**
 * Greedily pack records into requests of at most {@link MAX_REQUEST_BYTES}
 * (wire size, base64 included), preserving order. A record larger than the
 * limit ships alone so K2's rejection surfaces instead of the record being
 * dropped.
 */
export declare const packStreamSinkBatches: (records: ReadonlyArray<EncodedRecord>, maxBytes?: number) => ReadonlyArray<ReadonlyArray<EncodedRecord>>;
/** Build the sink over a `WriteStream` client: one `sendEncoded` per packed batch. */
export declare const makeStreamSink: <A>(client: WriteStreamClient<A>) => StreamSinkClient<A>;
/**
 * {@link StreamSink} over whichever {@link WriteStream} implementation is
 * provided. Composed with each `WriteStream` layer in `StreamSinkBinding`,
 * `StreamSinkHttp` and `StreamSinkLocal`.
 */
export declare const StreamSinkFromWriteStream: Layer.Layer<StreamSink, never, WriteStream>;
//# sourceMappingURL=StreamSinkBatch.d.ts.map