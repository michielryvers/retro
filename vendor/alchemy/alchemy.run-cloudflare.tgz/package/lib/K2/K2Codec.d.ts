import type * as k2 from "@distilled.cloud/cloudflare/k2";
import * as Effect from "effect/Effect";
import { type ConsumedRecord, type DecodedRecord, type EncodedRecord, K2SchemaError, type Record as K2Record, type RecordSchema } from "./K2Types.ts";
/** Header K2 producers set on schema-encoded (JSON) records. */
export declare const JSON_HEADERS: {
    readonly "content-type": "application/json";
};
/** Normalize record content to bytes; strings are UTF-8 encoded. */
export declare const toBytes: (content: Uint8Array | ArrayBuffer | string) => Uint8Array;
/** Standard (padded) base64, chunked so large payloads don't overflow `apply`. */
export declare const toBase64: (bytes: Uint8Array) => string;
export declare const fromBase64: (base64: string) => Uint8Array;
/** Encode untyped records: content to bytes, headers passed through. */
export declare const encodeRecords: (records: ReadonlyArray<K2Record>) => ReadonlyArray<EncodedRecord>;
/** Encode typed values to JSON records with the binding's schema. */
export declare const encodeWithSchema: <A>(schema: RecordSchema<A>) => (values: ReadonlyArray<A>) => Effect.Effect<ReadonlyArray<EncodedRecord>, K2SchemaError>;
/** The `produce` request body shape for encoded records. */
export declare const toProduceRecords: (records: ReadonlyArray<EncodedRecord>) => Array<k2.ProduceRecord>;
/** Decode the `consume` response records into bytes + headers + timestamp. */
export declare const fromConsumedRecords: (records: ReadonlyArray<k2.ConsumedRecord>) => ReadonlyArray<ConsumedRecord>;
/** Decode JSON record content with a schema into `record.value`. */
export declare const decodeWithSchema: <A>(schema: RecordSchema<A>) => (records: ReadonlyArray<ConsumedRecord>) => Effect.Effect<ReadonlyArray<DecodedRecord<A>>, K2SchemaError>;
/**
 * Approximate size K2 counts against the 1 MB record limit: content plus
 * header names and values.
 */
export declare const recordSize: (record: EncodedRecord) => number;
/**
 * Approximate wire size of a record inside a `produce` request: base64
 * content (4/3 of the bytes) plus headers and JSON framing.
 */
export declare const wireSize: (record: EncodedRecord) => number;
//# sourceMappingURL=K2Codec.d.ts.map