import * as Layer from "effect/Layer";
import { QueueSink, type QueueSinkClient } from "./QueueSink.ts";
import { WriteQueue, type WriteQueueClient } from "./WriteQueue.ts";
/** Cloudflare's `sendBatch` limit on messages per call. */
export declare const MAX_BATCH_MESSAGES = 100;
/** Cloudflare's `sendBatch` limit on total batch size (1 KB = 1000 bytes). */
export declare const MAX_BATCH_BYTES = 256000;
/** Internal metadata Cloudflare counts against the size limits per message. */
export declare const MESSAGE_OVERHEAD_BYTES = 100;
/**
 * Approximate wire size of one message: its UTF-8 JSON encoding plus the
 * per-message metadata overhead. Values JSON cannot encode count as the
 * overhead alone; `sendBatch` rejects them and the error surfaces through
 * the sink.
 */
export declare const messageSize: (body: unknown) => number;
/**
 * Greedily pack bodies into batches of at most {@link MAX_BATCH_MESSAGES}
 * messages and {@link MAX_BATCH_BYTES} bytes, preserving order. A single
 * message larger than the byte limit ships alone so Cloudflare's rejection
 * surfaces instead of the message being dropped.
 */
export declare const packQueueSinkBatches: <A>(bodies: ReadonlyArray<A>) => ReadonlyArray<ReadonlyArray<A>>;
/** Build the sink over a `WriteQueue` client: one `sendBatch` per packed batch. */
export declare const makeQueueSink: (client: WriteQueueClient) => QueueSinkClient;
/**
 * {@link QueueSink} over whichever {@link WriteQueue} implementation is
 * provided. Composed with each `WriteQueue` layer in `QueueSinkBinding`,
 * `QueueSinkHttp` and `QueueSinkLocal`.
 */
export declare const QueueSinkFromWriteQueue: Layer.Layer<QueueSink, never, WriteQueue>;
//# sourceMappingURL=QueueSinkBatch.d.ts.map