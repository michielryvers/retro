import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { type QueueAuth } from "./QueueHttp.ts";
import { WriteQueue, type WriteQueueClient } from "./WriteQueue.ts";
/**
 * HTTP-backed implementation of the {@link WriteQueue} service.
 *
 * It creates a scoped {@link AccountApiToken} with the `Queues Write`
 * permission and pushes messages via the Cloudflare Queues bulk-push
 * HTTP API (`POST /messages/batch`). The bulk endpoint takes the raw
 * JSON value as the message `body` (the single-message endpoint
 * expects a pre-encoded string), so it round-trips arbitrary
 * JSON-serializable payloads the same way the native producer binding
 * does — `send` is just a batch of one.
 */
export declare const WriteQueueHttp: Layer.Layer<WriteQueue, never, import("alchemy/Self").Self<{
    Type: string;
    LogicalId: string;
}>>;
/**
 * Build the producer client over the Queues bulk-push HTTP API.
 *
 * Shared by {@link WriteQueueHttp} (scoped token auth) and
 * `WriteQueueLocal` (current-credentials auth) — they differ only in the
 * {@link QueueAuth} they inject.
 */
export declare const makeWriteQueueHttpClient: (auth: QueueAuth, queueId: Effect.Effect<string>) => WriteQueueClient;
//# sourceMappingURL=WriteQueueHttp.d.ts.map