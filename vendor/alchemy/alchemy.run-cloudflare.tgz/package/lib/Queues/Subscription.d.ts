import * as queues from "@distilled.cloud/cloudflare/queues";
import type { PropsInput } from "alchemy/Input";
import * as Provider from "alchemy/Provider";
import { Resource, type ResourceClass } from "alchemy/Resource";
import * as Effect from "effect/Effect";
import type { Model } from "../AI/Model.ts";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Variant } from "../Images/Variant.ts";
import type { Namespace } from "../KV/Namespace.ts";
import type { Providers } from "../Providers.ts";
import type { Bucket } from "../R2/Bucket.ts";
import type { SuperSlurperJob } from "../R2/SuperSlurperJob.ts";
import type { Index } from "../Vectorize/VectorizeIndex.ts";
import type { Worker } from "../Workers/Worker.ts";
import type { WorkflowBinding, WorkflowResource } from "../Workflows/Workflow.ts";
declare const TypeId: "Cloudflare.Queues.Subscription";
type TypeId = typeof TypeId;
/**
 * The Cloudflare product whose events the subscription delivers into the
 * Queue. Cloudflare allows a single subscription per source per account,
 * and the source is fixed at creation — changing it triggers a
 * replacement.
 */
export type SubscriptionSource = {
    /** Cloudflare Images events. */
    type: "images";
} | {
    /** Workers KV namespace events. */
    type: "kv";
} | {
    /** R2 bucket events. */
    type: "r2";
} | {
    /** Super Slurper migration events. */
    type: "superSlurper";
} | {
    /** Vectorize index events. */
    type: "vectorize";
} | {
    /** Workers AI model events for a specific model. */
    type: "workersAi.model";
    /** Name of the Workers AI model to subscribe to. */
    modelName: string;
} | {
    /** Workers Builds events for a specific Worker. */
    type: "workersBuilds.worker";
    /** Name of the Worker whose build events to subscribe to. */
    workerName: string;
} | {
    /** Workflows events for a specific workflow. */
    type: "workflows.workflow";
    /** Name of the workflow to subscribe to. */
    workflowName: string;
} | {
    /** Email Sending lifecycle events for one sending domain. */
    type: "email.sending";
    /** Zone the sending domain belongs to. */
    zoneId: string;
    /** The zone apex or a verified sending subdomain, e.g. `mail.example.com`. */
    domain: string;
};
export type SubscriptionProps = {
    /**
     * Human readable name of the subscription. If omitted, a unique name is
     * generated from the app, stage, and logical ID.
     * @default ${app}-${stage}-${id}
     */
    name?: string;
    /**
     * The event source to subscribe to (e.g. `{ type: "r2" }` for R2 bucket
     * events). The constructor also accepts Workflow bindings and supported
     * Cloudflare resources or yielded `.ref(...)` references. Images variants,
     * KV namespaces, R2 buckets, Super Slurper jobs, and Vectorize indexes select
     * all events of that product in the account, not just the supplied resource.
     * Models, Workers, and Workflows select their deferred physical names.
     * References read persisted state without owning their sources.
     * Fixed at creation — changing it triggers a replacement. Cloudflare
     * allows at most one subscription per source per account.
     */
    source: SubscriptionSource;
    /**
     * Account of a resource source, captured by the constructor. Resource sources
     * must belong to the subscription's ambient Cloudflare account.
     */
    sourceAccountId?: string;
    /**
     * Event types to deliver, scoped to the source (e.g. `bucket.created`
     * and `bucket.deleted` for the `r2` source, `namespace.created` for
     * `kv`). Must contain at least one event type valid for the source.
     */
    events: string[];
    /**
     * The ID of the Queue that receives the events
     * (the destination, e.g. `queue.queueId`).
     */
    queueId: string;
    /**
     * Whether the subscription is active.
     * @default true
     */
    enabled?: boolean;
};
export type SubscriptionAttributes = {
    /**
     * Unique identifier for the subscription.
     */
    subscriptionId: string;
    /**
     * The Cloudflare account the subscription belongs to.
     */
    accountId: string;
    /**
     * Human readable name of the subscription.
     */
    name: string;
    /**
     * The event source the subscription listens to.
     */
    source: SubscriptionSource;
    /**
     * Event types delivered by this subscription.
     */
    events: string[];
    /**
     * The ID of the destination Queue.
     */
    queueId: string;
    /**
     * Whether the subscription is active.
     */
    enabled: boolean;
    /**
     * When the subscription was created.
     */
    createdAt: string;
    /**
     * When the subscription was last modified.
     */
    modifiedAt: string;
};
export type Subscription = Resource<TypeId, SubscriptionProps, SubscriptionAttributes, never, Providers>;
/** Resources whose product events can be delivered to a Queue. */
export type SubscriptionResourceSource = WorkflowResource | Variant | Namespace | Bucket | SuperSlurperJob | Index | Model | Worker;
/** Constructor inputs; resource sources are normalized before registration. */
export type SubscriptionInput = Omit<PropsInput<SubscriptionProps>, "source" | "sourceAccountId"> & {
    /** An explicit source, Workflow binding, resource, or yielded resource reference. */
    source: PropsInput<SubscriptionProps>["source"] | WorkflowBinding | SubscriptionResourceSource;
};
type SubscriptionConstructor<Req = never> = {
    Type: TypeId;
    Props: SubscriptionProps;
    <const Methods extends Record<string, any>>(methods: Methods): SubscriptionClass & Methods;
    (id: string, props: SubscriptionInput): Effect.Effect<Subscription, never, Req>;
    <PropsReq = never>(id: string, props: Effect.Effect<SubscriptionInput, never, PropsReq>): Effect.Effect<Subscription, never, PropsReq | Req>;
};
type SubscriptionClass = SubscriptionConstructor<Providers> & Effect.Effect<SubscriptionConstructor> & Pick<ResourceClass<Subscription>, "Self" | "Provider" | "Aliases" | "ref">;
declare const SubscriptionSourceAccountMismatch_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "SubscriptionSourceAccountMismatch";
} & Readonly<A>;
/** A resource source cannot select events in a different Cloudflare account. */
export declare class SubscriptionSourceAccountMismatch extends SubscriptionSourceAccountMismatch_base<{
    readonly accountId: string;
    readonly sourceAccountId: string;
}> {
}
/**
 * A Cloudflare Queues event subscription — delivers platform events
 * (R2 bucket events, KV namespace events, Workers Builds, Workflows,
 * etc.) into a Queue as messages.
 *
 * The `source` selects which product emits the events and is fixed at
 * creation (changing it replaces the subscription). `name`, `events`,
 * `enabled`, and the destination `queueId` are all mutable in place.
 * Cloudflare allows at most one subscription per source per account.
 * ### Creating a Subscription
 * **Example:** R2 bucket events into a Queue
 * ```typescript
 * const queue = yield* Cloudflare.Queues.Queue("EventsQueue");
 *
 * const subscription = yield* Cloudflare.Queues.Subscription("R2Events", {
 *   source: { type: "r2" },
 *   events: ["bucket.created", "bucket.deleted"],
 *   queueId: queue.queueId,
 * });
 * ```
 *
 * **Example:** KV namespace events with an explicit name
 * ```typescript
 * const subscription = yield* Cloudflare.Queues.Subscription("KvEvents", {
 *   name: "kv-events",
 *   source: { type: "kv" },
 *   events: ["namespace.created"],
 *   queueId: queue.queueId,
 * });
 * ```
 *
 * **Example:** Workers Builds events for one Worker
 * ```typescript
 * const subscription = yield* Cloudflare.Queues.Subscription("BuildEvents", {
 *   source: { type: "workersBuilds.worker", workerName: "my-worker" },
 *   events: ["build.started", "build.succeeded"],
 *   queueId: queue.queueId,
 * });
 * ```
 *
 * **Example:** Workflow lifecycle events, from a Workflow bound in this stack
 * Pass the Workflow binding from the host Worker's `env` directly. Its
 * physical name remains an `Output`, so the subscription works on the
 * Workflow's first deployment and follows later renames. Only the source
 * type and physical workflow name are persisted, not the binding metadata.
 * ```typescript
 * const worker = yield* Cloudflare.Worker("Worker", {
 *   main: "./src/worker.ts",
 *   env: { INGESTION: Cloudflare.Workflow("Ingestion", { className: "IngestionWorkflow" }) },
 * });
 *
 * const subscription = yield* Cloudflare.Queues.Subscription("WorkflowEvents", {
 *   source: worker.env.INGESTION,
 *   events: ["instance.completed", "instance.errored"],
 *   queueId: queue.queueId,
 * });
 * ```
 *
 * **Example:** Workflow lifecycle events from a persisted resource reference
 * Use the logical resource ID, including any namespace. References read
 * persisted state, so deploy the host first. Omitting the options uses the
 * current stack and stage; the reference does not take ownership of the host.
 * ```typescript
 * const subscription = yield* Cloudflare.Queues.Subscription("WorkflowEvents", {
 *   source: yield* Cloudflare.Workflow.ref("Ingestion", {
 *     stack: "workflow-host",
 *     stage: "production",
 *   }),
 *   events: ["instance.completed", "instance.errored"],
 *   queueId: queue.queueId,
 * });
 * ```
 *
 * **Example:** Workflow lifecycle events by an existing physical name
 * ```typescript
 * const subscription = yield* Cloudflare.Queues.Subscription("WorkflowEvents", {
 *   source: { type: "workflows.workflow", workflowName: "existing-ingestion" },
 *   events: ["instance.completed", "instance.errored"],
 *   queueId: queue.queueId,
 * });
 * ```
 *
 * **Example:** Bounces and complaints from an Email Sending domain
 * ```typescript
 * const subscription = yield* Cloudflare.Queues.Subscription("MailEvents", {
 *   source: { type: "email.sending", zoneId: zone.zoneId, domain: "mail.example.com" },
 *   events: ["message.bounced", "message.complained"],
 *   queueId: queue.queueId,
 * });
 * ```
 *
 * ### Resource and Reference Sources
 * **Example:** Account-wide KV events from a namespace
 * ```typescript
 * const namespace = yield* Cloudflare.KV.Namespace("Cache");
 * yield* Cloudflare.Queues.Subscription("NamespaceEvents", {
 *   source: namespace,
 *   events: ["namespace.created", "namespace.deleted"],
 *   queueId: queue.queueId,
 * });
 * ```
 * KV, R2, Images, Vectorize, and Super Slurper sources are account-wide.
 * Passing a resource retains its account and deployment dependency, but does
 * not filter events to that resource. The subscription can miss the source's
 * initial creation or final deletion because it depends on that source.
 * Use an explicit product descriptor when the subscription must exist first.
 *
 * **Example:** R2 bucket reference from another stack
 * ```typescript
 * yield* Cloudflare.Queues.Subscription("BucketEvents", {
 *   source: yield* Cloudflare.R2.Bucket.ref("Uploads", {
 *     stack: "storage",
 *     stage: "production",
 *   }),
 *   events: ["bucket.created", "bucket.deleted"],
 *   queueId: queue.queueId,
 * });
 * ```
 * All resource forms accept yielded `.ref` references with optional stack
 * and stage selectors. The referenced resource must already be deployed in
 * the same Cloudflare account. Removing a subscription does not remove its
 * referenced resource.
 *
 * **Example:** Images upload events from a variant reference
 * ```typescript
 * yield* Cloudflare.Queues.Subscription("ImageEvents", {
 *   source: yield* Cloudflare.Images.Variant.ref("Thumbnail"),
 *   events: ["image.uploaded"],
 *   queueId: queue.queueId,
 * });
 * ```
 * The variant selects its Images account; uploads are not filtered by variant.
 *
 * **Example:** Vectorize index events
 * ```typescript
 * yield* Cloudflare.Queues.Subscription("IndexEvents", {
 *   source: yield* Cloudflare.Vectorize.Index.ref("Search"),
 *   events: ["index.created", "index.deleted"],
 *   queueId: queue.queueId,
 * });
 * ```
 *
 * **Example:** Super Slurper migration events
 * ```typescript
 * yield* Cloudflare.Queues.Subscription("MigrationEvents", {
 *   source: yield* Cloudflare.R2.SuperSlurperJob.ref("Migration"),
 *   events: ["job.completed", "job.aborted"],
 *   queueId: queue.queueId,
 * });
 * ```
 * This selects all migration jobs in the account, not one job's objects.
 *
 * **Example:** Workers AI batch events
 * ```typescript
 * const model = yield* Cloudflare.AI.Model("Embeddings", {
 *   modelName: "@cf/baai/bge-m3",
 * });
 * yield* Cloudflare.Queues.Subscription("BatchEvents", {
 *   source: model,
 *   events: ["batch.queued", "batch.succeeded", "batch.failed"],
 *   queueId: queue.queueId,
 * });
 * ```
 * The model is a non-owning catalog handle. These events require asynchronous
 * batch inference; ordinary synchronous inference does not emit them.
 *
 * **Example:** Workers Builds events from a Worker reference
 * ```typescript
 * yield* Cloudflare.Queues.Subscription("BuildEvents", {
 *   source: yield* Cloudflare.Worker.ref("Website"),
 *   events: ["build.started", "build.succeeded", "build.failed"],
 *   queueId: queue.queueId,
 * });
 * ```
 * The Worker must have a Workers Builds integration to emit build events.
 * An ordinary Alchemy Worker upload is not a Workers Builds run.
 *
 * Event delivery can lag subscription creation or replacement even after the
 * destination Queue accepts messages. Deployment confirms configuration, not
 * delivery readiness; verify delivery before emitting events that must be observed.
 * During Vectorize subscription replacement or a destination Queue update,
 * Cloudflare can still route new events to the previous Queue. Replacement events
 * can carry the deleted subscription's ID; updates retain the same subscription ID.
 * A single early event does not prove that routing has fully propagated. Keep the
 * previous destination available during the transition and verify the receiving
 * Queue, `metadata.eventSubscriptionId`, and the event's resource identity.
 *
 * ### Pausing delivery
 * **Example:** Disable a subscription without deleting it
 * ```typescript
 * const subscription = yield* Cloudflare.Queues.Subscription("R2Events", {
 *   source: { type: "r2" },
 *   events: ["bucket.created"],
 *   queueId: queue.queueId,
 *   enabled: false,
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/queues/event-subscriptions/
 *
 * @resource
 * @product Queues
 * @category Storage & Databases
 */
export declare const Subscription: SubscriptionClass;
/**
 * Returns true if the given value is a Subscription resource.
 */
export declare const isSubscription: (value: unknown) => value is Subscription;
export declare const SubscriptionProvider: () => import("effect/Layer").Layer<Provider.Provider<Subscription>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | queues.CloudflareOpContext>;
export {};
//# sourceMappingURL=Subscription.d.ts.map