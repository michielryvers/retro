import { type DnsAdapter, type DnsConfig, type DnsRecord } from "alchemy/DNS/Adapter";
import type { Input } from "alchemy/Input";
import type { Providers } from "../Providers.ts";
import { RecordList } from "./RecordList.ts";
import { Records } from "./Records.ts";
/** The {@link DnsConfig.type} of the Cloudflare DNS adapter. */
export declare const CLOUDFLARE_DNS = "Cloudflare.DNS";
export interface AdapterOptions {
    /**
     * Zone that owns the records: a zone id, a zone name, or a `Zone`
     * resource. Inferred from each hostname when omitted.
     */
    readonly zone?: Input<string> | {
        readonly zoneId: Input<string>;
    };
    /**
     * Send alias records through Cloudflare's proxy (orange cloud).
     * Validation and verification records are always DNS-only.
     * @default false
     */
    readonly proxied?: boolean;
}
/**
 * Publish a custom domain's DNS records in a Cloudflare zone — e.g. a
 * domain registered with Cloudflare Registrar that is served by AWS, Fly,
 * Railway, Neon, Prisma, or Hetzner.
 *
 * Pass it as `domain.dns`. The serving platform then publishes its
 * certificate-validation / verification records (always DNS-only) and
 * points each hostname at itself with a `CNAME` (flattened at the zone
 * apex) or `A`/`AAAA` records. Requires `Cloudflare.providers()` in the
 * stack. See [DNS Adapters](/infrastructure-as-code/dns-adapters).
 *
 * **Example:** AWS site on a Cloudflare domain
 * ```typescript
 * yield* AWS.Website.StaticSite("Site", {
 *   path: "./dist",
 *   domain: { name: "www.example.com", dns: Cloudflare.DNS.Adapter() },
 * });
 * ```
 *
 * **Example:** Pinned zone, proxied aliases
 * ```typescript
 * // Proxying CloudFront through Cloudflare: set the zone's SSL/TLS mode
 * // to Full (strict).
 * dns: Cloudflare.DNS.Adapter({ zone: "example.com", proxied: true })
 * ```
 */
export declare const Adapter: (options?: AdapterOptions) => DnsConfig<typeof CLOUDFLARE_DNS>;
/**
 * The Cloudflare DNS adapter, registered by `Cloudflare.providers()`:
 *
 * - `alias` / `aliasSet` — a `Cloudflare.DNS.Records` CNAME set for a
 *   hostname target (logical id `{id}-CNAME`), or a
 *   `Cloudflare.DNS.RecordList` of `A`/`AAAA` records for an address target
 *   (`{id}-Addresses`).
 * - `records` — a `Cloudflare.DNS.RecordList`.
 */
export declare const adapter: {
    alias: (id: string, { zone, options, name, target }: import("alchemy/DNS/Adapter").DnsZone & {
        name: string;
        target: import("alchemy/DNS/Adapter").DnsAliasTarget;
        ipv6?: boolean;
    }) => import("effect/Effect").Effect<RecordList, never, Providers> | import("effect/Effect").Effect<Records, never, Providers>;
    aliasSet: (id: string, { zone, options, names, target }: import("alchemy/DNS/Adapter").DnsZone & {
        names?: string[];
        target: import("alchemy/DNS/Adapter").DnsHostnameTarget;
    }) => import("effect/Effect").Effect<Records, never, Providers>;
    records: (id: string, { zone, records, retain }: import("alchemy/DNS/Adapter").DnsZone & {
        records: Input<DnsRecord[]>;
        retain?: boolean;
    }) => import("effect/Effect").Effect<RecordList, never, Providers>;
};
export declare const AdapterLive: import("effect/Layer").Layer<DnsAdapter<any>, never, never>;
//# sourceMappingURL=Adapter.d.ts.map