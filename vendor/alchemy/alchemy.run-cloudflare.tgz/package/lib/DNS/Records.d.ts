import * as dns from "@distilled.cloud/cloudflare/dns";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
import { type Reference as ZoneReference } from "../Zone/lookup.ts";
/** Record types a {@link Records} set can manage. */
export type RecordsType = "A" | "AAAA" | "CNAME";
/**
 * Binding contract of {@link Records}: composites (e.g. an
 * `AWS.Website.StaticSite` attached to an `AWS.Website.Router`) contribute
 * additional record names without a circular input prop.
 */
export type RecordsBinding = {
    /**
     * Additional record names to manage alongside {@link RecordsProps.names}.
     */
    names?: string[];
};
export interface RecordsProps {
    /**
     * Zone that owns the records — a zone id, zone name, or `Zone`
     * resource. When omitted, the
     * zone containing the set's first name is inferred by walking its parent
     * domains; the deploy fails actionably when no zone matches. Every name in
     * the set lives in the one zone either way.
     */
    zone?: ZoneReference;
    /**
     * Record type shared by every record in the set. Stable — changing it
     * replaces the set.
     */
    type: RecordsType;
    /**
     * Record value shared by every record in the set (e.g. the target
     * hostname of a CNAME).
     */
    content: string;
    /**
     * Record names managed by this set. Names contributed through the binding
     * contract (see {@link RecordsBinding}) are merged in at reconcile time.
     */
    names?: string[];
    /**
     * Whether to send the records through Cloudflare's proxy.
     * @default false
     */
    proxied?: boolean;
    /**
     * TTL in seconds (`60`–`86400`), or `1` for Cloudflare's "automatic"
     * setting. Must be `1` when `proxied` is `true`.
     * @default 1
     */
    ttl?: number;
}
export interface RecordsAttributes {
    /**
     * Zone that owns the records. `undefined` only while the set is empty
     * with no explicit zone — resolved on the first reconcile that has a
     * name.
     */
    zoneId: string | undefined;
    /** Record type shared by every record in the set. */
    type: RecordsType;
    /** Record value shared by every record in the set. */
    content: string;
    /** Whether the records are proxied. */
    proxied: boolean;
    /** TTL of the records (`1` = automatic). */
    ttl: number;
    /**
     * Fully qualified names of every record currently managed by this set
     * (declared `names` plus bound names, as of the last reconcile).
     */
    names: string[];
}
export type Records = Resource<"Cloudflare.DNS.Records", RecordsProps, RecordsAttributes, RecordsBinding, Providers>;
/**
 * A dynamic set of identically-configured Cloudflare DNS records that differ
 * only by name — the Cloudflare counterpart of `AWS.Route53.Records`.
 *
 * Unlike `Cloudflare.DNS.Record` (one resource per record), `Records`
 * reconciles a whole name set against the zone: names added to the set are
 * created or overwritten, names removed from the set are deleted. The set is
 * the union of the declared `names` prop and names contributed through the
 * {@link RecordsBinding} binding contract, which is how composites (e.g. a
 * site attached to an `AWS.Website.Router`) register hostnames on a
 * distribution's DNS without a circular input prop.
 *
 * Ownership: when the set is first created, records that already exist at
 * its names are reported as not owned, so the deploy refuses to overwrite
 * them unless `--adopt` (or `adopt(true)`) is set. Names added later are
 * overwritten like a Route 53 `UPSERT`, and removed again when the name
 * leaves the set or the set is destroyed. Cloudflare
 * rejects a `CNAME` at a name that already has `A`/`AAAA` records; remove
 * those first.
 * ### Managing Record Sets
 * **Example:** CNAMEs For Several Hostnames
 * ```typescript
 * const records = yield* Cloudflare.DNS.Records("AliasRecords", {
 *   type: "CNAME",
 *   content: distribution.domainName,
 *   names: ["www.example.com", "docs.example.com"],
 * });
 * ```
 *
 * **Example:** Binding Target For Composite-Contributed Names
 * ```typescript
 * // An empty set that attached sites bind their hostnames onto:
 * const records = yield* Cloudflare.DNS.Records("SiteAliasRecords", {
 *   zone: "example.com",
 *   type: "CNAME",
 *   content: distribution.domainName,
 * });
 * // elsewhere:
 * yield* records.bind`MySite`({ names: ["docs.example.com"] });
 * ```
 *
 * @resource
 * @product DNS
 * @category Domains & DNS
 */
export declare const Records: import("alchemy/Resource").ResourceClass<Records>;
export declare const RecordsProvider: () => import("effect/Layer").Layer<Provider.Provider<Records>, never, CloudflareEnvironment | dns.CloudflareOpContext>;
//# sourceMappingURL=Records.d.ts.map