import * as dns from "@distilled.cloud/cloudflare/dns";
import type { DnsRecord, DnsRecordType } from "alchemy/DNS/Adapter";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
export interface RecordListProps {
    /**
     * Zone that owns every record — a zone id or zone name. When omitted,
     * each record's zone is inferred from its name by walking its parent
     * domains, so one list may span several zones (e.g. certificate
     * validation records for `example.com` and `example.org`).
     */
    zone?: string;
    /**
     * Records to publish. Always DNS-only (never proxied).
     *
     * - `CNAME` — overwrites any record at the name (one CNAME per name).
     * - `A` / `AAAA` — the name's addresses of that type converge to exactly
     *   the listed values.
     * - `TXT` — each listed value is added alongside any other TXT values at
     *   the name.
     */
    records: DnsRecord[];
}
/** One record published by a {@link RecordList}. */
export interface RecordListEntry {
    /** Zone the record lives in. */
    zoneId: string;
    /** Normalized record name (lowercase, no trailing dot). */
    name: string;
    /** Record type. */
    type: DnsRecordType;
    /** Normalized record value. */
    value: string;
    /** TTL in seconds (`1` = automatic). */
    ttl: number;
}
export interface RecordListAttributes {
    /** Every record this list currently publishes. */
    records: RecordListEntry[];
}
export type RecordList = Resource<"Cloudflare.DNS.RecordList", RecordListProps, RecordListAttributes, never, Providers>;
/**
 * An explicit list of Cloudflare DNS records whose values are typically
 * computed from another resource's outputs — ACM certificate validation
 * CNAMEs, a platform's ownership-verification TXT, a Fly App's addresses.
 *
 * This is the resource a `Cloudflare.DNS.Adapter()` declares for
 * `domain.dns` record publication (see
 * [DNS Adapters](/infrastructure-as-code/dns-adapters)). Records are
 * DNS-only, the zone of each record is inferred from its name unless
 * `zone` is set, and only the records the list published are removed when
 * they leave the list or the list is destroyed.
 * ### Publishing Records
 * **Example:** Certificate Validation Records
 * ```typescript
 * const cert = yield* AWS.ACM.Certificate("Cert", {
 *   domainName: "app.example.com",
 *   dnsValidation: "external",
 * });
 * yield* Cloudflare.DNS.RecordList("CertValidation", {
 *   records: cert.domainValidationOptions.pipe(
 *     Output.map(AWS.ACM.validationRecordsOf),
 *   ),
 * });
 * ```
 *
 * **Example:** Verification TXT
 * ```typescript
 * yield* Cloudflare.DNS.RecordList("Verify", {
 *   zone: "example.com",
 *   records: [
 *     { name: "_verify.example.com", type: "TXT", value: "token-123" },
 *   ],
 * });
 * ```
 *
 * @resource
 * @product DNS
 * @category Domains & DNS
 */
export declare const RecordList: import("alchemy/Resource").ResourceClass<RecordList>;
export declare const RecordListProvider: () => import("effect/Layer").Layer<Provider.Provider<RecordList>, never, CloudflareEnvironment | dns.CloudflareOpContext>;
//# sourceMappingURL=RecordList.d.ts.map