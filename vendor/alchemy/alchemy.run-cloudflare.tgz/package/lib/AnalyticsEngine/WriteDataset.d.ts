import * as Binding from "alchemy/Binding";
import type { RuntimeContext } from "alchemy/RuntimeContext";
import * as Effect from "effect/Effect";
import type { Dataset as AnalyticsEngineDatasetLike } from "./Dataset.ts";
/**
 * Bind an {@link AnalyticsEngineDatasetLike} dataset to a Worker and obtain the
 * Effect-native client (`writeDataPoint`, `raw`).
 *
 * `WriteDataset` is a single identifier that is simultaneously the binding's
 * Context tag, its type, and the callable —
 * `yield* Cloudflare.AnalyticsEngine.WriteDataset(dataset)`.
 *
 *
 * **Example:** Write a data point inside a Worker
 * ```typescript
 * const analytics = yield* Cloudflare.AnalyticsEngine.WriteDataset(Dataset);
 * yield* analytics.writeDataPoint({ blobs: ["signup"] });
 * ```
 *
 * @binding
 * @product Analytics Engine
 * @category Observability & Analytics
 */
export interface WriteDataset extends Binding.Service<WriteDataset, "Cloudflare.AnalyticsEngineDataset.WriteDataset", (dataset: AnalyticsEngineDatasetLike) => Effect.Effect<DatasetClient>> {
}
export declare const WriteDataset: WriteDataset;
export interface DataPoint {
    indexes?: string[];
    blobs?: string[];
    doubles?: number[];
}
export interface RuntimeAnalyticsEngineDataset {
    writeDataPoint(dataPoint: DataPoint): void;
}
declare const DatasetError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DatasetError";
} & Readonly<A>;
export declare class DatasetError extends DatasetError_base<{
    message: string;
    cause: Error;
}> {
}
export interface DatasetClient {
    raw: Effect.Effect<RuntimeAnalyticsEngineDataset, never, RuntimeContext>;
    writeDataPoint(dataPoint: DataPoint): Effect.Effect<void, DatasetError, RuntimeContext>;
}
export {};
//# sourceMappingURL=WriteDataset.d.ts.map