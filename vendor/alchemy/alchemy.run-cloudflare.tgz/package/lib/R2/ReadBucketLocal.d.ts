import * as Layer from "effect/Layer";
import { ReadBucket } from "./ReadBucket.ts";
/**
 * Local implementation of the {@link ReadBucket} binding — reads R2 objects
 * over the Cloudflare HTTP API using the **current credentials** instead of a
 * native Worker binding (`ReadBucketBinding`) or a scoped API token
 * (`ReadBucketHttp`).
 *
 * Provide it on an {@link Action} (or any deploy-time Effect) to read a bucket
 * with the same `head`/`get`/`list` client you'd use inside a Worker.
 *
 * @example Reading an object from an Action
 * ```typescript
 * const Read = Alchemy.Action(
 *   "Read",
 *   Effect.gen(function* () {
 *     const r2 = yield* Cloudflare.R2.ReadBucket(bucket);
 *     return Effect.fn(function* () {
 *       const object = yield* r2.get("hello.txt");
 *       return object ? yield* object.text() : null;
 *     });
 *   }).pipe(Effect.provide(Cloudflare.R2.ReadBucketLocal)),
 * );
 * ```
 */
export declare const ReadBucketLocal: Layer.Layer<ReadBucket, never, import("../CloudflareEnvironmentService.ts").CloudflareEnvironment | import("@distilled.cloud/cloudflare/Credentials").Credentials | import("effect/http/HttpClient").HttpClient>;
//# sourceMappingURL=ReadBucketLocal.d.ts.map