import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { type R2Auth } from "./BucketHttp.ts";
import { ReadWriteBucket, type ReadWriteBucketClient } from "./ReadWriteBucket.ts";
/**
 * HTTP-backed implementation of the {@link ReadWriteBucket} binding.
 *
 * It creates a scoped {@link AccountApiToken} with the `Workers R2 Storage Read` and `Workers R2 Storage Write` permissions.
 */
export declare const ReadWriteBucketHttp: Layer.Layer<ReadWriteBucket, never, import("alchemy/Self").Self<{
    Type: string;
    LogicalId: string;
}>>;
/** Build the HTTP-backed {@link ReadWrite} over a bound token + bucket. */
export declare const makeReadWriteR2HttpClient: (auth: R2Auth, bucketName: Effect.Effect<string>, jurisdiction: Effect.Effect<string>) => ReadWriteBucketClient;
//# sourceMappingURL=ReadWriteBucketHttp.d.ts.map