import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { type R2Auth } from "./BucketHttp.ts";
import { ReadBucket, type ReadBucketClient } from "./ReadBucket.ts";
/**
 * HTTP-backed implementation of the {@link ReadBucket} binding.
 *
 * It creates a scoped {@link AccountApiToken} with the `Workers R2 Storage Read` and `Workers R2 Storage Write` permissions.
 */
export declare const ReadBucketHttp: Layer.Layer<ReadBucket, never, import("alchemy/Self").Self<{
    Type: string;
    LogicalId: string;
}>>;
export declare const makeReadR2HttpClient: (auth: R2Auth, bucketName: Effect.Effect<string>, jurisdiction: Effect.Effect<string>) => ReadBucketClient;
//# sourceMappingURL=ReadBucketHttp.d.ts.map