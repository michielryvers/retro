import type * as runtime from "@cloudflare/workers-types";
import * as Binding from "alchemy/Binding";
import type { RuntimeContext } from "alchemy/RuntimeContext";
import * as Effect from "effect/Effect";
import type { Bucket } from "./Bucket.ts";
import type { R2Error, GetOptions, ListOptions, R2Object, ObjectBody, Objects } from "./BucketTypes.ts";
/**
 * @binding
 * @product R2
 * @category Storage & Databases
 */
export interface ReadBucket extends Binding.Service<ReadBucket, "Cloudflare.R2.ReadBucket", (bucket: Bucket) => Effect.Effect<ReadBucketClient>> {
}
export declare const ReadBucket: ReadBucket;
export interface ReadBucketClient {
    raw: Effect.Effect<runtime.R2Bucket, never, RuntimeContext>;
    head(key: string): Effect.Effect<R2Object | null, R2Error, RuntimeContext>;
    get(key: string, options: GetOptions & {
        onlyIf: runtime.R2Conditional | Headers;
    }): Effect.Effect<ObjectBody | R2Object | null, R2Error, RuntimeContext>;
    get(key: string, options?: GetOptions): Effect.Effect<ObjectBody | null, R2Error, RuntimeContext>;
    list(options?: ListOptions): Effect.Effect<Objects, R2Error, RuntimeContext>;
}
//# sourceMappingURL=ReadBucket.d.ts.map