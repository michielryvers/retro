import * as Layer from "effect/Layer";
import { PresignPutObject } from "./PresignPutObject.ts";
/**
 * Implementation of {@link PresignPutObject} that signs URLs with S3
 * credentials derived from an API token. Signing is local SigV4 — no request
 * is made to R2.
 *
 * Deployed, it mints a scoped account API token with
 * `Workers R2 Storage Write` (access key id = token id, secret = SHA-256 of
 * the token value) and signs URLs for `{accountId}.r2.cloudflarestorage.com`.
 * Under `alchemy dev`, a locally-emulated bucket is signed with fixed local
 * credentials for the Worker's local S3 endpoint, and no token is created.
 *
 * @layer
 * @provides Cloudflare.R2.PresignPutObject
 * @product R2
 */
export declare const PresignPutObjectToken: Layer.Layer<PresignPutObject, never, import("../index.ts").WorkerEnvironment | import("../index.ts").Worker<any>>;
//# sourceMappingURL=PresignPutObjectToken.d.ts.map