import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { type R2Auth } from "./BucketHttp.ts";
import { WriteBucket, type WriteBucketClient } from "./WriteBucket.ts";
/**
 * HTTP-backed implementation of the {@link WriteBucket} binding.
 *
 * It creates a scoped {@link AccountApiToken} with the `Workers R2 Storage Read` and `Workers R2 Storage Write` permissions.
 */
export declare const WriteBucketHttp: Layer.Layer<WriteBucket, never, import("alchemy/Self").Self<{
    Type: string;
    LogicalId: string;
}>>;
/** Build the write half of the HTTP-backed {@link ReadWrite} client. */
export declare const makeWriteR2HttpClient: (auth: R2Auth, bucketName: Effect.Effect<string>, jurisdiction: Effect.Effect<string>) => WriteBucketClient;
//# sourceMappingURL=WriteBucketHttp.d.ts.map