import * as r2 from "@distilled.cloud/cloudflare/r2";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Redacted from "effect/Redacted";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
/** S3-compatible credentials with access to a migration bucket. */
export interface SuperSlurperCredentials {
    /** Access key ID. Changing credentials replaces the migration. */
    accessKeyId: Redacted.Redacted<string>;
    /** Secret access key. Changing credentials replaces the migration. */
    secretAccessKey: Redacted.Redacted<string>;
}
/** Object selection shared by all source vendors. */
export interface SuperSlurperSourceSelection {
    /** Name of the source bucket. Immutable. */
    bucket: string;
    /** Object keys to migrate. Omit to migrate all matching objects. Immutable. */
    keys?: string[];
    /** Restrict migration to this object key prefix. Immutable. */
    pathPrefix?: string;
}
/** AWS S3 or another HTTPS S3-compatible source. */
export interface SuperSlurperS3Source extends SuperSlurperSourceSelection {
    /** Select the S3 source API. */
    vendor: "s3";
    /** Source credentials with read access. Immutable. */
    secret: SuperSlurperCredentials;
    /** Custom S3-compatible HTTPS endpoint. Immutable. */
    endpoint?: string;
    /** Source bucket region. Immutable. */
    region?: string;
}
/** Google Cloud Storage source. */
export interface SuperSlurperGcsSource extends SuperSlurperSourceSelection {
    /** Select Google Cloud Storage. */
    vendor: "gcs";
    /** Service account credentials with source read access. Immutable. */
    secret: {
        /** Service account email. */
        clientEmail: Redacted.Redacted<string>;
        /** Service account private key in PEM format. */
        privateKey: Redacted.Redacted<string>;
    };
}
/** Cloudflare R2 source. */
export interface SuperSlurperR2Source extends SuperSlurperSourceSelection {
    /** Select Cloudflare R2. */
    vendor: "r2";
    /** S3-compatible R2 credentials with source read access. Immutable. */
    secret: SuperSlurperCredentials;
    /** Source jurisdiction. Immutable. @default "default" */
    jurisdiction?: "default" | "eu" | "us" | "fedramp";
}
/** Supported source bucket configurations. */
export type SuperSlurperSource = SuperSlurperS3Source | SuperSlurperGcsSource | SuperSlurperR2Source;
/** R2 destination for migrated objects. */
export interface SuperSlurperTarget {
    /** Name of the destination R2 bucket. Immutable. */
    bucket: string;
    /** The destination vendor must be R2. */
    vendor: "r2";
    /** S3-compatible R2 credentials with destination write access. Immutable. */
    secret: SuperSlurperCredentials;
    /** Destination jurisdiction. Immutable. @default "default" */
    jurisdiction?: "default" | "eu" | "us" | "fedramp";
}
export interface SuperSlurperJobProps {
    /** Source bucket and credentials. Any change replaces the job. */
    source: SuperSlurperSource;
    /** Destination R2 bucket and credentials. Any change replaces the job. */
    target: SuperSlurperTarget;
    /** Overwrite existing destination objects. Immutable. @default false */
    overwrite?: boolean;
    /**
     * Pause an active job, or resume it when false. Terminal jobs are never
     * restarted. A new job starts running before the pause request is applied,
     * so this is not a guarantee that no objects are transferred.
     * @default false
     */
    paused?: boolean;
}
export interface SuperSlurperJobAttributes {
    /** Cloudflare account that owns the migration. */
    accountId: string;
    /** Server-assigned migration ID. Stable until replacement. */
    jobId: string;
    /** Last observed job status; not a completion guarantee. */
    status: r2.GetSuperSlurperJobResponse["status"];
    /** Creation timestamp reported by Cloudflare. */
    createdAt: string | undefined;
    /** Completion timestamp, if the job has finished. */
    finishedAt: string | undefined;
}
export type SuperSlurperJob = Resource<"Cloudflare.R2.SuperSlurperJob", SuperSlurperJobProps, SuperSlurperJobAttributes, never, Providers>;
/**
 * Starts a bulk migration from S3, GCS, or R2 into an R2 bucket.
 *
 * Deployment returns the job identity without waiting for the migration.
 * Completed and aborted jobs remain resources: redeploying does not run them
 * again. Changing source, target, credentials, or overwrite replaces the job.
 * Destroy only cancels this resource's active job; it never deletes copied
 * objects or Cloudflare's job history. Transfers already in flight may finish.
 *
 * Cloudflare exposes no job name, ownership tags, or idempotency key. The
 * persisted job ID is the only ownership record; similar jobs are never
 * adopted. If a create response or the subsequent state write is lost, the
 * job cannot be recovered automatically and retrying may create a second job.
 * Inspect the account's migration history and cancel that orphan explicitly.
 * Account-wide adoption and cancellation are intentionally not supported.
 * If reading a cached ID fails with Cloudflare's ambiguous server error,
 * paginated job history is checked for that exact ID before declaring it absent.
 *
 * ### Migrating from S3
 * **Example:** Copy an S3 prefix into R2
 * ```typescript
 * const target = yield* Cloudflare.R2.Bucket("Archive");
 * const job = yield* Cloudflare.R2.SuperSlurperJob("Migration", {
 *   source: {
 *     vendor: "s3",
 *     bucket: "legacy-archive",
 *     region: "us-east-1",
 *     pathPrefix: "photos/",
 *     secret: {
 *       accessKeyId: yield* Config.Redacted("AWS_ACCESS_KEY_ID"),
 *       secretAccessKey: yield* Config.Redacted("AWS_SECRET_ACCESS_KEY"),
 *     },
 *   },
 *   target: {
 *     vendor: "r2",
 *     bucket: target.bucketName,
 *     secret: {
 *       accessKeyId: yield* Config.Redacted("R2_ACCESS_KEY_ID"),
 *       secretAccessKey: yield* Config.Redacted("R2_SECRET_ACCESS_KEY"),
 *     },
 *   },
 * });
 * ```
 *
 * ### Migrating from GCS or R2
 * **Example:** Google Cloud Storage source
 * ```typescript
 * const source: Cloudflare.R2.SuperSlurperSource = {
 *   vendor: "gcs",
 *   bucket: "legacy-media",
 *   secret: {
 *     clientEmail: yield* Config.Redacted("GCS_CLIENT_EMAIL"),
 *     privateKey: yield* Config.Redacted("GCS_PRIVATE_KEY"),
 *   },
 * };
 * ```
 *
 * **Example:** R2 source and paused desired state
 * ```typescript
 * yield* Cloudflare.R2.SuperSlurperJob("Migration", {
 *   source: {
 *     vendor: "r2",
 *     bucket: "old-media",
 *     secret: {
 *       accessKeyId: yield* Config.Redacted("SOURCE_R2_ACCESS_KEY_ID"),
 *       secretAccessKey: yield* Config.Redacted("SOURCE_R2_SECRET_ACCESS_KEY"),
 *     },
 *   },
 *   target: {
 *     vendor: "r2",
 *     bucket: "new-media",
 *     secret: {
 *       accessKeyId: yield* Config.Redacted("TARGET_R2_ACCESS_KEY_ID"),
 *       secretAccessKey: yield* Config.Redacted("TARGET_R2_SECRET_ACCESS_KEY"),
 *     },
 *   },
 *   paused: true,
 * });
 * ```
 *
 * ### Referencing a Migration
 * **Example:** Read a persisted job identity without creating a new job
 * ```typescript
 * const job = yield* Cloudflare.R2.SuperSlurperJob.ref("Migration");
 * return { accountId: job.accountId, jobId: job.jobId };
 * ```
 *
 * @resource
 * @product R2
 * @category Storage & Databases
 */
export declare const SuperSlurperJob: import("alchemy/Resource").ResourceClass<SuperSlurperJob>;
export declare const SuperSlurperJobProvider: () => import("effect/Layer").Layer<Provider.Provider<SuperSlurperJob>, never, CloudflareEnvironment | r2.CloudflareOpContext>;
//# sourceMappingURL=SuperSlurperJob.d.ts.map