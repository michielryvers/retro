import * as r2 from "@distilled.cloud/cloudflare/r2";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type * as Cloudflare from "../Providers.ts";
import * as Zone from "../Zone/index.ts";
export declare const isBucket: (value: any) => value is Bucket;
export type BucketName = string;
export type BucketCustomDomainZone = Zone.Reference;
export type BucketCustomDomain = {
    /**
     * Custom domain name to attach to the bucket.
     */
    name: string;
    /**
     * Zone that contains the custom domain. If omitted, the zone is inferred
     * from `domain`. Pass a zone ID string, a hostname in the zone, or any object
     * with a `zoneId` attribute such as `Cloudflare.Zone.Zone`.
     */
    zone?: BucketCustomDomainZone;
    /**
     * Whether public bucket access is enabled at this custom domain.
     * @default true
     */
    enabled?: boolean;
    /**
     * Allowlist of TLS ciphers in BoringSSL format.
     */
    ciphers?: string[];
    /**
     * Minimum TLS version accepted by the custom domain.
     * @default "1.0"
     */
    minTLS?: "1.0" | "1.1" | "1.2" | "1.3";
};
export type BucketLifecycleCondition = {
    type: "Age";
    /**
     * Maximum age of an object, in seconds, before the rule's action applies.
     */
    maxAge: number;
} | {
    type: "Date";
    /**
     * Absolute date (ISO 8601) at which the rule's action applies.
     */
    date: string;
};
export type BucketLifecycleRule = {
    /**
     * Unique identifier for the rule within the bucket.
     */
    id: string;
    /**
     * Whether the rule is enabled.
     * @default true
     */
    enabled?: boolean;
    /**
     * Object key prefix the rule applies to. Use `""` (or omit) to match all
     * objects in the bucket.
     * @default ""
     */
    prefix?: string;
    /**
     * Abort incomplete multipart uploads after the configured age.
     */
    abortMultipartUploadsTransition?: {
        condition?: {
            type: "Age";
            maxAge: number;
        };
    };
    /**
     * Delete matching objects after the configured age or on a specific date.
     */
    deleteObjectsTransition?: {
        condition?: BucketLifecycleCondition;
    };
    /**
     * Transition matching objects to a different storage class. Cloudflare R2
     * only supports transitioning to `InfrequentAccess` today.
     */
    storageClassTransitions?: {
        condition: BucketLifecycleCondition;
        storageClass: "InfrequentAccess";
    }[];
};
export type BucketCorsRule = {
    /**
     * Optional label for this rule, shown in the Cloudflare dashboard. Not
     * used to correlate rules across updates — the CORS configuration is
     * always replaced as a whole.
     */
    id?: string;
    /**
     * HTTP methods browsers are allowed to use in cross-origin requests.
     */
    allowedMethods: ("GET" | "PUT" | "POST" | "DELETE" | "HEAD")[];
    /**
     * Origins allowed to make cross-origin requests, e.g.
     * `"https://example.com"`. Use `"*"` to allow any origin.
     */
    allowedOrigins: string[];
    /**
     * Request headers browsers are allowed to send, e.g. `"range"` for
     * range reads. If omitted, only simple headers are allowed.
     */
    allowedHeaders?: string[];
    /**
     * Response headers the browser is allowed to expose to the requesting
     * JavaScript, e.g. `"etag"` or `"content-range"`.
     */
    exposeHeaders?: string[];
    /**
     * How long (in seconds) browsers may cache CORS preflight responses.
     * Browsers may cap this at 2 hours or less, even if 86400 is specified.
     */
    maxAgeSeconds?: number;
};
export type BucketLockCondition = {
    /**
     * Lock matching objects permanently. They can never be deleted or
     * overwritten, so the bucket can never be emptied or deleted.
     */
    type: "Indefinite";
} | {
    type: "Age";
    /**
     * Seconds after upload during which matching objects stay locked.
     */
    maxAgeSeconds: number;
} | {
    type: "Date";
    /**
     * Absolute date (ISO 8601) until which matching objects stay locked.
     */
    date: string;
};
export type BucketLockRule = {
    /**
     * Unique identifier for the rule within the bucket.
     */
    id: string;
    /**
     * Whether the rule is in effect.
     */
    enabled: boolean;
    /**
     * Object key prefix the rule applies to. Use `""` (or omit) to lock every
     * object in the bucket.
     * @default ""
     */
    prefix?: string;
    /**
     * How long matching objects stay locked.
     */
    condition: BucketLockCondition;
};
export type BucketProps = {
    /**
     * Name of the bucket. If omitted, a unique name will be generated.
     * @default ${app}-${stage}-${id}
     */
    name?: string;
    /**
     * Storage class for newly uploaded objects.
     * @default "Standard"
     */
    storageClass?: Bucket.StorageClass;
    /**
     * Jurisdiction where objects in this bucket are guaranteed to be stored.
     * @default "default"
     */
    jurisdiction?: Bucket.Jurisdiction;
    /**
     * Location hint for the bucket.
     */
    locationHint?: Bucket.Location;
    /**
     * Custom domains to attach to the bucket. Pass an empty array (or omit)
     * to remove all custom domains.
     */
    domains?: BucketCustomDomain[];
    /**
     * Whether the bucket is publicly readable at Cloudflare's managed
     * `r2.dev` domain. Cloudflare's default is off; omit or pass `false`
     * to disable it.
     *
     * Once enabled, the hostname is reported on `publicDomain`. This
     * endpoint is rate-limited and intended for non-production use — use
     * `domains` for production public access.
     *
     * @default false
     */
    publicAccess?: boolean;
    /**
     * Object lifecycle rules applied to the bucket. Pass an empty array (or
     * omit) to clear all lifecycle rules. See the Cloudflare R2 docs for
     * supported transitions.
     */
    lifecycleRules?: BucketLifecycleRule[];
    /**
     * CORS rules applied to the bucket, controlling which cross-origin
     * browser requests are allowed against the bucket's public or S3 API
     * endpoints. Pass an empty array (or omit) to remove the CORS
     * configuration.
     */
    cors?: BucketCorsRule[];
    /**
     * Object lock rules applied to the bucket. While a rule's condition
     * holds, R2 refuses to delete or overwrite any object whose key matches
     * the rule's prefix, whoever signs the request (S3 API credentials
     * included). An `Indefinite` rule never lapses: matching objects are
     * permanent and the bucket can never be emptied, so `forceDestroy`
     * cannot delete it.
     *
     * A bucket that never declared `locks` keeps whatever rules it has: they
     * are left unmanaged. Pass an empty array, or drop `locks` after
     * declaring it, to remove every rule.
     */
    locks?: BucketLockRule[];
    /**
     * Whether R2 Local Uploads is enabled. Uploads from clients far from the
     * bucket's region are written near the client first and replicated to the
     * bucket asynchronously. Toggling it updates the bucket in place.
     *
     * Not available for jurisdiction-restricted buckets: enabling it on a
     * bucket whose `jurisdiction` is not `"default"` fails the deploy.
     *
     * A bucket that never declared `localUploads` keeps whatever setting it
     * has. Drop `localUploads` after declaring it to disable it.
     */
    localUploads?: boolean;
    /**
     * Allow alchemy to delete every object in the bucket when the bucket
     * itself is deleted.
     *
     * R2 refuses to delete a bucket that still has objects in it — that
     * refusal is the last line of defense for your data, so alchemy does not
     * bypass it by default: destroying a non-empty bucket fails with
     * `BucketNotEmpty` and both the bucket and its objects survive. Set this
     * to `true` for buckets whose contents are disposable (caches, previews,
     * test fixtures).
     *
     * `alchemy unsafe nuke` empties buckets regardless, since it is an
     * explicitly operator-confirmed account teardown.
     *
     * @default false
     */
    forceDestroy?: boolean;
};
export type Bucket = Resource<"Cloudflare.R2.Bucket", BucketProps, {
    bucketName: BucketName;
    storageClass: Bucket.StorageClass;
    jurisdiction: Bucket.Jurisdiction;
    location: Bucket.Location | undefined;
    accountId: string;
    domains: Bucket.CustomDomain[];
    lifecycleRules: Bucket.LifecycleRule[];
    cors: Bucket.CorsRule[];
    /**
     * Lock rules on the bucket. `undefined` while `locks` is unmanaged
     * (omitted from the props).
     */
    locks: Bucket.LockRule[] | undefined;
    /**
     * Whether Local Uploads is enabled. `undefined` while `localUploads` is
     * unmanaged (omitted from the props).
     */
    localUploads: boolean | undefined;
    /**
     * Hostname of the bucket's Cloudflare-managed `r2.dev` domain.
     * Set only while `publicAccess` is enabled; `undefined` when
     * disabled (the domain still exists but serves 401).
     */
    publicDomain: string | undefined;
}, never, Cloudflare.Providers>;
/**
 * A Cloudflare R2 object storage bucket with S3-compatible API.
 *
 * R2 provides zero-egress-fee object storage. Create a bucket as a resource,
 * then bind it to a Worker to read and write objects at runtime.
 * ### Creating a Bucket
 * **Example:** Basic R2 bucket
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket");
 * ```
 *
 * **Example:** Bucket with location hint
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   locationHint: "wnam",
 * });
 * ```
 *
 * ### Binding to a Worker
 * **Example:** Reading and writing objects
 * ```typescript
 * const bucket = yield* Cloudflare.R2.ReadWriteBucket(MyBucket);
 *
 * // Write an object
 * yield* bucket.put("hello.txt", "Hello, World!");
 *
 * // Read an object
 * const object = yield* bucket.get("hello.txt");
 * if (object) {
 *   const text = yield* object.text();
 * }
 * ```
 *
 * **Example:** Streaming upload with content length
 * ```typescript
 * const bucket = yield* Cloudflare.R2.ReadWriteBucket(MyBucket);
 *
 * yield* bucket.put("upload.bin", request.stream, {
 *   contentLength: Number(request.headers["content-length"] ?? 0),
 * });
 * ```
 *
 * ### Custom Domains
 *
 * Attach one or more custom domains to serve bucket objects from a hostname
 * you control. The domain's zone must already exist in your Cloudflare
 * account; the zone is inferred from the hostname when omitted, or you can
 * pass a `Cloudflare.Zone.Zone` resource, a zone ID, or any hostname inside the
 * zone via the `zone` field.
 *
 * **Example:** Single custom domain
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   domains: [{ name: "assets.example.com" }],
 * });
 * ```
 *
 * **Example:** Multiple custom domains
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   domains: [
 *     { name: "assets.example.com" },
 *     { name: "static.example.com" },
 *   ],
 * });
 * ```
 *
 * **Example:** Disable a custom domain without removing it
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   domains: [{ name: "assets.example.com", enabled: false }],
 * });
 * ```
 *
 * **Example:** Custom domain with explicit zone and TLS settings
 * ```typescript
 * const zone = yield* Cloudflare.Zone.Zone("ExampleZone", {
 *   name: "example.com",
 * });
 *
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   domains: [
 *     {
 *       name: "assets.example.com",
 *       zone,
 *       minTLS: "1.2",
 *     },
 *   ],
 * });
 * ```
 *
 * ### Public Development URL
 *
 * Enable Cloudflare's managed `r2.dev` domain so objects are publicly
 * readable without attaching a custom domain. The hostname is reported
 * on `publicDomain`. This endpoint is rate-limited and intended for
 * non-production use — use `domains` for production public access.
 *
 * **Example:** Enable public access at r2.dev
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   publicAccess: true,
 * });
 * // objects are at https://${bucket.publicDomain}/<key>
 * ```
 *
 * **Example:** Disable public access
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   publicAccess: false,
 * });
 * ```
 *
 * ### Object Lifecycle Rules
 *
 * Configure lifecycle rules to automatically delete objects, abort
 * incomplete multipart uploads, or transition objects to InfrequentAccess
 * storage. Pass an empty array (or omit) to clear all rules. See the
 * [Cloudflare R2 docs](https://developers.cloudflare.com/r2/buckets/object-lifecycles/)
 * for details and limits (max 1000 rules per bucket).
 *
 * **Example:** Delete objects 30 days after upload
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   lifecycleRules: [
 *     {
 *       id: "expire-old-objects",
 *       deleteObjectsTransition: {
 *         condition: { type: "Age", maxAge: 60 * 60 * 24 * 30 },
 *       },
 *     },
 *   ],
 * });
 * ```
 *
 * **Example:** Transition to InfrequentAccess after 60 days, delete after 365
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   lifecycleRules: [
 *     {
 *       id: "archive-then-delete",
 *       prefix: "logs/",
 *       storageClassTransitions: [
 *         {
 *           condition: { type: "Age", maxAge: 60 * 60 * 24 * 60 },
 *           storageClass: "InfrequentAccess",
 *         },
 *       ],
 *       deleteObjectsTransition: {
 *         condition: { type: "Age", maxAge: 60 * 60 * 24 * 365 },
 *       },
 *     },
 *   ],
 * });
 * ```
 *
 * **Example:** Abort incomplete multipart uploads after 7 days
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   lifecycleRules: [
 *     {
 *       id: "abort-stale-uploads",
 *       abortMultipartUploadsTransition: {
 *         condition: { type: "Age", maxAge: 60 * 60 * 24 * 7 },
 *       },
 *     },
 *   ],
 * });
 * ```
 *
 * ### CORS
 *
 * Configure CORS rules so browsers can make cross-origin requests against
 * the bucket's public (custom domain / r2.dev) or S3 API endpoints. Pass an
 * empty array (or omit) to remove the CORS configuration. See the
 * [Cloudflare R2 docs](https://developers.cloudflare.com/r2/buckets/cors/)
 * for details.
 *
 * **Example:** Allow cross-origin reads from any origin
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   cors: [
 *     {
 *       allowedMethods: ["GET", "HEAD"],
 *       allowedOrigins: ["*"],
 *     },
 *   ],
 * });
 * ```
 *
 * **Example:** Browser range reads (e.g. PMTiles map tiles)
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   domains: [{ name: "tiles.example.com" }],
 *   cors: [
 *     {
 *       allowedMethods: ["GET", "HEAD"],
 *       allowedOrigins: ["https://map.example.com"],
 *       allowedHeaders: ["range", "if-match"],
 *       exposeHeaders: ["etag", "content-range"],
 *       maxAgeSeconds: 3600,
 *     },
 *   ],
 * });
 * ```
 *
 * **Example:** Allow uploads from a web app
 * ```typescript
 * const bucket = yield* Cloudflare.R2.Bucket("MyBucket", {
 *   cors: [
 *     {
 *       allowedMethods: ["GET", "PUT", "POST"],
 *       allowedOrigins: ["https://app.example.com"],
 *       allowedHeaders: ["content-type"],
 *       exposeHeaders: ["etag"],
 *     },
 *   ],
 * });
 * ```
 *
 * ### Bucket Locks
 *
 * Lock rules make objects write-once: while a rule's condition holds, R2
 * refuses to delete or overwrite any object under the rule's prefix,
 * whoever signs the request. `Indefinite` locks never lapse, so a bucket
 * with indefinitely locked objects can never be emptied or deleted. A
 * bucket that never declares `locks` keeps its rules unmanaged; pass an
 * empty array (or drop `locks` after declaring it) to remove them. See the
 * [Cloudflare R2 docs](https://developers.cloudflare.com/r2/buckets/bucket-locks/)
 * for details.
 *
 * **Example:** Write-once landing zone
 * ```typescript
 * const lake = yield* Cloudflare.R2.Bucket("Lake", {
 *   locks: [
 *     {
 *       id: "raw-write-once",
 *       enabled: true,
 *       prefix: "raw/",
 *       condition: { type: "Indefinite" },
 *     },
 *   ],
 * });
 * ```
 *
 * **Example:** Retain logs for 90 days
 * ```typescript
 * const audit = yield* Cloudflare.R2.Bucket("Audit", {
 *   locks: [
 *     {
 *       id: "retain-logs",
 *       enabled: true,
 *       prefix: "logs/",
 *       condition: { type: "Age", maxAgeSeconds: 60 * 60 * 24 * 90 },
 *     },
 *   ],
 * });
 * ```
 *
 * ### Local Uploads
 *
 * Local Uploads writes uploaded objects near the client and replicates them
 * to the bucket's region asynchronously, cutting upload latency for clients
 * far from the bucket. It is not available for jurisdiction-restricted
 * buckets. See the
 * [Cloudflare R2 docs](https://developers.cloudflare.com/r2/buckets/local-uploads/)
 * for details.
 *
 * **Example:** Enable Local Uploads
 * ```typescript
 * const uploads = yield* Cloudflare.R2.Bucket("Uploads", {
 *   localUploads: true,
 * });
 * ```
 *
 * ### Deleting a Bucket
 *
 * R2 refuses to delete a bucket that still has objects in it, and alchemy
 * does not bypass that refusal: destroying a non-empty bucket fails with
 * `BucketNotEmpty` and both the bucket and its objects survive. Opt into
 * emptying the bucket first with `forceDestroy` for buckets whose contents
 * are disposable.
 *
 * **Example:** Empty the bucket on destroy
 * ```typescript
 * const cache = yield* Cloudflare.R2.Bucket("Cache", {
 *   forceDestroy: true,
 * });
 * ```
 *
 * **Example:** Keep the bucket even when the stack goes away
 * ```typescript
 * import * as RemovalPolicy from "alchemy/RemovalPolicy";
 *
 * const uploads = yield* Cloudflare.R2.Bucket("Uploads").pipe(
 *   RemovalPolicy.retain(),
 * );
 * ```
 *
 * @resource
 * @product R2
 * @category Storage & Databases
 */
export declare const Bucket: import("alchemy/Resource").ResourceClass<Bucket>;
export declare namespace Bucket {
    type StorageClass = "Standard" | "InfrequentAccess";
    type Jurisdiction = "default" | "eu" | "fedramp";
    type Location = "apac" | "eeur" | "enam" | "weur" | "wnam" | "oc";
    type LifecycleRule = {
        id: string;
        enabled: boolean;
        prefix: string;
        abortMultipartUploadsTransition: {
            condition: {
                type: "Age";
                maxAge: number;
            } | undefined;
        } | undefined;
        deleteObjectsTransition: {
            condition: BucketLifecycleCondition | undefined;
        } | undefined;
        storageClassTransitions: {
            condition: BucketLifecycleCondition;
            storageClass: "InfrequentAccess";
        }[] | undefined;
    };
    type CorsRule = {
        id: string | undefined;
        allowedMethods: ("GET" | "PUT" | "POST" | "DELETE" | "HEAD")[];
        allowedOrigins: string[];
        allowedHeaders: string[] | undefined;
        exposeHeaders: string[] | undefined;
        maxAgeSeconds: number | undefined;
    };
    type LockRule = {
        id: string;
        enabled: boolean;
        prefix: string;
        condition: BucketLockCondition;
    };
    type CustomDomain = {
        domain: string;
        zoneId: string | undefined;
        enabled: boolean;
        ciphers: string[] | undefined;
        minTLS: "1.0" | "1.1" | "1.2" | "1.3" | undefined;
        status: {
            ownership: "pending" | "active" | "deactivated" | "blocked" | "error" | "unknown";
            ssl: "initializing" | "pending" | "active" | "deactivated" | "error" | "unknown";
        } | undefined;
    };
}
export declare const ProviderLive: () => import("effect/Layer").Layer<Provider.Provider<Bucket>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | r2.CloudflareOpContext>;
/**
 * Local (dev) provider — the bucket is purely virtual: a `dev:`-prefixed
 * bucket name keyed into the local workerd R2 simulator (data under
 * `.alchemy/local/r2`). `toRuntimeBinding` lowers an `r2_bucket` binding
 * whose bucket name is `dev:`-prefixed onto the local R2 service. R2 has no
 * opaque id — the name IS the identity — so the `dev:` marker rides on the
 * name (a `:` can never appear in a real R2 bucket name).
 *
 * Custom domains, lifecycle rules, CORS, lock rules, and the managed r2.dev
 * domain are deploy-side concerns with no local behavior; the local
 * attributes report them empty.
 */
export declare const ProviderLocal: () => import("effect/Layer").Layer<Provider.Provider<Bucket>, never, never>;
export declare const BucketProvider: () => import("effect/Layer").Layer<Provider.Provider<Bucket>, never, import("alchemy/AlchemyContext").AlchemyContext | CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | r2.CloudflareOpContext>;
declare const LocalUploadsUnsupported_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "LocalUploadsUnsupported";
} & Readonly<A>;
/**
 * Local Uploads was requested on a jurisdiction-restricted bucket, which
 * Cloudflare does not support.
 */
export declare class LocalUploadsUnsupported extends LocalUploadsUnsupported_base<{
    bucketName: string;
    jurisdiction: Bucket.Jurisdiction;
    message: string;
}> {
}
export {};
//# sourceMappingURL=Bucket.d.ts.map