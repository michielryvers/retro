import * as Effect from "effect/Effect";
import type { Policy } from "../ApiToken/Common.ts";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Worker } from "../Workers/Worker.ts";
import type { Bucket } from "./Bucket.ts";
import type { S3Credentials, S3CredentialsAccess } from "./S3Credentials.ts";
/**
 * Deploy-time half of `Cloudflare.R2.S3Credentials`, shared by async Worker
 * `env` declarations and the Effect-native bindings (`S3Credentials`,
 * `PresignGetObjectToken`, `PresignPutObjectToken`).
 *
 * Binds `bindingName` on the host Worker to the JSON-encoded
 * {@link S3CredentialsValue} for `bucket`:
 *
 * - **live** — mints (or extends) the Worker's {@link AccountApiToken} with
 *   a policy scoped to `bucket` (see {@link s3CredentialsPolicy}) and
 *   injects a `secret_text` binding. R2 derives S3 credentials from any API
 *   token: the access key id is the token id and the secret access key is
 *   the SHA-256 of the token value.
 * - **local** (`alchemy dev`, `dev:` bucket) — injects the dev-only
 *   `r2_s3_credentials` binding. The local runtime lowers it to the Worker's
 *   local S3 endpoint and fixed local credentials, and serves the bucket on
 *   that endpoint. No token or cloud call is involved.
 *
 * NOT exported from `index.ts`.
 */
export declare const bindS3Credentials: (host: Worker, bindingName: string, bucket: Bucket, access: S3CredentialsAccess) => Effect.Effect<void, never, CloudflareEnvironment | import("../Providers.ts").Providers>;
/**
 * A bucket, or its declaration (`Cloudflare.R2.Bucket("Uploads")`), which
 * is resolved when the credentials are bound.
 */
export type BucketInput = Bucket | Effect.Effect<Bucket, never, any>;
/** Resolve a {@link BucketInput} to the bucket resource. */
export declare const resolveBucket: (bucket: BucketInput) => Effect.Effect<Bucket>;
/**
 * The token policy behind deployed `S3Credentials`: `access` to the objects of
 * one bucket. Bucket-scoped groups on the bucket resource, because the
 * account-level R2 groups would reach every bucket in the account.
 *
 * @see https://developers.cloudflare.com/r2/api/tokens/#bucket
 */
export declare const s3CredentialsPolicy: (accountId: string, bucketName: string, jurisdiction: Bucket.Jurisdiction, access: S3CredentialsAccess) => Policy;
/**
 * Whether an env value is a `Cloudflare.R2.S3Credentials` declaration (keyed
 * on the static `~alchemy/Kind` marker — the value is also an Effect, so env
 * resolution must check this before yielding Effects). Lives here, free of
 * value imports from `Worker.ts`, so async env resolution can use it without
 * a module cycle.
 */
export declare const isS3Credentials: (value: unknown) => value is S3Credentials;
//# sourceMappingURL=S3CredentialsBinding.d.ts.map