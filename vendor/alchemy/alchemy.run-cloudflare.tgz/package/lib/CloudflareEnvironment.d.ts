import * as Config from "effect/Config";
import * as Layer from "effect/Layer";
import { CloudflareEnvironment } from "./CloudflareEnvironmentService.ts";
export { CloudflareEnvironment } from "./CloudflareEnvironmentService.ts";
export declare const fromEnv: () => Layer.Layer<CloudflareEnvironment, Config.ConfigError, never>;
export declare const fromProfile: () => Layer.Layer<CloudflareEnvironment, never, import("alchemy/Auth/AuthProvider").AuthProviders | import("alchemy/Auth/Profile").ProfileStore>;
//# sourceMappingURL=CloudflareEnvironment.d.ts.map