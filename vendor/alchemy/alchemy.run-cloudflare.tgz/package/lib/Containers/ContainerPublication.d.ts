import type { DockerImagePublicationError } from "@alchemy.run/docker/RegistryError";
import * as Effect from "effect/Effect";
export declare const retryContainerPublication: <A, R>(publication: Effect.Effect<A, DockerImagePublicationError, R>) => Effect.Effect<A, DockerImagePublicationError, R>;
//# sourceMappingURL=ContainerPublication.d.ts.map