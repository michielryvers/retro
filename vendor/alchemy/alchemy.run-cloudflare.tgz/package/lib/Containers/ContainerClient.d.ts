import type * as cf from "@cloudflare/workers-types";
import type { RuntimeContext } from "alchemy/RuntimeContext";
import * as Effect from "effect/Effect";
import type { HttpClientError } from "effect/http/HttpClientError";
import type * as HttpClientRequest from "effect/http/HttpClientRequest";
import type * as HttpClientResponse from "effect/http/HttpClientResponse";
import type { HttpServerError } from "effect/http/HttpServerError";
import type * as HttpServerRequest from "effect/http/HttpServerRequest";
import type * as HttpServerResponse from "effect/http/HttpServerResponse";
import type * as Scope from "effect/Scope";
import * as Sink from "effect/Sink";
import type * as Socket from "effect/socket/Socket";
import * as Stream from "effect/Stream";
import { type Fetcher, type SocketAddress, type SocketOptions } from "../Fetcher.ts";
import { ContainerCrashedError, ContainerError, ContainerNotRunningError, ContainerRateLimitedError, NoContainerInstanceError, type ContainerStartupOptions } from "./Container.ts";
export type ContainerExecOptions = cf.ContainerExecOptions;
export type ContainerExecOutput = cf.ExecOutput;
export type ContainerInfo = cf.ContainerInfo;
export type ContainerSnapshot = cf.ContainerSnapshot;
export type ContainerSnapshotOptions = cf.ContainerSnapshotOptions;
/** Errors a container `start` can fail with. */
export type ContainerStartError = ContainerError | NoContainerInstanceError | ContainerRateLimitedError;
/** Errors a container port can fail with before the request reaches it. */
export type ContainerPortError = ContainerError | ContainerNotRunningError | ContainerCrashedError;
/**
 * A port inside the container. Each request waits until the port accepts
 * connections, then is sent exactly once. A port never starts the container:
 * a stopped container fails with {@link ContainerNotRunningError}.
 */
export interface ContainerPort {
    fetch(request: HttpClientRequest.HttpClientRequest): Effect.Effect<HttpClientResponse.HttpClientResponse, ContainerPortError | HttpClientError, RuntimeContext>;
    fetch(request: HttpServerRequest.HttpServerRequest): Effect.Effect<HttpServerResponse.HttpServerResponse, ContainerPortError | HttpServerError, RuntimeContext>;
    connect(address: SocketAddress | string, options?: SocketOptions): Socket.Socket;
}
/** A native process, owned by the scope that called {@link ContainerClient.exec}. */
export interface ContainerProcess {
    /** Process ID inside the container. */
    readonly pid: number;
    /** Whether the process has a pseudo-terminal. */
    readonly isPty: boolean;
    /** Piped standard input. Completing the sink closes stdin. */
    readonly stdin: Sink.Sink<void, Uint8Array, never, ContainerError, RuntimeContext> | undefined;
    /** Piped standard output. Consume this or call output(), not both. */
    readonly stdout: Stream.Stream<Uint8Array, ContainerError, RuntimeContext> | undefined;
    /** Standard error, absent when ignored or combined with stdout. */
    readonly stderr: Stream.Stream<Uint8Array, ContainerError, RuntimeContext> | undefined;
    /** Wait for completion. Nonzero exit codes are returned normally. */
    readonly exitCode: Effect.Effect<number, ContainerError, RuntimeContext>;
    /** Collect output once. For large output, consume stdout and stderr concurrently. */
    output(): Effect.Effect<ContainerExecOutput, ContainerError, RuntimeContext>;
    /** Signal this process. Defaults to SIGTERM; child processes are not signaled. */
    kill(signal?: number): Effect.Effect<void, ContainerError, RuntimeContext>;
    /** Resize the process's pseudo-terminal. */
    resize(cols: number, rows: number): Effect.Effect<void, ContainerError, RuntimeContext>;
}
/**
 * The container bound to the current Durable Object — what `yield* Sandbox`
 * returns. Binding never starts the container: call {@link start} before
 * using it. `start` is idempotent and coordinated across every handle in the
 * Durable Object, so calling it at the top of each operation is cheap.
 *
 * A Durable Object has one container instance. When several Durable
 * Object-managed Containers are bound to it, each handle starts its own image,
 * and every handle controls that same instance: start one image at a time.
 */
export interface ContainerClient {
    /**
     * This Container's prepared image reference, the key `start()` selects by
     * default. Fails with {@link ContainerError} when the Container publishes no
     * image to this Durable Object (fleet Containers and Containers without an
     * image source).
     */
    readonly image: Effect.Effect<string, ContainerError, RuntimeContext>;
    /** Whether the container process is running; this does not imply port readiness. */
    readonly running: Effect.Effect<boolean, ContainerError, RuntimeContext>;
    /**
     * Start the container unless it is already running. Concurrent calls start
     * it once. Returns before ports are ready; {@link getTcpPort} waits for them.
     * Options apply only when this call actually starts the container.
     *
     * A Durable Object-managed Container starts its own {@link image} unless
     * `options` names an `image` or a `containerSnapshot`. A no-op while any
     * image is running: `destroy()` first to switch images.
     */
    start(options?: ContainerStartupOptions): Effect.Effect<void, ContainerStartError, RuntimeContext>;
    /** Stop the container immediately. */
    destroy(error?: unknown): Effect.Effect<void, ContainerError, RuntimeContext>;
    /** Signal the container's main process. */
    signal(signo: number): Effect.Effect<void, ContainerError, RuntimeContext>;
    /**
     * Wait for the container to exit, preserving failures in the Effect error channel.
     * Cloudflare often reports a failed start here rather than from `start`, so a start
     * it had no instance for fails with `NoContainerInstanceError` and a rate-limited one
     * with `ContainerRateLimitedError`, as `start` does.
     */
    monitor(): Effect.Effect<void, ContainerStartError, RuntimeContext>;
    /** Running image and labels, or null when stopped. */
    inspect(): Effect.Effect<ContainerInfo | null, ContainerError, RuntimeContext>;
    /** A port inside the container whose requests wait until it accepts connections. */
    getTcpPort(port: number): Effect.Effect<ContainerPort, never, RuntimeContext>;
    /**
     * Execute an argument vector without a shell. The container must already
     * be started. Scope closure kills this process with SIGKILL; descendants
     * are not signaled. Supply an explicit shell when shell syntax is needed.
     */
    exec(cmd: string[], options?: ContainerExecOptions): Effect.Effect<ContainerProcess, ContainerError, RuntimeContext | Scope.Scope>;
    /**
     * Save the writable root filesystem. Memory and running processes are not
     * captured. Restore by passing the handle to start({ containerSnapshot }).
     */
    snapshotContainer(options?: ContainerSnapshotOptions): Effect.Effect<ContainerSnapshot, ContainerError, RuntimeContext>;
    /** Set the idle timeout for this Durable Object instance, in milliseconds. */
    setInactivityTimeout(durationMs: number | bigint): Effect.Effect<void, ContainerError, RuntimeContext>;
    /** Intercept matching outbound HTTP requests. Re-register after each start. */
    interceptOutboundHttp(addr: string, binding: Fetcher): Effect.Effect<void, ContainerError, RuntimeContext>;
    /** Intercept all outbound HTTP requests. Re-register after each start. */
    interceptAllOutboundHttp(binding: Fetcher): Effect.Effect<void, ContainerError, RuntimeContext>;
    /** Intercept matching outbound HTTPS requests. Re-register after each start. */
    interceptOutboundHttps(addr: string, binding: Fetcher): Effect.Effect<void, ContainerError, RuntimeContext>;
}
/**
 * Names the container handle reserves. A container's RPC shape cannot
 * declare them: the handle's own method would shadow the RPC call.
 */
export type ReservedContainerKey = keyof ContainerClient | "~alchemy/Id";
/**
 * @internal Adapt `ctx.container` to the Effect client. The container is
 * looked up on every call, never at construction: the client is also built
 * while planning a Worker, where no Durable Object state exists.
 */
export declare const fromContainer: (getContainer: () => cf.Container | undefined, 
/** The key of this Container's image in `ctx.container.images`. */
imageKey?: string) => ContainerClient;
/**
 * @internal What `yield* Container` runs inside a Durable Object: register the
 * container's bindings, then return its handle. Methods declared on the
 * container's RPC shape are sent to its port-3000 server; the handle's own
 * methods take precedence.
 */
export declare const makeContainerHandle: (id: string, binding: Effect.Effect<unknown, never, any>) => Effect.Effect<ContainerClient, never, any>;
//# sourceMappingURL=ContainerClient.d.ts.map