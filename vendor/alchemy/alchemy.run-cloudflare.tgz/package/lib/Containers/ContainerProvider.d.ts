import { Docker } from "@alchemy.run/docker/Docker";
import * as Containers from "@distilled.cloud/cloudflare/containers";
import { AlchemyContext } from "alchemy/AlchemyContext";
import * as Provider from "alchemy/Provider";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { ContainerApplication } from "./ContainerApplication.ts";
export declare const LiveContainerProvider: () => import("effect/Layer").Layer<Provider.Provider<ContainerApplication<unknown>>, never, AlchemyContext | CloudflareEnvironment | Docker | FileSystem.FileSystem | Path.Path | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | Containers.CloudflareOpContext>;
export declare const retryForContainerApplicationReadiness: <A, E, R>(operation: string, applicationId: string, effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
//# sourceMappingURL=ContainerProvider.d.ts.map