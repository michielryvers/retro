import { Platform } from "alchemy/Platform";
import type { ProcessContext } from "alchemy/Runtime/Process";
import * as Effect from "effect/Effect";
import { DurableObject } from "../Workers/DurableObject.ts";
import { Worker } from "../Workers/Worker.ts";
import { type Container } from "./Container.ts";
import type { ContainerApplication, ContainerServices, ContainerShape } from "./ContainerApplication.ts";
/**
 * workerd container ports reject TLS outright ("Connecting to a container
 * using HTTPS is not currently supported") — but the common proxy pattern
 * forwards the incoming Worker request, whose production URL is `https://`,
 * straight to the port. The hop into the container is already secure, so
 * downgrade the scheme before forwarding, exactly like Cloudflare's own
 * `@cloudflare/containers` `containerFetch` does
 * (`request.url.replace("https:", "http:")`).
 */
export declare const httpSchemePort: <P extends {
    fetch: (...args: any[]) => any;
    connect: (...args: any[]) => any;
}>(port: P) => P;
declare const bindContainer: <Shape, Req = never>(containerEff: ContainerApplication<Shape> | Effect.Effect<ContainerApplication<Shape>, never, Req>) => Effect.Effect<void, never, Req | DurableObject<unknown> | import("../Providers.ts").Providers | Worker<any>>;
export declare const ContainerPlatform: Platform<ContainerApplication, ContainerServices, ContainerShape, ProcessContext, Container> & {
    bind: typeof bindContainer;
};
export {};
//# sourceMappingURL=ContainerPlatform.d.ts.map