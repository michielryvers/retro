import * as Containers from "@distilled.cloud/cloudflare/containers";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Effect from "effect/Effect";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
import type { DurableObjectApplicationSettings } from "./ContainerApplication.ts";
export declare const DurableObjectApplicationTypeId = "Cloudflare.Containers.DurableObjectApplication";
export interface DurableObjectApplicationProps {
    /** The Durable Object class whose namespace the application serves. */
    className: string;
}
/** What each bound Container contributes to its class's application. */
export interface DurableObjectApplicationBinding {
    /** The Durable Object namespace the application is attached to. */
    durableObjects?: {
        namespaceId: string;
    };
    /** The bound Container and the application-wide settings it declares. */
    container?: {
        id: string;
        settings: DurableObjectApplicationSettings;
    };
}
/**
 * INTERNAL — the one container application of a Durable Object class.
 *
 * Cloudflare allows exactly one container application per Durable Object
 * namespace. Every `schedulingPolicy: "durable_object"` Container bound to a
 * class declares this resource under the same logical id, so the engine
 * registers it once; each Container then binds its application-wide settings
 * onto it. The images themselves are Worker upload metadata, merged by the
 * Worker.
 *
 * @internal
 */
export interface DurableObjectApplication extends Resource<typeof DurableObjectApplicationTypeId, DurableObjectApplicationProps, {
    /** The application id, which equals the Durable Object namespace id. Empty before creation. */
    applicationId: string;
    /** The generated application name. */
    applicationName: string;
    /** The Cloudflare account that owns the application. */
    accountId: string;
    /** The Durable Object class the application serves. */
    className: string;
    /** The Durable Object namespace attached to the application. */
    durableObjects: {
        namespaceId: string;
    } | undefined;
    /** ISO-8601 creation time. Empty before creation. */
    createdAt: string;
    /** Application-wide container configuration (SSH and authorized keys). */
    configuration: Containers.DurableObjectContainerConfiguration;
    /** Application-wide logging. */
    observability: Containers.ContainerApplicationObservability | undefined;
    /** The merged settings last applied, used to reset settings a Container stops declaring. */
    settings: DurableObjectApplicationSettings;
}, DurableObjectApplicationBinding, Providers> {
}
export declare const DurableObjectApplication: import("alchemy/Resource").ResourceClass<DurableObjectApplication>;
/**
 * Declare the container application of `className`, hosted by `worker`. Every
 * Container bound to the class calls this; the engine dedupes the declaration
 * by its fully qualified id, so all of them share one resource.
 */
export declare const declareDurableObjectApplication: (worker: {
    LogicalId: string;
}, className: string) => Effect.Effect<DurableObjectApplication, never, Providers>;
/**
 * Right after a Worker upload creates a Durable Object namespace, the
 * containers API can report the namespace missing for a few seconds before it
 * sees it. Retry creates that attach to it, bounded at ~30s.
 */
export declare const retryNamespacePropagation: <A, E extends {
    readonly _tag: string;
}, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
export declare const LiveDurableObjectApplicationProvider: () => import("effect/Layer").Layer<Provider.Provider<DurableObjectApplication>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | Containers.CloudflareOpContext>;
/**
 * Local (dev) provider: `alchemy dev` runs every image through workerd and
 * Docker, so the application is a placeholder carrying a `dev:` id.
 */
export declare const LocalDurableObjectApplicationProvider: () => import("effect/Layer").Layer<Provider.Provider<DurableObjectApplication>, never, import("alchemy/Stack").Stack | import("alchemy/Stage").Stage>;
export declare const DurableObjectApplicationProvider: () => import("effect/Layer").Layer<Provider.Provider<DurableObjectApplication>, never, import("alchemy/AlchemyContext").AlchemyContext | CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | Containers.CloudflareOpContext>;
//# sourceMappingURL=DurableObjectApplication.d.ts.map