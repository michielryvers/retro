import type * as Containers from "@distilled.cloud/cloudflare/containers";
import * as Output from "alchemy/Output";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import type { AnyContainerApplicationProps, ContainerApplication, DevContainerImage, DurableObjectApplicationSettings, DurableObjectContainerProps } from "./ContainerApplication.ts";
import type { DurableObjectApplication } from "./DurableObjectApplication.ts";
declare const ContainerConfigurationError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ContainerConfigurationError";
} & Readonly<A>;
export declare class ContainerConfigurationError extends ContainerConfigurationError_base<{
    readonly message: string;
}> {
}
declare const ContainerImagePreparationError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ContainerImagePreparationError";
} & Readonly<A>;
export declare class ContainerImagePreparationError extends ContainerImagePreparationError_base<{
    readonly image: string;
    readonly status: "pending" | "error";
    readonly message: string;
}> {
}
declare const ContainerApplicationSettingsConflict_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ContainerApplicationSettingsConflict";
} & Readonly<A>;
/**
 * Two Containers bound to the same Durable Object class declare different
 * values for one application-wide setting. The class has one container
 * application, so the declarations must agree (or only one may declare it).
 */
export declare class ContainerApplicationSettingsConflict extends ContainerApplicationSettingsConflict_base<{
    readonly className: string;
    readonly setting: keyof DurableObjectApplicationSettings;
    readonly containers: ReadonlyArray<string>;
    readonly message: string;
}> {
}
declare const DurableObjectContainerConflict_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DurableObjectContainerConflict";
} & Readonly<A>;
/**
 * The Containers bound to one Durable Object class cannot be merged into the
 * class's single container entry: two images share a key, the class mixes a
 * fleet Container with Durable Object-managed ones, or it exceeds Cloudflare's
 * image limit.
 */
export declare class DurableObjectContainerConflict extends DurableObjectContainerConflict_base<{
    readonly className: string;
    readonly message: string;
}> {
}
declare const DurableObjectContainerBindingError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DurableObjectContainerBindingError";
} & Readonly<A>;
/**
 * A Durable Object-managed Container was bound on an async Worker outside a
 * Durable Object binding, or a Durable Object binding lists a Container it
 * cannot attach. Durable Object-managed Containers attach to a class through
 * `Cloudflare.DurableObject(className, { containers })`.
 */
export declare class DurableObjectContainerBindingError extends DurableObjectContainerBindingError_base<{
    readonly bindingName: string;
    readonly message: string;
}> {
}
declare const DurableObjectContainersOnEffectNativeClass_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DurableObjectContainersOnEffectNativeClass";
} & Readonly<A>;
/**
 * An async `Cloudflare.DurableObject(className, { containers })` binding
 * attaches Containers to a class the same Worker implements as an
 * Effect-native Durable Object. Effect-native classes `yield*` their
 * Containers instead.
 */
export declare class DurableObjectContainersOnEffectNativeClass extends DurableObjectContainersOnEffectNativeClass_base<{
    readonly className: string;
    readonly message: string;
}> {
}
/**
 * Fail when an async binding's `containers` target a class the Worker
 * implements as an Effect-native Durable Object.
 */
export declare const assertBindingContainersOnAsyncClasses: (rows: ReadonlyArray<{
    readonly className: string;
    readonly attachedBy?: "binding";
}>, effectNativeClasses: Iterable<string>) => Effect.Effect<void, never, never> | Effect.Effect<never, DurableObjectContainersOnEffectNativeClass, never>;
export declare const isDurableObjectContainer: (props: AnyContainerApplicationProps) => props is DurableObjectContainerProps;
/** Validate a bounded preparation deadline before publishing any images. */
export declare const imagePreparationTimeoutMillis: (timeout?: Duration.Input) => Effect.Effect<number, ContainerConfigurationError, never>;
/**
 * Validate container props before publishing images or touching the hosting
 * Worker. Reject switches between fleet scheduling and Durable Object scheduling.
 */
export declare const validateContainerConfiguration: (props: AnyContainerApplicationProps, deployedPolicy?: string | undefined) => Effect.Effect<undefined, ContainerConfigurationError, never>;
/** Whether a Durable Object-managed Container declares an image to publish. */
export declare const hasImageSource: (props: DurableObjectContainerProps) => boolean;
/** Read the scheduling policy off a declared Container resource's props. */
export declare const isDurableObjectContainerResource: (container: ContainerApplication) => boolean;
/** The application-wide settings a Container contributes to its Durable Object class. */
export declare const containerApplicationSettings: (container: ContainerApplication) => {
    ssh: import("./ContainerApplication.ts").ContainerSshConfiguration | undefined;
    authorizedKeys: Containers.UserSSHPublicKeyList | undefined;
    observability: Containers.ContainerApplicationObservability | undefined;
};
/**
 * Merge the application-wide settings every bound Container declares. A
 * setting declared by several Containers must have the same value.
 */
export declare const mergeApplicationSettings: (className: string, contributions: ReadonlyArray<{
    readonly id: string;
    readonly settings: DurableObjectApplicationSettings | undefined;
}>) => Effect.Effect<DurableObjectApplicationSettings, ContainerApplicationSettingsConflict, never>;
/**
 * One row of a Worker's `containers` binding data: the container a Durable
 * Object class is backed by.
 */
export interface WorkerContainerRow {
    readonly className: string;
    /** Set when an async `Cloudflare.DurableObject(name, { containers })` binding contributed the row. */
    readonly attachedBy?: "binding";
    /** Application name, set for a Durable Object-managed class. */
    readonly name?: string;
    /** Prepared images keyed by Container id (Durable Object-managed). */
    readonly images?: Record<string, string>;
    /** Local image sources keyed by Container id (Durable Object-managed). */
    readonly devImages?: Record<string, DevContainerImage>;
    /** The fleet container's local image. */
    readonly dev: DevContainerImage | undefined;
    readonly hash: string | undefined;
}
/**
 * Merge a Worker's `containers` rows into one entry per Durable Object class.
 * A Durable Object-managed class unions the images of every bound Container;
 * a fleet class is backed by exactly one Container.
 */
export declare const mergeWorkerContainers: <Row extends Partial<WorkerContainerRow> & {
    className: string;
}>(rows: ReadonlyArray<Row>) => Effect.Effect<Row[], DurableObjectContainerConflict, never>;
/**
 * The `containers` entry a fleet Container contributes to the Durable Object
 * class it backs.
 */
export declare const workerContainerBinding: (className: string, application: ContainerApplication) => {
    className: string;
    dev: Output.Output<DevContainerImage | undefined, never>;
    hash: Output.Output<string | undefined, never>;
};
/**
 * The `containers` entry a Durable Object-managed Container contributes to
 * its class: the class's application name plus this Container's one image,
 * keyed by the Container's id. The Worker merges every entry of the class.
 */
export declare const durableObjectContainerBinding: (className: string, application: DurableObjectApplication, container: ContainerApplication) => {
    className: string;
    name: Output.Output<string, never>;
    images: Output.ObjectExpr<{
        [x: string]: string;
    }, never>;
    devImages: Output.ObjectExpr<{
        [x: string]: DevContainerImage;
    }, never>;
    dev: undefined;
    hash: Output.Output<string | undefined, never>;
};
/**
 * Converge declared settings and reset settings removed from a prior declaration.
 * Omitted settings on new or adopted applications remain unmanaged.
 */
export declare const durableObjectSettingsPatch: (desired: DurableObjectApplicationSettings, previous: DurableObjectApplicationSettings | undefined, observed: Pick<Containers.GetContainerApplicationResponse, "configuration" | "observability">) => Pick<Containers.UpdateContainerApplicationRequest, "configuration" | "observability">;
/** Common attributes before a Durable Object-managed application exists remotely. */
export declare const durableObjectPlaceholder: (identity: Pick<ContainerApplication["Attributes"], "applicationId" | "applicationName" | "accountId" | "createdAt" | "observability">) => ContainerApplication["Attributes"];
export {};
//# sourceMappingURL=ContainerConfiguration.d.ts.map