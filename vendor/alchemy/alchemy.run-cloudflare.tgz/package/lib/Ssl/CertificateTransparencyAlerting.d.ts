import * as zones from "@distilled.cloud/cloudflare/zones";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
declare const TypeId: "Cloudflare.Ssl.CertificateTransparencyAlerting";
type TypeId = typeof TypeId;
export type CertificateTransparencyAlertingProps = {
    /**
     * Zone whose Certificate Transparency alerting is managed. Stable —
     * changing the zone triggers a replacement (the old zone's subscription
     * is restored to what it was before Alchemy managed it).
     */
    zoneId: string;
    /**
     * Whether Cloudflare emails an alert when a certificate is issued for
     * one of the zone's hostnames. Cloudflare leaves it off for a new zone.
     * @default true
     */
    enabled?: boolean;
    /**
     * Addresses that receive the alerts (at most 100). When omitted, the
     * zone's stored recipients are left as they are.
     */
    emails?: string[];
};
export type CertificateTransparencyAlertingAttributes = {
    /** Zone the subscription belongs to. */
    zoneId: string;
    /** Whether CT alerting is enabled for the zone. */
    enabled: boolean;
    /** The zone's alert recipients. */
    emails: string[];
    /** `enabled` before Alchemy first managed the subscription. */
    initialEnabled: boolean;
    /** `emails` before Alchemy first managed the subscription. */
    initialEmails: string[];
};
export type CertificateTransparencyAlerting = Resource<TypeId, CertificateTransparencyAlertingProps, CertificateTransparencyAlertingAttributes, never, Providers>;
/**
 * Certificate Transparency alerting for a Cloudflare zone ("Certificate
 * Transparency Monitoring" in the dashboard, `/zones/{zone_id}/ct/alerting`
 * in the API): Cloudflare watches the public Certificate Transparency logs
 * and emails the listed recipients when a certificate is issued for one of
 * the zone's hostnames. Certificates Cloudflare issues itself are filtered
 * out.
 *
 * The subscription is a zone singleton, so this resource never creates or
 * deletes anything physical. Reconcile patches it when the observed state
 * differs from the props; destroy restores the state observed before
 * Alchemy first managed it.
 * ### Monitoring certificate issuance
 * **Example:** Email the security team on every new certificate
 * ```typescript
 * yield* Cloudflare.Ssl.CertificateTransparencyAlerting("CtAlerting", {
 *   zoneId: zone.zoneId,
 *   emails: ["security@example.com"],
 * });
 * ```
 *
 * **Example:** Turn alerting off for a zone
 * ```typescript
 * yield* Cloudflare.Ssl.CertificateTransparencyAlerting("CtAlerting", {
 *   zoneId: zone.zoneId,
 *   enabled: false,
 * });
 * ```
 *
 * @see https://blog.cloudflare.com/certificate-transparency-monitoring-ga/
 *
 * @resource
 * @product SSL/TLS
 * @category SSL/TLS & Certificates
 */
export declare const CertificateTransparencyAlerting: import("alchemy/Resource").ResourceClass<CertificateTransparencyAlerting>;
/**
 * Returns true if the given value is a CertificateTransparencyAlerting resource.
 */
export declare const isCertificateTransparencyAlerting: (value: unknown) => value is CertificateTransparencyAlerting;
export declare const CertificateTransparencyAlertingProvider: () => import("effect/Layer").Layer<Provider.Provider<CertificateTransparencyAlerting>, never, CloudflareEnvironment | zones.CloudflareOpContext>;
export {};
//# sourceMappingURL=CertificateTransparencyAlerting.d.ts.map