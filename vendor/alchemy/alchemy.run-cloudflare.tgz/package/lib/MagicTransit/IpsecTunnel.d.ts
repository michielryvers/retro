import * as magicTransit from "@distilled.cloud/cloudflare/magic-transit";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Redacted from "effect/Redacted";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
import type { MagicTunnelBgp, MagicTunnelHealthCheck } from "./GreTunnel.ts";
declare const TypeId: "Cloudflare.MagicTransit.IpsecTunnel";
type TypeId = typeof TypeId;
export interface IpsecTunnelProps {
    /**
     * The name of the IPsec tunnel. Cannot share a name with other tunnels.
     * Immutable in practice — changing it triggers a replacement.
     */
    name: string;
    /**
     * The IP address assigned to the Cloudflare side of the IPsec tunnel
     * (a Cloudflare anycast IP allocated to the account).
     */
    cloudflareEndpoint: string;
    /**
     * The IP address assigned to the customer side of the IPsec tunnel. Not
     * required, but must be set for proactive traceroutes to work.
     */
    customerEndpoint?: string;
    /**
     * A 31-bit prefix (/31 in CIDR notation) from RFC1918 private space; one
     * host for each side of the tunnel.
     */
    interfaceAddress: string;
    /**
     * A /127 IPv6 prefix from within the account's `virtual_subnet6` space.
     */
    interfaceAddress6?: string;
    /**
     * An optional description of the IPsec tunnel.
     */
    description?: string;
    /**
     * Pre-shared key for the tunnel. Write-only — Cloudflare never returns
     * it, so the value is carried in state. When omitted, Cloudflare leaves
     * the tunnel without a PSK until one is generated via the dashboard/API.
     */
    psk?: Redacted.Redacted<string>;
    /**
     * If `true`, IPsec replay protection is supported in the
     * Cloudflare-to-customer direction.
     * @default false
     */
    replayProtection?: boolean;
    /**
     * Tunnel health-check configuration.
     */
    healthCheck?: MagicTunnelHealthCheck;
    /**
     * BGP configuration for the tunnel.
     */
    bgp?: MagicTunnelBgp;
    /**
     * Custom remote identities for IKE negotiation.
     */
    customRemoteIdentities?: {
        /** Identifier of the FQDN remote identity. */
        fqdnId?: string;
    };
    /**
     * True if automatic stateful return routing should be enabled. Requires
     * the `coupler_integration` account flag.
     * @default false
     */
    automaticReturnRouting?: boolean;
}
export interface IpsecTunnelAttributes {
    /** Cloudflare-assigned identifier of the IPsec tunnel. */
    tunnelId: string;
    /** The Cloudflare account the tunnel belongs to. */
    accountId: string;
    /** The name of the tunnel. */
    name: string;
    /** The IP address on the Cloudflare side of the tunnel. */
    cloudflareEndpoint: string;
    /** The IP address on the customer side of the tunnel, if set. */
    customerEndpoint: string | undefined;
    /** The /31 interface address of the tunnel. */
    interfaceAddress: string;
    /** The /127 IPv6 interface address, if configured. */
    interfaceAddress6: string | undefined;
    /** The tunnel description, if set. */
    description: string | undefined;
    /**
     * The pre-shared key as configured. Write-only on Cloudflare's side —
     * this is the value from props, carried in state, never read back.
     */
    psk: Redacted.Redacted<string> | undefined;
    /** Whether the tunnel allows a null cipher (`ENCR_NULL`) in Phase 2. */
    allowNullCipher: boolean | undefined;
    /** Whether replay protection is enabled. */
    replayProtection: boolean | undefined;
    /** ISO8601 creation timestamp. */
    createdOn: string | undefined;
    /** ISO8601 last-modified timestamp. */
    modifiedOn: string | undefined;
}
export type IpsecTunnel = Resource<TypeId, IpsecTunnelProps, IpsecTunnelAttributes, never, Providers>;
/**
 * A Magic Transit / Magic WAN IPsec tunnel between Cloudflare and a
 * customer device.
 *
 * Requires a Magic Transit or Magic WAN subscription on the account —
 * accounts that are not onboarded receive a typed
 * `MagicTransitNotOnboarded` error (Cloudflare code 1012).
 *
 * The tunnel `name` is unique per account and immutable in practice —
 * changing it triggers a replacement. The `psk` is write-only: Cloudflare
 * never returns it, so the configured value is carried in state.
 * ### Creating an IPsec tunnel
 * **Example:** Basic tunnel with a provided PSK
 * ```typescript
 * const tunnel = yield* Cloudflare.MagicTransit.IpsecTunnel("branch", {
 *   name: "branch-ipsec-1",
 *   cloudflareEndpoint: "203.0.113.1",
 *   customerEndpoint: "198.51.100.1",
 *   interfaceAddress: "10.213.0.10/31",
 *   psk: yield* Config.Redacted("IPSEC_PSK"),
 * });
 * ```
 *
 * **Example:** Tunnel with replay protection and health checks
 * ```typescript
 * const tunnel = yield* Cloudflare.MagicTransit.IpsecTunnel("branch", {
 *   name: "branch-ipsec-1",
 *   cloudflareEndpoint: "203.0.113.1",
 *   interfaceAddress: "10.213.0.10/31",
 *   replayProtection: true,
 *   healthCheck: { enabled: true, rate: "mid" },
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/magic-wan/reference/tunnels/
 *
 * @resource
 * @product Magic Transit
 * @category Network
 */
export declare const IpsecTunnel: import("alchemy/Resource").ResourceClass<IpsecTunnel>;
/**
 * Returns true if the given value is an IpsecTunnel resource.
 */
export declare const isIpsecTunnel: (value: unknown) => value is IpsecTunnel;
export declare const IpsecTunnelProvider: () => import("effect/Layer").Layer<Provider.Provider<IpsecTunnel>, never, CloudflareEnvironment | magicTransit.CloudflareOpContext>;
export {};
//# sourceMappingURL=IpsecTunnel.d.ts.map