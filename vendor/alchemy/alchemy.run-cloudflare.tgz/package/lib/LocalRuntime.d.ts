import { AlchemyContext } from "alchemy/AlchemyContext";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as MutableHashMap from "effect/MutableHashMap";
import * as Path from "effect/Path";
import { CloudflareEnvironment } from "./CloudflareEnvironment.ts";
import type { Consumer } from "./Queues/Consumer.ts";
import type { Queue } from "./Queues/Queue.ts";
/**
 * The Cloudflare provider group module ([Local.ts](./Local.ts)) every
 * Cloudflare local provider is registered in; the dev sidecar imports it on
 * first use (see `Local/Sidecar.ts`).
 */
export declare const LOCAL_PROVIDERS_URL: string;
declare const LocalRuntimeState_base: Context.ServiceClass<LocalRuntimeState, "alchemy/cloudflare/LocalRuntimeState", {
    readonly queues: MutableHashMap.MutableHashMap<Queue["Attributes"]["queueId"], Queue["Attributes"]>;
    readonly queueConsumers: MutableHashMap.MutableHashMap<Consumer["Attributes"]["consumerId"], Consumer["Attributes"]>;
    /**
     * Restart hooks for locally running Workers, keyed by script name.
     *
     * A local workerd instance bakes its queue-consumer wiring in at start
     * time (`runtime.start({ queueConsumers })`), but the `Consumer`
     * resource that populates {@link queueConsumers} reconciles as a
     * *sibling* of the Worker — the engine may start workerd before the
     * consumer registers. Providers that mutate a worker's runtime wiring
     * (e.g. `ConsumerProviderLocal`) invoke the script's hook after
     * updating state so the running instance is reconfigured; the hook is
     * a no-op until the worker has served at least once.
     */
    readonly workerRestarts: MutableHashMap.MutableHashMap<string, Effect.Effect<void>>;
}>;
export declare class LocalRuntimeState extends LocalRuntimeState_base {
}
/**
 * Directory under `.alchemy` holding local-provider persistent state
 * (workerd storage). Shared so every consumer — the local runtime layer and
 * Vite child processes — points at the same storage.
 */
export declare const localStorageDirectory: Effect.Effect<string, never, AlchemyContext | Path.Path>;
/**
 * The shared local-runtime dependency layer (workerd `Runtime`,
 * `WorkerProxy`, {@link LocalRuntimeState}, the zone-routing `LocalEdge`) used by every Cloudflare local
 * provider.
 *
 * Returns a **module-memoized layer reference**: local providers register
 * via `ProviderLayer.dual`, which builds each provider's local variant
 * lazily against the stack build's shared `Layer.MemoMap` — memoization is
 * keyed by layer identity, so Worker/Queue/Consumer/Container composing
 * this exact reference into their local thunks share one runtime instance
 * per stack build (a fresh build gets a fresh instance via its own memo
 * map; the layer blueprint itself is immutable).
 */
export declare const localRuntimeServices: () => Layer.Layer<import("@alchemy.run/cloudflare-runtime/core/bindings/analytics-engine").AnalyticsEngine | import("@alchemy.run/cloudflare-runtime/core/bindings/assets/Assets").Assets | import("@alchemy.run/cloudflare-runtime/core/bindings/browser").Browser | import("@alchemy.run/cloudflare-runtime/core/bindings/cache").Cache | import("@alchemy.run/cloudflare-runtime/core/bindings/d1").D1 | import("@alchemy.run/cloudflare-runtime/core/bindings/dispatch-namespace").DispatchNamespace | import("@alchemy.run/cloudflare-runtime/core/bindings/hyperdrive").Hyperdrive | import("@alchemy.run/cloudflare-runtime/core/bindings/images").Images | import("@alchemy.run/cloudflare-runtime/core/bindings/kv-namespace").KvNamespace | import("./Workers/LocalEdge.ts").LocalEdge | LocalRuntimeState | import("@alchemy.run/cloudflare-runtime/core/globals/Loopback").Loopback | import("@alchemy.run/cloudflare-runtime/core/bindings/queue").Queue | import("@alchemy.run/cloudflare-runtime/core/bindings/r2-bucket").R2Bucket | import("@alchemy.run/cloudflare-runtime/core/bindings/rate-limit").RateLimit | import("@alchemy.run/cloudflare-runtime/core/registry/RegistryProxy").RegistryProxy | import("@alchemy.run/cloudflare-runtime/core/remote-bindings/RemoteBindings").RemoteBindings | import("@alchemy.run/cloudflare-runtime/core").Runtime | import("@alchemy.run/cloudflare-runtime/core/bindings/secrets-store").SecretsStore | import("@alchemy.run/cloudflare-runtime/core/bindings/send-email").SendEmail | import("@alchemy.run/cloudflare-runtime/core/bindings/stream").Stream | import("@alchemy.run/cloudflare-runtime/core/proxy/WorkerProxy").WorkerProxy | import("@alchemy.run/cloudflare-runtime/core/bindings/workflows").Workflows, import("effect/Config").ConfigError | import("@alchemy.run/cloudflare-runtime/core").ConfigError | import("effect/PlatformError").PlatformError | import("@alchemy.run/cloudflare-runtime/core").SystemError, AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | CloudflareEnvironment | import("@distilled.cloud/cloudflare/Credentials").Credentials | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | Path.Path>;
export declare const isLocalId: (id: string | undefined) => id is string;
export declare const isLiveId: (id: string | undefined) => id is string;
export declare const generateLocalId: () => string;
export {};
//# sourceMappingURL=LocalRuntime.d.ts.map