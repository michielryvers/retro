import * as d1 from "@distilled.cloud/cloudflare/d1";
import * as Effect from "effect/Effect";
export interface ImportDatabaseOptions {
    accountId: string;
    databaseId: string;
    sqlData: string | Uint8Array;
    filename?: string;
}
export interface ImportDatabaseResult {
    filename: string;
    numQueries: number;
}
/**
 * Import SQL into a D1 database via the multi-step Cloudflare flow:
 *   1. POST `action: "init"` -> returns presigned `upload_url`
 *   2. PUT raw SQL to `upload_url`
 *   3. POST `action: "ingest"` -> returns `at_bookmark`
 *   4. POST `action: "poll"` until `status === "complete"`
 */
export declare const importD1Database: (options: ImportDatabaseOptions) => Effect.Effect<ImportDatabaseResult, import("@distilled.cloud/iceberg").BadGateway | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | import("@distilled.cloud/iceberg").ConfigError | import("@distilled.cloud/iceberg").GatewayTimeout | import("effect/http/HttpClientError").HttpClientError | import("@distilled.cloud/iceberg").InternalServerError | d1.InvalidObjectIdentifier | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("@distilled.cloud/iceberg").ServiceUnavailable | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError, d1.CloudflareOpContext>;
//# sourceMappingURL=ImportDatabase.d.ts.map