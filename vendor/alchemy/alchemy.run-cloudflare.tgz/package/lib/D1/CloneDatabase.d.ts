import * as Effect from "effect/Effect";
export interface CloneDatabaseOptions {
    accountId: string;
    sourceDatabaseId: string;
    targetDatabaseId: string;
}
/**
 * Clone a D1 database by exporting from the source and importing into the
 * target. Fetches the SQL dump from the export's signed URL and streams the
 * payload through the import flow.
 */
export declare const cloneDatabase: (options: CloneDatabaseOptions) => Effect.Effect<import("./ImportDatabase.ts").ImportDatabaseResult, import("@distilled.cloud/cloudflare/d1").ExportDatabaseError, import("@distilled.cloud/cloudflare/Protocol").CloudflareOpContext>;
//# sourceMappingURL=CloneDatabase.d.ts.map