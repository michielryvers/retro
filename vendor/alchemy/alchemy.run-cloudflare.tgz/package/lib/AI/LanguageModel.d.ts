import type { RuntimeContext } from "alchemy/RuntimeContext";
import { LanguageModel as AiLanguageModel, Response } from "effect/ai";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
/**
 * The slice of an AI client the LanguageModel adapter needs: the raw Workers
 * AI handle plus, when routed through an AI Gateway, the gateway id.
 *
 * Both `Cloudflare.AI.QueryGateway(gateway)` (gateway-routed) and
 * `Cloudflare.Workers.AI()` (plain Workers AI binding) clients satisfy it.
 */
export interface LanguageModelClient {
    /** Effect resolving to the raw Workers AI runtime binding. */
    readonly raw: Effect.Effect<Ai, never, RuntimeContext>;
    /**
     * Effect resolving to the AI Gateway id to route `ai.run` calls through.
     * Omit for a plain Workers AI binding — requests then go directly to
     * Workers AI without a gateway.
     */
    readonly id?: Effect.Effect<string, never, RuntimeContext>;
}
/**
 * Options for constructing a Workers AI-backed LanguageModel.
 */
export interface LanguageModelOptions {
    /**
     * Already-bound AI client — from `Cloudflare.AI.QueryGateway(gateway)`
     * (routed through the gateway) or `Cloudflare.Workers.AI()` (direct).
     */
    readonly client: LanguageModelClient;
    /** Workers AI model id, e.g. `@cf/meta/llama-3.3-70b-instruct-fp8-fast`. */
    readonly model: string;
    /** Optional per-call defaults; overridable per request via `providerOptions`. */
    readonly parameters?: {
        readonly temperature?: number;
        readonly maxTokens?: number;
        readonly topP?: number;
        readonly topK?: number;
        readonly seed?: number;
        readonly frequencyPenalty?: number;
        readonly presencePenalty?: number;
    };
}
/**
 * Provide a {@link AiLanguageModel.LanguageModel} layer backed by the supplied
 * AI Gateway client and Workers AI model.
 */
export declare const makeLanguageModelLayer: (options: LanguageModelOptions) => Layer.Layer<AiLanguageModel.LanguageModel, never, RuntimeContext>;
/**
 * Build a {@link AiLanguageModel.LanguageModel} that proxies generateText/streamText
 * through the supplied AI Gateway client to a Workers AI model.
 */
export declare const makeLanguageModel: ({ client, model, parameters, }: LanguageModelOptions) => Effect.Effect<AiLanguageModel.LanguageModel, never, RuntimeContext>;
/**
 * The neurons Workers AI billed for a response, read from its finish part.
 * Workers AI reports this as `usage.neurons`; the adapter carries it on the
 * finish part as `metadata.cloudflare.neurons`. `undefined` when the model
 * did not report it.
 *
 * @example
 * ```typescript
 * const response = yield* LanguageModel.generateText({ prompt });
 * const finish = response.content.find((part) => part.type === "finish");
 * const neurons = finish ? Cloudflare.AI.finishNeurons(finish) : undefined;
 * ```
 */
export declare const finishNeurons: (part: {
    readonly metadata: Response.FinishPartMetadata;
}) => number | undefined;
//# sourceMappingURL=LanguageModel.d.ts.map