import * as aiGateway from "@distilled.cloud/cloudflare/ai-gateway";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
declare const TypeId: "Cloudflare.AI.GatewayProvider";
type TypeId = typeof TypeId;
export type GatewayProviderProps = {
    /**
     * The AI Gateway the provider config (BYOK key) belongs to. The gateway
     * must have its `storeId` set to a Secrets Store id — Cloudflare resolves
     * the key inside that store. Changing the gateway triggers a replacement.
     */
    gatewayId: string;
    /**
     * The upstream provider the key authenticates against (e.g. `openai`,
     * `anthropic`, `workers-ai`). Changing the provider triggers a
     * replacement.
     */
    providerSlug: string;
    /**
     * Alias distinguishing multiple keys for the same provider. If omitted, a
     * unique name is generated from the app, stage, and logical ID.
     *
     * Cloudflare requires the referenced Secrets Store secret to be named
     * exactly `{gatewayId}_{providerSlug}_{alias}` and scoped to
     * `ai_gateway`. Changing the alias triggers a replacement.
     * @default ${app}-${stage}-${id}
     */
    alias?: string;
    /**
     * The Secrets Store secret holding the provider API key. The secret must
     * live in the gateway's `storeId` store, be scoped to `ai_gateway`, and
     * be named `{gatewayId}_{providerSlug}_{alias}`. Changing the secret
     * triggers a replacement.
     */
    secretId: string;
    /**
     * Whether this key is the gateway's default credential for the provider
     * (used when a request does not name a specific key).
     * @default false
     */
    defaultConfig?: boolean;
    /**
     * Maximum number of requests allowed per `rateLimitPeriod` through this
     * key. Omit for no limit. Changing the limit triggers a replacement
     * (Cloudflare exposes no update API for provider configs).
     */
    rateLimit?: number;
    /**
     * The rate limit window in seconds.
     * @default 60
     */
    rateLimitPeriod?: number;
};
export type GatewayProviderAttributes = {
    /**
     * Server-generated gateway provider identifier.
     */
    providerConfigId: string;
    /**
     * The Cloudflare account the gateway provider belongs to.
     */
    accountId: string;
    /**
     * The AI Gateway the gateway provider belongs to.
     */
    gatewayId: string;
    /**
     * Alias distinguishing multiple keys for the same provider.
     */
    alias: string;
    /**
     * The upstream provider the key authenticates against.
     */
    providerSlug: string;
    /**
     * The Secrets Store secret holding the gateway provider API key.
     */
    secretId: string;
    /**
     * Masked preview of the secret value.
     */
    secretPreview: string;
    /**
     * Whether this key is the gateway's default credential for the gateway provider.
     */
    defaultConfig: boolean;
    /**
     * Maximum number of requests allowed per `rateLimitPeriod`, if limited, for the gateway provider.
     */
    rateLimit: number | undefined;
    /**
     * The rate limit window in seconds for the gateway provider.
     */
    rateLimitPeriod: number | undefined;
    /**
     * When the gateway provider was last modified.
     */
    modifiedAt: string;
};
export type GatewayProvider = Resource<TypeId, GatewayProviderProps, GatewayProviderAttributes, never, Providers>;
/**
 * A BYOK (bring-your-own-key) provider credential on a Cloudflare AI
 * Gateway.
 *
 * Provider configs let the gateway authenticate against upstream model
 * providers (OpenAI, Anthropic, Workers AI, ...) with your own API key,
 * stored in Cloudflare Secrets Store. Cloudflare exposes no update API for
 * provider configs, so every prop change replaces the config (the old one
 * is deleted first — a gateway allows only one config per provider slug
 * and alias).
 *
 * Cloudflare imposes a strict naming contract: the gateway must reference a
 * Secrets Store via its `storeId`, and the secret must be scoped to
 * `ai_gateway` and named exactly `{gatewayId}_{providerSlug}_{alias}`.
 * ### Creating a Provider Config
 * **Example:** Bring your own OpenAI key
 * ```typescript
 * const store = yield* Cloudflare.SecretsStore.Store("Store");
 *
 * const gateway = yield* Cloudflare.AI.Gateway("Gateway", {
 *   id: "my-gateway",
 *   storeId: store.storeId,
 * });
 *
 * // The secret name must be `{gatewayId}_{providerSlug}_{alias}`.
 * // Prefer `Cloudflare.AI.ProviderKey` to wire this secret automatically.
 * const secret = yield* Cloudflare.SecretsStore.Secret("OpenAiKey", {
 *   store,
 *   name: "my-gateway_openai_default",
 *   value: yield* Config.Redacted("OPENAI_API_KEY"),
 *   scopes: ["ai_gateway"],
 * });
 *
 * const byok = yield* Cloudflare.AI.GatewayProvider("OpenAi", {
 *   gatewayId: gateway.gatewayId,
 *   providerSlug: "openai",
 *   alias: "default",
 *   secretId: secret.secretId,
 *   defaultConfig: true,
 * });
 * ```
 *
 * **Example:** Rate-limit a key
 * ```typescript
 * const byok = yield* Cloudflare.AI.GatewayProvider("OpenAi", {
 *   gatewayId: gateway.gatewayId,
 *   providerSlug: "openai",
 *   alias: "default",
 *   secretId: secret.secretId,
 *   rateLimit: 100,
 *   rateLimitPeriod: 60,
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/ai-gateway/configuration/bring-your-own-keys/
 *
 * @resource
 * @product AI Gateway
 * @category AI
 */
export declare const GatewayProvider: import("alchemy/Resource").ResourceClass<GatewayProvider>;
/**
 * Returns true if the given value is a GatewayProvider resource.
 */
export declare const isGatewayProvider: (value: unknown) => value is GatewayProvider;
export declare const GatewayProviderProvider: () => import("effect/Layer").Layer<Provider.Provider<GatewayProvider>, never, CloudflareEnvironment | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage | aiGateway.CloudflareOpContext>;
export {};
//# sourceMappingURL=GatewayProvider.d.ts.map