import * as ai from "@distilled.cloud/cloudflare/ai";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
export interface ModelProps {
    /** Cloudflare-managed model name, such as `@cf/baai/bge-m3`. */
    modelName: string;
}
export interface ModelAttributes {
    /** Account used to validate and subscribe to the model. */
    accountId: string;
    /** Cloudflare-managed model name. */
    modelName: string;
}
export type Model = Resource<"Cloudflare.AI.Model", ModelProps, ModelAttributes, never, Providers>;
/**
 * A persisted, non-owning handle to a Cloudflare Workers AI catalog model.
 *
 * Deployment validates the model through its schema endpoint and records its
 * name and account in Alchemy state. It does not provision or invoke a model.
 * Destruction removes only the handle from state; Cloudflare owns the model.
 *
 * ### Selecting a Model
 * **Example:** Observe a Workers AI model
 * ```typescript
 * const model = yield* Cloudflare.AI.Model("Embeddings", {
 *   modelName: "@cf/baai/bge-m3",
 * });
 * ```
 *
 * ### Subscribing to Batch Events
 * **Example:** Model-specific Queue subscription
 * ```typescript
 * const model = yield* Cloudflare.AI.Model("Embeddings", {
 *   modelName: "@cf/baai/bge-m3",
 * });
 * const queue = yield* Cloudflare.Queues.Queue("BatchEvents");
 * yield* Cloudflare.Queues.Subscription("ModelEvents", {
 *   source: model,
 *   events: ["batch.queued", "batch.succeeded", "batch.failed"],
 *   queueId: queue.queueId,
 * });
 * ```
 * These events require asynchronous batch inference. Synchronous inference
 * does not emit batch events.
 *
 * ### Referencing a Persisted Handle
 * **Example:** Read a model handle from another stack
 * ```typescript
 * const model = yield* Cloudflare.AI.Model.ref("Embeddings", {
 *   stack: "models",
 *   stage: "production",
 * });
 * ```
 * The handle must already be deployed. A reference neither invokes the model
 * nor takes ownership of the source stack's state.
 *
 * @resource
 * @product Workers AI
 * @category AI
 */
export declare const Model: import("alchemy/Resource").ResourceClass<Model>;
export declare const ModelProvider: () => import("effect/Layer").Layer<Provider.Provider<Model>, never, CloudflareEnvironment | ai.CloudflareOpContext>;
//# sourceMappingURL=Model.d.ts.map