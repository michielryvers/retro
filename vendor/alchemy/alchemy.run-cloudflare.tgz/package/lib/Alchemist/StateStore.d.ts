import type { StateStoreImpl, StateStoreLifecycle } from "alchemy/Contributions";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as CloudflareAccess from "../Access.ts";
import * as CloudflareEnvironment from "../CloudflareEnvironment.ts";
import * as CloudflareCredentials from "../Credentials.ts";
/**
 * The profile, Cloudflare account and clients a store's lifecycle operation
 * runs with, under the profile config and auth registry core provides.
 */
export declare const stateStoreScope: (name: string | undefined) => Effect.Effect<{
    layer: Layer.Layer<CloudflareAccess.Access | CloudflareEnvironment.CloudflareEnvironment | CloudflareCredentials.Credentials, import("effect/PlatformError").PlatformError, import("alchemy/AlchemyContext").AlchemyContext | import("alchemy/Auth/AuthProvider").AuthProviders | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("alchemy/Auth/Profile").ProfileStore>;
    profile: string;
    accountId: string;
    workerName: string;
}, import("effect/PlatformError").PlatformError | import("alchemy/Auth/Profile").ProfileError | import("alchemy/State/State").StateStoreError, import("alchemy/AlchemyContext").AlchemyContext | import("alchemy/Auth/AuthProvider").AuthProviders | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("alchemy/Auth/Profile").ProfileStore>;
/** The state-store Worker's lifecycle, for `Alchemist.State` and `alchemy state`. */
export declare const lifecycle: StateStoreLifecycle;
/** The state store Cloudflare contributes. */
export declare const stateStore: StateStoreImpl;
//# sourceMappingURL=StateStore.d.ts.map