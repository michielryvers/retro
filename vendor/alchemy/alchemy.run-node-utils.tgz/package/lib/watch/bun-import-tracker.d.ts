import { DependencyWatcher, type DependencyWatcherOptions } from "./dependency-watcher.ts";
export interface BunImportTrackerOptions extends DependencyWatcherOptions {
    /**
     * Directory whose modules belong to the tracked graph. Files outside it and
     * anything under a `node_modules` directory load untouched.
     */
    readonly root: string;
}
/**
 * Records every project-local module Bun loads after registration and watches
 * those files for changes.
 *
 * Bun has no loader hooks that can evict or re-namespace an evaluated module,
 * so unlike Node's `ImportWatcher` (./import-watcher.ts) this cannot import
 * a fresh generation in-process. A runtime `Bun.plugin` `onLoad` hook is used purely
 * as a dependency probe: it hands the source back unchanged with the loader
 * Bun would have picked itself. It stays registered after `close()`, only
 * echoing sources. Callers react to a change by exiting so a
 * supervisor can start a fresh process.
 */
export declare class BunImportTracker extends DependencyWatcher {
    #private;
    constructor(options: BunImportTrackerOptions);
}
export declare const trackBunImports: (options: BunImportTrackerOptions) => BunImportTracker;
//# sourceMappingURL=bun-import-tracker.d.ts.map