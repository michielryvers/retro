import type { LoaderOptions } from "../loader/hooks.ts";
import type { NamespaceOptions } from "../loader/namespace.ts";
import { DependencyWatcher, type DependencyWatcherOptions } from "./dependency-watcher.ts";
export interface ImportGeneration<T> {
    readonly value: T;
    readonly namespace: string;
    readonly dependencies: ReadonlySet<string>;
}
export interface ImportWatcherOptions extends LoaderOptions, DependencyWatcherOptions, Pick<NamespaceOptions, "shouldInvalidate"> {
    readonly parentURL: string;
}
/**
 * Imports fresh generations of one module graph and watches exactly the
 * files the current generation loaded. Each generation registers the Oxc
 * loader hooks under a new namespace (see ../loader/namespace.ts), so Node
 * evaluates the same files again as new modules; the previous generation's
 * hooks are deregistered once the new one is in.
 *
 * CommonJS members of the graph live in Node's path-keyed `require` cache,
 * which no namespace reaches; a new generation evicts the previous one's
 * files from it so they are evaluated again too.
 *
 * Bun callers use `BunImportTracker` (./bun-import-tracker.ts): Bun cannot
 * evict evaluated modules, so a change there restarts the process instead.
 */
export declare class ImportWatcher<T = unknown> extends DependencyWatcher {
    #private;
    constructor(specifier: string, options: ImportWatcherOptions);
    import(): Promise<ImportGeneration<T>>;
    close(): Promise<void>;
}
export declare const watchImport: <T = unknown>(specifier: string, options: ImportWatcherOptions) => ImportWatcher<T>;
//# sourceMappingURL=import-watcher.d.ts.map