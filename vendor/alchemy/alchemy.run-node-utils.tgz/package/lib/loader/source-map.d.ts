import type { transformSync } from "rolldown/utils";
export type SourceMap = NonNullable<ReturnType<typeof transformSync>["map"]>;
/**
 * The map as stored in the cache: `sources` names the file by URL and
 * `sourcesContent` is dropped. A bare path in `sources` is resolved against
 * the map's own location — the shared cache directory — whereas a URL is
 * location-independent and correct on Windows too. Every source is a file
 * on this machine, so embedding its text only makes the map larger than
 * the code it describes and every process that loads the module pay for it.
 */
export declare const storedSourceMap: ({ sourcesContent: _sourcesContent, ...map }: SourceMap, filePath: string) => string;
/** Where a module's source map is, and how to get its text if needed. */
export interface SourceMapRef {
    /** Absolute path of the map on disk, if it has been written there. */
    readonly file: string | undefined;
    readonly text: () => string;
}
/**
 * `code` with its source map attached.
 *
 * Normally by reference to the file on disk: an inline `data:` map is part
 * of the script source V8 keeps for the process lifetime, which for a graph
 * the size of alchemy's is hundreds of megabytes. Inlined when there is no
 * file, and — with the source embedded — while a debugger is attached: a
 * map in the shared cache directory is one debuggers either refuse to read
 * (VS Code only loads maps under the workspace by default) or cannot fetch
 * over the inspector protocol (DevTools), leaving every module to show up
 * as transpiled output from a foreign folder.
 */
export declare const attachSourceMap: (code: string, map: SourceMapRef, readSource: () => string) => string;
/**
 * Turns Node's source-map support on for as long as any holder of a lease
 * keeps it, and restores the previous setting once the last one releases
 * theirs. Transformed sources only reference their maps; Node reads and
 * applies them to stack traces when this is on. `nodeModules` stays on: a
 * published alchemy runs its own `lib/` from `node_modules`, and ships maps
 * back to its `src/`. Leases are counted on `globalThis` because a checkout
 * can load this module twice (src/ and lib/).
 */
export declare const leaseSourceMapSupport: () => (() => void);
//# sourceMappingURL=source-map.d.ts.map