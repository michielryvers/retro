import type { LoadHookSync, ResolveHookSync } from "node:module";
export interface LoaderOptions {
    /**
     * Additional package export conditions used during module resolution.
     * They are made available alongside Node's ambient conditions to both the
     * TypeScript-aware resolver and Node's package exports resolver.
     */
    readonly conditions?: ReadonlyArray<string> | undefined;
    /**
     * Honour `tsconfig.json` discovered upward from each file: compiler
     * options for the transform, `paths`/`baseUrl` aliases for resolution.
     * @default true
     */
    readonly tsconfig?: boolean | undefined;
    /**
     * Limits transformation to matching absolute file paths; everything else
     * loads through Node untouched. Lets a published install transpile only
     * the user's own TypeScript while alchemy and its dependencies run their
     * built JavaScript.
     */
    readonly filter?: ((path: string) => boolean) | undefined;
    /**
     * On-disk cache of Oxc output shared by every process on the machine, so
     * the CLI, its dev exec child and the local-provider sidecars transpile
     * each source file once between them rather than once each. `false`
     * disables it, a string names the directory.
     * @default `$ALCHEMY_TRANSFORM_CACHE` (`0` disables), else a per-user
     * directory under the OS temp directory
     */
    readonly cache?: boolean | string | undefined;
}
/** Synchronous Node module hooks, as `module.registerHooks` takes them. */
export interface LoaderHooks {
    readonly resolve: ResolveHookSync;
    readonly load: LoadHookSync;
}
/**
 * The loader itself: synchronous `resolve` and `load` hooks that transpile
 * TypeScript with Rolldown's Oxc transformer and resolve it the way
 * TypeScript (and tsx) does. Register them process-wide with
 * `registerOxc` (./register.ts), or scoped to one import graph through
 * `namespaced` (./namespace.ts). Each call creates its own resolver,
 * transformer and resolution memo.
 */
export declare const createHooks: (options?: LoaderOptions) => LoaderHooks;
//# sourceMappingURL=hooks.d.ts.map