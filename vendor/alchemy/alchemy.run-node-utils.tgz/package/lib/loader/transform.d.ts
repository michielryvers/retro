import type { LoaderOptions } from "./hooks.ts";
/** Extensions Oxc transpiles; everything else is JavaScript Node can run. */
export declare const transformExtensions: Set<string>;
export type ModuleFormat = "module" | "commonjs";
export interface TransformedSource {
    readonly format: ModuleFormat;
    readonly source: string;
}
export declare class SourceTransformer {
    #private;
    constructor(options: LoaderOptions);
    /**
     * Transpiles `filePath` for Node, or returns `undefined` when the file is
     * JavaScript that needs no work. `format` is what Node's `load` hook was
     * told; it decides `sourceType` and the format handed back.
     */
    transform(filePath: string, format: string | null | undefined): TransformedSource | undefined;
}
//# sourceMappingURL=transform.d.ts.map