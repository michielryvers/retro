import type { LoaderHooks } from "./hooks.ts";
export interface NamespaceOptions {
    /**
     * Isolates one import graph in Node's module cache: every file URL the
     * graph resolves carries this namespace as a query parameter, so the same
     * files import again as fresh modules under a new namespace. This is how
     * `alchemy dev` reloads the user's stack.
     */
    readonly namespace: string;
    /** Controls which file URLs belong to the graph. */
    readonly shouldInvalidate?: ((url: string, parentURL: string | undefined) => boolean) | undefined;
    /** Called once the runtime loads a file in the graph. */
    readonly onImport?: ((url: string) => void) | undefined;
}
/**
 * `hooks` scoped to one namespaced graph. A graph's entry carries the
 * namespace itself (see `importNamespaced`); everything it imports inherits
 * it from the importing module's URL. Specifiers from any other graph pass
 * straight through, and the underlying hooks never see a namespace: it is
 * stripped before they run and added back to what they resolve.
 *
 * CommonJS members are the exception to inheritance by URL: Node's CommonJS
 * loader addresses modules by path, so a member's `require()` calls arrive
 * with a plain file URL as parent and what they load has none either. The
 * graph therefore also remembers its members by clean URL, so those files
 * are resolved by the same hooks and reported through `onImport` too. They
 * do stay in Node's path-keyed CommonJS cache across generations.
 */
export declare const namespaced: (hooks: LoaderHooks, options: NamespaceOptions) => LoaderHooks;
/**
 * Imports a file as the entry of `namespace`'s graph. `specifier` is a file
 * URL, an absolute path, or a path relative to `parentURL`.
 */
export declare const importNamespaced: <T>(specifier: string, parentURL: string, namespace: string) => Promise<T>;
//# sourceMappingURL=namespace.d.ts.map