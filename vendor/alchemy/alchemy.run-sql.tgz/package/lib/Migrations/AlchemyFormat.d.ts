import * as Effect from "effect/Effect";
import { MigrationError, type MigrationApplyError, type MigrationHistoryConflictError, type MigrationRecord, type SqlExecutor } from "./Format.ts";
export declare const ALCHEMY_DEFAULT_TABLE = "__alchemy_migrations";
/**
 * Apply pending migrations with Alchemy's bookkeeping. Idempotent: each
 * migration's statements and its bookkeeping INSERT go through
 * `executor.batch` as one unit (a transaction on pg/mysql, one batched
 * query on D1, which has no transactions over HTTP). Nontransactional DDL
 * targets can supply `applyMigration` to checkpoint individual statements.
 *
 * Applied-detection is name-keyed with layout aliasing: pre-registry
 * Alchemy recorded drizzle-layout migrations under `<dir>/migration.sql`
 * while current records key them by `<dir>`, so both keys are honored.
 * An already-applied name whose local hash changed, or a recorded name
 * with no local file, is a hard {@link RewrittenMigrationHistoryError}
 * rather than a silent skip that would persist the new hashes.
 */
export declare const applyAlchemyFormat: (options: {
    executor: SqlExecutor;
    table: string;
    records: ReadonlyArray<MigrationRecord>;
}) => Effect.Effect<void, MigrationApplyError>;
/**
 * {@link applyAlchemyFormat} without the rewritten-history check: applied
 * names are skipped regardless of their hash. For runtime appliers (Durable
 * Object SQLite) where failing would take every instance down after a
 * deploy that already succeeded.
 */
export declare const applyPendingAlchemyFormat: (options: {
    executor: SqlExecutor;
    table: string;
    records: ReadonlyArray<MigrationRecord>;
}) => Effect.Effect<void, MigrationError | MigrationHistoryConflictError>;
//# sourceMappingURL=AlchemyFormat.d.ts.map