import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import { MigrationError, type MigrationRecord } from "./Format.ts";
export { DRIZZLE_DIR_PATTERN, inlineSqlParams, quoteIdentifier, sqlLiteral, timestampPrefixMillis, } from "./Utils.ts";
/** Map filesystem failures into the migration error channel. */
export declare const mapPlatformError: <A, E, R>(effect: Effect.Effect<A, E, R>, context: string) => Effect.Effect<A, MigrationError, R>;
/**
 * Read a drizzle-v1-layout directory (`{ts}_{name}/migration.sql`) into
 * records keyed the way drizzle keys them: `name` = the directory name,
 * sorted by name (drizzle's own sort), hash = sha256 of `migration.sql`.
 */
export declare const readDrizzleDirRecords: (dir: string) => Effect.Effect<MigrationRecord[], MigrationError, FileSystem.FileSystem | Path.Path>;
/**
 * Read a flat directory of `.sql` files into records keyed by relative file
 * path — the convention wrangler and legacy Alchemy state share. Nested
 * `dir/migration.sql` paths are included (via `listSqlFiles`'s recursive
 * listing) so legacy state written against drizzle-layout dirs keeps
 * resolving.
 */
export declare const readFlatRecords: (dir: string) => Effect.Effect<MigrationRecord[], MigrationError, FileSystem.FileSystem | Path.Path>;
/** Read migration records using the directory's detected layout. */
export declare const readMigrationRecords: (dir: string) => Effect.Effect<MigrationRecord[], import("./Format.ts").DrizzleV0LayoutError | MigrationError, FileSystem.FileSystem | Path.Path>;
//# sourceMappingURL=Records.d.ts.map