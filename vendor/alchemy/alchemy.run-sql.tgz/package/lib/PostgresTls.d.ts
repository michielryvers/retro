import type * as PgClient from "@effect/sql-pg/PgClient";
import * as Redacted from "effect/Redacted";
type PgSsl = PgClient.PgPoolConfig["ssl"];
/**
 * Resolve the `ssl` option to hand `@effect/sql-pg` for a connection URL.
 *
 * When the caller left `ssl` implicit and the URL's `sslmode` is `prefer` or
 * `allow`, returns `ssl: true` so the connection is TLS-on exactly as it was
 * under node-postgres. Railway's `no-verify` mode defaults to TLS without
 * certificate verification. Explicit caller settings take precedence, and
 * other URL modes keep driving the decision inside `@effect/sql-pg`.
 *
 * (`@effect/sql-pg` < rc.115 also sent no TLS SNI; that was fixed upstream in
 * Effect-TS/effect#8174, so this helper no longer sets `servername`.)
 */
export declare const resolveSsl: (url: Redacted.Redacted<string>, ssl: PgSsl) => PgSsl;
/**
 * Normalize the URL and TLS settings together for Effect's Postgres driver.
 * Translate node-postgres's `sslmode=no-verify` to `require` with explicit
 * TLS options so it also works with stricter URL parsers. Retain its verification
 * choice in the TLS options. Other URL parameters and explicit TLS settings
 * remain intact; credentials stay redacted.
 */
export declare const resolveConnectionOptions: (url: Redacted.Redacted<string>, ssl?: PgSsl) => {
    url: Redacted.Redacted<string>;
    ssl: PgSsl;
};
/**
 * The `@effect/sql-pg` pool config for a connection URL plus caller options.
 * Options such as `prepare` or pool limits pass through; the URL and TLS come
 * from {@link resolveConnectionOptions}, honoring an explicit `ssl` option.
 */
export declare const resolvePoolConfig: (url: Redacted.Redacted<string>, options?: Omit<PgClient.PgPoolConfig, "url">) => PgClient.PgPoolConfig;
export {};
//# sourceMappingURL=PostgresTls.d.ts.map