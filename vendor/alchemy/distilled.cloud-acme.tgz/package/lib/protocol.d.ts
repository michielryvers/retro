import * as API from "@distilled.cloud/core/api";
import { type ConfigError } from "@distilled.cloud/core/errors";
import * as HttpClient from "effect/http/HttpClient";
import type * as HttpClientError from "effect/http/HttpClientError";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
import type * as AST from "effect/SchemaAST";
import { Credentials } from "./credentials.ts";
import { type DefaultErrors } from "./errors.ts";
/**
 * Error channel shared by every generated ACME operation. Generated service
 * files annotate operations with `API.OperationMethod<I, O, AcmeOpError,
 * AcmeOpContext>` explicitly so the compiler never infers these back out of
 * the schema generics.
 */
export type AcmeOpError = DefaultErrors | ConfigError | HttpClientError.HttpClientError;
/** Context (requirements) shared by every generated ACME operation. */
export type AcmeOpContext = Credentials | HttpClient.HttpClient;
export declare const AcmeProtocol: Layer.Layer<API.Protocol>;
/** Forget cached directories and nonces (tests, CA switches). */
export declare const resetProtocolCaches: () => void;
/** @internal re-exported for tests */
export declare const _internal: {
    getAnn: (ast: AST.AST, symbol: symbol) => unknown;
    Redacted: typeof Redacted;
};
//# sourceMappingURL=protocol.d.ts.map