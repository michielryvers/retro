/**
 * JOSE helpers for ACME -- hand-written, WebCrypto only (no native code).
 *
 * - account keys (ES256 P-256 by default, RS256 accepted)
 * - JWS in the flattened JSON serialization every ACME POST carries
 *   (RFC 8555 §6.2), including the HS256 External Account Binding
 * - RFC 7638 JWK thumbprints, key authorizations and the DNS-01 TXT value
 */
import * as Effect from "effect/Effect";
import * as Redacted from "effect/Redacted";
import { JoseError } from "./errors.ts";
export type Algorithm = "ES256" | "RS256";
export interface Jwk {
    readonly kty: string;
    readonly crv?: string;
    readonly x?: string;
    readonly y?: string;
    readonly n?: string;
    readonly e?: string;
    readonly d?: string;
    readonly [key: string]: unknown;
}
export declare const base64url: (bytes: Uint8Array | ArrayBuffer) => string;
export declare const base64urlDecode: (text: string) => Uint8Array;
/** Detect the JWS algorithm for a JWK. */
export declare const algorithmOf: (jwk: Jwk) => Algorithm;
/** Generate a fresh account key as a private JWK (JSON text, Redacted). */
export declare const generateAccountKey: (alg?: Algorithm) => Effect.Effect<Redacted.Redacted<string>>;
/** Parse a private JWK from its JSON text. */
export declare const parseJwk: (key: Redacted.Redacted<string> | string) => Effect.Effect<Jwk, JoseError>;
/** The public half of a JWK, with members in RFC 7638 canonical order. */
export declare const publicJwk: (jwk: Jwk) => Jwk;
/** RFC 7638 JWK thumbprint (base64url SHA-256 of the canonical public JWK). */
export declare const thumbprint: (jwk: Jwk) => Effect.Effect<string>;
/** `<token>.<thumbprint>` -- what a challenge proves the client holds. */
export declare const keyAuthorization: (token: string, jwk: Jwk) => Effect.Effect<string>;
/** The TXT record value for a DNS-01 challenge: base64url(SHA-256(keyAuthorization)). */
export declare const dnsChallengeValue: (token: string, jwk: Jwk) => Effect.Effect<string>;
export interface FlattenedJws {
    readonly protected: string;
    readonly payload: string;
    readonly signature: string;
}
export interface SignOptions {
    readonly jwk: Jwk;
    readonly url: string;
    readonly nonce: string;
    /** Sent as `kid` when known; otherwise the public JWK is embedded. */
    readonly kid?: string | undefined;
    /** `undefined` produces a POST-as-GET (empty payload). */
    readonly payload?: unknown;
}
/** Sign an ACME request body (RFC 8555 §6.2) with the account key. */
export declare const signRequest: (options: SignOptions) => Effect.Effect<FlattenedJws, JoseError>;
/**
 * The External Account Binding JWS (RFC 8555 §7.3.4): HS256 over the
 * account's public JWK, keyed by the CA-issued HMAC key, with the CA's key
 * id as `kid`.
 */
export declare const signExternalAccountBinding: (options: {
    readonly jwk: Jwk;
    readonly url: string;
    readonly keyId: string;
    readonly hmacKey: Redacted.Redacted<string> | string;
}) => Effect.Effect<FlattenedJws, JoseError>;
//# sourceMappingURL=jose.d.ts.map