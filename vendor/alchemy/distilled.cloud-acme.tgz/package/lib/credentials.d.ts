import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
/** Well-known ACME directories. */
export declare const Directories: {
    readonly LetsEncrypt: "https://acme-v02.api.letsencrypt.org/directory";
    readonly LetsEncryptStaging: "https://acme-staging-v02.api.letsencrypt.org/directory";
    readonly ZeroSSL: "https://acme.zerossl.com/v2/DV90";
    readonly GoogleTrustServices: "https://dv.acme-v02.api.pki.goog/directory";
    readonly GoogleTrustServicesStaging: "https://dv.acme-v02.test-api.pki.goog/directory";
};
export interface ExternalAccountBinding {
    /** The CA-issued EAB key id. */
    readonly keyId: string;
    /** The CA-issued base64url HMAC key. */
    readonly hmacKey: Redacted.Redacted<string>;
}
export interface Config {
    /** The CA's directory URL. */
    readonly directoryUrl: string;
    /**
     * The account's private key as a JSON Web Key (JSON text). ES256 (`EC`
     * P-256) by default; RS256 (`RSA`) is accepted.
     */
    readonly accountKey: Redacted.Redacted<string>;
    /**
     * The account URL the CA assigned (`Location` of `newAccount`). Sent as
     * `kid` on every request once known; `newAccount` uses the bare JWK.
     */
    readonly accountUrl?: string | undefined;
    /** EAB for CAs that require it (ZeroSSL, Google Trust Services). */
    readonly externalAccountBinding?: ExternalAccountBinding | undefined;
}
declare const Credentials_base: Context.ServiceClass<Credentials, "AcmeCredentials", Effect.Effect<Config, never, never>>;
export declare class Credentials extends /*@__PURE__*/ Credentials_base {
}
/**
 * Credentials from the environment:
 *
 * - `ACME_DIRECTORY_URL` (default: Let's Encrypt production)
 * - `ACME_ACCOUNT_KEY` -- the private JWK as JSON
 * - `ACME_ACCOUNT_URL` -- optional, once the account exists
 * - `ACME_EAB_KID` / `ACME_EAB_HMAC_KEY` -- optional EAB pair
 */
export declare const CredentialsFromEnv: Layer.Layer<Credentials, never, never>;
/** A fixed credentials layer (tests, and consumers that manage keys themselves). */
export declare const layer: (config: Config | Effect.Effect<Config>) => Layer.Layer<Credentials, never, never>;
export {};
//# sourceMappingURL=credentials.d.ts.map