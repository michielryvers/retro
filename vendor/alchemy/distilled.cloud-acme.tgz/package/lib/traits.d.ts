/**
 * ACME SDK trait surface -- hand-written.
 *
 * Re-exports the generic protocol traits from core so generated operations
 * import everything from one place (`import * as T from "../traits.ts"`).
 * ACME is JWS-signed JSON, so
 * there are no ACME-specific traits -- the REST-protocol traits
 * (`SensitiveValue` / `RawResponse` / `RawResponseRoot`) come from
 * `core/protocol-rest`.
 */
export { SensitiveValue, RawResponse, RawResponseRoot, sensitiveValueSymbol, rawResponseSymbol, rawResponseRootSymbol, } from "@distilled.cloud/core/protocol-rest";
export { Body, Header, Query, Label, Http, ResponseCode, HttpBody, FormDataFile, KeyDictionary, UnionCases, applyErrorMatchers, getErrorMatchers, type HttpTrait, type ErrorMatcher, bodySymbol, headerSymbol, querySymbol, labelSymbol, httpSymbol, responseCodeSymbol, httpBodySymbol, formDataFileSymbol, keyDictionarySymbol, unionCasesSymbol, errorMatchersSymbol, } from "@distilled.cloud/core/trait";
//# sourceMappingURL=traits.d.ts.map