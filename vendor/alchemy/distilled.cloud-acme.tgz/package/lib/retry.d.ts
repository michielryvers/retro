import { type Policy } from "@distilled.cloud/core/retry";
/**
 * ACME retry configuration.
 *
 * Defines the per-SDK `Retry` Context.Service tag that generated operations
 * wire into `API.make({ retry: Retry.Retry })`. Callers can install a
 * blanket retry policy at the layer level and have every ACME call
 * below it pick it up:
 *
 * @example
 * ```ts
 * import * as Acme from "@distilled.cloud/acme";
 *
 * myEffect.pipe(Acme.Retry.transient);
 * Effect.provide(myEffect, Layer.succeed(Acme.Retry.Retry, customPolicy));
 * ```
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
export { type Options, type Factory, type Policy, makeDefault, jittered, capped, throttlingOptions, transientOptions, throttlingFactory, transientFactory, } from "@distilled.cloud/core/retry";
declare const Retry_base: Context.ServiceClass<Retry, "AcmeRetry", Policy>;
/** Context tag for configuring retry behavior of ACME calls. */
export declare class Retry extends /*@__PURE__*/ Retry_base {
}
/** Provides a custom retry policy to every ACME call below it. */
export declare const policy: (optionsOrFactory: Policy) => <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
/** Disables all automatic retries. */
export declare const none: <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
/** Apply the throttling retry policy (retries throttling errors indefinitely). */
export declare const throttling: <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
/** Apply the transient retry policy (retries all transient errors indefinitely). */
export declare const transient: <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
//# sourceMappingURL=retry.d.ts.map