/**
 * ACME-specific error types.
 *
 * ACME reports failures as RFC 7807 problem documents whose `type` is a
 * `urn:ietf:params:acme:error:*` URN (RFC 8555 §6.7). Every URN the SDK
 * knows is a typed class in the generated service (patched onto the
 * operations that raise it, matched on the URN by the protocol). This
 * module holds the shared HTTP defaults and the package's own client
 * errors.
 */
export { BadGateway, BadRequest, Conflict, ConfigError, Forbidden, GatewayTimeout, InternalServerError, Locked, NotFound, ServiceUnavailable, TooManyRequests, Unauthorized, UnprocessableEntity, HTTP_STATUS_MAP, DEFAULT_ERRORS, API_ERRORS, } from "@distilled.cloud/core/errors";
import type { BadRequest as CoreBadRequest, Conflict as CoreConflict, DefaultErrors as CoreDefaultErrors, Forbidden as CoreForbidden, NotFound as CoreNotFound } from "@distilled.cloud/core/errors";
import * as Schema from "@distilled.cloud/core/schema-lite-typed";
declare const UnknownAcmeError_base: Schema.TaggedErrorClass<"UnknownAcmeError", {
    /** The problem `type` URN, when the body was a problem document. */
    readonly type: import("effect/Schema").optional<import("effect/Schema").String>;
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
    readonly status: import("effect/Schema").optional<import("effect/Schema").Number>;
    readonly detail: import("effect/Schema").optional<import("effect/Schema").String>;
    readonly subproblems: import("effect/Schema").optional<Schema.$Array<import("effect/Schema").Unknown>>;
    readonly body: import("effect/Schema").Unknown;
}>;
/**
 * Unknown ACME error -- a problem document whose `type` matches no typed
 * class on the operation. Carries structured problem fields and a redacted
 * body. Add newly observed URNs to the authored model.
 */
export declare class UnknownAcmeError extends /*@__PURE__*/ UnknownAcmeError_base {
}
declare const AcmeParseError_base: Schema.TaggedErrorClass<"AcmeParseError", {
    readonly body: import("effect/Schema").Unknown;
    readonly cause: import("effect/Schema").Unknown;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ParseError: true;
    };
});
/** Schema parse error wrapper. */
export declare class AcmeParseError extends /*@__PURE__*/ AcmeParseError_base {
}
declare const JoseError_base: Schema.TaggedErrorClass<"JoseError", {
    readonly message: import("effect/Schema").String;
    readonly cause: import("effect/Schema").optional<import("effect/Schema").Unknown>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** The account key could not be parsed or used to sign (client-side). */
export declare class JoseError extends /*@__PURE__*/ JoseError_base {
}
declare const DirectoryMissingResource_base: Schema.TaggedErrorClass<"DirectoryMissingResource", {
    readonly resource: import("effect/Schema").String;
    readonly directoryUrl: import("effect/Schema").String;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/**
 * The directory has no URL for the requested resource (a CA without
 * `newAuthz`/`keyChange`, or a stale directory URL).
 */
export declare class DirectoryMissingResource extends /*@__PURE__*/ DirectoryMissingResource_base {
}
/** Errors any ACME operation may surface beyond the core HTTP defaults. */
export type ClientErrors = UnknownAcmeError | AcmeParseError | JoseError | DirectoryMissingResource;
/**
 * Default ACME operation errors: the shared HTTP status errors from core plus
 * the client errors above.
 */
export type DefaultErrors = CoreDefaultErrors | CoreBadRequest | CoreForbidden | CoreNotFound | CoreConflict | ClientErrors;
//# sourceMappingURL=errors.d.ts.map