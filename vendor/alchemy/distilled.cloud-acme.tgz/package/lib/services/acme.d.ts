import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type AcmeOpError, type AcmeOpContext } from "../protocol.ts";
export type { AcmeOpError, AcmeOpContext };
declare const AcmeAccountDoesNotExist_base: S.TaggedErrorClass<"AcmeAccountDoesNotExist", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The request specified an account that does not exist. */
export declare class AcmeAccountDoesNotExist extends /*@__PURE__*/ AcmeAccountDoesNotExist_base {
}
declare const AcmeAlreadyRevoked_base: S.TaggedErrorClass<"AcmeAlreadyRevoked", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The request specified a certificate to be revoked that has already been revoked. */
export declare class AcmeAlreadyRevoked extends /*@__PURE__*/ AcmeAlreadyRevoked_base {
}
declare const AcmeBadCsr_base: S.TaggedErrorClass<"AcmeBadCsr", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The CSR is unacceptable (e.g., due to a short key). */
export declare class AcmeBadCsr extends /*@__PURE__*/ AcmeBadCsr_base {
}
declare const AcmeBadNonce_base: S.TaggedErrorClass<"AcmeBadNonce", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The client sent an unacceptable anti-replay nonce. */
export declare class AcmeBadNonce extends /*@__PURE__*/ AcmeBadNonce_base {
}
declare const AcmeBadPublicKey_base: S.TaggedErrorClass<"AcmeBadPublicKey", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The JWS was signed by a public key the server does not support. */
export declare class AcmeBadPublicKey extends /*@__PURE__*/ AcmeBadPublicKey_base {
}
declare const AcmeBadRevocationReason_base: S.TaggedErrorClass<"AcmeBadRevocationReason", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The revocation reason provided is not allowed by the server. */
export declare class AcmeBadRevocationReason extends /*@__PURE__*/ AcmeBadRevocationReason_base {
}
declare const AcmeBadSignatureAlgorithm_base: S.TaggedErrorClass<"AcmeBadSignatureAlgorithm", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The JWS was signed with an algorithm the server does not support. */
export declare class AcmeBadSignatureAlgorithm extends /*@__PURE__*/ AcmeBadSignatureAlgorithm_base {
}
declare const AcmeCaa_base: S.TaggedErrorClass<"AcmeCaa", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** Certification Authority Authorization (CAA) records forbid the CA from issuing a certificate. */
export declare class AcmeCaa extends /*@__PURE__*/ AcmeCaa_base {
}
declare const AcmeConnection_base: S.TaggedErrorClass<"AcmeConnection", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The server could not connect to validation target. */
export declare class AcmeConnection extends /*@__PURE__*/ AcmeConnection_base {
}
declare const AcmeDns_base: S.TaggedErrorClass<"AcmeDns", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** There was a problem with a DNS query during identifier validation. */
export declare class AcmeDns extends /*@__PURE__*/ AcmeDns_base {
}
declare const AcmeExternalAccountRequired_base: S.TaggedErrorClass<"AcmeExternalAccountRequired", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The request must include a value for the "externalAccountBinding" field. */
export declare class AcmeExternalAccountRequired extends /*@__PURE__*/ AcmeExternalAccountRequired_base {
}
declare const AcmeIncorrectResponse_base: S.TaggedErrorClass<"AcmeIncorrectResponse", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** Response received didn't match the challenge's requirements. */
export declare class AcmeIncorrectResponse extends /*@__PURE__*/ AcmeIncorrectResponse_base {
}
declare const AcmeInvalidContact_base: S.TaggedErrorClass<"AcmeInvalidContact", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** A contact URL for an account was invalid. */
export declare class AcmeInvalidContact extends /*@__PURE__*/ AcmeInvalidContact_base {
}
declare const AcmeMalformed_base: S.TaggedErrorClass<"AcmeMalformed", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The request message was malformed. */
export declare class AcmeMalformed extends /*@__PURE__*/ AcmeMalformed_base {
}
declare const AcmeOrderNotReady_base: S.TaggedErrorClass<"AcmeOrderNotReady", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The request attempted to finalize an order that is not ready to be finalized. */
export declare class AcmeOrderNotReady extends /*@__PURE__*/ AcmeOrderNotReady_base {
}
declare const AcmeRateLimited_base: S.TaggedErrorClass<"AcmeRateLimited", {
    readonly retryAfter: any;
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
/** The request exceeds a rate limit. */
export declare class AcmeRateLimited extends /*@__PURE__*/ AcmeRateLimited_base {
}
declare const AcmeRejectedIdentifier_base: S.TaggedErrorClass<"AcmeRejectedIdentifier", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The server will not issue certificates for the identifier. */
export declare class AcmeRejectedIdentifier extends /*@__PURE__*/ AcmeRejectedIdentifier_base {
}
declare const AcmeServerInternal_base: S.TaggedErrorClass<"AcmeServerInternal", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
/** The server experienced an internal error. */
export declare class AcmeServerInternal extends /*@__PURE__*/ AcmeServerInternal_base {
}
declare const AcmeTls_base: S.TaggedErrorClass<"AcmeTls", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The server received a TLS error during validation. */
export declare class AcmeTls extends /*@__PURE__*/ AcmeTls_base {
}
declare const AcmeUnauthorized_base: S.TaggedErrorClass<"AcmeUnauthorized", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** The client lacks sufficient authorization. */
export declare class AcmeUnauthorized extends /*@__PURE__*/ AcmeUnauthorized_base {
}
declare const AcmeUnsupportedContact_base: S.TaggedErrorClass<"AcmeUnsupportedContact", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** A contact URL for an account used an unsupported protocol scheme. */
export declare class AcmeUnsupportedContact extends /*@__PURE__*/ AcmeUnsupportedContact_base {
}
declare const AcmeUnsupportedIdentifier_base: S.TaggedErrorClass<"AcmeUnsupportedIdentifier", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** An identifier is of an unsupported type. */
export declare class AcmeUnsupportedIdentifier extends /*@__PURE__*/ AcmeUnsupportedIdentifier_base {
}
declare const AcmeUserActionRequired_base: S.TaggedErrorClass<"AcmeUserActionRequired", {
    readonly code: any;
    readonly message: any;
    readonly type: any;
    readonly detail: any;
}>;
/** Visit the "instance" URL and take actions specified there. */
export declare class AcmeUserActionRequired extends /*@__PURE__*/ AcmeUserActionRequired_base {
}
export interface DeactivateAuthorizationRequest {
    /** Absolute URL of the resource, as returned by the CA. */
    url: string;
    /** Always `deactivated`. */
    status: string;
}
export interface Identifier {
    /** The type of identifier. This document defines the "dns" identifier type. See the registry defined in Section 9.7.7 for any others. */
    type: string;
    /** The identifier itself. */
    value: string;
}
export interface Subproblem {
    /** The error type URI. */
    type?: string;
    /** A human-readable explanation. */
    detail?: string;
    /** The identifier this subproblem is about. */
    identifier?: Identifier;
}
export type ProblemSubproblemsList = Array<Subproblem>;
/** RFC 7807 problem document (RFC 8555 §6.7). */
export interface Problem {
    /** The error type URI, e.g. `urn:ietf:params:acme:error:malformed`. */
    type?: string;
    /** A human-readable explanation. */
    detail?: string;
    /** The HTTP status code. */
    status?: number;
    /** A URI reference identifying this occurrence. */
    instance?: string;
    /** The identifier the error relates to. */
    identifier?: Identifier;
    /** Errors for individual identifiers (RFC 8555 §6.7.1). */
    subproblems?: ProblemSubproblemsList;
}
/** RFC 8555 §8 */
export interface Challenge {
    /** The type of challenge encoded in the object. */
    type: string;
    /** The URL to which a response can be posted. */
    url: string;
    /** The status of this challenge. Possible values are "pending", "processing", "valid", and "invalid" (see Section 7.1.6). */
    status: string;
    /** The time at which the server validated this challenge, encoded in the format specified in [RFC3339]. This field is REQUIRED if the "status" field is "valid". */
    validated?: string;
    /** A random value that uniquely identifies the challenge. This value MUST have at least 128 bits of entropy. It MUST NOT contain any characters outside the base64url alphabet and MUST NOT include base64 padding characters ("="). See [RFC4086] for additional information on randomness requirements. */
    token?: string;
    /** Error that occurred while the server was validating the challenge, if any, structured as a problem document [RFC7807]. Multiple errors can be indicated by using subproblems Section 6.7.1. A challenge object with an error MUST have status equal to "invalid". */
    error?: Problem;
}
export type AuthorizationChallengesList = Array<Challenge>;
/** RFC 8555 §7.1.4 */
export interface Authorization {
    /** The identifier that the account is authorized to represent. */
    identifier: Identifier;
    /** The status of this authorization. Possible values are "pending", "valid", "invalid", "deactivated", "expired", and "revoked". See Section 7.1.6. */
    status: string;
    /** The timestamp after which the server will consider this authorization invalid, encoded in the format specified in [RFC3339]. This field is REQUIRED for objects with "valid" in the "status" field. */
    expires?: string;
    /** For pending authorizations, the challenges that the client can fulfill in order to prove possession of the identifier. For valid authorizations, the challenge that was validated. For invalid authorizations, the challenge that was attempted and failed. Each array entry is an object with parameters required to validate the challenge. A client should attempt to fulfill one of these challenges, and a server should consider any one of the challenges sufficient to make the authorization valid. */
    challenges: AuthorizationChallengesList;
    /** This field MUST be present and true for authorizations created as a result of a newOrder request containing a DNS identifier with a value that was a wildcard domain name. For other authorizations, it MUST be absent. Wildcard domain names are described in Section 7.1.3. */
    wildcard?: boolean;
}
export interface DownloadCertificateRequest {
    /** Absolute URL of the resource, as returned by the CA. */
    url: string;
}
/** Alternate chain URLs from `Link: <url>;rel="alternate"` headers. */
export type CertificateChainAlternatesList = Array<string>;
export interface CertificateChain {
    /** PEM certificate chain (`application/pem-certificate-chain`), leaf first. */
    chain: string;
    /** Alternate chain URLs from `Link: <url>;rel="alternate"` headers. */
    alternates?: CertificateChainAlternatesList;
}
export interface FinalizeOrderRequest {
    /** Absolute URL of the resource, as returned by the CA. */
    url: string;
    /** A CSR encoding the parameters for the certificate being requested [RFC2986]. The CSR is sent in the base64url-encoded version of the DER format. (Note: Because this field uses base64url, and does not include headers, it is different from PEM.) */
    csr: string;
}
export type OrderResponseIdentifiersList = Array<Identifier>;
export type OrderResponseAuthorizationsList = Array<string>;
/** RFC 8555 §7.1.3, plus the `Location` header as `location`. */
export interface OrderResponse {
    /** The status of this order. Possible values are "pending", "ready", "processing", "valid", and "invalid". See Section 7.1.6. */
    status: string;
    /** The timestamp after which the server will consider this order invalid, encoded in the format specified in [RFC3339]. This field is REQUIRED for objects with "pending" or "valid" in the status field. */
    expires?: string;
    /** An array of identifier objects that the order pertains to. */
    identifiers: OrderResponseIdentifiersList;
    /** The requested value of the notBefore field in the certificate, in the date format defined in [RFC3339]. */
    notBefore?: string;
    /** The requested value of the notAfter field in the certificate, in the date format defined in [RFC3339]. */
    notAfter?: string;
    /** The error that occurred while processing the order, if any. This field is structured as a problem document [RFC7807]. */
    error?: Problem;
    /** For pending orders, the authorizations that the client needs to complete before the requested certificate can be issued (see Section 7.5), including unexpired authorizations that the client has completed in the past for identifiers specified in the order. The authorizations required are dictated by server policy; there may not be a 1:1 relationship between the order identifiers and the authorizations required. For final orders (in the "valid" or "invalid" state), the authorizations that were completed. Each entry is a URL from which an authorization can be fetched with a POST-as-GET request. */
    authorizations: OrderResponseAuthorizationsList;
    /** A URL that a CSR must be POSTed to once all of the order's authorizations are satisfied to finalize the order. The result of a successful finalization will be the population of the certificate URL for the order. */
    finalize: string;
    /** A URL for the certificate that has been issued in response to this order. */
    certificate?: string;
    /** The order URL (`Location` header). */
    location?: string;
}
export interface GetAuthorizationRequest {
    /** Absolute URL of the resource, as returned by the CA. */
    url: string;
}
export interface GetDirectoryRequest {
}
export type DirectoryMetaCaaIdentitiesList = Array<string>;
export interface DirectoryMeta {
    /** A URL identifying the current terms of service. */
    termsOfService?: string;
    /** An HTTP or HTTPS URL locating a website providing more information about the ACME server. */
    website?: string;
    /** The hostnames that the ACME server recognizes as referring to itself for the purposes of CAA record validation as defined in [RFC6844]. Each string MUST represent the same sequence of ASCII code points that the server will expect to see as the "Issuer Domain Name" in a CAA issue or issuewild property tag. This allows clients to determine the correct issuer domain name to use when configuring CAA records. */
    caaIdentities?: DirectoryMetaCaaIdentitiesList;
    /** If this field is present and set to "true", then the CA requires that all newAccount requests include an "externalAccountBinding" field associating the new account with an external account. */
    externalAccountRequired?: boolean;
}
/** RFC 8555 §7.1.1 */
export interface Directory {
    /** URL of the new nonce resource. */
    newNonce: string;
    /** URL of the new account resource. */
    newAccount: string;
    /** URL of the new order resource. */
    newOrder: string;
    /** URL of the new authorization resource. */
    newAuthz?: string;
    /** URL of the revoke certificate resource. */
    revokeCert: string;
    /** URL of the key change resource. */
    keyChange?: string;
    /** Metadata relating to the service provided by the ACME server. */
    meta?: DirectoryMeta;
}
export interface GetOrderRequest {
    /** Absolute URL of the resource, as returned by the CA. */
    url: string;
}
export type NewAccountRequestContactList = Array<string>;
/** A JWS binding this account to an existing CA account (RFC 8555 §7.3.4). The protocol builds it from the credentials' EAB key id and HMAC key. */
export interface ExternalAccountBinding {
    protected: string;
    payload: string;
    signature: string;
}
export interface NewAccountRequest {
    /** Same meaning as the corresponding server field defined in Section 7.1.2. */
    contact?: NewAccountRequestContactList;
    /** Same meaning as the corresponding server field defined in Section 7.1.2. */
    termsOfServiceAgreed?: boolean;
    /** If this field is present with the value "true", then the server MUST NOT create a new account if one does not already exist. This allows a client to look up an account URL based on an account key (see Section 7.3.1). */
    onlyReturnExisting?: boolean;
    /** Same meaning as the corresponding server field defined in Section 7.1.2 */
    externalAccountBinding?: ExternalAccountBinding;
}
export type AccountResponseContactList = Array<string>;
/** RFC 8555 §7.1.2, plus the `Location` header as `location`. */
export interface AccountResponse {
    /** The status of this account. Possible values are "valid", "deactivated", and "revoked". The value "deactivated" should be used to indicate client-initiated deactivation whereas "revoked" should be used to indicate server- initiated deactivation. See Section 7.1.6. */
    status: string;
    /** An array of URLs that the server can use to contact the client for issues related to this account. For example, the server may wish to notify the client about server-initiated revocation or certificate expiration. For information on supported URL schemes, see Section 7.3. */
    contact?: AccountResponseContactList;
    /** Including this field in a newAccount request, with a value of true, indicates the client's agreement with the terms of service. This field cannot be updated by the client. */
    termsOfServiceAgreed?: boolean;
    /** A URL from which a list of orders submitted by this account can be fetched via a POST-as-GET request, as described in Section 7.1.2.1. */
    orders?: string;
    /** The account URL (`Location` header); the `kid` for every later request. */
    location?: string;
}
export interface NewNonceRequest {
}
export interface NonceResponse {
    /** The `Replay-Nonce` header. */
    replayNonce: string;
}
export type NewOrderRequestIdentifiersList = Array<Identifier>;
export interface NewOrderRequest {
    /** An array of identifier objects that the client wishes to submit an order for. */
    identifiers: NewOrderRequestIdentifiersList;
    /** The requested value of the notBefore field in the certificate, in the date format defined in [RFC3339]. */
    notBefore?: string;
    /** The requested value of the notAfter field in the certificate, in the date format defined in [RFC3339]. */
    notAfter?: string;
}
export interface RespondChallengeRequest {
    /** Absolute URL of the resource, as returned by the CA. */
    url: string;
}
export interface RevokeCertificateRequest {
    /** The certificate to be revoked, in the base64url-encoded version of the DER format. (Note: Because this field uses base64url, and does not include headers, it is different from PEM.) */
    certificate: string;
    /** One of the revocation reasonCodes defined in Section 5.3.1 of [RFC5280] to be used when generating OCSP responses and CRLs. If this field is not set, the server SHOULD omit the reasonCode CRL entry extension when generating OCSP responses and CRLs. The server MAY disallow a subset of reasonCodes from being used by the user. If a request contains a disallowed reasonCode, then the server MUST reject it with the error type "urn:ietf:params:acme:error:badRevocationReason". The problem document detail SHOULD indicate which reasonCodes are allowed. */
    reason?: number;
}
export interface RevokeCertificateResponse {
}
export type UpdateAccountRequestContactList = Array<string>;
export interface UpdateAccountRequest {
    /** Absolute URL of the resource, as returned by the CA. */
    url: string;
    /** An array of URLs that the server can use to contact the client for issues related to this account. For example, the server may wish to notify the client about server-initiated revocation or certificate expiration. For information on supported URL schemes, see Section 7.3. */
    contact?: UpdateAccountRequestContactList;
    /** `deactivated` to deactivate the account (RFC 8555 §7.3.6). */
    status?: string;
}
export type DeactivateAuthorizationError = AcmeAccountDoesNotExist | AcmeBadNonce | AcmeMalformed | AcmeRateLimited | AcmeServerInternal | AcmeUnauthorized | AcmeOpError;
/** Deactivate the authorization at `url` */
export declare const deactivateAuthorization: API.OperationMethod<DeactivateAuthorizationRequest, Authorization, DeactivateAuthorizationError, AcmeOpContext>;
export type DownloadCertificateError = AcmeAccountDoesNotExist | AcmeBadNonce | AcmeMalformed | AcmeRateLimited | AcmeServerInternal | AcmeUnauthorized | AcmeOpError;
/** Download the PEM certificate chain at `url` (POST-as-GET) */
export declare const downloadCertificate: API.OperationMethod<DownloadCertificateRequest, CertificateChain, DownloadCertificateError, AcmeOpContext>;
export type FinalizeOrderError = AcmeAccountDoesNotExist | AcmeBadCsr | AcmeBadNonce | AcmeMalformed | AcmeOrderNotReady | AcmeRateLimited | AcmeServerInternal | AcmeUnauthorized | AcmeOpError;
/** Submit the CSR to the order's finalize URL */
export declare const finalizeOrder: API.OperationMethod<FinalizeOrderRequest, OrderResponse, FinalizeOrderError, AcmeOpContext>;
export type GetAuthorizationError = AcmeAccountDoesNotExist | AcmeBadNonce | AcmeMalformed | AcmeRateLimited | AcmeServerInternal | AcmeUnauthorized | AcmeOpError;
/** Fetch the authorization at `url` (POST-as-GET) */
export declare const getAuthorization: API.OperationMethod<GetAuthorizationRequest, Authorization, GetAuthorizationError, AcmeOpContext>;
export type GetDirectoryError = AcmeOpError;
/** Fetch the CA's directory of resource URLs */
export declare const getDirectory: API.OperationMethod<GetDirectoryRequest, Directory, GetDirectoryError, AcmeOpContext>;
export type GetOrderError = AcmeAccountDoesNotExist | AcmeBadNonce | AcmeMalformed | AcmeRateLimited | AcmeServerInternal | AcmeUnauthorized | AcmeOpError;
/** Fetch the order at `url` (POST-as-GET) */
export declare const getOrder: API.OperationMethod<GetOrderRequest, OrderResponse, GetOrderError, AcmeOpContext>;
export type NewAccountError = AcmeAccountDoesNotExist | AcmeBadNonce | AcmeBadPublicKey | AcmeBadSignatureAlgorithm | AcmeExternalAccountRequired | AcmeInvalidContact | AcmeMalformed | AcmeRateLimited | AcmeServerInternal | AcmeUnauthorized | AcmeUnsupportedContact | AcmeUserActionRequired | AcmeOpError;
/** Create an account, or find the existing account for this key */
export declare const newAccount: API.OperationMethod<NewAccountRequest, AccountResponse, NewAccountError, AcmeOpContext>;
export type NewNonceError = AcmeOpError;
/** Get a fresh anti-replay nonce (the `Replay-Nonce` header) */
export declare const newNonce: API.OperationMethod<NewNonceRequest, NonceResponse, NewNonceError, AcmeOpContext>;
export type NewOrderError = AcmeAccountDoesNotExist | AcmeBadNonce | AcmeMalformed | AcmeRateLimited | AcmeRejectedIdentifier | AcmeServerInternal | AcmeUnauthorized | AcmeUnsupportedIdentifier | AcmeUserActionRequired | AcmeOpError;
/** Create an order for a set of identifiers */
export declare const newOrder: API.OperationMethod<NewOrderRequest, OrderResponse, NewOrderError, AcmeOpContext>;
export type RespondChallengeError = AcmeAccountDoesNotExist | AcmeBadNonce | AcmeCaa | AcmeConnection | AcmeDns | AcmeIncorrectResponse | AcmeMalformed | AcmeRateLimited | AcmeServerInternal | AcmeTls | AcmeUnauthorized | AcmeOpError;
/** Tell the CA the challenge at `url` is ready to be validated */
export declare const respondChallenge: API.OperationMethod<RespondChallengeRequest, Challenge, RespondChallengeError, AcmeOpContext>;
export type RevokeCertificateError = AcmeAccountDoesNotExist | AcmeAlreadyRevoked | AcmeBadNonce | AcmeBadRevocationReason | AcmeMalformed | AcmeRateLimited | AcmeServerInternal | AcmeUnauthorized | AcmeOpError;
/** Revoke a certificate */
export declare const revokeCertificate: API.OperationMethod<RevokeCertificateRequest, RevokeCertificateResponse, RevokeCertificateError, AcmeOpContext>;
export type UpdateAccountError = AcmeAccountDoesNotExist | AcmeBadNonce | AcmeInvalidContact | AcmeMalformed | AcmeRateLimited | AcmeServerInternal | AcmeUnauthorized | AcmeUnsupportedContact | AcmeOpError;
/** Update (or deactivate) the account at `url` */
export declare const updateAccount: API.OperationMethod<UpdateAccountRequest, AccountResponse, UpdateAccountError, AcmeOpContext>;
//# sourceMappingURL=acme.d.ts.map