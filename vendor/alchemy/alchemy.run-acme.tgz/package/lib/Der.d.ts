/**
 * A minimal DER encoder/decoder — just enough ASN.1 for a PKCS#10
 * certificate request (encode) and reading a certificate's serial,
 * validity, issuer and subject alternative names (decode). Pure
 * TypeScript; no native code, no dependency, works on workerd.
 *
 * @internal
 */
export declare const concat: (...parts: ReadonlyArray<Uint8Array>) => Uint8Array;
/** Tag-length-value. */
export declare const tlv: (tag: number, body: Uint8Array) => Uint8Array;
export declare const sequence: (...items: ReadonlyArray<Uint8Array>) => Uint8Array<ArrayBufferLike>;
export declare const set: (...items: ReadonlyArray<Uint8Array>) => Uint8Array<ArrayBufferLike>;
export declare const octetString: (body: Uint8Array) => Uint8Array<ArrayBufferLike>;
export declare const bitString: (body: Uint8Array) => Uint8Array<ArrayBufferLike>;
export declare const nullValue: () => Uint8Array<ArrayBuffer>;
export declare const ia5String: (text: string) => Uint8Array<ArrayBufferLike>;
export declare const utf8String: (text: string) => Uint8Array<ArrayBufferLike>;
/** Context-specific constructed tag `[n]` (implicit or explicit, caller's choice of body). */
export declare const contextTag: (n: number, body: Uint8Array) => Uint8Array<ArrayBufferLike>;
/** Context-specific primitive tag `[n]` (e.g. GeneralName dNSName is `[2]`). */
export declare const contextPrimitive: (n: number, body: Uint8Array) => Uint8Array<ArrayBufferLike>;
/** INTEGER from a non-negative number or big-endian magnitude bytes. */
export declare const integer: (value: number | Uint8Array) => Uint8Array;
/** OBJECT IDENTIFIER from dotted notation. */
export declare const oid: (dotted: string) => Uint8Array;
export interface Node {
    readonly tag: number;
    /** Offset of the first content byte. */
    readonly start: number;
    /** Offset one past the last content byte. */
    readonly end: number;
    readonly bytes: Uint8Array;
}
export declare const read: (bytes: Uint8Array, offset: number) => Node;
/** The children of a constructed node, in order. */
export declare const children: (node: Node) => Node[];
export declare const content: (node: Node) => Uint8Array;
export declare const decodeOid: (node: Node) => string;
/** Parse UTCTime (`YYMMDDHHMMSSZ`) or GeneralizedTime (`YYYYMMDDHHMMSSZ`). */
export declare const decodeTime: (node: Node) => Date;
export declare const toHex: (bytes: Uint8Array) => string;
//# sourceMappingURL=Der.d.ts.map