/**
 * The ACME issuance flow shared by the `Certificate` resource (deploy time)
 * and the `IssueCertificate` binding (runtime):
 *
 *   order → DNS-01 per authorization (present → propagated → respond →
 *   poll) → finalize with a fresh key's CSR → download → parse.
 *
 * The wire is `@distilled.cloud/acme`; this file only sequences it.
 */
import * as Acme from "@distilled.cloud/acme";
import * as acme from "@distilled.cloud/acme/acme";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
import type { CertificateAuthority } from "./CertificateAuthority.ts";
import { type PropagationOptions } from "./Dns.ts";
import type { DnsSolver } from "./DnsSolver.ts";
import { ChallengeFailed, ChallengeUnsupported, OrderInvalid, OrderTimeout, PkiError, type DnsPropagationTimeout, type DnsSolverError } from "./Errors.ts";
import { type KeyAlgorithm } from "./Pki.ts";
/** Everything the flow needs to sign requests as an account. */
export interface AccountCredentials {
    readonly ca: CertificateAuthority;
    /** The account's private JWK (JSON). */
    readonly accountKey: Redacted.Redacted<string>;
    /** The account URL (`kid`), once the account exists. */
    readonly accountUrl?: string | undefined;
    readonly externalAccountBinding?: {
        readonly keyId: string;
        readonly hmacKey: Redacted.Redacted<string>;
    } | undefined;
}
/**
 * The SDK's `Credentials` (+ a CA-trusting `HttpClient` for private CAs)
 * for one account. Provide around any `@distilled.cloud/acme` call.
 */
export declare const accountLayer: (credentials: AccountCredentials) => Layer.Layer<Acme.Credentials | HttpClient.HttpClient>;
export interface IssueRequest<R = never> {
    /** DNS names; the first is the subject CN. Wildcards allowed. */
    readonly identifiers: ReadonlyArray<string>;
    readonly solver: DnsSolver<R>;
    /** @default "ES256" */
    readonly keyAlgorithm?: KeyAlgorithm | undefined;
    /** Issuer name (`CN=...` substring) to prefer when the CA offers alternate chains. */
    readonly preferredChain?: string | undefined;
    readonly propagation?: PropagationOptions | undefined;
}
export interface IssuedCertificate {
    /** Leaf certificate PEM. */
    readonly certificate: string;
    /** Full chain PEM, leaf first. */
    readonly chain: string;
    /** PKCS#8 private key PEM. */
    readonly privateKey: Redacted.Redacted<string>;
    readonly identifiers: ReadonlyArray<string>;
    readonly serial: string;
    /** ISO 8601. */
    readonly notBefore: string;
    /** ISO 8601. */
    readonly notAfter: string;
    readonly issuer: string;
    /** The CA's certificate URL (for re-download and revocation bookkeeping). */
    readonly certificateUrl: string;
    readonly orderUrl: string;
}
export type IssueError = OrderInvalid | ChallengeFailed | ChallengeUnsupported | OrderTimeout | DnsPropagationTimeout | DnsSolverError | PkiError | Acme.JoseError | acme.NewOrderError | acme.GetAuthorizationError | acme.RespondChallengeError | acme.FinalizeOrderError | acme.GetOrderError | acme.DownloadCertificateError;
/**
 * Issue a certificate for `identifiers` as the current `Credentials`
 * account. Requires the SDK's `Credentials` and an `HttpClient` (see
 * {@link accountLayer}) plus whatever the solver needs.
 */
export declare const issueCertificate: <R = never>(request: IssueRequest<R>) => Effect.Effect<IssuedCertificate, IssueError, Acme.Credentials | HttpClient.HttpClient | R>;
/** RFC 5280 revocation reasons. */
export type RevocationReason = "unspecified" | "keyCompromise" | "affiliationChanged" | "superseded" | "cessationOfOperation";
export interface RevokeRequest {
    /** Leaf certificate PEM. */
    readonly certificate: string;
    /**
     * The certificate's private key. When given, the request is signed with
     * it (RFC 8555 §7.6) so no account is needed; otherwise the ambient
     * account credentials sign.
     */
    readonly privateKey?: Redacted.Redacted<string> | string | undefined;
    readonly reason?: RevocationReason | undefined;
}
export type RevokeError = PkiError | acme.RevokeCertificateError;
/** Revoke a certificate. `AcmeAlreadyRevoked` is folded into success. */
export declare const revokeCertificate: (request: RevokeRequest) => Effect.Effect<void, RevokeError, Acme.Credentials | HttpClient.HttpClient>;
//# sourceMappingURL=Client.d.ts.map