/**
 * Keys, PKCS#10 certificate requests and X.509 parsing for the ACME flow.
 * WebCrypto plus the tiny DER codec in `Der.ts` — no native code, so the
 * same code runs at deploy time and inside a Worker or Fly Service.
 */
import * as Effect from "effect/Effect";
import * as Redacted from "effect/Redacted";
import { PkiError } from "./Errors.ts";
export type KeyAlgorithm = "ES256" | "RS256";
/** The DER bytes of the first (or `index`-th) PEM block in `pem`. */
export declare const fromPem: (pem: string, index?: number) => Uint8Array;
/** Every PEM block in a chain, leaf first. */
export declare const splitPemChain: (pem: string) => string[];
export interface GeneratedKey {
    readonly algorithm: KeyAlgorithm;
    /** PKCS#8 PEM. */
    readonly privateKeyPem: Redacted.Redacted<string>;
    readonly privateKey: CryptoKey;
    /** SubjectPublicKeyInfo DER. */
    readonly spki: Uint8Array;
}
/** Generate a certificate key pair (ES256 P-256 by default). */
export declare const generateKey: (algorithm?: KeyAlgorithm) => Effect.Effect<GeneratedKey, PkiError>;
/** Import a PKCS#8 PEM private key (ES256 or RS256, detected from the DER). */
export declare const importPrivateKey: (pem: Redacted.Redacted<string> | string) => Effect.Effect<{
    readonly key: CryptoKey;
    readonly algorithm: KeyAlgorithm;
}, PkiError>;
/** The private JWK of a PKCS#8 PEM key (for revocation signed by the certificate key). */
export declare const privateKeyToJwk: (pem: Redacted.Redacted<string> | string) => Effect.Effect<Redacted.Redacted<string>, PkiError>;
/**
 * A PKCS#10 certificate request for `identifiers` signed by `key`: the
 * first identifier is the subject CN, all of them are `subjectAltName`
 * dNSName entries. Returned as DER.
 */
export declare const createCsr: (options: {
    readonly key: GeneratedKey;
    readonly identifiers: ReadonlyArray<string>;
}) => Effect.Effect<Uint8Array, PkiError>;
/** base64url of a DER CSR, as ACME's `finalize` expects. */
export declare const csrToBase64Url: (der: Uint8Array) => string;
export interface ParsedCertificate {
    /** Serial number as lowercase hex. */
    readonly serial: string;
    readonly notBefore: Date;
    readonly notAfter: Date;
    /** Issuer distinguished name, `CN` first (`CN=R11, O=Let's Encrypt`). */
    readonly issuer: string;
    /** Subject distinguished name in the same form. */
    readonly subject: string;
    /** `subjectAltName` dNSName entries. */
    readonly dnsNames: ReadonlyArray<string>;
}
/** Parse the first certificate of a PEM (or a DER buffer). */
export declare const parseCertificate: (input: string | Uint8Array) => Effect.Effect<ParsedCertificate, PkiError>;
//# sourceMappingURL=Pki.d.ts.map