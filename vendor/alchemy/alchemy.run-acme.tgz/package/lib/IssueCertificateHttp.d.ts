import * as Layer from "effect/Layer";
import { IssueCertificate } from "./IssueCertificate.ts";
/**
 * Implementation of {@link IssueCertificate}: the account's directory
 * URL, account URL and private key are bound into the host at deploy time
 * and read back at runtime; every call signs with them over HTTPS.
 *
 * Provide it on the Worker / Service / Action Effect.
 *
 * ### Provide the layer
 * **Example:** On a Fly Service
 * ```typescript
 * Effect.gen(function* () {
 *   const acme = yield* ACME.IssueCertificate(LetsEncrypt);
 *   // ...
 * }).pipe(Effect.provide(ACME.IssueCertificateHttp))
 * ```
 *
 * @layer
 * @product Certificate
 * @provides ACME.IssueCertificate
 */
export declare const IssueCertificateHttp: Layer.Layer<IssueCertificate, never, never>;
//# sourceMappingURL=IssueCertificateHttp.d.ts.map