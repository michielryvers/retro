import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Redacted from "effect/Redacted";
import type { CertificateAuthority } from "./CertificateAuthority.ts";
import type { KeyAlgorithm } from "./Pki.ts";
import type { Providers } from "./Providers.ts";
export interface ExternalAccountBinding {
    /** The key id the CA issued (ZeroSSL: `eab_kid`). */
    keyId: string;
    /** The base64url HMAC key the CA issued (ZeroSSL: `eab_hmac_key`). */
    hmacKey: Redacted.Redacted<string> | string;
}
export interface AccountProps {
    /**
     * The certificate authority: a preset ({@link LetsEncrypt},
     * {@link ZeroSSL}, …) or `{ directoryUrl }`. Changing it replaces the
     * account.
     */
    ca: CertificateAuthority;
    /**
     * Contact URLs (`mailto:…`) the CA notifies about expiry and incidents.
     * Updated in place.
     */
    contact?: string[];
    /**
     * You must agree to the CA's terms of service. Explicit on purpose —
     * never defaulted.
     */
    termsOfServiceAgreed: true;
    /**
     * External Account Binding for CAs that require one (ZeroSSL, Google
     * Trust Services). Changing the key id replaces the account.
     */
    eab?: ExternalAccountBinding;
    /**
     * Account key algorithm. Changing it replaces the account.
     * @default "ES256"
     */
    keyAlgorithm?: KeyAlgorithm;
}
export interface Account extends Resource<"ACME.Account", AccountProps, {
    /** The CA's directory URL. */
    directoryUrl: string;
    /** PEM root trusted for the CA's HTTPS endpoint (private CAs only). */
    trustedRoot: string | undefined;
    /** The account URL the CA assigned — the `kid` on every later request. */
    accountUrl: string;
    /** Observed account status (`valid`, `deactivated`, `revoked`). */
    status: string;
    /** Observed contact URLs. */
    contact: string[];
    /** Account key algorithm. */
    keyAlgorithm: KeyAlgorithm;
    /** The account's private JWK (JSON). Sensitive; persisted in stack state. */
    privateKey: Redacted.Redacted<string>;
}, never, Providers> {
}
/**
 * An ACME account with a certificate authority — the identity that every
 * {@link Certificate} and every runtime {@link IssueCertificate} call
 * signs with. One per CA per stack.
 *
 * The account key is generated on first reconcile and persisted as a
 * redacted value alongside the CA's account URL. Protect the state store
 * as secret material; redaction alone does not encrypt the storage backend.
 *
 * ### Let's Encrypt
 * **Example:** An account with Let's Encrypt
 * ```typescript
 * export const LetsEncrypt = ACME.Account("LetsEncrypt", {
 *   ca: ACME.LetsEncrypt,
 *   contact: ["mailto:ops@example.com"],
 *   termsOfServiceAgreed: true,
 * });
 * ```
 *
 * ### External Account Binding
 * ZeroSSL and Google Trust Services bind ACME accounts to an existing
 * customer account with a key id + HMAC pair from their dashboard (ZeroSSL
 * also mints them over its REST API — see `@distilled.cloud/zerossl`).
 *
 * **Example:** ZeroSSL
 * ```typescript
 * export const ZeroSsl = ACME.Account("ZeroSSL", {
 *   ca: ACME.ZeroSSL,
 *   eab: {
 *     keyId: Config.String("ZEROSSL_EAB_KID"),
 *     hmacKey: Config.Redacted("ZEROSSL_EAB_HMAC_KEY"),
 *   },
 *   termsOfServiceAgreed: true,
 * });
 * ```
 *
 * ### Private CAs
 * A private CA (Pebble, step-ca) whose HTTPS certificate is not publicly
 * trusted passes its root as `trustedRoot`.
 *
 * **Example:** Pebble
 * ```typescript
 * export const Pebble = ACME.Account("Pebble", {
 *   ca: { directoryUrl: "https://localhost:14000/dir", trustedRoot: pebbleRootPem },
 *   termsOfServiceAgreed: true,
 * });
 * ```
 *
 * @resource
 * @product Account
 * @category Certificates
 */
export declare const Account: import("alchemy/Resource").ResourceClass<Account>;
declare const AccountUrlMissing_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ACME.AccountUrlMissing";
} & Readonly<A>;
/** The CA answered `newAccount` without a `Location`, so the account has no URL. */
export declare class AccountUrlMissing extends AccountUrlMissing_base<{
    readonly directoryUrl: string;
}> {
}
export declare const AccountProvider: () => import("effect/Layer").Layer<Provider.Provider<Account>, never, never>;
export {};
//# sourceMappingURL=Account.d.ts.map