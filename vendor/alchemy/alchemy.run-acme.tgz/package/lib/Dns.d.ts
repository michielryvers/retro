/**
 * TXT propagation checks.
 *
 * Public recursive resolvers are a poor oracle: they cache negative
 * answers for the zone's SOA minimum (30 minutes is common) and old
 * record sets past their TTL, so a challenge value published a moment ago
 * can stay invisible for far longer than the CA takes to validate. Where
 * `node:dns` is available (deploy time, Fly Machines) the check therefore
 * asks the zone's **authoritative** nameservers directly — the same
 * servers the CA asks. Networks can intercept port 53, so DNS over HTTPS
 * also checks for the exact challenge value. A stale recursive cache must
 * not veto a positive answer; the CA performs its own validation.
 */
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import { DnsPropagationTimeout } from "./Errors.ts";
export interface PropagationOptions {
    /**
     * Wait before the first lookup to avoid caching an unpublished record.
     * Outside the polling budget. Cloudflare defaults to 60 seconds.
     * @default "0 seconds"
     */
    readonly initialDelay?: Duration.Input | undefined;
    /**
     * Extra wait after the record is seen (or, for solvers that skip the
     * check, the whole wait): anycast edges lag the first one that answers.
     * @default "5 seconds"
     */
    readonly delay?: Duration.Input | undefined;
    /**
     * DNS-over-HTTPS JSON endpoints to use instead of automatic discovery.
     * When supplied, every resolver must return the record. Automatic lookup
     * accepts all discovered nameservers or any default DoH resolver.
     * @default Cloudflare (1.1.1.1) and Google public DNS
     */
    readonly resolvers?: ReadonlyArray<string> | undefined;
    /** Polling budget. @default "45 seconds" */
    readonly timeout?: Duration.Input | undefined;
    /** Polling interval. @default "3 seconds" */
    readonly interval?: Duration.Input | undefined;
}
export declare const DEFAULT_PROPAGATION_DELAY: Duration.Input;
/** Sleep `options.delay` (default 5 seconds). */
export declare const propagationDelay: (options?: PropagationOptions) => Effect.Effect<void>;
export declare const DEFAULT_RESOLVERS: ReadonlyArray<string>;
/**
 * TXT values for `fqdn` from one DoH resolver. Any transport or parse
 * failure reads as "no records yet".
 */
export declare const resolveTxt: (resolver: string, fqdn: string) => Effect.Effect<ReadonlyArray<string>, never, HttpClient.HttpClient>;
/**
 * Wait `initialDelay`, then poll for the exact challenge value and wait
 * `delay`. Explicit resolvers must all agree; automatic lookup accepts all
 * discovered nameservers or a positive default DoH answer. Discovery and
 * polling share `timeout`; the delays before and after are outside it.
 */
export declare const waitForTxt: (fqdn: string, value: string, options?: PropagationOptions) => Effect.Effect<void, DnsPropagationTimeout, HttpClient.HttpClient>;
//# sourceMappingURL=Dns.d.ts.map