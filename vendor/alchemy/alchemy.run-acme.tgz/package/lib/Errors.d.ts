/** A problem the CA attached to an order or one of its identifiers. */
export interface IdentifierProblem {
    /** The identifier the problem concerns, when the CA said. */
    readonly identifier?: string | undefined;
    /** The `urn:ietf:params:acme:error:*` type. */
    readonly type?: string | undefined;
    /** Human-readable detail from the CA. */
    readonly detail?: string | undefined;
}
declare const OrderInvalid_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ACME.OrderInvalid";
} & Readonly<A>;
/**
 * The CA moved the order to `invalid`. Carries the problem documents the
 * order and its authorizations reported, one per failed identifier where
 * the CA said which.
 */
export declare class OrderInvalid extends OrderInvalid_base<{
    readonly orderUrl: string;
    readonly problems: ReadonlyArray<IdentifierProblem>;
}> {
    get message(): string;
}
declare const ChallengeFailed_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ACME.ChallengeFailed";
} & Readonly<A>;
/** The CA rejected the DNS-01 challenge for one identifier. */
export declare class ChallengeFailed extends ChallengeFailed_base<{
    readonly identifier: string;
    readonly type?: string | undefined;
    readonly detail?: string | undefined;
}> {
    get message(): string;
}
declare const ChallengeUnsupported_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ACME.ChallengeUnsupported";
} & Readonly<A>;
/** The CA offered no `dns-01` challenge for an identifier. */
export declare class ChallengeUnsupported extends ChallengeUnsupported_base<{
    readonly identifier: string;
    readonly offered: ReadonlyArray<string>;
}> {
    get message(): string;
}
declare const OrderTimeout_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ACME.OrderTimeout";
} & Readonly<A>;
/** The order never reached a terminal state within the polling budget. */
export declare class OrderTimeout extends OrderTimeout_base<{
    readonly orderUrl: string;
    readonly status: string;
}> {
    get message(): string;
}
declare const DnsPropagationTimeout_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ACME.DnsPropagationTimeout";
} & Readonly<A>;
/** The `_acme-challenge` TXT record never became visible to public resolvers. */
export declare class DnsPropagationTimeout extends DnsPropagationTimeout_base<{
    readonly fqdn: string;
    readonly value: string;
}> {
    get message(): string;
}
declare const DnsSolverError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ACME.DnsSolverError";
} & Readonly<A>;
/** A DNS solver could not publish or remove a challenge record. */
export declare class DnsSolverError extends DnsSolverError_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
declare const DnsSolverNotRegistered_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ACME.DnsSolverNotRegistered";
} & Readonly<A>;
/** A solver descriptor names a `type` no registered DNS provider handles. */
export declare class DnsSolverNotRegistered extends DnsSolverNotRegistered_base<{
    readonly type: string;
}> {
    get message(): string;
}
declare const PkiError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ACME.PkiError";
} & Readonly<A>;
/** Key generation, CSR encoding or certificate parsing failed. */
export declare class PkiError extends PkiError_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
export {};
//# sourceMappingURL=Errors.d.ts.map