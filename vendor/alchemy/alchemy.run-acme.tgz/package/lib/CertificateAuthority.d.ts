/**
 * An ACME certificate authority: its directory URL plus, for private CAs
 * (Pebble, step-ca), the PEM root that signs the CA's own HTTPS endpoint.
 */
export interface CertificateAuthority {
    /** The CA's ACME directory URL. */
    readonly directoryUrl: string;
    /**
     * PEM root certificate to trust for the CA's HTTPS endpoint. Only for
     * private CAs whose API certificate is not publicly trusted; public CAs
     * leave it unset.
     */
    readonly trustedRoot?: string | undefined;
}
/** Let's Encrypt production. No External Account Binding. */
export declare const LetsEncrypt: CertificateAuthority;
/** Let's Encrypt staging: generous limits, untrusted chain. */
export declare const LetsEncryptStaging: CertificateAuthority;
/** ZeroSSL. Requires an External Account Binding (`eab`). */
export declare const ZeroSSL: CertificateAuthority;
/** Google Trust Services. Requires an External Account Binding (`eab`). */
export declare const GoogleTrustServices: CertificateAuthority;
/** Google Trust Services staging. */
export declare const GoogleTrustServicesStaging: CertificateAuthority;
//# sourceMappingURL=CertificateAuthority.d.ts.map