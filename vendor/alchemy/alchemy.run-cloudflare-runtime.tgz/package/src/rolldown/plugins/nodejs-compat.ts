import assert from "node:assert";
import { createRequire } from "node:module";
import path from "node:path";
import { getCloudflarePreset, nonPrefixedNodeModules } from "@cloudflare/unenv-preset";
import { defineEnv } from "unenv";
import { createPlugin } from "../factory.ts";
import { isSkippedEnvironment } from "../options.ts";
import type { BasePluginOptions } from "../options.ts";
import { hasNodejsAls, hasNodejsCompat, toPosixPath } from "../utils.ts";

const ASYNC_HOOKS_REGEXP = /^(node:)?async_hooks$/;
const NODE_BUILTIN_MODULES_REGEXP = new RegExp(`^(${nonPrefixedNodeModules.join("|")}|node:.+)$`);

export const nodejsAlsPlugin = createPlugin("nodejs-als", (options) => {
  if (!hasNodejsAls(options.compatibilityFlags)) return;
  return {
    rolldown: {
      resolveId: {
        filter: { id: ASYNC_HOOKS_REGEXP },
        handler(id) {
          return { id, external: true };
        },
      },
    },
    vite: {
      enforce: "pre",
      configEnvironment(name) {
        if (name === "client") return;
        return {
          resolve: {
            builtins: ["async_hooks", "node:async_hooks"],
          },
          optimizeDeps: {
            exclude: ["async_hooks", "node:async_hooks"],
          },
        };
      },
    },
  };
});

export interface UnenvApi {
  polyfill: ReadonlyArray<string>;
  inject: { [injectedName: string]: string };
}

export const getUnenv = (options: BasePluginOptions) =>
  defineEnv({
    presets: [
      getCloudflarePreset({
        compatibilityDate: options.compatibilityDate,
        compatibilityFlags: options.compatibilityFlags,
      }),
    ],
  }).env;

export const nodejsUnenvPlugin = createPlugin<"nodejs-unenv", UnenvApi>(
  "nodejs-unenv",
  (options) => {
    if (!hasNodejsCompat(options.compatibilityFlags, options.compatibilityDate)) return;
    const { alias, inject, polyfill, external } = getUnenv(options);
    const entries = new Set(Object.values(alias));
    for (const globalInject of Object.values(inject)) {
      if (typeof globalInject === "string") {
        entries.add(globalInject);
      } else {
        entries.add(globalInject[0]);
      }
    }
    polyfill.forEach((module) => entries.add(module));
    external.forEach((module) => entries.delete(module));
    const require = createRequire(import.meta.url);
    // `unresolved` is the polyfill's bare specifier: the key it is
    // pre-bundled under, shared by every import that aliases to it.
    const resolveNodejsImport = (id: string) => {
      if (alias[id] && !external.includes(alias[id])) {
        return { unresolved: alias[id], resolved: require.resolve(alias[id]) };
      }
      if (entries.has(id)) {
        return { unresolved: id, resolved: require.resolve(id) };
      }
    };
    const RESOLVE_ID_FILTER = {
      id: [NODE_BUILTIN_MODULES_REGEXP, /^unenv\//, /^@cloudflare\/unenv-preset\//],
    };
    return {
      shared: {
        api: {
          // Virtual entries have no package directory for bare-import resolution.
          polyfill: polyfill.map((id) => toPosixPath(require.resolve(id))),
          inject: Object.fromEntries(
            Object.entries(inject).map(([injectedName, moduleSpecifier]) => {
              assert(
                typeof moduleSpecifier === "string",
                `expected moduleSpecifier to be a string`,
              );
              return [injectedName, toPosixPath(require.resolve(moduleSpecifier))];
            }),
          ),
        },
      },
      rolldown: {
        resolveId: {
          filter: RESOLVE_ID_FILTER,
          handler(source, importer, options) {
            const result = resolveNodejsImport(source);
            if (!result) return;
            return this.resolve(result.resolved, importer, options);
          },
        },
      },
      vite: {
        enforce: "pre",
        async configEnvironment(name) {
          if (name === "client") return;
          const { esmExternalRequirePlugin } = await import("vite");
          return {
            resolve: {
              builtins: [...external],
            },
            ...(this.meta.rolldownVersion
              ? {
                  build: {
                    rolldownOptions: {
                      plugins: [
                        esmExternalRequirePlugin({
                          external: [...external],
                          skipDuplicateCheck: true,
                        }),
                      ],
                    },
                  },
                }
              : {}),
            optimizeDeps: {
              // (Node.js built-ins are excluded from pre-bundling for every
              // Worker environment by the options plugin.)
              ...(this.meta.rolldownVersion
                ? {
                    rolldownOptions: {
                      plugins: [
                        // In Vite 8, `require` calls are not automatically replaced when
                        // the format is ESM and `platform` is `neutral`.
                        esmExternalRequirePlugin({
                          external: [NODE_BUILTIN_MODULES_REGEXP],
                          skipDuplicateCheck: true,
                        }),
                      ],
                    },
                  }
                : {}),
            },
          };
        },
        async configureServer(server) {
          await Promise.all(
            Object.values(server.environments).flatMap(async (environment) => {
              // Framework-owned Node-side environments (e.g. Astro's `astro`
              // and `prerender`) must be left untouched — this is a
              // server-level hook, so `applyToEnvironment` cannot gate it.
              if (isSkippedEnvironment(options, environment.name)) return;
              const depsOptimizer = environment.depsOptimizer;
              if (!depsOptimizer) return;
              // Environments using Vite's no-discovery ("explicit") optimizer
              // throw on `registerMissingImport` by design; pre-bundling the
              // unenv polyfills is best-effort, so skip them.
              if (!supportsMissingImportRegistration(environment)) return;
              await depsOptimizer.init();
              return Array.from(entries).map((entry) => {
                const result = resolveNodejsImport(entry);
                if (!result) return;
                const registration = depsOptimizer.registerMissingImport(
                  result.unresolved,
                  result.resolved,
                );
                return registration?.processing;
              });
            }),
          );
        },
        resolveId: {
          filter: RESOLVE_ID_FILTER,
          handler(source, importer, options) {
            const result = resolveNodejsImport(source);
            if (!result) return;
            if (
              this.environment.mode === "dev" &&
              this.environment.depsOptimizer &&
              supportsMissingImportRegistration(this.environment)
            ) {
              // We are in dev mode (rather than build).
              // So let's pre-bundle this polyfill entry-point using the dependency optimizer.
              const { id } = this.environment.depsOptimizer.registerMissingImport(
                result.unresolved,
                result.resolved,
              );
              // We use the unresolved path to the polyfill and let the dependency optimizer's
              // resolver find the resolved path to the bundled version.
              return this.resolve(id, importer, options);
            }
            return this.resolve(result.resolved, importer, options);
          },
        },
      },
    };
  },
);

/**
 * Vite's no-discovery ("explicit") dependency optimizer throws on
 * `registerMissingImport` by design, and third-party environments may not
 * implement it at all. Feature-detect before registering polyfill entries.
 */
const supportsMissingImportRegistration = (environment: {
  config: { optimizeDeps?: { noDiscovery?: boolean } };
  depsOptimizer?: { registerMissingImport?: unknown } | undefined;
}): boolean =>
  environment.config.optimizeDeps?.noDiscovery !== true &&
  typeof environment.depsOptimizer?.registerMissingImport === "function";

export const nodejsImportWarningPlugin = createPlugin("nodejs-import-warning", (options) => {
  if (hasNodejsCompat(options.compatibilityFlags, options.compatibilityDate)) return;
  const imports = new Map<string, Set<string>>();
  let root = process.cwd();
  // In dev there is no `buildEnd` until the server closes, so, as
  // `@cloudflare/vite-plugin` does, warn once imports go quiet.
  const devImports = new Map<string, Set<string>>();
  let devTimer: ReturnType<typeof setTimeout> | undefined;
  const warnInDev = (environment: {
    name: string;
    logger: { warn: (message: string, options?: { timestamp?: boolean }) => void };
  }) => {
    if (devTimer) clearTimeout(devTimer);
    devTimer = setTimeout(() => {
      devTimer = undefined;
      if (devImports.size === 0) return;
      let message = `Unexpected Node.js imports for environment "${environment.name}". Do you need to enable the "nodejs_compat" compatibility flag? Refer to https://developers.cloudflare.com/workers/runtime-apis/nodejs/ for more details.\n`;
      for (const [id, importers] of devImports) {
        for (const importer of importers) {
          message += ` - "${id}" imported from "${toPosixPath(path.relative(root, importer))}"\n`;
        }
      }
      devImports.clear();
      environment.logger.warn(message, { timestamp: true });
    }, 500);
  };
  return {
    rolldown: {
      options(options) {
        if (options.cwd) {
          root = options.cwd;
        }
      },
    },
    vite: {
      enforce: "pre",
      configResolved(config) {
        root = config.root;
      },
    },
    shared: {
      buildStart() {
        imports.clear();
      },
      resolveId: {
        filter: { id: NODE_BUILTIN_MODULES_REGEXP },
        async handler(id, importer) {
          if (hasNodejsAls(options.compatibilityFlags) && ASYNC_HOOKS_REGEXP.test(id)) return;
          if (importer) {
            if (!imports.has(id)) {
              imports.set(id, new Set());
            }
            imports.get(id)?.add(importer);
            const environment = (
              this as {
                environment?: {
                  name: string;
                  mode: string;
                  logger: Parameters<typeof warnInDev>[0]["logger"];
                };
              }
            ).environment;
            if (environment?.mode === "dev") {
              if (!devImports.has(id)) devImports.set(id, new Set());
              devImports.get(id)?.add(importer);
              warnInDev(environment);
            }
          }
          return { id, external: true };
        },
      },
      buildEnd() {
        const filteredImports: Array<{ id: string; importer: string }> = [];
        for (const [id, importers] of imports.entries()) {
          for (const importer of importers) {
            if (this.getModuleInfo(importer)) {
              filteredImports.push({ id, importer });
            }
          }
        }
        if (filteredImports.length > 0) {
          const message = [
            "Unexpected Node.js imports. ",
            'Do you need to enable the "nodejs_compat" compatibility flag? ',
            "Refer to https://developers.cloudflare.com/workers/runtime-apis/nodejs/ for more details.\n",
            ...filteredImports.map(
              ({ id, importer }) =>
                ` - "${id}" imported from "${toPosixPath(path.relative(root, importer))}"\n`,
            ),
          ].join("");
          this.warn(message);
        }
      },
    },
  };
});
