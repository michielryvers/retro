module.exports = "world (.cjs)";
