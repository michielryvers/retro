import { expect, layer } from "@effect/vitest";
import * as Effect from "effect/Effect";
import { PATH_MODULE_RUNNER_INIT } from "../../globals/EntryOptions.shared.ts";
import {
  HEADER_ORIGINAL_URL,
  HEADER_PROXY_SHARED_SECRET,
} from "../../globals/ProxyHeaders.shared.ts";
import * as WorkerProxy from "../../proxy/WorkerProxy.ts";
import { getFixture } from "../helpers/fixture.ts";
import { localRuntimeLayer, startTestWorker } from "../helpers/runtime.ts";

layer(localRuntimeLayer, { excludeTestServices: true })((it) => {
  it.effect("routes only the module-runner init path directly past assets", () =>
    Effect.gen(function* () {
      const worker = yield* startTestWorker({
        name: "module-runner-routing",
        compatibilityDate: "2026-03-10",
        compatibilityFlags: [],
        bindings: [],
        assets: {
          directory: getFixture("assets"),
          runWorkerFirst: ["/api/*"],
          notFoundHandling: "single-page-application",
        },
        modules: [
          {
            name: "main.js",
            type: "ESModule",
            content: `export default { fetch() { return new Response("worker"); } };`,
          },
        ],
      });
      expect(yield* worker.fetchText(PATH_MODULE_RUNNER_INIT)).toBe("worker");
      for (const pathname of [
        "/dashboard",
        "/__vite_module_runner/init",
        `${PATH_MODULE_RUNNER_INIT}/other`,
        "/cdn-cgi/alchemy/other",
      ]) {
        expect(yield* worker.fetchText(pathname)).toBe("<h1>home</h1>\n");
      }
    }),
  );
  it.effect("preserves the proxy URL, Host, body and path across runtime restarts", () =>
    Effect.gen(function* () {
      const proxy = yield* WorkerProxy.WorkerProxy;
      const instance = yield* proxy.serve();
      // A server that fronts workerd itself (the vite plugin) signs its
      // forwarded requests with a secret of its own; the relay sends none.
      const proxySharedSecret = "test-proxy-secret";
      for (const name of ["first", "replacement"]) {
        const worker = yield* startTestWorker({
          name,
          proxySharedSecret,
          compatibilityDate: "2026-03-10",
          compatibilityFlags: [],
          bindings: [],
          modules: [
            {
              name: "main.js",
              type: "ESModule",
              content: `
            export default { async fetch(request) {
              return Response.json({ url: request.url, host: request.headers.get("host"),
                body: await request.text(),
                original: request.headers.get("Alchemy-Runtime-Original-URL"),
                secret: request.headers.get("Alchemy-Runtime-Proxy-Shared-Secret") });
            } };`,
            },
          ],
        });
        yield* instance.set(worker.baseUrl);
        const url = new URL(instance.url);
        url.pathname = "//callback/%2F";
        url.search = "?return=%2Fhome&x=1&x=2";
        // Moving the relay to the replacement resets connections pinned
        // to the previous worker (see WorkerProxy.test.ts), so no
        // keep-alive connection may carry over between rounds.
        const result = yield* Effect.promise(() =>
          fetch(url, { method: "POST", body: "hello", headers: { connection: "close" } }).then(
            (res) => res.json(),
          ),
        );
        expect(result).toEqual({
          url: url.href,
          host: url.host,
          body: "hello",
          original: null,
          secret: null,
        });
        // The proxy is a transparent relay, not a trusted proxy: it signs
        // nothing and strips nothing, so a client forging the trusted
        // headers through it is rejected exactly like a direct request.
        const forgedViaProxy = yield* Effect.promise(() =>
          fetch(url, {
            headers: {
              connection: "close",
              [HEADER_ORIGINAL_URL]: "https://forged.example/",
              [HEADER_PROXY_SHARED_SECRET]: "forged",
            },
          }),
        );
        expect(forgedViaProxy.status).toBe(400);

        const direct = yield* worker.fetchJson("/direct", {
          headers: { [HEADER_ORIGINAL_URL]: "https://forged.example/" },
        });
        expect(direct).toMatchObject({
          url: new URL("/direct", worker.baseUrl).href,
          original: null,
          secret: null,
        });
        const trusted = yield* worker.fetchJson("/callback", {
          headers: {
            [HEADER_ORIGINAL_URL]: "https://public.example:8443/callback?x=1",
            [HEADER_PROXY_SHARED_SECRET]: proxySharedSecret,
          },
        });
        expect(trusted).toMatchObject({
          url: "https://public.example:8443/callback?x=1",
          host: "public.example:8443",
          original: null,
          secret: null,
        });
        const forged = yield* worker.fetch("/direct", {
          headers: {
            [HEADER_ORIGINAL_URL]: "https://forged.example/",
            [HEADER_PROXY_SHARED_SECRET]: "forged",
          },
        });
        expect(forged.status).toBe(400);
      }
    }),
  );
});
