import * as NodeOs from "node:os";
import * as Config from "effect/Config";
import * as Effect from "effect/Effect";

export const home = Config.String("CLOUDFLARE_RUNTIME_HOME").pipe(
  Effect.orElseSucceed(() => NodeOs.homedir()),
);

export const fileSystemSupportsWatcher = Config.Boolean(
  "CLOUDFLARE_RUNTIME_FILE_SYSTEM_SUPPORTS_WATCHER",
).pipe(Effect.orElseSucceed(() => NodeOs.platform() !== "win32"));
