/**
 * Cloudflare-specific error types.
 */
export { BadGateway, BadRequest, Conflict, ConfigError, Forbidden, GatewayTimeout, InternalServerError, NotFound, ServiceUnavailable, TooManyRequests, Unauthorized, UnprocessableEntity, HTTP_STATUS_MAP, DEFAULT_ERRORS, API_ERRORS, } from "@distilled.cloud/core/errors";
import type { DefaultErrors as CoreDefaultErrors } from "@distilled.cloud/core/errors";
import * as Schema from "@distilled.cloud/core/schema-lite-typed";
declare const CloudflareParseError_base: Schema.TaggedErrorClass<"CloudflareParseError", {
    readonly body: import("effect/Schema").Unknown;
    readonly cause: import("effect/Schema").Unknown;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ParseError: true;
    };
});
export declare class CloudflareParseError extends /*@__PURE__*/ CloudflareParseError_base {
}
declare const UnknownCloudflareError_base: Schema.TaggedErrorClass<"UnknownCloudflareError", {
    readonly code: import("effect/Schema").optional<import("effect/Schema").Number>;
    readonly message: import("effect/Schema").String;
}>;
/**
 * Unknown Cloudflare error - returned when an error code is not recognized.
 * Contains the raw error code for later cataloging.
 */
export declare class UnknownCloudflareError extends /*@__PURE__*/ UnknownCloudflareError_base {
}
declare const InvalidRoute_base: Schema.TaggedErrorClass<"InvalidRoute", {
    readonly code: import("effect/Schema").optional<import("effect/Schema").Number>;
    readonly message: import("effect/Schema").String;
}>;
/**
 * Cloudflare error code 7003 -- "invalid request: invalid route". Returned when
 * a path component (typically accountId / zoneId) doesn't match a real
 * Cloudflare resource. Mapped globally so every operation surfaces it as
 * InvalidRoute rather than UnknownCloudflareError.
 *
 * Per-operation patches that explicitly map code 7003 still produce their
 * service-local InvalidRoute class with the same `_tag`, so test assertions
 * on `e._tag === "InvalidRoute"` work for both global and per-op variants.
 */
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const CloudflareHttpError_base: Schema.TaggedErrorClass<"CloudflareHttpError", {
    readonly status: import("effect/Schema").Number;
    readonly statusText: import("effect/Schema").String;
    readonly message: import("effect/Schema").String;
    readonly body: import("effect/Schema").optional<import("effect/Schema").String>;
}>;
/**
 * HTTP error - non-2xx response without a parseable Cloudflare error body.
 */
export declare class CloudflareHttpError extends /*@__PURE__*/ CloudflareHttpError_base {
}
/**
 * Errors that any Cloudflare operation may surface in addition to status/code-
 * matched API errors declared per endpoint.
 */
export type ClientErrors = CloudflareHttpError | CloudflareParseError | InvalidRoute | UnknownCloudflareError;
/**
 * Default Cloudflare operation errors include the shared HTTP status errors from
 * core plus the client-level fallback/decode errors that the Cloudflare client
 * can emit at runtime.
 */
export type DefaultErrors = CoreDefaultErrors | ClientErrors;
/** A single `{ code, message }` entry from the envelope's `errors` array. */
export interface CloudflareApiError {
    readonly code?: number;
    readonly message: string;
}
declare const CloudflareError_base: Schema.TaggedErrorClass<"CloudflareError", {
    readonly status: import("effect/Schema").Number;
    readonly errors: Schema.$Array<import("effect/Schema").Struct<{
        readonly code: import("effect/Schema").optional<import("effect/Schema").Number>;
        readonly message: import("effect/Schema").String;
    }>>;
}>;
/**
 * Legacy generic Cloudflare API error. The protocol no longer constructs
 * this (failures map to the distilled-compatible DefaultErrors classes
 * above); it remains exported because generated operations reference it in
 * their `errors` lists.
 */
export declare class CloudflareError extends /*@__PURE__*/ CloudflareError_base {
}
declare const CloudflareRateLimited_base: Schema.TaggedErrorClass<"CloudflareRateLimited", {
    readonly status: import("effect/Schema").Number;
    readonly errors: Schema.$Array<import("effect/Schema").Struct<{
        readonly code: import("effect/Schema").optional<import("effect/Schema").Number>;
        readonly message: import("effect/Schema").String;
    }>>;
}> & (new (...args: any[]) => {
    "@distilled/meta/error-categories": {
        "@distilled/errors/retryable": true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
/** Legacy rate-limit error -- see {@link CloudflareError}'s note. */
export declare class CloudflareRateLimited extends /*@__PURE__*/ CloudflareRateLimited_base {
}
//# sourceMappingURL=errors.d.ts.map