import { ConfigError } from "@distilled.cloud/core/errors";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
export declare const DEFAULT_API_BASE_URL = "https://api.cloudflare.com/client/v4";
export interface ApiTokenConfig {
    readonly apiToken: Redacted.Redacted<string>;
    readonly apiBaseUrl?: string;
}
export interface ApiKeyConfig {
    readonly apiKey: Redacted.Redacted<string>;
    readonly email: string;
    readonly apiBaseUrl?: string;
}
export interface OAuthConfig {
    readonly accessToken: Redacted.Redacted<string>;
    readonly refreshToken?: Redacted.Redacted<string>;
    readonly expiresAt?: number;
}
export interface OAuthProvider {
    readonly load: Effect.Effect<OAuthConfig, unknown>;
    readonly refresh: (credentials: OAuthConfig) => Effect.Effect<OAuthConfig, unknown>;
    readonly apiBaseUrl?: string;
}
export interface ApiTokenCredentials {
    readonly type: "apiToken";
    readonly apiToken: Redacted.Redacted<string>;
    readonly apiBaseUrl: string;
}
export interface ApiKeyCredentials {
    readonly type: "apiKey";
    readonly apiKey: Redacted.Redacted<string>;
    readonly email: string;
    readonly apiBaseUrl: string;
}
export interface OAuthCredentials {
    readonly type: "oauth";
    readonly accessToken: Redacted.Redacted<string>;
    readonly refreshToken: Redacted.Redacted<string> | undefined;
    readonly expiresAt?: number;
    readonly apiBaseUrl: string;
}
export type ResolvedCredentials = ApiTokenCredentials | ApiKeyCredentials | OAuthCredentials;
declare const OAuthRefreshError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "CloudflareOAuthRefreshError";
} & Readonly<A>;
export declare class OAuthRefreshError extends /*@__PURE__*/ OAuthRefreshError_base<{
    message: string;
    cause?: unknown;
}> {
}
export type CredentialsError = ConfigError | OAuthRefreshError;
declare const Credentials_base: Context.ServiceClass<Credentials, "CloudflareCredentials", Effect.Effect<ResolvedCredentials, CredentialsError, never>>;
export declare class Credentials extends /*@__PURE__*/ Credentials_base {
}
export declare const apiTokenCredentials: (config: ApiTokenConfig) => ApiTokenCredentials;
export declare const apiKeyCredentials: (config: ApiKeyConfig) => ApiKeyCredentials;
export declare const oauthCredentials: (config: OAuthConfig, apiBaseUrl?: string) => OAuthCredentials;
export declare const fromApiToken: (config: ApiTokenConfig) => Layer.Layer<Credentials>;
export declare const fromApiKey: (config: ApiKeyConfig) => Layer.Layer<Credentials>;
export declare const fromOAuth: (provider: OAuthProvider) => Layer.Layer<Credentials>;
export declare const resolveFromEnv: Effect.Effect<ResolvedCredentials, ConfigError>;
export declare const fromEnv: () => Layer.Layer<Credentials>;
export declare const CredentialsFromEnv: Layer.Layer<Credentials, never, never>;
export declare const formatHeaders: (credentials: ResolvedCredentials) => Record<string, string>;
/**
 * Convenience layer from a redacted token + optional base URL (kept for local
 * tests; distilled's equivalent is `fromApiToken`).
 */
export declare const credentials: (config: {
    readonly apiToken: Redacted.Redacted<string>;
    readonly baseUrl?: string;
}) => Layer.Layer<Credentials>;
export {};
//# sourceMappingURL=credentials.d.ts.map