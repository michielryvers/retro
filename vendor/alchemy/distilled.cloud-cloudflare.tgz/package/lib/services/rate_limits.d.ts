import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type CreateRequestActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export interface CreateRequestActionResponse {
    /** The response body to return. The value must conform to the configured content type. */
    body?: string;
    /** The content type of the body. Must be one of the following: `text/plain`, `text/xml`, or `application/json`. */
    contentType?: string;
}
export interface CreateRequestAction {
    /** The action to perform. */
    mode?: CreateRequestActionMode | (string & {});
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. Notes: If you omit this object, Cloudflare will use the default HTML error page. If "mode" is "challenge", "managed_challenge", or "js_challenge", Cloudflare will use the zone challenge pages and you should not provide the "response" object. */
    response?: CreateRequestActionResponse;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. Notes: If "mode" is "challenge", "managed_challenge", or "js_challenge", Cloudflare will use the zone's Challenge Passage time and you should not provide this value. */
    timeout?: number;
}
export type CreateRequestMatchHeadersItemOp = "eq" | "ne";
export interface CreateRequestMatchHeadersItem {
    /** The name of the response header to match. */
    name?: string;
    /** The operator used when matching: `eq` means "equal" and `ne` means "not equal". */
    op?: CreateRequestMatchHeadersItemOp | (string & {});
    /** The value of the response header, which must match exactly. */
    value?: string;
}
export type CreateRequestMatchHeadersList = Array<CreateRequestMatchHeadersItem>;
export type CreateRequestMatchRequestMethodsItem = "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | "HEAD" | "_ALL_";
export type CreateRequestMatchRequestMethodsList = Array<CreateRequestMatchRequestMethodsItem | (string & {})>;
export type CreateRequestMatchRequestSchemesList = Array<string>;
export interface CreateRequestMatchRequest {
    /** The HTTP methods to match. You can specify a subset (for example, `['POST','PUT']`) or all methods (`['_ALL_']`). This field is optional when creating a rate limit. */
    methods?: CreateRequestMatchRequestMethodsList;
    /** The HTTP schemes to match. You can specify one scheme (`['HTTPS']`), both schemes (`['HTTP','HTTPS']`), or all schemes (`['_ALL_']`). This field is optional. */
    schemes?: CreateRequestMatchRequestSchemesList;
    /** The URL pattern to match, composed of a host and a path such as `example.org/path*`. Normalization is applied before the pattern is matched. `*` wildcards are expanded to match applicable traffic. Query strings are not matched. Set the value to `*` to match all traffic to your zone. */
    url?: string;
}
export interface CreateRequestMatchResponse {
    /** When true, only the uncached traffic served from your origin servers will count towards rate limiting. In this case, any cached traffic served by Cloudflare will not count towards rate limiting. This field is optional. Notes: This field is deprecated. Instead, use response headers and set "origin_traffic" to "false" to avoid legacy behaviour interacting with the "response_headers" property. */
    originTraffic?: boolean;
}
export interface CreateRequestMatch {
    headers?: CreateRequestMatchHeadersList;
    request?: CreateRequestMatchRequest;
    response?: CreateRequestMatchResponse;
}
export interface CreateRateLimitRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action: CreateRequestAction;
    /** Determines which traffic the rate limit counts towards the threshold. */
    match: CreateRequestMatch;
    /** The time in seconds (an integer value) to count matching traffic. If the count exceeds the configured threshold within this period, Cloudflare will perform the configured action. */
    period: number;
    /** The threshold that will trigger the configured mitigation action. Configure this value along with the `period` property to establish a threshold per period. */
    threshold: number;
}
export interface CreateRateLimitResponse {
}
export interface DeleteRateLimitRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique identifier of the rate limit. */
    rateLimitId: string;
}
export interface DeleteRateLimitResponse {
}
export type EditRequestActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export type EditRequestActionResponse = CreateRequestActionResponse;
export interface EditRequestAction {
    /** The action to perform. */
    mode?: EditRequestActionMode | (string & {});
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. Notes: If you omit this object, Cloudflare will use the default HTML error page. If "mode" is "challenge", "managed_challenge", or "js_challenge", Cloudflare will use the zone challenge pages and you should not provide the "response" object. */
    response?: CreateRequestActionResponse;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. Notes: If "mode" is "challenge", "managed_challenge", or "js_challenge", Cloudflare will use the zone's Challenge Passage time and you should not provide this value. */
    timeout?: number;
}
export type EditRequestMatchHeadersItemOp = "eq" | "ne";
export interface EditRequestMatchHeadersItem {
    /** The name of the response header to match. */
    name?: string;
    /** The operator used when matching: `eq` means "equal" and `ne` means "not equal". */
    op?: EditRequestMatchHeadersItemOp | (string & {});
    /** The value of the response header, which must match exactly. */
    value?: string;
}
export type EditRequestMatchHeadersList = Array<EditRequestMatchHeadersItem>;
export type EditRequestMatchRequestMethodsItem = "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | "HEAD" | "_ALL_";
export type EditRequestMatchRequestMethodsList = Array<EditRequestMatchRequestMethodsItem | (string & {})>;
export type EditRequestMatchRequestSchemesList = Array<string>;
export interface EditRequestMatchRequest {
    /** The HTTP methods to match. You can specify a subset (for example, `['POST','PUT']`) or all methods (`['_ALL_']`). This field is optional when creating a rate limit. */
    methods?: EditRequestMatchRequestMethodsList;
    /** The HTTP schemes to match. You can specify one scheme (`['HTTPS']`), both schemes (`['HTTP','HTTPS']`), or all schemes (`['_ALL_']`). This field is optional. */
    schemes?: EditRequestMatchRequestSchemesList;
    /** The URL pattern to match, composed of a host and a path such as `example.org/path*`. Normalization is applied before the pattern is matched. `*` wildcards are expanded to match applicable traffic. Query strings are not matched. Set the value to `*` to match all traffic to your zone. */
    url?: string;
}
export type EditRequestMatchResponse = CreateRequestMatchResponse;
export interface EditRequestMatch {
    headers?: EditRequestMatchHeadersList;
    request?: EditRequestMatchRequest;
    response?: CreateRequestMatchResponse;
}
export interface EditRateLimitRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique identifier of the rate limit. */
    rateLimitId: string;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action: EditRequestAction;
    /** Determines which traffic the rate limit counts towards the threshold. */
    match: EditRequestMatch;
    /** The time in seconds (an integer value) to count matching traffic. If the count exceeds the configured threshold within this period, Cloudflare will perform the configured action. */
    period: number;
    /** The threshold that will trigger the configured mitigation action. Configure this value along with the `period` property to establish a threshold per period. */
    threshold: number;
}
export interface EditRateLimitResponse {
}
export interface GetRateLimitRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique identifier of the rate limit. */
    rateLimitId: string;
}
export interface GetRateLimitResponse {
}
export interface ListRateLimitsRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the page number of paginated results. */
    page?: number;
    /** Defines the maximum number of results per page. You can only set the value to `1` or to a multiple of 5 such as `5`, `10`, `15`, or `20`. */
    perPage?: number;
}
export interface ListRateLimitsResponse {
}
export type CreateRateLimitError = CloudflareOpError;
/** **Deprecated**: This endpoint returns 410 Gone. Please use the Rulesets API instead. */
export declare const createRateLimit: API.OperationMethod<CreateRateLimitRequest, CreateRateLimitResponse, CreateRateLimitError, CloudflareOpContext>;
export type DeleteRateLimitError = CloudflareOpError;
/** **Deprecated**: This endpoint returns 410 Gone. Please use the Rulesets API instead. */
export declare const deleteRateLimit: API.OperationMethod<DeleteRateLimitRequest, DeleteRateLimitResponse, DeleteRateLimitError, CloudflareOpContext>;
export type EditRateLimitError = CloudflareOpError;
/** **Deprecated**: This endpoint returns 410 Gone. Please use the Rulesets API instead. */
export declare const editRateLimit: API.OperationMethod<EditRateLimitRequest, EditRateLimitResponse, EditRateLimitError, CloudflareOpContext>;
export type GetRateLimitError = CloudflareOpError;
/** **Deprecated**: This endpoint returns 410 Gone. Please use the Rulesets API instead. */
export declare const getRateLimit: API.OperationMethod<GetRateLimitRequest, GetRateLimitResponse, GetRateLimitError, CloudflareOpContext>;
export type ListRateLimitsError = CloudflareOpError;
/** **Deprecated**: This endpoint returns 410 Gone. Please use the Rulesets API instead. */
export declare const listRateLimits: API.OperationMethod<ListRateLimitsRequest, ListRateLimitsResponse, ListRateLimitsError, CloudflareOpContext>;
//# sourceMappingURL=rate_limits.d.ts.map