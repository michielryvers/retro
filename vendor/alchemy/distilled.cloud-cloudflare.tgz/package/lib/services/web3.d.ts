import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidWeb3HostnameTarget_base: S.TaggedErrorClass<"InvalidWeb3HostnameTarget", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidWeb3HostnameTarget extends /*@__PURE__*/ InvalidWeb3HostnameTarget_base {
}
declare const Web3HostnameNotEntitled_base: S.TaggedErrorClass<"Web3HostnameNotEntitled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Web3HostnameNotEntitled extends /*@__PURE__*/ Web3HostnameNotEntitled_base {
}
declare const Web3HostnameNotFound_base: S.TaggedErrorClass<"Web3HostnameNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Web3HostnameNotFound extends /*@__PURE__*/ Web3HostnameNotFound_base {
}
export type HostnamesCreateRequestTarget = "ethereum" | "ipfs" | "ipfs_universal_path";
export interface CreateHostnameRequest {
    /** Specify the identifier of the hostname. */
    zoneId: string;
    /** Specify the hostname that points to the target gateway via CNAME. */
    name: string;
    /** Specify the target gateway of the hostname. */
    target: HostnamesCreateRequestTarget | (string & {});
    /** Specify an optional description of the hostname. */
    description?: string;
    /** Specify the DNSLink value used if the target is ipfs. */
    dnslink?: string;
}
export type HostnamesCreateResponseStatus = "active" | "pending" | "deleting" | "error";
export type HostnamesCreateResponseTarget = "ethereum" | "ipfs" | "ipfs_universal_path";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateHostnameResponse {
    /** Specify the identifier of the hostname. */
    id?: string | null;
    createdOn?: string | null;
    /** Specify an optional description of the hostname. */
    description?: string | null;
    /** Specify the DNSLink value used if the target is ipfs. */
    dnslink?: string | null;
    modifiedOn?: string | null;
    /** Specify the hostname that points to the target gateway via CNAME. */
    name?: string | null;
    /** Specifies the status of the hostname's activation. */
    status?: HostnamesCreateResponseStatus | null;
    /** Specify the target gateway of the hostname. */
    target?: HostnamesCreateResponseTarget | null;
}
export type HostnamesIpfsUniversalPathsContentListsEntriesCreateRequestType = "cid" | "content_path";
export interface CreateHostnameIpfsUniversalPathContentListEntryRequest {
    /** Specify the identifier of the hostname. */
    zoneId: string;
    /** Specify the identifier of the hostname. */
    identifier: string;
    /** Specify the CID or content path of content to block. */
    content: string;
    /** Specify the type of content list entry to block. */
    type: HostnamesIpfsUniversalPathsContentListsEntriesCreateRequestType | (string & {});
    /** Specify an optional description of the content list entry. */
    description?: string;
}
export type HostnamesIpfsUniversalPathsContentListsEntriesCreateResponseType = "cid" | "content_path";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateHostnameIpfsUniversalPathContentListEntryResponse {
    /** Specify the identifier of the hostname. */
    id?: string | null;
    /** Specify the CID or content path of content to block. */
    content?: string | null;
    createdOn?: string | null;
    /** Specify an optional description of the content list entry. */
    description?: string | null;
    modifiedOn?: string | null;
    /** Specify the type of content list entry to block. */
    type?: HostnamesIpfsUniversalPathsContentListsEntriesCreateResponseType | null;
}
export interface DeleteHostnameRequest {
    /** Specify the identifier of the hostname. */
    zoneId: string;
    /** Specify the identifier of the hostname. */
    identifier: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteHostnameResponse {
    /** Specify the identifier of the hostname. */
    id: string;
}
export interface DeleteHostnameIpfsUniversalPathContentListEntryRequest {
    /** Specify the identifier of the hostname. */
    zoneId: string;
    /** Specify the identifier of the hostname. */
    identifier: string;
    /** Specify the identifier of the hostname. */
    contentListEntryIdentifier: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteHostnameIpfsUniversalPathContentListEntryResponse {
    /** Specify the identifier of the hostname. */
    id: string;
}
export interface GetHostnameRequest {
    /** Specify the identifier of the hostname. */
    zoneId: string;
    /** Specify the identifier of the hostname. */
    identifier: string;
}
export type HostnamesGetResponseStatus = "active" | "pending" | "deleting" | "error";
export type HostnamesGetResponseTarget = "ethereum" | "ipfs" | "ipfs_universal_path";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHostnameResponse {
    /** Specify the identifier of the hostname. */
    id?: string | null;
    createdOn?: string | null;
    /** Specify an optional description of the hostname. */
    description?: string | null;
    /** Specify the DNSLink value used if the target is ipfs. */
    dnslink?: string | null;
    modifiedOn?: string | null;
    /** Specify the hostname that points to the target gateway via CNAME. */
    name?: string | null;
    /** Specifies the status of the hostname's activation. */
    status?: HostnamesGetResponseStatus | null;
    /** Specify the target gateway of the hostname. */
    target?: HostnamesGetResponseTarget | null;
}
export interface GetHostnameIpfsUniversalPathContentListRequest {
    /** Specify the identifier of the hostname. */
    zoneId: string;
    /** Specify the identifier of the hostname. */
    identifier: string;
}
export type HostnamesIpfsUniversalPathsContentListsGetResponseAction = "block";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHostnameIpfsUniversalPathContentListResponse {
    /** Behavior of the content list. */
    action?: HostnamesIpfsUniversalPathsContentListsGetResponseAction | null;
}
export interface GetHostnameIpfsUniversalPathContentListEntryRequest {
    /** Specify the identifier of the hostname. */
    zoneId: string;
    /** Specify the identifier of the hostname. */
    identifier: string;
    /** Specify the identifier of the hostname. */
    contentListEntryIdentifier: string;
}
export type HostnamesIpfsUniversalPathsContentListsEntriesGetResponseType = "cid" | "content_path";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHostnameIpfsUniversalPathContentListEntryResponse {
    /** Specify the identifier of the hostname. */
    id?: string | null;
    /** Specify the CID or content path of content to block. */
    content?: string | null;
    createdOn?: string | null;
    /** Specify an optional description of the content list entry. */
    description?: string | null;
    modifiedOn?: string | null;
    /** Specify the type of content list entry to block. */
    type?: HostnamesIpfsUniversalPathsContentListsEntriesGetResponseType | null;
}
export interface ListHostnameIpfsUniversalPathContentListEntriesRequest {
    /** Specify the identifier of the hostname. */
    zoneId: string;
    /** Specify the identifier of the hostname. */
    identifier: string;
}
export type HostnamesIpfsUniversalPathsContentListsEntriesListResponseEntriesItemType = "cid" | "content_path";
export interface HostnamesIpfsUniversalPathsContentListsEntriesListResponseEntriesItem {
    /** Specify the identifier of the hostname. */
    id?: string | null;
    /** Specify the CID or content path of content to block. */
    content?: string | null;
    createdOn?: string | null;
    /** Specify an optional description of the content list entry. */
    description?: string | null;
    modifiedOn?: string | null;
    /** Specify the type of content list entry to block. */
    type?: HostnamesIpfsUniversalPathsContentListsEntriesListResponseEntriesItemType | null;
}
export type HostnamesIpfsUniversalPathsContentListsEntriesListResponseEntriesList = Array<HostnamesIpfsUniversalPathsContentListsEntriesListResponseEntriesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListHostnameIpfsUniversalPathContentListEntriesResponse {
    /** Provides content list entries. */
    entries?: HostnamesIpfsUniversalPathsContentListsEntriesListResponseEntriesList | null;
}
export interface ListHostnamesRequest {
    /** Specify the identifier of the hostname. */
    zoneId: string;
}
export type HostnamesListResultItemStatus = "active" | "pending" | "deleting" | "error";
export type HostnamesListResultItemTarget = "ethereum" | "ipfs" | "ipfs_universal_path";
export interface HostnamesListResultItem {
    /** Specify the identifier of the hostname. */
    id?: string | null;
    createdOn?: string | null;
    /** Specify an optional description of the hostname. */
    description?: string | null;
    /** Specify the DNSLink value used if the target is ipfs. */
    dnslink?: string | null;
    modifiedOn?: string | null;
    /** Specify the hostname that points to the target gateway via CNAME. */
    name?: string | null;
    /** Specifies the status of the hostname's activation. */
    status?: HostnamesListResultItemStatus | null;
    /** Specify the target gateway of the hostname. */
    target?: HostnamesListResultItemTarget | null;
}
export type HostnamesListResultList = Array<HostnamesListResultItem>;
export interface ListHostnamesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: HostnamesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface PatchHostnameRequest {
    /** Specify the identifier of the hostname. */
    zoneId: string;
    /** Specify the identifier of the hostname. */
    identifier: string;
    /** Specify an optional description of the hostname. */
    description?: string;
    /** Specify the DNSLink value used if the target is ipfs. */
    dnslink?: string;
}
export type HostnamesEditResponseStatus = "active" | "pending" | "deleting" | "error";
export type HostnamesEditResponseTarget = "ethereum" | "ipfs" | "ipfs_universal_path";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchHostnameResponse {
    /** Specify the identifier of the hostname. */
    id?: string | null;
    createdOn?: string | null;
    /** Specify an optional description of the hostname. */
    description?: string | null;
    /** Specify the DNSLink value used if the target is ipfs. */
    dnslink?: string | null;
    modifiedOn?: string | null;
    /** Specify the hostname that points to the target gateway via CNAME. */
    name?: string | null;
    /** Specifies the status of the hostname's activation. */
    status?: HostnamesEditResponseStatus | null;
    /** Specify the target gateway of the hostname. */
    target?: HostnamesEditResponseTarget | null;
}
export type HostnamesIpfsUniversalPathsContentListsUpdateRequestAction = "block";
export type HostnamesIpfsUniversalPathsContentListsUpdateRequestEntriesItemType = "cid" | "content_path";
export interface HostnamesIpfsUniversalPathsContentListsUpdateRequestEntriesItem {
    /** Specify the identifier of the hostname. */
    id?: string;
    /** Specify the CID or content path of content to block. */
    content?: string;
    createdOn?: string;
    /** Specify an optional description of the content list entry. */
    description?: string;
    modifiedOn?: string;
    /** Specify the type of content list entry to block. */
    type?: HostnamesIpfsUniversalPathsContentListsUpdateRequestEntriesItemType | (string & {});
}
export type HostnamesIpfsUniversalPathsContentListsUpdateRequestEntriesList = Array<HostnamesIpfsUniversalPathsContentListsUpdateRequestEntriesItem>;
export interface PutHostnameIpfsUniversalPathContentListRequest {
    /** Specify the identifier of the hostname. */
    zoneId: string;
    /** Specify the identifier of the hostname. */
    identifier: string;
    /** Behavior of the content list. */
    action: HostnamesIpfsUniversalPathsContentListsUpdateRequestAction | (string & {});
    /** Provides content list entries. */
    entries: HostnamesIpfsUniversalPathsContentListsUpdateRequestEntriesList;
}
export type HostnamesIpfsUniversalPathsContentListsUpdateResponseAction = "block";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutHostnameIpfsUniversalPathContentListResponse {
    /** Behavior of the content list. */
    action?: HostnamesIpfsUniversalPathsContentListsUpdateResponseAction | null;
}
export type HostnamesIpfsUniversalPathsContentListsEntriesUpdateRequestType = "cid" | "content_path";
export interface UpdateHostnameIpfsUniversalPathContentListEntryRequest {
    /** Specify the identifier of the hostname. */
    zoneId: string;
    /** Specify the identifier of the hostname. */
    identifier: string;
    /** Specify the identifier of the hostname. */
    contentListEntryIdentifier: string;
    /** Specify the CID or content path of content to block. */
    content: string;
    /** Specify the type of content list entry to block. */
    type: HostnamesIpfsUniversalPathsContentListsEntriesUpdateRequestType | (string & {});
    /** Specify an optional description of the content list entry. */
    description?: string;
}
export type HostnamesIpfsUniversalPathsContentListsEntriesUpdateResponseType = "cid" | "content_path";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateHostnameIpfsUniversalPathContentListEntryResponse {
    /** Specify the identifier of the hostname. */
    id?: string | null;
    /** Specify the CID or content path of content to block. */
    content?: string | null;
    createdOn?: string | null;
    /** Specify an optional description of the content list entry. */
    description?: string | null;
    modifiedOn?: string | null;
    /** Specify the type of content list entry to block. */
    type?: HostnamesIpfsUniversalPathsContentListsEntriesUpdateResponseType | null;
}
export type CreateHostnameError = Web3HostnameNotEntitled | Forbidden | CloudflareOpError;
/** Create Web3 Hostname */
export declare const createHostname: API.OperationMethod<CreateHostnameRequest, CreateHostnameResponse, CreateHostnameError, CloudflareOpContext>;
export type CreateHostnameIpfsUniversalPathContentListEntryError = CloudflareOpError;
/** Create IPFS Universal Path Gateway Content List Entry */
export declare const createHostnameIpfsUniversalPathContentListEntry: API.OperationMethod<CreateHostnameIpfsUniversalPathContentListEntryRequest, CreateHostnameIpfsUniversalPathContentListEntryResponse, CreateHostnameIpfsUniversalPathContentListEntryError, CloudflareOpContext>;
export type DeleteHostnameError = Web3HostnameNotFound | Forbidden | CloudflareOpError;
/** Delete Web3 Hostname */
export declare const deleteHostname: API.OperationMethod<DeleteHostnameRequest, DeleteHostnameResponse, DeleteHostnameError, CloudflareOpContext>;
export type DeleteHostnameIpfsUniversalPathContentListEntryError = CloudflareOpError;
/** Delete IPFS Universal Path Gateway Content List Entry */
export declare const deleteHostnameIpfsUniversalPathContentListEntry: API.OperationMethod<DeleteHostnameIpfsUniversalPathContentListEntryRequest, DeleteHostnameIpfsUniversalPathContentListEntryResponse, DeleteHostnameIpfsUniversalPathContentListEntryError, CloudflareOpContext>;
export type GetHostnameError = Web3HostnameNotFound | Forbidden | CloudflareOpError;
/** Web3 Hostname Details */
export declare const getHostname: API.OperationMethod<GetHostnameRequest, GetHostnameResponse, GetHostnameError, CloudflareOpContext>;
export type GetHostnameIpfsUniversalPathContentListError = Web3HostnameNotFound | InvalidWeb3HostnameTarget | Forbidden | CloudflareOpError;
/** IPFS Universal Path Gateway Content List Details */
export declare const getHostnameIpfsUniversalPathContentList: API.OperationMethod<GetHostnameIpfsUniversalPathContentListRequest, GetHostnameIpfsUniversalPathContentListResponse, GetHostnameIpfsUniversalPathContentListError, CloudflareOpContext>;
export type GetHostnameIpfsUniversalPathContentListEntryError = CloudflareOpError;
/** IPFS Universal Path Gateway Content List Entry Details */
export declare const getHostnameIpfsUniversalPathContentListEntry: API.OperationMethod<GetHostnameIpfsUniversalPathContentListEntryRequest, GetHostnameIpfsUniversalPathContentListEntryResponse, GetHostnameIpfsUniversalPathContentListEntryError, CloudflareOpContext>;
export type ListHostnameIpfsUniversalPathContentListEntriesError = Web3HostnameNotFound | InvalidWeb3HostnameTarget | Forbidden | CloudflareOpError;
/** List IPFS Universal Path Gateway Content List Entries */
export declare const listHostnameIpfsUniversalPathContentListEntries: API.OperationMethod<ListHostnameIpfsUniversalPathContentListEntriesRequest, ListHostnameIpfsUniversalPathContentListEntriesResponse, ListHostnameIpfsUniversalPathContentListEntriesError, CloudflareOpContext>;
export type ListHostnamesError = Forbidden | CloudflareOpError;
/** List Web3 Hostnames */
export declare const listHostnames: API.PaginatedOperationMethod<ListHostnamesRequest, ListHostnamesResponse, ListHostnamesError, CloudflareOpContext, HostnamesListResultItem>;
export type PatchHostnameError = Web3HostnameNotFound | Forbidden | CloudflareOpError;
/** Edit Web3 Hostname */
export declare const patchHostname: API.OperationMethod<PatchHostnameRequest, PatchHostnameResponse, PatchHostnameError, CloudflareOpContext>;
export type PutHostnameIpfsUniversalPathContentListError = Web3HostnameNotFound | InvalidWeb3HostnameTarget | Forbidden | CloudflareOpError;
/** Update IPFS Universal Path Gateway Content List */
export declare const putHostnameIpfsUniversalPathContentList: API.OperationMethod<PutHostnameIpfsUniversalPathContentListRequest, PutHostnameIpfsUniversalPathContentListResponse, PutHostnameIpfsUniversalPathContentListError, CloudflareOpContext>;
export type UpdateHostnameIpfsUniversalPathContentListEntryError = CloudflareOpError;
/** Edit IPFS Universal Path Gateway Content List Entry */
export declare const updateHostnameIpfsUniversalPathContentListEntry: API.OperationMethod<UpdateHostnameIpfsUniversalPathContentListEntryRequest, UpdateHostnameIpfsUniversalPathContentListEntryResponse, UpdateHostnameIpfsUniversalPathContentListEntryError, CloudflareOpContext>;
//# sourceMappingURL=web3.d.ts.map