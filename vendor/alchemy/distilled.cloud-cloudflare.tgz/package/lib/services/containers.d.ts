import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const BadRequest_base: S.TaggedErrorClass<"BadRequest", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** The image preparation request is invalid. */
export declare class BadRequest extends /*@__PURE__*/ BadRequest_base {
}
declare const ContainerApplicationNotFound_base: S.TaggedErrorClass<"ContainerApplicationNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ContainerApplicationNotFound extends /*@__PURE__*/ ContainerApplicationNotFound_base {
}
declare const ContainerImagePreparationInvalidImage_base: S.TaggedErrorClass<"ContainerImagePreparationInvalidImage", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** The image is invalid or does not exist in this account. */
export declare class ContainerImagePreparationInvalidImage extends /*@__PURE__*/ ContainerImagePreparationInvalidImage_base {
}
declare const DurableObjectAlreadyHasApplication_base: S.TaggedErrorClass<"DurableObjectAlreadyHasApplication", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DurableObjectAlreadyHasApplication extends /*@__PURE__*/ DurableObjectAlreadyHasApplication_base {
}
declare const DurableObjectCheckError_base: S.TaggedErrorClass<"DurableObjectCheckError", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DurableObjectCheckError extends /*@__PURE__*/ DurableObjectCheckError_base {
}
declare const DurableObjectNamespaceNotFound_base: S.TaggedErrorClass<"DurableObjectNamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
/** The Durable Object namespace is not visible to the containers API. Right after a Worker upload creates the namespace this is transient; retry. */
export declare class DurableObjectNamespaceNotFound extends /*@__PURE__*/ DurableObjectNamespaceNotFound_base {
}
declare const DurableObjectNotContainerEnabled_base: S.TaggedErrorClass<"DurableObjectNotContainerEnabled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DurableObjectNotContainerEnabled extends /*@__PURE__*/ DurableObjectNotContainerEnabled_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
/** The image preparation request is forbidden. */
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
export interface EnvironmentVariable {
    name: string;
    value: string;
}
export type EnvironmentVariableList = Array<EnvironmentVariable>;
export type DocumentList = Array<unknown>;
export type StringList = Array<string>;
export interface ContainerConfiguration {
    image: string;
    instanceType?: string;
    vcpu?: number;
    memory?: string;
    memoryMib?: number;
    disk?: unknown;
    environmentVariables?: EnvironmentVariableList;
    secrets?: DocumentList;
    labels?: DocumentList;
    ports?: DocumentList;
    network?: unknown;
    command?: StringList;
    entrypoint?: StringList;
    observability?: unknown;
    checks?: DocumentList;
    dns?: unknown;
    sshPublicKeyIds?: StringList;
}
export interface DurableObjectsRef {
    namespaceId: string;
}
export interface CreateContainerApplicationRequest {
    accountId: string;
    name: string;
    maxInstances: number;
    configuration: ContainerConfiguration;
    durableObjects?: DurableObjectsRef;
    instances?: number;
    schedulingPolicy?: string;
    constraints?: unknown;
    affinities?: unknown;
    jobs?: boolean;
}
export type DurableObjectSchedulingPolicy = "durable_object";
/** Configuration for connecting to a container over SSH with Wrangler. Source: https://github.com/cloudflare/workers-sdk/blob/main/packages/containers-shared/src/client/models/WranglerSSHConfig.ts (2026-09-30). */
export interface WranglerSSHConfiguration {
    enabled: boolean;
    port?: number | null;
}
/** An SSH public key provided by the user. Source: https://github.com/cloudflare/workers-sdk/blob/main/packages/containers-shared/src/client/models/UserSSHPublicKey.ts (2026-09-30). */
export interface UserSSHPublicKey {
    name?: string | null;
    publicKey: string;
}
export type UserSSHPublicKeyList = Array<UserSSHPublicKey>;
export interface DurableObjectContainerConfiguration {
    wranglerSsh?: WranglerSSHConfiguration | null;
    authorizedKeys?: UserSSHPublicKeyList | null;
    experimentalFlags?: StringList | null;
}
export interface DurableObjectApplicationConstraints {
    /** The jurisdiction of the application's primary control-plane object: eu, fedramp or us. Set on create; it cannot change. */
    jurisdiction: string;
}
export interface DurableObjectApplicationHealthInstances {
    active: number;
    starting: number;
}
export interface DurableObjectApplicationHealth {
    instances: DurableObjectApplicationHealthInstances;
    summary?: string | null;
}
export interface ContainerApplicationLogs {
    enabled?: boolean | null;
}
export interface ContainerApplicationObservability {
    logs?: ContainerApplicationLogs | null;
}
/** An application whose Durable Objects create and manage the lifecycle of its container instances. Deployment configuration, scaling, placement constraints, versions and rollouts do not apply. Source: https://developers.cloudflare.com/api/resources/containers/subresources/applications/methods/get/ (2026-10-22) (CcDurableObjectApplication). */
export interface DurableObjectContainerApplication {
    id: string;
    accountId: string;
    createdAt: string;
    updatedAt: string;
    name: string;
    schedulingPolicy: DurableObjectSchedulingPolicy;
    durableObjects: DurableObjectsRef;
    configuration?: DurableObjectContainerConfiguration | null;
    constraints?: DurableObjectApplicationConstraints | null;
    health?: DurableObjectApplicationHealth | null;
    observability?: ContainerApplicationObservability | null;
}
export type ContainerSchedulingPolicy = "default" | "durable_object";
export interface ContainerApplicationConfiguration {
    image?: string | null;
    instanceType?: string | null;
    vcpu?: number | null;
    memory?: string | null;
    memoryMib?: number | null;
    disk?: unknown | null;
    environmentVariables?: EnvironmentVariableList | null;
    secrets?: DocumentList | null;
    labels?: DocumentList | null;
    ports?: DocumentList | null;
    network?: unknown | null;
    command?: StringList | null;
    entrypoint?: StringList | null;
    observability?: unknown | null;
    checks?: DocumentList | null;
    dns?: unknown | null;
    sshPublicKeyIds?: StringList | null;
    wranglerSsh?: WranglerSSHConfiguration | null;
    authorizedKeys?: UserSSHPublicKeyList | null;
    experimentalFlags?: StringList | null;
}
export interface ScheduledApplicationConstraints {
    jurisdiction?: string | null;
    regions?: StringList | null;
}
export interface ScheduledApplicationHealthInstances {
    active: number;
    assigned: number;
}
export interface ScheduledApplicationHealth {
    errors: DocumentList;
    instances: ScheduledApplicationHealthInstances;
    summary?: string | null;
}
/** An application that places its instances through the Containers scheduler. Source: https://developers.cloudflare.com/api/resources/containers/subresources/applications/methods/get/ (2026-10-22) (CcScheduledApplication). */
export interface ScheduledContainerApplication {
    id: string;
    accountId: string;
    createdAt: string;
    updatedAt: string;
    name: string;
    schedulingPolicy: ContainerSchedulingPolicy;
    configuration: ContainerApplicationConfiguration;
    instances: number;
    version: number;
    maxInstances?: number | null;
    activeRolloutId?: string | null;
    rolloutActiveGracePeriod?: number | null;
    constraints?: ScheduledApplicationConstraints | null;
    /** Not in the API reference; kept from the earlier transcription of the live API. */
    affinities?: unknown | null;
    durableObjects?: DurableObjectsRef | null;
    health?: ScheduledApplicationHealth | null;
    observability?: ContainerApplicationObservability | null;
}
/** A Containers application, one case per scheduling policy (CcDurableObjectApplication | CcScheduledApplication). The durable_object case is listed first: its keys are a subset of the scheduled case's, and a key-set tie picks the first case. Source: https://developers.cloudflare.com/api/resources/containers/subresources/applications/methods/get/ (2026-10-22). */
export type ContainerApplicationItem = DurableObjectContainerApplication | ScheduledContainerApplication;
export type CreateContainerApplicationResponse = ContainerApplicationItem;
export interface CreateContainerApplicationRolloutRequest {
    accountId: string;
    applicationId: string;
    description: string;
    strategy: string;
    kind?: string;
    stepPercentage?: number;
    targetConfiguration?: ContainerConfiguration;
}
export type CreateContainerApplicationRolloutResponse = ContainerApplicationItem;
export interface CreateContainerRegistryCredentialsRequest {
    accountId: string;
    registryId: string;
    permissions: StringList;
    expirationMinutes: number;
}
/** Registry credentials (transcribed from the distilled SDK -- endpoint is docs-absent). */
export interface CreateContainerRegistryCredentialsResult {
    user?: string | null;
    username?: string | null;
    password: string;
}
export type CreateContainerRegistryCredentialsResponse = CreateContainerRegistryCredentialsResult;
export interface CreateDurableObjectContainerApplicationRequest {
    accountId: string;
    name: string;
    schedulingPolicy: DurableObjectSchedulingPolicy;
    durableObjects: DurableObjectsRef;
    configuration?: DurableObjectContainerConfiguration;
    observability?: ContainerApplicationObservability;
}
export type CreateDurableObjectContainerApplicationResponse = ContainerApplicationItem;
export interface DeleteContainerApplicationRequest {
    accountId: string;
    applicationId: string;
}
export type DeleteContainerApplicationResponse = unknown;
export interface GetContainerApplicationRequest {
    accountId: string;
    applicationId: string;
}
export type GetContainerApplicationResponse = ContainerApplicationItem;
export interface GetContainerIdentityRequest {
    accountId: string;
}
export type GetContainerIdentityResponse = unknown;
export interface ListContainerApplicationsRequest {
    accountId: string;
}
export type ContainerApplicationItemList = Array<ContainerApplicationItem>;
export type ListContainerApplicationsResponse = ContainerApplicationItemList;
export interface PrepareContainerImageRequest {
    accountId: string;
    image: string;
}
export type ContainerImagePreparationStatus = "pending" | "ready" | "error";
export interface ContainerImagePreparation {
    image: string;
    status: ContainerImagePreparationStatus;
    artifactDigest?: string | null;
    reason?: string | null;
}
export type PrepareContainerImageResponse = ContainerImagePreparation;
export interface UpdateContainerApplicationRequest {
    accountId: string;
    applicationId: string;
    maxInstances?: number;
    configuration?: ContainerApplicationConfiguration;
    instances?: number;
    schedulingPolicy?: string;
    constraints?: unknown;
    affinities?: unknown;
    observability?: ContainerApplicationObservability;
}
export type UpdateContainerApplicationResponse = ContainerApplicationItem;
export type CreateContainerApplicationError = InvalidRoute | DurableObjectAlreadyHasApplication | DurableObjectNotContainerEnabled | DurableObjectCheckError | DurableObjectNamespaceNotFound | CloudflareOpError;
export declare const createContainerApplication: API.OperationMethod<CreateContainerApplicationRequest, CreateContainerApplicationResponse, CreateContainerApplicationError, CloudflareOpContext>;
export type CreateContainerApplicationRolloutError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
export declare const createContainerApplicationRollout: API.OperationMethod<CreateContainerApplicationRolloutRequest, CreateContainerApplicationRolloutResponse, CreateContainerApplicationRolloutError, CloudflareOpContext>;
export type CreateContainerRegistryCredentialsError = InvalidRoute | CloudflareOpError;
export declare const createContainerRegistryCredentials: API.OperationMethod<CreateContainerRegistryCredentialsRequest, CreateContainerRegistryCredentialsResponse, CreateContainerRegistryCredentialsError, CloudflareOpContext>;
export type CreateDurableObjectContainerApplicationError = InvalidRoute | DurableObjectAlreadyHasApplication | DurableObjectNotContainerEnabled | DurableObjectCheckError | DurableObjectNamespaceNotFound | CloudflareOpError;
/** Create a Durable Object-managed application. Requires an existing SQLite Durable Object namespace; the application ID is the namespace ID. Source: cloudflare/workers-sdk packages/deploy-helpers/src/deploy/helpers/durable-object-container-applications.ts (2026-09-30). */
export declare const createDurableObjectContainerApplication: API.OperationMethod<CreateDurableObjectContainerApplicationRequest, CreateDurableObjectContainerApplicationResponse, CreateDurableObjectContainerApplicationError, CloudflareOpContext>;
export type DeleteContainerApplicationError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
export declare const deleteContainerApplication: API.OperationMethod<DeleteContainerApplicationRequest, DeleteContainerApplicationResponse, DeleteContainerApplicationError, CloudflareOpContext>;
export type GetContainerApplicationError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
export declare const getContainerApplication: API.OperationMethod<GetContainerApplicationRequest, GetContainerApplicationResponse, GetContainerApplicationError, CloudflareOpContext>;
export type GetContainerIdentityError = InvalidRoute | CloudflareOpError;
export declare const getContainerIdentity: API.OperationMethod<GetContainerIdentityRequest, GetContainerIdentityResponse, GetContainerIdentityError, CloudflareOpContext>;
export type ListContainerApplicationsError = InvalidRoute | CloudflareOpError;
export declare const listContainerApplications: API.OperationMethod<ListContainerApplicationsRequest, ListContainerApplicationsResponse, ListContainerApplicationsError, CloudflareOpContext>;
export type PrepareContainerImageError = ContainerImagePreparationInvalidImage | BadRequest | Forbidden | CloudflareOpError;
/** Prepare a digest-pinned image in the Cloudflare managed registry. Repeat while status is pending. Source: cloudflare/workers-sdk packages/containers-shared/src/client/services/ContainerImagePreparationsService.ts (2026-09-30). */
export declare const prepareContainerImage: API.OperationMethod<PrepareContainerImageRequest, PrepareContainerImageResponse, PrepareContainerImageError, CloudflareOpContext>;
export type UpdateContainerApplicationError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
export declare const updateContainerApplication: API.OperationMethod<UpdateContainerApplicationRequest, UpdateContainerApplicationResponse, UpdateContainerApplicationError, CloudflareOpContext>;
//# sourceMappingURL=containers.d.ts.map