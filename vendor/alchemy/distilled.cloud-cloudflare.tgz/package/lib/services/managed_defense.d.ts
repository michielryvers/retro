import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CreateVulnerabilityDiscoveryRepositoryRequest {
    accountId: string;
    idempotencyKey?: string;
    name: string;
    workerScriptName?: string;
}
export type CreateVulnerabilityDiscoveryRepositoryResultCase0RepositoryReadiness = "awaiting_source" | "processing" | "ready" | "failed";
export type CreateVulnerabilityDiscoveryRepositoryResultCase0RepositorySource = "upload" | "worker";
export type CreateVulnerabilityDiscoveryRepositoryResultCase0RepositoryImportErrorCode = "worker_import_failed";
export type CreateVulnerabilityDiscoveryRepositoryResultCase0RepositoryImportErrorMessage = "Worker import failed.";
export interface CreateVulnerabilityDiscoveryRepositoryResultCase0RepositoryImportError {
    code: CreateVulnerabilityDiscoveryRepositoryResultCase0RepositoryImportErrorCode;
    message: CreateVulnerabilityDiscoveryRepositoryResultCase0RepositoryImportErrorMessage;
}
export interface CreateVulnerabilityDiscoveryRepositoryResultCase0Repository {
    id: string;
    name: string;
    /** Source state. `awaiting_source`: the upload repository's default branch has no commits yet. `processing`: an import is in progress. `ready`: source is available. `failed`: the Worker import failed or could not be verified. */
    readiness: CreateVulnerabilityDiscoveryRepositoryResultCase0RepositoryReadiness;
    source: CreateVulnerabilityDiscoveryRepositoryResultCase0RepositorySource;
    importError?: CreateVulnerabilityDiscoveryRepositoryResultCase0RepositoryImportError | null;
}
export type CreateVulnerabilityDiscoveryRepositoryResultCase0UploadExpiresIn = 3600;
export interface CreateVulnerabilityDiscoveryRepositoryResultCase0Upload {
    token: string;
    expiresIn: CreateVulnerabilityDiscoveryRepositoryResultCase0UploadExpiresIn;
    remote: string;
}
export interface CreateVulnerabilityDiscoveryRepositoryResultCase0 {
    repository: CreateVulnerabilityDiscoveryRepositoryResultCase0Repository;
    upload: CreateVulnerabilityDiscoveryRepositoryResultCase0Upload;
}
export type CreateVulnerabilityDiscoveryRepositoryResultRepositoryRepositoryReadiness = "awaiting_source" | "processing" | "ready" | "failed";
export type CreateVulnerabilityDiscoveryRepositoryResultRepositoryRepositorySource = "upload" | "worker";
export type CreateVulnerabilityDiscoveryRepositoryResultRepositoryRepositoryImportErrorCode = "worker_import_failed";
export type CreateVulnerabilityDiscoveryRepositoryResultRepositoryRepositoryImportErrorMessage = "Worker import failed.";
export interface CreateVulnerabilityDiscoveryRepositoryResultRepositoryRepositoryImportError {
    code: CreateVulnerabilityDiscoveryRepositoryResultRepositoryRepositoryImportErrorCode;
    message: CreateVulnerabilityDiscoveryRepositoryResultRepositoryRepositoryImportErrorMessage;
}
export interface CreateVulnerabilityDiscoveryRepositoryResultRepositoryRepository {
    id: string;
    name: string;
    /** Source state. `awaiting_source`: the upload repository's default branch has no commits yet. `processing`: an import is in progress. `ready`: source is available. `failed`: the Worker import failed or could not be verified. */
    readiness: CreateVulnerabilityDiscoveryRepositoryResultRepositoryRepositoryReadiness;
    source: CreateVulnerabilityDiscoveryRepositoryResultRepositoryRepositorySource;
    importError?: CreateVulnerabilityDiscoveryRepositoryResultRepositoryRepositoryImportError | null;
}
export interface CreateVulnerabilityDiscoveryRepositoryResultRepository {
    repository: CreateVulnerabilityDiscoveryRepositoryResultRepositoryRepository;
}
export type CreateVulnerabilityDiscoveryRepositoryResult = CreateVulnerabilityDiscoveryRepositoryResultCase0 | CreateVulnerabilityDiscoveryRepositoryResultRepository;
export type CreateVulnerabilityDiscoveryRepositoryResponse = CreateVulnerabilityDiscoveryRepositoryResult;
export type CreateVulnerabilityDiscoveryScanRequestReposItemHostsList = Array<string>;
export interface CreateVulnerabilityDiscoveryScanRequestReposItem {
    name: string;
    /** Branch to scan. Defaults to the repository's default branch. */
    branch?: string;
    /** Explicit hostname scopes. Every hostname must be authorized for this repository before review admission; rejected scopes return 422 and do not persist a scan request. */
    hosts?: CreateVulnerabilityDiscoveryScanRequestReposItemHostsList;
}
export type CreateVulnerabilityDiscoveryScanRequestReposList = Array<CreateVulnerabilityDiscoveryScanRequestReposItem>;
export interface CreateVulnerabilityDiscoveryScanRequestTelemetryWindow {
    end: string;
    start: string;
}
export interface CreateVulnerabilityDiscoveryScanRequest {
    accountId: string;
    idempotencyKey?: string;
    /** Repository names must be unique within a request. */
    repos: CreateVulnerabilityDiscoveryScanRequestReposList;
    /** UTC ISO-8601 interval. Start is inclusive, end is exclusive, and the interval must be positive and at most seven days. */
    telemetryWindow?: CreateVulnerabilityDiscoveryScanRequestTelemetryWindow;
}
export type CreateVulnerabilityDiscoveryScanResponsePhase = "provisioning" | "indexing" | "analyzing" | "reporting" | "finalizing";
export type CreateVulnerabilityDiscoveryScanResponseRepositoriesItemPhase = "provisioning" | "indexing" | "analyzing" | "reporting" | "finalizing";
export type CreateVulnerabilityDiscoveryScanResponseRepositoriesItemReportStatus = "not_ready" | "pending_review" | "published" | "withdrawn";
export type CreateVulnerabilityDiscoveryScanResponseRepositoriesItemStatus = "requested" | "accepted" | "running" | "completed" | "failed" | "rejected" | "cancelled";
export interface CreateVulnerabilityDiscoveryScanResponseRepositoriesItem {
    id: string;
    name: string;
    phase: CreateVulnerabilityDiscoveryScanResponseRepositoriesItemPhase;
    reportStatus: CreateVulnerabilityDiscoveryScanResponseRepositoriesItemReportStatus;
    status: CreateVulnerabilityDiscoveryScanResponseRepositoriesItemStatus;
}
export type CreateVulnerabilityDiscoveryScanResponseRepositoriesList = Array<CreateVulnerabilityDiscoveryScanResponseRepositoriesItem>;
export type CreateVulnerabilityDiscoveryScanResponseStatus = "requested" | "accepted" | "running" | "completed" | "failed" | "rejected" | "cancelled";
export type CreateVulnerabilityDiscoveryScanResponseTelemetryWindow = CreateVulnerabilityDiscoveryScanRequestTelemetryWindow;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateVulnerabilityDiscoveryScanResponse {
    id: string;
    completedAt: string;
    message: string;
    phase: CreateVulnerabilityDiscoveryScanResponsePhase;
    repositories: CreateVulnerabilityDiscoveryScanResponseRepositoriesList;
    startedAt: string;
    status: CreateVulnerabilityDiscoveryScanResponseStatus;
    submittedAt: string;
    /** UTC ISO-8601 interval. Start is inclusive, end is exclusive, and the interval must be positive and at most seven days. */
    telemetryWindow?: CreateVulnerabilityDiscoveryScanRequestTelemetryWindow | null;
}
export interface GetVulnerabilityDiscoveryReportRequest {
    accountId: string;
    repoId: string;
    scanId: string;
}
export interface GetVulnerabilityDiscoveryReportResponsePublication {
    publishedAt: string;
    revisionId: string;
    version: number;
}
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemConditionsList = Array<string>;
export interface GetVulnerabilityDiscoveryReportResponseReportFindingsItemLocation {
    file: string;
    line: number;
    route: string;
}
export interface GetVulnerabilityDiscoveryReportResponseReportFindingsItemReachabilityItem {
    consumer: string;
    reachable: boolean;
    via: string;
}
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemReachabilityList = Array<GetVulnerabilityDiscoveryReportResponseReportFindingsItemReachabilityItem>;
export interface GetVulnerabilityDiscoveryReportResponseReportFindingsItemRemediation {
    codeChanges: string;
    strategy: string;
}
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemSeverity = "critical" | "high" | "medium" | "low" | "info";
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemTelemetryReferencesList = Array<string>;
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemTelemetryState = "no_route" | "no_telemetry" | "no_match" | "matched";
export interface GetVulnerabilityDiscoveryReportResponseReportFindingsItemTelemetry {
    references: GetVulnerabilityDiscoveryReportResponseReportFindingsItemTelemetryReferencesList;
    state: GetVulnerabilityDiscoveryReportResponseReportFindingsItemTelemetryState;
}
export interface GetVulnerabilityDiscoveryReportResponseReportFindingsItemTraceItem {
    line: number;
    path: string;
    scope: string;
    why: string;
}
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemTraceList = Array<GetVulnerabilityDiscoveryReportResponseReportFindingsItemTraceItem>;
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRulesBroadAction = "block" | "managed_challenge" | "js_challenge" | "log";
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRulesBroadConfidence = "low" | "medium" | "high";
export interface GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRulesBroad {
    action: GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRulesBroadAction;
    confidence: GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRulesBroadConfidence;
    description: string;
    expression: string;
    falsePositiveRisk: string;
    name: string;
    rationale: string;
}
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRulesTargetedAction = "block" | "managed_challenge" | "js_challenge" | "log";
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRulesTargetedConfidence = "low" | "medium" | "high";
export interface GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRulesTargeted {
    action: GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRulesTargetedAction;
    confidence: GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRulesTargetedConfidence;
    description: string;
    expression: string;
    falsePositiveRisk: string;
    name: string;
    rationale: string;
}
export interface GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRules {
    broad: GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRulesBroad;
    targeted: GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRulesTargeted;
}
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemAttackerPosition = "external" | "authenticated" | "internal" | "post_compromise";
export interface GetVulnerabilityDiscoveryReportResponseReportFindingsItemExternalLinksItem {
    title: string;
    url: string;
}
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemExternalLinksList = Array<GetVulnerabilityDiscoveryReportResponseReportFindingsItemExternalLinksItem>;
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemImpactIdsList = Array<string>;
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemProofMethod = "structural" | "experimental" | "acquired_source" | "public_knowledge" | "team_question";
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemProofState = "closed" | "pending_source" | "pending_public" | "pending_experiment" | "pending_team";
export type GetVulnerabilityDiscoveryReportResponseReportFindingsItemThreatIdsList = Array<string>;
export interface GetVulnerabilityDiscoveryReportResponseReportFindingsItem {
    id: string;
    conditions: GetVulnerabilityDiscoveryReportResponseReportFindingsItemConditionsList;
    cwe: string;
    impact: string;
    location: GetVulnerabilityDiscoveryReportResponseReportFindingsItemLocation;
    reachability: GetVulnerabilityDiscoveryReportResponseReportFindingsItemReachabilityList;
    remediation: GetVulnerabilityDiscoveryReportResponseReportFindingsItemRemediation;
    rootCause: string;
    severity: GetVulnerabilityDiscoveryReportResponseReportFindingsItemSeverity;
    severityBasis: string;
    summary: string;
    telemetry: GetVulnerabilityDiscoveryReportResponseReportFindingsItemTelemetry;
    title: string;
    trace: GetVulnerabilityDiscoveryReportResponseReportFindingsItemTraceList;
    wafRules: GetVulnerabilityDiscoveryReportResponseReportFindingsItemWafRules;
    /** Least-privileged position required to trigger the finding. Optional on legacy report revisions. */
    attackerPosition?: GetVulnerabilityDiscoveryReportResponseReportFindingsItemAttackerPosition | null;
    externalLinks?: GetVulnerabilityDiscoveryReportResponseReportFindingsItemExternalLinksList | null;
    /** Accepted settled impact-charter premises cited by the finding. Optional on legacy report revisions. */
    impactIds?: GetVulnerabilityDiscoveryReportResponseReportFindingsItemImpactIdsList | null;
    /** One bounded unresolved proof question. Optional on legacy report revisions. */
    openQuestion?: string | null;
    /** Method used or needed to close the proof. Optional on legacy report revisions. */
    proofMethod?: GetVulnerabilityDiscoveryReportResponseReportFindingsItemProofMethod | null;
    /** Current proof lifecycle state. Optional on legacy report revisions. */
    proofState?: GetVulnerabilityDiscoveryReportResponseReportFindingsItemProofState | null;
    /** Accepted settled threat-model premises cited by the finding. Optional on legacy report revisions. */
    threatIds?: GetVulnerabilityDiscoveryReportResponseReportFindingsItemThreatIdsList | null;
}
export type GetVulnerabilityDiscoveryReportResponseReportFindingsList = Array<GetVulnerabilityDiscoveryReportResponseReportFindingsItem>;
export type GetVulnerabilityDiscoveryReportResponseReportOverallSeverity = "critical" | "high" | "medium" | "low" | "info";
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttpErrorPathsItem {
    id: string;
    hits: number;
    host: string;
    path: string;
    status: number;
}
export type GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttpErrorPathsList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttpErrorPathsItem>;
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttpHotPathsItem {
    id: string;
    hits: number;
    host: string;
    path: string;
    topStatus: number;
}
export type GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttpHotPathsList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttpHotPathsItem>;
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttp {
    errorPaths: GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttpErrorPathsList;
    hotPaths: GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttpHotPathsList;
    requestVolume: number;
}
export type GetVulnerabilityDiscoveryReportResponseReportTrafficContextTargetHostsList = Array<string>;
export type GetVulnerabilityDiscoveryReportResponseReportTrafficContextTargetKind = "worker" | "origin";
export type GetVulnerabilityDiscoveryReportResponseReportTrafficContextTargetTelemetryWindow = CreateVulnerabilityDiscoveryScanRequestTelemetryWindow;
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextTarget {
    hosts: GetVulnerabilityDiscoveryReportResponseReportTrafficContextTargetHostsList;
    kind: GetVulnerabilityDiscoveryReportResponseReportTrafficContextTargetKind;
    /** UTC ISO-8601 interval. Start is inclusive, end is exclusive, and the interval must be positive and at most seven days. */
    telemetryWindow?: CreateVulnerabilityDiscoveryScanRequestTelemetryWindow | null;
}
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextWafRulesItemPathsItem {
    id: string;
    hitVolume: number;
    host: string;
    path: string;
}
export type GetVulnerabilityDiscoveryReportResponseReportTrafficContextWafRulesItemPathsList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextWafRulesItemPathsItem>;
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextWafRulesItem {
    id: string;
    hitVolume: number;
    paths: GetVulnerabilityDiscoveryReportResponseReportTrafficContextWafRulesItemPathsList;
    ruleId: string;
    ruleVersion: number;
}
export type GetVulnerabilityDiscoveryReportResponseReportTrafficContextWafRulesList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextWafRulesItem>;
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextWaf {
    hitVolume: number;
    rules: GetVulnerabilityDiscoveryReportResponseReportTrafficContextWafRulesList;
}
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsItemRiskLabelsItem {
    description: string;
    name: string;
}
export type GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsItemRiskLabelsList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsItemRiskLabelsItem>;
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsItemPerformance {
    avgOriginLatencyMs: number;
    errorRate: number;
    estimatedRequests: number;
}
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsItem {
    id: string;
    endpoint: string;
    host: string;
    method: string;
    riskLabels: GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsItemRiskLabelsList;
    performance?: GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsItemPerformance | null;
}
export type GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsItem>;
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsPathsItem {
    id: string;
    avgOriginLatencyMs: number;
    errorRate: number;
    estimatedRequests: number;
    host: string;
    path: string;
}
export type GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsPathsList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsPathsItem>;
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsRiskTypesItem {
    description: string;
    name: string;
    operationCount: number;
}
export type GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsRiskTypesList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsRiskTypesItem>;
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssets {
    operations: GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsList;
    paths: GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsPathsList;
    riskTypes: GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsRiskTypesList;
}
export interface GetVulnerabilityDiscoveryReportResponseReportTrafficContext {
    http: GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttp;
    target: GetVulnerabilityDiscoveryReportResponseReportTrafficContextTarget;
    waf: GetVulnerabilityDiscoveryReportResponseReportTrafficContextWaf;
    webAssets: GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssets;
}
export type GetVulnerabilityDiscoveryReportResponseReportExternalLinksItem = GetVulnerabilityDiscoveryReportResponseReportFindingsItemExternalLinksItem;
export type GetVulnerabilityDiscoveryReportResponseReportExternalLinksList = Array<GetVulnerabilityDiscoveryReportResponseReportFindingsItemExternalLinksItem>;
export type GetVulnerabilityDiscoveryReportResponseReportLimitationsList = Array<string>;
export interface GetVulnerabilityDiscoveryReportResponseReport {
    findings: GetVulnerabilityDiscoveryReportResponseReportFindingsList;
    overallSeverity: GetVulnerabilityDiscoveryReportResponseReportOverallSeverity;
    repositoryId: string;
    repositoryName: string;
    summary: string;
    trafficContext: GetVulnerabilityDiscoveryReportResponseReportTrafficContext;
    externalLinks?: GetVulnerabilityDiscoveryReportResponseReportExternalLinksList | null;
    limitations?: GetVulnerabilityDiscoveryReportResponseReportLimitationsList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetVulnerabilityDiscoveryReportResponse {
    publication: GetVulnerabilityDiscoveryReportResponsePublication;
    report: GetVulnerabilityDiscoveryReportResponseReport;
    repositoryId: string;
    scanId: string;
}
export interface GetVulnerabilityDiscoveryRepositoryRequest {
    accountId: string;
    repoId: string;
    scanCursor?: string;
    scanLimit?: number;
}
export type GetVulnerabilityDiscoveryRepositoryResponseRepositoryReadiness = "awaiting_source" | "processing" | "ready" | "failed";
export type GetVulnerabilityDiscoveryRepositoryResponseRepositorySource = "upload" | "worker";
export type GetVulnerabilityDiscoveryRepositoryResponseRepositoryImportErrorCode = "worker_import_failed";
export type GetVulnerabilityDiscoveryRepositoryResponseRepositoryImportErrorMessage = "Worker import failed.";
export interface GetVulnerabilityDiscoveryRepositoryResponseRepositoryImportError {
    code: GetVulnerabilityDiscoveryRepositoryResponseRepositoryImportErrorCode;
    message: GetVulnerabilityDiscoveryRepositoryResponseRepositoryImportErrorMessage;
}
export interface GetVulnerabilityDiscoveryRepositoryResponseRepository {
    id: string;
    createdAt: string;
    name: string;
    /** Source state. `awaiting_source`: the upload repository's default branch has no commits yet. `processing`: an import is in progress. `ready`: source is available. `failed`: the Worker import failed or could not be verified. */
    readiness: GetVulnerabilityDiscoveryRepositoryResponseRepositoryReadiness;
    source: GetVulnerabilityDiscoveryRepositoryResponseRepositorySource;
    importError?: GetVulnerabilityDiscoveryRepositoryResponseRepositoryImportError | null;
}
export type GetVulnerabilityDiscoveryRepositoryResponseScansItemPhase = "provisioning" | "indexing" | "analyzing" | "reporting" | "finalizing";
export type GetVulnerabilityDiscoveryRepositoryResponseScansItemRepositoriesItemPhase = "provisioning" | "indexing" | "analyzing" | "reporting" | "finalizing";
export type GetVulnerabilityDiscoveryRepositoryResponseScansItemRepositoriesItemReportStatus = "not_ready" | "pending_review" | "published" | "withdrawn";
export type GetVulnerabilityDiscoveryRepositoryResponseScansItemRepositoriesItemStatus = "requested" | "accepted" | "running" | "completed" | "failed" | "rejected" | "cancelled";
export interface GetVulnerabilityDiscoveryRepositoryResponseScansItemRepositoriesItem {
    id: string;
    name: string;
    phase: GetVulnerabilityDiscoveryRepositoryResponseScansItemRepositoriesItemPhase;
    reportStatus: GetVulnerabilityDiscoveryRepositoryResponseScansItemRepositoriesItemReportStatus;
    status: GetVulnerabilityDiscoveryRepositoryResponseScansItemRepositoriesItemStatus;
}
export type GetVulnerabilityDiscoveryRepositoryResponseScansItemRepositoriesList = Array<GetVulnerabilityDiscoveryRepositoryResponseScansItemRepositoriesItem>;
export type GetVulnerabilityDiscoveryRepositoryResponseScansItemStatus = "requested" | "accepted" | "running" | "completed" | "failed" | "rejected" | "cancelled";
export type GetVulnerabilityDiscoveryRepositoryResponseScansItemTelemetryWindow = CreateVulnerabilityDiscoveryScanRequestTelemetryWindow;
export interface GetVulnerabilityDiscoveryRepositoryResponseScansItem {
    id: string;
    completedAt: string;
    message: string;
    phase: GetVulnerabilityDiscoveryRepositoryResponseScansItemPhase;
    repositories: GetVulnerabilityDiscoveryRepositoryResponseScansItemRepositoriesList;
    startedAt: string;
    status: GetVulnerabilityDiscoveryRepositoryResponseScansItemStatus;
    submittedAt: string;
    /** UTC ISO-8601 interval. Start is inclusive, end is exclusive, and the interval must be positive and at most seven days. */
    telemetryWindow?: CreateVulnerabilityDiscoveryScanRequestTelemetryWindow | null;
}
export type GetVulnerabilityDiscoveryRepositoryResponseScansList = Array<GetVulnerabilityDiscoveryRepositoryResponseScansItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetVulnerabilityDiscoveryRepositoryResponse {
    repository: GetVulnerabilityDiscoveryRepositoryResponseRepository;
    scans: GetVulnerabilityDiscoveryRepositoryResponseScansList;
}
export interface GetVulnerabilityDiscoveryScanRequest {
    accountId: string;
    scanId: string;
}
export type GetVulnerabilityDiscoveryScanResponsePhase = "provisioning" | "indexing" | "analyzing" | "reporting" | "finalizing";
export type GetVulnerabilityDiscoveryScanResponseRepositoriesItemPhase = "provisioning" | "indexing" | "analyzing" | "reporting" | "finalizing";
export type GetVulnerabilityDiscoveryScanResponseRepositoriesItemReportStatus = "not_ready" | "pending_review" | "published" | "withdrawn";
export type GetVulnerabilityDiscoveryScanResponseRepositoriesItemStatus = "requested" | "accepted" | "running" | "completed" | "failed" | "rejected" | "cancelled";
export interface GetVulnerabilityDiscoveryScanResponseRepositoriesItem {
    id: string;
    name: string;
    phase: GetVulnerabilityDiscoveryScanResponseRepositoriesItemPhase;
    reportStatus: GetVulnerabilityDiscoveryScanResponseRepositoriesItemReportStatus;
    status: GetVulnerabilityDiscoveryScanResponseRepositoriesItemStatus;
}
export type GetVulnerabilityDiscoveryScanResponseRepositoriesList = Array<GetVulnerabilityDiscoveryScanResponseRepositoriesItem>;
export type GetVulnerabilityDiscoveryScanResponseStatus = "requested" | "accepted" | "running" | "completed" | "failed" | "rejected" | "cancelled";
export type GetVulnerabilityDiscoveryScanResponseTelemetryWindow = CreateVulnerabilityDiscoveryScanRequestTelemetryWindow;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetVulnerabilityDiscoveryScanResponse {
    id: string;
    completedAt: string;
    message: string;
    phase: GetVulnerabilityDiscoveryScanResponsePhase;
    repositories: GetVulnerabilityDiscoveryScanResponseRepositoriesList;
    startedAt: string;
    status: GetVulnerabilityDiscoveryScanResponseStatus;
    submittedAt: string;
    /** UTC ISO-8601 interval. Start is inclusive, end is exclusive, and the interval must be positive and at most seven days. */
    telemetryWindow?: CreateVulnerabilityDiscoveryScanRequestTelemetryWindow | null;
}
export interface ListVulnerabilityDiscoveryRepositoriesRequest {
    accountId: string;
    cursor?: string;
    limit?: number;
}
export type ListVulnerabilityDiscoveryRepositoriesResultItemReadiness = "awaiting_source" | "processing" | "ready" | "failed";
export type ListVulnerabilityDiscoveryRepositoriesResultItemSource = "upload" | "worker";
export type ListVulnerabilityDiscoveryRepositoriesResultItemImportErrorCode = "worker_import_failed";
export type ListVulnerabilityDiscoveryRepositoriesResultItemImportErrorMessage = "Worker import failed.";
export interface ListVulnerabilityDiscoveryRepositoriesResultItemImportError {
    code: ListVulnerabilityDiscoveryRepositoriesResultItemImportErrorCode;
    message: ListVulnerabilityDiscoveryRepositoriesResultItemImportErrorMessage;
}
export interface ListVulnerabilityDiscoveryRepositoriesResultItem {
    id: string;
    createdAt: string;
    name: string;
    /** Source state. `awaiting_source`: the upload repository's default branch has no commits yet. `processing`: an import is in progress. `ready`: source is available. `failed`: the Worker import failed or could not be verified. */
    readiness: ListVulnerabilityDiscoveryRepositoriesResultItemReadiness;
    source: ListVulnerabilityDiscoveryRepositoriesResultItemSource;
    importError?: ListVulnerabilityDiscoveryRepositoriesResultItemImportError | null;
}
export type ListVulnerabilityDiscoveryRepositoriesResultList = Array<ListVulnerabilityDiscoveryRepositoriesResultItem>;
export type ListVulnerabilityDiscoveryRepositoriesResponse = ListVulnerabilityDiscoveryRepositoriesResultList;
export type ListVulnerabilityDiscoveryScansRequestStatusCase0 = "requested" | "accepted" | "running" | "completed" | "failed" | "rejected" | "cancelled";
export type ListVulnerabilityDiscoveryScansRequestStatusCase1Item = "requested" | "accepted" | "running" | "completed" | "failed" | "rejected" | "cancelled";
export type ListVulnerabilityDiscoveryScansRequestStatusCase1List = Array<ListVulnerabilityDiscoveryScansRequestStatusCase1Item | (string & {})>;
export type ListVulnerabilityDiscoveryScansRequestStatus = ListVulnerabilityDiscoveryScansRequestStatusCase0 | (string & {}) | ListVulnerabilityDiscoveryScansRequestStatusCase1List;
export interface ListVulnerabilityDiscoveryScansRequest {
    accountId: string;
    cursor?: string;
    limit?: number;
    repo?: string;
    /** Repeat parameter or provide comma-separated values. */
    status?: ListVulnerabilityDiscoveryScansRequestStatus;
}
export type ListVulnerabilityDiscoveryScansResultItemPhase = "provisioning" | "indexing" | "analyzing" | "reporting" | "finalizing";
export type ListVulnerabilityDiscoveryScansResultItemRepositoriesItemPhase = "provisioning" | "indexing" | "analyzing" | "reporting" | "finalizing";
export type ListVulnerabilityDiscoveryScansResultItemRepositoriesItemReportStatus = "not_ready" | "pending_review" | "published" | "withdrawn";
export type ListVulnerabilityDiscoveryScansResultItemRepositoriesItemStatus = "requested" | "accepted" | "running" | "completed" | "failed" | "rejected" | "cancelled";
export interface ListVulnerabilityDiscoveryScansResultItemRepositoriesItem {
    id: string;
    name: string;
    phase: ListVulnerabilityDiscoveryScansResultItemRepositoriesItemPhase;
    reportStatus: ListVulnerabilityDiscoveryScansResultItemRepositoriesItemReportStatus;
    status: ListVulnerabilityDiscoveryScansResultItemRepositoriesItemStatus;
}
export type ListVulnerabilityDiscoveryScansResultItemRepositoriesList = Array<ListVulnerabilityDiscoveryScansResultItemRepositoriesItem>;
export type ListVulnerabilityDiscoveryScansResultItemStatus = "requested" | "accepted" | "running" | "completed" | "failed" | "rejected" | "cancelled";
export type ListVulnerabilityDiscoveryScansResultItemTelemetryWindow = CreateVulnerabilityDiscoveryScanRequestTelemetryWindow;
export interface ListVulnerabilityDiscoveryScansResultItem {
    id: string;
    completedAt: string;
    message: string;
    phase: ListVulnerabilityDiscoveryScansResultItemPhase;
    repositories: ListVulnerabilityDiscoveryScansResultItemRepositoriesList;
    startedAt: string;
    status: ListVulnerabilityDiscoveryScansResultItemStatus;
    submittedAt: string;
    /** UTC ISO-8601 interval. Start is inclusive, end is exclusive, and the interval must be positive and at most seven days. */
    telemetryWindow?: CreateVulnerabilityDiscoveryScanRequestTelemetryWindow | null;
}
export type ListVulnerabilityDiscoveryScansResultList = Array<ListVulnerabilityDiscoveryScansResultItem>;
export type ListVulnerabilityDiscoveryScansResponse = ListVulnerabilityDiscoveryScansResultList;
export interface VulnerabilityDiscoveryScansGetReportRequest {
    accountId: string;
    scanId: string;
}
export type VulnerabilityDiscoveryScansGetReportResponsePublication = GetVulnerabilityDiscoveryReportResponsePublication;
export type VulnerabilityDiscoveryScansGetReportResponseReportOverallSeverity = "critical" | "high" | "medium" | "low" | "info";
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemConditionsList = Array<string>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemLocation = GetVulnerabilityDiscoveryReportResponseReportFindingsItemLocation;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemReachabilityItem = GetVulnerabilityDiscoveryReportResponseReportFindingsItemReachabilityItem;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemReachabilityList = Array<GetVulnerabilityDiscoveryReportResponseReportFindingsItemReachabilityItem>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemRemediation = GetVulnerabilityDiscoveryReportResponseReportFindingsItemRemediation;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemSeverity = "critical" | "high" | "medium" | "low" | "info";
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemTelemetryReferencesList = Array<string>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemTelemetryState = "no_route" | "no_telemetry" | "no_match" | "matched";
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemTelemetry {
    references: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemTelemetryReferencesList;
    state: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemTelemetryState;
}
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemTraceItem = GetVulnerabilityDiscoveryReportResponseReportFindingsItemTraceItem;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemTraceList = Array<GetVulnerabilityDiscoveryReportResponseReportFindingsItemTraceItem>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRulesBroadAction = "block" | "managed_challenge" | "js_challenge" | "log";
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRulesBroadConfidence = "low" | "medium" | "high";
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRulesBroad {
    action: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRulesBroadAction;
    confidence: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRulesBroadConfidence;
    description: string;
    expression: string;
    falsePositiveRisk: string;
    name: string;
    rationale: string;
}
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRulesTargetedAction = "block" | "managed_challenge" | "js_challenge" | "log";
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRulesTargetedConfidence = "low" | "medium" | "high";
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRulesTargeted {
    action: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRulesTargetedAction;
    confidence: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRulesTargetedConfidence;
    description: string;
    expression: string;
    falsePositiveRisk: string;
    name: string;
    rationale: string;
}
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRules {
    broad: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRulesBroad;
    targeted: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRulesTargeted;
}
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemAttackerPosition = "external" | "authenticated" | "internal" | "post_compromise";
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemExternalLinksItem = GetVulnerabilityDiscoveryReportResponseReportFindingsItemExternalLinksItem;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemExternalLinksList = Array<GetVulnerabilityDiscoveryReportResponseReportFindingsItemExternalLinksItem>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemImpactIdsList = Array<string>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemProofMethod = "structural" | "experimental" | "acquired_source" | "public_knowledge" | "team_question";
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemProofState = "closed" | "pending_source" | "pending_public" | "pending_experiment" | "pending_team";
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemThreatIdsList = Array<string>;
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItem {
    id: string;
    conditions: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemConditionsList;
    cwe: string;
    impact: string;
    location: GetVulnerabilityDiscoveryReportResponseReportFindingsItemLocation;
    reachability: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemReachabilityList;
    remediation: GetVulnerabilityDiscoveryReportResponseReportFindingsItemRemediation;
    rootCause: string;
    severity: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemSeverity;
    severityBasis: string;
    summary: string;
    telemetry: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemTelemetry;
    title: string;
    trace: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemTraceList;
    wafRules: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemWafRules;
    /** Least-privileged position required to trigger the finding. Optional on legacy report revisions. */
    attackerPosition?: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemAttackerPosition | null;
    externalLinks?: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemExternalLinksList | null;
    /** Accepted settled impact-charter premises cited by the finding. Optional on legacy report revisions. */
    impactIds?: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemImpactIdsList | null;
    /** One bounded unresolved proof question. Optional on legacy report revisions. */
    openQuestion?: string | null;
    /** Method used or needed to close the proof. Optional on legacy report revisions. */
    proofMethod?: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemProofMethod | null;
    /** Current proof lifecycle state. Optional on legacy report revisions. */
    proofState?: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemProofState | null;
    /** Accepted settled threat-model premises cited by the finding. Optional on legacy report revisions. */
    threatIds?: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItemThreatIdsList | null;
}
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsList = Array<VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsItem>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemOverallSeverity = "critical" | "high" | "medium" | "low" | "info";
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextHttpErrorPathsItem = GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttpErrorPathsItem;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextHttpErrorPathsList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttpErrorPathsItem>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextHttpHotPathsItem = GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttpHotPathsItem;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextHttpHotPathsList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextHttpHotPathsItem>;
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextHttp {
    errorPaths: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextHttpErrorPathsList;
    hotPaths: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextHttpHotPathsList;
    requestVolume: number;
}
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextTargetHostsList = Array<string>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextTargetKind = "worker" | "origin";
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextTargetTelemetryWindow = CreateVulnerabilityDiscoveryScanRequestTelemetryWindow;
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextTarget {
    hosts: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextTargetHostsList;
    kind: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextTargetKind;
    /** UTC ISO-8601 interval. Start is inclusive, end is exclusive, and the interval must be positive and at most seven days. */
    telemetryWindow?: CreateVulnerabilityDiscoveryScanRequestTelemetryWindow | null;
}
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWafRulesItemPathsItem = GetVulnerabilityDiscoveryReportResponseReportTrafficContextWafRulesItemPathsItem;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWafRulesItemPathsList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextWafRulesItemPathsItem>;
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWafRulesItem {
    id: string;
    hitVolume: number;
    paths: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWafRulesItemPathsList;
    ruleId: string;
    ruleVersion: number;
}
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWafRulesList = Array<VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWafRulesItem>;
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWaf {
    hitVolume: number;
    rules: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWafRulesList;
}
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsOperationsItemRiskLabelsItem = GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsItemRiskLabelsItem;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsOperationsItemRiskLabelsList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsItemRiskLabelsItem>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsOperationsItemPerformance = GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsItemPerformance;
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsOperationsItem {
    id: string;
    endpoint: string;
    host: string;
    method: string;
    riskLabels: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsOperationsItemRiskLabelsList;
    performance?: GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsOperationsItemPerformance | null;
}
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsOperationsList = Array<VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsOperationsItem>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsPathsItem = GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsPathsItem;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsPathsList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsPathsItem>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsRiskTypesItem = GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsRiskTypesItem;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsRiskTypesList = Array<GetVulnerabilityDiscoveryReportResponseReportTrafficContextWebAssetsRiskTypesItem>;
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssets {
    operations: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsOperationsList;
    paths: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsPathsList;
    riskTypes: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssetsRiskTypesList;
}
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContext {
    http: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextHttp;
    target: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextTarget;
    waf: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWaf;
    webAssets: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContextWebAssets;
}
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemExternalLinksItem = GetVulnerabilityDiscoveryReportResponseReportFindingsItemExternalLinksItem;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemExternalLinksList = Array<GetVulnerabilityDiscoveryReportResponseReportFindingsItemExternalLinksItem>;
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemLimitationsList = Array<string>;
export interface VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItem {
    findings: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemFindingsList;
    overallSeverity: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemOverallSeverity;
    repositoryId: string;
    repositoryName: string;
    summary: string;
    trafficContext: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemTrafficContext;
    externalLinks?: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemExternalLinksList | null;
    limitations?: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItemLimitationsList | null;
}
export type VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesList = Array<VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesItem>;
export type VulnerabilityDiscoveryScansGetReportResponseReportSchemaVersion = 2;
export interface VulnerabilityDiscoveryScansGetReportResponseReport {
    executiveSummary: string;
    /** Revision requests must echo the existing generation timestamp unchanged. */
    generatedAt: string;
    overallSeverity: VulnerabilityDiscoveryScansGetReportResponseReportOverallSeverity;
    repositories: VulnerabilityDiscoveryScansGetReportResponseReportRepositoriesList;
    schemaVersion: VulnerabilityDiscoveryScansGetReportResponseReportSchemaVersion;
    title: string;
}
export type VulnerabilityDiscoveryScansGetReportResponseRepositoriesItemReportStatus = "not_ready" | "pending_review" | "published" | "withdrawn";
export type VulnerabilityDiscoveryScansGetReportResponseRepositoriesItemScanStatus = "requested" | "accepted" | "running" | "completed" | "failed" | "rejected" | "cancelled";
export interface VulnerabilityDiscoveryScansGetReportResponseRepositoriesItem {
    id: string;
    name: string;
    reportStatus: VulnerabilityDiscoveryScansGetReportResponseRepositoriesItemReportStatus;
    scanStatus: VulnerabilityDiscoveryScansGetReportResponseRepositoriesItemScanStatus;
}
export type VulnerabilityDiscoveryScansGetReportResponseRepositoriesList = Array<VulnerabilityDiscoveryScansGetReportResponseRepositoriesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface VulnerabilityDiscoveryScansGetReportResponse {
    publication: GetVulnerabilityDiscoveryReportResponsePublication;
    report: VulnerabilityDiscoveryScansGetReportResponseReport;
    repositories: VulnerabilityDiscoveryScansGetReportResponseRepositoriesList;
    scanId: string;
}
export type CreateVulnerabilityDiscoveryRepositoryError = CloudflareOpError;
/** Creates an upload repository or reserves an asynchronous deployed Worker import by name. Worker imports require Idempotency-Key. Push upload source to `main` or specify the `branch` to scan in the scan request. */
export declare const createVulnerabilityDiscoveryRepository: API.OperationMethod<CreateVulnerabilityDiscoveryRepositoryRequest, CreateVulnerabilityDiscoveryRepositoryResponse, CreateVulnerabilityDiscoveryRepositoryError, CloudflareOpContext>;
export type CreateVulnerabilityDiscoveryScanError = CloudflareOpError;
/** Submits repository intent for operator review. This endpoint does not immediately start execution. Worker-imported repositories must be ready; explicit repository host scopes must be authorized and explicit branch selections must exist before the request is persisted. */
export declare const createVulnerabilityDiscoveryScan: API.OperationMethod<CreateVulnerabilityDiscoveryScanRequest, CreateVulnerabilityDiscoveryScanResponse, CreateVulnerabilityDiscoveryScanError, CloudflareOpContext>;
export type GetVulnerabilityDiscoveryReportError = CloudflareOpError;
/** Gets the repository projection of the active operator-reviewed scan report. `scan_id` is the customer scan's stable request ID. */
export declare const getVulnerabilityDiscoveryReport: API.OperationMethod<GetVulnerabilityDiscoveryReportRequest, GetVulnerabilityDiscoveryReportResponse, GetVulnerabilityDiscoveryReportError, CloudflareOpContext>;
export type GetVulnerabilityDiscoveryRepositoryError = CloudflareOpError;
/** Gets repository metadata, source readiness, and customer scan history. */
export declare const getVulnerabilityDiscoveryRepository: API.OperationMethod<GetVulnerabilityDiscoveryRepositoryRequest, GetVulnerabilityDiscoveryRepositoryResponse, GetVulnerabilityDiscoveryRepositoryError, CloudflareOpContext>;
export type GetVulnerabilityDiscoveryScanError = CloudflareOpError;
/** Gets one customer-requested scan across its review and execution lifecycle. */
export declare const getVulnerabilityDiscoveryScan: API.OperationMethod<GetVulnerabilityDiscoveryScanRequest, GetVulnerabilityDiscoveryScanResponse, GetVulnerabilityDiscoveryScanError, CloudflareOpContext>;
export type ListVulnerabilityDiscoveryRepositoriesError = CloudflareOpError;
/** Lists repositories available for vulnerability discovery in an account. */
export declare const listVulnerabilityDiscoveryRepositories: API.OperationMethod<ListVulnerabilityDiscoveryRepositoriesRequest, ListVulnerabilityDiscoveryRepositoriesResponse, ListVulnerabilityDiscoveryRepositoriesError, CloudflareOpContext>;
export type ListVulnerabilityDiscoveryScansError = CloudflareOpError;
/** Lists customer-requested scans across review and execution lifecycle states. */
export declare const listVulnerabilityDiscoveryScans: API.OperationMethod<ListVulnerabilityDiscoveryScansRequest, ListVulnerabilityDiscoveryScansResponse, ListVulnerabilityDiscoveryScansError, CloudflareOpContext>;
export type VulnerabilityDiscoveryScansGetReportError = CloudflareOpError;
/** Gets the active operator-reviewed scan report. Repository metadata records report readiness even when no publication is available. */
export declare const vulnerabilityDiscoveryScansGetReport: API.OperationMethod<VulnerabilityDiscoveryScansGetReportRequest, VulnerabilityDiscoveryScansGetReportResponse, VulnerabilityDiscoveryScansGetReportError, CloudflareOpContext>;
//# sourceMappingURL=managed_defense.d.ts.map