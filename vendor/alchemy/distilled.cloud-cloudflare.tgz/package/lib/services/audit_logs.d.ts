import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface ListRequestAction {
    /** Filters by the action type. */
    type?: string;
}
export interface ListRequestActor {
    /** Filters by the email address of the actor that made the change. */
    email?: string;
    /** Filters by the IP address of the request that made the change by specific IP address or valid CIDR Range. */
    ip?: string;
}
export type ListRequestDirection = "desc" | "asc";
export interface ListRequestZone {
    /** Filters by the name of the zone associated to the change. */
    name?: string;
}
export interface ListAuditLogsRequest {
    /** Identifier */
    accountId: string;
    /** Finds a specific log by its ID. */
    id?: string;
    action?: ListRequestAction;
    actor?: ListRequestActor;
    /** Limits the returned results to logs older than the specified date. A `full-date` that conforms to RFC3339. */
    before?: string;
    /** Changes the direction of the chronological sorting. */
    direction?: ListRequestDirection | (string & {});
    /** Indicates that this request is an export of logs in CSV format. */
    export?: boolean;
    /** Indicates whether or not to hide user level audit logs. */
    hideUserLogs?: boolean;
    /** Defines which page of results to return. */
    page?: number;
    /** Sets the number of results to return per page. */
    perPage?: number;
    /** Limits the returned results to logs newer than the specified date. A `full-date` that conforms to RFC3339. */
    since?: string;
    zone?: ListRequestZone;
}
export interface ListResultItemAction {
    /** A boolean that indicates if the action attempted was successful. */
    result?: boolean | null;
    /** A short string that describes the action that was performed. */
    type?: string | null;
}
export type ListResultItemActorType = "user" | "admin" | "Cloudflare";
export interface ListResultItemActor {
    /** The ID of the actor that performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null;
    /** The email of the user that performed the action. */
    email?: string | null;
    /** The IP address of the request that performed the action. */
    ip?: string | null;
    /** The type of actor, whether a User, Cloudflare Admin, or an Automated System. */
    type?: ListResultItemActorType | null;
}
export interface ListResultItemOwner {
    /** Identifier */
    id?: string | null;
}
export interface ListResultItemResource {
    /** An identifier for the resource that was affected by the action. */
    id?: string | null;
    /** A short string that describes the resource that was affected by the action. */
    type?: string | null;
}
export interface ListResultItem {
    /** A string that uniquely identifies the audit log. */
    id?: string | null;
    action?: ListResultItemAction | null;
    actor?: ListResultItemActor | null;
    /** The source of the event. */
    interface?: string | null;
    /** An object which can lend more context to the action being logged. This is a flexible value and varies between different actions. */
    metadata?: unknown | null;
    /** The new value of the resource that was modified. */
    newValue?: string | null;
    /** The value of the resource before it was modified. */
    oldValue?: string | null;
    owner?: ListResultItemOwner | null;
    resource?: ListResultItemResource | null;
    /** A UTC RFC3339 timestamp that specifies when the action being logged occured. */
    when?: string | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListAuditLogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ListAuditLogsError = CloudflareOpError;
/** Gets a list of audit logs for an account. Can be filtered by who made the change, on which zone, and the timeframe of the change. */
export declare const listAuditLogs: API.PaginatedOperationMethod<ListAuditLogsRequest, ListAuditLogsResponse, ListAuditLogsError, CloudflareOpContext, ListResultItem>;
//# sourceMappingURL=audit_logs.d.ts.map