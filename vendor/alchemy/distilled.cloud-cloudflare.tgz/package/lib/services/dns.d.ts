import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AclNotFound_base: S.TaggedErrorClass<"AclNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class AclNotFound extends /*@__PURE__*/ AclNotFound_base {
}
declare const DnsRecordAlreadyExists_base: S.TaggedErrorClass<"DnsRecordAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DnsRecordAlreadyExists extends /*@__PURE__*/ DnsRecordAlreadyExists_base {
}
declare const DnsSettingNotAvailable_base: S.TaggedErrorClass<"DnsSettingNotAvailable", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DnsSettingNotAvailable extends /*@__PURE__*/ DnsSettingNotAvailable_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const IncomingZoneTransferNotFound_base: S.TaggedErrorClass<"IncomingZoneTransferNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class IncomingZoneTransferNotFound extends /*@__PURE__*/ IncomingZoneTransferNotFound_base {
}
declare const InternalDnsNotAvailable_base: S.TaggedErrorClass<"InternalDnsNotAvailable", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InternalDnsNotAvailable extends /*@__PURE__*/ InternalDnsNotAvailable_base {
}
declare const OutgoingZoneTransferNotFound_base: S.TaggedErrorClass<"OutgoingZoneTransferNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class OutgoingZoneTransferNotFound extends /*@__PURE__*/ OutgoingZoneTransferNotFound_base {
}
declare const OutgoingZoneTransfersNotAllowed_base: S.TaggedErrorClass<"OutgoingZoneTransfersNotAllowed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class OutgoingZoneTransfersNotAllowed extends /*@__PURE__*/ OutgoingZoneTransfersNotAllowed_base {
}
declare const PeerNotFound_base: S.TaggedErrorClass<"PeerNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PeerNotFound extends /*@__PURE__*/ PeerNotFound_base {
}
declare const RecordNotFound_base: S.TaggedErrorClass<"RecordNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class RecordNotFound extends /*@__PURE__*/ RecordNotFound_base {
}
declare const TsigNotFound_base: S.TaggedErrorClass<"TsigNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TsigNotFound extends /*@__PURE__*/ TsigNotFound_base {
}
declare const ViewNotFound_base: S.TaggedErrorClass<"ViewNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ViewNotFound extends /*@__PURE__*/ ViewNotFound_base {
}
export interface RecordsBatchRequestDeletesItem {
    /** Identifier. */
    id: string;
}
export type RecordsBatchRequestDeletesList = Array<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemARecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemAAAARecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemCNAMERecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemMXRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemNSRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemOpenpgpkeyRecordType = "OPENPGPKEY";
export interface RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings {
    /** When enabled, only A records will be generated, and AAAA records will not be created. This setting is intended for exceptional cases. Note that this option only applies to proxied records and it has no effect on whether Cloudflare communicates with the origin using IPv4 or IPv6. */
    ipv4Only?: boolean;
    /** When enabled, only AAAA records will be generated, and A records will not be created. This setting is intended for exceptional cases. Note that this option only applies to proxied records and it has no effect on whether Cloudflare communicates with the origin using IPv4 or IPv6. */
    ipv6Only?: boolean;
}
export type RecordsBatchRequestPatchesItemOpenpgpkeyRecordTagsList = Array<string>;
export interface RecordsBatchRequestPatchesItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPatchesItemOpenpgpkeyRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordTagsList;
}
export type RecordsBatchRequestPatchesItemPTRRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemTXTRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemCAARecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemCERTRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemDNSKEYRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemDSRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemHTTPSRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemLOCRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemNAPTRRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemSMIMEARecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemSRVRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemSSHFPRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemSVCBRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemTLSARecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItemURIRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesItem = RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestPatchesItemOpenpgpkeyRecord | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPatchesList = Array<RecordsBatchRequestPatchesItem>;
export type RecordsBatchRequestPostsItemARecordType = "A";
export type RecordsBatchRequestPostsItemARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemARecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv4 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemARecordTagsList;
}
export type RecordsBatchRequestPostsItemAAAARecordType = "AAAA";
export type RecordsBatchRequestPostsItemAAAARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemAAAARecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemAAAARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemAAAARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv6 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemAAAARecordTagsList;
}
export type RecordsBatchRequestPostsItemCNAMERecordType = "CNAME";
export interface RecordsBatchRequestPostsItemCNAMERecordSettings {
    /** If enabled, causes the CNAME record to be resolved externally and the resulting address records (e.g., A and AAAA) to be returned instead of the CNAME record itself. This setting is unavailable for proxied records, since they are always flattened. */
    flattenCname?: boolean;
    /** When enabled, only A records will be generated, and AAAA records will not be created. This setting is intended for exceptional cases. Note that this option only applies to proxied records and it has no effect on whether Cloudflare communicates with the origin using IPv4 or IPv6. */
    ipv4Only?: boolean;
    /** When enabled, only AAAA records will be generated, and A records will not be created. This setting is intended for exceptional cases. Note that this option only applies to proxied records and it has no effect on whether Cloudflare communicates with the origin using IPv4 or IPv6. */
    ipv6Only?: boolean;
}
export type RecordsBatchRequestPostsItemCNAMERecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemCNAMERecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemCNAMERecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid hostname. Must not match the record's name. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPostsItemCNAMERecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemCNAMERecordTagsList;
}
export type RecordsBatchRequestPostsItemMXRecordType = "MX";
export type RecordsBatchRequestPostsItemMXRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemMXRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemMXRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemMXRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid mail server hostname. */
    content?: string;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemMXRecordTagsList;
}
export type RecordsBatchRequestPostsItemNSRecordType = "NS";
export type RecordsBatchRequestPostsItemNSRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemNSRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemNSRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemNSRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid name server host name. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemNSRecordTagsList;
}
export type RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordType = "OPENPGPKEY";
export type RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordTagsList;
}
export type RecordsBatchRequestPostsItemPTRRecordType = "PTR";
export type RecordsBatchRequestPostsItemPTRRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemPTRRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemPTRRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemPTRRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Domain name pointing to the address. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemPTRRecordTagsList;
}
export type RecordsBatchRequestPostsItemTXTRecordType = "TXT";
export type RecordsBatchRequestPostsItemTXTRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemTXTRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemTXTRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemTXTRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Text content for the record. The content must consist of quoted "character strings" (RFC 1035), each with a length of up to 255 bytes. Strings exceeding this allowed maximum length are automatically split. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemTXTRecordTagsList;
}
export type RecordsBatchRequestPostsItemCAARecordType = "CAA";
export interface RecordsBatchRequestPostsItemCAARecordData {
    /** Flags for the CAA record. */
    flags?: number;
    /** Name of the property controlled by this record (e.g.: issue, issuewild, iodef). */
    tag?: string;
    /** Value of the record. This field's semantics depend on the chosen tag. */
    value?: string;
}
export type RecordsBatchRequestPostsItemCAARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemCAARecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemCAARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemCAARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted CAA content. See 'data' to set CAA properties. */
    content?: string;
    /** Components of a CAA record. */
    data?: RecordsBatchRequestPostsItemCAARecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemCAARecordTagsList;
}
export type RecordsBatchRequestPostsItemCERTRecordType = "CERT";
export interface RecordsBatchRequestPostsItemCERTRecordData {
    /** Algorithm. */
    algorithm?: number;
    /** Certificate. */
    certificate?: string;
    /** Key Tag. */
    keyTag?: number;
    /** Type. */
    type?: number;
}
export type RecordsBatchRequestPostsItemCERTRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemCERTRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemCERTRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemCERTRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted CERT content. See 'data' to set CERT properties. */
    content?: string;
    /** Components of a CERT record. */
    data?: RecordsBatchRequestPostsItemCERTRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemCERTRecordTagsList;
}
export type RecordsBatchRequestPostsItemDNSKEYRecordType = "DNSKEY";
export interface RecordsBatchRequestPostsItemDNSKEYRecordData {
    /** Algorithm. */
    algorithm?: number;
    /** Flags. */
    flags?: number;
    /** Protocol. */
    protocol?: number;
    /** Public Key. */
    publicKey?: string;
}
export type RecordsBatchRequestPostsItemDNSKEYRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemDNSKEYRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemDNSKEYRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemDNSKEYRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted DNSKEY content. See 'data' to set DNSKEY properties. */
    content?: string;
    /** Components of a DNSKEY record. */
    data?: RecordsBatchRequestPostsItemDNSKEYRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemDNSKEYRecordTagsList;
}
export type RecordsBatchRequestPostsItemDSRecordType = "DS";
export interface RecordsBatchRequestPostsItemDSRecordData {
    /** Algorithm. */
    algorithm?: number;
    /** Digest. */
    digest?: string;
    /** Digest Type. */
    digestType?: number;
    /** Key Tag. */
    keyTag?: number;
}
export type RecordsBatchRequestPostsItemDSRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemDSRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemDSRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemDSRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted DS content. See 'data' to set DS properties. */
    content?: string;
    /** Components of a DS record. */
    data?: RecordsBatchRequestPostsItemDSRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemDSRecordTagsList;
}
export type RecordsBatchRequestPostsItemHTTPSRecordType = "HTTPS";
export interface RecordsBatchRequestPostsItemHTTPSRecordData {
    /** Priority. */
    priority?: number;
    /** Target. */
    target?: string;
    /** Value. */
    value?: string;
}
export type RecordsBatchRequestPostsItemHTTPSRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemHTTPSRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemHTTPSRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemHTTPSRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted HTTPS content. See 'data' to set HTTPS properties. */
    content?: string;
    /** Components of a HTTPS record. */
    data?: RecordsBatchRequestPostsItemHTTPSRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemHTTPSRecordTagsList;
}
export type RecordsBatchRequestPostsItemLOCRecordType = "LOC";
export type RecordsBatchRequestPostsItemLOCRecordDataLatDirection = "N" | "S";
export type RecordsBatchRequestPostsItemLOCRecordDataLongDirection = "E" | "W";
export interface RecordsBatchRequestPostsItemLOCRecordData {
    /** Altitude of location in meters. */
    altitude?: number;
    /** Degrees of latitude. */
    latDegrees?: number;
    /** Latitude direction. */
    latDirection?: RecordsBatchRequestPostsItemLOCRecordDataLatDirection | (string & {});
    /** Minutes of latitude. */
    latMinutes?: number;
    /** Seconds of latitude. */
    latSeconds?: number;
    /** Degrees of longitude. */
    longDegrees?: number;
    /** Longitude direction. */
    longDirection?: RecordsBatchRequestPostsItemLOCRecordDataLongDirection | (string & {});
    /** Minutes of longitude. */
    longMinutes?: number;
    /** Seconds of longitude. */
    longSeconds?: number;
    /** Horizontal precision of location. */
    precisionHorz?: number;
    /** Vertical precision of location. */
    precisionVert?: number;
    /** Size of location in meters. */
    size?: number;
}
export type RecordsBatchRequestPostsItemLOCRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemLOCRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemLOCRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemLOCRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted LOC content. See 'data' to set LOC properties. */
    content?: string;
    /** Components of a LOC record. */
    data?: RecordsBatchRequestPostsItemLOCRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemLOCRecordTagsList;
}
export type RecordsBatchRequestPostsItemNAPTRRecordType = "NAPTR";
export interface RecordsBatchRequestPostsItemNAPTRRecordData {
    /** Flags. */
    flags?: string;
    /** Order. */
    order?: number;
    /** Preference. */
    preference?: number;
    /** Regex. */
    regex?: string;
    /** Replacement. */
    replacement?: string;
    /** Service. */
    service?: string;
}
export type RecordsBatchRequestPostsItemNAPTRRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemNAPTRRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemNAPTRRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemNAPTRRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted NAPTR content. See 'data' to set NAPTR properties. */
    content?: string;
    /** Components of a NAPTR record. */
    data?: RecordsBatchRequestPostsItemNAPTRRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemNAPTRRecordTagsList;
}
export type RecordsBatchRequestPostsItemSMIMEARecordType = "SMIMEA";
export interface RecordsBatchRequestPostsItemSMIMEARecordData {
    /** Certificate. */
    certificate?: string;
    /** Matching Type. */
    matchingType?: number;
    /** Selector. */
    selector?: number;
    /** Usage. */
    usage?: number;
}
export type RecordsBatchRequestPostsItemSMIMEARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemSMIMEARecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemSMIMEARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemSMIMEARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted SMIMEA content. See 'data' to set SMIMEA properties. */
    content?: string;
    /** Components of a SMIMEA record. */
    data?: RecordsBatchRequestPostsItemSMIMEARecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemSMIMEARecordTagsList;
}
export type RecordsBatchRequestPostsItemSRVRecordType = "SRV";
export interface RecordsBatchRequestPostsItemSRVRecordData {
    /** The port of the service. */
    port?: number;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** A valid hostname. */
    target?: string;
    /** The record weight. */
    weight?: number;
}
export type RecordsBatchRequestPostsItemSRVRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemSRVRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemSRVRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemSRVRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Priority, weight, port, and SRV target. See 'data' for setting the individual component values. */
    content?: string;
    /** Components of a SRV record. */
    data?: RecordsBatchRequestPostsItemSRVRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemSRVRecordTagsList;
}
export type RecordsBatchRequestPostsItemSSHFPRecordType = "SSHFP";
export interface RecordsBatchRequestPostsItemSSHFPRecordData {
    /** Algorithm. */
    algorithm?: number;
    /** Fingerprint. */
    fingerprint?: string;
    /** Type. */
    type?: number;
}
export type RecordsBatchRequestPostsItemSSHFPRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemSSHFPRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemSSHFPRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemSSHFPRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted SSHFP content. See 'data' to set SSHFP properties. */
    content?: string;
    /** Components of a SSHFP record. */
    data?: RecordsBatchRequestPostsItemSSHFPRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemSSHFPRecordTagsList;
}
export type RecordsBatchRequestPostsItemSVCBRecordType = "SVCB";
export type RecordsBatchRequestPostsItemSVCBRecordData = RecordsBatchRequestPostsItemHTTPSRecordData;
export type RecordsBatchRequestPostsItemSVCBRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemSVCBRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemSVCBRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemSVCBRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted SVCB content. See 'data' to set SVCB properties. */
    content?: string;
    /** Components of a SVCB record. */
    data?: RecordsBatchRequestPostsItemHTTPSRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemSVCBRecordTagsList;
}
export type RecordsBatchRequestPostsItemTLSARecordType = "TLSA";
export type RecordsBatchRequestPostsItemTLSARecordData = RecordsBatchRequestPostsItemSMIMEARecordData;
export type RecordsBatchRequestPostsItemTLSARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemTLSARecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemTLSARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemTLSARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted TLSA content. See 'data' to set TLSA properties. */
    content?: string;
    /** Components of a TLSA record. */
    data?: RecordsBatchRequestPostsItemSMIMEARecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemTLSARecordTagsList;
}
export type RecordsBatchRequestPostsItemURIRecordType = "URI";
export interface RecordsBatchRequestPostsItemURIRecordData {
    /** The record content. */
    target?: string;
    /** The record weight. */
    weight?: number;
}
export type RecordsBatchRequestPostsItemURIRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPostsItemURIRecordTagsList = Array<string>;
export interface RecordsBatchRequestPostsItemURIRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemURIRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted URI content. See 'data' to set URI properties. */
    content?: string;
    /** Components of a URI record. */
    data?: RecordsBatchRequestPostsItemURIRecordData;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemURIRecordTagsList;
}
export type RecordsBatchRequestPostsItem = RecordsBatchRequestPostsItemARecord | RecordsBatchRequestPostsItemAAAARecord | RecordsBatchRequestPostsItemCNAMERecord | RecordsBatchRequestPostsItemMXRecord | RecordsBatchRequestPostsItemNSRecord | RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecord | RecordsBatchRequestPostsItemPTRRecord | RecordsBatchRequestPostsItemTXTRecord | RecordsBatchRequestPostsItemCAARecord | RecordsBatchRequestPostsItemCERTRecord | RecordsBatchRequestPostsItemDNSKEYRecord | RecordsBatchRequestPostsItemDSRecord | RecordsBatchRequestPostsItemHTTPSRecord | RecordsBatchRequestPostsItemLOCRecord | RecordsBatchRequestPostsItemNAPTRRecord | RecordsBatchRequestPostsItemSMIMEARecord | RecordsBatchRequestPostsItemSRVRecord | RecordsBatchRequestPostsItemSSHFPRecord | RecordsBatchRequestPostsItemSVCBRecord | RecordsBatchRequestPostsItemTLSARecord | RecordsBatchRequestPostsItemURIRecord;
export type RecordsBatchRequestPostsList = Array<RecordsBatchRequestPostsItem>;
export type RecordsBatchRequestPutsItemARecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemAAAARecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemCNAMERecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemMXRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemNSRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemOpenpgpkeyRecordType = "OPENPGPKEY";
export type RecordsBatchRequestPutsItemOpenpgpkeyRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsBatchRequestPutsItemOpenpgpkeyRecordTagsList = Array<string>;
export interface RecordsBatchRequestPutsItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPutsItemOpenpgpkeyRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPutsItemOpenpgpkeyRecordTagsList;
}
export type RecordsBatchRequestPutsItemPTRRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemTXTRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemCAARecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemCERTRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemDNSKEYRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemDSRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemHTTPSRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemLOCRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemNAPTRRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemSMIMEARecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemSRVRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemSSHFPRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemSVCBRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemTLSARecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItemURIRecord = RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsItem = RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestPutsItemOpenpgpkeyRecord | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem;
export type RecordsBatchRequestPutsList = Array<RecordsBatchRequestPutsItem>;
export interface BatchRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether to include shadow metadata in the `meta` field of each record in the response. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    includeShadowMetadata?: boolean;
    deletes?: RecordsBatchRequestDeletesList;
    patches?: RecordsBatchRequestPatchesList;
    posts?: RecordsBatchRequestPostsList;
    puts?: RecordsBatchRequestPutsList;
}
export type RecordsBatchResponseDeletesItemARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemAAAARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemCNAMERecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemMXRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemNSRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings {
    /** When enabled, only A records will be generated, and AAAA records will not be created. This setting is intended for exceptional cases. Note that this option only applies to proxied records and it has no effect on whether Cloudflare communicates with the origin using IPv4 or IPv6. */
    ipv4Only?: boolean | null;
    /** When enabled, only AAAA records will be generated, and A records will not be created. This setting is intended for exceptional cases. Note that this option only applies to proxied records and it has no effect on whether Cloudflare communicates with the origin using IPv4 or IPv6. */
    ipv6Only?: boolean | null;
}
export type RecordsBatchResponseDeletesItemOpenpgpkeyRecordTagsList = Array<string>;
export type RecordsBatchResponseDeletesItemOpenpgpkeyRecordType = "OPENPGPKEY";
export interface RecordsBatchResponseDeletesItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsBatchResponseDeletesItemOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchResponseDeletesItemOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemTXTRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemCAARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemCERTRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemDNSKEYRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemDSRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemHTTPSRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemLOCRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemNAPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemSMIMEARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemSRVRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemSSHFPRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemSVCBRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemTLSARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItemURIRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponseDeletesItemURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponseDeletesItemURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponseDeletesItem = RecordsBatchResponseDeletesItemARecord | RecordsBatchResponseDeletesItemAAAARecord | RecordsBatchResponseDeletesItemCNAMERecord | RecordsBatchResponseDeletesItemMXRecord | RecordsBatchResponseDeletesItemNSRecord | RecordsBatchResponseDeletesItemOpenpgpkeyRecord | RecordsBatchResponseDeletesItemPTRRecord | RecordsBatchResponseDeletesItemTXTRecord | RecordsBatchResponseDeletesItemCAARecord | RecordsBatchResponseDeletesItemCERTRecord | RecordsBatchResponseDeletesItemDNSKEYRecord | RecordsBatchResponseDeletesItemDSRecord | RecordsBatchResponseDeletesItemHTTPSRecord | RecordsBatchResponseDeletesItemLOCRecord | RecordsBatchResponseDeletesItemNAPTRRecord | RecordsBatchResponseDeletesItemSMIMEARecord | RecordsBatchResponseDeletesItemSRVRecord | RecordsBatchResponseDeletesItemSSHFPRecord | RecordsBatchResponseDeletesItemSVCBRecord | RecordsBatchResponseDeletesItemTLSARecord | RecordsBatchResponseDeletesItemURIRecord;
export type RecordsBatchResponseDeletesList = Array<RecordsBatchResponseDeletesItem>;
export type RecordsBatchResponsePatchesItemARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemAAAARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemCNAMERecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemMXRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemNSRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsBatchResponsePatchesItemOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export type RecordsBatchResponsePatchesItemOpenpgpkeyRecordTagsList = Array<string>;
export type RecordsBatchResponsePatchesItemOpenpgpkeyRecordType = "OPENPGPKEY";
export interface RecordsBatchResponsePatchesItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsBatchResponsePatchesItemOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchResponsePatchesItemOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemTXTRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemCAARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemCERTRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemDNSKEYRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemDSRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemHTTPSRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemLOCRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemNAPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemSMIMEARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemSRVRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemSSHFPRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemSVCBRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemTLSARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItemURIRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePatchesItemURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePatchesItemURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePatchesItemURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePatchesItemURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePatchesItem = RecordsBatchResponsePatchesItemARecord | RecordsBatchResponsePatchesItemAAAARecord | RecordsBatchResponsePatchesItemCNAMERecord | RecordsBatchResponsePatchesItemMXRecord | RecordsBatchResponsePatchesItemNSRecord | RecordsBatchResponsePatchesItemOpenpgpkeyRecord | RecordsBatchResponsePatchesItemPTRRecord | RecordsBatchResponsePatchesItemTXTRecord | RecordsBatchResponsePatchesItemCAARecord | RecordsBatchResponsePatchesItemCERTRecord | RecordsBatchResponsePatchesItemDNSKEYRecord | RecordsBatchResponsePatchesItemDSRecord | RecordsBatchResponsePatchesItemHTTPSRecord | RecordsBatchResponsePatchesItemLOCRecord | RecordsBatchResponsePatchesItemNAPTRRecord | RecordsBatchResponsePatchesItemSMIMEARecord | RecordsBatchResponsePatchesItemSRVRecord | RecordsBatchResponsePatchesItemSSHFPRecord | RecordsBatchResponsePatchesItemSVCBRecord | RecordsBatchResponsePatchesItemTLSARecord | RecordsBatchResponsePatchesItemURIRecord;
export type RecordsBatchResponsePatchesList = Array<RecordsBatchResponsePatchesItem>;
export type RecordsBatchResponsePostsItemARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemAAAARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemCNAMERecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemMXRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemNSRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsBatchResponsePostsItemOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export type RecordsBatchResponsePostsItemOpenpgpkeyRecordTagsList = Array<string>;
export type RecordsBatchResponsePostsItemOpenpgpkeyRecordType = "OPENPGPKEY";
export interface RecordsBatchResponsePostsItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsBatchResponsePostsItemOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchResponsePostsItemOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemTXTRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemCAARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemCERTRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemDNSKEYRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemDSRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemHTTPSRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemLOCRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemNAPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemSMIMEARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemSRVRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemSSHFPRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemSVCBRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemTLSARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItemURIRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePostsItemURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePostsItemURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePostsItemURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePostsItemURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePostsItem = RecordsBatchResponsePostsItemARecord | RecordsBatchResponsePostsItemAAAARecord | RecordsBatchResponsePostsItemCNAMERecord | RecordsBatchResponsePostsItemMXRecord | RecordsBatchResponsePostsItemNSRecord | RecordsBatchResponsePostsItemOpenpgpkeyRecord | RecordsBatchResponsePostsItemPTRRecord | RecordsBatchResponsePostsItemTXTRecord | RecordsBatchResponsePostsItemCAARecord | RecordsBatchResponsePostsItemCERTRecord | RecordsBatchResponsePostsItemDNSKEYRecord | RecordsBatchResponsePostsItemDSRecord | RecordsBatchResponsePostsItemHTTPSRecord | RecordsBatchResponsePostsItemLOCRecord | RecordsBatchResponsePostsItemNAPTRRecord | RecordsBatchResponsePostsItemSMIMEARecord | RecordsBatchResponsePostsItemSRVRecord | RecordsBatchResponsePostsItemSSHFPRecord | RecordsBatchResponsePostsItemSVCBRecord | RecordsBatchResponsePostsItemTLSARecord | RecordsBatchResponsePostsItemURIRecord;
export type RecordsBatchResponsePostsList = Array<RecordsBatchResponsePostsItem>;
export type RecordsBatchResponsePutsItemARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemAAAARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemCNAMERecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemMXRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemNSRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsBatchResponsePutsItemOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export type RecordsBatchResponsePutsItemOpenpgpkeyRecordTagsList = Array<string>;
export type RecordsBatchResponsePutsItemOpenpgpkeyRecordType = "OPENPGPKEY";
export interface RecordsBatchResponsePutsItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsBatchResponsePutsItemOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchResponsePutsItemOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemTXTRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemCAARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemCERTRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemDNSKEYRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemDSRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemHTTPSRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemLOCRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemNAPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemSMIMEARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemSRVRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemSSHFPRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemSVCBRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemTLSARecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItemURIRecordMetaShadowedByList = Array<string>;
export interface RecordsBatchResponsePutsItemURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponsePutsItemURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsBatchResponsePutsItemURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponsePutsItemURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsBatchResponsePutsItem = RecordsBatchResponsePutsItemARecord | RecordsBatchResponsePutsItemAAAARecord | RecordsBatchResponsePutsItemCNAMERecord | RecordsBatchResponsePutsItemMXRecord | RecordsBatchResponsePutsItemNSRecord | RecordsBatchResponsePutsItemOpenpgpkeyRecord | RecordsBatchResponsePutsItemPTRRecord | RecordsBatchResponsePutsItemTXTRecord | RecordsBatchResponsePutsItemCAARecord | RecordsBatchResponsePutsItemCERTRecord | RecordsBatchResponsePutsItemDNSKEYRecord | RecordsBatchResponsePutsItemDSRecord | RecordsBatchResponsePutsItemHTTPSRecord | RecordsBatchResponsePutsItemLOCRecord | RecordsBatchResponsePutsItemNAPTRRecord | RecordsBatchResponsePutsItemSMIMEARecord | RecordsBatchResponsePutsItemSRVRecord | RecordsBatchResponsePutsItemSSHFPRecord | RecordsBatchResponsePutsItemSVCBRecord | RecordsBatchResponsePutsItemTLSARecord | RecordsBatchResponsePutsItemURIRecord;
export type RecordsBatchResponsePutsList = Array<RecordsBatchResponsePutsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BatchRecordResponse {
    deletes?: RecordsBatchResponseDeletesList | null;
    patches?: RecordsBatchResponsePatchesList | null;
    posts?: RecordsBatchResponsePostsList | null;
    puts?: RecordsBatchResponsePutsList | null;
}
export type RecordsCreateRequestType = "A" | "AAAA" | "CNAME" | "MX" | "NS" | "OPENPGPKEY" | "PTR" | "TXT" | "CAA" | "CERT" | "DNSKEY" | "DS" | "HTTPS" | "LOC" | "NAPTR" | "SMIMEA" | "SRV" | "SSHFP" | "SVCB" | "TLSA" | "URI";
export type RecordsCreateRequestSettingsARecord = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsCreateRequestSettingsCNAMERecord = RecordsBatchRequestPostsItemCNAMERecordSettings;
export type RecordsCreateRequestSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings | RecordsBatchRequestPostsItemCNAMERecordSettings;
export type RecordsCreateRequestTagsList = Array<string>;
export type RecordsCreateRequestDataCAARecord = RecordsBatchRequestPostsItemCAARecordData;
export type RecordsCreateRequestDataCERTRecord = RecordsBatchRequestPostsItemCERTRecordData;
export type RecordsCreateRequestDataDNSKEYRecord = RecordsBatchRequestPostsItemDNSKEYRecordData;
export type RecordsCreateRequestDataDSRecord = RecordsBatchRequestPostsItemDSRecordData;
export type RecordsCreateRequestDataHTTPSRecord = RecordsBatchRequestPostsItemHTTPSRecordData;
export type RecordsCreateRequestDataLOCRecordLatDirection = "N" | "S";
export type RecordsCreateRequestDataLOCRecordLongDirection = "E" | "W";
export interface RecordsCreateRequestDataLOCRecord {
    /** Altitude of location in meters. */
    altitude?: number;
    /** Degrees of latitude. */
    latDegrees?: number;
    /** Latitude direction. */
    latDirection?: RecordsCreateRequestDataLOCRecordLatDirection | (string & {});
    /** Minutes of latitude. */
    latMinutes?: number;
    /** Seconds of latitude. */
    latSeconds?: number;
    /** Degrees of longitude. */
    longDegrees?: number;
    /** Longitude direction. */
    longDirection?: RecordsCreateRequestDataLOCRecordLongDirection | (string & {});
    /** Minutes of longitude. */
    longMinutes?: number;
    /** Seconds of longitude. */
    longSeconds?: number;
    /** Horizontal precision of location. */
    precisionHorz?: number;
    /** Vertical precision of location. */
    precisionVert?: number;
    /** Size of location in meters. */
    size?: number;
}
export type RecordsCreateRequestDataNAPTRRecord = RecordsBatchRequestPostsItemNAPTRRecordData;
export type RecordsCreateRequestDataSMIMEARecord = RecordsBatchRequestPostsItemSMIMEARecordData;
export type RecordsCreateRequestDataSRVRecord = RecordsBatchRequestPostsItemSRVRecordData;
export type RecordsCreateRequestDataSSHFPRecord = RecordsBatchRequestPostsItemSSHFPRecordData;
export type RecordsCreateRequestDataURIRecord = RecordsBatchRequestPostsItemURIRecordData;
export type RecordsCreateRequestData = RecordsBatchRequestPostsItemCAARecordData | RecordsBatchRequestPostsItemCERTRecordData | RecordsBatchRequestPostsItemDNSKEYRecordData | RecordsBatchRequestPostsItemDSRecordData | RecordsBatchRequestPostsItemHTTPSRecordData | RecordsCreateRequestDataLOCRecord | RecordsBatchRequestPostsItemNAPTRRecordData | RecordsBatchRequestPostsItemSMIMEARecordData | RecordsBatchRequestPostsItemSRVRecordData | RecordsBatchRequestPostsItemSSHFPRecordData | RecordsBatchRequestPostsItemURIRecordData;
export interface CreateRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether to include shadow metadata in the `meta` field of each record in the response. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    includeShadowMetadata?: boolean;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsCreateRequestType | (string & {});
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv4 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsCreateRequestSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsCreateRequestTagsList;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Components of a CAA record. */
    data?: RecordsCreateRequestData;
}
export type RecordsCreateResultARecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeA = "A";
export type DnsRecordTagsList = Array<string>;
export interface RecordsCreateResultARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultAAAARecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeAAAA = "AAAA";
export interface RecordsCreateResultAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeAAAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultCNAMERecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeCNAME = "CNAME";
export interface RecordsCreateResultCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCNAME;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultMXRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeMX = "MX";
export interface RecordsCreateResultMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeMX;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultNSRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeNS = "NS";
export interface RecordsCreateResultNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsCreateResultOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export type RecordsCreateResultOpenpgpkeyRecordTagsList = Array<string>;
export type RecordsCreateResultOpenpgpkeyRecordType = "OPENPGPKEY";
export interface RecordsCreateResultOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsCreateResultOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsCreateResultOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsCreateResultPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypePTR = "PTR";
export interface RecordsCreateResultPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypePTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultTXTRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeTXT = "TXT";
export interface RecordsCreateResultTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTXT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultCAARecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeCAA = "CAA";
export interface RecordsCreateResultCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultCERTRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeCERT = "CERT";
export interface RecordsCreateResultCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCERT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultDNSKEYRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeDNSKEY = "DNSKEY";
export interface RecordsCreateResultDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDNSKEY;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultDSRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeDS = "DS";
export interface RecordsCreateResultDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultHTTPSRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeHTTPS = "HTTPS";
export interface RecordsCreateResultHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeHTTPS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultLOCRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeLOC = "LOC";
export interface RecordsCreateResultLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeLOC;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultNAPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeNAPTR = "NAPTR";
export interface RecordsCreateResultNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNAPTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultSMIMEARecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeSMIMEA = "SMIMEA";
export interface RecordsCreateResultSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSMIMEA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultSRVRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeSRV = "SRV";
export interface RecordsCreateResultSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSRV;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultSSHFPRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeSSHFP = "SSHFP";
export interface RecordsCreateResultSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSSHFP;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultSVCBRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeSVCB = "SVCB";
export interface RecordsCreateResultSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSVCB;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultTLSARecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeTLSA = "TLSA";
export interface RecordsCreateResultTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTLSA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResultURIRecordMetaShadowedByList = Array<string>;
export interface RecordsCreateResultURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type DnsRecordTypeURI = "URI";
export interface RecordsCreateResultURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeURI;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsCreateResult = RecordsCreateResultARecord | RecordsCreateResultAAAARecord | RecordsCreateResultCNAMERecord | RecordsCreateResultMXRecord | RecordsCreateResultNSRecord | RecordsCreateResultOpenpgpkeyRecord | RecordsCreateResultPTRRecord | RecordsCreateResultTXTRecord | RecordsCreateResultCAARecord | RecordsCreateResultCERTRecord | RecordsCreateResultDNSKEYRecord | RecordsCreateResultDSRecord | RecordsCreateResultHTTPSRecord | RecordsCreateResultLOCRecord | RecordsCreateResultNAPTRRecord | RecordsCreateResultSMIMEARecord | RecordsCreateResultSRVRecord | RecordsCreateResultSSHFPRecord | RecordsCreateResultSVCBRecord | RecordsCreateResultTLSARecord | RecordsCreateResultURIRecord;
export type CreateRecordResponse = RecordsCreateResult;
export type SettingsAccountViewsCreateRequestZonesList = Array<string>;
export interface CreateSettingAccountViewRequest {
    /** Identifier. */
    accountId: string;
    /** The name of the view. */
    name: string;
    /** The list of zones linked to this view. */
    zones: SettingsAccountViewsCreateRequestZonesList;
}
export type SettingsAccountViewsCreateResponseZonesList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingAccountViewResponse {
    /** Identifier. */
    id: string;
    /** When the view was created. */
    createdTime: string;
    /** When the view was last modified. */
    modifiedTime: string;
    /** The name of the view. */
    name: string;
    /** The list of zones linked to this view. */
    zones: SettingsAccountViewsCreateResponseZonesList;
}
export interface CreateSettingsAccountNameserverSetRequestNameserversItem {
    /** A unique lowercase Punycode nameserver name within the set. */
    name: string;
    /** Number of IPv4 addresses and number of IPv6 addresses to allocate to this nameserver. All nameservers in an Advanced nameserver set must use the same value. */
    ipCount?: number;
}
export type CreateSettingsAccountNameserverSetRequestNameserversList = Array<CreateSettingsAccountNameserverSetRequestNameserversItem>;
export interface CreateSettingsAccountNameserverSetRequest {
    /** Identifier. */
    accountId: string;
    /** Lists each nameserver and the number of addresses to allocate to it. Requires a unique name for each entry in the set. */
    nameservers: CreateSettingsAccountNameserverSetRequestNameserversList;
    /** Whether to allocate the nameservers from distinct Advanced anycast groups. */
    advanced?: boolean;
    /** Selects the account-specific IP set that supplies the nameserver addresses. Nameserver sets with the same `ip_set` and `advanced` value may reuse addresses; otherwise, they use disjoint address groups. */
    ipSet?: number;
}
export type CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversItemIpv4List = Array<string>;
export type CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversItemIpv6List = Array<string>;
export interface CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversItem {
    /** IPv4 addresses assigned to the nameserver. */
    ipv4: CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversItemIpv4List;
    /** IPv6 addresses assigned to the nameserver. */
    ipv6: CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversItemIpv6List;
    /** A unique lowercase Punycode nameserver name within the set. */
    name: string;
}
export type CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversList = Array<CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversItem>;
export interface CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponse {
    /** Identifier for a nameserver set. */
    id: string;
    /** Whether the nameserver set uses Advanced anycast groups. */
    advanced: boolean;
    /** When the nameserver set was created. */
    createdOn: string;
    /** Selects the account-specific IP set that supplies the nameserver addresses. Nameserver sets with the same `ip_set` and `advanced` value may reuse addresses; otherwise, they use disjoint address groups. */
    ipSet: number;
    nameservers: CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversList;
}
export type CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4List = Array<string>;
export type CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4GroupsItem = "a" | "b" | "c";
export type CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4GroupsList = Array<CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4GroupsItem>;
export type CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6List = Array<string>;
export type CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6GroupsItem = "a" | "b" | "c";
export type CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6GroupsList = Array<CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6GroupsItem>;
export interface CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItem {
    /** IPv4 addresses assigned to the nameserver. */
    ipv4: CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4List;
    /** Advanced anycast group for each address in the corresponding address array. Entries have the same order as, and correspond one-to-one with, the addresses. */
    ipv4Groups: CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4GroupsList;
    /** IPv6 addresses assigned to the nameserver. */
    ipv6: CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6List;
    /** Advanced anycast group for each address in the corresponding address array. Entries have the same order as, and correspond one-to-one with, the addresses. */
    ipv6Groups: CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6GroupsList;
    /** A unique lowercase Punycode nameserver name within the set. */
    name: string;
}
export type CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversList = Array<CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItem>;
export interface CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponse {
    /** Identifier for a nameserver set. */
    id: string;
    /** Whether the nameserver set uses Advanced anycast groups. */
    advanced: boolean;
    /** When the nameserver set was created. */
    createdOn: string;
    /** Selects the account-specific IP set that supplies the nameserver addresses. Nameserver sets with the same `ip_set` and `advanced` value may reuse addresses; otherwise, they use disjoint address groups. */
    ipSet: number;
    nameservers: CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversList;
}
export type CreateSettingsAccountNameserverSetResult = CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponse | CreateSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponse;
export type CreateSettingsAccountNameserverSetResponse = CreateSettingsAccountNameserverSetResult;
export interface CreateZoneTransferAclRequest {
    accountId: string;
    /** Allowed IPv4/IPv6 address range of primary or secondary nameservers. This will be applied for the entire account. The IP range is used to allow additional NOTIFY IPs for secondary zones and IPs Cloudflare allows AXFR/IXFR requests from for primary zones. CIDRs are limited to a maximum of /24 for IPv4 and /64 for IPv6 respectively. */
    ipRange: string;
    /** The name of the acl. */
    name: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneTransferAclResponse {
    id: string;
    /** Allowed IPv4/IPv6 address range of primary or secondary nameservers. This will be applied for the entire account. The IP range is used to allow additional NOTIFY IPs for secondary zones and IPs Cloudflare allows AXFR/IXFR requests from for primary zones. CIDRs are limited to a maximum of /24 for IPv4 and /64 for IPv6 respectively. */
    ipRange: string;
    /** The name of the acl. */
    name: string;
}
export interface CreateZoneTransferForceAxfrRequest {
    zoneId: string;
}
export type CreateZoneTransferForceAxfrResponse = string;
export type ZoneTransfersIncomingCreateRequestPeersList = Array<string>;
export interface CreateZoneTransferIncomingRequest {
    zoneId: string;
    /** How often should a secondary zone auto refresh regardless of DNS NOTIFY. Not applicable for primary zones. */
    autoRefreshSeconds: number;
    /** Zone name. */
    name: string;
    /** A list of peer tags. */
    peers: ZoneTransfersIncomingCreateRequestPeersList;
}
export type ZoneTransfersIncomingCreateResponsePeersList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneTransferIncomingResponse {
    id?: string | null;
    /** How often should a secondary zone auto refresh regardless of DNS NOTIFY. Not applicable for primary zones. */
    autoRefreshSeconds?: number | null;
    /** The time for a specific event. */
    checkedTime?: string | null;
    /** The time for a specific event. */
    createdTime?: string | null;
    /** The time for a specific event. */
    modifiedTime?: string | null;
    /** Zone name. */
    name?: string | null;
    /** A list of peer tags. */
    peers?: ZoneTransfersIncomingCreateResponsePeersList | null;
    /** The serial number of the SOA for the given zone. */
    soaSerial?: number | null;
}
export type ZoneTransfersOutgoingCreateRequestPeersList = Array<string>;
export interface CreateZoneTransferOutgoingRequest {
    zoneId: string;
    /** Zone name. */
    name: string;
    /** A list of peer tags. */
    peers: ZoneTransfersOutgoingCreateRequestPeersList;
}
export type ZoneTransfersOutgoingCreateResponsePeersList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneTransferOutgoingResponse {
    id?: string | null;
    /** The time for a specific event. */
    checkedTime?: string | null;
    /** The time for a specific event. */
    createdTime?: string | null;
    /** The time for a specific event. */
    lastTransferredTime?: string | null;
    /** Zone name. */
    name?: string | null;
    /** A list of peer tags. */
    peers?: ZoneTransfersOutgoingCreateResponsePeersList | null;
    /** The serial number of the SOA for the given zone. */
    soaSerial?: number | null;
}
export interface CreateZoneTransferPeerRequest {
    accountId: string;
    /** The name of the peer. */
    name: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneTransferPeerResponse {
    id: string;
    /** The name of the peer. */
    name: string;
    /** IPv4/IPv6 address of primary or secondary nameserver, depending on what zone this peer is linked to. For primary zones this IP defines the IP of the secondary nameserver Cloudflare will NOTIFY upon zone changes. For secondary zones this IP defines the IP of the primary nameserver Cloudflare will send AXFR/IXFR requests to. */
    ip?: string | null;
    /** Enable IXFR transfer protocol, default is AXFR. Only applicable to secondary zones. */
    ixfrEnable?: boolean | null;
    /** DNS port of primary or secondary nameserver, depending on what zone this peer is linked to. */
    port?: number | null;
    /** TSIG authentication will be used for zone transfer if configured. */
    tsigId?: string | null;
}
export interface CreateZoneTransferTsigRequest {
    accountId: string;
    /** TSIG algorithm. */
    algo: string;
    /** TSIG key name. */
    name: string;
    /** TSIG secret. */
    secret: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneTransferTsigResponse {
    id: string;
    /** TSIG algorithm. */
    algo: string;
    /** TSIG key name. */
    name: string;
    /** TSIG secret. */
    secret: string;
}
export interface DeleteDnssecRequest {
    /** Identifier. */
    zoneId: string;
}
export type DeleteDnssecResponse = string;
export interface DeleteRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    dnsRecordId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRecordResponse {
    /** Identifier. */
    id?: string | null;
}
export interface DeleteSettingAccountViewRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    viewId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingAccountViewResponse {
    /** Identifier. */
    id?: string | null;
}
export interface DeleteSettingsAccountNameserverSetRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for a nameserver set. */
    nameserverSetId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingsAccountNameserverSetResponse {
    /** Identifier for a nameserver set. */
    id: string;
}
export interface DeleteZoneTransferAclRequest {
    accountId: string;
    aclId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneTransferAclResponse {
    id?: string | null;
}
export interface DeleteZoneTransferIncomingRequest {
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneTransferIncomingResponse {
    id?: string | null;
}
export interface DeleteZoneTransferOutgoingRequest {
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneTransferOutgoingResponse {
    id?: string | null;
}
export interface DeleteZoneTransferPeerRequest {
    accountId: string;
    peerId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneTransferPeerResponse {
    id?: string | null;
}
export interface DeleteZoneTransferTsigRequest {
    accountId: string;
    tsigId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneTransferTsigResponse {
    id?: string | null;
}
export interface DisableZoneTransferOutgoingRequest {
    zoneId: string;
}
export type DisableZoneTransferOutgoingResponse = string;
export interface EnableZoneTransferOutgoingRequest {
    zoneId: string;
}
export type EnableZoneTransferOutgoingResponse = string;
export interface ExportRecordRequest {
    /** Identifier. */
    zoneId: string;
}
export interface ExportRecordResponse {
}
export interface ForceNotifyZoneTransferOutgoingRequest {
    zoneId: string;
}
export type ForceNotifyZoneTransferOutgoingResponse = string;
export interface GetAnalyticReportRequest {
    /** Identifier. */
    zoneId: string;
    /** A comma-separated list of dimensions to group results by. */
    dimensions?: string;
    /** Segmentation filter in 'attribute operator value' format. */
    filters?: string;
    /** Limit number of returned metrics. */
    limit?: number;
    /** A comma-separated list of metrics to query. */
    metrics?: string;
    /** Start date and time of requesting data period in ISO 8601 format. */
    since?: string;
    /** A comma-separated list of dimensions to sort by, where each dimension may be prefixed by - (descending) or + (ascending). */
    sort?: string;
    /** End date and time of requesting data period in ISO 8601 format. */
    until?: string;
}
export type AnalyticsReportsGetResponseDataItemDimensionsList = Array<string>;
export type AnalyticsReportsGetResponseDataItemMetricsList = Array<number>;
export interface AnalyticsReportsGetResponseDataItem {
    /** Array of dimension values, representing the combination of dimension values corresponding to this row. */
    dimensions: AnalyticsReportsGetResponseDataItemDimensionsList;
    /** Array with one item per requested metric. Each item is a single value. */
    metrics: AnalyticsReportsGetResponseDataItemMetricsList;
}
export type AnalyticsReportsGetResponseDataList = Array<AnalyticsReportsGetResponseDataItem>;
export type AnalyticsReportsGetResponseQueryDimensionsList = Array<string>;
export type AnalyticsReportsGetResponseQueryMetricsList = Array<string>;
export type AnalyticsReportsGetResponseQuerySortList = Array<string>;
export interface AnalyticsReportsGetResponseQuery {
    /** Array of dimension names. */
    dimensions: AnalyticsReportsGetResponseQueryDimensionsList;
    /** Limit number of returned metrics. */
    limit: number;
    /** Array of metric names. */
    metrics: AnalyticsReportsGetResponseQueryMetricsList;
    /** Start date and time of requesting data period in ISO 8601 format. */
    since: string;
    /** End date and time of requesting data period in ISO 8601 format. */
    until: string;
    /** Segmentation filter in 'attribute operator value' format. */
    filters?: string | null;
    /** Array of dimensions to sort by, where each dimension may be prefixed by - (descending) or + (ascending). */
    sort?: AnalyticsReportsGetResponseQuerySortList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAnalyticReportResponse {
    /** Array with one row per combination of dimension values. */
    data: AnalyticsReportsGetResponseDataList;
    /** Number of seconds between current time and last processed event, in another words how many seconds of data could be missing. */
    dataLag: number;
    /** Maximum results for each metric (object mapping metric names to values). Currently always an empty object. */
    max: unknown;
    /** Minimum results for each metric (object mapping metric names to values). Currently always an empty object. */
    min: unknown;
    query: AnalyticsReportsGetResponseQuery;
    /** Total number of rows in the result. */
    rows: number;
    /** Total results for metrics across all data (object mapping metric names to values). */
    totals: unknown;
}
export type AnalyticsReportsBytimesGetRequestTimeDelta = "all" | "auto" | "year" | "quarter" | "month" | "week" | "day" | "hour" | "dekaminute" | "minute";
export interface GetAnalyticReportBytimeRequest {
    /** Identifier. */
    zoneId: string;
    /** A comma-separated list of dimensions to group results by. */
    dimensions?: string;
    /** Segmentation filter in 'attribute operator value' format. */
    filters?: string;
    /** Limit number of returned metrics. */
    limit?: number;
    /** A comma-separated list of metrics to query. */
    metrics?: string;
    /** Start date and time of requesting data period in ISO 8601 format. */
    since?: string;
    /** A comma-separated list of dimensions to sort by, where each dimension may be prefixed by - (descending) or + (ascending). */
    sort?: string;
    /** Unit of time to group data by. */
    timeDelta?: AnalyticsReportsBytimesGetRequestTimeDelta | (string & {});
    /** End date and time of requesting data period in ISO 8601 format. */
    until?: string;
}
export type AnalyticsReportsBytimesGetResponseDataItemDimensionsList = Array<string>;
export type AnalyticsReportsBytimesGetResponseDataItemMetricsItemList = Array<number>;
export type AnalyticsReportsBytimesGetResponseDataItemMetricsList = Array<AnalyticsReportsBytimesGetResponseDataItemMetricsItemList>;
export interface AnalyticsReportsBytimesGetResponseDataItem {
    /** Array of dimension values, representing the combination of dimension values corresponding to this row. */
    dimensions: AnalyticsReportsBytimesGetResponseDataItemDimensionsList;
    /** Array with one item per requested metric. Each item is an array of values, broken down by time interval. */
    metrics: AnalyticsReportsBytimesGetResponseDataItemMetricsList;
}
export type AnalyticsReportsBytimesGetResponseDataList = Array<AnalyticsReportsBytimesGetResponseDataItem>;
export type AnalyticsReportsBytimesGetResponseQueryDimensionsList = Array<string>;
export type AnalyticsReportsBytimesGetResponseQueryMetricsList = Array<string>;
export type AnalyticsReportsBytimesGetResponseQueryTimeDelta = "all" | "auto" | "year" | "quarter" | "month" | "week" | "day" | "hour" | "dekaminute" | "minute";
export type AnalyticsReportsBytimesGetResponseQuerySortList = Array<string>;
export interface AnalyticsReportsBytimesGetResponseQuery {
    /** Array of dimension names. */
    dimensions: AnalyticsReportsBytimesGetResponseQueryDimensionsList;
    /** Limit number of returned metrics. */
    limit: number;
    /** Array of metric names. */
    metrics: AnalyticsReportsBytimesGetResponseQueryMetricsList;
    /** Start date and time of requesting data period in ISO 8601 format. */
    since: string;
    /** Unit of time to group data by. */
    timeDelta: AnalyticsReportsBytimesGetResponseQueryTimeDelta;
    /** End date and time of requesting data period in ISO 8601 format. */
    until: string;
    /** Segmentation filter in 'attribute operator value' format. */
    filters?: string | null;
    /** Array of dimensions to sort by, where each dimension may be prefixed by - (descending) or + (ascending). */
    sort?: AnalyticsReportsBytimesGetResponseQuerySortList | null;
}
export type AnalyticsReportsBytimesGetResponseTimeIntervalsItemList = Array<string>;
export type AnalyticsReportsBytimesGetResponseTimeIntervalsList = Array<AnalyticsReportsBytimesGetResponseTimeIntervalsItemList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAnalyticReportBytimeResponse {
    /** Array with one row per combination of dimension values. */
    data: AnalyticsReportsBytimesGetResponseDataList;
    /** Number of seconds between current time and last processed event, in another words how many seconds of data could be missing. */
    dataLag: number;
    /** Maximum results for each metric (object mapping metric names to values). Currently always an empty object. */
    max: unknown;
    /** Minimum results for each metric (object mapping metric names to values). Currently always an empty object. */
    min: unknown;
    query: AnalyticsReportsBytimesGetResponseQuery;
    /** Total number of rows in the result. */
    rows: number;
    /** Array of time intervals in the response data. Each interval is represented as an array containing two values: the start time, and the end time. */
    timeIntervals: AnalyticsReportsBytimesGetResponseTimeIntervalsList;
    /** Total results for metrics across all data (object mapping metric names to values). */
    totals: unknown;
}
export interface GetDnssecRequest {
    /** Identifier. */
    zoneId: string;
}
export type DnssecGetResponseStatus = "active" | "pending" | "disabled" | "pending-disabled" | "error";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDnssecResponse {
    /** Algorithm key code. */
    algorithm?: string | null;
    /** Digest hash. */
    digest?: string | null;
    /** Type of digest algorithm. */
    digestAlgorithm?: string | null;
    /** Coded type for digest algorithm. */
    digestType?: string | null;
    /** If true, multi-signer DNSSEC is enabled on the zone, allowing multiple providers to serve a DNSSEC-signed zone at the same time. This is required for DNSKEY records (except those automatically generated by Cloudflare) to be added to the zone. */
    dnssecMultiSigner?: boolean | null;
    /** If true, allows Cloudflare to transfer in a DNSSEC-signed zone including signatures from an external provider, without requiring Cloudflare to sign any records on the fly. */
    dnssecPresigned?: boolean | null;
    /** If true, enables the use of NSEC3 together with DNSSEC on the zone. Combined with setting dnssec_presigned to true, this enables the use of NSEC3 records when transferring in from an external provider. If dnssec_presigned is instead set to false (default), NSEC3 records will be generated and signed at request time. */
    dnssecUseNsec3?: boolean | null;
    /** Full DS record. */
    ds?: string | null;
    /** Flag for DNSSEC record. */
    flags?: number | null;
    /** Code for key tag. */
    keyTag?: number | null;
    /** Algorithm key type. */
    keyType?: string | null;
    /** When DNSSEC was last modified. */
    modifiedOn?: string | null;
    /** Public key for DS record. */
    publicKey?: string | null;
    /** Status of DNSSEC, based on user-desired state and presence of necessary records. */
    status?: DnssecGetResponseStatus | null;
}
export interface GetRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    dnsRecordId: string;
    /** Whether to include shadow metadata in the `meta` field of each record in the response. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    includeShadowMetadata?: boolean;
}
export type RecordsGetResultARecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultAAAARecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeAAAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultCNAMERecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCNAME;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultMXRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeMX;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultNSRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsGetResultOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export type RecordsGetResultOpenpgpkeyRecordTagsList = Array<string>;
export type RecordsGetResultOpenpgpkeyRecordType = "OPENPGPKEY";
export interface RecordsGetResultOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsGetResultOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsGetResultOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsGetResultPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypePTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultTXTRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTXT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultCAARecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultCERTRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCERT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultDNSKEYRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDNSKEY;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultDSRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultHTTPSRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeHTTPS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultLOCRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeLOC;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultNAPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNAPTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultSMIMEARecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSMIMEA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultSRVRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSRV;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultSSHFPRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSSHFP;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultSVCBRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSVCB;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultTLSARecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTLSA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResultURIRecordMetaShadowedByList = Array<string>;
export interface RecordsGetResultURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsGetResultURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeURI;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsGetResult = RecordsGetResultARecord | RecordsGetResultAAAARecord | RecordsGetResultCNAMERecord | RecordsGetResultMXRecord | RecordsGetResultNSRecord | RecordsGetResultOpenpgpkeyRecord | RecordsGetResultPTRRecord | RecordsGetResultTXTRecord | RecordsGetResultCAARecord | RecordsGetResultCERTRecord | RecordsGetResultDNSKEYRecord | RecordsGetResultDSRecord | RecordsGetResultHTTPSRecord | RecordsGetResultLOCRecord | RecordsGetResultNAPTRRecord | RecordsGetResultSMIMEARecord | RecordsGetResultSRVRecord | RecordsGetResultSSHFPRecord | RecordsGetResultSVCBRecord | RecordsGetResultTLSARecord | RecordsGetResultURIRecord;
export type GetRecordResponse = RecordsGetResult;
export interface GetSettingAccountRequest {
    /** Identifier. */
    accountId: string;
}
export interface SettingsAccountGetResponseZoneDefaultsInternalDns {
    /** The ID of the zone to fallback to. */
    referenceZoneId?: string | null;
}
export type SettingsAccountGetResponseZoneDefaultsNameserversType = "cloudflare.standard" | "cloudflare.advanced" | "cloudflare.standard.random" | "custom.account" | "custom.tenant";
export interface SettingsAccountGetResponseZoneDefaultsNameservers {
    /** Nameserver type */
    type: SettingsAccountGetResponseZoneDefaultsNameserversType;
}
export interface SettingsAccountGetResponseZoneDefaultsSoa {
    /** Time in seconds of being unable to query the primary server after which secondary servers should stop serving the zone. */
    expire?: number | null;
    /** The time to live (TTL) for negative caching of records within the zone. */
    minTtl?: number | null;
    /** The primary nameserver, which may be used for outbound zone transfers. If null, a Cloudflare-assigned value will be used. */
    mname?: string | null;
    /** Time in seconds after which secondary servers should re-check the SOA record to see if the zone has been updated. */
    refresh?: number | null;
    /** Time in seconds after which secondary servers should retry queries after the primary server was unresponsive. */
    retry?: number | null;
    /** The email address of the zone administrator, with the first label representing the local part of the email address. */
    rname?: string | null;
    /** The time to live (TTL) of the SOA record itself. */
    ttl?: number | null;
}
export type SettingsAccountGetResponseZoneDefaultsZoneMode = "standard" | "cdn_only" | "dns_only";
export interface SettingsAccountGetResponseZoneDefaults {
    /** Whether to flatten all CNAME records in the zone. Note that, due to DNS limitations, a CNAME record at the zone apex will always be flattened. */
    flattenAllCnames: boolean;
    /** foundation_dns is deprecated. Use nameservers.type: cloudflare.advanced to turn on Advanced Nameservers and cloudflare.standard to turn it off. This field will be removed in a future API version. */
    foundationDns: boolean;
    /** Settings for this internal zone. */
    internalDns: SettingsAccountGetResponseZoneDefaultsInternalDns;
    /** Whether to enable multi-provider DNS, which causes Cloudflare to activate the zone even when non-Cloudflare NS records exist, and to respect NS records at the zone apex during outbound zone transfers. */
    multiProvider: boolean;
    /** Settings determining the nameservers through which the zone should be available. */
    nameservers: SettingsAccountGetResponseZoneDefaultsNameservers;
    /** The time to live (TTL) of the zone's nameserver (NS) records. */
    nsTtl: number;
    /** Allows a Secondary DNS zone to use (proxied) override records and CNAME flattening at the zone apex. */
    secondaryOverrides: boolean;
    /** Components of the zone's SOA record. */
    soa: SettingsAccountGetResponseZoneDefaultsSoa;
    /** Whether the zone mode is a regular or CDN/DNS only zone. */
    zoneMode: SettingsAccountGetResponseZoneDefaultsZoneMode;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingAccountResponse {
    /** Default settings for new zones created in this account. */
    zoneDefaults: SettingsAccountGetResponseZoneDefaults;
    /** When enabled, forces all proxied DNS records in the account to behave as DNS-only at the edge, regardless of each record's individual proxy setting. Note that this account-level override does not modify the records themselves; it only affects how they are served at the edge. See more on [Enforce DNS-only](https://developers.cloudflare.com/dns/proxy-status/enforce-dns-only). */
    enforceDnsOnly?: boolean | null;
}
export interface GetSettingAccountViewRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    viewId: string;
}
export type SettingsAccountViewsGetResponseZonesList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingAccountViewResponse {
    /** Identifier. */
    id: string;
    /** When the view was created. */
    createdTime: string;
    /** When the view was last modified. */
    modifiedTime: string;
    /** The name of the view. */
    name: string;
    /** The list of zones linked to this view. */
    zones: SettingsAccountViewsGetResponseZonesList;
}
export interface GetSettingsAccountNameserverSetRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for a nameserver set. */
    nameserverSetId: string;
}
export type GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversItemIpv4List = Array<string>;
export type GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversItemIpv6List = Array<string>;
export interface GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversItem {
    /** IPv4 addresses assigned to the nameserver. */
    ipv4: GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversItemIpv4List;
    /** IPv6 addresses assigned to the nameserver. */
    ipv6: GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversItemIpv6List;
    /** A unique lowercase Punycode nameserver name within the set. */
    name: string;
}
export type GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversList = Array<GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversItem>;
export interface GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponse {
    /** Identifier for a nameserver set. */
    id: string;
    /** Whether the nameserver set uses Advanced anycast groups. */
    advanced: boolean;
    /** When the nameserver set was created. */
    createdOn: string;
    /** Selects the account-specific IP set that supplies the nameserver addresses. Nameserver sets with the same `ip_set` and `advanced` value may reuse addresses; otherwise, they use disjoint address groups. */
    ipSet: number;
    nameservers: GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponseNameserversList;
}
export type GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4List = Array<string>;
export type GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4GroupsItem = "a" | "b" | "c";
export type GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4GroupsList = Array<GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4GroupsItem>;
export type GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6List = Array<string>;
export type GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6GroupsItem = "a" | "b" | "c";
export type GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6GroupsList = Array<GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6GroupsItem>;
export interface GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItem {
    /** IPv4 addresses assigned to the nameserver. */
    ipv4: GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4List;
    /** Advanced anycast group for each address in the corresponding address array. Entries have the same order as, and correspond one-to-one with, the addresses. */
    ipv4Groups: GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4GroupsList;
    /** IPv6 addresses assigned to the nameserver. */
    ipv6: GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6List;
    /** Advanced anycast group for each address in the corresponding address array. Entries have the same order as, and correspond one-to-one with, the addresses. */
    ipv6Groups: GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6GroupsList;
    /** A unique lowercase Punycode nameserver name within the set. */
    name: string;
}
export type GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversList = Array<GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversItem>;
export interface GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponse {
    /** Identifier for a nameserver set. */
    id: string;
    /** Whether the nameserver set uses Advanced anycast groups. */
    advanced: boolean;
    /** When the nameserver set was created. */
    createdOn: string;
    /** Selects the account-specific IP set that supplies the nameserver addresses. Nameserver sets with the same `ip_set` and `advanced` value may reuse addresses; otherwise, they use disjoint address groups. */
    ipSet: number;
    nameservers: GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponseNameserversList;
}
export type GetSettingsAccountNameserverSetResult = GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetStandardResponse | GetSettingsAccountNameserverSetResultDNSSettingsNameserverSetAdvancedResponse;
export type GetSettingsAccountNameserverSetResponse = GetSettingsAccountNameserverSetResult;
export interface GetSettingZoneRequest {
    /** Identifier. */
    zoneId: string;
}
export type SettingsZoneGetResponseInternalDns = SettingsAccountGetResponseZoneDefaultsInternalDns;
export type SettingsZoneGetResponseNameserversDNSSettingsZoneNameserversCloudflareType = "cloudflare.standard" | "cloudflare.advanced";
export interface SettingsZoneGetResponseNameserversDNSSettingsZoneNameserversCloudflare {
    /** Nameserver type. */
    type: SettingsZoneGetResponseNameserversDNSSettingsZoneNameserversCloudflareType;
}
export type SettingsZoneGetResponseNameserversDNSSettingsZoneNameserversCustomExistingType = "custom.account" | "custom.tenant" | "custom.zone";
export interface SettingsZoneGetResponseNameserversDNSSettingsZoneNameserversCustomExisting {
    /** Nameserver type. */
    type: SettingsZoneGetResponseNameserversDNSSettingsZoneNameserversCustomExistingType;
    /** Configured nameserver set number to use for this zone. */
    nsSet?: number | null;
}
export type SettingsZoneGetResponseNameserversDNSSettingsZoneNameserversCustomSetType = "custom";
export interface SettingsZoneGetResponseNameserversDNSSettingsZoneNameserversCustomSet {
    /** Identifier of the account-owned Custom Nameserver Set to use for this zone. */
    nameserverSetId: string;
    /** Nameserver type. */
    type: SettingsZoneGetResponseNameserversDNSSettingsZoneNameserversCustomSetType;
}
export type SettingsZoneGetResponseNameservers = SettingsZoneGetResponseNameserversDNSSettingsZoneNameserversCloudflare | SettingsZoneGetResponseNameserversDNSSettingsZoneNameserversCustomExisting | SettingsZoneGetResponseNameserversDNSSettingsZoneNameserversCustomSet;
export type SettingsZoneGetResponseSoa = SettingsAccountGetResponseZoneDefaultsSoa;
export type SettingsZoneGetResponseZoneMode = "standard" | "cdn_only" | "dns_only";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingZoneResponse {
    /** Whether to flatten all CNAME records in the zone. Note that, due to DNS limitations, a CNAME record at the zone apex will always be flattened. */
    flattenAllCnames: boolean;
    /** foundation_dns is deprecated. Use nameservers.type: cloudflare.advanced to turn on Advanced Nameservers and cloudflare.standard to turn it off. This field will be removed in a future API version. */
    foundationDns: boolean;
    /** Settings for this internal zone. */
    internalDns: SettingsAccountGetResponseZoneDefaultsInternalDns;
    /** Whether to enable multi-provider DNS, which causes Cloudflare to activate the zone even when non-Cloudflare NS records exist, and to respect NS records at the zone apex during outbound zone transfers. */
    multiProvider: boolean;
    /** Controls the nameservers through which the zone is available. */
    nameservers: SettingsZoneGetResponseNameservers;
    /** The time to live (TTL) of the zone's nameserver (NS) records. */
    nsTtl: number;
    /** Allows a Secondary DNS zone to use (proxied) override records and CNAME flattening at the zone apex. */
    secondaryOverrides: boolean;
    /** Components of the zone's SOA record. */
    soa: SettingsAccountGetResponseZoneDefaultsSoa;
    /** Whether the zone mode is a regular or CDN/DNS only zone. */
    zoneMode: SettingsZoneGetResponseZoneMode;
}
export interface GetUsageAccountRequest {
    /** Identifier. */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUsageAccountResponse {
    /** Maximum number of DNS records allowed across all public zones in the account. Null if using zone-level quota. */
    recordQuota: number;
    /** Current number of DNS records across all public zones in the account. */
    recordUsage: number;
    /** Maximum number of DNS records allowed across all internal zones in the account. Only present if internal DNS is enabled. */
    internalRecordQuota?: number | null;
    /** Current number of DNS records across all internal zones in the account. Only present if internal DNS is enabled. */
    internalRecordUsage?: number | null;
}
export interface GetUsageZoneRequest {
    /** Identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUsageZoneResponse {
    /** Maximum number of DNS records allowed for the zone. Null if using account-level quota. */
    recordQuota: number;
    /** Current number of DNS records in the zone. */
    recordUsage: number;
}
export interface GetZoneTransferAclRequest {
    accountId: string;
    aclId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneTransferAclResponse {
    id: string;
    /** Allowed IPv4/IPv6 address range of primary or secondary nameservers. This will be applied for the entire account. The IP range is used to allow additional NOTIFY IPs for secondary zones and IPs Cloudflare allows AXFR/IXFR requests from for primary zones. CIDRs are limited to a maximum of /24 for IPv4 and /64 for IPv6 respectively. */
    ipRange: string;
    /** The name of the acl. */
    name: string;
}
export interface GetZoneTransferIncomingRequest {
    zoneId: string;
}
export type ZoneTransfersIncomingGetResponsePeersList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneTransferIncomingResponse {
    id?: string | null;
    /** How often should a secondary zone auto refresh regardless of DNS NOTIFY. Not applicable for primary zones. */
    autoRefreshSeconds?: number | null;
    /** The time for a specific event. */
    checkedTime?: string | null;
    /** The time for a specific event. */
    createdTime?: string | null;
    /** The time for a specific event. */
    modifiedTime?: string | null;
    /** Zone name. */
    name?: string | null;
    /** A list of peer tags. */
    peers?: ZoneTransfersIncomingGetResponsePeersList | null;
    /** The serial number of the SOA for the given zone. */
    soaSerial?: number | null;
}
export interface GetZoneTransferOutgoingRequest {
    zoneId: string;
}
export type ZoneTransfersOutgoingGetResponsePeersList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneTransferOutgoingResponse {
    id?: string | null;
    /** The time for a specific event. */
    checkedTime?: string | null;
    /** The time for a specific event. */
    createdTime?: string | null;
    /** The time for a specific event. */
    lastTransferredTime?: string | null;
    /** Zone name. */
    name?: string | null;
    /** A list of peer tags. */
    peers?: ZoneTransfersOutgoingGetResponsePeersList | null;
    /** The serial number of the SOA for the given zone. */
    soaSerial?: number | null;
}
export interface GetZoneTransferOutgoingStatusRequest {
    zoneId: string;
}
export type GetZoneTransferOutgoingStatusResponse = string;
export interface GetZoneTransferPeerRequest {
    accountId: string;
    peerId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneTransferPeerResponse {
    id: string;
    /** The name of the peer. */
    name: string;
    /** IPv4/IPv6 address of primary or secondary nameserver, depending on what zone this peer is linked to. For primary zones this IP defines the IP of the secondary nameserver Cloudflare will NOTIFY upon zone changes. For secondary zones this IP defines the IP of the primary nameserver Cloudflare will send AXFR/IXFR requests to. */
    ip?: string | null;
    /** Enable IXFR transfer protocol, default is AXFR. Only applicable to secondary zones. */
    ixfrEnable?: boolean | null;
    /** DNS port of primary or secondary nameserver, depending on what zone this peer is linked to. */
    port?: number | null;
    /** TSIG authentication will be used for zone transfer if configured. */
    tsigId?: string | null;
}
export interface GetZoneTransferTsigRequest {
    accountId: string;
    tsigId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneTransferTsigResponse {
    id: string;
    /** TSIG algorithm. */
    algo: string;
    /** TSIG key name. */
    name: string;
    /** TSIG secret. */
    secret: string;
}
export interface ImportRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** BIND config to import. */
    file: string;
    /** Whether or not proxiable records should receive the performance and security benefits of Cloudflare. */
    proxied?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ImportRecordResponse {
    /** Number of DNS records added. */
    recsAdded?: number | null;
    /** Total number of DNS records parsed. */
    totalRecordsParsed?: number | null;
}
export interface ListDnssecZskRequest {
    /** Identifier. */
    zoneId: string;
}
export interface ListDnssecZskResultItemDNSKEYHdr {
    Class?: number | null;
    name?: string | null;
    rdlength?: number | null;
    rrtype?: number | null;
    ttl?: number | null;
}
export interface ListDnssecZskResultItemDNSKEY {
    algorithm?: number | null;
    flags?: number | null;
    hdr?: ListDnssecZskResultItemDNSKEYHdr | null;
    protocol?: number | null;
    publicKey?: string | null;
}
export type ListDnssecZskResultItemLocation = "database" | "vault";
export interface ListDnssecZskResultItemSigningKey {
    /** Key encryption key name used to encrypt the private key. */
    kek?: string | null;
    /** Encrypted private key material for the signing key. */
    privkey?: string | null;
    /** Public key content associated with the signing key. */
    pubkey?: string | null;
}
export type ListDnssecZskResultItemTag = "active" | "publish" | "external" | "retired" | "revoked" | "removed";
export interface ListDnssecZskResultItem {
    dNSKEY?: ListDnssecZskResultItemDNSKEY | null;
    /** Storage backend where the DNSSEC key material is stored. */
    location?: ListDnssecZskResultItemLocation | null;
    /** Internal key name for the ZSK. */
    name?: string | null;
    signingKey?: ListDnssecZskResultItemSigningKey | null;
    /** Lifecycle state tag attached to the DNSSEC key. */
    tag?: ListDnssecZskResultItemTag | null;
}
export type ListDnssecZskResultList = Array<ListDnssecZskResultItem>;
export type ListDnssecZskResponse = ListDnssecZskResultList;
export interface RecordsListRequestComment {
    /** If this parameter is present, only records *without* a comment are returned. */
    absent?: string;
    /** Substring of the DNS record comment. Comment filters are case-insensitive. */
    contains?: string;
    /** Suffix of the DNS record comment. Comment filters are case-insensitive. */
    endswith?: string;
    /** Exact value of the DNS record comment. Comment filters are case-insensitive. */
    exact?: string;
    /** If this parameter is present, only records *with* a comment are returned. */
    present?: string;
    /** Prefix of the DNS record comment. Comment filters are case-insensitive. */
    startswith?: string;
}
export interface RecordsListRequestContent {
    /** Substring of the DNS record content. Content filters are case-insensitive. */
    contains?: string;
    /** Suffix of the DNS record content. Content filters are case-insensitive. */
    endswith?: string;
    /** Exact value of the DNS record content. Content filters are case-insensitive. */
    exact?: string;
    /** Prefix of the DNS record content. Content filters are case-insensitive. */
    startswith?: string;
}
export type RecordsListRequestMatch = "any" | "all";
export interface RecordsListRequestName {
    /** Substring of the DNS record name. Name filters are case-insensitive. */
    contains?: string;
    /** Suffix of the DNS record name. Name filters are case-insensitive. */
    endswith?: string;
    /** Exact value of the DNS record name. Name filters are case-insensitive. */
    exact?: string;
    /** Prefix of the DNS record name. Name filters are case-insensitive. */
    startswith?: string;
}
export type RecordsListRequestOrder = "type" | "name" | "content" | "ttl" | "proxied";
export interface RecordsListRequestTag {
    /** Name of a tag which must *not* be present on the DNS record. Tag filters are case-insensitive. */
    absent?: string;
    /** A tag and value, of the form `&lt;tag-name&gt;:&lt;tag-value&gt;`. The API will only return DNS records that have a tag named `&lt;tag-name&gt;` whose value contains `&lt;tag-value&gt;`. Tag filters are case-insensitive. */
    contains?: string;
    /** A tag and value, of the form `&lt;tag-name&gt;:&lt;tag-value&gt;`. The API will only return DNS records that have a tag named `&lt;tag-name&gt;` whose value ends with `&lt;tag-value&gt;`. Tag filters are case-insensitive. */
    endswith?: string;
    /** A tag and value, of the form `&lt;tag-name&gt;:&lt;tag-value&gt;`. The API will only return DNS records that have a tag named `&lt;tag-name&gt;` whose value is `&lt;tag-value&gt;`. Tag filters are case-insensitive. */
    exact?: string;
    /** Name of a tag which must be present on the DNS record. Tag filters are case-insensitive. */
    present?: string;
    /** A tag and value, of the form `&lt;tag-name&gt;:&lt;tag-value&gt;`. The API will only return DNS records that have a tag named `&lt;tag-name&gt;` whose value starts with `&lt;tag-value&gt;`. Tag filters are case-insensitive. */
    startswith?: string;
}
export type RecordsListRequestTagMatch = "any" | "all";
export type RecordsListRequestType = "A" | "AAAA" | "CAA" | "CERT" | "CNAME" | "DNSKEY" | "DS" | "HTTPS" | "LOC" | "MX" | "NAPTR" | "NS" | "OPENPGPKEY" | "PTR" | "SMIMEA" | "SRV" | "SSHFP" | "SVCB" | "TLSA" | "TXT" | "URI";
export interface ListRecordsRequest {
    /** Identifier. */
    zoneId: string;
    comment?: RecordsListRequestComment;
    content?: RecordsListRequestContent;
    /** Direction to order DNS records in. */
    direction?: string;
    /** Whether to include shadow metadata in the `meta` field of each record in the response. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    includeShadowMetadata?: boolean;
    /** Whether to match all search requirements or at least one (any). If set to `all`, acts like a logical AND between filters. If set to `any`, acts like a logical OR instead. Note that the interaction between tag filters is controlled by the `tag-match` parameter instead. */
    match?: RecordsListRequestMatch | (string & {});
    name?: RecordsListRequestName;
    /** Field to order DNS records by. */
    order?: RecordsListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of DNS records per page. */
    perPage?: number;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Allows searching in multiple properties of a DNS record simultaneously. This parameter is intended for human users, not automation. Its exact behavior is intentionally left unspecified and is subject to change in the future. This parameter works independently of the `match` setting. For automated searches, please use the other available parameters. */
    search?: string;
    /** Filters the response to records at or below the specified NS delegation name. NS, DS, and NSEC records at the delegation name are excluded because they are not shadowed by that delegation. Those record types are included only when they exist below the delegation. The value must be a non-apex subdomain of the zone. Requires `include_shadow_metadata=true`. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedByName?: string;
    /** Returns NS records that shadow the given name, searching at the name itself and each of its ancestor names within the zone, excluding the zone apex. The value must be a subdomain of the zone; the zone apex is not accepted. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowingName?: string;
    tag?: RecordsListRequestTag;
    /** Whether to match all tag search requirements or at least one (any). If set to `all`, acts like a logical AND between tag filters. If set to `any`, acts like a logical OR instead. Note that the regular `match` parameter is still used to combine the resulting condition with other filters that aren't related to tags. */
    tagMatch?: RecordsListRequestTagMatch | (string & {});
    /** Record type. */
    type?: RecordsListRequestType | (string & {});
}
export type RecordsListResultItemARecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemARecordType = "A";
export interface RecordsListResultItemARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemARecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemAAAARecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemAAAARecordType = "AAAA";
export interface RecordsListResultItemAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemAAAARecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemCNAMERecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemCNAMERecordType = "CNAME";
export interface RecordsListResultItemCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemCNAMERecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemMXRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemMXRecordType = "MX";
export interface RecordsListResultItemMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemMXRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemNSRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemNSRecordType = "NS";
export interface RecordsListResultItemNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemNSRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export type RecordsListResultItemOpenpgpkeyRecordTagsList = Array<string>;
export type RecordsListResultItemOpenpgpkeyRecordType = "OPENPGPKEY";
export interface RecordsListResultItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsListResultItemOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsListResultItemOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsListResultItemPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemPTRRecordType = "PTR";
export interface RecordsListResultItemPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemPTRRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemTXTRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemTXTRecordType = "TXT";
export interface RecordsListResultItemTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemTXTRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemCAARecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemCAARecordType = "CAA";
export interface RecordsListResultItemCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemCAARecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemCERTRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemCERTRecordType = "CERT";
export interface RecordsListResultItemCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemCERTRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemDNSKEYRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemDNSKEYRecordType = "DNSKEY";
export interface RecordsListResultItemDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemDNSKEYRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemDSRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemDSRecordType = "DS";
export interface RecordsListResultItemDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemDSRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemHTTPSRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemHTTPSRecordType = "HTTPS";
export interface RecordsListResultItemHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemHTTPSRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemLOCRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemLOCRecordType = "LOC";
export interface RecordsListResultItemLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemLOCRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemNAPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemNAPTRRecordType = "NAPTR";
export interface RecordsListResultItemNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemNAPTRRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemSMIMEARecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemSMIMEARecordType = "SMIMEA";
export interface RecordsListResultItemSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemSMIMEARecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemSRVRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemSRVRecordType = "SRV";
export interface RecordsListResultItemSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemSRVRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemSSHFPRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemSSHFPRecordType = "SSHFP";
export interface RecordsListResultItemSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemSSHFPRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemSVCBRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemSVCBRecordType = "SVCB";
export interface RecordsListResultItemSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemSVCBRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemTLSARecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemTLSARecordType = "TLSA";
export interface RecordsListResultItemTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemTLSARecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItemURIRecordMetaShadowedByList = Array<string>;
export interface RecordsListResultItemURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsListResultItemURIRecordType = "URI";
export interface RecordsListResultItemURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemURIRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsListResultItem = RecordsListResultItemARecord | RecordsListResultItemAAAARecord | RecordsListResultItemCNAMERecord | RecordsListResultItemMXRecord | RecordsListResultItemNSRecord | RecordsListResultItemOpenpgpkeyRecord | RecordsListResultItemPTRRecord | RecordsListResultItemTXTRecord | RecordsListResultItemCAARecord | RecordsListResultItemCERTRecord | RecordsListResultItemDNSKEYRecord | RecordsListResultItemDSRecord | RecordsListResultItemHTTPSRecord | RecordsListResultItemLOCRecord | RecordsListResultItemNAPTRRecord | RecordsListResultItemSMIMEARecord | RecordsListResultItemSRVRecord | RecordsListResultItemSSHFPRecord | RecordsListResultItemSVCBRecord | RecordsListResultItemTLSARecord | RecordsListResultItemURIRecord;
export type RecordsListResultList = Array<RecordsListResultItem>;
export interface ListRecordsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RecordsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type SettingsAccountViewsListRequestDirection = "asc" | "desc";
export type SettingsAccountViewsListRequestMatch = "any" | "all";
export interface SettingsAccountViewsListRequestName {
    /** Substring of the DNS view name. */
    contains?: string;
    /** Suffix of the DNS view name. */
    endswith?: string;
    /** Exact value of the DNS view name. */
    exact?: string;
    /** Prefix of the DNS view name. */
    startswith?: string;
}
export type SettingsAccountViewsListRequestOrder = "name" | "created_on" | "modified_on";
export interface ListSettingAccountViewsRequest {
    /** Identifier. */
    accountId: string;
    /** Direction to order DNS views in. */
    direction?: SettingsAccountViewsListRequestDirection | (string & {});
    /** Whether to match all search requirements or at least one (any). If set to `all`, acts like a logical AND between filters. If set to `any`, acts like a logical OR instead. */
    match?: SettingsAccountViewsListRequestMatch | (string & {});
    name?: SettingsAccountViewsListRequestName;
    /** Field to order DNS views by. */
    order?: SettingsAccountViewsListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of results per page. */
    perPage?: number;
    /** A zone ID that exists in the zones list for the view. */
    zoneId?: string;
    /** A zone name that exists in the zones list for the view. */
    zoneName?: string;
}
export type SettingsAccountViewsListResultItemZonesList = Array<string>;
export interface SettingsAccountViewsListResultItem {
    /** Identifier. */
    id: string;
    /** When the view was created. */
    createdTime: string;
    /** When the view was last modified. */
    modifiedTime: string;
    /** The name of the view. */
    name: string;
    /** The list of zones linked to this view. */
    zones: SettingsAccountViewsListResultItemZonesList;
}
export type SettingsAccountViewsListResultList = Array<SettingsAccountViewsListResultItem>;
export interface ListSettingAccountViewsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsAccountViewsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListSettingsAccountNameserverSetsRequest {
    /** Identifier. */
    accountId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of results per page. */
    perPage?: number;
}
export type ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetStandardResponseNameserversItemIpv4List = Array<string>;
export type ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetStandardResponseNameserversItemIpv6List = Array<string>;
export interface ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetStandardResponseNameserversItem {
    /** IPv4 addresses assigned to the nameserver. */
    ipv4: ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetStandardResponseNameserversItemIpv4List;
    /** IPv6 addresses assigned to the nameserver. */
    ipv6: ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetStandardResponseNameserversItemIpv6List;
    /** A unique lowercase Punycode nameserver name within the set. */
    name: string;
}
export type ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetStandardResponseNameserversList = Array<ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetStandardResponseNameserversItem>;
export interface ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetStandardResponse {
    /** Identifier for a nameserver set. */
    id: string;
    /** Whether the nameserver set uses Advanced anycast groups. */
    advanced: boolean;
    /** When the nameserver set was created. */
    createdOn: string;
    /** Selects the account-specific IP set that supplies the nameserver addresses. Nameserver sets with the same `ip_set` and `advanced` value may reuse addresses; otherwise, they use disjoint address groups. */
    ipSet: number;
    nameservers: ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetStandardResponseNameserversList;
}
export type ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4List = Array<string>;
export type ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4GroupsItem = "a" | "b" | "c";
export type ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4GroupsList = Array<ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4GroupsItem>;
export type ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6List = Array<string>;
export type ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6GroupsItem = "a" | "b" | "c";
export type ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6GroupsList = Array<ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6GroupsItem>;
export interface ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItem {
    /** IPv4 addresses assigned to the nameserver. */
    ipv4: ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4List;
    /** Advanced anycast group for each address in the corresponding address array. Entries have the same order as, and correspond one-to-one with, the addresses. */
    ipv4Groups: ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv4GroupsList;
    /** IPv6 addresses assigned to the nameserver. */
    ipv6: ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6List;
    /** Advanced anycast group for each address in the corresponding address array. Entries have the same order as, and correspond one-to-one with, the addresses. */
    ipv6Groups: ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItemIpv6GroupsList;
    /** A unique lowercase Punycode nameserver name within the set. */
    name: string;
}
export type ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversList = Array<ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversItem>;
export interface ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponse {
    /** Identifier for a nameserver set. */
    id: string;
    /** Whether the nameserver set uses Advanced anycast groups. */
    advanced: boolean;
    /** When the nameserver set was created. */
    createdOn: string;
    /** Selects the account-specific IP set that supplies the nameserver addresses. Nameserver sets with the same `ip_set` and `advanced` value may reuse addresses; otherwise, they use disjoint address groups. */
    ipSet: number;
    nameservers: ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponseNameserversList;
}
export type ListSettingsAccountNameserverSetsResultItem = ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetStandardResponse | ListSettingsAccountNameserverSetsResultItemDNSSettingsNameserverSetAdvancedResponse;
export type ListSettingsAccountNameserverSetsResultList = Array<ListSettingsAccountNameserverSetsResultItem>;
export type ListSettingsAccountNameserverSetsResponse = ListSettingsAccountNameserverSetsResultList;
export interface ListZoneTransferAclsRequest {
    accountId: string;
}
export interface ZoneTransfersAclsListResultItem {
    id: string;
    /** Allowed IPv4/IPv6 address range of primary or secondary nameservers. This will be applied for the entire account. The IP range is used to allow additional NOTIFY IPs for secondary zones and IPs Cloudflare allows AXFR/IXFR requests from for primary zones. CIDRs are limited to a maximum of /24 for IPv4 and /64 for IPv6 respectively. */
    ipRange: string;
    /** The name of the acl. */
    name: string;
}
export type ZoneTransfersAclsListResultList = Array<ZoneTransfersAclsListResultItem>;
export interface ListZoneTransferAclsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ZoneTransfersAclsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListZoneTransferPeersRequest {
    accountId: string;
}
export interface ZoneTransfersPeersListResultItem {
    id: string;
    /** The name of the peer. */
    name: string;
    /** IPv4/IPv6 address of primary or secondary nameserver, depending on what zone this peer is linked to. For primary zones this IP defines the IP of the secondary nameserver Cloudflare will NOTIFY upon zone changes. For secondary zones this IP defines the IP of the primary nameserver Cloudflare will send AXFR/IXFR requests to. */
    ip?: string | null;
    /** Enable IXFR transfer protocol, default is AXFR. Only applicable to secondary zones. */
    ixfrEnable?: boolean | null;
    /** DNS port of primary or secondary nameserver, depending on what zone this peer is linked to. */
    port?: number | null;
    /** TSIG authentication will be used for zone transfer if configured. */
    tsigId?: string | null;
}
export type ZoneTransfersPeersListResultList = Array<ZoneTransfersPeersListResultItem>;
export interface ListZoneTransferPeersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ZoneTransfersPeersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListZoneTransferTsigsRequest {
    accountId: string;
}
export interface ZoneTransfersTsigsListResultItem {
    id: string;
    /** TSIG algorithm. */
    algo: string;
    /** TSIG key name. */
    name: string;
    /** TSIG secret. */
    secret: string;
}
export type ZoneTransfersTsigsListResultList = Array<ZoneTransfersTsigsListResultItem>;
export interface ListZoneTransferTsigsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ZoneTransfersTsigsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type DnssecEditRequestStatus = "active" | "disabled";
export interface PatchDnssecRequest {
    /** Identifier. */
    zoneId: string;
    /** If true, multi-signer DNSSEC is enabled on the zone, allowing multiple providers to serve a DNSSEC-signed zone at the same time. This is required for DNSKEY records (except those automatically generated by Cloudflare) to be added to the zone. */
    dnssecMultiSigner?: boolean;
    /** If true, allows Cloudflare to transfer in a DNSSEC-signed zone including signatures from an external provider, without requiring Cloudflare to sign any records on the fly. */
    dnssecPresigned?: boolean;
    /** If true, enables the use of NSEC3 together with DNSSEC on the zone. Combined with setting dnssec_presigned to true, this enables the use of NSEC3 records when transferring in from an external provider. If dnssec_presigned is instead set to false (default), NSEC3 records will be generated and signed at request time. */
    dnssecUseNsec3?: boolean;
    /** Status of DNSSEC, based on user-desired state and presence of necessary records. */
    status?: DnssecEditRequestStatus | (string & {});
}
export type DnssecEditResponseStatus = "active" | "pending" | "disabled" | "pending-disabled" | "error";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchDnssecResponse {
    /** Algorithm key code. */
    algorithm?: string | null;
    /** Digest hash. */
    digest?: string | null;
    /** Type of digest algorithm. */
    digestAlgorithm?: string | null;
    /** Coded type for digest algorithm. */
    digestType?: string | null;
    /** If true, multi-signer DNSSEC is enabled on the zone, allowing multiple providers to serve a DNSSEC-signed zone at the same time. This is required for DNSKEY records (except those automatically generated by Cloudflare) to be added to the zone. */
    dnssecMultiSigner?: boolean | null;
    /** If true, allows Cloudflare to transfer in a DNSSEC-signed zone including signatures from an external provider, without requiring Cloudflare to sign any records on the fly. */
    dnssecPresigned?: boolean | null;
    /** If true, enables the use of NSEC3 together with DNSSEC on the zone. Combined with setting dnssec_presigned to true, this enables the use of NSEC3 records when transferring in from an external provider. If dnssec_presigned is instead set to false (default), NSEC3 records will be generated and signed at request time. */
    dnssecUseNsec3?: boolean | null;
    /** Full DS record. */
    ds?: string | null;
    /** Flag for DNSSEC record. */
    flags?: number | null;
    /** Code for key tag. */
    keyTag?: number | null;
    /** Algorithm key type. */
    keyType?: string | null;
    /** When DNSSEC was last modified. */
    modifiedOn?: string | null;
    /** Public key for DS record. */
    publicKey?: string | null;
    /** Status of DNSSEC, based on user-desired state and presence of necessary records. */
    status?: DnssecEditResponseStatus | null;
}
export type RecordsEditRequestType = "A" | "AAAA" | "CNAME" | "MX" | "NS" | "OPENPGPKEY" | "PTR" | "TXT" | "CAA" | "CERT" | "DNSKEY" | "DS" | "HTTPS" | "LOC" | "NAPTR" | "SMIMEA" | "SRV" | "SSHFP" | "SVCB" | "TLSA" | "URI";
export type RecordsEditRequestSettingsARecord = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsEditRequestSettingsCNAMERecord = RecordsBatchRequestPostsItemCNAMERecordSettings;
export type RecordsEditRequestSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings | RecordsBatchRequestPostsItemCNAMERecordSettings;
export type RecordsEditRequestTagsList = Array<string>;
export type RecordsEditRequestDataCAARecord = RecordsBatchRequestPostsItemCAARecordData;
export type RecordsEditRequestDataCERTRecord = RecordsBatchRequestPostsItemCERTRecordData;
export type RecordsEditRequestDataDNSKEYRecord = RecordsBatchRequestPostsItemDNSKEYRecordData;
export type RecordsEditRequestDataDSRecord = RecordsBatchRequestPostsItemDSRecordData;
export type RecordsEditRequestDataHTTPSRecord = RecordsBatchRequestPostsItemHTTPSRecordData;
export type RecordsEditRequestDataLOCRecordLatDirection = "N" | "S";
export type RecordsEditRequestDataLOCRecordLongDirection = "E" | "W";
export interface RecordsEditRequestDataLOCRecord {
    /** Altitude of location in meters. */
    altitude?: number;
    /** Degrees of latitude. */
    latDegrees?: number;
    /** Latitude direction. */
    latDirection?: RecordsEditRequestDataLOCRecordLatDirection | (string & {});
    /** Minutes of latitude. */
    latMinutes?: number;
    /** Seconds of latitude. */
    latSeconds?: number;
    /** Degrees of longitude. */
    longDegrees?: number;
    /** Longitude direction. */
    longDirection?: RecordsEditRequestDataLOCRecordLongDirection | (string & {});
    /** Minutes of longitude. */
    longMinutes?: number;
    /** Seconds of longitude. */
    longSeconds?: number;
    /** Horizontal precision of location. */
    precisionHorz?: number;
    /** Vertical precision of location. */
    precisionVert?: number;
    /** Size of location in meters. */
    size?: number;
}
export type RecordsEditRequestDataNAPTRRecord = RecordsBatchRequestPostsItemNAPTRRecordData;
export type RecordsEditRequestDataSMIMEARecord = RecordsBatchRequestPostsItemSMIMEARecordData;
export type RecordsEditRequestDataSRVRecord = RecordsBatchRequestPostsItemSRVRecordData;
export type RecordsEditRequestDataSSHFPRecord = RecordsBatchRequestPostsItemSSHFPRecordData;
export type RecordsEditRequestDataURIRecord = RecordsBatchRequestPostsItemURIRecordData;
export type RecordsEditRequestData = RecordsBatchRequestPostsItemCAARecordData | RecordsBatchRequestPostsItemCERTRecordData | RecordsBatchRequestPostsItemDNSKEYRecordData | RecordsBatchRequestPostsItemDSRecordData | RecordsBatchRequestPostsItemHTTPSRecordData | RecordsEditRequestDataLOCRecord | RecordsBatchRequestPostsItemNAPTRRecordData | RecordsBatchRequestPostsItemSMIMEARecordData | RecordsBatchRequestPostsItemSRVRecordData | RecordsBatchRequestPostsItemSSHFPRecordData | RecordsBatchRequestPostsItemURIRecordData;
export interface PatchRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    dnsRecordId: string;
    /** Whether to include shadow metadata in the `meta` field of each record in the response. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    includeShadowMetadata?: boolean;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsEditRequestType | (string & {});
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv4 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsEditRequestSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsEditRequestTagsList;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Components of a CAA record. */
    data?: RecordsEditRequestData;
}
export type RecordsEditResultARecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultAAAARecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeAAAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultCNAMERecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCNAME;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultMXRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeMX;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultNSRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsEditResultOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export type RecordsEditResultOpenpgpkeyRecordTagsList = Array<string>;
export type RecordsEditResultOpenpgpkeyRecordType = "OPENPGPKEY";
export interface RecordsEditResultOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsEditResultOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsEditResultOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsEditResultPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypePTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultTXTRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTXT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultCAARecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultCERTRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCERT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultDNSKEYRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDNSKEY;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultDSRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultHTTPSRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeHTTPS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultLOCRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeLOC;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultNAPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNAPTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultSMIMEARecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSMIMEA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultSRVRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSRV;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultSSHFPRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSSHFP;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultSVCBRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSVCB;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultTLSARecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTLSA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResultURIRecordMetaShadowedByList = Array<string>;
export interface RecordsEditResultURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsEditResultURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeURI;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsEditResult = RecordsEditResultARecord | RecordsEditResultAAAARecord | RecordsEditResultCNAMERecord | RecordsEditResultMXRecord | RecordsEditResultNSRecord | RecordsEditResultOpenpgpkeyRecord | RecordsEditResultPTRRecord | RecordsEditResultTXTRecord | RecordsEditResultCAARecord | RecordsEditResultCERTRecord | RecordsEditResultDNSKEYRecord | RecordsEditResultDSRecord | RecordsEditResultHTTPSRecord | RecordsEditResultLOCRecord | RecordsEditResultNAPTRRecord | RecordsEditResultSMIMEARecord | RecordsEditResultSRVRecord | RecordsEditResultSSHFPRecord | RecordsEditResultSVCBRecord | RecordsEditResultTLSARecord | RecordsEditResultURIRecord;
export type PatchRecordResponse = RecordsEditResult;
export interface SettingsAccountEditRequestZoneDefaultsInternalDns {
    /** The ID of the zone to fallback to. */
    referenceZoneId?: string;
}
export type SettingsAccountEditRequestZoneDefaultsNameserversType = "cloudflare.standard" | "cloudflare.advanced" | "cloudflare.standard.random" | "custom.account" | "custom.tenant";
export interface SettingsAccountEditRequestZoneDefaultsNameservers {
    /** Nameserver type */
    type?: SettingsAccountEditRequestZoneDefaultsNameserversType | (string & {});
}
export interface SettingsAccountEditRequestZoneDefaultsSoa {
    /** Time in seconds of being unable to query the primary server after which secondary servers should stop serving the zone. */
    expire?: number;
    /** The time to live (TTL) for negative caching of records within the zone. */
    minTtl?: number;
    /** The primary nameserver, which may be used for outbound zone transfers. If null, a Cloudflare-assigned value will be used. */
    mname?: string;
    /** Time in seconds after which secondary servers should re-check the SOA record to see if the zone has been updated. */
    refresh?: number;
    /** Time in seconds after which secondary servers should retry queries after the primary server was unresponsive. */
    retry?: number;
    /** The email address of the zone administrator, with the first label representing the local part of the email address. */
    rname?: string;
    /** The time to live (TTL) of the SOA record itself. */
    ttl?: number;
}
export type SettingsAccountEditRequestZoneDefaultsZoneMode = "standard" | "cdn_only" | "dns_only";
export interface SettingsAccountEditRequestZoneDefaults {
    /** Whether to flatten all CNAME records in the zone. Note that, due to DNS limitations, a CNAME record at the zone apex will always be flattened. */
    flattenAllCnames?: boolean;
    /** foundation_dns is deprecated. Use nameservers.type: cloudflare.advanced to turn on Advanced Nameservers and cloudflare.standard to turn it off. This field will be removed in a future API version. */
    foundationDns?: boolean;
    /** Settings for this internal zone. */
    internalDns?: SettingsAccountEditRequestZoneDefaultsInternalDns;
    /** Whether to enable multi-provider DNS, which causes Cloudflare to activate the zone even when non-Cloudflare NS records exist, and to respect NS records at the zone apex during outbound zone transfers. */
    multiProvider?: boolean;
    /** Settings determining the nameservers through which the zone should be available. */
    nameservers?: SettingsAccountEditRequestZoneDefaultsNameservers;
    /** The time to live (TTL) of the zone's nameserver (NS) records. */
    nsTtl?: number;
    /** Allows a Secondary DNS zone to use (proxied) override records and CNAME flattening at the zone apex. */
    secondaryOverrides?: boolean;
    /** Components of the zone's SOA record. */
    soa?: SettingsAccountEditRequestZoneDefaultsSoa;
    /** Whether the zone mode is a regular or CDN/DNS only zone. */
    zoneMode?: SettingsAccountEditRequestZoneDefaultsZoneMode | (string & {});
}
export interface PatchSettingAccountRequest {
    /** Identifier. */
    accountId: string;
    /** When enabled, forces all proxied DNS records in the account to behave as DNS-only at the edge, regardless of each record's individual proxy setting. Note that this account-level override does not modify the records themselves; it only affects how they are served at the edge. See more on [Enforce DNS-only](https://developers.cloudflare.com/dns/proxy-status/enforce-dns-only). */
    enforceDnsOnly?: boolean;
    /** Default settings for new zones created in this account. */
    zoneDefaults?: SettingsAccountEditRequestZoneDefaults;
}
export type SettingsAccountEditResponseZoneDefaultsInternalDns = SettingsAccountGetResponseZoneDefaultsInternalDns;
export type SettingsAccountEditResponseZoneDefaultsNameserversType = "cloudflare.standard" | "cloudflare.advanced" | "cloudflare.standard.random" | "custom.account" | "custom.tenant";
export interface SettingsAccountEditResponseZoneDefaultsNameservers {
    /** Nameserver type */
    type: SettingsAccountEditResponseZoneDefaultsNameserversType;
}
export type SettingsAccountEditResponseZoneDefaultsSoa = SettingsAccountGetResponseZoneDefaultsSoa;
export type SettingsAccountEditResponseZoneDefaultsZoneMode = "standard" | "cdn_only" | "dns_only";
export interface SettingsAccountEditResponseZoneDefaults {
    /** Whether to flatten all CNAME records in the zone. Note that, due to DNS limitations, a CNAME record at the zone apex will always be flattened. */
    flattenAllCnames: boolean;
    /** foundation_dns is deprecated. Use nameservers.type: cloudflare.advanced to turn on Advanced Nameservers and cloudflare.standard to turn it off. This field will be removed in a future API version. */
    foundationDns: boolean;
    /** Settings for this internal zone. */
    internalDns: SettingsAccountGetResponseZoneDefaultsInternalDns;
    /** Whether to enable multi-provider DNS, which causes Cloudflare to activate the zone even when non-Cloudflare NS records exist, and to respect NS records at the zone apex during outbound zone transfers. */
    multiProvider: boolean;
    /** Settings determining the nameservers through which the zone should be available. */
    nameservers: SettingsAccountEditResponseZoneDefaultsNameservers;
    /** The time to live (TTL) of the zone's nameserver (NS) records. */
    nsTtl: number;
    /** Allows a Secondary DNS zone to use (proxied) override records and CNAME flattening at the zone apex. */
    secondaryOverrides: boolean;
    /** Components of the zone's SOA record. */
    soa: SettingsAccountGetResponseZoneDefaultsSoa;
    /** Whether the zone mode is a regular or CDN/DNS only zone. */
    zoneMode: SettingsAccountEditResponseZoneDefaultsZoneMode;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingAccountResponse {
    /** Default settings for new zones created in this account. */
    zoneDefaults: SettingsAccountEditResponseZoneDefaults;
    /** When enabled, forces all proxied DNS records in the account to behave as DNS-only at the edge, regardless of each record's individual proxy setting. Note that this account-level override does not modify the records themselves; it only affects how they are served at the edge. See more on [Enforce DNS-only](https://developers.cloudflare.com/dns/proxy-status/enforce-dns-only). */
    enforceDnsOnly?: boolean | null;
}
export type SettingsAccountViewsEditRequestZonesList = Array<string>;
export interface PatchSettingAccountViewRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    viewId: string;
    /** The name of the view. */
    name?: string;
    /** The list of zones linked to this view. */
    zones?: SettingsAccountViewsEditRequestZonesList;
}
export type SettingsAccountViewsEditResponseZonesList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingAccountViewResponse {
    /** Identifier. */
    id: string;
    /** When the view was created. */
    createdTime: string;
    /** When the view was last modified. */
    modifiedTime: string;
    /** The name of the view. */
    name: string;
    /** The list of zones linked to this view. */
    zones: SettingsAccountViewsEditResponseZonesList;
}
export type SettingsZoneEditRequestInternalDns = SettingsAccountEditRequestZoneDefaultsInternalDns;
export type SettingsZoneEditRequestNameserversDNSSettingsZoneNameserversCloudflareType = "cloudflare.standard" | "cloudflare.advanced";
export interface SettingsZoneEditRequestNameserversDNSSettingsZoneNameserversCloudflare {
    /** Nameserver type. */
    type: SettingsZoneEditRequestNameserversDNSSettingsZoneNameserversCloudflareType | (string & {});
}
export type SettingsZoneEditRequestNameserversDNSSettingsZoneNameserversCustomExistingType = "custom.account" | "custom.tenant" | "custom.zone";
export interface SettingsZoneEditRequestNameserversDNSSettingsZoneNameserversCustomExisting {
    /** Nameserver type. */
    type: SettingsZoneEditRequestNameserversDNSSettingsZoneNameserversCustomExistingType | (string & {});
    /** Configured nameserver set number to use for this zone. */
    nsSet?: number;
}
export type SettingsZoneEditRequestNameserversDNSSettingsZoneNameserversCustomSetType = "custom";
export interface SettingsZoneEditRequestNameserversDNSSettingsZoneNameserversCustomSet {
    /** Identifier of the account-owned Custom Nameserver Set to use for this zone. */
    nameserverSetId: string;
    /** Nameserver type. */
    type: SettingsZoneEditRequestNameserversDNSSettingsZoneNameserversCustomSetType;
}
export type SettingsZoneEditRequestNameservers = SettingsZoneEditRequestNameserversDNSSettingsZoneNameserversCloudflare | SettingsZoneEditRequestNameserversDNSSettingsZoneNameserversCustomExisting | SettingsZoneEditRequestNameserversDNSSettingsZoneNameserversCustomSet;
export type SettingsZoneEditRequestSoa = SettingsAccountEditRequestZoneDefaultsSoa;
export type SettingsZoneEditRequestZoneMode = "standard" | "cdn_only" | "dns_only";
export interface PatchSettingZoneRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether to flatten all CNAME records in the zone. Note that, due to DNS limitations, a CNAME record at the zone apex will always be flattened. */
    flattenAllCnames?: boolean;
    /** foundation_dns is deprecated. Use nameservers.type: cloudflare.advanced to turn on Advanced Nameservers and cloudflare.standard to turn it off. This field will be removed in a future API version. */
    foundationDns?: boolean;
    /** Settings for this internal zone. */
    internalDns?: SettingsAccountEditRequestZoneDefaultsInternalDns;
    /** Whether to enable multi-provider DNS, which causes Cloudflare to activate the zone even when non-Cloudflare NS records exist, and to respect NS records at the zone apex during outbound zone transfers. */
    multiProvider?: boolean;
    /** Controls the nameservers through which the zone is available. */
    nameservers?: SettingsZoneEditRequestNameservers;
    /** The time to live (TTL) of the zone's nameserver (NS) records. */
    nsTtl?: number;
    /** Allows a Secondary DNS zone to use (proxied) override records and CNAME flattening at the zone apex. */
    secondaryOverrides?: boolean;
    /** Components of the zone's SOA record. */
    soa?: SettingsAccountEditRequestZoneDefaultsSoa;
    /** Whether the zone mode is a regular or CDN/DNS only zone. */
    zoneMode?: SettingsZoneEditRequestZoneMode | (string & {});
}
export type SettingsZoneEditResponseInternalDns = SettingsAccountGetResponseZoneDefaultsInternalDns;
export type SettingsZoneEditResponseNameserversDNSSettingsZoneNameserversCloudflareType = "cloudflare.standard" | "cloudflare.advanced";
export interface SettingsZoneEditResponseNameserversDNSSettingsZoneNameserversCloudflare {
    /** Nameserver type. */
    type: SettingsZoneEditResponseNameserversDNSSettingsZoneNameserversCloudflareType;
}
export type SettingsZoneEditResponseNameserversDNSSettingsZoneNameserversCustomExistingType = "custom.account" | "custom.tenant" | "custom.zone";
export interface SettingsZoneEditResponseNameserversDNSSettingsZoneNameserversCustomExisting {
    /** Nameserver type. */
    type: SettingsZoneEditResponseNameserversDNSSettingsZoneNameserversCustomExistingType;
    /** Configured nameserver set number to use for this zone. */
    nsSet?: number | null;
}
export type SettingsZoneEditResponseNameserversDNSSettingsZoneNameserversCustomSetType = "custom";
export interface SettingsZoneEditResponseNameserversDNSSettingsZoneNameserversCustomSet {
    /** Identifier of the account-owned Custom Nameserver Set to use for this zone. */
    nameserverSetId: string;
    /** Nameserver type. */
    type: SettingsZoneEditResponseNameserversDNSSettingsZoneNameserversCustomSetType;
}
export type SettingsZoneEditResponseNameservers = SettingsZoneEditResponseNameserversDNSSettingsZoneNameserversCloudflare | SettingsZoneEditResponseNameserversDNSSettingsZoneNameserversCustomExisting | SettingsZoneEditResponseNameserversDNSSettingsZoneNameserversCustomSet;
export type SettingsZoneEditResponseSoa = SettingsAccountGetResponseZoneDefaultsSoa;
export type SettingsZoneEditResponseZoneMode = "standard" | "cdn_only" | "dns_only";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingZoneResponse {
    /** Whether to flatten all CNAME records in the zone. Note that, due to DNS limitations, a CNAME record at the zone apex will always be flattened. */
    flattenAllCnames: boolean;
    /** foundation_dns is deprecated. Use nameservers.type: cloudflare.advanced to turn on Advanced Nameservers and cloudflare.standard to turn it off. This field will be removed in a future API version. */
    foundationDns: boolean;
    /** Settings for this internal zone. */
    internalDns: SettingsAccountGetResponseZoneDefaultsInternalDns;
    /** Whether to enable multi-provider DNS, which causes Cloudflare to activate the zone even when non-Cloudflare NS records exist, and to respect NS records at the zone apex during outbound zone transfers. */
    multiProvider: boolean;
    /** Controls the nameservers through which the zone is available. */
    nameservers: SettingsZoneEditResponseNameservers;
    /** The time to live (TTL) of the zone's nameserver (NS) records. */
    nsTtl: number;
    /** Allows a Secondary DNS zone to use (proxied) override records and CNAME flattening at the zone apex. */
    secondaryOverrides: boolean;
    /** Components of the zone's SOA record. */
    soa: SettingsAccountGetResponseZoneDefaultsSoa;
    /** Whether the zone mode is a regular or CDN/DNS only zone. */
    zoneMode: SettingsZoneEditResponseZoneMode;
}
export interface ScanListRecordRequest {
    /** Identifier. */
    zoneId: string;
}
export type RecordsScanListResultItemARecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemAAAARecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeAAAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemCNAMERecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCNAME;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemMXRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeMX;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemNSRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsScanListResultItemOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export type RecordsScanListResultItemOpenpgpkeyRecordTagsList = Array<string>;
export type RecordsScanListResultItemOpenpgpkeyRecordType = "OPENPGPKEY";
export interface RecordsScanListResultItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsScanListResultItemOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanListResultItemOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanListResultItemPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypePTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemTXTRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTXT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemCAARecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemCERTRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCERT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemDNSKEYRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDNSKEY;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemDSRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemHTTPSRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeHTTPS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemLOCRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeLOC;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemNAPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNAPTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemSMIMEARecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSMIMEA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemSRVRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSRV;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemSSHFPRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSSHFP;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemSVCBRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSVCB;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemTLSARecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTLSA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItemURIRecordMetaShadowedByList = Array<string>;
export interface RecordsScanListResultItemURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanListResultItemURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeURI;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsScanListResultItem = RecordsScanListResultItemARecord | RecordsScanListResultItemAAAARecord | RecordsScanListResultItemCNAMERecord | RecordsScanListResultItemMXRecord | RecordsScanListResultItemNSRecord | RecordsScanListResultItemOpenpgpkeyRecord | RecordsScanListResultItemPTRRecord | RecordsScanListResultItemTXTRecord | RecordsScanListResultItemCAARecord | RecordsScanListResultItemCERTRecord | RecordsScanListResultItemDNSKEYRecord | RecordsScanListResultItemDSRecord | RecordsScanListResultItemHTTPSRecord | RecordsScanListResultItemLOCRecord | RecordsScanListResultItemNAPTRRecord | RecordsScanListResultItemSMIMEARecord | RecordsScanListResultItemSRVRecord | RecordsScanListResultItemSSHFPRecord | RecordsScanListResultItemSVCBRecord | RecordsScanListResultItemTLSARecord | RecordsScanListResultItemURIRecord;
export type RecordsScanListResultList = Array<RecordsScanListResultItem>;
export interface ScanListRecordResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RecordsScanListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ScanRecordRequest {
    /** Identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ScanRecordResponse {
    /** Number of DNS records added. */
    recsAdded?: number | null;
    /** Total number of DNS records parsed. */
    totalRecordsParsed?: number | null;
}
export type RecordsScanReviewRequestAcceptsItemARecordType = "A";
export type RecordsScanReviewRequestAcceptsItemARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemARecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv4 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemARecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemAAAARecordType = "AAAA";
export type RecordsScanReviewRequestAcceptsItemAAAARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemAAAARecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemAAAARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemAAAARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv6 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemAAAARecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemCNAMERecordType = "CNAME";
export type RecordsScanReviewRequestAcceptsItemCNAMERecordSettings = RecordsBatchRequestPostsItemCNAMERecordSettings;
export type RecordsScanReviewRequestAcceptsItemCNAMERecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemCNAMERecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemCNAMERecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid hostname. Must not match the record's name. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPostsItemCNAMERecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemCNAMERecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemMXRecordType = "MX";
export type RecordsScanReviewRequestAcceptsItemMXRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemMXRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemMXRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemMXRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid mail server hostname. */
    content?: string;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemMXRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemNSRecordType = "NS";
export type RecordsScanReviewRequestAcceptsItemNSRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemNSRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemNSRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemNSRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid name server host name. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemNSRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordType = "OPENPGPKEY";
export type RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemPTRRecordType = "PTR";
export type RecordsScanReviewRequestAcceptsItemPTRRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemPTRRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemPTRRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemPTRRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Domain name pointing to the address. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemPTRRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemTXTRecordType = "TXT";
export type RecordsScanReviewRequestAcceptsItemTXTRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemTXTRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemTXTRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemTXTRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Text content for the record. The content must consist of quoted "character strings" (RFC 1035), each with a length of up to 255 bytes. Strings exceeding this allowed maximum length are automatically split. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemTXTRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemCAARecordType = "CAA";
export type RecordsScanReviewRequestAcceptsItemCAARecordData = RecordsBatchRequestPostsItemCAARecordData;
export type RecordsScanReviewRequestAcceptsItemCAARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemCAARecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemCAARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemCAARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted CAA content. See 'data' to set CAA properties. */
    content?: string;
    /** Components of a CAA record. */
    data?: RecordsBatchRequestPostsItemCAARecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemCAARecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemCERTRecordType = "CERT";
export type RecordsScanReviewRequestAcceptsItemCERTRecordData = RecordsBatchRequestPostsItemCERTRecordData;
export type RecordsScanReviewRequestAcceptsItemCERTRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemCERTRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemCERTRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemCERTRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted CERT content. See 'data' to set CERT properties. */
    content?: string;
    /** Components of a CERT record. */
    data?: RecordsBatchRequestPostsItemCERTRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemCERTRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemDNSKEYRecordType = "DNSKEY";
export type RecordsScanReviewRequestAcceptsItemDNSKEYRecordData = RecordsBatchRequestPostsItemDNSKEYRecordData;
export type RecordsScanReviewRequestAcceptsItemDNSKEYRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemDNSKEYRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemDNSKEYRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemDNSKEYRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted DNSKEY content. See 'data' to set DNSKEY properties. */
    content?: string;
    /** Components of a DNSKEY record. */
    data?: RecordsBatchRequestPostsItemDNSKEYRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemDNSKEYRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemDSRecordType = "DS";
export type RecordsScanReviewRequestAcceptsItemDSRecordData = RecordsBatchRequestPostsItemDSRecordData;
export type RecordsScanReviewRequestAcceptsItemDSRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemDSRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemDSRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemDSRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted DS content. See 'data' to set DS properties. */
    content?: string;
    /** Components of a DS record. */
    data?: RecordsBatchRequestPostsItemDSRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemDSRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemHTTPSRecordType = "HTTPS";
export type RecordsScanReviewRequestAcceptsItemHTTPSRecordData = RecordsBatchRequestPostsItemHTTPSRecordData;
export type RecordsScanReviewRequestAcceptsItemHTTPSRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemHTTPSRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemHTTPSRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemHTTPSRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted HTTPS content. See 'data' to set HTTPS properties. */
    content?: string;
    /** Components of a HTTPS record. */
    data?: RecordsBatchRequestPostsItemHTTPSRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemHTTPSRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemLOCRecordType = "LOC";
export type RecordsScanReviewRequestAcceptsItemLOCRecordDataLatDirection = "N" | "S";
export type RecordsScanReviewRequestAcceptsItemLOCRecordDataLongDirection = "E" | "W";
export interface RecordsScanReviewRequestAcceptsItemLOCRecordData {
    /** Altitude of location in meters. */
    altitude?: number;
    /** Degrees of latitude. */
    latDegrees?: number;
    /** Latitude direction. */
    latDirection?: RecordsScanReviewRequestAcceptsItemLOCRecordDataLatDirection | (string & {});
    /** Minutes of latitude. */
    latMinutes?: number;
    /** Seconds of latitude. */
    latSeconds?: number;
    /** Degrees of longitude. */
    longDegrees?: number;
    /** Longitude direction. */
    longDirection?: RecordsScanReviewRequestAcceptsItemLOCRecordDataLongDirection | (string & {});
    /** Minutes of longitude. */
    longMinutes?: number;
    /** Seconds of longitude. */
    longSeconds?: number;
    /** Horizontal precision of location. */
    precisionHorz?: number;
    /** Vertical precision of location. */
    precisionVert?: number;
    /** Size of location in meters. */
    size?: number;
}
export type RecordsScanReviewRequestAcceptsItemLOCRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemLOCRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemLOCRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemLOCRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted LOC content. See 'data' to set LOC properties. */
    content?: string;
    /** Components of a LOC record. */
    data?: RecordsScanReviewRequestAcceptsItemLOCRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemLOCRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemNAPTRRecordType = "NAPTR";
export type RecordsScanReviewRequestAcceptsItemNAPTRRecordData = RecordsBatchRequestPostsItemNAPTRRecordData;
export type RecordsScanReviewRequestAcceptsItemNAPTRRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemNAPTRRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemNAPTRRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemNAPTRRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted NAPTR content. See 'data' to set NAPTR properties. */
    content?: string;
    /** Components of a NAPTR record. */
    data?: RecordsBatchRequestPostsItemNAPTRRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemNAPTRRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemSMIMEARecordType = "SMIMEA";
export type RecordsScanReviewRequestAcceptsItemSMIMEARecordData = RecordsBatchRequestPostsItemSMIMEARecordData;
export type RecordsScanReviewRequestAcceptsItemSMIMEARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemSMIMEARecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemSMIMEARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemSMIMEARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted SMIMEA content. See 'data' to set SMIMEA properties. */
    content?: string;
    /** Components of a SMIMEA record. */
    data?: RecordsBatchRequestPostsItemSMIMEARecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemSMIMEARecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemSRVRecordType = "SRV";
export type RecordsScanReviewRequestAcceptsItemSRVRecordData = RecordsBatchRequestPostsItemSRVRecordData;
export type RecordsScanReviewRequestAcceptsItemSRVRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemSRVRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemSRVRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemSRVRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Priority, weight, port, and SRV target. See 'data' for setting the individual component values. */
    content?: string;
    /** Components of a SRV record. */
    data?: RecordsBatchRequestPostsItemSRVRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemSRVRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemSSHFPRecordType = "SSHFP";
export type RecordsScanReviewRequestAcceptsItemSSHFPRecordData = RecordsBatchRequestPostsItemSSHFPRecordData;
export type RecordsScanReviewRequestAcceptsItemSSHFPRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemSSHFPRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemSSHFPRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemSSHFPRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted SSHFP content. See 'data' to set SSHFP properties. */
    content?: string;
    /** Components of a SSHFP record. */
    data?: RecordsBatchRequestPostsItemSSHFPRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemSSHFPRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemSVCBRecordType = "SVCB";
export type RecordsScanReviewRequestAcceptsItemSVCBRecordData = RecordsBatchRequestPostsItemHTTPSRecordData;
export type RecordsScanReviewRequestAcceptsItemSVCBRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemSVCBRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemSVCBRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemSVCBRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted SVCB content. See 'data' to set SVCB properties. */
    content?: string;
    /** Components of a SVCB record. */
    data?: RecordsBatchRequestPostsItemHTTPSRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemSVCBRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemTLSARecordType = "TLSA";
export type RecordsScanReviewRequestAcceptsItemTLSARecordData = RecordsBatchRequestPostsItemSMIMEARecordData;
export type RecordsScanReviewRequestAcceptsItemTLSARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemTLSARecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemTLSARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemTLSARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted TLSA content. See 'data' to set TLSA properties. */
    content?: string;
    /** Components of a TLSA record. */
    data?: RecordsBatchRequestPostsItemSMIMEARecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemTLSARecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItemURIRecordType = "URI";
export type RecordsScanReviewRequestAcceptsItemURIRecordData = RecordsBatchRequestPostsItemURIRecordData;
export type RecordsScanReviewRequestAcceptsItemURIRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewRequestAcceptsItemURIRecordTagsList = Array<string>;
export interface RecordsScanReviewRequestAcceptsItemURIRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemURIRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted URI content. See 'data' to set URI properties. */
    content?: string;
    /** Components of a URI record. */
    data?: RecordsBatchRequestPostsItemURIRecordData;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemURIRecordTagsList;
}
export type RecordsScanReviewRequestAcceptsItem = RecordsScanReviewRequestAcceptsItemARecord | RecordsScanReviewRequestAcceptsItemAAAARecord | RecordsScanReviewRequestAcceptsItemCNAMERecord | RecordsScanReviewRequestAcceptsItemMXRecord | RecordsScanReviewRequestAcceptsItemNSRecord | RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecord | RecordsScanReviewRequestAcceptsItemPTRRecord | RecordsScanReviewRequestAcceptsItemTXTRecord | RecordsScanReviewRequestAcceptsItemCAARecord | RecordsScanReviewRequestAcceptsItemCERTRecord | RecordsScanReviewRequestAcceptsItemDNSKEYRecord | RecordsScanReviewRequestAcceptsItemDSRecord | RecordsScanReviewRequestAcceptsItemHTTPSRecord | RecordsScanReviewRequestAcceptsItemLOCRecord | RecordsScanReviewRequestAcceptsItemNAPTRRecord | RecordsScanReviewRequestAcceptsItemSMIMEARecord | RecordsScanReviewRequestAcceptsItemSRVRecord | RecordsScanReviewRequestAcceptsItemSSHFPRecord | RecordsScanReviewRequestAcceptsItemSVCBRecord | RecordsScanReviewRequestAcceptsItemTLSARecord | RecordsScanReviewRequestAcceptsItemURIRecord;
export type RecordsScanReviewRequestAcceptsList = Array<RecordsScanReviewRequestAcceptsItem>;
export type RecordsScanReviewRequestRejectsItem = RecordsBatchRequestDeletesItem;
export type RecordsScanReviewRequestRejectsList = Array<RecordsBatchRequestDeletesItem>;
export interface ScanReviewRecordRequest {
    /** Identifier. */
    zoneId: string;
    accepts?: RecordsScanReviewRequestAcceptsList;
    rejects?: RecordsScanReviewRequestRejectsList;
}
export type RecordsScanReviewResponseAcceptsItemARecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemAAAARecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemCNAMERecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemMXRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemNSRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export type RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordTagsList = Array<string>;
export type RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordType = "OPENPGPKEY";
export interface RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemTXTRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemCAARecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemCERTRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemDNSKEYRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemDSRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemHTTPSRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemLOCRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemNAPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemSMIMEARecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemSRVRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemSSHFPRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemSVCBRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemTLSARecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItemURIRecordMetaShadowedByList = Array<string>;
export interface RecordsScanReviewResponseAcceptsItemURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsScanReviewResponseAcceptsItemURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsScanReviewResponseAcceptsItem = RecordsScanReviewResponseAcceptsItemARecord | RecordsScanReviewResponseAcceptsItemAAAARecord | RecordsScanReviewResponseAcceptsItemCNAMERecord | RecordsScanReviewResponseAcceptsItemMXRecord | RecordsScanReviewResponseAcceptsItemNSRecord | RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecord | RecordsScanReviewResponseAcceptsItemPTRRecord | RecordsScanReviewResponseAcceptsItemTXTRecord | RecordsScanReviewResponseAcceptsItemCAARecord | RecordsScanReviewResponseAcceptsItemCERTRecord | RecordsScanReviewResponseAcceptsItemDNSKEYRecord | RecordsScanReviewResponseAcceptsItemDSRecord | RecordsScanReviewResponseAcceptsItemHTTPSRecord | RecordsScanReviewResponseAcceptsItemLOCRecord | RecordsScanReviewResponseAcceptsItemNAPTRRecord | RecordsScanReviewResponseAcceptsItemSMIMEARecord | RecordsScanReviewResponseAcceptsItemSRVRecord | RecordsScanReviewResponseAcceptsItemSSHFPRecord | RecordsScanReviewResponseAcceptsItemSVCBRecord | RecordsScanReviewResponseAcceptsItemTLSARecord | RecordsScanReviewResponseAcceptsItemURIRecord;
export type RecordsScanReviewResponseAcceptsList = Array<RecordsScanReviewResponseAcceptsItem>;
export type RecordsScanReviewResponseRejectsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ScanReviewRecordResponse {
    accepts?: RecordsScanReviewResponseAcceptsList | null;
    rejects?: RecordsScanReviewResponseRejectsList | null;
}
export interface ScanTriggerRecordRequest {
    /** Identifier. */
    zoneId: string;
}
export interface ScanTriggerRecordResponse {
}
export type RecordsUpdateRequestType = "A" | "AAAA" | "CNAME" | "MX" | "NS" | "OPENPGPKEY" | "PTR" | "TXT" | "CAA" | "CERT" | "DNSKEY" | "DS" | "HTTPS" | "LOC" | "NAPTR" | "SMIMEA" | "SRV" | "SSHFP" | "SVCB" | "TLSA" | "URI";
export type RecordsUpdateRequestSettingsARecord = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export type RecordsUpdateRequestSettingsCNAMERecord = RecordsBatchRequestPostsItemCNAMERecordSettings;
export type RecordsUpdateRequestSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings | RecordsBatchRequestPostsItemCNAMERecordSettings;
export type RecordsUpdateRequestTagsList = Array<string>;
export type RecordsUpdateRequestDataCAARecord = RecordsBatchRequestPostsItemCAARecordData;
export type RecordsUpdateRequestDataCERTRecord = RecordsBatchRequestPostsItemCERTRecordData;
export type RecordsUpdateRequestDataDNSKEYRecord = RecordsBatchRequestPostsItemDNSKEYRecordData;
export type RecordsUpdateRequestDataDSRecord = RecordsBatchRequestPostsItemDSRecordData;
export type RecordsUpdateRequestDataHTTPSRecord = RecordsBatchRequestPostsItemHTTPSRecordData;
export type RecordsUpdateRequestDataLOCRecordLatDirection = "N" | "S";
export type RecordsUpdateRequestDataLOCRecordLongDirection = "E" | "W";
export interface RecordsUpdateRequestDataLOCRecord {
    /** Altitude of location in meters. */
    altitude?: number;
    /** Degrees of latitude. */
    latDegrees?: number;
    /** Latitude direction. */
    latDirection?: RecordsUpdateRequestDataLOCRecordLatDirection | (string & {});
    /** Minutes of latitude. */
    latMinutes?: number;
    /** Seconds of latitude. */
    latSeconds?: number;
    /** Degrees of longitude. */
    longDegrees?: number;
    /** Longitude direction. */
    longDirection?: RecordsUpdateRequestDataLOCRecordLongDirection | (string & {});
    /** Minutes of longitude. */
    longMinutes?: number;
    /** Seconds of longitude. */
    longSeconds?: number;
    /** Horizontal precision of location. */
    precisionHorz?: number;
    /** Vertical precision of location. */
    precisionVert?: number;
    /** Size of location in meters. */
    size?: number;
}
export type RecordsUpdateRequestDataNAPTRRecord = RecordsBatchRequestPostsItemNAPTRRecordData;
export type RecordsUpdateRequestDataSMIMEARecord = RecordsBatchRequestPostsItemSMIMEARecordData;
export type RecordsUpdateRequestDataSRVRecord = RecordsBatchRequestPostsItemSRVRecordData;
export type RecordsUpdateRequestDataSSHFPRecord = RecordsBatchRequestPostsItemSSHFPRecordData;
export type RecordsUpdateRequestDataURIRecord = RecordsBatchRequestPostsItemURIRecordData;
export type RecordsUpdateRequestData = RecordsBatchRequestPostsItemCAARecordData | RecordsBatchRequestPostsItemCERTRecordData | RecordsBatchRequestPostsItemDNSKEYRecordData | RecordsBatchRequestPostsItemDSRecordData | RecordsBatchRequestPostsItemHTTPSRecordData | RecordsUpdateRequestDataLOCRecord | RecordsBatchRequestPostsItemNAPTRRecordData | RecordsBatchRequestPostsItemSMIMEARecordData | RecordsBatchRequestPostsItemSRVRecordData | RecordsBatchRequestPostsItemSSHFPRecordData | RecordsBatchRequestPostsItemURIRecordData;
export interface UpdateRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    dnsRecordId: string;
    /** Whether to include shadow metadata in the `meta` field of each record in the response. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    includeShadowMetadata?: boolean;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsUpdateRequestType | (string & {});
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv4 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsUpdateRequestSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsUpdateRequestTagsList;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Components of a CAA record. */
    data?: RecordsUpdateRequestData;
}
export type RecordsUpdateResultARecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultAAAARecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeAAAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultCNAMERecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCNAME;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultMXRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeMX;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultNSRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export type RecordsUpdateResultOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export type RecordsUpdateResultOpenpgpkeyRecordTagsList = Array<string>;
export type RecordsUpdateResultOpenpgpkeyRecordType = "OPENPGPKEY";
export interface RecordsUpdateResultOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsUpdateResultOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsUpdateResultOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export type RecordsUpdateResultPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypePTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultTXTRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTXT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultCAARecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultCERTRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCERT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultDNSKEYRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDNSKEY;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultDSRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultHTTPSRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeHTTPS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultLOCRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeLOC;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultNAPTRRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNAPTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultSMIMEARecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSMIMEA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultSRVRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSRV;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultSSHFPRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSSHFP;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultSVCBRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSVCB;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultTLSARecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTLSA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResultURIRecordMetaShadowedByList = Array<string>;
export interface RecordsUpdateResultURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export interface RecordsUpdateResultURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeURI;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export type RecordsUpdateResult = RecordsUpdateResultARecord | RecordsUpdateResultAAAARecord | RecordsUpdateResultCNAMERecord | RecordsUpdateResultMXRecord | RecordsUpdateResultNSRecord | RecordsUpdateResultOpenpgpkeyRecord | RecordsUpdateResultPTRRecord | RecordsUpdateResultTXTRecord | RecordsUpdateResultCAARecord | RecordsUpdateResultCERTRecord | RecordsUpdateResultDNSKEYRecord | RecordsUpdateResultDSRecord | RecordsUpdateResultHTTPSRecord | RecordsUpdateResultLOCRecord | RecordsUpdateResultNAPTRRecord | RecordsUpdateResultSMIMEARecord | RecordsUpdateResultSRVRecord | RecordsUpdateResultSSHFPRecord | RecordsUpdateResultSVCBRecord | RecordsUpdateResultTLSARecord | RecordsUpdateResultURIRecord;
export type UpdateRecordResponse = RecordsUpdateResult;
export interface UpdateZoneTransferAclRequest {
    accountId: string;
    aclId: string;
    /** Allowed IPv4/IPv6 address range of primary or secondary nameservers. This will be applied for the entire account. The IP range is used to allow additional NOTIFY IPs for secondary zones and IPs Cloudflare allows AXFR/IXFR requests from for primary zones. CIDRs are limited to a maximum of /24 for IPv4 and /64 for IPv6 respectively. */
    ipRange: string;
    /** The name of the acl. */
    name: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateZoneTransferAclResponse {
    id: string;
    /** Allowed IPv4/IPv6 address range of primary or secondary nameservers. This will be applied for the entire account. The IP range is used to allow additional NOTIFY IPs for secondary zones and IPs Cloudflare allows AXFR/IXFR requests from for primary zones. CIDRs are limited to a maximum of /24 for IPv4 and /64 for IPv6 respectively. */
    ipRange: string;
    /** The name of the acl. */
    name: string;
}
export type ZoneTransfersIncomingUpdateRequestPeersList = Array<string>;
export interface UpdateZoneTransferIncomingRequest {
    zoneId: string;
    /** How often should a secondary zone auto refresh regardless of DNS NOTIFY. Not applicable for primary zones. */
    autoRefreshSeconds: number;
    /** Zone name. */
    name: string;
    /** A list of peer tags. */
    peers: ZoneTransfersIncomingUpdateRequestPeersList;
}
export type ZoneTransfersIncomingUpdateResponsePeersList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateZoneTransferIncomingResponse {
    id?: string | null;
    /** How often should a secondary zone auto refresh regardless of DNS NOTIFY. Not applicable for primary zones. */
    autoRefreshSeconds?: number | null;
    /** The time for a specific event. */
    checkedTime?: string | null;
    /** The time for a specific event. */
    createdTime?: string | null;
    /** The time for a specific event. */
    modifiedTime?: string | null;
    /** Zone name. */
    name?: string | null;
    /** A list of peer tags. */
    peers?: ZoneTransfersIncomingUpdateResponsePeersList | null;
    /** The serial number of the SOA for the given zone. */
    soaSerial?: number | null;
}
export type ZoneTransfersOutgoingUpdateRequestPeersList = Array<string>;
export interface UpdateZoneTransferOutgoingRequest {
    zoneId: string;
    /** Zone name. */
    name: string;
    /** A list of peer tags. */
    peers: ZoneTransfersOutgoingUpdateRequestPeersList;
}
export type ZoneTransfersOutgoingUpdateResponsePeersList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateZoneTransferOutgoingResponse {
    id?: string | null;
    /** The time for a specific event. */
    checkedTime?: string | null;
    /** The time for a specific event. */
    createdTime?: string | null;
    /** The time for a specific event. */
    lastTransferredTime?: string | null;
    /** Zone name. */
    name?: string | null;
    /** A list of peer tags. */
    peers?: ZoneTransfersOutgoingUpdateResponsePeersList | null;
    /** The serial number of the SOA for the given zone. */
    soaSerial?: number | null;
}
export interface UpdateZoneTransferPeerRequest {
    accountId: string;
    peerId: string;
    /** The name of the peer. */
    name: string;
    /** IPv4/IPv6 address of primary or secondary nameserver, depending on what zone this peer is linked to. For primary zones this IP defines the IP of the secondary nameserver Cloudflare will NOTIFY upon zone changes. For secondary zones this IP defines the IP of the primary nameserver Cloudflare will send AXFR/IXFR requests to. */
    ip?: string;
    /** Enable IXFR transfer protocol, default is AXFR. Only applicable to secondary zones. */
    ixfrEnable?: boolean;
    /** DNS port of primary or secondary nameserver, depending on what zone this peer is linked to. */
    port?: number;
    /** TSIG authentication will be used for zone transfer if configured. */
    tsigId?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateZoneTransferPeerResponse {
    id: string;
    /** The name of the peer. */
    name: string;
    /** IPv4/IPv6 address of primary or secondary nameserver, depending on what zone this peer is linked to. For primary zones this IP defines the IP of the secondary nameserver Cloudflare will NOTIFY upon zone changes. For secondary zones this IP defines the IP of the primary nameserver Cloudflare will send AXFR/IXFR requests to. */
    ip?: string | null;
    /** Enable IXFR transfer protocol, default is AXFR. Only applicable to secondary zones. */
    ixfrEnable?: boolean | null;
    /** DNS port of primary or secondary nameserver, depending on what zone this peer is linked to. */
    port?: number | null;
    /** TSIG authentication will be used for zone transfer if configured. */
    tsigId?: string | null;
}
export interface UpdateZoneTransferTsigRequest {
    accountId: string;
    tsigId: string;
    /** TSIG algorithm. */
    algo: string;
    /** TSIG key name. */
    name: string;
    /** TSIG secret. */
    secret: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateZoneTransferTsigResponse {
    id: string;
    /** TSIG algorithm. */
    algo: string;
    /** TSIG key name. */
    name: string;
    /** TSIG secret. */
    secret: string;
}
export type BatchRecordError = CloudflareOpError;
/** Send a Batch of DNS Record API calls to be executed together. Notes: - Although Cloudflare will execute the batched operations in a single database transaction, Cloudflare's distributed KV store must treat each record change as a single key-value pair. This means that the propagation of changes is not atomic. See [the documentation](https://developers.cloudflare.com/dns/manage-dns-records/how-to/batch-record-changes/ "Batch DNS records") for more information. - The operations you specify within the /batch request body are always executed in the following order: - Deletes - Patches - Puts - Posts */
export declare const batchRecord: API.OperationMethod<BatchRecordRequest, BatchRecordResponse, BatchRecordError, CloudflareOpContext>;
export type CreateRecordError = DnsRecordAlreadyExists | Forbidden | CloudflareOpError;
/** Create a new DNS record for a zone. Notes: - A/AAAA records cannot exist on the same name as CNAME records. - NS records cannot exist on the same name as any other record type. - Domain names are always represented in Punycode, even if Unicode characters were used when creating the record. */
export declare const createRecord: API.OperationMethod<CreateRecordRequest, CreateRecordResponse, CreateRecordError, CloudflareOpContext>;
export type CreateSettingAccountViewError = InternalDnsNotAvailable | CloudflareOpError;
/** Create Internal DNS View for an account */
export declare const createSettingAccountView: API.OperationMethod<CreateSettingAccountViewRequest, CreateSettingAccountViewResponse, CreateSettingAccountViewError, CloudflareOpContext>;
export type CreateSettingsAccountNameserverSetError = CloudflareOpError;
/** Creates an immutable Custom Nameserver Set. To change a set, create a new one, move any zone assignments, and delete the old set. */
export declare const createSettingsAccountNameserverSet: API.OperationMethod<CreateSettingsAccountNameserverSetRequest, CreateSettingsAccountNameserverSetResponse, CreateSettingsAccountNameserverSetError, CloudflareOpContext>;
export type CreateZoneTransferAclError = CloudflareOpError;
/** Create ACL. */
export declare const createZoneTransferAcl: API.OperationMethod<CreateZoneTransferAclRequest, CreateZoneTransferAclResponse, CreateZoneTransferAclError, CloudflareOpContext>;
export type CreateZoneTransferForceAxfrError = CloudflareOpError;
/** Sends AXFR zone transfer request to primary nameserver(s). */
export declare const createZoneTransferForceAxfr: API.OperationMethod<CreateZoneTransferForceAxfrRequest, CreateZoneTransferForceAxfrResponse, CreateZoneTransferForceAxfrError, CloudflareOpContext>;
export type CreateZoneTransferIncomingError = CloudflareOpError;
/** Create secondary zone configuration for incoming zone transfers. */
export declare const createZoneTransferIncoming: API.OperationMethod<CreateZoneTransferIncomingRequest, CreateZoneTransferIncomingResponse, CreateZoneTransferIncomingError, CloudflareOpContext>;
export type CreateZoneTransferOutgoingError = OutgoingZoneTransfersNotAllowed | CloudflareOpError;
/** Create primary zone configuration for outgoing zone transfers. */
export declare const createZoneTransferOutgoing: API.OperationMethod<CreateZoneTransferOutgoingRequest, CreateZoneTransferOutgoingResponse, CreateZoneTransferOutgoingError, CloudflareOpContext>;
export type CreateZoneTransferPeerError = CloudflareOpError;
/** Create Peer. */
export declare const createZoneTransferPeer: API.OperationMethod<CreateZoneTransferPeerRequest, CreateZoneTransferPeerResponse, CreateZoneTransferPeerError, CloudflareOpContext>;
export type CreateZoneTransferTsigError = CloudflareOpError;
/** Create TSIG. */
export declare const createZoneTransferTsig: API.OperationMethod<CreateZoneTransferTsigRequest, CreateZoneTransferTsigResponse, CreateZoneTransferTsigError, CloudflareOpContext>;
export type DeleteDnssecError = Forbidden | CloudflareOpError;
/** Delete DNSSEC. */
export declare const deleteDnssec: API.OperationMethod<DeleteDnssecRequest, DeleteDnssecResponse, DeleteDnssecError, CloudflareOpContext>;
export type DeleteRecordError = RecordNotFound | CloudflareOpError;
/** Permanently removes a DNS record from the zone. */
export declare const deleteRecord: API.OperationMethod<DeleteRecordRequest, DeleteRecordResponse, DeleteRecordError, CloudflareOpContext>;
export type DeleteSettingAccountViewError = ViewNotFound | CloudflareOpError;
/** Delete an existing Internal DNS View */
export declare const deleteSettingAccountView: API.OperationMethod<DeleteSettingAccountViewRequest, DeleteSettingAccountViewResponse, DeleteSettingAccountViewError, CloudflareOpContext>;
export type DeleteSettingsAccountNameserverSetError = CloudflareOpError;
/** Deletes an unassigned Custom Nameserver Set. */
export declare const deleteSettingsAccountNameserverSet: API.OperationMethod<DeleteSettingsAccountNameserverSetRequest, DeleteSettingsAccountNameserverSetResponse, DeleteSettingsAccountNameserverSetError, CloudflareOpContext>;
export type DeleteZoneTransferAclError = AclNotFound | CloudflareOpError;
/** Delete ACL. */
export declare const deleteZoneTransferAcl: API.OperationMethod<DeleteZoneTransferAclRequest, DeleteZoneTransferAclResponse, DeleteZoneTransferAclError, CloudflareOpContext>;
export type DeleteZoneTransferIncomingError = IncomingZoneTransferNotFound | CloudflareOpError;
/** Delete secondary zone configuration for incoming zone transfers. */
export declare const deleteZoneTransferIncoming: API.OperationMethod<DeleteZoneTransferIncomingRequest, DeleteZoneTransferIncomingResponse, DeleteZoneTransferIncomingError, CloudflareOpContext>;
export type DeleteZoneTransferOutgoingError = OutgoingZoneTransferNotFound | OutgoingZoneTransfersNotAllowed | CloudflareOpError;
/** Delete primary zone configuration for outgoing zone transfers. */
export declare const deleteZoneTransferOutgoing: API.OperationMethod<DeleteZoneTransferOutgoingRequest, DeleteZoneTransferOutgoingResponse, DeleteZoneTransferOutgoingError, CloudflareOpContext>;
export type DeleteZoneTransferPeerError = PeerNotFound | CloudflareOpError;
/** Delete Peer. */
export declare const deleteZoneTransferPeer: API.OperationMethod<DeleteZoneTransferPeerRequest, DeleteZoneTransferPeerResponse, DeleteZoneTransferPeerError, CloudflareOpContext>;
export type DeleteZoneTransferTsigError = TsigNotFound | CloudflareOpError;
/** Delete TSIG. */
export declare const deleteZoneTransferTsig: API.OperationMethod<DeleteZoneTransferTsigRequest, DeleteZoneTransferTsigResponse, DeleteZoneTransferTsigError, CloudflareOpContext>;
export type DisableZoneTransferOutgoingError = OutgoingZoneTransfersNotAllowed | CloudflareOpError;
/** Disable outgoing zone transfers for primary zone and clears IXFR backlog of primary zone. */
export declare const disableZoneTransferOutgoing: API.OperationMethod<DisableZoneTransferOutgoingRequest, DisableZoneTransferOutgoingResponse, DisableZoneTransferOutgoingError, CloudflareOpContext>;
export type EnableZoneTransferOutgoingError = OutgoingZoneTransfersNotAllowed | CloudflareOpError;
/** Enable outgoing zone transfers for primary zone. */
export declare const enableZoneTransferOutgoing: API.OperationMethod<EnableZoneTransferOutgoingRequest, EnableZoneTransferOutgoingResponse, EnableZoneTransferOutgoingError, CloudflareOpContext>;
export type ExportRecordError = CloudflareOpError;
/** You can export your [BIND config](https://en.wikipedia.org/wiki/Zone_file "Zone file") through this endpoint. See [the documentation](https://developers.cloudflare.com/dns/manage-dns-records/how-to/import-and-export/ "Import and export records") for more information. */
export declare const exportRecord: API.OperationMethod<ExportRecordRequest, ExportRecordResponse, ExportRecordError, CloudflareOpContext>;
export type ForceNotifyZoneTransferOutgoingError = CloudflareOpError;
/** Notifies the secondary nameserver(s) and clears IXFR backlog of primary zone. */
export declare const forceNotifyZoneTransferOutgoing: API.OperationMethod<ForceNotifyZoneTransferOutgoingRequest, ForceNotifyZoneTransferOutgoingResponse, ForceNotifyZoneTransferOutgoingError, CloudflareOpContext>;
export type GetAnalyticReportError = CloudflareOpError;
/** Retrieves a list of summarised aggregate metrics over a given time period. See [Analytics API properties](https://developers.cloudflare.com/dns/reference/analytics-api-properties/) for detailed information about the available query parameters. */
export declare const getAnalyticReport: API.OperationMethod<GetAnalyticReportRequest, GetAnalyticReportResponse, GetAnalyticReportError, CloudflareOpContext>;
export type GetAnalyticReportBytimeError = CloudflareOpError;
/** Retrieves a list of aggregate metrics grouped by time interval. See [Analytics API properties](https://developers.cloudflare.com/dns/reference/analytics-api-properties/) for detailed information about the available query parameters. */
export declare const getAnalyticReportBytime: API.OperationMethod<GetAnalyticReportBytimeRequest, GetAnalyticReportBytimeResponse, GetAnalyticReportBytimeError, CloudflareOpContext>;
export type GetDnssecError = Forbidden | CloudflareOpError;
/** Details about DNSSEC status and configuration. */
export declare const getDnssec: API.OperationMethod<GetDnssecRequest, GetDnssecResponse, GetDnssecError, CloudflareOpContext>;
export type GetRecordError = Forbidden | RecordNotFound | CloudflareOpError;
/** Retrieves details for a specific DNS record in the zone. */
export declare const getRecord: API.OperationMethod<GetRecordRequest, GetRecordResponse, GetRecordError, CloudflareOpContext>;
export type GetSettingAccountError = CloudflareOpError;
/** Show DNS settings for an account */
export declare const getSettingAccount: API.OperationMethod<GetSettingAccountRequest, GetSettingAccountResponse, GetSettingAccountError, CloudflareOpContext>;
export type GetSettingAccountViewError = ViewNotFound | CloudflareOpError;
/** Get DNS Internal View */
export declare const getSettingAccountView: API.OperationMethod<GetSettingAccountViewRequest, GetSettingAccountViewResponse, GetSettingAccountViewError, CloudflareOpContext>;
export type GetSettingsAccountNameserverSetError = CloudflareOpError;
/** Gets a Custom Nameserver Set owned by an account. */
export declare const getSettingsAccountNameserverSet: API.OperationMethod<GetSettingsAccountNameserverSetRequest, GetSettingsAccountNameserverSetResponse, GetSettingsAccountNameserverSetError, CloudflareOpContext>;
export type GetSettingZoneError = Forbidden | CloudflareOpError;
/** Show DNS settings for a zone */
export declare const getSettingZone: API.OperationMethod<GetSettingZoneRequest, GetSettingZoneResponse, GetSettingZoneError, CloudflareOpContext>;
export type GetUsageAccountError = CloudflareOpError;
/** Get the current DNS record usage and quota for an account. May include internal DNS usage and quota. */
export declare const getUsageAccount: API.OperationMethod<GetUsageAccountRequest, GetUsageAccountResponse, GetUsageAccountError, CloudflareOpContext>;
export type GetUsageZoneError = CloudflareOpError;
/** Get the current DNS record usage for a zone, including the number of records and the quota limit. */
export declare const getUsageZone: API.OperationMethod<GetUsageZoneRequest, GetUsageZoneResponse, GetUsageZoneError, CloudflareOpContext>;
export type GetZoneTransferAclError = AclNotFound | CloudflareOpError;
/** Get ACL. */
export declare const getZoneTransferAcl: API.OperationMethod<GetZoneTransferAclRequest, GetZoneTransferAclResponse, GetZoneTransferAclError, CloudflareOpContext>;
export type GetZoneTransferIncomingError = IncomingZoneTransferNotFound | CloudflareOpError;
/** Get secondary zone configuration for incoming zone transfers. */
export declare const getZoneTransferIncoming: API.OperationMethod<GetZoneTransferIncomingRequest, GetZoneTransferIncomingResponse, GetZoneTransferIncomingError, CloudflareOpContext>;
export type GetZoneTransferOutgoingError = OutgoingZoneTransferNotFound | OutgoingZoneTransfersNotAllowed | CloudflareOpError;
/** Get primary zone configuration for outgoing zone transfers. */
export declare const getZoneTransferOutgoing: API.OperationMethod<GetZoneTransferOutgoingRequest, GetZoneTransferOutgoingResponse, GetZoneTransferOutgoingError, CloudflareOpContext>;
export type GetZoneTransferOutgoingStatusError = CloudflareOpError;
/** Get primary zone transfer status. */
export declare const getZoneTransferOutgoingStatus: API.OperationMethod<GetZoneTransferOutgoingStatusRequest, GetZoneTransferOutgoingStatusResponse, GetZoneTransferOutgoingStatusError, CloudflareOpContext>;
export type GetZoneTransferPeerError = PeerNotFound | CloudflareOpError;
/** Get Peer. */
export declare const getZoneTransferPeer: API.OperationMethod<GetZoneTransferPeerRequest, GetZoneTransferPeerResponse, GetZoneTransferPeerError, CloudflareOpContext>;
export type GetZoneTransferTsigError = TsigNotFound | CloudflareOpError;
/** Get TSIG. */
export declare const getZoneTransferTsig: API.OperationMethod<GetZoneTransferTsigRequest, GetZoneTransferTsigResponse, GetZoneTransferTsigError, CloudflareOpContext>;
export type ImportRecordError = CloudflareOpError;
/** You can upload your [BIND config](https://en.wikipedia.org/wiki/Zone_file "Zone file") through this endpoint. It assumes that cURL is called from a location with bind_config.txt (valid BIND config) present. See [the documentation](https://developers.cloudflare.com/dns/manage-dns-records/how-to/import-and-export/ "Import and export records") for more information. */
export declare const importRecord: API.OperationMethod<ImportRecordRequest, ImportRecordResponse, ImportRecordError, CloudflareOpContext>;
export type ListDnssecZskError = CloudflareOpError;
/** List the Zone Signing Keys (ZSKs) that DNSSEC uses for the zone. */
export declare const listDnssecZsk: API.OperationMethod<ListDnssecZskRequest, ListDnssecZskResponse, ListDnssecZskError, CloudflareOpContext>;
export type ListRecordsError = Forbidden | CloudflareOpError;
/** List, search, sort, and filter a zones' DNS records. */
export declare const listRecords: API.PaginatedOperationMethod<ListRecordsRequest, ListRecordsResponse, ListRecordsError, CloudflareOpContext, RecordsListResultItem>;
export type ListSettingAccountViewsError = CloudflareOpError;
/** List DNS Internal Views for an Account */
export declare const listSettingAccountViews: API.PaginatedOperationMethod<ListSettingAccountViewsRequest, ListSettingAccountViewsResponse, ListSettingAccountViewsError, CloudflareOpContext, SettingsAccountViewsListResultItem>;
export type ListSettingsAccountNameserverSetsError = CloudflareOpError;
/** Lists an account's Custom Nameserver Sets. */
export declare const listSettingsAccountNameserverSets: API.OperationMethod<ListSettingsAccountNameserverSetsRequest, ListSettingsAccountNameserverSetsResponse, ListSettingsAccountNameserverSetsError, CloudflareOpContext>;
export type ListZoneTransferAclsError = CloudflareOpError;
/** List ACLs. */
export declare const listZoneTransferAcls: API.PaginatedOperationMethod<ListZoneTransferAclsRequest, ListZoneTransferAclsResponse, ListZoneTransferAclsError, CloudflareOpContext, ZoneTransfersAclsListResultItem>;
export type ListZoneTransferPeersError = CloudflareOpError;
/** List Peers. */
export declare const listZoneTransferPeers: API.PaginatedOperationMethod<ListZoneTransferPeersRequest, ListZoneTransferPeersResponse, ListZoneTransferPeersError, CloudflareOpContext, ZoneTransfersPeersListResultItem>;
export type ListZoneTransferTsigsError = CloudflareOpError;
/** List TSIGs. */
export declare const listZoneTransferTsigs: API.PaginatedOperationMethod<ListZoneTransferTsigsRequest, ListZoneTransferTsigsResponse, ListZoneTransferTsigsError, CloudflareOpContext, ZoneTransfersTsigsListResultItem>;
export type PatchDnssecError = Forbidden | CloudflareOpError;
/** Enable or disable DNSSEC. */
export declare const patchDnssec: API.OperationMethod<PatchDnssecRequest, PatchDnssecResponse, PatchDnssecError, CloudflareOpContext>;
export type PatchRecordError = CloudflareOpError;
/** Update an existing DNS record. Notes: - A/AAAA records cannot exist on the same name as CNAME records. - NS records cannot exist on the same name as any other record type. - Domain names are always represented in Punycode, even if Unicode characters were used when creating the record. */
export declare const patchRecord: API.OperationMethod<PatchRecordRequest, PatchRecordResponse, PatchRecordError, CloudflareOpContext>;
export type PatchSettingAccountError = DnsSettingNotAvailable | CloudflareOpError;
/** Update DNS settings for an account */
export declare const patchSettingAccount: API.OperationMethod<PatchSettingAccountRequest, PatchSettingAccountResponse, PatchSettingAccountError, CloudflareOpContext>;
export type PatchSettingAccountViewError = ViewNotFound | CloudflareOpError;
/** Update an existing Internal DNS View */
export declare const patchSettingAccountView: API.OperationMethod<PatchSettingAccountViewRequest, PatchSettingAccountViewResponse, PatchSettingAccountViewError, CloudflareOpContext>;
export type PatchSettingZoneError = Forbidden | CloudflareOpError;
/** Update DNS settings for a zone */
export declare const patchSettingZone: API.OperationMethod<PatchSettingZoneRequest, PatchSettingZoneResponse, PatchSettingZoneError, CloudflareOpContext>;
export type ScanListRecordError = CloudflareOpError;
/** Retrieves the list of DNS records discovered up to this point by the asynchronous scan. These records are temporary until explicitly accepted or rejected via `POST /scan/review`. Additional records may be discovered by the scan later. */
export declare const scanListRecord: API.PaginatedOperationMethod<ScanListRecordRequest, ScanListRecordResponse, ScanListRecordError, CloudflareOpContext, RecordsScanListResultItem>;
export type ScanRecordError = CloudflareOpError;
/** Scan for common DNS records on your domain and automatically add them to your zone. Useful if you haven't updated your nameservers yet. */
export declare const scanRecord: API.OperationMethod<ScanRecordRequest, ScanRecordResponse, ScanRecordError, CloudflareOpContext>;
export type ScanReviewRecordError = CloudflareOpError;
/** Accept or reject DNS records found by the DNS records scan. Accepted records will be permanently added to the zone, while rejected records will be permanently deleted. */
export declare const scanReviewRecord: API.OperationMethod<ScanReviewRecordRequest, ScanReviewRecordResponse, ScanReviewRecordError, CloudflareOpContext>;
export type ScanTriggerRecordError = CloudflareOpError;
/** Initiates an asynchronous scan for common DNS records on your domain. Note that this **does not** automatically add records to your zone. The scan runs in the background, and results can be reviewed later using the `/scan/review` endpoints. Useful if you haven't updated your nameservers yet. */
export declare const scanTriggerRecord: API.OperationMethod<ScanTriggerRecordRequest, ScanTriggerRecordResponse, ScanTriggerRecordError, CloudflareOpContext>;
export type UpdateRecordError = CloudflareOpError;
/** Overwrite an existing DNS record. Notes: - A/AAAA records cannot exist on the same name as CNAME records. - NS records cannot exist on the same name as any other record type. - Domain names are always represented in Punycode, even if Unicode characters were used when creating the record. */
export declare const updateRecord: API.OperationMethod<UpdateRecordRequest, UpdateRecordResponse, UpdateRecordError, CloudflareOpContext>;
export type UpdateZoneTransferAclError = AclNotFound | CloudflareOpError;
/** Modify ACL. */
export declare const updateZoneTransferAcl: API.OperationMethod<UpdateZoneTransferAclRequest, UpdateZoneTransferAclResponse, UpdateZoneTransferAclError, CloudflareOpContext>;
export type UpdateZoneTransferIncomingError = IncomingZoneTransferNotFound | CloudflareOpError;
/** Update secondary zone configuration for incoming zone transfers. */
export declare const updateZoneTransferIncoming: API.OperationMethod<UpdateZoneTransferIncomingRequest, UpdateZoneTransferIncomingResponse, UpdateZoneTransferIncomingError, CloudflareOpContext>;
export type UpdateZoneTransferOutgoingError = OutgoingZoneTransferNotFound | OutgoingZoneTransfersNotAllowed | CloudflareOpError;
/** Update primary zone configuration for outgoing zone transfers. */
export declare const updateZoneTransferOutgoing: API.OperationMethod<UpdateZoneTransferOutgoingRequest, UpdateZoneTransferOutgoingResponse, UpdateZoneTransferOutgoingError, CloudflareOpContext>;
export type UpdateZoneTransferPeerError = PeerNotFound | CloudflareOpError;
/** Modify Peer. */
export declare const updateZoneTransferPeer: API.OperationMethod<UpdateZoneTransferPeerRequest, UpdateZoneTransferPeerResponse, UpdateZoneTransferPeerError, CloudflareOpContext>;
export type UpdateZoneTransferTsigError = TsigNotFound | CloudflareOpError;
/** Modify TSIG. */
export declare const updateZoneTransferTsig: API.OperationMethod<UpdateZoneTransferTsigRequest, UpdateZoneTransferTsigResponse, UpdateZoneTransferTsigError, CloudflareOpContext>;
//# sourceMappingURL=dns.d.ts.map