import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const WaitingRoomNotFound_base: S.TaggedErrorClass<"WaitingRoomNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WaitingRoomNotFound extends /*@__PURE__*/ WaitingRoomNotFound_base {
}
declare const ZoneNotEntitled_base: S.TaggedErrorClass<"ZoneNotEntitled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ZoneNotEntitled extends /*@__PURE__*/ ZoneNotEntitled_base {
}
export type EventsCreateRequestTurnstileAction = "log" | "infinite_queue";
export type EventsCreateRequestTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
export interface CreateEventRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    /** An ISO 8601 timestamp that marks the end of the event. */
    eventEndTime: string;
    /** An ISO 8601 timestamp that marks the start of the event. At this time, queued users will be processed with the event's configuration. The start time must be at least one minute before `event_end_time`. */
    eventStartTime: string;
    /** A unique name to identify the event. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** If set, the event will override the waiting room's `custom_page_html` property while it is active. If null, the event will inherit it. */
    customPageHtml?: string;
    /** A note that you can use to add more details about the event. */
    description?: string;
    /** If set, the event will override the waiting room's `disable_session_renewal` property while it is active. If null, the event will inherit it. */
    disableSessionRenewal?: boolean;
    /** If set, the event will override the waiting room's `new_users_per_minute` property while it is active. If null, the event will inherit it. This can only be set if the event's `total_active_users` property is also set. */
    newUsersPerMinute?: number;
    /** An ISO 8601 timestamp that marks when to begin queueing all users before the event starts. The prequeue must start at least five minutes before `event_start_time`. */
    prequeueStartTime?: string;
    /** If set, the event will override the waiting room's `queueing_method` property while it is active. If null, the event will inherit it. */
    queueingMethod?: string;
    /** If set, the event will override the waiting room's `session_duration` property while it is active. If null, the event will inherit it. */
    sessionDuration?: number;
    /** If enabled, users in the prequeue will be shuffled randomly at the `event_start_time`. Requires that `prequeue_start_time` is not null. This is useful for situations when many users will join the event prequeue at the same time and you want to shuffle them to ensure fairness. Naturally, it makes the most sense to enable this feature when the `queueing_method` during the event respects ordering such as **fifo**, or else the shuffling may be unnecessary. */
    shuffleAtEventStart?: boolean;
    /** Suspends or allows an event. If set to `true`, the event is ignored and traffic will be handled based on the waiting room configuration. */
    suspended?: boolean;
    /** If set, the event will override the waiting room's `total_active_users` property while it is active. If null, the event will inherit it. This can only be set if the event's `new_users_per_minute` property is also set. */
    totalActiveUsers?: number;
    /** If set, the event will override the waiting room's `turnstile_action` property while it is active. If null, the event will inherit it. */
    turnstileAction?: EventsCreateRequestTurnstileAction | (string & {});
    /** If set, the event will override the waiting room's `turnstile_mode` property while it is active. If null, the event will inherit it. */
    turnstileMode?: EventsCreateRequestTurnstileMode | (string & {});
}
export type EventsCreateResponseTurnstileAction = "log" | "infinite_queue";
export type EventsCreateResponseTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateEventResponse {
    id?: string | null;
    createdOn?: string | null;
    /** If set, the event will override the waiting room's `custom_page_html` property while it is active. If null, the event will inherit it. */
    customPageHtml?: string | null;
    /** A note that you can use to add more details about the event. */
    description?: string | null;
    /** If set, the event will override the waiting room's `disable_session_renewal` property while it is active. If null, the event will inherit it. */
    disableSessionRenewal?: boolean | null;
    /** An ISO 8601 timestamp that marks the end of the event. */
    eventEndTime?: string | null;
    /** An ISO 8601 timestamp that marks the start of the event. At this time, queued users will be processed with the event's configuration. The start time must be at least one minute before `event_end_time`. */
    eventStartTime?: string | null;
    modifiedOn?: string | null;
    /** A unique name to identify the event. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** If set, the event will override the waiting room's `new_users_per_minute` property while it is active. If null, the event will inherit it. This can only be set if the event's `total_active_users` property is also set. */
    newUsersPerMinute?: number | null;
    /** An ISO 8601 timestamp that marks when to begin queueing all users before the event starts. The prequeue must start at least five minutes before `event_start_time`. */
    prequeueStartTime?: string | null;
    /** If set, the event will override the waiting room's `queueing_method` property while it is active. If null, the event will inherit it. */
    queueingMethod?: string | null;
    /** If set, the event will override the waiting room's `session_duration` property while it is active. If null, the event will inherit it. */
    sessionDuration?: number | null;
    /** If enabled, users in the prequeue will be shuffled randomly at the `event_start_time`. Requires that `prequeue_start_time` is not null. This is useful for situations when many users will join the event prequeue at the same time and you want to shuffle them to ensure fairness. Naturally, it makes the most sense to enable this feature when the `queueing_method` during the event respects ordering such as **fifo**, or else the shuffling may be unnecessary. */
    shuffleAtEventStart?: boolean | null;
    /** Suspends or allows an event. If set to `true`, the event is ignored and traffic will be handled based on the waiting room configuration. */
    suspended?: boolean | null;
    /** If set, the event will override the waiting room's `total_active_users` property while it is active. If null, the event will inherit it. This can only be set if the event's `new_users_per_minute` property is also set. */
    totalActiveUsers?: number | null;
    /** If set, the event will override the waiting room's `turnstile_action` property while it is active. If null, the event will inherit it. */
    turnstileAction?: EventsCreateResponseTurnstileAction | null;
    /** If set, the event will override the waiting room's `turnstile_mode` property while it is active. If null, the event will inherit it. */
    turnstileMode?: EventsCreateResponseTurnstileMode | null;
}
export type RulesCreateRequestRulesAction = "bypass_waiting_room";
export interface RulesCreateRequestRules {
    /** The action to take when the expression matches. */
    action: RulesCreateRequestRulesAction | (string & {});
    /** Criteria defining when there is a match for the current rule. */
    expression: string;
    /** The description of the rule. */
    description?: string;
    /** When set to true, the rule is enabled. */
    enabled?: boolean;
}
export interface CreateRuleRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    rules: RulesCreateRequestRules;
}
export type RulesCreateResultItemAction = "bypass_waiting_room";
export interface RulesCreateResultItem {
    /** The ID of the rule. */
    id?: string | null;
    /** The action to take when the expression matches. */
    action?: RulesCreateResultItemAction | null;
    /** The description of the rule. */
    description?: string | null;
    /** When set to true, the rule is enabled. */
    enabled?: boolean | null;
    /** Criteria defining when there is a match for the current rule. */
    expression?: string | null;
    lastUpdated?: string | null;
    /** The version of the rule. */
    version?: string | null;
}
export type RulesCreateResultList = Array<RulesCreateResultItem>;
export interface CreateRuleResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface CreateRequestAdditionalRoutesItem {
    /** The hostname to which this waiting room will be applied (no wildcards). The hostname must be the primary domain, subdomain, or custom hostname (if using SSL for SaaS) of this zone. Please do not include the scheme (http:// or https://). */
    host?: string;
    /** Sets the path within the host to enable the waiting room on. The waiting room will be enabled for all subpaths as well. If there are two waiting rooms on the same subpath, the waiting room for the most specific path will be chosen. Wildcards and query parameters are not supported. */
    path?: string;
}
export type CreateRequestAdditionalRoutesList = Array<CreateRequestAdditionalRoutesItem>;
export type CreateRequestCookieAttributesSamesite = "auto" | "lax" | "none" | "strict";
export type CreateRequestCookieAttributesSecure = "auto" | "always" | "never";
export interface CreateRequestCookieAttributes {
    /** Configures the SameSite attribute on the waiting room cookie. Value `auto` will be translated to `lax` or `none` depending if **Always Use HTTPS** is enabled. Note that when using value `none`, the secure attribute cannot be set to `never`. */
    samesite?: CreateRequestCookieAttributesSamesite | (string & {});
    /** Configures the Secure attribute on the waiting room cookie. Value `always` indicates that the Secure attribute will be set in the Set-Cookie header, `never` indicates that the Secure attribute will not be set, and `auto` will set the Secure attribute depending if **Always Use HTTPS** is enabled. */
    secure?: CreateRequestCookieAttributesSecure | (string & {});
}
export type CreateRequestDefaultTemplateLanguage = "en-US" | "es-ES" | "de-DE" | "fr-FR" | "it-IT" | "ja-JP" | "ko-KR" | "pt-BR" | "zh-CN" | "zh-TW" | "nl-NL" | "pl-PL" | "id-ID" | "tr-TR" | "ar-EG" | "ru-RU" | "fa-IR" | "bg-BG" | "hr-HR" | "cs-CZ" | "da-DK" | "fi-FI" | "lt-LT" | "lv-LV" | "ms-MY" | "nb-NO" | "ro-RO" | "el-GR" | "he-IL" | "hi-IN" | "hu-HU" | "sr-BA" | "sk-SK" | "sl-SI" | "sv-SE" | "tl-PH" | "th-TH" | "uk-UA" | "vi-VN";
export type CreateRequestEnabledOriginCommandsItem = "revoke";
export type CreateRequestEnabledOriginCommandsList = Array<CreateRequestEnabledOriginCommandsItem | (string & {})>;
export type CreateRequestQueueingMethod = "fifo" | "random" | "passthrough" | "reject";
export type CreateRequestQueueingStatusCode = 200 | 202 | 429;
export type CreateRequestTurnstileAction = "log" | "infinite_queue";
export type CreateRequestTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
export interface CreateWaitingRoomRequest {
    /** Identifier. */
    zoneId: string;
    /** The host name to which the waiting room will be applied (no wildcards). Please do not include the scheme (http:// or https://). The host and path combination must be unique. */
    host: string;
    /** A unique name to identify the waiting room. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** Sets the number of new users that will be let into the route every minute. This value is used as baseline for the number of users that are let in per minute. So it is possible that there is a little more or little less traffic coming to the route based on the traffic patterns at that time around the world. */
    newUsersPerMinute: number;
    /** Sets the total number of active user sessions on the route at a point in time. A route is a combination of host and path on which a waiting room is available. This value is used as a baseline for the total number of active user sessions on the route. It is possible to have a situation where there are more or less active users sessions on the route based on the traffic patterns at that time around the world. */
    totalActiveUsers: number;
    /** Only available for the Waiting Room Advanced subscription. Additional hostname and path combinations to which this waiting room will be applied. There is an implied wildcard at the end of the path. The hostname and path combination must be unique to this and all other waiting rooms. */
    additionalRoutes?: CreateRequestAdditionalRoutesList;
    /** Configures cookie attributes for the waiting room cookie. This encrypted cookie stores a user's status in the waiting room, such as queue position. */
    cookieAttributes?: CreateRequestCookieAttributes;
    /** Appends a '_' + a custom suffix to the end of Cloudflare Waiting Room's cookie name(__cf_waitingroom). If `cookie_suffix` is "abcd", the cookie name will be `__cf_waitingroom_abcd`. This field is required if using `additional_routes`. */
    cookieSuffix?: string;
    /** Only available for the Waiting Room Advanced subscription. This is a template html file that will be rendered at the edge. If no custom_page_html is provided, the default waiting room will be used. The template is based on mustache ( https://mustache.github.io/ ). There are several variables that are evaluated by the Cloudflare edge: */
    customPageHtml?: string;
    /** The language of the default page template. If no default_template_language is provided, then `en-US` (English) will be used. */
    defaultTemplateLanguage?: CreateRequestDefaultTemplateLanguage | (string & {});
    /** A note that you can use to add more details about the waiting room. */
    description?: string;
    /** Only available for the Waiting Room Advanced subscription. Disables automatic renewal of session cookies. If `true`, an accepted user will have session_duration minutes to browse the site. After that, they will have to go through the waiting room again. If `false`, a user's session cookie will be automatically renewed on every request. */
    disableSessionRenewal?: boolean;
    /** A list of enabled origin commands. */
    enabledOriginCommands?: CreateRequestEnabledOriginCommandsList;
    /** Only available for the Waiting Room Advanced subscription. If `true`, requests to the waiting room with the header `Accept: application/json` will receive a JSON response object with information on the user's status in the waiting room as opposed to the configured static HTML page. This JSON response object has one property `cfWaitingRoom` which is an object containing the following fields: */
    jsonResponseEnabled?: boolean;
    /** Sets the path within the host to enable the waiting room on. The waiting room will be enabled for all subpaths as well. If there are two waiting rooms on the same subpath, the waiting room for the most specific path will be chosen. Wildcards and query parameters are not supported. */
    path?: string;
    /** If queue_all is `true`, all the traffic that is coming to a route will be sent to the waiting room. No new traffic can get to the route once this field is set and estimated time will become unavailable. */
    queueAll?: boolean;
    /** Sets the queueing method used by the waiting room. Changing this parameter from the **default** queueing method is only available for the Waiting Room Advanced subscription. Regardless of the queueing method, if `queue_all` is enabled or an event is prequeueing, users in the waiting room will not be accepted to the origin. These users will always see a waiting room page that refreshes automatically. The valid queueing methods are: */
    queueingMethod?: CreateRequestQueueingMethod | (string & {});
    /** HTTP status code returned to a user while in the queue. */
    queueingStatusCode?: CreateRequestQueueingStatusCode | (number & {});
    /** Lifetime of a cookie (in minutes) set by Cloudflare for users who get access to the route. If a user is not seen by Cloudflare again in that time period, they will be treated as a new user that visits the route. */
    sessionDuration?: number;
    /** Suspends or allows traffic going to the waiting room. If set to `true`, the traffic will not go to the waiting room. */
    suspended?: boolean;
    /** Which action to take when a bot is detected using Turnstile. `log` will have no impact on queueing behavior, simply keeping track of how many bots are detected in Waiting Room Analytics. `infinite_queue` will send bots to a false queueing state, where they will never reach your origin. `infinite_queue` requires Advanced Waiting Room. */
    turnstileAction?: CreateRequestTurnstileAction | (string & {});
    /** Which Turnstile widget type to use for detecting bot traffic. See [the Turnstile documentation](https://developers.cloudflare.com/turnstile/concepts/widget/#widget-types) for the definitions of these widget types. Set to `off` to disable the Turnstile integration entirely. Setting this to anything other than `off` or `invisible` requires Advanced Waiting Room. */
    turnstileMode?: CreateRequestTurnstileMode | (string & {});
}
export interface CreateResponseAdditionalRoutesItem {
    /** The hostname to which this waiting room will be applied (no wildcards). The hostname must be the primary domain, subdomain, or custom hostname (if using SSL for SaaS) of this zone. Please do not include the scheme (http:// or https://). */
    host?: string | null;
    /** Sets the path within the host to enable the waiting room on. The waiting room will be enabled for all subpaths as well. If there are two waiting rooms on the same subpath, the waiting room for the most specific path will be chosen. Wildcards and query parameters are not supported. */
    path?: string | null;
}
export type CreateResponseAdditionalRoutesList = Array<CreateResponseAdditionalRoutesItem>;
export type CreateResponseCookieAttributesSamesite = "auto" | "lax" | "none" | "strict";
export type CreateResponseCookieAttributesSecure = "auto" | "always" | "never";
export interface CreateResponseCookieAttributes {
    /** Configures the SameSite attribute on the waiting room cookie. Value `auto` will be translated to `lax` or `none` depending if **Always Use HTTPS** is enabled. Note that when using value `none`, the secure attribute cannot be set to `never`. */
    samesite?: CreateResponseCookieAttributesSamesite | null;
    /** Configures the Secure attribute on the waiting room cookie. Value `always` indicates that the Secure attribute will be set in the Set-Cookie header, `never` indicates that the Secure attribute will not be set, and `auto` will set the Secure attribute depending if **Always Use HTTPS** is enabled. */
    secure?: CreateResponseCookieAttributesSecure | null;
}
export type CreateResponseDefaultTemplateLanguage = "en-US" | "es-ES" | "de-DE" | "fr-FR" | "it-IT" | "ja-JP" | "ko-KR" | "pt-BR" | "zh-CN" | "zh-TW" | "nl-NL" | "pl-PL" | "id-ID" | "tr-TR" | "ar-EG" | "ru-RU" | "fa-IR" | "bg-BG" | "hr-HR" | "cs-CZ" | "da-DK" | "fi-FI" | "lt-LT" | "lv-LV" | "ms-MY" | "nb-NO" | "ro-RO" | "el-GR" | "he-IL" | "hi-IN" | "hu-HU" | "sr-BA" | "sk-SK" | "sl-SI" | "sv-SE" | "tl-PH" | "th-TH" | "uk-UA" | "vi-VN";
export type CreateResponseEnabledOriginCommandsItem = "revoke";
export type CreateResponseEnabledOriginCommandsList = Array<CreateResponseEnabledOriginCommandsItem>;
export type CreateResponseQueueingMethod = "fifo" | "random" | "passthrough" | "reject";
export type CreateResponseQueueingStatusCode = 200 | 202 | 429;
export type CreateResponseTurnstileAction = "log" | "infinite_queue";
export type CreateResponseTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateWaitingRoomResponse {
    id?: string | null;
    /** Only available for the Waiting Room Advanced subscription. Additional hostname and path combinations to which this waiting room will be applied. There is an implied wildcard at the end of the path. The hostname and path combination must be unique to this and all other waiting rooms. */
    additionalRoutes?: CreateResponseAdditionalRoutesList | null;
    /** Configures cookie attributes for the waiting room cookie. This encrypted cookie stores a user's status in the waiting room, such as queue position. */
    cookieAttributes?: CreateResponseCookieAttributes | null;
    /** Appends a '_' + a custom suffix to the end of Cloudflare Waiting Room's cookie name(__cf_waitingroom). If `cookie_suffix` is "abcd", the cookie name will be `__cf_waitingroom_abcd`. This field is required if using `additional_routes`. */
    cookieSuffix?: string | null;
    createdOn?: string | null;
    /** Only available for the Waiting Room Advanced subscription. This is a template html file that will be rendered at the edge. If no custom_page_html is provided, the default waiting room will be used. The template is based on mustache ( https://mustache.github.io/ ). There are several variables that are evaluated by the Cloudflare edge: */
    customPageHtml?: string | null;
    /** The language of the default page template. If no default_template_language is provided, then `en-US` (English) will be used. */
    defaultTemplateLanguage?: CreateResponseDefaultTemplateLanguage | null;
    /** A note that you can use to add more details about the waiting room. */
    description?: string | null;
    /** Only available for the Waiting Room Advanced subscription. Disables automatic renewal of session cookies. If `true`, an accepted user will have session_duration minutes to browse the site. After that, they will have to go through the waiting room again. If `false`, a user's session cookie will be automatically renewed on every request. */
    disableSessionRenewal?: boolean | null;
    /** A list of enabled origin commands. */
    enabledOriginCommands?: CreateResponseEnabledOriginCommandsList | null;
    /** The host name to which the waiting room will be applied (no wildcards). Please do not include the scheme (http:// or https://). The host and path combination must be unique. */
    host?: string | null;
    /** Only available for the Waiting Room Advanced subscription. If `true`, requests to the waiting room with the header `Accept: application/json` will receive a JSON response object with information on the user's status in the waiting room as opposed to the configured static HTML page. This JSON response object has one property `cfWaitingRoom` which is an object containing the following fields: */
    jsonResponseEnabled?: boolean | null;
    modifiedOn?: string | null;
    /** A unique name to identify the waiting room. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** Sets the number of new users that will be let into the route every minute. This value is used as baseline for the number of users that are let in per minute. So it is possible that there is a little more or little less traffic coming to the route based on the traffic patterns at that time around the world. */
    newUsersPerMinute?: number | null;
    /** An ISO 8601 timestamp that marks when the next event will begin queueing. */
    nextEventPrequeueStartTime?: string | null;
    /** An ISO 8601 timestamp that marks when the next event will start. */
    nextEventStartTime?: string | null;
    /** Sets the path within the host to enable the waiting room on. The waiting room will be enabled for all subpaths as well. If there are two waiting rooms on the same subpath, the waiting room for the most specific path will be chosen. Wildcards and query parameters are not supported. */
    path?: string | null;
    /** If queue_all is `true`, all the traffic that is coming to a route will be sent to the waiting room. No new traffic can get to the route once this field is set and estimated time will become unavailable. */
    queueAll?: boolean | null;
    /** Sets the queueing method used by the waiting room. Changing this parameter from the **default** queueing method is only available for the Waiting Room Advanced subscription. Regardless of the queueing method, if `queue_all` is enabled or an event is prequeueing, users in the waiting room will not be accepted to the origin. These users will always see a waiting room page that refreshes automatically. The valid queueing methods are: */
    queueingMethod?: CreateResponseQueueingMethod | null;
    /** HTTP status code returned to a user while in the queue. */
    queueingStatusCode?: CreateResponseQueueingStatusCode | null;
    /** Lifetime of a cookie (in minutes) set by Cloudflare for users who get access to the route. If a user is not seen by Cloudflare again in that time period, they will be treated as a new user that visits the route. */
    sessionDuration?: number | null;
    /** Suspends or allows traffic going to the waiting room. If set to `true`, the traffic will not go to the waiting room. */
    suspended?: boolean | null;
    /** Sets the total number of active user sessions on the route at a point in time. A route is a combination of host and path on which a waiting room is available. This value is used as a baseline for the total number of active user sessions on the route. It is possible to have a situation where there are more or less active users sessions on the route based on the traffic patterns at that time around the world. */
    totalActiveUsers?: number | null;
    /** Which action to take when a bot is detected using Turnstile. `log` will have no impact on queueing behavior, simply keeping track of how many bots are detected in Waiting Room Analytics. `infinite_queue` will send bots to a false queueing state, where they will never reach your origin. `infinite_queue` requires Advanced Waiting Room. */
    turnstileAction?: CreateResponseTurnstileAction | null;
    /** Which Turnstile widget type to use for detecting bot traffic. See [the Turnstile documentation](https://developers.cloudflare.com/turnstile/concepts/widget/#widget-types) for the definitions of these widget types. Set to `off` to disable the Turnstile integration entirely. Setting this to anything other than `off` or `invisible` requires Advanced Waiting Room. */
    turnstileMode?: CreateResponseTurnstileMode | null;
}
export interface DeleteEventRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    eventId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteEventResponse {
    id?: string | null;
}
export interface DeleteRuleRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    /** The ID of the rule. */
    ruleId: string;
}
export type RulesDeleteResultItemAction = "bypass_waiting_room";
export interface RulesDeleteResultItem {
    /** The ID of the rule. */
    id?: string | null;
    /** The action to take when the expression matches. */
    action?: RulesDeleteResultItemAction | null;
    /** The description of the rule. */
    description?: string | null;
    /** When set to true, the rule is enabled. */
    enabled?: boolean | null;
    /** Criteria defining when there is a match for the current rule. */
    expression?: string | null;
    lastUpdated?: string | null;
    /** The version of the rule. */
    version?: string | null;
}
export type RulesDeleteResultList = Array<RulesDeleteResultItem>;
export interface DeleteRuleResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesDeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface DeleteWaitingRoomRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteWaitingRoomResponse {
    id?: string | null;
}
export interface GetEventRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    eventId: string;
}
export type EventsGetResponseTurnstileAction = "log" | "infinite_queue";
export type EventsGetResponseTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetEventResponse {
    id?: string | null;
    createdOn?: string | null;
    /** If set, the event will override the waiting room's `custom_page_html` property while it is active. If null, the event will inherit it. */
    customPageHtml?: string | null;
    /** A note that you can use to add more details about the event. */
    description?: string | null;
    /** If set, the event will override the waiting room's `disable_session_renewal` property while it is active. If null, the event will inherit it. */
    disableSessionRenewal?: boolean | null;
    /** An ISO 8601 timestamp that marks the end of the event. */
    eventEndTime?: string | null;
    /** An ISO 8601 timestamp that marks the start of the event. At this time, queued users will be processed with the event's configuration. The start time must be at least one minute before `event_end_time`. */
    eventStartTime?: string | null;
    modifiedOn?: string | null;
    /** A unique name to identify the event. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** If set, the event will override the waiting room's `new_users_per_minute` property while it is active. If null, the event will inherit it. This can only be set if the event's `total_active_users` property is also set. */
    newUsersPerMinute?: number | null;
    /** An ISO 8601 timestamp that marks when to begin queueing all users before the event starts. The prequeue must start at least five minutes before `event_start_time`. */
    prequeueStartTime?: string | null;
    /** If set, the event will override the waiting room's `queueing_method` property while it is active. If null, the event will inherit it. */
    queueingMethod?: string | null;
    /** If set, the event will override the waiting room's `session_duration` property while it is active. If null, the event will inherit it. */
    sessionDuration?: number | null;
    /** If enabled, users in the prequeue will be shuffled randomly at the `event_start_time`. Requires that `prequeue_start_time` is not null. This is useful for situations when many users will join the event prequeue at the same time and you want to shuffle them to ensure fairness. Naturally, it makes the most sense to enable this feature when the `queueing_method` during the event respects ordering such as **fifo**, or else the shuffling may be unnecessary. */
    shuffleAtEventStart?: boolean | null;
    /** Suspends or allows an event. If set to `true`, the event is ignored and traffic will be handled based on the waiting room configuration. */
    suspended?: boolean | null;
    /** If set, the event will override the waiting room's `total_active_users` property while it is active. If null, the event will inherit it. This can only be set if the event's `new_users_per_minute` property is also set. */
    totalActiveUsers?: number | null;
    /** If set, the event will override the waiting room's `turnstile_action` property while it is active. If null, the event will inherit it. */
    turnstileAction?: EventsGetResponseTurnstileAction | null;
    /** If set, the event will override the waiting room's `turnstile_mode` property while it is active. If null, the event will inherit it. */
    turnstileMode?: EventsGetResponseTurnstileMode | null;
}
export interface GetEventDetailRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    eventId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetEventDetailResponse {
    id?: string | null;
    createdOn?: string | null;
    customPageHtml?: string | null;
    /** A note that you can use to add more details about the event. */
    description?: string | null;
    disableSessionRenewal?: boolean | null;
    /** An ISO 8601 timestamp that marks the end of the event. */
    eventEndTime?: string | null;
    /** An ISO 8601 timestamp that marks the start of the event. At this time, queued users will be processed with the event's configuration. The start time must be at least one minute before `event_end_time`. */
    eventStartTime?: string | null;
    modifiedOn?: string | null;
    /** A unique name to identify the event. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    newUsersPerMinute?: number | null;
    /** An ISO 8601 timestamp that marks when to begin queueing all users before the event starts. The prequeue must start at least five minutes before `event_start_time`. */
    prequeueStartTime?: string | null;
    queueingMethod?: string | null;
    sessionDuration?: number | null;
    /** If enabled, users in the prequeue will be shuffled randomly at the `event_start_time`. Requires that `prequeue_start_time` is not null. This is useful for situations when many users will join the event prequeue at the same time and you want to shuffle them to ensure fairness. Naturally, it makes the most sense to enable this feature when the `queueing_method` during the event respects ordering such as **fifo**, or else the shuffling may be unnecessary. */
    shuffleAtEventStart?: boolean | null;
    /** Suspends or allows an event. If set to `true`, the event is ignored and traffic will be handled based on the waiting room configuration. */
    suspended?: boolean | null;
    totalActiveUsers?: number | null;
}
export interface GetRuleRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
}
export type RulesGetResultItemAction = "bypass_waiting_room";
export interface RulesGetResultItem {
    /** The ID of the rule. */
    id?: string | null;
    /** The action to take when the expression matches. */
    action?: RulesGetResultItemAction | null;
    /** The description of the rule. */
    description?: string | null;
    /** When set to true, the rule is enabled. */
    enabled?: boolean | null;
    /** Criteria defining when there is a match for the current rule. */
    expression?: string | null;
    lastUpdated?: string | null;
    /** The version of the rule. */
    version?: string | null;
}
export type RulesGetResultList = Array<RulesGetResultItem>;
export interface GetRuleResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetSettingRequest {
    /** Identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingResponse {
    /** Whether to allow verified search engine crawlers to bypass all waiting rooms on this zone. Verified search engine crawlers will not be tracked or counted by the waiting room system, and will not appear in waiting room analytics. */
    searchEngineCrawlerBypass: boolean;
}
export interface GetStatusRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
}
export type StatusesGetResponseStatus = "event_prequeueing" | "not_queueing" | "queueing" | "suspended";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetStatusResponse {
    estimatedQueuedUsers?: number | null;
    estimatedTotalActiveUsers?: number | null;
    eventId?: string | null;
    maxEstimatedTimeMinutes?: number | null;
    status?: StatusesGetResponseStatus | null;
}
export interface GetWaitingRoomRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
}
export type GetResponseAdditionalRoutesItem = CreateResponseAdditionalRoutesItem;
export type GetResponseAdditionalRoutesList = Array<CreateResponseAdditionalRoutesItem>;
export type GetResponseCookieAttributesSamesite = "auto" | "lax" | "none" | "strict";
export type GetResponseCookieAttributesSecure = "auto" | "always" | "never";
export interface GetResponseCookieAttributes {
    /** Configures the SameSite attribute on the waiting room cookie. Value `auto` will be translated to `lax` or `none` depending if **Always Use HTTPS** is enabled. Note that when using value `none`, the secure attribute cannot be set to `never`. */
    samesite?: GetResponseCookieAttributesSamesite | null;
    /** Configures the Secure attribute on the waiting room cookie. Value `always` indicates that the Secure attribute will be set in the Set-Cookie header, `never` indicates that the Secure attribute will not be set, and `auto` will set the Secure attribute depending if **Always Use HTTPS** is enabled. */
    secure?: GetResponseCookieAttributesSecure | null;
}
export type GetResponseDefaultTemplateLanguage = "en-US" | "es-ES" | "de-DE" | "fr-FR" | "it-IT" | "ja-JP" | "ko-KR" | "pt-BR" | "zh-CN" | "zh-TW" | "nl-NL" | "pl-PL" | "id-ID" | "tr-TR" | "ar-EG" | "ru-RU" | "fa-IR" | "bg-BG" | "hr-HR" | "cs-CZ" | "da-DK" | "fi-FI" | "lt-LT" | "lv-LV" | "ms-MY" | "nb-NO" | "ro-RO" | "el-GR" | "he-IL" | "hi-IN" | "hu-HU" | "sr-BA" | "sk-SK" | "sl-SI" | "sv-SE" | "tl-PH" | "th-TH" | "uk-UA" | "vi-VN";
export type GetResponseEnabledOriginCommandsItem = "revoke";
export type GetResponseEnabledOriginCommandsList = Array<GetResponseEnabledOriginCommandsItem>;
export type GetResponseQueueingMethod = "fifo" | "random" | "passthrough" | "reject";
export type GetResponseQueueingStatusCode = 200 | 202 | 429;
export type GetResponseTurnstileAction = "log" | "infinite_queue";
export type GetResponseTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetWaitingRoomResponse {
    id?: string | null;
    /** Only available for the Waiting Room Advanced subscription. Additional hostname and path combinations to which this waiting room will be applied. There is an implied wildcard at the end of the path. The hostname and path combination must be unique to this and all other waiting rooms. */
    additionalRoutes?: GetResponseAdditionalRoutesList | null;
    /** Configures cookie attributes for the waiting room cookie. This encrypted cookie stores a user's status in the waiting room, such as queue position. */
    cookieAttributes?: GetResponseCookieAttributes | null;
    /** Appends a '_' + a custom suffix to the end of Cloudflare Waiting Room's cookie name(__cf_waitingroom). If `cookie_suffix` is "abcd", the cookie name will be `__cf_waitingroom_abcd`. This field is required if using `additional_routes`. */
    cookieSuffix?: string | null;
    createdOn?: string | null;
    /** Only available for the Waiting Room Advanced subscription. This is a template html file that will be rendered at the edge. If no custom_page_html is provided, the default waiting room will be used. The template is based on mustache ( https://mustache.github.io/ ). There are several variables that are evaluated by the Cloudflare edge: */
    customPageHtml?: string | null;
    /** The language of the default page template. If no default_template_language is provided, then `en-US` (English) will be used. */
    defaultTemplateLanguage?: GetResponseDefaultTemplateLanguage | null;
    /** A note that you can use to add more details about the waiting room. */
    description?: string | null;
    /** Only available for the Waiting Room Advanced subscription. Disables automatic renewal of session cookies. If `true`, an accepted user will have session_duration minutes to browse the site. After that, they will have to go through the waiting room again. If `false`, a user's session cookie will be automatically renewed on every request. */
    disableSessionRenewal?: boolean | null;
    /** A list of enabled origin commands. */
    enabledOriginCommands?: GetResponseEnabledOriginCommandsList | null;
    /** The host name to which the waiting room will be applied (no wildcards). Please do not include the scheme (http:// or https://). The host and path combination must be unique. */
    host?: string | null;
    /** Only available for the Waiting Room Advanced subscription. If `true`, requests to the waiting room with the header `Accept: application/json` will receive a JSON response object with information on the user's status in the waiting room as opposed to the configured static HTML page. This JSON response object has one property `cfWaitingRoom` which is an object containing the following fields: */
    jsonResponseEnabled?: boolean | null;
    modifiedOn?: string | null;
    /** A unique name to identify the waiting room. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** Sets the number of new users that will be let into the route every minute. This value is used as baseline for the number of users that are let in per minute. So it is possible that there is a little more or little less traffic coming to the route based on the traffic patterns at that time around the world. */
    newUsersPerMinute?: number | null;
    /** An ISO 8601 timestamp that marks when the next event will begin queueing. */
    nextEventPrequeueStartTime?: string | null;
    /** An ISO 8601 timestamp that marks when the next event will start. */
    nextEventStartTime?: string | null;
    /** Sets the path within the host to enable the waiting room on. The waiting room will be enabled for all subpaths as well. If there are two waiting rooms on the same subpath, the waiting room for the most specific path will be chosen. Wildcards and query parameters are not supported. */
    path?: string | null;
    /** If queue_all is `true`, all the traffic that is coming to a route will be sent to the waiting room. No new traffic can get to the route once this field is set and estimated time will become unavailable. */
    queueAll?: boolean | null;
    /** Sets the queueing method used by the waiting room. Changing this parameter from the **default** queueing method is only available for the Waiting Room Advanced subscription. Regardless of the queueing method, if `queue_all` is enabled or an event is prequeueing, users in the waiting room will not be accepted to the origin. These users will always see a waiting room page that refreshes automatically. The valid queueing methods are: */
    queueingMethod?: GetResponseQueueingMethod | null;
    /** HTTP status code returned to a user while in the queue. */
    queueingStatusCode?: GetResponseQueueingStatusCode | null;
    /** Lifetime of a cookie (in minutes) set by Cloudflare for users who get access to the route. If a user is not seen by Cloudflare again in that time period, they will be treated as a new user that visits the route. */
    sessionDuration?: number | null;
    /** Suspends or allows traffic going to the waiting room. If set to `true`, the traffic will not go to the waiting room. */
    suspended?: boolean | null;
    /** Sets the total number of active user sessions on the route at a point in time. A route is a combination of host and path on which a waiting room is available. This value is used as a baseline for the total number of active user sessions on the route. It is possible to have a situation where there are more or less active users sessions on the route based on the traffic patterns at that time around the world. */
    totalActiveUsers?: number | null;
    /** Which action to take when a bot is detected using Turnstile. `log` will have no impact on queueing behavior, simply keeping track of how many bots are detected in Waiting Room Analytics. `infinite_queue` will send bots to a false queueing state, where they will never reach your origin. `infinite_queue` requires Advanced Waiting Room. */
    turnstileAction?: GetResponseTurnstileAction | null;
    /** Which Turnstile widget type to use for detecting bot traffic. See [the Turnstile documentation](https://developers.cloudflare.com/turnstile/concepts/widget/#widget-types) for the definitions of these widget types. Set to `off` to disable the Turnstile integration entirely. Setting this to anything other than `off` or `invisible` requires Advanced Waiting Room. */
    turnstileMode?: GetResponseTurnstileMode | null;
}
export interface ListEventsRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. Must be a multiple of 5. */
    perPage?: number;
}
export type EventsListResultItemTurnstileAction = "log" | "infinite_queue";
export type EventsListResultItemTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
export interface EventsListResultItem {
    id?: string | null;
    createdOn?: string | null;
    /** If set, the event will override the waiting room's `custom_page_html` property while it is active. If null, the event will inherit it. */
    customPageHtml?: string | null;
    /** A note that you can use to add more details about the event. */
    description?: string | null;
    /** If set, the event will override the waiting room's `disable_session_renewal` property while it is active. If null, the event will inherit it. */
    disableSessionRenewal?: boolean | null;
    /** An ISO 8601 timestamp that marks the end of the event. */
    eventEndTime?: string | null;
    /** An ISO 8601 timestamp that marks the start of the event. At this time, queued users will be processed with the event's configuration. The start time must be at least one minute before `event_end_time`. */
    eventStartTime?: string | null;
    modifiedOn?: string | null;
    /** A unique name to identify the event. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** If set, the event will override the waiting room's `new_users_per_minute` property while it is active. If null, the event will inherit it. This can only be set if the event's `total_active_users` property is also set. */
    newUsersPerMinute?: number | null;
    /** An ISO 8601 timestamp that marks when to begin queueing all users before the event starts. The prequeue must start at least five minutes before `event_start_time`. */
    prequeueStartTime?: string | null;
    /** If set, the event will override the waiting room's `queueing_method` property while it is active. If null, the event will inherit it. */
    queueingMethod?: string | null;
    /** If set, the event will override the waiting room's `session_duration` property while it is active. If null, the event will inherit it. */
    sessionDuration?: number | null;
    /** If enabled, users in the prequeue will be shuffled randomly at the `event_start_time`. Requires that `prequeue_start_time` is not null. This is useful for situations when many users will join the event prequeue at the same time and you want to shuffle them to ensure fairness. Naturally, it makes the most sense to enable this feature when the `queueing_method` during the event respects ordering such as **fifo**, or else the shuffling may be unnecessary. */
    shuffleAtEventStart?: boolean | null;
    /** Suspends or allows an event. If set to `true`, the event is ignored and traffic will be handled based on the waiting room configuration. */
    suspended?: boolean | null;
    /** If set, the event will override the waiting room's `total_active_users` property while it is active. If null, the event will inherit it. This can only be set if the event's `new_users_per_minute` property is also set. */
    totalActiveUsers?: number | null;
    /** If set, the event will override the waiting room's `turnstile_action` property while it is active. If null, the event will inherit it. */
    turnstileAction?: EventsListResultItemTurnstileAction | null;
    /** If set, the event will override the waiting room's `turnstile_mode` property while it is active. If null, the event will inherit it. */
    turnstileMode?: EventsListResultItemTurnstileMode | null;
}
export type EventsListResultList = Array<EventsListResultItem>;
export interface ListEventsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: EventsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListWaitingRoomsForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. Must be a multiple of 5. */
    perPage?: number;
}
export type ListResultItemAdditionalRoutesItem = CreateResponseAdditionalRoutesItem;
export type ListResultItemAdditionalRoutesList = Array<CreateResponseAdditionalRoutesItem>;
export type ListResultItemCookieAttributesSamesite = "auto" | "lax" | "none" | "strict";
export type ListResultItemCookieAttributesSecure = "auto" | "always" | "never";
export interface ListResultItemCookieAttributes {
    /** Configures the SameSite attribute on the waiting room cookie. Value `auto` will be translated to `lax` or `none` depending if **Always Use HTTPS** is enabled. Note that when using value `none`, the secure attribute cannot be set to `never`. */
    samesite?: ListResultItemCookieAttributesSamesite | null;
    /** Configures the Secure attribute on the waiting room cookie. Value `always` indicates that the Secure attribute will be set in the Set-Cookie header, `never` indicates that the Secure attribute will not be set, and `auto` will set the Secure attribute depending if **Always Use HTTPS** is enabled. */
    secure?: ListResultItemCookieAttributesSecure | null;
}
export type ListResultItemDefaultTemplateLanguage = "en-US" | "es-ES" | "de-DE" | "fr-FR" | "it-IT" | "ja-JP" | "ko-KR" | "pt-BR" | "zh-CN" | "zh-TW" | "nl-NL" | "pl-PL" | "id-ID" | "tr-TR" | "ar-EG" | "ru-RU" | "fa-IR" | "bg-BG" | "hr-HR" | "cs-CZ" | "da-DK" | "fi-FI" | "lt-LT" | "lv-LV" | "ms-MY" | "nb-NO" | "ro-RO" | "el-GR" | "he-IL" | "hi-IN" | "hu-HU" | "sr-BA" | "sk-SK" | "sl-SI" | "sv-SE" | "tl-PH" | "th-TH" | "uk-UA" | "vi-VN";
export type ListResultItemEnabledOriginCommandsItem = "revoke";
export type ListResultItemEnabledOriginCommandsList = Array<ListResultItemEnabledOriginCommandsItem>;
export type ListResultItemQueueingMethod = "fifo" | "random" | "passthrough" | "reject";
export type ListResultItemQueueingStatusCode = 200 | 202 | 429;
export type ListResultItemTurnstileAction = "log" | "infinite_queue";
export type ListResultItemTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
export interface ListResultItem {
    id?: string | null;
    /** Only available for the Waiting Room Advanced subscription. Additional hostname and path combinations to which this waiting room will be applied. There is an implied wildcard at the end of the path. The hostname and path combination must be unique to this and all other waiting rooms. */
    additionalRoutes?: ListResultItemAdditionalRoutesList | null;
    /** Configures cookie attributes for the waiting room cookie. This encrypted cookie stores a user's status in the waiting room, such as queue position. */
    cookieAttributes?: ListResultItemCookieAttributes | null;
    /** Appends a '_' + a custom suffix to the end of Cloudflare Waiting Room's cookie name(__cf_waitingroom). If `cookie_suffix` is "abcd", the cookie name will be `__cf_waitingroom_abcd`. This field is required if using `additional_routes`. */
    cookieSuffix?: string | null;
    createdOn?: string | null;
    /** Only available for the Waiting Room Advanced subscription. This is a template html file that will be rendered at the edge. If no custom_page_html is provided, the default waiting room will be used. The template is based on mustache ( https://mustache.github.io/ ). There are several variables that are evaluated by the Cloudflare edge: */
    customPageHtml?: string | null;
    /** The language of the default page template. If no default_template_language is provided, then `en-US` (English) will be used. */
    defaultTemplateLanguage?: ListResultItemDefaultTemplateLanguage | null;
    /** A note that you can use to add more details about the waiting room. */
    description?: string | null;
    /** Only available for the Waiting Room Advanced subscription. Disables automatic renewal of session cookies. If `true`, an accepted user will have session_duration minutes to browse the site. After that, they will have to go through the waiting room again. If `false`, a user's session cookie will be automatically renewed on every request. */
    disableSessionRenewal?: boolean | null;
    /** A list of enabled origin commands. */
    enabledOriginCommands?: ListResultItemEnabledOriginCommandsList | null;
    /** The host name to which the waiting room will be applied (no wildcards). Please do not include the scheme (http:// or https://). The host and path combination must be unique. */
    host?: string | null;
    /** Only available for the Waiting Room Advanced subscription. If `true`, requests to the waiting room with the header `Accept: application/json` will receive a JSON response object with information on the user's status in the waiting room as opposed to the configured static HTML page. This JSON response object has one property `cfWaitingRoom` which is an object containing the following fields: */
    jsonResponseEnabled?: boolean | null;
    modifiedOn?: string | null;
    /** A unique name to identify the waiting room. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** Sets the number of new users that will be let into the route every minute. This value is used as baseline for the number of users that are let in per minute. So it is possible that there is a little more or little less traffic coming to the route based on the traffic patterns at that time around the world. */
    newUsersPerMinute?: number | null;
    /** An ISO 8601 timestamp that marks when the next event will begin queueing. */
    nextEventPrequeueStartTime?: string | null;
    /** An ISO 8601 timestamp that marks when the next event will start. */
    nextEventStartTime?: string | null;
    /** Sets the path within the host to enable the waiting room on. The waiting room will be enabled for all subpaths as well. If there are two waiting rooms on the same subpath, the waiting room for the most specific path will be chosen. Wildcards and query parameters are not supported. */
    path?: string | null;
    /** If queue_all is `true`, all the traffic that is coming to a route will be sent to the waiting room. No new traffic can get to the route once this field is set and estimated time will become unavailable. */
    queueAll?: boolean | null;
    /** Sets the queueing method used by the waiting room. Changing this parameter from the **default** queueing method is only available for the Waiting Room Advanced subscription. Regardless of the queueing method, if `queue_all` is enabled or an event is prequeueing, users in the waiting room will not be accepted to the origin. These users will always see a waiting room page that refreshes automatically. The valid queueing methods are: */
    queueingMethod?: ListResultItemQueueingMethod | null;
    /** HTTP status code returned to a user while in the queue. */
    queueingStatusCode?: ListResultItemQueueingStatusCode | null;
    /** Lifetime of a cookie (in minutes) set by Cloudflare for users who get access to the route. If a user is not seen by Cloudflare again in that time period, they will be treated as a new user that visits the route. */
    sessionDuration?: number | null;
    /** Suspends or allows traffic going to the waiting room. If set to `true`, the traffic will not go to the waiting room. */
    suspended?: boolean | null;
    /** Sets the total number of active user sessions on the route at a point in time. A route is a combination of host and path on which a waiting room is available. This value is used as a baseline for the total number of active user sessions on the route. It is possible to have a situation where there are more or less active users sessions on the route based on the traffic patterns at that time around the world. */
    totalActiveUsers?: number | null;
    /** Which action to take when a bot is detected using Turnstile. `log` will have no impact on queueing behavior, simply keeping track of how many bots are detected in Waiting Room Analytics. `infinite_queue` will send bots to a false queueing state, where they will never reach your origin. `infinite_queue` requires Advanced Waiting Room. */
    turnstileAction?: ListResultItemTurnstileAction | null;
    /** Which Turnstile widget type to use for detecting bot traffic. See [the Turnstile documentation](https://developers.cloudflare.com/turnstile/concepts/widget/#widget-types) for the definitions of these widget types. Set to `off` to disable the Turnstile integration entirely. Setting this to anything other than `off` or `invisible` requires Advanced Waiting Room. */
    turnstileMode?: ListResultItemTurnstileMode | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListWaitingRoomsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListWaitingRoomsForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. Must be a multiple of 5. */
    perPage?: number;
}
export type EventsEditRequestTurnstileAction = "log" | "infinite_queue";
export type EventsEditRequestTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
export interface PatchEventRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    eventId: string;
    /** An ISO 8601 timestamp that marks the end of the event. */
    eventEndTime: string;
    /** An ISO 8601 timestamp that marks the start of the event. At this time, queued users will be processed with the event's configuration. The start time must be at least one minute before `event_end_time`. */
    eventStartTime: string;
    /** A unique name to identify the event. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** If set, the event will override the waiting room's `custom_page_html` property while it is active. If null, the event will inherit it. */
    customPageHtml?: string;
    /** A note that you can use to add more details about the event. */
    description?: string;
    /** If set, the event will override the waiting room's `disable_session_renewal` property while it is active. If null, the event will inherit it. */
    disableSessionRenewal?: boolean;
    /** If set, the event will override the waiting room's `new_users_per_minute` property while it is active. If null, the event will inherit it. This can only be set if the event's `total_active_users` property is also set. */
    newUsersPerMinute?: number;
    /** An ISO 8601 timestamp that marks when to begin queueing all users before the event starts. The prequeue must start at least five minutes before `event_start_time`. */
    prequeueStartTime?: string;
    /** If set, the event will override the waiting room's `queueing_method` property while it is active. If null, the event will inherit it. */
    queueingMethod?: string;
    /** If set, the event will override the waiting room's `session_duration` property while it is active. If null, the event will inherit it. */
    sessionDuration?: number;
    /** If enabled, users in the prequeue will be shuffled randomly at the `event_start_time`. Requires that `prequeue_start_time` is not null. This is useful for situations when many users will join the event prequeue at the same time and you want to shuffle them to ensure fairness. Naturally, it makes the most sense to enable this feature when the `queueing_method` during the event respects ordering such as **fifo**, or else the shuffling may be unnecessary. */
    shuffleAtEventStart?: boolean;
    /** Suspends or allows an event. If set to `true`, the event is ignored and traffic will be handled based on the waiting room configuration. */
    suspended?: boolean;
    /** If set, the event will override the waiting room's `total_active_users` property while it is active. If null, the event will inherit it. This can only be set if the event's `new_users_per_minute` property is also set. */
    totalActiveUsers?: number;
    /** If set, the event will override the waiting room's `turnstile_action` property while it is active. If null, the event will inherit it. */
    turnstileAction?: EventsEditRequestTurnstileAction | (string & {});
    /** If set, the event will override the waiting room's `turnstile_mode` property while it is active. If null, the event will inherit it. */
    turnstileMode?: EventsEditRequestTurnstileMode | (string & {});
}
export type EventsEditResponseTurnstileAction = "log" | "infinite_queue";
export type EventsEditResponseTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchEventResponse {
    id?: string | null;
    createdOn?: string | null;
    /** If set, the event will override the waiting room's `custom_page_html` property while it is active. If null, the event will inherit it. */
    customPageHtml?: string | null;
    /** A note that you can use to add more details about the event. */
    description?: string | null;
    /** If set, the event will override the waiting room's `disable_session_renewal` property while it is active. If null, the event will inherit it. */
    disableSessionRenewal?: boolean | null;
    /** An ISO 8601 timestamp that marks the end of the event. */
    eventEndTime?: string | null;
    /** An ISO 8601 timestamp that marks the start of the event. At this time, queued users will be processed with the event's configuration. The start time must be at least one minute before `event_end_time`. */
    eventStartTime?: string | null;
    modifiedOn?: string | null;
    /** A unique name to identify the event. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** If set, the event will override the waiting room's `new_users_per_minute` property while it is active. If null, the event will inherit it. This can only be set if the event's `total_active_users` property is also set. */
    newUsersPerMinute?: number | null;
    /** An ISO 8601 timestamp that marks when to begin queueing all users before the event starts. The prequeue must start at least five minutes before `event_start_time`. */
    prequeueStartTime?: string | null;
    /** If set, the event will override the waiting room's `queueing_method` property while it is active. If null, the event will inherit it. */
    queueingMethod?: string | null;
    /** If set, the event will override the waiting room's `session_duration` property while it is active. If null, the event will inherit it. */
    sessionDuration?: number | null;
    /** If enabled, users in the prequeue will be shuffled randomly at the `event_start_time`. Requires that `prequeue_start_time` is not null. This is useful for situations when many users will join the event prequeue at the same time and you want to shuffle them to ensure fairness. Naturally, it makes the most sense to enable this feature when the `queueing_method` during the event respects ordering such as **fifo**, or else the shuffling may be unnecessary. */
    shuffleAtEventStart?: boolean | null;
    /** Suspends or allows an event. If set to `true`, the event is ignored and traffic will be handled based on the waiting room configuration. */
    suspended?: boolean | null;
    /** If set, the event will override the waiting room's `total_active_users` property while it is active. If null, the event will inherit it. This can only be set if the event's `new_users_per_minute` property is also set. */
    totalActiveUsers?: number | null;
    /** If set, the event will override the waiting room's `turnstile_action` property while it is active. If null, the event will inherit it. */
    turnstileAction?: EventsEditResponseTurnstileAction | null;
    /** If set, the event will override the waiting room's `turnstile_mode` property while it is active. If null, the event will inherit it. */
    turnstileMode?: EventsEditResponseTurnstileMode | null;
}
export type RulesEditRequestAction = "bypass_waiting_room";
export interface RulesEditRequestPositionIndex {
    /** Places the rule in the exact position specified by the integer number &lt;POSITION_NUMBER&gt;. Position numbers start with 1. Existing rules in the ruleset from the specified position number onward are shifted one position (no rule is overwritten). */
    index?: number;
}
export interface RulesEditRequestPositionBefore {
    /** Places the rule before rule &lt;RULE_ID&gt;. Use this argument with an empty rule ID value ("") to set the rule as the first rule in the ruleset. */
    before?: string;
}
export interface RulesEditRequestPositionAfter {
    /** Places the rule after rule &lt;RULE_ID&gt;. Use this argument with an empty rule ID value ("") to set the rule as the last rule in the ruleset. */
    after?: string;
}
export type RulesEditRequestPosition = RulesEditRequestPositionIndex | RulesEditRequestPositionBefore | RulesEditRequestPositionAfter;
export interface PatchRuleRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    /** The ID of the rule. */
    ruleId: string;
    /** The action to take when the expression matches. */
    action: RulesEditRequestAction | (string & {});
    /** Criteria defining when there is a match for the current rule. */
    expression: string;
    /** The description of the rule. */
    description?: string;
    /** When set to true, the rule is enabled. */
    enabled?: boolean;
    /** Reorder the position of a rule */
    position?: RulesEditRequestPosition;
}
export type RulesEditResultItemAction = "bypass_waiting_room";
export interface RulesEditResultItem {
    /** The ID of the rule. */
    id?: string | null;
    /** The action to take when the expression matches. */
    action?: RulesEditResultItemAction | null;
    /** The description of the rule. */
    description?: string | null;
    /** When set to true, the rule is enabled. */
    enabled?: boolean | null;
    /** Criteria defining when there is a match for the current rule. */
    expression?: string | null;
    lastUpdated?: string | null;
    /** The version of the rule. */
    version?: string | null;
}
export type RulesEditResultList = Array<RulesEditResultItem>;
export interface PatchRuleResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesEditResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface PatchSettingRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether to allow verified search engine crawlers to bypass all waiting rooms on this zone. Verified search engine crawlers will not be tracked or counted by the waiting room system, and will not appear in waiting room analytics. */
    searchEngineCrawlerBypass?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingResponse {
    /** Whether to allow verified search engine crawlers to bypass all waiting rooms on this zone. Verified search engine crawlers will not be tracked or counted by the waiting room system, and will not appear in waiting room analytics. */
    searchEngineCrawlerBypass: boolean;
}
export type EditRequestAdditionalRoutesItem = CreateRequestAdditionalRoutesItem;
export type EditRequestAdditionalRoutesList = Array<CreateRequestAdditionalRoutesItem>;
export type EditRequestCookieAttributesSamesite = "auto" | "lax" | "none" | "strict";
export type EditRequestCookieAttributesSecure = "auto" | "always" | "never";
export interface EditRequestCookieAttributes {
    /** Configures the SameSite attribute on the waiting room cookie. Value `auto` will be translated to `lax` or `none` depending if **Always Use HTTPS** is enabled. Note that when using value `none`, the secure attribute cannot be set to `never`. */
    samesite?: EditRequestCookieAttributesSamesite | (string & {});
    /** Configures the Secure attribute on the waiting room cookie. Value `always` indicates that the Secure attribute will be set in the Set-Cookie header, `never` indicates that the Secure attribute will not be set, and `auto` will set the Secure attribute depending if **Always Use HTTPS** is enabled. */
    secure?: EditRequestCookieAttributesSecure | (string & {});
}
export type EditRequestDefaultTemplateLanguage = "en-US" | "es-ES" | "de-DE" | "fr-FR" | "it-IT" | "ja-JP" | "ko-KR" | "pt-BR" | "zh-CN" | "zh-TW" | "nl-NL" | "pl-PL" | "id-ID" | "tr-TR" | "ar-EG" | "ru-RU" | "fa-IR" | "bg-BG" | "hr-HR" | "cs-CZ" | "da-DK" | "fi-FI" | "lt-LT" | "lv-LV" | "ms-MY" | "nb-NO" | "ro-RO" | "el-GR" | "he-IL" | "hi-IN" | "hu-HU" | "sr-BA" | "sk-SK" | "sl-SI" | "sv-SE" | "tl-PH" | "th-TH" | "uk-UA" | "vi-VN";
export type EditRequestEnabledOriginCommandsItem = "revoke";
export type EditRequestEnabledOriginCommandsList = Array<EditRequestEnabledOriginCommandsItem | (string & {})>;
export type EditRequestQueueingMethod = "fifo" | "random" | "passthrough" | "reject";
export type EditRequestQueueingStatusCode = 200 | 202 | 429;
export type EditRequestTurnstileAction = "log" | "infinite_queue";
export type EditRequestTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
export interface PatchWaitingRoomRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    /** The host name to which the waiting room will be applied (no wildcards). Please do not include the scheme (http:// or https://). The host and path combination must be unique. */
    host: string;
    /** A unique name to identify the waiting room. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** Sets the number of new users that will be let into the route every minute. This value is used as baseline for the number of users that are let in per minute. So it is possible that there is a little more or little less traffic coming to the route based on the traffic patterns at that time around the world. */
    newUsersPerMinute: number;
    /** Sets the total number of active user sessions on the route at a point in time. A route is a combination of host and path on which a waiting room is available. This value is used as a baseline for the total number of active user sessions on the route. It is possible to have a situation where there are more or less active users sessions on the route based on the traffic patterns at that time around the world. */
    totalActiveUsers: number;
    /** Only available for the Waiting Room Advanced subscription. Additional hostname and path combinations to which this waiting room will be applied. There is an implied wildcard at the end of the path. The hostname and path combination must be unique to this and all other waiting rooms. */
    additionalRoutes?: EditRequestAdditionalRoutesList;
    /** Configures cookie attributes for the waiting room cookie. This encrypted cookie stores a user's status in the waiting room, such as queue position. */
    cookieAttributes?: EditRequestCookieAttributes;
    /** Appends a '_' + a custom suffix to the end of Cloudflare Waiting Room's cookie name(__cf_waitingroom). If `cookie_suffix` is "abcd", the cookie name will be `__cf_waitingroom_abcd`. This field is required if using `additional_routes`. */
    cookieSuffix?: string;
    /** Only available for the Waiting Room Advanced subscription. This is a template html file that will be rendered at the edge. If no custom_page_html is provided, the default waiting room will be used. The template is based on mustache ( https://mustache.github.io/ ). There are several variables that are evaluated by the Cloudflare edge: */
    customPageHtml?: string;
    /** The language of the default page template. If no default_template_language is provided, then `en-US` (English) will be used. */
    defaultTemplateLanguage?: EditRequestDefaultTemplateLanguage | (string & {});
    /** A note that you can use to add more details about the waiting room. */
    description?: string;
    /** Only available for the Waiting Room Advanced subscription. Disables automatic renewal of session cookies. If `true`, an accepted user will have session_duration minutes to browse the site. After that, they will have to go through the waiting room again. If `false`, a user's session cookie will be automatically renewed on every request. */
    disableSessionRenewal?: boolean;
    /** A list of enabled origin commands. */
    enabledOriginCommands?: EditRequestEnabledOriginCommandsList;
    /** Only available for the Waiting Room Advanced subscription. If `true`, requests to the waiting room with the header `Accept: application/json` will receive a JSON response object with information on the user's status in the waiting room as opposed to the configured static HTML page. This JSON response object has one property `cfWaitingRoom` which is an object containing the following fields: */
    jsonResponseEnabled?: boolean;
    /** Sets the path within the host to enable the waiting room on. The waiting room will be enabled for all subpaths as well. If there are two waiting rooms on the same subpath, the waiting room for the most specific path will be chosen. Wildcards and query parameters are not supported. */
    path?: string;
    /** If queue_all is `true`, all the traffic that is coming to a route will be sent to the waiting room. No new traffic can get to the route once this field is set and estimated time will become unavailable. */
    queueAll?: boolean;
    /** Sets the queueing method used by the waiting room. Changing this parameter from the **default** queueing method is only available for the Waiting Room Advanced subscription. Regardless of the queueing method, if `queue_all` is enabled or an event is prequeueing, users in the waiting room will not be accepted to the origin. These users will always see a waiting room page that refreshes automatically. The valid queueing methods are: */
    queueingMethod?: EditRequestQueueingMethod | (string & {});
    /** HTTP status code returned to a user while in the queue. */
    queueingStatusCode?: EditRequestQueueingStatusCode | (number & {});
    /** Lifetime of a cookie (in minutes) set by Cloudflare for users who get access to the route. If a user is not seen by Cloudflare again in that time period, they will be treated as a new user that visits the route. */
    sessionDuration?: number;
    /** Suspends or allows traffic going to the waiting room. If set to `true`, the traffic will not go to the waiting room. */
    suspended?: boolean;
    /** Which action to take when a bot is detected using Turnstile. `log` will have no impact on queueing behavior, simply keeping track of how many bots are detected in Waiting Room Analytics. `infinite_queue` will send bots to a false queueing state, where they will never reach your origin. `infinite_queue` requires Advanced Waiting Room. */
    turnstileAction?: EditRequestTurnstileAction | (string & {});
    /** Which Turnstile widget type to use for detecting bot traffic. See [the Turnstile documentation](https://developers.cloudflare.com/turnstile/concepts/widget/#widget-types) for the definitions of these widget types. Set to `off` to disable the Turnstile integration entirely. Setting this to anything other than `off` or `invisible` requires Advanced Waiting Room. */
    turnstileMode?: EditRequestTurnstileMode | (string & {});
}
export type EditResponseAdditionalRoutesItem = CreateResponseAdditionalRoutesItem;
export type EditResponseAdditionalRoutesList = Array<CreateResponseAdditionalRoutesItem>;
export type EditResponseCookieAttributesSamesite = "auto" | "lax" | "none" | "strict";
export type EditResponseCookieAttributesSecure = "auto" | "always" | "never";
export interface EditResponseCookieAttributes {
    /** Configures the SameSite attribute on the waiting room cookie. Value `auto` will be translated to `lax` or `none` depending if **Always Use HTTPS** is enabled. Note that when using value `none`, the secure attribute cannot be set to `never`. */
    samesite?: EditResponseCookieAttributesSamesite | null;
    /** Configures the Secure attribute on the waiting room cookie. Value `always` indicates that the Secure attribute will be set in the Set-Cookie header, `never` indicates that the Secure attribute will not be set, and `auto` will set the Secure attribute depending if **Always Use HTTPS** is enabled. */
    secure?: EditResponseCookieAttributesSecure | null;
}
export type EditResponseDefaultTemplateLanguage = "en-US" | "es-ES" | "de-DE" | "fr-FR" | "it-IT" | "ja-JP" | "ko-KR" | "pt-BR" | "zh-CN" | "zh-TW" | "nl-NL" | "pl-PL" | "id-ID" | "tr-TR" | "ar-EG" | "ru-RU" | "fa-IR" | "bg-BG" | "hr-HR" | "cs-CZ" | "da-DK" | "fi-FI" | "lt-LT" | "lv-LV" | "ms-MY" | "nb-NO" | "ro-RO" | "el-GR" | "he-IL" | "hi-IN" | "hu-HU" | "sr-BA" | "sk-SK" | "sl-SI" | "sv-SE" | "tl-PH" | "th-TH" | "uk-UA" | "vi-VN";
export type EditResponseEnabledOriginCommandsItem = "revoke";
export type EditResponseEnabledOriginCommandsList = Array<EditResponseEnabledOriginCommandsItem>;
export type EditResponseQueueingMethod = "fifo" | "random" | "passthrough" | "reject";
export type EditResponseQueueingStatusCode = 200 | 202 | 429;
export type EditResponseTurnstileAction = "log" | "infinite_queue";
export type EditResponseTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchWaitingRoomResponse {
    id?: string | null;
    /** Only available for the Waiting Room Advanced subscription. Additional hostname and path combinations to which this waiting room will be applied. There is an implied wildcard at the end of the path. The hostname and path combination must be unique to this and all other waiting rooms. */
    additionalRoutes?: EditResponseAdditionalRoutesList | null;
    /** Configures cookie attributes for the waiting room cookie. This encrypted cookie stores a user's status in the waiting room, such as queue position. */
    cookieAttributes?: EditResponseCookieAttributes | null;
    /** Appends a '_' + a custom suffix to the end of Cloudflare Waiting Room's cookie name(__cf_waitingroom). If `cookie_suffix` is "abcd", the cookie name will be `__cf_waitingroom_abcd`. This field is required if using `additional_routes`. */
    cookieSuffix?: string | null;
    createdOn?: string | null;
    /** Only available for the Waiting Room Advanced subscription. This is a template html file that will be rendered at the edge. If no custom_page_html is provided, the default waiting room will be used. The template is based on mustache ( https://mustache.github.io/ ). There are several variables that are evaluated by the Cloudflare edge: */
    customPageHtml?: string | null;
    /** The language of the default page template. If no default_template_language is provided, then `en-US` (English) will be used. */
    defaultTemplateLanguage?: EditResponseDefaultTemplateLanguage | null;
    /** A note that you can use to add more details about the waiting room. */
    description?: string | null;
    /** Only available for the Waiting Room Advanced subscription. Disables automatic renewal of session cookies. If `true`, an accepted user will have session_duration minutes to browse the site. After that, they will have to go through the waiting room again. If `false`, a user's session cookie will be automatically renewed on every request. */
    disableSessionRenewal?: boolean | null;
    /** A list of enabled origin commands. */
    enabledOriginCommands?: EditResponseEnabledOriginCommandsList | null;
    /** The host name to which the waiting room will be applied (no wildcards). Please do not include the scheme (http:// or https://). The host and path combination must be unique. */
    host?: string | null;
    /** Only available for the Waiting Room Advanced subscription. If `true`, requests to the waiting room with the header `Accept: application/json` will receive a JSON response object with information on the user's status in the waiting room as opposed to the configured static HTML page. This JSON response object has one property `cfWaitingRoom` which is an object containing the following fields: */
    jsonResponseEnabled?: boolean | null;
    modifiedOn?: string | null;
    /** A unique name to identify the waiting room. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** Sets the number of new users that will be let into the route every minute. This value is used as baseline for the number of users that are let in per minute. So it is possible that there is a little more or little less traffic coming to the route based on the traffic patterns at that time around the world. */
    newUsersPerMinute?: number | null;
    /** An ISO 8601 timestamp that marks when the next event will begin queueing. */
    nextEventPrequeueStartTime?: string | null;
    /** An ISO 8601 timestamp that marks when the next event will start. */
    nextEventStartTime?: string | null;
    /** Sets the path within the host to enable the waiting room on. The waiting room will be enabled for all subpaths as well. If there are two waiting rooms on the same subpath, the waiting room for the most specific path will be chosen. Wildcards and query parameters are not supported. */
    path?: string | null;
    /** If queue_all is `true`, all the traffic that is coming to a route will be sent to the waiting room. No new traffic can get to the route once this field is set and estimated time will become unavailable. */
    queueAll?: boolean | null;
    /** Sets the queueing method used by the waiting room. Changing this parameter from the **default** queueing method is only available for the Waiting Room Advanced subscription. Regardless of the queueing method, if `queue_all` is enabled or an event is prequeueing, users in the waiting room will not be accepted to the origin. These users will always see a waiting room page that refreshes automatically. The valid queueing methods are: */
    queueingMethod?: EditResponseQueueingMethod | null;
    /** HTTP status code returned to a user while in the queue. */
    queueingStatusCode?: EditResponseQueueingStatusCode | null;
    /** Lifetime of a cookie (in minutes) set by Cloudflare for users who get access to the route. If a user is not seen by Cloudflare again in that time period, they will be treated as a new user that visits the route. */
    sessionDuration?: number | null;
    /** Suspends or allows traffic going to the waiting room. If set to `true`, the traffic will not go to the waiting room. */
    suspended?: boolean | null;
    /** Sets the total number of active user sessions on the route at a point in time. A route is a combination of host and path on which a waiting room is available. This value is used as a baseline for the total number of active user sessions on the route. It is possible to have a situation where there are more or less active users sessions on the route based on the traffic patterns at that time around the world. */
    totalActiveUsers?: number | null;
    /** Which action to take when a bot is detected using Turnstile. `log` will have no impact on queueing behavior, simply keeping track of how many bots are detected in Waiting Room Analytics. `infinite_queue` will send bots to a false queueing state, where they will never reach your origin. `infinite_queue` requires Advanced Waiting Room. */
    turnstileAction?: EditResponseTurnstileAction | null;
    /** Which Turnstile widget type to use for detecting bot traffic. See [the Turnstile documentation](https://developers.cloudflare.com/turnstile/concepts/widget/#widget-types) for the definitions of these widget types. Set to `off` to disable the Turnstile integration entirely. Setting this to anything other than `off` or `invisible` requires Advanced Waiting Room. */
    turnstileMode?: EditResponseTurnstileMode | null;
}
export interface PreviewPageRequest {
    /** Identifier. */
    zoneId: string;
    /** Only available for the Waiting Room Advanced subscription. This is a template html file that will be rendered at the edge. If no custom_page_html is provided, the default waiting room will be used. The template is based on mustache ( https://mustache.github.io/ ). There are several variables that are evaluated by the Cloudflare edge: */
    customHtml: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PreviewPageResponse {
    /** URL where the custom waiting room page can temporarily be previewed. */
    previewUrl?: string | null;
}
export interface PutSettingRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether to allow verified search engine crawlers to bypass all waiting rooms on this zone. Verified search engine crawlers will not be tracked or counted by the waiting room system, and will not appear in waiting room analytics. */
    searchEngineCrawlerBypass?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSettingResponse {
    /** Whether to allow verified search engine crawlers to bypass all waiting rooms on this zone. Verified search engine crawlers will not be tracked or counted by the waiting room system, and will not appear in waiting room analytics. */
    searchEngineCrawlerBypass: boolean;
}
export type EventsUpdateRequestTurnstileAction = "log" | "infinite_queue";
export type EventsUpdateRequestTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
export interface UpdateEventRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    eventId: string;
    /** An ISO 8601 timestamp that marks the end of the event. */
    eventEndTime: string;
    /** An ISO 8601 timestamp that marks the start of the event. At this time, queued users will be processed with the event's configuration. The start time must be at least one minute before `event_end_time`. */
    eventStartTime: string;
    /** A unique name to identify the event. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** If set, the event will override the waiting room's `custom_page_html` property while it is active. If null, the event will inherit it. */
    customPageHtml?: string;
    /** A note that you can use to add more details about the event. */
    description?: string;
    /** If set, the event will override the waiting room's `disable_session_renewal` property while it is active. If null, the event will inherit it. */
    disableSessionRenewal?: boolean;
    /** If set, the event will override the waiting room's `new_users_per_minute` property while it is active. If null, the event will inherit it. This can only be set if the event's `total_active_users` property is also set. */
    newUsersPerMinute?: number;
    /** An ISO 8601 timestamp that marks when to begin queueing all users before the event starts. The prequeue must start at least five minutes before `event_start_time`. */
    prequeueStartTime?: string;
    /** If set, the event will override the waiting room's `queueing_method` property while it is active. If null, the event will inherit it. */
    queueingMethod?: string;
    /** If set, the event will override the waiting room's `session_duration` property while it is active. If null, the event will inherit it. */
    sessionDuration?: number;
    /** If enabled, users in the prequeue will be shuffled randomly at the `event_start_time`. Requires that `prequeue_start_time` is not null. This is useful for situations when many users will join the event prequeue at the same time and you want to shuffle them to ensure fairness. Naturally, it makes the most sense to enable this feature when the `queueing_method` during the event respects ordering such as **fifo**, or else the shuffling may be unnecessary. */
    shuffleAtEventStart?: boolean;
    /** Suspends or allows an event. If set to `true`, the event is ignored and traffic will be handled based on the waiting room configuration. */
    suspended?: boolean;
    /** If set, the event will override the waiting room's `total_active_users` property while it is active. If null, the event will inherit it. This can only be set if the event's `new_users_per_minute` property is also set. */
    totalActiveUsers?: number;
    /** If set, the event will override the waiting room's `turnstile_action` property while it is active. If null, the event will inherit it. */
    turnstileAction?: EventsUpdateRequestTurnstileAction | (string & {});
    /** If set, the event will override the waiting room's `turnstile_mode` property while it is active. If null, the event will inherit it. */
    turnstileMode?: EventsUpdateRequestTurnstileMode | (string & {});
}
export type EventsUpdateResponseTurnstileAction = "log" | "infinite_queue";
export type EventsUpdateResponseTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateEventResponse {
    id?: string | null;
    createdOn?: string | null;
    /** If set, the event will override the waiting room's `custom_page_html` property while it is active. If null, the event will inherit it. */
    customPageHtml?: string | null;
    /** A note that you can use to add more details about the event. */
    description?: string | null;
    /** If set, the event will override the waiting room's `disable_session_renewal` property while it is active. If null, the event will inherit it. */
    disableSessionRenewal?: boolean | null;
    /** An ISO 8601 timestamp that marks the end of the event. */
    eventEndTime?: string | null;
    /** An ISO 8601 timestamp that marks the start of the event. At this time, queued users will be processed with the event's configuration. The start time must be at least one minute before `event_end_time`. */
    eventStartTime?: string | null;
    modifiedOn?: string | null;
    /** A unique name to identify the event. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** If set, the event will override the waiting room's `new_users_per_minute` property while it is active. If null, the event will inherit it. This can only be set if the event's `total_active_users` property is also set. */
    newUsersPerMinute?: number | null;
    /** An ISO 8601 timestamp that marks when to begin queueing all users before the event starts. The prequeue must start at least five minutes before `event_start_time`. */
    prequeueStartTime?: string | null;
    /** If set, the event will override the waiting room's `queueing_method` property while it is active. If null, the event will inherit it. */
    queueingMethod?: string | null;
    /** If set, the event will override the waiting room's `session_duration` property while it is active. If null, the event will inherit it. */
    sessionDuration?: number | null;
    /** If enabled, users in the prequeue will be shuffled randomly at the `event_start_time`. Requires that `prequeue_start_time` is not null. This is useful for situations when many users will join the event prequeue at the same time and you want to shuffle them to ensure fairness. Naturally, it makes the most sense to enable this feature when the `queueing_method` during the event respects ordering such as **fifo**, or else the shuffling may be unnecessary. */
    shuffleAtEventStart?: boolean | null;
    /** Suspends or allows an event. If set to `true`, the event is ignored and traffic will be handled based on the waiting room configuration. */
    suspended?: boolean | null;
    /** If set, the event will override the waiting room's `total_active_users` property while it is active. If null, the event will inherit it. This can only be set if the event's `new_users_per_minute` property is also set. */
    totalActiveUsers?: number | null;
    /** If set, the event will override the waiting room's `turnstile_action` property while it is active. If null, the event will inherit it. */
    turnstileAction?: EventsUpdateResponseTurnstileAction | null;
    /** If set, the event will override the waiting room's `turnstile_mode` property while it is active. If null, the event will inherit it. */
    turnstileMode?: EventsUpdateResponseTurnstileMode | null;
}
export type RulesUpdateRequestRulesItemAction = "bypass_waiting_room";
export interface RulesUpdateRequestRulesItem {
    /** The action to take when the expression matches. */
    action: RulesUpdateRequestRulesItemAction | (string & {});
    /** Criteria defining when there is a match for the current rule. */
    expression: string;
    /** The description of the rule. */
    description?: string;
    /** When set to true, the rule is enabled. */
    enabled?: boolean;
}
export type RulesUpdateRequestRulesList = Array<RulesUpdateRequestRulesItem>;
export interface UpdateRuleRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    rules: RulesUpdateRequestRulesList;
}
export type RulesUpdateResultItemAction = "bypass_waiting_room";
export interface RulesUpdateResultItem {
    /** The ID of the rule. */
    id?: string | null;
    /** The action to take when the expression matches. */
    action?: RulesUpdateResultItemAction | null;
    /** The description of the rule. */
    description?: string | null;
    /** When set to true, the rule is enabled. */
    enabled?: boolean | null;
    /** Criteria defining when there is a match for the current rule. */
    expression?: string | null;
    lastUpdated?: string | null;
    /** The version of the rule. */
    version?: string | null;
}
export type RulesUpdateResultList = Array<RulesUpdateResultItem>;
export interface UpdateRuleResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type UpdateRequestAdditionalRoutesItem = CreateRequestAdditionalRoutesItem;
export type UpdateRequestAdditionalRoutesList = Array<CreateRequestAdditionalRoutesItem>;
export type UpdateRequestCookieAttributesSamesite = "auto" | "lax" | "none" | "strict";
export type UpdateRequestCookieAttributesSecure = "auto" | "always" | "never";
export interface UpdateRequestCookieAttributes {
    /** Configures the SameSite attribute on the waiting room cookie. Value `auto` will be translated to `lax` or `none` depending if **Always Use HTTPS** is enabled. Note that when using value `none`, the secure attribute cannot be set to `never`. */
    samesite?: UpdateRequestCookieAttributesSamesite | (string & {});
    /** Configures the Secure attribute on the waiting room cookie. Value `always` indicates that the Secure attribute will be set in the Set-Cookie header, `never` indicates that the Secure attribute will not be set, and `auto` will set the Secure attribute depending if **Always Use HTTPS** is enabled. */
    secure?: UpdateRequestCookieAttributesSecure | (string & {});
}
export type UpdateRequestDefaultTemplateLanguage = "en-US" | "es-ES" | "de-DE" | "fr-FR" | "it-IT" | "ja-JP" | "ko-KR" | "pt-BR" | "zh-CN" | "zh-TW" | "nl-NL" | "pl-PL" | "id-ID" | "tr-TR" | "ar-EG" | "ru-RU" | "fa-IR" | "bg-BG" | "hr-HR" | "cs-CZ" | "da-DK" | "fi-FI" | "lt-LT" | "lv-LV" | "ms-MY" | "nb-NO" | "ro-RO" | "el-GR" | "he-IL" | "hi-IN" | "hu-HU" | "sr-BA" | "sk-SK" | "sl-SI" | "sv-SE" | "tl-PH" | "th-TH" | "uk-UA" | "vi-VN";
export type UpdateRequestEnabledOriginCommandsItem = "revoke";
export type UpdateRequestEnabledOriginCommandsList = Array<UpdateRequestEnabledOriginCommandsItem | (string & {})>;
export type UpdateRequestQueueingMethod = "fifo" | "random" | "passthrough" | "reject";
export type UpdateRequestQueueingStatusCode = 200 | 202 | 429;
export type UpdateRequestTurnstileAction = "log" | "infinite_queue";
export type UpdateRequestTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
export interface UpdateWaitingRoomRequest {
    /** Identifier. */
    zoneId: string;
    waitingRoomId: string;
    /** The host name to which the waiting room will be applied (no wildcards). Please do not include the scheme (http:// or https://). The host and path combination must be unique. */
    host: string;
    /** A unique name to identify the waiting room. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** Sets the number of new users that will be let into the route every minute. This value is used as baseline for the number of users that are let in per minute. So it is possible that there is a little more or little less traffic coming to the route based on the traffic patterns at that time around the world. */
    newUsersPerMinute: number;
    /** Sets the total number of active user sessions on the route at a point in time. A route is a combination of host and path on which a waiting room is available. This value is used as a baseline for the total number of active user sessions on the route. It is possible to have a situation where there are more or less active users sessions on the route based on the traffic patterns at that time around the world. */
    totalActiveUsers: number;
    /** Only available for the Waiting Room Advanced subscription. Additional hostname and path combinations to which this waiting room will be applied. There is an implied wildcard at the end of the path. The hostname and path combination must be unique to this and all other waiting rooms. */
    additionalRoutes?: UpdateRequestAdditionalRoutesList;
    /** Configures cookie attributes for the waiting room cookie. This encrypted cookie stores a user's status in the waiting room, such as queue position. */
    cookieAttributes?: UpdateRequestCookieAttributes;
    /** Appends a '_' + a custom suffix to the end of Cloudflare Waiting Room's cookie name(__cf_waitingroom). If `cookie_suffix` is "abcd", the cookie name will be `__cf_waitingroom_abcd`. This field is required if using `additional_routes`. */
    cookieSuffix?: string;
    /** Only available for the Waiting Room Advanced subscription. This is a template html file that will be rendered at the edge. If no custom_page_html is provided, the default waiting room will be used. The template is based on mustache ( https://mustache.github.io/ ). There are several variables that are evaluated by the Cloudflare edge: */
    customPageHtml?: string;
    /** The language of the default page template. If no default_template_language is provided, then `en-US` (English) will be used. */
    defaultTemplateLanguage?: UpdateRequestDefaultTemplateLanguage | (string & {});
    /** A note that you can use to add more details about the waiting room. */
    description?: string;
    /** Only available for the Waiting Room Advanced subscription. Disables automatic renewal of session cookies. If `true`, an accepted user will have session_duration minutes to browse the site. After that, they will have to go through the waiting room again. If `false`, a user's session cookie will be automatically renewed on every request. */
    disableSessionRenewal?: boolean;
    /** A list of enabled origin commands. */
    enabledOriginCommands?: UpdateRequestEnabledOriginCommandsList;
    /** Only available for the Waiting Room Advanced subscription. If `true`, requests to the waiting room with the header `Accept: application/json` will receive a JSON response object with information on the user's status in the waiting room as opposed to the configured static HTML page. This JSON response object has one property `cfWaitingRoom` which is an object containing the following fields: */
    jsonResponseEnabled?: boolean;
    /** Sets the path within the host to enable the waiting room on. The waiting room will be enabled for all subpaths as well. If there are two waiting rooms on the same subpath, the waiting room for the most specific path will be chosen. Wildcards and query parameters are not supported. */
    path?: string;
    /** If queue_all is `true`, all the traffic that is coming to a route will be sent to the waiting room. No new traffic can get to the route once this field is set and estimated time will become unavailable. */
    queueAll?: boolean;
    /** Sets the queueing method used by the waiting room. Changing this parameter from the **default** queueing method is only available for the Waiting Room Advanced subscription. Regardless of the queueing method, if `queue_all` is enabled or an event is prequeueing, users in the waiting room will not be accepted to the origin. These users will always see a waiting room page that refreshes automatically. The valid queueing methods are: */
    queueingMethod?: UpdateRequestQueueingMethod | (string & {});
    /** HTTP status code returned to a user while in the queue. */
    queueingStatusCode?: UpdateRequestQueueingStatusCode | (number & {});
    /** Lifetime of a cookie (in minutes) set by Cloudflare for users who get access to the route. If a user is not seen by Cloudflare again in that time period, they will be treated as a new user that visits the route. */
    sessionDuration?: number;
    /** Suspends or allows traffic going to the waiting room. If set to `true`, the traffic will not go to the waiting room. */
    suspended?: boolean;
    /** Which action to take when a bot is detected using Turnstile. `log` will have no impact on queueing behavior, simply keeping track of how many bots are detected in Waiting Room Analytics. `infinite_queue` will send bots to a false queueing state, where they will never reach your origin. `infinite_queue` requires Advanced Waiting Room. */
    turnstileAction?: UpdateRequestTurnstileAction | (string & {});
    /** Which Turnstile widget type to use for detecting bot traffic. See [the Turnstile documentation](https://developers.cloudflare.com/turnstile/concepts/widget/#widget-types) for the definitions of these widget types. Set to `off` to disable the Turnstile integration entirely. Setting this to anything other than `off` or `invisible` requires Advanced Waiting Room. */
    turnstileMode?: UpdateRequestTurnstileMode | (string & {});
}
export type UpdateResponseAdditionalRoutesItem = CreateResponseAdditionalRoutesItem;
export type UpdateResponseAdditionalRoutesList = Array<CreateResponseAdditionalRoutesItem>;
export type UpdateResponseCookieAttributesSamesite = "auto" | "lax" | "none" | "strict";
export type UpdateResponseCookieAttributesSecure = "auto" | "always" | "never";
export interface UpdateResponseCookieAttributes {
    /** Configures the SameSite attribute on the waiting room cookie. Value `auto` will be translated to `lax` or `none` depending if **Always Use HTTPS** is enabled. Note that when using value `none`, the secure attribute cannot be set to `never`. */
    samesite?: UpdateResponseCookieAttributesSamesite | null;
    /** Configures the Secure attribute on the waiting room cookie. Value `always` indicates that the Secure attribute will be set in the Set-Cookie header, `never` indicates that the Secure attribute will not be set, and `auto` will set the Secure attribute depending if **Always Use HTTPS** is enabled. */
    secure?: UpdateResponseCookieAttributesSecure | null;
}
export type UpdateResponseDefaultTemplateLanguage = "en-US" | "es-ES" | "de-DE" | "fr-FR" | "it-IT" | "ja-JP" | "ko-KR" | "pt-BR" | "zh-CN" | "zh-TW" | "nl-NL" | "pl-PL" | "id-ID" | "tr-TR" | "ar-EG" | "ru-RU" | "fa-IR" | "bg-BG" | "hr-HR" | "cs-CZ" | "da-DK" | "fi-FI" | "lt-LT" | "lv-LV" | "ms-MY" | "nb-NO" | "ro-RO" | "el-GR" | "he-IL" | "hi-IN" | "hu-HU" | "sr-BA" | "sk-SK" | "sl-SI" | "sv-SE" | "tl-PH" | "th-TH" | "uk-UA" | "vi-VN";
export type UpdateResponseEnabledOriginCommandsItem = "revoke";
export type UpdateResponseEnabledOriginCommandsList = Array<UpdateResponseEnabledOriginCommandsItem>;
export type UpdateResponseQueueingMethod = "fifo" | "random" | "passthrough" | "reject";
export type UpdateResponseQueueingStatusCode = 200 | 202 | 429;
export type UpdateResponseTurnstileAction = "log" | "infinite_queue";
export type UpdateResponseTurnstileMode = "off" | "invisible" | "visible_non_interactive" | "visible_managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateWaitingRoomResponse {
    id?: string | null;
    /** Only available for the Waiting Room Advanced subscription. Additional hostname and path combinations to which this waiting room will be applied. There is an implied wildcard at the end of the path. The hostname and path combination must be unique to this and all other waiting rooms. */
    additionalRoutes?: UpdateResponseAdditionalRoutesList | null;
    /** Configures cookie attributes for the waiting room cookie. This encrypted cookie stores a user's status in the waiting room, such as queue position. */
    cookieAttributes?: UpdateResponseCookieAttributes | null;
    /** Appends a '_' + a custom suffix to the end of Cloudflare Waiting Room's cookie name(__cf_waitingroom). If `cookie_suffix` is "abcd", the cookie name will be `__cf_waitingroom_abcd`. This field is required if using `additional_routes`. */
    cookieSuffix?: string | null;
    createdOn?: string | null;
    /** Only available for the Waiting Room Advanced subscription. This is a template html file that will be rendered at the edge. If no custom_page_html is provided, the default waiting room will be used. The template is based on mustache ( https://mustache.github.io/ ). There are several variables that are evaluated by the Cloudflare edge: */
    customPageHtml?: string | null;
    /** The language of the default page template. If no default_template_language is provided, then `en-US` (English) will be used. */
    defaultTemplateLanguage?: UpdateResponseDefaultTemplateLanguage | null;
    /** A note that you can use to add more details about the waiting room. */
    description?: string | null;
    /** Only available for the Waiting Room Advanced subscription. Disables automatic renewal of session cookies. If `true`, an accepted user will have session_duration minutes to browse the site. After that, they will have to go through the waiting room again. If `false`, a user's session cookie will be automatically renewed on every request. */
    disableSessionRenewal?: boolean | null;
    /** A list of enabled origin commands. */
    enabledOriginCommands?: UpdateResponseEnabledOriginCommandsList | null;
    /** The host name to which the waiting room will be applied (no wildcards). Please do not include the scheme (http:// or https://). The host and path combination must be unique. */
    host?: string | null;
    /** Only available for the Waiting Room Advanced subscription. If `true`, requests to the waiting room with the header `Accept: application/json` will receive a JSON response object with information on the user's status in the waiting room as opposed to the configured static HTML page. This JSON response object has one property `cfWaitingRoom` which is an object containing the following fields: */
    jsonResponseEnabled?: boolean | null;
    modifiedOn?: string | null;
    /** A unique name to identify the waiting room. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** Sets the number of new users that will be let into the route every minute. This value is used as baseline for the number of users that are let in per minute. So it is possible that there is a little more or little less traffic coming to the route based on the traffic patterns at that time around the world. */
    newUsersPerMinute?: number | null;
    /** An ISO 8601 timestamp that marks when the next event will begin queueing. */
    nextEventPrequeueStartTime?: string | null;
    /** An ISO 8601 timestamp that marks when the next event will start. */
    nextEventStartTime?: string | null;
    /** Sets the path within the host to enable the waiting room on. The waiting room will be enabled for all subpaths as well. If there are two waiting rooms on the same subpath, the waiting room for the most specific path will be chosen. Wildcards and query parameters are not supported. */
    path?: string | null;
    /** If queue_all is `true`, all the traffic that is coming to a route will be sent to the waiting room. No new traffic can get to the route once this field is set and estimated time will become unavailable. */
    queueAll?: boolean | null;
    /** Sets the queueing method used by the waiting room. Changing this parameter from the **default** queueing method is only available for the Waiting Room Advanced subscription. Regardless of the queueing method, if `queue_all` is enabled or an event is prequeueing, users in the waiting room will not be accepted to the origin. These users will always see a waiting room page that refreshes automatically. The valid queueing methods are: */
    queueingMethod?: UpdateResponseQueueingMethod | null;
    /** HTTP status code returned to a user while in the queue. */
    queueingStatusCode?: UpdateResponseQueueingStatusCode | null;
    /** Lifetime of a cookie (in minutes) set by Cloudflare for users who get access to the route. If a user is not seen by Cloudflare again in that time period, they will be treated as a new user that visits the route. */
    sessionDuration?: number | null;
    /** Suspends or allows traffic going to the waiting room. If set to `true`, the traffic will not go to the waiting room. */
    suspended?: boolean | null;
    /** Sets the total number of active user sessions on the route at a point in time. A route is a combination of host and path on which a waiting room is available. This value is used as a baseline for the total number of active user sessions on the route. It is possible to have a situation where there are more or less active users sessions on the route based on the traffic patterns at that time around the world. */
    totalActiveUsers?: number | null;
    /** Which action to take when a bot is detected using Turnstile. `log` will have no impact on queueing behavior, simply keeping track of how many bots are detected in Waiting Room Analytics. `infinite_queue` will send bots to a false queueing state, where they will never reach your origin. `infinite_queue` requires Advanced Waiting Room. */
    turnstileAction?: UpdateResponseTurnstileAction | null;
    /** Which Turnstile widget type to use for detecting bot traffic. See [the Turnstile documentation](https://developers.cloudflare.com/turnstile/concepts/widget/#widget-types) for the definitions of these widget types. Set to `off` to disable the Turnstile integration entirely. Setting this to anything other than `off` or `invisible` requires Advanced Waiting Room. */
    turnstileMode?: UpdateResponseTurnstileMode | null;
}
export type CreateEventError = CloudflareOpError;
/** Only available for the Waiting Room Advanced subscription. Creates an event for a waiting room. An event takes place during a specified period of time, temporarily changing the behavior of a waiting room. While the event is active, some of the properties in the event's configuration may either override or inherit from the waiting room's configuration. Note that events cannot overlap with each other, so only one event can be active at a time. */
export declare const createEvent: API.OperationMethod<CreateEventRequest, CreateEventResponse, CreateEventError, CloudflareOpContext>;
export type CreateRuleError = CloudflareOpError;
/** Only available for the Waiting Room Advanced subscription. Creates a rule for a waiting room. */
export declare const createRule: API.PaginatedOperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, CloudflareOpContext, RulesCreateResultItem>;
export type CreateWaitingRoomError = ZoneNotEntitled | Forbidden | CloudflareOpError;
/** Creates a new waiting room. */
export declare const createWaitingRoom: API.OperationMethod<CreateWaitingRoomRequest, CreateWaitingRoomResponse, CreateWaitingRoomError, CloudflareOpContext>;
export type DeleteEventError = CloudflareOpError;
/** Deletes an event for a waiting room. */
export declare const deleteEvent: API.OperationMethod<DeleteEventRequest, DeleteEventResponse, DeleteEventError, CloudflareOpContext>;
export type DeleteRuleError = CloudflareOpError;
/** Deletes a rule for a waiting room. */
export declare const deleteRule: API.PaginatedOperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext, RulesDeleteResultItem>;
export type DeleteWaitingRoomError = WaitingRoomNotFound | Forbidden | CloudflareOpError;
/** Deletes a waiting room. */
export declare const deleteWaitingRoom: API.OperationMethod<DeleteWaitingRoomRequest, DeleteWaitingRoomResponse, DeleteWaitingRoomError, CloudflareOpContext>;
export type GetEventError = CloudflareOpError;
/** Fetches a single configured event for a waiting room. */
export declare const getEvent: API.OperationMethod<GetEventRequest, GetEventResponse, GetEventError, CloudflareOpContext>;
export type GetEventDetailError = CloudflareOpError;
/** Previews an event's configuration as if it was active. Inherited fields from the waiting room will be displayed with their current values. */
export declare const getEventDetail: API.OperationMethod<GetEventDetailRequest, GetEventDetailResponse, GetEventDetailError, CloudflareOpContext>;
export type GetRuleError = CloudflareOpError;
/** Lists rules for a waiting room. */
export declare const getRule: API.PaginatedOperationMethod<GetRuleRequest, GetRuleResponse, GetRuleError, CloudflareOpContext, RulesGetResultItem>;
export type GetSettingError = Forbidden | CloudflareOpError;
/** Get zone-level Waiting Room settings. */
export declare const getSetting: API.OperationMethod<GetSettingRequest, GetSettingResponse, GetSettingError, CloudflareOpContext>;
export type GetStatusError = CloudflareOpError;
/** Fetches the status of a configured waiting room. Response fields include: 1. `status`: String indicating the status of the waiting room. The possible status are: - **not_queueing** indicates that the configured thresholds have not been met and all users are going through to the origin. - **queueing** indicates that the thresholds have been met and some users are held in the waiting room. - **event_prequeueing** indicates that an event is active and is currently prequeueing users before it starts. - **suspended** indicates that the room is suspended. 2. `event_id`: String of the current event's `id` if an event is active, otherwise an empty string. 3. `estimated_queued_users`: Integer of the estimated number of users currently waiting in the queue. 4. `estimated_total_active_users`: Integer of the estimated number of users currently active on the origin. 5. `max_estimated_time_minutes`: Integer of the maximum estimated time currently presented to the users. */
export declare const getStatus: API.OperationMethod<GetStatusRequest, GetStatusResponse, GetStatusError, CloudflareOpContext>;
export type GetWaitingRoomError = WaitingRoomNotFound | Forbidden | CloudflareOpError;
/** Fetches a single configured waiting room. */
export declare const getWaitingRoom: API.OperationMethod<GetWaitingRoomRequest, GetWaitingRoomResponse, GetWaitingRoomError, CloudflareOpContext>;
export type ListEventsError = CloudflareOpError;
/** Lists events for a waiting room. */
export declare const listEvents: API.PaginatedOperationMethod<ListEventsRequest, ListEventsResponse, ListEventsError, CloudflareOpContext, EventsListResultItem>;
export type ListWaitingRoomsForAccountError = Forbidden | CloudflareOpError;
/** Lists waiting rooms for account or zone. */
export declare const listWaitingRoomsForAccount: API.PaginatedOperationMethod<ListWaitingRoomsForAccountRequest, ListWaitingRoomsResponse, ListWaitingRoomsForAccountError, CloudflareOpContext, ListResultItem>;
export type ListWaitingRoomsForZoneError = Forbidden | CloudflareOpError;
/** Lists waiting rooms for account or zone. */
export declare const listWaitingRoomsForZone: API.PaginatedOperationMethod<ListWaitingRoomsForZoneRequest, ListWaitingRoomsResponse, ListWaitingRoomsForZoneError, CloudflareOpContext, ListResultItem>;
export type PatchEventError = CloudflareOpError;
/** Patches a configured event for a waiting room. */
export declare const patchEvent: API.OperationMethod<PatchEventRequest, PatchEventResponse, PatchEventError, CloudflareOpContext>;
export type PatchRuleError = CloudflareOpError;
/** Patches a rule for a waiting room. */
export declare const patchRule: API.PaginatedOperationMethod<PatchRuleRequest, PatchRuleResponse, PatchRuleError, CloudflareOpContext, RulesEditResultItem>;
export type PatchSettingError = CloudflareOpError;
/** Patch zone-level Waiting Room settings. */
export declare const patchSetting: API.OperationMethod<PatchSettingRequest, PatchSettingResponse, PatchSettingError, CloudflareOpContext>;
export type PatchWaitingRoomError = CloudflareOpError;
/** Patches a configured waiting room. */
export declare const patchWaitingRoom: API.OperationMethod<PatchWaitingRoomRequest, PatchWaitingRoomResponse, PatchWaitingRoomError, CloudflareOpContext>;
export type PreviewPageError = CloudflareOpError;
/** Creates a waiting room page preview. Upload a custom waiting room page for preview. You will receive a preview URL in the form `http://waitingrooms.dev/preview/<uuid>`. You can use the following query parameters to change the state of the preview: 1. `force_queue`: Boolean indicating if all users will be queued in the waiting room and no one will be let into the origin website (also known as queueAll). 2. `queue_is_full`: Boolean indicating if the waiting room's queue is currently full and not accepting new users at the moment. 3. `queueing_method`: The queueing method currently used by the waiting room. - **fifo** indicates a FIFO queue. - **random** indicates a Random queue. - **passthrough** indicates a Passthrough queue. Keep in mind that the waiting room page will only be displayed if `force_queue=true` or `event=prequeueing` -- for other cases the request will pass through to the origin. For our preview, this will be a fake origin website returning "Welcome". - **reject** indicates a Reject queue. 4. `event`: Used to preview a waiting room event. - **none** indicates no event is occurring. - **prequeueing** indicates that an event is prequeueing (between `prequeue_start_time` and `event_start_time`). - **started** indicates that an event has started (between `event_start_time` and `event_end_time`). 5. `shuffle_at_event_start`: Boolean indicating if the event will shuffle users in the prequeue when it starts. This can only be set to **true** if an event is active ( `event` is not **none**). For example, you can make a request to `http://waitingrooms.dev/preview/<uuid>?force_queue=false&queue_is_full=false&queueing_method=random&event=started&shuffle_at_event_start=true` 6. `waitTime`: Non-zero, positive integer indicating the estimated wait time in minutes. The default value is 10 minutes. For example, you can make a request to `http://waitingrooms.dev/preview/<uuid>?waitTime=50` to configure the estimated wait time as 50 minutes. */
export declare const previewPage: API.OperationMethod<PreviewPageRequest, PreviewPageResponse, PreviewPageError, CloudflareOpContext>;
export type PutSettingError = ZoneNotEntitled | Forbidden | CloudflareOpError;
/** Replace zone-level Waiting Room settings. */
export declare const putSetting: API.OperationMethod<PutSettingRequest, PutSettingResponse, PutSettingError, CloudflareOpContext>;
export type UpdateEventError = CloudflareOpError;
/** Updates a configured event for a waiting room. */
export declare const updateEvent: API.OperationMethod<UpdateEventRequest, UpdateEventResponse, UpdateEventError, CloudflareOpContext>;
export type UpdateRuleError = CloudflareOpError;
/** Only available for the Waiting Room Advanced subscription. Replaces all rules for a waiting room. */
export declare const updateRule: API.PaginatedOperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, CloudflareOpContext, RulesUpdateResultItem>;
export type UpdateWaitingRoomError = WaitingRoomNotFound | ZoneNotEntitled | Forbidden | CloudflareOpError;
/** Updates a configured waiting room. */
export declare const updateWaitingRoom: API.OperationMethod<UpdateWaitingRoomRequest, UpdateWaitingRoomResponse, UpdateWaitingRoomError, CloudflareOpContext>;
//# sourceMappingURL=waiting_rooms.d.ts.map