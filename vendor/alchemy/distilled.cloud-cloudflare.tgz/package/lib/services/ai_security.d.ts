import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AiSecurityNotEntitled_base: S.TaggedErrorClass<"AiSecurityNotEntitled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class AiSecurityNotEntitled extends /*@__PURE__*/ AiSecurityNotEntitled_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const ZoneNotAuthorized_base: S.TaggedErrorClass<"ZoneNotAuthorized", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ZoneNotAuthorized extends /*@__PURE__*/ ZoneNotAuthorized_base {
}
export interface GetAiSecurityRequest {
    /** Defines the zone. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAiSecurityResponse {
    /** Whether AI Security for Apps is enabled on the zone. */
    enabled?: boolean | null;
}
export interface GetCustomTopicRequest {
    /** Defines the zone. */
    zoneId: string;
}
export interface CustomTopicsGetResponseTopicsItem {
    /** Unique label identifier. Must contain only lowercase letters (a-z), digits (0-9), and hyphens. */
    label: string;
    /** Description of the topic category. Must contain only printable ASCII characters. */
    topic: string;
}
export type CustomTopicsGetResponseTopicsList = Array<CustomTopicsGetResponseTopicsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCustomTopicResponse {
    /** Custom topic categories for AI Security for Apps content detection. */
    topics?: CustomTopicsGetResponseTopicsList | null;
}
export interface PutAiSecurityRequest {
    /** Defines the zone. */
    zoneId: string;
    /** Whether AI Security for Apps is enabled on the zone. */
    enabled?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutAiSecurityResponse {
    /** Whether AI Security for Apps is enabled on the zone. */
    enabled?: boolean | null;
}
export type CustomTopicsUpdateRequestTopicsItem = CustomTopicsGetResponseTopicsItem;
export type CustomTopicsUpdateRequestTopicsList = Array<CustomTopicsGetResponseTopicsItem>;
export interface PutCustomTopicRequest {
    /** Defines the zone. */
    zoneId: string;
    /** Custom topic categories for AI Security for Apps content detection. */
    topics?: CustomTopicsUpdateRequestTopicsList;
}
export type CustomTopicsUpdateResponseTopicsItem = CustomTopicsGetResponseTopicsItem;
export type CustomTopicsUpdateResponseTopicsList = Array<CustomTopicsGetResponseTopicsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutCustomTopicResponse {
    /** Custom topic categories for AI Security for Apps content detection. */
    topics?: CustomTopicsUpdateResponseTopicsList | null;
}
export type GetAiSecurityError = AiSecurityNotEntitled | ZoneNotAuthorized | Forbidden | CloudflareOpError;
/** Get the current AI Security for Apps status for the zone. While enabled, Cloudflare scans prompts sent to endpoints labeled `cf-llm` for personally identifiable information, unsafe topics, and prompt injection attempts. */
export declare const getAiSecurity: API.OperationMethod<GetAiSecurityRequest, GetAiSecurityResponse, GetAiSecurityError, CloudflareOpContext>;
export type GetCustomTopicError = AiSecurityNotEntitled | ZoneNotAuthorized | Forbidden | CloudflareOpError;
/** Get the custom topic categories defined for the zone. While AI Security for Apps is enabled, it scores every incoming prompt against these topics and writes the scores to the `cf.llm.prompt.custom_topic_categories` field, keyed by topic label. Topics can be configured while the detection is disabled, but no prompt is scored until you enable it. */
export declare const getCustomTopic: API.OperationMethod<GetCustomTopicRequest, GetCustomTopicResponse, GetCustomTopicError, CloudflareOpContext>;
export type PutAiSecurityError = AiSecurityNotEntitled | ZoneNotAuthorized | Forbidden | CloudflareOpError;
/** Update the AI Security for Apps status for the zone, enabling or disabling the detection. The detection results are exposed as `cf.llm.prompt.*` fields for use in custom rules and rate limiting rules; changes can take up to a minute to propagate. */
export declare const putAiSecurity: API.OperationMethod<PutAiSecurityRequest, PutAiSecurityResponse, PutAiSecurityError, CloudflareOpContext>;
export type PutCustomTopicError = AiSecurityNotEntitled | ZoneNotAuthorized | Forbidden | CloudflareOpError;
/** Update the custom topic list of the zone, overwriting it entirely with the topics in the request, so include every topic you want to keep. Changes can take up to a minute to propagate. Each entry has a `label`, used to reference the topic in rule expressions and analytics, and a `topic` description, which the classifier scores prompts against while AI Security for Apps is enabled. The following rules apply: - A zone can hold at most 20 topics. - `label` must be 2-20 characters, using only lowercase letters (a-z), digits (0-9), and hyphens. - `topic` must be 2-50 printable ASCII characters. - Labels must be unique within the zone, and so must topic descriptions. */
export declare const putCustomTopic: API.OperationMethod<PutCustomTopicRequest, PutCustomTopicResponse, PutCustomTopicError, CloudflareOpContext>;
//# sourceMappingURL=ai_security.d.ts.map