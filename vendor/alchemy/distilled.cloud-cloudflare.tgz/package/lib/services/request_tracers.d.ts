import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface TracesCreateRequestBody {
    /** Base64 encoded request body */
    base64?: string;
    /** Arbitrary json as request body */
    json?: unknown;
    /** Request body as plain text */
    plainText?: string;
}
export interface TracesCreateRequestContextGeoloc {
    city?: string;
    continent?: string;
    isEuCountry?: boolean;
    isoCode?: string;
    latitude?: number;
    longitude?: number;
    postalCode?: string;
    regionCode?: string;
    subdivision_2_iso_code?: string;
    timezone?: string;
}
export interface TracesCreateRequestContext {
    /** Bot score used for evaluating tracing request processing */
    botScore?: number;
    /** Geodata for tracing request */
    geoloc?: TracesCreateRequestContextGeoloc;
    /** Whether to skip any challenges for tracing request (e.g.: captcha) */
    skipChallenge?: boolean;
    /** Threat score used for evaluating tracing request processing */
    threatScore?: number;
}
export type TracesCreateRequestCookiesMap = {
    [key: string]: string | undefined;
};
export type TracesCreateRequestHeadersMap = {
    [key: string]: string | undefined;
};
export interface CreateTraceRequest {
    /** Identifier. */
    accountId: string;
    /** HTTP Method of tracing request */
    method: string;
    /** URL to which perform tracing request */
    url: string;
    body?: TracesCreateRequestBody;
    /** Additional request parameters */
    context?: TracesCreateRequestContext;
    /** Cookies added to tracing request */
    cookies?: TracesCreateRequestCookiesMap;
    /** Headers added to tracing request */
    headers?: TracesCreateRequestHeadersMap;
    /** HTTP Protocol of tracing request */
    protocol?: string;
    /** Skip sending the request to the Origin server after all rules evaluation */
    skipResponse?: boolean;
}
export interface TracesCreateResponseTraceItem {
    /** If step type is rule, then action performed by this rule */
    action?: string | null;
    /** If step type is rule, then action parameters of this rule as JSON */
    actionParameters?: unknown | null;
    /** If step type is rule or ruleset, the description of this entity */
    description?: string | null;
    /** If step type is rule, then expression used to match for this rule */
    expression?: string | null;
    /** If step type is ruleset, then kind of this ruleset */
    kind?: string | null;
    /** Whether tracing step affected tracing request/response */
    matched?: boolean | null;
    /** If step type is ruleset, then name of this ruleset */
    name?: string | null;
    /** Tracing step identifying name */
    stepName?: string | null;
    trace?: unknown | null;
    /** Tracing step type */
    type?: string | null;
}
export type TracesCreateResponseTraceList = Array<TracesCreateResponseTraceItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTraceResponse {
    /** HTTP Status code of zone response */
    statusCode?: number | null;
    trace?: TracesCreateResponseTraceList | null;
}
export type CreateTraceError = CloudflareOpError;
/** Traces a simulated HTTP request through Cloudflare's edge to analyze how rules, settings, and configurations would process the request. Useful for debugging firewall rules, page rules, and other request transformations without sending actual traffic. Supports custom headers, cookies, body content, and geolocation context. */
export declare const createTrace: API.OperationMethod<CreateTraceRequest, CreateTraceResponse, CreateTraceError, CloudflareOpContext>;
//# sourceMappingURL=request_tracers.d.ts.map