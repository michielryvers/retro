import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface DeleteOriginTlsComplianceModeRequest {
    /** Identifier. */
    zoneId: string;
}
export type DeleteResponseId = "origin_tls_compliance_modes";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOriginTlsComplianceModeResponse {
    /** The identifier of the caching setting. */
    id: DeleteResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export interface GetOriginTlsComplianceModeRequest {
    /** Identifier. */
    zoneId: string;
}
export type GetResponseId = "origin_tls_compliance_modes";
export type GetResponseValueList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOriginTlsComplianceModeResponse {
    /** The identifier of the caching setting. */
    id: GetResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** List of TLS compliance modes that constrain the key-exchange algorithms Cloudflare may use when establishing the TLS connection to the zone's origin. Currently supported values are `fips` (FIPS-approved curves) and `pqh` (post-quantum hybrid). Future modes (e.g. `cnsa2`) may be added; clients should treat unknown values as opaque strings. Multiple modes are combined as the intersection of their permitted algorithm lists; selections whose intersection is empty are rejected. An empty list clears the constraint. */
    value: GetResponseValueList;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export type EditRequestValueList = Array<string>;
export interface PatchOriginTlsComplianceModeRequest {
    /** Identifier. */
    zoneId: string;
    /** List of TLS compliance modes that constrain the key-exchange algorithms Cloudflare may use when establishing the TLS connection to the zone's origin. Currently supported values are `fips` (FIPS-approved curves) and `pqh` (post-quantum hybrid). Future modes (e.g. `cnsa2`) may be added; clients should treat unknown values as opaque strings. Multiple modes are combined as the intersection of their permitted algorithm lists; selections whose intersection is empty are rejected. An empty list clears the constraint. */
    value: EditRequestValueList;
}
export type EditResponseId = "origin_tls_compliance_modes";
export type EditResponseValueList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchOriginTlsComplianceModeResponse {
    /** The identifier of the caching setting. */
    id: EditResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** List of TLS compliance modes that constrain the key-exchange algorithms Cloudflare may use when establishing the TLS connection to the zone's origin. Currently supported values are `fips` (FIPS-approved curves) and `pqh` (post-quantum hybrid). Future modes (e.g. `cnsa2`) may be added; clients should treat unknown values as opaque strings. Multiple modes are combined as the intersection of their permitted algorithm lists; selections whose intersection is empty are rejected. An empty list clears the constraint. */
    value: EditResponseValueList;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export type UpdateRequestValueList = Array<string>;
export interface PutOriginTlsComplianceModeRequest {
    /** Identifier. */
    zoneId: string;
    /** List of TLS compliance modes that constrain the key-exchange algorithms Cloudflare may use when establishing the TLS connection to the zone's origin. Currently supported values are `fips` (FIPS-approved curves) and `pqh` (post-quantum hybrid). Future modes (e.g. `cnsa2`) may be added; clients should treat unknown values as opaque strings. Multiple modes are combined as the intersection of their permitted algorithm lists; selections whose intersection is empty are rejected. An empty list clears the constraint. */
    value: UpdateRequestValueList;
}
export type UpdateResponseId = "origin_tls_compliance_modes";
export type UpdateResponseValueList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutOriginTlsComplianceModeResponse {
    /** The identifier of the caching setting. */
    id: UpdateResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** List of TLS compliance modes that constrain the key-exchange algorithms Cloudflare may use when establishing the TLS connection to the zone's origin. Currently supported values are `fips` (FIPS-approved curves) and `pqh` (post-quantum hybrid). Future modes (e.g. `cnsa2`) may be added; clients should treat unknown values as opaque strings. Multiple modes are combined as the intersection of their permitted algorithm lists; selections whose intersection is empty are rejected. An empty list clears the constraint. */
    value: UpdateResponseValueList;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export type DeleteOriginTlsComplianceModeError = CloudflareOpError;
/** Delete the Origin TLS Compliance Modes setting for the zone, removing any configured compliance constraint. After deletion, Cloudflare's default behavior applies (no compliance filtering of the key-exchange algorithm list sent to the origin). */
export declare const deleteOriginTlsComplianceMode: API.OperationMethod<DeleteOriginTlsComplianceModeRequest, DeleteOriginTlsComplianceModeResponse, DeleteOriginTlsComplianceModeError, CloudflareOpContext>;
export type GetOriginTlsComplianceModeError = CloudflareOpError;
/** Origin TLS Compliance Modes constrains the set of TLS key-exchange algorithms Cloudflare may use when establishing the TLS connection to the zone's origin. The value is a list of named compliance modes (currently `fips` and `pqh`). Multiple modes are combined as the intersection of their permitted algorithm lists. An empty list (or no rule configured) means no compliance constraint is applied. */
export declare const getOriginTlsComplianceMode: API.OperationMethod<GetOriginTlsComplianceModeRequest, GetOriginTlsComplianceModeResponse, GetOriginTlsComplianceModeError, CloudflareOpContext>;
export type PatchOriginTlsComplianceModeError = CloudflareOpError;
/** Update the set of TLS compliance modes for the zone. PATCH performs a full replace of the modes list, not a merge -- the request body is treated as the complete new list, and any modes not present in it are removed. (To remove a single mode from an existing configuration, send the updated list without it.) The request body must be of the form `{"value": ["fips", "pqh"]}`. Currently supported modes are `fips` and `pqh`; an empty list clears the constraint. Future modes (e.g. `cnsa2`) may be added; clients should treat unknown values as opaque strings. Invalid mode values are rejected with a 4xx response. */
export declare const patchOriginTlsComplianceMode: API.OperationMethod<PatchOriginTlsComplianceModeRequest, PatchOriginTlsComplianceModeResponse, PatchOriginTlsComplianceModeError, CloudflareOpContext>;
export type PutOriginTlsComplianceModeError = CloudflareOpError;
/** Replace the entire set of TLS compliance modes for the zone with the list provided in the request body. PUT performs a full replace, not a merge -- any modes not present in the request body are removed. The request body must be of the form `{"value": ["fips", "pqh"]}`. Currently supported modes are `fips` and `pqh`; an empty list clears the constraint. Future modes (e.g. `cnsa2`) may be added; clients should treat unknown values as opaque strings. Invalid mode values are rejected with a 4xx response. */
export declare const putOriginTlsComplianceMode: API.OperationMethod<PutOriginTlsComplianceModeRequest, PutOriginTlsComplianceModeResponse, PutOriginTlsComplianceModeError, CloudflareOpContext>;
//# sourceMappingURL=origin_tls_compliance_modes.d.ts.map