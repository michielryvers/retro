import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const SecurityTxtInvalid_base: S.TaggedErrorClass<"SecurityTxtInvalid", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SecurityTxtInvalid extends /*@__PURE__*/ SecurityTxtInvalid_base {
}
export interface DeleteSecurityTxtRequest {
    /** Identifier. */
    zoneId: string;
}
export interface DeleteSecurityTxtResponse {
}
export interface GetSecurityTxtRequest {
    /** Identifier. */
    zoneId: string;
}
export type GetResponseAcknowledgmentsList = Array<string>;
export type GetResponseCanonicalList = Array<string>;
export type GetResponseContactList = Array<string>;
export type GetResponseEncryptionList = Array<string>;
export type GetResponseHiringList = Array<string>;
export type GetResponsePolicyList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SecurityTxtFile {
    acknowledgments?: GetResponseAcknowledgmentsList | null;
    canonical?: GetResponseCanonicalList | null;
    contact?: GetResponseContactList | null;
    enabled?: boolean | null;
    encryption?: GetResponseEncryptionList | null;
    expires?: string | null;
    hiring?: GetResponseHiringList | null;
    policy?: GetResponsePolicyList | null;
    preferredLanguages?: string | null;
}
export type GetSecurityTxtResponse = SecurityTxtFile;
export type UpdateRequestAcknowledgmentsList = Array<string>;
export type UpdateRequestCanonicalList = Array<string>;
export type UpdateRequestContactList = Array<string>;
export type UpdateRequestEncryptionList = Array<string>;
export type UpdateRequestHiringList = Array<string>;
export type UpdateRequestPolicyList = Array<string>;
export interface PutSecurityTxtRequest {
    /** Identifier. */
    zoneId: string;
    acknowledgments?: UpdateRequestAcknowledgmentsList;
    canonical?: UpdateRequestCanonicalList;
    contact?: UpdateRequestContactList;
    enabled?: boolean;
    encryption?: UpdateRequestEncryptionList;
    expires?: string;
    hiring?: UpdateRequestHiringList;
    policy?: UpdateRequestPolicyList;
    preferredLanguages?: string;
}
export interface PutSecurityTxtResponse {
}
export type DeleteSecurityTxtError = Forbidden | CloudflareOpError;
/** Removes the security.txt file configuration for a zone. The /.well-known/security.txt endpoint will no longer be served. */
export declare const deleteSecurityTxt: API.OperationMethod<DeleteSecurityTxtRequest, DeleteSecurityTxtResponse, DeleteSecurityTxtError, CloudflareOpContext>;
export type GetSecurityTxtError = Forbidden | CloudflareOpError;
/** Retrieves the current security.txt file configuration for a zone, used for security vulnerability reporting. */
export declare const getSecurityTxt: API.OperationMethod<GetSecurityTxtRequest, GetSecurityTxtResponse, GetSecurityTxtError, CloudflareOpContext>;
export type PutSecurityTxtError = Forbidden | SecurityTxtInvalid | CloudflareOpError;
/** Updates the security.txt file configuration for a zone, which provides security researchers with vulnerability reporting information. */
export declare const putSecurityTxt: API.OperationMethod<PutSecurityTxtRequest, PutSecurityTxtResponse, PutSecurityTxtError, CloudflareOpContext>;
//# sourceMappingURL=security_txt.d.ts.map