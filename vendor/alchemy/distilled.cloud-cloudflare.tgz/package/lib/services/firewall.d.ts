import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AccessRuleNotFound_base: S.TaggedErrorClass<"AccessRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class AccessRuleNotFound extends /*@__PURE__*/ AccessRuleNotFound_base {
}
declare const DuplicateAccessRule_base: S.TaggedErrorClass<"DuplicateAccessRule", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DuplicateAccessRule extends /*@__PURE__*/ DuplicateAccessRule_base {
}
declare const DuplicateLockdown_base: S.TaggedErrorClass<"DuplicateLockdown", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DuplicateLockdown extends /*@__PURE__*/ DuplicateLockdown_base {
}
declare const DuplicateUaRule_base: S.TaggedErrorClass<"DuplicateUaRule", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DuplicateUaRule extends /*@__PURE__*/ DuplicateUaRule_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const LockdownNotFound_base: S.TaggedErrorClass<"LockdownNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class LockdownNotFound extends /*@__PURE__*/ LockdownNotFound_base {
}
declare const UaRuleNotFound_base: S.TaggedErrorClass<"UaRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class UaRuleNotFound extends /*@__PURE__*/ UaRuleNotFound_base {
}
export interface BulkDeleteRulesRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export type RulesBulkDeleteResultItemAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export interface RulesBulkDeleteResultItemFilterFirewallFilter {
    /** The unique identifier of the filter. */
    id?: string | null;
    /** An informative summary of the filter. */
    description?: string | null;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string | null;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean | null;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string | null;
}
export interface RulesBulkDeleteResultItemFilterDeletedFilter {
    /** The unique identifier of the filter. */
    id: string;
    /** When true, indicates that the firewall rule was deleted. */
    deleted: boolean;
}
export type RulesBulkDeleteResultItemFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesBulkDeleteResultItemProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export type RulesBulkDeleteResultItemProductsList = Array<RulesBulkDeleteResultItemProductsItem>;
export interface RulesBulkDeleteResultItem {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesBulkDeleteResultItemAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesBulkDeleteResultItemFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesBulkDeleteResultItemProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export type RulesBulkDeleteResultList = Array<RulesBulkDeleteResultItem>;
export interface BulkDeleteRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesBulkDeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface BulkPatchRulesRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the firewall rule. */
    id: string;
}
export type RulesBulkEditResultItemAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export type RulesBulkEditResultItemFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export type RulesBulkEditResultItemFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesBulkEditResultItemFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesBulkEditResultItemProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export type RulesBulkEditResultItemProductsList = Array<RulesBulkEditResultItemProductsItem>;
export interface RulesBulkEditResultItem {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesBulkEditResultItemAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesBulkEditResultItemFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesBulkEditResultItemProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export type RulesBulkEditResultList = Array<RulesBulkEditResultItem>;
export interface BulkPatchRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesBulkEditResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface BulkPutRulesRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the firewall rule. */
    id: string;
}
export type RulesBulkUpdateResultItemAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export type RulesBulkUpdateResultItemFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export type RulesBulkUpdateResultItemFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesBulkUpdateResultItemFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesBulkUpdateResultItemProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export type RulesBulkUpdateResultItemProductsList = Array<RulesBulkUpdateResultItemProductsItem>;
export interface RulesBulkUpdateResultItem {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesBulkUpdateResultItemAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesBulkUpdateResultItemFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesBulkUpdateResultItemProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export type RulesBulkUpdateResultList = Array<RulesBulkUpdateResultItem>;
export interface BulkPutRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesBulkUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type AccessRulesCreateRequestConfigurationAccessRuleIPConfigurationTarget = "ip";
export interface AccessRulesCreateRequestConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: AccessRulesCreateRequestConfigurationAccessRuleIPConfigurationTarget | (string & {});
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string;
}
export type AccessRulesCreateRequestConfigurationIPV6ConfigurationTarget = "ip6";
export interface AccessRulesCreateRequestConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: AccessRulesCreateRequestConfigurationIPV6ConfigurationTarget | (string & {});
    /** The IPv6 address to match. */
    value?: string;
}
export type AccessRulesCreateRequestConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export interface AccessRulesCreateRequestConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: AccessRulesCreateRequestConfigurationAccessRuleCIDRConfigurationTarget | (string & {});
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string;
}
export type AccessRulesCreateRequestConfigurationASNConfigurationTarget = "asn";
export interface AccessRulesCreateRequestConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: AccessRulesCreateRequestConfigurationASNConfigurationTarget | (string & {});
    /** The AS number to match. */
    value?: string;
}
export type AccessRulesCreateRequestConfigurationCountryConfigurationTarget = "country";
export interface AccessRulesCreateRequestConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: AccessRulesCreateRequestConfigurationCountryConfigurationTarget | (string & {});
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string;
}
export type AccessRulesCreateRequestConfiguration = AccessRulesCreateRequestConfigurationAccessRuleIPConfiguration | AccessRulesCreateRequestConfigurationIPV6Configuration | AccessRulesCreateRequestConfigurationAccessRuleCIDRConfiguration | AccessRulesCreateRequestConfigurationASNConfiguration | AccessRulesCreateRequestConfigurationCountryConfiguration;
export type AccessRulesCreateRequestMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export interface CreateAccessRuleForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** The rule configuration. */
    configuration: AccessRulesCreateRequestConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesCreateRequestMode | (string & {});
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string;
}
export type AccessRulesCreateResponseAllowedModesItem = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export type AccessRulesCreateResponseAllowedModesList = Array<AccessRulesCreateResponseAllowedModesItem>;
export type AccessRulesCreateResponseConfigurationAccessRuleIPConfigurationTarget = "ip";
export interface AccessRulesCreateResponseConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: AccessRulesCreateResponseConfigurationAccessRuleIPConfigurationTarget | null;
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string | null;
}
export type AccessRulesCreateResponseConfigurationIPV6ConfigurationTarget = "ip6";
export interface AccessRulesCreateResponseConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: AccessRulesCreateResponseConfigurationIPV6ConfigurationTarget | null;
    /** The IPv6 address to match. */
    value?: string | null;
}
export type AccessRulesCreateResponseConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export interface AccessRulesCreateResponseConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: AccessRulesCreateResponseConfigurationAccessRuleCIDRConfigurationTarget | null;
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string | null;
}
export type AccessRulesCreateResponseConfigurationASNConfigurationTarget = "asn";
export interface AccessRulesCreateResponseConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: AccessRulesCreateResponseConfigurationASNConfigurationTarget | null;
    /** The AS number to match. */
    value?: string | null;
}
export type AccessRulesCreateResponseConfigurationCountryConfigurationTarget = "country";
export interface AccessRulesCreateResponseConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: AccessRulesCreateResponseConfigurationCountryConfigurationTarget | null;
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string | null;
}
export type AccessRulesCreateResponseConfiguration = AccessRulesCreateResponseConfigurationAccessRuleIPConfiguration | AccessRulesCreateResponseConfigurationIPV6Configuration | AccessRulesCreateResponseConfigurationAccessRuleCIDRConfiguration | AccessRulesCreateResponseConfigurationASNConfiguration | AccessRulesCreateResponseConfigurationCountryConfiguration;
export type AccessRulesCreateResponseMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export type AccessRulesCreateResponseScopeType = "user" | "organization";
export interface AccessRulesCreateResponseScope {
    /** Defines an identifier. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Defines the scope of the rule. */
    type?: AccessRulesCreateResponseScopeType | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAccessRuleResponse {
    /** The unique identifier of the IP Access rule. */
    id: string;
    /** The available actions that a rule can apply to a matched request. */
    allowedModes: AccessRulesCreateResponseAllowedModesList;
    /** The rule configuration. */
    configuration: AccessRulesCreateResponseConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesCreateResponseMode;
    /** The timestamp of when the rule was created. */
    createdOn?: string | null;
    /** The timestamp of when the rule was last modified. */
    modifiedOn?: string | null;
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string | null;
    /** All zones owned by the user will have the rule applied. */
    scope?: AccessRulesCreateResponseScope | null;
}
export interface CreateAccessRuleForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** The rule configuration. */
    configuration: AccessRulesCreateRequestConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesCreateRequestMode | (string & {});
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string;
}
export type LockdownsCreateRequestConfigurationsLockdownIPConfigurationTarget = "ip";
export interface LockdownsCreateRequestConfigurationsLockdownIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the Zone Lockdown rule. */
    target?: LockdownsCreateRequestConfigurationsLockdownIPConfigurationTarget | (string & {}) | null;
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string | null;
}
export type LockdownsCreateRequestConfigurationsLockdownCIDRConfigurationTarget = "ip_range";
export interface LockdownsCreateRequestConfigurationsLockdownCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the Zone Lockdown rule. */
    target?: LockdownsCreateRequestConfigurationsLockdownCIDRConfigurationTarget | (string & {}) | null;
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24`. */
    value?: string | null;
}
export type LockdownsCreateRequestConfigurations = LockdownsCreateRequestConfigurationsLockdownIPConfiguration | LockdownsCreateRequestConfigurationsLockdownCIDRConfiguration;
export type LockdownConfigurationsList = Array<LockdownsCreateRequestConfigurations>;
export type LockdownsCreateRequestUrlsList = Array<string>;
export interface CreateLockdownRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** A list of IP addresses or CIDR ranges that will be allowed to access the URLs specified in the Zone Lockdown rule. You can include any number of `ip` or `ip_range` configurations. */
    configurations: LockdownConfigurationsList;
    /** The URLs to include in the current WAF override. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: LockdownsCreateRequestUrlsList;
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean;
    /** The priority of the rule to control the processing order. A lower number indicates higher priority. If not provided, any rules with a configured priority will be processed before rules without a priority. */
    priority?: number;
}
export type LockdownsCreateResponseUrlsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLockdownResponse {
    /** The unique identifier of the Zone Lockdown rule. */
    id: string;
    /** A list of IP addresses or CIDR ranges that will be allowed to access the URLs specified in the Zone Lockdown rule. You can include any number of `ip` or `ip_range` configurations. */
    configurations: LockdownConfigurationsList;
    /** The timestamp of when the rule was created. */
    createdOn: string;
    /** An informative summary of the rule. */
    description: string;
    /** The timestamp of when the rule was last modified. */
    modifiedOn: string;
    /** When true, indicates that the rule is currently paused. */
    paused: boolean;
    /** The URLs to include in the rule definition. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: LockdownsCreateResponseUrlsList;
    /** The priority of the Zone Lockdown rule, echoed on reads. */
    priority?: number | null;
}
export type RulesCreateRequestActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export interface RulesCreateRequestActionResponse {
    /** The response body to return. The value must conform to the configured content type. */
    body?: string;
    /** The content type of the body. Must be one of the following: `text/plain`, `text/xml`, or `application/json`. */
    contentType?: string;
}
export interface RulesCreateRequestAction {
    /** The action to perform. */
    mode?: RulesCreateRequestActionMode | (string & {});
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. Notes: If you omit this object, Cloudflare will use the default HTML error page. If "mode" is "challenge", "managed_challenge", or "js_challenge", Cloudflare will use the zone challenge pages and you should not provide the "response" object. */
    response?: RulesCreateRequestActionResponse;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. Notes: If "mode" is "challenge", "managed_challenge", or "js_challenge", Cloudflare will use the zone's Challenge Passage time and you should not provide this value. */
    timeout?: number;
}
export interface RulesCreateRequestFilter {
    /** The unique identifier of the filter. */
    id?: string;
    /** An informative summary of the filter. */
    description?: string;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string;
}
export interface CreateRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action: RulesCreateRequestAction;
    filter: RulesCreateRequestFilter;
}
export type RulesCreateResultItemAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export type RulesCreateResultItemFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export type RulesCreateResultItemFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesCreateResultItemFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesCreateResultItemProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export type RulesCreateResultItemProductsList = Array<RulesCreateResultItemProductsItem>;
export interface RulesCreateResultItem {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesCreateResultItemAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesCreateResultItemFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesCreateResultItemProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export type RulesCreateResultList = Array<RulesCreateResultItem>;
export interface CreateRuleResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type UaRulesCreateRequestConfigurationTarget = "ua";
export interface UaRulesCreateRequestConfiguration {
    /** The configuration target. You must set the target to `ua` when specifying a user agent in the rule. */
    target?: UaRulesCreateRequestConfigurationTarget | (string & {});
    /** the user agent to exactly match */
    value?: string;
}
export type UaRulesCreateRequestMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export interface CreateUaRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    configuration: UaRulesCreateRequestConfiguration;
    /** The action to apply to a matched request. */
    mode: UaRulesCreateRequestMode | (string & {});
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean;
}
export interface UaRulesCreateResponseConfiguration {
    /** The configuration target for this rule. You must set the target to `ua` for User Agent Blocking rules. */
    target?: string | null;
    /** The exact user agent string to match. This value will be compared to the received `User-Agent` HTTP header value. */
    value?: string | null;
}
export type UaRulesCreateResponseMode = "block" | "challenge" | "js_challenge" | "managed_challenge";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateUaRuleResponse {
    /** The unique identifier of the User Agent Blocking rule. */
    id?: string | null;
    /** The configuration object for the current rule. */
    configuration?: UaRulesCreateResponseConfiguration | null;
    /** An informative summary of the rule. */
    description?: string | null;
    /** The action to apply to a matched request. */
    mode?: UaRulesCreateResponseMode | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
}
export type WafOverridesCreateRequestUrlsList = Array<string>;
export interface CreateWafOverrideRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The URLs to include in the current WAF override. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: WafOverridesCreateRequestUrlsList;
}
export interface CreateWafOverrideResponse {
}
export interface DeleteAccessRuleForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Unique identifier for a rule. */
    ruleId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAccessRuleResponse {
    /** Defines an identifier. */
    id: string;
}
export interface DeleteAccessRuleForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Unique identifier for a rule. */
    ruleId: string;
}
export interface DeleteLockdownRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the Zone Lockdown rule. */
    lockDownsId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteLockdownResponse {
    /** The unique identifier of the Zone Lockdown rule. */
    id?: string | null;
}
export interface DeleteRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the firewall rule. */
    ruleId: string;
}
export type RulesDeleteResponseAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export type RulesDeleteResponseFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export type RulesDeleteResponseFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesDeleteResponseFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesDeleteResponseProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export type RulesDeleteResponseProductsList = Array<RulesDeleteResponseProductsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRuleResponse {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesDeleteResponseAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesDeleteResponseFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesDeleteResponseProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export interface DeleteUaRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the User Agent Blocking rule. */
    uaRuleId: string;
}
export type UaRulesDeleteResponseConfiguration = UaRulesCreateResponseConfiguration;
export type UaRulesDeleteResponseMode = "block" | "challenge" | "js_challenge" | "managed_challenge";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteUaRuleResponse {
    /** The unique identifier of the User Agent Blocking rule. */
    id?: string | null;
    /** The configuration object for the current rule. */
    configuration?: UaRulesCreateResponseConfiguration | null;
    /** An informative summary of the rule. */
    description?: string | null;
    /** The action to apply to a matched request. */
    mode?: UaRulesDeleteResponseMode | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
}
export interface DeleteWafOverrideRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the WAF override. */
    overridesId: string;
}
export interface DeleteWafOverrideResponse {
}
export interface GetAccessRuleForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Unique identifier for a rule. */
    ruleId: string;
}
export type AccessRulesGetResponseAllowedModesItem = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export type AccessRulesGetResponseAllowedModesList = Array<AccessRulesGetResponseAllowedModesItem>;
export type AccessRulesGetResponseConfigurationAccessRuleIPConfigurationTarget = "ip";
export interface AccessRulesGetResponseConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: AccessRulesGetResponseConfigurationAccessRuleIPConfigurationTarget | null;
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string | null;
}
export type AccessRulesGetResponseConfigurationIPV6ConfigurationTarget = "ip6";
export interface AccessRulesGetResponseConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: AccessRulesGetResponseConfigurationIPV6ConfigurationTarget | null;
    /** The IPv6 address to match. */
    value?: string | null;
}
export type AccessRulesGetResponseConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export interface AccessRulesGetResponseConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: AccessRulesGetResponseConfigurationAccessRuleCIDRConfigurationTarget | null;
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string | null;
}
export type AccessRulesGetResponseConfigurationASNConfigurationTarget = "asn";
export interface AccessRulesGetResponseConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: AccessRulesGetResponseConfigurationASNConfigurationTarget | null;
    /** The AS number to match. */
    value?: string | null;
}
export type AccessRulesGetResponseConfigurationCountryConfigurationTarget = "country";
export interface AccessRulesGetResponseConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: AccessRulesGetResponseConfigurationCountryConfigurationTarget | null;
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string | null;
}
export type AccessRulesGetResponseConfiguration = AccessRulesGetResponseConfigurationAccessRuleIPConfiguration | AccessRulesGetResponseConfigurationIPV6Configuration | AccessRulesGetResponseConfigurationAccessRuleCIDRConfiguration | AccessRulesGetResponseConfigurationASNConfiguration | AccessRulesGetResponseConfigurationCountryConfiguration;
export type AccessRulesGetResponseMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export type AccessRulesGetResponseScopeType = "user" | "organization";
export interface AccessRulesGetResponseScope {
    /** Defines an identifier. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Defines the scope of the rule. */
    type?: AccessRulesGetResponseScopeType | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAccessRuleResponse {
    /** The unique identifier of the IP Access rule. */
    id: string;
    /** The available actions that a rule can apply to a matched request. */
    allowedModes: AccessRulesGetResponseAllowedModesList;
    /** The rule configuration. */
    configuration: AccessRulesGetResponseConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesGetResponseMode;
    /** The timestamp of when the rule was created. */
    createdOn?: string | null;
    /** The timestamp of when the rule was last modified. */
    modifiedOn?: string | null;
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string | null;
    /** All zones owned by the user will have the rule applied. */
    scope?: AccessRulesGetResponseScope | null;
}
export interface GetAccessRuleForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Unique identifier for a rule. */
    ruleId: string;
}
export interface GetLockdownRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the Zone Lockdown rule. */
    lockDownsId: string;
}
export type LockdownsGetResponseUrlsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLockdownResponse {
    /** The unique identifier of the Zone Lockdown rule. */
    id: string;
    /** A list of IP addresses or CIDR ranges that will be allowed to access the URLs specified in the Zone Lockdown rule. You can include any number of `ip` or `ip_range` configurations. */
    configurations: LockdownConfigurationsList;
    /** The timestamp of when the rule was created. */
    createdOn: string;
    /** An informative summary of the rule. */
    description: string;
    /** The timestamp of when the rule was last modified. */
    modifiedOn: string;
    /** When true, indicates that the rule is currently paused. */
    paused: boolean;
    /** The URLs to include in the rule definition. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: LockdownsGetResponseUrlsList;
    /** The priority of the Zone Lockdown rule, echoed on reads. */
    priority?: number | null;
}
export interface GetRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the firewall rule. */
    ruleId: string;
}
export type RulesGetResponseAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export type RulesGetResponseFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export type RulesGetResponseFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesGetResponseFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesGetResponseProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export type RulesGetResponseProductsList = Array<RulesGetResponseProductsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRuleResponse {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesGetResponseAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesGetResponseFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesGetResponseProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export interface GetUaRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the User Agent Blocking rule. */
    uaRuleId: string;
}
export type UaRulesGetResponseConfiguration = UaRulesCreateResponseConfiguration;
export type UaRulesGetResponseMode = "block" | "challenge" | "js_challenge" | "managed_challenge";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUaRuleResponse {
    /** The unique identifier of the User Agent Blocking rule. */
    id?: string | null;
    /** The configuration object for the current rule. */
    configuration?: UaRulesCreateResponseConfiguration | null;
    /** An informative summary of the rule. */
    description?: string | null;
    /** The action to apply to a matched request. */
    mode?: UaRulesGetResponseMode | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
}
export interface GetWafOverrideRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the WAF override. */
    overridesId: string;
}
export interface GetWafOverrideResponse {
}
export interface GetWafPackageRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines a package identifier. */
    packageId: string;
}
export type GetWafPackageResponse = unknown;
export interface GetWafPackageGroupRequest {
    /** Defines an identifier of a schema. */
    zoneId: string;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the unique identifier of a WAF package. */
    groupId: string;
}
export type GetWafPackageGroupResponse = unknown;
export interface GetWafPackageRuleRequest {
    /** Defines an identifier of a schema. */
    zoneId: string;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the unique identifier of a WAF package. */
    ruleId: string;
}
export type GetWafPackageRuleResponse = unknown;
export type AccessRulesListRequestConfigurationTarget = "ip" | "ip_range" | "asn" | "country";
export interface AccessRulesListRequestConfiguration {
    /** Defines the target to search in existing rules. */
    target?: AccessRulesListRequestConfigurationTarget | (string & {});
    /** Defines the target value to search for in existing rules: an IP address, an IP address range, or a country code, depending on the provided `configuration.target`. Notes: You can search for a single IPv4 address, an IP address range with a subnet of '/16' or '/24', or a two-letter ISO-3166-1 alpha-2 country code. */
    value?: string;
}
export type AccessRulesListRequestDirection = "asc" | "desc";
export type AccessRulesListRequestMatch = "any" | "all";
export type AccessRulesListRequestMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export type AccessRulesListRequestOrder = "configuration.target" | "configuration.value" | "mode";
export interface ListAccessRulesForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    configuration?: AccessRulesListRequestConfiguration;
    /** Defines the direction used to sort returned rules. */
    direction?: AccessRulesListRequestDirection | (string & {});
    /** Defines the search requirements. When set to `all`, all the search requirements must match. When set to `any`, only one of the search requirements has to match. */
    match?: AccessRulesListRequestMatch | (string & {});
    /** The action to apply to a matched request. */
    mode?: AccessRulesListRequestMode | (string & {});
    /** Defines the string to search for in the notes of existing IP Access rules. Notes: For example, the string 'attack' would match IP Access rules with notes 'Attack 26/02' and 'Attack 27/02'. The search is case insensitive. */
    notes?: string;
    /** Defines the field used to sort returned rules. */
    order?: AccessRulesListRequestOrder | (string & {});
    /** Defines the requested page within paginated list of results. */
    page?: number;
    /** Defines the maximum number of results requested. */
    perPage?: number;
}
export type AccessRulesListResultItemAllowedModesItem = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export type AccessRulesListResultItemAllowedModesList = Array<AccessRulesListResultItemAllowedModesItem>;
export type AccessRulesListResultItemConfigurationAccessRuleIPConfigurationTarget = "ip";
export interface AccessRulesListResultItemConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: AccessRulesListResultItemConfigurationAccessRuleIPConfigurationTarget | null;
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string | null;
}
export type AccessRulesListResultItemConfigurationIPV6ConfigurationTarget = "ip6";
export interface AccessRulesListResultItemConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: AccessRulesListResultItemConfigurationIPV6ConfigurationTarget | null;
    /** The IPv6 address to match. */
    value?: string | null;
}
export type AccessRulesListResultItemConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export interface AccessRulesListResultItemConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: AccessRulesListResultItemConfigurationAccessRuleCIDRConfigurationTarget | null;
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string | null;
}
export type AccessRulesListResultItemConfigurationASNConfigurationTarget = "asn";
export interface AccessRulesListResultItemConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: AccessRulesListResultItemConfigurationASNConfigurationTarget | null;
    /** The AS number to match. */
    value?: string | null;
}
export type AccessRulesListResultItemConfigurationCountryConfigurationTarget = "country";
export interface AccessRulesListResultItemConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: AccessRulesListResultItemConfigurationCountryConfigurationTarget | null;
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string | null;
}
export type AccessRulesListResultItemConfiguration = AccessRulesListResultItemConfigurationAccessRuleIPConfiguration | AccessRulesListResultItemConfigurationIPV6Configuration | AccessRulesListResultItemConfigurationAccessRuleCIDRConfiguration | AccessRulesListResultItemConfigurationASNConfiguration | AccessRulesListResultItemConfigurationCountryConfiguration;
export type AccessRulesListResultItemMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export type AccessRulesListResultItemScopeType = "user" | "organization";
export interface AccessRulesListResultItemScope {
    /** Defines an identifier. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Defines the scope of the rule. */
    type?: AccessRulesListResultItemScopeType | null;
}
export interface AccessRulesListResultItem {
    /** The unique identifier of the IP Access rule. */
    id: string;
    /** The available actions that a rule can apply to a matched request. */
    allowedModes: AccessRulesListResultItemAllowedModesList;
    /** The rule configuration. */
    configuration: AccessRulesListResultItemConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesListResultItemMode;
    /** The timestamp of when the rule was created. */
    createdOn?: string | null;
    /** The timestamp of when the rule was last modified. */
    modifiedOn?: string | null;
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string | null;
    /** All zones owned by the user will have the rule applied. */
    scope?: AccessRulesListResultItemScope | null;
}
export type AccessRulesListResultList = Array<AccessRulesListResultItem>;
export interface ListAccessRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AccessRulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListAccessRulesForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    configuration?: AccessRulesListRequestConfiguration;
    /** Defines the direction used to sort returned rules. */
    direction?: AccessRulesListRequestDirection | (string & {});
    /** Defines the search requirements. When set to `all`, all the search requirements must match. When set to `any`, only one of the search requirements has to match. */
    match?: AccessRulesListRequestMatch | (string & {});
    /** The action to apply to a matched request. */
    mode?: AccessRulesListRequestMode | (string & {});
    /** Defines the string to search for in the notes of existing IP Access rules. Notes: For example, the string 'attack' would match IP Access rules with notes 'Attack 26/02' and 'Attack 27/02'. The search is case insensitive. */
    notes?: string;
    /** Defines the field used to sort returned rules. */
    order?: AccessRulesListRequestOrder | (string & {});
    /** Defines the requested page within paginated list of results. */
    page?: number;
    /** Defines the maximum number of results requested. */
    perPage?: number;
}
export interface ListLockdownsRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The timestamp of when the rule was created. */
    createdOn?: string;
    /** A string to search for in the description of existing rules. */
    description?: string;
    /** A string to search for in the description of existing rules. */
    descriptionSearch?: string;
    /** A single IP address to search for in existing rules. */
    ip?: string;
    /** A single IP address range to search for in existing rules. */
    ipRangeSearch?: string;
    /** A single IP address to search for in existing rules. */
    ipSearch?: string;
    /** The timestamp of when the rule was last modified. */
    modifiedOn?: string;
    /** Page number of paginated results. */
    page?: number;
    /** The maximum number of results per page. You can only set the value to `1` or to a multiple of 5 such as `5`, `10`, `15`, or `20`. */
    perPage?: number;
    /** The priority of the rule to control the processing order. A lower number indicates higher priority. If not provided, any rules with a configured priority will be processed before rules without a priority. */
    priority?: number;
    /** A single URI to search for in the list of URLs of existing rules. */
    uriSearch?: string;
}
export type LockdownsListResultItemUrlsList = Array<string>;
export interface LockdownsListResultItem {
    /** The unique identifier of the Zone Lockdown rule. */
    id: string;
    /** A list of IP addresses or CIDR ranges that will be allowed to access the URLs specified in the Zone Lockdown rule. You can include any number of `ip` or `ip_range` configurations. */
    configurations: LockdownConfigurationsList;
    /** The timestamp of when the rule was created. */
    createdOn: string;
    /** An informative summary of the rule. */
    description: string;
    /** The timestamp of when the rule was last modified. */
    modifiedOn: string;
    /** When true, indicates that the rule is currently paused. */
    paused: boolean;
    /** The URLs to include in the rule definition. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: LockdownsListResultItemUrlsList;
    /** The priority of the Zone Lockdown rule, echoed on reads. */
    priority?: number | null;
}
export type LockdownsListResultList = Array<LockdownsListResultItem>;
export interface ListLockdownsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LockdownsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListRulesRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the firewall rule. */
    id?: string;
    /** The action to search for. Must be an exact match. */
    action?: string;
    /** A case-insensitive string to find in the description. */
    description?: string;
    /** Page number of paginated results. */
    page?: number;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean;
    /** Number of firewall rules per page. */
    perPage?: number;
}
export type RulesListResultItemAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export type RulesListResultItemFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export type RulesListResultItemFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesListResultItemFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesListResultItemProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export type RulesListResultItemProductsList = Array<RulesListResultItemProductsItem>;
export interface RulesListResultItem {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesListResultItemAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesListResultItemFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesListResultItemProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export type RulesListResultList = Array<RulesListResultItem>;
export interface ListRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListUaRulesRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** A string to search for in the description of existing rules. */
    description?: string;
    /** Page number of paginated results. */
    page?: number;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean;
    /** The maximum number of results per page. You can only set the value to `1` or to a multiple of 5 such as `5`, `10`, `15`, or `20`. */
    perPage?: number;
    /** A string to search for in the user agent values of existing rules. */
    userAgent?: string;
}
export type UaRulesListResultItemConfiguration = UaRulesCreateResponseConfiguration;
export type UaRulesListResultItemMode = "block" | "challenge" | "js_challenge" | "managed_challenge";
export interface UaRulesListResultItem {
    /** The unique identifier of the User Agent Blocking rule. */
    id?: string | null;
    /** The configuration object for the current rule. */
    configuration?: UaRulesCreateResponseConfiguration | null;
    /** An informative summary of the rule. */
    description?: string | null;
    /** The action to apply to a matched request. */
    mode?: UaRulesListResultItemMode | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
}
export type UaRulesListResultList = Array<UaRulesListResultItem>;
export interface ListUaRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UaRulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListWafOverridesRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The page number of paginated results. */
    page?: number;
    /** The number of WAF overrides per page. */
    perPage?: number;
}
export interface ListWafOverridesResponse {
}
export type WafPackagesGroupsListRequestDirection = "asc" | "desc";
export type WafPackagesGroupsListRequestMatch = "any" | "all";
export type WafPackagesGroupsListRequestMode = "on" | "off";
export type WafPackagesGroupsListRequestOrder = "mode" | "rules_count";
export interface ListWafPackageGroupsRequest {
    /** Defines an identifier of a schema. */
    zoneId: string;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the direction used to sort returned rule groups. */
    direction?: WafPackagesGroupsListRequestDirection | (string & {});
    /** Defines the condition for search requirements. When set to `all`, all the search requirements must match. When set to `any`, only one of the search requirements has to match. */
    match?: WafPackagesGroupsListRequestMatch | (string & {});
    /** Defines the state of the rules contained in the rule group. When `on`, the rules in the group are configurable/usable. */
    mode?: WafPackagesGroupsListRequestMode | (string & {});
    /** Defines the name of the rule group. */
    name?: string;
    /** Defines the field used to sort returned rule groups. */
    order?: WafPackagesGroupsListRequestOrder | (string & {});
    /** Defines the page number of paginated results. */
    page?: number;
    /** Defines the number of rule groups per page. */
    perPage?: number;
    /** Defines the number of rules in the current rule group. */
    rulesCount?: number;
}
export type WafPackagesGroupsListResultItemMode = "on" | "off";
export type WafPackagesGroupsListResultItemAllowedModesItem = "on" | "off";
export type WafPackagesGroupsListResultItemAllowedModesList = Array<WafPackagesGroupsListResultItemAllowedModesItem>;
export interface WafPackagesGroupsListResultItem {
    /** Defines the unique identifier of the rule group. */
    id: string;
    /** Defines an informative summary of what the rule group does. */
    description: string;
    /** Defines the state of the rules contained in the rule group. When `on`, the rules in the group are configurable/usable. */
    mode: WafPackagesGroupsListResultItemMode;
    /** Defines the name of the rule group. */
    name: string;
    /** Defines the number of rules in the current rule group. */
    rulesCount: number;
    /** Defines the available states for the rule group. */
    allowedModes?: WafPackagesGroupsListResultItemAllowedModesList | null;
    /** Defines the number of rules within the group that have been modified from their default configuration. */
    modifiedRulesCount?: number | null;
    /** Defines the unique identifier of a WAF package. */
    packageId?: string | null;
}
export type WafPackagesGroupsListResultList = Array<WafPackagesGroupsListResultItem>;
export interface ListWafPackageGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: WafPackagesGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type WafPackagesRulesListRequestDirection = "asc" | "desc";
export type WafPackagesRulesListRequestMatch = "any" | "all";
export type WafPackagesRulesListRequestMode = "DIS" | "CHL" | "BLK" | "SIM";
export type WafPackagesRulesListRequestOrder = "priority" | "group_id" | "description";
export interface ListWafPackageRulesRequest {
    /** Defines an identifier of a schema. */
    zoneId: string;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the public description of the WAF rule. */
    description?: string;
    /** Defines the direction used to sort returned rules. */
    direction?: WafPackagesRulesListRequestDirection | (string & {});
    /** Defines the unique identifier of the rule group. */
    groupId?: string;
    /** Defines the search requirements. When set to `all`, all the search requirements must match. When set to `any`, only one of the search requirements has to match. */
    match?: WafPackagesRulesListRequestMatch | (string & {});
    /** Defines the action/mode a rule has been overridden to perform. */
    mode?: WafPackagesRulesListRequestMode | (string & {});
    /** Defines the field used to sort returned rules. */
    order?: WafPackagesRulesListRequestOrder | (string & {});
    /** Defines the page number of paginated results. */
    page?: number;
    /** Defines the number of rules per page. */
    perPage?: number;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority?: string;
}
export type WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleAllowedModesItem = "on" | "off";
export type WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleAllowedModesList = Array<WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleAllowedModesItem>;
export interface WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup {
    /** Defines the unique identifier of the rule group. */
    id?: string | null;
    /** Defines the name of the rule group. */
    name?: string | null;
}
export type WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleMode = "on" | "off";
export interface WafPackagesRulesListResultItemWAFManagedRulesAnomalyRule {
    /** Defines the unique identifier of the WAF rule. */
    id: string;
    /** Defines the available modes for the current WAF rule. Applies to anomaly detection WAF rules. */
    allowedModes: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleAllowedModesList;
    /** Defines the public description of the WAF rule. */
    description: string;
    /** Defines the rule group to which the current WAF rule belongs. */
    group: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
    /** Defines the mode anomaly. When set to `on`, the current WAF rule will be used when evaluating the request. Applies to anomaly detection WAF rules. */
    mode: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleMode;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority: string;
}
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleAllowedModesItem = "default" | "disable" | "simulate" | "block" | "challenge";
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleAllowedModesList = Array<WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleAllowedModesItem>;
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleDefaultMode = "disable" | "simulate" | "block" | "challenge";
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleGroup = WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleMode = "default" | "disable" | "simulate" | "block" | "challenge";
export interface WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRule {
    /** Defines the unique identifier of the WAF rule. */
    id: string;
    /** Defines the list of possible actions of the WAF rule when it is triggered. */
    allowedModes: WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleAllowedModesList;
    /** Defines the default action/mode of a rule. */
    defaultMode: WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleDefaultMode;
    /** Defines the public description of the WAF rule. */
    description: string;
    /** Defines the rule group to which the current WAF rule belongs. */
    group: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
    /** Defines the action that the current WAF rule will perform when triggered. Applies to traditional (deny) WAF rules. */
    mode: WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleMode;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority: string;
}
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleAllowedModesItem = "on" | "off";
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleAllowedModesList = Array<WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleAllowedModesItem>;
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleGroup = WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleMode = "on" | "off";
export interface WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRule {
    /** Defines the unique identifier of the WAF rule. */
    id: string;
    /** Defines the available modes for the current WAF rule. */
    allowedModes: WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleAllowedModesList;
    /** Defines the public description of the WAF rule. */
    description: string;
    /** Defines the rule group to which the current WAF rule belongs. */
    group: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
    /** When set to `on`, the current rule will be used when evaluating the request. Applies to traditional (allow) WAF rules. */
    mode: WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleMode;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority: string;
}
export type WafPackagesRulesListResultItem = WafPackagesRulesListResultItemWAFManagedRulesAnomalyRule | WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRule | WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRule;
export type WafPackagesRulesListResultList = Array<WafPackagesRulesListResultItem>;
export interface ListWafPackageRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: WafPackagesRulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type WafPackagesListRequestDirection = "asc" | "desc";
export type WafPackagesListRequestMatch = "any" | "all";
export type WafPackagesListRequestOrder = "name";
export interface ListWafPackagesRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The direction used to sort returned packages. */
    direction?: WafPackagesListRequestDirection | (string & {});
    /** When set to `all`, all the search requirements must match. When set to `any`, only one of the search requirements has to match. */
    match?: WafPackagesListRequestMatch | (string & {});
    /** The name of the WAF package. */
    name?: string;
    /** The field used to sort returned packages. */
    order?: WafPackagesListRequestOrder | (string & {});
    /** The page number of paginated results. */
    page?: number;
    /** The number of packages per page. */
    perPage?: number;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListWafPackagesResponse {
}
export type AccessRulesEditRequestConfigurationAccessRuleIPConfigurationTarget = "ip";
export interface AccessRulesEditRequestConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: AccessRulesEditRequestConfigurationAccessRuleIPConfigurationTarget | (string & {});
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string;
}
export type AccessRulesEditRequestConfigurationIPV6ConfigurationTarget = "ip6";
export interface AccessRulesEditRequestConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: AccessRulesEditRequestConfigurationIPV6ConfigurationTarget | (string & {});
    /** The IPv6 address to match. */
    value?: string;
}
export type AccessRulesEditRequestConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export interface AccessRulesEditRequestConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: AccessRulesEditRequestConfigurationAccessRuleCIDRConfigurationTarget | (string & {});
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string;
}
export type AccessRulesEditRequestConfigurationASNConfigurationTarget = "asn";
export interface AccessRulesEditRequestConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: AccessRulesEditRequestConfigurationASNConfigurationTarget | (string & {});
    /** The AS number to match. */
    value?: string;
}
export type AccessRulesEditRequestConfigurationCountryConfigurationTarget = "country";
export interface AccessRulesEditRequestConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: AccessRulesEditRequestConfigurationCountryConfigurationTarget | (string & {});
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string;
}
export type AccessRulesEditRequestConfiguration = AccessRulesEditRequestConfigurationAccessRuleIPConfiguration | AccessRulesEditRequestConfigurationIPV6Configuration | AccessRulesEditRequestConfigurationAccessRuleCIDRConfiguration | AccessRulesEditRequestConfigurationASNConfiguration | AccessRulesEditRequestConfigurationCountryConfiguration;
export type AccessRulesEditRequestMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export interface PatchAccessRuleForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Unique identifier for a rule. */
    ruleId: string;
    /** The rule configuration. */
    configuration: AccessRulesEditRequestConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesEditRequestMode | (string & {});
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string;
}
export type AccessRulesEditResponseAllowedModesItem = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export type AccessRulesEditResponseAllowedModesList = Array<AccessRulesEditResponseAllowedModesItem>;
export type AccessRulesEditResponseConfigurationAccessRuleIPConfigurationTarget = "ip";
export interface AccessRulesEditResponseConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: AccessRulesEditResponseConfigurationAccessRuleIPConfigurationTarget | null;
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string | null;
}
export type AccessRulesEditResponseConfigurationIPV6ConfigurationTarget = "ip6";
export interface AccessRulesEditResponseConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: AccessRulesEditResponseConfigurationIPV6ConfigurationTarget | null;
    /** The IPv6 address to match. */
    value?: string | null;
}
export type AccessRulesEditResponseConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export interface AccessRulesEditResponseConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: AccessRulesEditResponseConfigurationAccessRuleCIDRConfigurationTarget | null;
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string | null;
}
export type AccessRulesEditResponseConfigurationASNConfigurationTarget = "asn";
export interface AccessRulesEditResponseConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: AccessRulesEditResponseConfigurationASNConfigurationTarget | null;
    /** The AS number to match. */
    value?: string | null;
}
export type AccessRulesEditResponseConfigurationCountryConfigurationTarget = "country";
export interface AccessRulesEditResponseConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: AccessRulesEditResponseConfigurationCountryConfigurationTarget | null;
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string | null;
}
export type AccessRulesEditResponseConfiguration = AccessRulesEditResponseConfigurationAccessRuleIPConfiguration | AccessRulesEditResponseConfigurationIPV6Configuration | AccessRulesEditResponseConfigurationAccessRuleCIDRConfiguration | AccessRulesEditResponseConfigurationASNConfiguration | AccessRulesEditResponseConfigurationCountryConfiguration;
export type AccessRulesEditResponseMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export type AccessRulesEditResponseScopeType = "user" | "organization";
export interface AccessRulesEditResponseScope {
    /** Defines an identifier. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Defines the scope of the rule. */
    type?: AccessRulesEditResponseScopeType | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAccessRuleResponse {
    /** The unique identifier of the IP Access rule. */
    id: string;
    /** The available actions that a rule can apply to a matched request. */
    allowedModes: AccessRulesEditResponseAllowedModesList;
    /** The rule configuration. */
    configuration: AccessRulesEditResponseConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesEditResponseMode;
    /** The timestamp of when the rule was created. */
    createdOn?: string | null;
    /** The timestamp of when the rule was last modified. */
    modifiedOn?: string | null;
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string | null;
    /** All zones owned by the user will have the rule applied. */
    scope?: AccessRulesEditResponseScope | null;
}
export interface PatchAccessRuleForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Unique identifier for a rule. */
    ruleId: string;
    /** The rule configuration. */
    configuration: AccessRulesEditRequestConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesEditRequestMode | (string & {});
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string;
}
export interface PatchRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the firewall rule. */
    ruleId: string;
}
export type RulesEditResultItemAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export type RulesEditResultItemFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export type RulesEditResultItemFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesEditResultItemFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesEditResultItemProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export type RulesEditResultItemProductsList = Array<RulesEditResultItemProductsItem>;
export interface RulesEditResultItem {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesEditResultItemAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesEditResultItemFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesEditResultItemProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export type RulesEditResultList = Array<RulesEditResultItem>;
export interface PatchRuleResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesEditResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type WafPackagesGroupsEditRequestMode = "on" | "off";
export interface PatchWafPackageGroupRequest {
    /** Defines an identifier of a schema. */
    zoneId: string;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the unique identifier of a WAF package. */
    groupId: string;
    /** Defines the state of the rules contained in the rule group. When `on`, the rules in the group are configurable/usable. */
    mode?: WafPackagesGroupsEditRequestMode | (string & {});
}
export type PatchWafPackageGroupResponse = unknown;
export type WafPackagesRulesEditRequestMode = "default" | "disable" | "simulate" | "block" | "challenge" | "on" | "off";
export interface PatchWafPackageRuleRequest {
    /** Defines an identifier of a schema. */
    zoneId: string;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the unique identifier of a WAF package. */
    ruleId: string;
    /** Defines the mode/action of the rule when triggered. You must use a value from the `allowed_modes` array of the current rule. */
    mode?: WafPackagesRulesEditRequestMode | (string & {});
}
export type WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleAllowedModesItem = "on" | "off";
export type WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleAllowedModesList = Array<WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleAllowedModesItem>;
export type WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleGroup = WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
export type WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleMode = "on" | "off";
export interface WafPackagesRulesEditResultWAFManagedRulesAnomalyRule {
    /** Defines the unique identifier of the WAF rule. */
    id: string;
    /** Defines the available modes for the current WAF rule. Applies to anomaly detection WAF rules. */
    allowedModes: WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleAllowedModesList;
    /** Defines the public description of the WAF rule. */
    description: string;
    /** Defines the rule group to which the current WAF rule belongs. */
    group: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
    /** Defines the mode anomaly. When set to `on`, the current WAF rule will be used when evaluating the request. Applies to anomaly detection WAF rules. */
    mode: WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleMode;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority: string;
}
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleAllowedModesItem = "default" | "disable" | "simulate" | "block" | "challenge";
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleAllowedModesList = Array<WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleAllowedModesItem>;
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleDefaultMode = "disable" | "simulate" | "block" | "challenge";
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleGroup = WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleMode = "default" | "disable" | "simulate" | "block" | "challenge";
export interface WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRule {
    /** Defines the unique identifier of the WAF rule. */
    id: string;
    /** Defines the list of possible actions of the WAF rule when it is triggered. */
    allowedModes: WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleAllowedModesList;
    /** Defines the default action/mode of a rule. */
    defaultMode: WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleDefaultMode;
    /** Defines the public description of the WAF rule. */
    description: string;
    /** Defines the rule group to which the current WAF rule belongs. */
    group: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
    /** Defines the action that the current WAF rule will perform when triggered. Applies to traditional (deny) WAF rules. */
    mode: WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleMode;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority: string;
}
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleAllowedModesItem = "on" | "off";
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleAllowedModesList = Array<WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleAllowedModesItem>;
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleGroup = WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleMode = "on" | "off";
export interface WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRule {
    /** Defines the unique identifier of the WAF rule. */
    id: string;
    /** Defines the available modes for the current WAF rule. */
    allowedModes: WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleAllowedModesList;
    /** Defines the public description of the WAF rule. */
    description: string;
    /** Defines the rule group to which the current WAF rule belongs. */
    group: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
    /** When set to `on`, the current rule will be used when evaluating the request. Applies to traditional (allow) WAF rules. */
    mode: WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleMode;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority: string;
}
export type WafPackagesRulesEditResult = WafPackagesRulesEditResultWAFManagedRulesAnomalyRule | WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRule | WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRule;
export type PatchWafPackageRuleResponse = WafPackagesRulesEditResult;
export type LockdownsUpdateRequestUrlsList = Array<string>;
export interface UpdateLockdownRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the Zone Lockdown rule. */
    lockDownsId: string;
    /** A list of IP addresses or CIDR ranges that will be allowed to access the URLs specified in the Zone Lockdown rule. You can include any number of `ip` or `ip_range` configurations. */
    configurations: LockdownConfigurationsList;
    /** The URLs to include in the current WAF override. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: LockdownsUpdateRequestUrlsList;
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean;
    /** The priority of the rule to control the processing order. A lower number indicates higher priority. If not provided, any rules with a configured priority will be processed before rules without a priority. */
    priority?: number;
}
export type LockdownsUpdateResponseUrlsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateLockdownResponse {
    /** The unique identifier of the Zone Lockdown rule. */
    id: string;
    /** A list of IP addresses or CIDR ranges that will be allowed to access the URLs specified in the Zone Lockdown rule. You can include any number of `ip` or `ip_range` configurations. */
    configurations: LockdownConfigurationsList;
    /** The timestamp of when the rule was created. */
    createdOn: string;
    /** An informative summary of the rule. */
    description: string;
    /** The timestamp of when the rule was last modified. */
    modifiedOn: string;
    /** When true, indicates that the rule is currently paused. */
    paused: boolean;
    /** The URLs to include in the rule definition. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: LockdownsUpdateResponseUrlsList;
    /** The priority of the Zone Lockdown rule, echoed on reads. */
    priority?: number | null;
}
export type RulesUpdateRequestActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export type RulesUpdateRequestActionResponse = RulesCreateRequestActionResponse;
export interface RulesUpdateRequestAction {
    /** The action to perform. */
    mode?: RulesUpdateRequestActionMode | (string & {});
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. Notes: If you omit this object, Cloudflare will use the default HTML error page. If "mode" is "challenge", "managed_challenge", or "js_challenge", Cloudflare will use the zone challenge pages and you should not provide the "response" object. */
    response?: RulesCreateRequestActionResponse;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. Notes: If "mode" is "challenge", "managed_challenge", or "js_challenge", Cloudflare will use the zone's Challenge Passage time and you should not provide this value. */
    timeout?: number;
}
export type RulesUpdateRequestFilter = RulesCreateRequestFilter;
export interface UpdateRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the firewall rule. */
    ruleId: string;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action: RulesUpdateRequestAction;
    filter: RulesCreateRequestFilter;
}
export type RulesUpdateResponseAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export type RulesUpdateResponseFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export type RulesUpdateResponseFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesUpdateResponseFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export type RulesUpdateResponseProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export type RulesUpdateResponseProductsList = Array<RulesUpdateResponseProductsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRuleResponse {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesUpdateResponseAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesUpdateResponseFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesUpdateResponseProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export type UaRulesUpdateRequestConfigurationAccessRuleIPConfigurationTarget = "ip";
export interface UaRulesUpdateRequestConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: UaRulesUpdateRequestConfigurationAccessRuleIPConfigurationTarget | (string & {});
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string;
}
export type UaRulesUpdateRequestConfigurationIPV6ConfigurationTarget = "ip6";
export interface UaRulesUpdateRequestConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: UaRulesUpdateRequestConfigurationIPV6ConfigurationTarget | (string & {});
    /** The IPv6 address to match. */
    value?: string;
}
export type UaRulesUpdateRequestConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export interface UaRulesUpdateRequestConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: UaRulesUpdateRequestConfigurationAccessRuleCIDRConfigurationTarget | (string & {});
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string;
}
export type UaRulesUpdateRequestConfigurationASNConfigurationTarget = "asn";
export interface UaRulesUpdateRequestConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: UaRulesUpdateRequestConfigurationASNConfigurationTarget | (string & {});
    /** The AS number to match. */
    value?: string;
}
export type UaRulesUpdateRequestConfigurationCountryConfigurationTarget = "country";
export interface UaRulesUpdateRequestConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: UaRulesUpdateRequestConfigurationCountryConfigurationTarget | (string & {});
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string;
}
export type UaRulesUpdateRequestConfiguration = UaRulesUpdateRequestConfigurationAccessRuleIPConfiguration | UaRulesUpdateRequestConfigurationIPV6Configuration | UaRulesUpdateRequestConfigurationAccessRuleCIDRConfiguration | UaRulesUpdateRequestConfigurationASNConfiguration | UaRulesUpdateRequestConfigurationCountryConfiguration;
export type UaRulesUpdateRequestMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export interface UpdateUaRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the User Agent Blocking rule. */
    uaRuleId: string;
    /** The rule configuration. */
    configuration: UaRulesUpdateRequestConfiguration;
    /** The action to apply to a matched request. */
    mode: UaRulesUpdateRequestMode | (string & {});
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean;
}
export type UaRulesUpdateResponseConfiguration = UaRulesCreateResponseConfiguration;
export type UaRulesUpdateResponseMode = "block" | "challenge" | "js_challenge" | "managed_challenge";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateUaRuleResponse {
    /** The unique identifier of the User Agent Blocking rule. */
    id?: string | null;
    /** The configuration object for the current rule. */
    configuration?: UaRulesCreateResponseConfiguration | null;
    /** An informative summary of the rule. */
    description?: string | null;
    /** The action to apply to a matched request. */
    mode?: UaRulesUpdateResponseMode | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
}
export type WafOverridesUpdateRequestRewriteActionBlock = "challenge" | "block" | "simulate" | "disable" | "default";
export type WafOverridesUpdateRequestRewriteActionChallenge = "challenge" | "block" | "simulate" | "disable" | "default";
export type WafOverridesUpdateRequestRewriteActionDefault = "challenge" | "block" | "simulate" | "disable" | "default";
export type WafOverridesUpdateRequestRewriteActionDisable = "challenge" | "block" | "simulate" | "disable" | "default";
export type WafOverridesUpdateRequestRewriteActionSimulate = "challenge" | "block" | "simulate" | "disable" | "default";
export interface WafOverridesUpdateRequestRewriteAction {
    /** The WAF rule action to apply. */
    block?: WafOverridesUpdateRequestRewriteActionBlock | (string & {});
    /** The WAF rule action to apply. */
    challenge?: WafOverridesUpdateRequestRewriteActionChallenge | (string & {});
    /** The WAF rule action to apply. */
    default?: WafOverridesUpdateRequestRewriteActionDefault | (string & {});
    /** The WAF rule action to apply. */
    disable?: WafOverridesUpdateRequestRewriteActionDisable | (string & {});
    /** The WAF rule action to apply. */
    simulate?: WafOverridesUpdateRequestRewriteActionSimulate | (string & {});
}
export type WafOverridesUpdateRequestRules = "challenge" | "block" | "simulate" | "disable" | "default";
export type WafOverridesUpdateRequestUrlsList = Array<string>;
export interface UpdateWafOverrideRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the WAF override. */
    overridesId: string;
    /** Defines an identifier. */
    id: string;
    /** Specifies that, when a WAF rule matches, its configured action will be replaced by the action configured in this object. */
    rewriteAction: WafOverridesUpdateRequestRewriteAction;
    /** An object that allows you to override the action of specific WAF rules. Each key of this object must be the ID of a WAF rule, and each value must be a valid WAF action. Unless you are disabling a rule, ensure that you also enable the rule group that this WAF rule belongs to. When creating a new URI-based WAF override, you must provide a `groups` object or a `rules` object. */
    rules: WafOverridesUpdateRequestRules | (string & {});
    /** The URLs to include in the current WAF override. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: WafOverridesUpdateRequestUrlsList;
}
export interface UpdateWafOverrideResponse {
}
export type BulkDeleteRulesError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Deletes existing firewall rules. */
export declare const bulkDeleteRules: API.PaginatedOperationMethod<BulkDeleteRulesRequest, BulkDeleteRulesResponse, BulkDeleteRulesError, CloudflareOpContext, RulesBulkDeleteResultItem>;
export type BulkPatchRulesError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Updates the priority of existing firewall rules. */
export declare const bulkPatchRules: API.PaginatedOperationMethod<BulkPatchRulesRequest, BulkPatchRulesResponse, BulkPatchRulesError, CloudflareOpContext, RulesBulkEditResultItem>;
export type BulkPutRulesError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Updates one or more existing firewall rules. */
export declare const bulkPutRules: API.PaginatedOperationMethod<BulkPutRulesRequest, BulkPutRulesResponse, BulkPutRulesError, CloudflareOpContext, RulesBulkUpdateResultItem>;
export type CreateAccessRuleForAccountError = DuplicateAccessRule | Forbidden | CloudflareOpError;
/** Creates a new IP Access rule for an account or zone. The rule will apply to all zones in the account or zone. Note: To create an IP Access rule that applies to a single zone, refer to the [IP Access rules for a zone](#ip-access-rules-for-a-zone) endpoints. */
export declare const createAccessRuleForAccount: API.OperationMethod<CreateAccessRuleForAccountRequest, CreateAccessRuleResponse, CreateAccessRuleForAccountError, CloudflareOpContext>;
export type CreateAccessRuleForZoneError = DuplicateAccessRule | Forbidden | CloudflareOpError;
/** Creates a new IP Access rule for an account or zone. The rule will apply to all zones in the account or zone. Note: To create an IP Access rule that applies to a single zone, refer to the [IP Access rules for a zone](#ip-access-rules-for-a-zone) endpoints. */
export declare const createAccessRuleForZone: API.OperationMethod<CreateAccessRuleForZoneRequest, CreateAccessRuleResponse, CreateAccessRuleForZoneError, CloudflareOpContext>;
export type CreateLockdownError = DuplicateLockdown | Forbidden | CloudflareOpError;
/** Creates a new Zone Lockdown rule. */
export declare const createLockdown: API.OperationMethod<CreateLockdownRequest, CreateLockdownResponse, CreateLockdownError, CloudflareOpContext>;
export type CreateRuleError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Create one or more firewall rules. */
export declare const createRule: API.PaginatedOperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, CloudflareOpContext, RulesCreateResultItem>;
export type CreateUaRuleError = DuplicateUaRule | Forbidden | CloudflareOpError;
/** Creates a new User Agent Blocking rule in a zone. */
export declare const createUaRule: API.OperationMethod<CreateUaRuleRequest, CreateUaRuleResponse, CreateUaRuleError, CloudflareOpContext>;
export type CreateWafOverrideError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Previously created a URI-based WAF override for a zone. */
export declare const createWafOverride: API.OperationMethod<CreateWafOverrideRequest, CreateWafOverrideResponse, CreateWafOverrideError, CloudflareOpContext>;
export type DeleteAccessRuleForAccountError = AccessRuleNotFound | Forbidden | CloudflareOpError;
/** Deletes an existing IP Access rule defined. Note: This operation will affect all zones in the account or zone. */
export declare const deleteAccessRuleForAccount: API.OperationMethod<DeleteAccessRuleForAccountRequest, DeleteAccessRuleResponse, DeleteAccessRuleForAccountError, CloudflareOpContext>;
export type DeleteAccessRuleForZoneError = AccessRuleNotFound | Forbidden | CloudflareOpError;
/** Deletes an existing IP Access rule defined. Note: This operation will affect all zones in the account or zone. */
export declare const deleteAccessRuleForZone: API.OperationMethod<DeleteAccessRuleForZoneRequest, DeleteAccessRuleResponse, DeleteAccessRuleForZoneError, CloudflareOpContext>;
export type DeleteLockdownError = LockdownNotFound | Forbidden | CloudflareOpError;
/** Deletes an existing Zone Lockdown rule. */
export declare const deleteLockdown: API.OperationMethod<DeleteLockdownRequest, DeleteLockdownResponse, DeleteLockdownError, CloudflareOpContext>;
export type DeleteRuleError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Deletes an existing firewall rule. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type DeleteUaRuleError = UaRuleNotFound | Forbidden | CloudflareOpError;
/** Deletes an existing User Agent Blocking rule. */
export declare const deleteUaRule: API.OperationMethod<DeleteUaRuleRequest, DeleteUaRuleResponse, DeleteUaRuleError, CloudflareOpContext>;
export type DeleteWafOverrideError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Previously deleted an existing URI-based WAF override. */
export declare const deleteWafOverride: API.OperationMethod<DeleteWafOverrideRequest, DeleteWafOverrideResponse, DeleteWafOverrideError, CloudflareOpContext>;
export type GetAccessRuleForAccountError = AccessRuleNotFound | Forbidden | CloudflareOpError;
/** Fetches the details of an IP Access rule defined. */
export declare const getAccessRuleForAccount: API.OperationMethod<GetAccessRuleForAccountRequest, GetAccessRuleResponse, GetAccessRuleForAccountError, CloudflareOpContext>;
export type GetAccessRuleForZoneError = AccessRuleNotFound | Forbidden | CloudflareOpError;
/** Fetches the details of an IP Access rule defined. */
export declare const getAccessRuleForZone: API.OperationMethod<GetAccessRuleForZoneRequest, GetAccessRuleResponse, GetAccessRuleForZoneError, CloudflareOpContext>;
export type GetLockdownError = LockdownNotFound | Forbidden | CloudflareOpError;
/** Fetches the details of a Zone Lockdown rule. */
export declare const getLockdown: API.OperationMethod<GetLockdownRequest, GetLockdownResponse, GetLockdownError, CloudflareOpContext>;
export type GetRuleError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Fetches the details of a firewall rule. */
export declare const getRule: API.OperationMethod<GetRuleRequest, GetRuleResponse, GetRuleError, CloudflareOpContext>;
export type GetUaRuleError = UaRuleNotFound | Forbidden | CloudflareOpError;
/** Fetches the details of a User Agent Blocking rule. */
export declare const getUaRule: API.OperationMethod<GetUaRuleRequest, GetUaRuleResponse, GetUaRuleError, CloudflareOpContext>;
export type GetWafOverrideError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Previously fetched the details of a URI-based WAF override. */
export declare const getWafOverride: API.OperationMethod<GetWafOverrideRequest, GetWafOverrideResponse, GetWafOverrideError, CloudflareOpContext>;
export type GetWafPackageError = CloudflareOpError;
/** Fetches the details of a WAF package. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const getWafPackage: API.OperationMethod<GetWafPackageRequest, GetWafPackageResponse, GetWafPackageError, CloudflareOpContext>;
export type GetWafPackageGroupError = CloudflareOpError;
/** Fetches the details of a WAF rule group. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const getWafPackageGroup: API.OperationMethod<GetWafPackageGroupRequest, GetWafPackageGroupResponse, GetWafPackageGroupError, CloudflareOpContext>;
export type GetWafPackageRuleError = CloudflareOpError;
/** Fetches the details of a WAF rule in a WAF package. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const getWafPackageRule: API.OperationMethod<GetWafPackageRuleRequest, GetWafPackageRuleResponse, GetWafPackageRuleError, CloudflareOpContext>;
export type ListAccessRulesForAccountError = Forbidden | CloudflareOpError;
/** Fetches IP Access rules of an account or zone. These rules apply to all the zones in the account or zone. You can filter the results using several optional parameters. */
export declare const listAccessRulesForAccount: API.PaginatedOperationMethod<ListAccessRulesForAccountRequest, ListAccessRulesResponse, ListAccessRulesForAccountError, CloudflareOpContext, AccessRulesListResultItem>;
export type ListAccessRulesForZoneError = Forbidden | CloudflareOpError;
/** Fetches IP Access rules of an account or zone. These rules apply to all the zones in the account or zone. You can filter the results using several optional parameters. */
export declare const listAccessRulesForZone: API.PaginatedOperationMethod<ListAccessRulesForZoneRequest, ListAccessRulesResponse, ListAccessRulesForZoneError, CloudflareOpContext, AccessRulesListResultItem>;
export type ListLockdownsError = Forbidden | CloudflareOpError;
/** Fetches Zone Lockdown rules. You can filter the results using several optional parameters. */
export declare const listLockdowns: API.PaginatedOperationMethod<ListLockdownsRequest, ListLockdownsResponse, ListLockdownsError, CloudflareOpContext, LockdownsListResultItem>;
export type ListRulesError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Fetches firewall rules in a zone. You can filter the results using several optional parameters. */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext, RulesListResultItem>;
export type ListUaRulesError = Forbidden | CloudflareOpError;
/** Fetches User Agent Blocking rules in a zone. You can filter the results using several optional parameters. */
export declare const listUaRules: API.PaginatedOperationMethod<ListUaRulesRequest, ListUaRulesResponse, ListUaRulesError, CloudflareOpContext, UaRulesListResultItem>;
export type ListWafOverridesError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Previously fetched the URI-based WAF overrides in a zone. */
export declare const listWafOverrides: API.OperationMethod<ListWafOverridesRequest, ListWafOverridesResponse, ListWafOverridesError, CloudflareOpContext>;
export type ListWafPackageGroupsError = CloudflareOpError;
/** Fetches the WAF rule groups in a WAF package. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const listWafPackageGroups: API.PaginatedOperationMethod<ListWafPackageGroupsRequest, ListWafPackageGroupsResponse, ListWafPackageGroupsError, CloudflareOpContext, WafPackagesGroupsListResultItem>;
export type ListWafPackageRulesError = CloudflareOpError;
/** Fetches WAF rules in a WAF package. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const listWafPackageRules: API.PaginatedOperationMethod<ListWafPackageRulesRequest, ListWafPackageRulesResponse, ListWafPackageRulesError, CloudflareOpContext, WafPackagesRulesListResultItem>;
export type ListWafPackagesError = CloudflareOpError;
/** Fetches WAF packages for a zone. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const listWafPackages: API.OperationMethod<ListWafPackagesRequest, ListWafPackagesResponse, ListWafPackagesError, CloudflareOpContext>;
export type PatchAccessRuleForAccountError = AccessRuleNotFound | Forbidden | CloudflareOpError;
/** Updates an IP Access rule defined. Note: This operation will affect all zones in the account or zone. */
export declare const patchAccessRuleForAccount: API.OperationMethod<PatchAccessRuleForAccountRequest, PatchAccessRuleResponse, PatchAccessRuleForAccountError, CloudflareOpContext>;
export type PatchAccessRuleForZoneError = AccessRuleNotFound | Forbidden | CloudflareOpError;
/** Updates an IP Access rule defined. Note: This operation will affect all zones in the account or zone. */
export declare const patchAccessRuleForZone: API.OperationMethod<PatchAccessRuleForZoneRequest, PatchAccessRuleResponse, PatchAccessRuleForZoneError, CloudflareOpContext>;
export type PatchRuleError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Updates the priority of an existing firewall rule. */
export declare const patchRule: API.PaginatedOperationMethod<PatchRuleRequest, PatchRuleResponse, PatchRuleError, CloudflareOpContext, RulesEditResultItem>;
export type PatchWafPackageGroupError = CloudflareOpError;
/** Updates a WAF rule group. You can update the state (`mode` parameter) of a rule group. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const patchWafPackageGroup: API.OperationMethod<PatchWafPackageGroupRequest, PatchWafPackageGroupResponse, PatchWafPackageGroupError, CloudflareOpContext>;
export type PatchWafPackageRuleError = CloudflareOpError;
/** Updates a WAF rule. You can only update the mode/action of the rule. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const patchWafPackageRule: API.OperationMethod<PatchWafPackageRuleRequest, PatchWafPackageRuleResponse, PatchWafPackageRuleError, CloudflareOpContext>;
export type UpdateLockdownError = LockdownNotFound | DuplicateLockdown | Forbidden | CloudflareOpError;
/** Updates an existing Zone Lockdown rule. */
export declare const updateLockdown: API.OperationMethod<UpdateLockdownRequest, UpdateLockdownResponse, UpdateLockdownError, CloudflareOpContext>;
export type UpdateRuleError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Updates an existing firewall rule. */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, CloudflareOpContext>;
export type UpdateUaRuleError = UaRuleNotFound | DuplicateUaRule | Forbidden | CloudflareOpError;
/** Updates an existing User Agent Blocking rule. */
export declare const updateUaRule: API.OperationMethod<UpdateUaRuleRequest, UpdateUaRuleResponse, UpdateUaRuleError, CloudflareOpContext>;
export type UpdateWafOverrideError = CloudflareOpError;
/** **This endpoint has been deprecated and returns 410 Gone. Please use the [Rulesets API](https://developers.cloudflare.com/ruleset-engine/) instead.** Previously updated an existing URI-based WAF override. */
export declare const updateWafOverride: API.OperationMethod<UpdateWafOverrideRequest, UpdateWafOverrideResponse, UpdateWafOverrideError, CloudflareOpContext>;
//# sourceMappingURL=firewall.d.ts.map