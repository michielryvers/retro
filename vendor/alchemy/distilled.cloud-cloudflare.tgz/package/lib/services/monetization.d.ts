import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface DeleteRuleRequest {
    /** The unique ID of the zone. */
    zoneId: string;
}
export type DeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPriceScheme = "exact" | "upto";
export interface DeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPrice {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** Price in the smallest indivisible unit of the configured payment token, encoded as a decimal string. Must be a canonical decimal integer in [1000, 100000000]: no leading zeros, and a bare JSON number is rejected. The price is required for the fixed-price schemes ("exact" and "upto") and must be at least 1000, the smallest amount the payment facilitator can settle ($0.001 for a 6-decimal token such as USDC), and at most 100000000 ($100 for a 6-decimal token). When the scheme is "origin_controlled" the origin server sets pricing dynamically and the rule carries no price: the field must be omitted -- any provided value, including "0", is rejected because it would not be enforced. Responses always encode this as a string and omit it for "origin_controlled" rules; the pattern matches exactly the set of values the server accepts. */
    price: string;
    /** X402 payment scheme. "exact" requires the specified payment amount; "upto" permits a payment up to the specified amount. Both fixed-price schemes require the price field. */
    scheme: DeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPriceScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
}
export type DeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlledScheme = "origin_controlled";
export interface DeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlled {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** X402 payment scheme. "origin_controlled" lets the origin server set pricing dynamically; the rule carries no price and the price field must be omitted. */
    scheme: DeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlledScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
}
export type DeleteRuleResponseRulesItem = DeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPrice | DeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlled;
export type DeleteRuleResponseRulesList = Array<DeleteRuleResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRuleResponse {
    /** The zone's payment rules, in the order they are evaluated. Empty when the zone has no payment rules. */
    rules: DeleteRuleResponseRulesList;
}
export type EditRuleRequestScheme = "exact" | "upto" | "origin_controlled";
export interface EditRuleRequest {
    /** The unique ID of the zone. */
    zoneId: string;
    ruleId: string;
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The effective address must pass wallet screening whenever the rule is patched. */
    address?: string;
    description?: string;
    enabled?: boolean;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression?: string;
    /** Price in the smallest indivisible unit of the configured payment token, encoded as a decimal string. Must be a canonical decimal integer in [1000, 100000000]: no leading zeros, and a bare JSON number is rejected. The price is required for the fixed-price schemes ("exact" and "upto") and must be at least 1000, the smallest amount the payment facilitator can settle ($0.001 for a 6-decimal token such as USDC), and at most 100000000 ($100 for a 6-decimal token). When the scheme is "origin_controlled" the origin server sets pricing dynamically and the rule carries no price: the field must be omitted -- any provided value, including "0", is rejected because it would not be enforced. Responses always encode this as a string and omit it for "origin_controlled" rules; the pattern matches exactly the set of values the server accepts. */
    price?: string;
    /** X402 payment scheme. "exact" requires the specified payment amount; "upto" permits a payment up to the specified amount; "origin_controlled" lets the origin server set pricing dynamically, in which case the rule carries no price and the price field must be omitted. */
    scheme?: EditRuleRequestScheme | (string & {});
}
export type EditRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPriceScheme = "exact" | "upto";
export interface EditRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPrice {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** Price in the smallest indivisible unit of the configured payment token, encoded as a decimal string. Must be a canonical decimal integer in [1000, 100000000]: no leading zeros, and a bare JSON number is rejected. The price is required for the fixed-price schemes ("exact" and "upto") and must be at least 1000, the smallest amount the payment facilitator can settle ($0.001 for a 6-decimal token such as USDC), and at most 100000000 ($100 for a 6-decimal token). When the scheme is "origin_controlled" the origin server sets pricing dynamically and the rule carries no price: the field must be omitted -- any provided value, including "0", is rejected because it would not be enforced. Responses always encode this as a string and omit it for "origin_controlled" rules; the pattern matches exactly the set of values the server accepts. */
    price: string;
    /** X402 payment scheme. "exact" requires the specified payment amount; "upto" permits a payment up to the specified amount. Both fixed-price schemes require the price field. */
    scheme: EditRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPriceScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
}
export type EditRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlledScheme = "origin_controlled";
export interface EditRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlled {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** X402 payment scheme. "origin_controlled" lets the origin server set pricing dynamically; the rule carries no price and the price field must be omitted. */
    scheme: EditRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlledScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
}
export type EditRuleResponseRulesItem = EditRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPrice | EditRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlled;
export type EditRuleResponseRulesList = Array<EditRuleResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditRuleResponse {
    /** The zone's payment rules, in the order they are evaluated. Empty when the zone has no payment rules. */
    rules: EditRuleResponseRulesList;
}
export interface GetRuleRequest {
    /** The unique ID of the zone. */
    zoneId: string;
}
export type GetRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPriceScheme = "exact" | "upto";
export interface GetRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPrice {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** Price in the smallest indivisible unit of the configured payment token, encoded as a decimal string. Must be a canonical decimal integer in [1000, 100000000]: no leading zeros, and a bare JSON number is rejected. The price is required for the fixed-price schemes ("exact" and "upto") and must be at least 1000, the smallest amount the payment facilitator can settle ($0.001 for a 6-decimal token such as USDC), and at most 100000000 ($100 for a 6-decimal token). When the scheme is "origin_controlled" the origin server sets pricing dynamically and the rule carries no price: the field must be omitted -- any provided value, including "0", is rejected because it would not be enforced. Responses always encode this as a string and omit it for "origin_controlled" rules; the pattern matches exactly the set of values the server accepts. */
    price: string;
    /** X402 payment scheme. "exact" requires the specified payment amount; "upto" permits a payment up to the specified amount. Both fixed-price schemes require the price field. */
    scheme: GetRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPriceScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
}
export type GetRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlledScheme = "origin_controlled";
export interface GetRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlled {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** X402 payment scheme. "origin_controlled" lets the origin server set pricing dynamically; the rule carries no price and the price field must be omitted. */
    scheme: GetRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlledScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
}
export type GetRuleResponseRulesItem = GetRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPrice | GetRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlled;
export type GetRuleResponseRulesList = Array<GetRuleResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRuleResponse {
    /** The zone's payment rules, in the order they are evaluated. Empty when the zone has no payment rules. */
    rules: GetRuleResponseRulesList;
}
export interface RulesDeleteRuleRequest {
    /** The unique ID of the zone. */
    zoneId: string;
    ruleId: string;
}
export type RulesDeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPriceScheme = "exact" | "upto";
export interface RulesDeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPrice {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** Price in the smallest indivisible unit of the configured payment token, encoded as a decimal string. Must be a canonical decimal integer in [1000, 100000000]: no leading zeros, and a bare JSON number is rejected. The price is required for the fixed-price schemes ("exact" and "upto") and must be at least 1000, the smallest amount the payment facilitator can settle ($0.001 for a 6-decimal token such as USDC), and at most 100000000 ($100 for a 6-decimal token). When the scheme is "origin_controlled" the origin server sets pricing dynamically and the rule carries no price: the field must be omitted -- any provided value, including "0", is rejected because it would not be enforced. Responses always encode this as a string and omit it for "origin_controlled" rules; the pattern matches exactly the set of values the server accepts. */
    price: string;
    /** X402 payment scheme. "exact" requires the specified payment amount; "upto" permits a payment up to the specified amount. Both fixed-price schemes require the price field. */
    scheme: RulesDeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPriceScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
}
export type RulesDeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlledScheme = "origin_controlled";
export interface RulesDeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlled {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** X402 payment scheme. "origin_controlled" lets the origin server set pricing dynamically; the rule carries no price and the price field must be omitted. */
    scheme: RulesDeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlledScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
}
export type RulesDeleteRuleResponseRulesItem = RulesDeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPrice | RulesDeleteRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlled;
export type RulesDeleteRuleResponseRulesList = Array<RulesDeleteRuleResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RulesDeleteRuleResponse {
    /** The zone's payment rules, in the order they are evaluated. Empty when the zone has no payment rules. */
    rules: RulesDeleteRuleResponseRulesList;
}
export interface RulesGetRuleRequest {
    /** The unique ID of the zone. */
    zoneId: string;
    ruleId: string;
}
export type RulesGetRuleResultMonetizationRulesMonetizationRuleInputFixedPriceScheme = "exact" | "upto";
export interface RulesGetRuleResultMonetizationRulesMonetizationRuleInputFixedPrice {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** Price in the smallest indivisible unit of the configured payment token, encoded as a decimal string. Must be a canonical decimal integer in [1000, 100000000]: no leading zeros, and a bare JSON number is rejected. The price is required for the fixed-price schemes ("exact" and "upto") and must be at least 1000, the smallest amount the payment facilitator can settle ($0.001 for a 6-decimal token such as USDC), and at most 100000000 ($100 for a 6-decimal token). When the scheme is "origin_controlled" the origin server sets pricing dynamically and the rule carries no price: the field must be omitted -- any provided value, including "0", is rejected because it would not be enforced. Responses always encode this as a string and omit it for "origin_controlled" rules; the pattern matches exactly the set of values the server accepts. */
    price: string;
    /** X402 payment scheme. "exact" requires the specified payment amount; "upto" permits a payment up to the specified amount. Both fixed-price schemes require the price field. */
    scheme: RulesGetRuleResultMonetizationRulesMonetizationRuleInputFixedPriceScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
}
export type RulesGetRuleResultMonetizationRulesMonetizationRuleInputOriginControlledScheme = "origin_controlled";
export interface RulesGetRuleResultMonetizationRulesMonetizationRuleInputOriginControlled {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** X402 payment scheme. "origin_controlled" lets the origin server set pricing dynamically; the rule carries no price and the price field must be omitted. */
    scheme: RulesGetRuleResultMonetizationRulesMonetizationRuleInputOriginControlledScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
}
export type RulesGetRuleResult = RulesGetRuleResultMonetizationRulesMonetizationRuleInputFixedPrice | RulesGetRuleResultMonetizationRulesMonetizationRuleInputOriginControlled;
export type RulesGetRuleResponse = RulesGetRuleResult;
export type UpdateRuleRequestRulesItemMonetizationRuleInputFixedPriceScheme = "exact" | "upto";
export interface UpdateRuleRequestRulesItemMonetizationRuleInputFixedPrice {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** Price in the smallest indivisible unit of the configured payment token, encoded as a decimal string. Must be a canonical decimal integer in [1000, 100000000]: no leading zeros, and a bare JSON number is rejected. The price is required for the fixed-price schemes ("exact" and "upto") and must be at least 1000, the smallest amount the payment facilitator can settle ($0.001 for a 6-decimal token such as USDC), and at most 100000000 ($100 for a 6-decimal token). When the scheme is "origin_controlled" the origin server sets pricing dynamically and the rule carries no price: the field must be omitted -- any provided value, including "0", is rejected because it would not be enforced. Responses always encode this as a string and omit it for "origin_controlled" rules; the pattern matches exactly the set of values the server accepts. */
    price: string;
    /** X402 payment scheme. "exact" requires the specified payment amount; "upto" permits a payment up to the specified amount. Both fixed-price schemes require the price field. */
    scheme: UpdateRuleRequestRulesItemMonetizationRuleInputFixedPriceScheme | (string & {});
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string;
    description?: string;
    enabled?: boolean;
}
export type UpdateRuleRequestRulesItemMonetizationRuleInputOriginControlledScheme = "origin_controlled";
export interface UpdateRuleRequestRulesItemMonetizationRuleInputOriginControlled {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** X402 payment scheme. "origin_controlled" lets the origin server set pricing dynamically; the rule carries no price and the price field must be omitted. */
    scheme: UpdateRuleRequestRulesItemMonetizationRuleInputOriginControlledScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string;
    description?: string;
    enabled?: boolean;
}
export type UpdateRuleRequestRulesItem = UpdateRuleRequestRulesItemMonetizationRuleInputFixedPrice | UpdateRuleRequestRulesItemMonetizationRuleInputOriginControlled;
export type UpdateRuleRequestRulesList = Array<UpdateRuleRequestRulesItem>;
export interface UpdateRuleRequest {
    /** The unique ID of the zone. */
    zoneId: string;
    /** Full desired Payment Required ruleset. An empty array clears all payment rules. The ruleset may contain at most 40 unique wallet addresses; address comparison is case-insensitive. Every address must pass wallet screening before deployment. */
    rules: UpdateRuleRequestRulesList;
}
export type UpdateRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPriceScheme = "exact" | "upto";
export interface UpdateRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPrice {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** Price in the smallest indivisible unit of the configured payment token, encoded as a decimal string. Must be a canonical decimal integer in [1000, 100000000]: no leading zeros, and a bare JSON number is rejected. The price is required for the fixed-price schemes ("exact" and "upto") and must be at least 1000, the smallest amount the payment facilitator can settle ($0.001 for a 6-decimal token such as USDC), and at most 100000000 ($100 for a 6-decimal token). When the scheme is "origin_controlled" the origin server sets pricing dynamically and the rule carries no price: the field must be omitted -- any provided value, including "0", is rejected because it would not be enforced. Responses always encode this as a string and omit it for "origin_controlled" rules; the pattern matches exactly the set of values the server accepts. */
    price: string;
    /** X402 payment scheme. "exact" requires the specified payment amount; "upto" permits a payment up to the specified amount. Both fixed-price schemes require the price field. */
    scheme: UpdateRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPriceScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
}
export type UpdateRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlledScheme = "origin_controlled";
export interface UpdateRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlled {
    /** 0x-prefixed 20-byte hexadecimal Ethereum address. Mixed-case addresses must carry a valid EIP-55 checksum; all-lowercase or all-uppercase addresses are also accepted. The address must pass wallet screening whenever its rule is deployed or patched. */
    address: string;
    /** Wirefilter expression identifying the requests that require payment. Forwarded verbatim to the Rulesets API, which validates its syntax. */
    expression: string;
    /** X402 payment scheme. "origin_controlled" lets the origin server set pricing dynamically; the rule carries no price and the price field must be omitted. */
    scheme: UpdateRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlledScheme;
    /** Optional on input. Include the ID of an existing payment rule to update it in place, preserving its stable identity across the full-ruleset replacement; omit it to create a new rule. An ID that does not match an existing payment rule in the zone is rejected. Rules omitted from the request are deleted. */
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
}
export type UpdateRuleResponseRulesItem = UpdateRuleResponseRulesItemMonetizationRulesMonetizationRuleInputFixedPrice | UpdateRuleResponseRulesItemMonetizationRulesMonetizationRuleInputOriginControlled;
export type UpdateRuleResponseRulesList = Array<UpdateRuleResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRuleResponse {
    /** The zone's payment rules, in the order they are evaluated. Empty when the zone has no payment rules. */
    rules: UpdateRuleResponseRulesList;
}
export type DeleteRuleError = CloudflareOpError;
/** Removes every Payment Required rule from the zone. Any rules the service does not own are preserved. Deleting a zone with no payment rules is a no-op. Returns the resulting (empty) rule collection. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type EditRuleError = CloudflareOpError;
/** Applies a partial update to a single Payment Required rule. Only the fields present in the request body are changed; omitted fields keep their current values. Returns the full resulting rule collection. */
export declare const editRule: API.OperationMethod<EditRuleRequest, EditRuleResponse, EditRuleError, CloudflareOpContext>;
export type GetRuleError = CloudflareOpError;
/** Returns the currently deployed Payment Required rules for a zone. A zone with no Payment Required ruleset returns 404. */
export declare const getRule: API.OperationMethod<GetRuleRequest, GetRuleResponse, GetRuleError, CloudflareOpContext>;
export type RulesDeleteRuleError = CloudflareOpError;
/** Removes a single Payment Required rule identified by its ID. Every other rule is preserved. Returns the resulting rule collection. */
export declare const rulesDeleteRule: API.OperationMethod<RulesDeleteRuleRequest, RulesDeleteRuleResponse, RulesDeleteRuleError, CloudflareOpContext>;
export type RulesGetRuleError = CloudflareOpError;
/** Returns a single Payment Required rule identified by its ID. */
export declare const rulesGetRule: API.OperationMethod<RulesGetRuleRequest, RulesGetRuleResponse, RulesGetRuleError, CloudflareOpContext>;
export type UpdateRuleError = CloudflareOpError;
/** Replaces the zone's Payment Required ruleset with the submitted desired state. Submit an empty rules array to clear all payment rules. */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, CloudflareOpContext>;
//# sourceMappingURL=monetization.d.ts.map