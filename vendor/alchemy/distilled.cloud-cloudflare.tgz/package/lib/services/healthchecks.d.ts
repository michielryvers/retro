import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HealthcheckAlreadyExists_base: S.TaggedErrorClass<"HealthcheckAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HealthcheckAlreadyExists extends /*@__PURE__*/ HealthcheckAlreadyExists_base {
}
declare const HealthcheckNotFound_base: S.TaggedErrorClass<"HealthcheckNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HealthcheckNotFound extends /*@__PURE__*/ HealthcheckNotFound_base {
}
export type CreateRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type CreateRequestCheckRegionsList = Array<CreateRequestCheckRegionsItem | (string & {})>;
export type CreateRequestHttpConfigExpectedCodesList = Array<string>;
export type CreateRequestHttpConfigHeaderValueList = Array<string>;
export type CreateRequestHttpConfigHeaderMap = {
    [key: string]: CreateRequestHttpConfigHeaderValueList | undefined;
};
export type CreateRequestHttpConfigMethod = "GET" | "HEAD";
export interface CreateRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: CreateRequestHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: CreateRequestHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: CreateRequestHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export type CreateRequestTcpConfigMethod = "connection_established";
export interface CreateRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: CreateRequestTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export interface CreateHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: CreateRequestCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    /** A human-readable description of the health check. */
    description?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: CreateRequestHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: CreateRequestTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export type CreateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type CreateResponseCheckRegionsList = Array<CreateResponseCheckRegionsItem>;
export type CreateResponseHttpConfigExpectedCodesList = Array<string>;
export type CreateResponseHttpConfigHeaderValueList = Array<string>;
export type CreateResponseHttpConfigHeaderMap = {
    [key: string]: CreateResponseHttpConfigHeaderValueList | undefined;
};
export type CreateResponseHttpConfigMethod = "GET" | "HEAD";
export interface CreateResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: CreateResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: CreateResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: CreateResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export type CreateResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type CreateResponseTcpConfigMethod = "connection_established";
export interface CreateResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: CreateResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateHealthcheckResponse {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: CreateResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: CreateResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: CreateResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: CreateResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export type PreviewsCreateRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type PreviewsCreateRequestCheckRegionsList = Array<PreviewsCreateRequestCheckRegionsItem | (string & {})>;
export type PreviewsCreateRequestHttpConfigExpectedCodesList = Array<string>;
export type PreviewsCreateRequestHttpConfigHeaderValueList = Array<string>;
export type PreviewsCreateRequestHttpConfigHeaderMap = {
    [key: string]: PreviewsCreateRequestHttpConfigHeaderValueList | undefined;
};
export type PreviewsCreateRequestHttpConfigMethod = "GET" | "HEAD";
export interface PreviewsCreateRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: PreviewsCreateRequestHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: PreviewsCreateRequestHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: PreviewsCreateRequestHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export type PreviewsCreateRequestTcpConfigMethod = "connection_established";
export interface PreviewsCreateRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: PreviewsCreateRequestTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export interface CreatePreviewRequest {
    /** Identifier */
    zoneId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: PreviewsCreateRequestCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    /** A human-readable description of the health check. */
    description?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: PreviewsCreateRequestHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: PreviewsCreateRequestTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export type PreviewsCreateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type PreviewsCreateResponseCheckRegionsList = Array<PreviewsCreateResponseCheckRegionsItem>;
export type PreviewsCreateResponseHttpConfigExpectedCodesList = Array<string>;
export type PreviewsCreateResponseHttpConfigHeaderValueList = Array<string>;
export type PreviewsCreateResponseHttpConfigHeaderMap = {
    [key: string]: PreviewsCreateResponseHttpConfigHeaderValueList | undefined;
};
export type PreviewsCreateResponseHttpConfigMethod = "GET" | "HEAD";
export interface PreviewsCreateResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: PreviewsCreateResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: PreviewsCreateResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: PreviewsCreateResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export type PreviewsCreateResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type PreviewsCreateResponseTcpConfigMethod = "connection_established";
export interface PreviewsCreateResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: PreviewsCreateResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePreviewResponse {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: PreviewsCreateResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: PreviewsCreateResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: PreviewsCreateResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: PreviewsCreateResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export interface DeleteHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteHealthcheckResponse {
    /** Identifier */
    id?: string | null;
}
export interface DeletePreviewRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeletePreviewResponse {
    /** Identifier */
    id?: string | null;
}
export interface GetHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
}
export type GetResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type GetResponseCheckRegionsList = Array<GetResponseCheckRegionsItem>;
export type GetResponseHttpConfigExpectedCodesList = Array<string>;
export type GetResponseHttpConfigHeaderValueList = Array<string>;
export type GetResponseHttpConfigHeaderMap = {
    [key: string]: GetResponseHttpConfigHeaderValueList | undefined;
};
export type GetResponseHttpConfigMethod = "GET" | "HEAD";
export interface GetResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: GetResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: GetResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: GetResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export type GetResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type GetResponseTcpConfigMethod = "connection_established";
export interface GetResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: GetResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHealthcheckResponse {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: GetResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: GetResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: GetResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: GetResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export interface GetPreviewRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
}
export type PreviewsGetResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type PreviewsGetResponseCheckRegionsList = Array<PreviewsGetResponseCheckRegionsItem>;
export type PreviewsGetResponseHttpConfigExpectedCodesList = Array<string>;
export type PreviewsGetResponseHttpConfigHeaderValueList = Array<string>;
export type PreviewsGetResponseHttpConfigHeaderMap = {
    [key: string]: PreviewsGetResponseHttpConfigHeaderValueList | undefined;
};
export type PreviewsGetResponseHttpConfigMethod = "GET" | "HEAD";
export interface PreviewsGetResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: PreviewsGetResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: PreviewsGetResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: PreviewsGetResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export type PreviewsGetResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type PreviewsGetResponseTcpConfigMethod = "connection_established";
export interface PreviewsGetResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: PreviewsGetResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPreviewResponse {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: PreviewsGetResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: PreviewsGetResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: PreviewsGetResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: PreviewsGetResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export interface ListHealthchecksRequest {
    /** Identifier */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. Must be a multiple of 5. */
    perPage?: number;
}
export type ListResultItemCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type ListResultItemCheckRegionsList = Array<ListResultItemCheckRegionsItem>;
export type ListResultItemHttpConfigExpectedCodesList = Array<string>;
export type ListResultItemHttpConfigHeaderValueList = Array<string>;
export type ListResultItemHttpConfigHeaderMap = {
    [key: string]: ListResultItemHttpConfigHeaderValueList | undefined;
};
export type ListResultItemHttpConfigMethod = "GET" | "HEAD";
export interface ListResultItemHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: ListResultItemHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: ListResultItemHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: ListResultItemHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export type ListResultItemStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type ListResultItemTcpConfigMethod = "connection_established";
export interface ListResultItemTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: ListResultItemTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export interface ListResultItem {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: ListResultItemCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: ListResultItemHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: ListResultItemStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: ListResultItemTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListHealthchecksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type EditRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type EditRequestCheckRegionsList = Array<EditRequestCheckRegionsItem | (string & {})>;
export type EditRequestHttpConfigExpectedCodesList = Array<string>;
export type EditRequestHttpConfigHeaderValueList = Array<string>;
export type EditRequestHttpConfigHeaderMap = {
    [key: string]: EditRequestHttpConfigHeaderValueList | undefined;
};
export type EditRequestHttpConfigMethod = "GET" | "HEAD";
export interface EditRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: EditRequestHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: EditRequestHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: EditRequestHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export type EditRequestTcpConfigMethod = "connection_established";
export interface EditRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: EditRequestTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export interface PatchHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: EditRequestCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    /** A human-readable description of the health check. */
    description?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: EditRequestHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: EditRequestTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export type EditResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type EditResponseCheckRegionsList = Array<EditResponseCheckRegionsItem>;
export type EditResponseHttpConfigExpectedCodesList = Array<string>;
export type EditResponseHttpConfigHeaderValueList = Array<string>;
export type EditResponseHttpConfigHeaderMap = {
    [key: string]: EditResponseHttpConfigHeaderValueList | undefined;
};
export type EditResponseHttpConfigMethod = "GET" | "HEAD";
export interface EditResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: EditResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: EditResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: EditResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export type EditResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type EditResponseTcpConfigMethod = "connection_established";
export interface EditResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: EditResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchHealthcheckResponse {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: EditResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: EditResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: EditResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: EditResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export type UpdateRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type UpdateRequestCheckRegionsList = Array<UpdateRequestCheckRegionsItem | (string & {})>;
export type UpdateRequestHttpConfigExpectedCodesList = Array<string>;
export type UpdateRequestHttpConfigHeaderValueList = Array<string>;
export type UpdateRequestHttpConfigHeaderMap = {
    [key: string]: UpdateRequestHttpConfigHeaderValueList | undefined;
};
export type UpdateRequestHttpConfigMethod = "GET" | "HEAD";
export interface UpdateRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: UpdateRequestHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: UpdateRequestHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: UpdateRequestHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export type UpdateRequestTcpConfigMethod = "connection_established";
export interface UpdateRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: UpdateRequestTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export interface UpdateHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: UpdateRequestCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    /** A human-readable description of the health check. */
    description?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: UpdateRequestHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: UpdateRequestTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export type UpdateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type UpdateResponseCheckRegionsList = Array<UpdateResponseCheckRegionsItem>;
export type UpdateResponseHttpConfigExpectedCodesList = Array<string>;
export type UpdateResponseHttpConfigHeaderValueList = Array<string>;
export type UpdateResponseHttpConfigHeaderMap = {
    [key: string]: UpdateResponseHttpConfigHeaderValueList | undefined;
};
export type UpdateResponseHttpConfigMethod = "GET" | "HEAD";
export interface UpdateResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: UpdateResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: UpdateResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: UpdateResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export type UpdateResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type UpdateResponseTcpConfigMethod = "connection_established";
export interface UpdateResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: UpdateResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateHealthcheckResponse {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: UpdateResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: UpdateResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: UpdateResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: UpdateResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export type CreateHealthcheckError = HealthcheckAlreadyExists | Forbidden | CloudflareOpError;
/** Create a new health check. */
export declare const createHealthcheck: API.OperationMethod<CreateHealthcheckRequest, CreateHealthcheckResponse, CreateHealthcheckError, CloudflareOpContext>;
export type CreatePreviewError = CloudflareOpError;
/** Create a new preview health check. */
export declare const createPreview: API.OperationMethod<CreatePreviewRequest, CreatePreviewResponse, CreatePreviewError, CloudflareOpContext>;
export type DeleteHealthcheckError = HealthcheckNotFound | Forbidden | CloudflareOpError;
/** Delete a health check. */
export declare const deleteHealthcheck: API.OperationMethod<DeleteHealthcheckRequest, DeleteHealthcheckResponse, DeleteHealthcheckError, CloudflareOpContext>;
export type DeletePreviewError = CloudflareOpError;
/** Delete a health check. */
export declare const deletePreview: API.OperationMethod<DeletePreviewRequest, DeletePreviewResponse, DeletePreviewError, CloudflareOpContext>;
export type GetHealthcheckError = HealthcheckNotFound | Forbidden | CloudflareOpError;
/** Fetch a single configured health check. */
export declare const getHealthcheck: API.OperationMethod<GetHealthcheckRequest, GetHealthcheckResponse, GetHealthcheckError, CloudflareOpContext>;
export type GetPreviewError = CloudflareOpError;
/** Fetch a single configured health check preview. */
export declare const getPreview: API.OperationMethod<GetPreviewRequest, GetPreviewResponse, GetPreviewError, CloudflareOpContext>;
export type ListHealthchecksError = Forbidden | CloudflareOpError;
/** List configured health checks. */
export declare const listHealthchecks: API.PaginatedOperationMethod<ListHealthchecksRequest, ListHealthchecksResponse, ListHealthchecksError, CloudflareOpContext, ListResultItem>;
export type PatchHealthcheckError = CloudflareOpError;
/** Patch a configured health check. */
export declare const patchHealthcheck: API.OperationMethod<PatchHealthcheckRequest, PatchHealthcheckResponse, PatchHealthcheckError, CloudflareOpContext>;
export type UpdateHealthcheckError = HealthcheckNotFound | Forbidden | CloudflareOpError;
/** Update a configured health check. */
export declare const updateHealthcheck: API.OperationMethod<UpdateHealthcheckRequest, UpdateHealthcheckResponse, UpdateHealthcheckError, CloudflareOpContext>;
//# sourceMappingURL=healthchecks.d.ts.map