import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const DatabaseAlreadyExists_base: S.TaggedErrorClass<"DatabaseAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DatabaseAlreadyExists extends /*@__PURE__*/ DatabaseAlreadyExists_base {
}
declare const DatabaseNotFound_base: S.TaggedErrorClass<"DatabaseNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DatabaseNotFound extends /*@__PURE__*/ DatabaseNotFound_base {
}
declare const InternalError_base: S.TaggedErrorClass<"InternalError", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InternalError extends /*@__PURE__*/ InternalError_base {
}
declare const InvalidObjectIdentifier_base: S.TaggedErrorClass<"InvalidObjectIdentifier", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidObjectIdentifier extends /*@__PURE__*/ InvalidObjectIdentifier_base {
}
declare const InvalidProperty_base: S.TaggedErrorClass<"InvalidProperty", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidProperty extends /*@__PURE__*/ InvalidProperty_base {
}
declare const InvalidRequest_base: S.TaggedErrorClass<"InvalidRequest", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRequest extends /*@__PURE__*/ InvalidRequest_base {
}
declare const NoHistoryAvailable_base: S.TaggedErrorClass<"NoHistoryAvailable", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NoHistoryAvailable extends /*@__PURE__*/ NoHistoryAvailable_base {
}
declare const TimestampTooOld_base: S.TaggedErrorClass<"TimestampTooOld", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TimestampTooOld extends /*@__PURE__*/ TimestampTooOld_base {
}
declare const UnknownError_base: S.TaggedErrorClass<"UnknownError", {
    readonly code: any;
    readonly message: any;
}>;
export declare class UnknownError extends /*@__PURE__*/ UnknownError_base {
}
export type DatabaseCreateRequestJurisdiction = "eu" | "fedramp" | "us";
export type DatabaseCreateRequestPrimaryLocationHint = "wnam" | "enam" | "weur" | "eeur" | "apac" | "oc";
export type DatabaseCreateRequestReadReplicationMode = "auto" | "disabled";
export interface DatabaseCreateRequestReadReplication {
    /** The read replication mode for the database. Use 'auto' to create replicas and allow D1 automatically place them around the world, or 'disabled' to not use any database replicas (it can take a few hours for all replicas to be deleted). */
    mode: DatabaseCreateRequestReadReplicationMode | (string & {});
}
export interface CreateDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database name. */
    name: string;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: DatabaseCreateRequestJurisdiction | (string & {});
    /** Specify the region to create the D1 primary, if available. If this option is omitted, the D1 will be created as close as possible to the current user. */
    primaryLocationHint?: DatabaseCreateRequestPrimaryLocationHint | (string & {});
    /** Configuration for D1 read replication. */
    readReplication?: DatabaseCreateRequestReadReplication;
}
export type DatabaseCreateResponseJurisdiction = "eu" | "fedramp" | "us";
export type DatabaseCreateResponseReadReplicationMode = "auto" | "disabled";
export interface DatabaseCreateResponseReadReplication {
    /** The read replication mode for the database. Mode 'auto' denotes that D1 creates replicas and automatically places them around the world. Mode 'disabled' denotes that no database replicas are used. */
    mode: DatabaseCreateResponseReadReplicationMode;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDatabaseResponse {
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdAt?: string | null;
    /** The D1 database's size, in bytes. */
    fileSize?: number | null;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: DatabaseCreateResponseJurisdiction | null;
    /** D1 database name. */
    name?: string | null;
    /** The number of tables in the D1 database. This count is no longer accurate and should not be relied upon. */
    numTables?: number | null;
    /** Configuration for D1 read replication. */
    readReplication?: DatabaseCreateResponseReadReplication | null;
    /** D1 database identifier (UUID). */
    uuid?: string | null;
    version?: string | null;
}
export interface DeleteDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
}
export type DeleteDatabaseResponse = unknown;
export type DatabaseExportRequestOutputFormat = "polling";
export type DatabaseExportRequestDumpOptionsTablesList = Array<string>;
export interface DatabaseExportRequestDumpOptions {
    /** Export only the table definitions, not their contents */
    noData?: boolean;
    /** Export only each table's contents, not its definition */
    noSchema?: boolean;
    /** Filter the export to just one or more tables. Passing an empty array is the same as not passing anything and means: export all tables. */
    tables?: DatabaseExportRequestDumpOptionsTablesList;
}
export interface ExportDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Specifies that you will poll this endpoint until the export completes */
    outputFormat: DatabaseExportRequestOutputFormat | (string & {});
    /** To poll an in-progress export, provide the current bookmark (returned by your first polling response) */
    currentBookmark?: string;
    dumpOptions?: DatabaseExportRequestDumpOptions;
}
export type DatabaseExportResponseMessagesList = Array<string>;
export interface DatabaseExportResponseResult {
    /** The generated SQL filename. */
    filename?: string | null;
    /** The URL to download the exported SQL. Available for one hour. */
    signedUrl?: string | null;
}
export type DatabaseExportResponseStatus = "complete" | "error";
export type DatabaseExportResponseType = "export";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ExportDatabaseResponse {
    /** The current time-travel bookmark for your D1, used to poll for updates. Will not change for the duration of the export task. */
    atBookmark?: string | null;
    /** Only present when status = 'error'. Contains the error message. */
    error?: string | null;
    /** Logs since the last time you polled */
    messages?: DatabaseExportResponseMessagesList | null;
    /** Only present when status = 'complete' */
    result?: DatabaseExportResponseResult | null;
    status?: DatabaseExportResponseStatus | null;
    success?: boolean | null;
    type?: DatabaseExportResponseType | null;
}
export interface GetBookmarkDatabaseTimeTravelRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** An optional ISO 8601 timestamp. If provided, returns the nearest available bookmark at or before this timestamp. If omitted, returns the current bookmark. */
    timestamp?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBookmarkDatabaseTimeTravelResponse {
    /** A bookmark representing a specific state of the database at a specific point in time. */
    bookmark?: string | null;
}
export type DatabaseGetRequestFields = "uuid" | "name" | "created_at" | "version" | "jurisdiction" | "num_tables" | "file_size" | "running_in_region" | "read_replication";
export type DatabaseGetRequestFieldsList = Array<DatabaseGetRequestFields | (string & {})>;
export interface GetDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Comma-separated list of fields to include in the response. When omitted, all fields are returned. */
    fields?: DatabaseGetRequestFieldsList;
}
export type DatabaseGetResponseJurisdiction = "eu" | "fedramp" | "us";
export type DatabaseGetResponseReadReplicationMode = "auto" | "disabled";
export interface DatabaseGetResponseReadReplication {
    /** The read replication mode for the database. Mode 'auto' denotes that D1 creates replicas and automatically places them around the world. Mode 'disabled' denotes that no database replicas are used. */
    mode: DatabaseGetResponseReadReplicationMode;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDatabaseResponse {
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdAt?: string | null;
    /** The D1 database's size, in bytes. */
    fileSize?: number | null;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: DatabaseGetResponseJurisdiction | null;
    /** D1 database name. */
    name?: string | null;
    /** The number of tables in the D1 database. This count is no longer accurate and should not be relied upon. */
    numTables?: number | null;
    /** Configuration for D1 read replication. */
    readReplication?: DatabaseGetResponseReadReplication | null;
    /** D1 database identifier (UUID). */
    uuid?: string | null;
    version?: string | null;
}
export type DatabaseImportRequestAction = "init" | "ingest" | "poll";
export interface ImportDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Indicates you have a new SQL file to upload. */
    action: DatabaseImportRequestAction | (string & {});
    /** Required when action is 'init' or 'ingest'. An md5 hash of the file you're uploading. Used to check if it already exists, and validate its contents before ingesting. */
    etag?: string;
    /** The filename you have successfully uploaded. */
    filename?: string;
    /** This identifies the currently-running import, checking its status. */
    currentBookmark?: string;
}
export type DatabaseImportResponseMessagesList = Array<string>;
export type DatabaseImportResponseResultMetaServedByRegion = "WNAM" | "ENAM" | "WEUR" | "EEUR" | "APAC" | "OC";
export interface DatabaseImportResponseResultMetaTimings {
    /** The duration of the SQL query execution inside the database. Does not include any network communication. */
    sqlDurationMs?: number | null;
}
export interface DatabaseImportResponseResultMeta {
    /** Denotes if the database has been altered in some way, like deleting rows. */
    changedDb?: boolean | null;
    /** Rough indication of how many rows were modified by the query, as provided by SQLite's `sqlite3_total_changes()`. */
    changes?: number | null;
    /** The duration of the SQL query execution inside the database. Does not include any network communication. */
    duration?: number | null;
    /** The row ID of the last inserted row in a table with an `INTEGER PRIMARY KEY` as provided by SQLite. Tables created with `WITHOUT ROWID` do not populate this. */
    lastRowId?: number | null;
    /** Number of rows read during the SQL query execution, including indices (not all rows are necessarily returned). */
    rowsRead?: number | null;
    /** Number of rows written during the SQL query execution, including indices. */
    rowsWritten?: number | null;
    /** The three letters airport code of the colo that handled the query. */
    servedByColo?: string | null;
    /** Denotes if the query has been handled by the database primary instance. */
    servedByPrimary?: boolean | null;
    /** Region location hint of the database instance that handled the query. */
    servedByRegion?: DatabaseImportResponseResultMetaServedByRegion | null;
    /** Size of the database after the query committed, in bytes. */
    sizeAfter?: number | null;
    /** Various durations for the query. */
    timings?: DatabaseImportResponseResultMetaTimings | null;
}
export interface DatabaseImportResponseResult {
    /** The time-travel bookmark if you need restore your D1 to directly after the import succeeded. */
    finalBookmark?: string | null;
    meta?: DatabaseImportResponseResultMeta | null;
    /** The total number of queries that were executed during the import. */
    numQueries?: number | null;
}
export type DatabaseImportResponseStatus = "complete" | "error";
export type DatabaseImportResponseType = "import";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ImportDatabaseResponse {
    /** The current time-travel bookmark for your D1, used to poll for updates. Will not change for the duration of the import. Only returned if an import process is currently running or recently finished. */
    atBookmark?: string | null;
    /** Only present when status = 'error'. Contains the error message that prevented the import from succeeding. */
    error?: string | null;
    /** Derived from the database ID and etag, to use in avoiding repeated uploads. Only returned when for the 'init' action. */
    filename?: string | null;
    /** Logs since the last time you polled */
    messages?: DatabaseImportResponseMessagesList | null;
    /** Only present when status = 'complete' */
    result?: DatabaseImportResponseResult | null;
    status?: DatabaseImportResponseStatus | null;
    success?: boolean | null;
    type?: DatabaseImportResponseType | null;
    /** The R2 presigned URL to use for uploading. Only returned when for the 'init' action. */
    uploadUrl?: string | null;
}
export interface ListDatabasesRequest {
    /** Account identifier tag. */
    accountId: string;
    /** a database name to search for. */
    name?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
}
export type DatabaseListResultItemJurisdiction = "eu" | "fedramp" | "us";
export interface DatabaseListResultItem {
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdAt?: string | null;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: DatabaseListResultItemJurisdiction | null;
    /** D1 database name. */
    name?: string | null;
    /** D1 database identifier (UUID). */
    uuid?: string | null;
    version?: string | null;
}
export type DatabaseListResultList = Array<DatabaseListResultItem>;
export interface ListDatabasesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DatabaseListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type DatabaseEditRequestReadReplicationMode = "auto" | "disabled";
export interface DatabaseEditRequestReadReplication {
    /** The read replication mode for the database. Use 'auto' to create replicas and allow D1 automatically place them around the world, or 'disabled' to not use any database replicas (it can take a few hours for all replicas to be deleted). */
    mode: DatabaseEditRequestReadReplicationMode | (string & {});
}
export interface PatchDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Configuration for D1 read replication. */
    readReplication?: DatabaseEditRequestReadReplication;
}
export type DatabaseEditResponseJurisdiction = "eu" | "fedramp" | "us";
export type DatabaseEditResponseReadReplicationMode = "auto" | "disabled";
export interface DatabaseEditResponseReadReplication {
    /** The read replication mode for the database. Mode 'auto' denotes that D1 creates replicas and automatically places them around the world. Mode 'disabled' denotes that no database replicas are used. */
    mode: DatabaseEditResponseReadReplicationMode;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchDatabaseResponse {
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdAt?: string | null;
    /** The D1 database's size, in bytes. */
    fileSize?: number | null;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: DatabaseEditResponseJurisdiction | null;
    /** D1 database name. */
    name?: string | null;
    /** The number of tables in the D1 database. This count is no longer accurate and should not be relied upon. */
    numTables?: number | null;
    /** Configuration for D1 read replication. */
    readReplication?: DatabaseEditResponseReadReplication | null;
    /** D1 database identifier (UUID). */
    uuid?: string | null;
    version?: string | null;
}
export type DatabaseQueryRequestParamsList = Array<unknown>;
export type DatabaseQueryRequestBatchItemParamsList = Array<unknown>;
export interface DatabaseQueryRequestBatchItem {
    /** Your SQL query. Supports multiple statements, joined by semicolons, which will be executed as a batch. */
    sql: string;
    params?: DatabaseQueryRequestBatchItemParamsList;
}
export type DatabaseQueryRequestBatchList = Array<DatabaseQueryRequestBatchItem>;
export interface QueryDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Your SQL query. Supports multiple statements, joined by semicolons, which will be executed as a batch. */
    sql?: string;
    params?: DatabaseQueryRequestParamsList;
    batch?: DatabaseQueryRequestBatchList;
}
export type DatabaseQueryResultItemMetaServedByRegion = "WNAM" | "ENAM" | "WEUR" | "EEUR" | "APAC" | "OC";
export type DatabaseQueryResultItemMetaTimings = DatabaseImportResponseResultMetaTimings;
export interface DatabaseQueryResultItemMeta {
    /** Denotes if the database has been altered in some way, like deleting rows. */
    changedDb?: boolean | null;
    /** Rough indication of how many rows were modified by the query, as provided by SQLite's `sqlite3_total_changes()`. */
    changes?: number | null;
    /** The duration of the SQL query execution inside the database. Does not include any network communication. */
    duration?: number | null;
    /** The row ID of the last inserted row in a table with an `INTEGER PRIMARY KEY` as provided by SQLite. Tables created with `WITHOUT ROWID` do not populate this. */
    lastRowId?: number | null;
    /** Number of rows read during the SQL query execution, including indices (not all rows are necessarily returned). */
    rowsRead?: number | null;
    /** Number of rows written during the SQL query execution, including indices. */
    rowsWritten?: number | null;
    /** The three letters airport code of the colo that handled the query. */
    servedByColo?: string | null;
    /** Denotes if the query has been handled by the database primary instance. */
    servedByPrimary?: boolean | null;
    /** Region location hint of the database instance that handled the query. */
    servedByRegion?: DatabaseQueryResultItemMetaServedByRegion | null;
    /** Size of the database after the query committed, in bytes. */
    sizeAfter?: number | null;
    /** Various durations for the query. */
    timings?: DatabaseImportResponseResultMetaTimings | null;
}
export type DatabaseQueryResultItemResultsList = Array<unknown>;
export interface DatabaseQueryResultItem {
    meta?: DatabaseQueryResultItemMeta | null;
    results?: DatabaseQueryResultItemResultsList | null;
    success?: boolean | null;
}
export type DatabaseQueryResultList = Array<DatabaseQueryResultItem>;
export interface QueryDatabaseResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DatabaseQueryResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type DatabaseRawRequestParamsList = Array<unknown>;
export type DatabaseRawRequestBatchItemParamsList = Array<unknown>;
export interface DatabaseRawRequestBatchItem {
    /** Your SQL query. Supports multiple statements, joined by semicolons, which will be executed as a batch. */
    sql: string;
    params?: DatabaseRawRequestBatchItemParamsList;
}
export type DatabaseRawRequestBatchList = Array<DatabaseRawRequestBatchItem>;
export interface RawDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Your SQL query. Supports multiple statements, joined by semicolons, which will be executed as a batch. */
    sql?: string;
    params?: DatabaseRawRequestParamsList;
    batch?: DatabaseRawRequestBatchList;
}
export type DatabaseRawResultItemMetaServedByRegion = "WNAM" | "ENAM" | "WEUR" | "EEUR" | "APAC" | "OC";
export type DatabaseRawResultItemMetaTimings = DatabaseImportResponseResultMetaTimings;
export interface DatabaseRawResultItemMeta {
    /** Denotes if the database has been altered in some way, like deleting rows. */
    changedDb?: boolean | null;
    /** Rough indication of how many rows were modified by the query, as provided by SQLite's `sqlite3_total_changes()`. */
    changes?: number | null;
    /** The duration of the SQL query execution inside the database. Does not include any network communication. */
    duration?: number | null;
    /** The row ID of the last inserted row in a table with an `INTEGER PRIMARY KEY` as provided by SQLite. Tables created with `WITHOUT ROWID` do not populate this. */
    lastRowId?: number | null;
    /** Number of rows read during the SQL query execution, including indices (not all rows are necessarily returned). */
    rowsRead?: number | null;
    /** Number of rows written during the SQL query execution, including indices. */
    rowsWritten?: number | null;
    /** The three letters airport code of the colo that handled the query. */
    servedByColo?: string | null;
    /** Denotes if the query has been handled by the database primary instance. */
    servedByPrimary?: boolean | null;
    /** Region location hint of the database instance that handled the query. */
    servedByRegion?: DatabaseRawResultItemMetaServedByRegion | null;
    /** Size of the database after the query committed, in bytes. */
    sizeAfter?: number | null;
    /** Various durations for the query. */
    timings?: DatabaseImportResponseResultMetaTimings | null;
}
export type DatabaseRawResultItemResultsColumnsList = Array<string>;
export type DatabaseRawResultItemResultsRowsList = Array<unknown>;
export interface DatabaseRawResultItemResults {
    columns?: DatabaseRawResultItemResultsColumnsList | null;
    rows?: DatabaseRawResultItemResultsRowsList | null;
}
export interface DatabaseRawResultItem {
    meta?: DatabaseRawResultItemMeta | null;
    results?: DatabaseRawResultItemResults | null;
    success?: boolean | null;
}
export type DatabaseRawResultList = Array<DatabaseRawResultItem>;
export interface RawDatabaseResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DatabaseRawResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface RestoreDatabaseTimeTravelRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** A bookmark to restore the database to. Required if `timestamp` is not provided. */
    bookmark?: string;
    /** An ISO 8601 timestamp to restore the database to. Required if `bookmark` is not provided. */
    timestamp?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RestoreDatabaseTimeTravelResponse {
    /** The new bookmark representing the state of the database after the restore operation. */
    bookmark?: string | null;
    /** A message describing the result of the restore operation. */
    message?: string | null;
    /** The bookmark representing the state of the database before the restore operation. Can be used to undo the restore if needed. */
    previousBookmark?: string | null;
}
export interface UndeleteDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Restore the database with this name instead of the name it had when it was deleted. Required if another database in the account already uses that name. */
    newName?: string;
}
export type UndeleteDatabaseResponseJurisdiction = "eu" | "fedramp" | "us";
export type UndeleteDatabaseResponseReadReplicationMode = "auto" | "disabled";
export interface UndeleteDatabaseResponseReadReplication {
    /** The read replication mode for the database. Mode 'auto' denotes that D1 creates replicas and automatically places them around the world. Mode 'disabled' denotes that no database replicas are used. */
    mode: UndeleteDatabaseResponseReadReplicationMode;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UndeleteDatabaseResponse {
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdAt?: string | null;
    /** The D1 database's size, in bytes. */
    fileSize?: number | null;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: UndeleteDatabaseResponseJurisdiction | null;
    /** D1 database name. */
    name?: string | null;
    /** The number of tables in the D1 database. This count is no longer accurate and should not be relied upon. */
    numTables?: number | null;
    /** Configuration for D1 read replication. */
    readReplication?: UndeleteDatabaseResponseReadReplication | null;
    /** D1 database identifier (UUID). */
    uuid?: string | null;
    version?: string | null;
}
export type DatabaseUpdateRequestReadReplicationMode = "auto" | "disabled";
export interface DatabaseUpdateRequestReadReplication {
    /** The read replication mode for the database. Use 'auto' to create replicas and allow D1 automatically place them around the world, or 'disabled' to not use any database replicas (it can take a few hours for all replicas to be deleted). */
    mode: DatabaseUpdateRequestReadReplicationMode | (string & {});
}
export interface UpdateDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Configuration for D1 read replication. */
    readReplication: DatabaseUpdateRequestReadReplication;
}
export type DatabaseUpdateResponseJurisdiction = "eu" | "fedramp" | "us";
export type DatabaseUpdateResponseReadReplicationMode = "auto" | "disabled";
export interface DatabaseUpdateResponseReadReplication {
    /** The read replication mode for the database. Mode 'auto' denotes that D1 creates replicas and automatically places them around the world. Mode 'disabled' denotes that no database replicas are used. */
    mode: DatabaseUpdateResponseReadReplicationMode;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateDatabaseResponse {
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdAt?: string | null;
    /** The D1 database's size, in bytes. */
    fileSize?: number | null;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: DatabaseUpdateResponseJurisdiction | null;
    /** D1 database name. */
    name?: string | null;
    /** The number of tables in the D1 database. This count is no longer accurate and should not be relied upon. */
    numTables?: number | null;
    /** Configuration for D1 read replication. */
    readReplication?: DatabaseUpdateResponseReadReplication | null;
    /** D1 database identifier (UUID). */
    uuid?: string | null;
    version?: string | null;
}
export type CreateDatabaseError = InvalidObjectIdentifier | InvalidProperty | DatabaseAlreadyExists | CloudflareOpError;
/** Create a new D1 database in your account. */
export declare const createDatabase: API.OperationMethod<CreateDatabaseRequest, CreateDatabaseResponse, CreateDatabaseError, CloudflareOpContext>;
export type DeleteDatabaseError = InvalidObjectIdentifier | DatabaseNotFound | UnknownError | CloudflareOpError;
/** Delete a D1 database. */
export declare const deleteDatabase: API.OperationMethod<DeleteDatabaseRequest, DeleteDatabaseResponse, DeleteDatabaseError, CloudflareOpContext>;
export type ExportDatabaseError = InvalidObjectIdentifier | InvalidRequest | DatabaseNotFound | CloudflareOpError;
/** Export the SQL contents of a D1 database and return a URL where they can be downloaded. Note: this process may take some time for larger DBs, during which your D1 will be unavailable to serve queries. To avoid blocking your DB unnecessarily, an in-progress export must be continually polled or will automatically cancel. */
export declare const exportDatabase: API.OperationMethod<ExportDatabaseRequest, ExportDatabaseResponse, ExportDatabaseError, CloudflareOpContext>;
export type GetBookmarkDatabaseTimeTravelError = InvalidObjectIdentifier | NoHistoryAvailable | TimestampTooOld | DatabaseNotFound | CloudflareOpError;
/** Retrieve the current bookmark, or the nearest bookmark at or before a provided timestamp. Bookmarks can be used with the restore endpoint to revert the database to a previous point in time. */
export declare const getBookmarkDatabaseTimeTravel: API.OperationMethod<GetBookmarkDatabaseTimeTravelRequest, GetBookmarkDatabaseTimeTravelResponse, GetBookmarkDatabaseTimeTravelError, CloudflareOpContext>;
export type GetDatabaseError = InvalidObjectIdentifier | DatabaseNotFound | UnknownError | CloudflareOpError;
/** Get details for a specific D1 database. */
export declare const getDatabase: API.OperationMethod<GetDatabaseRequest, GetDatabaseResponse, GetDatabaseError, CloudflareOpContext>;
export type ImportDatabaseError = InvalidObjectIdentifier | CloudflareOpError;
/** Generate a temporary URL for uploading an SQL file to, then instruct the D1 to import it and poll it for status updates. Imports block the D1 for their duration. */
export declare const importDatabase: API.OperationMethod<ImportDatabaseRequest, ImportDatabaseResponse, ImportDatabaseError, CloudflareOpContext>;
export type ListDatabasesError = CloudflareOpError;
/** List D1 databases in your account. */
export declare const listDatabases: API.PaginatedOperationMethod<ListDatabasesRequest, ListDatabasesResponse, ListDatabasesError, CloudflareOpContext, DatabaseListResultItem>;
export type PatchDatabaseError = InvalidObjectIdentifier | InternalError | DatabaseNotFound | CloudflareOpError;
/** Partially update a D1 database's configuration. */
export declare const patchDatabase: API.OperationMethod<PatchDatabaseRequest, PatchDatabaseResponse, PatchDatabaseError, CloudflareOpContext>;
export type QueryDatabaseError = CloudflareOpError;
/** Execute a SQL query against a D1 database and return results as objects. */
export declare const queryDatabase: API.PaginatedOperationMethod<QueryDatabaseRequest, QueryDatabaseResponse, QueryDatabaseError, CloudflareOpContext, DatabaseQueryResultItem>;
export type RawDatabaseError = CloudflareOpError;
/** Execute a SQL query against a D1 database and return result rows as arrays rather than objects. This is a performance-optimized version of the /query endpoint. */
export declare const rawDatabase: API.PaginatedOperationMethod<RawDatabaseRequest, RawDatabaseResponse, RawDatabaseError, CloudflareOpContext, DatabaseRawResultItem>;
export type RestoreDatabaseTimeTravelError = InvalidObjectIdentifier | NoHistoryAvailable | DatabaseNotFound | InvalidProperty | CloudflareOpError;
/** Restore a D1 database to a previous point in time either via a bookmark or a timestamp. */
export declare const restoreDatabaseTimeTravel: API.OperationMethod<RestoreDatabaseTimeTravelRequest, RestoreDatabaseTimeTravelResponse, RestoreDatabaseTimeTravelError, CloudflareOpContext>;
export type UndeleteDatabaseError = CloudflareOpError;
/** Restore a deleted D1 database. The database is restored with the name it had when it was deleted, unless `new_name` is provided. The restored database counts against the account's limits. Undeleting a database that is not deleted succeeds without changes, unless `new_name` differs from its current name which errors. Once a database is undeleted, Time Travel (point-in-time recovery) cannot restore it to a bookmark or timestamp at or before the undeletion. Only states after the undeletion can be restored. */
export declare const undeleteDatabase: API.OperationMethod<UndeleteDatabaseRequest, UndeleteDatabaseResponse, UndeleteDatabaseError, CloudflareOpContext>;
export type UpdateDatabaseError = InvalidObjectIdentifier | InternalError | DatabaseNotFound | CloudflareOpError;
/** Update a D1 database's configuration. */
export declare const updateDatabase: API.OperationMethod<UpdateDatabaseRequest, UpdateDatabaseResponse, UpdateDatabaseError, CloudflareOpContext>;
//# sourceMappingURL=d1.d.ts.map