import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface AddressValidationRequest {
    /** Address line 1. */
    address?: string;
    /** Address line 2. */
    address2?: string;
    /** City. */
    city?: string;
    /** Country code. */
    country?: string;
    /** State or province. */
    state?: string;
    /** Postal or zip code. */
    zipcode?: string;
}
export interface AddressValidationResponseValidatedAddressesItem {
    /** Validated address line 1. */
    address?: string | null;
    /** Validated address line 2. */
    address2?: string | null;
    /** Validated city. */
    city?: string | null;
    /** Validated country code. */
    country?: string | null;
    /** Validated state or province. */
    state?: string | null;
    /** The validation result code. */
    validationCode?: string | null;
    /** Validated postal or zip code. */
    zipcode?: string | null;
}
export type AddressValidationResponseValidatedAddressesList = Array<AddressValidationResponseValidatedAddressesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface AddressValidationResponse {
    /** List of validated address suggestions. */
    validatedAddresses?: AddressValidationResponseValidatedAddressesList | null;
}
export interface CreateProfileRequest {
    /** Identifier */
    accountId: string;
    /** Street address line 1. */
    address?: string;
    /** Street address line 2 (apt, suite, etc.). */
    address2?: string;
    /** Primary billing email address. */
    billingEmail?: string;
    /** Rate plan being purchased right after profile setup. */
    buyingRatePlan?: string;
    /** Captcha challenge JWT issued during onboarding. */
    captchaChallengeJwt?: string;
    /** Cloudflare Turnstile response. */
    cfTurnstileResponse?: string;
    /** City on the billing profile. */
    city?: string;
    /** Company name on the billing profile. */
    company?: string;
    /** ISO 3166-1 alpha-2 country code. */
    country?: string;
    /** First name on the billing profile. */
    firstName?: string;
    /** hCaptcha response. */
    hCaptchaResponse?: string;
    /** Last name on the billing profile. */
    lastName?: string;
    /** Preferred locale for invoice rendering (BCP 47). */
    preferredLocale?: string;
    /** Secondary billing email address for CC on invoices. */
    secondaryBillingEmail?: string;
    /** State or region on the billing profile. */
    state?: string;
    /** Type of tax ID provided. */
    taxIdType?: string;
    /** Contact phone number. */
    telephone?: string;
    /** VAT identifier. */
    vat?: string;
    /** ZIP or postal code. */
    zipcode?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProfileResponse {
    /** Billing item identifier tag. */
    id?: string | null;
    accountType?: string | null;
    address?: string | null;
    address2?: string | null;
    balance?: string | null;
    cardExpiryMonth?: number | null;
    cardExpiryYear?: number | null;
    cardNumber?: string | null;
    city?: string | null;
    company?: string | null;
    country?: string | null;
    createdOn?: string | null;
    deviceData?: string | null;
    editedOn?: string | null;
    enterpriseBillingEmail?: string | null;
    enterprisePrimaryEmail?: string | null;
    firstName?: string | null;
    isPartner?: boolean | null;
    lastName?: string | null;
    nextBillDate?: string | null;
    paymentAddress?: string | null;
    paymentAddress2?: string | null;
    paymentCity?: string | null;
    paymentCountry?: string | null;
    paymentEmail?: string | null;
    paymentFirstName?: string | null;
    paymentGateway?: string | null;
    paymentLastName?: string | null;
    paymentNonce?: string | null;
    paymentState?: string | null;
    paymentZipcode?: string | null;
    primaryEmail?: string | null;
    state?: string | null;
    taxIdType?: string | null;
    telephone?: string | null;
    validationCode?: string | null;
    vat?: string | null;
    zipcode?: string | null;
}
export interface CreateProfilesPaymentMethodRequest {
    /** Identifier */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProfilesPaymentMethodResponse {
    /** The Stripe client secret for frontend payment method collection. */
    clientSecret?: string | null;
    /** The type of Stripe intent created. */
    intentType?: string | null;
}
export interface DeleteProfileRequest {
    /** Identifier */
    accountId: string;
}
export interface DeleteProfileResponse {
}
export interface GetBadDebtRequest {
    /** Identifier */
    accountId: string;
}
export interface GetBadDebtResponseInvoicesItem {
    /** Billing history item identifier. */
    id?: string | null;
    /** The billing item action. */
    action?: string | null;
    /** The amount associated with this billing item. */
    amount?: number | null;
    /** The amount remaining to pay. */
    amountToPay?: number | null;
    /** The currency of the billing item. */
    currency?: string | null;
    /** The billing item description. */
    description?: string | null;
    /** The external invoice identifier. */
    externalInvoiceId?: string | null;
    /** URL to the hosted invoice. */
    hostedInvoiceUrl?: string | null;
    /** The associated invoice identifier. */
    invoiceId?: string | null;
    /** When the billing event occurred. */
    occurredAt?: string | null;
    /** The associated receipt identifier. */
    receiptId?: string | null;
    /** The source of the billing item. */
    source?: string | null;
    /** The source invoice identifier. */
    sourceInvoiceId?: string | null;
    /** The status of the billing item. */
    status?: string | null;
    /** The billing item type. */
    type?: string | null;
}
export type GetBadDebtResponseInvoicesList = Array<GetBadDebtResponseInvoicesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBadDebtResponse {
    /** Amount already paid towards the debt. */
    alreadyPaid?: number | null;
    /** The current bad debt status of the account. */
    badDebtStatus?: string | null;
    /** List of outstanding invoices contributing to bad debt. */
    invoices?: GetBadDebtResponseInvoicesList | null;
    /** Total outstanding debt amount. */
    totalDebtAmount?: number | null;
}
export interface GetCreditRequest {
    /** Identifier */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCreditResponse {
    /** The confirmed credit balance in cents. */
    confirmedBalanceCents?: number | null;
    /** Currency of the credit balance. */
    currency?: string | null;
    /** Days remaining until the credits expire. */
    daysRemaining?: number | null;
    /** Whether the account is eligible to receive credits. */
    eligible?: boolean | null;
    /** Whether a credit record exists for the account. */
    hasRecord?: boolean | null;
    /** The original credit amount in cents. */
    originalAmountCents?: number | null;
    /** Percentage of the original credit amount consumed. */
    percentConsumed?: number | null;
    /** Projected date when the credits will be depleted. */
    projectedDepletionDate?: string | null;
    /** When the credits become valid. */
    validFrom?: string | null;
    /** When the credits expire. */
    validTo?: string | null;
}
export interface GetProfileRequest {
    /** Identifier */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetProfileResponse {
    /** Billing item identifier tag. */
    id?: string | null;
    accountType?: string | null;
    address?: string | null;
    address2?: string | null;
    balance?: string | null;
    cardExpiryMonth?: number | null;
    cardExpiryYear?: number | null;
    cardNumber?: string | null;
    city?: string | null;
    company?: string | null;
    country?: string | null;
    createdOn?: string | null;
    deviceData?: string | null;
    editedOn?: string | null;
    enterpriseBillingEmail?: string | null;
    enterprisePrimaryEmail?: string | null;
    firstName?: string | null;
    isPartner?: boolean | null;
    lastName?: string | null;
    nextBillDate?: string | null;
    paymentAddress?: string | null;
    paymentAddress2?: string | null;
    paymentCity?: string | null;
    paymentCountry?: string | null;
    paymentEmail?: string | null;
    paymentFirstName?: string | null;
    paymentGateway?: string | null;
    paymentLastName?: string | null;
    paymentNonce?: string | null;
    paymentState?: string | null;
    paymentZipcode?: string | null;
    primaryEmail?: string | null;
    state?: string | null;
    taxIdType?: string | null;
    telephone?: string | null;
    validationCode?: string | null;
    vat?: string | null;
    zipcode?: string | null;
}
export interface GetRatePlanRequest {
    publicKey: string;
}
export type GetRatePlanResponseComponentsItemMap = {
    [key: string]: unknown | undefined;
};
export type GetRatePlanResponseComponentsList = Array<GetRatePlanResponseComponentsItemMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRatePlanResponse {
    /** The uppercase rate plan public key. */
    id?: string | null;
    /** Pricing components that make up this rate plan. */
    components?: GetRatePlanResponseComponentsList | null;
    /** Currency of the rate plan pricing. */
    currency?: string | null;
    /** Human-readable description of the rate plan. */
    publicName?: string | null;
}
export interface GetUnpaidInvoiceRequest {
    /** Identifier */
    accountId: string;
}
export type GetUnpaidInvoiceResponseInvoicesItem = GetBadDebtResponseInvoicesItem;
export type GetUnpaidInvoiceResponseInvoicesList = Array<GetBadDebtResponseInvoicesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUnpaidInvoiceResponse {
    /** List of unpaid invoices. */
    invoices?: GetUnpaidInvoiceResponseInvoicesList | null;
}
export interface GetUsageRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** Start date for the usage query (ISO 8601). Required if `to` is set. When omitted along with `to`, defaults to the start of the current month. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    from?: string;
    /** End date for the usage query (ISO 8601). Required if `from` is set. When omitted along with `from`, defaults to today. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    to?: string;
}
export type UsageGetResultItemChargeCategory = "Usage";
export type UsageGetResultItemChargeFrequency = "Usage-Based";
export type UsageGetResultItemChargeClass = "Correction";
export type UsageGetResultItemTagsValue = string | boolean;
export type UsageGetResultItemTagsMap = {
    [key: string]: UsageGetResultItemTagsValue | undefined;
};
export interface UsageGetResultItem {
    /** Highest-level classification of a charge based on the nature of how it gets billed. Currently only "Usage" is supported. */
    chargeCategory: UsageGetResultItemChargeCategory;
    /** Self-contained summary of the charge's purpose and price. */
    chargeDescription: string;
    /** Indicates how often a charge occurs. Currently only "Usage-Based" is supported. */
    chargeFrequency: UsageGetResultItemChargeFrequency;
    /** Exclusive end of the time interval during which the usage was consumed. */
    chargePeriodEnd: string;
    /** Inclusive start of the time interval during which the usage was consumed. */
    chargePeriodStart: string;
    /** Unit of measure for the consumed quantity (e.g., "GB", "Requests", "vCPU-Hours"). */
    consumedUnit: string;
    /** Name of the entity providing the underlying infrastructure or platform. */
    hostProviderName: string;
    /** Name of the entity responsible for invoicing for the services consumed. */
    invoiceIssuerName: string;
    /** Name of the entity that made the services available for purchase. */
    serviceProviderName: string;
    /** The unique identifier for the billable metric in the Cloudflare catalog. Cloudflare extension; replaces FOCUS SkuId. */
    xBillableMetricId: string;
    /** A charge serving as the basis for invoicing, inclusive of all reduced rates and discounts while excluding the amortization of upfront charges (one-time or recurring). */
    billedCost?: number | null;
    /** Public identifier of the Cloudflare account (account tag). Omitted when account is not part of the requested grouping, and always omitted for usage measured at contract level, even when grouping by account: that usage is returned as its own record with no account. */
    billingAccountId?: string | null;
    /** Display name of the Cloudflare account. Omitted when account is not part of the requested grouping, and for usage measured at contract level. */
    billingAccountName?: string | null;
    /** Currency that a charge was billed in (ISO 4217). */
    billingCurrency?: string | null;
    /** Exclusive end of the billing cycle that contains this usage record. */
    billingPeriodEnd?: string | null;
    /** Inclusive start of the billing cycle that contains this usage record. */
    billingPeriodStart?: string | null;
    /** Indicates whether the row represents a correction to one or more charges invoiced in a previous billing period. */
    chargeClass?: UsageGetResultItemChargeClass | null;
    /** Measured usage amount within the charge period. Reflects raw metered consumption before pricing transformations. */
    consumedQuantity?: number | null;
    /** Cost calculated by multiplying ContractedUnitPrice and the corresponding PricingQuantity. */
    contractedCost?: number | null;
    /** The agreed-upon unit price for a single PricingUnit of the associated billable metric, inclusive of negotiated discounts, if present, while excluding any other discounts. */
    contractedUnitPrice?: number | null;
    /** The amortized cost of the charge after applying all reduced rates, discounts, and the applicable portion of relevant, prepaid purchases (one-time or recurring) that covered the charge. */
    effectiveCost?: number | null;
    /** Cost calculated by multiplying ListUnitPrice and the corresponding PricingQuantity. */
    listCost?: number | null;
    /** Suggested provider-published unit price for a single PricingUnit of the associated billable metric, exclusive of any discounts. */
    listUnitPrice?: number | null;
    /** Volume of a given service used or purchased, based on the PricingUnit. */
    pricingQuantity?: number | null;
    /** Provider-specified measurement unit for determining unit prices, indicating how the provider rates measured usage after applying pricing rules like block pricing. */
    pricingUnit?: string | null;
    /** Provider-assigned identifier for an isolated geographic area where a service is provided. */
    regionId?: string | null;
    /** Name of an isolated geographic area where a service is provided. */
    regionName?: string | null;
    /** Unique identifier assigned to a grouping of services. For Cloudflare, this is the subscription or contract ID. */
    subAccountId?: string | null;
    /** Name assigned to a grouping of services. For Cloudflare, this is the subscription or contract display name. */
    subAccountName?: string | null;
    /** Tag values for the requested `GroupBy` keys. Omitted when `GroupBy` is not provided. Missing keys are omitted, and key-only tags are returned as boolean `true`. All other tag values are strings. */
    tags?: UsageGetResultItemTagsMap | null;
    /** The display name of the billable metric. Cloudflare extension; replaces FOCUS SkuMeter. */
    xBillableMetricName?: string | null;
    /** The product category the charge belongs to (e.g., "Developer", "Cloudflare One"). Cloudflare extension; replaces FOCUS ServiceCategory. */
    xProductCategoryName?: string | null;
    /** The unique identifier for the product family in the Cloudflare catalog. Cloudflare extension; replaces FOCUS ServiceId. */
    xProductFamilyId?: string | null;
    /** The product family the charge belongs to (e.g., "R2", "Workers"). Cloudflare extension; replaces FOCUS ServiceName. */
    xProductFamilyName?: string | null;
    /** The identifier for the Cloudflare zone (zone tag). Omitted when zone is not part of the requested grouping, and always omitted for usage measured at contract level, even when grouping by zone. Cloudflare extension. */
    xZoneId?: string | null;
    /** The display name of the Cloudflare zone. Omitted when zone is not part of the requested grouping, and for usage measured at contract level. Cloudflare extension. */
    xZoneName?: string | null;
}
export type UsageGetResultList = Array<UsageGetResultItem>;
export type GetUsageResponse = UsageGetResultList;
export interface ListHistoryRequest {
    /** Identifier */
    accountId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
    /** Filter billing history by status. */
    status?: string;
}
export type ListHistoryResultItem = GetBadDebtResponseInvoicesItem;
export type ListHistoryResultList = Array<GetBadDebtResponseInvoicesItem>;
export type ListHistoryResponse = ListHistoryResultList;
export interface PaygoUsageRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** Start date for the usage query (ISO 8601). The provided time range must include the subscription billing cycle anchor day, otherwise no usage data is returned. Use the info endpoint to retrieve the subscription anchor day. */
    from?: string;
    /** End date for the usage query (ISO 8601). */
    to?: string;
}
export type UsagePaygoResultItemChargeCategory = "Usage";
export interface UsagePaygoResultItem {
    /** The amount invoiced for this charge. PayGo is billed directly by Cloudflare, so this equals ContractedCost. */
    billedCost: number;
    /** The identifier of the account the charge is billed to (account tag). */
    billingAccountId: string;
    /** The display name of the billing account. Null when the name could not be resolved. */
    billingAccountName: string;
    /** Specifies the billing currency code (ISO 4217). */
    billingCurrency: string;
    /** Indicates the start of the billing period. There is no `BillingPeriodEnd` counterpart; see the known gaps described on this schema. */
    billingPeriodStart: string;
    /** Describes the nature of the charge. Always "Usage" for this endpoint, which only returns metered usage. */
    chargeCategory: UsagePaygoResultItemChargeCategory;
    /** Indicates whether the row corrects a previously invoiced billing period. Always null for this endpoint, which does not return corrections. */
    chargeClass: string;
    /** A human-readable summary of the charge. */
    chargeDescription: string;
    /** Indicates the end of the charge period. */
    chargePeriodEnd: string;
    /** Indicates the start of the charge period. */
    chargePeriodStart: string;
    /** Specifies the quantity consumed during this charge period. */
    consumedQuantity: number;
    /** A display name for the unit of measurement used for the product (for example, "GB-months", "GB-seconds"). May be empty when the unit is implicit in the service name. */
    consumedUnit: string;
    /** Specifies the cost for this charge period in the billing currency. */
    contractedCost: number;
    /** Specifies the cumulated cost for the billing period in the billing currency. */
    cumulatedContractedCost: number;
    /** Specifies the portion of usage that is actually subject to a unit price. */
    cumulatedPricingQuantity: number;
    /** The amortized cost of the charge. PayGo has no upfront commitments, so this equals ContractedCost. */
    effectiveCost: number;
    /** The provider that hosts the infrastructure or platform the service runs on. */
    hostProviderName: string;
    /** The entity that issues the invoice for this charge. */
    invoiceIssuerName: string;
    /** The cost at published list prices, before any discount. PayGo has no commitment discounts, so this equals ContractedCost. */
    listCost: number;
    /** Specifies the pricing quantity for this charge period. */
    pricingQuantity: number;
    /** The unit that PricingQuantity is expressed in. Unlike ConsumedUnit this is never empty; it falls back to "Count" when the service has no explicit unit. */
    pricingUnit: string;
    /** Identifies the Cloudflare service. */
    serviceName: string;
    /** The provider of the purchased service. */
    serviceProviderName: string;
    /** Identifies the product family for the Cloudflare service. */
    serviceFamilyName?: string | null;
    /** The identifier for the Cloudflare subscription. */
    subscriptionId?: string | null;
    /** The identifier for the Cloudflare zone (zone tag). */
    zoneId?: string | null;
    /** The display name of the Cloudflare zone. */
    zoneName?: string | null;
}
export type UsagePaygoResultList = Array<UsagePaygoResultItem>;
export type PaygoUsageResponse = UsagePaygoResultList;
export interface ProfilesUpdateBillingEmailRequest {
    /** Identifier */
    accountId: string;
    billingEmail?: string;
    preferredLocale?: string;
    secondaryBillingEmail?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ProfilesUpdateBillingEmailResponse {
    /** Billing item identifier tag. */
    id?: string | null;
    accountType?: string | null;
    address?: string | null;
    address2?: string | null;
    balance?: string | null;
    cardExpiryMonth?: number | null;
    cardExpiryYear?: number | null;
    cardNumber?: string | null;
    city?: string | null;
    company?: string | null;
    country?: string | null;
    createdOn?: string | null;
    deviceData?: string | null;
    editedOn?: string | null;
    enterpriseBillingEmail?: string | null;
    enterprisePrimaryEmail?: string | null;
    firstName?: string | null;
    isPartner?: boolean | null;
    lastName?: string | null;
    nextBillDate?: string | null;
    paymentAddress?: string | null;
    paymentAddress2?: string | null;
    paymentCity?: string | null;
    paymentCountry?: string | null;
    paymentEmail?: string | null;
    paymentFirstName?: string | null;
    paymentGateway?: string | null;
    paymentLastName?: string | null;
    paymentNonce?: string | null;
    paymentState?: string | null;
    paymentZipcode?: string | null;
    primaryEmail?: string | null;
    state?: string | null;
    taxIdType?: string | null;
    telephone?: string | null;
    validationCode?: string | null;
    vat?: string | null;
    zipcode?: string | null;
}
export interface UpdateProfileRequest {
    /** Identifier */
    accountId: string;
    /** Street address line 1. */
    address?: string;
    /** Street address line 2 (apt, suite, etc.). */
    address2?: string;
    /** Primary billing email address. */
    billingEmail?: string;
    /** Rate plan being purchased right after profile setup. */
    buyingRatePlan?: string;
    /** Captcha challenge JWT issued during onboarding. */
    captchaChallengeJwt?: string;
    /** Cloudflare Turnstile response. */
    cfTurnstileResponse?: string;
    /** City on the billing profile. */
    city?: string;
    /** Company name on the billing profile. */
    company?: string;
    /** ISO 3166-1 alpha-2 country code. */
    country?: string;
    /** First name on the billing profile. */
    firstName?: string;
    /** hCaptcha response. */
    hCaptchaResponse?: string;
    /** Last name on the billing profile. */
    lastName?: string;
    /** Preferred locale for invoice rendering (BCP 47). */
    preferredLocale?: string;
    /** Secondary billing email address for CC on invoices. */
    secondaryBillingEmail?: string;
    /** State or region on the billing profile. */
    state?: string;
    /** Type of tax ID provided. */
    taxIdType?: string;
    /** Contact phone number. */
    telephone?: string;
    /** VAT identifier. */
    vat?: string;
    /** ZIP or postal code. */
    zipcode?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateProfileResponse {
    /** Billing item identifier tag. */
    id?: string | null;
    accountType?: string | null;
    address?: string | null;
    address2?: string | null;
    balance?: string | null;
    cardExpiryMonth?: number | null;
    cardExpiryYear?: number | null;
    cardNumber?: string | null;
    city?: string | null;
    company?: string | null;
    country?: string | null;
    createdOn?: string | null;
    deviceData?: string | null;
    editedOn?: string | null;
    enterpriseBillingEmail?: string | null;
    enterprisePrimaryEmail?: string | null;
    firstName?: string | null;
    isPartner?: boolean | null;
    lastName?: string | null;
    nextBillDate?: string | null;
    paymentAddress?: string | null;
    paymentAddress2?: string | null;
    paymentCity?: string | null;
    paymentCountry?: string | null;
    paymentEmail?: string | null;
    paymentFirstName?: string | null;
    paymentGateway?: string | null;
    paymentLastName?: string | null;
    paymentNonce?: string | null;
    paymentState?: string | null;
    paymentZipcode?: string | null;
    primaryEmail?: string | null;
    state?: string | null;
    taxIdType?: string | null;
    telephone?: string | null;
    validationCode?: string | null;
    vat?: string | null;
    zipcode?: string | null;
}
export interface UsageGetAccountUsageInfoV1Request {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
}
export interface UsageGetAccountUsageInfoV1ResponseSubscriptionsItem {
    /** The identifier for the Cloudflare subscription. */
    id: string;
    /** The subscription billing cycle anchor timestamp. */
    billingCycleAnchorTimestamp: string;
    /** The subscription start timestamp. */
    startTimestamp: string;
    /** The subscription end timestamp. Omitted for active subscriptions; present only when the subscription has been cancelled. */
    endTimestamp?: string | null;
}
export type UsageGetAccountUsageInfoV1ResponseSubscriptionsList = Array<UsageGetAccountUsageInfoV1ResponseSubscriptionsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UsageGetAccountUsageInfoV1Response {
    /** Indicates whether the account is covered. */
    covered: boolean;
    /** List of subscriptions for the account. */
    subscriptions: UsageGetAccountUsageInfoV1ResponseSubscriptionsList;
}
export interface UsageGetAccountUsageV1Request {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** Start date for the usage query (ISO 8601). The provided time range must include the subscription billing cycle anchor day, otherwise no usage data is returned. Use the info endpoint to retrieve the subscription anchor day. */
    from?: string;
    /** End date for the usage query (ISO 8601). */
    to?: string;
}
export type UsageGetAccountUsageV1ResultItemChargeCategory = "Usage";
export interface UsageGetAccountUsageV1ResultItem {
    /** The amount invoiced for this charge. PayGo is billed directly by Cloudflare, so this equals ContractedCost. */
    billedCost: number;
    /** The identifier of the account the charge is billed to (account tag). */
    billingAccountId: string;
    /** The display name of the billing account. Null when the name could not be resolved. */
    billingAccountName: string;
    /** Specifies the billing currency code (ISO 4217). */
    billingCurrency: string;
    /** Indicates the start of the billing period. There is no `BillingPeriodEnd` counterpart; see the known gaps described on this schema. */
    billingPeriodStart: string;
    /** Describes the nature of the charge. Always "Usage" for this endpoint, which only returns metered usage. */
    chargeCategory: UsageGetAccountUsageV1ResultItemChargeCategory;
    /** Indicates whether the row corrects a previously invoiced billing period. Always null for this endpoint, which does not return corrections. */
    chargeClass: string;
    /** A human-readable summary of the charge. */
    chargeDescription: string;
    /** Indicates the end of the charge period. */
    chargePeriodEnd: string;
    /** Indicates the start of the charge period. */
    chargePeriodStart: string;
    /** Specifies the quantity consumed during this charge period. */
    consumedQuantity: number;
    /** A display name for the unit of measurement used for the product (for example, "GB-months", "GB-seconds"). May be empty when the unit is implicit in the service name. */
    consumedUnit: string;
    /** Specifies the cost for this charge period in the billing currency. */
    contractedCost: number;
    /** Specifies the cumulated cost for the billing period in the billing currency. */
    cumulatedContractedCost: number;
    /** Specifies the portion of usage that is actually subject to a unit price. */
    cumulatedPricingQuantity: number;
    /** The amortized cost of the charge. PayGo has no upfront commitments, so this equals ContractedCost. */
    effectiveCost: number;
    /** The provider that hosts the infrastructure or platform the service runs on. */
    hostProviderName: string;
    /** The entity that issues the invoice for this charge. */
    invoiceIssuerName: string;
    /** The cost at published list prices, before any discount. PayGo has no commitment discounts, so this equals ContractedCost. */
    listCost: number;
    /** Specifies the pricing quantity for this charge period. */
    pricingQuantity: number;
    /** The unit that PricingQuantity is expressed in. Unlike ConsumedUnit this is never empty; it falls back to "Count" when the service has no explicit unit. */
    pricingUnit: string;
    /** Identifies the Cloudflare service. */
    serviceName: string;
    /** The provider of the purchased service. */
    serviceProviderName: string;
    /** Identifies the product family for the Cloudflare service. */
    serviceFamilyName?: string | null;
    /** The identifier for the Cloudflare subscription. */
    subscriptionId?: string | null;
    /** The identifier for the Cloudflare zone (zone tag). */
    zoneId?: string | null;
    /** The display name of the Cloudflare zone. */
    zoneName?: string | null;
}
export type UsageGetAccountUsageV1ResultList = Array<UsageGetAccountUsageV1ResultItem>;
export type UsageGetAccountUsageV1Response = UsageGetAccountUsageV1ResultList;
export interface UsageGetAccountUsageV2Request {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** Start date for the usage query (ISO 8601). Required if `to` is set. When omitted along with `to`, defaults to the start of the current month. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    from?: string;
    /** End date for the usage query (ISO 8601). Required if `from` is set. When omitted along with `from`, defaults to today. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    to?: string;
}
export type UsageGetAccountUsageV2ResultItemChargeCategory = "Usage";
export type UsageGetAccountUsageV2ResultItemChargeFrequency = "Usage-Based";
export type UsageGetAccountUsageV2ResultItemChargeClass = "Correction";
export type UsageGetAccountUsageV2ResultItemTagsValue = string | boolean;
export type UsageGetAccountUsageV2ResultItemTagsMap = {
    [key: string]: UsageGetAccountUsageV2ResultItemTagsValue | undefined;
};
export interface UsageGetAccountUsageV2ResultItem {
    /** Highest-level classification of a charge based on the nature of how it gets billed. Currently only "Usage" is supported. */
    chargeCategory: UsageGetAccountUsageV2ResultItemChargeCategory;
    /** Self-contained summary of the charge's purpose and price. */
    chargeDescription: string;
    /** Indicates how often a charge occurs. Currently only "Usage-Based" is supported. */
    chargeFrequency: UsageGetAccountUsageV2ResultItemChargeFrequency;
    /** Exclusive end of the time interval during which the usage was consumed. */
    chargePeriodEnd: string;
    /** Inclusive start of the time interval during which the usage was consumed. */
    chargePeriodStart: string;
    /** Unit of measure for the consumed quantity (e.g., "GB", "Requests", "vCPU-Hours"). */
    consumedUnit: string;
    /** Name of the entity providing the underlying infrastructure or platform. */
    hostProviderName: string;
    /** Name of the entity responsible for invoicing for the services consumed. */
    invoiceIssuerName: string;
    /** Name of the entity that made the services available for purchase. */
    serviceProviderName: string;
    /** The unique identifier for the billable metric in the Cloudflare catalog. Cloudflare extension; replaces FOCUS SkuId. */
    xBillableMetricId: string;
    /** A charge serving as the basis for invoicing, inclusive of all reduced rates and discounts while excluding the amortization of upfront charges (one-time or recurring). */
    billedCost?: number | null;
    /** Public identifier of the Cloudflare account (account tag). Omitted when account is not part of the requested grouping, and always omitted for usage measured at contract level, even when grouping by account: that usage is returned as its own record with no account. */
    billingAccountId?: string | null;
    /** Display name of the Cloudflare account. Omitted when account is not part of the requested grouping, and for usage measured at contract level. */
    billingAccountName?: string | null;
    /** Currency that a charge was billed in (ISO 4217). */
    billingCurrency?: string | null;
    /** Exclusive end of the billing cycle that contains this usage record. */
    billingPeriodEnd?: string | null;
    /** Inclusive start of the billing cycle that contains this usage record. */
    billingPeriodStart?: string | null;
    /** Indicates whether the row represents a correction to one or more charges invoiced in a previous billing period. */
    chargeClass?: UsageGetAccountUsageV2ResultItemChargeClass | null;
    /** Measured usage amount within the charge period. Reflects raw metered consumption before pricing transformations. */
    consumedQuantity?: number | null;
    /** Cost calculated by multiplying ContractedUnitPrice and the corresponding PricingQuantity. */
    contractedCost?: number | null;
    /** The agreed-upon unit price for a single PricingUnit of the associated billable metric, inclusive of negotiated discounts, if present, while excluding any other discounts. */
    contractedUnitPrice?: number | null;
    /** The amortized cost of the charge after applying all reduced rates, discounts, and the applicable portion of relevant, prepaid purchases (one-time or recurring) that covered the charge. */
    effectiveCost?: number | null;
    /** Cost calculated by multiplying ListUnitPrice and the corresponding PricingQuantity. */
    listCost?: number | null;
    /** Suggested provider-published unit price for a single PricingUnit of the associated billable metric, exclusive of any discounts. */
    listUnitPrice?: number | null;
    /** Volume of a given service used or purchased, based on the PricingUnit. */
    pricingQuantity?: number | null;
    /** Provider-specified measurement unit for determining unit prices, indicating how the provider rates measured usage after applying pricing rules like block pricing. */
    pricingUnit?: string | null;
    /** Provider-assigned identifier for an isolated geographic area where a service is provided. */
    regionId?: string | null;
    /** Name of an isolated geographic area where a service is provided. */
    regionName?: string | null;
    /** Unique identifier assigned to a grouping of services. For Cloudflare, this is the subscription or contract ID. */
    subAccountId?: string | null;
    /** Name assigned to a grouping of services. For Cloudflare, this is the subscription or contract display name. */
    subAccountName?: string | null;
    /** Tag values for the requested `GroupBy` keys. Omitted when `GroupBy` is not provided. Missing keys are omitted, and key-only tags are returned as boolean `true`. All other tag values are strings. */
    tags?: UsageGetAccountUsageV2ResultItemTagsMap | null;
    /** The display name of the billable metric. Cloudflare extension; replaces FOCUS SkuMeter. */
    xBillableMetricName?: string | null;
    /** The product category the charge belongs to (e.g., "Developer", "Cloudflare One"). Cloudflare extension; replaces FOCUS ServiceCategory. */
    xProductCategoryName?: string | null;
    /** The unique identifier for the product family in the Cloudflare catalog. Cloudflare extension; replaces FOCUS ServiceId. */
    xProductFamilyId?: string | null;
    /** The product family the charge belongs to (e.g., "R2", "Workers"). Cloudflare extension; replaces FOCUS ServiceName. */
    xProductFamilyName?: string | null;
    /** The identifier for the Cloudflare zone (zone tag). Omitted when zone is not part of the requested grouping, and always omitted for usage measured at contract level, even when grouping by zone. Cloudflare extension. */
    xZoneId?: string | null;
    /** The display name of the Cloudflare zone. Omitted when zone is not part of the requested grouping, and for usage measured at contract level. Cloudflare extension. */
    xZoneName?: string | null;
}
export type UsageGetAccountUsageV2ResultList = Array<UsageGetAccountUsageV2ResultItem>;
export type UsageGetAccountUsageV2Response = UsageGetAccountUsageV2ResultList;
export interface UsagePaygoInfoRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
}
export type UsagePaygoInfoResponseSubscriptionsItem = UsageGetAccountUsageInfoV1ResponseSubscriptionsItem;
export type UsagePaygoInfoResponseSubscriptionsList = Array<UsageGetAccountUsageInfoV1ResponseSubscriptionsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UsagePaygoInfoResponse {
    /** Indicates whether the account is covered. */
    covered: boolean;
    /** List of subscriptions for the account. */
    subscriptions: UsagePaygoInfoResponseSubscriptionsList;
}
export type AddressValidationError = CloudflareOpError;
/** Validates a billing address and returns validated address suggestions. Authentication is not enforced to support pre-signup address validation flows, so credentials are accepted but not required. */
export declare const addressValidation: API.OperationMethod<AddressValidationRequest, AddressValidationResponse, AddressValidationError, CloudflareOpContext>;
export type CreateProfileError = CloudflareOpError;
/** Creates a billing profile for an account. */
export declare const createProfile: API.OperationMethod<CreateProfileRequest, CreateProfileResponse, CreateProfileError, CloudflareOpContext>;
export type CreateProfilesPaymentMethodError = CloudflareOpError;
/** Creates a Stripe payment intent for adding or updating a payment method on the account's billing profile. Returns a client secret for frontend payment method collection. */
export declare const createProfilesPaymentMethod: API.OperationMethod<CreateProfilesPaymentMethodRequest, CreateProfilesPaymentMethodResponse, CreateProfilesPaymentMethodError, CloudflareOpContext>;
export type DeleteProfileError = CloudflareOpError;
/** Deletes the billing profile for an account. */
export declare const deleteProfile: API.OperationMethod<DeleteProfileRequest, DeleteProfileResponse, DeleteProfileError, CloudflareOpContext>;
export type GetBadDebtError = CloudflareOpError;
/** Gets bad debt information for an account, including outstanding invoices and total debt amount. */
export declare const getBadDebt: API.OperationMethod<GetBadDebtRequest, GetBadDebtResponse, GetBadDebtError, CloudflareOpContext>;
export type GetCreditError = CloudflareOpError;
/** Gets the credit balance and eligibility for an account. */
export declare const getCredit: API.OperationMethod<GetCreditRequest, GetCreditResponse, GetCreditError, CloudflareOpContext>;
export type GetProfileError = CloudflareOpError;
/** Gets the current billing profile for the account. */
export declare const getProfile: API.OperationMethod<GetProfileRequest, GetProfileResponse, GetProfileError, CloudflareOpContext>;
export type GetRatePlanError = CloudflareOpError;
/** Gets a rate plan's details by its public key (e.g., 'teams_free', 'cf_pro_20_20'). This is a public catalog endpoint, so authentication is not enforced and credentials are accepted but not required. */
export declare const getRatePlan: API.OperationMethod<GetRatePlanRequest, GetRatePlanResponse, GetRatePlanError, CloudflareOpContext>;
export type GetUnpaidInvoiceError = CloudflareOpError;
/** Gets unpaid invoice information for an account. */
export declare const getUnpaidInvoice: API.OperationMethod<GetUnpaidInvoiceRequest, GetUnpaidInvoiceResponse, GetUnpaidInvoiceError, CloudflareOpContext>;
export type GetUsageError = CloudflareOpError;
/** Returns cost and usage data for a single Cloudflare account, aligned with the [FinOps FOCUS v1.3](https://focus.finops.org/focus-specification/v1-3/) Cost and Usage dataset specification. Each record represents one billable metric for one account on one day. This includes all metered usage, including usage that falls within free-tier allowances and may result in zero cost. **Note:** This endpoint serves `usage` records only; cost and pricing fields are absent from responses. To retrieve rated costs, use `POST` on the same path with `Metric: cost`. When `from` and `to` are omitted, defaults to the start of the current month through today. The maximum date range is 31 days. */
export declare const getUsage: API.OperationMethod<GetUsageRequest, GetUsageResponse, GetUsageError, CloudflareOpContext>;
export type ListHistoryError = CloudflareOpError;
/** Gets the billing history for an account. */
export declare const listHistory: API.OperationMethod<ListHistoryRequest, ListHistoryResponse, ListHistoryError, CloudflareOpContext>;
export type PaygoUsageError = CloudflareOpError;
/** Returns billable usage data for the account. When no query parameters are provided, returns usage for the current billing period. */
export declare const paygoUsage: API.OperationMethod<PaygoUsageRequest, PaygoUsageResponse, PaygoUsageError, CloudflareOpContext>;
export type ProfilesUpdateBillingEmailError = CloudflareOpError;
/** Updates the billing email addresses and preferred locale for an account. */
export declare const profilesUpdateBillingEmail: API.OperationMethod<ProfilesUpdateBillingEmailRequest, ProfilesUpdateBillingEmailResponse, ProfilesUpdateBillingEmailError, CloudflareOpContext>;
export type UpdateProfileError = CloudflareOpError;
/** Updates the billing profile for an account. */
export declare const updateProfile: API.OperationMethod<UpdateProfileRequest, UpdateProfileResponse, UpdateProfileError, CloudflareOpContext>;
export type UsageGetAccountUsageInfoV1Error = CloudflareOpError;
/** Returns high-level usage information for the account, including coverage, and subscription metadata. */
export declare const usageGetAccountUsageInfoV1: API.OperationMethod<UsageGetAccountUsageInfoV1Request, UsageGetAccountUsageInfoV1Response, UsageGetAccountUsageInfoV1Error, CloudflareOpContext>;
export type UsageGetAccountUsageV1Error = CloudflareOpError;
/** Returns billable usage data for the account. When no query parameters are provided, returns usage for the current billing period. */
export declare const usageGetAccountUsageV1: API.OperationMethod<UsageGetAccountUsageV1Request, UsageGetAccountUsageV1Response, UsageGetAccountUsageV1Error, CloudflareOpContext>;
export type UsageGetAccountUsageV2Error = CloudflareOpError;
/** Returns cost and usage data for a single Cloudflare account, aligned with the [FinOps FOCUS v1.3](https://focus.finops.org/focus-specification/v1-3/) Cost and Usage dataset specification. Each record represents one billable metric for one account on one day. This includes all metered usage, including usage that falls within free-tier allowances and may result in zero cost. **Note:** This endpoint serves `usage` records only; cost and pricing fields are absent from responses. To retrieve rated costs, use `POST` on the same path with `Metric: cost`. When `from` and `to` are omitted, defaults to the start of the current month through today. The maximum date range is 31 days. */
export declare const usageGetAccountUsageV2: API.OperationMethod<UsageGetAccountUsageV2Request, UsageGetAccountUsageV2Response, UsageGetAccountUsageV2Error, CloudflareOpContext>;
export type UsagePaygoInfoError = CloudflareOpError;
/** Returns high-level usage information for the account, including coverage, and subscription metadata. */
export declare const usagePaygoInfo: API.OperationMethod<UsagePaygoInfoRequest, UsagePaygoInfoResponse, UsagePaygoInfoError, CloudflareOpContext>;
//# sourceMappingURL=billing.d.ts.map