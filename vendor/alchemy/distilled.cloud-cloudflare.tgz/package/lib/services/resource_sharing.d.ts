import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const ShareNotFound_base: S.TaggedErrorClass<"ShareNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ShareNotFound extends /*@__PURE__*/ ShareNotFound_base {
}
declare const ShareRecipientNotFound_base: S.TaggedErrorClass<"ShareRecipientNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ShareRecipientNotFound extends /*@__PURE__*/ ShareRecipientNotFound_base {
}
declare const ShareResourceNotFound_base: S.TaggedErrorClass<"ShareResourceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ShareResourceNotFound extends /*@__PURE__*/ ShareResourceNotFound_base {
}
export interface CreateRecipientRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Organization identifier. */
    organizationId?: string;
    /** The account that will receive the share. */
    recipientAccountId?: string;
}
export type RecipientsCreateResponseAssociationStatus = "associating" | "associated" | "disassociating" | "disassociated";
export interface RecipientsCreateResponseResourcesItem {
    /** Share Recipient error message. */
    error: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Version. */
    resourceVersion: number;
    /** Whether the error is terminal or will be continually retried. */
    terminal: boolean;
}
export type RecipientsCreateResponseResourcesList = Array<RecipientsCreateResponseResourcesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRecipientResponse {
    /** Share Recipient identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The current state of the recipient relative to the share. The `desired_association_status` (not exposed in the response) tracks the target state set by the API; the background reconciliation workflow drives `current_association_status` toward it. */
    associationStatus: RecipientsCreateResponseAssociationStatus;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    resources?: RecipientsCreateResponseResourcesList | null;
}
export type ResourcesCreateRequestResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export interface CreateResourceRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Resource Metadata. */
    meta: unknown;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ResourcesCreateRequestResourceType | (string & {});
}
export type ResourcesCreateResponseResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export type ResourcesCreateResponseStatus = "active" | "deleting" | "deleted";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateResourceResponse {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ResourcesCreateResponseResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: ResourcesCreateResponseStatus;
}
export interface CreateRequestRecipientsItem {
    /** This field has been renamed to `recipient_account_id`. Both names are accepted during the deprecation period. */
    accountId?: string;
    /** Organization identifier. */
    organizationId?: string;
    /** The account that will receive the share. */
    recipientAccountId?: string;
}
export type CreateRequestRecipientsList = Array<CreateRequestRecipientsItem>;
export type CreateRequestResourcesItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export interface CreateRequestResourcesItem {
    /** Resource Metadata. */
    meta: unknown;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: CreateRequestResourcesItemResourceType | (string & {});
}
export type CreateRequestResourcesList = Array<CreateRequestResourcesItem>;
export interface CreateResourceSharingRequest {
    /** Account identifier. */
    accountId: string;
    /** The name of the share. */
    name: string;
    recipients: CreateRequestRecipientsList;
    resources: CreateRequestResourcesList;
}
export type CreateResponseStatus = "active" | "deleting" | "deleted";
export type CreateResponseTargetType = "account" | "organization";
export type CreateResponseKind = "sent" | "received";
export type CreateResponseResourcesItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export type CreateResponseResourcesItemStatus = "active" | "deleting" | "deleted";
export interface CreateResponseResourcesItem {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: CreateResponseResourcesItemResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: CreateResponseResourcesItemStatus;
}
export type CreateResponseResourcesList = Array<CreateResponseResourcesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateResourceSharingResponse {
    /** Share identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The display name of an account. */
    accountName: string;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    /** The name of the share. */
    name: string;
    /** Organization identifier. */
    organizationId: string;
    status: CreateResponseStatus;
    targetType: CreateResponseTargetType;
    /** The number of recipients in the 'associated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatedRecipientCount?: number | null;
    /** The number of recipients in the 'associating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatingRecipientCount?: number | null;
    /** The number of recipients in the 'disassociated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatedRecipientCount?: number | null;
    /** The number of recipients in the 'disassociating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatingRecipientCount?: number | null;
    kind?: CreateResponseKind | null;
    /** A list of resources that are part of the share. This field is only included when requested via the 'include_resources' parameter. */
    resources?: CreateResponseResourcesList | null;
}
export interface DeleteRecipientRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Share Recipient identifier tag. */
    recipientId: string;
}
export type RecipientsDeleteResponseAssociationStatus = "associating" | "associated" | "disassociating" | "disassociated";
export type RecipientsDeleteResponseResourcesItem = RecipientsCreateResponseResourcesItem;
export type RecipientsDeleteResponseResourcesList = Array<RecipientsCreateResponseResourcesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRecipientResponse {
    /** Share Recipient identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The current state of the recipient relative to the share. The `desired_association_status` (not exposed in the response) tracks the target state set by the API; the background reconciliation workflow drives `current_association_status` toward it. */
    associationStatus: RecipientsDeleteResponseAssociationStatus;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    resources?: RecipientsDeleteResponseResourcesList | null;
}
export interface DeleteResourceRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Share Resource identifier. */
    shareResourceId: string;
}
export type ResourcesDeleteResponseResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export type ResourcesDeleteResponseStatus = "active" | "deleting" | "deleted";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteResourceResponse {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ResourcesDeleteResponseResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: ResourcesDeleteResponseStatus;
}
export interface DeleteResourceSharingRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
}
export type DeleteResponseStatus = "active" | "deleting" | "deleted";
export type DeleteResponseTargetType = "account" | "organization";
export type DeleteResponseKind = "sent" | "received";
export type DeleteResponseResourcesItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export type DeleteResponseResourcesItemStatus = "active" | "deleting" | "deleted";
export interface DeleteResponseResourcesItem {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: DeleteResponseResourcesItemResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: DeleteResponseResourcesItemStatus;
}
export type DeleteResponseResourcesList = Array<DeleteResponseResourcesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteResourceSharingResponse {
    /** Share identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The display name of an account. */
    accountName: string;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    /** The name of the share. */
    name: string;
    /** Organization identifier. */
    organizationId: string;
    status: DeleteResponseStatus;
    targetType: DeleteResponseTargetType;
    /** The number of recipients in the 'associated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatedRecipientCount?: number | null;
    /** The number of recipients in the 'associating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatingRecipientCount?: number | null;
    /** The number of recipients in the 'disassociated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatedRecipientCount?: number | null;
    /** The number of recipients in the 'disassociating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatingRecipientCount?: number | null;
    kind?: DeleteResponseKind | null;
    /** A list of resources that are part of the share. This field is only included when requested via the 'include_resources' parameter. */
    resources?: DeleteResponseResourcesList | null;
}
export interface GetRecipientRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Share Recipient identifier tag. */
    recipientId: string;
    /** Include resources in the response. */
    includeResources?: boolean;
}
export type RecipientsGetResponseAssociationStatus = "associating" | "associated" | "disassociating" | "disassociated";
export type RecipientsGetResponseResourcesItem = RecipientsCreateResponseResourcesItem;
export type RecipientsGetResponseResourcesList = Array<RecipientsCreateResponseResourcesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRecipientResponse {
    /** Share Recipient identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The current state of the recipient relative to the share. The `desired_association_status` (not exposed in the response) tracks the target state set by the API; the background reconciliation workflow drives `current_association_status` toward it. */
    associationStatus: RecipientsGetResponseAssociationStatus;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    resources?: RecipientsGetResponseResourcesList | null;
}
export interface GetResourceRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Share Resource identifier. */
    shareResourceId: string;
}
export type ResourcesGetResponseResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export type ResourcesGetResponseStatus = "active" | "deleting" | "deleted";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResourceResponse {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ResourcesGetResponseResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: ResourcesGetResponseStatus;
}
export interface GetResourceSharingRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Include recipient counts in the response. */
    includeRecipientCounts?: boolean;
    /** Include resources in the response. */
    includeResources?: boolean;
}
export type GetResponseStatus = "active" | "deleting" | "deleted";
export type GetResponseTargetType = "account" | "organization";
export type GetResponseKind = "sent" | "received";
export type GetResponseResourcesItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export type GetResponseResourcesItemStatus = "active" | "deleting" | "deleted";
export interface GetResponseResourcesItem {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: GetResponseResourcesItemResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: GetResponseResourcesItemStatus;
}
export type GetResponseResourcesList = Array<GetResponseResourcesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResourceSharingResponse {
    /** Share identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The display name of an account. */
    accountName: string;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    /** The name of the share. */
    name: string;
    /** Organization identifier. */
    organizationId: string;
    status: GetResponseStatus;
    targetType: GetResponseTargetType;
    /** The number of recipients in the 'associated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatedRecipientCount?: number | null;
    /** The number of recipients in the 'associating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatingRecipientCount?: number | null;
    /** The number of recipients in the 'disassociated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatedRecipientCount?: number | null;
    /** The number of recipients in the 'disassociating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatingRecipientCount?: number | null;
    kind?: GetResponseKind | null;
    /** A list of resources that are part of the share. This field is only included when requested via the 'include_resources' parameter. */
    resources?: GetResponseResourcesList | null;
}
export interface ListRecipientsRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Include resources in the response. */
    includeResources?: boolean;
    /** Page number. Defaults to `1` when `per_page` is supplied without `page`. May be omitted entirely along with `per_page` to receive a non-paginated response. */
    page?: number;
    /** Number of objects to return per page. Defaults to `20` when `page` is supplied without `per_page`. May be omitted entirely along with `page` to receive a non-paginated response. */
    perPage?: number;
}
export type RecipientsListResultItemAssociationStatus = "associating" | "associated" | "disassociating" | "disassociated";
export type RecipientsListResultItemResourcesItem = RecipientsCreateResponseResourcesItem;
export type RecipientsListResultItemResourcesList = Array<RecipientsCreateResponseResourcesItem>;
export interface RecipientsListResultItem {
    /** Share Recipient identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The current state of the recipient relative to the share. The `desired_association_status` (not exposed in the response) tracks the target state set by the API; the background reconciliation workflow drives `current_association_status` toward it. */
    associationStatus: RecipientsListResultItemAssociationStatus;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    resources?: RecipientsListResultItemResourcesList | null;
}
export type RecipientsListResultList = Array<RecipientsListResultItem>;
export interface ListRecipientsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RecipientsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ResourcesListRequestResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export type ResourcesListRequestStatus = "active" | "deleting" | "deleted";
export interface ListResourcesRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Page number. Defaults to `1` when `per_page` is supplied without `page`. May be omitted entirely along with `per_page` to receive a non-paginated response. */
    page?: number;
    /** Number of objects to return per page. Defaults to `20` when `page` is supplied without `per_page`. May be omitted entirely along with `page` to receive a non-paginated response. */
    perPage?: number;
    /** Filter share resources by resource_type. */
    resourceType?: ResourcesListRequestResourceType | (string & {});
    /** Filter share resources by status. */
    status?: ResourcesListRequestStatus | (string & {});
}
export type ResourcesListResultItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export type ResourcesListResultItemStatus = "active" | "deleting" | "deleted";
export interface ResourcesListResultItem {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ResourcesListResultItemResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: ResourcesListResultItemStatus;
}
export type ResourcesListResultList = Array<ResourcesListResultItem>;
export interface ListResourcesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ResourcesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ListRequestDirection = "asc" | "desc";
export type ListRequestKind = "sent" | "received";
export type ListRequestOrder = "name" | "created";
export type ListRequestResourceTypes = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export type ListRequestResourceTypesList = Array<ListRequestResourceTypes | (string & {})>;
export type ListRequestStatus = "active" | "deleting" | "deleted";
export type ListRequestTagList = Array<string>;
export type ListRequestTargetType = "account" | "organization";
export interface ListResourceSharingsRequest {
    /** Account identifier. */
    accountId: string;
    /** Direction to sort objects. */
    direction?: ListRequestDirection | (string & {});
    /** Include recipient counts in the response. */
    includeRecipientCounts?: boolean;
    /** Include resources in the response. */
    includeResources?: boolean;
    /** Filter shares by kind. */
    kind?: ListRequestKind | (string & {});
    /** Order shares by values in the given field. */
    order?: ListRequestOrder | (string & {});
    /** Page number. Defaults to `1` when `per_page` is supplied without `page`. May be omitted entirely along with `per_page` to receive a non-paginated response. */
    page?: number;
    /** Number of objects to return per page. Defaults to `20` when `page` is supplied without `per_page`. May be omitted entirely along with `page` to receive a non-paginated response. */
    perPage?: number;
    /** Filter share resources by resource_types. */
    resourceTypes?: ListRequestResourceTypesList;
    /** Filter shares by status. */
    status?: ListRequestStatus | (string & {});
    /** Filter shares by tag. Each value is either `key=value` (matches shares whose tags contain that key/value pair) or `key` alone (matches shares that have any value for that key). May be repeated; multiple `tag` parameters are ANDed together. Maximum 20 `tag` parameters per request. */
    tag?: ListRequestTagList;
    /** Filter shares by target_type. */
    targetType?: ListRequestTargetType | (string & {});
}
export type ListResultItemStatus = "active" | "deleting" | "deleted";
export type ListResultItemTargetType = "account" | "organization";
export type ListResultItemKind = "sent" | "received";
export type ListResultItemResourcesItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export type ListResultItemResourcesItemStatus = "active" | "deleting" | "deleted";
export interface ListResultItemResourcesItem {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ListResultItemResourcesItemResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: ListResultItemResourcesItemStatus;
}
export type ListResultItemResourcesList = Array<ListResultItemResourcesItem>;
export interface ListResultItem {
    /** Share identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The display name of an account. */
    accountName: string;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    /** The name of the share. */
    name: string;
    /** Organization identifier. */
    organizationId: string;
    status: ListResultItemStatus;
    targetType: ListResultItemTargetType;
    /** The number of recipients in the 'associated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatedRecipientCount?: number | null;
    /** The number of recipients in the 'associating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatingRecipientCount?: number | null;
    /** The number of recipients in the 'disassociated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatedRecipientCount?: number | null;
    /** The number of recipients in the 'disassociating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatingRecipientCount?: number | null;
    kind?: ListResultItemKind | null;
    /** A list of resources that are part of the share. This field is only included when requested via the 'include_resources' parameter. */
    resources?: ListResultItemResourcesList | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListResourceSharingsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface UpdateResourceRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Share Resource identifier. */
    shareResourceId: string;
    /** Resource Metadata. */
    meta: unknown;
}
export type ResourcesUpdateResponseResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export type ResourcesUpdateResponseStatus = "active" | "deleting" | "deleted";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResourceResponse {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ResourcesUpdateResponseResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: ResourcesUpdateResponseStatus;
}
export interface UpdateResourceSharingRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** The name of the share. */
    name: string;
}
export type UpdateResponseStatus = "active" | "deleting" | "deleted";
export type UpdateResponseTargetType = "account" | "organization";
export type UpdateResponseKind = "sent" | "received";
export type UpdateResponseResourcesItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant" | "trust-grant";
export type UpdateResponseResourcesItemStatus = "active" | "deleting" | "deleted";
export interface UpdateResponseResourcesItem {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: UpdateResponseResourcesItemResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: UpdateResponseResourcesItemStatus;
}
export type UpdateResponseResourcesList = Array<UpdateResponseResourcesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResourceSharingResponse {
    /** Share identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The display name of an account. */
    accountName: string;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    /** The name of the share. */
    name: string;
    /** Organization identifier. */
    organizationId: string;
    status: UpdateResponseStatus;
    targetType: UpdateResponseTargetType;
    /** The number of recipients in the 'associated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatedRecipientCount?: number | null;
    /** The number of recipients in the 'associating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatingRecipientCount?: number | null;
    /** The number of recipients in the 'disassociated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatedRecipientCount?: number | null;
    /** The number of recipients in the 'disassociating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatingRecipientCount?: number | null;
    kind?: UpdateResponseKind | null;
    /** A list of resources that are part of the share. This field is only included when requested via the 'include_resources' parameter. */
    resources?: UpdateResponseResourcesList | null;
}
export type CreateRecipientError = ShareNotFound | Forbidden | CloudflareOpError;
/** Adds a single recipient to an account-targeted resource share, granting them access to the shared resources. The recipient account must belong to the same organization as the share owner. To replace the entire recipient list in one call, use `PUT /accounts/{account_id}/shares/{share_id}/recipients` instead. */
export declare const createRecipient: API.OperationMethod<CreateRecipientRequest, CreateRecipientResponse, CreateRecipientError, CloudflareOpContext>;
export type CreateResourceError = ShareNotFound | Forbidden | CloudflareOpError;
/** Adds a resource to an existing share, making it available to share recipients. */
export declare const createResource: API.OperationMethod<CreateResourceRequest, CreateResourceResponse, CreateResourceError, CloudflareOpContext>;
export type CreateResourceSharingError = Forbidden | CloudflareOpError;
/** Creates a new resource share for sharing Cloudflare resources with other accounts or organizations. */
export declare const createResourceSharing: API.OperationMethod<CreateResourceSharingRequest, CreateResourceSharingResponse, CreateResourceSharingError, CloudflareOpContext>;
export type DeleteRecipientError = ShareRecipientNotFound | Forbidden | CloudflareOpError;
/** Performs a **soft delete**: sets the recipient's `desired_association_status` to `disassociated`, which signals the background reconciliation workflow (Temporal) to remove the shared resources from the recipient account. The recipient record remains in the database for audit purposes and is still returned by `GET /accounts/{account_id}/shares/{share_id}/recipients` with its updated status. Resource access is not fully removed until the workflow completes and `current_association_status` transitions to `disassociated`. The recipient record itself is never physically deleted. */
export declare const deleteRecipient: API.OperationMethod<DeleteRecipientRequest, DeleteRecipientResponse, DeleteRecipientError, CloudflareOpContext>;
export type DeleteResourceError = ShareResourceNotFound | Forbidden | CloudflareOpError;
/** Deletion is not immediate, an updated share resource object with a new status will be returned. */
export declare const deleteResource: API.OperationMethod<DeleteResourceRequest, DeleteResourceResponse, DeleteResourceError, CloudflareOpContext>;
export type DeleteResourceSharingError = ShareNotFound | Forbidden | CloudflareOpError;
/** Deletion is not immediate, an updated share object with a new status will be returned. */
export declare const deleteResourceSharing: API.OperationMethod<DeleteResourceSharingRequest, DeleteResourceSharingResponse, DeleteResourceSharingError, CloudflareOpContext>;
export type GetRecipientError = ShareRecipientNotFound | Forbidden | CloudflareOpError;
/** Get share recipient by ID. */
export declare const getRecipient: API.OperationMethod<GetRecipientRequest, GetRecipientResponse, GetRecipientError, CloudflareOpContext>;
export type GetResourceError = ShareResourceNotFound | Forbidden | CloudflareOpError;
/** Get share resource by ID. */
export declare const getResource: API.OperationMethod<GetResourceRequest, GetResourceResponse, GetResourceError, CloudflareOpContext>;
export type GetResourceSharingError = ShareNotFound | Forbidden | CloudflareOpError;
/** Fetches share by ID. */
export declare const getResourceSharing: API.OperationMethod<GetResourceSharingRequest, GetResourceSharingResponse, GetResourceSharingError, CloudflareOpContext>;
export type ListRecipientsError = ShareNotFound | Forbidden | CloudflareOpError;
/** List share recipients by share ID. Returns **all** recipients regardless of their `association_status` (associating, associated, disassociating, disassociated). Callers that want only "active" recipients must filter client-side on the `association_status` field. */
export declare const listRecipients: API.PaginatedOperationMethod<ListRecipientsRequest, ListRecipientsResponse, ListRecipientsError, CloudflareOpContext, RecipientsListResultItem>;
export type ListResourcesError = ShareNotFound | Forbidden | CloudflareOpError;
/** List share resources by share ID. */
export declare const listResources: API.PaginatedOperationMethod<ListResourcesRequest, ListResourcesResponse, ListResourcesError, CloudflareOpContext, ResourcesListResultItem>;
export type ListResourceSharingsError = Forbidden | CloudflareOpError;
/** Lists all account shares. */
export declare const listResourceSharings: API.PaginatedOperationMethod<ListResourceSharingsRequest, ListResourceSharingsResponse, ListResourceSharingsError, CloudflareOpContext, ListResultItem>;
export type UpdateResourceError = ShareResourceNotFound | Forbidden | CloudflareOpError;
/** Update is not immediate, an updated share resource object with a new status will be returned. */
export declare const updateResource: API.OperationMethod<UpdateResourceRequest, UpdateResourceResponse, UpdateResourceError, CloudflareOpContext>;
export type UpdateResourceSharingError = ShareNotFound | Forbidden | CloudflareOpError;
/** Updates the share's display name and tags. This endpoint does **not** modify recipients or resources -- those are managed via dedicated subresource endpoints: - **Recipients**: Use `POST /accounts/{account_id}/shares/{share_id}/recipients` to add a single recipient, `PUT /accounts/{account_id}/shares/{share_id}/recipients` to replace the full recipient list, or `DELETE /accounts/{account_id}/shares/{share_id}/recipients/{recipient_id}` to remove a recipient. - **Resources**: Use the share's resource subresource endpoints. Updating is not immediate; an updated share object with a new status will be returned. */
export declare const updateResourceSharing: API.OperationMethod<UpdateResourceSharingRequest, UpdateResourceSharingResponse, UpdateResourceSharingError, CloudflareOpContext>;
//# sourceMappingURL=resource_sharing.d.ts.map