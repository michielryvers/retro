import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const MaxRulesExceeded_base: S.TaggedErrorClass<"MaxRulesExceeded", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MaxRulesExceeded extends /*@__PURE__*/ MaxRulesExceeded_base {
}
declare const RuleNotFound_base: S.TaggedErrorClass<"RuleNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class RuleNotFound extends /*@__PURE__*/ RuleNotFound_base {
}
declare const RulesetNotFound_base: S.TaggedErrorClass<"RulesetNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class RulesetNotFound extends /*@__PURE__*/ RulesetNotFound_base {
}
declare const RumSiteQuotaExceeded_base: S.TaggedErrorClass<"RumSiteQuotaExceeded", {
    readonly code: any;
    readonly message: any;
}>;
export declare class RumSiteQuotaExceeded extends /*@__PURE__*/ RumSiteQuotaExceeded_base {
}
declare const SiteNotFound_base: S.TaggedErrorClass<"SiteNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SiteNotFound extends /*@__PURE__*/ SiteNotFound_base {
}
export type RulesBulkCreateRequestDeleteRulesList = Array<string>;
export type RulesBulkCreateRequestRulesItemPathsList = Array<string>;
export interface RulesBulkCreateRequestRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string;
    host?: string;
    inclusive?: boolean;
    isPaused?: boolean;
    paths?: RulesBulkCreateRequestRulesItemPathsList;
}
export type RulesBulkCreateRequestRulesList = Array<RulesBulkCreateRequestRulesItem>;
export interface BulkCreateRulesRequest {
    /** Identifier. */
    accountId: string;
    /** The Web Analytics ruleset identifier. */
    rulesetId: string;
    /** A list of rule identifiers to delete. */
    deleteRules?: RulesBulkCreateRequestDeleteRulesList;
    /** A list of rules to create or update. */
    rules?: RulesBulkCreateRequestRulesList;
}
export type RulesBulkCreateResponseRulesItemPathsList = Array<string>;
export interface RulesBulkCreateResponseRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: RulesBulkCreateResponseRulesItemPathsList | null;
    priority?: number | null;
}
export type RulesBulkCreateResponseRulesList = Array<RulesBulkCreateResponseRulesItem>;
export interface RulesBulkCreateResponseRuleset {
    /** The Web Analytics ruleset identifier. */
    id?: string | null;
    /** Whether the ruleset is enabled. */
    enabled?: boolean | null;
    zoneName?: string | null;
    /** The zone identifier. */
    zoneTag?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkCreateRulesResponse {
    /** A list of rules. */
    rules?: RulesBulkCreateResponseRulesList | null;
    ruleset?: RulesBulkCreateResponseRuleset | null;
}
export type RulesCreateRequestPathsList = Array<string>;
export interface CreateRuleRequest {
    /** Identifier. */
    accountId: string;
    /** The Web Analytics ruleset identifier. */
    rulesetId: string;
    host?: string;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean;
    /** Whether the rule is paused or not. */
    isPaused?: boolean;
    paths?: RulesCreateRequestPathsList;
}
export type RulesCreateResponsePathsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRuleResponse {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: RulesCreateResponsePathsList | null;
    priority?: number | null;
}
export interface CreateSiteInfoRequest {
    /** Identifier. */
    accountId: string;
    /** If enabled, the JavaScript snippet is automatically injected for orange-clouded sites. */
    autoInstall?: boolean;
    /** The hostname to use for gray-clouded sites. */
    host?: string;
    /** The zone identifier. */
    zoneTag?: string;
}
export type SiteInfoCreateResponseRulesItemPathsList = Array<string>;
export interface SiteInfoCreateResponseRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: SiteInfoCreateResponseRulesItemPathsList | null;
    priority?: number | null;
}
export type SiteInfoCreateResponseRulesList = Array<SiteInfoCreateResponseRulesItem>;
export type SiteInfoCreateResponseRuleset = RulesBulkCreateResponseRuleset;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSiteInfoResponse {
    /** If enabled, the JavaScript snippet is automatically injected for orange-clouded sites. */
    autoInstall?: boolean | null;
    created?: string | null;
    /** A list of rules. */
    rules?: SiteInfoCreateResponseRulesList | null;
    ruleset?: RulesBulkCreateResponseRuleset | null;
    /** The Web Analytics site identifier. */
    siteTag?: string | null;
    /** The Web Analytics site token. */
    siteToken?: string | null;
    /** Encoded JavaScript snippet. */
    snippet?: string | null;
    /** The hostname the site measures (gray-clouded sites). */
    host?: string | null;
}
export interface DeleteRuleRequest {
    /** Identifier. */
    accountId: string;
    /** The Web Analytics ruleset identifier. */
    rulesetId: string;
    /** The Web Analytics rule identifier. */
    ruleId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRuleResponse {
    /** The Web Analytics rule identifier. */
    id?: string | null;
}
export interface DeleteSiteInfoRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    siteId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSiteInfoResponse {
    /** The Web Analytics site identifier. */
    siteTag?: string | null;
}
export interface GetSiteInfoRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    siteId: string;
}
export type SiteInfoGetResponseRulesItemPathsList = Array<string>;
export interface SiteInfoGetResponseRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: SiteInfoGetResponseRulesItemPathsList | null;
    priority?: number | null;
}
export type SiteInfoGetResponseRulesList = Array<SiteInfoGetResponseRulesItem>;
export type SiteInfoGetResponseRuleset = RulesBulkCreateResponseRuleset;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSiteInfoResponse {
    /** If enabled, the JavaScript snippet is automatically injected for orange-clouded sites. */
    autoInstall?: boolean | null;
    created?: string | null;
    /** A list of rules. */
    rules?: SiteInfoGetResponseRulesList | null;
    ruleset?: RulesBulkCreateResponseRuleset | null;
    /** The Web Analytics site identifier. */
    siteTag?: string | null;
    /** The Web Analytics site token. */
    siteToken?: string | null;
    /** Encoded JavaScript snippet. */
    snippet?: string | null;
    /** The hostname the site measures (gray-clouded sites). */
    host?: string | null;
}
export interface ListRulesRequest {
    /** Identifier. */
    accountId: string;
    /** The Web Analytics ruleset identifier. */
    rulesetId: string;
}
export type RulesListResponseRulesItemPathsList = Array<string>;
export interface RulesListResponseRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: RulesListResponseRulesItemPathsList | null;
    priority?: number | null;
}
export type RulesListResponseRulesList = Array<RulesListResponseRulesItem>;
export type RulesListResponseRuleset = RulesBulkCreateResponseRuleset;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListRulesResponse {
    /** A list of rules. */
    rules?: RulesListResponseRulesList | null;
    ruleset?: RulesBulkCreateResponseRuleset | null;
}
export type SiteInfoListRequestOrderBy = "host" | "created";
export interface ListSiteInfosRequest {
    /** Identifier. */
    accountId: string;
    /** The property used to sort the list of results. */
    orderBy?: SiteInfoListRequestOrderBy | (string & {});
    /** Current page within the paginated list of results. */
    page?: number;
    /** Number of items to return per page of results. */
    perPage?: number;
}
export type SiteInfoListResultItemRulesItemPathsList = Array<string>;
export interface SiteInfoListResultItemRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: SiteInfoListResultItemRulesItemPathsList | null;
    priority?: number | null;
}
export type SiteInfoListResultItemRulesList = Array<SiteInfoListResultItemRulesItem>;
export type SiteInfoListResultItemRuleset = RulesBulkCreateResponseRuleset;
export interface SiteInfoListResultItem {
    /** If enabled, the JavaScript snippet is automatically injected for orange-clouded sites. */
    autoInstall?: boolean | null;
    created?: string | null;
    /** A list of rules. */
    rules?: SiteInfoListResultItemRulesList | null;
    ruleset?: RulesBulkCreateResponseRuleset | null;
    /** The Web Analytics site identifier. */
    siteTag?: string | null;
    /** The Web Analytics site token. */
    siteToken?: string | null;
    /** Encoded JavaScript snippet. */
    snippet?: string | null;
    /** The hostname the site measures (gray-clouded sites). */
    host?: string | null;
}
export type SiteInfoListResultList = Array<SiteInfoListResultItem>;
export interface ListSiteInfosResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SiteInfoListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type RulesUpdateRequestPathsList = Array<string>;
export interface UpdateRuleRequest {
    /** Identifier. */
    accountId: string;
    /** The Web Analytics ruleset identifier. */
    rulesetId: string;
    /** The Web Analytics rule identifier. */
    ruleId: string;
    host?: string;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean;
    /** Whether the rule is paused or not. */
    isPaused?: boolean;
    paths?: RulesUpdateRequestPathsList;
}
export type RulesUpdateResponsePathsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRuleResponse {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: RulesUpdateResponsePathsList | null;
    priority?: number | null;
}
export interface UpdateSiteInfoRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    siteId: string;
    /** If enabled, the JavaScript snippet is automatically injected for orange-clouded sites. */
    autoInstall?: boolean;
    /** Enables or disables RUM. This option can be used only when auto_install is set to true. */
    enabled?: boolean;
    /** The hostname to use for gray-clouded sites. */
    host?: string;
    /** If enabled, the JavaScript snippet will not be injected for visitors from the EU. */
    lite?: boolean;
    /** The zone identifier. */
    zoneTag?: string;
}
export type SiteInfoUpdateResponseRulesItemPathsList = Array<string>;
export interface SiteInfoUpdateResponseRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: SiteInfoUpdateResponseRulesItemPathsList | null;
    priority?: number | null;
}
export type SiteInfoUpdateResponseRulesList = Array<SiteInfoUpdateResponseRulesItem>;
export type SiteInfoUpdateResponseRuleset = RulesBulkCreateResponseRuleset;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSiteInfoResponse {
    /** If enabled, the JavaScript snippet is automatically injected for orange-clouded sites. */
    autoInstall?: boolean | null;
    created?: string | null;
    /** A list of rules. */
    rules?: SiteInfoUpdateResponseRulesList | null;
    ruleset?: RulesBulkCreateResponseRuleset | null;
    /** The Web Analytics site identifier. */
    siteTag?: string | null;
    /** The Web Analytics site token. */
    siteToken?: string | null;
    /** Encoded JavaScript snippet. */
    snippet?: string | null;
    /** The hostname the site measures (gray-clouded sites). */
    host?: string | null;
}
export type BulkCreateRulesError = CloudflareOpError;
/** Modifies one or more rules in a Web Analytics ruleset with a single request. */
export declare const bulkCreateRules: API.OperationMethod<BulkCreateRulesRequest, BulkCreateRulesResponse, BulkCreateRulesError, CloudflareOpContext>;
export type CreateRuleError = Forbidden | RulesetNotFound | MaxRulesExceeded | CloudflareOpError;
/** Creates a new rule in a Web Analytics ruleset. */
export declare const createRule: API.OperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, CloudflareOpContext>;
export type CreateSiteInfoError = Forbidden | RumSiteQuotaExceeded | CloudflareOpError;
/** Creates a new Web Analytics site. */
export declare const createSiteInfo: API.OperationMethod<CreateSiteInfoRequest, CreateSiteInfoResponse, CreateSiteInfoError, CloudflareOpContext>;
export type DeleteRuleError = Forbidden | RulesetNotFound | RuleNotFound | CloudflareOpError;
/** Deletes an existing rule from a Web Analytics ruleset. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type DeleteSiteInfoError = SiteNotFound | Forbidden | CloudflareOpError;
/** Deletes an existing Web Analytics site. */
export declare const deleteSiteInfo: API.OperationMethod<DeleteSiteInfoRequest, DeleteSiteInfoResponse, DeleteSiteInfoError, CloudflareOpContext>;
export type GetSiteInfoError = SiteNotFound | Forbidden | CloudflareOpError;
/** Retrieves a Web Analytics site. */
export declare const getSiteInfo: API.OperationMethod<GetSiteInfoRequest, GetSiteInfoResponse, GetSiteInfoError, CloudflareOpContext>;
export type ListRulesError = Forbidden | RulesetNotFound | CloudflareOpError;
/** Lists all the rules in a Web Analytics ruleset. */
export declare const listRules: API.OperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext>;
export type ListSiteInfosError = Forbidden | CloudflareOpError;
/** Lists all Web Analytics sites of an account. */
export declare const listSiteInfos: API.PaginatedOperationMethod<ListSiteInfosRequest, ListSiteInfosResponse, ListSiteInfosError, CloudflareOpContext, SiteInfoListResultItem>;
export type UpdateRuleError = Forbidden | RulesetNotFound | CloudflareOpError;
/** Updates a rule in a Web Analytics ruleset. */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, CloudflareOpContext>;
export type UpdateSiteInfoError = SiteNotFound | Forbidden | CloudflareOpError;
/** Updates an existing Web Analytics site. */
export declare const updateSiteInfo: API.OperationMethod<UpdateSiteInfoRequest, UpdateSiteInfoResponse, UpdateSiteInfoError, CloudflareOpContext>;
//# sourceMappingURL=rum.d.ts.map