import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const K2AppendOutcomeUnknown_base: S.TaggedErrorClass<"K2AppendOutcomeUnknown", {
    readonly code: any;
    readonly message: any;
}>;
/** 10212 (HTTP 503): K2 could not append the batch and it MAY have been stored. K2 does not deduplicate, so retrying can store it twice; never retried automatically. */
export declare class K2AppendOutcomeUnknown extends /*@__PURE__*/ K2AppendOutcomeUnknown_base {
}
declare const K2BatchPending_base: S.TaggedErrorClass<"K2BatchPending", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
/** 10217: K2 is still reading a batch for this worker_id from an earlier request. Retry to receive it. */
export declare class K2BatchPending extends /*@__PURE__*/ K2BatchPending_base {
}
declare const K2InvalidRequest_base: S.TaggedErrorClass<"K2InvalidRequest", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** 10204: the request is invalid (malformed JSON or base64, a field out of range, both inputs disabled, an empty batch). */
export declare class K2InvalidRequest extends /*@__PURE__*/ K2InvalidRequest_base {
}
declare const K2LeaseLost_base: S.TaggedErrorClass<"K2LeaseLost", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
/** 10218: the lease is no longer held by this worker (expired, released, acknowledged, or redelivered). Do not retry; consume a new batch. */
export declare class K2LeaseLost extends /*@__PURE__*/ K2LeaseLost_base {
}
declare const K2LeasesExhausted_base: S.TaggedErrorClass<"K2LeasesExhausted", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
/** 10216: every one of the subscription's 128 leases is held. Retry after a lease is acknowledged, released, or expires. */
export declare class K2LeasesExhausted extends /*@__PURE__*/ K2LeasesExhausted_base {
}
declare const K2NameAlreadyExists_base: S.TaggedErrorClass<"K2NameAlreadyExists", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** 10201: a stream with this name exists, or a subscription with this name exists with different settings. */
export declare class K2NameAlreadyExists extends /*@__PURE__*/ K2NameAlreadyExists_base {
}
declare const K2ReadFailed_base: S.TaggedErrorClass<"K2ReadFailed", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
/** 10214: K2 could not read records from storage. Retry the request. */
export declare class K2ReadFailed extends /*@__PURE__*/ K2ReadFailed_base {
}
declare const K2RecordTooLarge_base: S.TaggedErrorClass<"K2RecordTooLarge", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** 10207: a record exceeds 1 MB (content and headers combined). */
export declare class K2RecordTooLarge extends /*@__PURE__*/ K2RecordTooLarge_base {
}
declare const K2RequestTooLarge_base: S.TaggedErrorClass<"K2RequestTooLarge", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** 10206: the produce request exceeds 5 MB, before or after decompression. */
export declare class K2RequestTooLarge extends /*@__PURE__*/ K2RequestTooLarge_base {
}
declare const K2StreamNotFound_base: S.TaggedErrorClass<"K2StreamNotFound", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** 10200: the stream does not exist (or, on produce, the input is not enabled). */
export declare class K2StreamNotFound extends /*@__PURE__*/ K2StreamNotFound_base {
}
declare const K2SubscriptionLimitExceeded_base: S.TaggedErrorClass<"K2SubscriptionLimitExceeded", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** 10219: the stream already has the maximum of 100 subscriptions. */
export declare class K2SubscriptionLimitExceeded extends /*@__PURE__*/ K2SubscriptionLimitExceeded_base {
}
declare const K2SubscriptionNotFound_base: S.TaggedErrorClass<"K2SubscriptionNotFound", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** 10215: the subscription does not exist. */
export declare class K2SubscriptionNotFound extends /*@__PURE__*/ K2SubscriptionNotFound_base {
}
declare const K2Unavailable_base: S.TaggedErrorClass<"K2Unavailable", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
/** 10211: K2 is temporarily unavailable. On produce the batch was NOT stored; retry it. */
export declare class K2Unavailable extends /*@__PURE__*/ K2Unavailable_base {
}
export interface AckBatchRequest {
    streamId: string;
    subscriptionId: string;
    batchId: string;
    /** The consumer holding (or requesting) the lease, 1 to 256 characters. */
    workerId: string;
}
export interface AckBatchResponse {
}
export interface ConsumeRequest {
    streamId: string;
    subscriptionId: string;
    /** The consumer holding (or requesting) the lease, 1 to 256 characters. */
    workerId: string;
    /** At most this many records, from 1 to 10000. */
    maxRecords: number;
}
export type RecordHeaders = {
    [key: string]: string | undefined;
};
export interface ConsumedRecord {
    /** When K2 received the record, in Unix milliseconds. */
    timestampMs: number;
    /** The record payload as standard base64. */
    content: string;
    /** The record headers; omitted when it was produced without any. */
    headers?: RecordHeaders | null;
}
export type ConsumedRecordList = Array<ConsumedRecord>;
export interface ConsumeResponse {
    /** The leased batch, or null when there were no records. */
    batchId?: string | null;
    /** When the lease expires, in Unix milliseconds. */
    leasedUntilMs?: number | null;
    records: ConsumedRecordList;
}
export type CorsOriginList = Array<string>;
export interface StreamCors {
    /** Origins allowed to produce from a browser: `http(s)://host[:port]` without a path, or `*` alone. Up to five. */
    origins?: CorsOriginList | null;
}
export interface StreamHttpInput {
    /** Whether the `/produce` endpoint accepts records. */
    enabled: boolean;
    /** Require an API token with the K2 Produce permission. When false or omitted the endpoint is public. */
    authentication?: boolean | null;
    cors?: StreamCors | null;
}
export interface StreamWorkerBindingInput {
    /** Whether Workers can produce to the stream through a `k2` binding. */
    enabled: boolean;
}
export interface CreateStreamRequest {
    accountId: string;
    /** 1 to 128 letters, numbers, or underscores. Unique in the account, not case-sensitive. */
    name: string;
    /** From 3600 (one hour) to 2592000 (30 days). Defaults to 604800 (seven days). */
    retentionSeconds?: number;
    http: StreamHttpInput;
    /** Defaults to enabled. */
    workerBinding?: StreamWorkerBindingInput;
}
export interface CreateStreamResponse {
    /** The stream ID: 32 lowercase hexadecimal characters. */
    id: string;
    /** 1 to 128 letters, numbers, or underscores. Unique in the account, not case-sensitive. */
    name: string;
    /** How long records are retained, from 3600 to 2592000 seconds. */
    retentionSeconds: number;
    /** The stream's HTTP endpoint, `https://<id>.k2.cloudflarestorage.com`. */
    endpoint: string;
    http: StreamHttpInput;
    workerBinding: StreamWorkerBindingInput;
    createdAt: string;
    modifiedAt: string;
}
export type StartAtType = "earliest" | "latest";
export interface SubscriptionStartAt {
    /** `earliest` reads from the oldest retained record; `latest` from after the newest one. */
    type: StartAtType | (string & {});
}
export interface CreateSubscriptionRequest {
    streamId: string;
    /** 1 to 128 letters, numbers, underscores, or hyphens. Unique within the stream, not case-sensitive. */
    name: string;
    startAt: SubscriptionStartAt;
}
export interface CreateSubscriptionResponse {
    /** The subscription ID. */
    id: string;
}
export interface DeleteStreamRequest {
    accountId: string;
    streamId: string;
}
export interface DeleteStreamResponse {
}
export interface DeleteSubscriptionRequest {
    streamId: string;
    subscriptionId: string;
}
export interface DeleteSubscriptionResponse {
    /** The deleted subscription's ID. */
    id: string;
}
export interface ExtendLeaseRequest {
    streamId: string;
    subscriptionId: string;
    batchId: string;
    /** The consumer holding (or requesting) the lease, 1 to 256 characters. */
    workerId: string;
}
export interface ExtendLeaseResponse {
    /** The new lease expiry, in Unix milliseconds. */
    leasedUntilMs: number;
}
export interface GetStreamRequest {
    accountId: string;
    streamId: string;
}
export interface GetStreamResponse {
    /** The stream ID: 32 lowercase hexadecimal characters. */
    id: string;
    /** 1 to 128 letters, numbers, or underscores. Unique in the account, not case-sensitive. */
    name: string;
    /** How long records are retained, from 3600 to 2592000 seconds. */
    retentionSeconds: number;
    /** The stream's HTTP endpoint, `https://<id>.k2.cloudflarestorage.com`. */
    endpoint: string;
    http: StreamHttpInput;
    workerBinding: StreamWorkerBindingInput;
    createdAt: string;
    modifiedAt: string;
}
export interface GetSubscriptionRequest {
    streamId: string;
    subscriptionId: string;
}
export interface GetSubscriptionResponse {
    /** The subscription ID. */
    id: string;
    /** 1 to 128 letters, numbers, underscores, or hyphens. Unique within the stream, not case-sensitive. */
    name: string;
    startAt: SubscriptionStartAt;
    createdAt: string;
    modifiedAt: string;
}
export interface ListMonitoredSubscriptionsRequest {
    accountId: string;
    streamId: string;
}
export type ConsumerLagStatus = "available" | "unsupported" | "unavailable";
export interface ConsumerLag {
    status: ConsumerLagStatus;
    /** Decimal string: records between the subscription's committed position and the stream tail. Null unless `status` is `available`. */
    records?: string | null;
}
export interface MonitoredSubscription {
    /** The subscription ID. */
    id: string;
    /** 1 to 128 letters, numbers, underscores, or hyphens. Unique within the stream, not case-sensitive. */
    name: string;
    startAt: SubscriptionStartAt;
    createdAt: string;
    modifiedAt: string;
    lag: ConsumerLag;
}
export type MonitoredSubscriptionList = Array<MonitoredSubscription>;
export type ListMonitoredSubscriptionsResponse = MonitoredSubscriptionList;
export interface ListStreamsRequest {
    accountId: string;
    page?: number;
    perPage?: number;
}
export interface Stream {
    /** The stream ID: 32 lowercase hexadecimal characters. */
    id: string;
    /** 1 to 128 letters, numbers, or underscores. Unique in the account, not case-sensitive. */
    name: string;
    /** How long records are retained, from 3600 to 2592000 seconds. */
    retentionSeconds: number;
    /** The stream's HTTP endpoint, `https://<id>.k2.cloudflarestorage.com`. */
    endpoint: string;
    http: StreamHttpInput;
    workerBinding: StreamWorkerBindingInput;
    createdAt: string;
    modifiedAt: string;
}
export type StreamList = Array<Stream>;
export interface ListStreamsResponse {
    result: StreamList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListSubscriptionsRequest {
    streamId: string;
    name?: string;
}
export interface Subscription {
    /** The subscription ID. */
    id: string;
    /** 1 to 128 letters, numbers, underscores, or hyphens. Unique within the stream, not case-sensitive. */
    name: string;
    startAt: SubscriptionStartAt;
    createdAt: string;
    modifiedAt: string;
}
export type SubscriptionList = Array<Subscription>;
export type ListSubscriptionsResponse = SubscriptionList;
export interface NackBatchRequest {
    streamId: string;
    subscriptionId: string;
    batchId: string;
    /** The consumer holding (or requesting) the lease, 1 to 256 characters. */
    workerId: string;
}
export interface NackBatchResponse {
}
export interface ProduceRecord {
    /** The record payload as standard (padded, not URL-safe) base64. */
    content: string;
    /** Up to 32 string headers describing the content. */
    headers?: RecordHeaders;
}
export type ProduceRecordList = Array<ProduceRecord>;
export interface ProduceRequest {
    streamId: string;
    records: ProduceRecordList;
}
export interface ProduceResponse {
}
export interface UpdateStreamRequest {
    accountId: string;
    streamId: string;
    retentionSeconds?: number;
    http?: StreamHttpInput;
    workerBinding?: StreamWorkerBindingInput;
}
export interface UpdateStreamResponse {
    /** The stream ID: 32 lowercase hexadecimal characters. */
    id: string;
    /** 1 to 128 letters, numbers, or underscores. Unique in the account, not case-sensitive. */
    name: string;
    /** How long records are retained, from 3600 to 2592000 seconds. */
    retentionSeconds: number;
    /** The stream's HTTP endpoint, `https://<id>.k2.cloudflarestorage.com`. */
    endpoint: string;
    http: StreamHttpInput;
    workerBinding: StreamWorkerBindingInput;
    createdAt: string;
    modifiedAt: string;
}
export type AckBatchError = K2StreamNotFound | K2SubscriptionNotFound | CloudflareOpError;
/** Mark a batch processed and release its lease. Acknowledging an unknown or already acknowledged batch succeeds. */
export declare const ackBatch: API.OperationMethod<AckBatchRequest, AckBatchResponse, AckBatchError, CloudflareOpContext>;
export type ConsumeError = K2StreamNotFound | K2SubscriptionNotFound | K2InvalidRequest | K2Unavailable | K2ReadFailed | K2LeasesExhausted | K2BatchPending | CloudflareOpError;
/** Lease the next batch of records to `worker_id` for five minutes. An empty batch has a null `batch_id`. A worker that already holds a lease gets the same batch back, with the lease refreshed. */
export declare const consume: API.OperationMethod<ConsumeRequest, ConsumeResponse, ConsumeError, CloudflareOpContext>;
export type CreateStreamError = K2NameAlreadyExists | K2InvalidRequest | CloudflareOpError;
/** Create a K2 stream. At least one of `http` and `worker_binding` must be enabled. */
export declare const createStream: API.OperationMethod<CreateStreamRequest, CreateStreamResponse, CreateStreamError, CloudflareOpContext>;
export type CreateSubscriptionError = K2StreamNotFound | K2NameAlreadyExists | K2InvalidRequest | K2SubscriptionLimitExceeded | CloudflareOpError;
/** Create a subscription. Creating one with the same name and settings returns the existing ID. */
export declare const createSubscription: API.OperationMethod<CreateSubscriptionRequest, CreateSubscriptionResponse, CreateSubscriptionError, CloudflareOpContext>;
export type DeleteStreamError = CloudflareOpError;
/** Delete a stream and all of its records. Deleting a stream that does not exist succeeds. */
export declare const deleteStream: API.OperationMethod<DeleteStreamRequest, DeleteStreamResponse, DeleteStreamError, CloudflareOpContext>;
export type DeleteSubscriptionError = K2StreamNotFound | K2SubscriptionNotFound | CloudflareOpError;
/** Delete a subscription. Deleting one that does not exist fails with K2SubscriptionNotFound. */
export declare const deleteSubscription: API.OperationMethod<DeleteSubscriptionRequest, DeleteSubscriptionResponse, DeleteSubscriptionError, CloudflareOpContext>;
export type ExtendLeaseError = K2StreamNotFound | K2SubscriptionNotFound | K2LeaseLost | CloudflareOpError;
/** Extend a held lease to five minutes from now. Fails with K2LeaseLost when `worker_id` no longer holds it. */
export declare const extendLease: API.OperationMethod<ExtendLeaseRequest, ExtendLeaseResponse, ExtendLeaseError, CloudflareOpContext>;
export type GetStreamError = K2StreamNotFound | CloudflareOpError;
/** Get a K2 stream. */
export declare const getStream: API.OperationMethod<GetStreamRequest, GetStreamResponse, GetStreamError, CloudflareOpContext>;
export type GetSubscriptionError = K2StreamNotFound | K2SubscriptionNotFound | CloudflareOpError;
/** Get a subscription. */
export declare const getSubscription: API.OperationMethod<GetSubscriptionRequest, GetSubscriptionResponse, GetSubscriptionError, CloudflareOpContext>;
export type ListMonitoredSubscriptionsError = K2StreamNotFound | CloudflareOpError;
/** List a stream's subscriptions with their consumer lag (control plane; needs K2 Config Read). */
export declare const listMonitoredSubscriptions: API.OperationMethod<ListMonitoredSubscriptionsRequest, ListMonitoredSubscriptionsResponse, ListMonitoredSubscriptionsError, CloudflareOpContext>;
export type ListStreamsError = CloudflareOpError;
/** List the account's K2 streams. */
export declare const listStreams: API.PaginatedOperationMethod<ListStreamsRequest, ListStreamsResponse, ListStreamsError, CloudflareOpContext, Stream>;
export type ListSubscriptionsError = K2StreamNotFound | CloudflareOpError;
/** List a stream's subscriptions, oldest first. With `name`, at most one. */
export declare const listSubscriptions: API.OperationMethod<ListSubscriptionsRequest, ListSubscriptionsResponse, ListSubscriptionsError, CloudflareOpContext>;
export type NackBatchError = K2StreamNotFound | K2SubscriptionNotFound | CloudflareOpError;
/** Release a batch for redelivery in the next consume, under a new batch ID. */
export declare const nackBatch: API.OperationMethod<NackBatchRequest, NackBatchResponse, NackBatchError, CloudflareOpContext>;
export type ProduceError = K2StreamNotFound | K2InvalidRequest | K2RequestTooLarge | K2RecordTooLarge | K2Unavailable | K2AppendOutcomeUnknown | CloudflareOpError;
/** Append a batch of records atomically. Needs the stream's HTTP input enabled. */
export declare const produce: API.OperationMethod<ProduceRequest, ProduceResponse, ProduceError, CloudflareOpContext>;
export type UpdateStreamError = K2StreamNotFound | K2InvalidRequest | CloudflareOpError;
/** Update a stream's retention or inputs. A provided input object replaces the existing one; the name cannot change. */
export declare const updateStream: API.OperationMethod<UpdateStreamRequest, UpdateStreamResponse, UpdateStreamError, CloudflareOpContext>;
//# sourceMappingURL=k2.d.ts.map