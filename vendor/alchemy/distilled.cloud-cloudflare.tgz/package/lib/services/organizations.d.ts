import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const OrganizationNotFound_base: S.TaggedErrorClass<"OrganizationNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class OrganizationNotFound extends /*@__PURE__*/ OrganizationNotFound_base {
}
export interface CreateMemberRequestMemberUser {
    email: string;
}
export type CreateMemberRequestMemberStatus = "active" | "canceled";
export interface CreateMemberRequestMember {
    user: CreateMemberRequestMemberUser;
    status?: CreateMemberRequestMemberStatus | (string & {});
}
export interface CreateMemberRequest {
    organizationId: string;
    member: CreateMemberRequestMember;
}
export type CreateMemberResponseMetaMap = {
    [key: string]: unknown | undefined;
};
export type CreateMemberResponseStatus = "active" | "pending" | "rejected" | "canceled";
export interface CreateMemberResponseUser {
    id: string;
    email: string;
    name: string;
    twoFactorAuthenticationEnabled: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMemberResponse {
    /** Organization Member ID */
    id: string;
    createTime: string;
    meta: CreateMemberResponseMetaMap;
    status: CreateMemberResponseStatus;
    updateTime: string;
    user: CreateMemberResponseUser;
}
export interface CreateRequestParent {
    id: string;
    name?: string;
}
export interface CreateRequestProfile {
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export interface CreateOrganizationRequest {
    name: string;
    parent?: CreateRequestParent;
    profile?: CreateRequestProfile;
}
export type CreateResponseMetaHierarchyTagsList = Array<string>;
export interface CreateResponseMetaTenantFlags {
    accountCreation: string;
    accountCreationAppliesTenantDefaults: string;
    accountDeletion: string;
    accountMigration: string;
    accountMobility: string;
    enterpriseCapability: string;
    memberManagement: string;
    subOrgCreation: string;
}
export interface CreateResponseMeta {
    /** Ordered chain of organization tags from the root organization down to (and including) this organization itself. Root organizations return a single-element array containing their own tag; sub-organizations return `[rootTag, ...intermediateTags, parentTag, selfTag]`. Useful for constructing authorization scopes that need to cover every ancestor in the hierarchy. */
    hierarchyTags?: CreateResponseMetaHierarchyTagsList | null;
    managedBy?: string | null;
    /** Enable features for Organizations. */
    tenantFlags?: CreateResponseMetaTenantFlags | null;
}
export interface CreateResponseParent {
    id: string;
    name: string;
}
export type CreateResponseProfile = CreateRequestProfile;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOrganizationResponse {
    id: string;
    createTime: string;
    meta: CreateResponseMeta;
    name: string;
    parent?: CreateResponseParent | null;
    profile?: CreateRequestProfile | null;
}
export interface DeleteMemberRequest {
    organizationId: string;
    /** Organization Member ID */
    memberId: string;
}
export interface DeleteMemberResponse {
}
export interface DeleteOrganizationRequest {
    organizationId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOrganizationResponse {
    id: string;
}
export interface GetBillingUsageRequest {
    /** Represents a Cloudflare resource identifier tag. */
    organizationId: string;
    /** Start date for the usage query (ISO 8601). Required if `to` is set. When omitted along with `to`, defaults to the start of the current month. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    from?: string;
    /** End date for the usage query (ISO 8601). Required if `from` is set. When omitted along with `from`, defaults to today. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    to?: string;
}
export type BillingUsageGetResultItemChargeCategory = "Usage";
export type BillingUsageGetResultItemChargeFrequency = "Usage-Based";
export type BillingUsageGetResultItemChargeClass = "Correction";
export type BillingUsageGetResultItemTagsValue = string | boolean;
export type BillingUsageGetResultItemTagsMap = {
    [key: string]: BillingUsageGetResultItemTagsValue | undefined;
};
export interface BillingUsageGetResultItem {
    /** Highest-level classification of a charge based on the nature of how it gets billed. Currently only "Usage" is supported. */
    chargeCategory: BillingUsageGetResultItemChargeCategory;
    /** Self-contained summary of the charge's purpose and price. */
    chargeDescription: string;
    /** Indicates how often a charge occurs. Currently only "Usage-Based" is supported. */
    chargeFrequency: BillingUsageGetResultItemChargeFrequency;
    /** Exclusive end of the time interval during which the usage was consumed. */
    chargePeriodEnd: string;
    /** Inclusive start of the time interval during which the usage was consumed. */
    chargePeriodStart: string;
    /** Unit of measure for the consumed quantity (e.g., "GB", "Requests", "vCPU-Hours"). */
    consumedUnit: string;
    /** Name of the entity providing the underlying infrastructure or platform. */
    hostProviderName: string;
    /** Name of the entity responsible for invoicing for the services consumed. */
    invoiceIssuerName: string;
    /** Name of the entity that made the services available for purchase. */
    serviceProviderName: string;
    /** The unique identifier for the billable metric in the Cloudflare catalog. Cloudflare extension; replaces FOCUS SkuId. */
    xBillableMetricId: string;
    /** A charge serving as the basis for invoicing, inclusive of all reduced rates and discounts while excluding the amortization of upfront charges (one-time or recurring). */
    billedCost?: number | null;
    /** Public identifier of the Cloudflare account (account tag). Omitted when account is not part of the requested grouping, and always omitted for usage measured at contract level, even when grouping by account: that usage is returned as its own record with no account. */
    billingAccountId?: string | null;
    /** Display name of the Cloudflare account. Omitted when account is not part of the requested grouping, and for usage measured at contract level. */
    billingAccountName?: string | null;
    /** Currency that a charge was billed in (ISO 4217). */
    billingCurrency?: string | null;
    /** Exclusive end of the billing cycle that contains this usage record. */
    billingPeriodEnd?: string | null;
    /** Inclusive start of the billing cycle that contains this usage record. */
    billingPeriodStart?: string | null;
    /** Indicates whether the row represents a correction to one or more charges invoiced in a previous billing period. */
    chargeClass?: BillingUsageGetResultItemChargeClass | null;
    /** Measured usage amount within the charge period. Reflects raw metered consumption before pricing transformations. */
    consumedQuantity?: number | null;
    /** Cost calculated by multiplying ContractedUnitPrice and the corresponding PricingQuantity. */
    contractedCost?: number | null;
    /** The agreed-upon unit price for a single PricingUnit of the associated billable metric, inclusive of negotiated discounts, if present, while excluding any other discounts. */
    contractedUnitPrice?: number | null;
    /** The amortized cost of the charge after applying all reduced rates, discounts, and the applicable portion of relevant, prepaid purchases (one-time or recurring) that covered the charge. */
    effectiveCost?: number | null;
    /** Cost calculated by multiplying ListUnitPrice and the corresponding PricingQuantity. */
    listCost?: number | null;
    /** Suggested provider-published unit price for a single PricingUnit of the associated billable metric, exclusive of any discounts. */
    listUnitPrice?: number | null;
    /** Volume of a given service used or purchased, based on the PricingUnit. */
    pricingQuantity?: number | null;
    /** Provider-specified measurement unit for determining unit prices, indicating how the provider rates measured usage after applying pricing rules like block pricing. */
    pricingUnit?: string | null;
    /** Provider-assigned identifier for an isolated geographic area where a service is provided. */
    regionId?: string | null;
    /** Name of an isolated geographic area where a service is provided. */
    regionName?: string | null;
    /** Unique identifier assigned to a grouping of services. For Cloudflare, this is the subscription or contract ID. */
    subAccountId?: string | null;
    /** Name assigned to a grouping of services. For Cloudflare, this is the subscription or contract display name. */
    subAccountName?: string | null;
    /** Tag values for the requested `GroupBy` keys. Omitted when `GroupBy` is not provided. Missing keys are omitted, and key-only tags are returned as boolean `true`. All other tag values are strings. */
    tags?: BillingUsageGetResultItemTagsMap | null;
    /** The display name of the billable metric. Cloudflare extension; replaces FOCUS SkuMeter. */
    xBillableMetricName?: string | null;
    /** The product category the charge belongs to (e.g., "Developer", "Cloudflare One"). Cloudflare extension; replaces FOCUS ServiceCategory. */
    xProductCategoryName?: string | null;
    /** The unique identifier for the product family in the Cloudflare catalog. Cloudflare extension; replaces FOCUS ServiceId. */
    xProductFamilyId?: string | null;
    /** The product family the charge belongs to (e.g., "R2", "Workers"). Cloudflare extension; replaces FOCUS ServiceName. */
    xProductFamilyName?: string | null;
    /** The identifier for the Cloudflare zone (zone tag). Omitted when zone is not part of the requested grouping, and always omitted for usage measured at contract level, even when grouping by zone. Cloudflare extension. */
    xZoneId?: string | null;
    /** The display name of the Cloudflare zone. Omitted when zone is not part of the requested grouping, and for usage measured at contract level. Cloudflare extension. */
    xZoneName?: string | null;
}
export type BillingUsageGetResultList = Array<BillingUsageGetResultItem>;
export type GetBillingUsageResponse = BillingUsageGetResultList;
export interface GetMemberRequest {
    organizationId: string;
    /** Organization Member ID */
    memberId: string;
}
export type GetMemberResponseMetaMap = {
    [key: string]: unknown | undefined;
};
export type GetMemberResponseStatus = "active" | "pending" | "rejected" | "canceled";
export type GetMemberResponseUser = CreateMemberResponseUser;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMemberResponse {
    /** Organization Member ID */
    id: string;
    createTime: string;
    meta: GetMemberResponseMetaMap;
    status: GetMemberResponseStatus;
    updateTime: string;
    user: CreateMemberResponseUser;
}
export interface GetOrganizationRequest {
    organizationId: string;
}
export type GetResponseMetaHierarchyTagsList = Array<string>;
export type GetResponseMetaTenantFlags = CreateResponseMetaTenantFlags;
export interface GetResponseMeta {
    /** Ordered chain of organization tags from the root organization down to (and including) this organization itself. Root organizations return a single-element array containing their own tag; sub-organizations return `[rootTag, ...intermediateTags, parentTag, selfTag]`. Useful for constructing authorization scopes that need to cover every ancestor in the hierarchy. */
    hierarchyTags?: GetResponseMetaHierarchyTagsList | null;
    managedBy?: string | null;
    /** Enable features for Organizations. */
    tenantFlags?: CreateResponseMetaTenantFlags | null;
}
export type GetResponseParent = CreateResponseParent;
export type GetResponseProfile = CreateRequestProfile;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOrganizationResponse {
    id: string;
    createTime: string;
    meta: GetResponseMeta;
    name: string;
    parent?: CreateResponseParent | null;
    profile?: CreateRequestProfile | null;
}
export interface GetOrganizationAccountRequestAccountPubname {
    /** (case-insensitive) Filter the list of accounts to where the account_pubname contains a particular string. */
    contains?: string;
    /** (case-insensitive) Filter the list of accounts to where the account_pubname ends with a particular string. */
    endsWith?: string;
    /** (case-insensitive) Filter the list of accounts to where the account_pubname starts with a particular string. */
    startsWith?: string;
}
export type GetOrganizationAccountRequestDirection = "asc" | "desc";
export interface GetOrganizationAccountRequestName {
    /** (case-insensitive) Filter the list of accounts to where the name contains a particular string. */
    contains?: string;
    /** (case-insensitive) Filter the list of accounts to where the name ends with a particular string. */
    endsWith?: string;
    /** (case-insensitive) Filter the list of accounts to where the name starts with a particular string. */
    startsWith?: string;
}
export type GetOrganizationAccountRequestOrderBy = "account_name";
export interface GetOrganizationAccountRequest {
    organizationId: string;
    accountPubname?: GetOrganizationAccountRequestAccountPubname;
    /** Sort direction for the order_by field. Valid values: `asc`, `desc`. Defaults to `asc` when order_by is specified. */
    direction?: GetOrganizationAccountRequestDirection | (string & {});
    /** Include Account tags from the resource tag mirror. Omit this parameter to preserve the existing Account response shape. */
    includeTags?: boolean;
    /** Whether to calculate and return the exact result_info.total_size for cursor pagination. Defaults to true. When false, total_size is omitted. page_size and include_total may change between pages; next_page_token remains the authoritative continuation signal. Legacy page/per_page requests always calculate total_count. */
    includeTotal?: boolean;
    name?: GetOrganizationAccountRequestName;
    /** Field to order results by. Currently supported values: `account_name`. When not specified, results are ordered by internal account ID. */
    orderBy?: GetOrganizationAccountRequestOrderBy | (string & {});
    /** The amount of items to return. Defaults to 10. */
    pageSize?: number;
    /** An opaque token returned from the last list response that when provided will retrieve the next page. */
    pageToken?: string;
}
export interface GetOrganizationAccountResultItemSettings {
    abuseContactEmail: string;
    accessApprovalExpiry: string;
    apiAccessEnabled: boolean;
    /** Use [DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-an-account-list-dns-settings) instead. Deprecated. */
    defaultNameservers: string;
    enforceTwofactor: boolean;
    /** Use [DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-an-account-list-dns-settings) instead. Deprecated. */
    useAccountCustomNsByDefault: boolean;
}
export type GetOrganizationAccountResultItemType = "standard" | "enterprise";
export type GetOrganizationAccountResultItemTagsMap = {
    [key: string]: string | undefined;
};
export interface GetOrganizationAccountResultItem {
    id: string;
    createdOn: string;
    name: string;
    settings: GetOrganizationAccountResultItemSettings;
    type: GetOrganizationAccountResultItemType;
    /** Account tags, present only when `include_tags=true` is requested. */
    tags?: GetOrganizationAccountResultItemTagsMap | null;
}
export type GetOrganizationAccountResultList = Array<GetOrganizationAccountResultItem>;
export type GetOrganizationAccountResponse = GetOrganizationAccountResultList;
export interface GetOrganizationProfileRequest {
    organizationId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOrganizationProfileResponse {
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export type LogsAuditListRequestIdNotList = Array<string>;
export interface LogsAuditListRequestId {
    /** Filters out audit logs by their IDs. */
    not?: LogsAuditListRequestIdNotList;
}
export type LogsAuditListRequestActionResultNotItem = "success" | "failure";
export type LogsAuditListRequestActionResultNotList = Array<LogsAuditListRequestActionResultNotItem | (string & {})>;
export interface LogsAuditListRequestActionResult {
    /** Filters out audit logs by whether the action was successful or not. */
    not?: LogsAuditListRequestActionResultNotList;
}
export type LogsAuditListRequestActionTypeNotItem = "create" | "delete" | "view" | "update";
export type LogsAuditListRequestActionTypeNotList = Array<LogsAuditListRequestActionTypeNotItem | (string & {})>;
export interface LogsAuditListRequestActionType {
    /** Filters out audit logs by the action type. */
    not?: LogsAuditListRequestActionTypeNotList;
}
export type LogsAuditListRequestActorContextNotItem = "api" | "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export type LogsAuditListRequestActorContextNotList = Array<LogsAuditListRequestActorContextNotItem | (string & {})>;
export interface LogsAuditListRequestActorContext {
    /** Filters out audit logs by the actor context. */
    not?: LogsAuditListRequestActorContextNotList;
}
export type LogsAuditListRequestActorEmailNotList = Array<string>;
export interface LogsAuditListRequestActorEmail {
    /** Filters out audit logs by the actor's email address. */
    not?: LogsAuditListRequestActorEmailNotList;
}
export type LogsAuditListRequestActorIdNotList = Array<string>;
export interface LogsAuditListRequestActorId {
    /** Filters out audit logs by the actor's user ID. */
    not?: LogsAuditListRequestActorIdNotList;
}
export type LogsAuditListRequestActorIpAddressNotList = Array<string>;
export interface LogsAuditListRequestActorIpAddress {
    /** Filters out audit logs IP address where the action was initiated. */
    not?: LogsAuditListRequestActorIpAddressNotList;
}
export type LogsAuditListRequestActorTokenIdNotList = Array<string>;
export interface LogsAuditListRequestActorTokenId {
    /** Filters out audit logs by the API token ID when the actor context is an api_token or oauth. */
    not?: LogsAuditListRequestActorTokenIdNotList;
}
export type LogsAuditListRequestActorTokenNameNotList = Array<string>;
export interface LogsAuditListRequestActorTokenName {
    /** Filters out audit logs by the API token name when the actor context is an api_token or oauth. */
    not?: LogsAuditListRequestActorTokenNameNotList;
}
export type LogsAuditListRequestActorTypeNotItem = "cloudflare_admin" | "system" | "user";
export type LogsAuditListRequestActorTypeNotList = Array<LogsAuditListRequestActorTypeNotItem | (string & {})>;
export interface LogsAuditListRequestActorType {
    /** Filters out audit logs by the actor type. */
    not?: LogsAuditListRequestActorTypeNotList;
}
export type LogsAuditListRequestDirection = "desc" | "asc";
export type LogsAuditListRequestRawCfRayIdNotList = Array<string>;
export interface LogsAuditListRequestRawCfRayId {
    /** Filters out audit logs by the response CF Ray ID. */
    not?: LogsAuditListRequestRawCfRayIdNotList;
}
export type LogsAuditListRequestRawMethodNotList = Array<string>;
export interface LogsAuditListRequestRawMethod {
    /** Filters out audit logs by the HTTP method for the API call. */
    not?: LogsAuditListRequestRawMethodNotList;
}
export type LogsAuditListRequestRawStatusCodeNotList = Array<number>;
export interface LogsAuditListRequestRawStatusCode {
    /** Filters out audit logs by the response status code that was returned. */
    not?: LogsAuditListRequestRawStatusCodeNotList;
}
export type LogsAuditListRequestRawUriNotList = Array<string>;
export interface LogsAuditListRequestRawUri {
    /** Filters out audit logs by the request URI. */
    not?: LogsAuditListRequestRawUriNotList;
}
export type LogsAuditListRequestResourceIdNotList = Array<string>;
export interface LogsAuditListRequestResourceId {
    /** Filters out audit logs by the resource ID. */
    not?: LogsAuditListRequestResourceIdNotList;
}
export type LogsAuditListRequestResourceProductNotList = Array<string>;
export interface LogsAuditListRequestResourceProduct {
    /** Filters out audit logs by the Cloudflare product associated with the changed resource. */
    not?: LogsAuditListRequestResourceProductNotList;
}
export type LogsAuditListRequestResourceScopeNotItem = "organizations";
export type LogsAuditListRequestResourceScopeNotList = Array<LogsAuditListRequestResourceScopeNotItem | (string & {})>;
export interface LogsAuditListRequestResourceScope {
    /** Filters out audit logs by the resource scope, specifying whether the resource is associated with an organization. */
    not?: LogsAuditListRequestResourceScopeNotList;
}
export type LogsAuditListRequestResourceTypeNotList = Array<string>;
export interface LogsAuditListRequestResourceType {
    /** Filters out audit logs based on the unique type of resource changed by the action. */
    not?: LogsAuditListRequestResourceTypeNotList;
}
export interface ListLogAuditsRequest {
    /** The unique id that identifies the organization. */
    organizationId: string;
    /** Limits the returned results to logs older than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    before: string;
    /** Limits the returned results to logs newer than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    since: string;
    id?: LogsAuditListRequestId;
    actionResult?: LogsAuditListRequestActionResult;
    actionType?: LogsAuditListRequestActionType;
    actorContext?: LogsAuditListRequestActorContext;
    actorEmail?: LogsAuditListRequestActorEmail;
    actorId?: LogsAuditListRequestActorId;
    actorIpAddress?: LogsAuditListRequestActorIpAddress;
    actorTokenId?: LogsAuditListRequestActorTokenId;
    actorTokenName?: LogsAuditListRequestActorTokenName;
    actorType?: LogsAuditListRequestActorType;
    /** The cursor is an opaque token used to paginate through large sets of records. It indicates the position from which to continue when requesting the next set of records. A valid cursor value can be obtained from the cursor object in the result_info structure of a previous response. */
    cursor?: string;
    /** Sets sorting order. */
    direction?: LogsAuditListRequestDirection | (string & {});
    /** The number limits the objects to return. The cursor attribute may be used to iterate over the next batch of objects if there are more than the limit. */
    limit?: number;
    rawCfRayId?: LogsAuditListRequestRawCfRayId;
    rawMethod?: LogsAuditListRequestRawMethod;
    rawStatusCode?: LogsAuditListRequestRawStatusCode;
    rawUri?: LogsAuditListRequestRawUri;
    resourceId?: LogsAuditListRequestResourceId;
    resourceProduct?: LogsAuditListRequestResourceProduct;
    resourceScope?: LogsAuditListRequestResourceScope;
    resourceType?: LogsAuditListRequestResourceType;
}
export interface LogsAuditListResultItemAction {
    /** A short description of the action performed. */
    description?: string | null;
    /** The result of the action, indicating success or failure. */
    result?: string | null;
    /** A timestamp indicating when the action was logged. */
    time?: string | null;
    /** A short string that describes the action that was performed. */
    type?: string | null;
}
export type LogsAuditListResultItemActorContext = "api" | "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export type LogsAuditListResultItemActorType = "cloudflare_admin" | "system" | "user";
export interface LogsAuditListResultItemActor {
    /** The ID of the actor who performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null;
    /** The context in which the action was initiated. */
    context?: LogsAuditListResultItemActorContext | null;
    /** The email of the actor who performed the action. */
    email?: string | null;
    /** The IP address of the request that performed the action. */
    ipAddress?: string | null;
    /** The API token ID when the actor context is an api_token or oauth. */
    tokenId?: string | null;
    /** The API token name when the actor context is an api_token or oauth. */
    tokenName?: string | null;
    /** The type of actor. */
    type?: LogsAuditListResultItemActorType | null;
}
export interface LogsAuditListResultItemOrganization {
    /** A unique identifier for the organization. */
    id?: string | null;
}
export interface LogsAuditListResultItemRaw {
    /** The Cloudflare Ray ID for the request. */
    cfRayId?: string | null;
    /** The HTTP method of the request. */
    method?: string | null;
    /** The HTTP response status code returned by the API. */
    statusCode?: number | null;
    /** The URI of the request. */
    uri?: string | null;
    /** The client's user agent string sent with the request. */
    userAgent?: string | null;
}
export interface LogsAuditListResultItemResource {
    /** The unique identifier for the affected resource. */
    id?: string | null;
    /** The Cloudflare product associated with the resource. */
    product?: string | null;
    request?: unknown | null;
    response?: unknown | null;
    /** The scope of the resource. */
    scope?: unknown | null;
    /** The type of the resource. */
    type?: string | null;
}
export interface LogsAuditListResultItem {
    /** A unique identifier for the audit log entry. */
    id?: string | null;
    /** Provides information about the action performed. */
    action?: LogsAuditListResultItemAction | null;
    /** Provides details about the actor who performed the action. */
    actor?: LogsAuditListResultItemActor | null;
    /** Contains organization related information. */
    organization?: LogsAuditListResultItemOrganization | null;
    /** Provides raw information about the request and response. */
    raw?: LogsAuditListResultItemRaw | null;
    /** Provides details about the affected resource. */
    resource?: LogsAuditListResultItemResource | null;
}
export type LogsAuditListResultList = Array<LogsAuditListResultItem>;
export interface ListLogAuditsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogsAuditListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ListMembersRequestStatus = "active" | "pending" | "rejected" | "canceled";
export type ListMembersRequestStatusList = Array<ListMembersRequestStatus | (string & {})>;
export interface ListMembersRequestUser {
    /** Filter the list of memberships for a specific email that ends with a substring. */
    email?: string;
}
export interface ListMembersRequest {
    organizationId: string;
    /** The amount of items to return. Defaults to 10. */
    pageSize?: number;
    /** An opaque token returned from the last list response that when provided will retrieve the next page. */
    pageToken?: string;
    /** Filter the list of memberships by membership status. */
    status?: ListMembersRequestStatusList;
    user?: ListMembersRequestUser;
}
export type ListMembersResultItemMetaMap = {
    [key: string]: unknown | undefined;
};
export type ListMembersResultItemStatus = "active" | "pending" | "rejected" | "canceled";
export type ListMembersResultItemUser = CreateMemberResponseUser;
export interface ListMembersResultItem {
    /** Organization Member ID */
    id: string;
    createTime: string;
    meta: ListMembersResultItemMetaMap;
    status: ListMembersResultItemStatus;
    updateTime: string;
    user: CreateMemberResponseUser;
}
export type ListMembersResultList = Array<ListMembersResultItem>;
export type ListMembersResponse = ListMembersResultList;
export type ListRequestIdList = Array<string>;
export interface ListRequestContaining {
    /** Filter the list of organizations to the ones that contain this particular account. */
    account?: string;
    /** Filter the list of organizations to the ones that contain this particular organization. */
    organization?: string;
    /** Filter the list of organizations to the ones that contain this particular user. */
    user?: string;
}
export interface ListRequestName {
    /** (case-insensitive) Filter the list of organizations to where the name contains a particular string. */
    contains?: string;
    /** (case-insensitive) Filter the list of organizations to where the name ends with a particular string. */
    endsWith?: string;
    /** (case-insensitive) Filter the list of organizations to where the name starts with a particular string. */
    startsWith?: string;
}
export interface ListRequestParent {
    /** Filter the list of organizations to the ones that are a sub-organization of the specified organization. */
    id?: string;
}
export interface ListOrganizationsRequest {
    /** Only return organizations with the specified IDs (ex. id=foo&id=bar). Send multiple elements by repeating the query value. */
    id?: ListRequestIdList;
    containing?: ListRequestContaining;
    name?: ListRequestName;
    /** The amount of items to return. Defaults to 10. */
    pageSize?: number;
    /** An opaque token returned from the last list response that when provided will retrieve the next page. */
    pageToken?: string;
    parent?: ListRequestParent;
}
export type ListResultItemMetaHierarchyTagsList = Array<string>;
export type ListResultItemMetaTenantFlags = CreateResponseMetaTenantFlags;
export interface ListResultItemMeta {
    /** Ordered chain of organization tags from the root organization down to (and including) this organization itself. Root organizations return a single-element array containing their own tag; sub-organizations return `[rootTag, ...intermediateTags, parentTag, selfTag]`. Useful for constructing authorization scopes that need to cover every ancestor in the hierarchy. */
    hierarchyTags?: ListResultItemMetaHierarchyTagsList | null;
    managedBy?: string | null;
    /** Enable features for Organizations. */
    tenantFlags?: CreateResponseMetaTenantFlags | null;
}
export type ListResultItemParent = CreateResponseParent;
export type ListResultItemProfile = CreateRequestProfile;
export interface ListResultItem {
    id: string;
    createTime: string;
    meta: ListResultItemMeta;
    name: string;
    parent?: CreateResponseParent | null;
    profile?: CreateRequestProfile | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListOrganizationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type LogsAuditHistoryRequestDirection = "desc" | "asc";
export interface LogsAuditHistoryRequest {
    /** The unique ID that identifies the organization. */
    organizationId: string;
    /** The ID of the audit log to fetch resource history for. */
    id: string;
    /** RFC3339 timestamp of the source audit log entry's action time. Used to narrow the source-entry lookup window. Provide the `action.time` value from the audit log identified by `id`. */
    actionTime: string;
    /** Limits the returned results to logs older than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    before: string;
    /** Limits the returned results to logs newer than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    since: string;
    /** The cursor is an opaque token used to paginate through large sets of records. It indicates the position from which to continue when requesting the next set of records. A valid cursor value can be obtained from the cursor object in the result_info structure of a previous response. */
    cursor?: string;
    /** Sets sorting order. */
    direction?: LogsAuditHistoryRequestDirection | (string & {});
    /** The number limits the objects to return. The cursor attribute may be used to iterate over the next batch of objects if there are more than the limit. */
    limit?: number;
}
export type LogsAuditHistoryResultItemAction = LogsAuditListResultItemAction;
export type LogsAuditHistoryResultItemActorContext = "api" | "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export type LogsAuditHistoryResultItemActorType = "cloudflare_admin" | "system" | "user";
export interface LogsAuditHistoryResultItemActor {
    /** The ID of the actor who performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null;
    /** The context in which the action was initiated. */
    context?: LogsAuditHistoryResultItemActorContext | null;
    /** The email of the actor who performed the action. */
    email?: string | null;
    /** The IP address of the request that performed the action. */
    ipAddress?: string | null;
    /** The API token ID when the actor context is an api_token or oauth. */
    tokenId?: string | null;
    /** The API token name when the actor context is an api_token or oauth. */
    tokenName?: string | null;
    /** The type of actor. */
    type?: LogsAuditHistoryResultItemActorType | null;
}
export type LogsAuditHistoryResultItemOrganization = LogsAuditListResultItemOrganization;
export type LogsAuditHistoryResultItemRaw = LogsAuditListResultItemRaw;
export type LogsAuditHistoryResultItemResource = LogsAuditListResultItemResource;
export interface LogsAuditHistoryResultItem {
    /** A unique identifier for the audit log entry. */
    id?: string | null;
    /** Provides information about the action performed. */
    action?: LogsAuditListResultItemAction | null;
    /** Provides details about the actor who performed the action. */
    actor?: LogsAuditHistoryResultItemActor | null;
    /** Contains organization related information. */
    organization?: LogsAuditListResultItemOrganization | null;
    /** Provides raw information about the request and response. */
    raw?: LogsAuditListResultItemRaw | null;
    /** Provides details about the affected resource. */
    resource?: LogsAuditListResultItemResource | null;
}
export type LogsAuditHistoryResultList = Array<LogsAuditHistoryResultItem>;
export type LogsAuditHistoryResponse = LogsAuditHistoryResultList;
export interface PutOrganizationProfileRequest {
    organizationId: string;
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export interface PutOrganizationProfileResponse {
}
export type UpdateRequestParent = CreateRequestParent;
export type UpdateRequestProfile = CreateRequestProfile;
export interface UpdateOrganizationRequest {
    organizationId: string;
    name: string;
    parent?: CreateRequestParent;
    profile?: CreateRequestProfile;
}
export type UpdateResponseMetaHierarchyTagsList = Array<string>;
export type UpdateResponseMetaTenantFlags = CreateResponseMetaTenantFlags;
export interface UpdateResponseMeta {
    /** Ordered chain of organization tags from the root organization down to (and including) this organization itself. Root organizations return a single-element array containing their own tag; sub-organizations return `[rootTag, ...intermediateTags, parentTag, selfTag]`. Useful for constructing authorization scopes that need to cover every ancestor in the hierarchy. */
    hierarchyTags?: UpdateResponseMetaHierarchyTagsList | null;
    managedBy?: string | null;
    /** Enable features for Organizations. */
    tenantFlags?: CreateResponseMetaTenantFlags | null;
}
export type UpdateResponseParent = CreateResponseParent;
export type UpdateResponseProfile = CreateRequestProfile;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateOrganizationResponse {
    id: string;
    createTime: string;
    meta: UpdateResponseMeta;
    name: string;
    parent?: CreateResponseParent | null;
    profile?: CreateRequestProfile | null;
}
export type CreateMemberError = CloudflareOpError;
/** Create a membership that grants access to a specific Organization. */
export declare const createMember: API.OperationMethod<CreateMemberRequest, CreateMemberResponse, CreateMemberError, CloudflareOpContext>;
export type CreateOrganizationError = Forbidden | CloudflareOpError;
/** Create a new organization for a user. Sub-organization creation availability depends on the organization's capabilities. */
export declare const createOrganization: API.OperationMethod<CreateOrganizationRequest, CreateOrganizationResponse, CreateOrganizationError, CloudflareOpContext>;
export type DeleteMemberError = CloudflareOpError;
/** Delete a membership to a particular Organization. */
export declare const deleteMember: API.OperationMethod<DeleteMemberRequest, DeleteMemberResponse, DeleteMemberError, CloudflareOpContext>;
export type DeleteOrganizationError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Delete an organization. The organization MUST be empty before deleting. It must not contain any sub-organizations, accounts, members or users. Sub-organization deletion availability depends on the organization's capabilities. **Access Control:** Restricted to enterprise organizations. */
export declare const deleteOrganization: API.OperationMethod<DeleteOrganizationRequest, DeleteOrganizationResponse, DeleteOrganizationError, CloudflareOpContext>;
export type GetBillingUsageError = CloudflareOpError;
/** Returns cost and usage data for all accounts within an organization, aligned with the [FinOps FOCUS v1.3](https://focus.finops.org/focus-specification/v1-3/) Cost and Usage dataset specification. Each record represents one billable metric for one account on one day. This includes all metered usage, including usage that falls within free-tier allowances and may result in zero cost. The response includes usage for every account belonging to the specified organization. **Note:** This endpoint serves `usage` records only; cost and pricing fields are absent from responses. Rated costs are available per account via `POST /accounts/{account_id}/billable/usage` with `Metric: cost`. When `from` and `to` are omitted, defaults to the start of the current month through today. The maximum date range is 31 days. An organization with no accounts, or an organization ID that does not exist, returns a successful response with an empty result set rather than an error. */
export declare const getBillingUsage: API.OperationMethod<GetBillingUsageRequest, GetBillingUsageResponse, GetBillingUsageError, CloudflareOpContext>;
export type GetMemberError = CloudflareOpError;
/** Retrieve a single membership from an Organization. */
export declare const getMember: API.OperationMethod<GetMemberRequest, GetMemberResponse, GetMemberError, CloudflareOpContext>;
export type GetOrganizationError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Retrieve the details of a certain organization. */
export declare const getOrganization: API.OperationMethod<GetOrganizationRequest, GetOrganizationResponse, GetOrganizationError, CloudflareOpContext>;
export type GetOrganizationAccountError = CloudflareOpError;
/** Retrieve the accounts immediately attached to a specific organization. Accounts attached to sub-organizations are not included. */
export declare const getOrganizationAccount: API.OperationMethod<GetOrganizationAccountRequest, GetOrganizationAccountResponse, GetOrganizationAccountError, CloudflareOpContext>;
export type GetOrganizationProfileError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Get an organizations profile if it exists. */
export declare const getOrganizationProfile: API.OperationMethod<GetOrganizationProfileRequest, GetOrganizationProfileResponse, GetOrganizationProfileError, CloudflareOpContext>;
export type ListLogAuditsError = CloudflareOpError;
/** Gets a list of audit logs for an organization. */
export declare const listLogAudits: API.PaginatedOperationMethod<ListLogAuditsRequest, ListLogAuditsResponse, ListLogAuditsError, CloudflareOpContext, LogsAuditListResultItem>;
export type ListMembersError = CloudflareOpError;
/** List memberships for an Organization. */
export declare const listMembers: API.OperationMethod<ListMembersRequest, ListMembersResponse, ListMembersError, CloudflareOpContext>;
export type ListOrganizationsError = Forbidden | CloudflareOpError;
/** Retrieve a list of organizations a particular user has access to. */
export declare const listOrganizations: API.PaginatedOperationMethod<ListOrganizationsRequest, ListOrganizationsResponse, ListOrganizationsError, CloudflareOpContext, ListResultItem>;
export type LogsAuditHistoryError = CloudflareOpError;
/** Returns the chronological change history for the resource identified by the given organization-scoped audit log entry. The endpoint first locates the source audit log entry by `id` (using `action_time` to narrow the lookup window), derives identifying filters from that entry, and then returns matching audit logs within the `since`/`before` window. The `result_info.history_status` field indicates the quality of the resource identification used: - `exact`: Resource was identified by the resource URI. - `approximate`: Resource was identified without the resource URI. - `unavailable`: The source audit log entry did not contain enough information to identify the resource; an empty result is returned. */
export declare const logsAuditHistory: API.OperationMethod<LogsAuditHistoryRequest, LogsAuditHistoryResponse, LogsAuditHistoryError, CloudflareOpContext>;
export type PutOrganizationProfileError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Modify organization profile. */
export declare const putOrganizationProfile: API.OperationMethod<PutOrganizationProfileRequest, PutOrganizationProfileResponse, PutOrganizationProfileError, CloudflareOpContext>;
export type UpdateOrganizationError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Update an organization's name. */
export declare const updateOrganization: API.OperationMethod<UpdateOrganizationRequest, UpdateOrganizationResponse, UpdateOrganizationError, CloudflareOpContext>;
//# sourceMappingURL=organizations.d.ts.map