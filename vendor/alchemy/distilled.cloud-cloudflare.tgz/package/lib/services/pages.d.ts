import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ActiveProductionDeployment_base: S.TaggedErrorClass<"ActiveProductionDeployment", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ActiveProductionDeployment extends /*@__PURE__*/ ActiveProductionDeployment_base {
}
declare const DeploymentNotFound_base: S.TaggedErrorClass<"DeploymentNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DeploymentNotFound extends /*@__PURE__*/ DeploymentNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const PagesDomainAlreadyExists_base: S.TaggedErrorClass<"PagesDomainAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PagesDomainAlreadyExists extends /*@__PURE__*/ PagesDomainAlreadyExists_base {
}
declare const PagesDomainNotFound_base: S.TaggedErrorClass<"PagesDomainNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PagesDomainNotFound extends /*@__PURE__*/ PagesDomainNotFound_base {
}
declare const ProjectAlreadyExists_base: S.TaggedErrorClass<"ProjectAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ProjectAlreadyExists extends /*@__PURE__*/ ProjectAlreadyExists_base {
}
declare const ProjectNotFound_base: S.TaggedErrorClass<"ProjectNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ProjectNotFound extends /*@__PURE__*/ ProjectNotFound_base {
}
export type AssetsCheckMissingRequestHashesList = Array<string>;
export interface AssetsCheckMissingRequest {
    /** List of file content hashes to check for existence in the asset store. */
    hashes: AssetsCheckMissingRequestHashesList;
}
export type AssetsCheckMissingResultList = Array<string>;
export type AssetsCheckMissingResponse = AssetsCheckMissingResultList;
export type AssetsUpsertHashesRequestHashesList = Array<string>;
export interface AssetsUpsertHashesRequest {
    /** List of file content hashes to register in the asset store. */
    hashes: AssetsUpsertHashesRequestHashesList;
}
export interface AssetsUpsertHashesResponse {
}
export interface ProjectsCreateRequestBuildConfig {
    /** Enable build caching for the project. */
    buildCaching?: boolean;
    /** Command used to build project. */
    buildCommand?: string;
    /** Output directory of the build. */
    destinationDir?: string;
    /** Directory to run the command. */
    rootDir?: string;
    /** The classifying tag for analytics. */
    webAnalyticsTag?: string;
    /** The auth token for analytics. */
    webAnalyticsToken?: string;
}
export interface ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue {
    projectId: string;
}
export type ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export interface ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue {
    /** Name of the dataset. */
    dataset: string;
}
export type ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsPreviewBrowsersMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsPreviewCompatibilityFlagsList = Array<string>;
export type ProjectsCreateRequestDeploymentConfigsPreviewD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export interface ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue {
    /** ID of the Durable Object namespace. */
    namespaceId: string;
}
export type ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export type UntypedBindingMap = {
    [key: string]: unknown | undefined;
};
export interface ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue {
    id: string;
}
export type ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsPreviewKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export interface ProjectsCreateRequestDeploymentConfigsPreviewLimits {
    /** CPU time limit in milliseconds. */
    cpuMs: number;
}
export interface ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue {
    certificateId: string;
}
export type ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export interface ProjectsCreateRequestDeploymentConfigsPreviewPlacement {
    /** Placement mode. */
    mode: string;
}
export interface ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue {
    /** Name of the Queue. */
    name: string;
}
export type ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsPreviewR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export interface ProjectsCreateRequestDeploymentConfigsPreviewServicesValue {
    /** The Service name. */
    service: string;
    /** The entrypoint to bind to. */
    entrypoint?: string;
    /** The Service environment. */
    environment?: string;
}
export type ProjectsCreateRequestDeploymentConfigsPreviewServicesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewServicesValue | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsPreviewUsageModel = "standard" | "bundled" | "unbound";
export interface ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue {
    indexName: string;
}
export type ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export interface ProjectsCreateRequestDeploymentConfigsPreview {
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsMap;
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate?: boolean;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsMap;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsCreateRequestDeploymentConfigsPreviewBrowsersMap;
    /** The major version of the build image to use for Pages Functions. Version 1 is retired and its projects are moved to version 3. Once a project's builds have been moved, a request that sets version 1 is rejected. */
    buildImageMajorVersion?: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate?: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags?: ProjectsCreateRequestDeploymentConfigsPreviewCompatibilityFlagsList;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsCreateRequestDeploymentConfigsPreviewD1DatabasesMap;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesMap;
    /** Environment variables used for builds and Pages Functions. */
    envVars?: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen?: boolean;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsMap;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsCreateRequestDeploymentConfigsPreviewKvNamespacesMap;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesMap;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersMap;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsCreateRequestDeploymentConfigsPreviewR2BucketsMap;
    /** Services used for Pages Functions. */
    services?: ProjectsCreateRequestDeploymentConfigsPreviewServicesMap;
    /** All new projects now use the Standard usage model. */
    usageModel?: ProjectsCreateRequestDeploymentConfigsPreviewUsageModel | (string & {});
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsMap;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string;
}
export type ProjectsCreateRequestDeploymentConfigsProductionAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export type ProjectsCreateRequestDeploymentConfigsProductionAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsProductionAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export type ProjectsCreateRequestDeploymentConfigsProductionAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsProductionBrowsersMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsProductionCompatibilityFlagsList = Array<string>;
export type ProjectsCreateRequestDeploymentConfigsProductionD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsProductionDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export type ProjectsCreateRequestDeploymentConfigsProductionDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsProductionHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export type ProjectsCreateRequestDeploymentConfigsProductionHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsProductionKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsProductionLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export type ProjectsCreateRequestDeploymentConfigsProductionMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export type ProjectsCreateRequestDeploymentConfigsProductionMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsProductionPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export type ProjectsCreateRequestDeploymentConfigsProductionQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export type ProjectsCreateRequestDeploymentConfigsProductionQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsProductionR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsProductionServicesValue = ProjectsCreateRequestDeploymentConfigsPreviewServicesValue;
export type ProjectsCreateRequestDeploymentConfigsProductionServicesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewServicesValue | undefined;
};
export type ProjectsCreateRequestDeploymentConfigsProductionUsageModel = "standard" | "bundled" | "unbound";
export type ProjectsCreateRequestDeploymentConfigsProductionVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export type ProjectsCreateRequestDeploymentConfigsProductionVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export interface ProjectsCreateRequestDeploymentConfigsProduction {
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsCreateRequestDeploymentConfigsProductionAiBindingsMap;
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate?: boolean;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsCreateRequestDeploymentConfigsProductionAnalyticsEngineDatasetsMap;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsCreateRequestDeploymentConfigsProductionBrowsersMap;
    /** The major version of the build image to use for Pages Functions. Version 1 is retired and its projects are moved to version 3. Once a project's builds have been moved, a request that sets version 1 is rejected. */
    buildImageMajorVersion?: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate?: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags?: ProjectsCreateRequestDeploymentConfigsProductionCompatibilityFlagsList;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsCreateRequestDeploymentConfigsProductionD1DatabasesMap;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsCreateRequestDeploymentConfigsProductionDurableObjectNamespacesMap;
    /** Environment variables used for builds and Pages Functions. */
    envVars?: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen?: boolean;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsCreateRequestDeploymentConfigsProductionHyperdriveBindingsMap;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsCreateRequestDeploymentConfigsProductionKvNamespacesMap;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsCreateRequestDeploymentConfigsProductionMtlsCertificatesMap;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsCreateRequestDeploymentConfigsProductionQueueProducersMap;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsCreateRequestDeploymentConfigsProductionR2BucketsMap;
    /** Services used for Pages Functions. */
    services?: ProjectsCreateRequestDeploymentConfigsProductionServicesMap;
    /** All new projects now use the Standard usage model. */
    usageModel?: ProjectsCreateRequestDeploymentConfigsProductionUsageModel | (string & {});
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsCreateRequestDeploymentConfigsProductionVectorizeBindingsMap;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string;
}
export interface ProjectsCreateRequestDeploymentConfigs {
    /** Configs for preview deploys. */
    preview?: ProjectsCreateRequestDeploymentConfigsPreview;
    /** Configs for production deploys. */
    production?: ProjectsCreateRequestDeploymentConfigsProduction;
}
export type ProjectsCreateRequestSourceConfigPathExcludesList = Array<string>;
export type ProjectsCreateRequestSourceConfigPathIncludesList = Array<string>;
export type ProjectsCreateRequestSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsCreateRequestSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsCreateRequestSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsCreateRequestSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled?: boolean;
    /** The owner of the repository. */
    owner?: string;
    /** The owner ID of the repository. */
    ownerId?: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes?: ProjectsCreateRequestSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes?: ProjectsCreateRequestSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled?: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes?: ProjectsCreateRequestSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes?: ProjectsCreateRequestSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting?: ProjectsCreateRequestSourceConfigPreviewDeploymentSetting | (string & {});
    /** The production branch of the repository. */
    productionBranch?: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled?: boolean;
    /** The ID of the repository. */
    repoId?: string;
    /** The name of the repository. */
    repoName?: string;
}
export type ProjectsCreateRequestSourceType = "github" | "gitlab";
export interface ProjectsCreateRequestSource {
    config: ProjectsCreateRequestSourceConfig;
    /** The source control management provider. */
    type: ProjectsCreateRequestSourceType | (string & {});
}
export interface CreateProjectRequest {
    /** Identifier. */
    accountId: string;
    /** Name for the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    name: string;
    /** Production branch of the project. Used to identify production deployments. */
    productionBranch: string;
    /** Configs for the project build process. */
    buildConfig?: ProjectsCreateRequestBuildConfig;
    /** Configs for deployments in a project. */
    deploymentConfigs?: ProjectsCreateRequestDeploymentConfigs;
    /** Configs for the project source control. */
    source?: ProjectsCreateRequestSource;
}
export type ProjectsCreateResponseCanonicalDeploymentAliasesList = Array<string>;
export interface ProjectsCreateResponseCanonicalDeploymentBuildConfig {
    /** The classifying tag for analytics. */
    webAnalyticsTag: string;
    /** The auth token for analytics. */
    webAnalyticsToken: string;
    /** Enable build caching for the project. */
    buildCaching?: boolean | null;
    /** Command used to build project. */
    buildCommand?: string | null;
    /** Assets output directory of the build. */
    destinationDir?: string | null;
    /** Directory to run the command. */
    rootDir?: string | null;
}
export interface ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata {
    /** Where the trigger happened. */
    branch: string;
    /** Whether the deployment trigger commit was dirty. */
    commitDirty: boolean;
    /** Hash of the deployment trigger commit. */
    commitHash: string;
    /** Message of the deployment trigger commit. */
    commitMessage: string;
}
export type ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsCreateResponseCanonicalDeploymentDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerType;
}
export type ProjectsCreateResponseCanonicalDeploymentEnvironment = "preview" | "production";
export type ProjectsCreateResponseCanonicalDeploymentLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsCreateResponseCanonicalDeploymentLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsCreateResponseCanonicalDeploymentLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsCreateResponseCanonicalDeploymentLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsCreateResponseCanonicalDeploymentLatestStageStatus;
}
export type ProjectsCreateResponseCanonicalDeploymentSourceConfigPathExcludesList = Array<string>;
export type ProjectsCreateResponseCanonicalDeploymentSourceConfigPathIncludesList = Array<string>;
export type ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsCreateResponseCanonicalDeploymentSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsCreateResponseCanonicalDeploymentSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsCreateResponseCanonicalDeploymentSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsCreateResponseCanonicalDeploymentSourceType = "github" | "gitlab";
export interface ProjectsCreateResponseCanonicalDeploymentSource {
    config: ProjectsCreateResponseCanonicalDeploymentSourceConfig;
    /** The source control management provider. */
    type: ProjectsCreateResponseCanonicalDeploymentSourceType;
}
export type ProjectsCreateResponseCanonicalDeploymentStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsCreateResponseCanonicalDeploymentStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsCreateResponseCanonicalDeploymentStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsCreateResponseCanonicalDeploymentStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsCreateResponseCanonicalDeploymentStagesItemStatus;
}
export type ProjectsCreateResponseCanonicalDeploymentStagesList = Array<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export type ProjectsCreateResponseCanonicalDeploymentSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
export interface ProjectsCreateResponseCanonicalDeployment {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsCreateResponseCanonicalDeploymentAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsCreateResponseCanonicalDeploymentDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsCreateResponseCanonicalDeploymentEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsCreateResponseCanonicalDeploymentLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsCreateResponseCanonicalDeploymentSource;
    /** List of past stages. */
    stages: ProjectsCreateResponseCanonicalDeploymentStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsCreateResponseCanonicalDeploymentSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export type ProjectsCreateResponseDeploymentConfigsPreviewCompatibilityFlagsList = Array<string>;
export type ProjectsCreateResponseDeploymentConfigsPreviewUsageModel = "standard" | "bundled" | "unbound";
export type ProjectsCreateResponseDeploymentConfigsPreviewAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export type ProjectsCreateResponseDeploymentConfigsPreviewAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export type ProjectsCreateResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsPreviewBrowsersMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsPreviewD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsPreviewDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export type ProjectsCreateResponseDeploymentConfigsPreviewDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsPreviewHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export type ProjectsCreateResponseDeploymentConfigsPreviewHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsPreviewKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsPreviewLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export type ProjectsCreateResponseDeploymentConfigsPreviewMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export type ProjectsCreateResponseDeploymentConfigsPreviewMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsPreviewPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export type ProjectsCreateResponseDeploymentConfigsPreviewQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export type ProjectsCreateResponseDeploymentConfigsPreviewQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsPreviewR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export interface ProjectsCreateResponseDeploymentConfigsPreviewServicesValue {
    /** The Service environment. */
    environment: string;
    /** The Service name. */
    service: string;
    /** The entrypoint to bind to. */
    entrypoint?: string | null;
}
export type ProjectsCreateResponseDeploymentConfigsPreviewServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsPreviewVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export type ProjectsCreateResponseDeploymentConfigsPreviewVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export interface ProjectsCreateResponseDeploymentConfigsPreview {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. Version 1 is retired and its projects are moved to version 3. Once a project's builds have been moved, this is the version the builds run on and `build_image_auto_upgrade` is set on the project. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsCreateResponseDeploymentConfigsPreviewCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** All new projects now use the Standard usage model. */
    usageModel: ProjectsCreateResponseDeploymentConfigsPreviewUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsCreateResponseDeploymentConfigsPreviewAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsCreateResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsCreateResponseDeploymentConfigsPreviewBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsCreateResponseDeploymentConfigsPreviewD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsCreateResponseDeploymentConfigsPreviewDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsCreateResponseDeploymentConfigsPreviewHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsCreateResponseDeploymentConfigsPreviewKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsCreateResponseDeploymentConfigsPreviewMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsCreateResponseDeploymentConfigsPreviewQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsCreateResponseDeploymentConfigsPreviewR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsCreateResponseDeploymentConfigsPreviewServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsCreateResponseDeploymentConfigsPreviewVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export type ProjectsCreateResponseDeploymentConfigsProductionCompatibilityFlagsList = Array<string>;
export type ProjectsCreateResponseDeploymentConfigsProductionUsageModel = "standard" | "bundled" | "unbound";
export type ProjectsCreateResponseDeploymentConfigsProductionAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export type ProjectsCreateResponseDeploymentConfigsProductionAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsProductionAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export type ProjectsCreateResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsProductionBrowsersMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsProductionD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsProductionDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export type ProjectsCreateResponseDeploymentConfigsProductionDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsProductionHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export type ProjectsCreateResponseDeploymentConfigsProductionHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsProductionKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsProductionLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export type ProjectsCreateResponseDeploymentConfigsProductionMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export type ProjectsCreateResponseDeploymentConfigsProductionMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsProductionPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export type ProjectsCreateResponseDeploymentConfigsProductionQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export type ProjectsCreateResponseDeploymentConfigsProductionQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsProductionR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsProductionServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export type ProjectsCreateResponseDeploymentConfigsProductionServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export type ProjectsCreateResponseDeploymentConfigsProductionVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export type ProjectsCreateResponseDeploymentConfigsProductionVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export interface ProjectsCreateResponseDeploymentConfigsProduction {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. Version 1 is retired and its projects are moved to version 3. Once a project's builds have been moved, this is the version the builds run on and `build_image_auto_upgrade` is set on the project. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsCreateResponseDeploymentConfigsProductionCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** All new projects now use the Standard usage model. */
    usageModel: ProjectsCreateResponseDeploymentConfigsProductionUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsCreateResponseDeploymentConfigsProductionAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsCreateResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsCreateResponseDeploymentConfigsProductionBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsCreateResponseDeploymentConfigsProductionD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsCreateResponseDeploymentConfigsProductionDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsCreateResponseDeploymentConfigsProductionHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsCreateResponseDeploymentConfigsProductionKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsCreateResponseDeploymentConfigsProductionMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsCreateResponseDeploymentConfigsProductionQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsCreateResponseDeploymentConfigsProductionR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsCreateResponseDeploymentConfigsProductionServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsCreateResponseDeploymentConfigsProductionVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export interface ProjectsCreateResponseDeploymentConfigs {
    /** Configs for preview deploys. */
    preview: ProjectsCreateResponseDeploymentConfigsPreview;
    /** Configs for production deploys. */
    production: ProjectsCreateResponseDeploymentConfigsProduction;
}
export type ProjectsCreateResponseLatestDeploymentAliasesList = Array<string>;
export type ProjectsCreateResponseLatestDeploymentBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsCreateResponseLatestDeploymentDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export type ProjectsCreateResponseLatestDeploymentDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsCreateResponseLatestDeploymentDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsCreateResponseLatestDeploymentDeploymentTriggerType;
}
export type ProjectsCreateResponseLatestDeploymentEnvVarsValuePlainTextType = "plain_text";
export interface ProjectsCreateResponseLatestDeploymentEnvVarsValuePlainText {
    type: ProjectsCreateResponseLatestDeploymentEnvVarsValuePlainTextType;
    /** Environment variable value. */
    value: string;
}
export type ProjectsCreateResponseLatestDeploymentEnvVarsValueSecretTextType = "secret_text";
export interface ProjectsCreateResponseLatestDeploymentEnvVarsValueSecretText {
    type: ProjectsCreateResponseLatestDeploymentEnvVarsValueSecretTextType;
    /** Secret value. */
    value: string;
}
export type ProjectsCreateResponseLatestDeploymentEnvVarsValue = ProjectsCreateResponseLatestDeploymentEnvVarsValuePlainText | ProjectsCreateResponseLatestDeploymentEnvVarsValueSecretText;
export type ProjectsCreateResponseLatestDeploymentEnvVarsMap = {
    [key: string]: ProjectsCreateResponseLatestDeploymentEnvVarsValue | undefined;
};
export type ProjectsCreateResponseLatestDeploymentEnvironment = "preview" | "production";
export type ProjectsCreateResponseLatestDeploymentLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsCreateResponseLatestDeploymentLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsCreateResponseLatestDeploymentLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsCreateResponseLatestDeploymentLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsCreateResponseLatestDeploymentLatestStageStatus;
}
export type ProjectsCreateResponseLatestDeploymentSourceConfigPathExcludesList = Array<string>;
export type ProjectsCreateResponseLatestDeploymentSourceConfigPathIncludesList = Array<string>;
export type ProjectsCreateResponseLatestDeploymentSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsCreateResponseLatestDeploymentSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsCreateResponseLatestDeploymentSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsCreateResponseLatestDeploymentSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsCreateResponseLatestDeploymentSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsCreateResponseLatestDeploymentSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsCreateResponseLatestDeploymentSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsCreateResponseLatestDeploymentSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsCreateResponseLatestDeploymentSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsCreateResponseLatestDeploymentSourceType = "github" | "gitlab";
export interface ProjectsCreateResponseLatestDeploymentSource {
    config: ProjectsCreateResponseLatestDeploymentSourceConfig;
    /** The source control management provider. */
    type: ProjectsCreateResponseLatestDeploymentSourceType;
}
export type ProjectsCreateResponseLatestDeploymentStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsCreateResponseLatestDeploymentStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsCreateResponseLatestDeploymentStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsCreateResponseLatestDeploymentStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsCreateResponseLatestDeploymentStagesItemStatus;
}
export type ProjectsCreateResponseLatestDeploymentStagesList = Array<ProjectsCreateResponseLatestDeploymentStagesItem>;
export type ProjectsCreateResponseLatestDeploymentSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
export interface ProjectsCreateResponseLatestDeployment {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsCreateResponseLatestDeploymentAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsCreateResponseLatestDeploymentDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: ProjectsCreateResponseLatestDeploymentEnvVarsMap;
    /** Type of deploy. */
    environment: ProjectsCreateResponseLatestDeploymentEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsCreateResponseLatestDeploymentLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsCreateResponseLatestDeploymentSource;
    /** List of past stages. */
    stages: ProjectsCreateResponseLatestDeploymentStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsCreateResponseLatestDeploymentSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export type ProjectsCreateResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export interface ProjectsCreateResponseBuildImageAutoUpgrade {
    /** The retired build image major version the project is set to. */
    fromVersion: number;
    /** The build image major version the project's builds run on. */
    toVersion: number;
}
export type ProjectsCreateResponseDomainsList = Array<string>;
export type ProjectsCreateResponseSourceConfigPathExcludesList = Array<string>;
export type ProjectsCreateResponseSourceConfigPathIncludesList = Array<string>;
export type ProjectsCreateResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsCreateResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsCreateResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsCreateResponseSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsCreateResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsCreateResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsCreateResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsCreateResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsCreateResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsCreateResponseSourceType = "github" | "gitlab";
export interface ProjectsCreateResponseSource {
    config: ProjectsCreateResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsCreateResponseSourceType;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProjectResponse {
    /** ID of the project. */
    id: string;
    /** Most recent production deployment of the project. */
    canonicalDeployment: ProjectsCreateResponseCanonicalDeployment;
    /** When the project was created. */
    createdOn: string;
    /** Configs for deployments in a project. */
    deploymentConfigs: ProjectsCreateResponseDeploymentConfigs;
    /** Framework the project is using. */
    framework: string;
    /** Version of the framework the project is using. */
    frameworkVersion: string;
    /** Most recent deployment of the project. */
    latestDeployment: ProjectsCreateResponseLatestDeployment;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    name: string;
    /** Name of the preview script. */
    previewScriptName: string;
    /** Production branch of the project. Used to identify production deployments. */
    productionBranch: string;
    /** Name of the production script. */
    productionScriptName: string;
    /** Whether the project uses functions. */
    usesFunctions: boolean;
    /** Configs for the project build process. */
    buildConfig?: ProjectsCreateResponseCanonicalDeploymentBuildConfig | null;
    /** Present when the project is set to a retired build image major version and its builds have been moved to a newer one. `build_image_major_version` in `deployment_configs` then reports the version the builds run on. */
    buildImageAutoUpgrade?: ProjectsCreateResponseBuildImageAutoUpgrade | null;
    /** A list of associated custom domains for the project. */
    domains?: ProjectsCreateResponseDomainsList | null;
    /** Configs for the project source control. */
    source?: ProjectsCreateResponseSource | null;
    /** The Cloudflare subdomain associated with the project. */
    subdomain?: string | null;
}
export interface CreateProjectDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Headers configuration file for the deployment. */
    headers?: unknown;
    /** Redirects configuration file for the deployment. */
    redirects?: unknown;
    /** Routes configuration file defining routing rules. */
    routesJson?: unknown;
    /** Worker bundle file in multipart/form-data format. Mutually exclusive with `_worker.js`. Cannot specify both `_worker.js` and `_worker.bundle` in the same request. Maximum size: 25 MiB. */
    workerBundle?: unknown;
    /** Worker JavaScript file. Mutually exclusive with `_worker.bundle`. Cannot specify both `_worker.js` and `_worker.bundle` in the same request. */
    workerJs?: unknown;
    /** Git branch to deploy. Uses the branch's `HEAD`; defaults to the project's production branch. */
    branch?: string;
    /** Whether the associated Git working tree has uncommitted changes. Provide `true` or `false`. */
    commitDirty?: boolean;
    /** Git commit SHA associated with the deployment. */
    commitHash?: string;
    /** Git commit message associated with the deployment. */
    commitMessage?: string;
    /** Functions routing configuration file. */
    functionsFilepathRoutingConfigJson?: unknown;
    /** JSON-encoded object mapping deployment file paths to their uploaded content hashes. Required for Direct Upload deployments. Maximum 20,000 entries. */
    manifest?: string;
    /** The build output directory path. */
    pagesBuildOutputDir?: string;
    /** Hash of the Wrangler configuration file used for this deployment. */
    wranglerConfigHash?: string;
}
export type ProjectsDeploymentsCreateResponseAliasesList = Array<string>;
export type ProjectsDeploymentsCreateResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsDeploymentsCreateResponseDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export type ProjectsDeploymentsCreateResponseDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsDeploymentsCreateResponseDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsDeploymentsCreateResponseDeploymentTriggerType;
}
export type ProjectsDeploymentsCreateResponseEnvironment = "preview" | "production";
export type ProjectsDeploymentsCreateResponseLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsDeploymentsCreateResponseLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsDeploymentsCreateResponseLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsCreateResponseLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsCreateResponseLatestStageStatus;
}
export type ProjectsDeploymentsCreateResponseSourceConfigPathExcludesList = Array<string>;
export type ProjectsDeploymentsCreateResponseSourceConfigPathIncludesList = Array<string>;
export type ProjectsDeploymentsCreateResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsDeploymentsCreateResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsDeploymentsCreateResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsDeploymentsCreateResponseSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsDeploymentsCreateResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsDeploymentsCreateResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsDeploymentsCreateResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsDeploymentsCreateResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsDeploymentsCreateResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsDeploymentsCreateResponseSourceType = "github" | "gitlab";
export interface ProjectsDeploymentsCreateResponseSource {
    config: ProjectsDeploymentsCreateResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsDeploymentsCreateResponseSourceType;
}
export type ProjectsDeploymentsCreateResponseStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsDeploymentsCreateResponseStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsDeploymentsCreateResponseStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsCreateResponseStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsCreateResponseStagesItemStatus;
}
export type ProjectsDeploymentsCreateResponseStagesList = Array<ProjectsDeploymentsCreateResponseStagesItem>;
export type ProjectsDeploymentsCreateResponseSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProjectDeploymentResponse {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsDeploymentsCreateResponseAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsDeploymentsCreateResponseDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsDeploymentsCreateResponseEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsDeploymentsCreateResponseLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsDeploymentsCreateResponseSource;
    /** List of past stages. */
    stages: ProjectsDeploymentsCreateResponseStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsDeploymentsCreateResponseSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export interface CreateProjectDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Fully qualified domain name for the Pages project, such as `example.com`. */
    name: string;
}
export type ProjectsDomainsCreateResponseCertificateAuthority = "google" | "lets_encrypt";
export type ProjectsDomainsCreateResponseStatus = "initializing" | "pending" | "active" | "deactivated" | "blocked" | "error";
export type ProjectsDomainsCreateResponseValidationDataMethod = "http" | "txt";
export type ProjectsDomainsCreateResponseValidationDataStatus = "initializing" | "pending" | "active" | "deactivated" | "error";
export interface ProjectsDomainsCreateResponseValidationData {
    method: ProjectsDomainsCreateResponseValidationDataMethod;
    status: ProjectsDomainsCreateResponseValidationDataStatus;
    errorMessage?: string | null;
    txtName?: string | null;
    txtValue?: string | null;
}
export type ProjectsDomainsCreateResponseVerificationDataStatus = "pending" | "active" | "deactivated" | "blocked" | "error";
export interface ProjectsDomainsCreateResponseVerificationData {
    status: ProjectsDomainsCreateResponseVerificationDataStatus;
    errorMessage?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProjectDomainResponse {
    id: string;
    certificateAuthority: ProjectsDomainsCreateResponseCertificateAuthority;
    createdOn: string;
    domainId: string;
    /** Fully qualified domain name for the Pages project, such as `example.com`. */
    name: string;
    status: ProjectsDomainsCreateResponseStatus;
    validationData: ProjectsDomainsCreateResponseValidationData;
    verificationData: ProjectsDomainsCreateResponseVerificationData;
    zoneTag: string;
}
export type CreateProjectsDeploymentsTailRequestFiltersItemMap = {
    [key: string]: unknown | undefined;
};
export type CreateProjectsDeploymentsTailRequestFiltersList = Array<CreateProjectsDeploymentsTailRequestFiltersItemMap>;
export interface CreateProjectsDeploymentsTailRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** UUID of the Pages deployment, as returned by deployment list or create operations. */
    deploymentId: string;
    /** Filters to apply to the tail session. */
    filters?: CreateProjectsDeploymentsTailRequestFiltersList;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProjectsDeploymentsTailResponse {
    /** Identifier of the tail session. */
    id: string;
    /** Optional WebSocket URL to connect to for receiving tail events, when returned by the tail service. */
    url?: string | null;
}
export interface DeleteProjectRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
}
export type DeleteProjectResponse = unknown;
export interface DeleteProjectDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** UUID of the Pages deployment, as returned by deployment list or create operations. */
    deploymentId: string;
    /** Allow deletion when a non-production deployment has an active alias. */
    force?: boolean;
}
export type DeleteProjectDeploymentResponse = unknown;
export interface DeleteProjectDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Fully qualified domain name for the Pages project, such as `example.com`. */
    domainName: string;
}
export type DeleteProjectDomainResponse = unknown;
export interface DeleteProjectsDeploymentsTailRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** UUID of the Pages deployment, as returned by deployment list or create operations. */
    deploymentId: string;
    /** Identifier. */
    tailId: string;
}
export type DeleteProjectsDeploymentsTailResponse = unknown;
export interface GetProjectRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
}
export type ProjectsGetResponseCanonicalDeploymentAliasesList = Array<string>;
export type ProjectsGetResponseCanonicalDeploymentBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsGetResponseCanonicalDeploymentDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export type ProjectsGetResponseCanonicalDeploymentDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsGetResponseCanonicalDeploymentDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsGetResponseCanonicalDeploymentDeploymentTriggerType;
}
export type ProjectsGetResponseCanonicalDeploymentEnvironment = "preview" | "production";
export type ProjectsGetResponseCanonicalDeploymentLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsGetResponseCanonicalDeploymentLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsGetResponseCanonicalDeploymentLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsGetResponseCanonicalDeploymentLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsGetResponseCanonicalDeploymentLatestStageStatus;
}
export type ProjectsGetResponseCanonicalDeploymentSourceConfigPathExcludesList = Array<string>;
export type ProjectsGetResponseCanonicalDeploymentSourceConfigPathIncludesList = Array<string>;
export type ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsGetResponseCanonicalDeploymentSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsGetResponseCanonicalDeploymentSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsGetResponseCanonicalDeploymentSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsGetResponseCanonicalDeploymentSourceType = "github" | "gitlab";
export interface ProjectsGetResponseCanonicalDeploymentSource {
    config: ProjectsGetResponseCanonicalDeploymentSourceConfig;
    /** The source control management provider. */
    type: ProjectsGetResponseCanonicalDeploymentSourceType;
}
export type ProjectsGetResponseCanonicalDeploymentStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsGetResponseCanonicalDeploymentStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsGetResponseCanonicalDeploymentStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsGetResponseCanonicalDeploymentStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsGetResponseCanonicalDeploymentStagesItemStatus;
}
export type ProjectsGetResponseCanonicalDeploymentStagesList = Array<ProjectsGetResponseCanonicalDeploymentStagesItem>;
export type ProjectsGetResponseCanonicalDeploymentSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
export interface ProjectsGetResponseCanonicalDeployment {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsGetResponseCanonicalDeploymentAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsGetResponseCanonicalDeploymentDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsGetResponseCanonicalDeploymentEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsGetResponseCanonicalDeploymentLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsGetResponseCanonicalDeploymentSource;
    /** List of past stages. */
    stages: ProjectsGetResponseCanonicalDeploymentStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsGetResponseCanonicalDeploymentSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export type ProjectsGetResponseDeploymentConfigsPreviewCompatibilityFlagsList = Array<string>;
export type ProjectsGetResponseDeploymentConfigsPreviewUsageModel = "standard" | "bundled" | "unbound";
export type ProjectsGetResponseDeploymentConfigsPreviewAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export type ProjectsGetResponseDeploymentConfigsPreviewAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export type ProjectsGetResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsPreviewBrowsersMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsGetResponseDeploymentConfigsPreviewD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsGetResponseDeploymentConfigsPreviewDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export type ProjectsGetResponseDeploymentConfigsPreviewDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsPreviewHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export type ProjectsGetResponseDeploymentConfigsPreviewHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsPreviewKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsGetResponseDeploymentConfigsPreviewLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export type ProjectsGetResponseDeploymentConfigsPreviewMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export type ProjectsGetResponseDeploymentConfigsPreviewMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsPreviewPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export type ProjectsGetResponseDeploymentConfigsPreviewQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export type ProjectsGetResponseDeploymentConfigsPreviewQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsPreviewR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsGetResponseDeploymentConfigsPreviewServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export type ProjectsGetResponseDeploymentConfigsPreviewServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsPreviewVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export type ProjectsGetResponseDeploymentConfigsPreviewVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export interface ProjectsGetResponseDeploymentConfigsPreview {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. Version 1 is retired and its projects are moved to version 3. Once a project's builds have been moved, this is the version the builds run on and `build_image_auto_upgrade` is set on the project. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsGetResponseDeploymentConfigsPreviewCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** All new projects now use the Standard usage model. */
    usageModel: ProjectsGetResponseDeploymentConfigsPreviewUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsGetResponseDeploymentConfigsPreviewAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsGetResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsGetResponseDeploymentConfigsPreviewBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsGetResponseDeploymentConfigsPreviewD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsGetResponseDeploymentConfigsPreviewDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsGetResponseDeploymentConfigsPreviewHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsGetResponseDeploymentConfigsPreviewKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsGetResponseDeploymentConfigsPreviewMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsGetResponseDeploymentConfigsPreviewQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsGetResponseDeploymentConfigsPreviewR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsGetResponseDeploymentConfigsPreviewServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsGetResponseDeploymentConfigsPreviewVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export type ProjectsGetResponseDeploymentConfigsProductionCompatibilityFlagsList = Array<string>;
export type ProjectsGetResponseDeploymentConfigsProductionUsageModel = "standard" | "bundled" | "unbound";
export type ProjectsGetResponseDeploymentConfigsProductionAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export type ProjectsGetResponseDeploymentConfigsProductionAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsProductionAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export type ProjectsGetResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsProductionBrowsersMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsGetResponseDeploymentConfigsProductionD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsGetResponseDeploymentConfigsProductionDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export type ProjectsGetResponseDeploymentConfigsProductionDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsProductionHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export type ProjectsGetResponseDeploymentConfigsProductionHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsProductionKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsGetResponseDeploymentConfigsProductionLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export type ProjectsGetResponseDeploymentConfigsProductionMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export type ProjectsGetResponseDeploymentConfigsProductionMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsProductionPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export type ProjectsGetResponseDeploymentConfigsProductionQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export type ProjectsGetResponseDeploymentConfigsProductionQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsProductionR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsGetResponseDeploymentConfigsProductionServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export type ProjectsGetResponseDeploymentConfigsProductionServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export type ProjectsGetResponseDeploymentConfigsProductionVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export type ProjectsGetResponseDeploymentConfigsProductionVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export interface ProjectsGetResponseDeploymentConfigsProduction {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. Version 1 is retired and its projects are moved to version 3. Once a project's builds have been moved, this is the version the builds run on and `build_image_auto_upgrade` is set on the project. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsGetResponseDeploymentConfigsProductionCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** All new projects now use the Standard usage model. */
    usageModel: ProjectsGetResponseDeploymentConfigsProductionUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsGetResponseDeploymentConfigsProductionAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsGetResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsGetResponseDeploymentConfigsProductionBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsGetResponseDeploymentConfigsProductionD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsGetResponseDeploymentConfigsProductionDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsGetResponseDeploymentConfigsProductionHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsGetResponseDeploymentConfigsProductionKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsGetResponseDeploymentConfigsProductionMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsGetResponseDeploymentConfigsProductionQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsGetResponseDeploymentConfigsProductionR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsGetResponseDeploymentConfigsProductionServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsGetResponseDeploymentConfigsProductionVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export interface ProjectsGetResponseDeploymentConfigs {
    /** Configs for preview deploys. */
    preview: ProjectsGetResponseDeploymentConfigsPreview;
    /** Configs for production deploys. */
    production: ProjectsGetResponseDeploymentConfigsProduction;
}
export type ProjectsGetResponseLatestDeploymentAliasesList = Array<string>;
export type ProjectsGetResponseLatestDeploymentBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsGetResponseLatestDeploymentDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export type ProjectsGetResponseLatestDeploymentDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsGetResponseLatestDeploymentDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsGetResponseLatestDeploymentDeploymentTriggerType;
}
export type ProjectsGetResponseLatestDeploymentEnvVarsValuePlainTextType = "plain_text";
export interface ProjectsGetResponseLatestDeploymentEnvVarsValuePlainText {
    type: ProjectsGetResponseLatestDeploymentEnvVarsValuePlainTextType;
    /** Environment variable value. */
    value: string;
}
export type ProjectsGetResponseLatestDeploymentEnvVarsValueSecretTextType = "secret_text";
export interface ProjectsGetResponseLatestDeploymentEnvVarsValueSecretText {
    type: ProjectsGetResponseLatestDeploymentEnvVarsValueSecretTextType;
    /** Secret value. */
    value: string;
}
export type ProjectsGetResponseLatestDeploymentEnvVarsValue = ProjectsGetResponseLatestDeploymentEnvVarsValuePlainText | ProjectsGetResponseLatestDeploymentEnvVarsValueSecretText;
export type ProjectsGetResponseLatestDeploymentEnvVarsMap = {
    [key: string]: ProjectsGetResponseLatestDeploymentEnvVarsValue | undefined;
};
export type ProjectsGetResponseLatestDeploymentEnvironment = "preview" | "production";
export type ProjectsGetResponseLatestDeploymentLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsGetResponseLatestDeploymentLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsGetResponseLatestDeploymentLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsGetResponseLatestDeploymentLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsGetResponseLatestDeploymentLatestStageStatus;
}
export type ProjectsGetResponseLatestDeploymentSourceConfigPathExcludesList = Array<string>;
export type ProjectsGetResponseLatestDeploymentSourceConfigPathIncludesList = Array<string>;
export type ProjectsGetResponseLatestDeploymentSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsGetResponseLatestDeploymentSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsGetResponseLatestDeploymentSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsGetResponseLatestDeploymentSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsGetResponseLatestDeploymentSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsGetResponseLatestDeploymentSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsGetResponseLatestDeploymentSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsGetResponseLatestDeploymentSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsGetResponseLatestDeploymentSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsGetResponseLatestDeploymentSourceType = "github" | "gitlab";
export interface ProjectsGetResponseLatestDeploymentSource {
    config: ProjectsGetResponseLatestDeploymentSourceConfig;
    /** The source control management provider. */
    type: ProjectsGetResponseLatestDeploymentSourceType;
}
export type ProjectsGetResponseLatestDeploymentStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsGetResponseLatestDeploymentStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsGetResponseLatestDeploymentStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsGetResponseLatestDeploymentStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsGetResponseLatestDeploymentStagesItemStatus;
}
export type ProjectsGetResponseLatestDeploymentStagesList = Array<ProjectsGetResponseLatestDeploymentStagesItem>;
export type ProjectsGetResponseLatestDeploymentSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
export interface ProjectsGetResponseLatestDeployment {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsGetResponseLatestDeploymentAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsGetResponseLatestDeploymentDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: ProjectsGetResponseLatestDeploymentEnvVarsMap;
    /** Type of deploy. */
    environment: ProjectsGetResponseLatestDeploymentEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsGetResponseLatestDeploymentLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsGetResponseLatestDeploymentSource;
    /** List of past stages. */
    stages: ProjectsGetResponseLatestDeploymentStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsGetResponseLatestDeploymentSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export type ProjectsGetResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsGetResponseBuildImageAutoUpgrade = ProjectsCreateResponseBuildImageAutoUpgrade;
export type ProjectsGetResponseDomainsList = Array<string>;
export type ProjectsGetResponseSourceConfigPathExcludesList = Array<string>;
export type ProjectsGetResponseSourceConfigPathIncludesList = Array<string>;
export type ProjectsGetResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsGetResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsGetResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsGetResponseSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsGetResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsGetResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsGetResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsGetResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsGetResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsGetResponseSourceType = "github" | "gitlab";
export interface ProjectsGetResponseSource {
    config: ProjectsGetResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsGetResponseSourceType;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetProjectResponse {
    /** ID of the project. */
    id: string;
    /** Most recent production deployment of the project. */
    canonicalDeployment: ProjectsGetResponseCanonicalDeployment;
    /** When the project was created. */
    createdOn: string;
    /** Configs for deployments in a project. */
    deploymentConfigs: ProjectsGetResponseDeploymentConfigs;
    /** Framework the project is using. */
    framework: string;
    /** Version of the framework the project is using. */
    frameworkVersion: string;
    /** Most recent deployment of the project. */
    latestDeployment: ProjectsGetResponseLatestDeployment;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    name: string;
    /** Name of the preview script. */
    previewScriptName: string;
    /** Production branch of the project. Used to identify production deployments. */
    productionBranch: string;
    /** Name of the production script. */
    productionScriptName: string;
    /** Whether the project uses functions. */
    usesFunctions: boolean;
    /** Configs for the project build process. */
    buildConfig?: ProjectsCreateResponseCanonicalDeploymentBuildConfig | null;
    /** Present when the project is set to a retired build image major version and its builds have been moved to a newer one. `build_image_major_version` in `deployment_configs` then reports the version the builds run on. */
    buildImageAutoUpgrade?: ProjectsCreateResponseBuildImageAutoUpgrade | null;
    /** A list of associated custom domains for the project. */
    domains?: ProjectsGetResponseDomainsList | null;
    /** Configs for the project source control. */
    source?: ProjectsGetResponseSource | null;
    /** The Cloudflare subdomain associated with the project. */
    subdomain?: string | null;
}
export interface GetProjectDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** UUID of the Pages deployment, as returned by deployment list or create operations. */
    deploymentId: string;
}
export type ProjectsDeploymentsGetResponseAliasesList = Array<string>;
export type ProjectsDeploymentsGetResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsDeploymentsGetResponseDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export type ProjectsDeploymentsGetResponseDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsDeploymentsGetResponseDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsDeploymentsGetResponseDeploymentTriggerType;
}
export type ProjectsDeploymentsGetResponseEnvironment = "preview" | "production";
export type ProjectsDeploymentsGetResponseLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsDeploymentsGetResponseLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsDeploymentsGetResponseLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsGetResponseLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsGetResponseLatestStageStatus;
}
export type ProjectsDeploymentsGetResponseSourceConfigPathExcludesList = Array<string>;
export type ProjectsDeploymentsGetResponseSourceConfigPathIncludesList = Array<string>;
export type ProjectsDeploymentsGetResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsDeploymentsGetResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsDeploymentsGetResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsDeploymentsGetResponseSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsDeploymentsGetResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsDeploymentsGetResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsDeploymentsGetResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsDeploymentsGetResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsDeploymentsGetResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsDeploymentsGetResponseSourceType = "github" | "gitlab";
export interface ProjectsDeploymentsGetResponseSource {
    config: ProjectsDeploymentsGetResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsDeploymentsGetResponseSourceType;
}
export type ProjectsDeploymentsGetResponseStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsDeploymentsGetResponseStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsDeploymentsGetResponseStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsGetResponseStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsGetResponseStagesItemStatus;
}
export type ProjectsDeploymentsGetResponseStagesList = Array<ProjectsDeploymentsGetResponseStagesItem>;
export type ProjectsDeploymentsGetResponseSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetProjectDeploymentResponse {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsDeploymentsGetResponseAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsDeploymentsGetResponseDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsDeploymentsGetResponseEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsDeploymentsGetResponseLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsDeploymentsGetResponseSource;
    /** List of past stages. */
    stages: ProjectsDeploymentsGetResponseStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsDeploymentsGetResponseSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export interface GetProjectDeploymentHistoryLogRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** UUID of the Pages deployment, as returned by deployment list or create operations. */
    deploymentId: string;
}
export interface ProjectsDeploymentsHistoryLogsGetResponseDataItem {
    line: string;
    ts: string;
}
export type ProjectsDeploymentsHistoryLogsGetResponseDataList = Array<ProjectsDeploymentsHistoryLogsGetResponseDataItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetProjectDeploymentHistoryLogResponse {
    data: ProjectsDeploymentsHistoryLogsGetResponseDataList;
    includesContainerLogs: boolean;
    total: number;
}
export interface GetProjectDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Fully qualified domain name for the Pages project, such as `example.com`. */
    domainName: string;
}
export type ProjectsDomainsGetResponseCertificateAuthority = "google" | "lets_encrypt";
export type ProjectsDomainsGetResponseStatus = "initializing" | "pending" | "active" | "deactivated" | "blocked" | "error";
export type ProjectsDomainsGetResponseValidationDataMethod = "http" | "txt";
export type ProjectsDomainsGetResponseValidationDataStatus = "initializing" | "pending" | "active" | "deactivated" | "error";
export interface ProjectsDomainsGetResponseValidationData {
    method: ProjectsDomainsGetResponseValidationDataMethod;
    status: ProjectsDomainsGetResponseValidationDataStatus;
    errorMessage?: string | null;
    txtName?: string | null;
    txtValue?: string | null;
}
export type ProjectsDomainsGetResponseVerificationDataStatus = "pending" | "active" | "deactivated" | "blocked" | "error";
export interface ProjectsDomainsGetResponseVerificationData {
    status: ProjectsDomainsGetResponseVerificationDataStatus;
    errorMessage?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetProjectDomainResponse {
    id: string;
    certificateAuthority: ProjectsDomainsGetResponseCertificateAuthority;
    createdOn: string;
    domainId: string;
    /** Fully qualified domain name for the Pages project, such as `example.com`. */
    name: string;
    status: ProjectsDomainsGetResponseStatus;
    validationData: ProjectsDomainsGetResponseValidationData;
    verificationData: ProjectsDomainsGetResponseVerificationData;
    zoneTag: string;
}
export type ProjectsDeploymentsListRequestEnv = "production" | "preview";
export interface ListProjectDeploymentsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Deployment environment to return. Valid values are `production` and `preview`. */
    env?: ProjectsDeploymentsListRequestEnv | (string & {});
    /** Page number of results to return. */
    page?: number;
    /** Number of results to return per page. */
    perPage?: number;
}
export type ProjectsDeploymentsListResultItemAliasesList = Array<string>;
export type ProjectsDeploymentsListResultItemBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsDeploymentsListResultItemDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export type ProjectsDeploymentsListResultItemDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsDeploymentsListResultItemDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsDeploymentsListResultItemDeploymentTriggerType;
}
export type ProjectsDeploymentsListResultItemEnvironment = "preview" | "production";
export type ProjectsDeploymentsListResultItemLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsDeploymentsListResultItemLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsDeploymentsListResultItemLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsListResultItemLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsListResultItemLatestStageStatus;
}
export type ProjectsDeploymentsListResultItemSourceConfigPathExcludesList = Array<string>;
export type ProjectsDeploymentsListResultItemSourceConfigPathIncludesList = Array<string>;
export type ProjectsDeploymentsListResultItemSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsDeploymentsListResultItemSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsDeploymentsListResultItemSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsDeploymentsListResultItemSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsDeploymentsListResultItemSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsDeploymentsListResultItemSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsDeploymentsListResultItemSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsDeploymentsListResultItemSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsDeploymentsListResultItemSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsDeploymentsListResultItemSourceType = "github" | "gitlab";
export interface ProjectsDeploymentsListResultItemSource {
    config: ProjectsDeploymentsListResultItemSourceConfig;
    /** The source control management provider. */
    type: ProjectsDeploymentsListResultItemSourceType;
}
export type ProjectsDeploymentsListResultItemStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsDeploymentsListResultItemStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsDeploymentsListResultItemStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsListResultItemStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsListResultItemStagesItemStatus;
}
export type ProjectsDeploymentsListResultItemStagesList = Array<ProjectsDeploymentsListResultItemStagesItem>;
export type ProjectsDeploymentsListResultItemSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
export interface ProjectsDeploymentsListResultItem {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsDeploymentsListResultItemAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsDeploymentsListResultItemDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsDeploymentsListResultItemEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsDeploymentsListResultItemLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsDeploymentsListResultItemSource;
    /** List of past stages. */
    stages: ProjectsDeploymentsListResultItemStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsDeploymentsListResultItemSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export type ProjectsDeploymentsListResultList = Array<ProjectsDeploymentsListResultItem>;
export interface ListProjectDeploymentsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ProjectsDeploymentsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListProjectDomainsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
}
export type ProjectsDomainsListResultItemCertificateAuthority = "google" | "lets_encrypt";
export type ProjectsDomainsListResultItemStatus = "initializing" | "pending" | "active" | "deactivated" | "blocked" | "error";
export type ProjectsDomainsListResultItemValidationDataMethod = "http" | "txt";
export type ProjectsDomainsListResultItemValidationDataStatus = "initializing" | "pending" | "active" | "deactivated" | "error";
export interface ProjectsDomainsListResultItemValidationData {
    method: ProjectsDomainsListResultItemValidationDataMethod;
    status: ProjectsDomainsListResultItemValidationDataStatus;
    errorMessage?: string | null;
    txtName?: string | null;
    txtValue?: string | null;
}
export type ProjectsDomainsListResultItemVerificationDataStatus = "pending" | "active" | "deactivated" | "blocked" | "error";
export interface ProjectsDomainsListResultItemVerificationData {
    status: ProjectsDomainsListResultItemVerificationDataStatus;
    errorMessage?: string | null;
}
export interface ProjectsDomainsListResultItem {
    id: string;
    certificateAuthority: ProjectsDomainsListResultItemCertificateAuthority;
    createdOn: string;
    domainId: string;
    /** Fully qualified domain name for the Pages project, such as `example.com`. */
    name: string;
    status: ProjectsDomainsListResultItemStatus;
    validationData: ProjectsDomainsListResultItemValidationData;
    verificationData: ProjectsDomainsListResultItemVerificationData;
    zoneTag: string;
}
export type ProjectsDomainsListResultList = Array<ProjectsDomainsListResultItem>;
export interface ListProjectDomainsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ProjectsDomainsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListProjectsRequest {
    /** Identifier. */
    accountId: string;
    /** Page number of results to return. */
    page?: number;
    /** Number of results to return per page. */
    perPage?: number;
}
export type ProjectsListResultItemCanonicalDeploymentAliasesList = Array<string>;
export type ProjectsListResultItemCanonicalDeploymentBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsListResultItemCanonicalDeploymentDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export type ProjectsListResultItemCanonicalDeploymentDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsListResultItemCanonicalDeploymentDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsListResultItemCanonicalDeploymentDeploymentTriggerType;
}
export type ProjectsListResultItemCanonicalDeploymentEnvironment = "preview" | "production";
export type ProjectsListResultItemCanonicalDeploymentLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsListResultItemCanonicalDeploymentLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsListResultItemCanonicalDeploymentLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsListResultItemCanonicalDeploymentLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsListResultItemCanonicalDeploymentLatestStageStatus;
}
export type ProjectsListResultItemCanonicalDeploymentSourceConfigPathExcludesList = Array<string>;
export type ProjectsListResultItemCanonicalDeploymentSourceConfigPathIncludesList = Array<string>;
export type ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsListResultItemCanonicalDeploymentSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsListResultItemCanonicalDeploymentSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsListResultItemCanonicalDeploymentSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsListResultItemCanonicalDeploymentSourceType = "github" | "gitlab";
export interface ProjectsListResultItemCanonicalDeploymentSource {
    config: ProjectsListResultItemCanonicalDeploymentSourceConfig;
    /** The source control management provider. */
    type: ProjectsListResultItemCanonicalDeploymentSourceType;
}
export type ProjectsListResultItemCanonicalDeploymentStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsListResultItemCanonicalDeploymentStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsListResultItemCanonicalDeploymentStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsListResultItemCanonicalDeploymentStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsListResultItemCanonicalDeploymentStagesItemStatus;
}
export type ProjectsListResultItemCanonicalDeploymentStagesList = Array<ProjectsListResultItemCanonicalDeploymentStagesItem>;
export type ProjectsListResultItemCanonicalDeploymentSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
export interface ProjectsListResultItemCanonicalDeployment {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsListResultItemCanonicalDeploymentAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsListResultItemCanonicalDeploymentDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsListResultItemCanonicalDeploymentEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsListResultItemCanonicalDeploymentLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsListResultItemCanonicalDeploymentSource;
    /** List of past stages. */
    stages: ProjectsListResultItemCanonicalDeploymentStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsListResultItemCanonicalDeploymentSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export type ProjectsListResultItemDeploymentConfigsPreviewCompatibilityFlagsList = Array<string>;
export type ProjectsListResultItemDeploymentConfigsPreviewUsageModel = "standard" | "bundled" | "unbound";
export type ProjectsListResultItemDeploymentConfigsPreviewAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export type ProjectsListResultItemDeploymentConfigsPreviewAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsPreviewAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export type ProjectsListResultItemDeploymentConfigsPreviewAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsPreviewBrowsersMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsListResultItemDeploymentConfigsPreviewD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsListResultItemDeploymentConfigsPreviewDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export type ProjectsListResultItemDeploymentConfigsPreviewDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsPreviewHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export type ProjectsListResultItemDeploymentConfigsPreviewHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsPreviewKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsListResultItemDeploymentConfigsPreviewLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export type ProjectsListResultItemDeploymentConfigsPreviewMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export type ProjectsListResultItemDeploymentConfigsPreviewMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsPreviewPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export type ProjectsListResultItemDeploymentConfigsPreviewQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export type ProjectsListResultItemDeploymentConfigsPreviewQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsPreviewR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsListResultItemDeploymentConfigsPreviewServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export type ProjectsListResultItemDeploymentConfigsPreviewServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsPreviewVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export type ProjectsListResultItemDeploymentConfigsPreviewVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export interface ProjectsListResultItemDeploymentConfigsPreview {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. Version 1 is retired and its projects are moved to version 3. Once a project's builds have been moved, this is the version the builds run on and `build_image_auto_upgrade` is set on the project. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsListResultItemDeploymentConfigsPreviewCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** All new projects now use the Standard usage model. */
    usageModel: ProjectsListResultItemDeploymentConfigsPreviewUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsListResultItemDeploymentConfigsPreviewAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsListResultItemDeploymentConfigsPreviewAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsListResultItemDeploymentConfigsPreviewBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsListResultItemDeploymentConfigsPreviewD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsListResultItemDeploymentConfigsPreviewDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsListResultItemDeploymentConfigsPreviewHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsListResultItemDeploymentConfigsPreviewKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsListResultItemDeploymentConfigsPreviewMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsListResultItemDeploymentConfigsPreviewQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsListResultItemDeploymentConfigsPreviewR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsListResultItemDeploymentConfigsPreviewServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsListResultItemDeploymentConfigsPreviewVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export type ProjectsListResultItemDeploymentConfigsProductionCompatibilityFlagsList = Array<string>;
export type ProjectsListResultItemDeploymentConfigsProductionUsageModel = "standard" | "bundled" | "unbound";
export type ProjectsListResultItemDeploymentConfigsProductionAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export type ProjectsListResultItemDeploymentConfigsProductionAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsProductionAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export type ProjectsListResultItemDeploymentConfigsProductionAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsProductionBrowsersMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsListResultItemDeploymentConfigsProductionD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsListResultItemDeploymentConfigsProductionDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export type ProjectsListResultItemDeploymentConfigsProductionDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsProductionHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export type ProjectsListResultItemDeploymentConfigsProductionHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsProductionKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsListResultItemDeploymentConfigsProductionLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export type ProjectsListResultItemDeploymentConfigsProductionMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export type ProjectsListResultItemDeploymentConfigsProductionMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsProductionPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export type ProjectsListResultItemDeploymentConfigsProductionQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export type ProjectsListResultItemDeploymentConfigsProductionQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsProductionR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsListResultItemDeploymentConfigsProductionServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export type ProjectsListResultItemDeploymentConfigsProductionServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export type ProjectsListResultItemDeploymentConfigsProductionVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export type ProjectsListResultItemDeploymentConfigsProductionVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export interface ProjectsListResultItemDeploymentConfigsProduction {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. Version 1 is retired and its projects are moved to version 3. Once a project's builds have been moved, this is the version the builds run on and `build_image_auto_upgrade` is set on the project. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsListResultItemDeploymentConfigsProductionCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** All new projects now use the Standard usage model. */
    usageModel: ProjectsListResultItemDeploymentConfigsProductionUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsListResultItemDeploymentConfigsProductionAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsListResultItemDeploymentConfigsProductionAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsListResultItemDeploymentConfigsProductionBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsListResultItemDeploymentConfigsProductionD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsListResultItemDeploymentConfigsProductionDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsListResultItemDeploymentConfigsProductionHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsListResultItemDeploymentConfigsProductionKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsListResultItemDeploymentConfigsProductionMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsListResultItemDeploymentConfigsProductionQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsListResultItemDeploymentConfigsProductionR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsListResultItemDeploymentConfigsProductionServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsListResultItemDeploymentConfigsProductionVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export interface ProjectsListResultItemDeploymentConfigs {
    /** Configs for preview deploys. */
    preview: ProjectsListResultItemDeploymentConfigsPreview;
    /** Configs for production deploys. */
    production: ProjectsListResultItemDeploymentConfigsProduction;
}
export type ProjectsListResultItemLatestDeploymentAliasesList = Array<string>;
export type ProjectsListResultItemLatestDeploymentBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsListResultItemLatestDeploymentDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export type ProjectsListResultItemLatestDeploymentDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsListResultItemLatestDeploymentDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsListResultItemLatestDeploymentDeploymentTriggerType;
}
export type ProjectsListResultItemLatestDeploymentEnvVarsValuePlainTextType = "plain_text";
export interface ProjectsListResultItemLatestDeploymentEnvVarsValuePlainText {
    type: ProjectsListResultItemLatestDeploymentEnvVarsValuePlainTextType;
    /** Environment variable value. */
    value: string;
}
export type ProjectsListResultItemLatestDeploymentEnvVarsValueSecretTextType = "secret_text";
export interface ProjectsListResultItemLatestDeploymentEnvVarsValueSecretText {
    type: ProjectsListResultItemLatestDeploymentEnvVarsValueSecretTextType;
    /** Secret value. */
    value: string;
}
export type ProjectsListResultItemLatestDeploymentEnvVarsValue = ProjectsListResultItemLatestDeploymentEnvVarsValuePlainText | ProjectsListResultItemLatestDeploymentEnvVarsValueSecretText;
export type ProjectsListResultItemLatestDeploymentEnvVarsMap = {
    [key: string]: ProjectsListResultItemLatestDeploymentEnvVarsValue | undefined;
};
export type ProjectsListResultItemLatestDeploymentEnvironment = "preview" | "production";
export type ProjectsListResultItemLatestDeploymentLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsListResultItemLatestDeploymentLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsListResultItemLatestDeploymentLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsListResultItemLatestDeploymentLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsListResultItemLatestDeploymentLatestStageStatus;
}
export type ProjectsListResultItemLatestDeploymentSourceConfigPathExcludesList = Array<string>;
export type ProjectsListResultItemLatestDeploymentSourceConfigPathIncludesList = Array<string>;
export type ProjectsListResultItemLatestDeploymentSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsListResultItemLatestDeploymentSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsListResultItemLatestDeploymentSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsListResultItemLatestDeploymentSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsListResultItemLatestDeploymentSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsListResultItemLatestDeploymentSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsListResultItemLatestDeploymentSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsListResultItemLatestDeploymentSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsListResultItemLatestDeploymentSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsListResultItemLatestDeploymentSourceType = "github" | "gitlab";
export interface ProjectsListResultItemLatestDeploymentSource {
    config: ProjectsListResultItemLatestDeploymentSourceConfig;
    /** The source control management provider. */
    type: ProjectsListResultItemLatestDeploymentSourceType;
}
export type ProjectsListResultItemLatestDeploymentStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsListResultItemLatestDeploymentStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsListResultItemLatestDeploymentStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsListResultItemLatestDeploymentStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsListResultItemLatestDeploymentStagesItemStatus;
}
export type ProjectsListResultItemLatestDeploymentStagesList = Array<ProjectsListResultItemLatestDeploymentStagesItem>;
export type ProjectsListResultItemLatestDeploymentSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
export interface ProjectsListResultItemLatestDeployment {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsListResultItemLatestDeploymentAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsListResultItemLatestDeploymentDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: ProjectsListResultItemLatestDeploymentEnvVarsMap;
    /** Type of deploy. */
    environment: ProjectsListResultItemLatestDeploymentEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsListResultItemLatestDeploymentLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsListResultItemLatestDeploymentSource;
    /** List of past stages. */
    stages: ProjectsListResultItemLatestDeploymentStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsListResultItemLatestDeploymentSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export type ProjectsListResultItemBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsListResultItemBuildImageAutoUpgrade = ProjectsCreateResponseBuildImageAutoUpgrade;
export type ProjectsListResultItemDomainsList = Array<string>;
export type ProjectsListResultItemSourceConfigPathExcludesList = Array<string>;
export type ProjectsListResultItemSourceConfigPathIncludesList = Array<string>;
export type ProjectsListResultItemSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsListResultItemSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsListResultItemSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsListResultItemSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsListResultItemSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsListResultItemSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsListResultItemSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsListResultItemSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsListResultItemSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsListResultItemSourceType = "github" | "gitlab";
export interface ProjectsListResultItemSource {
    config: ProjectsListResultItemSourceConfig;
    /** The source control management provider. */
    type: ProjectsListResultItemSourceType;
}
export interface ProjectsListResultItem {
    /** ID of the project. */
    id: string;
    /** Most recent production deployment of the project. */
    canonicalDeployment: ProjectsListResultItemCanonicalDeployment;
    /** When the project was created. */
    createdOn: string;
    /** Configs for deployments in a project. */
    deploymentConfigs: ProjectsListResultItemDeploymentConfigs;
    /** Framework the project is using. */
    framework: string;
    /** Version of the framework the project is using. */
    frameworkVersion: string;
    /** Most recent deployment of the project. */
    latestDeployment: ProjectsListResultItemLatestDeployment;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    name: string;
    /** Name of the preview script. */
    previewScriptName: string;
    /** Production branch of the project. Used to identify production deployments. */
    productionBranch: string;
    /** Name of the production script. */
    productionScriptName: string;
    /** Whether the project uses functions. */
    usesFunctions: boolean;
    /** Configs for the project build process. */
    buildConfig?: ProjectsCreateResponseCanonicalDeploymentBuildConfig | null;
    /** Present when the project is set to a retired build image major version and its builds have been moved to a newer one. `build_image_major_version` in `deployment_configs` then reports the version the builds run on. */
    buildImageAutoUpgrade?: ProjectsCreateResponseBuildImageAutoUpgrade | null;
    /** A list of associated custom domains for the project. */
    domains?: ProjectsListResultItemDomainsList | null;
    /** Configs for the project source control. */
    source?: ProjectsListResultItemSource | null;
    /** The Cloudflare subdomain associated with the project. */
    subdomain?: string | null;
}
export type ProjectsListResultList = Array<ProjectsListResultItem>;
export interface ListProjectsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ProjectsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ProjectsEditRequestBuildConfig = ProjectsCreateRequestBuildConfig;
export type ProjectsEditRequestDeploymentConfigsPreviewAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export type ProjectsEditRequestDeploymentConfigsPreviewAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export type ProjectsEditRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsPreviewBrowsersMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditRequestDeploymentConfigsPreviewCompatibilityFlagsList = Array<string>;
export type ProjectsEditRequestDeploymentConfigsPreviewD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditRequestDeploymentConfigsPreviewDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export type ProjectsEditRequestDeploymentConfigsPreviewDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsPreviewHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export type ProjectsEditRequestDeploymentConfigsPreviewHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsPreviewKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditRequestDeploymentConfigsPreviewLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export type ProjectsEditRequestDeploymentConfigsPreviewMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export type ProjectsEditRequestDeploymentConfigsPreviewMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsPreviewPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export type ProjectsEditRequestDeploymentConfigsPreviewQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export type ProjectsEditRequestDeploymentConfigsPreviewQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsPreviewR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditRequestDeploymentConfigsPreviewServicesValue = ProjectsCreateRequestDeploymentConfigsPreviewServicesValue;
export type ProjectsEditRequestDeploymentConfigsPreviewServicesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewServicesValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsPreviewUsageModel = "standard" | "bundled" | "unbound";
export type ProjectsEditRequestDeploymentConfigsPreviewVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export type ProjectsEditRequestDeploymentConfigsPreviewVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export interface ProjectsEditRequestDeploymentConfigsPreview {
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsEditRequestDeploymentConfigsPreviewAiBindingsMap;
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate?: boolean;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsEditRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsMap;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsEditRequestDeploymentConfigsPreviewBrowsersMap;
    /** The major version of the build image to use for Pages Functions. Version 1 is retired and its projects are moved to version 3. Once a project's builds have been moved, a request that sets version 1 is rejected. */
    buildImageMajorVersion?: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate?: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags?: ProjectsEditRequestDeploymentConfigsPreviewCompatibilityFlagsList;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsEditRequestDeploymentConfigsPreviewD1DatabasesMap;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsEditRequestDeploymentConfigsPreviewDurableObjectNamespacesMap;
    /** Environment variables used for builds and Pages Functions. */
    envVars?: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen?: boolean;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsEditRequestDeploymentConfigsPreviewHyperdriveBindingsMap;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsEditRequestDeploymentConfigsPreviewKvNamespacesMap;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsEditRequestDeploymentConfigsPreviewMtlsCertificatesMap;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsEditRequestDeploymentConfigsPreviewQueueProducersMap;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsEditRequestDeploymentConfigsPreviewR2BucketsMap;
    /** Services used for Pages Functions. */
    services?: ProjectsEditRequestDeploymentConfigsPreviewServicesMap;
    /** All new projects now use the Standard usage model. */
    usageModel?: ProjectsEditRequestDeploymentConfigsPreviewUsageModel | (string & {});
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsEditRequestDeploymentConfigsPreviewVectorizeBindingsMap;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string;
}
export type ProjectsEditRequestDeploymentConfigsProductionAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export type ProjectsEditRequestDeploymentConfigsProductionAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsProductionAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export type ProjectsEditRequestDeploymentConfigsProductionAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsProductionBrowsersMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditRequestDeploymentConfigsProductionCompatibilityFlagsList = Array<string>;
export type ProjectsEditRequestDeploymentConfigsProductionD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditRequestDeploymentConfigsProductionDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export type ProjectsEditRequestDeploymentConfigsProductionDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsProductionHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export type ProjectsEditRequestDeploymentConfigsProductionHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsProductionKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditRequestDeploymentConfigsProductionLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export type ProjectsEditRequestDeploymentConfigsProductionMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export type ProjectsEditRequestDeploymentConfigsProductionMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsProductionPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export type ProjectsEditRequestDeploymentConfigsProductionQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export type ProjectsEditRequestDeploymentConfigsProductionQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsProductionR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditRequestDeploymentConfigsProductionServicesValue = ProjectsCreateRequestDeploymentConfigsPreviewServicesValue;
export type ProjectsEditRequestDeploymentConfigsProductionServicesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewServicesValue | undefined;
};
export type ProjectsEditRequestDeploymentConfigsProductionUsageModel = "standard" | "bundled" | "unbound";
export type ProjectsEditRequestDeploymentConfigsProductionVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export type ProjectsEditRequestDeploymentConfigsProductionVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export interface ProjectsEditRequestDeploymentConfigsProduction {
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsEditRequestDeploymentConfigsProductionAiBindingsMap;
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate?: boolean;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsEditRequestDeploymentConfigsProductionAnalyticsEngineDatasetsMap;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsEditRequestDeploymentConfigsProductionBrowsersMap;
    /** The major version of the build image to use for Pages Functions. Version 1 is retired and its projects are moved to version 3. Once a project's builds have been moved, a request that sets version 1 is rejected. */
    buildImageMajorVersion?: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate?: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags?: ProjectsEditRequestDeploymentConfigsProductionCompatibilityFlagsList;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsEditRequestDeploymentConfigsProductionD1DatabasesMap;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsEditRequestDeploymentConfigsProductionDurableObjectNamespacesMap;
    /** Environment variables used for builds and Pages Functions. */
    envVars?: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen?: boolean;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsEditRequestDeploymentConfigsProductionHyperdriveBindingsMap;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsEditRequestDeploymentConfigsProductionKvNamespacesMap;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsEditRequestDeploymentConfigsProductionMtlsCertificatesMap;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsEditRequestDeploymentConfigsProductionQueueProducersMap;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsEditRequestDeploymentConfigsProductionR2BucketsMap;
    /** Services used for Pages Functions. */
    services?: ProjectsEditRequestDeploymentConfigsProductionServicesMap;
    /** All new projects now use the Standard usage model. */
    usageModel?: ProjectsEditRequestDeploymentConfigsProductionUsageModel | (string & {});
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsEditRequestDeploymentConfigsProductionVectorizeBindingsMap;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string;
}
export interface ProjectsEditRequestDeploymentConfigs {
    /** Configs for preview deploys. */
    preview?: ProjectsEditRequestDeploymentConfigsPreview;
    /** Configs for production deploys. */
    production?: ProjectsEditRequestDeploymentConfigsProduction;
}
export type ProjectsEditRequestSourceConfigPathExcludesList = Array<string>;
export type ProjectsEditRequestSourceConfigPathIncludesList = Array<string>;
export type ProjectsEditRequestSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsEditRequestSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsEditRequestSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsEditRequestSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled?: boolean;
    /** The owner of the repository. */
    owner?: string;
    /** The owner ID of the repository. */
    ownerId?: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes?: ProjectsEditRequestSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes?: ProjectsEditRequestSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled?: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes?: ProjectsEditRequestSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes?: ProjectsEditRequestSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting?: ProjectsEditRequestSourceConfigPreviewDeploymentSetting | (string & {});
    /** The production branch of the repository. */
    productionBranch?: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled?: boolean;
    /** The ID of the repository. */
    repoId?: string;
    /** The name of the repository. */
    repoName?: string;
}
export type ProjectsEditRequestSourceType = "github" | "gitlab";
export interface ProjectsEditRequestSource {
    config: ProjectsEditRequestSourceConfig;
    /** The source control management provider. */
    type: ProjectsEditRequestSourceType | (string & {});
}
export interface PatchProjectRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Configs for the project build process. */
    buildConfig?: ProjectsCreateRequestBuildConfig;
    /** Configs for deployments in a project. */
    deploymentConfigs?: ProjectsEditRequestDeploymentConfigs;
    /** Name for the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    name?: string;
    /** Production branch of the project. Used to identify production deployments. */
    productionBranch?: string;
    /** Configs for the project source control. */
    source?: ProjectsEditRequestSource;
}
export type ProjectsEditResponseCanonicalDeploymentAliasesList = Array<string>;
export type ProjectsEditResponseCanonicalDeploymentBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsEditResponseCanonicalDeploymentDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export type ProjectsEditResponseCanonicalDeploymentDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsEditResponseCanonicalDeploymentDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsEditResponseCanonicalDeploymentDeploymentTriggerType;
}
export type ProjectsEditResponseCanonicalDeploymentEnvironment = "preview" | "production";
export type ProjectsEditResponseCanonicalDeploymentLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsEditResponseCanonicalDeploymentLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsEditResponseCanonicalDeploymentLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsEditResponseCanonicalDeploymentLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsEditResponseCanonicalDeploymentLatestStageStatus;
}
export type ProjectsEditResponseCanonicalDeploymentSourceConfigPathExcludesList = Array<string>;
export type ProjectsEditResponseCanonicalDeploymentSourceConfigPathIncludesList = Array<string>;
export type ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsEditResponseCanonicalDeploymentSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsEditResponseCanonicalDeploymentSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsEditResponseCanonicalDeploymentSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsEditResponseCanonicalDeploymentSourceType = "github" | "gitlab";
export interface ProjectsEditResponseCanonicalDeploymentSource {
    config: ProjectsEditResponseCanonicalDeploymentSourceConfig;
    /** The source control management provider. */
    type: ProjectsEditResponseCanonicalDeploymentSourceType;
}
export type ProjectsEditResponseCanonicalDeploymentStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsEditResponseCanonicalDeploymentStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsEditResponseCanonicalDeploymentStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsEditResponseCanonicalDeploymentStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsEditResponseCanonicalDeploymentStagesItemStatus;
}
export type ProjectsEditResponseCanonicalDeploymentStagesList = Array<ProjectsEditResponseCanonicalDeploymentStagesItem>;
export type ProjectsEditResponseCanonicalDeploymentSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
export interface ProjectsEditResponseCanonicalDeployment {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsEditResponseCanonicalDeploymentAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsEditResponseCanonicalDeploymentDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsEditResponseCanonicalDeploymentEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsEditResponseCanonicalDeploymentLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsEditResponseCanonicalDeploymentSource;
    /** List of past stages. */
    stages: ProjectsEditResponseCanonicalDeploymentStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsEditResponseCanonicalDeploymentSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export type ProjectsEditResponseDeploymentConfigsPreviewCompatibilityFlagsList = Array<string>;
export type ProjectsEditResponseDeploymentConfigsPreviewUsageModel = "standard" | "bundled" | "unbound";
export type ProjectsEditResponseDeploymentConfigsPreviewAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export type ProjectsEditResponseDeploymentConfigsPreviewAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export type ProjectsEditResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsPreviewBrowsersMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditResponseDeploymentConfigsPreviewD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditResponseDeploymentConfigsPreviewDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export type ProjectsEditResponseDeploymentConfigsPreviewDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsPreviewHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export type ProjectsEditResponseDeploymentConfigsPreviewHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsPreviewKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditResponseDeploymentConfigsPreviewLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export type ProjectsEditResponseDeploymentConfigsPreviewMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export type ProjectsEditResponseDeploymentConfigsPreviewMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsPreviewPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export type ProjectsEditResponseDeploymentConfigsPreviewQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export type ProjectsEditResponseDeploymentConfigsPreviewQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsPreviewR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditResponseDeploymentConfigsPreviewServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export type ProjectsEditResponseDeploymentConfigsPreviewServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsPreviewVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export type ProjectsEditResponseDeploymentConfigsPreviewVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export interface ProjectsEditResponseDeploymentConfigsPreview {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. Version 1 is retired and its projects are moved to version 3. Once a project's builds have been moved, this is the version the builds run on and `build_image_auto_upgrade` is set on the project. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsEditResponseDeploymentConfigsPreviewCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** All new projects now use the Standard usage model. */
    usageModel: ProjectsEditResponseDeploymentConfigsPreviewUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsEditResponseDeploymentConfigsPreviewAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsEditResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsEditResponseDeploymentConfigsPreviewBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsEditResponseDeploymentConfigsPreviewD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsEditResponseDeploymentConfigsPreviewDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsEditResponseDeploymentConfigsPreviewHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsEditResponseDeploymentConfigsPreviewKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsEditResponseDeploymentConfigsPreviewMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsEditResponseDeploymentConfigsPreviewQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsEditResponseDeploymentConfigsPreviewR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsEditResponseDeploymentConfigsPreviewServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsEditResponseDeploymentConfigsPreviewVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export type ProjectsEditResponseDeploymentConfigsProductionCompatibilityFlagsList = Array<string>;
export type ProjectsEditResponseDeploymentConfigsProductionUsageModel = "standard" | "bundled" | "unbound";
export type ProjectsEditResponseDeploymentConfigsProductionAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export type ProjectsEditResponseDeploymentConfigsProductionAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsProductionAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export type ProjectsEditResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsProductionBrowsersMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditResponseDeploymentConfigsProductionD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditResponseDeploymentConfigsProductionDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export type ProjectsEditResponseDeploymentConfigsProductionDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsProductionHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export type ProjectsEditResponseDeploymentConfigsProductionHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsProductionKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditResponseDeploymentConfigsProductionLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export type ProjectsEditResponseDeploymentConfigsProductionMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export type ProjectsEditResponseDeploymentConfigsProductionMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsProductionPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export type ProjectsEditResponseDeploymentConfigsProductionQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export type ProjectsEditResponseDeploymentConfigsProductionQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsProductionR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsEditResponseDeploymentConfigsProductionServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export type ProjectsEditResponseDeploymentConfigsProductionServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export type ProjectsEditResponseDeploymentConfigsProductionVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export type ProjectsEditResponseDeploymentConfigsProductionVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export interface ProjectsEditResponseDeploymentConfigsProduction {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. Version 1 is retired and its projects are moved to version 3. Once a project's builds have been moved, this is the version the builds run on and `build_image_auto_upgrade` is set on the project. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsEditResponseDeploymentConfigsProductionCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** All new projects now use the Standard usage model. */
    usageModel: ProjectsEditResponseDeploymentConfigsProductionUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsEditResponseDeploymentConfigsProductionAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsEditResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsEditResponseDeploymentConfigsProductionBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsEditResponseDeploymentConfigsProductionD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsEditResponseDeploymentConfigsProductionDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsEditResponseDeploymentConfigsProductionHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsEditResponseDeploymentConfigsProductionKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsEditResponseDeploymentConfigsProductionMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsEditResponseDeploymentConfigsProductionQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsEditResponseDeploymentConfigsProductionR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsEditResponseDeploymentConfigsProductionServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsEditResponseDeploymentConfigsProductionVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export interface ProjectsEditResponseDeploymentConfigs {
    /** Configs for preview deploys. */
    preview: ProjectsEditResponseDeploymentConfigsPreview;
    /** Configs for production deploys. */
    production: ProjectsEditResponseDeploymentConfigsProduction;
}
export type ProjectsEditResponseLatestDeploymentAliasesList = Array<string>;
export type ProjectsEditResponseLatestDeploymentBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsEditResponseLatestDeploymentDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export type ProjectsEditResponseLatestDeploymentDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsEditResponseLatestDeploymentDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsEditResponseLatestDeploymentDeploymentTriggerType;
}
export type ProjectsEditResponseLatestDeploymentEnvVarsValuePlainTextType = "plain_text";
export interface ProjectsEditResponseLatestDeploymentEnvVarsValuePlainText {
    type: ProjectsEditResponseLatestDeploymentEnvVarsValuePlainTextType;
    /** Environment variable value. */
    value: string;
}
export type ProjectsEditResponseLatestDeploymentEnvVarsValueSecretTextType = "secret_text";
export interface ProjectsEditResponseLatestDeploymentEnvVarsValueSecretText {
    type: ProjectsEditResponseLatestDeploymentEnvVarsValueSecretTextType;
    /** Secret value. */
    value: string;
}
export type ProjectsEditResponseLatestDeploymentEnvVarsValue = ProjectsEditResponseLatestDeploymentEnvVarsValuePlainText | ProjectsEditResponseLatestDeploymentEnvVarsValueSecretText;
export type ProjectsEditResponseLatestDeploymentEnvVarsMap = {
    [key: string]: ProjectsEditResponseLatestDeploymentEnvVarsValue | undefined;
};
export type ProjectsEditResponseLatestDeploymentEnvironment = "preview" | "production";
export type ProjectsEditResponseLatestDeploymentLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsEditResponseLatestDeploymentLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsEditResponseLatestDeploymentLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsEditResponseLatestDeploymentLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsEditResponseLatestDeploymentLatestStageStatus;
}
export type ProjectsEditResponseLatestDeploymentSourceConfigPathExcludesList = Array<string>;
export type ProjectsEditResponseLatestDeploymentSourceConfigPathIncludesList = Array<string>;
export type ProjectsEditResponseLatestDeploymentSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsEditResponseLatestDeploymentSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsEditResponseLatestDeploymentSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsEditResponseLatestDeploymentSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsEditResponseLatestDeploymentSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsEditResponseLatestDeploymentSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsEditResponseLatestDeploymentSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsEditResponseLatestDeploymentSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsEditResponseLatestDeploymentSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsEditResponseLatestDeploymentSourceType = "github" | "gitlab";
export interface ProjectsEditResponseLatestDeploymentSource {
    config: ProjectsEditResponseLatestDeploymentSourceConfig;
    /** The source control management provider. */
    type: ProjectsEditResponseLatestDeploymentSourceType;
}
export type ProjectsEditResponseLatestDeploymentStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsEditResponseLatestDeploymentStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsEditResponseLatestDeploymentStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsEditResponseLatestDeploymentStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsEditResponseLatestDeploymentStagesItemStatus;
}
export type ProjectsEditResponseLatestDeploymentStagesList = Array<ProjectsEditResponseLatestDeploymentStagesItem>;
export type ProjectsEditResponseLatestDeploymentSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
export interface ProjectsEditResponseLatestDeployment {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsEditResponseLatestDeploymentAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsEditResponseLatestDeploymentDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: ProjectsEditResponseLatestDeploymentEnvVarsMap;
    /** Type of deploy. */
    environment: ProjectsEditResponseLatestDeploymentEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsEditResponseLatestDeploymentLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsEditResponseLatestDeploymentSource;
    /** List of past stages. */
    stages: ProjectsEditResponseLatestDeploymentStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsEditResponseLatestDeploymentSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export type ProjectsEditResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsEditResponseBuildImageAutoUpgrade = ProjectsCreateResponseBuildImageAutoUpgrade;
export type ProjectsEditResponseDomainsList = Array<string>;
export type ProjectsEditResponseSourceConfigPathExcludesList = Array<string>;
export type ProjectsEditResponseSourceConfigPathIncludesList = Array<string>;
export type ProjectsEditResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsEditResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsEditResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsEditResponseSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsEditResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsEditResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsEditResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsEditResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsEditResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsEditResponseSourceType = "github" | "gitlab";
export interface ProjectsEditResponseSource {
    config: ProjectsEditResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsEditResponseSourceType;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchProjectResponse {
    /** ID of the project. */
    id: string;
    /** Most recent production deployment of the project. */
    canonicalDeployment: ProjectsEditResponseCanonicalDeployment;
    /** When the project was created. */
    createdOn: string;
    /** Configs for deployments in a project. */
    deploymentConfigs: ProjectsEditResponseDeploymentConfigs;
    /** Framework the project is using. */
    framework: string;
    /** Version of the framework the project is using. */
    frameworkVersion: string;
    /** Most recent deployment of the project. */
    latestDeployment: ProjectsEditResponseLatestDeployment;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    name: string;
    /** Name of the preview script. */
    previewScriptName: string;
    /** Production branch of the project. Used to identify production deployments. */
    productionBranch: string;
    /** Name of the production script. */
    productionScriptName: string;
    /** Whether the project uses functions. */
    usesFunctions: boolean;
    /** Configs for the project build process. */
    buildConfig?: ProjectsCreateResponseCanonicalDeploymentBuildConfig | null;
    /** Present when the project is set to a retired build image major version and its builds have been moved to a newer one. `build_image_major_version` in `deployment_configs` then reports the version the builds run on. */
    buildImageAutoUpgrade?: ProjectsCreateResponseBuildImageAutoUpgrade | null;
    /** A list of associated custom domains for the project. */
    domains?: ProjectsEditResponseDomainsList | null;
    /** Configs for the project source control. */
    source?: ProjectsEditResponseSource | null;
    /** The Cloudflare subdomain associated with the project. */
    subdomain?: string | null;
}
export interface PatchProjectDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Fully qualified domain name for the Pages project, such as `example.com`. */
    domainName: string;
}
export type ProjectsDomainsEditResponseCertificateAuthority = "google" | "lets_encrypt";
export type ProjectsDomainsEditResponseStatus = "initializing" | "pending" | "active" | "deactivated" | "blocked" | "error";
export type ProjectsDomainsEditResponseValidationDataMethod = "http" | "txt";
export type ProjectsDomainsEditResponseValidationDataStatus = "initializing" | "pending" | "active" | "deactivated" | "error";
export interface ProjectsDomainsEditResponseValidationData {
    method: ProjectsDomainsEditResponseValidationDataMethod;
    status: ProjectsDomainsEditResponseValidationDataStatus;
    errorMessage?: string | null;
    txtName?: string | null;
    txtValue?: string | null;
}
export type ProjectsDomainsEditResponseVerificationDataStatus = "pending" | "active" | "deactivated" | "blocked" | "error";
export interface ProjectsDomainsEditResponseVerificationData {
    status: ProjectsDomainsEditResponseVerificationDataStatus;
    errorMessage?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchProjectDomainResponse {
    id: string;
    certificateAuthority: ProjectsDomainsEditResponseCertificateAuthority;
    createdOn: string;
    domainId: string;
    /** Fully qualified domain name for the Pages project, such as `example.com`. */
    name: string;
    status: ProjectsDomainsEditResponseStatus;
    validationData: ProjectsDomainsEditResponseValidationData;
    verificationData: ProjectsDomainsEditResponseVerificationData;
    zoneTag: string;
}
export interface ProjectsGetUploadTokenRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ProjectsGetUploadTokenResponse {
    /** Short-lived JWT used to authenticate Pages Direct Upload asset operations. */
    jwt: string;
}
export interface PurgeBuildCacheProjectRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
}
export type PurgeBuildCacheProjectResponse = unknown;
export interface RetryProjectDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** UUID of the Pages deployment, as returned by deployment list or create operations. */
    deploymentId: string;
}
export type ProjectsDeploymentsRetryResponseAliasesList = Array<string>;
export type ProjectsDeploymentsRetryResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsDeploymentsRetryResponseDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export type ProjectsDeploymentsRetryResponseDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsDeploymentsRetryResponseDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsDeploymentsRetryResponseDeploymentTriggerType;
}
export type ProjectsDeploymentsRetryResponseEnvironment = "preview" | "production";
export type ProjectsDeploymentsRetryResponseLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsDeploymentsRetryResponseLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsDeploymentsRetryResponseLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsRetryResponseLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsRetryResponseLatestStageStatus;
}
export type ProjectsDeploymentsRetryResponseSourceConfigPathExcludesList = Array<string>;
export type ProjectsDeploymentsRetryResponseSourceConfigPathIncludesList = Array<string>;
export type ProjectsDeploymentsRetryResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsDeploymentsRetryResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsDeploymentsRetryResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsDeploymentsRetryResponseSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsDeploymentsRetryResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsDeploymentsRetryResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsDeploymentsRetryResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsDeploymentsRetryResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsDeploymentsRetryResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsDeploymentsRetryResponseSourceType = "github" | "gitlab";
export interface ProjectsDeploymentsRetryResponseSource {
    config: ProjectsDeploymentsRetryResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsDeploymentsRetryResponseSourceType;
}
export type ProjectsDeploymentsRetryResponseStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsDeploymentsRetryResponseStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsDeploymentsRetryResponseStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsRetryResponseStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsRetryResponseStagesItemStatus;
}
export type ProjectsDeploymentsRetryResponseStagesList = Array<ProjectsDeploymentsRetryResponseStagesItem>;
export type ProjectsDeploymentsRetryResponseSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RetryProjectDeploymentResponse {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsDeploymentsRetryResponseAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsDeploymentsRetryResponseDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsDeploymentsRetryResponseEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsDeploymentsRetryResponseLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsDeploymentsRetryResponseSource;
    /** List of past stages. */
    stages: ProjectsDeploymentsRetryResponseStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsDeploymentsRetryResponseSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export interface RollbackProjectDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** UUID of the Pages deployment, as returned by deployment list or create operations. */
    deploymentId: string;
}
export type ProjectsDeploymentsRollbackResponseAliasesList = Array<string>;
export type ProjectsDeploymentsRollbackResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export type ProjectsDeploymentsRollbackResponseDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export type ProjectsDeploymentsRollbackResponseDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export interface ProjectsDeploymentsRollbackResponseDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsDeploymentsRollbackResponseDeploymentTriggerType;
}
export type ProjectsDeploymentsRollbackResponseEnvironment = "preview" | "production";
export type ProjectsDeploymentsRollbackResponseLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsDeploymentsRollbackResponseLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsDeploymentsRollbackResponseLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsRollbackResponseLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsRollbackResponseLatestStageStatus;
}
export type ProjectsDeploymentsRollbackResponseSourceConfigPathExcludesList = Array<string>;
export type ProjectsDeploymentsRollbackResponseSourceConfigPathIncludesList = Array<string>;
export type ProjectsDeploymentsRollbackResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export type ProjectsDeploymentsRollbackResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export type ProjectsDeploymentsRollbackResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export interface ProjectsDeploymentsRollbackResponseSourceConfig {
    /** Use `production_deployments_enabled` and `preview_deployment_setting` for more granular control. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsDeploymentsRollbackResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsDeploymentsRollbackResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsDeploymentsRollbackResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsDeploymentsRollbackResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsDeploymentsRollbackResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export type ProjectsDeploymentsRollbackResponseSourceType = "github" | "gitlab";
export interface ProjectsDeploymentsRollbackResponseSource {
    config: ProjectsDeploymentsRollbackResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsDeploymentsRollbackResponseSourceType;
}
export type ProjectsDeploymentsRollbackResponseStagesItemName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export type ProjectsDeploymentsRollbackResponseStagesItemStatus = "success" | "idle" | "active" | "failure" | "canceled" | "skipped";
export interface ProjectsDeploymentsRollbackResponseStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsRollbackResponseStagesItemName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsRollbackResponseStagesItemStatus;
}
export type ProjectsDeploymentsRollbackResponseStagesList = Array<ProjectsDeploymentsRollbackResponseStagesItem>;
export type ProjectsDeploymentsRollbackResponseSkipReason = "commit_message" | "preview_deployments_disabled" | "production_deployments_disabled" | "path_config" | "branch_config" | "pages_to_workers_conversion" | "superseded_queued_build";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RollbackProjectDeploymentResponse {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsDeploymentsRollbackResponseAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsDeploymentsRollbackResponseDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsDeploymentsRollbackResponseEnvironment;
    /** Whether the deployment was skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsDeploymentsRollbackResponseLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the Pages project. Must begin with a lowercase letter or digit and contain only lowercase letters, digits, and hyphens. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsDeploymentsRollbackResponseSource;
    /** List of past stages. */
    stages: ProjectsDeploymentsRollbackResponseStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Why the deployment was skipped. */
    skipReason?: ProjectsDeploymentsRollbackResponseSkipReason | null;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export interface UploadAssetRequestBodyItemMetadata {
    /** MIME type for the uploaded file. */
    contentType: string;
}
export interface UploadAssetRequestBodyItem {
    /** Whether value is base64 encoded. */
    base64: boolean;
    /** File content hash used as the object key in the Pages asset store. */
    key: string;
    metadata: UploadAssetRequestBodyItemMetadata;
    /** File content. When base64 is true, this value is base64 encoded. */
    value: string;
}
export type UploadAssetRequestBodyList = Array<UploadAssetRequestBodyItem>;
export interface UploadAssetRequest {
    body: UploadAssetRequestBodyList;
}
export interface UploadAssetResponse {
}
export type AssetsCheckMissingError = CloudflareOpError;
/** Check which of the provided file hashes are missing from the Pages asset store. Returns a list of missing hashes that need to be uploaded. Used as part of the Pages Direct Upload workflow. Authenticate with the JWT obtained from the upload-token endpoint: GET /accounts/{account_id}/pages/projects/{project_name}/upload-token */
export declare const assetsCheckMissing: API.OperationMethod<AssetsCheckMissingRequest, AssetsCheckMissingResponse, AssetsCheckMissingError, CloudflareOpContext>;
export type AssetsUpsertHashesError = CloudflareOpError;
/** Register the provided file hashes as recently uploaded to the Pages asset store. Used as part of the Pages Direct Upload workflow so future deployments can avoid re-uploading files that are already present. Authenticate with the JWT obtained from the upload-token endpoint: GET /accounts/{account_id}/pages/projects/{project_name}/upload-token */
export declare const assetsUpsertHashes: API.OperationMethod<AssetsUpsertHashesRequest, AssetsUpsertHashesResponse, AssetsUpsertHashesError, CloudflareOpContext>;
export type CreateProjectError = ProjectAlreadyExists | Forbidden | CloudflareOpError;
/** Create a Cloudflare Pages project for configuring and deploying a site or application. */
export declare const createProject: API.OperationMethod<CreateProjectRequest, CreateProjectResponse, CreateProjectError, CloudflareOpContext>;
export type CreateProjectDeploymentError = ProjectNotFound | Forbidden | CloudflareOpError;
/** Create a Cloudflare Pages deployment from a Git branch or Direct Upload manifest. Git repositories must already be authorized in Cloudflare Pages. */
export declare const createProjectDeployment: API.OperationMethod<CreateProjectDeploymentRequest, CreateProjectDeploymentResponse, CreateProjectDeploymentError, CloudflareOpContext>;
export type CreateProjectDomainError = ProjectNotFound | PagesDomainAlreadyExists | Forbidden | CloudflareOpError;
/** Attach a custom domain to a Cloudflare Pages project. */
export declare const createProjectDomain: API.OperationMethod<CreateProjectDomainRequest, CreateProjectDomainResponse, CreateProjectDomainError, CloudflareOpContext>;
export type CreateProjectsDeploymentsTailError = CloudflareOpError;
/** Start a tail that receives logs and exception data. */
export declare const createProjectsDeploymentsTail: API.OperationMethod<CreateProjectsDeploymentsTailRequest, CreateProjectsDeploymentsTailResponse, CreateProjectsDeploymentsTailError, CloudflareOpContext>;
export type DeleteProjectError = ProjectNotFound | Forbidden | CloudflareOpError;
/** Permanently delete a Cloudflare Pages project and its deployments. */
export declare const deleteProject: API.OperationMethod<DeleteProjectRequest, DeleteProjectResponse, DeleteProjectError, CloudflareOpContext>;
export type DeleteProjectDeploymentError = DeploymentNotFound | ProjectNotFound | ActiveProductionDeployment | Forbidden | CloudflareOpError;
/** Remove a deployment from a Cloudflare Pages project. */
export declare const deleteProjectDeployment: API.OperationMethod<DeleteProjectDeploymentRequest, DeleteProjectDeploymentResponse, DeleteProjectDeploymentError, CloudflareOpContext>;
export type DeleteProjectDomainError = ProjectNotFound | PagesDomainNotFound | Forbidden | CloudflareOpError;
/** Remove a custom domain from a Cloudflare Pages project. */
export declare const deleteProjectDomain: API.OperationMethod<DeleteProjectDomainRequest, DeleteProjectDomainResponse, DeleteProjectDomainError, CloudflareOpContext>;
export type DeleteProjectsDeploymentsTailError = CloudflareOpError;
/** Deletes a tail from a Pages deployment. */
export declare const deleteProjectsDeploymentsTail: API.OperationMethod<DeleteProjectsDeploymentsTailRequest, DeleteProjectsDeploymentsTailResponse, DeleteProjectsDeploymentsTailError, CloudflareOpContext>;
export type GetProjectError = ProjectNotFound | Forbidden | CloudflareOpError;
/** Retrieve the configuration and deployment settings for a Cloudflare Pages project. */
export declare const getProject: API.OperationMethod<GetProjectRequest, GetProjectResponse, GetProjectError, CloudflareOpContext>;
export type GetProjectDeploymentError = DeploymentNotFound | ProjectNotFound | Forbidden | CloudflareOpError;
/** Retrieve the status and details of a Cloudflare Pages deployment. */
export declare const getProjectDeployment: API.OperationMethod<GetProjectDeploymentRequest, GetProjectDeploymentResponse, GetProjectDeploymentError, CloudflareOpContext>;
export type GetProjectDeploymentHistoryLogError = CloudflareOpError;
/** Retrieve the build logs for a Cloudflare Pages deployment. */
export declare const getProjectDeploymentHistoryLog: API.OperationMethod<GetProjectDeploymentHistoryLogRequest, GetProjectDeploymentHistoryLogResponse, GetProjectDeploymentHistoryLogError, CloudflareOpContext>;
export type GetProjectDomainError = ProjectNotFound | PagesDomainNotFound | Forbidden | CloudflareOpError;
/** Retrieve the configuration and validation status of a custom domain attached to a Cloudflare Pages project. */
export declare const getProjectDomain: API.OperationMethod<GetProjectDomainRequest, GetProjectDomainResponse, GetProjectDomainError, CloudflareOpContext>;
export type ListProjectDeploymentsError = CloudflareOpError;
/** List the production or preview deployments for a Cloudflare Pages project. */
export declare const listProjectDeployments: API.PaginatedOperationMethod<ListProjectDeploymentsRequest, ListProjectDeploymentsResponse, ListProjectDeploymentsError, CloudflareOpContext, ProjectsDeploymentsListResultItem>;
export type ListProjectDomainsError = ProjectNotFound | Forbidden | CloudflareOpError;
/** List the custom domains associated with a Cloudflare Pages project. */
export declare const listProjectDomains: API.PaginatedOperationMethod<ListProjectDomainsRequest, ListProjectDomainsResponse, ListProjectDomainsError, CloudflareOpContext, ProjectsDomainsListResultItem>;
export type ListProjectsError = Forbidden | CloudflareOpError;
/** List the Cloudflare Pages projects in an account. */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsRequest, ListProjectsResponse, ListProjectsError, CloudflareOpContext, ProjectsListResultItem>;
export type PatchProjectError = ProjectNotFound | Forbidden | CloudflareOpError;
/** Update the build, deployment, source, or environment settings for a Cloudflare Pages project. To delete an environment variable, set its key to `null`. */
export declare const patchProject: API.OperationMethod<PatchProjectRequest, PatchProjectResponse, PatchProjectError, CloudflareOpContext>;
export type PatchProjectDomainError = ProjectNotFound | PagesDomainNotFound | Forbidden | CloudflareOpError;
/** Retry validation for a custom domain attached to a Cloudflare Pages project. */
export declare const patchProjectDomain: API.OperationMethod<PatchProjectDomainRequest, PatchProjectDomainResponse, PatchProjectDomainError, CloudflareOpContext>;
export type ProjectsGetUploadTokenError = CloudflareOpError;
/** Get a short-lived JWT for Pages Direct Upload asset operations. */
export declare const projectsGetUploadToken: API.OperationMethod<ProjectsGetUploadTokenRequest, ProjectsGetUploadTokenResponse, ProjectsGetUploadTokenError, CloudflareOpContext>;
export type PurgeBuildCacheProjectError = CloudflareOpError;
/** Remove cached build artifacts so subsequent builds run without the project's existing build cache. */
export declare const purgeBuildCacheProject: API.OperationMethod<PurgeBuildCacheProjectRequest, PurgeBuildCacheProjectResponse, PurgeBuildCacheProjectError, CloudflareOpContext>;
export type RetryProjectDeploymentError = CloudflareOpError;
/** Retry a previous Cloudflare Pages deployment. */
export declare const retryProjectDeployment: API.OperationMethod<RetryProjectDeploymentRequest, RetryProjectDeploymentResponse, RetryProjectDeploymentError, CloudflareOpContext>;
export type RollbackProjectDeploymentError = CloudflareOpError;
/** Roll back production to a previous successful Cloudflare Pages deployment. */
export declare const rollbackProjectDeployment: API.OperationMethod<RollbackProjectDeploymentRequest, RollbackProjectDeploymentResponse, RollbackProjectDeploymentError, CloudflareOpContext>;
export type UploadAssetError = CloudflareOpError;
/** Upload one or more files to the Pages asset store. Each file is identified by its content hash and is uploaded using the same JSON shape as the Cloudflare KV bulk write API. Used as part of the Pages Direct Upload workflow. Authenticate with the JWT obtained from the upload-token endpoint: GET /accounts/{account_id}/pages/projects/{project_name}/upload-token */
export declare const uploadAsset: API.OperationMethod<UploadAssetRequest, UploadAssetResponse, UploadAssetError, CloudflareOpContext>;
//# sourceMappingURL=pages.d.ts.map