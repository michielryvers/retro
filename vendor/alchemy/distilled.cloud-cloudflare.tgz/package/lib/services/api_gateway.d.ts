import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidObjectIdentifier_base: S.TaggedErrorClass<"InvalidObjectIdentifier", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidObjectIdentifier extends /*@__PURE__*/ InvalidObjectIdentifier_base {
}
declare const LabelAlreadyExists_base: S.TaggedErrorClass<"LabelAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class LabelAlreadyExists extends /*@__PURE__*/ LabelAlreadyExists_base {
}
declare const LabelNotFound_base: S.TaggedErrorClass<"LabelNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class LabelNotFound extends /*@__PURE__*/ LabelNotFound_base {
}
declare const NotEntitled_base: S.TaggedErrorClass<"NotEntitled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NotEntitled extends /*@__PURE__*/ NotEntitled_base {
}
declare const NotFound_base: S.TaggedErrorClass<"NotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
declare const OperationNotFound_base: S.TaggedErrorClass<"OperationNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class OperationNotFound extends /*@__PURE__*/ OperationNotFound_base {
}
declare const SchemaNotFound_base: S.TaggedErrorClass<"SchemaNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SchemaNotFound extends /*@__PURE__*/ SchemaNotFound_base {
}
declare const ZonePurged_base: S.TaggedErrorClass<"ZonePurged", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ZonePurged extends /*@__PURE__*/ ZonePurged_base {
}
export interface LabelsUserBulkCreateRequestBodyItem {
    /** The name of the label */
    name: string;
    /** The description of the label */
    description?: string;
    /** Metadata for the label */
    metadata?: unknown;
}
export type LabelsUserBulkCreateRequestBodyList = Array<LabelsUserBulkCreateRequestBodyItem>;
export interface BulkCreateLabelUsersRequest {
    /** Identifier. */
    zoneId: string;
    body: LabelsUserBulkCreateRequestBodyList;
}
export type LabelsUserBulkCreateResultItemSource = "user" | "managed";
export interface LabelsUserBulkCreateResultItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: LabelsUserBulkCreateResultItemSource;
}
export type LabelsUserBulkCreateResultList = Array<LabelsUserBulkCreateResultItem>;
export interface BulkCreateLabelUsersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LabelsUserBulkCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type OperationsLabelsBulkCreateRequestSelectorIncludeOperationIdsList = Array<string>;
export interface OperationsLabelsBulkCreateRequestSelectorInclude {
    operationIds: OperationsLabelsBulkCreateRequestSelectorIncludeOperationIdsList;
}
export interface OperationsLabelsBulkCreateRequestSelector {
    include: OperationsLabelsBulkCreateRequestSelectorInclude;
}
export type OperationsLabelsBulkCreateRequestManagedLabelsList = Array<string>;
export interface OperationsLabelsBulkCreateRequestManaged {
    /** List of managed label names. */
    labels?: OperationsLabelsBulkCreateRequestManagedLabelsList;
}
export type OperationsLabelsBulkCreateRequestUserLabelsList = Array<string>;
export interface OperationsLabelsBulkCreateRequestUser {
    /** List of user label names. */
    labels?: OperationsLabelsBulkCreateRequestUserLabelsList;
}
export interface BulkCreateOperationLabelsRequest {
    /** Identifier. */
    zoneId: string;
    /** Operation IDs selector */
    selector: OperationsLabelsBulkCreateRequestSelector;
    managed?: OperationsLabelsBulkCreateRequestManaged;
    user?: OperationsLabelsBulkCreateRequestUser;
}
export type OperationsLabelsBulkCreateResultItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export type OperationsLabelsBulkCreateResultItemLabelsItemSource = "user" | "managed";
export interface OperationsLabelsBulkCreateResultItemLabelsItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: OperationsLabelsBulkCreateResultItemLabelsItemSource;
}
export type OperationsLabelsBulkCreateResultItemLabelsList = Array<OperationsLabelsBulkCreateResultItemLabelsItem>;
export interface OperationsLabelsBulkCreateResultItem {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsLabelsBulkCreateResultItemMethod;
    /** UUID. */
    operationId: string;
    labels?: OperationsLabelsBulkCreateResultItemLabelsList | null;
}
export type OperationsLabelsBulkCreateResultList = Array<OperationsLabelsBulkCreateResultItem>;
export interface BulkCreateOperationLabelsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OperationsLabelsBulkCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type OperationsBulkCreateRequestBodyItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export interface OperationsBulkCreateRequestBodyItem {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsBulkCreateRequestBodyItemMethod | (string & {});
}
export type OperationsBulkCreateRequestBodyList = Array<OperationsBulkCreateRequestBodyItem>;
export interface BulkCreateOperationsRequest {
    /** Identifier. */
    zoneId: string;
    body: OperationsBulkCreateRequestBodyList;
}
export type OperationsBulkCreateResultItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds {
    /** The total number of auth-ids seen across this calculation. */
    authIdTokens?: number | null;
    /** The number of data points used for the threshold suggestion calculation. */
    dataPoints?: number | null;
    lastUpdated?: string | null;
    /** The p50 quantile of requests (in period_seconds). */
    p50?: number | null;
    /** The p90 quantile of requests (in period_seconds). */
    p90?: number | null;
    /** The p99 quantile of requests (in period_seconds). */
    p99?: number | null;
    /** The period over which this threshold is suggested. */
    periodSeconds?: number | null;
    /** The estimated number of requests covered by these calculations. */
    requests?: number | null;
    /** The suggested threshold in requests done by the same auth_id or period_seconds. */
    suggestedThreshold?: number | null;
}
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds {
    thresholds?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds | null;
}
export type OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList = Array<unknown>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas {
    /** An array containing the learned parameter schemas. */
    parameters?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList | null;
    /** An empty response object. This field is required to yield a valid operation schema. */
    responses?: unknown | null;
}
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas {
    lastUpdated?: string | null;
    /** An operation schema object containing a response. */
    parameterSchemas?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas | null;
}
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemas {
    parameterSchemas: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas;
}
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting {
    lastUpdated?: string | null;
    /** Target route. */
    route?: string | null;
}
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting {
    /** API Routing settings on endpoint. */
    apiRouting?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting | null;
}
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 {
    /** Lower bound for percentile estimate */
    lower?: number | null;
    /** Upper bound for percentile estimate */
    upper?: number | null;
}
export type OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals {
    /** Upper and lower bound for percentile estimate */
    p90?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 | null;
    /** Upper and lower bound for percentile estimate */
    p95?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 | null;
    /** Upper and lower bound for percentile estimate */
    p99?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 | null;
}
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold {
    confidenceIntervals?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals | null;
    /** Suggested threshold. */
    mean?: number | null;
}
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals {
    lastUpdated?: string | null;
    suggestedThreshold?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold | null;
}
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals {
    confidenceIntervals?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals | null;
}
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema {
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    /** Schema file name. */
    name?: string | null;
}
export type OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction = "none" | "log" | "block";
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo {
    /** Schema active on endpoint. */
    activeSchema?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema | null;
    /** Action taken on requests failing validation. */
    mitigationAction?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction | null;
}
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfo {
    schemaInfo?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo | null;
}
export type OperationsBulkCreateResultItemFeatures = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemas | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfo;
export interface OperationsBulkCreateResultItem {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsBulkCreateResultItemMethod;
    /** UUID. */
    operationId: string;
    features?: OperationsBulkCreateResultItemFeatures | null;
}
export type OperationsBulkCreateResultList = Array<OperationsBulkCreateResultItem>;
export interface BulkCreateOperationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OperationsBulkCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface BulkDeleteLabelUsersRequest {
    /** Identifier. */
    zoneId: string;
}
export type LabelsUserBulkDeleteResultItemSource = "user" | "managed";
export interface LabelsUserBulkDeleteResultItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: LabelsUserBulkDeleteResultItemSource;
}
export type LabelsUserBulkDeleteResultList = Array<LabelsUserBulkDeleteResultItem>;
export interface BulkDeleteLabelUsersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LabelsUserBulkDeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface BulkDeleteOperationLabelsRequest {
    /** Identifier. */
    zoneId: string;
}
export type OperationsLabelsBulkDeleteResultItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export type OperationsLabelsBulkDeleteResultItemLabelsItemSource = "user" | "managed";
export interface OperationsLabelsBulkDeleteResultItemLabelsItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: OperationsLabelsBulkDeleteResultItemLabelsItemSource;
}
export type OperationsLabelsBulkDeleteResultItemLabelsList = Array<OperationsLabelsBulkDeleteResultItemLabelsItem>;
export interface OperationsLabelsBulkDeleteResultItem {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsLabelsBulkDeleteResultItemMethod;
    /** UUID. */
    operationId: string;
    labels?: OperationsLabelsBulkDeleteResultItemLabelsList | null;
}
export type OperationsLabelsBulkDeleteResultList = Array<OperationsLabelsBulkDeleteResultItem>;
export interface BulkDeleteOperationLabelsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OperationsLabelsBulkDeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface BulkDeleteOperationsRequest {
    /** Identifier. */
    zoneId: string;
}
export interface BulkDeleteOperationsResponse {
}
export type DiscoveryOperationsBulkEditRequestBodyValueState = "review" | "ignored";
export interface DiscoveryOperationsBulkEditRequestBodyValue {
    /** Mark state of operation in API Discovery */
    state?: DiscoveryOperationsBulkEditRequestBodyValueState | (string & {});
}
export type DiscoveryOperationsBulkEditRequestBodyMap = {
    [key: string]: DiscoveryOperationsBulkEditRequestBodyValue | undefined;
};
export interface BulkPatchDiscoveryOperationsRequest {
    /** Identifier. */
    zoneId: string;
    body: DiscoveryOperationsBulkEditRequestBodyMap;
}
export type DiscoveryOperationsBulkEditResultValueState = "review" | "ignored";
export interface DiscoveryOperationsBulkEditResultValue {
    /** Mark state of operation in API Discovery */
    state?: DiscoveryOperationsBulkEditResultValueState | null;
}
export type DiscoveryOperationsBulkEditResultMap = {
    [key: string]: DiscoveryOperationsBulkEditResultValue | undefined;
};
export type BulkPatchDiscoveryOperationsResponse = DiscoveryOperationsBulkEditResultMap;
export type OperationsLabelsBulkUpdateRequestManagedLabelsList = Array<string>;
export interface OperationsLabelsBulkUpdateRequestManaged {
    /** List of managed label names. Providing an empty array will result in all managed labels being removed from all affected operations */
    labels: OperationsLabelsBulkUpdateRequestManagedLabelsList;
}
export type OperationsLabelsBulkUpdateRequestSelectorIncludeOperationIdsList = Array<string>;
export interface OperationsLabelsBulkUpdateRequestSelectorInclude {
    operationIds: OperationsLabelsBulkUpdateRequestSelectorIncludeOperationIdsList;
}
export interface OperationsLabelsBulkUpdateRequestSelector {
    include: OperationsLabelsBulkUpdateRequestSelectorInclude;
}
export type OperationsLabelsBulkUpdateRequestUserLabelsList = Array<string>;
export interface OperationsLabelsBulkUpdateRequestUser {
    /** List of user label names. Providing an empty array will result in all user labels being removed from all affected operations */
    labels: OperationsLabelsBulkUpdateRequestUserLabelsList;
}
export interface BulkUpdateOperationLabelsRequest {
    /** Identifier. */
    zoneId: string;
    /** Managed labels to replace for all affected operations */
    managed: OperationsLabelsBulkUpdateRequestManaged;
    /** Operation IDs selector */
    selector: OperationsLabelsBulkUpdateRequestSelector;
    /** User labels to replace for all affected operations */
    user: OperationsLabelsBulkUpdateRequestUser;
}
export type OperationsLabelsBulkUpdateResultItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export type OperationsLabelsBulkUpdateResultItemLabelsItemSource = "user" | "managed";
export interface OperationsLabelsBulkUpdateResultItemLabelsItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: OperationsLabelsBulkUpdateResultItemLabelsItemSource;
}
export type OperationsLabelsBulkUpdateResultItemLabelsList = Array<OperationsLabelsBulkUpdateResultItemLabelsItem>;
export interface OperationsLabelsBulkUpdateResultItem {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsLabelsBulkUpdateResultItemMethod;
    /** UUID. */
    operationId: string;
    labels?: OperationsLabelsBulkUpdateResultItemLabelsList | null;
}
export type OperationsLabelsBulkUpdateResultList = Array<OperationsLabelsBulkUpdateResultItem>;
export interface BulkUpdateOperationLabelsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OperationsLabelsBulkUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ExpressionTemplateFallthroughCreateRequestHostsList = Array<string>;
export interface CreateExpressionTemplateFallthroughRequest {
    /** Identifier. */
    zoneId: string;
    /** List of hosts to be targeted in the expression */
    hosts: ExpressionTemplateFallthroughCreateRequestHostsList;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateExpressionTemplateFallthroughResponse {
    /** WAF Expression for fallthrough */
    expression: string;
    /** Title for the expression */
    title: string;
}
export type OperationsCreateRequestMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export interface CreateOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsCreateRequestMethod | (string & {});
}
export type OperationsCreateResponseMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureThresholdsThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList = Array<unknown>;
export interface OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas {
    /** An array containing the learned parameter schemas. */
    parameters?: OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList | null;
    /** An empty response object. This field is required to yield a valid operation schema. */
    responses?: unknown | null;
}
export interface OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas {
    lastUpdated?: string | null;
    /** An operation schema object containing a response. */
    parameterSchemas?: OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas | null;
}
export interface OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemas {
    parameterSchemas: OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas;
}
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureAPIRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction = "none" | "log" | "block";
export interface OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo {
    /** Schema active on endpoint. */
    activeSchema?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema | null;
    /** Action taken on requests failing validation. */
    mitigationAction?: OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction | null;
}
export interface OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfo {
    schemaInfo?: OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo | null;
}
export type OperationsCreateResponseFeatures = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds | OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemas | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals | OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfo;
export type OperationsCreateResponseSchemasLearnedParametersItemMap = {
    [key: string]: unknown | undefined;
};
export type OperationsCreateResponseSchemasLearnedParametersList = Array<OperationsCreateResponseSchemasLearnedParametersItemMap>;
export type OperationsCreateResponseSchemasLearnedRequestBodyMap = {
    [key: string]: unknown | undefined;
};
export interface OperationsCreateResponseSchemasLearned {
    /** OpenAPI parameter objects describing path, query, header, or cookie parameters. */
    parameters?: OperationsCreateResponseSchemasLearnedParametersList | null;
    /** OpenAPI request body object describing the expected request payload. */
    requestBody?: OperationsCreateResponseSchemasLearnedRequestBodyMap | null;
}
export type OperationsCreateResponseSchemasUploadedParametersItemMap = {
    [key: string]: unknown | undefined;
};
export type OperationsCreateResponseSchemasUploadedParametersList = Array<OperationsCreateResponseSchemasUploadedParametersItemMap>;
export type OperationsCreateResponseSchemasUploadedRequestBodyMap = {
    [key: string]: unknown | undefined;
};
export interface OperationsCreateResponseSchemasUploaded {
    /** OpenAPI parameter objects describing path, query, header, or cookie parameters. */
    parameters?: OperationsCreateResponseSchemasUploadedParametersList | null;
    /** OpenAPI request body object describing the expected request payload. */
    requestBody?: OperationsCreateResponseSchemasUploadedRequestBodyMap | null;
}
export interface OperationsCreateResponseSchemas {
    /** An OpenAPI operation object fragment containing schema information for an operation. May include parameter definitions, request body specifications, and a component schema extension. */
    learned?: OperationsCreateResponseSchemasLearned | null;
    /** An OpenAPI operation object fragment containing schema information for an operation. May include parameter definitions, request body specifications, and a component schema extension. */
    uploaded?: OperationsCreateResponseSchemasUploaded | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOperationResponse {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsCreateResponseMethod;
    /** UUID. */
    operationId: string;
    features?: OperationsCreateResponseFeatures | null;
    /** OpenAPI JSON schemas for an operation, including both user-uploaded and Cloudflare-learned schemas. */
    schemas?: OperationsCreateResponseSchemas | null;
}
export type OperationsLabelsCreateRequestManagedList = Array<string>;
export type OperationsLabelsCreateRequestUserList = Array<string>;
export interface CreateOperationLabelRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
    /** List of managed label names. */
    managed?: OperationsLabelsCreateRequestManagedList;
    /** List of user label names. */
    user?: OperationsLabelsCreateRequestUserList;
}
export type OperationsLabelsCreateResponseMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export type OperationsLabelsCreateResponseLabelsItemSource = "user" | "managed";
export interface OperationsLabelsCreateResponseLabelsItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: OperationsLabelsCreateResponseLabelsItemSource;
}
export type OperationsLabelsCreateResponseLabelsList = Array<OperationsLabelsCreateResponseLabelsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOperationLabelResponse {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsLabelsCreateResponseMethod;
    /** UUID. */
    operationId: string;
    labels?: OperationsLabelsCreateResponseLabelsList | null;
}
export interface CreateUserSchemaRequest {
    /** Identifier. */
    zoneId: string;
    /** Schema file bytes (File/Blob), sent as the multipart `file` part. */
    file: unknown;
    /** Kind of schema (openapi_v3). */
    kind: string;
    /** Name of the schema. */
    name?: string;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean;
}
export type UserSchemasCreateResponseSchemaKind = "openapi_v3";
export interface UserSchemasCreateResponseSchema {
    createdAt: string;
    /** Kind of schema */
    kind: UserSchemasCreateResponseSchemaKind;
    /** Name of the schema */
    name: string;
    /** UUID. */
    schemaId: string;
    /** Source of the schema */
    source?: string | null;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean | null;
}
export type UserSchemasCreateResponseUploadDetailsWarningsItemLocationsList = Array<string>;
export interface UserSchemasCreateResponseUploadDetailsWarningsItem {
    /** Code that identifies the event that occurred. */
    code: number;
    /** JSONPath location(s) in the schema where these events were encountered. See https://goessner.net/articles/JsonPath/ for JSONPath specification. */
    locations?: UserSchemasCreateResponseUploadDetailsWarningsItemLocationsList | null;
    /** Diagnostic message that describes the event. */
    message?: string | null;
}
export type UserSchemasCreateResponseUploadDetailsWarningsList = Array<UserSchemasCreateResponseUploadDetailsWarningsItem>;
export interface UserSchemasCreateResponseUploadDetails {
    /** Diagnostic warning events that occurred during processing. These events are non-critical errors found within the schema. */
    warnings?: UserSchemasCreateResponseUploadDetailsWarningsList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateUserSchemaResponse {
    schema: UserSchemasCreateResponseSchema;
    uploadDetails?: UserSchemasCreateResponseUploadDetails | null;
}
export interface DeleteLabelUserRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
}
export type LabelsUserDeleteResponseSource = "user" | "managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteLabelUserResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: LabelsUserDeleteResponseSource;
}
export interface DeleteOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
}
export interface DeleteOperationResponse {
}
export interface DeleteOperationLabelRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
}
export type OperationsLabelsDeleteResponseMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export type OperationsLabelsDeleteResponseLabelsItemSource = "user" | "managed";
export interface OperationsLabelsDeleteResponseLabelsItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: OperationsLabelsDeleteResponseLabelsItemSource;
}
export type OperationsLabelsDeleteResponseLabelsList = Array<OperationsLabelsDeleteResponseLabelsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOperationLabelResponse {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsLabelsDeleteResponseMethod;
    /** UUID. */
    operationId: string;
    labels?: OperationsLabelsDeleteResponseLabelsList | null;
}
export interface DeleteUserSchemaRequest {
    /** Identifier. */
    zoneId: string;
    schemaId: string;
}
export interface DeleteUserSchemaResponse {
}
export type EditDiscoveryOperationRequestState = "review" | "ignored";
export interface EditDiscoveryOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    discoveryId: string;
    /** Mark state of operation in API Discovery */
    state?: EditDiscoveryOperationRequestState | (string & {});
}
export type EditDiscoveryOperationResponseState = "review" | "saved" | "ignored";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditDiscoveryOperationResponse {
    /** State of operation in API Discovery */
    state?: EditDiscoveryOperationResponseState | null;
}
export interface GetConfigurationRequest {
    /** Identifier. */
    zoneId: string;
    /** Ensures that the configuration is written or retrieved in normalized fashion */
    normalize?: boolean;
}
export type ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType = "header" | "cookie";
export interface ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic {
    /** The name of the characteristic field, i.e., the header or cookie name. */
    name: string;
    /** The type of characteristic. */
    type: ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType;
}
export type ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType = "jwt";
export interface ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim {
    /** Claim location expressed as `$(token_config_id):$(json_path)`, where `token_config_id` is the ID of the token configuration used in validating the JWT, and `json_path` is a RFC 9535 JSONPath (https://goessner.net/articles/JsonPath/, https://www.rfc-editor.org/rfc/rfc9535.html). The JSONPath expression may be in dot or bracket notation, may only specify literal keys or array indexes, and must return a singleton value, which will be interpreted as a string. */
    name: string;
    /** The type of characteristic. */
    type: ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType;
}
export type ConfigurationsGetResponseAuthIdCharacteristicsItem = ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic | ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim;
export type ConfigurationsGetResponseAuthIdCharacteristicsList = Array<ConfigurationsGetResponseAuthIdCharacteristicsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigurationResponse {
    authIdCharacteristics: ConfigurationsGetResponseAuthIdCharacteristicsList;
}
export interface GetDiscoveryRequest {
    /** Identifier. */
    zoneId: string;
}
export type DiscoveryGetResponseSchemasList = Array<unknown>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDiscoveryResponse {
    schemas: DiscoveryGetResponseSchemasList;
    timestamp: string;
}
export interface GetLabelManagedRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
    /** Include `mapped_resources` for each label */
    withMappedResourceCounts?: boolean;
}
export type LabelsManagedGetResponseSource = "user" | "managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLabelManagedResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: LabelsManagedGetResponseSource;
    /** Provides counts of what resources are linked to this label */
    mappedResources?: unknown | null;
}
export interface GetLabelUserRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
    /** Include `mapped_resources` for each label */
    withMappedResourceCounts?: boolean;
}
export type LabelsUserGetResponseSource = "user" | "managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLabelUserResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: LabelsUserGetResponseSource;
    /** Provides counts of what resources are linked to this label */
    mappedResources?: unknown | null;
}
export type OperationsGetRequestFeature = "thresholds" | "parameter_schemas" | "schema_info" | "confidence_intervals";
export type OperationsGetRequestFeatureList = Array<OperationsGetRequestFeature | (string & {})>;
export interface GetOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
    /** Add feature(s) to the results. The feature name that is given here corresponds to the resulting feature object. Have a look at the top-level object description for more details on the specific meaning. */
    feature?: OperationsGetRequestFeatureList;
    /** When true, includes OpenAPI schemas (both uploaded and learned) for the operation in the response. Due to the conversion overhead, this parameter is only supported on single-operation retrieval. */
    withSchemas?: boolean;
}
export type OperationsGetResponseMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureThresholdsThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList = Array<unknown>;
export interface OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas {
    /** An array containing the learned parameter schemas. */
    parameters?: OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList | null;
    /** An empty response object. This field is required to yield a valid operation schema. */
    responses?: unknown | null;
}
export interface OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas {
    lastUpdated?: string | null;
    /** An operation schema object containing a response. */
    parameterSchemas?: OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas | null;
}
export interface OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemas {
    parameterSchemas: OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas;
}
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureAPIRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction = "none" | "log" | "block";
export interface OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo {
    /** Schema active on endpoint. */
    activeSchema?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema | null;
    /** Action taken on requests failing validation. */
    mitigationAction?: OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction | null;
}
export interface OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfo {
    schemaInfo?: OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo | null;
}
export type OperationsGetResponseFeatures = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds | OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemas | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals | OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfo;
export type OperationsGetResponseSchemasLearnedParametersItemMap = {
    [key: string]: unknown | undefined;
};
export type OperationsGetResponseSchemasLearnedParametersList = Array<OperationsGetResponseSchemasLearnedParametersItemMap>;
export type OperationsGetResponseSchemasLearnedRequestBodyMap = {
    [key: string]: unknown | undefined;
};
export interface OperationsGetResponseSchemasLearned {
    /** OpenAPI parameter objects describing path, query, header, or cookie parameters. */
    parameters?: OperationsGetResponseSchemasLearnedParametersList | null;
    /** OpenAPI request body object describing the expected request payload. */
    requestBody?: OperationsGetResponseSchemasLearnedRequestBodyMap | null;
}
export type OperationsGetResponseSchemasUploadedParametersItemMap = {
    [key: string]: unknown | undefined;
};
export type OperationsGetResponseSchemasUploadedParametersList = Array<OperationsGetResponseSchemasUploadedParametersItemMap>;
export type OperationsGetResponseSchemasUploadedRequestBodyMap = {
    [key: string]: unknown | undefined;
};
export interface OperationsGetResponseSchemasUploaded {
    /** OpenAPI parameter objects describing path, query, header, or cookie parameters. */
    parameters?: OperationsGetResponseSchemasUploadedParametersList | null;
    /** OpenAPI request body object describing the expected request payload. */
    requestBody?: OperationsGetResponseSchemasUploadedRequestBodyMap | null;
}
export interface OperationsGetResponseSchemas {
    /** An OpenAPI operation object fragment containing schema information for an operation. May include parameter definitions, request body specifications, and a component schema extension. */
    learned?: OperationsGetResponseSchemasLearned | null;
    /** An OpenAPI operation object fragment containing schema information for an operation. May include parameter definitions, request body specifications, and a component schema extension. */
    uploaded?: OperationsGetResponseSchemasUploaded | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOperationResponse {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsGetResponseMethod;
    /** UUID. */
    operationId: string;
    features?: OperationsGetResponseFeatures | null;
    /** OpenAPI JSON schemas for an operation, including both user-uploaded and Cloudflare-learned schemas. */
    schemas?: OperationsGetResponseSchemas | null;
}
export interface GetOperationSchemaValidationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
}
export type OperationsSchemaValidationGetResponseMitigationAction = "log" | "block" | "none";
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetOperationSchemaValidationResponse {
    /** When set, this applies a mitigation action to this operation */
    mitigationAction?: OperationsSchemaValidationGetResponseMitigationAction | null;
    /** UUID. */
    operationId?: string | null;
}
export interface GetSettingSchemaValidationRequest {
    /** Identifier. */
    zoneId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSettingSchemaValidationResponse {
}
export interface GetUserSchemaRequest {
    /** Identifier. */
    zoneId: string;
    schemaId: string;
    /** Omit the source-files of schemas and only retrieve their meta-data. */
    omitSource?: boolean;
}
export type UserSchemasGetResponseKind = "openapi_v3";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUserSchemaResponse {
    createdAt: string;
    /** Kind of schema */
    kind: UserSchemasGetResponseKind;
    /** Name of the schema */
    name: string;
    /** UUID. */
    schemaId: string;
    /** Source of the schema */
    source?: string | null;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean | null;
}
export type DiscoveryOperationsListRequestDirection = "asc" | "desc";
export type DiscoveryOperationsListRequestHostList = Array<string>;
export type DiscoveryOperationsListRequestMethodList = Array<string>;
export type DiscoveryOperationsListRequestOrder = "host" | "method" | "endpoint" | "traffic_stats.requests" | "traffic_stats.last_updated";
export type DiscoveryOperationsListRequestOrigin = "ML" | "SessionIdentifier" | "LabelDiscovery";
export type DiscoveryOperationsListRequestState = "review" | "saved" | "ignored";
export interface ListDiscoveryOperationsRequest {
    /** Identifier. */
    zoneId: string;
    /** When `true`, only return API Discovery results that are not saved into API Shield Endpoint Management */
    diff?: boolean;
    /** Direction to order results. */
    direction?: DiscoveryOperationsListRequestDirection | (string & {});
    /** Filter results to only include endpoints containing this pattern. */
    endpoint?: string;
    /** Filter results to only include the specified hosts. */
    host?: DiscoveryOperationsListRequestHostList;
    /** Filter results to only include the specified HTTP methods. */
    method?: DiscoveryOperationsListRequestMethodList;
    /** Field to order by */
    order?: DiscoveryOperationsListRequestOrder | (string & {});
    /** Filter results to only include discovery results sourced from a particular discovery engine */
    origin?: DiscoveryOperationsListRequestOrigin | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** Filter results to only include discovery results in a particular state. States are as follows */
    state?: DiscoveryOperationsListRequestState | (string & {});
}
export type DiscoveryOperationsListResultItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export type DiscoveryOperationsListResultItemOriginItem = "ML" | "SessionIdentifier" | "LabelDiscovery";
export type DiscoveryOperationsListResultItemOriginList = Array<DiscoveryOperationsListResultItemOriginItem>;
export type DiscoveryOperationsListResultItemState = "review" | "saved" | "ignored";
export interface DiscoveryOperationsListResultItemFeaturesTrafficStats {
    lastUpdated: string;
    /** The period in seconds these statistics were computed over */
    periodSeconds: number;
    /** The average number of requests seen during this period */
    requests: number;
}
export interface DiscoveryOperationsListResultItemFeatures {
    trafficStats?: DiscoveryOperationsListResultItemFeaturesTrafficStats | null;
}
export interface DiscoveryOperationsListResultItem {
    /** UUID. */
    id: string;
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: DiscoveryOperationsListResultItemMethod;
    /** API discovery engine(s) that discovered this operation */
    origin: DiscoveryOperationsListResultItemOriginList;
    /** State of operation in API Discovery */
    state: DiscoveryOperationsListResultItemState;
    features?: DiscoveryOperationsListResultItemFeatures | null;
}
export type DiscoveryOperationsListResultList = Array<DiscoveryOperationsListResultItem>;
export interface ListDiscoveryOperationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DiscoveryOperationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type LabelsListRequestDirection = "asc" | "desc";
export type LabelsListRequestOrder = "name" | "description" | "created_at" | "last_updated" | "mapped_resources.operations";
export type LabelsListRequestSource = "user" | "managed";
export interface ListLabelsRequest {
    /** Identifier. */
    zoneId: string;
    /** Direction to order results. */
    direction?: LabelsListRequestDirection | (string & {});
    /** Filter for labels where the name or description matches using substring match */
    filter?: string;
    /** Field to order by */
    order?: LabelsListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** Filter for labels with source */
    source?: LabelsListRequestSource | (string & {});
    /** Include `mapped_resources` for each label */
    withMappedResourceCounts?: boolean;
}
export type LabelsListResultItemSource = "user" | "managed";
export interface LabelsListResultItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: LabelsListResultItemSource;
    /** Provides counts of what resources are linked to this label */
    mappedResources?: unknown | null;
}
export type LabelsListResultList = Array<LabelsListResultItem>;
export interface ListLabelsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LabelsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type OperationsListRequestDirection = "asc" | "desc";
export type OperationsListRequestFeature = "thresholds" | "parameter_schemas" | "schema_info" | "confidence_intervals";
export type OperationsListRequestFeatureList = Array<OperationsListRequestFeature | (string & {})>;
export type OperationsListRequestHostList = Array<string>;
export type OperationsListRequestMethodList = Array<string>;
export type OperationsListRequestOrder = "method" | "host" | "endpoint" | "thresholds.$key";
export interface ListOperationsRequest {
    /** Identifier. */
    zoneId: string;
    /** Direction to order results. */
    direction?: OperationsListRequestDirection | (string & {});
    /** Filter results to only include endpoints containing this pattern. */
    endpoint?: string;
    /** Add feature(s) to the results. The feature name that is given here corresponds to the resulting feature object. Have a look at the top-level object description for more details on the specific meaning. */
    feature?: OperationsListRequestFeatureList;
    /** Filter results to only include the specified hosts. */
    host?: OperationsListRequestHostList;
    /** Filter results to only include the specified HTTP methods. */
    method?: OperationsListRequestMethodList;
    /** Field to order by. When requesting a feature, the feature keys are available for ordering as well, e.g., `thresholds.suggested_threshold`. */
    order?: OperationsListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type OperationsListResultItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList = Array<unknown>;
export interface OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas {
    /** An array containing the learned parameter schemas. */
    parameters?: OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList | null;
    /** An empty response object. This field is required to yield a valid operation schema. */
    responses?: unknown | null;
}
export interface OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas {
    lastUpdated?: string | null;
    /** An operation schema object containing a response. */
    parameterSchemas?: OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas | null;
}
export interface OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemas {
    parameterSchemas: OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas;
}
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureAPIRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction = "none" | "log" | "block";
export interface OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo {
    /** Schema active on endpoint. */
    activeSchema?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema | null;
    /** Action taken on requests failing validation. */
    mitigationAction?: OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction | null;
}
export interface OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfo {
    schemaInfo?: OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo | null;
}
export type OperationsListResultItemFeatures = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds | OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemas | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals | OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfo;
export interface OperationsListResultItem {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsListResultItemMethod;
    /** UUID. */
    operationId: string;
    features?: OperationsListResultItemFeatures | null;
}
export type OperationsListResultList = Array<OperationsListResultItem>;
export interface ListOperationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OperationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type SchemasListRequestFeature = "thresholds" | "parameter_schemas" | "schema_info" | "confidence_intervals";
export type SchemasListRequestFeatureList = Array<SchemasListRequestFeature | (string & {})>;
export type SchemasListRequestHostList = Array<string>;
export type SchemasListRequestIncludeSchemaKind = "learned";
export type SchemasListRequestIncludeSchemaKindList = Array<SchemasListRequestIncludeSchemaKind | (string & {})>;
export interface ListSchemasRequest {
    /** Identifier. */
    zoneId: string;
    /** Add feature(s) to the results. The feature name that is given here corresponds to the resulting feature object. Have a look at the top-level object description for more details on the specific meaning. */
    feature?: SchemasListRequestFeatureList;
    /** Receive schema only for the given host(s). */
    host?: SchemasListRequestHostList;
    /** Schema kinds to include in exported OpenAPI schemas. */
    includeSchemaKind?: SchemasListRequestIncludeSchemaKindList;
}
export type SchemasListResponseSchemasList = Array<unknown>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListSchemasResponse {
    schemas?: SchemasListResponseSchemasList | null;
    timestamp?: string | null;
}
export interface ListUserSchemaHostsRequest {
    /** Identifier. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type UserSchemasHostsListResultItemHostsList = Array<string>;
export interface UserSchemasHostsListResultItem {
    createdAt: string;
    /** Hosts serving the schema, e.g zone.host.com */
    hosts: UserSchemasHostsListResultItemHostsList;
    /** Name of the schema */
    name: string;
    /** UUID. */
    schemaId: string;
}
export type UserSchemasHostsListResultList = Array<UserSchemasHostsListResultItem>;
export interface ListUserSchemaHostsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserSchemasHostsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type UserSchemasOperationsListRequestFeature = "thresholds" | "parameter_schemas" | "schema_info" | "confidence_intervals";
export type UserSchemasOperationsListRequestFeatureList = Array<UserSchemasOperationsListRequestFeature | (string & {})>;
export type UserSchemasOperationsListRequestHostList = Array<string>;
export type UserSchemasOperationsListRequestMethodList = Array<string>;
export type UserSchemasOperationsListRequestOperationStatus = "new" | "existing";
export interface ListUserSchemaOperationsRequest {
    /** Identifier. */
    zoneId: string;
    schemaId: string;
    /** Filter results to only include endpoints containing this pattern. */
    endpoint?: string;
    /** Add feature(s) to the results. The feature name that is given here corresponds to the resulting feature object. Have a look at the top-level object description for more details on the specific meaning. */
    feature?: UserSchemasOperationsListRequestFeatureList;
    /** Filter results to only include the specified hosts. */
    host?: UserSchemasOperationsListRequestHostList;
    /** Filter results to only include the specified HTTP methods. */
    method?: UserSchemasOperationsListRequestMethodList;
    /** Filter results by whether operations exist in API Shield Endpoint Management or not. `new` will just return operations from the schema that do not exist in API Shield Endpoint Management. `existing` will just return operations from the schema that already exist in API Shield Endpoint Management. */
    operationStatus?: UserSchemasOperationsListRequestOperationStatus | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type UserSchemasOperationsListResultItemAPIShieldOperationMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureThresholdsThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList = Array<unknown>;
export interface UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas {
    /** An array containing the learned parameter schemas. */
    parameters?: UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList | null;
    /** An empty response object. This field is required to yield a valid operation schema. */
    responses?: unknown | null;
}
export interface UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas {
    lastUpdated?: string | null;
    /** An operation schema object containing a response. */
    parameterSchemas?: UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas | null;
}
export interface UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemas {
    parameterSchemas: UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas;
}
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureAPIRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction = "none" | "log" | "block";
export interface UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo {
    /** Schema active on endpoint. */
    activeSchema?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema | null;
    /** Action taken on requests failing validation. */
    mitigationAction?: UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction | null;
}
export interface UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfo {
    schemaInfo?: UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo | null;
}
export type UserSchemasOperationsListResultItemAPIShieldOperationFeatures = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds | UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemas | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals | UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfo;
export interface UserSchemasOperationsListResultItemAPIShieldOperation {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: UserSchemasOperationsListResultItemAPIShieldOperationMethod;
    /** UUID. */
    operationId: string;
    features?: UserSchemasOperationsListResultItemAPIShieldOperationFeatures | null;
}
export type UserSchemasOperationsListResultItemAPIShieldBasicOperationMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export interface UserSchemasOperationsListResultItemAPIShieldBasicOperation {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    /** The HTTP method used to access the endpoint. */
    method: UserSchemasOperationsListResultItemAPIShieldBasicOperationMethod;
}
export type UserSchemasOperationsListResultItem = UserSchemasOperationsListResultItemAPIShieldOperation | UserSchemasOperationsListResultItemAPIShieldBasicOperation;
export type UserSchemasOperationsListResultList = Array<UserSchemasOperationsListResultItem>;
export interface ListUserSchemaOperationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserSchemasOperationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListUserSchemasRequest {
    /** Identifier. */
    zoneId: string;
    /** Omit the source-files of schemas and only retrieve their meta-data. */
    omitSource?: boolean;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean;
}
export type UserSchemasListResultItemKind = "openapi_v3";
export interface UserSchemasListResultItem {
    createdAt: string;
    /** Kind of schema */
    kind: UserSchemasListResultItemKind;
    /** Name of the schema */
    name: string;
    /** UUID. */
    schemaId: string;
    /** Source of the schema */
    source?: string | null;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean | null;
}
export type UserSchemasListResultList = Array<UserSchemasListResultItem>;
export interface ListUserSchemasResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserSchemasListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface PatchLabelUserRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
    /** The description of the label */
    description?: string;
    /** Metadata for the label */
    metadata?: unknown;
}
export type LabelsUserEditResponseSource = "user" | "managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchLabelUserResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: LabelsUserEditResponseSource;
}
export type OperationsSchemaValidationEditRequestSettingsMultipleRequestMitigationAction = "log" | "block" | "none";
export interface OperationsSchemaValidationEditRequestSettingsMultipleRequest {
    /** When set, this applies a mitigation action to this operation */
    mitigationAction?: OperationsSchemaValidationEditRequestSettingsMultipleRequestMitigationAction | (string & {});
}
export interface PatchOperationSchemaValidationRequest {
    /** Identifier. */
    zoneId: string;
    settingsMultipleRequest: OperationsSchemaValidationEditRequestSettingsMultipleRequest;
}
export type OperationsSchemaValidationEditResponseMitigationAction = "log" | "block" | "none";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchOperationSchemaValidationResponse {
    /** When set, this applies a mitigation action to this operation */
    mitigationAction?: OperationsSchemaValidationEditResponseMitigationAction | null;
}
export type SettingsSchemaValidationEditRequestValidationDefaultMitigationAction = "none" | "log" | "block";
export type SettingsSchemaValidationEditRequestValidationOverrideMitigationAction = "none" | "disable_override";
export interface PatchSettingSchemaValidationRequest {
    /** Identifier. */
    zoneId: string;
    /** The default mitigation action used when there is no mitigation action defined on the operation Mitigation actions are as follows: */
    validationDefaultMitigationAction?: SettingsSchemaValidationEditRequestValidationDefaultMitigationAction | (string & {});
    /** When set, this overrides both zone level and operation level mitigation actions. */
    validationOverrideMitigationAction?: SettingsSchemaValidationEditRequestValidationOverrideMitigationAction | (string & {});
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchSettingSchemaValidationResponse {
}
export interface PatchUserSchemaRequest {
    /** Identifier. */
    zoneId: string;
    schemaId: string;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean;
}
export type UserSchemasEditResponseKind = "openapi_v3";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchUserSchemaResponse {
    createdAt: string;
    /** Kind of schema */
    kind: UserSchemasEditResponseKind;
    /** Name of the schema */
    name: string;
    /** UUID. */
    schemaId: string;
    /** Source of the schema */
    source?: string | null;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean | null;
}
export type ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType = "header" | "cookie";
export interface ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic {
    /** The name of the characteristic field, i.e., the header or cookie name. */
    name: string;
    /** The type of characteristic. */
    type: ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType | (string & {});
}
export type ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType = "jwt";
export interface ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim {
    /** Claim location expressed as `$(token_config_id):$(json_path)`, where `token_config_id` is the ID of the token configuration used in validating the JWT, and `json_path` is a RFC 9535 JSONPath (https://goessner.net/articles/JsonPath/, https://www.rfc-editor.org/rfc/rfc9535.html). The JSONPath expression may be in dot or bracket notation, may only specify literal keys or array indexes, and must return a singleton value, which will be interpreted as a string. */
    name: string;
    /** The type of characteristic. */
    type: ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType;
}
export type ConfigurationsUpdateRequestAuthIdCharacteristicsItem = ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic | ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim;
export type ConfigurationsUpdateRequestAuthIdCharacteristicsList = Array<ConfigurationsUpdateRequestAuthIdCharacteristicsItem>;
export interface PutConfigurationRequest {
    /** Identifier. */
    zoneId: string;
    /** Ensures that the configuration is written or retrieved in normalized fashion */
    normalize?: boolean;
    authIdCharacteristics: ConfigurationsUpdateRequestAuthIdCharacteristicsList;
}
export type ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType = "header" | "cookie";
export interface ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic {
    /** The name of the characteristic field, i.e., the header or cookie name. */
    name: string;
    /** The type of characteristic. */
    type: ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType;
}
export type ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType = "jwt";
export interface ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim {
    /** Claim location expressed as `$(token_config_id):$(json_path)`, where `token_config_id` is the ID of the token configuration used in validating the JWT, and `json_path` is a RFC 9535 JSONPath (https://goessner.net/articles/JsonPath/, https://www.rfc-editor.org/rfc/rfc9535.html). The JSONPath expression may be in dot or bracket notation, may only specify literal keys or array indexes, and must return a singleton value, which will be interpreted as a string. */
    name: string;
    /** The type of characteristic. */
    type: ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType;
}
export type ConfigurationsUpdateResponseAuthIdCharacteristicsItem = ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic | ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim;
export type ConfigurationsUpdateResponseAuthIdCharacteristicsList = Array<ConfigurationsUpdateResponseAuthIdCharacteristicsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutConfigurationResponse {
    authIdCharacteristics: ConfigurationsUpdateResponseAuthIdCharacteristicsList;
}
export type LabelsManagedResourcesOperationUpdateRequestSelectorIncludeOperationIdsList = Array<string>;
export interface LabelsManagedResourcesOperationUpdateRequestSelectorInclude {
    operationIds: LabelsManagedResourcesOperationUpdateRequestSelectorIncludeOperationIdsList;
}
export interface LabelsManagedResourcesOperationUpdateRequestSelector {
    include: LabelsManagedResourcesOperationUpdateRequestSelectorInclude;
}
export interface PutLabelManagedResourceOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
    /** Operation IDs selector */
    selector: LabelsManagedResourcesOperationUpdateRequestSelector;
}
export type LabelsManagedResourcesOperationUpdateResponseSource = "user" | "managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutLabelManagedResourceOperationResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: LabelsManagedResourcesOperationUpdateResponseSource;
    /** Provides counts of what resources are linked to this label */
    mappedResources?: unknown | null;
}
export interface PutLabelUserRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
    /** The description of the label */
    description?: string;
    /** Metadata for the label */
    metadata?: unknown;
}
export type LabelsUserUpdateResponseSource = "user" | "managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutLabelUserResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: LabelsUserUpdateResponseSource;
}
export type LabelsUserResourcesOperationUpdateRequestSelectorIncludeOperationIdsList = Array<string>;
export interface LabelsUserResourcesOperationUpdateRequestSelectorInclude {
    operationIds: LabelsUserResourcesOperationUpdateRequestSelectorIncludeOperationIdsList;
}
export interface LabelsUserResourcesOperationUpdateRequestSelector {
    include: LabelsUserResourcesOperationUpdateRequestSelectorInclude;
}
export interface PutLabelUserResourceOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
    /** Operation IDs selector */
    selector: LabelsUserResourcesOperationUpdateRequestSelector;
}
export type LabelsUserResourcesOperationUpdateResponseSource = "user" | "managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutLabelUserResourceOperationResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: LabelsUserResourcesOperationUpdateResponseSource;
    /** Provides counts of what resources are linked to this label */
    mappedResources?: unknown | null;
}
export type OperationsSchemaValidationUpdateRequestMitigationAction = "log" | "block" | "none";
export interface PutOperationSchemaValidationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
    /** When set, this applies a mitigation action to this operation */
    mitigationAction?: OperationsSchemaValidationUpdateRequestMitigationAction | (string & {});
}
export type OperationsSchemaValidationUpdateResponseMitigationAction = "log" | "block" | "none";
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PutOperationSchemaValidationResponse {
    /** When set, this applies a mitigation action to this operation */
    mitigationAction?: OperationsSchemaValidationUpdateResponseMitigationAction | null;
    /** UUID. */
    operationId?: string | null;
}
export type SettingsSchemaValidationUpdateRequestValidationDefaultMitigationAction = "none" | "log" | "block";
export type SettingsSchemaValidationUpdateRequestValidationOverrideMitigationAction = "none" | "disable_override";
export interface PutSettingSchemaValidationRequest {
    /** Identifier. */
    zoneId: string;
    /** The default mitigation action used when there is no mitigation action defined on the operation */
    validationDefaultMitigationAction: SettingsSchemaValidationUpdateRequestValidationDefaultMitigationAction | (string & {});
    /** When set, this overrides both zone level and operation level mitigation actions. */
    validationOverrideMitigationAction?: SettingsSchemaValidationUpdateRequestValidationOverrideMitigationAction | (string & {});
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PutSettingSchemaValidationResponse {
}
export type OperationsLabelsUpdateRequestManagedList = Array<string>;
export type OperationsLabelsUpdateRequestUserList = Array<string>;
export interface UpdateOperationLabelRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
    /** List of managed label names. Omitting this property or passing an empty array will result in all managed labels being removed from the operation */
    managed?: OperationsLabelsUpdateRequestManagedList;
    /** List of user label names. Omitting this property or passing an empty array will result in all user labels being removed from the operation */
    user?: OperationsLabelsUpdateRequestUserList;
}
export type OperationsLabelsUpdateResponseMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export type OperationsLabelsUpdateResponseLabelsItemSource = "user" | "managed";
export interface OperationsLabelsUpdateResponseLabelsItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** - `user` - label is owned by the user - `managed` - label is owned by cloudflare */
    source: OperationsLabelsUpdateResponseLabelsItemSource;
}
export type OperationsLabelsUpdateResponseLabelsList = Array<OperationsLabelsUpdateResponseLabelsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateOperationLabelResponse {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsLabelsUpdateResponseMethod;
    /** UUID. */
    operationId: string;
    labels?: OperationsLabelsUpdateResponseLabelsList | null;
}
export type BulkCreateLabelUsersError = LabelAlreadyExists | Forbidden | CloudflareOpError;
/** Creates one or more user-defined labels for classifying web and API operations. */
export declare const bulkCreateLabelUsers: API.PaginatedOperationMethod<BulkCreateLabelUsersRequest, BulkCreateLabelUsersResponse, BulkCreateLabelUsersError, CloudflareOpContext, LabelsUserBulkCreateResultItem>;
export type BulkCreateOperationLabelsError = CloudflareOpError;
/** Attaches labels to multiple web or API operations in one request. */
export declare const bulkCreateOperationLabels: API.PaginatedOperationMethod<BulkCreateOperationLabelsRequest, BulkCreateOperationLabelsResponse, BulkCreateOperationLabelsError, CloudflareOpContext, OperationsLabelsBulkCreateResultItem>;
export type BulkCreateOperationsError = CloudflareOpError;
/** Creates one or more web or API operations. Hosts, methods, and paths are normalized; an existing matching operation is returned instead of duplicated. */
export declare const bulkCreateOperations: API.PaginatedOperationMethod<BulkCreateOperationsRequest, BulkCreateOperationsResponse, BulkCreateOperationsError, CloudflareOpContext, OperationsBulkCreateResultItem>;
export type BulkDeleteLabelUsersError = CloudflareOpError;
/** Deletes one or more user-defined labels and removes their associations with web and API operations. */
export declare const bulkDeleteLabelUsers: API.PaginatedOperationMethod<BulkDeleteLabelUsersRequest, BulkDeleteLabelUsersResponse, BulkDeleteLabelUsersError, CloudflareOpContext, LabelsUserBulkDeleteResultItem>;
export type BulkDeleteOperationLabelsError = CloudflareOpError;
/** Removes labels from multiple web or API operations in one request. */
export declare const bulkDeleteOperationLabels: API.PaginatedOperationMethod<BulkDeleteOperationLabelsRequest, BulkDeleteOperationLabelsResponse, BulkDeleteOperationLabelsError, CloudflareOpContext, OperationsLabelsBulkDeleteResultItem>;
export type BulkDeleteOperationsError = InvalidObjectIdentifier | CloudflareOpError;
/** Deletes multiple web or API operations from endpoint management in one request. */
export declare const bulkDeleteOperations: API.OperationMethod<BulkDeleteOperationsRequest, BulkDeleteOperationsResponse, BulkDeleteOperationsError, CloudflareOpContext>;
export type BulkPatchDiscoveryOperationsError = InvalidObjectIdentifier | NotEntitled | CloudflareOpError;
/** Updates the state of one or more discovered web and API operations. */
export declare const bulkPatchDiscoveryOperations: API.OperationMethod<BulkPatchDiscoveryOperationsRequest, BulkPatchDiscoveryOperationsResponse, BulkPatchDiscoveryOperationsError, CloudflareOpContext>;
export type BulkUpdateOperationLabelsError = CloudflareOpError;
/** Replaces the complete label sets on multiple web or API operations in one request. */
export declare const bulkUpdateOperationLabels: API.PaginatedOperationMethod<BulkUpdateOperationLabelsRequest, BulkUpdateOperationLabelsResponse, BulkUpdateOperationLabelsError, CloudflareOpContext, OperationsLabelsBulkUpdateResultItem>;
export type CreateExpressionTemplateFallthroughError = InvalidObjectIdentifier | CloudflareOpError;
/** Generates a WAF expression template that matches fallthrough traffic for the supplied API hosts. This operation is deprecated and should not be used for new integrations. */
export declare const createExpressionTemplateFallthrough: API.OperationMethod<CreateExpressionTemplateFallthroughRequest, CreateExpressionTemplateFallthroughResponse, CreateExpressionTemplateFallthroughError, CloudflareOpContext>;
export type CreateOperationError = InvalidObjectIdentifier | Forbidden | CloudflareOpError;
/** Creates one web or API operation. The host, method, and path are normalized; an existing matching operation is returned instead of duplicated. */
export declare const createOperation: API.OperationMethod<CreateOperationRequest, CreateOperationResponse, CreateOperationError, CloudflareOpContext>;
export type CreateOperationLabelError = CloudflareOpError;
/** Attaches one or more labels to a web or API operation. */
export declare const createOperationLabel: API.OperationMethod<CreateOperationLabelRequest, CreateOperationLabelResponse, CreateOperationLabelError, CloudflareOpContext>;
export type CreateUserSchemaError = InvalidObjectIdentifier | Forbidden | CloudflareOpError;
/** Uploads an OpenAPI schema that defines expected request formats for API endpoints. Deprecated; use `/zones/{zone_id}/schema_validation/schemas` instead. */
export declare const createUserSchema: API.OperationMethod<CreateUserSchemaRequest, CreateUserSchemaResponse, CreateUserSchemaError, CloudflareOpContext>;
export type DeleteLabelUserError = LabelNotFound | Forbidden | CloudflareOpError;
/** Deletes a user-defined label and removes its associations with web and API operations. */
export declare const deleteLabelUser: API.OperationMethod<DeleteLabelUserRequest, DeleteLabelUserResponse, DeleteLabelUserError, CloudflareOpContext>;
export type DeleteOperationError = InvalidObjectIdentifier | OperationNotFound | Forbidden | CloudflareOpError;
/** Deletes a web or API operation from endpoint management so its feature configuration is no longer tracked. */
export declare const deleteOperation: API.OperationMethod<DeleteOperationRequest, DeleteOperationResponse, DeleteOperationError, CloudflareOpContext>;
export type DeleteOperationLabelError = CloudflareOpError;
/** Removes one or more labels from a web or API operation. */
export declare const deleteOperationLabel: API.OperationMethod<DeleteOperationLabelRequest, DeleteOperationLabelResponse, DeleteOperationLabelError, CloudflareOpContext>;
export type DeleteUserSchemaError = InvalidObjectIdentifier | SchemaNotFound | Forbidden | CloudflareOpError;
/** Permanently removes an uploaded OpenAPI schema from API Shield schema validation. Operations using this schema will lose their validation rules. Deprecated; use `/zones/{zone_id}/schema_validation/schemas/{schema_id}` instead. */
export declare const deleteUserSchema: API.OperationMethod<DeleteUserSchemaRequest, DeleteUserSchemaResponse, DeleteUserSchemaError, CloudflareOpContext>;
export type EditDiscoveryOperationError = CloudflareOpError;
/** Updates the state of a discovered web or API operation. */
export declare const editDiscoveryOperation: API.OperationMethod<EditDiscoveryOperationRequest, EditDiscoveryOperationResponse, EditDiscoveryOperationError, CloudflareOpContext>;
export type GetConfigurationError = InvalidObjectIdentifier | NotEntitled | Forbidden | CloudflareOpError;
/** Returns the authentication identifier characteristics configured for the zone. Header, cookie, or JWT claim values identify distinct API sessions. */
export declare const getConfiguration: API.OperationMethod<GetConfigurationRequest, GetConfigurationResponse, GetConfigurationError, CloudflareOpContext>;
export type GetDiscoveryError = InvalidObjectIdentifier | NotEntitled | CloudflareOpError;
/** Returns the latest API operations discovered from zone traffic, rendered as OpenAPI schemas. */
export declare const getDiscovery: API.OperationMethod<GetDiscoveryRequest, GetDiscoveryResponse, GetDiscoveryError, CloudflareOpContext>;
export type GetLabelManagedError = CloudflareOpError;
/** Returns a managed label and the web and API operations associated with it. */
export declare const getLabelManaged: API.OperationMethod<GetLabelManagedRequest, GetLabelManagedResponse, GetLabelManagedError, CloudflareOpContext>;
export type GetLabelUserError = LabelNotFound | Forbidden | CloudflareOpError;
/** Returns a user-defined label and the web and API operations associated with it. */
export declare const getLabelUser: API.OperationMethod<GetLabelUserRequest, GetLabelUserResponse, GetLabelUserError, CloudflareOpContext>;
export type GetOperationError = InvalidObjectIdentifier | OperationNotFound | Forbidden | CloudflareOpError;
/** Returns a web or API operation, including its schema validation settings and requested feature data. */
export declare const getOperation: API.OperationMethod<GetOperationRequest, GetOperationResponse, GetOperationError, CloudflareOpContext>;
export type GetOperationSchemaValidationError = InvalidObjectIdentifier | OperationNotFound | CloudflareOpError;
/** Retrieves operation-level schema validation settings on the zone. Deprecated; use `/zones/{zone_id}/schema_validation/settings/operations/{operation_id}` instead. */
export declare const getOperationSchemaValidation: API.OperationMethod<GetOperationSchemaValidationRequest, GetOperationSchemaValidationResponse, GetOperationSchemaValidationError, CloudflareOpContext>;
export type GetSettingSchemaValidationError = InvalidObjectIdentifier | CloudflareOpError;
/** Retrieves zone level schema validation settings currently set on the zone. Deprecated; use `/zones/{zone_id}/schema_validation/settings` instead. */
export declare const getSettingSchemaValidation: API.OperationMethod<GetSettingSchemaValidationRequest, GetSettingSchemaValidationResponse, GetSettingSchemaValidationError, CloudflareOpContext>;
export type GetUserSchemaError = InvalidObjectIdentifier | SchemaNotFound | Forbidden | CloudflareOpError;
/** Gets detailed information about a specific uploaded OpenAPI schema, including its contents and validation configuration. Deprecated; use `/zones/{zone_id}/schema_validation/schemas/{schema_id}` instead. */
export declare const getUserSchema: API.OperationMethod<GetUserSchemaRequest, GetUserSchemaResponse, GetUserSchemaError, CloudflareOpContext>;
export type ListDiscoveryOperationsError = CloudflareOpError;
/** Returns the latest web and API operations discovered from zone traffic. */
export declare const listDiscoveryOperations: API.PaginatedOperationMethod<ListDiscoveryOperationsRequest, ListDiscoveryOperationsResponse, ListDiscoveryOperationsError, CloudflareOpContext, DiscoveryOperationsListResultItem>;
export type ListLabelsError = ZonePurged | Forbidden | NotFound | CloudflareOpError;
/** Returns all managed and user-defined labels available for web and API operations in the zone. */
export declare const listLabels: API.PaginatedOperationMethod<ListLabelsRequest, ListLabelsResponse, ListLabelsError, CloudflareOpContext, LabelsListResultItem>;
export type ListOperationsError = Forbidden | CloudflareOpError;
/** Lists web and API operations tracked for the zone, including each operation's method, path, and feature configuration. */
export declare const listOperations: API.PaginatedOperationMethod<ListOperationsRequest, ListOperationsResponse, ListOperationsError, CloudflareOpContext, OperationsListResultItem>;
export type ListSchemasError = InvalidObjectIdentifier | CloudflareOpError;
/** Returns tracked web and API operations and their feature configuration rendered as OpenAPI schemas. */
export declare const listSchemas: API.OperationMethod<ListSchemasRequest, ListSchemasResponse, ListSchemasError, CloudflareOpContext>;
export type ListUserSchemaHostsError = CloudflareOpError;
/** Lists all unique hosts found in uploaded OpenAPI schemas for the zone. Useful for understanding which domains have schema coverage. Deprecated; use `/zones/{zone_id}/schema_validation/schemas/hosts` instead. */
export declare const listUserSchemaHosts: API.PaginatedOperationMethod<ListUserSchemaHostsRequest, ListUserSchemaHostsResponse, ListUserSchemaHostsError, CloudflareOpContext, UserSchemasHostsListResultItem>;
export type ListUserSchemaOperationsError = CloudflareOpError;
/** Retrieves all operations from the schema. Operations that already exist in API Shield Endpoint Management will be returned as full operations. Deprecated; use `/zones/{zone_id}/schema_validation/schemas/{schema_id}/operations` instead. */
export declare const listUserSchemaOperations: API.PaginatedOperationMethod<ListUserSchemaOperationsRequest, ListUserSchemaOperationsResponse, ListUserSchemaOperationsError, CloudflareOpContext, UserSchemasOperationsListResultItem>;
export type ListUserSchemasError = ZonePurged | Forbidden | CloudflareOpError;
/** Lists all OpenAPI schemas uploaded to API Shield for the zone, including their validation status and associated operations. Deprecated; use `/zones/{zone_id}/schema_validation/schemas` instead. */
export declare const listUserSchemas: API.PaginatedOperationMethod<ListUserSchemasRequest, ListUserSchemasResponse, ListUserSchemasError, CloudflareOpContext, UserSchemasListResultItem>;
export type PatchLabelUserError = LabelNotFound | CloudflareOpError;
/** Updates only the supplied fields on a user-defined label. */
export declare const patchLabelUser: API.OperationMethod<PatchLabelUserRequest, PatchLabelUserResponse, PatchLabelUserError, CloudflareOpContext>;
export type PatchOperationSchemaValidationError = InvalidObjectIdentifier | CloudflareOpError;
/** Updates multiple operation-level schema validation settings on the zone. Deprecated; use `/zones/{zone_id}/schema_validation/settings/operations` instead. */
export declare const patchOperationSchemaValidation: API.OperationMethod<PatchOperationSchemaValidationRequest, PatchOperationSchemaValidationResponse, PatchOperationSchemaValidationError, CloudflareOpContext>;
export type PatchSettingSchemaValidationError = InvalidObjectIdentifier | CloudflareOpError;
/** Updates zone level schema validation settings on the zone. Deprecated; use `/zones/{zone_id}/schema_validation/settings` instead. */
export declare const patchSettingSchemaValidation: API.OperationMethod<PatchSettingSchemaValidationRequest, PatchSettingSchemaValidationResponse, PatchSettingSchemaValidationError, CloudflareOpContext>;
export type PatchUserSchemaError = InvalidObjectIdentifier | SchemaNotFound | Forbidden | CloudflareOpError;
/** Activates schema validation for an uploaded OpenAPI schema. Requests to matching endpoints will be validated against the schema definitions. Deprecated; use `/zones/{zone_id}/schema_validation/schemas/{schema_id}` instead. */
export declare const patchUserSchema: API.OperationMethod<PatchUserSchemaRequest, PatchUserSchemaResponse, PatchUserSchemaError, CloudflareOpContext>;
export type PutConfigurationError = InvalidObjectIdentifier | NotEntitled | Forbidden | CloudflareOpError;
/** Replaces the zone's authentication identifier characteristics used to identify distinct API sessions. */
export declare const putConfiguration: API.OperationMethod<PutConfigurationRequest, PutConfigurationResponse, PutConfigurationError, CloudflareOpContext>;
export type PutLabelManagedResourceOperationError = CloudflareOpError;
/** Replaces the complete set of web and API operations attached to the managed label. */
export declare const putLabelManagedResourceOperation: API.OperationMethod<PutLabelManagedResourceOperationRequest, PutLabelManagedResourceOperationResponse, PutLabelManagedResourceOperationError, CloudflareOpContext>;
export type PutLabelUserError = LabelNotFound | CloudflareOpError;
/** Replaces all editable fields on a user-defined label. */
export declare const putLabelUser: API.OperationMethod<PutLabelUserRequest, PutLabelUserResponse, PutLabelUserError, CloudflareOpContext>;
export type PutLabelUserResourceOperationError = CloudflareOpError;
/** Replaces the complete set of web and API operations attached to the user-defined label. */
export declare const putLabelUserResourceOperation: API.OperationMethod<PutLabelUserResourceOperationRequest, PutLabelUserResourceOperationResponse, PutLabelUserResourceOperationError, CloudflareOpContext>;
export type PutOperationSchemaValidationError = InvalidObjectIdentifier | OperationNotFound | CloudflareOpError;
/** Updates operation-level schema validation settings on the zone. Deprecated; use `/zones/{zone_id}/schema_validation/settings/operations/{operation_id}` instead. */
export declare const putOperationSchemaValidation: API.OperationMethod<PutOperationSchemaValidationRequest, PutOperationSchemaValidationResponse, PutOperationSchemaValidationError, CloudflareOpContext>;
export type PutSettingSchemaValidationError = InvalidObjectIdentifier | CloudflareOpError;
/** Updates zone level schema validation settings on the zone. Deprecated; use `/zones/{zone_id}/schema_validation/settings` instead. */
export declare const putSettingSchemaValidation: API.OperationMethod<PutSettingSchemaValidationRequest, PutSettingSchemaValidationResponse, PutSettingSchemaValidationError, CloudflareOpContext>;
export type UpdateOperationLabelError = CloudflareOpError;
/** Replaces the complete label set on a web or API operation. */
export declare const updateOperationLabel: API.OperationMethod<UpdateOperationLabelRequest, UpdateOperationLabelResponse, UpdateOperationLabelError, CloudflareOpContext>;
//# sourceMappingURL=api_gateway.d.ts.map