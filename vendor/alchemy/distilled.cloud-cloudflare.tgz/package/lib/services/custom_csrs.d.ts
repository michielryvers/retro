import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type CreateRequestSansList = Array<string>;
export type CreateRequestKeyType = "rsa2048" | "p256v1";
export interface CreateCustomCsrForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** The common name (domain) for the CSR. Must be at most 64 characters. */
    commonName: string;
    /** Two-letter ISO 3166-1 alpha-2 country code. */
    country: string;
    /** City or locality name. */
    locality: string;
    /** Organization name. */
    organization: string;
    /** Subject Alternative Names for the CSR. At least one SAN is required. */
    sans: CreateRequestSansList;
    /** State or province name. */
    state: string;
    /** Optional description for the CSR. */
    description?: string;
    /** Key algorithm to use for the CSR. Defaults to rsa2048 if not specified. */
    keyType?: CreateRequestKeyType | (string & {});
    /** Human-readable name for the CSR. */
    name?: string;
    /** Organizational unit name. */
    organizationalUnit?: string;
}
export type CreateResponseKeyType = "rsa2048" | "p256v1";
export type CreateResponseSansList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCustomCsrResponse {
    /** Custom CSR identifier tag. */
    id: string;
    /** When the CSR was created. */
    createdAt: string;
    /** The key algorithm used to generate the CSR. */
    keyType: CreateResponseKeyType;
    /** Account identifier associated with this CSR. */
    accountTag?: string | null;
    /** The common name (domain) for the CSR. */
    commonName?: string | null;
    /** Two-letter ISO 3166-1 alpha-2 country code. */
    country?: string | null;
    /** The PEM-encoded Certificate Signing Request. */
    csr?: string | null;
    /** Optional description for the CSR. */
    description?: string | null;
    /** City or locality name. */
    locality?: string | null;
    /** Human-readable name for the CSR. */
    name?: string | null;
    /** Organization name. */
    organization?: string | null;
    /** Organizational unit name. */
    organizationalUnit?: string | null;
    /** Subject Alternative Names included in the CSR. */
    sans?: CreateResponseSansList | null;
    /** State or province name. */
    state?: string | null;
}
export interface CreateCustomCsrForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** The common name (domain) for the CSR. Must be at most 64 characters. */
    commonName: string;
    /** Two-letter ISO 3166-1 alpha-2 country code. */
    country: string;
    /** City or locality name. */
    locality: string;
    /** Organization name. */
    organization: string;
    /** Subject Alternative Names for the CSR. At least one SAN is required. */
    sans: CreateRequestSansList;
    /** State or province name. */
    state: string;
    /** Optional description for the CSR. */
    description?: string;
    /** Key algorithm to use for the CSR. Defaults to rsa2048 if not specified. */
    keyType?: CreateRequestKeyType | (string & {});
    /** Human-readable name for the CSR. */
    name?: string;
    /** Organizational unit name. */
    organizationalUnit?: string;
}
export interface DeleteCustomCsrForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Custom CSR identifier tag. */
    customCsrId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCustomCsrResponse {
    /** Custom CSR identifier tag. */
    id?: string | null;
}
export interface DeleteCustomCsrForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Custom CSR identifier tag. */
    customCsrId: string;
}
export interface GetCustomCsrForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Custom CSR identifier tag. */
    customCsrId: string;
}
export type GetResponseKeyType = "rsa2048" | "p256v1";
export type GetResponseSansList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCustomCsrResponse {
    /** Custom CSR identifier tag. */
    id: string;
    /** When the CSR was created. */
    createdAt: string;
    /** The key algorithm used to generate the CSR. */
    keyType: GetResponseKeyType;
    /** Account identifier associated with this CSR. */
    accountTag?: string | null;
    /** The common name (domain) for the CSR. */
    commonName?: string | null;
    /** Two-letter ISO 3166-1 alpha-2 country code. */
    country?: string | null;
    /** The PEM-encoded Certificate Signing Request. */
    csr?: string | null;
    /** Optional description for the CSR. */
    description?: string | null;
    /** City or locality name. */
    locality?: string | null;
    /** Human-readable name for the CSR. */
    name?: string | null;
    /** Organization name. */
    organization?: string | null;
    /** Organizational unit name. */
    organizationalUnit?: string | null;
    /** Subject Alternative Names included in the CSR. */
    sans?: GetResponseSansList | null;
    /** State or province name. */
    state?: string | null;
}
export interface GetCustomCsrForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Custom CSR identifier tag. */
    customCsrId: string;
}
export type ListRequestDirection = "asc" | "desc";
export type ListRequestOrder = "name" | "account_tag" | "created_at";
export interface ListCustomCsrsForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** The direction to sort by. */
    direction?: ListRequestDirection | (string & {});
    /** The field to sort the returned custom CSRs by. */
    order?: ListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of custom CSRs per page. */
    perPage?: number;
}
export type ListResultItemKeyType = "rsa2048" | "p256v1";
export type ListResultItemSansList = Array<string>;
export interface ListResultItem {
    /** Custom CSR identifier tag. */
    id: string;
    /** When the CSR was created. */
    createdAt: string;
    /** The key algorithm used to generate the CSR. */
    keyType: ListResultItemKeyType;
    /** Account identifier associated with this CSR. */
    accountTag?: string | null;
    /** The common name (domain) for the CSR. */
    commonName?: string | null;
    /** Two-letter ISO 3166-1 alpha-2 country code. */
    country?: string | null;
    /** The PEM-encoded Certificate Signing Request. */
    csr?: string | null;
    /** Optional description for the CSR. */
    description?: string | null;
    /** City or locality name. */
    locality?: string | null;
    /** Human-readable name for the CSR. */
    name?: string | null;
    /** Organization name. */
    organization?: string | null;
    /** Organizational unit name. */
    organizationalUnit?: string | null;
    /** Subject Alternative Names included in the CSR. */
    sans?: ListResultItemSansList | null;
    /** State or province name. */
    state?: string | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListCustomCsrsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListCustomCsrsForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** The direction to sort by. */
    direction?: ListRequestDirection | (string & {});
    /** The field to sort the returned custom CSRs by. */
    order?: ListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of custom CSRs per page. */
    perPage?: number;
}
export type CreateCustomCsrForAccountError = CloudflareOpError;
/** Generate a new custom Certificate Signing Request (CSR) for an account or zone. Cloudflare generates and securely stores the private key associated with the CSR. */
export declare const createCustomCsrForAccount: API.OperationMethod<CreateCustomCsrForAccountRequest, CreateCustomCsrResponse, CreateCustomCsrForAccountError, CloudflareOpContext>;
export type CreateCustomCsrForZoneError = CloudflareOpError;
/** Generate a new custom Certificate Signing Request (CSR) for an account or zone. Cloudflare generates and securely stores the private key associated with the CSR. */
export declare const createCustomCsrForZone: API.OperationMethod<CreateCustomCsrForZoneRequest, CreateCustomCsrResponse, CreateCustomCsrForZoneError, CloudflareOpContext>;
export type DeleteCustomCsrForAccountError = CloudflareOpError;
/** Delete a custom Certificate Signing Request (CSR) and its associated private key. */
export declare const deleteCustomCsrForAccount: API.OperationMethod<DeleteCustomCsrForAccountRequest, DeleteCustomCsrResponse, DeleteCustomCsrForAccountError, CloudflareOpContext>;
export type DeleteCustomCsrForZoneError = CloudflareOpError;
/** Delete a custom Certificate Signing Request (CSR) and its associated private key. */
export declare const deleteCustomCsrForZone: API.OperationMethod<DeleteCustomCsrForZoneRequest, DeleteCustomCsrResponse, DeleteCustomCsrForZoneError, CloudflareOpContext>;
export type GetCustomCsrForAccountError = CloudflareOpError;
/** Retrieve details for a specific custom Certificate Signing Request (CSR). */
export declare const getCustomCsrForAccount: API.OperationMethod<GetCustomCsrForAccountRequest, GetCustomCsrResponse, GetCustomCsrForAccountError, CloudflareOpContext>;
export type GetCustomCsrForZoneError = CloudflareOpError;
/** Retrieve details for a specific custom Certificate Signing Request (CSR). */
export declare const getCustomCsrForZone: API.OperationMethod<GetCustomCsrForZoneRequest, GetCustomCsrResponse, GetCustomCsrForZoneError, CloudflareOpContext>;
export type ListCustomCsrsForAccountError = CloudflareOpError;
/** List all custom Certificate Signing Requests (CSRs) for an account or zone. */
export declare const listCustomCsrsForAccount: API.PaginatedOperationMethod<ListCustomCsrsForAccountRequest, ListCustomCsrsResponse, ListCustomCsrsForAccountError, CloudflareOpContext, ListResultItem>;
export type ListCustomCsrsForZoneError = CloudflareOpError;
/** List all custom Certificate Signing Requests (CSRs) for an account or zone. */
export declare const listCustomCsrsForZone: API.PaginatedOperationMethod<ListCustomCsrsForZoneRequest, ListCustomCsrsResponse, ListCustomCsrsForZoneError, CloudflareOpContext, ListResultItem>;
//# sourceMappingURL=custom_csrs.d.ts.map