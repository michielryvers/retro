import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidSchema_base: S.TaggedErrorClass<"InvalidSchema", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidSchema extends /*@__PURE__*/ InvalidSchema_base {
}
declare const OperationNotFound_base: S.TaggedErrorClass<"OperationNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class OperationNotFound extends /*@__PURE__*/ OperationNotFound_base {
}
declare const SchemaNotFound_base: S.TaggedErrorClass<"SchemaNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SchemaNotFound extends /*@__PURE__*/ SchemaNotFound_base {
}
declare const UnentitledMitigationAction_base: S.TaggedErrorClass<"UnentitledMitigationAction", {
    readonly code: any;
    readonly message: any;
}>;
export declare class UnentitledMitigationAction extends /*@__PURE__*/ UnentitledMitigationAction_base {
}
declare const ZonePurged_base: S.TaggedErrorClass<"ZonePurged", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ZonePurged extends /*@__PURE__*/ ZonePurged_base {
}
export type SettingsOperationsBulkEditRequestBodyValueMitigationAction = "none" | "log" | "block";
export interface SettingsOperationsBulkEditRequestBodyValue {
    /** Mitigation actions are as follows: */
    mitigationAction?: SettingsOperationsBulkEditRequestBodyValueMitigationAction | (string & {});
}
export type SettingsOperationsBulkEditRequestBodyMap = {
    [key: string]: SettingsOperationsBulkEditRequestBodyValue | undefined;
};
export interface BulkPatchSettingOperationsRequest {
    /** Identifier. */
    zoneId: string;
    body: SettingsOperationsBulkEditRequestBodyMap;
}
export type SettingsOperationsBulkEditResultValueMitigationAction = "log" | "block" | "none";
export interface SettingsOperationsBulkEditResultValue {
    /** When set, this applies a mitigation action to this operation */
    mitigationAction?: SettingsOperationsBulkEditResultValueMitigationAction | null;
}
export type SettingsOperationsBulkEditResultMap = {
    [key: string]: SettingsOperationsBulkEditResultValue | undefined;
};
export type BulkPatchSettingOperationsResponse = SettingsOperationsBulkEditResultMap;
export type SchemasCreateRequestKind = "openapi_v3";
export interface CreateSchemaRequest {
    /** Identifier. */
    zoneId: string;
    /** The kind of the schema */
    kind: SchemasCreateRequestKind | (string & {});
    /** A human-readable name for the schema */
    name: string;
    /** The raw schema, e.g., the OpenAPI schema, either as JSON or YAML */
    source: string;
    /** An indicator if this schema is enabled */
    validationEnabled: boolean;
}
export type SchemasCreateResponseKind = "openapi_v3";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSchemaResponse {
    createdAt: string;
    /** The kind of the schema */
    kind: SchemasCreateResponseKind;
    /** A human-readable name for the schema */
    name: string;
    /** A unique identifier of this schema */
    schemaId: string;
    /** The raw schema, e.g., the OpenAPI schema, either as JSON or YAML */
    source: string;
    /** An indicator if this schema is enabled */
    validationEnabled?: boolean | null;
}
export interface DeleteSchemaRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    schemaId: string;
}
export type DeleteSchemaResponse = unknown;
export interface DeleteSettingOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingOperationResponse {
    /** UUID. */
    operationId?: string | null;
}
export interface GetSchemaRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    schemaId: string;
    /** Omit the source-files of schemas and only retrieve their meta-data. */
    omitSource?: boolean;
}
export type SchemasGetResponseKind = "openapi_v3";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSchemaResponse {
    createdAt: string;
    /** The kind of the schema */
    kind: SchemasGetResponseKind;
    /** A human-readable name for the schema */
    name: string;
    /** A unique identifier of this schema */
    schemaId: string;
    /** The raw schema, e.g., the OpenAPI schema, either as JSON or YAML */
    source: string;
    /** An indicator if this schema is enabled */
    validationEnabled?: boolean | null;
}
export interface GetSettingRequest {
    /** Identifier. */
    zoneId: string;
}
export type SettingsGetResponseValidationDefaultMitigationAction = "none" | "log" | "block";
export type SettingsGetResponseValidationOverrideMitigationAction = "none";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingResponse {
    /** The default mitigation action used */
    validationDefaultMitigationAction: SettingsGetResponseValidationDefaultMitigationAction;
    /** When not null, this overrides global both zone level and operation level mitigation actions. This can serve as a quick way to disable schema validation for the whole zone. */
    validationOverrideMitigationAction?: SettingsGetResponseValidationOverrideMitigationAction | null;
}
export interface GetSettingOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
}
export type SettingsOperationsGetResponseMitigationAction = "log" | "block" | "none";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingOperationResponse {
    /** When set, this applies a mitigation action to this operation which supersedes a global schema validation setting just for this operation */
    mitigationAction: SettingsOperationsGetResponseMitigationAction;
    /** UUID. */
    operationId: string;
}
export interface ListSchemasRequest {
    /** Identifier. */
    zoneId: string;
    /** Omit the source-files of schemas and only retrieve their meta-data. */
    omitSource?: boolean;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** Filter for enabled schemas */
    validationEnabled?: boolean;
}
export type SchemasListResultItemKind = "openapi_v3";
export interface SchemasListResultItem {
    createdAt: string;
    /** The kind of the schema */
    kind: SchemasListResultItemKind;
    /** A human-readable name for the schema */
    name: string;
    /** A unique identifier of this schema */
    schemaId: string;
    /** The raw schema, e.g., the OpenAPI schema, either as JSON or YAML */
    source: string;
    /** An indicator if this schema is enabled */
    validationEnabled?: boolean | null;
}
export type SchemasListResultList = Array<SchemasListResultItem>;
export interface ListSchemasResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SchemasListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListSettingOperationsRequest {
    /** Identifier. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type SettingsOperationsListResultItemMitigationAction = "log" | "block" | "none";
export interface SettingsOperationsListResultItem {
    /** When set, this applies a mitigation action to this operation which supersedes a global schema validation setting just for this operation */
    mitigationAction: SettingsOperationsListResultItemMitigationAction;
    /** UUID. */
    operationId: string;
}
export type SettingsOperationsListResultList = Array<SettingsOperationsListResultItem>;
export interface ListSettingOperationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsOperationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface PatchSchemaRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    schemaId: string;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean;
}
export type SchemasEditResponseKind = "openapi_v3";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSchemaResponse {
    createdAt: string;
    /** The kind of the schema */
    kind: SchemasEditResponseKind;
    /** A human-readable name for the schema */
    name: string;
    /** A unique identifier of this schema */
    schemaId: string;
    /** The raw schema, e.g., the OpenAPI schema, either as JSON or YAML */
    source: string;
    /** An indicator if this schema is enabled */
    validationEnabled?: boolean | null;
}
export type SettingsEditRequestValidationDefaultMitigationAction = "none" | "log" | "block";
export type SettingsEditRequestValidationOverrideMitigationAction = "none";
export interface PatchSettingRequest {
    /** Identifier. */
    zoneId: string;
    /** The default mitigation action used Mitigation actions are as follows: */
    validationDefaultMitigationAction?: SettingsEditRequestValidationDefaultMitigationAction | (string & {});
    /** When set, this overrides both zone level and operation level mitigation actions. */
    validationOverrideMitigationAction?: SettingsEditRequestValidationOverrideMitigationAction | (string & {}) | null;
}
export type SettingsEditResponseValidationDefaultMitigationAction = "none" | "log" | "block";
export type SettingsEditResponseValidationOverrideMitigationAction = "none";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingResponse {
    /** The default mitigation action used */
    validationDefaultMitigationAction: SettingsEditResponseValidationDefaultMitigationAction;
    /** When not null, this overrides global both zone level and operation level mitigation actions. This can serve as a quick way to disable schema validation for the whole zone. */
    validationOverrideMitigationAction?: SettingsEditResponseValidationOverrideMitigationAction | null;
}
export type SettingsUpdateRequestValidationDefaultMitigationAction = "none" | "log" | "block";
export type SettingsUpdateRequestValidationOverrideMitigationAction = "none";
export interface PutSettingRequest {
    /** Identifier. */
    zoneId: string;
    /** The default mitigation action used Mitigation actions are as follows: */
    validationDefaultMitigationAction: SettingsUpdateRequestValidationDefaultMitigationAction | (string & {});
    /** When set, this overrides both zone level and operation level mitigation actions. */
    validationOverrideMitigationAction?: SettingsUpdateRequestValidationOverrideMitigationAction | (string & {}) | null;
}
export type SettingsUpdateResponseValidationDefaultMitigationAction = "none" | "log" | "block";
export type SettingsUpdateResponseValidationOverrideMitigationAction = "none";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSettingResponse {
    /** The default mitigation action used */
    validationDefaultMitigationAction: SettingsUpdateResponseValidationDefaultMitigationAction;
    /** When not null, this overrides global both zone level and operation level mitigation actions. This can serve as a quick way to disable schema validation for the whole zone. */
    validationOverrideMitigationAction?: SettingsUpdateResponseValidationOverrideMitigationAction | null;
}
export type SettingsOperationsUpdateRequestMitigationAction = "log" | "block" | "none";
export interface PutSettingOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
    /** When set, this applies a mitigation action to this operation */
    mitigationAction: SettingsOperationsUpdateRequestMitigationAction | (string & {});
}
export type SettingsOperationsUpdateResponseMitigationAction = "log" | "block" | "none";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSettingOperationResponse {
    /** When set, this applies a mitigation action to this operation which supersedes a global schema validation setting just for this operation */
    mitigationAction: SettingsOperationsUpdateResponseMitigationAction;
    /** UUID. */
    operationId: string;
}
export type BulkPatchSettingOperationsError = CloudflareOpError;
/** Updates schema validation settings for multiple API operations in a single request. Efficient for applying consistent validation rules across endpoints. */
export declare const bulkPatchSettingOperations: API.OperationMethod<BulkPatchSettingOperationsRequest, BulkPatchSettingOperationsResponse, BulkPatchSettingOperationsError, CloudflareOpContext>;
export type CreateSchemaError = InvalidSchema | Forbidden | CloudflareOpError;
/** Uploads an OpenAPI schema that defines expected request formats for API operations. */
export declare const createSchema: API.OperationMethod<CreateSchemaRequest, CreateSchemaResponse, CreateSchemaError, CloudflareOpContext>;
export type DeleteSchemaError = SchemaNotFound | CloudflareOpError;
/** Permanently removes an uploaded OpenAPI schema from API Security. Operations using this schema will lose their validation rules. */
export declare const deleteSchema: API.OperationMethod<DeleteSchemaRequest, DeleteSchemaResponse, DeleteSchemaError, CloudflareOpContext>;
export type DeleteSettingOperationError = OperationNotFound | CloudflareOpError;
/** Removes custom schema validation settings for a specific API operation, reverting to zone-level defaults. */
export declare const deleteSettingOperation: API.OperationMethod<DeleteSettingOperationRequest, DeleteSettingOperationResponse, DeleteSettingOperationError, CloudflareOpContext>;
export type GetSchemaError = SchemaNotFound | Forbidden | CloudflareOpError;
/** Gets the contents and metadata of a specific OpenAPI schema uploaded to API Security. */
export declare const getSchema: API.OperationMethod<GetSchemaRequest, GetSchemaResponse, GetSchemaError, CloudflareOpContext>;
export type GetSettingError = Forbidden | CloudflareOpError;
/** Retrieves the current global schema validation settings for a zone. */
export declare const getSetting: API.OperationMethod<GetSettingRequest, GetSettingResponse, GetSettingError, CloudflareOpContext>;
export type GetSettingOperationError = OperationNotFound | Forbidden | CloudflareOpError;
/** Retrieves the schema validation settings configured for a specific API operation. */
export declare const getSettingOperation: API.OperationMethod<GetSettingOperationRequest, GetSettingOperationResponse, GetSettingOperationError, CloudflareOpContext>;
export type ListSchemasError = ZonePurged | Forbidden | CloudflareOpError;
/** Lists all OpenAPI schemas uploaded to API Security. */
export declare const listSchemas: API.PaginatedOperationMethod<ListSchemasRequest, ListSchemasResponse, ListSchemasError, CloudflareOpContext, SchemasListResultItem>;
export type ListSettingOperationsError = CloudflareOpError;
/** Lists per-operation schema validation settings configured for the zone. */
export declare const listSettingOperations: API.PaginatedOperationMethod<ListSettingOperationsRequest, ListSettingOperationsResponse, ListSettingOperationsError, CloudflareOpContext, SettingsOperationsListResultItem>;
export type PatchSchemaError = SchemaNotFound | CloudflareOpError;
/** Enables or disables validation for an uploaded OpenAPI schema without changing the schema document. */
export declare const patchSchema: API.OperationMethod<PatchSchemaRequest, PatchSchemaResponse, PatchSchemaError, CloudflareOpContext>;
export type PatchSettingError = CloudflareOpError;
/** Partially updates global schema validation settings for a zone using PATCH semantics. */
export declare const patchSetting: API.OperationMethod<PatchSettingRequest, PatchSettingResponse, PatchSettingError, CloudflareOpContext>;
export type PutSettingError = UnentitledMitigationAction | Forbidden | CloudflareOpError;
/** Fully updates global schema validation settings for a zone, replacing existing configuration. */
export declare const putSetting: API.OperationMethod<PutSettingRequest, PutSettingResponse, PutSettingError, CloudflareOpContext>;
export type PutSettingOperationError = OperationNotFound | UnentitledMitigationAction | CloudflareOpError;
/** Fully updates schema validation settings for a specific API operation. */
export declare const putSettingOperation: API.OperationMethod<PutSettingOperationRequest, PutSettingOperationResponse, PutSettingOperationError, CloudflareOpContext>;
//# sourceMappingURL=schema_validation.d.ts.map