import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidMember_base: S.TaggedErrorClass<"InvalidMember", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidMember extends /*@__PURE__*/ InvalidMember_base {
}
declare const PolicyValidationFailed_base: S.TaggedErrorClass<"PolicyValidationFailed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PolicyValidationFailed extends /*@__PURE__*/ PolicyValidationFailed_base {
}
declare const ResourceGroupNotFound_base: S.TaggedErrorClass<"ResourceGroupNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ResourceGroupNotFound extends /*@__PURE__*/ ResourceGroupNotFound_base {
}
declare const UserGroupMemberNotFound_base: S.TaggedErrorClass<"UserGroupMemberNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class UserGroupMemberNotFound extends /*@__PURE__*/ UserGroupMemberNotFound_base {
}
declare const UserGroupNameInUse_base: S.TaggedErrorClass<"UserGroupNameInUse", {
    readonly code: any;
    readonly message: any;
}>;
export declare class UserGroupNameInUse extends /*@__PURE__*/ UserGroupNameInUse_base {
}
declare const UserGroupNotFound_base: S.TaggedErrorClass<"UserGroupNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class UserGroupNotFound extends /*@__PURE__*/ UserGroupNotFound_base {
}
export interface BeginVerificationSsoRequest {
    /** Account identifier tag. */
    accountId: string;
    /** SSO Connector identifier tag. */
    ssoConnectorId: string;
}
export interface BeginVerificationSsoResponse {
}
export type OauthClientsCreateRequestGrantTypesItem = "authorization_code" | "refresh_token";
export type OauthClientsCreateRequestGrantTypesList = Array<OauthClientsCreateRequestGrantTypesItem | (string & {})>;
export type OauthClientsCreateRequestRedirectUrisList = Array<string>;
export type OauthClientsCreateRequestResponseTypesItem = "token" | "id_token" | "code";
export type OauthClientsCreateRequestResponseTypesList = Array<OauthClientsCreateRequestResponseTypesItem | (string & {})>;
export type OauthClientsCreateRequestScopesList = Array<string>;
export type OauthClientsCreateRequestTokenEndpointAuthMethod = "none" | "client_secret_basic" | "client_secret_post";
export type OauthClientsCreateRequestAllowedCorsOriginsList = Array<string>;
export type OauthClientsCreateRequestOptionalScopesList = Array<string>;
export type OauthClientsCreateRequestPostLogoutRedirectUrisList = Array<string>;
export interface CreateOauthClientRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Human-readable name of the OAuth client. */
    clientName: string;
    /** Array of OAuth grant types the client is allowed to use. `authorization_code` is required; `refresh_token` may be included optionally. */
    grantTypes: OauthClientsCreateRequestGrantTypesList;
    /** Array of allowed redirect URIs for the client. */
    redirectUris: OauthClientsCreateRequestRedirectUrisList;
    /** Array of OAuth response types the client is allowed to use. */
    responseTypes: OauthClientsCreateRequestResponseTypesList;
    /** Array of OAuth scopes the client is allowed to request. Colon-delimited scopes are not accepted. Dot-delimited scopes are validated against available OAuth API scopes; simple identity scopes are allowed. Protocol scopes `offline_access` and `openid` are added or removed automatically based on `grant_types` and `response_types`. */
    scopes: OauthClientsCreateRequestScopesList;
    /** The authentication method the client uses at the token endpoint. */
    tokenEndpointAuthMethod: OauthClientsCreateRequestTokenEndpointAuthMethod | (string & {});
    /** Array of allowed CORS origins. */
    allowedCorsOrigins?: OauthClientsCreateRequestAllowedCorsOriginsList;
    /** URL of the home page of the client. */
    clientUri?: string;
    /** URL of the client's logo. */
    logoUri?: string;
    /** Scopes that the authorizing user may decline during consent. Each value must also appear in `scopes`. The scopes `openid`, `offline`, and `offline_access` cannot be optional. */
    optionalScopes?: OauthClientsCreateRequestOptionalScopesList;
    /** URL that points to a privacy policy document. */
    policyUri?: string;
    /** Array of allowed post-logout redirect URIs. */
    postLogoutRedirectUris?: OauthClientsCreateRequestPostLogoutRedirectUrisList;
    /** URL that points to a terms of service document. */
    tosUri?: string;
}
export type OauthClientsCreateResponseVisibility = "public" | "private";
export type OauthClientsCreateResponseAllowedCorsOriginsList = Array<string>;
export type OauthClientsCreateResponseClientUriVerificationStatus = "pending" | "in_progress" | "verified" | "failed";
export interface OauthClientsCreateResponseClientUriVerification {
    /** Current verification status for the client URI host. */
    status?: OauthClientsCreateResponseClientUriVerificationStatus | null;
    /** Exact TXT record value that must be added to DNS to prove ownership of the client URI host. */
    text?: string | null;
}
export type OauthClientsCreateResponseGrantTypesItem = "authorization_code" | "refresh_token";
export type OauthClientsCreateResponseGrantTypesList = Array<OauthClientsCreateResponseGrantTypesItem>;
export type OauthClientsCreateResponseOptionalScopesList = Array<string>;
export type OauthClientsCreateResponsePostLogoutRedirectUrisList = Array<string>;
export type OauthClientsCreateResponseRedirectUrisList = Array<string>;
export type OauthClientsCreateResponseResponseTypesItem = "token" | "id_token" | "code";
export type OauthClientsCreateResponseResponseTypesList = Array<OauthClientsCreateResponseResponseTypesItem>;
export type OauthClientsCreateResponseScopesList = Array<string>;
export type OauthClientsCreateResponseTokenEndpointAuthMethod = "none" | "client_secret_basic" | "client_secret_post";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOauthClientResponse {
    /** The unique identifier for an OAuth client. */
    clientId: string;
    /** Visibility of the OAuth client. */
    visibility: OauthClientsCreateResponseVisibility;
    /** Array of allowed CORS origins. */
    allowedCorsOrigins?: OauthClientsCreateResponseAllowedCorsOriginsList | null;
    /** Human-readable name of the OAuth client. */
    clientName?: string | null;
    /** The client secret. This is the only time the secret is returned in a response. */
    clientSecret?: string | null;
    /** URL of the home page of the client. */
    clientUri?: string | null;
    /** Client URI domain control verification state. */
    clientUriVerification?: OauthClientsCreateResponseClientUriVerification | null;
    /** Timestamp when the OAuth client was created. */
    createdAt?: string | null;
    /** Array of OAuth grant types the client is allowed to use. `authorization_code` is required; `refresh_token` may be included optionally. */
    grantTypes?: OauthClientsCreateResponseGrantTypesList | null;
    /** Indicates whether the client has a rotated secret that has not yet been deleted. */
    hasRotatedSecret?: boolean | null;
    /** URL of the client's logo. */
    logoUri?: string | null;
    /** Scopes that the authorizing user may decline during consent. Each value must also appear in `scopes`. The scopes `openid`, `offline`, and `offline_access` cannot be optional. */
    optionalScopes?: OauthClientsCreateResponseOptionalScopesList | null;
    /** URL that points to a privacy policy document. */
    policyUri?: string | null;
    /** Array of allowed post-logout redirect URIs. */
    postLogoutRedirectUris?: OauthClientsCreateResponsePostLogoutRedirectUrisList | null;
    /** Timestamp when the OAuth client was promoted to public visibility. */
    promotedAt?: string | null;
    /** Array of allowed redirect URIs for the client. */
    redirectUris?: OauthClientsCreateResponseRedirectUrisList | null;
    /** Array of OAuth response types the client is allowed to use. */
    responseTypes?: OauthClientsCreateResponseResponseTypesList | null;
    /** Array of OAuth scopes the client is allowed to request. Colon-delimited scopes are not accepted. Dot-delimited scopes are validated against available OAuth API scopes; simple identity scopes are allowed. Protocol scopes `offline_access` and `openid` are added or removed automatically based on `grant_types` and `response_types`. */
    scopes?: OauthClientsCreateResponseScopesList | null;
    /** The authentication method the client uses at the token endpoint. */
    tokenEndpointAuthMethod?: OauthClientsCreateResponseTokenEndpointAuthMethod | null;
    /** URL that points to a terms of service document. */
    tosUri?: string | null;
    /** Timestamp when the OAuth client was last updated. */
    updatedAt?: string | null;
}
export interface ResourceGroupsCreateRequestScopeObjectsItem {
    /** This is a combination of pre-defined resource name and identifier (like Zone ID etc.) */
    key: string;
}
export type ResourceGroupsCreateRequestScopeObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export interface ResourceGroupsCreateRequestScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. The number of Scope objects should not be zero. */
    objects: ResourceGroupsCreateRequestScopeObjectsList;
}
export interface CreateResourceGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Name of the resource group */
    name: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: ResourceGroupsCreateRequestScope;
}
export type ResourceGroupsCreateResponseScopeObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export type ResourceGroupsCreateResponseScopeObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export interface ResourceGroupsCreateResponseScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: ResourceGroupsCreateResponseScopeObjectsList;
}
export interface ResourceGroupsCreateResponseMeta {
    key?: string | null;
    value?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateResourceGroupResponse {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: ResourceGroupsCreateResponseScope;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export interface CreateSsoRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Email domain of the new SSO connector */
    emailDomain: string;
    /** Begin the verification process after creation */
    beginVerification?: boolean;
    /** Controls the display of FedRAMP language to the user during SSO login */
    useFedrampLanguage?: boolean;
}
export type SsoCreateResponseVerificationStatus = "awaiting" | "pending" | "failed" | "verified";
export interface SsoCreateResponseVerification {
    /** DNS verification code. Add this entire string to the DNS TXT record of the email domain to validate ownership. */
    code?: string | null;
    /** The status of the verification code from the verification process. */
    status?: SsoCreateResponseVerificationStatus | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSsoResponse {
    /** SSO Connector identifier tag. */
    id?: string | null;
    /** Timestamp for the creation of the SSO connector */
    createdOn?: string | null;
    emailDomain?: string | null;
    enabled?: boolean | null;
    /** Timestamp for the last update of the SSO connector */
    updatedOn?: string | null;
    /** Controls the display of FedRAMP language to the user during SSO login */
    useFedrampLanguage?: boolean | null;
    verification?: SsoCreateResponseVerification | null;
}
export type UserGroupsCreateRequestPoliciesItemAccess = "allow" | "deny";
export interface UserGroupsCreateRequestPoliciesItemPermissionGroupsItem {
    /** Permission Group identifier tag. */
    id: string;
}
export type UserGroupsCreateRequestPoliciesItemPermissionGroupsList = Array<UserGroupsCreateRequestPoliciesItemPermissionGroupsItem>;
export interface UserGroupsCreateRequestPoliciesItemResourceGroupsItem {
    /** Resource Group identifier tag. */
    id: string;
}
export type UserGroupsCreateRequestPoliciesItemResourceGroupsList = Array<UserGroupsCreateRequestPoliciesItemResourceGroupsItem>;
export interface UserGroupsCreateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    access: UserGroupsCreateRequestPoliciesItemAccess | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: UserGroupsCreateRequestPoliciesItemPermissionGroupsList;
    /** A set of resource groups that are specified to the policy. */
    resourceGroups: UserGroupsCreateRequestPoliciesItemResourceGroupsList;
}
export type UserGroupsCreateRequestPoliciesList = Array<UserGroupsCreateRequestPoliciesItem>;
export interface CreateUserGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Name of the User group. */
    name: string;
    /** Policies attached to the User group */
    policies?: UserGroupsCreateRequestPoliciesList;
}
export type UserGroupsCreateResponsePoliciesItemAccess = "allow" | "deny";
export interface UserGroupsCreateResponsePoliciesItemPermissionGroupsItemMeta {
    /** A category used to group permission groups. */
    category?: string | null;
    /** Indicates whether the permission group is deprecated. */
    deprecated?: string | null;
    /** Additional information about the permission group. */
    description?: string | null;
    /** Indicates whether the permission group can be edited. */
    editable?: string | null;
    /** The planned end-of-life date and time, when provided. */
    eolAt?: string | null;
    /** A label identifying the permission group. */
    label?: string | null;
    /** The scope associated with the permission group. */
    scopes?: string | null;
    /** Indicates the permission group's availability or visibility. */
    visibility?: string | null;
}
export interface UserGroupsCreateResponsePoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: UserGroupsCreateResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the permission group. */
    name?: string | null;
}
export type UserGroupsCreateResponsePoliciesItemPermissionGroupsList = Array<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export type UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export type UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export interface UserGroupsCreateResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export type UserGroupsCreateResponsePoliciesItemResourceGroupsItemMeta = ResourceGroupsCreateResponseMeta;
export interface UserGroupsCreateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: UserGroupsCreateResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export type UserGroupsCreateResponsePoliciesItemResourceGroupsList = Array<UserGroupsCreateResponsePoliciesItemResourceGroupsItem>;
export interface UserGroupsCreateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: UserGroupsCreateResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: UserGroupsCreateResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: UserGroupsCreateResponsePoliciesItemResourceGroupsList | null;
}
export type UserGroupsCreateResponsePoliciesList = Array<UserGroupsCreateResponsePoliciesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateUserGroupResponse {
    /** User Group identifier tag. */
    id: string;
    /** Timestamp for the creation of the user group */
    createdOn: string;
    /** Last time the user group was modified. */
    modifiedOn: string;
    /** Name of the user group. */
    name: string;
    /** Policies attached to the User group */
    policies?: UserGroupsCreateResponsePoliciesList | null;
}
export interface UserGroupsMembersCreateRequestMembersItem {
    /** The identifier of an existing account Member. */
    id: string;
}
export type UserGroupsMembersCreateRequestMembersList = Array<UserGroupsMembersCreateRequestMembersItem>;
export interface CreateUserGroupMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
    members: UserGroupsMembersCreateRequestMembersList;
}
export type UserGroupsMembersCreateResultItemStatus = "accepted" | "pending";
export interface UserGroupsMembersCreateResultItem {
    /** Account member identifier. */
    id: string;
    /** The contact email address of the user. */
    email?: string | null;
    /** The member's status in the account. */
    status?: UserGroupsMembersCreateResultItemStatus | null;
}
export type UserGroupsMembersCreateResultList = Array<UserGroupsMembersCreateResultItem>;
export interface CreateUserGroupMemberResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserGroupsMembersCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface DeleteOauthClientRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The unique identifier for an OAuth client. */
    oauthClientId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOauthClientResponse {
    /** Identifier */
    id: string;
}
export interface DeleteResourceGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Resource Group identifier tag. */
    resourceGroupId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteResourceGroupResponse {
    /** Identifier */
    id: string;
}
export interface DeleteRotatedSecretOauthClientRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The unique identifier for an OAuth client. */
    oauthClientId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRotatedSecretOauthClientResponse {
    /** Identifier */
    id: string;
}
export interface DeleteSsoRequest {
    /** Account identifier tag. */
    accountId: string;
    /** SSO Connector identifier tag. */
    ssoConnectorId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSsoResponse {
    /** Identifier */
    id: string;
}
export interface DeleteUserGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteUserGroupResponse {
    /** Identifier */
    id: string;
}
export interface DeleteUserGroupMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
    /** The identifier of an existing account Member. */
    memberId: string;
}
export type UserGroupsMembersDeleteResponseStatus = "accepted" | "pending";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteUserGroupMemberResponse {
    /** Account member identifier. */
    id: string;
    /** The contact email address of the user. */
    email?: string | null;
    /** The member's status in the account. */
    status?: UserGroupsMembersDeleteResponseStatus | null;
}
export interface GetOauthClientRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The unique identifier for an OAuth client. */
    oauthClientId: string;
}
export type OauthClientsGetResponseVisibility = "public" | "private";
export type OauthClientsGetResponseAllowedCorsOriginsList = Array<string>;
export type OauthClientsGetResponseClientUriVerificationStatus = "pending" | "in_progress" | "verified" | "failed";
export interface OauthClientsGetResponseClientUriVerification {
    /** Current verification status for the client URI host. */
    status?: OauthClientsGetResponseClientUriVerificationStatus | null;
    /** Exact TXT record value that must be added to DNS to prove ownership of the client URI host. */
    text?: string | null;
}
export type OauthClientsGetResponseGrantTypesItem = "authorization_code" | "refresh_token";
export type OauthClientsGetResponseGrantTypesList = Array<OauthClientsGetResponseGrantTypesItem>;
export type OauthClientsGetResponseOptionalScopesList = Array<string>;
export type OauthClientsGetResponsePostLogoutRedirectUrisList = Array<string>;
export type OauthClientsGetResponseRedirectUrisList = Array<string>;
export type OauthClientsGetResponseResponseTypesItem = "token" | "id_token" | "code";
export type OauthClientsGetResponseResponseTypesList = Array<OauthClientsGetResponseResponseTypesItem>;
export type OauthClientsGetResponseScopesList = Array<string>;
export type OauthClientsGetResponseTokenEndpointAuthMethod = "none" | "client_secret_basic" | "client_secret_post";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOauthClientResponse {
    /** The unique identifier for an OAuth client. */
    clientId: string;
    /** Visibility of the OAuth client. */
    visibility: OauthClientsGetResponseVisibility;
    /** Array of allowed CORS origins. */
    allowedCorsOrigins?: OauthClientsGetResponseAllowedCorsOriginsList | null;
    /** Human-readable name of the OAuth client. */
    clientName?: string | null;
    /** URL of the home page of the client. */
    clientUri?: string | null;
    /** Client URI domain control verification state. */
    clientUriVerification?: OauthClientsGetResponseClientUriVerification | null;
    /** Timestamp when the OAuth client was created. */
    createdAt?: string | null;
    /** Array of OAuth grant types the client is allowed to use. `authorization_code` is required; `refresh_token` may be included optionally. */
    grantTypes?: OauthClientsGetResponseGrantTypesList | null;
    /** Indicates whether the client has a rotated secret that has not yet been deleted. */
    hasRotatedSecret?: boolean | null;
    /** URL of the client's logo. */
    logoUri?: string | null;
    /** Scopes that the authorizing user may decline during consent. Each value must also appear in `scopes`. The scopes `openid`, `offline`, and `offline_access` cannot be optional. */
    optionalScopes?: OauthClientsGetResponseOptionalScopesList | null;
    /** URL that points to a privacy policy document. */
    policyUri?: string | null;
    /** Array of allowed post-logout redirect URIs. */
    postLogoutRedirectUris?: OauthClientsGetResponsePostLogoutRedirectUrisList | null;
    /** Timestamp when the OAuth client was promoted to public visibility. */
    promotedAt?: string | null;
    /** Array of allowed redirect URIs for the client. */
    redirectUris?: OauthClientsGetResponseRedirectUrisList | null;
    /** Array of OAuth response types the client is allowed to use. */
    responseTypes?: OauthClientsGetResponseResponseTypesList | null;
    /** Array of OAuth scopes the client is allowed to request. Colon-delimited scopes are not accepted. Dot-delimited scopes are validated against available OAuth API scopes; simple identity scopes are allowed. Protocol scopes `offline_access` and `openid` are added or removed automatically based on `grant_types` and `response_types`. */
    scopes?: OauthClientsGetResponseScopesList | null;
    /** The authentication method the client uses at the token endpoint. */
    tokenEndpointAuthMethod?: OauthClientsGetResponseTokenEndpointAuthMethod | null;
    /** URL that points to a terms of service document. */
    tosUri?: string | null;
    /** Timestamp when the OAuth client was last updated. */
    updatedAt?: string | null;
}
export interface GetPermissionGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Permission Group identifier tag. */
    permissionGroupId: string;
}
export type PermissionGroupsGetResponseMeta = UserGroupsCreateResponsePoliciesItemPermissionGroupsItemMeta;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPermissionGroupResponse {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: UserGroupsCreateResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the permission group. */
    name?: string | null;
}
export interface GetResourceGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Resource Group identifier tag. */
    resourceGroupId: string;
}
export type ResourceGroupsGetResponseScopeObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export type ResourceGroupsGetResponseScopeObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export interface ResourceGroupsGetResponseScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: ResourceGroupsGetResponseScopeObjectsList;
}
export type ResourceGroupsGetResponseMeta = ResourceGroupsCreateResponseMeta;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResourceGroupResponse {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: ResourceGroupsGetResponseScope;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export interface GetSsoRequest {
    /** Account identifier tag. */
    accountId: string;
    /** SSO Connector identifier tag. */
    ssoConnectorId: string;
}
export type SsoGetResponseVerificationStatus = "awaiting" | "pending" | "failed" | "verified";
export interface SsoGetResponseVerification {
    /** DNS verification code. Add this entire string to the DNS TXT record of the email domain to validate ownership. */
    code?: string | null;
    /** The status of the verification code from the verification process. */
    status?: SsoGetResponseVerificationStatus | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSsoResponse {
    /** SSO Connector identifier tag. */
    id?: string | null;
    /** Timestamp for the creation of the SSO connector */
    createdOn?: string | null;
    emailDomain?: string | null;
    enabled?: boolean | null;
    /** Timestamp for the last update of the SSO connector */
    updatedOn?: string | null;
    /** Controls the display of FedRAMP language to the user during SSO login */
    useFedrampLanguage?: boolean | null;
    verification?: SsoGetResponseVerification | null;
}
export interface GetUserGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
}
export type UserGroupsGetResponsePoliciesItemAccess = "allow" | "deny";
export type UserGroupsGetResponsePoliciesItemPermissionGroupsItemMeta = UserGroupsCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type UserGroupsGetResponsePoliciesItemPermissionGroupsItem = UserGroupsCreateResponsePoliciesItemPermissionGroupsItem;
export type UserGroupsGetResponsePoliciesItemPermissionGroupsList = Array<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export type UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export type UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export interface UserGroupsGetResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export type UserGroupsGetResponsePoliciesItemResourceGroupsItemMeta = ResourceGroupsCreateResponseMeta;
export interface UserGroupsGetResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: UserGroupsGetResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export type UserGroupsGetResponsePoliciesItemResourceGroupsList = Array<UserGroupsGetResponsePoliciesItemResourceGroupsItem>;
export interface UserGroupsGetResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: UserGroupsGetResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: UserGroupsGetResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: UserGroupsGetResponsePoliciesItemResourceGroupsList | null;
}
export type UserGroupsGetResponsePoliciesList = Array<UserGroupsGetResponsePoliciesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUserGroupResponse {
    /** User Group identifier tag. */
    id: string;
    /** Timestamp for the creation of the user group */
    createdOn: string;
    /** Last time the user group was modified. */
    modifiedOn: string;
    /** Name of the user group. */
    name: string;
    /** Policies attached to the User group */
    policies?: UserGroupsGetResponsePoliciesList | null;
}
export interface GetUserGroupMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
    /** The identifier of an existing account Member. */
    memberId: string;
}
export type UserGroupsMembersGetResponseStatus = "accepted" | "pending";
export interface UserGroupsMembersGetResponseUser {
    /** User identifier tag. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** User's first name. */
    firstName?: string | null;
    /** User's last name. */
    lastName?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUserGroupMemberResponse {
    /** Account member identifier. */
    id: string;
    /** When the member was added to the user group. */
    createdAt?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** The member's status in the account. */
    status?: UserGroupsMembersGetResponseStatus | null;
    /** Details of the user associated with this membership. */
    user?: UserGroupsMembersGetResponseUser | null;
}
export interface ListOauthClientsRequest {
    /** Account identifier tag. */
    accountId: string;
}
export type OauthClientsListResultItemVisibility = "public" | "private";
export type OauthClientsListResultItemAllowedCorsOriginsList = Array<string>;
export type OauthClientsListResultItemClientUriVerificationStatus = "pending" | "in_progress" | "verified" | "failed";
export interface OauthClientsListResultItemClientUriVerification {
    /** Current verification status for the client URI host. */
    status?: OauthClientsListResultItemClientUriVerificationStatus | null;
    /** Exact TXT record value that must be added to DNS to prove ownership of the client URI host. */
    text?: string | null;
}
export type OauthClientsListResultItemGrantTypesItem = "authorization_code" | "refresh_token";
export type OauthClientsListResultItemGrantTypesList = Array<OauthClientsListResultItemGrantTypesItem>;
export type OauthClientsListResultItemOptionalScopesList = Array<string>;
export type OauthClientsListResultItemPostLogoutRedirectUrisList = Array<string>;
export type OauthClientsListResultItemRedirectUrisList = Array<string>;
export type OauthClientsListResultItemResponseTypesItem = "token" | "id_token" | "code";
export type OauthClientsListResultItemResponseTypesList = Array<OauthClientsListResultItemResponseTypesItem>;
export type OauthClientsListResultItemScopesList = Array<string>;
export type OauthClientsListResultItemTokenEndpointAuthMethod = "none" | "client_secret_basic" | "client_secret_post";
export interface OauthClientsListResultItem {
    /** The unique identifier for an OAuth client. */
    clientId: string;
    /** Visibility of the OAuth client. */
    visibility: OauthClientsListResultItemVisibility;
    /** Array of allowed CORS origins. */
    allowedCorsOrigins?: OauthClientsListResultItemAllowedCorsOriginsList | null;
    /** Human-readable name of the OAuth client. */
    clientName?: string | null;
    /** URL of the home page of the client. */
    clientUri?: string | null;
    /** Client URI domain control verification state. */
    clientUriVerification?: OauthClientsListResultItemClientUriVerification | null;
    /** Timestamp when the OAuth client was created. */
    createdAt?: string | null;
    /** Array of OAuth grant types the client is allowed to use. `authorization_code` is required; `refresh_token` may be included optionally. */
    grantTypes?: OauthClientsListResultItemGrantTypesList | null;
    /** Indicates whether the client has a rotated secret that has not yet been deleted. */
    hasRotatedSecret?: boolean | null;
    /** URL of the client's logo. */
    logoUri?: string | null;
    /** Scopes that the authorizing user may decline during consent. Each value must also appear in `scopes`. The scopes `openid`, `offline`, and `offline_access` cannot be optional. */
    optionalScopes?: OauthClientsListResultItemOptionalScopesList | null;
    /** URL that points to a privacy policy document. */
    policyUri?: string | null;
    /** Array of allowed post-logout redirect URIs. */
    postLogoutRedirectUris?: OauthClientsListResultItemPostLogoutRedirectUrisList | null;
    /** Timestamp when the OAuth client was promoted to public visibility. */
    promotedAt?: string | null;
    /** Array of allowed redirect URIs for the client. */
    redirectUris?: OauthClientsListResultItemRedirectUrisList | null;
    /** Array of OAuth response types the client is allowed to use. */
    responseTypes?: OauthClientsListResultItemResponseTypesList | null;
    /** Array of OAuth scopes the client is allowed to request. Colon-delimited scopes are not accepted. Dot-delimited scopes are validated against available OAuth API scopes; simple identity scopes are allowed. Protocol scopes `offline_access` and `openid` are added or removed automatically based on `grant_types` and `response_types`. */
    scopes?: OauthClientsListResultItemScopesList | null;
    /** The authentication method the client uses at the token endpoint. */
    tokenEndpointAuthMethod?: OauthClientsListResultItemTokenEndpointAuthMethod | null;
    /** URL that points to a terms of service document. */
    tosUri?: string | null;
    /** Timestamp when the OAuth client was last updated. */
    updatedAt?: string | null;
}
export type OauthClientsListResultList = Array<OauthClientsListResultItem>;
export interface ListOauthClientsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OauthClientsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListOauthScopesRequest {
}
export type OauthScopesListResultItemScopesList = Array<string>;
export interface OauthScopesListResultItem {
    /** The scope label to use in the scopes array when creating or updating an OAuth client. */
    id: string;
    /** Human-readable name of the OAuth scope. */
    name: string;
    /** Category for grouping scopes in the UI. */
    category?: string | null;
    /** The underlying resource scopes (Bach scopes) that define which resources this OAuth scope can act upon. */
    scopes?: OauthScopesListResultItemScopesList | null;
}
export type OauthScopesListResultList = Array<OauthScopesListResultItem>;
export interface ListOauthScopesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OauthScopesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListPermissionGroupsRequest {
    /** Account identifier tag. */
    accountId: string;
    /** ID of the permission group to be fetched. */
    id?: string;
    /** Label of the permission group to be fetched. */
    label?: string;
    /** Name of the permission group to be fetched. */
    name?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type PermissionGroupsListResultItemMeta = UserGroupsCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type PermissionGroupsListResultItem = UserGroupsCreateResponsePoliciesItemPermissionGroupsItem;
export type PermissionGroupsListResultList = Array<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export interface ListPermissionGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PermissionGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListResourceGroupsRequest {
    /** Account identifier tag. */
    accountId: string;
    /** ID of the resource group to be fetched. */
    id?: string;
    /** Name of the resource group to be fetched. */
    name?: string;
}
export type ResourceGroupsListResultItemScopeObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export type ResourceGroupsListResultItemScopeObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export interface ResourceGroupsListResultItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: ResourceGroupsListResultItemScopeObjectsList;
}
export type ResourceGroupsListResultItemMeta = ResourceGroupsCreateResponseMeta;
export interface ResourceGroupsListResultItem {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: ResourceGroupsListResultItemScope;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export type ResourceGroupsListResultList = Array<ResourceGroupsListResultItem>;
export interface ListResourceGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ResourceGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListSsosRequest {
    /** Account identifier tag. */
    accountId: string;
}
export type SsoListResultItemVerificationStatus = "awaiting" | "pending" | "failed" | "verified";
export interface SsoListResultItemVerification {
    /** DNS verification code. Add this entire string to the DNS TXT record of the email domain to validate ownership. */
    code?: string | null;
    /** The status of the verification code from the verification process. */
    status?: SsoListResultItemVerificationStatus | null;
}
export interface SsoListResultItem {
    /** SSO Connector identifier tag. */
    id?: string | null;
    /** Timestamp for the creation of the SSO connector */
    createdOn?: string | null;
    emailDomain?: string | null;
    enabled?: boolean | null;
    /** Timestamp for the last update of the SSO connector */
    updatedOn?: string | null;
    /** Controls the display of FedRAMP language to the user during SSO login */
    useFedrampLanguage?: boolean | null;
    verification?: SsoListResultItemVerification | null;
}
export type SsoListResultList = Array<SsoListResultItem>;
export interface ListSsosResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SsoListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type UserGroupsMembersListRequestDirection = "asc" | "desc";
export interface ListUserGroupMembersRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
    /** The sort order of returned user group members by email. */
    direction?: UserGroupsMembersListRequestDirection | (string & {});
    /** A string used for filtering members by partial email match. */
    fuzzyEmail?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type UserGroupsMembersListResultItemStatus = "accepted" | "pending";
export interface UserGroupsMembersListResultItem {
    /** Account member identifier. */
    id: string;
    /** The contact email address of the user. */
    email?: string | null;
    /** The member's status in the account. */
    status?: UserGroupsMembersListResultItemStatus | null;
}
export type UserGroupsMembersListResultList = Array<UserGroupsMembersListResultItem>;
export interface ListUserGroupMembersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserGroupsMembersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type UserGroupsListRequestDirection = "asc" | "desc";
export interface ListUserGroupsRequest {
    /** Account identifier tag. */
    accountId: string;
    /** ID of the user group to be fetched. */
    id?: string;
    /** The sort order of returned user groups by name (ascending or descending). */
    direction?: UserGroupsListRequestDirection | (string & {});
    /** A string used for searching for user groups containing that substring. */
    fuzzyName?: string;
    /** Name of the user group to be fetched. */
    name?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type UserGroupsListResultItemPoliciesItemAccess = "allow" | "deny";
export type UserGroupsListResultItemPoliciesItemPermissionGroupsItemMeta = UserGroupsCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type UserGroupsListResultItemPoliciesItemPermissionGroupsItem = UserGroupsCreateResponsePoliciesItemPermissionGroupsItem;
export type UserGroupsListResultItemPoliciesItemPermissionGroupsList = Array<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export type UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export type UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export interface UserGroupsListResultItemPoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeObjectsList;
}
export type UserGroupsListResultItemPoliciesItemResourceGroupsItemMeta = ResourceGroupsCreateResponseMeta;
export interface UserGroupsListResultItemPoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: UserGroupsListResultItemPoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export type UserGroupsListResultItemPoliciesItemResourceGroupsList = Array<UserGroupsListResultItemPoliciesItemResourceGroupsItem>;
export interface UserGroupsListResultItemPoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: UserGroupsListResultItemPoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: UserGroupsListResultItemPoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: UserGroupsListResultItemPoliciesItemResourceGroupsList | null;
}
export type UserGroupsListResultItemPoliciesList = Array<UserGroupsListResultItemPoliciesItem>;
export interface UserGroupsListResultItem {
    /** User Group identifier tag. */
    id: string;
    /** Timestamp for the creation of the user group */
    createdOn: string;
    /** Last time the user group was modified. */
    modifiedOn: string;
    /** Name of the user group. */
    name: string;
    /** Policies attached to the User group */
    policies?: UserGroupsListResultItemPoliciesList | null;
}
export type UserGroupsListResultList = Array<UserGroupsListResultItem>;
export interface ListUserGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type OauthClientsUpdateRequestAllowedCorsOriginsList = Array<string>;
export type OauthClientsUpdateRequestGrantTypesItem = "authorization_code" | "refresh_token";
export type OauthClientsUpdateRequestGrantTypesList = Array<OauthClientsUpdateRequestGrantTypesItem | (string & {})>;
export type OauthClientsUpdateRequestOptionalScopesList = Array<string>;
export type OauthClientsUpdateRequestPostLogoutRedirectUrisList = Array<string>;
export type OauthClientsUpdateRequestRedirectUrisList = Array<string>;
export type OauthClientsUpdateRequestResponseTypesItem = "token" | "id_token" | "code";
export type OauthClientsUpdateRequestResponseTypesList = Array<OauthClientsUpdateRequestResponseTypesItem | (string & {})>;
export type OauthClientsUpdateRequestScopesList = Array<string>;
export type OauthClientsUpdateRequestTokenEndpointAuthMethod = "none" | "client_secret_basic" | "client_secret_post";
export type OauthClientsUpdateRequestVisibility = "public";
export interface PatchOauthClientRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The unique identifier for an OAuth client. */
    oauthClientId: string;
    /** Array of allowed CORS origins. */
    allowedCorsOrigins?: OauthClientsUpdateRequestAllowedCorsOriginsList;
    /** Human-readable name of the OAuth client. */
    clientName?: string;
    /** URL of the home page of the client. */
    clientUri?: string;
    /** Array of OAuth grant types the client is allowed to use. `authorization_code` is required; `refresh_token` may be included optionally. */
    grantTypes?: OauthClientsUpdateRequestGrantTypesList;
    /** URL of the client's logo. */
    logoUri?: string;
    /** Scopes that the authorizing user may decline during consent. Each value must also appear in `scopes`. The scopes `openid`, `offline`, and `offline_access` cannot be optional. */
    optionalScopes?: OauthClientsUpdateRequestOptionalScopesList;
    /** URL that points to a privacy policy document. */
    policyUri?: string;
    /** Array of allowed post-logout redirect URIs. */
    postLogoutRedirectUris?: OauthClientsUpdateRequestPostLogoutRedirectUrisList;
    /** Array of allowed redirect URIs for the client. */
    redirectUris?: OauthClientsUpdateRequestRedirectUrisList;
    /** Array of OAuth response types the client is allowed to use. */
    responseTypes?: OauthClientsUpdateRequestResponseTypesList;
    /** Array of OAuth scopes the client is allowed to request. Colon-delimited scopes are not accepted. Dot-delimited scopes are validated against available OAuth API scopes; simple identity scopes are allowed. Protocol scopes `offline_access` and `openid` are added or removed automatically based on `grant_types` and `response_types`. */
    scopes?: OauthClientsUpdateRequestScopesList;
    /** The authentication method the client uses at the token endpoint. */
    tokenEndpointAuthMethod?: OauthClientsUpdateRequestTokenEndpointAuthMethod | (string & {});
    /** URL that points to a terms of service document. */
    tosUri?: string;
    /** Promote the OAuth client from private to public visibility. Only `public` is accepted; demotion to `private` is not supported. Promotion requires a non-empty client name, logo URI, verified client URI host, and at least one non-identity scope. */
    visibility?: OauthClientsUpdateRequestVisibility | (string & {});
}
export type OauthClientsUpdateResponseVisibility = "public" | "private";
export type OauthClientsUpdateResponseAllowedCorsOriginsList = Array<string>;
export type OauthClientsUpdateResponseClientUriVerificationStatus = "pending" | "in_progress" | "verified" | "failed";
export interface OauthClientsUpdateResponseClientUriVerification {
    /** Current verification status for the client URI host. */
    status?: OauthClientsUpdateResponseClientUriVerificationStatus | null;
    /** Exact TXT record value that must be added to DNS to prove ownership of the client URI host. */
    text?: string | null;
}
export type OauthClientsUpdateResponseGrantTypesItem = "authorization_code" | "refresh_token";
export type OauthClientsUpdateResponseGrantTypesList = Array<OauthClientsUpdateResponseGrantTypesItem>;
export type OauthClientsUpdateResponseOptionalScopesList = Array<string>;
export type OauthClientsUpdateResponsePostLogoutRedirectUrisList = Array<string>;
export type OauthClientsUpdateResponseRedirectUrisList = Array<string>;
export type OauthClientsUpdateResponseResponseTypesItem = "token" | "id_token" | "code";
export type OauthClientsUpdateResponseResponseTypesList = Array<OauthClientsUpdateResponseResponseTypesItem>;
export type OauthClientsUpdateResponseScopesList = Array<string>;
export type OauthClientsUpdateResponseTokenEndpointAuthMethod = "none" | "client_secret_basic" | "client_secret_post";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchOauthClientResponse {
    /** The unique identifier for an OAuth client. */
    clientId: string;
    /** Visibility of the OAuth client. */
    visibility: OauthClientsUpdateResponseVisibility;
    /** Array of allowed CORS origins. */
    allowedCorsOrigins?: OauthClientsUpdateResponseAllowedCorsOriginsList | null;
    /** Human-readable name of the OAuth client. */
    clientName?: string | null;
    /** URL of the home page of the client. */
    clientUri?: string | null;
    /** Client URI domain control verification state. */
    clientUriVerification?: OauthClientsUpdateResponseClientUriVerification | null;
    /** Timestamp when the OAuth client was created. */
    createdAt?: string | null;
    /** Array of OAuth grant types the client is allowed to use. `authorization_code` is required; `refresh_token` may be included optionally. */
    grantTypes?: OauthClientsUpdateResponseGrantTypesList | null;
    /** Indicates whether the client has a rotated secret that has not yet been deleted. */
    hasRotatedSecret?: boolean | null;
    /** URL of the client's logo. */
    logoUri?: string | null;
    /** Scopes that the authorizing user may decline during consent. Each value must also appear in `scopes`. The scopes `openid`, `offline`, and `offline_access` cannot be optional. */
    optionalScopes?: OauthClientsUpdateResponseOptionalScopesList | null;
    /** URL that points to a privacy policy document. */
    policyUri?: string | null;
    /** Array of allowed post-logout redirect URIs. */
    postLogoutRedirectUris?: OauthClientsUpdateResponsePostLogoutRedirectUrisList | null;
    /** Timestamp when the OAuth client was promoted to public visibility. */
    promotedAt?: string | null;
    /** Array of allowed redirect URIs for the client. */
    redirectUris?: OauthClientsUpdateResponseRedirectUrisList | null;
    /** Array of OAuth response types the client is allowed to use. */
    responseTypes?: OauthClientsUpdateResponseResponseTypesList | null;
    /** Array of OAuth scopes the client is allowed to request. Colon-delimited scopes are not accepted. Dot-delimited scopes are validated against available OAuth API scopes; simple identity scopes are allowed. Protocol scopes `offline_access` and `openid` are added or removed automatically based on `grant_types` and `response_types`. */
    scopes?: OauthClientsUpdateResponseScopesList | null;
    /** The authentication method the client uses at the token endpoint. */
    tokenEndpointAuthMethod?: OauthClientsUpdateResponseTokenEndpointAuthMethod | null;
    /** URL that points to a terms of service document. */
    tosUri?: string | null;
    /** Timestamp when the OAuth client was last updated. */
    updatedAt?: string | null;
}
export interface PatchSsoRequest {
    /** Account identifier tag. */
    accountId: string;
    /** SSO Connector identifier tag. */
    ssoConnectorId: string;
    /** SSO Connector enabled state */
    enabled?: boolean;
    /** Controls the display of FedRAMP language to the user during SSO login */
    useFedrampLanguage?: boolean;
}
export type SsoUpdateResponseVerificationStatus = "awaiting" | "pending" | "failed" | "verified";
export interface SsoUpdateResponseVerification {
    /** DNS verification code. Add this entire string to the DNS TXT record of the email domain to validate ownership. */
    code?: string | null;
    /** The status of the verification code from the verification process. */
    status?: SsoUpdateResponseVerificationStatus | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSsoResponse {
    /** SSO Connector identifier tag. */
    id?: string | null;
    /** Timestamp for the creation of the SSO connector */
    createdOn?: string | null;
    emailDomain?: string | null;
    enabled?: boolean | null;
    /** Timestamp for the last update of the SSO connector */
    updatedOn?: string | null;
    /** Controls the display of FedRAMP language to the user during SSO login */
    useFedrampLanguage?: boolean | null;
    verification?: SsoUpdateResponseVerification | null;
}
export interface RotateSecretOauthClientRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The unique identifier for an OAuth client. */
    oauthClientId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RotateSecretOauthClientResponse {
    /** The new client secret. */
    clientSecret?: string | null;
}
export type ResourceGroupsUpdateRequestScopeObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export type ResourceGroupsUpdateRequestScopeObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export interface ResourceGroupsUpdateRequestScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. The number of Scope objects should not be zero. */
    objects: ResourceGroupsUpdateRequestScopeObjectsList;
}
export interface UpdateResourceGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Resource Group identifier tag. */
    resourceGroupId: string;
    /** Name of the resource group */
    name?: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope?: ResourceGroupsUpdateRequestScope;
}
export type ResourceGroupsUpdateResponseScopeObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export type ResourceGroupsUpdateResponseScopeObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export interface ResourceGroupsUpdateResponseScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: ResourceGroupsUpdateResponseScopeObjectsList;
}
export type ResourceGroupsUpdateResponseMeta = ResourceGroupsCreateResponseMeta;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResourceGroupResponse {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: ResourceGroupsUpdateResponseScope;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export type UserGroupsUpdateRequestPoliciesItemAccess = "allow" | "deny";
export type UserGroupsUpdateRequestPoliciesItemPermissionGroupsItem = UserGroupsCreateRequestPoliciesItemPermissionGroupsItem;
export type UserGroupsUpdateRequestPoliciesItemPermissionGroupsList = Array<UserGroupsCreateRequestPoliciesItemPermissionGroupsItem>;
export type UserGroupsUpdateRequestPoliciesItemResourceGroupsItem = UserGroupsCreateRequestPoliciesItemResourceGroupsItem;
export type UserGroupsUpdateRequestPoliciesItemResourceGroupsList = Array<UserGroupsCreateRequestPoliciesItemResourceGroupsItem>;
export interface UserGroupsUpdateRequestPoliciesItem {
    /** Policy identifier. */
    id?: string;
    /** Allow or deny operations against the resources. */
    access: UserGroupsUpdateRequestPoliciesItemAccess | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: UserGroupsUpdateRequestPoliciesItemPermissionGroupsList;
    /** A set of resource groups that are specified to the policy. */
    resourceGroups: UserGroupsUpdateRequestPoliciesItemResourceGroupsList;
}
export type UserGroupsUpdateRequestPoliciesList = Array<UserGroupsUpdateRequestPoliciesItem>;
export interface UpdateUserGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
    /** Name of the User group. */
    name?: string;
    /** Policies attached to the User group */
    policies?: UserGroupsUpdateRequestPoliciesList;
}
export type UserGroupsUpdateResponsePoliciesItemAccess = "allow" | "deny";
export type UserGroupsUpdateResponsePoliciesItemPermissionGroupsItemMeta = UserGroupsCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type UserGroupsUpdateResponsePoliciesItemPermissionGroupsItem = UserGroupsCreateResponsePoliciesItemPermissionGroupsItem;
export type UserGroupsUpdateResponsePoliciesItemPermissionGroupsList = Array<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export type UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export type UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export interface UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export type UserGroupsUpdateResponsePoliciesItemResourceGroupsItemMeta = ResourceGroupsCreateResponseMeta;
export interface UserGroupsUpdateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export type UserGroupsUpdateResponsePoliciesItemResourceGroupsList = Array<UserGroupsUpdateResponsePoliciesItemResourceGroupsItem>;
export interface UserGroupsUpdateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: UserGroupsUpdateResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: UserGroupsUpdateResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: UserGroupsUpdateResponsePoliciesItemResourceGroupsList | null;
}
export type UserGroupsUpdateResponsePoliciesList = Array<UserGroupsUpdateResponsePoliciesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateUserGroupResponse {
    /** User Group identifier tag. */
    id: string;
    /** Timestamp for the creation of the user group */
    createdOn: string;
    /** Last time the user group was modified. */
    modifiedOn: string;
    /** Name of the user group. */
    name: string;
    /** Policies attached to the User group */
    policies?: UserGroupsUpdateResponsePoliciesList | null;
}
export type UserGroupsMembersUpdateRequestMembersItem = UserGroupsMembersCreateRequestMembersItem;
export type UserGroupsMembersUpdateRequestMembersList = Array<UserGroupsMembersCreateRequestMembersItem>;
export interface UpdateUserGroupMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
    /** Set/Replace members to a user group. */
    members: UserGroupsMembersUpdateRequestMembersList;
}
export type UserGroupsMembersUpdateResultItemStatus = "accepted" | "pending";
export interface UserGroupsMembersUpdateResultItem {
    /** Account member identifier. */
    id: string;
    /** The contact email address of the user. */
    email?: string | null;
    /** The member's status in the account. */
    status?: UserGroupsMembersUpdateResultItemStatus | null;
}
export type UserGroupsMembersUpdateResultList = Array<UserGroupsMembersUpdateResultItem>;
export interface UpdateUserGroupMemberResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserGroupsMembersUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type BeginVerificationSsoError = CloudflareOpError;
/** Validates the user has added the DNS TXT record required for validating ownership of the domain they are trying to set up a connector for. */
export declare const beginVerificationSso: API.OperationMethod<BeginVerificationSsoRequest, BeginVerificationSsoResponse, BeginVerificationSsoError, CloudflareOpContext>;
export type CreateOauthClientError = CloudflareOpError;
/** Create a new OAuth client for an account. */
export declare const createOauthClient: API.OperationMethod<CreateOauthClientRequest, CreateOauthClientResponse, CreateOauthClientError, CloudflareOpContext>;
export type CreateResourceGroupError = CloudflareOpError;
/** Create a new Resource Group under the specified account. */
export declare const createResourceGroup: API.OperationMethod<CreateResourceGroupRequest, CreateResourceGroupResponse, CreateResourceGroupError, CloudflareOpContext>;
export type CreateSsoError = CloudflareOpError;
/** Creates a new SSO connector for logging into Cloudflare through an identity provider. */
export declare const createSso: API.OperationMethod<CreateSsoRequest, CreateSsoResponse, CreateSsoError, CloudflareOpContext>;
export type CreateUserGroupError = UserGroupNameInUse | CloudflareOpError;
/** Create a new user group under the specified account. */
export declare const createUserGroup: API.OperationMethod<CreateUserGroupRequest, CreateUserGroupResponse, CreateUserGroupError, CloudflareOpContext>;
export type CreateUserGroupMemberError = InvalidMember | UserGroupNotFound | CloudflareOpError;
/** Add members to a User Group. */
export declare const createUserGroupMember: API.PaginatedOperationMethod<CreateUserGroupMemberRequest, CreateUserGroupMemberResponse, CreateUserGroupMemberError, CloudflareOpContext, UserGroupsMembersCreateResultItem>;
export type DeleteOauthClientError = CloudflareOpError;
/** Delete an OAuth client. */
export declare const deleteOauthClient: API.OperationMethod<DeleteOauthClientRequest, DeleteOauthClientResponse, DeleteOauthClientError, CloudflareOpContext>;
export type DeleteResourceGroupError = ResourceGroupNotFound | CloudflareOpError;
/** Remove a resource group from an account. */
export declare const deleteResourceGroup: API.OperationMethod<DeleteResourceGroupRequest, DeleteResourceGroupResponse, DeleteResourceGroupError, CloudflareOpContext>;
export type DeleteRotatedSecretOauthClientError = CloudflareOpError;
/** Removes the old client secret after a rotation, keeping only the new one. Use this after you have updated your client configuration to use the new secret. The `has_rotated_secret` field on the client indicates whether there is an old secret to delete. */
export declare const deleteRotatedSecretOauthClient: API.OperationMethod<DeleteRotatedSecretOauthClientRequest, DeleteRotatedSecretOauthClientResponse, DeleteRotatedSecretOauthClientError, CloudflareOpContext>;
export type DeleteSsoError = CloudflareOpError;
/** Deletes an SSO connector from the account. */
export declare const deleteSso: API.OperationMethod<DeleteSsoRequest, DeleteSsoResponse, DeleteSsoError, CloudflareOpContext>;
export type DeleteUserGroupError = UserGroupNotFound | CloudflareOpError;
/** Remove a user group from an account. */
export declare const deleteUserGroup: API.OperationMethod<DeleteUserGroupRequest, DeleteUserGroupResponse, DeleteUserGroupError, CloudflareOpContext>;
export type DeleteUserGroupMemberError = InvalidMember | UserGroupMemberNotFound | UserGroupNotFound | CloudflareOpError;
/** Remove a member from User Group */
export declare const deleteUserGroupMember: API.OperationMethod<DeleteUserGroupMemberRequest, DeleteUserGroupMemberResponse, DeleteUserGroupMemberError, CloudflareOpContext>;
export type GetOauthClientError = CloudflareOpError;
/** Get details of a specific OAuth client. */
export declare const getOauthClient: API.OperationMethod<GetOauthClientRequest, GetOauthClientResponse, GetOauthClientError, CloudflareOpContext>;
export type GetPermissionGroupError = CloudflareOpError;
/** Get information about a specific permission group in an account. */
export declare const getPermissionGroup: API.OperationMethod<GetPermissionGroupRequest, GetPermissionGroupResponse, GetPermissionGroupError, CloudflareOpContext>;
export type GetResourceGroupError = ResourceGroupNotFound | Forbidden | CloudflareOpError;
/** Get information about a specific resource group in an account. */
export declare const getResourceGroup: API.OperationMethod<GetResourceGroupRequest, GetResourceGroupResponse, GetResourceGroupError, CloudflareOpContext>;
export type GetSsoError = CloudflareOpError;
/** Retrieves details for a specific SSO connector. */
export declare const getSso: API.OperationMethod<GetSsoRequest, GetSsoResponse, GetSsoError, CloudflareOpContext>;
export type GetUserGroupError = UserGroupNotFound | Forbidden | CloudflareOpError;
/** Get information about a specific user group in an account. */
export declare const getUserGroup: API.OperationMethod<GetUserGroupRequest, GetUserGroupResponse, GetUserGroupError, CloudflareOpContext>;
export type GetUserGroupMemberError = UserGroupMemberNotFound | UserGroupNotFound | Forbidden | CloudflareOpError;
/** Get details of a specific member in a user group. */
export declare const getUserGroupMember: API.OperationMethod<GetUserGroupMemberRequest, GetUserGroupMemberResponse, GetUserGroupMemberError, CloudflareOpContext>;
export type ListOauthClientsError = CloudflareOpError;
/** List all OAuth clients for an account. */
export declare const listOauthClients: API.PaginatedOperationMethod<ListOauthClientsRequest, ListOauthClientsResponse, ListOauthClientsError, CloudflareOpContext, OauthClientsListResultItem>;
export type ListOauthScopesError = CloudflareOpError;
/** List all available OAuth scopes. This endpoint requires authentication but has no authorization role requirements. */
export declare const listOauthScopes: API.PaginatedOperationMethod<ListOauthScopesRequest, ListOauthScopesResponse, ListOauthScopesError, CloudflareOpContext, OauthScopesListResultItem>;
export type ListPermissionGroupsError = CloudflareOpError;
/** List all the permissions groups for an account. */
export declare const listPermissionGroups: API.PaginatedOperationMethod<ListPermissionGroupsRequest, ListPermissionGroupsResponse, ListPermissionGroupsError, CloudflareOpContext, UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export type ListResourceGroupsError = CloudflareOpError;
/** List all the resource groups for an account. */
export declare const listResourceGroups: API.PaginatedOperationMethod<ListResourceGroupsRequest, ListResourceGroupsResponse, ListResourceGroupsError, CloudflareOpContext, ResourceGroupsListResultItem>;
export type ListSsosError = CloudflareOpError;
/** Lists all SSO connectors configured for the account. */
export declare const listSsos: API.PaginatedOperationMethod<ListSsosRequest, ListSsosResponse, ListSsosError, CloudflareOpContext, SsoListResultItem>;
export type ListUserGroupMembersError = UserGroupNotFound | PolicyValidationFailed | CloudflareOpError;
/** List all the members attached to a user group. */
export declare const listUserGroupMembers: API.PaginatedOperationMethod<ListUserGroupMembersRequest, ListUserGroupMembersResponse, ListUserGroupMembersError, CloudflareOpContext, UserGroupsMembersListResultItem>;
export type ListUserGroupsError = CloudflareOpError;
/** List all the user groups for an account. */
export declare const listUserGroups: API.PaginatedOperationMethod<ListUserGroupsRequest, ListUserGroupsResponse, ListUserGroupsError, CloudflareOpContext, UserGroupsListResultItem>;
export type PatchOauthClientError = CloudflareOpError;
/** Update an existing OAuth client. Only include fields you want to update. */
export declare const patchOauthClient: API.OperationMethod<PatchOauthClientRequest, PatchOauthClientResponse, PatchOauthClientError, CloudflareOpContext>;
export type PatchSsoError = CloudflareOpError;
/** Updates the state or configuration of an SSO connector. */
export declare const patchSso: API.OperationMethod<PatchSsoRequest, PatchSsoResponse, PatchSsoError, CloudflareOpContext>;
export type RotateSecretOauthClientError = CloudflareOpError;
/** Creates a second client secret so you can update your client configuration before deleting the old one. The `has_rotated_secret` field on the client will be set to `true`. */
export declare const rotateSecretOauthClient: API.OperationMethod<RotateSecretOauthClientRequest, RotateSecretOauthClientResponse, RotateSecretOauthClientError, CloudflareOpContext>;
export type UpdateResourceGroupError = ResourceGroupNotFound | CloudflareOpError;
/** Modify an existing resource group. */
export declare const updateResourceGroup: API.OperationMethod<UpdateResourceGroupRequest, UpdateResourceGroupResponse, UpdateResourceGroupError, CloudflareOpContext>;
export type UpdateUserGroupError = UserGroupNotFound | UserGroupNameInUse | CloudflareOpError;
/** Modify an existing user group. */
export declare const updateUserGroup: API.OperationMethod<UpdateUserGroupRequest, UpdateUserGroupResponse, UpdateUserGroupError, CloudflareOpContext>;
export type UpdateUserGroupMemberError = InvalidMember | UserGroupNotFound | CloudflareOpError;
/** Replace the set of members attached to a User Group. */
export declare const updateUserGroupMember: API.PaginatedOperationMethod<UpdateUserGroupMemberRequest, UpdateUserGroupMemberResponse, UpdateUserGroupMemberError, CloudflareOpContext, UserGroupsMembersUpdateResultItem>;
//# sourceMappingURL=iam.d.ts.map