import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const ListAlreadyExists_base: S.TaggedErrorClass<"ListAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ListAlreadyExists extends /*@__PURE__*/ ListAlreadyExists_base {
}
declare const ListNotFound_base: S.TaggedErrorClass<"ListNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ListNotFound extends /*@__PURE__*/ ListNotFound_base {
}
export type ListsCreateRequestKind = "ip" | "redirect" | "hostname" | "asn";
export interface CreateListRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The type of the list. Each type supports specific list items (IP addresses, ASNs, hostnames or redirects). */
    kind: ListsCreateRequestKind | (string & {});
    /** An informative name for the list. Use this name in filter and rule expressions. */
    name: string;
    /** An informative summary of the list. */
    description?: string;
}
export type ListsCreateResponseKind = "ip" | "redirect" | "hostname" | "asn";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateListResponse {
    /** The unique ID of the list. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The type of the list. Each type supports specific list items (IP addresses, ASNs, hostnames or redirects). */
    kind: ListsCreateResponseKind;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** An informative name for the list. Use this name in filter and rule expressions. */
    name: string;
    /** The number of items in the list. */
    numItems: number;
    /** The number of [filters](https://developers.cloudflare.com/api/resources/filters/) referencing the list. */
    numReferencingFilters: number;
    /** An informative summary of the list. */
    description?: string | null;
}
export interface ListsItemsCreateRequestBodyItemListsListItemIPComment {
    /** An IPv4 address, an IPv4 CIDR, an IPv6 address, or an IPv6 CIDR. */
    ip: string;
    /** Defines an informative summary of the list item. */
    comment?: string;
}
export type ListsItemsCreateRequestBodyItemListsListItemRedirectCommentRedirectStatusCode = 301 | 302 | 307 | 308;
export interface ListsItemsCreateRequestBodyItemListsListItemRedirectCommentRedirect {
    sourceUrl: string;
    targetUrl: string;
    includeSubdomains?: boolean;
    preservePathSuffix?: boolean;
    preserveQueryString?: boolean;
    statusCode?: ListsItemsCreateRequestBodyItemListsListItemRedirectCommentRedirectStatusCode | (number & {});
    subpathMatching?: boolean;
}
export interface ListsItemsCreateRequestBodyItemListsListItemRedirectComment {
    /** The definition of the redirect. */
    redirect: ListsItemsCreateRequestBodyItemListsListItemRedirectCommentRedirect;
    /** Defines an informative summary of the list item. */
    comment?: string;
}
export interface ListsItemsCreateRequestBodyItemListsListItemHostnameCommentHostname {
    urlHostname: string;
    /** Only applies to wildcard hostnames (e.g., *.example.com). When true (default), the rule blocks only subdomains. When false, the rule blocks both the root domain and subdomains. */
    excludeExactHostname?: boolean;
}
export interface ListsItemsCreateRequestBodyItemListsListItemHostnameComment {
    /** Hostnames support ASCII(7) letters from a to z, the digits from 0 to 9, wildcards (*), and the hyphen (-). */
    hostname: ListsItemsCreateRequestBodyItemListsListItemHostnameCommentHostname;
    /** Defines an informative summary of the list item. */
    comment?: string;
}
export interface ListsItemsCreateRequestBodyItemListsListItemASNComment {
    /** Defines a non-negative 32 bit integer. */
    asn: number;
    /** Defines an informative summary of the list item. */
    comment?: string;
}
export type ListsItemsCreateRequestBodyItem = ListsItemsCreateRequestBodyItemListsListItemIPComment | ListsItemsCreateRequestBodyItemListsListItemRedirectComment | ListsItemsCreateRequestBodyItemListsListItemHostnameComment | ListsItemsCreateRequestBodyItemListsListItemASNComment;
export type ListsItemsCreateRequestBodyList = Array<ListsItemsCreateRequestBodyItem>;
export interface CreateListItemRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
    body: ListsItemsCreateRequestBodyList;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateListItemResponse {
    /** The unique operation ID of the asynchronous action. */
    operationId: string;
}
export interface DeleteListRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteListResponse {
    /** The unique ID of the list. */
    id: string;
}
export interface ListsItemsDeleteRequestItemsItem {
    /** Defines the unique ID of the item in the List. */
    id: string;
}
export type ListsItemsDeleteRequestItemsList = Array<ListsItemsDeleteRequestItemsItem>;
export interface DeleteListItemRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
    /** The list items to delete, identified by their unique IDs. */
    items?: ListsItemsDeleteRequestItemsList;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteListItemResponse {
    /** The unique operation ID of the asynchronous action. */
    operationId: string;
}
export interface GetListRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
}
export type ListsGetResponseKind = "ip" | "redirect" | "hostname" | "asn";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetListResponse {
    /** The unique ID of the list. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The type of the list. Each type supports specific list items (IP addresses, ASNs, hostnames or redirects). */
    kind: ListsGetResponseKind;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** An informative name for the list. Use this name in filter and rule expressions. */
    name: string;
    /** The number of items in the list. */
    numItems: number;
    /** The number of [filters](https://developers.cloudflare.com/api/resources/filters/) referencing the list. */
    numReferencingFilters: number;
    /** An informative summary of the list. */
    description?: string | null;
}
export interface GetListBulkOperationRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique operation ID of the asynchronous action. */
    operationId: string;
}
export type ListsBulkOperationsGetResultListsBulkOperationPendingOrRunningStatus = "pending" | "running";
export interface ListsBulkOperationsGetResultListsBulkOperationPendingOrRunning {
    /** The unique operation ID of the asynchronous action. */
    id: string;
    /** The current status of the asynchronous operation. */
    status: ListsBulkOperationsGetResultListsBulkOperationPendingOrRunningStatus;
}
export type ListsBulkOperationsGetResultListsBulkOperationCompletedStatus = "completed";
export interface ListsBulkOperationsGetResultListsBulkOperationCompleted {
    /** The unique operation ID of the asynchronous action. */
    id: string;
    /** The RFC 3339 timestamp of when the operation was completed. */
    completed: string;
    /** The current status of the asynchronous operation. */
    status: ListsBulkOperationsGetResultListsBulkOperationCompletedStatus;
}
export type ListsBulkOperationsGetResultListsBulkOperationFailedStatus = "failed";
export interface ListsBulkOperationsGetResultListsBulkOperationFailed {
    /** The unique operation ID of the asynchronous action. */
    id: string;
    /** The RFC 3339 timestamp of when the operation was completed. */
    completed: string;
    /** A message describing the error when the status is `failed`. */
    error: string;
    /** The current status of the asynchronous operation. */
    status: ListsBulkOperationsGetResultListsBulkOperationFailedStatus;
}
export type ListsBulkOperationsGetResult = ListsBulkOperationsGetResultListsBulkOperationPendingOrRunning | ListsBulkOperationsGetResultListsBulkOperationCompleted | ListsBulkOperationsGetResultListsBulkOperationFailed;
export type GetListBulkOperationResponse = ListsBulkOperationsGetResult;
export interface GetListItemRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
    /** Defines the unique ID of the item in the List. */
    itemId: string;
}
export interface ListsItemsGetResultListsListItemIPFull {
    /** Defines the unique ID of the item in the List. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** An IPv4 address, an IPv4 CIDR, an IPv6 address, or an IPv6 CIDR. */
    ip: string;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** Defines an informative summary of the list item. */
    comment?: string | null;
}
export interface ListsItemsGetResultListsListItemHostnameFullHostname {
    urlHostname: string;
    /** Only applies to wildcard hostnames (e.g., *.example.com). When true (default), the rule blocks only subdomains. When false, the rule blocks both the root domain and subdomains. */
    excludeExactHostname?: boolean | null;
}
export interface ListsItemsGetResultListsListItemHostnameFull {
    /** Defines the unique ID of the item in the List. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** Hostnames support ASCII(7) letters from a to z, the digits from 0 to 9, wildcards (*), and the hyphen (-). */
    hostname: ListsItemsGetResultListsListItemHostnameFullHostname;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** Defines an informative summary of the list item. */
    comment?: string | null;
}
export type ListsItemsGetResultListsListItemRedirectFullRedirectStatusCode = 301 | 302 | 307 | 308;
export interface ListsItemsGetResultListsListItemRedirectFullRedirect {
    sourceUrl: string;
    targetUrl: string;
    includeSubdomains?: boolean | null;
    preservePathSuffix?: boolean | null;
    preserveQueryString?: boolean | null;
    statusCode?: ListsItemsGetResultListsListItemRedirectFullRedirectStatusCode | null;
    subpathMatching?: boolean | null;
}
export interface ListsItemsGetResultListsListItemRedirectFull {
    /** Defines the unique ID of the item in the List. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** The definition of the redirect. */
    redirect: ListsItemsGetResultListsListItemRedirectFullRedirect;
    /** Defines an informative summary of the list item. */
    comment?: string | null;
}
export interface ListsItemsGetResultListsListItemASNFull {
    /** Defines the unique ID of the item in the List. */
    id: string;
    /** Defines a non-negative 32 bit integer. */
    asn: number;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** Defines an informative summary of the list item. */
    comment?: string | null;
}
export type ListsItemsGetResult = ListsItemsGetResultListsListItemIPFull | ListsItemsGetResultListsListItemHostnameFull | ListsItemsGetResultListsListItemRedirectFull | ListsItemsGetResultListsListItemASNFull;
export type GetListItemResponse = ListsItemsGetResult;
export interface ListListItemsRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
    /** The pagination cursor. An opaque string token that indicates where to continue when requesting the next/previous set of records. The response provides cursor values under `result_info.cursors`. You should make no assumptions about a cursor's content or length. */
    cursor?: string;
    /** Amount of results to include in each paginated response. A non-negative 32 bit integer. */
    perPage?: number;
    /** A search query to filter returned items. Its meaning depends on the list type: IP addresses must start with the provided string, hostnames and bulk redirects must contain the string, and ASNs must match the string exactly. */
    search?: string;
}
export type ListsItemsListResultItemListsListItemIPFull = ListsItemsGetResultListsListItemIPFull;
export type ListsItemsListResultItemListsListItemHostnameFullHostname = ListsItemsGetResultListsListItemHostnameFullHostname;
export type ListsItemsListResultItemListsListItemHostnameFull = ListsItemsGetResultListsListItemHostnameFull;
export type ListsItemsListResultItemListsListItemRedirectFullRedirectStatusCode = 301 | 302 | 307 | 308;
export interface ListsItemsListResultItemListsListItemRedirectFullRedirect {
    sourceUrl: string;
    targetUrl: string;
    includeSubdomains?: boolean | null;
    preservePathSuffix?: boolean | null;
    preserveQueryString?: boolean | null;
    statusCode?: ListsItemsListResultItemListsListItemRedirectFullRedirectStatusCode | null;
    subpathMatching?: boolean | null;
}
export interface ListsItemsListResultItemListsListItemRedirectFull {
    /** Defines the unique ID of the item in the List. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** The definition of the redirect. */
    redirect: ListsItemsListResultItemListsListItemRedirectFullRedirect;
    /** Defines an informative summary of the list item. */
    comment?: string | null;
}
export type ListsItemsListResultItemListsListItemASNFull = ListsItemsGetResultListsListItemASNFull;
export type ListsItemsListResultItem = ListsItemsGetResultListsListItemIPFull | ListsItemsGetResultListsListItemHostnameFull | ListsItemsListResultItemListsListItemRedirectFull | ListsItemsGetResultListsListItemASNFull;
export type ListsItemsListResultList = Array<ListsItemsListResultItem>;
export interface ListListItemsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListsItemsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListListsRequest {
    /** The Account ID for this resource. */
    accountId: string;
}
export type ListsListResultItemKind = "ip" | "redirect" | "hostname" | "asn";
export interface ListsListResultItem {
    /** The unique ID of the list. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The type of the list. Each type supports specific list items (IP addresses, ASNs, hostnames or redirects). */
    kind: ListsListResultItemKind;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** An informative name for the list. Use this name in filter and rule expressions. */
    name: string;
    /** The number of items in the list. */
    numItems: number;
    /** The number of [filters](https://developers.cloudflare.com/api/resources/filters/) referencing the list. */
    numReferencingFilters: number;
    /** An informative summary of the list. */
    description?: string | null;
}
export type ListsListResultList = Array<ListsListResultItem>;
export interface ListListsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface UpdateListRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
    /** An informative summary of the list. */
    description?: string;
}
export type ListsUpdateResponseKind = "ip" | "redirect" | "hostname" | "asn";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateListResponse {
    /** The unique ID of the list. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The type of the list. Each type supports specific list items (IP addresses, ASNs, hostnames or redirects). */
    kind: ListsUpdateResponseKind;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** An informative name for the list. Use this name in filter and rule expressions. */
    name: string;
    /** The number of items in the list. */
    numItems: number;
    /** The number of [filters](https://developers.cloudflare.com/api/resources/filters/) referencing the list. */
    numReferencingFilters: number;
    /** An informative summary of the list. */
    description?: string | null;
}
export type ListsItemsUpdateRequestBodyItemListsListItemIPComment = ListsItemsCreateRequestBodyItemListsListItemIPComment;
export type ListsItemsUpdateRequestBodyItemListsListItemRedirectCommentRedirectStatusCode = 301 | 302 | 307 | 308;
export interface ListsItemsUpdateRequestBodyItemListsListItemRedirectCommentRedirect {
    sourceUrl: string;
    targetUrl: string;
    includeSubdomains?: boolean;
    preservePathSuffix?: boolean;
    preserveQueryString?: boolean;
    statusCode?: ListsItemsUpdateRequestBodyItemListsListItemRedirectCommentRedirectStatusCode | (number & {});
    subpathMatching?: boolean;
}
export interface ListsItemsUpdateRequestBodyItemListsListItemRedirectComment {
    /** The definition of the redirect. */
    redirect: ListsItemsUpdateRequestBodyItemListsListItemRedirectCommentRedirect;
    /** Defines an informative summary of the list item. */
    comment?: string;
}
export type ListsItemsUpdateRequestBodyItemListsListItemHostnameCommentHostname = ListsItemsCreateRequestBodyItemListsListItemHostnameCommentHostname;
export type ListsItemsUpdateRequestBodyItemListsListItemHostnameComment = ListsItemsCreateRequestBodyItemListsListItemHostnameComment;
export type ListsItemsUpdateRequestBodyItemListsListItemASNComment = ListsItemsCreateRequestBodyItemListsListItemASNComment;
export type ListsItemsUpdateRequestBodyItem = ListsItemsCreateRequestBodyItemListsListItemIPComment | ListsItemsUpdateRequestBodyItemListsListItemRedirectComment | ListsItemsCreateRequestBodyItemListsListItemHostnameComment | ListsItemsCreateRequestBodyItemListsListItemASNComment;
export type ListsItemsUpdateRequestBodyList = Array<ListsItemsUpdateRequestBodyItem>;
export interface UpdateListItemRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
    body: ListsItemsUpdateRequestBodyList;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateListItemResponse {
    /** The unique operation ID of the asynchronous action. */
    operationId: string;
}
export type CreateListError = ListAlreadyExists | Forbidden | CloudflareOpError;
/** Creates a new list of the specified kind. */
export declare const createList: API.OperationMethod<CreateListRequest, CreateListResponse, CreateListError, CloudflareOpContext>;
export type CreateListItemError = CloudflareOpError;
/** Appends new items to the list. This operation is asynchronous. To get the current operation status, invoke the `Get bulk operation status` endpoint with the returned `operation_id`. There is a limit of 1 pending bulk operation per account. If an outstanding bulk operation is in progress, the request will be rejected. */
export declare const createListItem: API.OperationMethod<CreateListItemRequest, CreateListItemResponse, CreateListItemError, CloudflareOpContext>;
export type DeleteListError = ListNotFound | Forbidden | CloudflareOpError;
/** Deletes a specific list and all its items. */
export declare const deleteList: API.OperationMethod<DeleteListRequest, DeleteListResponse, DeleteListError, CloudflareOpContext>;
export type DeleteListItemError = CloudflareOpError;
/** Removes one or more items from a list. This operation is asynchronous. To get the current operation status, invoke the `Get bulk operation status` endpoint with the returned `operation_id`. There is a limit of 1 pending bulk operation per account. If an outstanding bulk operation is in progress, the request will be rejected. */
export declare const deleteListItem: API.OperationMethod<DeleteListItemRequest, DeleteListItemResponse, DeleteListItemError, CloudflareOpContext>;
export type GetListError = ListNotFound | Forbidden | CloudflareOpError;
/** Fetches the details of a list. */
export declare const getList: API.OperationMethod<GetListRequest, GetListResponse, GetListError, CloudflareOpContext>;
export type GetListBulkOperationError = ListNotFound | Forbidden | CloudflareOpError;
/** Gets the current status of an asynchronous operation on a list. The `status` property can have one of the following values: `pending`, `running`, `completed`, or `failed`. If the status is `failed`, the `error` property will contain a message describing the error. */
export declare const getListBulkOperation: API.OperationMethod<GetListBulkOperationRequest, GetListBulkOperationResponse, GetListBulkOperationError, CloudflareOpContext>;
export type GetListItemError = CloudflareOpError;
/** Fetches a list item in the list. */
export declare const getListItem: API.OperationMethod<GetListItemRequest, GetListItemResponse, GetListItemError, CloudflareOpContext>;
export type ListListItemsError = ListNotFound | Forbidden | CloudflareOpError;
/** Fetches all the items in the list. */
export declare const listListItems: API.PaginatedOperationMethod<ListListItemsRequest, ListListItemsResponse, ListListItemsError, CloudflareOpContext, ListsItemsListResultItem>;
export type ListListsError = Forbidden | CloudflareOpError;
/** Fetches all lists in the account. */
export declare const listLists: API.PaginatedOperationMethod<ListListsRequest, ListListsResponse, ListListsError, CloudflareOpContext, ListsListResultItem>;
export type UpdateListError = ListNotFound | Forbidden | CloudflareOpError;
/** Updates the description of a list. */
export declare const updateList: API.OperationMethod<UpdateListRequest, UpdateListResponse, UpdateListError, CloudflareOpContext>;
export type UpdateListItemError = ListNotFound | Forbidden | CloudflareOpError;
/** Removes all existing items from the list and adds the provided items to the list. This operation is asynchronous. To get the current operation status, invoke the `Get bulk operation status` endpoint with the returned `operation_id`. There is a limit of 1 pending bulk operation per account. If an outstanding bulk operation is in progress, the request will be rejected. */
export declare const updateListItem: API.OperationMethod<UpdateListItemRequest, UpdateListItemResponse, UpdateListItemError, CloudflareOpContext>;
//# sourceMappingURL=rules.d.ts.map