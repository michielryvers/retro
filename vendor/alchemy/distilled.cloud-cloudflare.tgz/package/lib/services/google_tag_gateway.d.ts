import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface GetConfigRequest {
    /** Identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigResponse {
    /** Enables or disables Google Tag Gateway for this zone. */
    enabled: boolean;
    /** Specifies the endpoint path for proxying Google Tag Manager requests. Use an absolute path starting with '/', with no nested paths and alphanumeric characters only (e.g. /metrics). */
    endpoint: string;
    /** Hides the original client IP address from Google when enabled. */
    hideOriginalIp: boolean;
    /** Specify the Google Tag Manager container or measurement ID (e.g. GTM-XXXXXXX or G-XXXXXXXXXX). */
    measurementId: string;
    /** Set up the associated Google Tag on the zone automatically when enabled. */
    setUpTag?: boolean | null;
}
export interface PutConfigRequest {
    /** Identifier. */
    zoneId: string;
    /** Enables or disables Google Tag Gateway for this zone. */
    enabled: boolean;
    /** Specifies the endpoint path for proxying Google Tag Manager requests. Use an absolute path starting with '/', with no nested paths and alphanumeric characters only (e.g. /metrics). */
    endpoint: string;
    /** Hides the original client IP address from Google when enabled. */
    hideOriginalIp: boolean;
    /** Specify the Google Tag Manager container or measurement ID (e.g. GTM-XXXXXXX or G-XXXXXXXXXX). */
    measurementId: string;
    /** Set up the associated Google Tag on the zone automatically when enabled. */
    setUpTag?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutConfigResponse {
    /** Enables or disables Google Tag Gateway for this zone. */
    enabled: boolean;
    /** Specifies the endpoint path for proxying Google Tag Manager requests. Use an absolute path starting with '/', with no nested paths and alphanumeric characters only (e.g. /metrics). */
    endpoint: string;
    /** Hides the original client IP address from Google when enabled. */
    hideOriginalIp: boolean;
    /** Specify the Google Tag Manager container or measurement ID (e.g. GTM-XXXXXXX or G-XXXXXXXXXX). */
    measurementId: string;
    /** Set up the associated Google Tag on the zone automatically when enabled. */
    setUpTag?: boolean | null;
}
export type GetConfigError = Forbidden | CloudflareOpError;
/** Gets the Google Tag Gateway configuration for a zone. */
export declare const getConfig: API.OperationMethod<GetConfigRequest, GetConfigResponse, GetConfigError, CloudflareOpContext>;
export type PutConfigError = Forbidden | CloudflareOpError;
/** Updates the Google Tag Gateway configuration for a zone. */
export declare const putConfig: API.OperationMethod<PutConfigRequest, PutConfigResponse, PutConfigError, CloudflareOpContext>;
//# sourceMappingURL=google_tag_gateway.d.ts.map