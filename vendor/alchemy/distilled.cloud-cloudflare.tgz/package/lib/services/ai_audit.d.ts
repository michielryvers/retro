import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface GetRobotRequest {
    zoneId: string;
    /** Optional subdomain to fetch robots.txt for. If omitted, fetches robots.txt for the zone apex domain. */
    subdomain?: string;
}
export type GetRobotResponseUserAgentsValueAllowList = Array<string>;
export type GetRobotResponseUserAgentsValueDisallowList = Array<string>;
export type GetRobotResponseUserAgentsValueContentSignalsAiInput = "yes" | "no";
export type GetRobotResponseUserAgentsValueContentSignalsAiTrain = "yes" | "no";
export type GetRobotResponseUserAgentsValueContentSignalsSearch = "yes" | "no";
export interface GetRobotResponseUserAgentsValueContentSignals {
    /** Whether AI input usage is permitted. */
    aiInput?: GetRobotResponseUserAgentsValueContentSignalsAiInput | null;
    /** Whether AI training is permitted. */
    aiTrain?: GetRobotResponseUserAgentsValueContentSignalsAiTrain | null;
    /** Whether search indexing is permitted. */
    search?: GetRobotResponseUserAgentsValueContentSignalsSearch | null;
}
export interface GetRobotResponseUserAgentsValue {
    /** List of allowed path patterns. */
    allow: GetRobotResponseUserAgentsValueAllowList;
    /** List of disallowed path patterns. */
    disallow: GetRobotResponseUserAgentsValueDisallowList;
    /** Content signal directives from robots.txt. */
    contentSignals?: GetRobotResponseUserAgentsValueContentSignals | null;
    /** Crawl delay in seconds. */
    crawlDelay?: number | null;
}
export type GetRobotResponseUserAgentsMap = {
    [key: string]: GetRobotResponseUserAgentsValue | undefined;
};
export type GetRobotResponseSitemapsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRobotResponse {
    /** Map of user-agent string to its parsed rules. */
    userAgents: GetRobotResponseUserAgentsMap;
    /** List of sitemap URLs found in robots.txt. */
    sitemaps?: GetRobotResponseSitemapsList | null;
    /** HTTP status code from fetching the robots.txt file. */
    status?: number | null;
}
export type RobotsBulkGetRequestBodyList = Array<string>;
export interface RobotsBulkGetRequest {
    zoneId: string;
    /** Array of domain hostnames to fetch robots.txt for. Each domain must end with the zone name. Maximum 25 domains per request. */
    body: RobotsBulkGetRequestBodyList;
}
export type RobotsBulkGetResultValueUserAgentsValueAllowList = Array<string>;
export type RobotsBulkGetResultValueUserAgentsValueDisallowList = Array<string>;
export type RobotsBulkGetResultValueUserAgentsValueContentSignalsAiInput = "yes" | "no";
export type RobotsBulkGetResultValueUserAgentsValueContentSignalsAiTrain = "yes" | "no";
export type RobotsBulkGetResultValueUserAgentsValueContentSignalsSearch = "yes" | "no";
export interface RobotsBulkGetResultValueUserAgentsValueContentSignals {
    /** Whether AI input usage is permitted. */
    aiInput?: RobotsBulkGetResultValueUserAgentsValueContentSignalsAiInput | null;
    /** Whether AI training is permitted. */
    aiTrain?: RobotsBulkGetResultValueUserAgentsValueContentSignalsAiTrain | null;
    /** Whether search indexing is permitted. */
    search?: RobotsBulkGetResultValueUserAgentsValueContentSignalsSearch | null;
}
export interface RobotsBulkGetResultValueUserAgentsValue {
    /** List of allowed path patterns. */
    allow: RobotsBulkGetResultValueUserAgentsValueAllowList;
    /** List of disallowed path patterns. */
    disallow: RobotsBulkGetResultValueUserAgentsValueDisallowList;
    /** Content signal directives from robots.txt. */
    contentSignals?: RobotsBulkGetResultValueUserAgentsValueContentSignals | null;
    /** Crawl delay in seconds. */
    crawlDelay?: number | null;
}
export type RobotsBulkGetResultValueUserAgentsMap = {
    [key: string]: RobotsBulkGetResultValueUserAgentsValue | undefined;
};
export type RobotsBulkGetResultValueSitemapsList = Array<string>;
export interface RobotsBulkGetResultValue {
    /** Map of user-agent string to its parsed rules. */
    userAgents: RobotsBulkGetResultValueUserAgentsMap;
    /** List of sitemap URLs found in robots.txt. */
    sitemaps?: RobotsBulkGetResultValueSitemapsList | null;
    /** HTTP status code from fetching the robots.txt file. */
    status?: number | null;
}
export type RobotsBulkGetResultMap = {
    [key: string]: RobotsBulkGetResultValue | undefined;
};
export type RobotsBulkGetResponse = RobotsBulkGetResultMap;
export type GetRobotError = CloudflareOpError;
/** Fetches and parses the robots.txt file for a zone or a specific subdomain within the zone. Returns parsed user-agent rules, content signals, and sitemaps. */
export declare const getRobot: API.OperationMethod<GetRobotRequest, GetRobotResponse, GetRobotError, CloudflareOpContext>;
export type RobotsBulkGetError = CloudflareOpError;
/** Fetches and parses robots.txt files for multiple domains within a zone in a single request. Each domain must belong to the specified zone. Results are keyed by hostname. */
export declare const robotsBulkGet: API.OperationMethod<RobotsBulkGetRequest, RobotsBulkGetResponse, RobotsBulkGetError, CloudflareOpContext>;
//# sourceMappingURL=ai_audit.d.ts.map