import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const DestinationNotVerified_base: S.TaggedErrorClass<"DestinationNotVerified", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DestinationNotVerified extends /*@__PURE__*/ DestinationNotVerified_base {
}
declare const EmailAddressCreatedTooRecently_base: S.TaggedErrorClass<"EmailAddressCreatedTooRecently", {
    readonly code: any;
    readonly message: any;
}>;
export declare class EmailAddressCreatedTooRecently extends /*@__PURE__*/ EmailAddressCreatedTooRecently_base {
}
declare const EmailAddressNotFound_base: S.TaggedErrorClass<"EmailAddressNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class EmailAddressNotFound extends /*@__PURE__*/ EmailAddressNotFound_base {
}
declare const EmailRoutingRuleNotFound_base: S.TaggedErrorClass<"EmailRoutingRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class EmailRoutingRuleNotFound extends /*@__PURE__*/ EmailRoutingRuleNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const WorkerScriptNotFound_base: S.TaggedErrorClass<"WorkerScriptNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WorkerScriptNotFound extends /*@__PURE__*/ WorkerScriptNotFound_base {
}
export interface AccountRulesListForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Filter by enabled routing rules. */
    enabled?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type AccountRulesListResultItemActionsItemType = "drop" | "forward" | "worker";
export type AccountRulesListResultItemActionsItemValueList = Array<string>;
export interface AccountRulesListResultItemActionsItem {
    /** Type of supported action. */
    type: AccountRulesListResultItemActionsItemType;
    /** List of values for the action. Currently limited to a single value. */
    value?: AccountRulesListResultItemActionsItemValueList | null;
}
export type AccountRulesListResultItemActionsList = Array<AccountRulesListResultItemActionsItem>;
export type AccountRulesListResultItemMatchersItemType = "all" | "literal";
export type AccountRulesListResultItemMatchersItemField = "to";
export interface AccountRulesListResultItemMatchersItem {
    /** Type of matcher. */
    type: AccountRulesListResultItemMatchersItemType;
    /** Field for type matcher. */
    field?: AccountRulesListResultItemMatchersItemField | null;
    /** Value for matcher. */
    value?: string | null;
}
export type AccountRulesListResultItemMatchersList = Array<AccountRulesListResultItemMatchersItem>;
export type AccountRulesListResultItemSource = "api" | "wrangler";
export interface AccountRulesListResultItemZone {
    /** Zone name. */
    name?: string | null;
    /** Zone tag. */
    tag?: string | null;
}
export interface AccountRulesListResultItem {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions patterns. */
    actions?: AccountRulesListResultItemActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** Matching patterns to forward to your actions. */
    matchers?: AccountRulesListResultItemMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Priority of the routing rule. */
    priority?: number | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; `wrangler` means the rule is managed by a Worker's wrangler.jsonc. Defaults to `api` when omitted on write. */
    source?: AccountRulesListResultItemSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
    /** Zone information for the routing rule. */
    zone?: AccountRulesListResultItemZone | null;
}
export type AccountRulesListResultList = Array<AccountRulesListResultItem>;
export type AccountRulesListResponse = AccountRulesListResultList;
export interface AccountRulesListForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Filter by enabled routing rules. */
    enabled?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export interface CreateAddressRequest {
    /** Identifier. */
    accountId: string;
    /** The contact email address of the user. */
    email: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAddressResponse {
    /** Destination address identifier. */
    id?: string | null;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Destination address tag. (Deprecated, replaced by destination address identifier) */
    tag?: string | null;
    /** The date and time the destination address has been verified. Null means not verified yet. */
    verified?: string | null;
}
export interface CreateDnsRequest {
    /** Identifier. */
    zoneId: string;
    /** Domain of your zone. */
    name?: string;
}
export type DnsCreateResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDnsResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: DnsCreateResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export type RulesCreateRequestActionsItemType = "drop" | "forward" | "worker";
export type RulesCreateRequestActionsItemValueList = Array<string>;
export interface RulesCreateRequestActionsItem {
    /** Type of supported action. */
    type: RulesCreateRequestActionsItemType | (string & {});
    /** List of values for the action. Currently limited to a single value. */
    value?: RulesCreateRequestActionsItemValueList;
}
export type RulesCreateRequestActionsList = Array<RulesCreateRequestActionsItem>;
export type RulesCreateRequestMatchersItemType = "all" | "literal";
export type RulesCreateRequestMatchersItemField = "to";
export interface RulesCreateRequestMatchersItem {
    /** Type of matcher. */
    type: RulesCreateRequestMatchersItemType | (string & {});
    /** Field for type matcher. */
    field?: RulesCreateRequestMatchersItemField | (string & {});
    /** Value for matcher. */
    value?: string;
}
export type RulesCreateRequestMatchersList = Array<RulesCreateRequestMatchersItem>;
export type RulesCreateRequestSource = "api" | "wrangler";
export interface CreateRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** List actions patterns. */
    actions: RulesCreateRequestActionsList;
    /** Matching patterns to forward to your actions. */
    matchers: RulesCreateRequestMatchersList;
    /** Routing rule status. */
    enabled?: boolean;
    /** Routing rule name. */
    name?: string;
    /** Public tag (script_tag) of the Worker that owns this rule. Required when `source` is `wrangler`. */
    ownerWorkerTag?: string;
    /** Priority of the routing rule. */
    priority?: number;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; `wrangler` means the rule is managed by a Worker's wrangler.jsonc. Defaults to `api` when omitted on write. */
    source?: RulesCreateRequestSource | (string & {});
}
export type RulesCreateResponseActionsItemType = "drop" | "forward" | "worker";
export type RulesCreateResponseActionsItemValueList = Array<string>;
export interface RulesCreateResponseActionsItem {
    /** Type of supported action. */
    type: RulesCreateResponseActionsItemType;
    /** List of values for the action. Currently limited to a single value. */
    value?: RulesCreateResponseActionsItemValueList | null;
}
export type RulesCreateResponseActionsList = Array<RulesCreateResponseActionsItem>;
export type RulesCreateResponseMatchersItemType = "all" | "literal";
export type RulesCreateResponseMatchersItemField = "to";
export interface RulesCreateResponseMatchersItem {
    /** Type of matcher. */
    type: RulesCreateResponseMatchersItemType;
    /** Field for type matcher. */
    field?: RulesCreateResponseMatchersItemField | null;
    /** Value for matcher. */
    value?: string | null;
}
export type RulesCreateResponseMatchersList = Array<RulesCreateResponseMatchersItem>;
export type RulesCreateResponseSource = "api" | "wrangler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRuleResponse {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions patterns. */
    actions?: RulesCreateResponseActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** Matching patterns to forward to your actions. */
    matchers?: RulesCreateResponseMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Priority of the routing rule. */
    priority?: number | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; `wrangler` means the rule is managed by a Worker's wrangler.jsonc. Defaults to `api` when omitted on write. */
    source?: RulesCreateResponseSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
}
export interface DeleteAddressRequest {
    /** Identifier. */
    accountId: string;
    /** Destination address identifier. */
    destinationAddressIdentifier: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAddressResponse {
    /** Destination address identifier. */
    id?: string | null;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Destination address tag. (Deprecated, replaced by destination address identifier) */
    tag?: string | null;
    /** The date and time the destination address has been verified. Null means not verified yet. */
    verified?: string | null;
}
export interface DeleteDnsRequest {
    /** Identifier. */
    zoneId: string;
}
export type DnsDeleteResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DnsDeleteResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: DnsDeleteResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export interface DeleteRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Routing rule identifier. */
    ruleIdentifier: string;
}
export type RulesDeleteResponseActionsItemType = "drop" | "forward" | "worker";
export type RulesDeleteResponseActionsItemValueList = Array<string>;
export interface RulesDeleteResponseActionsItem {
    /** Type of supported action. */
    type: RulesDeleteResponseActionsItemType;
    /** List of values for the action. Currently limited to a single value. */
    value?: RulesDeleteResponseActionsItemValueList | null;
}
export type RulesDeleteResponseActionsList = Array<RulesDeleteResponseActionsItem>;
export type RulesDeleteResponseMatchersItemType = "all" | "literal";
export type RulesDeleteResponseMatchersItemField = "to";
export interface RulesDeleteResponseMatchersItem {
    /** Type of matcher. */
    type: RulesDeleteResponseMatchersItemType;
    /** Field for type matcher. */
    field?: RulesDeleteResponseMatchersItemField | null;
    /** Value for matcher. */
    value?: string | null;
}
export type RulesDeleteResponseMatchersList = Array<RulesDeleteResponseMatchersItem>;
export type RulesDeleteResponseSource = "api" | "wrangler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRuleResponse {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions patterns. */
    actions?: RulesDeleteResponseActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** Matching patterns to forward to your actions. */
    matchers?: RulesDeleteResponseMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Priority of the routing rule. */
    priority?: number | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; `wrangler` means the rule is managed by a Worker's wrangler.jsonc. Defaults to `api` when omitted on write. */
    source?: RulesDeleteResponseSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
}
export interface DisableEmailRoutingRequest {
    /** Identifier. */
    zoneId: string;
}
export type DisableResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DisableEmailRoutingResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: DisableResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export interface EditRequest {
    /** Identifier. */
    zoneId: string;
    /** State of your zone Email Routing settings. No-op on this endpoint - use `POST`/`DELETE /zones/{zone_id}/email/routing/dns`. */
    enabled?: boolean;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean;
}
export type EditResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: EditResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export type EditAddressRequestStatus = "unverified" | "verified";
export interface EditAddressRequest {
    /** Identifier. */
    accountId: string;
    /** Destination address identifier. */
    destinationAddressIdentifier: string;
    /** Destination address status. Non-admin callers may only set verified addresses back to unverified; setting to verified requires admin privileges. */
    status: EditAddressRequestStatus | (string & {});
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditAddressResponse {
    /** Destination address identifier. */
    id?: string | null;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Destination address tag. (Deprecated, replaced by destination address identifier) */
    tag?: string | null;
    /** The date and time the destination address has been verified. Null means not verified yet. */
    verified?: string | null;
}
export interface EnableEmailRoutingRequest {
    /** Identifier. */
    zoneId: string;
}
export type EnableResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EnableEmailRoutingResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: EnableResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export interface GetAddressRequest {
    /** Identifier. */
    accountId: string;
    /** Destination address identifier. */
    destinationAddressIdentifier: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAddressResponse {
    /** Destination address identifier. */
    id?: string | null;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Destination address tag. (Deprecated, replaced by destination address identifier) */
    tag?: string | null;
    /** The date and time the destination address has been verified. Null means not verified yet. */
    verified?: string | null;
}
export interface GetDnsRequest {
    /** Identifier. */
    zoneId: string;
    /** Deprecated. When supplied, the response shape differs from the documented default and is not modeled in generated SDKs. Do not rely on this parameter. */
    subdomain?: string;
}
export type DnsGetResultItemType = "A" | "AAAA" | "CNAME" | "HTTPS" | "TXT" | "SRV" | "LOC" | "MX" | "NS" | "CERT" | "DNSKEY" | "DS" | "NAPTR" | "SMIMEA" | "SSHFP" | "SVCB" | "TLSA" | "URI";
export interface DnsGetResultItem {
    /** DNS record content. */
    content?: string | null;
    /** DNS record name (or @ for the zone apex). */
    name?: string | null;
    /** Required for MX, SRV and URI records. Unused by other record types. Records with lower priorities are preferred. */
    priority?: number | null;
    /** Time to live, in seconds, of the DNS record. Must be between 60 and 86400, or 1 for 'automatic'. */
    ttl?: number | null;
    /** DNS record type. */
    type?: DnsGetResultItemType | null;
}
export type DnsGetResultList = Array<DnsGetResultItem>;
export type GetDnsResponse = DnsGetResultList;
export interface GetEmailRoutingRequest {
    /** Identifier. */
    zoneId: string;
}
export type GetResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetEmailRoutingResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: GetResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export interface GetRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Routing rule identifier. */
    ruleIdentifier: string;
}
export type RulesGetResponseActionsItemType = "drop" | "forward" | "worker";
export type RulesGetResponseActionsItemValueList = Array<string>;
export interface RulesGetResponseActionsItem {
    /** Type of supported action. */
    type: RulesGetResponseActionsItemType;
    /** List of values for the action. Currently limited to a single value. */
    value?: RulesGetResponseActionsItemValueList | null;
}
export type RulesGetResponseActionsList = Array<RulesGetResponseActionsItem>;
export type RulesGetResponseMatchersItemType = "all" | "literal";
export type RulesGetResponseMatchersItemField = "to";
export interface RulesGetResponseMatchersItem {
    /** Type of matcher. */
    type: RulesGetResponseMatchersItemType;
    /** Field for type matcher. */
    field?: RulesGetResponseMatchersItemField | null;
    /** Value for matcher. */
    value?: string | null;
}
export type RulesGetResponseMatchersList = Array<RulesGetResponseMatchersItem>;
export type RulesGetResponseSource = "api" | "wrangler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRuleResponse {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions patterns. */
    actions?: RulesGetResponseActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** Matching patterns to forward to your actions. */
    matchers?: RulesGetResponseMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Priority of the routing rule. */
    priority?: number | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; `wrangler` means the rule is managed by a Worker's wrangler.jsonc. Defaults to `api` when omitted on write. */
    source?: RulesGetResponseSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
}
export interface GetRuleCatchAllRequest {
    /** Identifier. */
    zoneId: string;
}
export type RulesCatchAllsGetResponseActionsItemType = "drop" | "forward" | "worker";
export type RulesCatchAllsGetResponseActionsItemValueList = Array<string>;
export interface RulesCatchAllsGetResponseActionsItem {
    /** Type of action for catch-all rule. */
    type: RulesCatchAllsGetResponseActionsItemType;
    /** List of values for the action. Currently limited to a single value. */
    value?: RulesCatchAllsGetResponseActionsItemValueList | null;
}
export type RulesCatchAllsGetResponseActionsList = Array<RulesCatchAllsGetResponseActionsItem>;
export type RulesCatchAllsGetResponseMatchersItemType = "all";
export interface RulesCatchAllsGetResponseMatchersItem {
    /** Type of matcher. Default is 'all'. */
    type: RulesCatchAllsGetResponseMatchersItemType;
}
export type RulesCatchAllsGetResponseMatchersList = Array<RulesCatchAllsGetResponseMatchersItem>;
export type RulesCatchAllsGetResponseSource = "api" | "wrangler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRuleCatchAllResponse {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions for the catch-all routing rule. */
    actions?: RulesCatchAllsGetResponseActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** List of matchers for the catch-all routing rule. */
    matchers?: RulesCatchAllsGetResponseMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; `wrangler` means the rule is managed by a Worker's wrangler.jsonc. Defaults to `api` when omitted on write. */
    source?: RulesCatchAllsGetResponseSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
}
export type AddressesListRequestDirection = "asc" | "desc";
export interface ListAddressesRequest {
    /** Identifier. */
    accountId: string;
    /** Sorts results in an ascending or descending order. */
    direction?: AddressesListRequestDirection | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** Filter by verified destination addresses. */
    verified?: string;
}
export interface AddressesListResultItem {
    /** Destination address identifier. */
    id?: string | null;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Destination address tag. (Deprecated, replaced by destination address identifier) */
    tag?: string | null;
    /** The date and time the destination address has been verified. Null means not verified yet. */
    verified?: string | null;
}
export type AddressesListResultList = Array<AddressesListResultItem>;
export interface ListAddressesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AddressesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListRulesRequest {
    /** Identifier. */
    zoneId: string;
    page?: number;
    perPage?: number;
    /** Filter by enabled routing rules. */
    enabled?: boolean;
}
export type ListRulesResponseResultList = Array<GetRuleResponse>;
export interface ListRulesResponse {
    /** Routing rules for the zone. */
    result: ListRulesResponseResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface PatchDnsRequest {
    /** Identifier. */
    zoneId: string;
    /** Domain of your zone. */
    name?: string;
}
export type DnsEditResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchDnsResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: DnsEditResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export type RulesCatchAllsUpdateRequestActionsItemType = "drop" | "forward" | "worker";
export type RulesCatchAllsUpdateRequestActionsItemValueList = Array<string>;
export interface RulesCatchAllsUpdateRequestActionsItem {
    /** Type of action for catch-all rule. */
    type: RulesCatchAllsUpdateRequestActionsItemType | (string & {});
    /** List of values for the action. Currently limited to a single value. */
    value?: RulesCatchAllsUpdateRequestActionsItemValueList;
}
export type RulesCatchAllsUpdateRequestActionsList = Array<RulesCatchAllsUpdateRequestActionsItem>;
export type RulesCatchAllsUpdateRequestMatchersItemType = "all";
export interface RulesCatchAllsUpdateRequestMatchersItem {
    /** Type of matcher. Default is 'all'. */
    type: RulesCatchAllsUpdateRequestMatchersItemType | (string & {});
}
export type RulesCatchAllsUpdateRequestMatchersList = Array<RulesCatchAllsUpdateRequestMatchersItem>;
export type RulesCatchAllsUpdateRequestSource = "api" | "wrangler";
export interface PutRuleCatchAllRequest {
    /** Identifier. */
    zoneId: string;
    /** List actions for the catch-all routing rule. */
    actions: RulesCatchAllsUpdateRequestActionsList;
    /** List of matchers for the catch-all routing rule. */
    matchers: RulesCatchAllsUpdateRequestMatchersList;
    /** Routing rule status. */
    enabled?: boolean;
    /** Routing rule name. */
    name?: string;
    /** Public tag (script_tag) of the Worker that owns this rule. Required when `source` is `wrangler`. */
    ownerWorkerTag?: string;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; `wrangler` means the rule is managed by a Worker's wrangler.jsonc. Defaults to `api` when omitted on write. */
    source?: RulesCatchAllsUpdateRequestSource | (string & {});
}
export type RulesCatchAllsUpdateResponseActionsItemType = "drop" | "forward" | "worker";
export type RulesCatchAllsUpdateResponseActionsItemValueList = Array<string>;
export interface RulesCatchAllsUpdateResponseActionsItem {
    /** Type of action for catch-all rule. */
    type: RulesCatchAllsUpdateResponseActionsItemType;
    /** List of values for the action. Currently limited to a single value. */
    value?: RulesCatchAllsUpdateResponseActionsItemValueList | null;
}
export type RulesCatchAllsUpdateResponseActionsList = Array<RulesCatchAllsUpdateResponseActionsItem>;
export type RulesCatchAllsUpdateResponseMatchersItemType = "all";
export interface RulesCatchAllsUpdateResponseMatchersItem {
    /** Type of matcher. Default is 'all'. */
    type: RulesCatchAllsUpdateResponseMatchersItemType;
}
export type RulesCatchAllsUpdateResponseMatchersList = Array<RulesCatchAllsUpdateResponseMatchersItem>;
export type RulesCatchAllsUpdateResponseSource = "api" | "wrangler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutRuleCatchAllResponse {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions for the catch-all routing rule. */
    actions?: RulesCatchAllsUpdateResponseActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** List of matchers for the catch-all routing rule. */
    matchers?: RulesCatchAllsUpdateResponseMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; `wrangler` means the rule is managed by a Worker's wrangler.jsonc. Defaults to `api` when omitted on write. */
    source?: RulesCatchAllsUpdateResponseSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
}
export interface RulesListForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Filter by enabled routing rules. */
    enabled?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type RulesListResultItemActionsItemType = "drop" | "forward" | "worker";
export type RulesListResultItemActionsItemValueList = Array<string>;
export interface RulesListResultItemActionsItem {
    /** Type of supported action. */
    type: RulesListResultItemActionsItemType;
    /** List of values for the action. Currently limited to a single value. */
    value?: RulesListResultItemActionsItemValueList | null;
}
export type RulesListResultItemActionsList = Array<RulesListResultItemActionsItem>;
export type RulesListResultItemMatchersItemType = "all" | "literal";
export type RulesListResultItemMatchersItemField = "to";
export interface RulesListResultItemMatchersItem {
    /** Type of matcher. */
    type: RulesListResultItemMatchersItemType;
    /** Field for type matcher. */
    field?: RulesListResultItemMatchersItemField | null;
    /** Value for matcher. */
    value?: string | null;
}
export type RulesListResultItemMatchersList = Array<RulesListResultItemMatchersItem>;
export type RulesListResultItemSource = "api" | "wrangler";
export type RulesListResultItemZone = AccountRulesListResultItemZone;
export interface RulesListResultItem {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions patterns. */
    actions?: RulesListResultItemActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** Matching patterns to forward to your actions. */
    matchers?: RulesListResultItemMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Priority of the routing rule. */
    priority?: number | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; `wrangler` means the rule is managed by a Worker's wrangler.jsonc. Defaults to `api` when omitted on write. */
    source?: RulesListResultItemSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
    /** Zone information for the routing rule. */
    zone?: AccountRulesListResultItemZone | null;
}
export type RulesListResultList = Array<RulesListResultItem>;
export type RulesListResponse = RulesListResultList;
export interface RulesListForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Filter by enabled routing rules. */
    enabled?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export interface UnlockRequest {
    /** Identifier. */
    zoneId: string;
    /** Domain of your zone. */
    name?: string;
}
export type UnlockResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UnlockResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: UnlockResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export interface UpdateRequest {
    /** Identifier. */
    zoneId: string;
    /** State of your zone Email Routing settings. No-op on this endpoint - use `POST`/`DELETE /zones/{zone_id}/email/routing/dns`. */
    enabled?: boolean;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean;
}
export type UpdateResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: UpdateResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export type RulesUpdateRequestActionsItemType = "drop" | "forward" | "worker";
export type RulesUpdateRequestActionsItemValueList = Array<string>;
export interface RulesUpdateRequestActionsItem {
    /** Type of supported action. */
    type: RulesUpdateRequestActionsItemType | (string & {});
    /** List of values for the action. Currently limited to a single value. */
    value?: RulesUpdateRequestActionsItemValueList;
}
export type RulesUpdateRequestActionsList = Array<RulesUpdateRequestActionsItem>;
export type RulesUpdateRequestMatchersItemType = "all" | "literal";
export type RulesUpdateRequestMatchersItemField = "to";
export interface RulesUpdateRequestMatchersItem {
    /** Type of matcher. */
    type: RulesUpdateRequestMatchersItemType | (string & {});
    /** Field for type matcher. */
    field?: RulesUpdateRequestMatchersItemField | (string & {});
    /** Value for matcher. */
    value?: string;
}
export type RulesUpdateRequestMatchersList = Array<RulesUpdateRequestMatchersItem>;
export type RulesUpdateRequestSource = "api" | "wrangler";
export interface UpdateRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Routing rule identifier. */
    ruleIdentifier: string;
    /** List actions patterns. */
    actions: RulesUpdateRequestActionsList;
    /** Matching patterns to forward to your actions. */
    matchers: RulesUpdateRequestMatchersList;
    /** Routing rule status. */
    enabled?: boolean;
    /** Routing rule name. */
    name?: string;
    /** Public tag (script_tag) of the Worker that owns this rule. Required when `source` is `wrangler`. */
    ownerWorkerTag?: string;
    /** Priority of the routing rule. */
    priority?: number;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; `wrangler` means the rule is managed by a Worker's wrangler.jsonc. Defaults to `api` when omitted on write. */
    source?: RulesUpdateRequestSource | (string & {});
}
export type RulesUpdateResponseActionsItemType = "drop" | "forward" | "worker";
export type RulesUpdateResponseActionsItemValueList = Array<string>;
export interface RulesUpdateResponseActionsItem {
    /** Type of supported action. */
    type: RulesUpdateResponseActionsItemType;
    /** List of values for the action. Currently limited to a single value. */
    value?: RulesUpdateResponseActionsItemValueList | null;
}
export type RulesUpdateResponseActionsList = Array<RulesUpdateResponseActionsItem>;
export type RulesUpdateResponseMatchersItemType = "all" | "literal";
export type RulesUpdateResponseMatchersItemField = "to";
export interface RulesUpdateResponseMatchersItem {
    /** Type of matcher. */
    type: RulesUpdateResponseMatchersItemType;
    /** Field for type matcher. */
    field?: RulesUpdateResponseMatchersItemField | null;
    /** Value for matcher. */
    value?: string | null;
}
export type RulesUpdateResponseMatchersList = Array<RulesUpdateResponseMatchersItem>;
export type RulesUpdateResponseSource = "api" | "wrangler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRuleResponse {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions patterns. */
    actions?: RulesUpdateResponseActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** Matching patterns to forward to your actions. */
    matchers?: RulesUpdateResponseMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Priority of the routing rule. */
    priority?: number | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; `wrangler` means the rule is managed by a Worker's wrangler.jsonc. Defaults to `api` when omitted on write. */
    source?: RulesUpdateResponseSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
}
export type AccountRulesListForAccountError = CloudflareOpError;
/** Lists existing routing rules across all zones in the account or zone. */
export declare const accountRulesListForAccount: API.OperationMethod<AccountRulesListForAccountRequest, AccountRulesListResponse, AccountRulesListForAccountError, CloudflareOpContext>;
export type AccountRulesListForZoneError = CloudflareOpError;
/** Lists existing routing rules across all zones in the account or zone. */
export declare const accountRulesListForZone: API.OperationMethod<AccountRulesListForZoneRequest, AccountRulesListResponse, AccountRulesListForZoneError, CloudflareOpContext>;
export type CreateAddressError = CloudflareOpError;
/** Create a destination address to forward your emails to. Destination addresses need to be verified before they can be used. */
export declare const createAddress: API.OperationMethod<CreateAddressRequest, CreateAddressResponse, CreateAddressError, CloudflareOpContext>;
export type CreateDnsError = CloudflareOpError;
/** Enable your Email Routing zone. Add and lock the necessary MX and SPF records. */
export declare const createDns: API.OperationMethod<CreateDnsRequest, CreateDnsResponse, CreateDnsError, CloudflareOpContext>;
export type CreateRuleError = WorkerScriptNotFound | CloudflareOpError;
/** Rules consist of a set of criteria for matching emails (such as an email being sent to a specific custom email address) plus a set of actions to take on the email (like forwarding it to a specific destination address). Forward actions require exactly one verified destination address. */
export declare const createRule: API.OperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, CloudflareOpContext>;
export type DeleteAddressError = EmailAddressNotFound | EmailAddressCreatedTooRecently | CloudflareOpError;
/** Deletes a specific destination address. */
export declare const deleteAddress: API.OperationMethod<DeleteAddressRequest, DeleteAddressResponse, DeleteAddressError, CloudflareOpContext>;
export type DeleteDnsError = CloudflareOpError;
/** Disable your Email Routing zone. Also removes additional MX records previously required for Email Routing to work. */
export declare const deleteDns: API.OperationMethod<DeleteDnsRequest, DnsDeleteResponse, DeleteDnsError, CloudflareOpContext>;
export type DeleteRuleError = EmailRoutingRuleNotFound | CloudflareOpError;
/** Deletes a routing rule so matching incoming messages are no longer forwarded by it. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type DisableEmailRoutingError = Forbidden | CloudflareOpError;
/** Disable your Email Routing zone. Also removes additional MX records previously required for Email Routing to work. */
export declare const disableEmailRouting: API.OperationMethod<DisableEmailRoutingRequest, DisableEmailRoutingResponse, DisableEmailRoutingError, CloudflareOpContext>;
export type EditError = CloudflareOpError;
/** Update the settings for your Email Routing zone. */
export declare const edit: API.OperationMethod<EditRequest, EditResponse, EditError, CloudflareOpContext>;
export type EditAddressError = CloudflareOpError;
/** Updates the status of a specific destination address. */
export declare const editAddress: API.OperationMethod<EditAddressRequest, EditAddressResponse, EditAddressError, CloudflareOpContext>;
export type EnableEmailRoutingError = Forbidden | CloudflareOpError;
/** Enable you Email Routing zone. Add and lock the necessary MX and SPF records. */
export declare const enableEmailRouting: API.OperationMethod<EnableEmailRoutingRequest, EnableEmailRoutingResponse, EnableEmailRoutingError, CloudflareOpContext>;
export type GetAddressError = CloudflareOpError;
/** Gets information for a specific destination email already created. */
export declare const getAddress: API.OperationMethod<GetAddressRequest, GetAddressResponse, GetAddressError, CloudflareOpContext>;
export type GetDnsError = CloudflareOpError;
/** Show the DNS records needed to configure your Email Routing zone. */
export declare const getDns: API.OperationMethod<GetDnsRequest, GetDnsResponse, GetDnsError, CloudflareOpContext>;
export type GetEmailRoutingError = Forbidden | CloudflareOpError;
/** Get information about the settings for your Email Routing zone. */
export declare const getEmailRouting: API.OperationMethod<GetEmailRoutingRequest, GetEmailRoutingResponse, GetEmailRoutingError, CloudflareOpContext>;
export type GetRuleError = Forbidden | EmailRoutingRuleNotFound | CloudflareOpError;
/** Get information for a specific routing rule already created. */
export declare const getRule: API.OperationMethod<GetRuleRequest, GetRuleResponse, GetRuleError, CloudflareOpContext>;
export type GetRuleCatchAllError = Forbidden | CloudflareOpError;
/** Get information on the default catch-all routing rule. */
export declare const getRuleCatchAll: API.OperationMethod<GetRuleCatchAllRequest, GetRuleCatchAllResponse, GetRuleCatchAllError, CloudflareOpContext>;
export type ListAddressesError = CloudflareOpError;
/** Lists destination addresses configured for Email Routing in an account. */
export declare const listAddresses: API.PaginatedOperationMethod<ListAddressesRequest, ListAddressesResponse, ListAddressesError, CloudflareOpContext, AddressesListResultItem>;
export type ListRulesError = CloudflareOpError;
/** List routing rules (docs-absent endpoint). */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext, GetRuleResponse>;
export type PatchDnsError = CloudflareOpError;
/** Unlock MX Records previously locked by Email Routing. */
export declare const patchDns: API.OperationMethod<PatchDnsRequest, PatchDnsResponse, PatchDnsError, CloudflareOpContext>;
export type PutRuleCatchAllError = Forbidden | DestinationNotVerified | WorkerScriptNotFound | CloudflareOpError;
/** Enable or disable catch-all routing rule, or change action to forward to a specific destination address. Forward actions require exactly one verified destination address. */
export declare const putRuleCatchAll: API.OperationMethod<PutRuleCatchAllRequest, PutRuleCatchAllResponse, PutRuleCatchAllError, CloudflareOpContext>;
export type RulesListForAccountError = CloudflareOpError;
/** Lists existing routing rules across all zones in the account or zone. */
export declare const rulesListForAccount: API.OperationMethod<RulesListForAccountRequest, RulesListResponse, RulesListForAccountError, CloudflareOpContext>;
export type RulesListForZoneError = CloudflareOpError;
/** Lists existing routing rules across all zones in the account or zone. */
export declare const rulesListForZone: API.OperationMethod<RulesListForZoneRequest, RulesListResponse, RulesListForZoneError, CloudflareOpContext>;
export type UnlockError = CloudflareOpError;
/** Unlock MX records previously locked by Email Routing. Deprecated - use PATCH /zones/{zone_id}/email/routing/dns instead. */
export declare const unlock: API.OperationMethod<UnlockRequest, UnlockResponse, UnlockError, CloudflareOpContext>;
export type UpdateError = CloudflareOpError;
/** Apply the provided settings to your Email Routing zone. Omitted settings retain their current values, as with PATCH. */
export declare const update: API.OperationMethod<UpdateRequest, UpdateResponse, UpdateError, CloudflareOpContext>;
export type UpdateRuleError = WorkerScriptNotFound | CloudflareOpError;
/** Update actions and matches, or enable/disable specific routing rules. Forward actions require exactly one verified destination address. */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, CloudflareOpContext>;
//# sourceMappingURL=email_routing.d.ts.map