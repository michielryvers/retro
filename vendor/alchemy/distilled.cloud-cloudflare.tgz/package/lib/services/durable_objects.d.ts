import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const InvalidIdentifier_base: S.TaggedErrorClass<"InvalidIdentifier", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidIdentifier extends /*@__PURE__*/ InvalidIdentifier_base {
}
declare const MalformedParameter_base: S.TaggedErrorClass<"MalformedParameter", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MalformedParameter extends /*@__PURE__*/ MalformedParameter_base {
}
declare const NamespaceNotFound_base: S.TaggedErrorClass<"NamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NamespaceNotFound extends /*@__PURE__*/ NamespaceNotFound_base {
}
export interface ListNamespaceObjectsRequest {
    /** Identifier. */
    accountId: string;
    /** ID of the namespace. */
    id: string;
    /** Opaque token indicating the position from which to continue when requesting the next set of records. A valid value for the cursor can be obtained from the cursors object in the result_info structure. */
    cursor?: string;
    /** The number of objects to return. The cursor attribute may be used to iterate over the next batch of objects if there are more than the limit. */
    limit?: number;
}
export interface NamespacesObjectsListResultItem {
    /** ID of the Durable Object. */
    id?: string | null;
    /** Whether the Durable Object has stored data. */
    hasStoredData?: boolean | null;
}
export type NamespacesObjectsListResultList = Array<NamespacesObjectsListResultItem>;
export interface ListNamespaceObjectsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesObjectsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListNamespacesRequest {
    /** Identifier. */
    accountId: string;
    /** Current page. */
    page?: number;
    /** Items per-page. */
    perPage?: number;
}
export interface NamespacesListResultItem {
    id?: string | null;
    class?: string | null;
    name?: string | null;
    script?: string | null;
    useSqlite?: boolean | null;
    /** Workers for Platforms dispatch namespace of the script that owns this namespace; absent for account-level scripts. */
    dispatchNamespace?: string | null;
}
export type NamespacesListResultList = Array<NamespacesListResultItem>;
export interface ListNamespacesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ListNamespaceObjectsError = NamespaceNotFound | InvalidIdentifier | MalformedParameter | CloudflareOpError;
/** Returns the Durable Objects in a given Durable Object namespace. */
export declare const listNamespaceObjects: API.PaginatedOperationMethod<ListNamespaceObjectsRequest, ListNamespaceObjectsResponse, ListNamespaceObjectsError, CloudflareOpContext, NamespacesObjectsListResultItem>;
export type ListNamespacesError = InvalidIdentifier | CloudflareOpError;
/** Returns the Durable Object namespaces owned by an account. */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, CloudflareOpContext, NamespacesListResultItem>;
//# sourceMappingURL=durable_objects.d.ts.map