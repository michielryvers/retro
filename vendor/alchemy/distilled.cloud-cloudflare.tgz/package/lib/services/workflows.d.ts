import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const InstanceAlreadyExists_base: S.TaggedErrorClass<"InstanceAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InstanceAlreadyExists extends /*@__PURE__*/ InstanceAlreadyExists_base {
}
declare const InstanceCannotTerminate_base: S.TaggedErrorClass<"InstanceCannotTerminate", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InstanceCannotTerminate extends /*@__PURE__*/ InstanceCannotTerminate_base {
}
declare const InstanceNotFound_base: S.TaggedErrorClass<"InstanceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InstanceNotFound extends /*@__PURE__*/ InstanceNotFound_base {
}
declare const InvalidBody_base: S.TaggedErrorClass<"InvalidBody", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidBody extends /*@__PURE__*/ InvalidBody_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const VersionNotFound_base: S.TaggedErrorClass<"VersionNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class VersionNotFound extends /*@__PURE__*/ VersionNotFound_base {
}
declare const WorkflowInternalError_base: S.TaggedErrorClass<"WorkflowInternalError", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WorkflowInternalError extends /*@__PURE__*/ WorkflowInternalError_base {
}
declare const WorkflowNotFound_base: S.TaggedErrorClass<"WorkflowNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WorkflowNotFound extends /*@__PURE__*/ WorkflowNotFound_base {
}
export type InstancesBulkRequestBodyItemInstanceRetentionErrorRetention = string | number;
export type InstancesBulkRequestBodyItemInstanceRetentionSuccessRetention = string | number;
export interface InstancesBulkRequestBodyItemInstanceRetention {
    /** Specifies the duration in milliseconds or as a string like '5 minutes'. */
    errorRetention?: InstancesBulkRequestBodyItemInstanceRetentionErrorRetention;
    /** Specifies the duration in milliseconds or as a string like '5 minutes'. */
    successRetention?: InstancesBulkRequestBodyItemInstanceRetentionSuccessRetention;
}
export type InstancesBulkRequestBodyItemLocationHint = "wnam" | "weur" | "enam" | "eeur" | "apac" | "apac-ne" | "apac-se" | "oc" | "sam" | "afr" | "me";
export interface InstancesBulkRequestBodyItem {
    /** The system reserves IDs that consist of the `cf_` prefix and exactly 64 lowercase hexadecimal characters. */
    instanceId?: string;
    instanceRetention?: InstancesBulkRequestBodyItemInstanceRetention;
    locationHint?: InstancesBulkRequestBodyItemLocationHint | (string & {});
    /** JSON-encoded event payload passed into the new instance. */
    params?: string;
}
export type InstancesBulkRequestBodyList = Array<InstancesBulkRequestBodyItem>;
export interface BulkInstanceRequest {
    accountId: string;
    workflowName: string;
    body: InstancesBulkRequestBodyList;
}
export type InstancesBulkResultItemStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
export type InstancesBulkResultItemTriggerSource = "unknown" | "api" | "binding" | "event" | "cron";
export interface InstancesBulkResultItem {
    id: string;
    status: InstancesBulkResultItemStatus;
    versionId: string;
    workflowId: string;
    triggerSource?: InstancesBulkResultItemTriggerSource | null;
}
export type InstancesBulkResultList = Array<InstancesBulkResultItem>;
export interface BulkInstanceResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InstancesBulkResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type InstancesCreateRequestInstanceRetentionErrorRetention = string | number;
export type InstancesCreateRequestInstanceRetentionSuccessRetention = string | number;
export interface InstancesCreateRequestInstanceRetention {
    /** Specifies the duration in milliseconds or as a string like '5 minutes'. */
    errorRetention?: InstancesCreateRequestInstanceRetentionErrorRetention;
    /** Specifies the duration in milliseconds or as a string like '5 minutes'. */
    successRetention?: InstancesCreateRequestInstanceRetentionSuccessRetention;
}
export type InstancesCreateRequestLocationHint = "wnam" | "weur" | "enam" | "eeur" | "apac" | "apac-ne" | "apac-se" | "oc" | "sam" | "afr" | "me";
export interface CreateInstanceRequest {
    accountId: string;
    workflowName: string;
    /** The system reserves IDs that consist of the `cf_` prefix and exactly 64 lowercase hexadecimal characters. */
    instanceId?: string;
    instanceRetention?: InstancesCreateRequestInstanceRetention;
    locationHint?: InstancesCreateRequestLocationHint | (string & {});
    /** JSON-encoded event payload passed into the new instance. */
    params?: string;
}
export type InstancesCreateResponseStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
export type InstancesCreateResponseTriggerSource = "unknown" | "api" | "binding" | "event" | "cron";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInstanceResponse {
    id: string;
    status: InstancesCreateResponseStatus;
    versionId: string;
    workflowId: string;
    triggerSource?: InstancesCreateResponseTriggerSource | null;
}
export interface CreateInstanceEventRequest {
    accountId: string;
    workflowName: string;
    instanceId: string;
    eventType: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInstanceEventResponse {
    instanceId: string;
    /** Accepts ISO 8601 with no timezone offsets and in UTC. */
    timestamp: string;
}
export interface DeleteWorkflowRequest {
    accountId: string;
    workflowName: string;
}
export type DeleteResponseStatus = "ok";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteWorkflowResponse {
    status: DeleteResponseStatus;
    success: boolean;
}
export type InstancesGetRequestOrder = "asc" | "desc";
export interface GetInstanceRequest {
    accountId: string;
    workflowName: string;
    instanceId: string;
    /** Step ordering: "asc" (default, oldest first) or "desc" (newest first). */
    order?: InstancesGetRequestOrder | (string & {});
    /** When true, omits step details and returns only metadata with step_count. */
    simple?: boolean;
}
export interface InstancesGetResponseError {
    message: string;
    name: string;
}
export type InstancesGetResponseOutput = string | number;
export type InstancesGetResponseRollbackError = InstancesGetResponseError;
export type InstancesGetResponseRollbackOutcome = "complete" | "failed";
export interface InstancesGetResponseRollback {
    error: InstancesGetResponseError;
    outcome: InstancesGetResponseRollbackOutcome;
}
export type InstancesGetResponseStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
export type InstancesGetResponseStepsItemCase0AttemptsItemError = InstancesGetResponseError;
export interface InstancesGetResponseStepsItemCase0AttemptsItem {
    end: string;
    error: InstancesGetResponseError;
    start: string;
    success: boolean;
}
export type InstancesGetResponseStepsItemCase0AttemptsList = Array<InstancesGetResponseStepsItemCase0AttemptsItem>;
export type InstancesGetResponseStepsItemCase0ConfigRetriesDelay = string | number;
export type InstancesGetResponseStepsItemCase0ConfigRetriesBackoff = "constant" | "linear" | "exponential";
export interface InstancesGetResponseStepsItemCase0ConfigRetries {
    /** Specifies the delay duration. The value '[dynamic]' means that a user-supplied function computes the delay. */
    delay: InstancesGetResponseStepsItemCase0ConfigRetriesDelay;
    limit: number;
    backoff?: InstancesGetResponseStepsItemCase0ConfigRetriesBackoff | null;
}
export type InstancesGetResponseStepsItemCase0ConfigTimeout = string | number;
export type InstancesGetResponseStepsItemCase0ConfigSensitive = "output";
export interface InstancesGetResponseStepsItemCase0Config {
    retries: InstancesGetResponseStepsItemCase0ConfigRetries;
    /** Specifies the timeout duration. */
    timeout: InstancesGetResponseStepsItemCase0ConfigTimeout;
    /** When set to 'output', step output is redacted from log and step output responses. */
    sensitive?: InstancesGetResponseStepsItemCase0ConfigSensitive | null;
}
export type InstancesGetResponseStepsItemCase0Type = "step" | "rollback";
export interface InstancesGetResponseStepsItemCase0 {
    attempts: InstancesGetResponseStepsItemCase0AttemptsList;
    config: InstancesGetResponseStepsItemCase0Config;
    end: string;
    name: string;
    output: string;
    start: string;
    success: boolean;
    type: InstancesGetResponseStepsItemCase0Type;
}
export type InstancesGetResponseStepsItemCase1Error = InstancesGetResponseError;
export type InstancesGetResponseStepsItemCase1Type = "sleep";
export interface InstancesGetResponseStepsItemCase1 {
    end: string;
    error: InstancesGetResponseError;
    finished: boolean;
    name: string;
    start: string;
    type: InstancesGetResponseStepsItemCase1Type;
}
export interface InstancesGetResponseStepsItemCase2Trigger {
    source: string;
}
export type InstancesGetResponseStepsItemCase2Type = "termination";
export interface InstancesGetResponseStepsItemCase2 {
    trigger: InstancesGetResponseStepsItemCase2Trigger;
    type: InstancesGetResponseStepsItemCase2Type;
}
export type InstancesGetResponseStepsItemCase3Error = InstancesGetResponseError;
export type InstancesGetResponseStepsItemCase3Type = "waitForEvent";
export interface InstancesGetResponseStepsItemCase3 {
    end: string;
    error: InstancesGetResponseError;
    finished: boolean;
    name: string;
    start: string;
    type: InstancesGetResponseStepsItemCase3Type;
    eventType?: string | null;
    output?: string | null;
}
export type InstancesGetResponseStepsItem = InstancesGetResponseStepsItemCase0 | InstancesGetResponseStepsItemCase1 | InstancesGetResponseStepsItemCase2 | InstancesGetResponseStepsItemCase3;
export type InstancesGetResponseStepsList = Array<InstancesGetResponseStepsItem>;
export type InstancesGetResponseTriggerSource = "unknown" | "api" | "binding" | "event" | "cron";
export interface InstancesGetResponseTrigger {
    source: InstancesGetResponseTriggerSource;
}
export interface InstancesGetResponseSchedule {
    cron: string;
    scheduledTime: number;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInstanceResponse {
    end: string;
    error: InstancesGetResponseError;
    output: InstancesGetResponseOutput;
    params: unknown;
    queued: string;
    rollback: InstancesGetResponseRollback;
    start: string;
    status: InstancesGetResponseStatus;
    stepCount: number;
    steps: InstancesGetResponseStepsList;
    success: boolean;
    trigger: InstancesGetResponseTrigger;
    versionId: string;
    schedule?: InstancesGetResponseSchedule | null;
}
export interface GetVersionRequest {
    accountId: string;
    workflowName: string;
    versionId: string;
}
export type VersionsGetResponseLanguage = "javascript" | "python";
export interface VersionsGetResponseConcurrency {
    /** Maximum number of instances of this workflow that can run concurrently. Additional instances are queued and started as running instances complete. Must not exceed the account concurrency limit. */
    limit?: number | null;
}
export interface VersionsGetResponseDefaultRetention {
    /** Default error retention in milliseconds. */
    errorRetention?: number | null;
    /** Default success retention in milliseconds. */
    successRetention?: number | null;
}
export interface VersionsGetResponseLimits {
    steps?: number | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetVersionResponse {
    id: string;
    className: string;
    createdOn: string;
    hasDag: boolean;
    /** The programming language of the workflow implementation. */
    language: VersionsGetResponseLanguage;
    modifiedOn: string;
    workflowId: string;
    concurrency?: VersionsGetResponseConcurrency | null;
    defaultRetention?: VersionsGetResponseDefaultRetention | null;
    limits?: VersionsGetResponseLimits | null;
}
export interface GetWorkflowRequest {
    accountId: string;
    workflowName: string;
}
export type GetResponseInstancesMap = {
    [key: string]: number | undefined;
};
export interface GetResponseSchedulesItem {
    cron: string;
    nextInstance: string;
}
export type GetResponseSchedulesList = Array<GetResponseSchedulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetWorkflowResponse {
    id: string;
    className: string;
    createdOn: string;
    instances: GetResponseInstancesMap;
    modifiedOn: string;
    name: string;
    scriptName: string;
    triggeredOn: string;
    schedules?: GetResponseSchedulesList | null;
    /** Whether the bound Worker was deleted, leaving this Workflow inactive. */
    scriptDeleted?: boolean | null;
}
export interface GraphVersionRequest {
    accountId: string;
    workflowName: string;
    versionId: string;
}
export type VersionsGraphResponseGraphWorkflowFunctionsValueNodesList = Array<unknown>;
export type VersionsGraphResponseGraphWorkflowFunctionsValueType = "function_def";
export interface VersionsGraphResponseGraphWorkflowFunctionsValue {
    name: string;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowFunctionsValueNodesList;
    type: VersionsGraphResponseGraphWorkflowFunctionsValueType;
}
export type VersionsGraphResponseGraphWorkflowFunctionsMap = {
    [key: string]: VersionsGraphResponseGraphWorkflowFunctionsValue | undefined;
};
export type VersionsGraphResponseGraphWorkflowNodesItemCase0Duration = string | number;
export type VersionsGraphResponseGraphWorkflowNodesItemCase0Type = "step_sleep";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase0 {
    /** Duration as milliseconds (number) or human-readable string. */
    duration: VersionsGraphResponseGraphWorkflowNodesItemCase0Duration;
    name: string;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase0Type;
    resolves?: number | null;
    starts?: number | null;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetriesBackoff = "constant" | "linear" | "exponential";
export type VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetriesDelay = string | number;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetries {
    /** Backoff strategy for step retries. */
    backoff: VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetriesBackoff;
    /** Duration as milliseconds (number) or human-readable string. */
    delay: VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetriesDelay;
    limit: number;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigTimeout = string | number;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase1Config {
    /** Retry policy for a step. */
    retries: VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetries;
    /** Duration as milliseconds (number) or human-readable string. */
    timeout: VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigTimeout;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase1NodesList = Array<unknown>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase1Type = "step_do";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase1 {
    /** Configuration for a step (retries and timeout). */
    config: VersionsGraphResponseGraphWorkflowNodesItemCase1Config;
    name: string;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase1NodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase1Type;
    resolves?: number | null;
    starts?: number | null;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase2OptionsTimeout = string | number;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase2Options {
    eventType: string;
    /** Duration as milliseconds (number) or human-readable string. */
    timeout: VersionsGraphResponseGraphWorkflowNodesItemCase2OptionsTimeout;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase2Type = "step_wait_for_event";
export type VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadTypeType = "unknown";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadType {
    type: VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadTypeType;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1FieldsMap = {
    [key: string]: unknown | undefined;
};
export type VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1Type = "object";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1 {
    /** Nested JsonShape fields (recursive structure). */
    fields: VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1FieldsMap;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1Type;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase2Payload = VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadType | VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase2 {
    name: string;
    /** Options for a waitForEvent step. */
    options: VersionsGraphResponseGraphWorkflowNodesItemCase2Options;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase2Type;
    /** Shape descriptor for JSON payloads. */
    payload?: VersionsGraphResponseGraphWorkflowNodesItemCase2Payload | null;
    resolves?: number | null;
    starts?: number | null;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase3Type = "step_sleep_until";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase3 {
    name: string;
    timestamp: string;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase3Type;
    resolves?: number | null;
    starts?: number | null;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase4NodesList = Array<unknown>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase4Type = "loop";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase4 {
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase4NodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase4Type;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase5Kind = "all" | "any" | "all_settled" | "race";
export type VersionsGraphResponseGraphWorkflowNodesItemCase5NodesList = Array<unknown>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase5Type = "parallel";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase5 {
    /** Parallel execution strategy. */
    kind: VersionsGraphResponseGraphWorkflowNodesItemCase5Kind;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase5NodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase5Type;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlockNodesList = Array<unknown>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlockType = "block";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlock {
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlockNodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlockType;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlockNodesList = Array<unknown>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlockType = "block";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlock {
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlockNodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlockType;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlockNodesList = Array<unknown>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlockType = "block";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlock {
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlockNodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlockType;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase6Type = "try";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase6 {
    catchBlock: VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlock;
    finallyBlock: VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlock;
    tryBlock: VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlock;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase6Type;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase7NodesList = Array<unknown>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase7Type = "block";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase7 {
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase7NodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase7Type;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesItemNodesList = Array<unknown>;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesItem {
    condition: string;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesItemNodesList;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesList = Array<VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesItem>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase8Type = "if";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase8 {
    branches: VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase8Type;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesItemNodesList = Array<unknown>;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesItem {
    condition: string;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesItemNodesList;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesList = Array<VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesItem>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase9Type = "switch";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase9 {
    branches: VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesList;
    discriminant: string;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase9Type;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValueNodesList = Array<unknown>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValueType = "function_def";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValue {
    name: string;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValueNodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValueType;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsMap = {
    [key: string]: VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValue | undefined;
};
export type VersionsGraphResponseGraphWorkflowNodesItemCase10NodesList = Array<unknown>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase10Type = "start";
export type VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadTypeType = "unknown";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadType {
    type: VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadTypeType;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1FieldsMap = {
    [key: string]: unknown | undefined;
};
export type VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1Type = "object";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1 {
    /** Nested JsonShape fields (recursive structure). */
    fields: VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1FieldsMap;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1Type;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase10Payload = VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadType | VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase10 {
    className: string;
    functions: VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsMap;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase10NodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase10Type;
    /** Shape descriptor for JSON payloads. */
    payload?: VersionsGraphResponseGraphWorkflowNodesItemCase10Payload | null;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase11Type = "function_call";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase11 {
    name: string;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase11Type;
    resolves?: number | null;
    starts?: number | null;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase12NodesList = Array<unknown>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase12Type = "function_def";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase12 {
    name: string;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase12NodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase12Type;
}
export type VersionsGraphResponseGraphWorkflowNodesItemCase13Kind = "break" | "return";
export type VersionsGraphResponseGraphWorkflowNodesItemCase13Type = "break";
export interface VersionsGraphResponseGraphWorkflowNodesItemCase13 {
    /** Break or return from a loop. */
    kind: VersionsGraphResponseGraphWorkflowNodesItemCase13Kind;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase13Type;
}
export type VersionsGraphResponseGraphWorkflowNodesItem = VersionsGraphResponseGraphWorkflowNodesItemCase0 | VersionsGraphResponseGraphWorkflowNodesItemCase1 | VersionsGraphResponseGraphWorkflowNodesItemCase2 | VersionsGraphResponseGraphWorkflowNodesItemCase3 | VersionsGraphResponseGraphWorkflowNodesItemCase4 | VersionsGraphResponseGraphWorkflowNodesItemCase5 | VersionsGraphResponseGraphWorkflowNodesItemCase6 | VersionsGraphResponseGraphWorkflowNodesItemCase7 | VersionsGraphResponseGraphWorkflowNodesItemCase8 | VersionsGraphResponseGraphWorkflowNodesItemCase9 | VersionsGraphResponseGraphWorkflowNodesItemCase10 | VersionsGraphResponseGraphWorkflowNodesItemCase11 | VersionsGraphResponseGraphWorkflowNodesItemCase12 | VersionsGraphResponseGraphWorkflowNodesItemCase13;
export type VersionsGraphResponseGraphWorkflowNodesList = Array<VersionsGraphResponseGraphWorkflowNodesItem>;
export type VersionsGraphResponseGraphWorkflowPayloadTypeType = "unknown";
export interface VersionsGraphResponseGraphWorkflowPayloadType {
    type: VersionsGraphResponseGraphWorkflowPayloadTypeType;
}
export type VersionsGraphResponseGraphWorkflowPayloadCase1FieldsMap = {
    [key: string]: unknown | undefined;
};
export type VersionsGraphResponseGraphWorkflowPayloadCase1Type = "object";
export interface VersionsGraphResponseGraphWorkflowPayloadCase1 {
    /** Nested JsonShape fields (recursive structure). */
    fields: VersionsGraphResponseGraphWorkflowPayloadCase1FieldsMap;
    type: VersionsGraphResponseGraphWorkflowPayloadCase1Type;
}
export type VersionsGraphResponseGraphWorkflowPayload = VersionsGraphResponseGraphWorkflowPayloadType | VersionsGraphResponseGraphWorkflowPayloadCase1;
export interface VersionsGraphResponseGraphWorkflow {
    className: string;
    functions: VersionsGraphResponseGraphWorkflowFunctionsMap;
    nodes: VersionsGraphResponseGraphWorkflowNodesList;
    /** Shape descriptor for JSON payloads. */
    payload?: VersionsGraphResponseGraphWorkflowPayload | null;
}
export interface VersionsGraphResponseGraph {
    version: number;
    /** A parsed workflow entrypoint with its step graph. */
    workflow: VersionsGraphResponseGraphWorkflow;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GraphVersionResponse {
    id: string;
    className: string;
    createdOn: string;
    /** Versioned workflow graph payload. */
    graph: VersionsGraphResponseGraph;
    modifiedOn: string;
    workflowId: string;
}
export type InstancesListRequestDirection = "asc" | "desc";
export type InstancesListRequestStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
export interface ListInstancesRequest {
    accountId: string;
    workflowName: string;
    /** Opaque token for cursor-based pagination. Mutually exclusive with `page`. */
    cursor?: string;
    /** Accepts ISO 8601 with no timezone offsets and in UTC. */
    dateEnd?: string;
    /** Accepts ISO 8601 with no timezone offsets and in UTC. */
    dateStart?: string;
    /** Defines the direction for cursor-based pagination. */
    direction?: InstancesListRequestDirection | (string & {});
    /** Deprecated: use `cursor` for pagination instead. */
    page?: number;
    perPage?: number;
    status?: InstancesListRequestStatus | (string & {});
}
export type InstancesListResultItemStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
export type InstancesListResultItemTriggerSource = "unknown" | "api" | "binding" | "event" | "cron";
export interface InstancesListResultItem {
    id: string;
    createdOn: string;
    endedOn: string;
    modifiedOn: string;
    startedOn: string;
    status: InstancesListResultItemStatus;
    versionId: string;
    workflowId: string;
    triggerSource?: InstancesListResultItemTriggerSource | null;
}
export type InstancesListResultList = Array<InstancesListResultItem>;
export interface ListInstancesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InstancesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListVersionsRequest {
    accountId: string;
    workflowName: string;
    page?: number;
    perPage?: number;
}
export type VersionsListResultItemLanguage = "javascript" | "python";
export type VersionsListResultItemConcurrency = VersionsGetResponseConcurrency;
export type VersionsListResultItemDefaultRetention = VersionsGetResponseDefaultRetention;
export type VersionsListResultItemLimits = VersionsGetResponseLimits;
export interface VersionsListResultItem {
    id: string;
    className: string;
    createdOn: string;
    hasDag: boolean;
    /** The programming language of the workflow implementation. */
    language: VersionsListResultItemLanguage;
    modifiedOn: string;
    workflowId: string;
    concurrency?: VersionsGetResponseConcurrency | null;
    defaultRetention?: VersionsGetResponseDefaultRetention | null;
    limits?: VersionsGetResponseLimits | null;
}
export type VersionsListResultList = Array<VersionsListResultItem>;
export interface ListVersionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: VersionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListWorkflowsRequest {
    accountId: string;
    page?: number;
    perPage?: number;
    /** Allows filtering workflows` name. */
    search?: string;
}
export type ListResultItemInstancesMap = {
    [key: string]: number | undefined;
};
export type ListResultItemSchedulesItem = GetResponseSchedulesItem;
export type ListResultItemSchedulesList = Array<GetResponseSchedulesItem>;
export interface ListResultItem {
    id: string;
    className: string;
    createdOn: string;
    instances: ListResultItemInstancesMap;
    modifiedOn: string;
    name: string;
    scriptName: string;
    triggeredOn: string;
    schedules?: ListResultItemSchedulesList | null;
    /** Whether the bound Worker was deleted, leaving this Workflow inactive. */
    scriptDeleted?: boolean | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListWorkflowsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type InstancesStatusEditRequestStatus = "pause" | "resume" | "terminate" | "restart";
export type InstancesStatusEditRequestFromType = "do" | "sleep" | "waitForEvent";
export interface InstancesStatusEditRequestFrom {
    name: string;
    /** exclusiveMinimum */
    count?: number;
    type?: InstancesStatusEditRequestFromType | (string & {});
}
export interface PatchInstanceStatusRequest {
    accountId: string;
    workflowName: string;
    instanceId: string;
    status: InstancesStatusEditRequestStatus | (string & {});
    /** Run rollback before terminating. */
    rollback?: boolean;
    /** Step to restart from. */
    from?: InstancesStatusEditRequestFrom;
}
export type InstancesStatusEditResponseStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchInstanceStatusResponse {
    status: InstancesStatusEditResponseStatus;
    /** Accepts ISO 8601 with no timezone offsets and in UTC. */
    timestamp: string;
}
export interface UpdateRequestConcurrency {
    /** Maximum number of instances of this workflow that can run concurrently. Additional instances are queued and started as running instances complete. Must not exceed the account concurrency limit. */
    limit?: number;
}
export type UpdateRequestDefaultRetentionErrorRetention = string | number;
export type UpdateRequestDefaultRetentionSuccessRetention = string | number;
export interface UpdateRequestDefaultRetention {
    /** Specifies the duration in milliseconds or as a string like '5 minutes'. */
    errorRetention?: UpdateRequestDefaultRetentionErrorRetention;
    /** Specifies the duration in milliseconds or as a string like '5 minutes'. */
    successRetention?: UpdateRequestDefaultRetentionSuccessRetention;
}
export interface UpdateRequestLimits {
    steps?: number;
}
export interface UpdateRequestSchedulesItem {
    cron: string;
}
export type UpdateRequestSchedulesList = Array<UpdateRequestSchedulesItem>;
export interface PutWorkflowRequest {
    accountId: string;
    workflowName: string;
    className: string;
    scriptName: string;
    concurrency?: UpdateRequestConcurrency;
    /** Default retention applied to instances of this version when they do not set their own retention. */
    defaultRetention?: UpdateRequestDefaultRetention;
    limits?: UpdateRequestLimits;
    schedules?: UpdateRequestSchedulesList;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutWorkflowResponse {
    id: string;
    className: string;
    createdOn: string;
    isDeleted: number;
    modifiedOn: string;
    name: string;
    scriptName: string;
    terminatorRunning: number;
    triggeredOn: string;
    versionId: string;
}
export type InstancesStepRequestType = "step" | "waitForEvent";
export interface StepInstanceRequest {
    accountId: string;
    workflowName: string;
    instanceId: string;
    /** Exact step name from the instance logs response, including the generated counter suffix. */
    name: string;
    /** Step type to disambiguate step.do and waitForEvent entries that share the same name. */
    type: InstancesStepRequestType | (string & {});
    /** Specific attempt number to retrieve output or error for. */
    attempt?: number;
}
export type InstancesStepResponseError = InstancesGetResponseError;
export type InstancesStepResponseStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StepInstanceResponse {
    /** Error details when status='errored'; null otherwise. */
    error: InstancesGetResponseError;
    status: InstancesStepResponseStatus;
    /** The event type the step is waiting on, as supplied to step.waitForEvent. Only present when type='waitForEvent'. */
    eventType?: string | null;
    /** Contains the full step output or waitForEvent payload without truncation. Uses '[REDACTED]' for sensitive outputs. Contains a value when status='complete'. May contain a ReadableStream when step.do returns one; the response serves stream outputs as application/octet-stream rather than JSON. */
    output?: unknown | null;
}
export type BulkInstanceError = WorkflowNotFound | InstanceAlreadyExists | InvalidRoute | InvalidBody | CloudflareOpError;
/** Creates multiple workflow instances in a single batch operation. */
export declare const bulkInstance: API.PaginatedOperationMethod<BulkInstanceRequest, BulkInstanceResponse, BulkInstanceError, CloudflareOpContext, InstancesBulkResultItem>;
export type CreateInstanceError = WorkflowNotFound | InstanceAlreadyExists | InvalidRoute | InvalidBody | CloudflareOpError;
/** Creates a new instance of a workflow, starting its execution. */
export declare const createInstance: API.OperationMethod<CreateInstanceRequest, CreateInstanceResponse, CreateInstanceError, CloudflareOpContext>;
export type CreateInstanceEventError = WorkflowNotFound | InvalidRoute | InstanceNotFound | InvalidBody | CloudflareOpError;
/** Sends an event to a running workflow instance to trigger state transitions. */
export declare const createInstanceEvent: API.OperationMethod<CreateInstanceEventRequest, CreateInstanceEventResponse, CreateInstanceEventError, CloudflareOpContext>;
export type DeleteWorkflowError = WorkflowNotFound | InvalidRoute | CloudflareOpError;
/** Deletes a Workflow. This only deletes the Workflow and does not delete or modify any Worker associated to this Workflow or bounded to it. */
export declare const deleteWorkflow: API.OperationMethod<DeleteWorkflowRequest, DeleteWorkflowResponse, DeleteWorkflowError, CloudflareOpContext>;
export type GetInstanceError = WorkflowNotFound | InvalidRoute | InstanceNotFound | CloudflareOpError;
/** Retrieves logs and execution status for a specific workflow instance. */
export declare const getInstance: API.OperationMethod<GetInstanceRequest, GetInstanceResponse, GetInstanceError, CloudflareOpContext>;
export type GetVersionError = WorkflowNotFound | InvalidRoute | VersionNotFound | CloudflareOpError;
/** Retrieves details for a specific deployed workflow version. */
export declare const getVersion: API.OperationMethod<GetVersionRequest, GetVersionResponse, GetVersionError, CloudflareOpContext>;
export type GetWorkflowError = WorkflowNotFound | InvalidRoute | CloudflareOpError;
/** Retrieves configuration and metadata for a specific workflow. */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest, GetWorkflowResponse, GetWorkflowError, CloudflareOpContext>;
export type GraphVersionError = CloudflareOpError;
/** Retrieves the graph visualization of a workflow version. */
export declare const graphVersion: API.OperationMethod<GraphVersionRequest, GraphVersionResponse, GraphVersionError, CloudflareOpContext>;
export type ListInstancesError = WorkflowNotFound | WorkflowInternalError | InvalidRoute | InvalidBody | CloudflareOpError;
/** Lists all instances of a workflow with their execution status. */
export declare const listInstances: API.PaginatedOperationMethod<ListInstancesRequest, ListInstancesResponse, ListInstancesError, CloudflareOpContext, InstancesListResultItem>;
export type ListVersionsError = WorkflowNotFound | InvalidRoute | CloudflareOpError;
/** Lists all deployed versions of a workflow. */
export declare const listVersions: API.PaginatedOperationMethod<ListVersionsRequest, ListVersionsResponse, ListVersionsError, CloudflareOpContext, VersionsListResultItem>;
export type ListWorkflowsError = CloudflareOpError;
/** Lists all workflows configured for the account. */
export declare const listWorkflows: API.PaginatedOperationMethod<ListWorkflowsRequest, ListWorkflowsResponse, ListWorkflowsError, CloudflareOpContext, ListResultItem>;
export type PatchInstanceStatusError = WorkflowNotFound | InvalidRoute | InstanceNotFound | InstanceCannotTerminate | CloudflareOpError;
/** Changes the execution status of a workflow instance (e.g., pause, resume, terminate). */
export declare const patchInstanceStatus: API.OperationMethod<PatchInstanceStatusRequest, PatchInstanceStatusResponse, PatchInstanceStatusError, CloudflareOpContext>;
export type PutWorkflowError = WorkflowInternalError | InvalidRoute | CloudflareOpError;
/** Creates a new workflow or updates an existing workflow definition. */
export declare const putWorkflow: API.OperationMethod<PutWorkflowRequest, PutWorkflowResponse, PutWorkflowError, CloudflareOpContext>;
export type StepInstanceError = CloudflareOpError;
/** Retrieves the full, untruncated output for a specific step on a workflow instance. Returns a flat status-shaped JSON body with step `status` ('running' | 'waiting' | 'complete' | 'errored'), `error` (nullable), and `output` (the step value, or null while running/waiting/errored). When the step returned a ReadableStream from step.do, the response is served as 'application/octet-stream' with the raw bytes as the body instead of JSON. A `status='running'` response with non-null `error` indicates the step is currently retrying after a prior attempt failed. */
export declare const stepInstance: API.OperationMethod<StepInstanceRequest, StepInstanceResponse, StepInstanceError, CloudflareOpContext>;
//# sourceMappingURL=workflows.d.ts.map