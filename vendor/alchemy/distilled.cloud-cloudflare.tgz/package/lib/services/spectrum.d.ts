import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const SpectrumAppNotFound_base: S.TaggedErrorClass<"SpectrumAppNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SpectrumAppNotFound extends /*@__PURE__*/ SpectrumAppNotFound_base {
}
declare const SpectrumProtocolNotAvailable_base: S.TaggedErrorClass<"SpectrumProtocolNotAvailable", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SpectrumProtocolNotAvailable extends /*@__PURE__*/ SpectrumProtocolNotAvailable_base {
}
export type AppsCreateRequestDnsType = "CNAME" | "ADDRESS";
export interface AppsCreateRequestDns {
    /** The name of the DNS record associated with the application. */
    name?: string;
    /** The type of DNS record associated with the application. */
    type?: AppsCreateRequestDnsType | (string & {});
}
export type AppsCreateRequestTrafficType = "direct" | "http" | "https" | "worker";
export type AppsCreateRequestEdgeIpsDynamicConnectivity = "all" | "ipv4" | "ipv6";
export type AppsCreateRequestEdgeIpsDynamicType = "dynamic";
export interface AppsCreateRequestEdgeIpsDynamic {
    /** The IP versions supported for inbound connections on Spectrum anycast IPs. */
    connectivity?: AppsCreateRequestEdgeIpsDynamicConnectivity | (string & {});
    /** The type of edge IP configuration specified. Dynamically allocated edge IPs use Spectrum anycast IPs in accordance with the connectivity you specify. Only valid with CNAME DNS names. */
    type?: AppsCreateRequestEdgeIpsDynamicType | (string & {});
}
export type AppsCreateRequestEdgeIpsStaticIpsList = Array<string>;
export type AppsCreateRequestEdgeIpsStaticType = "static";
export interface AppsCreateRequestEdgeIpsStatic {
    /** The array of customer owned IPs we broadcast via anycast for this hostname and application. */
    ips?: AppsCreateRequestEdgeIpsStaticIpsList;
    /** The type of edge IP configuration specified. Statically allocated edge IPs use customer IPs in accordance with the ips array you specify. Only valid with ADDRESS DNS names. */
    type?: AppsCreateRequestEdgeIpsStaticType | (string & {});
}
export type AppsCreateRequestEdgeIps = AppsCreateRequestEdgeIpsDynamic | AppsCreateRequestEdgeIpsStatic;
export type AppsCreateRequestOriginDirectList = Array<string>;
export type AppsCreateRequestOriginDnsType = "" | "A" | "AAAA" | "SRV";
export interface AppsCreateRequestOriginDns {
    /** The name of the DNS record associated with the origin. */
    name?: string;
    /** The TTL of our resolution of your DNS record in seconds. */
    ttl?: number;
    /** The type of DNS record associated with the origin. "" is used to specify a combination of A/AAAA records. */
    type?: AppsCreateRequestOriginDnsType | (string & {});
}
export type AppsCreateRequestOriginPort = string | number;
export type AppsCreateRequestProxyProtocol = "off" | "v1" | "v2" | "simple";
export type AppsCreateRequestTls = "off" | "flexible" | "full" | "strict";
export interface CreateAppRequest {
    /** Zone identifier. */
    zoneId: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsCreateRequestDns;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** Determines how data travels from the edge to your origin. When set to "direct", Spectrum will send traffic directly to your origin, and the application's type is derived from the `protocol`. When set to "http" or "https", Spectrum will apply Cloudflare's HTTP/HTTPS features as it sends traffic to your origin, and the application type matches this property exactly. When set to "worker", traffic is sent to the Worker specified by `origin_worker_id`. */
    trafficType?: AppsCreateRequestTrafficType | (string & {});
    /** Enables Argo Smart Routing for this application. Notes: Only available for TCP or UDP applications with traffic_type set to "direct". */
    argoSmartRouting?: boolean;
    /** The anycast edge IP configuration for the hostname of this application. */
    edgeIps?: AppsCreateRequestEdgeIps;
    /** Enables IP Access Rules for this application. Notes: Only available for TCP applications. */
    ipFirewall?: boolean;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsCreateRequestOriginDirectList;
    /** The name and type of DNS record for the Spectrum application. */
    originDns?: AppsCreateRequestOriginDns;
    /** The destination port at the origin. Only specified in conjunction with origin_dns. May use an integer to specify a single origin port, for example `1000`, or a string to specify a range of origin ports, for example `"1000-2000"`. Notes: If specifying a port range, the number of ports in the range must match the number of ports specified in the "protocol" field. */
    originPort?: AppsCreateRequestOriginPort;
    /** Optional Worker script tag (worker ID) to use as the application's origin. Only supported for TCP applications with traffic_type "worker"; mutually exclusive with origin_direct, origin_dns, origin_port, proxy_protocol, and argo_smart_routing. tls may only be "off" or "flexible". */
    originWorkerId?: string;
    /** Enables Proxy Protocol to the origin. Refer to [Enable Proxy protocol](https://developers.cloudflare.com/spectrum/getting-started/proxy-protocol/) for implementation details on PROXY Protocol V1, PROXY Protocol V2, and Simple Proxy Protocol. */
    proxyProtocol?: AppsCreateRequestProxyProtocol | (string & {});
    /** The type of TLS termination associated with the application. */
    tls?: AppsCreateRequestTls | (string & {});
    /** Optional UUID of a virtual network for routing origin traffic through tunnel virtual networks. */
    virtualNetworkId?: string;
}
export type AppsCreateResultSpectrumConfigAppConfigDnsType = "CNAME" | "ADDRESS";
export interface AppsCreateResultSpectrumConfigAppConfigDns {
    /** The name of the DNS record associated with the application. */
    name?: string | null;
    /** The type of DNS record associated with the application. */
    type?: AppsCreateResultSpectrumConfigAppConfigDnsType | null;
}
export type AppsCreateResultSpectrumConfigAppConfigTrafficType = "direct" | "http" | "https" | "worker";
export type AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity = "all" | "ipv4" | "ipv6";
export type AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamicType = "dynamic";
export interface AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamic {
    /** The IP versions supported for inbound connections on Spectrum anycast IPs. */
    connectivity?: AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity | null;
    /** The type of edge IP configuration specified. Dynamically allocated edge IPs use Spectrum anycast IPs in accordance with the connectivity you specify. Only valid with CNAME DNS names. */
    type?: AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamicType | null;
}
export type AppsCreateResultSpectrumConfigAppConfigEdgeIpsStaticIpsList = Array<string>;
export type AppsCreateResultSpectrumConfigAppConfigEdgeIpsStaticType = "static";
export interface AppsCreateResultSpectrumConfigAppConfigEdgeIpsStatic {
    /** The array of customer owned IPs we broadcast via anycast for this hostname and application. */
    ips?: AppsCreateResultSpectrumConfigAppConfigEdgeIpsStaticIpsList | null;
    /** The type of edge IP configuration specified. Statically allocated edge IPs use customer IPs in accordance with the ips array you specify. Only valid with ADDRESS DNS names. */
    type?: AppsCreateResultSpectrumConfigAppConfigEdgeIpsStaticType | null;
}
export type AppsCreateResultSpectrumConfigAppConfigEdgeIps = AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamic | AppsCreateResultSpectrumConfigAppConfigEdgeIpsStatic;
export type AppsCreateResultSpectrumConfigAppConfigOriginDirectList = Array<string>;
export type AppsCreateResultSpectrumConfigAppConfigOriginDnsType = "" | "A" | "AAAA" | "SRV";
export interface AppsCreateResultSpectrumConfigAppConfigOriginDns {
    /** The name of the DNS record associated with the origin. */
    name?: string | null;
    /** The TTL of our resolution of your DNS record in seconds. */
    ttl?: number | null;
    /** The type of DNS record associated with the origin. "" is used to specify a combination of A/AAAA records. */
    type?: AppsCreateResultSpectrumConfigAppConfigOriginDnsType | null;
}
export type AppsCreateResultSpectrumConfigAppConfigOriginPort = string | number;
export type AppsCreateResultSpectrumConfigAppConfigProxyProtocol = "off" | "v1" | "v2" | "simple";
export type AppsCreateResultSpectrumConfigAppConfigTls = "off" | "flexible" | "full" | "strict";
export interface AppsCreateResultSpectrumConfigAppConfig {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsCreateResultSpectrumConfigAppConfigDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** Determines how data travels from the edge to your origin. When set to "direct", Spectrum will send traffic directly to your origin, and the application's type is derived from the `protocol`. When set to "http" or "https", Spectrum will apply Cloudflare's HTTP/HTTPS features as it sends traffic to your origin, and the application type matches this property exactly. When set to "worker", traffic is sent to the Worker specified by `origin_worker_id`. */
    trafficType: AppsCreateResultSpectrumConfigAppConfigTrafficType;
    /** Enables Argo Smart Routing for this application. Notes: Only available for TCP or UDP applications with traffic_type set to "direct". */
    argoSmartRouting?: boolean | null;
    /** The anycast edge IP configuration for the hostname of this application. */
    edgeIps?: AppsCreateResultSpectrumConfigAppConfigEdgeIps | null;
    /** Enables IP Access Rules for this application. Notes: Only available for TCP applications. */
    ipFirewall?: boolean | null;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsCreateResultSpectrumConfigAppConfigOriginDirectList | null;
    /** The name and type of DNS record for the Spectrum application. */
    originDns?: AppsCreateResultSpectrumConfigAppConfigOriginDns | null;
    /** The destination port at the origin. Only specified in conjunction with origin_dns. May use an integer to specify a single origin port, for example `1000`, or a string to specify a range of origin ports, for example `"1000-2000"`. Notes: If specifying a port range, the number of ports in the range must match the number of ports specified in the "protocol" field. */
    originPort?: AppsCreateResultSpectrumConfigAppConfigOriginPort | null;
    /** Optional Worker script tag (worker ID) to use as the application's origin. Only supported for TCP applications with traffic_type "worker"; mutually exclusive with origin_direct, origin_dns, origin_port, proxy_protocol, and argo_smart_routing. tls may only be "off" or "flexible". */
    originWorkerId?: string | null;
    /** Enables Proxy Protocol to the origin. Refer to [Enable Proxy protocol](https://developers.cloudflare.com/spectrum/getting-started/proxy-protocol/) for implementation details on PROXY Protocol V1, PROXY Protocol V2, and Simple Proxy Protocol. */
    proxyProtocol?: AppsCreateResultSpectrumConfigAppConfigProxyProtocol | null;
    /** The type of TLS termination associated with the application. */
    tls?: AppsCreateResultSpectrumConfigAppConfigTls | null;
    /** Optional UUID of a virtual network for routing origin traffic through tunnel virtual networks. */
    virtualNetworkId?: string | null;
}
export type AppsCreateResultSpectrumConfigPaygoAppConfigDnsType = "CNAME" | "ADDRESS";
export interface AppsCreateResultSpectrumConfigPaygoAppConfigDns {
    /** The name of the DNS record associated with the application. */
    name?: string | null;
    /** The type of DNS record associated with the application. */
    type?: AppsCreateResultSpectrumConfigPaygoAppConfigDnsType | null;
}
export type AppsCreateResultSpectrumConfigPaygoAppConfigOriginDirectList = Array<string>;
export interface AppsCreateResultSpectrumConfigPaygoAppConfig {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsCreateResultSpectrumConfigPaygoAppConfigDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsCreateResultSpectrumConfigPaygoAppConfigOriginDirectList | null;
}
export type AppsCreateResult = AppsCreateResultSpectrumConfigAppConfig | AppsCreateResultSpectrumConfigPaygoAppConfig;
export type CreateAppResponse = AppsCreateResult;
export interface DeleteAppRequest {
    /** Zone identifier. */
    zoneId: string;
    /** App identifier. */
    appId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAppResponse {
    /** Identifier. */
    id: string;
}
export interface GetAnalyticAggregateCurrentRequest {
    /** Identifier. */
    zoneId: string;
    /** Comma-delimited list of Spectrum Application Id(s). If provided, the response will be limited to Spectrum Application Id(s) that match. */
    appID?: string;
    /** Co-location identifier. */
    coloName?: string;
}
export interface AnalyticsAggregatesCurrentsGetResultItem {
    /** Application identifier. */
    appID: string;
    /** Number of bytes sent. */
    bytesEgress: number;
    /** Number of bytes received. */
    bytesIngress: number;
    /** Number of connections. */
    connections: number;
    /** Average duration of connections. */
    durationAvg: number;
}
export type AnalyticsAggregatesCurrentsGetResultList = Array<AnalyticsAggregatesCurrentsGetResultItem>;
export type GetAnalyticAggregateCurrentResponse = AnalyticsAggregatesCurrentsGetResultList;
export type AnalyticsEventsBytimesGetRequestTimeDelta = "year" | "quarter" | "month" | "week" | "day" | "hour" | "dekaminute" | "minute";
export type AnalyticsEventsBytimesGetRequestDimensionsList = Array<string>;
export type AnalyticsEventsBytimesGetRequestMetrics = "count" | "bytesIngress" | "bytesEgress" | "durationAvg" | "durationMedian" | "duration90th" | "duration99th";
export type AnalyticsEventsBytimesGetRequestMetricsList = Array<AnalyticsEventsBytimesGetRequestMetrics | (string & {})>;
export type AnalyticsEventsBytimesGetRequestSortList = Array<string>;
export interface GetAnalyticEventBytimeRequest {
    /** Identifier. */
    zoneId: string;
    /** Used to select time series resolution. */
    timeDelta: AnalyticsEventsBytimesGetRequestTimeDelta | (string & {});
    /** Can be used to break down the data by given attributes. Options are: */
    dimensions?: AnalyticsEventsBytimesGetRequestDimensionsList;
    /** Used to filter rows by one or more dimensions. Filters can be combined using OR and AND boolean logic. AND takes precedence over OR in all the expressions. The OR operator is defined using a comma (,) or OR keyword surrounded by whitespace. The AND operator is defined using a semicolon (;) or AND keyword surrounded by whitespace. Note that the semicolon is a reserved character in URLs (rfc1738) and needs to be percent-encoded as %3B. Comparison options are: */
    filters?: string;
    /** One or more metrics to compute. Options are: */
    metrics?: AnalyticsEventsBytimesGetRequestMetricsList;
    /** Start of time interval to query, defaults to `until` - 6 hours. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    since?: string;
    /** The sort order for the result set; sort fields must be included in `metrics` or `dimensions`. */
    sort?: AnalyticsEventsBytimesGetRequestSortList;
    /** End of time interval to query, defaults to current time. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    until?: string;
}
export type AnalyticsEventsBytimesGetResponseDataItemDimensionsList = Array<string>;
export type AnalyticsEventsBytimesGetResponseDataItemMetricsCase0List = Array<number>;
export type AnalyticsEventsBytimesGetResponseDataItemMetricsCase1ItemList = Array<number>;
export type AnalyticsEventsBytimesGetResponseDataItemMetricsCase1List = Array<AnalyticsEventsBytimesGetResponseDataItemMetricsCase1ItemList>;
export type AnalyticsEventsBytimesGetResponseDataItemMetrics = AnalyticsEventsBytimesGetResponseDataItemMetricsCase0List | AnalyticsEventsBytimesGetResponseDataItemMetricsCase1List;
export interface AnalyticsEventsBytimesGetResponseDataItem {
    dimensions?: AnalyticsEventsBytimesGetResponseDataItemDimensionsList | null;
    metrics?: AnalyticsEventsBytimesGetResponseDataItemMetrics | null;
}
export type AnalyticsEventsBytimesGetResponseDataList = Array<AnalyticsEventsBytimesGetResponseDataItem>;
export type AnalyticsEventsBytimesGetResponseMaxMap = {
    [key: string]: number | undefined;
};
export type AnalyticsEventsBytimesGetResponseMinMap = {
    [key: string]: number | undefined;
};
export type AnalyticsEventsBytimesGetResponseQueryDimensionsItem = "event" | "appID" | "coloName" | "ipVersion";
export type AnalyticsEventsBytimesGetResponseQueryDimensionsList = Array<AnalyticsEventsBytimesGetResponseQueryDimensionsItem>;
export type AnalyticsEventsBytimesGetResponseQueryMetricsItem = "count" | "bytesIngress" | "bytesEgress" | "durationAvg" | "durationMedian" | "duration90th" | "duration99th";
export type AnalyticsEventsBytimesGetResponseQueryMetricsList = Array<AnalyticsEventsBytimesGetResponseQueryMetricsItem>;
export type AnalyticsEventsBytimesGetResponseQuerySortList = Array<string>;
export interface AnalyticsEventsBytimesGetResponseQuery {
    /** Can be used to break down the data by given attributes. Options are: */
    dimensions?: AnalyticsEventsBytimesGetResponseQueryDimensionsList | null;
    /** Used to filter rows by one or more dimensions. Filters can be combined using OR and AND boolean logic. AND takes precedence over OR in all the expressions. The OR operator is defined using a comma (,) or OR keyword surrounded by whitespace. The AND operator is defined using a semicolon (;) or AND keyword surrounded by whitespace. Note that the semicolon is a reserved character in URLs (rfc1738) and needs to be percent-encoded as %3B. Comparison options are: */
    filters?: string | null;
    /** Limit number of returned metrics. */
    limit?: number | null;
    /** One or more metrics to compute. Options are: */
    metrics?: AnalyticsEventsBytimesGetResponseQueryMetricsList | null;
    /** Start of time interval to query, defaults to `until` - 6 hours. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    since?: string | null;
    /** The sort order for the result set; sort fields must be included in `metrics` or `dimensions`. */
    sort?: AnalyticsEventsBytimesGetResponseQuerySortList | null;
    /** End of time interval to query, defaults to current time. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    until?: string | null;
}
export type AnalyticsEventsBytimesGetResponseTotalsMap = {
    [key: string]: number | undefined;
};
export type AnalyticsEventsBytimesGetResponseTimeIntervalsItemList = Array<string>;
export type AnalyticsEventsBytimesGetResponseTimeIntervalsList = Array<AnalyticsEventsBytimesGetResponseTimeIntervalsItemList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAnalyticEventBytimeResponse {
    /** List of columns returned by the analytics query. */
    data: AnalyticsEventsBytimesGetResponseDataList;
    /** Number of seconds between current time and last processed event, i.e. how many seconds of data could be missing. */
    dataLag: number;
    /** Maximum result for each selected metrics across all data. */
    max: AnalyticsEventsBytimesGetResponseMaxMap;
    /** Minimum result for each selected metrics across all data. */
    min: AnalyticsEventsBytimesGetResponseMinMap;
    query: AnalyticsEventsBytimesGetResponseQuery;
    /** Total number of rows in the result. */
    rows: number;
    /** Total result for each selected metrics across all data. */
    totals: AnalyticsEventsBytimesGetResponseTotalsMap;
    /** List of time interval buckets: [start, end]. */
    timeIntervals?: AnalyticsEventsBytimesGetResponseTimeIntervalsList | null;
}
export type AnalyticsEventsSummariesGetRequestDimensionsList = Array<string>;
export type AnalyticsEventsSummariesGetRequestMetrics = "count" | "bytesIngress" | "bytesEgress" | "durationAvg" | "durationMedian" | "duration90th" | "duration99th";
export type AnalyticsEventsSummariesGetRequestMetricsList = Array<AnalyticsEventsSummariesGetRequestMetrics | (string & {})>;
export type AnalyticsEventsSummariesGetRequestSortList = Array<string>;
export interface GetAnalyticEventSummaryRequest {
    /** Identifier. */
    zoneId: string;
    /** Can be used to break down the data by given attributes. Options are: */
    dimensions?: AnalyticsEventsSummariesGetRequestDimensionsList;
    /** Used to filter rows by one or more dimensions. Filters can be combined using OR and AND boolean logic. AND takes precedence over OR in all the expressions. The OR operator is defined using a comma (,) or OR keyword surrounded by whitespace. The AND operator is defined using a semicolon (;) or AND keyword surrounded by whitespace. Note that the semicolon is a reserved character in URLs (rfc1738) and needs to be percent-encoded as %3B. Comparison options are: */
    filters?: string;
    /** One or more metrics to compute. Options are: */
    metrics?: AnalyticsEventsSummariesGetRequestMetricsList;
    /** Start of time interval to query, defaults to `until` - 6 hours. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    since?: string;
    /** The sort order for the result set; sort fields must be included in `metrics` or `dimensions`. */
    sort?: AnalyticsEventsSummariesGetRequestSortList;
    /** End of time interval to query, defaults to current time. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    until?: string;
}
export type AnalyticsEventsSummariesGetResponseDataItemDimensionsList = Array<string>;
export type AnalyticsEventsSummariesGetResponseDataItemMetricsCase0List = Array<number>;
export type AnalyticsEventsSummariesGetResponseDataItemMetricsCase1ItemList = Array<number>;
export type AnalyticsEventsSummariesGetResponseDataItemMetricsCase1List = Array<AnalyticsEventsSummariesGetResponseDataItemMetricsCase1ItemList>;
export type AnalyticsEventsSummariesGetResponseDataItemMetrics = AnalyticsEventsSummariesGetResponseDataItemMetricsCase0List | AnalyticsEventsSummariesGetResponseDataItemMetricsCase1List;
export interface AnalyticsEventsSummariesGetResponseDataItem {
    dimensions?: AnalyticsEventsSummariesGetResponseDataItemDimensionsList | null;
    metrics?: AnalyticsEventsSummariesGetResponseDataItemMetrics | null;
}
export type AnalyticsEventsSummariesGetResponseDataList = Array<AnalyticsEventsSummariesGetResponseDataItem>;
export type AnalyticsEventsSummariesGetResponseMaxMap = {
    [key: string]: number | undefined;
};
export type AnalyticsEventsSummariesGetResponseMinMap = {
    [key: string]: number | undefined;
};
export type AnalyticsEventsSummariesGetResponseQueryDimensionsItem = "event" | "appID" | "coloName" | "ipVersion";
export type AnalyticsEventsSummariesGetResponseQueryDimensionsList = Array<AnalyticsEventsSummariesGetResponseQueryDimensionsItem>;
export type AnalyticsEventsSummariesGetResponseQueryMetricsItem = "count" | "bytesIngress" | "bytesEgress" | "durationAvg" | "durationMedian" | "duration90th" | "duration99th";
export type AnalyticsEventsSummariesGetResponseQueryMetricsList = Array<AnalyticsEventsSummariesGetResponseQueryMetricsItem>;
export type AnalyticsEventsSummariesGetResponseQuerySortList = Array<string>;
export interface AnalyticsEventsSummariesGetResponseQuery {
    /** Can be used to break down the data by given attributes. Options are: */
    dimensions?: AnalyticsEventsSummariesGetResponseQueryDimensionsList | null;
    /** Used to filter rows by one or more dimensions. Filters can be combined using OR and AND boolean logic. AND takes precedence over OR in all the expressions. The OR operator is defined using a comma (,) or OR keyword surrounded by whitespace. The AND operator is defined using a semicolon (;) or AND keyword surrounded by whitespace. Note that the semicolon is a reserved character in URLs (rfc1738) and needs to be percent-encoded as %3B. Comparison options are: */
    filters?: string | null;
    /** Limit number of returned metrics. */
    limit?: number | null;
    /** One or more metrics to compute. Options are: */
    metrics?: AnalyticsEventsSummariesGetResponseQueryMetricsList | null;
    /** Start of time interval to query, defaults to `until` - 6 hours. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    since?: string | null;
    /** The sort order for the result set; sort fields must be included in `metrics` or `dimensions`. */
    sort?: AnalyticsEventsSummariesGetResponseQuerySortList | null;
    /** End of time interval to query, defaults to current time. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    until?: string | null;
}
export type AnalyticsEventsSummariesGetResponseTotalsMap = {
    [key: string]: number | undefined;
};
export type AnalyticsEventsSummariesGetResponseTimeIntervalsItemList = Array<string>;
export type AnalyticsEventsSummariesGetResponseTimeIntervalsList = Array<AnalyticsEventsSummariesGetResponseTimeIntervalsItemList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAnalyticEventSummaryResponse {
    /** List of columns returned by the analytics query. */
    data: AnalyticsEventsSummariesGetResponseDataList;
    /** Number of seconds between current time and last processed event, i.e. how many seconds of data could be missing. */
    dataLag: number;
    /** Maximum result for each selected metrics across all data. */
    max: AnalyticsEventsSummariesGetResponseMaxMap;
    /** Minimum result for each selected metrics across all data. */
    min: AnalyticsEventsSummariesGetResponseMinMap;
    query: AnalyticsEventsSummariesGetResponseQuery;
    /** Total number of rows in the result. */
    rows: number;
    /** Total result for each selected metrics across all data. */
    totals: AnalyticsEventsSummariesGetResponseTotalsMap;
    /** List of time interval buckets: [start, end]. */
    timeIntervals?: AnalyticsEventsSummariesGetResponseTimeIntervalsList | null;
}
export interface GetAppRequest {
    /** Zone identifier. */
    zoneId: string;
    /** App identifier. */
    appId: string;
}
export type AppsGetResultSpectrumConfigAppConfigDnsType = "CNAME" | "ADDRESS";
export interface AppsGetResultSpectrumConfigAppConfigDns {
    /** The name of the DNS record associated with the application. */
    name?: string | null;
    /** The type of DNS record associated with the application. */
    type?: AppsGetResultSpectrumConfigAppConfigDnsType | null;
}
export type AppsGetResultSpectrumConfigAppConfigTrafficType = "direct" | "http" | "https" | "worker";
export type AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity = "all" | "ipv4" | "ipv6";
export type AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamicType = "dynamic";
export interface AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamic {
    /** The IP versions supported for inbound connections on Spectrum anycast IPs. */
    connectivity?: AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity | null;
    /** The type of edge IP configuration specified. Dynamically allocated edge IPs use Spectrum anycast IPs in accordance with the connectivity you specify. Only valid with CNAME DNS names. */
    type?: AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamicType | null;
}
export type AppsGetResultSpectrumConfigAppConfigEdgeIpsStaticIpsList = Array<string>;
export type AppsGetResultSpectrumConfigAppConfigEdgeIpsStaticType = "static";
export interface AppsGetResultSpectrumConfigAppConfigEdgeIpsStatic {
    /** The array of customer owned IPs we broadcast via anycast for this hostname and application. */
    ips?: AppsGetResultSpectrumConfigAppConfigEdgeIpsStaticIpsList | null;
    /** The type of edge IP configuration specified. Statically allocated edge IPs use customer IPs in accordance with the ips array you specify. Only valid with ADDRESS DNS names. */
    type?: AppsGetResultSpectrumConfigAppConfigEdgeIpsStaticType | null;
}
export type AppsGetResultSpectrumConfigAppConfigEdgeIps = AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamic | AppsGetResultSpectrumConfigAppConfigEdgeIpsStatic;
export type AppsGetResultSpectrumConfigAppConfigOriginDirectList = Array<string>;
export type AppsGetResultSpectrumConfigAppConfigOriginDnsType = "" | "A" | "AAAA" | "SRV";
export interface AppsGetResultSpectrumConfigAppConfigOriginDns {
    /** The name of the DNS record associated with the origin. */
    name?: string | null;
    /** The TTL of our resolution of your DNS record in seconds. */
    ttl?: number | null;
    /** The type of DNS record associated with the origin. "" is used to specify a combination of A/AAAA records. */
    type?: AppsGetResultSpectrumConfigAppConfigOriginDnsType | null;
}
export type AppsGetResultSpectrumConfigAppConfigOriginPort = string | number;
export type AppsGetResultSpectrumConfigAppConfigProxyProtocol = "off" | "v1" | "v2" | "simple";
export type AppsGetResultSpectrumConfigAppConfigTls = "off" | "flexible" | "full" | "strict";
export interface AppsGetResultSpectrumConfigAppConfig {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsGetResultSpectrumConfigAppConfigDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** Determines how data travels from the edge to your origin. When set to "direct", Spectrum will send traffic directly to your origin, and the application's type is derived from the `protocol`. When set to "http" or "https", Spectrum will apply Cloudflare's HTTP/HTTPS features as it sends traffic to your origin, and the application type matches this property exactly. When set to "worker", traffic is sent to the Worker specified by `origin_worker_id`. */
    trafficType: AppsGetResultSpectrumConfigAppConfigTrafficType;
    /** Enables Argo Smart Routing for this application. Notes: Only available for TCP or UDP applications with traffic_type set to "direct". */
    argoSmartRouting?: boolean | null;
    /** The anycast edge IP configuration for the hostname of this application. */
    edgeIps?: AppsGetResultSpectrumConfigAppConfigEdgeIps | null;
    /** Enables IP Access Rules for this application. Notes: Only available for TCP applications. */
    ipFirewall?: boolean | null;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsGetResultSpectrumConfigAppConfigOriginDirectList | null;
    /** The name and type of DNS record for the Spectrum application. */
    originDns?: AppsGetResultSpectrumConfigAppConfigOriginDns | null;
    /** The destination port at the origin. Only specified in conjunction with origin_dns. May use an integer to specify a single origin port, for example `1000`, or a string to specify a range of origin ports, for example `"1000-2000"`. Notes: If specifying a port range, the number of ports in the range must match the number of ports specified in the "protocol" field. */
    originPort?: AppsGetResultSpectrumConfigAppConfigOriginPort | null;
    /** Optional Worker script tag (worker ID) to use as the application's origin. Only supported for TCP applications with traffic_type "worker"; mutually exclusive with origin_direct, origin_dns, origin_port, proxy_protocol, and argo_smart_routing. tls may only be "off" or "flexible". */
    originWorkerId?: string | null;
    /** Enables Proxy Protocol to the origin. Refer to [Enable Proxy protocol](https://developers.cloudflare.com/spectrum/getting-started/proxy-protocol/) for implementation details on PROXY Protocol V1, PROXY Protocol V2, and Simple Proxy Protocol. */
    proxyProtocol?: AppsGetResultSpectrumConfigAppConfigProxyProtocol | null;
    /** The type of TLS termination associated with the application. */
    tls?: AppsGetResultSpectrumConfigAppConfigTls | null;
    /** Optional UUID of a virtual network for routing origin traffic through tunnel virtual networks. */
    virtualNetworkId?: string | null;
}
export type AppsGetResultSpectrumConfigPaygoAppConfigDnsType = "CNAME" | "ADDRESS";
export interface AppsGetResultSpectrumConfigPaygoAppConfigDns {
    /** The name of the DNS record associated with the application. */
    name?: string | null;
    /** The type of DNS record associated with the application. */
    type?: AppsGetResultSpectrumConfigPaygoAppConfigDnsType | null;
}
export type AppsGetResultSpectrumConfigPaygoAppConfigOriginDirectList = Array<string>;
export interface AppsGetResultSpectrumConfigPaygoAppConfig {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsGetResultSpectrumConfigPaygoAppConfigDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsGetResultSpectrumConfigPaygoAppConfigOriginDirectList | null;
}
export type AppsGetResult = AppsGetResultSpectrumConfigAppConfig | AppsGetResultSpectrumConfigPaygoAppConfig;
export type GetAppResponse = AppsGetResult;
export type AppsListRequestDirection = "asc" | "desc";
export type AppsListRequestOrder = "protocol" | "app_id" | "created_on" | "modified_on" | "dns";
export interface ListAppsRequest {
    /** Zone identifier. */
    zoneId: string;
    /** Sets the direction by which results are ordered. */
    direction?: AppsListRequestDirection | (string & {});
    /** Application field by which results are ordered. */
    order?: AppsListRequestOrder | (string & {});
    /** Page number of paginated results. This parameter is required in order to use other pagination parameters. If included in the query, `result_info` will be present in the response. */
    page?: number;
    /** Sets the maximum number of results per page. */
    perPage?: number;
}
export type AppsListResultCase0ItemDnsType = "CNAME" | "ADDRESS";
export interface AppsListResultCase0ItemDns {
    /** The name of the DNS record associated with the application. */
    name?: string | null;
    /** The type of DNS record associated with the application. */
    type?: AppsListResultCase0ItemDnsType | null;
}
export type AppsListResultCase0ItemTrafficType = "direct" | "http" | "https" | "worker";
export type AppsListResultCase0ItemEdgeIpsDynamicConnectivity = "all" | "ipv4" | "ipv6";
export type AppsListResultCase0ItemEdgeIpsDynamicType = "dynamic";
export interface AppsListResultCase0ItemEdgeIpsDynamic {
    /** The IP versions supported for inbound connections on Spectrum anycast IPs. */
    connectivity?: AppsListResultCase0ItemEdgeIpsDynamicConnectivity | null;
    /** The type of edge IP configuration specified. Dynamically allocated edge IPs use Spectrum anycast IPs in accordance with the connectivity you specify. Only valid with CNAME DNS names. */
    type?: AppsListResultCase0ItemEdgeIpsDynamicType | null;
}
export type AppsListResultCase0ItemEdgeIpsStaticIpsList = Array<string>;
export type AppsListResultCase0ItemEdgeIpsStaticType = "static";
export interface AppsListResultCase0ItemEdgeIpsStatic {
    /** The array of customer owned IPs we broadcast via anycast for this hostname and application. */
    ips?: AppsListResultCase0ItemEdgeIpsStaticIpsList | null;
    /** The type of edge IP configuration specified. Statically allocated edge IPs use customer IPs in accordance with the ips array you specify. Only valid with ADDRESS DNS names. */
    type?: AppsListResultCase0ItemEdgeIpsStaticType | null;
}
export type AppsListResultCase0ItemEdgeIps = AppsListResultCase0ItemEdgeIpsDynamic | AppsListResultCase0ItemEdgeIpsStatic;
export type AppsListResultCase0ItemOriginDirectList = Array<string>;
export type AppsListResultCase0ItemOriginDnsType = "" | "A" | "AAAA" | "SRV";
export interface AppsListResultCase0ItemOriginDns {
    /** The name of the DNS record associated with the origin. */
    name?: string | null;
    /** The TTL of our resolution of your DNS record in seconds. */
    ttl?: number | null;
    /** The type of DNS record associated with the origin. "" is used to specify a combination of A/AAAA records. */
    type?: AppsListResultCase0ItemOriginDnsType | null;
}
export type AppsListResultCase0ItemOriginPort = string | number;
export type AppsListResultCase0ItemProxyProtocol = "off" | "v1" | "v2" | "simple";
export type AppsListResultCase0ItemTls = "off" | "flexible" | "full" | "strict";
export interface AppsListResultCase0Item {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsListResultCase0ItemDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** Determines how data travels from the edge to your origin. When set to "direct", Spectrum will send traffic directly to your origin, and the application's type is derived from the `protocol`. When set to "http" or "https", Spectrum will apply Cloudflare's HTTP/HTTPS features as it sends traffic to your origin, and the application type matches this property exactly. When set to "worker", traffic is sent to the Worker specified by `origin_worker_id`. */
    trafficType: AppsListResultCase0ItemTrafficType;
    /** Enables Argo Smart Routing for this application. Notes: Only available for TCP or UDP applications with traffic_type set to "direct". */
    argoSmartRouting?: boolean | null;
    /** The anycast edge IP configuration for the hostname of this application. */
    edgeIps?: AppsListResultCase0ItemEdgeIps | null;
    /** Enables IP Access Rules for this application. Notes: Only available for TCP applications. */
    ipFirewall?: boolean | null;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsListResultCase0ItemOriginDirectList | null;
    /** The name and type of DNS record for the Spectrum application. */
    originDns?: AppsListResultCase0ItemOriginDns | null;
    /** The destination port at the origin. Only specified in conjunction with origin_dns. May use an integer to specify a single origin port, for example `1000`, or a string to specify a range of origin ports, for example `"1000-2000"`. Notes: If specifying a port range, the number of ports in the range must match the number of ports specified in the "protocol" field. */
    originPort?: AppsListResultCase0ItemOriginPort | null;
    /** Optional Worker script tag (worker ID) to use as the application's origin. Only supported for TCP applications with traffic_type "worker"; mutually exclusive with origin_direct, origin_dns, origin_port, proxy_protocol, and argo_smart_routing. tls may only be "off" or "flexible". */
    originWorkerId?: string | null;
    /** Enables Proxy Protocol to the origin. Refer to [Enable Proxy protocol](https://developers.cloudflare.com/spectrum/getting-started/proxy-protocol/) for implementation details on PROXY Protocol V1, PROXY Protocol V2, and Simple Proxy Protocol. */
    proxyProtocol?: AppsListResultCase0ItemProxyProtocol | null;
    /** The type of TLS termination associated with the application. */
    tls?: AppsListResultCase0ItemTls | null;
    /** Optional UUID of a virtual network for routing origin traffic through tunnel virtual networks. */
    virtualNetworkId?: string | null;
}
export type AppsListResultCase0List = Array<AppsListResultCase0Item>;
export type AppsListResultCase1ItemDnsType = "CNAME" | "ADDRESS";
export interface AppsListResultCase1ItemDns {
    /** The name of the DNS record associated with the application. */
    name?: string | null;
    /** The type of DNS record associated with the application. */
    type?: AppsListResultCase1ItemDnsType | null;
}
export type AppsListResultCase1ItemOriginDirectList = Array<string>;
export interface AppsListResultCase1Item {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsListResultCase1ItemDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsListResultCase1ItemOriginDirectList | null;
}
export type AppsListResultCase1List = Array<AppsListResultCase1Item>;
export type AppsListResult = AppsListResultCase0List | AppsListResultCase1List;
export interface ListAppsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AppsListResult;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListProtocolsRequest {
    /** Zone identifier. */
    zoneId: string;
}
export type ListProtocolsResultItemPortsList = Array<number>;
export interface ListProtocolsResultItem {
    /** The full name of the application protocol. */
    description: string;
    /** The short name of the application protocol. */
    name: string;
    /** The available listening ports for the given protocol. */
    ports: ListProtocolsResultItemPortsList;
    /** The transport layer protocol used by the application protocol */
    transport: string;
}
export type ListProtocolsResultList = Array<ListProtocolsResultItem>;
export type ListProtocolsResponse = ListProtocolsResultList;
export type AppsUpdateRequestDnsType = "CNAME" | "ADDRESS";
export interface AppsUpdateRequestDns {
    /** The name of the DNS record associated with the application. */
    name?: string;
    /** The type of DNS record associated with the application. */
    type?: AppsUpdateRequestDnsType | (string & {});
}
export type AppsUpdateRequestTrafficType = "direct" | "http" | "https" | "worker";
export type AppsUpdateRequestEdgeIpsDynamicConnectivity = "all" | "ipv4" | "ipv6";
export type AppsUpdateRequestEdgeIpsDynamicType = "dynamic";
export interface AppsUpdateRequestEdgeIpsDynamic {
    /** The IP versions supported for inbound connections on Spectrum anycast IPs. */
    connectivity?: AppsUpdateRequestEdgeIpsDynamicConnectivity | (string & {});
    /** The type of edge IP configuration specified. Dynamically allocated edge IPs use Spectrum anycast IPs in accordance with the connectivity you specify. Only valid with CNAME DNS names. */
    type?: AppsUpdateRequestEdgeIpsDynamicType | (string & {});
}
export type AppsUpdateRequestEdgeIpsStaticIpsList = Array<string>;
export type AppsUpdateRequestEdgeIpsStaticType = "static";
export interface AppsUpdateRequestEdgeIpsStatic {
    /** The array of customer owned IPs we broadcast via anycast for this hostname and application. */
    ips?: AppsUpdateRequestEdgeIpsStaticIpsList;
    /** The type of edge IP configuration specified. Statically allocated edge IPs use customer IPs in accordance with the ips array you specify. Only valid with ADDRESS DNS names. */
    type?: AppsUpdateRequestEdgeIpsStaticType | (string & {});
}
export type AppsUpdateRequestEdgeIps = AppsUpdateRequestEdgeIpsDynamic | AppsUpdateRequestEdgeIpsStatic;
export type AppsUpdateRequestOriginDirectList = Array<string>;
export type AppsUpdateRequestOriginDnsType = "" | "A" | "AAAA" | "SRV";
export interface AppsUpdateRequestOriginDns {
    /** The name of the DNS record associated with the origin. */
    name?: string;
    /** The TTL of our resolution of your DNS record in seconds. */
    ttl?: number;
    /** The type of DNS record associated with the origin. "" is used to specify a combination of A/AAAA records. */
    type?: AppsUpdateRequestOriginDnsType | (string & {});
}
export type AppsUpdateRequestOriginPort = string | number;
export type AppsUpdateRequestProxyProtocol = "off" | "v1" | "v2" | "simple";
export type AppsUpdateRequestTls = "off" | "flexible" | "full" | "strict";
export interface UpdateAppRequest {
    /** Zone identifier. */
    zoneId: string;
    /** App identifier. */
    appId: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsUpdateRequestDns;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** Determines how data travels from the edge to your origin. When set to "direct", Spectrum will send traffic directly to your origin, and the application's type is derived from the `protocol`. When set to "http" or "https", Spectrum will apply Cloudflare's HTTP/HTTPS features as it sends traffic to your origin, and the application type matches this property exactly. When set to "worker", traffic is sent to the Worker specified by `origin_worker_id`. */
    trafficType?: AppsUpdateRequestTrafficType | (string & {});
    /** Enables Argo Smart Routing for this application. Notes: Only available for TCP or UDP applications with traffic_type set to "direct". */
    argoSmartRouting?: boolean;
    /** The anycast edge IP configuration for the hostname of this application. */
    edgeIps?: AppsUpdateRequestEdgeIps;
    /** Enables IP Access Rules for this application. Notes: Only available for TCP applications. */
    ipFirewall?: boolean;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsUpdateRequestOriginDirectList;
    /** The name and type of DNS record for the Spectrum application. */
    originDns?: AppsUpdateRequestOriginDns;
    /** The destination port at the origin. Only specified in conjunction with origin_dns. May use an integer to specify a single origin port, for example `1000`, or a string to specify a range of origin ports, for example `"1000-2000"`. Notes: If specifying a port range, the number of ports in the range must match the number of ports specified in the "protocol" field. */
    originPort?: AppsUpdateRequestOriginPort;
    /** Optional Worker script tag (worker ID) to use as the application's origin. Only supported for TCP applications with traffic_type "worker"; mutually exclusive with origin_direct, origin_dns, origin_port, proxy_protocol, and argo_smart_routing. tls may only be "off" or "flexible". */
    originWorkerId?: string;
    /** Enables Proxy Protocol to the origin. Refer to [Enable Proxy protocol](https://developers.cloudflare.com/spectrum/getting-started/proxy-protocol/) for implementation details on PROXY Protocol V1, PROXY Protocol V2, and Simple Proxy Protocol. */
    proxyProtocol?: AppsUpdateRequestProxyProtocol | (string & {});
    /** The type of TLS termination associated with the application. */
    tls?: AppsUpdateRequestTls | (string & {});
    /** Optional UUID of a virtual network for routing origin traffic through tunnel virtual networks. */
    virtualNetworkId?: string;
}
export type AppsUpdateResultSpectrumConfigAppConfigDnsType = "CNAME" | "ADDRESS";
export interface AppsUpdateResultSpectrumConfigAppConfigDns {
    /** The name of the DNS record associated with the application. */
    name?: string | null;
    /** The type of DNS record associated with the application. */
    type?: AppsUpdateResultSpectrumConfigAppConfigDnsType | null;
}
export type AppsUpdateResultSpectrumConfigAppConfigTrafficType = "direct" | "http" | "https" | "worker";
export type AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity = "all" | "ipv4" | "ipv6";
export type AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamicType = "dynamic";
export interface AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamic {
    /** The IP versions supported for inbound connections on Spectrum anycast IPs. */
    connectivity?: AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity | null;
    /** The type of edge IP configuration specified. Dynamically allocated edge IPs use Spectrum anycast IPs in accordance with the connectivity you specify. Only valid with CNAME DNS names. */
    type?: AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamicType | null;
}
export type AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStaticIpsList = Array<string>;
export type AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStaticType = "static";
export interface AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStatic {
    /** The array of customer owned IPs we broadcast via anycast for this hostname and application. */
    ips?: AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStaticIpsList | null;
    /** The type of edge IP configuration specified. Statically allocated edge IPs use customer IPs in accordance with the ips array you specify. Only valid with ADDRESS DNS names. */
    type?: AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStaticType | null;
}
export type AppsUpdateResultSpectrumConfigAppConfigEdgeIps = AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamic | AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStatic;
export type AppsUpdateResultSpectrumConfigAppConfigOriginDirectList = Array<string>;
export type AppsUpdateResultSpectrumConfigAppConfigOriginDnsType = "" | "A" | "AAAA" | "SRV";
export interface AppsUpdateResultSpectrumConfigAppConfigOriginDns {
    /** The name of the DNS record associated with the origin. */
    name?: string | null;
    /** The TTL of our resolution of your DNS record in seconds. */
    ttl?: number | null;
    /** The type of DNS record associated with the origin. "" is used to specify a combination of A/AAAA records. */
    type?: AppsUpdateResultSpectrumConfigAppConfigOriginDnsType | null;
}
export type AppsUpdateResultSpectrumConfigAppConfigOriginPort = string | number;
export type AppsUpdateResultSpectrumConfigAppConfigProxyProtocol = "off" | "v1" | "v2" | "simple";
export type AppsUpdateResultSpectrumConfigAppConfigTls = "off" | "flexible" | "full" | "strict";
export interface AppsUpdateResultSpectrumConfigAppConfig {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsUpdateResultSpectrumConfigAppConfigDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** Determines how data travels from the edge to your origin. When set to "direct", Spectrum will send traffic directly to your origin, and the application's type is derived from the `protocol`. When set to "http" or "https", Spectrum will apply Cloudflare's HTTP/HTTPS features as it sends traffic to your origin, and the application type matches this property exactly. When set to "worker", traffic is sent to the Worker specified by `origin_worker_id`. */
    trafficType: AppsUpdateResultSpectrumConfigAppConfigTrafficType;
    /** Enables Argo Smart Routing for this application. Notes: Only available for TCP or UDP applications with traffic_type set to "direct". */
    argoSmartRouting?: boolean | null;
    /** The anycast edge IP configuration for the hostname of this application. */
    edgeIps?: AppsUpdateResultSpectrumConfigAppConfigEdgeIps | null;
    /** Enables IP Access Rules for this application. Notes: Only available for TCP applications. */
    ipFirewall?: boolean | null;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsUpdateResultSpectrumConfigAppConfigOriginDirectList | null;
    /** The name and type of DNS record for the Spectrum application. */
    originDns?: AppsUpdateResultSpectrumConfigAppConfigOriginDns | null;
    /** The destination port at the origin. Only specified in conjunction with origin_dns. May use an integer to specify a single origin port, for example `1000`, or a string to specify a range of origin ports, for example `"1000-2000"`. Notes: If specifying a port range, the number of ports in the range must match the number of ports specified in the "protocol" field. */
    originPort?: AppsUpdateResultSpectrumConfigAppConfigOriginPort | null;
    /** Optional Worker script tag (worker ID) to use as the application's origin. Only supported for TCP applications with traffic_type "worker"; mutually exclusive with origin_direct, origin_dns, origin_port, proxy_protocol, and argo_smart_routing. tls may only be "off" or "flexible". */
    originWorkerId?: string | null;
    /** Enables Proxy Protocol to the origin. Refer to [Enable Proxy protocol](https://developers.cloudflare.com/spectrum/getting-started/proxy-protocol/) for implementation details on PROXY Protocol V1, PROXY Protocol V2, and Simple Proxy Protocol. */
    proxyProtocol?: AppsUpdateResultSpectrumConfigAppConfigProxyProtocol | null;
    /** The type of TLS termination associated with the application. */
    tls?: AppsUpdateResultSpectrumConfigAppConfigTls | null;
    /** Optional UUID of a virtual network for routing origin traffic through tunnel virtual networks. */
    virtualNetworkId?: string | null;
}
export type AppsUpdateResultSpectrumConfigPaygoAppConfigDnsType = "CNAME" | "ADDRESS";
export interface AppsUpdateResultSpectrumConfigPaygoAppConfigDns {
    /** The name of the DNS record associated with the application. */
    name?: string | null;
    /** The type of DNS record associated with the application. */
    type?: AppsUpdateResultSpectrumConfigPaygoAppConfigDnsType | null;
}
export type AppsUpdateResultSpectrumConfigPaygoAppConfigOriginDirectList = Array<string>;
export interface AppsUpdateResultSpectrumConfigPaygoAppConfig {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsUpdateResultSpectrumConfigPaygoAppConfigDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsUpdateResultSpectrumConfigPaygoAppConfigOriginDirectList | null;
}
export type AppsUpdateResult = AppsUpdateResultSpectrumConfigAppConfig | AppsUpdateResultSpectrumConfigPaygoAppConfig;
export type UpdateAppResponse = AppsUpdateResult;
export type CreateAppError = SpectrumProtocolNotAvailable | Forbidden | CloudflareOpError;
/** Creates a new Spectrum application from a configuration using a name for the origin. */
export declare const createApp: API.OperationMethod<CreateAppRequest, CreateAppResponse, CreateAppError, CloudflareOpContext>;
export type DeleteAppError = SpectrumAppNotFound | Forbidden | CloudflareOpError;
/** Deletes a previously existing application. */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest, DeleteAppResponse, DeleteAppError, CloudflareOpContext>;
export type GetAnalyticAggregateCurrentError = CloudflareOpError;
/** Retrieves analytics aggregated from the last minute of usage on Spectrum applications underneath a given zone. */
export declare const getAnalyticAggregateCurrent: API.OperationMethod<GetAnalyticAggregateCurrentRequest, GetAnalyticAggregateCurrentResponse, GetAnalyticAggregateCurrentError, CloudflareOpContext>;
export type GetAnalyticEventBytimeError = CloudflareOpError;
/** Retrieves a list of aggregate metrics grouped by time interval. */
export declare const getAnalyticEventBytime: API.OperationMethod<GetAnalyticEventBytimeRequest, GetAnalyticEventBytimeResponse, GetAnalyticEventBytimeError, CloudflareOpContext>;
export type GetAnalyticEventSummaryError = CloudflareOpError;
/** Retrieves a list of summarised aggregate metrics over a given time period. */
export declare const getAnalyticEventSummary: API.OperationMethod<GetAnalyticEventSummaryRequest, GetAnalyticEventSummaryResponse, GetAnalyticEventSummaryError, CloudflareOpContext>;
export type GetAppError = SpectrumAppNotFound | Forbidden | CloudflareOpError;
/** Gets the application configuration of a specific application inside a zone. */
export declare const getApp: API.OperationMethod<GetAppRequest, GetAppResponse, GetAppError, CloudflareOpContext>;
export type ListAppsError = Forbidden | CloudflareOpError;
/** Retrieves a list of currently existing Spectrum applications inside a zone. */
export declare const listApps: API.PaginatedOperationMethod<ListAppsRequest, ListAppsResponse, ListAppsError, CloudflareOpContext>;
export type ListProtocolsError = CloudflareOpError;
/** Retrieves a list of Spectrum application protocols available for a zone. */
export declare const listProtocols: API.OperationMethod<ListProtocolsRequest, ListProtocolsResponse, ListProtocolsError, CloudflareOpContext>;
export type UpdateAppError = SpectrumAppNotFound | SpectrumProtocolNotAvailable | Forbidden | CloudflareOpError;
/** Updates a previously existing application's configuration that uses a name for the origin. */
export declare const updateApp: API.OperationMethod<UpdateAppRequest, UpdateAppResponse, UpdateAppError, CloudflareOpContext>;
//# sourceMappingURL=spectrum.d.ts.map