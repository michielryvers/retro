import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AccountCreationForbidden_base: S.TaggedErrorClass<"AccountCreationForbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class AccountCreationForbidden extends /*@__PURE__*/ AccountCreationForbidden_base {
}
declare const AccountMemberAlreadyExists_base: S.TaggedErrorClass<"AccountMemberAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class AccountMemberAlreadyExists extends /*@__PURE__*/ AccountMemberAlreadyExists_base {
}
declare const AccountNameTooLong_base: S.TaggedErrorClass<"AccountNameTooLong", {
    readonly code: any;
    readonly message: any;
}>;
export declare class AccountNameTooLong extends /*@__PURE__*/ AccountNameTooLong_base {
}
declare const BadRequest_base: S.TaggedErrorClass<"BadRequest", {
    readonly code: any;
    readonly message: any;
}>;
export declare class BadRequest extends /*@__PURE__*/ BadRequest_base {
}
declare const EndpointNotFound_base: S.TaggedErrorClass<"EndpointNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class EndpointNotFound extends /*@__PURE__*/ EndpointNotFound_base {
}
declare const InvalidAccountName_base: S.TaggedErrorClass<"InvalidAccountName", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidAccountName extends /*@__PURE__*/ InvalidAccountName_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidTokenName_base: S.TaggedErrorClass<"InvalidTokenName", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidTokenName extends /*@__PURE__*/ InvalidTokenName_base {
}
declare const JsonDecodeFailure_base: S.TaggedErrorClass<"JsonDecodeFailure", {
    readonly code: any;
    readonly message: any;
}>;
export declare class JsonDecodeFailure extends /*@__PURE__*/ JsonDecodeFailure_base {
}
declare const MemberNotFound_base: S.TaggedErrorClass<"MemberNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MemberNotFound extends /*@__PURE__*/ MemberNotFound_base {
}
declare const MethodNotAllowed_base: S.TaggedErrorClass<"MethodNotAllowed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MethodNotAllowed extends /*@__PURE__*/ MethodNotAllowed_base {
}
declare const MissingAuthenticationToken_base: S.TaggedErrorClass<"MissingAuthenticationToken", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MissingAuthenticationToken extends /*@__PURE__*/ MissingAuthenticationToken_base {
}
declare const MissingName_base: S.TaggedErrorClass<"MissingName", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MissingName extends /*@__PURE__*/ MissingName_base {
}
declare const PermissionGroupNotFound_base: S.TaggedErrorClass<"PermissionGroupNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PermissionGroupNotFound extends /*@__PURE__*/ PermissionGroupNotFound_base {
}
declare const TokenManagedByCloudflare_base: S.TaggedErrorClass<"TokenManagedByCloudflare", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TokenManagedByCloudflare extends /*@__PURE__*/ TokenManagedByCloudflare_base {
}
declare const TokenNotFound_base: S.TaggedErrorClass<"TokenNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TokenNotFound extends /*@__PURE__*/ TokenNotFound_base {
}
declare const UpdateAccountTypeNotSupported_base: S.TaggedErrorClass<"UpdateAccountTypeNotSupported", {
    readonly code: any;
    readonly message: any;
}>;
export declare class UpdateAccountTypeNotSupported extends /*@__PURE__*/ UpdateAccountTypeNotSupported_base {
}
declare const ValidationError_base: S.TaggedErrorClass<"ValidationError", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ValidationError extends /*@__PURE__*/ ValidationError_base {
}
export type CreateRequestType = "standard" | "enterprise";
export interface CreateRequestUnit {
    /** Tenant unit ID */
    id?: string;
}
export interface CreateAccountRequest {
    idempotencyKey?: string;
    /** Account name */
    name: string;
    /** Set to `true` and omit `unit` to create a standalone Free Account. If provided, this field must be `true`. */
    standalone?: boolean;
    type?: CreateRequestType | (string & {});
    /** Information related to the tenant unit. Provide its ID and omit `standalone` to create the Account within an Organization. See https://developers.cloudflare.com/tenant/how-to/manage-accounts/. */
    unit?: CreateRequestUnit;
}
export type CreateResponseType = "standard" | "enterprise";
export interface CreateResponseManagedBy {
    /** ID of the parent Organization, if one exists */
    parentOrgId?: string | null;
    /** Name of the parent Organization, if one exists */
    parentOrgName?: string | null;
}
export interface CreateResponseSettings {
    /** Sets an abuse contact email to notify for abuse reports. */
    abuseContactEmail?: string | null;
    /** Indicates whether membership in this account requires that Two-Factor Authentication is enabled */
    enforceTwofactor?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAccountResponse {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: CreateResponseType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: CreateResponseManagedBy | null;
    /** Account settings */
    settings?: CreateResponseSettings | null;
}
export interface CreateAccountOrganizationRequest {
    accountId: string;
    /** The ID of the organization to move the account into. */
    destinationOrganizationId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAccountOrganizationResponse {
    accountId: string;
    destinationOrganizationId: string;
    sourceOrganizationId: string;
}
export interface CreateClientSecretRequest {
    /** Identifier */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateClientSecretResponse {
    /** The Stripe client secret for frontend payment confirmation. */
    clientSecret?: string | null;
}
export type MembersCreateRequestRolesList = Array<string>;
export type MembersCreateRequestStatus = "accepted" | "pending";
export type MembersCreateRequestPoliciesItemAccess = "allow" | "deny";
export interface MembersCreateRequestPoliciesItemPermissionGroupsItem {
    /** Identifier of the group. */
    id: string;
}
export type MembersCreateRequestPoliciesItemPermissionGroupsList = Array<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export type MembersCreateRequestPoliciesItemResourceGroupsItem = MembersCreateRequestPoliciesItemPermissionGroupsItem;
export type MembersCreateRequestPoliciesItemResourceGroupsList = Array<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export interface MembersCreateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    access: MembersCreateRequestPoliciesItemAccess | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: MembersCreateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource groups that the policy applies to. */
    resourceGroups: MembersCreateRequestPoliciesItemResourceGroupsList;
}
export type MembersCreateRequestPoliciesList = Array<MembersCreateRequestPoliciesItem>;
export interface CreateMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The contact email address of the user. */
    email: string;
    /** Array of roles associated with this member. */
    roles?: MembersCreateRequestRolesList;
    /** Status of the member invitation. If not provided during creation, defaults to 'pending'. Changing from 'accepted' back to 'pending' will trigger a replacement of the member resource in Terraform. */
    status?: MembersCreateRequestStatus | (string & {});
    /** Array of policies associated with this member. */
    policies?: MembersCreateRequestPoliciesList;
}
export type MembersCreateResponsePoliciesItemAccess = "allow" | "deny";
export interface MembersCreateResponsePoliciesItemPermissionGroupsItemMeta {
    /** A category used to group permission groups. */
    category?: string | null;
    /** Indicates whether the permission group is deprecated. */
    deprecated?: string | null;
    /** Additional information about the permission group. */
    description?: string | null;
    /** Indicates whether the permission group can be edited. */
    editable?: string | null;
    /** The planned end-of-life date and time, when provided. */
    eolAt?: string | null;
    /** A label identifying the permission group. */
    label?: string | null;
    /** The scope associated with the permission group. */
    scopes?: string | null;
    /** Indicates the permission group's availability or visibility. */
    visibility?: string | null;
}
export interface MembersCreateResponsePoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: MembersCreateResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the permission group. */
    name?: string | null;
}
export type MembersCreateResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export interface MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem {
    /** This is a combination of pre-defined resource name and identifier (like Zone ID etc.) */
    key: string;
}
export type MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem>;
export interface MembersCreateResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export interface MembersCreateResponsePoliciesItemResourceGroupsItemMeta {
    key?: string | null;
    value?: string | null;
}
export interface MembersCreateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: MembersCreateResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: MembersCreateResponsePoliciesItemResourceGroupsItemMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export type MembersCreateResponsePoliciesItemResourceGroupsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItem>;
export interface MembersCreateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: MembersCreateResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: MembersCreateResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: MembersCreateResponsePoliciesItemResourceGroupsList | null;
}
export type MembersCreateResponsePoliciesList = Array<MembersCreateResponsePoliciesItem>;
export interface MembersCreateResponseRolesItemPermissionsAnalytics {
    read?: boolean | null;
    write?: boolean | null;
}
export type MembersCreateResponseRolesItemPermissionsBilling = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsCachePurge = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsDns = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsDnsRecords = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsLb = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsLogs = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsOrganization = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsSsl = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsWaf = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsZoneSettings = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsZones = MembersCreateResponseRolesItemPermissionsAnalytics;
export interface MembersCreateResponseRolesItemPermissions {
    analytics?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    billing?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    cachePurge?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    dns?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    dnsRecords?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    lb?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    logs?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    organization?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    ssl?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    waf?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    zoneSettings?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    zones?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
}
export interface MembersCreateResponseRolesItem {
    /** Role identifier tag. */
    id: string;
    /** Description of role's permissions. */
    description: string;
    /** Role name. */
    name: string;
    permissions: MembersCreateResponseRolesItemPermissions;
}
export type MembersCreateResponseRolesList = Array<MembersCreateResponseRolesItem>;
export type MembersCreateResponseStatus = "accepted" | "pending";
export interface MembersCreateResponseUser {
    /** The contact email address of the user. */
    email: string;
    /** Identifier */
    id?: string | null;
    /** User's first name */
    firstName?: string | null;
    /** User's last name */
    lastName?: string | null;
    /** Indicates whether two-factor authentication is enabled for the user account. Does not apply to API authentication. */
    twoFactorAuthenticationEnabled?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMemberResponse {
    /** Membership identifier tag. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Access policy for the membership */
    policies?: MembersCreateResponsePoliciesList | null;
    /** Roles assigned to this Member. */
    roles?: MembersCreateResponseRolesList | null;
    /** A member's status in the account. */
    status?: MembersCreateResponseStatus | null;
    /** Details of the user associated to the membership. */
    user?: MembersCreateResponseUser | null;
}
export interface CreatePayBadDebtRequest {
    /** Identifier */
    accountId: string;
    /** The payment method to use. If omitted, the default payment method is used. */
    paymentMethodId?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePayBadDebtResponse {
    /** The Stripe client secret for frontend payment confirmation. */
    clientSecret?: string | null;
}
export interface CreatePayInvoiceRequest {
    /** Identifier */
    accountId: string;
    /** The identifier of the invoice to pay. */
    invoiceId?: string;
    /** The payment method to use. If omitted, the default payment method is used. */
    paymentMethodId?: string;
    /** Whether to validate the payment method before processing. */
    validatePaymentMethod?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePayInvoiceResponse {
    /** The Stripe client secret for frontend payment confirmation. */
    clientSecret?: string | null;
}
export type CreatePaymentMethodRequestType = "CREDIT_CARD" | "PAYPAL" | "CASHAPP" | "SEPA_DEBIT" | "LINK" | "ACH_DIRECT_DEBIT";
export interface CreatePaymentMethodRequest {
    /** Identifier */
    accountId: string;
    /** Billing address line 1. */
    address?: string;
    /** Billing address line 2. */
    address2?: string;
    /** Bank account type. */
    bankAccountType?: string;
    /** Bank code. */
    bankCode?: string;
    /** Bank country. */
    bankCountry?: string;
    /** Bank name for bank-based payment methods. */
    bankName?: string;
    /** Bank routing number. */
    bankRoutingNumber?: string;
    /** Cash App cash tag. */
    cashappCashTag?: string;
    /** Billing city. */
    city?: string;
    /** Billing country. */
    country?: string;
    /** Whether this is the default payment method. */
    default?: boolean;
    /** Device data for fraud prevention. */
    deviceData?: string;
    /** Billing first name. */
    firstName?: string;
    /** Billing last name. */
    lastName?: string;
    /** A nickname for the payment method. */
    nickName?: string;
    /** Email associated with the payment account. */
    paymentAccountEmail?: string;
    /** Payment email address. */
    paymentEmail?: string;
    /** The payment gateway used. */
    paymentGateway?: string;
    /** Payment nonce for tokenized payments. */
    paymentNonce?: string;
    /** Billing state. */
    state?: string;
    /** The payment method type. */
    type?: CreatePaymentMethodRequestType | (string & {});
    /** Billing zip code. */
    zipcode?: string;
}
export type CreatePaymentMethodResponseType = "CREDIT_CARD" | "PAYPAL" | "CASHAPP" | "SEPA_DEBIT" | "LINK" | "ACH_DIRECT_DEBIT";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePaymentMethodResponse {
    /** Payment method identifier. */
    id?: string | null;
    /** Billing address line 1. */
    address?: string | null;
    /** Billing address line 2. */
    address2?: string | null;
    /** Bank account type. */
    bankAccountType?: string | null;
    /** Bank code. */
    bankCode?: string | null;
    /** Bank country. */
    bankCountry?: string | null;
    /** Bank name for bank-based payment methods. */
    bankName?: string | null;
    /** Bank routing number. */
    bankRoutingNumber?: string | null;
    /** Cash App cash tag. */
    cashappCashTag?: string | null;
    /** Billing city. */
    city?: string | null;
    /** Billing country. */
    country?: string | null;
    /** Whether this is the default payment method. */
    default?: boolean | null;
    /** Device data for fraud prevention. */
    deviceData?: string | null;
    /** Card expiration date. */
    expirationDate?: string | null;
    /** Billing first name. */
    firstName?: string | null;
    /** Last four digits of the card number. */
    lastFour?: string | null;
    /** Billing last name. */
    lastName?: string | null;
    /** A nickname for the payment method. */
    nickName?: string | null;
    /** Email associated with the payment account. */
    paymentAccountEmail?: string | null;
    /** Payment email address. */
    paymentEmail?: string | null;
    /** The payment gateway used. */
    paymentGateway?: string | null;
    /** Payment nonce for tokenized payments. */
    paymentNonce?: string | null;
    /** Billing state. */
    state?: string | null;
    /** The payment method type. */
    type?: CreatePaymentMethodResponseType | null;
    /** Billing zip code. */
    zipcode?: string | null;
}
export type SubscriptionsCreateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsCreateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsCreateRequestRatePlanSetsList = Array<string>;
export interface SubscriptionsCreateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsCreateRequestRatePlanId | (string & {});
    /** The currency applied to the rate plan subscription. */
    currency?: string;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean;
    /** The full name of the rate plan. */
    publicName?: string;
    /** The scope that this rate plan applies to. */
    scope?: string;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsCreateRequestRatePlanSetsList;
}
export interface CreateSubscriptionRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsCreateRequestFrequency | (string & {});
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsCreateRequestRatePlan;
}
export type SubscriptionsCreateResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsCreateResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsCreateResponseRatePlanSetsList = Array<string>;
export interface SubscriptionsCreateResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsCreateResponseRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsCreateResponseRatePlanSetsList | null;
}
export type SubscriptionsCreateResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSubscriptionResponse {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsCreateResponseFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsCreateResponseRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsCreateResponseState | null;
}
export type TokensCreateRequestPoliciesItemEffect = "allow" | "deny";
export interface TokensCreateRequestPoliciesItemPermissionGroupsItemMeta {
    /** A category used to group permission groups. */
    category?: string;
    /** Indicates whether the permission group is deprecated. */
    deprecated?: string;
    /** Additional information about the permission group. */
    description?: string;
    /** Indicates whether the permission group can be edited. */
    editable?: string;
    /** The planned end-of-life date and time, when provided. */
    eolAt?: string;
    /** A label identifying the permission group. */
    label?: string;
    /** The scope associated with the permission group. */
    scopes?: string;
    /** Indicates the permission group's availability or visibility. */
    visibility?: string;
}
export interface TokensCreateRequestPoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: TokensCreateRequestPoliciesItemPermissionGroupsItemMeta;
    /** Name of the permission group. */
    name?: string;
}
export type TokensCreateRequestPoliciesItemPermissionGroupsList = Array<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export type TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensCreateRequestPoliciesItemResourcesValue = string | TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensCreateRequestPoliciesItemResourcesMap = {
    [key: string]: TokensCreateRequestPoliciesItemResourcesValue | undefined;
};
export interface TokensCreateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    effect: TokensCreateRequestPoliciesItemEffect | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensCreateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensCreateRequestPoliciesItemResourcesMap;
}
export type TokensCreateRequestPoliciesList = Array<TokensCreateRequestPoliciesItem>;
export type TokensCreateRequestConditionRequestIpInList = Array<string>;
export type TokensCreateRequestConditionRequestIpNotInList = Array<string>;
export interface TokensCreateRequestConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensCreateRequestConditionRequestIpInList;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensCreateRequestConditionRequestIpNotInList;
}
export interface TokensCreateRequestCondition {
    /** Client IP restrictions. */
    requestIp?: TokensCreateRequestConditionRequestIp;
}
export interface CreateTokenRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token name. */
    name: string;
    /** List of access policies assigned to the token. */
    policies: TokensCreateRequestPoliciesList;
    condition?: TokensCreateRequestCondition;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string;
}
export type TokensCreateResponseConditionRequestIpInList = Array<string>;
export type TokensCreateResponseConditionRequestIpNotInList = Array<string>;
export interface TokensCreateResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensCreateResponseConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensCreateResponseConditionRequestIpNotInList | null;
}
export interface TokensCreateResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensCreateResponseConditionRequestIp | null;
}
export type TokensCreateResponsePoliciesItemEffect = "allow" | "deny";
export type TokensCreateResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensCreateResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensCreateResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensCreateResponsePoliciesItemResourcesValue = string | TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensCreateResponsePoliciesItemResourcesMap = {
    [key: string]: TokensCreateResponsePoliciesItemResourcesValue | undefined;
};
export interface TokensCreateResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensCreateResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensCreateResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensCreateResponsePoliciesItemResourcesMap;
}
export type TokensCreateResponsePoliciesList = Array<TokensCreateResponsePoliciesItem>;
export type TokensCreateResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensCreateResponseCondition | null;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensCreateResponsePoliciesList | null;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null;
    /** Status of the token. */
    status?: TokensCreateResponseStatus | null;
    /** The token value. */
    value?: string | null;
}
export interface DeleteAccountRequest {
    /** The account ID of the account to be deleted */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAccountResponse {
    /** Identifier */
    id: string;
}
export interface DeleteMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Membership identifier tag. */
    memberId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMemberResponse {
    /** Identifier */
    id: string;
}
export interface DeletePaymentMethodRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    paymentMethodId: string;
}
export type DeletePaymentMethodResponse = unknown;
export interface DeleteSubscriptionRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSubscriptionResponse {
    /** Subscription identifier tag. */
    subscriptionId?: string | null;
}
export interface DeleteTokenRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token identifier tag. */
    tokenId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteTokenResponse {
    /** Identifier */
    id: string;
}
export interface EditInvoiceRequest {
    /** Identifier */
    accountId: string;
    /** Whether to enable or disable PDF invoice generation. */
    toggle?: boolean;
}
export type EditInvoiceResponse = unknown;
export interface GetAccountRequest {
    /** Account identifier tag. */
    accountId: string;
}
export type GetResponseType = "standard" | "enterprise";
export type GetResponseManagedBy = CreateResponseManagedBy;
export type GetResponseSettings = CreateResponseSettings;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAccountResponse {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: GetResponseType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: CreateResponseManagedBy | null;
    /** Account settings */
    settings?: CreateResponseSettings | null;
}
export interface GetAccountProfileRequest {
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAccountProfileResponse {
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export interface GetMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Membership identifier tag. */
    memberId: string;
}
export type MembersGetResponsePoliciesItemAccess = "allow" | "deny";
export type MembersGetResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type MembersGetResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type MembersGetResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type MembersGetResponsePoliciesItemResourceGroupsItemScopeObjectsItem = MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem;
export type MembersGetResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem>;
export interface MembersGetResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: MembersGetResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export type MembersGetResponsePoliciesItemResourceGroupsItemMeta = MembersCreateResponsePoliciesItemResourceGroupsItemMeta;
export interface MembersGetResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: MembersGetResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: MembersCreateResponsePoliciesItemResourceGroupsItemMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export type MembersGetResponsePoliciesItemResourceGroupsList = Array<MembersGetResponsePoliciesItemResourceGroupsItem>;
export interface MembersGetResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: MembersGetResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: MembersGetResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: MembersGetResponsePoliciesItemResourceGroupsList | null;
}
export type MembersGetResponsePoliciesList = Array<MembersGetResponsePoliciesItem>;
export type MembersGetResponseRolesItemPermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsBilling = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsCachePurge = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsDns = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsDnsRecords = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsLb = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsLogs = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsOrganization = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsSsl = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsWaf = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsZoneSettings = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsZones = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissions = MembersCreateResponseRolesItemPermissions;
export type MembersGetResponseRolesItem = MembersCreateResponseRolesItem;
export type MembersGetResponseRolesList = Array<MembersCreateResponseRolesItem>;
export type MembersGetResponseStatus = "accepted" | "pending";
export type MembersGetResponseUser = MembersCreateResponseUser;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMemberResponse {
    /** Membership identifier tag. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Access policy for the membership */
    policies?: MembersGetResponsePoliciesList | null;
    /** Roles assigned to this Member. */
    roles?: MembersGetResponseRolesList | null;
    /** A member's status in the account. */
    status?: MembersGetResponseStatus | null;
    /** Details of the user associated to the membership. */
    user?: MembersCreateResponseUser | null;
}
export interface GetPaymentMethodRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    paymentMethodId: string;
}
export type GetPaymentMethodResponseType = "CREDIT_CARD" | "PAYPAL" | "CASHAPP" | "SEPA_DEBIT" | "LINK" | "ACH_DIRECT_DEBIT";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPaymentMethodResponse {
    /** Payment method identifier. */
    id?: string | null;
    /** Billing address line 1. */
    address?: string | null;
    /** Billing address line 2. */
    address2?: string | null;
    /** Bank account type. */
    bankAccountType?: string | null;
    /** Bank code. */
    bankCode?: string | null;
    /** Bank country. */
    bankCountry?: string | null;
    /** Bank name for bank-based payment methods. */
    bankName?: string | null;
    /** Bank routing number. */
    bankRoutingNumber?: string | null;
    /** Cash App cash tag. */
    cashappCashTag?: string | null;
    /** Billing city. */
    city?: string | null;
    /** Billing country. */
    country?: string | null;
    /** Whether this is the default payment method. */
    default?: boolean | null;
    /** Device data for fraud prevention. */
    deviceData?: string | null;
    /** Card expiration date. */
    expirationDate?: string | null;
    /** Billing first name. */
    firstName?: string | null;
    /** Last four digits of the card number. */
    lastFour?: string | null;
    /** Billing last name. */
    lastName?: string | null;
    /** A nickname for the payment method. */
    nickName?: string | null;
    /** Email associated with the payment account. */
    paymentAccountEmail?: string | null;
    /** Payment email address. */
    paymentEmail?: string | null;
    /** The payment gateway used. */
    paymentGateway?: string | null;
    /** Payment nonce for tokenized payments. */
    paymentNonce?: string | null;
    /** Billing state. */
    state?: string | null;
    /** The payment method type. */
    type?: GetPaymentMethodResponseType | null;
    /** Billing zip code. */
    zipcode?: string | null;
}
export interface GetRoleRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Role identifier tag. */
    roleId: string;
}
export type RolesGetResponsePermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsBilling = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsCachePurge = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsDns = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsDnsRecords = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsLb = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsLogs = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsOrganization = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsSsl = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsWaf = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsZoneSettings = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsZones = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissions = MembersCreateResponseRolesItemPermissions;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRoleResponse {
    /** Role identifier tag. */
    id: string;
    /** Description of role's permissions. */
    description: string;
    /** Role name. */
    name: string;
    permissions: MembersCreateResponseRolesItemPermissions;
}
export interface GetSpeedSettingsTransformationRequest {
    /** Identifier. */
    accountId: string;
}
export interface GetSpeedSettingsTransformationResultItem {
    /** Feature identifier. */
    id?: string | null;
    /** Zone tag identifier. */
    cfZoneTag?: string | null;
    /** Whether this setting can be modified. */
    editable?: boolean | null;
    /** When this setting was last modified. */
    modifiedOn?: string | null;
    /** Current value of the feature setting. */
    value?: string | null;
}
export type GetSpeedSettingsTransformationResultList = Array<GetSpeedSettingsTransformationResultItem>;
export type GetSpeedSettingsTransformationResponse = GetSpeedSettingsTransformationResultList;
export interface GetSubscriptionRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
}
export type SubscriptionsGetResultItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsGetResultItemRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsGetResultItemRatePlanSetsList = Array<string>;
export interface SubscriptionsGetResultItemRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsGetResultItemRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsGetResultItemRatePlanSetsList | null;
}
export type SubscriptionsGetResultItemState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export interface SubscriptionsGetResultItem {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsGetResultItemFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsGetResultItemRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsGetResultItemState | null;
}
export type SubscriptionsGetResultList = Array<SubscriptionsGetResultItem>;
export interface GetSubscriptionResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubscriptionsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetTokenRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token identifier tag. */
    tokenId: string;
}
export type TokensGetResponseConditionRequestIpInList = Array<string>;
export type TokensGetResponseConditionRequestIpNotInList = Array<string>;
export interface TokensGetResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensGetResponseConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensGetResponseConditionRequestIpNotInList | null;
}
export interface TokensGetResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensGetResponseConditionRequestIp | null;
}
export type TokensGetResponsePoliciesItemEffect = "allow" | "deny";
export type TokensGetResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensGetResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensGetResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensGetResponsePoliciesItemResourcesValue = string | TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensGetResponsePoliciesItemResourcesMap = {
    [key: string]: TokensGetResponsePoliciesItemResourcesValue | undefined;
};
export interface TokensGetResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensGetResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensGetResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensGetResponsePoliciesItemResourcesMap;
}
export type TokensGetResponsePoliciesList = Array<TokensGetResponsePoliciesItem>;
export type TokensGetResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTokenResponse {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensGetResponseCondition | null;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensGetResponsePoliciesList | null;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null;
    /** Status of the token. */
    status?: TokensGetResponseStatus | null;
}
export interface GetTokenPermissionGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Filter by the name of the permission group. The value must be URL-encoded. */
    name?: string;
    /** Filter by the scope of the permission group. The value must be URL-encoded. */
    scope?: string;
}
export type TokensPermissionGroupsGetResultItemCategory = "developer_platform" | "ai_and_machine_learning" | "dns_and_zones" | "app_security" | "rules_and_configuration" | "cloudflare_one_and_zero_trust" | "analytics_and_logs" | "network_services" | "media" | "email_and_messaging" | "cache_and_performance" | "account_and_billing" | "other";
export type TokensPermissionGroupsGetResultItemScopesItem = "com.cloudflare.api.account" | "com.cloudflare.api.account.zone" | "com.cloudflare.api.user" | "com.cloudflare.edge.r2.bucket";
export type TokensPermissionGroupsGetResultItemScopesList = Array<TokensPermissionGroupsGetResultItemScopesItem>;
export interface TokensPermissionGroupsGetResultItem {
    /** Public ID. */
    id?: string | null;
    /** Product category that this permission group belongs to. */
    category?: TokensPermissionGroupsGetResultItemCategory | null;
    /** Whether the caller can select this permission group when creating a token. */
    isSelectable?: boolean | null;
    /** Permission Group Name */
    name?: string | null;
    /** Resources to which the Permission Group is scoped */
    scopes?: TokensPermissionGroupsGetResultItemScopesList | null;
}
export type TokensPermissionGroupsGetResultList = Array<TokensPermissionGroupsGetResultItem>;
export type GetTokenPermissionGroupResponse = TokensPermissionGroupsGetResultList;
export type ListRequestDirection = "asc" | "desc";
export interface ListAccountsRequest {
    /** Direction to order results. */
    direction?: ListRequestDirection | (string & {});
    /** Name of the account. */
    name?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type ListResultItemType = "standard" | "enterprise";
export type ListResultItemManagedBy = CreateResponseManagedBy;
export type ListResultItemSettings = CreateResponseSettings;
export interface ListResultItem {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: ListResultItemType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: CreateResponseManagedBy | null;
    /** Account settings */
    settings?: CreateResponseSettings | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListAccountsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListEntitlementsRequest {
    /** Identifier tag. */
    accountId: string;
}
export type ListEntitlementsResultItemAllocationType = "bool" | "max_count" | "enum_number" | "range" | "string";
export type ListEntitlementsResultItemAllocationValueCase3List = Array<number>;
export interface ListEntitlementsResultItemAllocationValueCase4 {
    max: number;
    min: number;
}
export type ListEntitlementsResultItemAllocationValue = string | number | boolean | ListEntitlementsResultItemAllocationValueCase3List | ListEntitlementsResultItemAllocationValueCase4;
export interface ListEntitlementsResultItemAllocation {
    /** Allocation type discriminator. */
    type: ListEntitlementsResultItemAllocationType;
    /** Contains the allocation value whose concrete type the `type` field determines: bool yields a boolean, max_count yields an integer, enum_number yields an array of numbers, range yields an object with `min` and `max`, and string yields a string. */
    value: ListEntitlementsResultItemAllocationValue;
}
export interface ListEntitlementsResultItemFeature {
    /** Numeric identifier of the feature. */
    id: number;
    /** The logical grouping (set) this feature belongs to. */
    featureSet: string;
    /** Unique string key for the feature. */
    key: string;
    /** Human-readable name of the feature. */
    name: string;
}
export interface ListEntitlementsResultItem {
    /** Entitlement identifier -- equal to the feature key. */
    id: string;
    /** Represents the allocation value for an entitlement. The shape of `value` depends on `type`: `bool` uses a boolean, `max_count` uses an integer, `enum_number` uses an array of numbers, `range` uses an object with `min` and `max` integer fields, and `string` uses a string. */
    allocation: ListEntitlementsResultItemAllocation;
    /** ISO 8601 timestamp (microsecond precision, no timezone offset) when the entitlement was created. Format: `YYYY-MM-DDTHH:MM:SS.ffffff`. */
    createdDate: string;
    /** ISO 8601 timestamp when the entitlement was deleted, or empty string if not deleted. */
    deletedDate: string;
    /** ISO 8601 timestamp (microsecond precision, no timezone offset) when the entitlement was last edited. */
    editedDate: string;
    /** Describes a product feature associated with an entitlement. */
    feature: ListEntitlementsResultItemFeature;
}
export type ListEntitlementsResultList = Array<ListEntitlementsResultItem>;
export type ListEntitlementsResponse = ListEntitlementsResultList;
export type LogsAuditListRequestIdNotList = Array<string>;
export interface LogsAuditListRequestId {
    /** Filters out audit logs by their IDs. */
    not?: LogsAuditListRequestIdNotList;
}
export type LogsAuditListRequestAccountNameNotList = Array<string>;
export interface LogsAuditListRequestAccountName {
    /** Filters out audit logs by the account name. */
    not?: LogsAuditListRequestAccountNameNotList;
}
export type LogsAuditListRequestActionResultNotItem = "success" | "failure";
export type LogsAuditListRequestActionResultNotList = Array<LogsAuditListRequestActionResultNotItem | (string & {})>;
export interface LogsAuditListRequestActionResult {
    /** Filters out audit logs by whether the action was successful or not. */
    not?: LogsAuditListRequestActionResultNotList;
}
export type LogsAuditListRequestActionTypeNotItem = "create" | "delete" | "view" | "update";
export type LogsAuditListRequestActionTypeNotList = Array<LogsAuditListRequestActionTypeNotItem | (string & {})>;
export interface LogsAuditListRequestActionType {
    /** Filters out audit logs by the action type. */
    not?: LogsAuditListRequestActionTypeNotList;
}
export type LogsAuditListRequestActorContextNotItem = "api" | "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export type LogsAuditListRequestActorContextNotList = Array<LogsAuditListRequestActorContextNotItem | (string & {})>;
export interface LogsAuditListRequestActorContext {
    /** Filters out audit logs by the actor context. */
    not?: LogsAuditListRequestActorContextNotList;
}
export type LogsAuditListRequestActorEmailNotList = Array<string>;
export interface LogsAuditListRequestActorEmail {
    /** Filters out audit logs by the actor's email address. */
    not?: LogsAuditListRequestActorEmailNotList;
}
export type LogsAuditListRequestActorIdNotList = Array<string>;
export interface LogsAuditListRequestActorId {
    /** Filters out audit logs by the actor ID. This can be either the Account ID or User ID. */
    not?: LogsAuditListRequestActorIdNotList;
}
export type LogsAuditListRequestActorIpAddressNotList = Array<string>;
export interface LogsAuditListRequestActorIpAddress {
    /** Filters out audit logs IP address where the action was initiated. */
    not?: LogsAuditListRequestActorIpAddressNotList;
}
export type LogsAuditListRequestActorTokenIdNotList = Array<string>;
export interface LogsAuditListRequestActorTokenId {
    /** Filters out audit logs by the API token ID when the actor context is an api_token or oauth. */
    not?: LogsAuditListRequestActorTokenIdNotList;
}
export type LogsAuditListRequestActorTokenNameNotList = Array<string>;
export interface LogsAuditListRequestActorTokenName {
    /** Filters out audit logs by the API token name when the actor context is an api_token or oauth. */
    not?: LogsAuditListRequestActorTokenNameNotList;
}
export type LogsAuditListRequestActorTypeNotItem = "account" | "cloudflare_admin" | "delegated_service" | "system" | "user";
export type LogsAuditListRequestActorTypeNotList = Array<LogsAuditListRequestActorTypeNotItem | (string & {})>;
export interface LogsAuditListRequestActorType {
    /** Filters out audit logs by the actor type. */
    not?: LogsAuditListRequestActorTypeNotList;
}
export type LogsAuditListRequestAuditLogIdNotList = Array<string>;
export interface LogsAuditListRequestAuditLogId {
    /** Filters out audit logs by their IDs. */
    not?: LogsAuditListRequestAuditLogIdNotList;
}
export type LogsAuditListRequestDirection = "desc" | "asc";
export type LogsAuditListRequestProductCategoryList = Array<string>;
export type LogsAuditListRequestRawCfRayIdNotList = Array<string>;
export interface LogsAuditListRequestRawCfRayId {
    /** Filters out audit logs by the response CF Ray ID. */
    not?: LogsAuditListRequestRawCfRayIdNotList;
}
export type LogsAuditListRequestRawMethodNotList = Array<string>;
export interface LogsAuditListRequestRawMethod {
    /** Filters out audit logs by the HTTP method for the API call. */
    not?: LogsAuditListRequestRawMethodNotList;
}
export type LogsAuditListRequestRawStatusCodeNotList = Array<number>;
export interface LogsAuditListRequestRawStatusCode {
    /** Filters out audit logs by the response status code that was returned. */
    not?: LogsAuditListRequestRawStatusCodeNotList;
}
export type LogsAuditListRequestRawUriNotList = Array<string>;
export interface LogsAuditListRequestRawUri {
    /** Filters out audit logs by the request URI. */
    not?: LogsAuditListRequestRawUriNotList;
}
export type LogsAuditListRequestResourceIdNotList = Array<string>;
export interface LogsAuditListRequestResourceId {
    /** Filters out audit logs by the resource ID. */
    not?: LogsAuditListRequestResourceIdNotList;
}
export type LogsAuditListRequestResourceProductNotList = Array<string>;
export interface LogsAuditListRequestResourceProduct {
    /** Filters out audit logs by the Cloudflare product associated with the changed resource. */
    not?: LogsAuditListRequestResourceProductNotList;
}
export type LogsAuditListRequestResourceScopeNotItem = "accounts" | "user" | "zones" | "memberships";
export type LogsAuditListRequestResourceScopeNotList = Array<LogsAuditListRequestResourceScopeNotItem | (string & {})>;
export interface LogsAuditListRequestResourceScope {
    /** Filters out audit logs by the resource scope, specifying whether the resource is associated with an user, an account, a zone, or a membership. */
    not?: LogsAuditListRequestResourceScopeNotList;
}
export type LogsAuditListRequestResourceTypeNotList = Array<string>;
export interface LogsAuditListRequestResourceType {
    /** Filters out audit logs based on the unique type of resource changed by the action. */
    not?: LogsAuditListRequestResourceTypeNotList;
}
export type LogsAuditListRequestZoneIdNotList = Array<string>;
export interface LogsAuditListRequestZoneId {
    /** Filters out audit logs by the zone ID. */
    not?: LogsAuditListRequestZoneIdNotList;
}
export type LogsAuditListRequestZoneNameNotList = Array<string>;
export interface LogsAuditListRequestZoneName {
    /** Filters out audit logs by the zone name associated with the change. */
    not?: LogsAuditListRequestZoneNameNotList;
}
export interface ListLogAuditsRequest {
    /** The unique id that identifies the account. */
    accountId: string;
    /** Limits the returned results to logs older than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    before: string;
    /** Limits the returned results to logs newer than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    since: string;
    id?: LogsAuditListRequestId;
    accountName?: LogsAuditListRequestAccountName;
    actionResult?: LogsAuditListRequestActionResult;
    actionType?: LogsAuditListRequestActionType;
    actorContext?: LogsAuditListRequestActorContext;
    actorEmail?: LogsAuditListRequestActorEmail;
    actorId?: LogsAuditListRequestActorId;
    actorIpAddress?: LogsAuditListRequestActorIpAddress;
    actorTokenId?: LogsAuditListRequestActorTokenId;
    actorTokenName?: LogsAuditListRequestActorTokenName;
    actorType?: LogsAuditListRequestActorType;
    auditLogId?: LogsAuditListRequestAuditLogId;
    /** The cursor is an opaque token used to paginate through large sets of records. It indicates the position from which to continue when requesting the next set of records. A valid cursor value can be obtained from the cursor object in the result_info structure of a previous response. */
    cursor?: string;
    /** Sets sorting order. */
    direction?: LogsAuditListRequestDirection | (string & {});
    /** The number limits the objects to return. The cursor attribute may be used to iterate over the next batch of objects if there are more than the limit. */
    limit?: number;
    /** Filters audit logs by one or more predefined product categories. Each product category expands into a curated set of resource_product values and is unioned with any explicit resource_product filter. Matched case-insensitively; unknown product categories return 400. Repeatable. Use the audit log product categories endpoint to discover the available values. */
    productCategory?: LogsAuditListRequestProductCategoryList;
    rawCfRayId?: LogsAuditListRequestRawCfRayId;
    rawMethod?: LogsAuditListRequestRawMethod;
    rawStatusCode?: LogsAuditListRequestRawStatusCode;
    rawUri?: LogsAuditListRequestRawUri;
    resourceId?: LogsAuditListRequestResourceId;
    resourceProduct?: LogsAuditListRequestResourceProduct;
    resourceScope?: LogsAuditListRequestResourceScope;
    resourceType?: LogsAuditListRequestResourceType;
    zoneId?: LogsAuditListRequestZoneId;
    zoneName?: LogsAuditListRequestZoneName;
}
export interface LogsAuditListResultItemAccount {
    /** A unique identifier for the account. */
    id?: string | null;
    /** A string that identifies the account name. */
    name?: string | null;
}
export interface LogsAuditListResultItemAction {
    /** A short description of the action performed. */
    description?: string | null;
    /** The result of the action, indicating success or failure. */
    result?: string | null;
    /** A timestamp indicating when the action was logged. */
    time?: string | null;
    /** A short string that describes the action that was performed. */
    type?: string | null;
}
export type LogsAuditListResultItemActorContext = "api" | "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export type LogsAuditListResultItemActorType = "account" | "cloudflare_admin" | "delegated_service" | "system" | "user";
export interface LogsAuditListResultItemActor {
    /** The ID of the actor who performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null;
    /** The context in which the action was initiated. */
    context?: LogsAuditListResultItemActorContext | null;
    /** The email of the actor who performed the action. */
    email?: string | null;
    /** The IP address of the request that performed the action. */
    ipAddress?: string | null;
    /** The API token ID when the actor context is an api_token or oauth. */
    tokenId?: string | null;
    /** The API token name when the actor context is an api_token or oauth. */
    tokenName?: string | null;
    /** The type of actor. */
    type?: LogsAuditListResultItemActorType | null;
}
export interface LogsAuditListResultItemRaw {
    /** The Cloudflare Ray ID for the request. */
    cfRayId?: string | null;
    /** The HTTP method of the request. */
    method?: string | null;
    /** The HTTP response status code returned by the API. */
    statusCode?: number | null;
    /** The URI of the request. */
    uri?: string | null;
    /** The client's user agent string sent with the request. */
    userAgent?: string | null;
}
export interface LogsAuditListResultItemResource {
    /** The unique identifier for the affected resource. */
    id?: string | null;
    /** The Cloudflare product associated with the resource. */
    product?: string | null;
    request?: unknown | null;
    response?: unknown | null;
    /** The scope of the resource. */
    scope?: unknown | null;
    /** The type of the resource. */
    type?: string | null;
}
export interface LogsAuditListResultItemZone {
    /** A string that identifies the zone id. */
    id?: string | null;
    /** A string that identifies the zone name. */
    name?: string | null;
}
export interface LogsAuditListResultItem {
    /** A unique identifier for the audit log entry. */
    id?: string | null;
    /** Contains account related information. */
    account?: LogsAuditListResultItemAccount | null;
    /** Provides information about the action performed. */
    action?: LogsAuditListResultItemAction | null;
    /** Provides details about the actor who performed the action. */
    actor?: LogsAuditListResultItemActor | null;
    /** Provides raw information about the request and response. */
    raw?: LogsAuditListResultItemRaw | null;
    /** Provides details about the affected resource. */
    resource?: LogsAuditListResultItemResource | null;
    /** Provides details about the zone affected by the action. */
    zone?: LogsAuditListResultItemZone | null;
}
export type LogsAuditListResultList = Array<LogsAuditListResultItem>;
export interface ListLogAuditsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogsAuditListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type MembersListRequestDirection = "asc" | "desc";
export type MembersListRequestOrder = "user.first_name" | "user.last_name" | "user.email" | "status";
export type MembersListRequestStatus = "accepted" | "pending" | "rejected";
export interface ListMembersRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Direction to order results. */
    direction?: MembersListRequestDirection | (string & {});
    /** Field to order results by. */
    order?: MembersListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** A member's status in the account. */
    status?: MembersListRequestStatus | (string & {});
}
export type MembersListResultItemPoliciesItemAccess = "allow" | "deny";
export type MembersListResultItemPoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type MembersListResultItemPoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type MembersListResultItemPoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type MembersListResultItemPoliciesItemResourceGroupsItemScopeObjectsItem = MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem;
export type MembersListResultItemPoliciesItemResourceGroupsItemScopeObjectsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem>;
export interface MembersListResultItemPoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: MembersListResultItemPoliciesItemResourceGroupsItemScopeObjectsList;
}
export type MembersListResultItemPoliciesItemResourceGroupsItemMeta = MembersCreateResponsePoliciesItemResourceGroupsItemMeta;
export interface MembersListResultItemPoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: MembersListResultItemPoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: MembersCreateResponsePoliciesItemResourceGroupsItemMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export type MembersListResultItemPoliciesItemResourceGroupsList = Array<MembersListResultItemPoliciesItemResourceGroupsItem>;
export interface MembersListResultItemPoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: MembersListResultItemPoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: MembersListResultItemPoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: MembersListResultItemPoliciesItemResourceGroupsList | null;
}
export type MembersListResultItemPoliciesList = Array<MembersListResultItemPoliciesItem>;
export type MembersListResultItemRolesItemPermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsBilling = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsCachePurge = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsDns = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsDnsRecords = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsLb = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsLogs = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsOrganization = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsSsl = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsWaf = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsZoneSettings = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsZones = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissions = MembersCreateResponseRolesItemPermissions;
export type MembersListResultItemRolesItem = MembersCreateResponseRolesItem;
export type MembersListResultItemRolesList = Array<MembersCreateResponseRolesItem>;
export type MembersListResultItemStatus = "accepted" | "pending";
export type MembersListResultItemUser = MembersCreateResponseUser;
export interface MembersListResultItem {
    /** Membership identifier tag. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Access policy for the membership */
    policies?: MembersListResultItemPoliciesList | null;
    /** Roles assigned to this Member. */
    roles?: MembersListResultItemRolesList | null;
    /** A member's status in the account. */
    status?: MembersListResultItemStatus | null;
    /** Details of the user associated to the membership. */
    user?: MembersCreateResponseUser | null;
}
export type MembersListResultList = Array<MembersListResultItem>;
export interface ListMembersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MembersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListPaymentMethodsRequest {
    /** Identifier */
    accountId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
}
export type ListPaymentMethodsResultItemType = "CREDIT_CARD" | "PAYPAL" | "CASHAPP" | "SEPA_DEBIT" | "LINK" | "ACH_DIRECT_DEBIT";
export interface ListPaymentMethodsResultItem {
    /** Payment method identifier. */
    id?: string | null;
    /** Billing address line 1. */
    address?: string | null;
    /** Billing address line 2. */
    address2?: string | null;
    /** Bank account type. */
    bankAccountType?: string | null;
    /** Bank code. */
    bankCode?: string | null;
    /** Bank country. */
    bankCountry?: string | null;
    /** Bank name for bank-based payment methods. */
    bankName?: string | null;
    /** Bank routing number. */
    bankRoutingNumber?: string | null;
    /** Cash App cash tag. */
    cashappCashTag?: string | null;
    /** Billing city. */
    city?: string | null;
    /** Billing country. */
    country?: string | null;
    /** Whether this is the default payment method. */
    default?: boolean | null;
    /** Device data for fraud prevention. */
    deviceData?: string | null;
    /** Card expiration date. */
    expirationDate?: string | null;
    /** Billing first name. */
    firstName?: string | null;
    /** Last four digits of the card number. */
    lastFour?: string | null;
    /** Billing last name. */
    lastName?: string | null;
    /** A nickname for the payment method. */
    nickName?: string | null;
    /** Email associated with the payment account. */
    paymentAccountEmail?: string | null;
    /** Payment email address. */
    paymentEmail?: string | null;
    /** The payment gateway used. */
    paymentGateway?: string | null;
    /** Payment nonce for tokenized payments. */
    paymentNonce?: string | null;
    /** Billing state. */
    state?: string | null;
    /** The payment method type. */
    type?: ListPaymentMethodsResultItemType | null;
    /** Billing zip code. */
    zipcode?: string | null;
}
export type ListPaymentMethodsResultList = Array<ListPaymentMethodsResultItem>;
export type ListPaymentMethodsResponse = ListPaymentMethodsResultList;
export interface ListRolesRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of roles per page. */
    perPage?: number;
}
export type RolesListResultItemPermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsBilling = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsCachePurge = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsDns = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsDnsRecords = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsLb = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsLogs = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsOrganization = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsSsl = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsWaf = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsZoneSettings = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsZones = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissions = MembersCreateResponseRolesItemPermissions;
export type RolesListResultItem = MembersCreateResponseRolesItem;
export type RolesListResultList = Array<MembersCreateResponseRolesItem>;
export interface ListRolesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RolesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type TokensListRequestDirection = "asc" | "desc";
export interface ListTokensRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Direction to order results. */
    direction?: TokensListRequestDirection | (string & {});
    /** When true, includes recently-expired tokens in the response. */
    includeExpired?: boolean;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type TokensListResultItemConditionRequestIpInList = Array<string>;
export type TokensListResultItemConditionRequestIpNotInList = Array<string>;
export interface TokensListResultItemConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensListResultItemConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensListResultItemConditionRequestIpNotInList | null;
}
export interface TokensListResultItemCondition {
    /** Client IP restrictions. */
    requestIp?: TokensListResultItemConditionRequestIp | null;
}
export type TokensListResultItemPoliciesItemEffect = "allow" | "deny";
export type TokensListResultItemPoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensListResultItemPoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensListResultItemPoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensListResultItemPoliciesItemResourcesValue = string | TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensListResultItemPoliciesItemResourcesMap = {
    [key: string]: TokensListResultItemPoliciesItemResourcesValue | undefined;
};
export interface TokensListResultItemPoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensListResultItemPoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensListResultItemPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensListResultItemPoliciesItemResourcesMap;
}
export type TokensListResultItemPoliciesList = Array<TokensListResultItemPoliciesItem>;
export type TokensListResultItemStatus = "active" | "disabled" | "expired";
export interface TokensListResultItem {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensListResultItemCondition | null;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensListResultItemPoliciesList | null;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null;
    /** Status of the token. */
    status?: TokensListResultItemStatus | null;
}
export type TokensListResultList = Array<TokensListResultItem>;
export interface ListTokensResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TokensListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListTokensPermissionGroupsRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Filter by the name of the permission group. The value must be URL-encoded. */
    name?: string;
    /** Filter by the scope of the permission group. The value must be URL-encoded. */
    scope?: string;
}
export type ListTokensPermissionGroupsResultItemCategory = "developer_platform" | "ai_and_machine_learning" | "dns_and_zones" | "app_security" | "rules_and_configuration" | "cloudflare_one_and_zero_trust" | "analytics_and_logs" | "network_services" | "media" | "email_and_messaging" | "cache_and_performance" | "account_and_billing" | "other";
export type ListTokensPermissionGroupsResultItemScopesItem = "com.cloudflare.api.account" | "com.cloudflare.api.account.zone" | "com.cloudflare.api.user" | "com.cloudflare.edge.r2.bucket";
export type ListTokensPermissionGroupsResultItemScopesList = Array<ListTokensPermissionGroupsResultItemScopesItem>;
export interface ListTokensPermissionGroupsResultItem {
    /** Public ID. */
    id?: string | null;
    /** Product category that this permission group belongs to. */
    category?: ListTokensPermissionGroupsResultItemCategory | null;
    /** Whether the caller can select this permission group when creating a token. */
    isSelectable?: boolean | null;
    /** Permission Group Name */
    name?: string | null;
    /** Resources to which the Permission Group is scoped */
    scopes?: ListTokensPermissionGroupsResultItemScopesList | null;
}
export type ListTokensPermissionGroupsResultList = Array<ListTokensPermissionGroupsResultItem>;
export type ListTokensPermissionGroupsResponse = ListTokensPermissionGroupsResultList;
export type LogsAuditHistoryRequestDirection = "desc" | "asc";
export interface LogsAuditHistoryRequest {
    /** The unique ID that identifies the account. */
    accountId: string;
    /** The ID of the audit log to fetch resource history for. */
    id: string;
    /** RFC3339 timestamp of the source audit log entry's action time. Used to narrow the source-entry lookup window. Provide the `action.time` value from the audit log identified by `id`. */
    actionTime: string;
    /** Limits the returned results to logs older than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    before: string;
    /** Limits the returned results to logs newer than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    since: string;
    /** The cursor is an opaque token used to paginate through large sets of records. It indicates the position from which to continue when requesting the next set of records. A valid cursor value can be obtained from the cursor object in the result_info structure of a previous response. */
    cursor?: string;
    /** Sets sorting order. */
    direction?: LogsAuditHistoryRequestDirection | (string & {});
    /** The number limits the objects to return. The cursor attribute may be used to iterate over the next batch of objects if there are more than the limit. */
    limit?: number;
}
export type LogsAuditHistoryResultItemAccount = LogsAuditListResultItemAccount;
export type LogsAuditHistoryResultItemAction = LogsAuditListResultItemAction;
export type LogsAuditHistoryResultItemActorContext = "api" | "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export type LogsAuditHistoryResultItemActorType = "account" | "cloudflare_admin" | "delegated_service" | "system" | "user";
export interface LogsAuditHistoryResultItemActor {
    /** The ID of the actor who performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null;
    /** The context in which the action was initiated. */
    context?: LogsAuditHistoryResultItemActorContext | null;
    /** The email of the actor who performed the action. */
    email?: string | null;
    /** The IP address of the request that performed the action. */
    ipAddress?: string | null;
    /** The API token ID when the actor context is an api_token or oauth. */
    tokenId?: string | null;
    /** The API token name when the actor context is an api_token or oauth. */
    tokenName?: string | null;
    /** The type of actor. */
    type?: LogsAuditHistoryResultItemActorType | null;
}
export type LogsAuditHistoryResultItemRaw = LogsAuditListResultItemRaw;
export type LogsAuditHistoryResultItemResource = LogsAuditListResultItemResource;
export type LogsAuditHistoryResultItemZone = LogsAuditListResultItemZone;
export interface LogsAuditHistoryResultItem {
    /** A unique identifier for the audit log entry. */
    id?: string | null;
    /** Contains account related information. */
    account?: LogsAuditListResultItemAccount | null;
    /** Provides information about the action performed. */
    action?: LogsAuditListResultItemAction | null;
    /** Provides details about the actor who performed the action. */
    actor?: LogsAuditHistoryResultItemActor | null;
    /** Provides raw information about the request and response. */
    raw?: LogsAuditListResultItemRaw | null;
    /** Provides details about the affected resource. */
    resource?: LogsAuditListResultItemResource | null;
    /** Provides details about the zone affected by the action. */
    zone?: LogsAuditListResultItemZone | null;
}
export type LogsAuditHistoryResultList = Array<LogsAuditHistoryResultItem>;
export type LogsAuditHistoryResponse = LogsAuditHistoryResultList;
export interface LogsAuditProductCategoriesRequest {
    /** The unique id that identifies the account. */
    accountId: string;
}
export interface LogsAuditProductCategoriesResultItemProductsItem {
    /** A human-readable label for the product. */
    label?: string | null;
    /** The resource_product value that the product category expands to. */
    value?: string | null;
}
export type LogsAuditProductCategoriesResultItemProductsList = Array<LogsAuditProductCategoriesResultItemProductsItem>;
export interface LogsAuditProductCategoriesResultItem {
    /** A human-readable label for the product category. */
    label?: string | null;
    /** The resource products that the product category expands to. */
    products?: LogsAuditProductCategoriesResultItemProductsList | null;
    /** The product category identifier used with the product_category filter. */
    value?: string | null;
}
export type LogsAuditProductCategoriesResultList = Array<LogsAuditProductCategoriesResultItem>;
export type LogsAuditProductCategoriesResponse = LogsAuditProductCategoriesResultList;
export interface PaymentMethodsSetAsDefaultRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    paymentMethodId: string;
}
export type PaymentMethodsSetAsDefaultResponse = unknown;
export interface PutTokenValueRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token identifier tag. */
    tokenId: string;
}
export type PutTokenValueResponse = unknown;
export interface ReceiptsPdfRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    receiptId: string;
    /** The document type to generate. */
    doctype?: string;
}
export interface ReceiptsPdfResponse {
}
export type SubscriptionsActionsAppendRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsActionsAppendRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsActionsAppendRequestRatePlanSetsList = Array<string>;
export interface SubscriptionsActionsAppendRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsActionsAppendRequestRatePlanId | (string & {});
    /** The currency applied to the rate plan subscription. */
    currency?: string;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean;
    /** The full name of the rate plan. */
    publicName?: string;
    /** The scope that this rate plan applies to. */
    scope?: string;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsActionsAppendRequestRatePlanSetsList;
}
export interface SubscriptionsActionsAppendRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsActionsAppendRequestFrequency | (string & {});
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsActionsAppendRequestRatePlan;
}
export type SubscriptionsActionsAppendResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsActionsAppendResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsActionsAppendResponseRatePlanSetsList = Array<string>;
export interface SubscriptionsActionsAppendResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsActionsAppendResponseRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsActionsAppendResponseRatePlanSetsList | null;
}
export type SubscriptionsActionsAppendResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SubscriptionsActionsAppendResponse {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsActionsAppendResponseFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsActionsAppendResponseRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsActionsAppendResponseState | null;
}
export type SubscriptionsBulkCreateRequestSubscriptionsItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsBulkCreateRequestSubscriptionsItemRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsBulkCreateRequestSubscriptionsItemRatePlanSetsList = Array<string>;
export interface SubscriptionsBulkCreateRequestSubscriptionsItemRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsBulkCreateRequestSubscriptionsItemRatePlanId | (string & {});
    /** The currency applied to the rate plan subscription. */
    currency?: string;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean;
    /** The full name of the rate plan. */
    publicName?: string;
    /** The scope that this rate plan applies to. */
    scope?: string;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsBulkCreateRequestSubscriptionsItemRatePlanSetsList;
}
export type SubscriptionsBulkCreateRequestSubscriptionsItemState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export interface SubscriptionsBulkCreateRequestSubscriptionsItem {
    /** Subscription identifier tag. */
    id?: string;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsBulkCreateRequestSubscriptionsItemFrequency | (string & {});
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsBulkCreateRequestSubscriptionsItemRatePlan;
    /** The state that the subscription is in. */
    state?: SubscriptionsBulkCreateRequestSubscriptionsItemState | (string & {});
}
export type SubscriptionsBulkCreateRequestSubscriptionsList = Array<SubscriptionsBulkCreateRequestSubscriptionsItem>;
export interface SubscriptionsBulkCreateRequest {
    /** Identifier */
    accountId: string;
    idempKey?: string;
    couponCode?: string;
    paymentHoldId?: number;
    subscriptions?: SubscriptionsBulkCreateRequestSubscriptionsList;
    userIsOnSession?: boolean;
}
export type SubscriptionsBulkCreateResultList = Array<unknown>;
export type SubscriptionsBulkCreateResponse = SubscriptionsBulkCreateResultList;
export type SubscriptionsCancelDowngradeRequestSubscriptionIdsList = Array<string>;
export interface SubscriptionsCancelDowngradeRequest {
    /** Identifier */
    accountId: string;
    /** List of subscription identifiers to cancel downgrades for. */
    subscriptionIds?: SubscriptionsCancelDowngradeRequestSubscriptionIdsList;
}
export type SubscriptionsCancelDowngradeResponse = unknown;
export type SubscriptionsCancelReasonCreateRequestReasonCodeList = Array<string>;
export interface SubscriptionsCancelReasonCreateRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
    /** Additional cancellation details. */
    other?: string;
    /** The cancellation reason codes. */
    reasonCode?: SubscriptionsCancelReasonCreateRequestReasonCodeList;
}
export type SubscriptionsCancelReasonCreateResponseReasonCodeList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SubscriptionsCancelReasonCreateResponse {
    /** The cancel reason identifier. */
    id?: string | null;
    /** Additional cancellation details. */
    other?: string | null;
    /** The cancellation reason codes. */
    reasonCode?: SubscriptionsCancelReasonCreateResponseReasonCodeList | null;
    /** When the cancel reason was submitted. */
    submitted?: string | null;
    /** The subscription identifier. */
    subscriptionId?: string | null;
}
export interface SubscriptionsCancelReasonGetRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
}
export type SubscriptionsCancelReasonGetResponseReasonCodeList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SubscriptionsCancelReasonGetResponse {
    /** The cancel reason identifier. */
    id?: string | null;
    /** Additional cancellation details. */
    other?: string | null;
    /** The cancellation reason codes. */
    reasonCode?: SubscriptionsCancelReasonGetResponseReasonCodeList | null;
    /** When the cancel reason was submitted. */
    submitted?: string | null;
    /** The subscription identifier. */
    subscriptionId?: string | null;
}
export interface SubscriptionsGetByIdentifierRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
}
export type SubscriptionsGetByIdentifierResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsGetByIdentifierResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsGetByIdentifierResponseRatePlanSetsList = Array<string>;
export interface SubscriptionsGetByIdentifierResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsGetByIdentifierResponseRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsGetByIdentifierResponseRatePlanSetsList | null;
}
export type SubscriptionsGetByIdentifierResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SubscriptionsGetByIdentifierResponse {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsGetByIdentifierResponseFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsGetByIdentifierResponseRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsGetByIdentifierResponseState | null;
}
export type UpdateRequestType = "standard" | "enterprise";
export interface UpdateRequestManagedBy {
    /** ID of the parent Organization, if one exists */
    parentOrgId?: string;
    /** Name of the parent Organization, if one exists */
    parentOrgName?: string;
}
export interface UpdateRequestSettings {
    /** Sets an abuse contact email to notify for abuse reports. */
    abuseContactEmail?: string;
    /** Indicates whether membership in this account requires that Two-Factor Authentication is enabled */
    enforceTwofactor?: boolean;
}
export interface UpdateAccountRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type?: UpdateRequestType | (string & {});
    /** Parent container details */
    managedBy?: UpdateRequestManagedBy;
    /** Account settings */
    settings?: UpdateRequestSettings;
}
export type UpdateResponseType = "standard" | "enterprise";
export type UpdateResponseManagedBy = CreateResponseManagedBy;
export type UpdateResponseSettings = CreateResponseSettings;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAccountResponse {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: UpdateResponseType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: CreateResponseManagedBy | null;
    /** Account settings */
    settings?: CreateResponseSettings | null;
}
export interface UpdateAccountProfileRequest {
    accountId: string;
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export interface UpdateAccountProfileResponse {
}
export interface MembersUpdateRequestRolesItemPermissionsAnalytics {
    read?: boolean;
    write?: boolean;
}
export type MembersUpdateRequestRolesItemPermissionsBilling = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsCachePurge = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsDns = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsDnsRecords = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsLb = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsLogs = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsOrganization = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsSsl = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsWaf = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsZoneSettings = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsZones = MembersUpdateRequestRolesItemPermissionsAnalytics;
export interface MembersUpdateRequestRolesItemPermissions {
    analytics?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    billing?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    cachePurge?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    dns?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    dnsRecords?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    lb?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    logs?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    organization?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    ssl?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    waf?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    zoneSettings?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    zones?: MembersUpdateRequestRolesItemPermissionsAnalytics;
}
export interface MembersUpdateRequestRolesItem {
    /** Role identifier tag. */
    id: string;
    /** Description of role's permissions. */
    description?: string;
    /** Role name. */
    name?: string;
    permissions?: MembersUpdateRequestRolesItemPermissions;
}
export type MembersUpdateRequestRolesList = Array<MembersUpdateRequestRolesItem>;
export type MembersUpdateRequestStatus = "accepted" | "pending";
export interface MembersUpdateRequestUser {
    /** The contact email address of the user. */
    email: string;
    /** Identifier */
    id?: string;
    /** User's first name */
    firstName?: string;
    /** User's last name */
    lastName?: string;
    /** Indicates whether two-factor authentication is enabled for the user account. Does not apply to API authentication. */
    twoFactorAuthenticationEnabled?: boolean;
}
export type MembersUpdateRequestPoliciesItemAccess = "allow" | "deny";
export type MembersUpdateRequestPoliciesItemPermissionGroupsItem = MembersCreateRequestPoliciesItemPermissionGroupsItem;
export type MembersUpdateRequestPoliciesItemPermissionGroupsList = Array<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export type MembersUpdateRequestPoliciesItemResourceGroupsItem = MembersCreateRequestPoliciesItemPermissionGroupsItem;
export type MembersUpdateRequestPoliciesItemResourceGroupsList = Array<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export interface MembersUpdateRequestPoliciesItem {
    /** Policy identifier. */
    id?: string;
    /** Allow or deny operations against the resources. */
    access: MembersUpdateRequestPoliciesItemAccess | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: MembersUpdateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource groups that the policy applies to. */
    resourceGroups: MembersUpdateRequestPoliciesItemResourceGroupsList;
}
export type MembersUpdateRequestPoliciesList = Array<MembersUpdateRequestPoliciesItem>;
export interface UpdateMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Membership identifier tag. */
    memberId: string;
    /** Membership identifier tag. */
    id?: string;
    /** Roles assigned to this member. */
    roles?: MembersUpdateRequestRolesList;
    /** A member's status in the account. */
    status?: MembersUpdateRequestStatus | (string & {});
    /** Details of the user associated to the membership. */
    user?: MembersUpdateRequestUser;
    /** Array of policies associated with this member. */
    policies?: MembersUpdateRequestPoliciesList;
}
export type MembersUpdateResponsePoliciesItemAccess = "allow" | "deny";
export type MembersUpdateResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type MembersUpdateResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type MembersUpdateResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type MembersUpdateResponsePoliciesItemResourceGroupsItemScopeObjectsItem = MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem;
export type MembersUpdateResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem>;
export interface MembersUpdateResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: MembersUpdateResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export type MembersUpdateResponsePoliciesItemResourceGroupsItemMeta = MembersCreateResponsePoliciesItemResourceGroupsItemMeta;
export interface MembersUpdateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: MembersUpdateResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: MembersCreateResponsePoliciesItemResourceGroupsItemMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export type MembersUpdateResponsePoliciesItemResourceGroupsList = Array<MembersUpdateResponsePoliciesItemResourceGroupsItem>;
export interface MembersUpdateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: MembersUpdateResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: MembersUpdateResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: MembersUpdateResponsePoliciesItemResourceGroupsList | null;
}
export type MembersUpdateResponsePoliciesList = Array<MembersUpdateResponsePoliciesItem>;
export type MembersUpdateResponseRolesItemPermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsBilling = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsCachePurge = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsDns = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsDnsRecords = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsLb = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsLogs = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsOrganization = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsSsl = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsWaf = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsZoneSettings = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsZones = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissions = MembersCreateResponseRolesItemPermissions;
export type MembersUpdateResponseRolesItem = MembersCreateResponseRolesItem;
export type MembersUpdateResponseRolesList = Array<MembersCreateResponseRolesItem>;
export type MembersUpdateResponseStatus = "accepted" | "pending";
export type MembersUpdateResponseUser = MembersCreateResponseUser;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateMemberResponse {
    /** Membership identifier tag. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Access policy for the membership */
    policies?: MembersUpdateResponsePoliciesList | null;
    /** Roles assigned to this Member. */
    roles?: MembersUpdateResponseRolesList | null;
    /** A member's status in the account. */
    status?: MembersUpdateResponseStatus | null;
    /** Details of the user associated to the membership. */
    user?: MembersCreateResponseUser | null;
}
export type UpdatePaymentMethodRequestType = "CREDIT_CARD" | "PAYPAL" | "CASHAPP" | "SEPA_DEBIT" | "LINK" | "ACH_DIRECT_DEBIT";
export interface UpdatePaymentMethodRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    paymentMethodId: string;
    /** Billing address line 1. */
    address?: string;
    /** Billing address line 2. */
    address2?: string;
    /** Bank account type. */
    bankAccountType?: string;
    /** Bank code. */
    bankCode?: string;
    /** Bank country. */
    bankCountry?: string;
    /** Bank name for bank-based payment methods. */
    bankName?: string;
    /** Bank routing number. */
    bankRoutingNumber?: string;
    /** Cash App cash tag. */
    cashappCashTag?: string;
    /** Billing city. */
    city?: string;
    /** Billing country. */
    country?: string;
    /** Whether this is the default payment method. */
    default?: boolean;
    /** Device data for fraud prevention. */
    deviceData?: string;
    /** Billing first name. */
    firstName?: string;
    /** Billing last name. */
    lastName?: string;
    /** A nickname for the payment method. */
    nickName?: string;
    /** Email associated with the payment account. */
    paymentAccountEmail?: string;
    /** Payment email address. */
    paymentEmail?: string;
    /** The payment gateway used. */
    paymentGateway?: string;
    /** Payment nonce for tokenized payments. */
    paymentNonce?: string;
    /** Billing state. */
    state?: string;
    /** The payment method type. */
    type?: UpdatePaymentMethodRequestType | (string & {});
    /** Billing zip code. */
    zipcode?: string;
}
export type UpdatePaymentMethodResponseType = "CREDIT_CARD" | "PAYPAL" | "CASHAPP" | "SEPA_DEBIT" | "LINK" | "ACH_DIRECT_DEBIT";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdatePaymentMethodResponse {
    /** Payment method identifier. */
    id?: string | null;
    /** Billing address line 1. */
    address?: string | null;
    /** Billing address line 2. */
    address2?: string | null;
    /** Bank account type. */
    bankAccountType?: string | null;
    /** Bank code. */
    bankCode?: string | null;
    /** Bank country. */
    bankCountry?: string | null;
    /** Bank name for bank-based payment methods. */
    bankName?: string | null;
    /** Bank routing number. */
    bankRoutingNumber?: string | null;
    /** Cash App cash tag. */
    cashappCashTag?: string | null;
    /** Billing city. */
    city?: string | null;
    /** Billing country. */
    country?: string | null;
    /** Whether this is the default payment method. */
    default?: boolean | null;
    /** Device data for fraud prevention. */
    deviceData?: string | null;
    /** Card expiration date. */
    expirationDate?: string | null;
    /** Billing first name. */
    firstName?: string | null;
    /** Last four digits of the card number. */
    lastFour?: string | null;
    /** Billing last name. */
    lastName?: string | null;
    /** A nickname for the payment method. */
    nickName?: string | null;
    /** Email associated with the payment account. */
    paymentAccountEmail?: string | null;
    /** Payment email address. */
    paymentEmail?: string | null;
    /** The payment gateway used. */
    paymentGateway?: string | null;
    /** Payment nonce for tokenized payments. */
    paymentNonce?: string | null;
    /** Billing state. */
    state?: string | null;
    /** The payment method type. */
    type?: UpdatePaymentMethodResponseType | null;
    /** Billing zip code. */
    zipcode?: string | null;
}
export type SubscriptionsUpdateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsUpdateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsUpdateRequestRatePlanSetsList = Array<string>;
export interface SubscriptionsUpdateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateRequestRatePlanId | (string & {});
    /** The currency applied to the rate plan subscription. */
    currency?: string;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean;
    /** The full name of the rate plan. */
    publicName?: string;
    /** The scope that this rate plan applies to. */
    scope?: string;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateRequestRatePlanSetsList;
}
export interface UpdateSubscriptionRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateRequestFrequency | (string & {});
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateRequestRatePlan;
}
export type SubscriptionsUpdateResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsUpdateResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsUpdateResponseRatePlanSetsList = Array<string>;
export interface SubscriptionsUpdateResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateResponseRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateResponseRatePlanSetsList | null;
}
export type SubscriptionsUpdateResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSubscriptionResponse {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateResponseFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateResponseRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsUpdateResponseState | null;
}
export type TokensUpdateRequestPoliciesItemEffect = "allow" | "deny";
export type TokensUpdateRequestPoliciesItemPermissionGroupsItemMeta = TokensCreateRequestPoliciesItemPermissionGroupsItemMeta;
export type TokensUpdateRequestPoliciesItemPermissionGroupsItem = TokensCreateRequestPoliciesItemPermissionGroupsItem;
export type TokensUpdateRequestPoliciesItemPermissionGroupsList = Array<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export type TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensUpdateRequestPoliciesItemResourcesValue = string | TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensUpdateRequestPoliciesItemResourcesMap = {
    [key: string]: TokensUpdateRequestPoliciesItemResourcesValue | undefined;
};
export interface TokensUpdateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    effect: TokensUpdateRequestPoliciesItemEffect | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensUpdateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensUpdateRequestPoliciesItemResourcesMap;
}
export type TokensUpdateRequestPoliciesList = Array<TokensUpdateRequestPoliciesItem>;
export type TokensUpdateRequestConditionRequestIpInList = Array<string>;
export type TokensUpdateRequestConditionRequestIpNotInList = Array<string>;
export interface TokensUpdateRequestConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensUpdateRequestConditionRequestIpInList;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensUpdateRequestConditionRequestIpNotInList;
}
export interface TokensUpdateRequestCondition {
    /** Client IP restrictions. */
    requestIp?: TokensUpdateRequestConditionRequestIp;
}
export type TokensUpdateRequestStatus = "active" | "disabled" | "expired";
export interface UpdateTokenRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token identifier tag. */
    tokenId: string;
    /** Token name. */
    name: string;
    /** List of access policies assigned to the token. */
    policies: TokensUpdateRequestPoliciesList;
    condition?: TokensUpdateRequestCondition;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string;
    /** Status of the token. */
    status?: TokensUpdateRequestStatus | (string & {});
}
export type TokensUpdateResponseConditionRequestIpInList = Array<string>;
export type TokensUpdateResponseConditionRequestIpNotInList = Array<string>;
export interface TokensUpdateResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensUpdateResponseConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensUpdateResponseConditionRequestIpNotInList | null;
}
export interface TokensUpdateResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensUpdateResponseConditionRequestIp | null;
}
export type TokensUpdateResponsePoliciesItemEffect = "allow" | "deny";
export type TokensUpdateResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensUpdateResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensUpdateResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensUpdateResponsePoliciesItemResourcesValue = string | TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensUpdateResponsePoliciesItemResourcesMap = {
    [key: string]: TokensUpdateResponsePoliciesItemResourcesValue | undefined;
};
export interface TokensUpdateResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensUpdateResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensUpdateResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensUpdateResponsePoliciesItemResourcesMap;
}
export type TokensUpdateResponsePoliciesList = Array<TokensUpdateResponsePoliciesItem>;
export type TokensUpdateResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTokenResponse {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensUpdateResponseCondition | null;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensUpdateResponsePoliciesList | null;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null;
    /** Status of the token. */
    status?: TokensUpdateResponseStatus | null;
}
export interface VerifyTokenRequest {
    /** Account identifier tag. */
    accountId: string;
}
export type TokensVerifyResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface VerifyTokenResponse {
    /** Token identifier tag. */
    id: string;
    /** Status of the token. */
    status: TokensVerifyResponseStatus;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
}
export type CreateAccountError = AccountCreationForbidden | MissingName | CloudflareOpError;
/** Create an Account. To create the Account within an Organization, provide `unit.id` and omit `standalone`. To create a standalone Free Account, provide `standalone: true` and omit `unit`. Providing both fields is invalid. If you omit both fields, Cloudflare can determine the destination only when the User is an administrator of exactly one Organization. Cloudflare creates the Account in that Organization; otherwise, the request returns an error. */
export declare const createAccount: API.OperationMethod<CreateAccountRequest, CreateAccountResponse, CreateAccountError, CloudflareOpContext>;
export type CreateAccountOrganizationError = CloudflareOpError;
/** Move an account into a destination organization, either assigning a standalone account to an organization or moving it between organizations in the same hierarchy. Availability depends on the organization's capabilities. */
export declare const createAccountOrganization: API.OperationMethod<CreateAccountOrganizationRequest, CreateAccountOrganizationResponse, CreateAccountOrganizationError, CloudflareOpContext>;
export type CreateClientSecretError = CloudflareOpError;
/** Creates a Stripe setup intent for adding a payment method to an account. Returns a client secret for frontend payment method collection. */
export declare const createClientSecret: API.OperationMethod<CreateClientSecretRequest, CreateClientSecretResponse, CreateClientSecretError, CloudflareOpContext>;
export type CreateMemberError = InvalidRoute | ValidationError | AccountMemberAlreadyExists | CloudflareOpError;
/** Add a user to the list of members for this account. */
export declare const createMember: API.OperationMethod<CreateMemberRequest, CreateMemberResponse, CreateMemberError, CloudflareOpContext>;
export type CreatePayBadDebtError = CloudflareOpError;
/** Pays outstanding bad debt for an account. Discovers all debt automatically and handles invoice deduplication. */
export declare const createPayBadDebt: API.OperationMethod<CreatePayBadDebtRequest, CreatePayBadDebtResponse, CreatePayBadDebtError, CloudflareOpContext>;
export type CreatePayInvoiceError = CloudflareOpError;
/** Pays an outstanding invoice for an account. Returns a Stripe client secret when Strong Customer Authentication (SCA) is required to complete the payment. */
export declare const createPayInvoice: API.OperationMethod<CreatePayInvoiceRequest, CreatePayInvoiceResponse, CreatePayInvoiceError, CloudflareOpContext>;
export type CreatePaymentMethodError = CloudflareOpError;
/** Creates a new payment method for an account. */
export declare const createPaymentMethod: API.OperationMethod<CreatePaymentMethodRequest, CreatePaymentMethodResponse, CreatePaymentMethodError, CloudflareOpContext>;
export type CreateSubscriptionError = JsonDecodeFailure | InvalidRoute | CloudflareOpError;
/** Creates an account or zone subscription. */
export declare const createSubscription: API.OperationMethod<CreateSubscriptionRequest, CreateSubscriptionResponse, CreateSubscriptionError, CloudflareOpContext>;
export type CreateTokenError = InvalidRoute | InvalidTokenName | PermissionGroupNotFound | CloudflareOpError;
/** Create a new Account Owned API token. */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type DeleteAccountError = InvalidRoute | MethodNotAllowed | CloudflareOpError;
/** Delete a specific account (only available for tenant admins at this time). This is a permanent operation that will delete any zones or other resources under the account */
export declare const deleteAccount: API.OperationMethod<DeleteAccountRequest, DeleteAccountResponse, DeleteAccountError, CloudflareOpContext>;
export type DeleteMemberError = MemberNotFound | InvalidRoute | CloudflareOpError;
/** Remove a member from an account. */
export declare const deleteMember: API.OperationMethod<DeleteMemberRequest, DeleteMemberResponse, DeleteMemberError, CloudflareOpContext>;
export type DeletePaymentMethodError = CloudflareOpError;
/** Deletes a payment method from an account. */
export declare const deletePaymentMethod: API.OperationMethod<DeletePaymentMethodRequest, DeletePaymentMethodResponse, DeletePaymentMethodError, CloudflareOpContext>;
export type DeleteSubscriptionError = InvalidRoute | EndpointNotFound | CloudflareOpError;
/** Deletes an account's subscription. */
export declare const deleteSubscription: API.OperationMethod<DeleteSubscriptionRequest, DeleteSubscriptionResponse, DeleteSubscriptionError, CloudflareOpContext>;
export type DeleteTokenError = InvalidRoute | MethodNotAllowed | TokenNotFound | TokenManagedByCloudflare | CloudflareOpError;
/** Destroy an Account Owned API token. */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, CloudflareOpContext>;
export type EditInvoiceError = CloudflareOpError;
/** Toggles PDF invoice generation for an account. */
export declare const editInvoice: API.OperationMethod<EditInvoiceRequest, EditInvoiceResponse, EditInvoiceError, CloudflareOpContext>;
export type GetAccountError = InvalidRoute | CloudflareOpError;
/** Get information about a specific account that you are a member of. */
export declare const getAccount: API.OperationMethod<GetAccountRequest, GetAccountResponse, GetAccountError, CloudflareOpContext>;
export type GetAccountProfileError = CloudflareOpError;
/** Retrieves the business profile (name, email, phone, address, and external metadata) associated with this account's parent organization customer record. Profiles can be shared across accounts and organizations. Only available to members of an organization that contains the account. */
export declare const getAccountProfile: API.OperationMethod<GetAccountProfileRequest, GetAccountProfileResponse, GetAccountProfileError, CloudflareOpContext>;
export type GetMemberError = MemberNotFound | InvalidRoute | CloudflareOpError;
/** Get information about a specific member of an account. */
export declare const getMember: API.OperationMethod<GetMemberRequest, GetMemberResponse, GetMemberError, CloudflareOpContext>;
export type GetPaymentMethodError = CloudflareOpError;
/** Gets a specific payment method for an account. */
export declare const getPaymentMethod: API.OperationMethod<GetPaymentMethodRequest, GetPaymentMethodResponse, GetPaymentMethodError, CloudflareOpContext>;
export type GetRoleError = InvalidRoute | CloudflareOpError;
/** Get information about a specific role for an account. */
export declare const getRole: API.OperationMethod<GetRoleRequest, GetRoleResponse, GetRoleError, CloudflareOpContext>;
export type GetSpeedSettingsTransformationError = CloudflareOpError;
/** Returns a list of Image Resizing configurations across all zones for the account. This endpoint is useful for retrieving the transformations (image_resizing) state for all zones belonging to an account. */
export declare const getSpeedSettingsTransformation: API.OperationMethod<GetSpeedSettingsTransformationRequest, GetSpeedSettingsTransformationResponse, GetSpeedSettingsTransformationError, CloudflareOpContext>;
export type GetSubscriptionError = CloudflareOpError;
/** Lists all of an account or zone's subscriptions. */
export declare const getSubscription: API.PaginatedOperationMethod<GetSubscriptionRequest, GetSubscriptionResponse, GetSubscriptionError, CloudflareOpContext, SubscriptionsGetResultItem>;
export type GetTokenError = InvalidRoute | TokenNotFound | CloudflareOpError;
/** Get information about a specific Account Owned API token. */
export declare const getToken: API.OperationMethod<GetTokenRequest, GetTokenResponse, GetTokenError, CloudflareOpContext>;
export type GetTokenPermissionGroupError = InvalidRoute | CloudflareOpError;
/** Find all available permission groups for Account Owned API Tokens. Each permission group indicates whether the caller can select it when creating a token. Token creation performs the authoritative permission check. */
export declare const getTokenPermissionGroup: API.OperationMethod<GetTokenPermissionGroupRequest, GetTokenPermissionGroupResponse, GetTokenPermissionGroupError, CloudflareOpContext>;
export type ListAccountsError = CloudflareOpError;
/** List all accounts you have ownership or verified access to. */
export declare const listAccounts: API.PaginatedOperationMethod<ListAccountsRequest, ListAccountsResponse, ListAccountsError, CloudflareOpContext, ListResultItem>;
export type ListEntitlementsError = CloudflareOpError;
/** Returns the list of entitlements (features and their allocations) for a given account. Each entitlement describes a product feature the account is permitted to use and the allocation value (boolean, count, range, enum, or string) that governs its behaviour. */
export declare const listEntitlements: API.OperationMethod<ListEntitlementsRequest, ListEntitlementsResponse, ListEntitlementsError, CloudflareOpContext>;
export type ListLogAuditsError = CloudflareOpError;
/** Gets a list of audit logs for an account. */
export declare const listLogAudits: API.PaginatedOperationMethod<ListLogAuditsRequest, ListLogAuditsResponse, ListLogAuditsError, CloudflareOpContext, LogsAuditListResultItem>;
export type ListMembersError = CloudflareOpError;
/** List all members of an account. */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersRequest, ListMembersResponse, ListMembersError, CloudflareOpContext, MembersListResultItem>;
export type ListPaymentMethodsError = CloudflareOpError;
/** Lists all payment methods for an account. */
export declare const listPaymentMethods: API.OperationMethod<ListPaymentMethodsRequest, ListPaymentMethodsResponse, ListPaymentMethodsError, CloudflareOpContext>;
export type ListRolesError = CloudflareOpError;
/** Get all available roles for an account. */
export declare const listRoles: API.PaginatedOperationMethod<ListRolesRequest, ListRolesResponse, ListRolesError, CloudflareOpContext, MembersCreateResponseRolesItem>;
export type ListTokensError = CloudflareOpError;
/** List Account Owned API tokens created for this account. Callers with `com.cloudflare.api.account.token.list_self` permission only receive tokens they created. Results include active, disabled, and recently-expired tokens when `include_expired` is set to true. */
export declare const listTokens: API.PaginatedOperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, CloudflareOpContext, TokensListResultItem>;
export type ListTokensPermissionGroupsError = InvalidRoute | CloudflareOpError;
/** Find all available permission groups for Account Owned API Tokens. Each permission group indicates whether the caller can select it when creating a token. Token creation performs the authoritative permission check. */
export declare const listTokensPermissionGroups: API.OperationMethod<ListTokensPermissionGroupsRequest, ListTokensPermissionGroupsResponse, ListTokensPermissionGroupsError, CloudflareOpContext>;
export type LogsAuditHistoryError = CloudflareOpError;
/** Returns the chronological change history for the resource identified by the given audit log entry. The endpoint first locates the source audit log entry by `id` (using `action_time` to narrow the lookup window), derives identifying filters from that entry, and then returns matching audit logs within the `since`/`before` window. The `result_info.history_status` field indicates the quality of the resource identification used: - `exact`: Resource was identified by the resource URI. - `approximate`: Resource was identified without the resource URI. - `unavailable`: The source audit log entry did not contain enough information to identify the resource; an empty result is returned. */
export declare const logsAuditHistory: API.OperationMethod<LogsAuditHistoryRequest, LogsAuditHistoryResponse, LogsAuditHistoryError, CloudflareOpContext>;
export type LogsAuditProductCategoriesError = CloudflareOpError;
/** Lists the available audit log product categories and the resource products each one expands to. Use these values with the product_category filter on the account audit logs endpoint. */
export declare const logsAuditProductCategories: API.OperationMethod<LogsAuditProductCategoriesRequest, LogsAuditProductCategoriesResponse, LogsAuditProductCategoriesError, CloudflareOpContext>;
export type PaymentMethodsSetAsDefaultError = CloudflareOpError;
/** Sets a payment method as the default for an account. */
export declare const paymentMethodsSetAsDefault: API.OperationMethod<PaymentMethodsSetAsDefaultRequest, PaymentMethodsSetAsDefaultResponse, PaymentMethodsSetAsDefaultError, CloudflareOpContext>;
export type PutTokenValueError = InvalidRoute | TokenNotFound | CloudflareOpError;
/** Roll the Account Owned API token secret. */
export declare const putTokenValue: API.OperationMethod<PutTokenValueRequest, PutTokenValueResponse, PutTokenValueError, CloudflareOpContext>;
export type ReceiptsPdfError = CloudflareOpError;
/** Downloads a receipt as a PDF document. */
export declare const receiptsPdf: API.OperationMethod<ReceiptsPdfRequest, ReceiptsPdfResponse, ReceiptsPdfError, CloudflareOpContext>;
export type SubscriptionsActionsAppendError = CloudflareOpError;
/** Smartly applies the incoming subscription into the lifecycle of the subscription. */
export declare const subscriptionsActionsAppend: API.OperationMethod<SubscriptionsActionsAppendRequest, SubscriptionsActionsAppendResponse, SubscriptionsActionsAppendError, CloudflareOpContext>;
export type SubscriptionsBulkCreateError = CloudflareOpError;
/** Creates multiple subscriptions for an account in a single request. */
export declare const subscriptionsBulkCreate: API.OperationMethod<SubscriptionsBulkCreateRequest, SubscriptionsBulkCreateResponse, SubscriptionsBulkCreateError, CloudflareOpContext>;
export type SubscriptionsCancelDowngradeError = CloudflareOpError;
/** Cancels pending delayed downgrades for the specified subscriptions. */
export declare const subscriptionsCancelDowngrade: API.OperationMethod<SubscriptionsCancelDowngradeRequest, SubscriptionsCancelDowngradeResponse, SubscriptionsCancelDowngradeError, CloudflareOpContext>;
export type SubscriptionsCancelReasonCreateError = CloudflareOpError;
/** Records a cancellation reason for an account subscription. */
export declare const subscriptionsCancelReasonCreate: API.OperationMethod<SubscriptionsCancelReasonCreateRequest, SubscriptionsCancelReasonCreateResponse, SubscriptionsCancelReasonCreateError, CloudflareOpContext>;
export type SubscriptionsCancelReasonGetError = CloudflareOpError;
/** Gets the cancellation reason for an account subscription. */
export declare const subscriptionsCancelReasonGet: API.OperationMethod<SubscriptionsCancelReasonGetRequest, SubscriptionsCancelReasonGetResponse, SubscriptionsCancelReasonGetError, CloudflareOpContext>;
export type SubscriptionsGetByIdentifierError = CloudflareOpError;
/** Gets an account subscription by identifier. */
export declare const subscriptionsGetByIdentifier: API.OperationMethod<SubscriptionsGetByIdentifierRequest, SubscriptionsGetByIdentifierResponse, SubscriptionsGetByIdentifierError, CloudflareOpContext>;
export type UpdateAccountError = InvalidAccountName | AccountNameTooLong | UpdateAccountTypeNotSupported | InvalidRoute | MethodNotAllowed | CloudflareOpError;
/** Update an existing account. */
export declare const updateAccount: API.OperationMethod<UpdateAccountRequest, UpdateAccountResponse, UpdateAccountError, CloudflareOpContext>;
export type UpdateAccountProfileError = CloudflareOpError;
/** Updates the business profile (name, email, phone, address, and external metadata) associated with this account's parent organization customer record. Changes apply to every account and organization sharing that profile. Omitted or empty fields are left unchanged. Only available to members of an organization that contains the account. */
export declare const updateAccountProfile: API.OperationMethod<UpdateAccountProfileRequest, UpdateAccountProfileResponse, UpdateAccountProfileError, CloudflareOpContext>;
export type UpdateMemberError = MemberNotFound | InvalidRoute | BadRequest | MethodNotAllowed | CloudflareOpError;
/** Modify an account member. */
export declare const updateMember: API.OperationMethod<UpdateMemberRequest, UpdateMemberResponse, UpdateMemberError, CloudflareOpContext>;
export type UpdatePaymentMethodError = CloudflareOpError;
/** Updates a payment method for an account. */
export declare const updatePaymentMethod: API.OperationMethod<UpdatePaymentMethodRequest, UpdatePaymentMethodResponse, UpdatePaymentMethodError, CloudflareOpContext>;
export type UpdateSubscriptionError = JsonDecodeFailure | InvalidRoute | EndpointNotFound | CloudflareOpError;
/** Updates an account subscription. */
export declare const updateSubscription: API.OperationMethod<UpdateSubscriptionRequest, UpdateSubscriptionResponse, UpdateSubscriptionError, CloudflareOpContext>;
export type UpdateTokenError = InvalidRoute | MethodNotAllowed | TokenNotFound | PermissionGroupNotFound | CloudflareOpError;
/** Update an existing token. */
export declare const updateToken: API.OperationMethod<UpdateTokenRequest, UpdateTokenResponse, UpdateTokenError, CloudflareOpContext>;
export type VerifyTokenError = MissingAuthenticationToken | InvalidRoute | CloudflareOpError;
/** Test whether a token works. */
export declare const verifyToken: API.OperationMethod<VerifyTokenRequest, VerifyTokenResponse, VerifyTokenError, CloudflareOpContext>;
export declare const listTokenPermissionGroups: API.OperationMethod<GetTokenPermissionGroupRequest, TokensPermissionGroupsGetResultList, GetTokenPermissionGroupError, CloudflareOpContext>;
export type ListTokenPermissionGroupsRequest = GetTokenPermissionGroupRequest;
export type ListTokenPermissionGroupsResponse = GetTokenPermissionGroupResponse;
export type ListTokenPermissionGroupsError = GetTokenPermissionGroupError;
//# sourceMappingURL=accounts.d.ts.map