import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CreateAssetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** A short description of the custom asset. */
    description: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    name: string;
    /** The URL where the asset content is fetched from. */
    url: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAssetResponse {
    /** A short description of the custom asset. */
    description?: string | null;
    lastUpdated?: string | null;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    name?: string | null;
    /** The size of the asset content in bytes. */
    sizeBytes?: number | null;
    /** The URL where the asset content is fetched from. */
    url?: string | null;
}
export interface CreateAssetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** A short description of the custom asset. */
    description: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    name: string;
    /** The URL where the asset content is fetched from. */
    url: string;
}
export interface DeleteAssetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    assetName: string;
}
export interface DeleteAssetForAccountResponse {
}
export interface DeleteAssetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    assetName: string;
}
export interface DeleteAssetForZoneResponse {
}
export interface GetAssetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    assetName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAssetResponse {
    /** A short description of the custom asset. */
    description?: string | null;
    lastUpdated?: string | null;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    name?: string | null;
    /** The size of the asset content in bytes. */
    sizeBytes?: number | null;
    /** The URL where the asset content is fetched from. */
    url?: string | null;
}
export interface GetAssetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    assetName: string;
}
export type GetRequestIdentifier = "1000_errors" | "500_errors" | "basic_challenge" | "country_challenge" | "ip_block" | "managed_challenge" | "ratelimit_block" | "under_attack" | "waf_block" | "waf_challenge";
export interface GetCustomPageForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Custom page type. */
    identifier: GetRequestIdentifier | (string & {});
}
export type GetResponseRequiredTokensList = Array<string>;
export type GetResponseState = "default" | "customized";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCustomPageResponse {
    id?: string | null;
    createdOn?: string | null;
    description?: string | null;
    modifiedOn?: string | null;
    previewTarget?: string | null;
    requiredTokens?: GetResponseRequiredTokensList | null;
    /** The custom page state. */
    state?: GetResponseState | null;
    /** The URL associated with the custom page. */
    url?: string | null;
}
export interface GetCustomPageForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Custom page type. */
    identifier: GetRequestIdentifier | (string & {});
}
export interface ListAssetsForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of custom assets per page. */
    perPage?: number;
}
export interface AssetsListResultItem {
    /** A short description of the custom asset. */
    description?: string | null;
    lastUpdated?: string | null;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    name?: string | null;
    /** The size of the asset content in bytes. */
    sizeBytes?: number | null;
    /** The URL where the asset content is fetched from. */
    url?: string | null;
}
export type AssetsListResultList = Array<AssetsListResultItem>;
export interface ListAssetsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AssetsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListAssetsForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of custom assets per page. */
    perPage?: number;
}
export interface ListCustomPagesForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
}
export type ListResultItemRequiredTokensList = Array<string>;
export type ListResultItemState = "default" | "customized";
export interface ListResultItem {
    id?: string | null;
    createdOn?: string | null;
    description?: string | null;
    modifiedOn?: string | null;
    previewTarget?: string | null;
    requiredTokens?: ListResultItemRequiredTokensList | null;
    /** The custom page state. */
    state?: ListResultItemState | null;
    /** The URL associated with the custom page. */
    url?: string | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListCustomPagesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListCustomPagesForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
}
export type UpdateRequestIdentifier = "1000_errors" | "500_errors" | "basic_challenge" | "country_challenge" | "ip_block" | "managed_challenge" | "ratelimit_block" | "under_attack" | "waf_block" | "waf_challenge";
export type UpdateRequestState = "default" | "customized";
export interface PutCustomPageForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Custom page type. */
    identifier: UpdateRequestIdentifier | (string & {});
    /** The custom page state. */
    state: UpdateRequestState | (string & {});
    /** The URL associated with the custom page. */
    url: string;
}
export type UpdateResponseRequiredTokensList = Array<string>;
export type UpdateResponseState = "default" | "customized";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutCustomPageResponse {
    id?: string | null;
    createdOn?: string | null;
    description?: string | null;
    modifiedOn?: string | null;
    previewTarget?: string | null;
    requiredTokens?: UpdateResponseRequiredTokensList | null;
    /** The custom page state. */
    state?: UpdateResponseState | null;
    /** The URL associated with the custom page. */
    url?: string | null;
}
export interface PutCustomPageForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Custom page type. */
    identifier: UpdateRequestIdentifier | (string & {});
    /** The custom page state. */
    state: UpdateRequestState | (string & {});
    /** The URL associated with the custom page. */
    url: string;
}
export interface UpdateAssetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    assetName: string;
    /** A short description of the custom asset. */
    description: string;
    /** The URL where the asset content is fetched from. */
    url: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAssetResponse {
    /** A short description of the custom asset. */
    description?: string | null;
    lastUpdated?: string | null;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    name?: string | null;
    /** The size of the asset content in bytes. */
    sizeBytes?: number | null;
    /** The URL where the asset content is fetched from. */
    url?: string | null;
}
export interface UpdateAssetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    assetName: string;
    /** A short description of the custom asset. */
    description: string;
    /** The URL where the asset content is fetched from. */
    url: string;
}
export type CreateAssetForAccountError = CloudflareOpError;
/** Creates a custom asset for an account or zone. */
export declare const createAssetForAccount: API.OperationMethod<CreateAssetForAccountRequest, CreateAssetResponse, CreateAssetForAccountError, CloudflareOpContext>;
export type CreateAssetForZoneError = CloudflareOpError;
/** Creates a custom asset for an account or zone. */
export declare const createAssetForZone: API.OperationMethod<CreateAssetForZoneRequest, CreateAssetResponse, CreateAssetForZoneError, CloudflareOpContext>;
export type DeleteAssetForAccountError = CloudflareOpError;
/** Deletes a custom asset from an account or zone. */
export declare const deleteAssetForAccount: API.OperationMethod<DeleteAssetForAccountRequest, DeleteAssetForAccountResponse, DeleteAssetForAccountError, CloudflareOpContext>;
export type DeleteAssetForZoneError = CloudflareOpError;
/** Deletes a custom asset from an account or zone. */
export declare const deleteAssetForZone: API.OperationMethod<DeleteAssetForZoneRequest, DeleteAssetForZoneResponse, DeleteAssetForZoneError, CloudflareOpContext>;
export type GetAssetForAccountError = CloudflareOpError;
/** Returns a custom asset for an account or zone. */
export declare const getAssetForAccount: API.OperationMethod<GetAssetForAccountRequest, GetAssetResponse, GetAssetForAccountError, CloudflareOpContext>;
export type GetAssetForZoneError = CloudflareOpError;
/** Returns a custom asset for an account or zone. */
export declare const getAssetForZone: API.OperationMethod<GetAssetForZoneRequest, GetAssetResponse, GetAssetForZoneError, CloudflareOpContext>;
export type GetCustomPageForAccountError = CloudflareOpError;
/** Returns the configuration for a custom page type. */
export declare const getCustomPageForAccount: API.OperationMethod<GetCustomPageForAccountRequest, GetCustomPageResponse, GetCustomPageForAccountError, CloudflareOpContext>;
export type GetCustomPageForZoneError = CloudflareOpError;
/** Returns the configuration for a custom page type. */
export declare const getCustomPageForZone: API.OperationMethod<GetCustomPageForZoneRequest, GetCustomPageResponse, GetCustomPageForZoneError, CloudflareOpContext>;
export type ListAssetsForAccountError = CloudflareOpError;
/** Lists custom assets for an account or zone. */
export declare const listAssetsForAccount: API.PaginatedOperationMethod<ListAssetsForAccountRequest, ListAssetsResponse, ListAssetsForAccountError, CloudflareOpContext, AssetsListResultItem>;
export type ListAssetsForZoneError = CloudflareOpError;
/** Lists custom assets for an account or zone. */
export declare const listAssetsForZone: API.PaginatedOperationMethod<ListAssetsForZoneRequest, ListAssetsResponse, ListAssetsForZoneError, CloudflareOpContext, AssetsListResultItem>;
export type ListCustomPagesForAccountError = CloudflareOpError;
/** Lists all custom page configurations for an account or zone. */
export declare const listCustomPagesForAccount: API.PaginatedOperationMethod<ListCustomPagesForAccountRequest, ListCustomPagesResponse, ListCustomPagesForAccountError, CloudflareOpContext, ListResultItem>;
export type ListCustomPagesForZoneError = CloudflareOpError;
/** Lists all custom page configurations for an account or zone. */
export declare const listCustomPagesForZone: API.PaginatedOperationMethod<ListCustomPagesForZoneRequest, ListCustomPagesResponse, ListCustomPagesForZoneError, CloudflareOpContext, ListResultItem>;
export type PutCustomPageForAccountError = CloudflareOpError;
/** Updates the configuration for a custom page type. */
export declare const putCustomPageForAccount: API.OperationMethod<PutCustomPageForAccountRequest, PutCustomPageResponse, PutCustomPageForAccountError, CloudflareOpContext>;
export type PutCustomPageForZoneError = CloudflareOpError;
/** Updates the configuration for a custom page type. */
export declare const putCustomPageForZone: API.OperationMethod<PutCustomPageForZoneRequest, PutCustomPageResponse, PutCustomPageForZoneError, CloudflareOpContext>;
export type UpdateAssetForAccountError = CloudflareOpError;
/** Updates a custom asset for an account or zone. */
export declare const updateAssetForAccount: API.OperationMethod<UpdateAssetForAccountRequest, UpdateAssetResponse, UpdateAssetForAccountError, CloudflareOpContext>;
export type UpdateAssetForZoneError = CloudflareOpError;
/** Updates a custom asset for an account or zone. */
export declare const updateAssetForZone: API.OperationMethod<UpdateAssetForZoneRequest, UpdateAssetResponse, UpdateAssetForZoneError, CloudflareOpContext>;
//# sourceMappingURL=custom_pages.d.ts.map