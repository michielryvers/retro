import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CustomCertificateNotFound_base: S.TaggedErrorClass<"CustomCertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CustomCertificateNotFound extends /*@__PURE__*/ CustomCertificateNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const PlanLevelNotAllowed_base: S.TaggedErrorClass<"PlanLevelNotAllowed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PlanLevelNotAllowed extends /*@__PURE__*/ PlanLevelNotAllowed_base {
}
declare const ZoneNotFound_base: S.TaggedErrorClass<"ZoneNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ZoneNotFound extends /*@__PURE__*/ ZoneNotFound_base {
}
export type CreateRequestBundleMethod = "ubiquitous" | "optimal" | "force";
export type CreateRequestDeploy = "staging" | "production";
export type CreateRequestGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export interface CreateRequestGeoRestrictions {
    label?: CreateRequestGeoRestrictionsLabel | (string & {});
}
export type CreateRequestType = "legacy_custom" | "sni_custom";
export interface CreateCustomCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** The zone's SSL certificate or certificate and the intermediate(s). */
    certificate: string;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: CreateRequestBundleMethod | (string & {});
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string;
    /** The environment to deploy the certificate to, defaults to production. */
    deploy?: CreateRequestDeploy | (string & {});
    /** Specify the region where your private key can be held locally for optimal TLS performance. HTTPS connections to any excluded data center will still be fully encrypted, but will incur some latency while Keyless SSL is used to complete the handshake with the nearest allowed data center. Options allow distribution to only to U.S. data centers, only to E.U. data centers, or only to highest security data centers. Default distribution is to all Cloudflare datacenters, for optimal performance. */
    geoRestrictions?: CreateRequestGeoRestrictions;
    /** Specify the policy that determines the region where your private key will be held locally. HTTPS connections to any excluded data center will still be fully encrypted, but will incur some latency while Keyless SSL is used to complete the handshake with the nearest allowed data center. Any combination of countries, specified by their two letter country code (https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2#Officially_assigned_code_elements) can be chosen, such as 'country: IN', as well as 'region: EU' which refers to the EU region. If there are too few data centers satisfying the policy, it will be rejected. Note: The API accepts this field as either "policy" or "policy_restrictions" in requests. Responses return this field as "policy_restrictions". */
    policy?: string;
    /** The zone's private key. Not required if custom_csr_id is provided, in which case the private key is retrieved from the CSR record held by Cloudflare. */
    privateKey?: string;
    /** The type 'legacy_custom' enables support for legacy clients which do not include SNI in the TLS handshake. */
    type?: CreateRequestType | (string & {});
}
export type CreateResponseBundleMethod = "ubiquitous" | "optimal" | "force";
export type CreateResponseGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export interface CreateResponseGeoRestrictions {
    label?: CreateResponseGeoRestrictionsLabel | null;
}
export type CreateResponseHostsList = Array<string>;
export type CreateResponseKeylessServerPermissionsList = Array<string>;
export type CreateResponseKeylessServerStatus = "active" | "deleted";
export interface CreateResponseKeylessServerTunnel {
    /** Private IP of the Key Server Host. */
    privateIp: string;
    /** Cloudflare Tunnel Virtual Network ID. */
    vnetId: string;
}
export interface CreateResponseKeylessServer {
    /** Keyless certificate identifier tag. */
    id: string;
    /** When the Keyless SSL was created. */
    createdOn: string;
    /** Whether or not the Keyless SSL is on or off. */
    enabled: boolean;
    /** The keyless SSL name. */
    host: string;
    /** When the Keyless SSL was last modified. */
    modifiedOn: string;
    /** The keyless SSL name. */
    name: string;
    /** Available permissions for the Keyless SSL for the current user requesting the item. */
    permissions: CreateResponseKeylessServerPermissionsList;
    /** The keyless SSL port used to communicate between Cloudflare and the client's Keyless SSL server. */
    port: number;
    /** Status of the Keyless SSL. */
    status: CreateResponseKeylessServerStatus;
    /** Configuration for using Keyless SSL through a Cloudflare Tunnel. */
    tunnel?: CreateResponseKeylessServerTunnel | null;
}
export type CreateResponseStatus = "active" | "expired" | "deleted" | "pending" | "initializing";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCustomCertificateResponse {
    /** Custom certificate identifier tag. */
    id: string;
    /** Identifier. */
    zoneId: string;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: CreateResponseBundleMethod | null;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string | null;
    /** When the certificate from the authority expires. */
    expiresOn?: string | null;
    /** Specify the region where your private key can be held locally for optimal TLS performance. HTTPS connections to any excluded data center will still be fully encrypted, but will incur some latency while Keyless SSL is used to complete the handshake with the nearest allowed data center. Options allow distribution to only to U.S. data centers, only to E.U. data centers, or only to highest security data centers. Default distribution is to all Cloudflare datacenters, for optimal performance. */
    geoRestrictions?: CreateResponseGeoRestrictions | null;
    hosts?: CreateResponseHostsList | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    keylessServer?: CreateResponseKeylessServer | null;
    /** When the certificate was last modified. */
    modifiedOn?: string | null;
    /** The policy restrictions returned by the API. This field is returned in responses when a policy has been set. The API accepts the "policy" field in requests but returns this field as "policy_restrictions" in responses. */
    policyRestrictions?: string | null;
    /** The order/priority in which the certificate will be used in a request. The higher priority will break ties across overlapping 'legacy_custom' certificates, but 'legacy_custom' certificates will always supercede 'sni_custom' certificates. */
    priority?: number | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the zone's custom SSL. */
    status?: CreateResponseStatus | null;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn?: string | null;
}
export interface DeleteCustomCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Custom certificate identifier tag. */
    customCertificateId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCustomCertificateResponse {
    /** Custom certificate identifier tag. */
    id?: string | null;
}
export interface GetCustomCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Custom certificate identifier tag. */
    customCertificateId: string;
}
export type GetResponseBundleMethod = "ubiquitous" | "optimal" | "force";
export type GetResponseGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export interface GetResponseGeoRestrictions {
    label?: GetResponseGeoRestrictionsLabel | null;
}
export type GetResponseHostsList = Array<string>;
export type GetResponseKeylessServerPermissionsList = Array<string>;
export type GetResponseKeylessServerStatus = "active" | "deleted";
export type GetResponseKeylessServerTunnel = CreateResponseKeylessServerTunnel;
export interface GetResponseKeylessServer {
    /** Keyless certificate identifier tag. */
    id: string;
    /** When the Keyless SSL was created. */
    createdOn: string;
    /** Whether or not the Keyless SSL is on or off. */
    enabled: boolean;
    /** The keyless SSL name. */
    host: string;
    /** When the Keyless SSL was last modified. */
    modifiedOn: string;
    /** The keyless SSL name. */
    name: string;
    /** Available permissions for the Keyless SSL for the current user requesting the item. */
    permissions: GetResponseKeylessServerPermissionsList;
    /** The keyless SSL port used to communicate between Cloudflare and the client's Keyless SSL server. */
    port: number;
    /** Status of the Keyless SSL. */
    status: GetResponseKeylessServerStatus;
    /** Configuration for using Keyless SSL through a Cloudflare Tunnel. */
    tunnel?: CreateResponseKeylessServerTunnel | null;
}
export type GetResponseStatus = "active" | "expired" | "deleted" | "pending" | "initializing";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCustomCertificateResponse {
    /** Custom certificate identifier tag. */
    id: string;
    /** Identifier. */
    zoneId: string;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: GetResponseBundleMethod | null;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string | null;
    /** When the certificate from the authority expires. */
    expiresOn?: string | null;
    /** Specify the region where your private key can be held locally for optimal TLS performance. HTTPS connections to any excluded data center will still be fully encrypted, but will incur some latency while Keyless SSL is used to complete the handshake with the nearest allowed data center. Options allow distribution to only to U.S. data centers, only to E.U. data centers, or only to highest security data centers. Default distribution is to all Cloudflare datacenters, for optimal performance. */
    geoRestrictions?: GetResponseGeoRestrictions | null;
    hosts?: GetResponseHostsList | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    keylessServer?: GetResponseKeylessServer | null;
    /** When the certificate was last modified. */
    modifiedOn?: string | null;
    /** The policy restrictions returned by the API. This field is returned in responses when a policy has been set. The API accepts the "policy" field in requests but returns this field as "policy_restrictions" in responses. */
    policyRestrictions?: string | null;
    /** The order/priority in which the certificate will be used in a request. The higher priority will break ties across overlapping 'legacy_custom' certificates, but 'legacy_custom' certificates will always supercede 'sni_custom' certificates. */
    priority?: number | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the zone's custom SSL. */
    status?: GetResponseStatus | null;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn?: string | null;
}
export type ListRequestMatch = "any" | "all";
export type ListRequestStatus = "active" | "expired" | "deleted" | "pending" | "initializing";
export interface ListCustomCertificatesRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether to match all search requirements or at least one (any). */
    match?: ListRequestMatch | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of zones per page. */
    perPage?: number;
    /** Status of the zone's custom SSL. */
    status?: ListRequestStatus | (string & {});
}
export type ListResultItemBundleMethod = "ubiquitous" | "optimal" | "force";
export type ListResultItemGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export interface ListResultItemGeoRestrictions {
    label?: ListResultItemGeoRestrictionsLabel | null;
}
export type ListResultItemHostsList = Array<string>;
export type ListResultItemKeylessServerPermissionsList = Array<string>;
export type ListResultItemKeylessServerStatus = "active" | "deleted";
export type ListResultItemKeylessServerTunnel = CreateResponseKeylessServerTunnel;
export interface ListResultItemKeylessServer {
    /** Keyless certificate identifier tag. */
    id: string;
    /** When the Keyless SSL was created. */
    createdOn: string;
    /** Whether or not the Keyless SSL is on or off. */
    enabled: boolean;
    /** The keyless SSL name. */
    host: string;
    /** When the Keyless SSL was last modified. */
    modifiedOn: string;
    /** The keyless SSL name. */
    name: string;
    /** Available permissions for the Keyless SSL for the current user requesting the item. */
    permissions: ListResultItemKeylessServerPermissionsList;
    /** The keyless SSL port used to communicate between Cloudflare and the client's Keyless SSL server. */
    port: number;
    /** Status of the Keyless SSL. */
    status: ListResultItemKeylessServerStatus;
    /** Configuration for using Keyless SSL through a Cloudflare Tunnel. */
    tunnel?: CreateResponseKeylessServerTunnel | null;
}
export type ListResultItemStatus = "active" | "expired" | "deleted" | "pending" | "initializing";
export interface ListResultItem {
    /** Custom certificate identifier tag. */
    id: string;
    /** Identifier. */
    zoneId: string;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: ListResultItemBundleMethod | null;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string | null;
    /** When the certificate from the authority expires. */
    expiresOn?: string | null;
    /** Specify the region where your private key can be held locally for optimal TLS performance. HTTPS connections to any excluded data center will still be fully encrypted, but will incur some latency while Keyless SSL is used to complete the handshake with the nearest allowed data center. Options allow distribution to only to U.S. data centers, only to E.U. data centers, or only to highest security data centers. Default distribution is to all Cloudflare datacenters, for optimal performance. */
    geoRestrictions?: ListResultItemGeoRestrictions | null;
    hosts?: ListResultItemHostsList | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    keylessServer?: ListResultItemKeylessServer | null;
    /** When the certificate was last modified. */
    modifiedOn?: string | null;
    /** The policy restrictions returned by the API. This field is returned in responses when a policy has been set. The API accepts the "policy" field in requests but returns this field as "policy_restrictions" in responses. */
    policyRestrictions?: string | null;
    /** The order/priority in which the certificate will be used in a request. The higher priority will break ties across overlapping 'legacy_custom' certificates, but 'legacy_custom' certificates will always supercede 'sni_custom' certificates. */
    priority?: number | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the zone's custom SSL. */
    status?: ListResultItemStatus | null;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn?: string | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListCustomCertificatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type EditRequestBundleMethod = "ubiquitous" | "optimal" | "force";
export type EditRequestDeploy = "staging" | "production";
export type EditRequestGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export interface EditRequestGeoRestrictions {
    label?: EditRequestGeoRestrictionsLabel | (string & {});
}
export interface PatchCustomCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Custom certificate identifier tag. */
    customCertificateId: string;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: EditRequestBundleMethod | (string & {});
    /** The zone's SSL certificate or certificate and the intermediate(s). */
    certificate?: string;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string;
    /** The environment to deploy the certificate to, defaults to production. */
    deploy?: EditRequestDeploy | (string & {});
    /** Specify the region where your private key can be held locally for optimal TLS performance. HTTPS connections to any excluded data center will still be fully encrypted, but will incur some latency while Keyless SSL is used to complete the handshake with the nearest allowed data center. Options allow distribution to only to U.S. data centers, only to E.U. data centers, or only to highest security data centers. Default distribution is to all Cloudflare datacenters, for optimal performance. */
    geoRestrictions?: EditRequestGeoRestrictions;
    /** Specify the policy that determines the region where your private key will be held locally. HTTPS connections to any excluded data center will still be fully encrypted, but will incur some latency while Keyless SSL is used to complete the handshake with the nearest allowed data center. Any combination of countries, specified by their two letter country code (https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2#Officially_assigned_code_elements) can be chosen, such as 'country: IN', as well as 'region: EU' which refers to the EU region. If there are too few data centers satisfying the policy, it will be rejected. Note: The API accepts this field as either "policy" or "policy_restrictions" in requests. Responses return this field as "policy_restrictions". */
    policy?: string;
    /** The zone's private key. Not required if custom_csr_id is provided, in which case the private key is retrieved from the CSR record held by Cloudflare. */
    privateKey?: string;
}
export type EditResponseBundleMethod = "ubiquitous" | "optimal" | "force";
export type EditResponseGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export interface EditResponseGeoRestrictions {
    label?: EditResponseGeoRestrictionsLabel | null;
}
export type EditResponseHostsList = Array<string>;
export type EditResponseKeylessServerPermissionsList = Array<string>;
export type EditResponseKeylessServerStatus = "active" | "deleted";
export type EditResponseKeylessServerTunnel = CreateResponseKeylessServerTunnel;
export interface EditResponseKeylessServer {
    /** Keyless certificate identifier tag. */
    id: string;
    /** When the Keyless SSL was created. */
    createdOn: string;
    /** Whether or not the Keyless SSL is on or off. */
    enabled: boolean;
    /** The keyless SSL name. */
    host: string;
    /** When the Keyless SSL was last modified. */
    modifiedOn: string;
    /** The keyless SSL name. */
    name: string;
    /** Available permissions for the Keyless SSL for the current user requesting the item. */
    permissions: EditResponseKeylessServerPermissionsList;
    /** The keyless SSL port used to communicate between Cloudflare and the client's Keyless SSL server. */
    port: number;
    /** Status of the Keyless SSL. */
    status: EditResponseKeylessServerStatus;
    /** Configuration for using Keyless SSL through a Cloudflare Tunnel. */
    tunnel?: CreateResponseKeylessServerTunnel | null;
}
export type EditResponseStatus = "active" | "expired" | "deleted" | "pending" | "initializing";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCustomCertificateResponse {
    /** Custom certificate identifier tag. */
    id: string;
    /** Identifier. */
    zoneId: string;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: EditResponseBundleMethod | null;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string | null;
    /** When the certificate from the authority expires. */
    expiresOn?: string | null;
    /** Specify the region where your private key can be held locally for optimal TLS performance. HTTPS connections to any excluded data center will still be fully encrypted, but will incur some latency while Keyless SSL is used to complete the handshake with the nearest allowed data center. Options allow distribution to only to U.S. data centers, only to E.U. data centers, or only to highest security data centers. Default distribution is to all Cloudflare datacenters, for optimal performance. */
    geoRestrictions?: EditResponseGeoRestrictions | null;
    hosts?: EditResponseHostsList | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    keylessServer?: EditResponseKeylessServer | null;
    /** When the certificate was last modified. */
    modifiedOn?: string | null;
    /** The policy restrictions returned by the API. This field is returned in responses when a policy has been set. The API accepts the "policy" field in requests but returns this field as "policy_restrictions" in responses. */
    policyRestrictions?: string | null;
    /** The order/priority in which the certificate will be used in a request. The higher priority will break ties across overlapping 'legacy_custom' certificates, but 'legacy_custom' certificates will always supercede 'sni_custom' certificates. */
    priority?: number | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the zone's custom SSL. */
    status?: EditResponseStatus | null;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn?: string | null;
}
export interface PrioritizeUpdateRequestCertificatesItem {
    /** Custom certificate identifier tag. */
    id?: string;
    /** The order/priority in which the certificate will be used in a request. The higher priority will break ties across overlapping 'legacy_custom' certificates, but 'legacy_custom' certificates will always supercede 'sni_custom' certificates. */
    priority?: number;
}
export type PrioritizeUpdateRequestCertificatesList = Array<PrioritizeUpdateRequestCertificatesItem>;
export interface PutPrioritizeRequest {
    /** Identifier. */
    zoneId: string;
    /** Array of ordered certificates. */
    certificates: PrioritizeUpdateRequestCertificatesList;
}
export type PrioritizeUpdateResultItemBundleMethod = "ubiquitous" | "optimal" | "force";
export type PrioritizeUpdateResultItemGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export interface PrioritizeUpdateResultItemGeoRestrictions {
    label?: PrioritizeUpdateResultItemGeoRestrictionsLabel | null;
}
export type PrioritizeUpdateResultItemHostsList = Array<string>;
export type PrioritizeUpdateResultItemKeylessServerPermissionsList = Array<string>;
export type PrioritizeUpdateResultItemKeylessServerStatus = "active" | "deleted";
export type PrioritizeUpdateResultItemKeylessServerTunnel = CreateResponseKeylessServerTunnel;
export interface PrioritizeUpdateResultItemKeylessServer {
    /** Keyless certificate identifier tag. */
    id: string;
    /** When the Keyless SSL was created. */
    createdOn: string;
    /** Whether or not the Keyless SSL is on or off. */
    enabled: boolean;
    /** The keyless SSL name. */
    host: string;
    /** When the Keyless SSL was last modified. */
    modifiedOn: string;
    /** The keyless SSL name. */
    name: string;
    /** Available permissions for the Keyless SSL for the current user requesting the item. */
    permissions: PrioritizeUpdateResultItemKeylessServerPermissionsList;
    /** The keyless SSL port used to communicate between Cloudflare and the client's Keyless SSL server. */
    port: number;
    /** Status of the Keyless SSL. */
    status: PrioritizeUpdateResultItemKeylessServerStatus;
    /** Configuration for using Keyless SSL through a Cloudflare Tunnel. */
    tunnel?: CreateResponseKeylessServerTunnel | null;
}
export type PrioritizeUpdateResultItemStatus = "active" | "expired" | "deleted" | "pending" | "initializing";
export interface PrioritizeUpdateResultItem {
    /** Custom certificate identifier tag. */
    id: string;
    /** Identifier. */
    zoneId: string;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: PrioritizeUpdateResultItemBundleMethod | null;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string | null;
    /** When the certificate from the authority expires. */
    expiresOn?: string | null;
    /** Specify the region where your private key can be held locally for optimal TLS performance. HTTPS connections to any excluded data center will still be fully encrypted, but will incur some latency while Keyless SSL is used to complete the handshake with the nearest allowed data center. Options allow distribution to only to U.S. data centers, only to E.U. data centers, or only to highest security data centers. Default distribution is to all Cloudflare datacenters, for optimal performance. */
    geoRestrictions?: PrioritizeUpdateResultItemGeoRestrictions | null;
    hosts?: PrioritizeUpdateResultItemHostsList | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    keylessServer?: PrioritizeUpdateResultItemKeylessServer | null;
    /** When the certificate was last modified. */
    modifiedOn?: string | null;
    /** The policy restrictions returned by the API. This field is returned in responses when a policy has been set. The API accepts the "policy" field in requests but returns this field as "policy_restrictions" in responses. */
    policyRestrictions?: string | null;
    /** The order/priority in which the certificate will be used in a request. The higher priority will break ties across overlapping 'legacy_custom' certificates, but 'legacy_custom' certificates will always supercede 'sni_custom' certificates. */
    priority?: number | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the zone's custom SSL. */
    status?: PrioritizeUpdateResultItemStatus | null;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn?: string | null;
}
export type PrioritizeUpdateResultList = Array<PrioritizeUpdateResultItem>;
export interface PutPrioritizeResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PrioritizeUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type CreateCustomCertificateError = PlanLevelNotAllowed | Forbidden | CloudflareOpError;
/** Upload a new SSL certificate for a zone. */
export declare const createCustomCertificate: API.OperationMethod<CreateCustomCertificateRequest, CreateCustomCertificateResponse, CreateCustomCertificateError, CloudflareOpContext>;
export type DeleteCustomCertificateError = CustomCertificateNotFound | PlanLevelNotAllowed | Forbidden | CloudflareOpError;
/** Remove a SSL certificate from a zone. */
export declare const deleteCustomCertificate: API.OperationMethod<DeleteCustomCertificateRequest, DeleteCustomCertificateResponse, DeleteCustomCertificateError, CloudflareOpContext>;
export type GetCustomCertificateError = CustomCertificateNotFound | PlanLevelNotAllowed | Forbidden | CloudflareOpError;
/** Retrieves details for a specific custom SSL certificate, including certificate metadata, bundle method, geographic restrictions, and associated keyless server configuration. */
export declare const getCustomCertificate: API.OperationMethod<GetCustomCertificateRequest, GetCustomCertificateResponse, GetCustomCertificateError, CloudflareOpContext>;
export type ListCustomCertificatesError = PlanLevelNotAllowed | ZoneNotFound | Forbidden | CloudflareOpError;
/** List, search, and filter all of your custom SSL certificates. The higher priority will break ties across overlapping 'legacy_custom' certificates, but 'legacy_custom' certificates will always supercede 'sni_custom' certificates. */
export declare const listCustomCertificates: API.PaginatedOperationMethod<ListCustomCertificatesRequest, ListCustomCertificatesResponse, ListCustomCertificatesError, CloudflareOpContext, ListResultItem>;
export type PatchCustomCertificateError = CustomCertificateNotFound | PlanLevelNotAllowed | Forbidden | CloudflareOpError;
/** Upload a new private key and/or PEM/CRT for the SSL certificate. Note: PATCHing a configuration for sni_custom certificates will result in a new resource id being returned, and the previous one being deleted. */
export declare const patchCustomCertificate: API.OperationMethod<PatchCustomCertificateRequest, PatchCustomCertificateResponse, PatchCustomCertificateError, CloudflareOpContext>;
export type PutPrioritizeError = PlanLevelNotAllowed | Forbidden | CloudflareOpError;
/** If a zone has multiple SSL certificates, you can set the order in which they should be used during a request. The higher priority will break ties across overlapping 'legacy_custom' certificates. */
export declare const putPrioritize: API.PaginatedOperationMethod<PutPrioritizeRequest, PutPrioritizeResponse, PutPrioritizeError, CloudflareOpContext, PrioritizeUpdateResultItem>;
//# sourceMappingURL=custom_certificates.d.ts.map