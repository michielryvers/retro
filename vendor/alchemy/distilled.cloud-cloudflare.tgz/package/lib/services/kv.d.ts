import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import * as T from "../traits.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const InvalidExpirationTtl_base: S.TaggedErrorClass<"InvalidExpirationTtl", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidExpirationTtl extends /*@__PURE__*/ InvalidExpirationTtl_base {
}
declare const InvalidObjectIdentifier_base: S.TaggedErrorClass<"InvalidObjectIdentifier", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidObjectIdentifier extends /*@__PURE__*/ InvalidObjectIdentifier_base {
}
declare const InvalidRequestBody_base: S.TaggedErrorClass<"InvalidRequestBody", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRequestBody extends /*@__PURE__*/ InvalidRequestBody_base {
}
declare const KeyNotFound_base: S.TaggedErrorClass<"KeyNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class KeyNotFound extends /*@__PURE__*/ KeyNotFound_base {
}
declare const MethodNotAllowed_base: S.TaggedErrorClass<"MethodNotAllowed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MethodNotAllowed extends /*@__PURE__*/ MethodNotAllowed_base {
}
declare const MinimumKeysRequired_base: S.TaggedErrorClass<"MinimumKeysRequired", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MinimumKeysRequired extends /*@__PURE__*/ MinimumKeysRequired_base {
}
declare const NamespaceNotFound_base: S.TaggedErrorClass<"NamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NamespaceNotFound extends /*@__PURE__*/ NamespaceNotFound_base {
}
declare const NamespaceTitleAlreadyExists_base: S.TaggedErrorClass<"NamespaceTitleAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NamespaceTitleAlreadyExists extends /*@__PURE__*/ NamespaceTitleAlreadyExists_base {
}
declare const TitleRequired_base: S.TaggedErrorClass<"TitleRequired", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TitleRequired extends /*@__PURE__*/ TitleRequired_base {
}
export type NamespacesBulkDeleteRequestBodyList = Array<string>;
export interface BulkDeleteNamespacesRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
    body: NamespacesBulkDeleteRequestBodyList;
}
export type NamespacesBulkDeleteResponseUnsuccessfulKeysList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkDeleteNamespacesResponse {
    /** Number of keys successfully written or deleted by the bulk operation. */
    successfulKeyCount?: number | null;
    /** Names of keys that failed to be written or deleted. Retry the operation for these keys. */
    unsuccessfulKeys?: NamespacesBulkDeleteResponseUnsuccessfulKeysList | null;
}
export type NamespacesBulkGetRequestKeysList = Array<string>;
export type NamespacesBulkGetRequestType = "text" | "json";
export interface BulkGetNamespacesRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
    /** Array of keys to retrieve (maximum of 100). */
    keys: NamespacesBulkGetRequestKeysList;
    /** Return values as strings with `text`, or parse stored JSON values with `json`. */
    type?: NamespacesBulkGetRequestType | (string & {});
    /** Whether to include metadata in the response. */
    withMetadata?: boolean;
}
export type NamespacesBulkGetResultWorkersKVBulkGetResultValuesCase3Map = {
    [key: string]: unknown | undefined;
};
export type NamespacesBulkGetResultWorkersKVBulkGetResultValues = string | number | boolean | NamespacesBulkGetResultWorkersKVBulkGetResultValuesCase3Map;
export interface NamespacesBulkGetResultWorkersKVBulkGetResult {
    /** Requested keys are paired with their values in an object. */
    values?: NamespacesBulkGetResultWorkersKVBulkGetResultValues | null;
}
export interface NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue {
    /** The metadata associated with the key. */
    metadata: unknown;
    /** The value associated with the key. */
    value: unknown;
    /** Expires the key at a certain time, measured in number of seconds since the UNIX epoch. */
    expiration?: number | null;
}
export type NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesMap = {
    [key: string]: NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue | undefined;
};
export interface NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadata {
    /** Requested keys are paired with their values and metadata in an object. */
    values?: NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesMap | null;
}
export type NamespacesBulkGetResult = NamespacesBulkGetResultWorkersKVBulkGetResult | NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadata;
export type BulkGetNamespacesResponse = NamespacesBulkGetResult;
export interface NamespacesBulkUpdateRequestBodyItem {
    /** A key's name. The name may be at most 512 bytes. All printable, non-whitespace characters are valid. */
    key: string;
    /** A UTF-8 encoded string to be stored, up to 25 MiB in length. */
    value: string;
    /** Indicates whether or not the server should base64 decode the value before storing it. Useful for writing values that wouldn't otherwise be valid JSON strings, such as images. */
    base64?: boolean;
    /** Expires the key at a certain time, measured in number of seconds since the UNIX epoch. */
    expiration?: number;
    /** Number of seconds until the key expires. Must be at least 60. Takes precedence over `expiration` when both are specified. */
    expirationTtl?: number;
    /** Arbitrary JSON that is associated with a key. */
    metadata?: unknown;
}
export type NamespacesBulkUpdateRequestBodyList = Array<NamespacesBulkUpdateRequestBodyItem>;
export interface BulkPutNamespacesRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
    body: NamespacesBulkUpdateRequestBodyList;
}
export type NamespacesBulkUpdateResponseUnsuccessfulKeysList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPutNamespacesResponse {
    /** Number of keys successfully written or deleted by the bulk operation. */
    successfulKeyCount?: number | null;
    /** Names of keys that failed to be written or deleted. Retry the operation for these keys. */
    unsuccessfulKeys?: NamespacesBulkUpdateResponseUnsuccessfulKeysList | null;
}
export type NamespacesCreateRequestJurisdiction = "eu" | "fedramp" | "us";
export type NamespacesCreateRequestMode = "instant";
export interface CreateNamespaceRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** Human-readable string name for a Workers KV namespace. */
    title: string;
    /** Specify the jurisdiction to restrict the KV namespace to durably store data within. Can only be set at namespace creation time. */
    jurisdiction?: NamespacesCreateRequestJurisdiction | (string & {});
    /** The mode of the Workers KV namespace. Specify `instant` when creating a namespace to create a KV Instant namespace. Omit this field when creating a namespace to create a classic namespace. Currently, `instant` is the only supported explicit value. */
    mode?: NamespacesCreateRequestMode | (string & {});
}
export type NamespacesCreateResponseJurisdiction = "eu" | "fedramp" | "us";
export type NamespacesCreateResponseMode = "instant";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateNamespaceResponse {
    /** ID of the Workers KV namespace. */
    id: string;
    /** Human-readable string name for a Workers KV namespace. */
    title: string;
    /** Specify the jurisdiction to restrict the KV namespace to durably store data within. Can only be set at namespace creation time. */
    jurisdiction?: NamespacesCreateResponseJurisdiction | null;
    /** The mode of the Workers KV namespace. Specify `instant` when creating a namespace to create a KV Instant namespace. Omit this field when creating a namespace to create a classic namespace. Currently, `instant` is the only supported explicit value. */
    mode?: NamespacesCreateResponseMode | null;
    /** True if keys written on the URL will be URL-decoded before storing. For example, if set to "true", a key written on the URL as "%3F" will be stored as "?". */
    supportsUrlEncoding?: boolean | null;
}
export interface DeleteNamespaceRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
}
export interface DeleteNamespaceResponse {
}
export interface DeleteNamespaceValueRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
    /** A key's name. The name may be at most 512 bytes. All printable, non-whitespace characters are valid. Use percent-encoding to define key names as part of a URL. */
    keyName: string;
}
export interface DeleteNamespaceValueResponse {
}
export interface GetNamespaceRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
}
export type NamespacesGetResponseJurisdiction = "eu" | "fedramp" | "us";
export type NamespacesGetResponseMode = "instant";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetNamespaceResponse {
    /** ID of the Workers KV namespace. */
    id: string;
    /** Human-readable string name for a Workers KV namespace. */
    title: string;
    /** Specify the jurisdiction to restrict the KV namespace to durably store data within. Can only be set at namespace creation time. */
    jurisdiction?: NamespacesGetResponseJurisdiction | null;
    /** The mode of the Workers KV namespace. Specify `instant` when creating a namespace to create a KV Instant namespace. Omit this field when creating a namespace to create a classic namespace. Currently, `instant` is the only supported explicit value. */
    mode?: NamespacesGetResponseMode | null;
    /** True if keys written on the URL will be URL-decoded before storing. For example, if set to "true", a key written on the URL as "%3F" will be stored as "?". */
    supportsUrlEncoding?: boolean | null;
}
export interface GetNamespaceMetadataRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
    /** A key's name. The name may be at most 512 bytes. All printable, non-whitespace characters are valid. Use percent-encoding to define key names as part of a URL. */
    keyName: string;
}
export type GetNamespaceMetadataResponse = unknown;
export interface GetNamespaceValueRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
    /** A key's name. The name may be at most 512 bytes. All printable, non-whitespace characters are valid. Use percent-encoding to define key names as part of a URL. */
    keyName: string;
}
export interface GetNamespaceValueResponse {
    /** Raw value body as an Effect Stream. */
    body: T.BinaryResponseBody;
    /** Expiration time of the KV pair, seconds since the UNIX epoch (set when the pair is set to expire). */
    expiration?: number;
    /** MIME type the value was stored with. */
    contentType?: string;
}
export interface ListNamespaceKeysRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
    /** Opaque pagination token from `result_info.cursor` in the previous response. Pass it unchanged to request the next page of keys. */
    cursor?: string;
    /** Maximum number of keys to return in one response. Pass `result_info.cursor` from the response as `cursor` to request the next page. */
    limit?: number;
    /** Filters returned keys by a name prefix. Exact matches and any key names that begin with the prefix will be returned. */
    prefix?: string;
}
export interface NamespacesKeysListResultItem {
    /** A key's name. The name may be at most 512 bytes. All printable, non-whitespace characters are valid. Use percent-encoding to define key names as part of a URL. */
    name: string;
    /** The time, measured in number of seconds since the UNIX epoch, at which the key will expire. This property is omitted for keys that will not expire. */
    expiration?: number | null;
    /** Arbitrary JSON that is associated with a key. */
    metadata?: unknown | null;
}
export type NamespacesKeysListResultList = Array<NamespacesKeysListResultItem>;
export interface ListNamespaceKeysResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesKeysListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type NamespacesListRequestDirection = "asc" | "desc";
export type NamespacesListRequestOrder = "id" | "title";
export interface ListNamespacesRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** Sort namespaces in ascending (`asc`) or descending (`desc`) order. */
    direction?: NamespacesListRequestDirection | (string & {});
    /** Namespace field to sort by (`id` or `title`). */
    order?: NamespacesListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type NamespacesListResultItemJurisdiction = "eu" | "fedramp" | "us";
export type NamespacesListResultItemMode = "instant";
export interface NamespacesListResultItem {
    /** ID of the Workers KV namespace. */
    id: string;
    /** Human-readable string name for a Workers KV namespace. */
    title: string;
    /** Specify the jurisdiction to restrict the KV namespace to durably store data within. Can only be set at namespace creation time. */
    jurisdiction?: NamespacesListResultItemJurisdiction | null;
    /** The mode of the Workers KV namespace. Specify `instant` when creating a namespace to create a KV Instant namespace. Omit this field when creating a namespace to create a classic namespace. Currently, `instant` is the only supported explicit value. */
    mode?: NamespacesListResultItemMode | null;
    /** True if keys written on the URL will be URL-decoded before storing. For example, if set to "true", a key written on the URL as "%3F" will be stored as "?". */
    supportsUrlEncoding?: boolean | null;
}
export type NamespacesListResultList = Array<NamespacesListResultItem>;
export interface ListNamespacesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type NamespacesKeysBulkDeleteRequestBodyList = Array<string>;
export interface NamespacesKeysBulkDeleteRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
    body: NamespacesKeysBulkDeleteRequestBodyList;
}
export type NamespacesKeysBulkDeleteResponseUnsuccessfulKeysList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface NamespacesKeysBulkDeleteResponse {
    /** Number of keys successfully written or deleted by the bulk operation. */
    successfulKeyCount?: number | null;
    /** Names of keys that failed to be written or deleted. Retry the operation for these keys. */
    unsuccessfulKeys?: NamespacesKeysBulkDeleteResponseUnsuccessfulKeysList | null;
}
export type NamespacesKeysBulkGetRequestKeysList = Array<string>;
export type NamespacesKeysBulkGetRequestType = "text" | "json";
export interface NamespacesKeysBulkGetRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
    /** Array of keys to retrieve (maximum of 100). */
    keys: NamespacesKeysBulkGetRequestKeysList;
    /** Return values as strings with `text`, or parse stored JSON values with `json`. */
    type?: NamespacesKeysBulkGetRequestType | (string & {});
    /** Whether to include metadata in the response. */
    withMetadata?: boolean;
}
export type NamespacesKeysBulkGetResultWorkersKVBulkGetResultValuesCase3Map = {
    [key: string]: unknown | undefined;
};
export type NamespacesKeysBulkGetResultWorkersKVBulkGetResultValues = string | number | boolean | NamespacesKeysBulkGetResultWorkersKVBulkGetResultValuesCase3Map;
export interface NamespacesKeysBulkGetResultWorkersKVBulkGetResult {
    /** Requested keys are paired with their values in an object. */
    values?: NamespacesKeysBulkGetResultWorkersKVBulkGetResultValues | null;
}
export type NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue = NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue;
export type NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadataValuesMap = {
    [key: string]: NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue | undefined;
};
export interface NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadata {
    /** Requested keys are paired with their values and metadata in an object. */
    values?: NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadataValuesMap | null;
}
export type NamespacesKeysBulkGetResult = NamespacesKeysBulkGetResultWorkersKVBulkGetResult | NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadata;
export type NamespacesKeysBulkGetResponse = NamespacesKeysBulkGetResult;
export type NamespacesKeysBulkUpdateRequestBodyItem = NamespacesBulkUpdateRequestBodyItem;
export type NamespacesKeysBulkUpdateRequestBodyList = Array<NamespacesBulkUpdateRequestBodyItem>;
export interface NamespacesKeysBulkUpdateRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
    body: NamespacesKeysBulkUpdateRequestBodyList;
}
export type NamespacesKeysBulkUpdateResponseUnsuccessfulKeysList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface NamespacesKeysBulkUpdateResponse {
    /** Number of keys successfully written or deleted by the bulk operation. */
    successfulKeyCount?: number | null;
    /** Names of keys that failed to be written or deleted. Retry the operation for these keys. */
    unsuccessfulKeys?: NamespacesKeysBulkUpdateResponseUnsuccessfulKeysList | null;
}
export interface PutNamespaceValueRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
    /** A key's name. The name may be at most 512 bytes. All printable, non-whitespace characters are valid. Use percent-encoding to define key names as part of a URL. */
    keyName: string;
    /** Expires the key at a certain time, measured in number of seconds since the UNIX epoch. */
    expiration?: number;
    /** Number of seconds until the key expires. Must be at least 60. Takes precedence over `expiration` when both are specified. */
    expirationTtl?: number;
    /** A byte sequence to be stored, up to 25 MiB in length. */
    value: string | File | Blob;
    /** Associates arbitrary JSON data with a key/value pair. */
    metadata?: unknown;
}
export interface PutNamespaceValueResponse {
}
export interface UpdateNamespaceRequest {
    /** ID of the Cloudflare account that owns the Workers KV namespaces. */
    accountId: string;
    /** ID of the Workers KV namespace. */
    namespaceId: string;
    /** Human-readable string name for a Workers KV namespace. */
    title: string;
}
export type NamespacesUpdateResponseJurisdiction = "eu" | "fedramp" | "us";
export type NamespacesUpdateResponseMode = "instant";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateNamespaceResponse {
    /** ID of the Workers KV namespace. */
    id: string;
    /** Human-readable string name for a Workers KV namespace. */
    title: string;
    /** Specify the jurisdiction to restrict the KV namespace to durably store data within. Can only be set at namespace creation time. */
    jurisdiction?: NamespacesUpdateResponseJurisdiction | null;
    /** The mode of the Workers KV namespace. Specify `instant` when creating a namespace to create a KV Instant namespace. Omit this field when creating a namespace to create a classic namespace. Currently, `instant` is the only supported explicit value. */
    mode?: NamespacesUpdateResponseMode | null;
    /** True if keys written on the URL will be URL-decoded before storing. For example, if set to "true", a key written on the URL as "%3F" will be stored as "?". */
    supportsUrlEncoding?: boolean | null;
}
export type BulkDeleteNamespacesError = NamespaceNotFound | InvalidRequestBody | InvalidObjectIdentifier | CloudflareOpError;
/** Deletes up to 10,000 key-value pairs from the specified Workers KV namespace. Send a JSON array of the key names to delete. The result reports the number of successful deletions and any keys that failed and should be retried. */
export declare const bulkDeleteNamespaces: API.OperationMethod<BulkDeleteNamespacesRequest, BulkDeleteNamespacesResponse, BulkDeleteNamespacesError, CloudflareOpContext>;
export type BulkGetNamespacesError = InvalidRequestBody | MinimumKeysRequired | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Retrieves the text-based values of up to 100 keys from the specified Workers KV namespace. The result maps each requested key to its value. Set `type` to `json` to parse JSON values instead of returning strings, and set `withMetadata` to `true` to include metadata with each value. Binary values are not supported by this operation. */
export declare const bulkGetNamespaces: API.OperationMethod<BulkGetNamespacesRequest, BulkGetNamespacesResponse, BulkGetNamespacesError, CloudflareOpContext>;
export type BulkPutNamespacesError = InvalidRequestBody | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Writes up to 10,000 key-value pairs to the specified Workers KV namespace from a JSON array, with optional metadata and expiration settings for each pair. Existing values and expirations are overwritten. If neither `expiration` nor `expiration_ttl` is specified, the key-value pair will not expire. If both are set, `expiration_ttl` takes precedence. The entire request must be 100 megabytes or less. The result reports the number of successful writes and any keys that failed and should be retried. */
export declare const bulkPutNamespaces: API.OperationMethod<BulkPutNamespacesRequest, BulkPutNamespacesResponse, BulkPutNamespacesError, CloudflareOpContext>;
export type CreateNamespaceError = TitleRequired | InvalidObjectIdentifier | NamespaceTitleAlreadyExists | CloudflareOpError;
/** Creates a Workers KV namespace in the specified account with the given title. Returns `400` if the account already owns a namespace with that title; an existing namespace must be explicitly deleted before it can be replaced. An optional jurisdiction restricts where data is durably stored and can only be set at creation time. */
export declare const createNamespace: API.OperationMethod<CreateNamespaceRequest, CreateNamespaceResponse, CreateNamespaceError, CloudflareOpContext>;
export type DeleteNamespaceError = MethodNotAllowed | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Deletes the specified Workers KV namespace and its stored key-value pairs from the account. */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest, DeleteNamespaceResponse, DeleteNamespaceError, CloudflareOpContext>;
export type DeleteNamespaceValueError = NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Deletes the specified key and its value from the Workers KV namespace. Use URL-encoding for special characters (for example, `:`, `!`, `%`) in the key name when constructing the request URL. */
export declare const deleteNamespaceValue: API.OperationMethod<DeleteNamespaceValueRequest, DeleteNamespaceValueResponse, DeleteNamespaceValueError, CloudflareOpContext>;
export type GetNamespaceError = NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Returns the Workers KV namespace for the specified account and namespace ID. */
export declare const getNamespace: API.OperationMethod<GetNamespaceRequest, GetNamespaceResponse, GetNamespaceError, CloudflareOpContext>;
export type GetNamespaceMetadataError = KeyNotFound | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Returns the JSON metadata associated with the specified key in the Workers KV namespace, without retrieving its value. Use URL-encoding for special characters (for example, `:`, `!`, `%`) in the key name when constructing the request URL. */
export declare const getNamespaceMetadata: API.OperationMethod<GetNamespaceMetadataRequest, GetNamespaceMetadataResponse, GetNamespaceMetadataError, CloudflareOpContext>;
export type GetNamespaceValueError = KeyNotFound | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Returns the value stored under the specified key in the Workers KV namespace as raw bytes. Use URL-encoding for special characters (for example, `:`, `!`, `%`) in the key name when constructing the request URL. If the key-value pair expires, the `expiration` response header contains its expiration time in seconds since the UNIX epoch. */
export declare const getNamespaceValue: API.OperationMethod<GetNamespaceValueRequest, GetNamespaceValueResponse, GetNamespaceValueError, CloudflareOpContext>;
export type ListNamespaceKeysError = CloudflareOpError;
/** Lists key names in the specified Workers KV namespace, with expiration times and metadata when present. Use `prefix` to filter names and `cursor` to request the next page. Values are not included. */
export declare const listNamespaceKeys: API.PaginatedOperationMethod<ListNamespaceKeysRequest, ListNamespaceKeysResponse, ListNamespaceKeysError, CloudflareOpContext, NamespacesKeysListResultItem>;
export type ListNamespacesError = CloudflareOpError;
/** Lists Workers KV namespaces owned by the specified account. Use `page` and `per_page` to select a page of results, and `order` and `direction` to control sorting. */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, CloudflareOpContext, NamespacesListResultItem>;
export type NamespacesKeysBulkDeleteError = NamespaceNotFound | InvalidRequestBody | InvalidObjectIdentifier | CloudflareOpError;
/** Deletes up to 10,000 key-value pairs from the specified Workers KV namespace. Send a JSON array of the key names to delete. The result reports the number of successful deletions and any keys that failed and should be retried. */
export declare const namespacesKeysBulkDelete: API.OperationMethod<NamespacesKeysBulkDeleteRequest, NamespacesKeysBulkDeleteResponse, NamespacesKeysBulkDeleteError, CloudflareOpContext>;
export type NamespacesKeysBulkGetError = InvalidRequestBody | MinimumKeysRequired | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Retrieves the text-based values of up to 100 keys from the specified Workers KV namespace. The result maps each requested key to its value. Set `type` to `json` to parse JSON values instead of returning strings, and set `withMetadata` to `true` to include metadata with each value. Binary values are not supported by this operation. */
export declare const namespacesKeysBulkGet: API.OperationMethod<NamespacesKeysBulkGetRequest, NamespacesKeysBulkGetResponse, NamespacesKeysBulkGetError, CloudflareOpContext>;
export type NamespacesKeysBulkUpdateError = InvalidRequestBody | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Writes up to 10,000 key-value pairs to the specified Workers KV namespace from a JSON array, with optional metadata and expiration settings for each pair. Existing values and expirations are overwritten. If neither `expiration` nor `expiration_ttl` is specified, the key-value pair will not expire. If both are set, `expiration_ttl` takes precedence. The entire request must be 100 megabytes or less. The result reports the number of successful writes and any keys that failed and should be retried. */
export declare const namespacesKeysBulkUpdate: API.OperationMethod<NamespacesKeysBulkUpdateRequest, NamespacesKeysBulkUpdateResponse, NamespacesKeysBulkUpdateError, CloudflareOpContext>;
export type PutNamespaceValueError = NamespaceNotFound | InvalidObjectIdentifier | InvalidExpirationTtl | CloudflareOpError;
/** Writes a value under the specified key in the Workers KV namespace, creating the key-value pair or replacing its existing value, expiration, and metadata. Send the value as an `application/octet-stream` request body, or use `multipart/form-data` with a `value` part and an optional JSON `metadata` part. Use URL-encoding for special characters (for example, `:`, `!`, `%`) in the key name when constructing the request URL. If neither `expiration` nor `expiration_ttl` is specified, the key-value pair will not expire. If both are set, `expiration_ttl` takes precedence. */
export declare const putNamespaceValue: API.OperationMethod<PutNamespaceValueRequest, PutNamespaceValueResponse, PutNamespaceValueError, CloudflareOpContext>;
export type UpdateNamespaceError = NamespaceNotFound | TitleRequired | InvalidObjectIdentifier | NamespaceTitleAlreadyExists | CloudflareOpError;
/** Changes the title of the specified Workers KV namespace and returns the updated namespace. The namespace ID and stored key-value pairs are unchanged. */
export declare const updateNamespace: API.OperationMethod<UpdateNamespaceRequest, UpdateNamespaceResponse, UpdateNamespaceError, CloudflareOpContext>;
export declare const bulkDeleteNamespaceKeys: API.OperationMethod<BulkDeleteNamespacesRequest, BulkDeleteNamespacesResponse, BulkDeleteNamespacesError, CloudflareOpContext>;
export type BulkDeleteNamespaceKeysRequest = BulkDeleteNamespacesRequest;
export type BulkDeleteNamespaceKeysResponse = BulkDeleteNamespacesResponse;
export type BulkDeleteNamespaceKeysError = BulkDeleteNamespacesError;
export declare const bulkGetNamespaceKeys: API.OperationMethod<BulkGetNamespacesRequest, NamespacesBulkGetResult, BulkGetNamespacesError, CloudflareOpContext>;
export type BulkGetNamespaceKeysRequest = BulkGetNamespacesRequest;
export type BulkGetNamespaceKeysResponse = BulkGetNamespacesResponse;
export type BulkGetNamespaceKeysError = BulkGetNamespacesError;
export declare const bulkPutNamespaceKeys: API.OperationMethod<BulkPutNamespacesRequest, BulkPutNamespacesResponse, BulkPutNamespacesError, CloudflareOpContext>;
export type BulkPutNamespaceKeysRequest = BulkPutNamespacesRequest;
export type BulkPutNamespaceKeysResponse = BulkPutNamespacesResponse;
export type BulkPutNamespaceKeysError = BulkPutNamespacesError;
//# sourceMappingURL=kv.d.ts.map