import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidSettingValue_base: S.TaggedErrorClass<"InvalidSettingValue", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidSettingValue extends /*@__PURE__*/ InvalidSettingValue_base {
}
declare const InvalidZoneIdentifier_base: S.TaggedErrorClass<"InvalidZoneIdentifier", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidZoneIdentifier extends /*@__PURE__*/ InvalidZoneIdentifier_base {
}
export interface GetOriginPostQuantumEncryptionRequest {
    /** Identifier. */
    zoneId: string;
}
export type GetResponseId = "origin_pqe";
export type GetResponseValue = "preferred" | "supported" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOriginPostQuantumEncryptionResponse {
    /** The identifier of the caching setting. */
    id: GetResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Origin Post Quantum Encryption Setting. */
    value: GetResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export type UpdateRequestValue = "preferred" | "supported" | "off";
export interface PutOriginPostQuantumEncryptionRequest {
    /** Identifier. */
    zoneId: string;
    /** Value of the Origin Post Quantum Encryption Setting. */
    value: UpdateRequestValue | (string & {});
}
export type UpdateResponseId = "origin_pqe";
export type UpdateResponseValue = "preferred" | "supported" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutOriginPostQuantumEncryptionResponse {
    /** The identifier of the caching setting. */
    id: UpdateResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Origin Post Quantum Encryption Setting. */
    value: UpdateResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export type GetOriginPostQuantumEncryptionError = InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Instructs Cloudflare to use Post-Quantum (PQ) key agreement algorithms when connecting to your origin. Preferred instructs Cloudflare to opportunistically send a Post-Quantum keyshare in the first message to the origin (for fastest connections when the origin supports and prefers PQ), supported means that PQ algorithms are advertised but only used when requested by the origin, and off means that PQ algorithms are not advertised. */
export declare const getOriginPostQuantumEncryption: API.OperationMethod<GetOriginPostQuantumEncryptionRequest, GetOriginPostQuantumEncryptionResponse, GetOriginPostQuantumEncryptionError, CloudflareOpContext>;
export type PutOriginPostQuantumEncryptionError = InvalidZoneIdentifier | InvalidSettingValue | Forbidden | CloudflareOpError;
/** Instructs Cloudflare to use Post-Quantum (PQ) key agreement algorithms when connecting to your origin. Preferred instructs Cloudflare to opportunistically send a Post-Quantum keyshare in the first message to the origin (for fastest connections when the origin supports and prefers PQ), supported means that PQ algorithms are advertised but only used when requested by the origin, and off means that PQ algorithms are not advertised. */
export declare const putOriginPostQuantumEncryption: API.OperationMethod<PutOriginPostQuantumEncryptionRequest, PutOriginPostQuantumEncryptionResponse, PutOriginPostQuantumEncryptionError, CloudflareOpContext>;
//# sourceMappingURL=origin_post_quantum_encryption.d.ts.map