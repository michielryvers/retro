import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface ListIpsRequest {
    /** Specified as `jdcloud` to list IPs used by JD Cloud data centers. */
    networks?: string;
}
export type ListResultPublicIPIPsIpv4CidrsList = Array<string>;
export type ListResultPublicIPIPsIpv6CidrsList = Array<string>;
export interface ListResultPublicIPIPs {
    /** A digest of the IP data. Useful for determining if the data has changed. */
    etag?: string | null;
    /** List of Cloudflare IPv4 CIDR addresses. */
    ipv4Cidrs?: ListResultPublicIPIPsIpv4CidrsList | null;
    /** List of Cloudflare IPv6 CIDR addresses. */
    ipv6Cidrs?: ListResultPublicIPIPsIpv6CidrsList | null;
}
export type ListResultPublicIPIPsJDCloudIpv4CidrsList = Array<string>;
export type ListResultPublicIPIPsJDCloudIpv6CidrsList = Array<string>;
export type ListResultPublicIPIPsJDCloudJdcloudCidrsList = Array<string>;
export interface ListResultPublicIPIPsJDCloud {
    /** A digest of the IP data. Useful for determining if the data has changed. */
    etag?: string | null;
    /** List of Cloudflare IPv4 CIDR addresses. */
    ipv4Cidrs?: ListResultPublicIPIPsJDCloudIpv4CidrsList | null;
    /** List of Cloudflare IPv6 CIDR addresses. */
    ipv6Cidrs?: ListResultPublicIPIPsJDCloudIpv6CidrsList | null;
    /** List IPv4 and IPv6 CIDRs, only populated if `?networks=jdcloud` is used. */
    jdcloudCidrs?: ListResultPublicIPIPsJDCloudJdcloudCidrsList | null;
}
export type ListResult = ListResultPublicIPIPs | ListResultPublicIPIPsJDCloud;
export type ListIpsResponse = ListResult;
export type ListIpsError = CloudflareOpError;
/** Get IPs used on the Cloudflare/JD Cloud network, see https://www.cloudflare.com/ips for Cloudflare IPs or https://developers.cloudflare.com/china-network/reference/infrastructure/ for JD Cloud IPs. */
export declare const listIps: API.OperationMethod<ListIpsRequest, ListIpsResponse, ListIpsError, CloudflareOpContext>;
//# sourceMappingURL=ips.d.ts.map