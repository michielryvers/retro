import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const JobNotFound_base: S.TaggedErrorClass<"JobNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class JobNotFound extends /*@__PURE__*/ JobNotFound_base {
}
declare const NotFound_base: S.TaggedErrorClass<"NotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
export interface CreateEdgeRequest {
    /** Identifier. */
    zoneId: string;
    /** Comma-separated list of fields. */
    fields?: string;
    /** Filters to drill down into specific events. */
    filter?: string;
    /** The sample parameter is the sample rate of the records set by the client: "sample": 1 is 100% of records "sample": 10 is 10% and so on. */
    sample?: number;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateEdgeResponse {
    /** Unique WebSocket address that will receive messages from Cloudflare's edge. */
    destinationConf?: string | null;
    /** Comma-separated list of fields. */
    fields?: string | null;
    /** Filters to drill down into specific events. */
    filter?: string | null;
    /** The sample parameter is the sample rate of the records set by the client: "sample": 1 is 100% of records "sample": 10 is 10% and so on. */
    sample?: number | null;
    /** Unique session id of the job. */
    sessionId?: string | null;
}
export type JobsCreateRequestDataset = "access_requests" | "account_abuse_protection_events" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_bgp_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export type JobsCreateRequestFrequency = "high" | "low";
export type JobsCreateRequestKind = "" | "edge";
export type JobsCreateRequestOutputOptionsFieldNamesList = Array<string>;
export type JobsCreateRequestOutputOptionsOutputType = "ndjson" | "csv";
export type JobsCreateRequestOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export interface JobsCreateRequestOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string;
    /** String to be appended after each batch. */
    batchSuffix?: string;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: JobsCreateRequestOutputOptionsFieldNamesList;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: JobsCreateRequestOutputOptionsOutputType | (string & {});
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string;
    /** String to be prepended before each record. */
    recordPrefix?: string;
    /** String to be appended after each record. */
    recordSuffix?: string;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string;
    /** Specifies the sampling rate as a floating number greater than 0 and at most 1. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: JobsCreateRequestOutputOptionsTimestampFormat | (string & {});
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean;
}
export interface CreateJobForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: JobsCreateRequestDataset | (string & {});
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean;
    /** The filters to select the events to include and/or remove from your logs. For more information, refer to [Filters](https://developers.cloudflare.com/logs/reference/filters/). */
    filter?: string;
    /** When true, excludes DDoS attack traffic from logs. This option is supported for the `http_requests`, `firewall_events`, and `network_analytics_logs` datasets. */
    filterAttackTraffic?: boolean;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsCreateRequestFrequency | (string & {});
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsCreateRequestKind | (string & {});
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsCreateRequestOutputOptions;
    /** Ownership challenge token to prove destination ownership. */
    ownershipChallenge?: string;
}
export type JobsCreateResponseDataset = "access_requests" | "account_abuse_protection_events" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_bgp_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export type JobsCreateResponseFrequency = "high" | "low";
export type JobsCreateResponseKind = "" | "edge";
export type JobsCreateResponseOutputOptionsFieldNamesList = Array<string>;
export type JobsCreateResponseOutputOptionsOutputType = "ndjson" | "csv";
export type JobsCreateResponseOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export interface JobsCreateResponseOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string | null;
    /** String to be appended after each batch. */
    batchSuffix?: string | null;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string | null;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: JobsCreateResponseOutputOptionsFieldNamesList | null;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean | null;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: JobsCreateResponseOutputOptionsOutputType | null;
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string | null;
    /** String to be prepended before each record. */
    recordPrefix?: string | null;
    /** String to be appended after each record. */
    recordSuffix?: string | null;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string | null;
    /** Specifies the sampling rate as a floating number greater than 0 and at most 1. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number | null;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: JobsCreateResponseOutputOptionsTimestampFormat | null;
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateJobResponse {
    /** Unique id of the job. */
    id?: number | null;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: JobsCreateResponseDataset | null;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string | null;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean | null;
    /** If not null, the job is currently failing. Failures are usually. repetitive (example: no permissions to write to destination bucket). Only the last failure is recorded. On successful execution of a job the error_message and last_error are set to null. */
    errorMessage?: string | null;
    /** When true, excludes DDoS attack traffic from logs. This option is supported for the `http_requests`, `firewall_events`, and `network_analytics_logs` datasets. */
    filterAttackTraffic?: boolean | null;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsCreateResponseFrequency | null;
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsCreateResponseKind | null;
    /** Records the last time for which logs have been successfully pushed. If the last successful push was for logs range 2018-07-23T10:00:00Z to 2018-07-23T10:01:00Z then the value of this field will be 2018-07-23T10:01:00Z. If the job has never run or has just been enabled and hasn't run yet then the field will be empty. */
    lastComplete?: string | null;
    /** Records the last time the job failed. If not null, the job is currently. failing. If null, the job has either never failed or has run successfully at least once since last failure. See also the error_message field. */
    lastError?: string | null;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string | null;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number | null;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number | null;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number | null;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string | null;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsCreateResponseOutputOptions | null;
}
export interface CreateJobForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: JobsCreateRequestDataset | (string & {});
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean;
    /** The filters to select the events to include and/or remove from your logs. For more information, refer to [Filters](https://developers.cloudflare.com/logs/reference/filters/). */
    filter?: string;
    /** When true, excludes DDoS attack traffic from logs. This option is supported for the `http_requests`, `firewall_events`, and `network_analytics_logs` datasets. */
    filterAttackTraffic?: boolean;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsCreateRequestFrequency | (string & {});
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsCreateRequestKind | (string & {});
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsCreateRequestOutputOptions;
    /** Ownership challenge token to prove destination ownership. */
    ownershipChallenge?: string;
}
export interface CreateOwnershipForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOwnershipResponse {
    filename?: string | null;
    message?: string | null;
    valid?: boolean | null;
}
export interface CreateOwnershipForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
}
export interface CreateTransformerRequest {
    /** Identifier. */
    accountId: string;
    /** The SQL transformer query. Maximum 32 KB. The query must contain a FROM clause referencing a valid logpush dataset. */
    code: string;
    /** Customer-provided name for identification. */
    name: string;
    /** Optional customer-provided description. */
    description?: string;
}
export type CreateTransformerResponseAssociatedJobsItemObjectType = "zone" | "account";
export interface CreateTransformerResponseAssociatedJobsItem {
    /** The logpush job ID. */
    id?: number | null;
    /** The logpush job destination name. */
    name?: string | null;
    /** The zone or account tag. */
    objectTag?: string | null;
    /** Whether the job is zone-scoped or account-scoped. */
    objectType?: CreateTransformerResponseAssociatedJobsItemObjectType | null;
}
export type CreateTransformerResponseAssociatedJobsList = Array<CreateTransformerResponseAssociatedJobsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTransformerResponse {
    /** The transformer ID. */
    id?: number | null;
    /** Logpush jobs that reference this transformer. */
    associatedJobs?: CreateTransformerResponseAssociatedJobsList | null;
    /** When the transformer was created (RFC 3339). */
    createdAt?: string | null;
    /** The dataset this transformer operates on, derived from the SQL query's FROM clause. Informational only. May be absent if the dataset cannot be determined from the query. */
    dataset?: string | null;
    /** Optional customer-provided description. */
    description?: string | null;
    /** Customer-provided name for identification. */
    name?: string | null;
    /** When the transformer was last modified (RFC 3339). */
    updatedAt?: string | null;
}
export interface DeleteJobForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Unique id of the job. */
    jobId: number;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteJobResponse {
    /** Unique id of the job. */
    id?: number | null;
}
export interface DeleteJobForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Unique id of the job. */
    jobId: number;
}
export interface DeleteTransformerRequest {
    /** Identifier. */
    accountId: string;
    /** The transformer ID. */
    transformerId: number;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteTransformerResponse {
    /** The deleted transformer's ID. */
    id?: number | null;
}
export interface DestinationExistsValidateForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DestinationExistsValidateResponse {
    exists?: boolean | null;
}
export interface DestinationExistsValidateForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
}
export interface DestinationValidateForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DestinationValidateResponse {
    message?: string | null;
    valid?: boolean | null;
}
export interface DestinationValidateForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
}
export type DatasetsFieldsGetRequestDatasetId = "access_requests" | "account_abuse_protection_events" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_bgp_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export interface GetDatasetFieldForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    datasetId: DatasetsFieldsGetRequestDatasetId | (string & {});
}
export type DatasetsFieldsGetResultMap = {
    [key: string]: string | undefined;
};
export type GetDatasetFieldResponse = DatasetsFieldsGetResultMap;
export interface GetDatasetFieldForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    datasetId: DatasetsFieldsGetRequestDatasetId | (string & {});
}
export type DatasetsJobsGetRequestDatasetId = "access_requests" | "account_abuse_protection_events" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_bgp_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export interface GetDatasetJobForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    datasetId: DatasetsJobsGetRequestDatasetId | (string & {});
}
export type DatasetsJobsGetResultItemDataset = "access_requests" | "account_abuse_protection_events" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_bgp_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export type DatasetsJobsGetResultItemFrequency = "high" | "low";
export type DatasetsJobsGetResultItemKind = "" | "edge";
export type DatasetsJobsGetResultItemOutputOptionsFieldNamesList = Array<string>;
export type DatasetsJobsGetResultItemOutputOptionsOutputType = "ndjson" | "csv";
export type DatasetsJobsGetResultItemOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export interface DatasetsJobsGetResultItemOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string | null;
    /** String to be appended after each batch. */
    batchSuffix?: string | null;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string | null;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: DatasetsJobsGetResultItemOutputOptionsFieldNamesList | null;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean | null;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: DatasetsJobsGetResultItemOutputOptionsOutputType | null;
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string | null;
    /** String to be prepended before each record. */
    recordPrefix?: string | null;
    /** String to be appended after each record. */
    recordSuffix?: string | null;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string | null;
    /** Specifies the sampling rate as a floating number greater than 0 and at most 1. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number | null;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: DatasetsJobsGetResultItemOutputOptionsTimestampFormat | null;
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean | null;
}
export interface DatasetsJobsGetResultItem {
    /** Unique id of the job. */
    id?: number | null;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: DatasetsJobsGetResultItemDataset | null;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string | null;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean | null;
    /** If not null, the job is currently failing. Failures are usually. repetitive (example: no permissions to write to destination bucket). Only the last failure is recorded. On successful execution of a job the error_message and last_error are set to null. */
    errorMessage?: string | null;
    /** When true, excludes DDoS attack traffic from logs. This option is supported for the `http_requests`, `firewall_events`, and `network_analytics_logs` datasets. */
    filterAttackTraffic?: boolean | null;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: DatasetsJobsGetResultItemFrequency | null;
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: DatasetsJobsGetResultItemKind | null;
    /** Records the last time for which logs have been successfully pushed. If the last successful push was for logs range 2018-07-23T10:00:00Z to 2018-07-23T10:01:00Z then the value of this field will be 2018-07-23T10:01:00Z. If the job has never run or has just been enabled and hasn't run yet then the field will be empty. */
    lastComplete?: string | null;
    /** Records the last time the job failed. If not null, the job is currently. failing. If null, the job has either never failed or has run successfully at least once since last failure. See also the error_message field. */
    lastError?: string | null;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string | null;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number | null;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number | null;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number | null;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string | null;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: DatasetsJobsGetResultItemOutputOptions | null;
}
export type DatasetsJobsGetResultList = Array<DatasetsJobsGetResultItem>;
export interface GetDatasetJobResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DatasetsJobsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetDatasetJobForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    datasetId: DatasetsJobsGetRequestDatasetId | (string & {});
}
export interface GetEdgeRequest {
    /** Identifier. */
    zoneId: string;
}
export interface EdgeGetResultItem {
    /** Unique WebSocket address that will receive messages from Cloudflare's edge. */
    destinationConf?: string | null;
    /** Comma-separated list of fields. */
    fields?: string | null;
    /** Filters to drill down into specific events. */
    filter?: string | null;
    /** The sample parameter is the sample rate of the records set by the client: "sample": 1 is 100% of records "sample": 10 is 10% and so on. */
    sample?: number | null;
    /** Unique session id of the job. */
    sessionId?: string | null;
}
export type EdgeGetResultList = Array<EdgeGetResultItem>;
export interface GetEdgeResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: EdgeGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetJobForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Unique id of the job. */
    jobId: number;
}
export type JobsGetResponseDataset = "access_requests" | "account_abuse_protection_events" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_bgp_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export type JobsGetResponseFrequency = "high" | "low";
export type JobsGetResponseKind = "" | "edge";
export type JobsGetResponseOutputOptionsFieldNamesList = Array<string>;
export type JobsGetResponseOutputOptionsOutputType = "ndjson" | "csv";
export type JobsGetResponseOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export interface JobsGetResponseOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string | null;
    /** String to be appended after each batch. */
    batchSuffix?: string | null;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string | null;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: JobsGetResponseOutputOptionsFieldNamesList | null;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean | null;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: JobsGetResponseOutputOptionsOutputType | null;
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string | null;
    /** String to be prepended before each record. */
    recordPrefix?: string | null;
    /** String to be appended after each record. */
    recordSuffix?: string | null;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string | null;
    /** Specifies the sampling rate as a floating number greater than 0 and at most 1. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number | null;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: JobsGetResponseOutputOptionsTimestampFormat | null;
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetJobResponse {
    /** Unique id of the job. */
    id?: number | null;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: JobsGetResponseDataset | null;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string | null;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean | null;
    /** If not null, the job is currently failing. Failures are usually. repetitive (example: no permissions to write to destination bucket). Only the last failure is recorded. On successful execution of a job the error_message and last_error are set to null. */
    errorMessage?: string | null;
    /** When true, excludes DDoS attack traffic from logs. This option is supported for the `http_requests`, `firewall_events`, and `network_analytics_logs` datasets. */
    filterAttackTraffic?: boolean | null;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsGetResponseFrequency | null;
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsGetResponseKind | null;
    /** Records the last time for which logs have been successfully pushed. If the last successful push was for logs range 2018-07-23T10:00:00Z to 2018-07-23T10:01:00Z then the value of this field will be 2018-07-23T10:01:00Z. If the job has never run or has just been enabled and hasn't run yet then the field will be empty. */
    lastComplete?: string | null;
    /** Records the last time the job failed. If not null, the job is currently. failing. If null, the job has either never failed or has run successfully at least once since last failure. See also the error_message field. */
    lastError?: string | null;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string | null;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number | null;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number | null;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number | null;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string | null;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsGetResponseOutputOptions | null;
}
export interface GetJobForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Unique id of the job. */
    jobId: number;
}
export interface GetTransformerRequest {
    /** Identifier. */
    accountId: string;
    /** The transformer ID. */
    transformerId: number;
}
export type GetTransformerResponseAssociatedJobsItemObjectType = "zone" | "account";
export interface GetTransformerResponseAssociatedJobsItem {
    /** The logpush job ID. */
    id?: number | null;
    /** The logpush job destination name. */
    name?: string | null;
    /** The zone or account tag. */
    objectTag?: string | null;
    /** Whether the job is zone-scoped or account-scoped. */
    objectType?: GetTransformerResponseAssociatedJobsItemObjectType | null;
}
export type GetTransformerResponseAssociatedJobsList = Array<GetTransformerResponseAssociatedJobsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTransformerResponse {
    /** The transformer ID. */
    id?: number | null;
    /** Logpush jobs that reference this transformer. */
    associatedJobs?: GetTransformerResponseAssociatedJobsList | null;
    /** When the transformer was created (RFC 3339). */
    createdAt?: string | null;
    /** The dataset this transformer operates on, derived from the SQL query's FROM clause. Informational only. May be absent if the dataset cannot be determined from the query. */
    dataset?: string | null;
    /** Optional customer-provided description. */
    description?: string | null;
    /** Customer-provided name for identification. */
    name?: string | null;
    /** When the transformer was last modified (RFC 3339). */
    updatedAt?: string | null;
}
export interface GetTransformersContentRequest {
    /** Identifier. */
    accountId: string;
    /** The transformer ID. */
    transformerId: number;
    /** Specific version ID to retrieve. When omitted, the latest version is returned. */
    versionId?: number;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTransformersContentResponse {
    /** The SQL query content. */
    content?: string | null;
}
export interface ListJobsForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
}
export type JobsListResultItemDataset = "access_requests" | "account_abuse_protection_events" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_bgp_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export type JobsListResultItemFrequency = "high" | "low";
export type JobsListResultItemKind = "" | "edge";
export type JobsListResultItemOutputOptionsFieldNamesList = Array<string>;
export type JobsListResultItemOutputOptionsOutputType = "ndjson" | "csv";
export type JobsListResultItemOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export interface JobsListResultItemOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string | null;
    /** String to be appended after each batch. */
    batchSuffix?: string | null;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string | null;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: JobsListResultItemOutputOptionsFieldNamesList | null;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean | null;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: JobsListResultItemOutputOptionsOutputType | null;
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string | null;
    /** String to be prepended before each record. */
    recordPrefix?: string | null;
    /** String to be appended after each record. */
    recordSuffix?: string | null;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string | null;
    /** Specifies the sampling rate as a floating number greater than 0 and at most 1. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number | null;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: JobsListResultItemOutputOptionsTimestampFormat | null;
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean | null;
}
export interface JobsListResultItem {
    /** Unique id of the job. */
    id?: number | null;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: JobsListResultItemDataset | null;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string | null;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean | null;
    /** If not null, the job is currently failing. Failures are usually. repetitive (example: no permissions to write to destination bucket). Only the last failure is recorded. On successful execution of a job the error_message and last_error are set to null. */
    errorMessage?: string | null;
    /** When true, excludes DDoS attack traffic from logs. This option is supported for the `http_requests`, `firewall_events`, and `network_analytics_logs` datasets. */
    filterAttackTraffic?: boolean | null;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsListResultItemFrequency | null;
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsListResultItemKind | null;
    /** Records the last time for which logs have been successfully pushed. If the last successful push was for logs range 2018-07-23T10:00:00Z to 2018-07-23T10:01:00Z then the value of this field will be 2018-07-23T10:01:00Z. If the job has never run or has just been enabled and hasn't run yet then the field will be empty. */
    lastComplete?: string | null;
    /** Records the last time the job failed. If not null, the job is currently. failing. If null, the job has either never failed or has run successfully at least once since last failure. See also the error_message field. */
    lastError?: string | null;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string | null;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number | null;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number | null;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number | null;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string | null;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsListResultItemOutputOptions | null;
}
export type JobsListResultList = Array<JobsListResultItem>;
export interface ListJobsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: JobsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListJobsForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
}
export interface ListTransformersRequest {
    /** Identifier. */
    accountId: string;
}
export type ListTransformersResultItemAssociatedJobsItemObjectType = "zone" | "account";
export interface ListTransformersResultItemAssociatedJobsItem {
    /** The logpush job ID. */
    id?: number | null;
    /** The logpush job destination name. */
    name?: string | null;
    /** The zone or account tag. */
    objectTag?: string | null;
    /** Whether the job is zone-scoped or account-scoped. */
    objectType?: ListTransformersResultItemAssociatedJobsItemObjectType | null;
}
export type ListTransformersResultItemAssociatedJobsList = Array<ListTransformersResultItemAssociatedJobsItem>;
export interface ListTransformersResultItem {
    /** The transformer ID. */
    id?: number | null;
    /** Logpush jobs that reference this transformer. */
    associatedJobs?: ListTransformersResultItemAssociatedJobsList | null;
    /** When the transformer was created (RFC 3339). */
    createdAt?: string | null;
    /** The dataset this transformer operates on, derived from the SQL query's FROM clause. Informational only. May be absent if the dataset cannot be determined from the query. */
    dataset?: string | null;
    /** Optional customer-provided description. */
    description?: string | null;
    /** Customer-provided name for identification. */
    name?: string | null;
    /** When the transformer was last modified (RFC 3339). */
    updatedAt?: string | null;
}
export type ListTransformersResultList = Array<ListTransformersResultItem>;
export type ListTransformersResponse = ListTransformersResultList;
export interface ListTransformersVersionsRequest {
    /** Identifier. */
    accountId: string;
    /** The transformer ID. */
    transformerId: number;
    /** Maximum number of versions to return. */
    limit?: number;
}
export interface ListTransformersVersionsResultItem {
    /** Unique identifier for this version. */
    id?: number | null;
    /** When this version was created (RFC 3339). */
    createdAt?: string | null;
    /** Sequential version number. */
    version?: number | null;
}
export type ListTransformersVersionsResultList = Array<ListTransformersVersionsResultItem>;
export type ListTransformersVersionsResponse = ListTransformersVersionsResultList;
export interface OriginValidateForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginValidateResponse {
    message?: string | null;
    valid?: boolean | null;
}
export interface OriginValidateForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions: string;
}
export type PreviewTransformerRequestInputMap = {
    [key: string]: unknown | undefined;
};
export interface PreviewTransformerRequest {
    /** Identifier. */
    accountId: string;
    /** A single log record to transform (JSON object). */
    input: PreviewTransformerRequestInputMap;
    /** The SQL transformer query. Maximum 32 KB. The query must contain a FROM clause referencing a valid logpush dataset. */
    sql: string;
}
export type PreviewTransformerResultItemMap = {
    [key: string]: unknown | undefined;
};
export type PreviewTransformerResultList = Array<PreviewTransformerResultItemMap>;
export type PreviewTransformerResponse = PreviewTransformerResultList;
export type JobsUpdateRequestFrequency = "high" | "low";
export type JobsUpdateRequestKind = "" | "edge";
export type JobsUpdateRequestOutputOptionsFieldNamesList = Array<string>;
export type JobsUpdateRequestOutputOptionsOutputType = "ndjson" | "csv";
export type JobsUpdateRequestOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export interface JobsUpdateRequestOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string;
    /** String to be appended after each batch. */
    batchSuffix?: string;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: JobsUpdateRequestOutputOptionsFieldNamesList;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: JobsUpdateRequestOutputOptionsOutputType | (string & {});
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string;
    /** String to be prepended before each record. */
    recordPrefix?: string;
    /** String to be appended after each record. */
    recordSuffix?: string;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string;
    /** Specifies the sampling rate as a floating number greater than 0 and at most 1. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: JobsUpdateRequestOutputOptionsTimestampFormat | (string & {});
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean;
}
export interface UpdateJobForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Unique id of the job. */
    jobId: number;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean;
    /** The filters to select the events to include and/or remove from your logs. For more information, refer to [Filters](https://developers.cloudflare.com/logs/reference/filters/). */
    filter?: string;
    /** When true, excludes DDoS attack traffic from logs. This option is supported for the `http_requests`, `firewall_events`, and `network_analytics_logs` datasets. */
    filterAttackTraffic?: boolean;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsUpdateRequestFrequency | (string & {});
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsUpdateRequestKind | (string & {});
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsUpdateRequestOutputOptions;
    /** Ownership challenge token to prove destination ownership. */
    ownershipChallenge?: string;
}
export type JobsUpdateResponseDataset = "access_requests" | "account_abuse_protection_events" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_bgp_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export type JobsUpdateResponseFrequency = "high" | "low";
export type JobsUpdateResponseKind = "" | "edge";
export type JobsUpdateResponseOutputOptionsFieldNamesList = Array<string>;
export type JobsUpdateResponseOutputOptionsOutputType = "ndjson" | "csv";
export type JobsUpdateResponseOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export interface JobsUpdateResponseOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string | null;
    /** String to be appended after each batch. */
    batchSuffix?: string | null;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string | null;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: JobsUpdateResponseOutputOptionsFieldNamesList | null;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean | null;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: JobsUpdateResponseOutputOptionsOutputType | null;
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string | null;
    /** String to be prepended before each record. */
    recordPrefix?: string | null;
    /** String to be appended after each record. */
    recordSuffix?: string | null;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string | null;
    /** Specifies the sampling rate as a floating number greater than 0 and at most 1. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number | null;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: JobsUpdateResponseOutputOptionsTimestampFormat | null;
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateJobResponse {
    /** Unique id of the job. */
    id?: number | null;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: JobsUpdateResponseDataset | null;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string | null;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean | null;
    /** If not null, the job is currently failing. Failures are usually. repetitive (example: no permissions to write to destination bucket). Only the last failure is recorded. On successful execution of a job the error_message and last_error are set to null. */
    errorMessage?: string | null;
    /** When true, excludes DDoS attack traffic from logs. This option is supported for the `http_requests`, `firewall_events`, and `network_analytics_logs` datasets. */
    filterAttackTraffic?: boolean | null;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsUpdateResponseFrequency | null;
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsUpdateResponseKind | null;
    /** Records the last time for which logs have been successfully pushed. If the last successful push was for logs range 2018-07-23T10:00:00Z to 2018-07-23T10:01:00Z then the value of this field will be 2018-07-23T10:01:00Z. If the job has never run or has just been enabled and hasn't run yet then the field will be empty. */
    lastComplete?: string | null;
    /** Records the last time the job failed. If not null, the job is currently. failing. If null, the job has either never failed or has run successfully at least once since last failure. See also the error_message field. */
    lastError?: string | null;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string | null;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number | null;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number | null;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number | null;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string | null;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsUpdateResponseOutputOptions | null;
}
export interface UpdateJobForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Unique id of the job. */
    jobId: number;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean;
    /** The filters to select the events to include and/or remove from your logs. For more information, refer to [Filters](https://developers.cloudflare.com/logs/reference/filters/). */
    filter?: string;
    /** When true, excludes DDoS attack traffic from logs. This option is supported for the `http_requests`, `firewall_events`, and `network_analytics_logs` datasets. */
    filterAttackTraffic?: boolean;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsUpdateRequestFrequency | (string & {});
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsUpdateRequestKind | (string & {});
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsUpdateRequestOutputOptions;
    /** Ownership challenge token to prove destination ownership. */
    ownershipChallenge?: string;
}
export interface UpdateTransformerRequest {
    /** Identifier. */
    accountId: string;
    /** The transformer ID. */
    transformerId: number;
    /** Customer-provided name for identification. */
    name: string;
    /** The SQL transformer query. Maximum 32 KB. The query must contain a FROM clause referencing a valid logpush dataset. */
    code?: string;
    /** Optional customer-provided description. */
    description?: string;
}
export type UpdateTransformerResponseAssociatedJobsItemObjectType = "zone" | "account";
export interface UpdateTransformerResponseAssociatedJobsItem {
    /** The logpush job ID. */
    id?: number | null;
    /** The logpush job destination name. */
    name?: string | null;
    /** The zone or account tag. */
    objectTag?: string | null;
    /** Whether the job is zone-scoped or account-scoped. */
    objectType?: UpdateTransformerResponseAssociatedJobsItemObjectType | null;
}
export type UpdateTransformerResponseAssociatedJobsList = Array<UpdateTransformerResponseAssociatedJobsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTransformerResponse {
    /** The transformer ID. */
    id?: number | null;
    /** Logpush jobs that reference this transformer. */
    associatedJobs?: UpdateTransformerResponseAssociatedJobsList | null;
    /** When the transformer was created (RFC 3339). */
    createdAt?: string | null;
    /** The dataset this transformer operates on, derived from the SQL query's FROM clause. Informational only. May be absent if the dataset cannot be determined from the query. */
    dataset?: string | null;
    /** Optional customer-provided description. */
    description?: string | null;
    /** Customer-provided name for identification. */
    name?: string | null;
    /** When the transformer was last modified (RFC 3339). */
    updatedAt?: string | null;
}
export interface ValidateOwnershipForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
    /** Ownership challenge token to prove destination ownership. */
    ownershipChallenge: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ValidateOwnershipResponse {
    valid?: boolean | null;
}
export interface ValidateOwnershipForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
    /** Ownership challenge token to prove destination ownership. */
    ownershipChallenge: string;
}
export type CreateEdgeError = CloudflareOpError;
/** Creates a new Instant Logs job for a zone. */
export declare const createEdge: API.OperationMethod<CreateEdgeRequest, CreateEdgeResponse, CreateEdgeError, CloudflareOpContext>;
export type CreateJobForAccountError = CloudflareOpError;
/** Creates a new Logpush job for an account or zone. */
export declare const createJobForAccount: API.OperationMethod<CreateJobForAccountRequest, CreateJobResponse, CreateJobForAccountError, CloudflareOpContext>;
export type CreateJobForZoneError = CloudflareOpError;
/** Creates a new Logpush job for an account or zone. */
export declare const createJobForZone: API.OperationMethod<CreateJobForZoneRequest, CreateJobResponse, CreateJobForZoneError, CloudflareOpContext>;
export type CreateOwnershipForAccountError = CloudflareOpError;
/** Gets a new ownership challenge sent to your destination. */
export declare const createOwnershipForAccount: API.OperationMethod<CreateOwnershipForAccountRequest, CreateOwnershipResponse, CreateOwnershipForAccountError, CloudflareOpContext>;
export type CreateOwnershipForZoneError = CloudflareOpError;
/** Gets a new ownership challenge sent to your destination. */
export declare const createOwnershipForZone: API.OperationMethod<CreateOwnershipForZoneRequest, CreateOwnershipResponse, CreateOwnershipForZoneError, CloudflareOpContext>;
export type CreateTransformerError = CloudflareOpError;
/** Creates a new custom log transformer for an account. */
export declare const createTransformer: API.OperationMethod<CreateTransformerRequest, CreateTransformerResponse, CreateTransformerError, CloudflareOpContext>;
export type DeleteJobForAccountError = JobNotFound | CloudflareOpError;
/** Deletes a Logpush job. */
export declare const deleteJobForAccount: API.OperationMethod<DeleteJobForAccountRequest, DeleteJobResponse, DeleteJobForAccountError, CloudflareOpContext>;
export type DeleteJobForZoneError = JobNotFound | CloudflareOpError;
/** Deletes a Logpush job. */
export declare const deleteJobForZone: API.OperationMethod<DeleteJobForZoneRequest, DeleteJobResponse, DeleteJobForZoneError, CloudflareOpContext>;
export type DeleteTransformerError = CloudflareOpError;
/** Deletes a custom log transformer. Returns 409 Conflict if any active logpush jobs reference the transformer. */
export declare const deleteTransformer: API.OperationMethod<DeleteTransformerRequest, DeleteTransformerResponse, DeleteTransformerError, CloudflareOpContext>;
export type DestinationExistsValidateForAccountError = CloudflareOpError;
/** Checks if there is an existing job with a destination. */
export declare const destinationExistsValidateForAccount: API.OperationMethod<DestinationExistsValidateForAccountRequest, DestinationExistsValidateResponse, DestinationExistsValidateForAccountError, CloudflareOpContext>;
export type DestinationExistsValidateForZoneError = CloudflareOpError;
/** Checks if there is an existing job with a destination. */
export declare const destinationExistsValidateForZone: API.OperationMethod<DestinationExistsValidateForZoneRequest, DestinationExistsValidateResponse, DestinationExistsValidateForZoneError, CloudflareOpContext>;
export type DestinationValidateForAccountError = CloudflareOpError;
/** Validates destination. */
export declare const destinationValidateForAccount: API.OperationMethod<DestinationValidateForAccountRequest, DestinationValidateResponse, DestinationValidateForAccountError, CloudflareOpContext>;
export type DestinationValidateForZoneError = CloudflareOpError;
/** Validates destination. */
export declare const destinationValidateForZone: API.OperationMethod<DestinationValidateForZoneRequest, DestinationValidateResponse, DestinationValidateForZoneError, CloudflareOpContext>;
export type GetDatasetFieldForAccountError = CloudflareOpError;
/** Lists all fields available for a dataset. The response result is. an object with key-value pairs, where keys are field names, and values are descriptions. */
export declare const getDatasetFieldForAccount: API.OperationMethod<GetDatasetFieldForAccountRequest, GetDatasetFieldResponse, GetDatasetFieldForAccountError, CloudflareOpContext>;
export type GetDatasetFieldForZoneError = CloudflareOpError;
/** Lists all fields available for a dataset. The response result is. an object with key-value pairs, where keys are field names, and values are descriptions. */
export declare const getDatasetFieldForZone: API.OperationMethod<GetDatasetFieldForZoneRequest, GetDatasetFieldResponse, GetDatasetFieldForZoneError, CloudflareOpContext>;
export type GetDatasetJobForAccountError = CloudflareOpError;
/** Lists Logpush jobs for an account or zone for a dataset. */
export declare const getDatasetJobForAccount: API.PaginatedOperationMethod<GetDatasetJobForAccountRequest, GetDatasetJobResponse, GetDatasetJobForAccountError, CloudflareOpContext, DatasetsJobsGetResultItem>;
export type GetDatasetJobForZoneError = CloudflareOpError;
/** Lists Logpush jobs for an account or zone for a dataset. */
export declare const getDatasetJobForZone: API.PaginatedOperationMethod<GetDatasetJobForZoneRequest, GetDatasetJobResponse, GetDatasetJobForZoneError, CloudflareOpContext, DatasetsJobsGetResultItem>;
export type GetEdgeError = CloudflareOpError;
/** Lists Instant Logs jobs for a zone. */
export declare const getEdge: API.PaginatedOperationMethod<GetEdgeRequest, GetEdgeResponse, GetEdgeError, CloudflareOpContext, EdgeGetResultItem>;
export type GetJobForAccountError = JobNotFound | Forbidden | CloudflareOpError;
/** Gets the details of a Logpush job. */
export declare const getJobForAccount: API.OperationMethod<GetJobForAccountRequest, GetJobResponse, GetJobForAccountError, CloudflareOpContext>;
export type GetJobForZoneError = JobNotFound | Forbidden | CloudflareOpError;
/** Gets the details of a Logpush job. */
export declare const getJobForZone: API.OperationMethod<GetJobForZoneRequest, GetJobResponse, GetJobForZoneError, CloudflareOpContext>;
export type GetTransformerError = CloudflareOpError;
/** Gets a single custom log transformer by ID. */
export declare const getTransformer: API.OperationMethod<GetTransformerRequest, GetTransformerResponse, GetTransformerError, CloudflareOpContext>;
export type GetTransformersContentError = CloudflareOpError;
/** Returns the SQL query content for a transformer. Without query params, returns the latest version. With `version_id`, returns the specified version. */
export declare const getTransformersContent: API.OperationMethod<GetTransformersContentRequest, GetTransformersContentResponse, GetTransformersContentError, CloudflareOpContext>;
export type ListJobsForAccountError = Forbidden | NotFound | CloudflareOpError;
/** Lists Logpush jobs for an account or zone. */
export declare const listJobsForAccount: API.PaginatedOperationMethod<ListJobsForAccountRequest, ListJobsResponse, ListJobsForAccountError, CloudflareOpContext, JobsListResultItem>;
export type ListJobsForZoneError = Forbidden | NotFound | CloudflareOpError;
/** Lists Logpush jobs for an account or zone. */
export declare const listJobsForZone: API.PaginatedOperationMethod<ListJobsForZoneRequest, ListJobsResponse, ListJobsForZoneError, CloudflareOpContext, JobsListResultItem>;
export type ListTransformersError = CloudflareOpError;
/** Lists all custom log transformers for an account. */
export declare const listTransformers: API.OperationMethod<ListTransformersRequest, ListTransformersResponse, ListTransformersError, CloudflareOpContext>;
export type ListTransformersVersionsError = CloudflareOpError;
/** Returns version metadata for a transformer, newest first. Each version corresponds to a SQL query update. */
export declare const listTransformersVersions: API.OperationMethod<ListTransformersVersionsRequest, ListTransformersVersionsResponse, ListTransformersVersionsError, CloudflareOpContext>;
export type OriginValidateForAccountError = CloudflareOpError;
/** Validates logpull origin with logpull_options. */
export declare const originValidateForAccount: API.OperationMethod<OriginValidateForAccountRequest, OriginValidateResponse, OriginValidateForAccountError, CloudflareOpContext>;
export type OriginValidateForZoneError = CloudflareOpError;
/** Validates logpull origin with logpull_options. */
export declare const originValidateForZone: API.OperationMethod<OriginValidateForZoneRequest, OriginValidateResponse, OriginValidateForZoneError, CloudflareOpContext>;
export type PreviewTransformerError = CloudflareOpError;
/** Executes a SQL transformer against a single input record and returns the transformed output. This is a stateless endpoint -- nothing is persisted. */
export declare const previewTransformer: API.OperationMethod<PreviewTransformerRequest, PreviewTransformerResponse, PreviewTransformerError, CloudflareOpContext>;
export type UpdateJobForAccountError = CloudflareOpError;
/** Updates a Logpush job. */
export declare const updateJobForAccount: API.OperationMethod<UpdateJobForAccountRequest, UpdateJobResponse, UpdateJobForAccountError, CloudflareOpContext>;
export type UpdateJobForZoneError = CloudflareOpError;
/** Updates a Logpush job. */
export declare const updateJobForZone: API.OperationMethod<UpdateJobForZoneRequest, UpdateJobResponse, UpdateJobForZoneError, CloudflareOpContext>;
export type UpdateTransformerError = CloudflareOpError;
/** Updates an existing custom log transformer. When `code` is provided, the SQL query is validated and a new version is created. When `code` is omitted, only the name and description are updated. Omitting `description` clears the existing description. */
export declare const updateTransformer: API.OperationMethod<UpdateTransformerRequest, UpdateTransformerResponse, UpdateTransformerError, CloudflareOpContext>;
export type ValidateOwnershipForAccountError = CloudflareOpError;
/** Validates ownership challenge of the destination. */
export declare const validateOwnershipForAccount: API.OperationMethod<ValidateOwnershipForAccountRequest, ValidateOwnershipResponse, ValidateOwnershipForAccountError, CloudflareOpContext>;
export type ValidateOwnershipForZoneError = CloudflareOpError;
/** Validates ownership challenge of the destination. */
export declare const validateOwnershipForZone: API.OperationMethod<ValidateOwnershipForZoneRequest, ValidateOwnershipResponse, ValidateOwnershipForZoneError, CloudflareOpContext>;
//# sourceMappingURL=logpush.d.ts.map