import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface GetCsamScannerRequest {
    /** Identifier for the zone. */
    zoneId: string;
}
export type GetResponseId = "csam_scanner";
export type GetResponseValueEmailState = "valid" | "pending" | "unverified";
export type GetResponseValueSourcesMap = {
    [key: string]: boolean | undefined;
};
export interface GetResponseValue {
    /** Notification email address for CSAM scan results. Masked in responses unless explicitly unmasked via admin endpoint. */
    email?: string | null;
    /** Current verification state of the notification email. */
    emailState?: GetResponseValueEmailState | null;
    /** Whether CSAM scanning is enabled for this zone. */
    enabled?: boolean | null;
    /** Map of scanning sources and their enabled state. */
    sources?: GetResponseValueSourcesMap | null;
    /** The zone's plan level. */
    zonePlan?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCsamScannerResponse {
    /** The feature identifier. */
    id?: GetResponseId | null;
    /** Whether the feature state can be changed. When false, the zone or account may be locked by Trust &amp; Safety. */
    editable?: boolean | null;
    /** When the setting was last modified. Currently always null as the server does not populate this field. */
    modifiedOn?: string | null;
    /** The CSAM Scanner feature configuration values. Contains the notification email and scanning enablement settings. */
    value?: GetResponseValue | null;
}
export type EditRequestId = "csam_scanner";
export type EditRequestValueSourcesMap = {
    [key: string]: boolean | undefined;
};
export interface EditRequestValue {
    /** Notification email address for CSAM scan results. When changed, email verification is triggered automatically. */
    email?: string;
    /** Whether CSAM scanning is enabled for this zone. */
    enabled?: boolean;
    /** Set to true to trigger re-sending the email verification. Write-only; never appears in responses (omitted when false). */
    resendEmail?: boolean;
    /** Map of scanning sources and their enabled state. */
    sources?: EditRequestValueSourcesMap;
}
export interface PatchCsamScannerRequest {
    /** Identifier for the zone. */
    zoneId: string;
    /** The feature identifier. */
    id?: EditRequestId | (string & {});
    /** Writable CSAM Scanner feature configuration values. */
    value?: EditRequestValue;
}
export type EditResponseId = "csam_scanner";
export type EditResponseValueEmailState = "valid" | "pending" | "unverified";
export type EditResponseValueSourcesMap = {
    [key: string]: boolean | undefined;
};
export interface EditResponseValue {
    /** Notification email address for CSAM scan results. Masked in responses unless explicitly unmasked via admin endpoint. */
    email?: string | null;
    /** Current verification state of the notification email. */
    emailState?: EditResponseValueEmailState | null;
    /** Whether CSAM scanning is enabled for this zone. */
    enabled?: boolean | null;
    /** Map of scanning sources and their enabled state. */
    sources?: EditResponseValueSourcesMap | null;
    /** The zone's plan level. */
    zonePlan?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCsamScannerResponse {
    /** The feature identifier. */
    id?: EditResponseId | null;
    /** Whether the feature state can be changed. When false, the zone or account may be locked by Trust &amp; Safety. */
    editable?: boolean | null;
    /** When the setting was last modified. Currently always null as the server does not populate this field. */
    modifiedOn?: string | null;
    /** The CSAM Scanner feature configuration values. Contains the notification email and scanning enablement settings. */
    value?: EditResponseValue | null;
}
export type GetCsamScannerError = CloudflareOpError;
/** Retrieve the current CSAM Scanner configuration for a zone. The notification email is masked by default in responses. */
export declare const getCsamScanner: API.OperationMethod<GetCsamScannerRequest, GetCsamScannerResponse, GetCsamScannerError, CloudflareOpContext>;
export type PatchCsamScannerError = CloudflareOpError;
/** Update the CSAM Scanner configuration for a zone. Allows enabling or disabling CSAM scanning, updating the notification email, and configuring scanning sources. When a new email is provided, email verification is triggered automatically. The `enabled` field is a toggle; the server may adjust it based on whether the notification email is verified. Returns 403 if the zone or account is locked by Trust & Safety. */
export declare const patchCsamScanner: API.OperationMethod<PatchCsamScannerRequest, PatchCsamScannerResponse, PatchCsamScannerError, CloudflareOpContext>;
//# sourceMappingURL=csam_scanner.d.ts.map