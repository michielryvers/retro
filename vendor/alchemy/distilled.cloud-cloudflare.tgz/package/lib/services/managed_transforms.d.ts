import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface DeleteManagedTransformRequest {
    /** The unique ID of the zone. */
    zoneId: string;
}
export interface DeleteManagedTransformResponse {
}
export interface ListManagedTransformsRequest {
    /** The unique ID of the zone. */
    zoneId: string;
}
export type ListResponseManagedRequestHeadersItemConflictsWithList = Array<string>;
export interface ListResponseManagedRequestHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: ListResponseManagedRequestHeadersItemConflictsWithList | null;
}
export type ListResponseManagedRequestHeadersList = Array<ListResponseManagedRequestHeadersItem>;
export type ListResponseManagedResponseHeadersItemConflictsWithList = Array<string>;
export interface ListResponseManagedResponseHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: ListResponseManagedResponseHeadersItemConflictsWithList | null;
}
export type ListResponseManagedResponseHeadersList = Array<ListResponseManagedResponseHeadersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListManagedTransformsResponse {
    /** The list of Managed Request Transforms. */
    managedRequestHeaders: ListResponseManagedRequestHeadersList;
    /** The list of Managed Response Transforms. */
    managedResponseHeaders: ListResponseManagedResponseHeadersList;
}
export type EditRequestManagedRequestHeadersItemConflictsWithList = Array<string>;
export interface EditRequestManagedRequestHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict?: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: EditRequestManagedRequestHeadersItemConflictsWithList;
}
export type EditRequestManagedRequestHeadersList = Array<EditRequestManagedRequestHeadersItem>;
export type EditRequestManagedResponseHeadersItemConflictsWithList = Array<string>;
export interface EditRequestManagedResponseHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict?: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: EditRequestManagedResponseHeadersItemConflictsWithList;
}
export type EditRequestManagedResponseHeadersList = Array<EditRequestManagedResponseHeadersItem>;
export interface PatchManagedTransformRequest {
    /** The unique ID of the zone. */
    zoneId: string;
    /** The list of Managed Request Transforms. */
    managedRequestHeaders?: EditRequestManagedRequestHeadersList;
    /** The list of Managed Response Transforms. */
    managedResponseHeaders?: EditRequestManagedResponseHeadersList;
}
export type EditResponseManagedRequestHeadersItemConflictsWithList = Array<string>;
export interface EditResponseManagedRequestHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: EditResponseManagedRequestHeadersItemConflictsWithList | null;
}
export type EditResponseManagedRequestHeadersList = Array<EditResponseManagedRequestHeadersItem>;
export type EditResponseManagedResponseHeadersItemConflictsWithList = Array<string>;
export interface EditResponseManagedResponseHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: EditResponseManagedResponseHeadersItemConflictsWithList | null;
}
export type EditResponseManagedResponseHeadersList = Array<EditResponseManagedResponseHeadersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchManagedTransformResponse {
    /** The list of Managed Request Transforms. */
    managedRequestHeaders: EditResponseManagedRequestHeadersList;
    /** The list of Managed Response Transforms. */
    managedResponseHeaders: EditResponseManagedResponseHeadersList;
}
export type DeleteManagedTransformError = Forbidden | CloudflareOpError;
/** Disables all Managed Transforms. */
export declare const deleteManagedTransform: API.OperationMethod<DeleteManagedTransformRequest, DeleteManagedTransformResponse, DeleteManagedTransformError, CloudflareOpContext>;
export type ListManagedTransformsError = Forbidden | CloudflareOpError;
/** Fetches a list of all Managed Transforms. */
export declare const listManagedTransforms: API.OperationMethod<ListManagedTransformsRequest, ListManagedTransformsResponse, ListManagedTransformsError, CloudflareOpContext>;
export type PatchManagedTransformError = Forbidden | CloudflareOpError;
/** Updates the status of one or more Managed Transforms. */
export declare const patchManagedTransform: API.OperationMethod<PatchManagedTransformRequest, PatchManagedTransformResponse, PatchManagedTransformError, CloudflareOpContext>;
//# sourceMappingURL=managed_transforms.d.ts.map