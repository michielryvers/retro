import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const DetectionAlreadyExists_base: S.TaggedErrorClass<"DetectionAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DetectionAlreadyExists extends /*@__PURE__*/ DetectionAlreadyExists_base {
}
declare const DetectionNotFound_base: S.TaggedErrorClass<"DetectionNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DetectionNotFound extends /*@__PURE__*/ DetectionNotFound_base {
}
declare const DetectionQuotaExceeded_base: S.TaggedErrorClass<"DetectionQuotaExceeded", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DetectionQuotaExceeded extends /*@__PURE__*/ DetectionQuotaExceeded_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const LeakedCredentialChecksDisabled_base: S.TaggedErrorClass<"LeakedCredentialChecksDisabled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class LeakedCredentialChecksDisabled extends /*@__PURE__*/ LeakedCredentialChecksDisabled_base {
}
export interface CreateDetectionRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines ehe ruleset expression to use in matching the password in a request. */
    password?: string;
    /** Defines the ruleset expression to use in matching the username in a request. */
    username?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDetectionResponse {
    /** Defines the unique ID for this custom detection. */
    id?: string | null;
    /** Defines ehe ruleset expression to use in matching the password in a request. */
    password?: string | null;
    /** Defines the ruleset expression to use in matching the username in a request. */
    username?: string | null;
}
export interface CreateLeakedCredentialCheckRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Determines whether or not Leaked Credential Checks are enabled. */
    enabled?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLeakedCredentialCheckResponse {
    /** Determines whether or not Leaked Credential Checks are enabled. */
    enabled?: boolean | null;
}
export interface DeleteDetectionRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique ID for this custom detection. */
    detectionId: string;
}
export type DeleteDetectionResponse = unknown;
export interface GetDetectionRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique ID for this custom detection. */
    detectionId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDetectionResponse {
    /** Defines the unique ID for this custom detection. */
    id?: string | null;
    /** Defines ehe ruleset expression to use in matching the password in a request. */
    password?: string | null;
    /** Defines the ruleset expression to use in matching the username in a request. */
    username?: string | null;
}
export interface GetLeakedCredentialCheckRequest {
    /** Defines an identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLeakedCredentialCheckResponse {
    /** Determines whether or not Leaked Credential Checks are enabled. */
    enabled?: boolean | null;
}
export interface ListDetectionsRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export interface DetectionsListResultItem {
    /** Defines the unique ID for this custom detection. */
    id?: string | null;
    /** Defines ehe ruleset expression to use in matching the password in a request. */
    password?: string | null;
    /** Defines the ruleset expression to use in matching the username in a request. */
    username?: string | null;
}
export type DetectionsListResultList = Array<DetectionsListResultItem>;
export interface ListDetectionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DetectionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface UpdateDetectionRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique ID for this custom detection. */
    detectionId: string;
    /** Defines ehe ruleset expression to use in matching the password in a request. */
    password?: string;
    /** Defines the ruleset expression to use in matching the username in a request. */
    username?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateDetectionResponse {
    /** Defines the unique ID for this custom detection. */
    id?: string | null;
    /** Defines ehe ruleset expression to use in matching the password in a request. */
    password?: string | null;
    /** Defines the ruleset expression to use in matching the username in a request. */
    username?: string | null;
}
export type CreateDetectionError = DetectionQuotaExceeded | LeakedCredentialChecksDisabled | Forbidden | DetectionAlreadyExists | CloudflareOpError;
/** Create a detection location for credentials that the default scan locations do not cover, using Rules language expressions such as `lookup_json_string(http.request.body.raw, "user")`. Only the username expression is required, and Leaked Credential Checks must be enabled on the zone. */
export declare const createDetection: API.OperationMethod<CreateDetectionRequest, CreateDetectionResponse, CreateDetectionError, CloudflareOpContext>;
export type CreateLeakedCredentialCheckError = Forbidden | CloudflareOpError;
/** Update the Leaked Credential Checks status for the zone, enabling or disabling the detection. While enabled, the detection populates the `cf.waf.credential_check.*` fields, which you can reference in custom rules and rate limiting rules to challenge or block requests carrying compromised credentials. */
export declare const createLeakedCredentialCheck: API.OperationMethod<CreateLeakedCredentialCheckRequest, CreateLeakedCredentialCheckResponse, CreateLeakedCredentialCheckError, CloudflareOpContext>;
export type DeleteDetectionError = DetectionNotFound | LeakedCredentialChecksDisabled | Forbidden | CloudflareOpError;
/** Delete a user-defined detection location, identified by its detection ID. Incoming requests are then scanned using only the default scan locations and the detection locations that remain. */
export declare const deleteDetection: API.OperationMethod<DeleteDetectionRequest, DeleteDetectionResponse, DeleteDetectionError, CloudflareOpContext>;
export type GetDetectionError = DetectionNotFound | LeakedCredentialChecksDisabled | Forbidden | CloudflareOpError;
/** Get the username and password expressions of a single user-defined detection location, identified by its detection ID. */
export declare const getDetection: API.OperationMethod<GetDetectionRequest, GetDetectionResponse, GetDetectionError, CloudflareOpContext>;
export type GetLeakedCredentialCheckError = Forbidden | CloudflareOpError;
/** Get the current Leaked Credential Checks status for the zone. While enabled, Cloudflare scans incoming requests for usernames and passwords that were exposed in known data breaches. */
export declare const getLeakedCredentialCheck: API.OperationMethod<GetLeakedCredentialCheckRequest, GetLeakedCredentialCheckResponse, GetLeakedCredentialCheckError, CloudflareOpContext>;
export type ListDetectionsError = LeakedCredentialChecksDisabled | Forbidden | CloudflareOpError;
/** List the user-defined detection locations configured for Leaked Credential Checks, each with its own identifier. A custom detection location tells the WAF where to find the username and password in requests to your application. */
export declare const listDetections: API.PaginatedOperationMethod<ListDetectionsRequest, ListDetectionsResponse, ListDetectionsError, CloudflareOpContext, DetectionsListResultItem>;
export type UpdateDetectionError = DetectionNotFound | LeakedCredentialChecksDisabled | Forbidden | DetectionAlreadyExists | CloudflareOpError;
/** Update the username and password expressions of an existing detection location, identified by its detection ID. Both expressions are overwritten, so omitting the password expression clears it. */
export declare const updateDetection: API.OperationMethod<UpdateDetectionRequest, UpdateDetectionResponse, UpdateDetectionError, CloudflareOpContext>;
//# sourceMappingURL=leaked_credential_checks.d.ts.map