import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CreateRelayRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    /** Human-readable name for the relay. */
    name: string;
}
export interface RelaysCreateResponseConfigUpstreamsUpstreamsItem {
    /** Upstream MOQT server publisher URL. Must be an absolute URL with a host and a scheme the relay can dial: moqt:// (raw QUIC) or https:// (WebTransport). Validated on update (PUT); rejected with 21013. */
    url: string;
}
export type RelaysCreateResponseConfigUpstreamsUpstreamsList = Array<RelaysCreateResponseConfigUpstreamsUpstreamsItem>;
export interface RelaysCreateResponseConfigUpstreams {
    enabled?: boolean | null;
    /** Ordered list of upstream MOQT server publishers. Each entry is an object (not a bare string) so per-upstream configuration can be added in the future without another breaking change. */
    upstreams?: RelaysCreateResponseConfigUpstreamsUpstreamsList | null;
}
export interface RelaysCreateResponseConfig {
    /** Upstreams are external MOQT server publishers that a relay falls back to when it has no local publisher for a requested namespace/track. */
    upstreams?: RelaysCreateResponseConfigUpstreams | null;
}
export type RelaysCreateResponseIssuersItemCloudflareTokensItemOperationsItem = "publish" | "subscribe";
export type RelaysCreateResponseIssuersItemCloudflareTokensItemOperationsList = Array<RelaysCreateResponseIssuersItemCloudflareTokensItemOperationsItem>;
export interface RelaysCreateResponseIssuersItemCloudflareTokensItem {
    created: string;
    /** Mandatory; no more than 1 year after `created`. */
    expires: string;
    /** Token identity and registry key (32 hex chars). */
    jti: string;
    /** Signed allowlist of what the token may do. V1 coarse roles; the array form extends to fine-grained MoQT message names later without a breaking change. */
    operations: RelaysCreateResponseIssuersItemCloudflareTokensItemOperationsList;
    /** Optional, customer-set. */
    label?: string | null;
    /** The signed JWT. Present ONLY in create / auto-create responses (shown once); never returned by list, never stored. */
    secret?: string | null;
}
export type RelaysCreateResponseIssuersItemCloudflareTokensList = Array<RelaysCreateResponseIssuersItemCloudflareTokensItem>;
export type RelaysCreateResponseIssuersItemIssuer = "cloudflare";
export type RelaysCreateResponseIssuersItemType = "cloudflare_jwt";
export interface RelaysCreateResponseIssuersItem {
    /** Always present ([] when empty). */
    cloudflareTokens: RelaysCreateResponseIssuersItemCloudflareTokensList;
    issuer: RelaysCreateResponseIssuersItemIssuer;
    type: RelaysCreateResponseIssuersItemType;
}
export type RelaysCreateResponseIssuersList = Array<RelaysCreateResponseIssuersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRelayResponse {
    /** Relay configuration. All sub-objects use whole-object replacement when present; omitted sub-objects preserve the existing value. */
    config: RelaysCreateResponseConfig;
    created: string;
    /** Token collection (discriminated union on `type`). On create this holds the auto-created default pair, each including its one-time secret. */
    issuers: RelaysCreateResponseIssuersList;
    modified: string;
    name: string;
    /** Server-generated unique identifier (32 hex chars). */
    uid: string;
}
export type CreateRelaysTokenRequestOperationsItem = "publish" | "subscribe";
export type CreateRelaysTokenRequestOperationsList = Array<CreateRelaysTokenRequestOperationsItem | (string & {})>;
export interface CreateRelaysTokenRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    relayId: string;
    /** Non-empty subset of the V1 roles the token is allowed to perform. Signed into the token. */
    operations: CreateRelaysTokenRequestOperationsList;
    /** Optional expiry (RFC 3339). Defaults to 1 year from creation; rejected if more than 1 year in the future. */
    expires?: string;
    /** Optional, customer-set label. */
    label?: string;
}
export type CreateRelaysTokenResponseIssuersItemCloudflareTokensItemOperationsItem = "publish" | "subscribe";
export type CreateRelaysTokenResponseIssuersItemCloudflareTokensItemOperationsList = Array<CreateRelaysTokenResponseIssuersItemCloudflareTokensItemOperationsItem>;
export interface CreateRelaysTokenResponseIssuersItemCloudflareTokensItem {
    created: string;
    /** Mandatory; no more than 1 year after `created`. */
    expires: string;
    /** Token identity and registry key (32 hex chars). */
    jti: string;
    /** Signed allowlist of what the token may do. V1 coarse roles; the array form extends to fine-grained MoQT message names later without a breaking change. */
    operations: CreateRelaysTokenResponseIssuersItemCloudflareTokensItemOperationsList;
    /** Optional, customer-set. */
    label?: string | null;
    /** The signed JWT. Present ONLY in create / auto-create responses (shown once); never returned by list, never stored. */
    secret?: string | null;
}
export type CreateRelaysTokenResponseIssuersItemCloudflareTokensList = Array<CreateRelaysTokenResponseIssuersItemCloudflareTokensItem>;
export type CreateRelaysTokenResponseIssuersItemIssuer = "cloudflare";
export type CreateRelaysTokenResponseIssuersItemType = "cloudflare_jwt";
export interface CreateRelaysTokenResponseIssuersItem {
    /** Always present ([] when empty). */
    cloudflareTokens: CreateRelaysTokenResponseIssuersItemCloudflareTokensList;
    issuer: CreateRelaysTokenResponseIssuersItemIssuer;
    type: CreateRelaysTokenResponseIssuersItemType;
}
export type CreateRelaysTokenResponseIssuersList = Array<CreateRelaysTokenResponseIssuersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRelaysTokenResponse {
    issuers: CreateRelaysTokenResponseIssuersList;
}
export interface DeleteRelayRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    relayId: string;
}
export type DeleteRelayResponse = unknown;
export interface DeleteRelaysTokenRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    relayId: string;
    jti: string;
}
export interface DeleteRelaysTokenResponse {
}
export interface GetRelayRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    relayId: string;
}
export type RelaysGetResponseConfigUpstreamsUpstreamsItem = RelaysCreateResponseConfigUpstreamsUpstreamsItem;
export type RelaysGetResponseConfigUpstreamsUpstreamsList = Array<RelaysCreateResponseConfigUpstreamsUpstreamsItem>;
export interface RelaysGetResponseConfigUpstreams {
    enabled?: boolean | null;
    /** Ordered list of upstream MOQT server publishers. Each entry is an object (not a bare string) so per-upstream configuration can be added in the future without another breaking change. */
    upstreams?: RelaysGetResponseConfigUpstreamsUpstreamsList | null;
}
export interface RelaysGetResponseConfig {
    /** Upstreams are external MOQT server publishers that a relay falls back to when it has no local publisher for a requested namespace/track. */
    upstreams?: RelaysGetResponseConfigUpstreams | null;
}
export type RelaysGetResponseStatus = "connected";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRelayResponse {
    /** Relay configuration. All sub-objects use whole-object replacement when present; omitted sub-objects preserve the existing value. */
    config: RelaysGetResponseConfig;
    created: string;
    modified: string;
    name: string;
    uid: string;
    /** "connected" when active, omitted otherwise. */
    status?: RelaysGetResponseStatus | null;
}
export interface ListRelaysRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    /** Sort order by `created`. When true, results are returned oldest-first (ascending); otherwise newest-first (descending, the default). */
    asc?: boolean;
    /** Cursor for pagination. Returns relays created strictly after this RFC 3339 timestamp (typically the `created` value of the last item on the current page, to fetch the next page). */
    createdAfter?: string;
    /** Cursor for pagination. Returns relays created strictly before this RFC 3339 timestamp (typically the `created` value of the first item on the current page, to fetch the previous page). */
    createdBefore?: string;
    /** Maximum number of relays to return per page. Values above the maximum are clamped to it rather than rejected. */
    perPage?: number;
}
export interface RelaysListResultItem {
    created: string;
    modified: string;
    name: string;
    uid: string;
}
export type RelaysListResultList = Array<RelaysListResultItem>;
export interface ListRelaysResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RelaysListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListRelaysTokensRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    relayId: string;
}
export type ListRelaysTokensResponseIssuersItemCloudflareTokensItemOperationsItem = "publish" | "subscribe";
export type ListRelaysTokensResponseIssuersItemCloudflareTokensItemOperationsList = Array<ListRelaysTokensResponseIssuersItemCloudflareTokensItemOperationsItem>;
export interface ListRelaysTokensResponseIssuersItemCloudflareTokensItem {
    created: string;
    /** Mandatory; no more than 1 year after `created`. */
    expires: string;
    /** Token identity and registry key (32 hex chars). */
    jti: string;
    /** Signed allowlist of what the token may do. V1 coarse roles; the array form extends to fine-grained MoQT message names later without a breaking change. */
    operations: ListRelaysTokensResponseIssuersItemCloudflareTokensItemOperationsList;
    /** Optional, customer-set. */
    label?: string | null;
    /** The signed JWT. Present ONLY in create / auto-create responses (shown once); never returned by list, never stored. */
    secret?: string | null;
}
export type ListRelaysTokensResponseIssuersItemCloudflareTokensList = Array<ListRelaysTokensResponseIssuersItemCloudflareTokensItem>;
export type ListRelaysTokensResponseIssuersItemIssuer = "cloudflare";
export type ListRelaysTokensResponseIssuersItemType = "cloudflare_jwt";
export interface ListRelaysTokensResponseIssuersItem {
    /** Always present ([] when empty). */
    cloudflareTokens: ListRelaysTokensResponseIssuersItemCloudflareTokensList;
    issuer: ListRelaysTokensResponseIssuersItemIssuer;
    type: ListRelaysTokensResponseIssuersItemType;
}
export type ListRelaysTokensResponseIssuersList = Array<ListRelaysTokensResponseIssuersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListRelaysTokensResponse {
    issuers: ListRelaysTokensResponseIssuersList;
}
export type RelaysTokensRotateRequestType = "publish_subscribe" | "subscribe";
export interface RotateRelayTokenRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    relayId: string;
    /** Which token type to rotate. */
    type: RelaysTokensRotateRequestType | (string & {});
}
export type RelaysTokensRotateResponseType = "publish_subscribe" | "subscribe";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RotateRelayTokenResponse {
    /** New token value (shown once). Treat as sensitive. */
    token: string;
    type: RelaysTokensRotateResponseType;
}
export type RelaysUpdateRequestConfigUpstreamsUpstreamsItem = RelaysCreateResponseConfigUpstreamsUpstreamsItem;
export type RelaysUpdateRequestConfigUpstreamsUpstreamsList = Array<RelaysCreateResponseConfigUpstreamsUpstreamsItem>;
export interface RelaysUpdateRequestConfigUpstreams {
    enabled?: boolean;
    /** Ordered list of upstream MOQT server publishers. Each entry is an object (not a bare string) so per-upstream configuration can be added in the future without another breaking change. */
    upstreams?: RelaysUpdateRequestConfigUpstreamsUpstreamsList;
}
export interface RelaysUpdateRequestConfig {
    /** Upstreams are external MOQT server publishers that a relay falls back to when it has no local publisher for a requested namespace/track. */
    upstreams?: RelaysUpdateRequestConfigUpstreams;
}
export interface UpdateRelayRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    relayId: string;
    /** Relay configuration. All sub-objects use whole-object replacement when present; omitted sub-objects preserve the existing value. */
    config?: RelaysUpdateRequestConfig;
    name?: string;
}
export type RelaysUpdateResponseConfigUpstreamsUpstreamsItem = RelaysCreateResponseConfigUpstreamsUpstreamsItem;
export type RelaysUpdateResponseConfigUpstreamsUpstreamsList = Array<RelaysCreateResponseConfigUpstreamsUpstreamsItem>;
export interface RelaysUpdateResponseConfigUpstreams {
    enabled?: boolean | null;
    /** Ordered list of upstream MOQT server publishers. Each entry is an object (not a bare string) so per-upstream configuration can be added in the future without another breaking change. */
    upstreams?: RelaysUpdateResponseConfigUpstreamsUpstreamsList | null;
}
export interface RelaysUpdateResponseConfig {
    /** Upstreams are external MOQT server publishers that a relay falls back to when it has no local publisher for a requested namespace/track. */
    upstreams?: RelaysUpdateResponseConfigUpstreams | null;
}
export type RelaysUpdateResponseStatus = "connected";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRelayResponse {
    /** Relay configuration. All sub-objects use whole-object replacement when present; omitted sub-objects preserve the existing value. */
    config: RelaysUpdateResponseConfig;
    created: string;
    modified: string;
    name: string;
    uid: string;
    /** "connected" when active, omitted otherwise. */
    status?: RelaysUpdateResponseStatus | null;
}
export type CreateRelayError = CloudflareOpError;
/** Provisions a new MoQ relay instance. Auto-creates a publish+subscribe token and a subscribe-only token. Token values are included in the response (shown once). Config is always set to defaults (upstreams off) and cannot be supplied here -- sending a non-empty `config` is rejected (21014); `null` or `{}` is accepted as absent. Use PUT to configure the relay after it exists. */
export declare const createRelay: API.OperationMethod<CreateRelayRequest, CreateRelayResponse, CreateRelayError, CloudflareOpContext>;
export type CreateRelaysTokenError = CloudflareOpError;
/** Mints a new relay-scoped token and adds it to the relay's accepted-auth registry. The token value (secret) is shown once in the response. A relay may hold up to 10 tokens; creating an 11th is rejected. */
export declare const createRelaysToken: API.OperationMethod<CreateRelaysTokenRequest, CreateRelaysTokenResponse, CreateRelaysTokenError, CloudflareOpContext>;
export type DeleteRelayError = CloudflareOpError;
/** Soft-deletes a MoQ relay. The relay ID goes in the URL path -- `DELETE /accounts/{account_id}/moq/relays/{relay_id}` -- not the request body; there is no collection-level delete endpoint. */
export declare const deleteRelay: API.OperationMethod<DeleteRelayRequest, DeleteRelayResponse, DeleteRelayError, CloudflareOpContext>;
export type DeleteRelaysTokenError = CloudflareOpError;
/** Revokes a token by removing it from the set the relay accepts. Relays cache that set, so revocation takes effect within seconds rather than instantly, and connections already established with the token are not closed. Revoking an unknown token succeeds, so the call is idempotent. */
export declare const deleteRelaysToken: API.OperationMethod<DeleteRelaysTokenRequest, DeleteRelaysTokenResponse, DeleteRelaysTokenError, CloudflareOpContext>;
export type GetRelayError = CloudflareOpError;
/** Retrieves a single MoQ relay including config and status. Tokens are NOT included. */
export declare const getRelay: API.OperationMethod<GetRelayRequest, GetRelayResponse, GetRelayError, CloudflareOpContext>;
export type ListRelaysError = CloudflareOpError;
/** Lists all MoQ relays for the account. Returns only metadata. Config, status, and tokens are omitted. Results are cursor-paginated (keyset on the `created` timestamp). Use `created_before` / `created_after` with the `created` value of the first/last item in a page to fetch the adjacent page. `result_info` reports the page `count` and the `total` matching the cursor filters. */
export declare const listRelays: API.PaginatedOperationMethod<ListRelaysRequest, ListRelaysResponse, ListRelaysError, CloudflareOpContext, RelaysListResultItem>;
export type ListRelaysTokensError = CloudflareOpError;
/** Returns metadata for every token the relay accepts. Secrets are never returned, so a token that has been lost cannot be recovered here. There is no expiry filter: compare each token's `expires` to the current time to tell which ones have lapsed. */
export declare const listRelaysTokens: API.OperationMethod<ListRelaysTokensRequest, ListRelaysTokensResponse, ListRelaysTokensError, CloudflareOpContext>;
export type RotateRelayTokenError = CloudflareOpError;
/** Generates a new token for the specified type. The old token is immediately invalidated. Token value is shown once in the response. */
export declare const rotateRelayToken: API.OperationMethod<RotateRelayTokenRequest, RotateRelayTokenResponse, RotateRelayTokenError, CloudflareOpContext>;
export type UpdateRelayError = CloudflareOpError;
/** Updates a relay's name and/or configuration. The relay ID goes in the URL path -- `PUT /accounts/{account_id}/moq/relays/{relay_id}` -- not the request body; there is no collection-level update endpoint. This is also the only way to set a relay's config (config cannot be set at create time). Partial updates: omitted fields are preserved; config sub-objects replace as whole objects when present. */
export declare const updateRelay: API.OperationMethod<UpdateRelayRequest, UpdateRelayResponse, UpdateRelayError, CloudflareOpContext>;
//# sourceMappingURL=moq.d.ts.map