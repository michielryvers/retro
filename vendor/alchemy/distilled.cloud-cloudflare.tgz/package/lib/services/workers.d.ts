import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ContentTypeRequired_base: S.TaggedErrorClass<"ContentTypeRequired", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ContentTypeRequired extends /*@__PURE__*/ ContentTypeRequired_base {
}
declare const D1DatabaseNotFound_base: S.TaggedErrorClass<"D1DatabaseNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class D1DatabaseNotFound extends /*@__PURE__*/ D1DatabaseNotFound_base {
}
declare const DeploymentNotFound_base: S.TaggedErrorClass<"DeploymentNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DeploymentNotFound extends /*@__PURE__*/ DeploymentNotFound_base {
}
declare const DispatchNamespaceNotFound_base: S.TaggedErrorClass<"DispatchNamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DispatchNamespaceNotFound extends /*@__PURE__*/ DispatchNamespaceNotFound_base {
}
declare const DomainNotFound_base: S.TaggedErrorClass<"DomainNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DomainNotFound extends /*@__PURE__*/ DomainNotFound_base {
}
declare const DuplicateMigrationTarget_base: S.TaggedErrorClass<"DuplicateMigrationTarget", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DuplicateMigrationTarget extends /*@__PURE__*/ DuplicateMigrationTarget_base {
}
declare const DurableObjectClassNotFound_base: S.TaggedErrorClass<"DurableObjectClassNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DurableObjectClassNotFound extends /*@__PURE__*/ DurableObjectClassNotFound_base {
}
declare const DurableObjectMustBeSqlite_base: S.TaggedErrorClass<"DurableObjectMustBeSqlite", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DurableObjectMustBeSqlite extends /*@__PURE__*/ DurableObjectMustBeSqlite_base {
}
declare const EventTriggerWorkflowNotFound_base: S.TaggedErrorClass<"EventTriggerWorkflowNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class EventTriggerWorkflowNotFound extends /*@__PURE__*/ EventTriggerWorkflowNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HostnameAlreadyInUse_base: S.TaggedErrorClass<"HostnameAlreadyInUse", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HostnameAlreadyInUse extends /*@__PURE__*/ HostnameAlreadyInUse_base {
}
declare const HyperdriveConfigNotFound_base: S.TaggedErrorClass<"HyperdriveConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HyperdriveConfigNotFound extends /*@__PURE__*/ HyperdriveConfigNotFound_base {
}
declare const InvalidEventTriggers_base: S.TaggedErrorClass<"InvalidEventTriggers", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidEventTriggers extends /*@__PURE__*/ InvalidEventTriggers_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidRoutePattern_base: S.TaggedErrorClass<"InvalidRoutePattern", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRoutePattern extends /*@__PURE__*/ InvalidRoutePattern_base {
}
declare const InvalidWorkerScript_base: S.TaggedErrorClass<"InvalidWorkerScript", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidWorkerScript extends /*@__PURE__*/ InvalidWorkerScript_base {
}
declare const KVNamespaceNotFound_base: S.TaggedErrorClass<"KVNamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class KVNamespaceNotFound extends /*@__PURE__*/ KVNamespaceNotFound_base {
}
declare const MtlsCertificateNotFound_base: S.TaggedErrorClass<"MtlsCertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MtlsCertificateNotFound extends /*@__PURE__*/ MtlsCertificateNotFound_base {
}
declare const ObservabilityDestinationCreateFailed_base: S.TaggedErrorClass<"ObservabilityDestinationCreateFailed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ObservabilityDestinationCreateFailed extends /*@__PURE__*/ ObservabilityDestinationCreateFailed_base {
}
declare const ObservabilityDestinationNotFound_base: S.TaggedErrorClass<"ObservabilityDestinationNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ObservabilityDestinationNotFound extends /*@__PURE__*/ ObservabilityDestinationNotFound_base {
}
declare const ObservabilityDestinationPreflightFailed_base: S.TaggedErrorClass<"ObservabilityDestinationPreflightFailed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ObservabilityDestinationPreflightFailed extends /*@__PURE__*/ ObservabilityDestinationPreflightFailed_base {
}
declare const ObservabilityIssueAutomationInvalid_base: S.TaggedErrorClass<"ObservabilityIssueAutomationInvalid", {
    readonly code: any;
    readonly message: any;
}>;
/** The automation body failed validation (e.g. neither or both of `afterOccurrences` / `afterInactivitySeconds`). */
export declare class ObservabilityIssueAutomationInvalid extends /*@__PURE__*/ ObservabilityIssueAutomationInvalid_base {
}
declare const ObservabilityIssueAutomationNotFound_base: S.TaggedErrorClass<"ObservabilityIssueAutomationNotFound", {
    readonly code: any;
    readonly message: any;
}>;
/** The Issues automation does not exist (or was already deleted). */
export declare class ObservabilityIssueAutomationNotFound extends /*@__PURE__*/ ObservabilityIssueAutomationNotFound_base {
}
declare const PreviewAlreadyExists_base: S.TaggedErrorClass<"PreviewAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PreviewAlreadyExists extends /*@__PURE__*/ PreviewAlreadyExists_base {
}
declare const PreviewDeploymentNotFound_base: S.TaggedErrorClass<"PreviewDeploymentNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PreviewDeploymentNotFound extends /*@__PURE__*/ PreviewDeploymentNotFound_base {
}
declare const PreviewNotFound_base: S.TaggedErrorClass<"PreviewNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PreviewNotFound extends /*@__PURE__*/ PreviewNotFound_base {
}
declare const QueueConsumerConflict_base: S.TaggedErrorClass<"QueueConsumerConflict", {
    readonly code: any;
    readonly message: any;
}>;
export declare class QueueConsumerConflict extends /*@__PURE__*/ QueueConsumerConflict_base {
}
declare const QueueNotFound_base: S.TaggedErrorClass<"QueueNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class QueueNotFound extends /*@__PURE__*/ QueueNotFound_base {
}
declare const R2BucketNotFound_base: S.TaggedErrorClass<"R2BucketNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class R2BucketNotFound extends /*@__PURE__*/ R2BucketNotFound_base {
}
declare const RouteNotFound_base: S.TaggedErrorClass<"RouteNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class RouteNotFound extends /*@__PURE__*/ RouteNotFound_base {
}
declare const RouteScriptNotFound_base: S.TaggedErrorClass<"RouteScriptNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class RouteScriptNotFound extends /*@__PURE__*/ RouteScriptNotFound_base {
}
declare const ScriptModuleNotFound_base: S.TaggedErrorClass<"ScriptModuleNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ScriptModuleNotFound extends /*@__PURE__*/ ScriptModuleNotFound_base {
}
declare const ScriptStartupError_base: S.TaggedErrorClass<"ScriptStartupError", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ScriptStartupError extends /*@__PURE__*/ ScriptStartupError_base {
}
declare const SecretNotFound_base: S.TaggedErrorClass<"SecretNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SecretNotFound extends /*@__PURE__*/ SecretNotFound_base {
}
declare const SecretsStoreBindingNotFound_base: S.TaggedErrorClass<"SecretsStoreBindingNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SecretsStoreBindingNotFound extends /*@__PURE__*/ SecretsStoreBindingNotFound_base {
}
declare const ServiceBindingConflict_base: S.TaggedErrorClass<"ServiceBindingConflict", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ServiceBindingConflict extends /*@__PURE__*/ ServiceBindingConflict_base {
}
declare const ServiceBindingNotFound_base: S.TaggedErrorClass<"ServiceBindingNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ServiceBindingNotFound extends /*@__PURE__*/ ServiceBindingNotFound_base {
}
declare const SubdomainAlreadyExists_base: S.TaggedErrorClass<"SubdomainAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SubdomainAlreadyExists extends /*@__PURE__*/ SubdomainAlreadyExists_base {
}
declare const SubdomainNotFound_base: S.TaggedErrorClass<"SubdomainNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SubdomainNotFound extends /*@__PURE__*/ SubdomainNotFound_base {
}
declare const VectorizeIndexNotFound_base: S.TaggedErrorClass<"VectorizeIndexNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class VectorizeIndexNotFound extends /*@__PURE__*/ VectorizeIndexNotFound_base {
}
declare const VersionNotFound_base: S.TaggedErrorClass<"VersionNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class VersionNotFound extends /*@__PURE__*/ VersionNotFound_base {
}
declare const WorkerHasNoVersions_base: S.TaggedErrorClass<"WorkerHasNoVersions", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WorkerHasNoVersions extends /*@__PURE__*/ WorkerHasNoVersions_base {
}
declare const WorkerNotFound_base: S.TaggedErrorClass<"WorkerNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WorkerNotFound extends /*@__PURE__*/ WorkerNotFound_base {
}
declare const WorkerVersionNotFound_base: S.TaggedErrorClass<"WorkerVersionNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WorkerVersionNotFound extends /*@__PURE__*/ WorkerVersionNotFound_base {
}
export type BetaWorkersVersionsProfileRequestProfileType = "cpu" | "heap";
export interface BetaWorkersVersionsProfileRequest {
    /** Identifier. */
    accountId: string;
    /** Identifies the Worker by ID or name. */
    workerId: string;
    /** Identifies the version by UUID or UUID prefix with a minimum length of eight characters. Use "latest" to select the most recently created version, which may not be deployed. Use "latest-deployed" to profile a version in the active deployment. Versions are tried in order of traffic share until one has a loaded isolate. */
    versionId: string;
    /** Profile duration in milliseconds. */
    durationMs: number;
    /** Identifies the exact Durable Object actor to profile. Must be specified together with namespace_id. The actor must currently be active and running the requested Worker version. */
    actorId?: string;
    /** Identifies the Durable Object namespace containing the actor to profile. Must be specified together with actor_id. */
    namespaceId?: string;
    profileType?: BetaWorkersVersionsProfileRequestProfileType | (string & {});
}
export interface BetaWorkersVersionsProfileResponse {
}
export type ScriptsSecretsBulkUpdateRequestSecretsValueSecretTextType = "secret_text";
export interface ScriptsSecretsBulkUpdateRequestSecretsValueSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsBulkUpdateRequestSecretsValueSecretTextType;
}
export type ScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type ScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyType = "secret_key";
export type ScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type ScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyUsagesList = Array<ScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyUsagesItem | (string & {})>;
export interface ScriptsSecretsBulkUpdateRequestSecretsValueSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyFormat | (string & {});
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown;
}
export type ScriptsSecretsBulkUpdateRequestSecretsValue = ScriptsSecretsBulkUpdateRequestSecretsValueSecretText | ScriptsSecretsBulkUpdateRequestSecretsValueSecretKey;
export type ScriptsSecretsBulkUpdateRequestSecretsMap = {
    [key: string]: ScriptsSecretsBulkUpdateRequestSecretsValue | undefined;
};
export type ScriptsSecretsBulkUpdateRequestVersionTagsMap = {
    [key: string]: unknown | undefined;
};
export interface BulkUpdateScriptSecretsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** Map of secret names to secret values: */
    secrets?: ScriptsSecretsBulkUpdateRequestSecretsMap;
    /** Optional version tags to apply to the new script version. */
    versionTags?: ScriptsSecretsBulkUpdateRequestVersionTagsMap;
}
export type ScriptsSecretsBulkUpdateResultValueSecretTextType = "secret_text";
export interface ScriptsSecretsBulkUpdateResultValueSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsBulkUpdateResultValueSecretTextType;
}
export type ScriptsSecretsBulkUpdateResultValueSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type ScriptsSecretsBulkUpdateResultValueSecretKeyType = "secret_key";
export type ScriptsSecretsBulkUpdateResultValueSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type ScriptsSecretsBulkUpdateResultValueSecretKeyUsagesList = Array<ScriptsSecretsBulkUpdateResultValueSecretKeyUsagesItem>;
export interface ScriptsSecretsBulkUpdateResultValueSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsSecretsBulkUpdateResultValueSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsBulkUpdateResultValueSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsSecretsBulkUpdateResultValueSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type ScriptsSecretsBulkUpdateResultValue = ScriptsSecretsBulkUpdateResultValueSecretText | ScriptsSecretsBulkUpdateResultValueSecretKey;
export type ScriptsSecretsBulkUpdateResultMap = {
    [key: string]: ScriptsSecretsBulkUpdateResultValue | undefined;
};
export type BulkUpdateScriptSecretsResponse = ScriptsSecretsBulkUpdateResultMap;
export type CreateAssetUploadBodyMap = {
    [key: string]: unknown | undefined;
};
export interface CreateAssetUploadRequest {
    /** Identifier. */
    accountId: string;
    /** Whether the file contents are base64-encoded. Must be `true`. */
    base64: boolean;
    /** Map of asset hash -> base64 file content; each entry is a multipart form part. */
    body?: CreateAssetUploadBodyMap;
    /** Asset-upload session JWT (sent as Bearer Authorization). */
    jwtToken?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAssetUploadResponse {
    /** A "completion" JWT which can be redeemed when creating a Worker version. */
    jwt?: string | null;
}
export interface BetaWorkersCreateRequestObservabilityIssues {
    /** Whether real-time Issues are enabled for the Worker. */
    enabled?: boolean;
}
export type BetaWorkersCreateRequestObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersCreateRequestObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersCreateRequestObservabilityLogsDestinationsList;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean;
}
export type BetaWorkersCreateRequestObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersCreateRequestObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersCreateRequestObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersCreateRequestObservabilityTracesDestinationsList;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersCreateRequestObservabilityTracesPropagationPolicy | (string & {});
}
export interface BetaWorkersCreateRequestObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateRequestObservabilityIssues;
    /** Log settings for the Worker. */
    logs?: BetaWorkersCreateRequestObservabilityLogs;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersCreateRequestObservabilityTraces;
}
export interface BetaWorkersCreateRequestPreviewsBaseConfigCacheOptions {
    /** Whether caching is enabled for this Worker. */
    enabled: boolean;
    /** Whether cached responses are shared across Worker version uploads. This is independent of `enabled`. It can stay true while caching is off, so the preference survives turning caching off and back on. */
    crossVersionCache?: boolean;
}
export interface BetaWorkersCreateRequestPreviewsBaseConfigEnvValue {
    /** The kind of resource that the binding provides. */
    type: string;
}
export type BetaWorkersCreateRequestPreviewsBaseConfigEnvMap = {
    [key: string]: BetaWorkersCreateRequestPreviewsBaseConfigEnvValue | undefined;
};
export interface BetaWorkersCreateRequestPreviewsBaseConfigLimits {
    /** The amount of CPU time this Worker can use in milliseconds. */
    cpuMs?: number;
    /** The number of subrequests this Worker can make per request. */
    subrequests?: number;
}
export type BetaWorkersCreateRequestPreviewsBaseConfigObservabilityIssues = BetaWorkersCreateRequestObservabilityIssues;
export type BetaWorkersCreateRequestPreviewsBaseConfigObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersCreateRequestPreviewsBaseConfigObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersCreateRequestPreviewsBaseConfigObservabilityLogsDestinationsList;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean;
}
export type BetaWorkersCreateRequestPreviewsBaseConfigObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersCreateRequestPreviewsBaseConfigObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersCreateRequestPreviewsBaseConfigObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersCreateRequestPreviewsBaseConfigObservabilityTracesDestinationsList;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersCreateRequestPreviewsBaseConfigObservabilityTracesPropagationPolicy | (string & {});
}
export interface BetaWorkersCreateRequestPreviewsBaseConfigObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateRequestObservabilityIssues;
    /** Log settings for the Worker. */
    logs?: BetaWorkersCreateRequestPreviewsBaseConfigObservabilityLogs;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersCreateRequestPreviewsBaseConfigObservabilityTraces;
}
export type BetaWorkersCreateRequestPreviewsBaseConfigPlacementModeMode = "smart";
export interface BetaWorkersCreateRequestPreviewsBaseConfigPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersCreateRequestPreviewsBaseConfigPlacementModeMode;
}
export interface BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export interface BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname {
    /** HTTP hostname for targeted placement. */
    hostname: string;
}
export interface BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost {
    /** TCP host and port for targeted placement. */
    host: string;
}
export type BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase4Mode = "targeted";
export interface BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase5Mode = "targeted";
export interface BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase5Mode;
}
export type BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase6Mode = "targeted";
export interface BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase6Mode;
}
export type BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7Mode = "targeted";
export interface BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion {
    /** Cloud region in format 'provider:region'. */
    region: string;
}
export type BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export interface BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost {
    /** TCP host:port for targeted placement. */
    host: string;
}
export type BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetList = Array<BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItem>;
export interface BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetList;
}
export type BetaWorkersCreateRequestPreviewsBaseConfigPlacement = BetaWorkersCreateRequestPreviewsBaseConfigPlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase4 | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase5 | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase6 | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7;
export interface BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem {
    /** Name of the consumer Worker. */
    name: string;
}
export type BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export interface BetaWorkersCreateRequestPreviewsBaseConfig {
    /** Cache options used when creating new Previews. */
    cacheOptions?: BetaWorkersCreateRequestPreviewsBaseConfigCacheOptions;
    /** Bindings used when creating new Previews, keyed by binding name. */
    env?: BetaWorkersCreateRequestPreviewsBaseConfigEnvMap;
    /** Resource limits enforced at runtime for newly created Previews. */
    limits?: BetaWorkersCreateRequestPreviewsBaseConfigLimits;
    /** Whether logpush is enabled when creating new Previews. */
    logpush?: boolean;
    /** Observability settings used when creating new Previews. */
    observability?: BetaWorkersCreateRequestPreviewsBaseConfigObservability;
    /** Placement configuration used when creating new Previews. */
    placement?: BetaWorkersCreateRequestPreviewsBaseConfigPlacement;
    /** Other Workers that should consume logs from newly created Previews. */
    tailConsumers?: BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersList;
}
export interface BetaWorkersCreateRequestSubdomain {
    /** Whether the *.workers.dev subdomain is enabled for the Worker. */
    enabled?: boolean;
    /** Prepend a version or preview prefix to this host suffix to form the *.workers.dev [preview URL](https://developers.cloudflare.com/workers/configuration/previews/) the Worker would serve on once previews are enabled, e.g. `https://&lt;prefix&gt;-my-worker.my-subdomain.workers.dev`. Present whenever the account owns a workers.dev subdomain, regardless of whether `previews_enabled` is true, so presence does not imply preview URLs are currently live. Absent only when the account owns no workers.dev subdomain. */
    previewUrlSuffix?: string;
    /** Whether [preview URLs](https://developers.cloudflare.com/workers/configuration/previews/) are enabled for the Worker. */
    previewsEnabled?: boolean;
    /** The address the Worker would serve on once its *.workers.dev subdomain is enabled. Present whenever the account owns a workers.dev subdomain, regardless of whether `enabled` is true, so presence does not imply the Worker is currently live at this URL. Absent only when the account owns no workers.dev subdomain. */
    url?: string;
}
export type BetaWorkersCreateRequestTagsList = Array<string>;
export type BetaWorkersCreateRequestTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersCreateRequestTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export interface CreateBetaWorkerRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Worker. */
    name: string;
    /** Whether logpush is enabled for the Worker. */
    logpush?: boolean;
    /** Observability settings for the Worker. */
    observability?: BetaWorkersCreateRequestObservability;
    /** Template configuration used when creating new Previews for this Worker. */
    previewsBaseConfig?: BetaWorkersCreateRequestPreviewsBaseConfig;
    /** Subdomain settings for the Worker. */
    subdomain?: BetaWorkersCreateRequestSubdomain;
    /** Tags associated with the Worker. */
    tags?: BetaWorkersCreateRequestTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers?: BetaWorkersCreateRequestTailConsumersList;
}
export interface BetaWorkersCreateResponseObservabilityIssues {
    /** Whether real-time Issues are enabled for the Worker. */
    enabled?: boolean | null;
}
export type BetaWorkersCreateResponseObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersCreateResponseObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersCreateResponseObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type BetaWorkersCreateResponseObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersCreateResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersCreateResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersCreateResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersCreateResponseObservabilityTracesPropagationPolicy | null;
}
export interface BetaWorkersCreateResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersCreateResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersCreateResponseObservabilityTraces | null;
}
export interface BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem {
    /** ID of the dispatch namespace. */
    namespaceId: string;
    /** Name of the dispatch namespace. */
    namespaceName: string;
    /** ID of the Worker using the dispatch namespace. */
    workerId: string;
    /** Name of the Worker using the dispatch namespace. */
    workerName: string;
}
export type BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsList = Array<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export interface BetaWorkersCreateResponseReferencesDomainsItem {
    /** ID of the custom domain. */
    id: string;
    /** ID of the TLS certificate issued for the custom domain. */
    certificateId: string;
    /** Full hostname of the custom domain, including the zone name. */
    hostname: string;
    /** ID of the zone. */
    zoneId: string;
    /** Name of the zone. */
    zoneName: string;
}
export type BetaWorkersCreateResponseReferencesDomainsList = Array<BetaWorkersCreateResponseReferencesDomainsItem>;
export interface BetaWorkersCreateResponseReferencesDurableObjectsItem {
    /** ID of the Durable Object namespace being used. */
    namespaceId: string;
    /** Name of the Durable Object namespace being used. */
    namespaceName: string;
    /** ID of the Worker using the Durable Object implementation. */
    workerId: string;
    /** Name of the Worker using the Durable Object implementation. */
    workerName: string;
}
export type BetaWorkersCreateResponseReferencesDurableObjectsList = Array<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export interface BetaWorkersCreateResponseReferencesQueuesItem {
    /** ID of the queue consumer configuration. */
    queueConsumerId: string;
    /** ID of the queue. */
    queueId: string;
    /** Name of the queue. */
    queueName: string;
}
export type BetaWorkersCreateResponseReferencesQueuesList = Array<BetaWorkersCreateResponseReferencesQueuesItem>;
export interface BetaWorkersCreateResponseReferencesWorkersItem {
    /** ID of the referencing Worker. */
    id: string;
    /** Name of the referencing Worker. */
    name: string;
}
export type BetaWorkersCreateResponseReferencesWorkersList = Array<BetaWorkersCreateResponseReferencesWorkersItem>;
export interface BetaWorkersCreateResponseReferences {
    /** Other Workers that reference the Worker as an outbound for a dispatch namespace. */
    dispatchNamespaceOutbounds: BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsList;
    /** Custom domains connected to the Worker. */
    domains: BetaWorkersCreateResponseReferencesDomainsList;
    /** Other Workers that reference Durable Object classes implemented by the Worker. */
    durableObjects: BetaWorkersCreateResponseReferencesDurableObjectsList;
    /** Queues that send messages to the Worker. */
    queues: BetaWorkersCreateResponseReferencesQueuesList;
    /** Other Workers that reference the Worker using [service bindings](https://developers.cloudflare.com/workers/runtime-apis/bindings/service-bindings/). */
    workers: BetaWorkersCreateResponseReferencesWorkersList;
}
export interface BetaWorkersCreateResponseSubdomain {
    /** Whether the *.workers.dev subdomain is enabled for the Worker. */
    enabled?: boolean | null;
    /** Prepend a version or preview prefix to this host suffix to form the *.workers.dev [preview URL](https://developers.cloudflare.com/workers/configuration/previews/) the Worker would serve on once previews are enabled, e.g. `https://&lt;prefix&gt;-my-worker.my-subdomain.workers.dev`. Present whenever the account owns a workers.dev subdomain, regardless of whether `previews_enabled` is true, so presence does not imply preview URLs are currently live. Absent only when the account owns no workers.dev subdomain. */
    previewUrlSuffix?: string | null;
    /** Whether [preview URLs](https://developers.cloudflare.com/workers/configuration/previews/) are enabled for the Worker. */
    previewsEnabled?: boolean | null;
    /** The address the Worker would serve on once its *.workers.dev subdomain is enabled. Present whenever the account owns a workers.dev subdomain, regardless of whether `enabled` is true, so presence does not imply the Worker is currently live at this URL. Absent only when the account owns no workers.dev subdomain. */
    url?: string | null;
}
export type BetaWorkersCreateResponseTagsList = Array<string>;
export type BetaWorkersCreateResponseTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersCreateResponseTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export interface BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions {
    /** Whether caching is enabled for this Worker. */
    enabled: boolean;
    /** Whether cached responses are shared across Worker version uploads. This is independent of `enabled`. It can stay true while caching is off, so the preference survives turning caching off and back on. */
    crossVersionCache?: boolean | null;
}
export type BetaWorkersCreateResponsePreviewsBaseConfigEnvValue = BetaWorkersCreateRequestPreviewsBaseConfigEnvValue;
export type BetaWorkersCreateResponsePreviewsBaseConfigEnvMap = {
    [key: string]: BetaWorkersCreateRequestPreviewsBaseConfigEnvValue | undefined;
};
export interface BetaWorkersCreateResponsePreviewsBaseConfigLimits {
    /** The amount of CPU time this Worker can use in milliseconds. */
    cpuMs?: number | null;
    /** The number of subrequests this Worker can make per request. */
    subrequests?: number | null;
}
export type BetaWorkersCreateResponsePreviewsBaseConfigObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type BetaWorkersCreateResponsePreviewsBaseConfigObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersCreateResponsePreviewsBaseConfigObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersCreateResponsePreviewsBaseConfigObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type BetaWorkersCreateResponsePreviewsBaseConfigObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersCreateResponsePreviewsBaseConfigObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersCreateResponsePreviewsBaseConfigObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersCreateResponsePreviewsBaseConfigObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersCreateResponsePreviewsBaseConfigObservabilityTracesPropagationPolicy | null;
}
export interface BetaWorkersCreateResponsePreviewsBaseConfigObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersCreateResponsePreviewsBaseConfigObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersCreateResponsePreviewsBaseConfigObservabilityTraces | null;
}
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementModeMode = "smart";
export interface BetaWorkersCreateResponsePreviewsBaseConfigPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersCreateResponsePreviewsBaseConfigPlacementModeMode;
}
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase4Mode = "targeted";
export interface BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase5Mode = "targeted";
export interface BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase5Mode;
}
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase6Mode = "targeted";
export interface BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase6Mode;
}
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase7Mode = "targeted";
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase7TargetList = Array<BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase7TargetItem>;
export interface BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase7TargetList;
}
export type BetaWorkersCreateResponsePreviewsBaseConfigPlacement = BetaWorkersCreateResponsePreviewsBaseConfigPlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase4 | BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase5 | BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase6 | BetaWorkersCreateResponsePreviewsBaseConfigPlacementCase7;
export type BetaWorkersCreateResponsePreviewsBaseConfigTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersCreateResponsePreviewsBaseConfigTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export interface BetaWorkersCreateResponsePreviewsBaseConfig {
    /** Cache options used when creating new Previews. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Bindings used when creating new Previews, keyed by binding name. */
    env?: BetaWorkersCreateResponsePreviewsBaseConfigEnvMap | null;
    /** Resource limits enforced at runtime for newly created Previews. */
    limits?: BetaWorkersCreateResponsePreviewsBaseConfigLimits | null;
    /** Whether logpush is enabled when creating new Previews. */
    logpush?: boolean | null;
    /** Observability settings used when creating new Previews. */
    observability?: BetaWorkersCreateResponsePreviewsBaseConfigObservability | null;
    /** Placement configuration used when creating new Previews. */
    placement?: BetaWorkersCreateResponsePreviewsBaseConfigPlacement | null;
    /** Other Workers that should consume logs from newly created Previews. */
    tailConsumers?: BetaWorkersCreateResponsePreviewsBaseConfigTailConsumersList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateBetaWorkerResponse {
    /** Immutable ID of the Worker. */
    id: string;
    /** When the Worker was created. */
    createdOn: string;
    /** Whether logpush is enabled for the Worker. */
    logpush: boolean;
    /** Name of the Worker. */
    name: string;
    /** Observability settings for the Worker. */
    observability: BetaWorkersCreateResponseObservability;
    /** Other resources that reference the Worker and depend on it existing. */
    references: BetaWorkersCreateResponseReferences;
    /** Subdomain settings for the Worker. */
    subdomain: BetaWorkersCreateResponseSubdomain;
    /** Tags associated with the Worker. */
    tags: BetaWorkersCreateResponseTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers: BetaWorkersCreateResponseTailConsumersList;
    /** When the Worker was most recently updated. */
    updatedOn: string;
    /** When the Worker's most recent deployment was created. `null` if the Worker has never been deployed. */
    deployedOn?: string | null;
    /** Template configuration used when creating new Previews for this Worker. */
    previewsBaseConfig?: BetaWorkersCreateResponsePreviewsBaseConfig | null;
}
export interface BetaWorkersVersionsCreateRequestAnnotations {
    /** Human-readable message about the version. Truncated to 1000 bytes if longer. */
    workersMessage?: string;
    /** User-provided identifier for the version. Maximum 100 bytes. */
    workersTag?: string;
    /** Operation that triggered the creation of the version. */
    workersTriggeredBy?: string;
}
export type BetaWorkersVersionsCreateRequestAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export type BetaWorkersVersionsCreateRequestAssetsConfigNotFoundHandling = "none" | "404-page" | "single-page-application";
export type BetaWorkersVersionsCreateRequestAssetsConfigRunWorkerFirstCase0List = Array<string>;
export type BetaWorkersVersionsCreateRequestAssetsConfigRunWorkerFirst = boolean | BetaWorkersVersionsCreateRequestAssetsConfigRunWorkerFirstCase0List;
export interface BetaWorkersVersionsCreateRequestAssetsConfig {
    /** The public URL path prefix under which assets are served. A null request value resets it to `/`; responses represent the root as `/`. All versions in a gradual deployment must use the same canonical value. To change it, first deploy the version containing the change at 100%. */
    basePath?: string;
    /** Determines the redirects and rewrites of requests for HTML content. */
    htmlHandling?: BetaWorkersVersionsCreateRequestAssetsConfigHtmlHandling | (string & {});
    /** Determines the response when a request does not match a static asset, and there is no Worker script. */
    notFoundHandling?: BetaWorkersVersionsCreateRequestAssetsConfigNotFoundHandling | (string & {});
    /** Contains a list path rules to control routing to either the Worker or assets. Glob (*) and negative (!) rules are supported. Rules must start with either '/' or '!/'. At least one non-negative rule must be provided, and negative rules have higher precedence than non-negative rules. */
    runWorkerFirst?: BetaWorkersVersionsCreateRequestAssetsConfigRunWorkerFirst;
}
export interface BetaWorkersVersionsCreateRequestAssets {
    /** Configuration for assets within a Worker. */
    config?: BetaWorkersVersionsCreateRequestAssetsConfig;
    /** Token provided upon successful upload of all files from a registered manifest. */
    jwt?: string;
}
export type BetaWorkersVersionsCreateRequestBindingsItemAIType = "ai";
export interface BetaWorkersVersionsCreateRequestBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemAIType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemAISearchType = "ai_search";
export interface BetaWorkersVersionsCreateRequestBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string;
}
export type BetaWorkersVersionsCreateRequestBindingsItemAISearchNamespaceType = "ai_search_namespace";
export interface BetaWorkersVersionsCreateRequestBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemAISearchNamespaceType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemMessagingType = "messaging";
export interface BetaWorkersVersionsCreateRequestBindingsItemMessaging {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Messaging namespace to bind to. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemMessagingType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemAnalyticsEngineType = "analytics_engine";
export interface BetaWorkersVersionsCreateRequestBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemAnalyticsEngineType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemArtifactsType = "artifacts";
export interface BetaWorkersVersionsCreateRequestBindingsItemArtifacts {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Artifacts namespace exposed to the Worker in the Worker's account. Must be 2-63 characters, start with an ASCII alphanumeric character, contain only ASCII alphanumeric characters, dots, underscores, and hyphens, and must not end with a hyphen. The namespace does not need to be created before binding it. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemArtifactsType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemAssetsType = "assets";
export interface BetaWorkersVersionsCreateRequestBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemAssetsType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemBrowserType = "browser";
export interface BetaWorkersVersionsCreateRequestBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemBrowserType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemD1Type = "d1";
export interface BetaWorkersVersionsCreateRequestBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemD1Type;
    /** This property has been renamed to `database_id`. */
    id?: string;
}
export type BetaWorkersVersionsCreateRequestBindingsItemDataBlobType = "data_blob";
export interface BetaWorkersVersionsCreateRequestBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemDataBlobType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceType = "dispatch_namespace";
export interface BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem {
    /** Name of the parameter. */
    name: string;
}
export type BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export interface BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundWorker {
    /** Entrypoint to invoke on the outbound worker. */
    entrypoint?: string;
    /** Environment of the outbound worker. */
    environment?: string;
    /** Name of the outbound worker. */
    service?: string;
}
export interface BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsList;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundWorker;
}
export interface BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutbound;
}
export type BetaWorkersVersionsCreateRequestBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export interface BetaWorkersVersionsCreateRequestBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string;
    /** The environment of the script_name to bind to. */
    environment?: string;
    /** Namespace identifier tag. */
    namespaceId?: string;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string;
}
export type BetaWorkersVersionsCreateRequestBindingsItemHyperdriveType = "hyperdrive";
export interface BetaWorkersVersionsCreateRequestBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemHyperdriveType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemInheritType = "inherit";
export interface BetaWorkersVersionsCreateRequestBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string;
    /** Identifier for the version to inherit the binding from. This can be a version ID, or the literal "latest" to inherit from the most recently uploaded version, which may not be the deployed version. Defaults to "latest". Only the Workers API version endpoints under `/accounts/{account_id}/workers/workers/{worker_id}/versions` accept a version ID. Other endpoints, including script upload and script version upload, accept only "latest" and reject a version ID with error 10057. */
    versionId?: string;
}
export type BetaWorkersVersionsCreateRequestBindingsItemImagesType = "images";
export interface BetaWorkersVersionsCreateRequestBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemImagesType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemJsonType = "json";
export interface BetaWorkersVersionsCreateRequestBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemJsonType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemKVNamespaceType = "kv_namespace";
export interface BetaWorkersVersionsCreateRequestBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemKVNamespaceType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemMediaType = "media";
export interface BetaWorkersVersionsCreateRequestBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemMediaType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemMTLSCertificateType = "mtls_certificate";
export interface BetaWorkersVersionsCreateRequestBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemMTLSCertificateType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemPlainTextType = "plain_text";
export interface BetaWorkersVersionsCreateRequestBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemPlainTextType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemPipelinesType = "pipelines";
export interface BetaWorkersVersionsCreateRequestBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemPipelinesType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemK2Type = "k2";
export interface BetaWorkersVersionsCreateRequestBindingsItemK2 {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** ID of a K2 stream owned by the account deploying the Worker. */
    stream: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemK2Type;
}
export type BetaWorkersVersionsCreateRequestBindingsItemQueueType = "queue";
export interface BetaWorkersVersionsCreateRequestBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemQueueType;
}
export interface BetaWorkersVersionsCreateRequestBindingsItemRatelimitSimple {
    /** The limit (requests per period). */
    limit: number;
    /** The period in seconds. */
    period: number;
    /** Duration in seconds to apply the mitigation action after the rate limit is exceeded. Valid values are 0 (disabled), 10, or multiples of 60 up to 86400. Must be greater than or equal to the period when non-zero. */
    mitigationTimeout?: number;
}
export type BetaWorkersVersionsCreateRequestBindingsItemRatelimitType = "ratelimit";
export interface BetaWorkersVersionsCreateRequestBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateRequestBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemRatelimitType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemR2BucketType = "r2_bucket";
export type BetaWorkersVersionsCreateRequestBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high" | "us";
export interface BetaWorkersVersionsCreateRequestBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: BetaWorkersVersionsCreateRequestBindingsItemR2BucketJurisdiction | (string & {});
}
export type BetaWorkersVersionsCreateRequestBindingsItemSecretTextType = "secret_text";
export interface BetaWorkersVersionsCreateRequestBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemSecretTextType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemSendEmailType = "send_email";
export type BetaWorkersVersionsCreateRequestBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export type BetaWorkersVersionsCreateRequestBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export interface BetaWorkersVersionsCreateRequestBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: BetaWorkersVersionsCreateRequestBindingsItemSendEmailAllowedDestinationAddressesList;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: BetaWorkersVersionsCreateRequestBindingsItemSendEmailAllowedSenderAddressesList;
    /** Destination address for the email. */
    destinationAddress?: string;
}
export type BetaWorkersVersionsCreateRequestBindingsItemServiceType = "service";
export interface BetaWorkersVersionsCreateRequestBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string;
    /** Optional environment if the Worker utilizes one. */
    environment?: string;
}
export type BetaWorkersVersionsCreateRequestBindingsItemTextBlobType = "text_blob";
export interface BetaWorkersVersionsCreateRequestBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemTextBlobType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemVectorizeType = "vectorize";
export interface BetaWorkersVersionsCreateRequestBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemVectorizeType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemVersionMetadataType = "version_metadata";
export interface BetaWorkersVersionsCreateRequestBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemVersionMetadataType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export interface BetaWorkersVersionsCreateRequestBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemSecretsStoreSecretType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemFlagshipType = "flagship";
export interface BetaWorkersVersionsCreateRequestBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemFlagshipType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type BetaWorkersVersionsCreateRequestBindingsItemSecretKeyType = "secret_key";
export type BetaWorkersVersionsCreateRequestBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type BetaWorkersVersionsCreateRequestBindingsItemSecretKeyUsagesList = Array<BetaWorkersVersionsCreateRequestBindingsItemSecretKeyUsagesItem | (string & {})>;
export interface BetaWorkersVersionsCreateRequestBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: BetaWorkersVersionsCreateRequestBindingsItemSecretKeyFormat | (string & {});
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: BetaWorkersVersionsCreateRequestBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown;
}
export type BetaWorkersVersionsCreateRequestBindingsItemWorkflowType = "workflow";
export interface BetaWorkersVersionsCreateRequestBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string;
}
export type BetaWorkersVersionsCreateRequestBindingsItemWasmModuleType = "wasm_module";
export interface BetaWorkersVersionsCreateRequestBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemWasmModuleType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemVPCServiceType = "vpc_service";
export interface BetaWorkersVersionsCreateRequestBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemVPCServiceType;
}
export type BetaWorkersVersionsCreateRequestBindingsItemVPCNetworkType = "vpc_network";
export type BetaWorkersVersionsCreateRequestBindingsItemVPCNetworkIdentity = "runtime-email-alpha";
export interface BetaWorkersVersionsCreateRequestBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemVPCNetworkType;
    /** Enables Gateway identity for the binding. Requires network_id to be "cf1:network" and cannot be combined with tunnel_id. */
    identity?: BetaWorkersVersionsCreateRequestBindingsItemVPCNetworkIdentity | (string & {});
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string;
}
export type BetaWorkersVersionsCreateRequestBindingsItem = BetaWorkersVersionsCreateRequestBindingsItemAI | BetaWorkersVersionsCreateRequestBindingsItemAISearch | BetaWorkersVersionsCreateRequestBindingsItemAISearchNamespace | BetaWorkersVersionsCreateRequestBindingsItemMessaging | BetaWorkersVersionsCreateRequestBindingsItemAnalyticsEngine | BetaWorkersVersionsCreateRequestBindingsItemArtifacts | BetaWorkersVersionsCreateRequestBindingsItemAssets | BetaWorkersVersionsCreateRequestBindingsItemBrowser | BetaWorkersVersionsCreateRequestBindingsItemD1 | BetaWorkersVersionsCreateRequestBindingsItemDataBlob | BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespace | BetaWorkersVersionsCreateRequestBindingsItemDurableObjectNamespace | BetaWorkersVersionsCreateRequestBindingsItemHyperdrive | BetaWorkersVersionsCreateRequestBindingsItemInherit | BetaWorkersVersionsCreateRequestBindingsItemImages | BetaWorkersVersionsCreateRequestBindingsItemJson | BetaWorkersVersionsCreateRequestBindingsItemKVNamespace | BetaWorkersVersionsCreateRequestBindingsItemMedia | BetaWorkersVersionsCreateRequestBindingsItemMTLSCertificate | BetaWorkersVersionsCreateRequestBindingsItemPlainText | BetaWorkersVersionsCreateRequestBindingsItemPipelines | BetaWorkersVersionsCreateRequestBindingsItemK2 | BetaWorkersVersionsCreateRequestBindingsItemQueue | BetaWorkersVersionsCreateRequestBindingsItemRatelimit | BetaWorkersVersionsCreateRequestBindingsItemR2Bucket | BetaWorkersVersionsCreateRequestBindingsItemSecretText | BetaWorkersVersionsCreateRequestBindingsItemSendEmail | BetaWorkersVersionsCreateRequestBindingsItemService | BetaWorkersVersionsCreateRequestBindingsItemTextBlob | BetaWorkersVersionsCreateRequestBindingsItemVectorize | BetaWorkersVersionsCreateRequestBindingsItemVersionMetadata | BetaWorkersVersionsCreateRequestBindingsItemSecretsStoreSecret | BetaWorkersVersionsCreateRequestBindingsItemFlagship | BetaWorkersVersionsCreateRequestBindingsItemSecretKey | BetaWorkersVersionsCreateRequestBindingsItemWorkflow | BetaWorkersVersionsCreateRequestBindingsItemWasmModule | BetaWorkersVersionsCreateRequestBindingsItemVPCService | BetaWorkersVersionsCreateRequestBindingsItemVPCNetwork;
export type BetaWorkersVersionsCreateRequestBindingsList = Array<BetaWorkersVersionsCreateRequestBindingsItem>;
export type BetaWorkersVersionsCreateRequestCacheOptions = BetaWorkersCreateRequestPreviewsBaseConfigCacheOptions;
export type BetaWorkersVersionsCreateRequestCompatibilityFlagsList = Array<string>;
export type ContainerImageMap = {
    [key: string]: string | undefined;
};
export interface BetaWorkersVersionsCreateRequestContainersItem {
    /** Select which Durable Object class should get this container attached. */
    className: string;
    name?: string;
    images?: ContainerImageMap;
}
export type BetaWorkersVersionsCreateRequestContainersList = Array<BetaWorkersVersionsCreateRequestContainersItem>;
export type BetaWorkersVersionsCreateRequestExportsValueWorkerType = "worker";
export interface BetaWorkersVersionsCreateRequestExportsValueWorkerCache {
    /** Whether caching is enabled for this entrypoint. */
    enabled: boolean;
}
export type BetaWorkersVersionsCreateRequestExportsValueWorkerState = "created";
export interface BetaWorkersVersionsCreateRequestExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: BetaWorkersVersionsCreateRequestExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: BetaWorkersVersionsCreateRequestExportsValueWorkerCache;
    /** Live export. May be omitted; defaults to `created`. */
    state?: BetaWorkersVersionsCreateRequestExportsValueWorkerState | (string & {});
}
export type BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExportType = "durable-object";
export type BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExportState = "created";
export interface BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExportStorage | (string & {});
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string;
    /** Live export. May be omitted; defaults to `created`. */
    state?: BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExportState | (string & {});
}
export type BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectDeletedExportType;
}
export type BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectRenamedExportType;
}
export type BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectTransferredExportType;
}
export type BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExpectingTransferExportStorage | (string & {});
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string;
}
export type BetaWorkersVersionsCreateRequestExportsValue = BetaWorkersVersionsCreateRequestExportsValueWorker | BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExport | BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectDeletedExport | BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectRenamedExport | BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectTransferredExport | BetaWorkersVersionsCreateRequestExportsValueWorkersDurableObjectExpectingTransferExport;
export type BetaWorkersVersionsCreateRequestExportsMap = {
    [key: string]: BetaWorkersVersionsCreateRequestExportsValue | undefined;
};
export interface BetaWorkersVersionsCreateRequestLimits {
    /** CPU time limit in milliseconds. */
    cpuMs?: number;
    /** Subrequest limit per request. */
    subrequests?: number;
}
export type BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export type BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationNewClassesList = Array<string>;
export type BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export interface BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem {
    from?: string;
    to?: string;
}
export type BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem>;
export interface BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem {
    from?: string;
    fromScript?: string;
    to?: string;
}
export type BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem>;
export interface BetaWorkersVersionsCreateRequestMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationDeletedClassesList;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationNewClassesList;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationNewSqliteClassesList;
    /** Tag to set as the latest migration tag. */
    newTag?: string;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesList;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesList;
}
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem>;
export interface BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList;
}
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsList = Array<BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItem>;
export interface BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string;
    /** Migrations to apply in order. */
    steps?: BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsList;
}
export type BetaWorkersVersionsCreateRequestMigrations = BetaWorkersVersionsCreateRequestMigrationsSingleStepMigration | BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrations;
export interface BetaWorkersVersionsCreateRequestModulesItem {
    /** The base64-encoded module content. */
    contentBase64: string;
    /** The content type of the module. */
    contentType: string;
    /** The name of the module. */
    name: string;
}
export type BetaWorkersVersionsCreateRequestModulesList = Array<BetaWorkersVersionsCreateRequestModulesItem>;
export interface BetaWorkersVersionsCreateRequestPackageDependenciesItem {
    /** The exact version that was resolved and installed by the package manager. */
    installedVersion: string;
    /** The npm package name. */
    name: string;
    /** The version constraint as written in package.json. */
    packageJsonVersion: string;
}
export type BetaWorkersVersionsCreateRequestPackageDependenciesList = Array<BetaWorkersVersionsCreateRequestPackageDependenciesItem>;
export type BetaWorkersVersionsCreateRequestPlacementModeMode = "smart";
export interface BetaWorkersVersionsCreateRequestPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersVersionsCreateRequestPlacementModeMode;
}
export type BetaWorkersVersionsCreateRequestPlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type BetaWorkersVersionsCreateRequestPlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersVersionsCreateRequestPlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type BetaWorkersVersionsCreateRequestPlacementCase4Mode = "targeted";
export interface BetaWorkersVersionsCreateRequestPlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateRequestPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type BetaWorkersVersionsCreateRequestPlacementCase5Mode = "targeted";
export interface BetaWorkersVersionsCreateRequestPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateRequestPlacementCase5Mode;
}
export type BetaWorkersVersionsCreateRequestPlacementCase6Mode = "targeted";
export interface BetaWorkersVersionsCreateRequestPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateRequestPlacementCase6Mode;
}
export type BetaWorkersVersionsCreateRequestPlacementCase7Mode = "targeted";
export type BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersVersionsCreateRequestPlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersVersionsCreateRequestPlacementCase7TargetList = Array<BetaWorkersVersionsCreateRequestPlacementCase7TargetItem>;
export interface BetaWorkersVersionsCreateRequestPlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateRequestPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersVersionsCreateRequestPlacementCase7TargetList;
}
export type BetaWorkersVersionsCreateRequestPlacement = BetaWorkersVersionsCreateRequestPlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | BetaWorkersVersionsCreateRequestPlacementCase4 | BetaWorkersVersionsCreateRequestPlacementCase5 | BetaWorkersVersionsCreateRequestPlacementCase6 | BetaWorkersVersionsCreateRequestPlacementCase7;
export type BetaWorkersVersionsCreateRequestUsageModel = "standard" | "bundled" | "unbound";
export interface CreateBetaWorkerVersionRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** If true, a deployment will be created that sends 100% of traffic to the new version. */
    deploy?: boolean;
    /** Metadata about the version. */
    annotations?: BetaWorkersVersionsCreateRequestAnnotations;
    /** Configuration for assets within a Worker. */
    assets?: BetaWorkersVersionsCreateRequestAssets;
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: BetaWorkersVersionsCreateRequestBindingsList;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: BetaWorkersCreateRequestPreviewsBaseConfigCacheOptions;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: BetaWorkersVersionsCreateRequestCompatibilityFlagsList;
    /** List of containers attached to a Worker. Containers can only be attached to Durable Object classes of this Worker script. */
    containers?: BetaWorkersVersionsCreateRequestContainersList;
    /** Declarative exports for the version, including Durable Object classes (with their `storage` backend) and named Worker entrypoints. On reads, tombstoned lifecycle entries are omitted, so only live exports (`created` and `expecting-transfer`) are returned. `exports` and `migrations` are mutually exclusive on upload. */
    exports?: BetaWorkersVersionsCreateRequestExportsMap;
    /** Resource limits enforced at runtime. */
    limits?: BetaWorkersVersionsCreateRequestLimits;
    /** The name of the main module in the `modules` array (e.g. the name of the module that exports a `fetch` handler). */
    mainModule?: string;
    /** Migrations for Durable Objects associated with the version. Migrations are applied when the version is deployed. */
    migrations?: BetaWorkersVersionsCreateRequestMigrations;
    /** Code, sourcemaps, and other content used at runtime. */
    modules?: BetaWorkersVersionsCreateRequestModulesList;
    /** The list of npm packages that were installed and used when this Worker version was built. */
    packageDependencies?: BetaWorkersVersionsCreateRequestPackageDependenciesList;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: BetaWorkersVersionsCreateRequestPlacement;
    /** Usage model for the version. */
    usageModel?: BetaWorkersVersionsCreateRequestUsageModel | (string & {});
}
export type BetaWorkersVersionsCreateResponseUrlsList = Array<string>;
export interface BetaWorkersVersionsCreateResponseAnnotations {
    /** Human-readable message about the version. Truncated to 1000 bytes if longer. */
    workersMessage?: string | null;
    /** User-provided identifier for the version. Maximum 100 bytes. */
    workersTag?: string | null;
    /** Operation that triggered the creation of the version. */
    workersTriggeredBy?: string | null;
}
export type BetaWorkersVersionsCreateResponseAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export type BetaWorkersVersionsCreateResponseAssetsConfigNotFoundHandling = "none" | "404-page" | "single-page-application";
export type BetaWorkersVersionsCreateResponseAssetsConfigRunWorkerFirstCase0List = Array<string>;
export type BetaWorkersVersionsCreateResponseAssetsConfigRunWorkerFirst = boolean | BetaWorkersVersionsCreateResponseAssetsConfigRunWorkerFirstCase0List;
export interface BetaWorkersVersionsCreateResponseAssetsConfig {
    /** The public URL path prefix under which assets are served. A null request value resets it to `/`; responses represent the root as `/`. All versions in a gradual deployment must use the same canonical value. To change it, first deploy the version containing the change at 100%. */
    basePath?: string | null;
    /** Determines the redirects and rewrites of requests for HTML content. */
    htmlHandling?: BetaWorkersVersionsCreateResponseAssetsConfigHtmlHandling | null;
    /** Determines the response when a request does not match a static asset, and there is no Worker script. */
    notFoundHandling?: BetaWorkersVersionsCreateResponseAssetsConfigNotFoundHandling | null;
    /** Contains a list path rules to control routing to either the Worker or assets. Glob (*) and negative (!) rules are supported. Rules must start with either '/' or '!/'. At least one non-negative rule must be provided, and negative rules have higher precedence than non-negative rules. */
    runWorkerFirst?: BetaWorkersVersionsCreateResponseAssetsConfigRunWorkerFirst | null;
}
export interface BetaWorkersVersionsCreateResponseAssets {
    /** Configuration for assets within a Worker. */
    config?: BetaWorkersVersionsCreateResponseAssetsConfig | null;
    /** Token provided upon successful upload of all files from a registered manifest. */
    jwt?: string | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItemAIType = "ai";
export interface BetaWorkersVersionsCreateResponseBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemAIType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemAISearchType = "ai_search";
export interface BetaWorkersVersionsCreateResponseBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItemAISearchNamespaceType = "ai_search_namespace";
export interface BetaWorkersVersionsCreateResponseBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemAISearchNamespaceType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemMessagingType = "messaging";
export interface BetaWorkersVersionsCreateResponseBindingsItemMessaging {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Messaging namespace to bind to. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemMessagingType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemAnalyticsEngineType = "analytics_engine";
export interface BetaWorkersVersionsCreateResponseBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemAnalyticsEngineType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemArtifactsType = "artifacts";
export interface BetaWorkersVersionsCreateResponseBindingsItemArtifacts {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Artifacts namespace exposed to the Worker in the Worker's account. Must be 2-63 characters, start with an ASCII alphanumeric character, contain only ASCII alphanumeric characters, dots, underscores, and hyphens, and must not end with a hyphen. The namespace does not need to be created before binding it. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemArtifactsType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemAssetsType = "assets";
export interface BetaWorkersVersionsCreateResponseBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemAssetsType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemBrowserType = "browser";
export interface BetaWorkersVersionsCreateResponseBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemBrowserType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemD1Type = "d1";
export interface BetaWorkersVersionsCreateResponseBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemD1Type;
    /** This property has been renamed to `database_id`. */
    id?: string | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItemDataBlobType = "data_blob";
export interface BetaWorkersVersionsCreateResponseBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemDataBlobType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceType = "dispatch_namespace";
export type BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundParamsItem = BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem;
export type BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export interface BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker {
    /** Entrypoint to invoke on the outbound worker. */
    entrypoint?: string | null;
    /** Environment of the outbound worker. */
    environment?: string | null;
    /** Name of the outbound worker. */
    service?: string | null;
}
export interface BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker | null;
}
export interface BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutbound | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export interface BetaWorkersVersionsCreateResponseBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItemHyperdriveType = "hyperdrive";
export interface BetaWorkersVersionsCreateResponseBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemHyperdriveType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemInheritType = "inherit";
export interface BetaWorkersVersionsCreateResponseBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from. This can be a version ID, or the literal "latest" to inherit from the most recently uploaded version, which may not be the deployed version. Defaults to "latest". Only the Workers API version endpoints under `/accounts/{account_id}/workers/workers/{worker_id}/versions` accept a version ID. Other endpoints, including script upload and script version upload, accept only "latest" and reject a version ID with error 10057. */
    versionId?: string | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItemImagesType = "images";
export interface BetaWorkersVersionsCreateResponseBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemImagesType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemJsonType = "json";
export interface BetaWorkersVersionsCreateResponseBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemJsonType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemKVNamespaceType = "kv_namespace";
export interface BetaWorkersVersionsCreateResponseBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemKVNamespaceType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemMediaType = "media";
export interface BetaWorkersVersionsCreateResponseBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemMediaType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemMTLSCertificateType = "mtls_certificate";
export interface BetaWorkersVersionsCreateResponseBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemMTLSCertificateType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemPlainTextType = "plain_text";
export interface BetaWorkersVersionsCreateResponseBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemPlainTextType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemPipelinesType = "pipelines";
export interface BetaWorkersVersionsCreateResponseBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemPipelinesType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemK2Type = "k2";
export interface BetaWorkersVersionsCreateResponseBindingsItemK2 {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** ID of a K2 stream owned by the account deploying the Worker. */
    stream: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemK2Type;
}
export type BetaWorkersVersionsCreateResponseBindingsItemQueueType = "queue";
export interface BetaWorkersVersionsCreateResponseBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemQueueType;
}
export interface BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple {
    /** The limit (requests per period). */
    limit: number;
    /** The period in seconds. */
    period: number;
    /** Duration in seconds to apply the mitigation action after the rate limit is exceeded. Valid values are 0 (disabled), 10, or multiples of 60 up to 86400. Must be greater than or equal to the period when non-zero. */
    mitigationTimeout?: number | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItemRatelimitType = "ratelimit";
export interface BetaWorkersVersionsCreateResponseBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemRatelimitType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemR2BucketType = "r2_bucket";
export type BetaWorkersVersionsCreateResponseBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high" | "us";
export interface BetaWorkersVersionsCreateResponseBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: BetaWorkersVersionsCreateResponseBindingsItemR2BucketJurisdiction | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItemSecretTextType = "secret_text";
export interface BetaWorkersVersionsCreateResponseBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemSecretTextType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemSendEmailType = "send_email";
export type BetaWorkersVersionsCreateResponseBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export type BetaWorkersVersionsCreateResponseBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export interface BetaWorkersVersionsCreateResponseBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: BetaWorkersVersionsCreateResponseBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: BetaWorkersVersionsCreateResponseBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItemServiceType = "service";
export interface BetaWorkersVersionsCreateResponseBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItemTextBlobType = "text_blob";
export interface BetaWorkersVersionsCreateResponseBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemTextBlobType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemVectorizeType = "vectorize";
export interface BetaWorkersVersionsCreateResponseBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemVectorizeType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemVersionMetadataType = "version_metadata";
export interface BetaWorkersVersionsCreateResponseBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemVersionMetadataType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export interface BetaWorkersVersionsCreateResponseBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemSecretsStoreSecretType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemFlagshipType = "flagship";
export interface BetaWorkersVersionsCreateResponseBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemFlagshipType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type BetaWorkersVersionsCreateResponseBindingsItemSecretKeyType = "secret_key";
export type BetaWorkersVersionsCreateResponseBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type BetaWorkersVersionsCreateResponseBindingsItemSecretKeyUsagesList = Array<BetaWorkersVersionsCreateResponseBindingsItemSecretKeyUsagesItem>;
export interface BetaWorkersVersionsCreateResponseBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: BetaWorkersVersionsCreateResponseBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: BetaWorkersVersionsCreateResponseBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItemWorkflowType = "workflow";
export interface BetaWorkersVersionsCreateResponseBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItemWasmModuleType = "wasm_module";
export interface BetaWorkersVersionsCreateResponseBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemWasmModuleType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemVPCServiceType = "vpc_service";
export interface BetaWorkersVersionsCreateResponseBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemVPCServiceType;
}
export type BetaWorkersVersionsCreateResponseBindingsItemVPCNetworkType = "vpc_network";
export type BetaWorkersVersionsCreateResponseBindingsItemVPCNetworkIdentity = "runtime-email-alpha";
export interface BetaWorkersVersionsCreateResponseBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemVPCNetworkType;
    /** Enables Gateway identity for the binding. Requires network_id to be "cf1:network" and cannot be combined with tunnel_id. */
    identity?: BetaWorkersVersionsCreateResponseBindingsItemVPCNetworkIdentity | null;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export type BetaWorkersVersionsCreateResponseBindingsItem = BetaWorkersVersionsCreateResponseBindingsItemAI | BetaWorkersVersionsCreateResponseBindingsItemAISearch | BetaWorkersVersionsCreateResponseBindingsItemAISearchNamespace | BetaWorkersVersionsCreateResponseBindingsItemMessaging | BetaWorkersVersionsCreateResponseBindingsItemAnalyticsEngine | BetaWorkersVersionsCreateResponseBindingsItemArtifacts | BetaWorkersVersionsCreateResponseBindingsItemAssets | BetaWorkersVersionsCreateResponseBindingsItemBrowser | BetaWorkersVersionsCreateResponseBindingsItemD1 | BetaWorkersVersionsCreateResponseBindingsItemDataBlob | BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespace | BetaWorkersVersionsCreateResponseBindingsItemDurableObjectNamespace | BetaWorkersVersionsCreateResponseBindingsItemHyperdrive | BetaWorkersVersionsCreateResponseBindingsItemInherit | BetaWorkersVersionsCreateResponseBindingsItemImages | BetaWorkersVersionsCreateResponseBindingsItemJson | BetaWorkersVersionsCreateResponseBindingsItemKVNamespace | BetaWorkersVersionsCreateResponseBindingsItemMedia | BetaWorkersVersionsCreateResponseBindingsItemMTLSCertificate | BetaWorkersVersionsCreateResponseBindingsItemPlainText | BetaWorkersVersionsCreateResponseBindingsItemPipelines | BetaWorkersVersionsCreateResponseBindingsItemK2 | BetaWorkersVersionsCreateResponseBindingsItemQueue | BetaWorkersVersionsCreateResponseBindingsItemRatelimit | BetaWorkersVersionsCreateResponseBindingsItemR2Bucket | BetaWorkersVersionsCreateResponseBindingsItemSecretText | BetaWorkersVersionsCreateResponseBindingsItemSendEmail | BetaWorkersVersionsCreateResponseBindingsItemService | BetaWorkersVersionsCreateResponseBindingsItemTextBlob | BetaWorkersVersionsCreateResponseBindingsItemVectorize | BetaWorkersVersionsCreateResponseBindingsItemVersionMetadata | BetaWorkersVersionsCreateResponseBindingsItemSecretsStoreSecret | BetaWorkersVersionsCreateResponseBindingsItemFlagship | BetaWorkersVersionsCreateResponseBindingsItemSecretKey | BetaWorkersVersionsCreateResponseBindingsItemWorkflow | BetaWorkersVersionsCreateResponseBindingsItemWasmModule | BetaWorkersVersionsCreateResponseBindingsItemVPCService | BetaWorkersVersionsCreateResponseBindingsItemVPCNetwork;
export type BetaWorkersVersionsCreateResponseBindingsList = Array<BetaWorkersVersionsCreateResponseBindingsItem>;
export type BetaWorkersVersionsCreateResponseCacheOptions = BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions;
export type BetaWorkersVersionsCreateResponseCompatibilityFlagsList = Array<string>;
export interface BetaWorkersVersionsCreateResponseContainersItem {
    /** Select which Durable Object class should get this container attached. */
    className: string;
    name?: string | null;
    images?: ContainerImageMap | null;
}
export type BetaWorkersVersionsCreateResponseContainersList = Array<BetaWorkersVersionsCreateResponseContainersItem>;
export type BetaWorkersVersionsCreateResponseExportsValueWorkerType = "worker";
export type BetaWorkersVersionsCreateResponseExportsValueWorkerCache = BetaWorkersVersionsCreateRequestExportsValueWorkerCache;
export type BetaWorkersVersionsCreateResponseExportsValueWorkerState = "created";
export interface BetaWorkersVersionsCreateResponseExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: BetaWorkersVersionsCreateResponseExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: BetaWorkersVersionsCreateRequestExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: BetaWorkersVersionsCreateResponseExportsValueWorkerState | null;
}
export type BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExportType = "durable-object";
export type BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExportState = "created";
export interface BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExportState | null;
}
export type BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectDeletedExportType;
}
export type BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectRenamedExportType;
}
export type BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectTransferredExportType;
}
export type BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type BetaWorkersVersionsCreateResponseExportsValue = BetaWorkersVersionsCreateResponseExportsValueWorker | BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExport | BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectDeletedExport | BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectRenamedExport | BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectTransferredExport | BetaWorkersVersionsCreateResponseExportsValueWorkersDurableObjectExpectingTransferExport;
export type BetaWorkersVersionsCreateResponseExportsMap = {
    [key: string]: BetaWorkersVersionsCreateResponseExportsValue | undefined;
};
export type BetaWorkersVersionsCreateResponseExportsReconciliationCreatedList = Array<string>;
export type BetaWorkersVersionsCreateResponseExportsReconciliationDeletedList = Array<string>;
export type BetaWorkersVersionsCreateResponseExportsReconciliationInfoItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export type BetaWorkersVersionsCreateResponseExportsReconciliationInfoItemReferencingScriptsList = Array<string>;
export interface BetaWorkersVersionsCreateResponseExportsReconciliationInfoItem {
    /** The class name the info entry is about. */
    class: string;
    /** Human-readable explanation. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: BetaWorkersVersionsCreateResponseExportsReconciliationInfoItemScenario;
    /** The provisioned namespace the entry relates to, when applicable. */
    namespaceId?: string | null;
    /** Other Workers in the account that still bind to the affected class. Advisory: while non-empty the tombstone is not yet safe to remove -- redeploy these Workers with bindings re-pointed first. */
    referencingScripts?: BetaWorkersVersionsCreateResponseExportsReconciliationInfoItemReferencingScriptsList | null;
}
export type BetaWorkersVersionsCreateResponseExportsReconciliationInfoList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationInfoItem>;
export type BetaWorkersVersionsCreateResponseExportsReconciliationRemovableEntriesList = Array<string>;
export interface BetaWorkersVersionsCreateResponseExportsReconciliationRenamedItem {
    /** The original (source) class name. */
    from: string;
    /** The new class name (`renamed_to`). */
    to: string;
}
export type BetaWorkersVersionsCreateResponseExportsReconciliationRenamedList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationRenamedItem>;
export interface BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingItem {
    /** The target-side class name awaiting transfer. */
    class: string;
    /** The source script the namespace will be transferred from. */
    from: string;
}
export type BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingItem>;
export type BetaWorkersVersionsCreateResponseExportsReconciliationTransferredItemPhase = "committed";
export interface BetaWorkersVersionsCreateResponseExportsReconciliationTransferredItem {
    /** The source class name that was transferred. */
    class: string;
    /** The transfer phase. Currently always `committed`. */
    phase: BetaWorkersVersionsCreateResponseExportsReconciliationTransferredItemPhase;
    /** The destination script that now owns the namespace. */
    to: string;
}
export type BetaWorkersVersionsCreateResponseExportsReconciliationTransferredList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationTransferredItem>;
export type BetaWorkersVersionsCreateResponseExportsReconciliationUpdatedList = Array<string>;
export type BetaWorkersVersionsCreateResponseExportsReconciliationWarningsItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export interface BetaWorkersVersionsCreateResponseExportsReconciliationWarningsItem {
    /** The class name the warning is about. */
    class: string;
    /** Human-readable explanation of the warning. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: BetaWorkersVersionsCreateResponseExportsReconciliationWarningsItemScenario;
    /** The provisioned namespace the warning relates to, when applicable. */
    namespaceId?: string | null;
}
export type BetaWorkersVersionsCreateResponseExportsReconciliationWarningsList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationWarningsItem>;
export interface BetaWorkersVersionsCreateResponseExportsReconciliation {
    /** Class names for which a new namespace was provisioned. */
    created: BetaWorkersVersionsCreateResponseExportsReconciliationCreatedList;
    /** Class names whose namespace was deleted by a `deleted` tombstone. */
    deleted: BetaWorkersVersionsCreateResponseExportsReconciliationDeletedList;
    /** Non-blocking info entries (stale tombstones, tombstone applied with class still in code). See `exports_reconciliation_info`. */
    info: BetaWorkersVersionsCreateResponseExportsReconciliationInfoList;
    /** Source class names whose tombstone entry is now stale and safe to delete from `exports` (no remaining referencing scripts). */
    removableEntries: BetaWorkersVersionsCreateResponseExportsReconciliationRemovableEntriesList;
    /** Applied `renamed` tombstones. */
    renamed: BetaWorkersVersionsCreateResponseExportsReconciliationRenamedList;
    /** Phase-1 transfer hints recorded on the target side. */
    transferPending: BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingList;
    /** Committed `transferred` tombstones (phase-2). */
    transferred: BetaWorkersVersionsCreateResponseExportsReconciliationTransferredList;
    /** Class names whose provisioned namespace was mutated in place. */
    updated: BetaWorkersVersionsCreateResponseExportsReconciliationUpdatedList;
    /** Non-blocking warnings. See `exports_reconciliation_warning`. */
    warnings: BetaWorkersVersionsCreateResponseExportsReconciliationWarningsList;
}
export interface BetaWorkersVersionsCreateResponseLimits {
    /** CPU time limit in milliseconds. */
    cpuMs?: number | null;
    /** Subrequest limit per request. */
    subrequests?: number | null;
}
export type BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export type BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationNewClassesList = Array<string>;
export type BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export interface BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem {
    from?: string | null;
    to?: string | null;
}
export type BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export interface BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem {
    from?: string | null;
    fromScript?: string | null;
    to?: string | null;
}
export type BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface BetaWorkersVersionsCreateResponseMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesList | null;
}
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsList = Array<BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export interface BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export type BetaWorkersVersionsCreateResponseMigrations = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigration | BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrations;
export type BetaWorkersVersionsCreateResponseModulesItem = BetaWorkersVersionsCreateRequestModulesItem;
export type BetaWorkersVersionsCreateResponseModulesList = Array<BetaWorkersVersionsCreateRequestModulesItem>;
export type BetaWorkersVersionsCreateResponsePackageDependenciesItem = BetaWorkersVersionsCreateRequestPackageDependenciesItem;
export type BetaWorkersVersionsCreateResponsePackageDependenciesList = Array<BetaWorkersVersionsCreateRequestPackageDependenciesItem>;
export type BetaWorkersVersionsCreateResponsePlacementModeMode = "smart";
export interface BetaWorkersVersionsCreateResponsePlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersVersionsCreateResponsePlacementModeMode;
}
export type BetaWorkersVersionsCreateResponsePlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type BetaWorkersVersionsCreateResponsePlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersVersionsCreateResponsePlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type BetaWorkersVersionsCreateResponsePlacementCase4Mode = "targeted";
export interface BetaWorkersVersionsCreateResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type BetaWorkersVersionsCreateResponsePlacementCase5Mode = "targeted";
export interface BetaWorkersVersionsCreateResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateResponsePlacementCase5Mode;
}
export type BetaWorkersVersionsCreateResponsePlacementCase6Mode = "targeted";
export interface BetaWorkersVersionsCreateResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateResponsePlacementCase6Mode;
}
export type BetaWorkersVersionsCreateResponsePlacementCase7Mode = "targeted";
export type BetaWorkersVersionsCreateResponsePlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type BetaWorkersVersionsCreateResponsePlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersVersionsCreateResponsePlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersVersionsCreateResponsePlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersVersionsCreateResponsePlacementCase7TargetList = Array<BetaWorkersVersionsCreateResponsePlacementCase7TargetItem>;
export interface BetaWorkersVersionsCreateResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersVersionsCreateResponsePlacementCase7TargetList;
}
export type BetaWorkersVersionsCreateResponsePlacement = BetaWorkersVersionsCreateResponsePlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | BetaWorkersVersionsCreateResponsePlacementCase4 | BetaWorkersVersionsCreateResponsePlacementCase5 | BetaWorkersVersionsCreateResponsePlacementCase6 | BetaWorkersVersionsCreateResponsePlacementCase7;
export type BetaWorkersVersionsCreateResponseUsageModel = "standard" | "bundled" | "unbound";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateBetaWorkerVersionResponse {
    /** Version identifier. */
    id: string;
    /** When the version was created. */
    createdOn: string;
    /** The integer version number, starting from one. */
    number: number;
    /** All routable URLs that always point to this version. Does not include alias URLs, since aliases can be updated to point to a different version. */
    urls: BetaWorkersVersionsCreateResponseUrlsList;
    /** Metadata about the version. */
    annotations?: BetaWorkersVersionsCreateResponseAnnotations | null;
    /** Configuration for assets within a Worker. */
    assets?: BetaWorkersVersionsCreateResponseAssets | null;
    /** Email of the user who created the version. */
    authorEmail?: string | null;
    /** Identifier of the user who created the version. */
    authorId?: string | null;
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: BetaWorkersVersionsCreateResponseBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: BetaWorkersVersionsCreateResponseCompatibilityFlagsList | null;
    /** List of containers attached to a Worker. Containers can only be attached to Durable Object classes of this Worker script. */
    containers?: BetaWorkersVersionsCreateResponseContainersList | null;
    /** Declarative exports for the version, including Durable Object classes (with their `storage` backend) and named Worker entrypoints. On reads, tombstoned lifecycle entries are omitted, so only live exports (`created` and `expecting-transfer`) are returned. `exports` and `migrations` are mutually exclusive on upload. */
    exports?: BetaWorkersVersionsCreateResponseExportsMap | null;
    /** Summary of the declarative exports reconciliation that ran on this upload. Populated only when the uploaded metadata included an `exports` block. Durable Object entries drive reconciliation; `type: worker` entries do not contribute to this summary. */
    exportsReconciliation?: BetaWorkersVersionsCreateResponseExportsReconciliation | null;
    /** Resource limits enforced at runtime. */
    limits?: BetaWorkersVersionsCreateResponseLimits | null;
    /** The name of the main module in the `modules` array (e.g. the name of the module that exports a `fetch` handler). */
    mainModule?: string | null;
    /** Durable Object migration tag. Set when the version is deployed. Omitted if the version has not been deployed or the Worker does not use Durable Objects. */
    migrationTag?: string | null;
    /** Migrations for Durable Objects associated with the version. Migrations are applied when the version is deployed. */
    migrations?: BetaWorkersVersionsCreateResponseMigrations | null;
    /** Code, sourcemaps, and other content used at runtime. */
    modules?: BetaWorkersVersionsCreateResponseModulesList | null;
    /** The list of npm packages that were installed and used when this Worker version was built. */
    packageDependencies?: BetaWorkersVersionsCreateResponsePackageDependenciesList | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: BetaWorkersVersionsCreateResponsePlacement | null;
    /** The client used to create the version. */
    source?: string | null;
    /** Time in milliseconds spent on [Worker startup](https://developers.cloudflare.com/workers/platform/limits/#worker-startup-time). */
    startupTimeMs?: number | null;
    /** Usage model for the version. */
    usageModel?: BetaWorkersVersionsCreateResponseUsageModel | null;
}
export type ObservabilityDestinationsCreateRequestConfigurationHeadersMap = {
    [key: string]: string | undefined;
};
export type ObservabilityDestinationsCreateRequestConfigurationLogpushDataset = "opentelemetry-traces" | "opentelemetry-logs" | "opentelemetry-metrics";
export type ObservabilityDestinationsCreateRequestConfigurationType = "logpush";
export interface ObservabilityDestinationsCreateRequestConfiguration {
    headers: ObservabilityDestinationsCreateRequestConfigurationHeadersMap;
    logpushDataset: ObservabilityDestinationsCreateRequestConfigurationLogpushDataset | (string & {});
    type: ObservabilityDestinationsCreateRequestConfigurationType | (string & {});
    url: string;
}
export interface CreateObservabilityDestinationRequest {
    accountId: string;
    configuration: ObservabilityDestinationsCreateRequestConfiguration;
    enabled: boolean;
    name: string;
    skipPreflightCheck?: boolean;
}
export type ObservabilityDestinationsCreateResponseConfigurationHeadersMap = {
    [key: string]: string | undefined;
};
export interface ObservabilityDestinationsCreateResponseConfigurationJobStatus {
    errorMessage: string;
    lastComplete: string;
    lastError: string;
}
export type ObservabilityDestinationsCreateResponseConfigurationLogpushDataset = "opentelemetry-traces" | "opentelemetry-logs" | "opentelemetry-metrics";
export type ObservabilityDestinationsCreateResponseConfigurationType = "logpush";
export interface ObservabilityDestinationsCreateResponseConfiguration {
    headers: ObservabilityDestinationsCreateResponseConfigurationHeadersMap;
    jobStatus: ObservabilityDestinationsCreateResponseConfigurationJobStatus;
    logpushDataset: ObservabilityDestinationsCreateResponseConfigurationLogpushDataset;
    type: ObservabilityDestinationsCreateResponseConfigurationType;
    url: string;
    /** The underlying Logpush destination string: the URL with the configured headers encoded as query parameters, so it can carry credentials. Optional: the 2026-10-21 spec omits it. */
    destinationConf?: string | null;
}
export type ObservabilityDestinationsCreateResponseScriptsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateObservabilityDestinationResponse {
    configuration: ObservabilityDestinationsCreateResponseConfiguration;
    enabled: boolean;
    name: string;
    scripts: ObservabilityDestinationsCreateResponseScriptsList;
    slug: string;
}
export interface CreateObservabilityIssueAutomationRequest {
    accountId: string;
    /** Id of the notification policy to notify, normally one with alert type `workers_observability_real_time_issue`. Cloudflare does not validate that it exists. */
    policyId: string;
    /** Automation name (1-200 characters). Cloudflare generates one when omitted. */
    name?: string;
    /** Whether the automation is enabled. Defaults to true. */
    enabled?: boolean;
    /** Limit the automation to one Worker (script name). Omit for every Worker in the account. */
    service?: string;
    /** Notify once an issue has occurred this many times. Exactly one of `afterOccurrences` or `afterInactivitySeconds` is required. */
    afterOccurrences?: number;
    /** Notify when an issue recurs after this many seconds of inactivity (3600-31536000). Exactly one of `afterOccurrences` or `afterInactivitySeconds` is required. */
    afterInactivitySeconds?: number;
}
export type ObservabilityIssueAutomationScope = "account" | "service";
export type ObservabilityIssueAutomationTriggerType = "occurrence_threshold" | "recurrence_after_inactivity";
export interface ObservabilityIssueAutomation {
    /** Automation id. */
    id: string;
    /** Revision, incremented on every update. */
    revision: number;
    /** Automation name. Cloudflare generates one (e.g. "Notify after 5 occurrences") when omitted. */
    name: string;
    enabled: boolean;
    /** Id of the notification policy (`workers_observability_real_time_issue`) the automation notifies. */
    ansPolicyId: string;
    /** `service` when the automation is limited to one Worker, otherwise `account`. */
    scope: ObservabilityIssueAutomationScope;
    /** Service type of `service` (e.g. `workers`). */
    serviceType?: string | null;
    /** Worker the automation is limited to. */
    service?: string | null;
    triggerType: ObservabilityIssueAutomationTriggerType;
    /** Occurrence count for an `occurrence_threshold` trigger. */
    threshold?: number | null;
    /** Inactivity period for a `recurrence_after_inactivity` trigger. */
    inactivitySeconds?: number | null;
    createdByUserId?: string | null;
    updatedByUserId?: string | null;
    /** Creation time, epoch milliseconds. */
    created?: number | null;
    /** Last update time, epoch milliseconds. */
    updated?: number | null;
}
export interface ObservabilityIssueAutomationResponse {
    automation: ObservabilityIssueAutomation;
}
export type ObservabilityQueriesCreateRequestParametersCalculationsItemCase0Operator = "count" | "COUNT";
export type ObservabilityQueriesCreateRequestParametersCalculationsItemCase0KeyType = "string" | "number" | "boolean";
export interface ObservabilityQueriesCreateRequestParametersCalculationsItemCase0 {
    operator: ObservabilityQueriesCreateRequestParametersCalculationsItemCase0Operator | (string & {});
    alias?: string;
    key?: string;
    keyType?: ObservabilityQueriesCreateRequestParametersCalculationsItemCase0KeyType | (string & {});
}
export type ObservabilityQueriesCreateRequestParametersCalculationsItemCase1Operator = "uniq" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export type ObservabilityQueriesCreateRequestParametersCalculationsItemCase1KeyType = "string" | "number" | "boolean";
export interface ObservabilityQueriesCreateRequestParametersCalculationsItemCase1 {
    key: string;
    operator: ObservabilityQueriesCreateRequestParametersCalculationsItemCase1Operator | (string & {});
    alias?: string;
    keyType?: ObservabilityQueriesCreateRequestParametersCalculationsItemCase1KeyType | (string & {});
}
export type ObservabilityQueriesCreateRequestParametersCalculationsItem = ObservabilityQueriesCreateRequestParametersCalculationsItemCase0 | ObservabilityQueriesCreateRequestParametersCalculationsItemCase1;
export type ObservabilityQueriesCreateRequestParametersCalculationsList = Array<ObservabilityQueriesCreateRequestParametersCalculationsItem>;
export type ObservabilityQueriesCreateRequestParametersDatasetsList = Array<string>;
export type ObservabilityQueriesCreateRequestParametersFilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityQueriesCreateRequestParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityQueriesCreateRequestParametersFiltersItemCase0FiltersList = Array<unknown>;
export type ObservabilityQueriesCreateRequestParametersFiltersItemCase0Kind = "group";
export interface ObservabilityQueriesCreateRequestParametersFiltersItemCase0 {
    filterCombination: ObservabilityQueriesCreateRequestParametersFiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityQueriesCreateRequestParametersFiltersItemCase0FiltersList;
    kind: ObservabilityQueriesCreateRequestParametersFiltersItemCase0Kind;
}
export type ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafValue;
}
export type ObservabilityQueriesCreateRequestParametersFiltersItem = ObservabilityQueriesCreateRequestParametersFiltersItemCase0 | ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilityQueriesCreateRequestParametersFiltersList = Array<ObservabilityQueriesCreateRequestParametersFiltersItem>;
export type ObservabilityQueriesCreateRequestParametersGroupBysItemType = "string" | "number" | "boolean";
export interface ObservabilityQueriesCreateRequestParametersGroupBysItem {
    type: ObservabilityQueriesCreateRequestParametersGroupBysItemType | (string & {});
    value: string;
}
export type ObservabilityQueriesCreateRequestParametersGroupBysList = Array<ObservabilityQueriesCreateRequestParametersGroupBysItem>;
export type ObservabilityQueriesCreateRequestParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export interface ObservabilityQueriesCreateRequestParametersHavingsItem {
    key: string;
    operation: ObservabilityQueriesCreateRequestParametersHavingsItemOperation | (string & {});
    value: number;
}
export type ObservabilityQueriesCreateRequestParametersHavingsList = Array<ObservabilityQueriesCreateRequestParametersHavingsItem>;
export type ObservabilityQueriesCreateRequestParametersNeedleValue = string | number | boolean;
export interface ObservabilityQueriesCreateRequestParametersNeedle {
    value: ObservabilityQueriesCreateRequestParametersNeedleValue;
    isRegex?: boolean;
    matchCase?: boolean;
}
export type ObservabilityQueriesCreateRequestParametersOrderByOrder = "asc" | "desc";
export interface ObservabilityQueriesCreateRequestParametersOrderBy {
    /** Configure which Calculation to order the results by. */
    value: string;
    /** Set the order of the results */
    order?: ObservabilityQueriesCreateRequestParametersOrderByOrder | (string & {});
}
export interface ObservabilityQueriesCreateRequestParameters {
    /** Create Calculations to compute as part of the query. */
    calculations?: ObservabilityQueriesCreateRequestParametersCalculationsList;
    /** Set the Datasets to query. Leave it empty to query all the datasets. */
    datasets?: ObservabilityQueriesCreateRequestParametersDatasetsList;
    /** Set a Flag to describe how to combine the filters on the query. */
    filterCombination?: ObservabilityQueriesCreateRequestParametersFilterCombination | (string & {});
    /** Configure the Filters to apply to the query. Supports nested groups via kind: 'group'. */
    filters?: ObservabilityQueriesCreateRequestParametersFiltersList;
    /** Define how to group the results of the query. */
    groupBys?: ObservabilityQueriesCreateRequestParametersGroupBysList;
    /** Configure the Having clauses that filter on calculations in the query result. */
    havings?: ObservabilityQueriesCreateRequestParametersHavingsList;
    /** Set a limit on the number of results / records returned by the query */
    limit?: number;
    /** Define an expression to search using full-text search. */
    needle?: ObservabilityQueriesCreateRequestParametersNeedle;
    /** Configure the order of the results returned by the query. */
    orderBy?: ObservabilityQueriesCreateRequestParametersOrderBy;
}
export interface CreateObservabilityQueryRequest {
    accountId: string;
    description: string;
    /** Query name */
    name: string;
    parameters: ObservabilityQueriesCreateRequestParameters;
}
export type ObservabilityQueriesCreateResponseParametersCalculationsItemCase0Operator = "count" | "COUNT";
export type ObservabilityQueriesCreateResponseParametersCalculationsItemCase0KeyType = "string" | "number" | "boolean";
export interface ObservabilityQueriesCreateResponseParametersCalculationsItemCase0 {
    operator: ObservabilityQueriesCreateResponseParametersCalculationsItemCase0Operator;
    alias?: string | null;
    key?: string | null;
    keyType?: ObservabilityQueriesCreateResponseParametersCalculationsItemCase0KeyType | null;
}
export type ObservabilityQueriesCreateResponseParametersCalculationsItemCase1Operator = "uniq" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export type ObservabilityQueriesCreateResponseParametersCalculationsItemCase1KeyType = "string" | "number" | "boolean";
export interface ObservabilityQueriesCreateResponseParametersCalculationsItemCase1 {
    key: string;
    operator: ObservabilityQueriesCreateResponseParametersCalculationsItemCase1Operator;
    alias?: string | null;
    keyType?: ObservabilityQueriesCreateResponseParametersCalculationsItemCase1KeyType | null;
}
export type ObservabilityQueriesCreateResponseParametersCalculationsItem = ObservabilityQueriesCreateResponseParametersCalculationsItemCase0 | ObservabilityQueriesCreateResponseParametersCalculationsItemCase1;
export type ObservabilityQueriesCreateResponseParametersCalculationsList = Array<ObservabilityQueriesCreateResponseParametersCalculationsItem>;
export type ObservabilityQueriesCreateResponseParametersDatasetsList = Array<string>;
export type ObservabilityQueriesCreateResponseParametersFilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityQueriesCreateResponseParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityQueriesCreateResponseParametersFiltersItemCase0FiltersList = Array<unknown>;
export type ObservabilityQueriesCreateResponseParametersFiltersItemCase0Kind = "group";
export interface ObservabilityQueriesCreateResponseParametersFiltersItemCase0 {
    filterCombination: ObservabilityQueriesCreateResponseParametersFiltersItemCase0FilterCombination;
    filters: ObservabilityQueriesCreateResponseParametersFiltersItemCase0FiltersList;
    kind: ObservabilityQueriesCreateResponseParametersFiltersItemCase0Kind;
}
export type ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafOperation;
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafType;
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafKind | null;
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafValue | null;
}
export type ObservabilityQueriesCreateResponseParametersFiltersItem = ObservabilityQueriesCreateResponseParametersFiltersItemCase0 | ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilityQueriesCreateResponseParametersFiltersList = Array<ObservabilityQueriesCreateResponseParametersFiltersItem>;
export type ObservabilityQueriesCreateResponseParametersGroupBysItemType = "string" | "number" | "boolean";
export interface ObservabilityQueriesCreateResponseParametersGroupBysItem {
    type: ObservabilityQueriesCreateResponseParametersGroupBysItemType;
    value: string;
}
export type ObservabilityQueriesCreateResponseParametersGroupBysList = Array<ObservabilityQueriesCreateResponseParametersGroupBysItem>;
export type ObservabilityQueriesCreateResponseParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export interface ObservabilityQueriesCreateResponseParametersHavingsItem {
    key: string;
    operation: ObservabilityQueriesCreateResponseParametersHavingsItemOperation;
    value: number;
}
export type ObservabilityQueriesCreateResponseParametersHavingsList = Array<ObservabilityQueriesCreateResponseParametersHavingsItem>;
export type ObservabilityQueriesCreateResponseParametersNeedleValue = string | number | boolean;
export interface ObservabilityQueriesCreateResponseParametersNeedle {
    value: ObservabilityQueriesCreateResponseParametersNeedleValue;
    isRegex?: boolean | null;
    matchCase?: boolean | null;
}
export type ObservabilityQueriesCreateResponseParametersOrderByOrder = "asc" | "desc";
export interface ObservabilityQueriesCreateResponseParametersOrderBy {
    /** Configure which Calculation to order the results by. */
    value: string;
    /** Set the order of the results */
    order?: ObservabilityQueriesCreateResponseParametersOrderByOrder | null;
}
export interface ObservabilityQueriesCreateResponseParameters {
    /** Create Calculations to compute as part of the query. */
    calculations?: ObservabilityQueriesCreateResponseParametersCalculationsList | null;
    /** Set the Datasets to query. Leave it empty to query all the datasets. */
    datasets?: ObservabilityQueriesCreateResponseParametersDatasetsList | null;
    /** Set a Flag to describe how to combine the filters on the query. */
    filterCombination?: ObservabilityQueriesCreateResponseParametersFilterCombination | null;
    /** Configure the Filters to apply to the query. Supports nested groups via kind: 'group'. */
    filters?: ObservabilityQueriesCreateResponseParametersFiltersList | null;
    /** Define how to group the results of the query. */
    groupBys?: ObservabilityQueriesCreateResponseParametersGroupBysList | null;
    /** Configure the Having clauses that filter on calculations in the query result. */
    havings?: ObservabilityQueriesCreateResponseParametersHavingsList | null;
    /** Set a limit on the number of results / records returned by the query */
    limit?: number | null;
    /** Define an expression to search using full-text search. */
    needle?: ObservabilityQueriesCreateResponseParametersNeedle | null;
    /** Configure the order of the results returned by the query. */
    orderBy?: ObservabilityQueriesCreateResponseParametersOrderBy | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateObservabilityQueryResponse {
    id: string;
    /** If the query wasn't explcitly saved */
    adhoc: boolean;
    created: string;
    createdBy: string;
    description: string;
    /** Query name */
    name: string;
    parameters: ObservabilityQueriesCreateResponseParameters;
    updated: string;
    updatedBy: string;
}
export interface ObservabilitySharedQueriesCreateRequestTimeframe {
    /** Start timestamp for the query timeframe. Unix timestamp in milliseconds */
    from: number;
    /** End timestamp for the query timeframe. Unix timestamp in milliseconds */
    to: number;
}
export type ObservabilitySharedQueriesCreateRequestChartType = "timeseries_and_aggregate" | "timeseries" | "aggregate" | "distribution";
export type ObservabilitySharedQueriesCreateRequestDistributionScale = "log" | "linear";
export type ObservabilitySharedQueriesCreateRequestParametersCalculationsItemCase0Operator = "count" | "COUNT";
export type ObservabilitySharedQueriesCreateRequestParametersCalculationsItemCase0KeyType = "string" | "number" | "boolean";
export interface ObservabilitySharedQueriesCreateRequestParametersCalculationsItemCase0 {
    /** Aggregation operator to apply. Examples: count, avg, sum, min, max, median, p90, p95, p99, uniq, stddev, variance. */
    operator: ObservabilitySharedQueriesCreateRequestParametersCalculationsItemCase0Operator | (string & {});
    /** Custom label for this calculation in the results. Useful for distinguishing multiple calculations. */
    alias?: string;
    /** Field name to calculate over. Must exist in the data. Verify with the keys endpoint. Required for every operator except `count`, which aggregates whole rows and may omit it. */
    key?: string;
    /** Data type of the key. Required when key is provided to ensure correct aggregation. */
    keyType?: ObservabilitySharedQueriesCreateRequestParametersCalculationsItemCase0KeyType | (string & {});
}
export type ObservabilitySharedQueriesCreateRequestParametersCalculationsItemCase1Operator = "uniq" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export type ObservabilitySharedQueriesCreateRequestParametersCalculationsItemCase1KeyType = "string" | "number" | "boolean";
export interface ObservabilitySharedQueriesCreateRequestParametersCalculationsItemCase1 {
    /** Field name to calculate over. Must exist in the data. Verify with the keys endpoint. Required for every operator except `count`, which aggregates whole rows and may omit it. */
    key: string;
    /** Aggregation operator to apply. Examples: count, avg, sum, min, max, median, p90, p95, p99, uniq, stddev, variance. */
    operator: ObservabilitySharedQueriesCreateRequestParametersCalculationsItemCase1Operator | (string & {});
    /** Custom label for this calculation in the results. Useful for distinguishing multiple calculations. */
    alias?: string;
    /** Data type of the key. Required when key is provided to ensure correct aggregation. */
    keyType?: ObservabilitySharedQueriesCreateRequestParametersCalculationsItemCase1KeyType | (string & {});
}
export type ObservabilitySharedQueriesCreateRequestParametersCalculationsItem = ObservabilitySharedQueriesCreateRequestParametersCalculationsItemCase0 | ObservabilitySharedQueriesCreateRequestParametersCalculationsItemCase1;
export type ObservabilitySharedQueriesCreateRequestParametersCalculationsList = Array<ObservabilitySharedQueriesCreateRequestParametersCalculationsItem>;
export type ObservabilitySharedQueriesCreateRequestParametersDatasetsList = Array<string>;
export type ObservabilitySharedQueriesCreateRequestParametersFilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0FiltersList = Array<unknown>;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0Kind = "group";
export interface ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0 {
    filterCombination: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0FiltersList;
    kind: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0Kind;
}
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue;
}
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItem = ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0 | ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersList = Array<ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItem>;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0Kind = "group";
export interface ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0 {
    filterCombination: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersList;
    kind: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0Kind;
}
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafValue;
}
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItem = ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0 | ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersList = Array<ObservabilitySharedQueriesCreateRequestParametersFiltersItem>;
export type ObservabilitySharedQueriesCreateRequestParametersGroupBysItemType = "string" | "number" | "boolean";
export interface ObservabilitySharedQueriesCreateRequestParametersGroupBysItem {
    /** Data type of the group-by field. */
    type: ObservabilitySharedQueriesCreateRequestParametersGroupBysItemType | (string & {});
    /** Field name to group results by (e.g. $metadata.service, $metadata.statusCode). */
    value: string;
}
export type ObservabilitySharedQueriesCreateRequestParametersGroupBysList = Array<ObservabilitySharedQueriesCreateRequestParametersGroupBysItem>;
export type ObservabilitySharedQueriesCreateRequestParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export interface ObservabilitySharedQueriesCreateRequestParametersHavingsItem {
    /** Calculation alias or operator to filter on after aggregation. */
    key: string;
    /** Numeric comparison operator: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilitySharedQueriesCreateRequestParametersHavingsItemOperation | (string & {});
    /** Threshold value to compare the calculation result against. */
    value: number;
}
export type ObservabilitySharedQueriesCreateRequestParametersHavingsList = Array<ObservabilitySharedQueriesCreateRequestParametersHavingsItem>;
export type ObservabilitySharedQueriesCreateRequestParametersNeedleValue = string | number | boolean;
export interface ObservabilitySharedQueriesCreateRequestParametersNeedle {
    /** The text or pattern to search for. */
    value: ObservabilitySharedQueriesCreateRequestParametersNeedleValue;
    /** When true, treats the value as a regular expression (RE2 syntax). */
    isRegex?: boolean;
    /** When true, performs a case-sensitive search. Defaults to case-insensitive. */
    matchCase?: boolean;
}
export type ObservabilitySharedQueriesCreateRequestParametersOrderByOrder = "asc" | "desc";
export interface ObservabilitySharedQueriesCreateRequestParametersOrderBy {
    /** Alias of the calculation to order results by. Must match the alias (or operator) of a calculation in the query. */
    value: string;
    /** Sort direction: 'asc' for ascending, 'desc' for descending. */
    order?: ObservabilitySharedQueriesCreateRequestParametersOrderByOrder | (string & {});
}
export interface ObservabilitySharedQueriesCreateRequestParameters {
    /** Aggregation calculations to compute (e.g. count, avg, p99). Each calculation produces aggregate values and optional time-series data. */
    calculations?: ObservabilitySharedQueriesCreateRequestParametersCalculationsList;
    /** Datasets to query. Leave empty to query all available datasets. */
    datasets?: ObservabilitySharedQueriesCreateRequestParametersDatasetsList;
    /** Logical operator for combining top-level filters: 'and' (all must match) or 'or' (any must match). Defaults to 'and'. */
    filterCombination?: ObservabilitySharedQueriesCreateRequestParametersFilterCombination | (string & {});
    /** Filters to narrow query results. Use the keys and values endpoints to discover available fields before building filters. Supports nested groups via kind: 'group'. Maximum nesting depth is 4. */
    filters?: ObservabilitySharedQueriesCreateRequestParametersFiltersList;
    /** Fields to group calculation results by. Only applicable when the query view is 'calculations'. Produces per-group aggregate values. */
    groupBys?: ObservabilitySharedQueriesCreateRequestParametersGroupBysList;
    /** Post-aggregation filters applied to calculation results. Use to filter groups after aggregation (e.g. only groups where count &gt; 100). */
    havings?: ObservabilitySharedQueriesCreateRequestParametersHavingsList;
    /** Maximum number of group-by rows to return in calculation results. A value of 10 is a sensible default for most use cases. */
    limit?: number;
    /** Full-text search expression applied across all event fields. Matches events containing the specified text. */
    needle?: ObservabilitySharedQueriesCreateRequestParametersNeedle;
    /** Ordering for grouped calculation results. Only effective when a group-by is present. */
    orderBy?: ObservabilitySharedQueriesCreateRequestParametersOrderBy;
}
export type ObservabilitySharedQueriesCreateRequestView = "traces" | "events" | "calculations" | "invocations" | "requests" | "agents";
export interface CreateObservabilitySharedQueryRequest {
    accountId: string;
    /** Identifier for the query. When parameters are omitted, this ID is used to load a previously saved query's parameters. When providing parameters inline, pass any identifier (e.g. an ad-hoc ID). */
    queryId: string;
    /** Timeframe for the query using Unix timestamps in milliseconds. 'from' must be earlier than 'to'. Narrower timeframes produce faster responses and more specific results. */
    timeframe: ObservabilitySharedQueriesCreateRequestTimeframe;
    /** When true, includes time-series data in the response. */
    chart?: boolean;
    /** Controls the SQL shape and response payload for the 'calculations' view. Omitted or 'timeseries_and_aggregate': current behaviour -- both the time-series and aggregate queries. 'timeseries': time-series only. 'aggregate': aggregate only. 'distribution': a bucketed 2D histogram (time × value buckets) returned in 'distribution' instead of 'calculations'. 'distribution' is not compatible with 'compare' -- combining them returns a 400. */
    chartType?: ObservabilitySharedQueriesCreateRequestChartType | (string & {});
    /** When true, includes a comparison dataset from the previous time period of equal length. */
    compare?: boolean;
    /** Value-axis bucketing for chartType 'distribution'. Omitted or 'log': geometric buckets, best for heavy-tailed latency. 'linear': fixed-width buckets, clearer for narrow or additive ranges. Ignored for other chartTypes. The response echoes the scheme used in distribution.bucketMode. */
    distributionScale?: ObservabilitySharedQueriesCreateRequestDistributionScale | (string & {});
    /** When true, executes the query without persisting the results. Useful for validation or previewing. */
    dry?: boolean;
    /** Number of time-series buckets. Only used when view is 'calculations'. Omit to let the system auto-detect an appropriate granularity. */
    granularity?: number;
    /** When true, omits time-series data from the response and returns only aggregated values. Reduces response size when series are not needed. */
    ignoreSeries?: boolean;
    /** Maximum number of events to return when view is 'events'. Also controls the number of group-by rows when view is 'calculations'. */
    limit?: number;
    /** Cursor for pagination in event, trace, invocation, and agent views. Pass the $metadata.id of the last event, the trace cursor, or AgentRun.id to fetch the next page. */
    offset?: string;
    /** Numeric offset for paginating grouped/pattern results (top-N lists). Use together with limit. Not used by cursor-based pagination. */
    offsetBy?: number;
    /** Pagination direction: 'next' for forward, 'prev' for backward. */
    offsetDirection?: string;
    /** Query parameters defining what data to retrieve -- filters, calculations, group-bys, and ordering. In practice this should always be provided for ad-hoc queries. Only omit when executing a previously saved query by queryId. Use the keys and values endpoints to discover available fields before building filters. */
    parameters?: ObservabilitySharedQueriesCreateRequestParameters;
    /** Controls the shape of the response. 'events': individual log lines matching the query. 'calculations': aggregated metrics (count, avg, p99, etc.) with optional group-by breakdowns and time-series. 'invocations': events grouped by request ID. 'traces': distributed trace summaries. 'agents': agent-specific trace summaries. */
    view?: ObservabilitySharedQueriesCreateRequestView | (string & {});
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateObservabilitySharedQueryResponse {
    /** Specify the ID of the shared query. */
    id: string;
}
export interface PreviewTailConsumer {
    name: string;
}
export type PreviewTailConsumersList = Array<PreviewTailConsumer>;
export interface CreatePreviewRequest {
    accountId: string;
    /** Parent Worker id or script name. */
    workerId: string;
    /** Do not copy the parent's Previews Base configuration onto this Preview. */
    ignoreBaseConfig?: boolean;
    /** Preview name. Defaults to the git branch in wrangler; Alchemy defaults to the stage. */
    name: string;
    logpush?: boolean;
    tailConsumers?: PreviewTailConsumersList;
}
export type PreviewUrlsList = Array<string>;
export interface PreviewResource {
    /** Immutable Preview id. */
    id: string;
    /** Preview name as created (e.g. a git branch). */
    name: string;
    /** DNS-safe slug used in Preview URLs. */
    slug: string;
    /** Parent Worker script name this Preview belongs to. */
    workerName: string;
    /** Stable Preview URLs (always the latest deployment). */
    urls?: PreviewUrlsList | null;
    tags?: PreviewUrlsList | null;
    logpush?: boolean | null;
    tailConsumers?: PreviewTailConsumersList | null;
    createdOn?: string | null;
    updatedOn?: string | null;
}
export interface CreatePreviewDeploymentMetadataAssets {
    jwt?: string;
    config?: unknown;
}
export type CreatePreviewDeploymentMetadataCompatibilityFlagsList = Array<string>;
export interface CreatePreviewDeploymentMetadataContainer {
    className: string;
    name?: string;
    images?: ContainerImageMap;
}
export type CreatePreviewDeploymentMetadataContainersList = Array<CreatePreviewDeploymentMetadataContainer>;
export type PutScriptMetadataExportType = "worker" | "durable-object";
export interface PutScriptMetadataCache {
    enabled?: boolean;
    crossVersionCache?: boolean;
}
export type PutScriptMetadataExportState = "created" | "deleted" | "renamed" | "transferred" | "expecting-transfer";
export interface PutScriptMetadataExport {
    type?: PutScriptMetadataExportType | (string & {});
    cache?: PutScriptMetadataCache;
    storage?: string;
    container?: string;
    state?: PutScriptMetadataExportState | (string & {});
    renamedTo?: string;
    transferredTo?: string;
    transferFrom?: string;
}
export type PutScriptMetadataExports = {
    [key: string]: PutScriptMetadataExport | undefined;
};
export interface CreatePreviewDeploymentMetadata {
    /** Entrypoint module filename. */
    mainModule?: string;
    assets?: CreatePreviewDeploymentMetadataAssets;
    compatibilityDate?: string;
    compatibilityFlags?: CreatePreviewDeploymentMetadataCompatibilityFlagsList;
    /** Version annotations (workers/message, workers/tag, ...). */
    annotations?: unknown;
    /** Durable Object class migrations for this Preview's isolated namespaces. */
    migrations?: unknown;
    limits?: unknown;
    placement?: unknown;
    cacheOptions?: unknown;
    /** Binding map keyed by runtime name (wrangler `env` format). */
    env?: unknown;
    containers?: CreatePreviewDeploymentMetadataContainersList;
    /** Per-export settings keyed by the verbatim export name (default for the default export). */
    exports?: PutScriptMetadataExports;
}
export interface CreatePreviewDeploymentRequest {
    accountId: string;
    workerId: string;
    /** Preview id (not name) -- wrangler uses the resource id returned by createPreview. */
    previewId: string;
    /** JSON-encoded multipart `metadata` part. */
    metadata: CreatePreviewDeploymentMetadata;
    /** Module files comprising the Worker script, appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
}
export interface PreviewDeploymentResource {
    id: string;
    previewId?: string | null;
    previewName?: string | null;
    migrationTag?: string | null;
    /** Pinned deployment URLs for this exact deploy. */
    urls?: PreviewUrlsList | null;
    compatibilityDate?: string | null;
    createdOn?: string | null;
}
export interface CreateRouteRequest {
    /** Identifier. */
    zoneId: string;
    /** Pattern to match incoming requests against. [Learn more](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior). */
    pattern: string;
    /** Name of the script to run if the route matches. */
    script?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRouteResponse {
    /** Identifier. */
    id: string;
    /** Pattern to match incoming requests against. [Learn more](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior). */
    pattern: string;
    /** Name of the script to run if the route matches. */
    script?: string | null;
}
export interface ScriptsAssetsUploadCreateRequestManifestValue {
    /** The hash of the file. */
    hash: string;
    /** The size of the file in bytes. */
    size: number;
}
export type ScriptsAssetsUploadCreateRequestManifestMap = {
    [key: string]: ScriptsAssetsUploadCreateRequestManifestValue | undefined;
};
export interface CreateScriptAssetUploadRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** A manifest ([path]: {hash, size}) map of files to upload. As an example, `/blog/hello-world.html` would be a valid path key. */
    manifest: ScriptsAssetsUploadCreateRequestManifestMap;
}
export type ScriptsAssetsUploadCreateResponseBucketsItemList = Array<string>;
export type ScriptsAssetsUploadCreateResponseBucketsList = Array<ScriptsAssetsUploadCreateResponseBucketsItemList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScriptAssetUploadResponse {
    /** The requests to make to upload assets. */
    buckets?: ScriptsAssetsUploadCreateResponseBucketsList | null;
    /** A JWT to use as authentication for uploading assets. */
    jwt?: string | null;
}
export type ScriptsDeploymentsCreateRequestStrategy = "percentage";
export interface ScriptsDeploymentsCreateRequestVersionsItem {
    /** Percentage of traffic served by this version. */
    percentage: number;
    /** Identifier of the Worker Version. */
    versionId: string;
}
export type ScriptsDeploymentsCreateRequestVersionsList = Array<ScriptsDeploymentsCreateRequestVersionsItem>;
export interface ScriptsDeploymentsCreateRequestAnnotations {
    /** Human-readable message about the deployment. Truncated to 1000 bytes if longer. */
    workersMessage?: string;
    /** Operation that triggered the creation of the deployment. */
    workersTriggeredBy?: string;
}
export interface CreateScriptDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** If set to true, the deployment will be created even if normally blocked by something such rolling back to an older version when a secret has changed. */
    force?: boolean;
    strategy: ScriptsDeploymentsCreateRequestStrategy | (string & {});
    /** Worker versions included in this deployment. Each object must contain a `version_id` UUID and a `percentage`; percentages across all objects must total 100. In the `cf` CLI, pass the entire array as one JSON value to `--versions`, either inline, for example `--versions '[{"version_id":"023e105f-2a42-4f8b-a1c1-73f6a2a30c0f","percentage":100}]'`, or from a JSON file with `--versions @versions.json`. */
    versions: ScriptsDeploymentsCreateRequestVersionsList;
    annotations?: ScriptsDeploymentsCreateRequestAnnotations;
}
export type ScriptsDeploymentsCreateResponseStrategy = "percentage";
export type ScriptsDeploymentsCreateResponseVersionsItem = ScriptsDeploymentsCreateRequestVersionsItem;
export type ScriptsDeploymentsCreateResponseVersionsList = Array<ScriptsDeploymentsCreateRequestVersionsItem>;
export interface ScriptsDeploymentsCreateResponseAnnotations {
    /** Human-readable message about the deployment. Truncated to 1000 bytes if longer. */
    workersMessage?: string | null;
    /** Operation that triggered the creation of the deployment. */
    workersTriggeredBy?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScriptDeploymentResponse {
    id: string;
    createdOn: string;
    source: string;
    strategy: ScriptsDeploymentsCreateResponseStrategy;
    /** Worker versions included in this deployment. Each object must contain a `version_id` UUID and a `percentage`; percentages across all objects must total 100. In the `cf` CLI, pass the entire array as one JSON value to `--versions`, either inline, for example `--versions '[{"version_id":"023e105f-2a42-4f8b-a1c1-73f6a2a30c0f","percentage":100}]'`, or from a JSON file with `--versions @versions.json`. */
    versions: ScriptsDeploymentsCreateResponseVersionsList;
    annotations?: ScriptsDeploymentsCreateResponseAnnotations | null;
    authorEmail?: string | null;
}
export interface CreateScriptEdgePreviewWranglerSessionConfigWorkersDev {
    /** Route the preview through workers.dev. */
    workersDev: boolean;
    minimalMode?: boolean;
}
export type CreateScriptEdgePreviewWranglerSessionConfigRoutesList = Array<string>;
export interface CreateScriptEdgePreviewWranglerSessionConfigRoutes {
    /** Routes to serve the preview on. */
    routes: CreateScriptEdgePreviewWranglerSessionConfigRoutesList;
    minimalMode?: boolean;
}
export type CreateScriptEdgePreviewWranglerSessionConfig = CreateScriptEdgePreviewWranglerSessionConfigWorkersDev | CreateScriptEdgePreviewWranglerSessionConfigRoutes;
export type CreateScriptEdgePreviewMetadataStringList = Array<string>;
export type CreateScriptEdgePreviewMetadataUsageModel = "bundled" | "unbound" | "standard";
export type CreateScriptEdgePreviewMetadataBindingPlainTextType = "plain_text";
export interface CreateScriptEdgePreviewMetadataBindingPlainText {
    type: CreateScriptEdgePreviewMetadataBindingPlainTextType;
    name: string;
    text: string;
}
export type CreateScriptEdgePreviewMetadataBindingSecretTextType = "secret_text";
export interface CreateScriptEdgePreviewMetadataBindingSecretText {
    type: CreateScriptEdgePreviewMetadataBindingSecretTextType;
    name: string;
    text: string;
}
export type CreateScriptEdgePreviewMetadataBindingJsonType = "json";
export interface CreateScriptEdgePreviewMetadataBindingJson {
    type: CreateScriptEdgePreviewMetadataBindingJsonType;
    name: string;
    json: unknown;
}
export type CreateScriptEdgePreviewMetadataBindingKvNamespaceType = "kv_namespace";
export interface CreateScriptEdgePreviewMetadataBindingKvNamespace {
    type: CreateScriptEdgePreviewMetadataBindingKvNamespaceType;
    name: string;
    namespaceId: string;
    raw?: boolean;
}
export type CreateScriptEdgePreviewMetadataBindingDurableObjectNamespaceType = "durable_object_namespace";
export interface CreateScriptEdgePreviewMetadataBindingDurableObjectNamespace {
    type: CreateScriptEdgePreviewMetadataBindingDurableObjectNamespaceType;
    name: string;
    className: string;
    scriptName?: string;
    environment?: string;
    namespaceId?: string;
}
export type CreateScriptEdgePreviewMetadataBindingR2BucketType = "r2_bucket";
export interface CreateScriptEdgePreviewMetadataBindingR2Bucket {
    type: CreateScriptEdgePreviewMetadataBindingR2BucketType;
    name: string;
    bucketName: string;
    jurisdiction?: string;
    raw?: boolean;
}
export type CreateScriptEdgePreviewMetadataBindingD1Type = "d1";
export interface CreateScriptEdgePreviewMetadataBindingD1 {
    type: CreateScriptEdgePreviewMetadataBindingD1Type;
    name: string;
    id: string;
    internalEnv?: string;
    raw?: boolean;
}
export type CreateScriptEdgePreviewMetadataBindingQueueType = "queue";
export interface CreateScriptEdgePreviewMetadataBindingQueue {
    type: CreateScriptEdgePreviewMetadataBindingQueueType;
    name: string;
    queueName: string;
    deliveryDelay?: number;
    raw?: boolean;
}
export type CreateScriptEdgePreviewMetadataBindingServiceType = "service";
export interface CreateScriptEdgePreviewMetadataBindingService {
    type: CreateScriptEdgePreviewMetadataBindingServiceType;
    name: string;
    service: string;
    environment?: string;
    entrypoint?: string;
    crossAccountGrant?: string;
}
export type CreateScriptEdgePreviewMetadataBindingAiType = "ai";
export interface CreateScriptEdgePreviewMetadataBindingAi {
    type: CreateScriptEdgePreviewMetadataBindingAiType;
    name: string;
    staging?: boolean;
    raw?: boolean;
}
export type CreateScriptEdgePreviewMetadataBindingBrowserType = "browser";
export interface CreateScriptEdgePreviewMetadataBindingBrowser {
    type: CreateScriptEdgePreviewMetadataBindingBrowserType;
    name: string;
    raw?: boolean;
}
export type CreateScriptEdgePreviewMetadataBindingImagesType = "images";
export interface CreateScriptEdgePreviewMetadataBindingImages {
    type: CreateScriptEdgePreviewMetadataBindingImagesType;
    name: string;
    raw?: boolean;
}
export type CreateScriptEdgePreviewMetadataBindingVectorizeType = "vectorize";
export interface CreateScriptEdgePreviewMetadataBindingVectorize {
    type: CreateScriptEdgePreviewMetadataBindingVectorizeType;
    name: string;
    indexName: string;
    internalEnv?: string;
    raw?: boolean;
}
export type CreateScriptEdgePreviewMetadataBindingWorkflowType = "workflow";
export interface CreateScriptEdgePreviewMetadataBindingWorkflow {
    type: CreateScriptEdgePreviewMetadataBindingWorkflowType;
    name: string;
    workflowName: string;
    className: string;
    scriptName?: string;
    raw?: boolean;
}
export type CreateScriptEdgePreviewMetadataBindingHyperdriveType = "hyperdrive";
export interface CreateScriptEdgePreviewMetadataBindingHyperdrive {
    type: CreateScriptEdgePreviewMetadataBindingHyperdriveType;
    name: string;
    id: string;
}
export type CreateScriptEdgePreviewMetadataBindingAnalyticsEngineType = "analytics_engine";
export interface CreateScriptEdgePreviewMetadataBindingAnalyticsEngine {
    type: CreateScriptEdgePreviewMetadataBindingAnalyticsEngineType;
    name: string;
    dataset?: string;
}
export type CreateScriptEdgePreviewMetadataBindingDispatchNamespaceType = "dispatch_namespace";
export interface CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundWorker {
    service?: string;
    environment?: string;
}
export type CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundParam = PreviewTailConsumer;
export type CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundParamsList = Array<PreviewTailConsumer>;
export interface CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutbound {
    worker?: CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundWorker;
    params?: CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundParamsList;
}
export interface CreateScriptEdgePreviewMetadataBindingDispatchNamespace {
    type: CreateScriptEdgePreviewMetadataBindingDispatchNamespaceType;
    name: string;
    namespace: string;
    outbound?: CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutbound;
}
export type CreateScriptEdgePreviewMetadataBindingSendEmailType = "send_email";
export interface CreateScriptEdgePreviewMetadataBindingSendEmail {
    type: CreateScriptEdgePreviewMetadataBindingSendEmailType;
    name: string;
    destinationAddress?: string;
    allowedDestinationAddresses?: CreateScriptEdgePreviewMetadataStringList;
    allowedSenderAddresses?: CreateScriptEdgePreviewMetadataStringList;
}
export type CreateScriptEdgePreviewMetadataBindingMtlsCertificateType = "mtls_certificate";
export interface CreateScriptEdgePreviewMetadataBindingMtlsCertificate {
    type: CreateScriptEdgePreviewMetadataBindingMtlsCertificateType;
    name: string;
    certificateId: string;
}
export type CreateScriptEdgePreviewMetadataBindingWasmModuleType = "wasm_module";
export interface CreateScriptEdgePreviewMetadataBindingWasmModule {
    type: CreateScriptEdgePreviewMetadataBindingWasmModuleType;
    name: string;
    part: string;
}
export type CreateScriptEdgePreviewMetadataBindingTextBlobType = "text_blob";
export interface CreateScriptEdgePreviewMetadataBindingTextBlob {
    type: CreateScriptEdgePreviewMetadataBindingTextBlobType;
    name: string;
    part: string;
}
export type CreateScriptEdgePreviewMetadataBindingDataBlobType = "data_blob";
export interface CreateScriptEdgePreviewMetadataBindingDataBlob {
    type: CreateScriptEdgePreviewMetadataBindingDataBlobType;
    name: string;
    part: string;
}
export type CreateScriptEdgePreviewMetadataBindingPipelinesType = "pipelines";
export interface CreateScriptEdgePreviewMetadataBindingPipelines {
    type: CreateScriptEdgePreviewMetadataBindingPipelinesType;
    name: string;
    pipeline: string;
}
export type CreateScriptEdgePreviewMetadataBindingSecretsStoreSecretType = "secrets_store_secret";
export interface CreateScriptEdgePreviewMetadataBindingSecretsStoreSecret {
    type: CreateScriptEdgePreviewMetadataBindingSecretsStoreSecretType;
    name: string;
    storeId: string;
    secretName: string;
}
export type CreateScriptEdgePreviewMetadataBindingStreamType = "stream";
export interface CreateScriptEdgePreviewMetadataBindingStream {
    type: CreateScriptEdgePreviewMetadataBindingStreamType;
    name: string;
}
export type CreateScriptEdgePreviewMetadataBindingMediaType = "media";
export interface CreateScriptEdgePreviewMetadataBindingMedia {
    type: CreateScriptEdgePreviewMetadataBindingMediaType;
    name: string;
}
export type CreateScriptEdgePreviewMetadataBindingVersionMetadataType = "version_metadata";
export interface CreateScriptEdgePreviewMetadataBindingVersionMetadata {
    type: CreateScriptEdgePreviewMetadataBindingVersionMetadataType;
    name: string;
}
export type CreateScriptEdgePreviewMetadataBindingAssetsType = "assets";
export interface CreateScriptEdgePreviewMetadataBindingAssets {
    type: CreateScriptEdgePreviewMetadataBindingAssetsType;
    name: string;
}
export type CreateScriptEdgePreviewMetadataBindingWorkerLoaderType = "worker_loader";
export interface CreateScriptEdgePreviewMetadataBindingWorkerLoader {
    type: CreateScriptEdgePreviewMetadataBindingWorkerLoaderType;
    name: string;
}
export type CreateScriptEdgePreviewMetadataBindingLogfwdrType = "logfwdr";
export interface CreateScriptEdgePreviewMetadataBindingLogfwdr {
    type: CreateScriptEdgePreviewMetadataBindingLogfwdrType;
    name: string;
    destination: string;
}
export type CreateScriptEdgePreviewMetadataBindingAiSearchNamespaceType = "ai_search_namespace";
export interface CreateScriptEdgePreviewMetadataBindingAiSearchNamespace {
    type: CreateScriptEdgePreviewMetadataBindingAiSearchNamespaceType;
    name: string;
    namespace: string;
}
export type CreateScriptEdgePreviewMetadataBindingAiSearchType = "ai_search";
export interface CreateScriptEdgePreviewMetadataBindingAiSearch {
    type: CreateScriptEdgePreviewMetadataBindingAiSearchType;
    name: string;
    instanceName: string;
}
export type CreateScriptEdgePreviewMetadataBindingRatelimitType = "ratelimit";
export type CreateScriptEdgePreviewMetadataBindingRatelimitPeriod = "10" | "60";
export interface CreateScriptEdgePreviewMetadataBindingRatelimitSimple {
    limit: number;
    period: CreateScriptEdgePreviewMetadataBindingRatelimitPeriod | (string & {});
}
export interface CreateScriptEdgePreviewMetadataBindingRatelimit {
    type: CreateScriptEdgePreviewMetadataBindingRatelimitType;
    name: string;
    namespaceId: string;
    simple: CreateScriptEdgePreviewMetadataBindingRatelimitSimple;
}
export type CreateScriptEdgePreviewMetadataBindingArtifactsType = "artifacts";
export interface CreateScriptEdgePreviewMetadataBindingArtifacts {
    type: CreateScriptEdgePreviewMetadataBindingArtifactsType;
    name: string;
    namespace: string;
}
export type CreateScriptEdgePreviewMetadataBindingUnsafeHelloWorldType = "unsafe_hello_world";
export interface CreateScriptEdgePreviewMetadataBindingUnsafeHelloWorld {
    type: CreateScriptEdgePreviewMetadataBindingUnsafeHelloWorldType;
    name: string;
    enableTimer?: boolean;
}
export type CreateScriptEdgePreviewMetadataBindingFlagshipType = "flagship";
export interface CreateScriptEdgePreviewMetadataBindingFlagship {
    type: CreateScriptEdgePreviewMetadataBindingFlagshipType;
    name: string;
    appId: string;
}
export type CreateScriptEdgePreviewMetadataBindingVpcServiceType = "vpc_service";
export interface CreateScriptEdgePreviewMetadataBindingVpcService {
    type: CreateScriptEdgePreviewMetadataBindingVpcServiceType;
    name: string;
    serviceId: string;
}
export type CreateScriptEdgePreviewMetadataBindingVpcNetworkType = "vpc_network";
export interface CreateScriptEdgePreviewMetadataBindingVpcNetwork {
    type: CreateScriptEdgePreviewMetadataBindingVpcNetworkType;
    name: string;
    tunnelId?: string;
    networkId?: string;
}
export type CreateScriptEdgePreviewMetadataBindingInheritType = "inherit";
export interface CreateScriptEdgePreviewMetadataBindingInherit {
    type: CreateScriptEdgePreviewMetadataBindingInheritType;
    name: string;
}
export type CreateScriptEdgePreviewMetadataBinding = CreateScriptEdgePreviewMetadataBindingPlainText | CreateScriptEdgePreviewMetadataBindingSecretText | CreateScriptEdgePreviewMetadataBindingJson | CreateScriptEdgePreviewMetadataBindingKvNamespace | CreateScriptEdgePreviewMetadataBindingDurableObjectNamespace | CreateScriptEdgePreviewMetadataBindingR2Bucket | CreateScriptEdgePreviewMetadataBindingD1 | CreateScriptEdgePreviewMetadataBindingQueue | CreateScriptEdgePreviewMetadataBindingService | CreateScriptEdgePreviewMetadataBindingAi | CreateScriptEdgePreviewMetadataBindingBrowser | CreateScriptEdgePreviewMetadataBindingImages | CreateScriptEdgePreviewMetadataBindingVectorize | CreateScriptEdgePreviewMetadataBindingWorkflow | CreateScriptEdgePreviewMetadataBindingHyperdrive | CreateScriptEdgePreviewMetadataBindingAnalyticsEngine | CreateScriptEdgePreviewMetadataBindingDispatchNamespace | CreateScriptEdgePreviewMetadataBindingSendEmail | CreateScriptEdgePreviewMetadataBindingMtlsCertificate | CreateScriptEdgePreviewMetadataBindingWasmModule | CreateScriptEdgePreviewMetadataBindingTextBlob | CreateScriptEdgePreviewMetadataBindingDataBlob | CreateScriptEdgePreviewMetadataBindingPipelines | CreateScriptEdgePreviewMetadataBindingSecretsStoreSecret | CreateScriptEdgePreviewMetadataBindingStream | CreateScriptEdgePreviewMetadataBindingMedia | CreateScriptEdgePreviewMetadataBindingVersionMetadata | CreateScriptEdgePreviewMetadataBindingAssets | CreateScriptEdgePreviewMetadataBindingWorkerLoader | CreateScriptEdgePreviewMetadataBindingLogfwdr | CreateScriptEdgePreviewMetadataBindingAiSearchNamespace | CreateScriptEdgePreviewMetadataBindingAiSearch | CreateScriptEdgePreviewMetadataBindingRatelimit | CreateScriptEdgePreviewMetadataBindingArtifacts | CreateScriptEdgePreviewMetadataBindingUnsafeHelloWorld | CreateScriptEdgePreviewMetadataBindingFlagship | CreateScriptEdgePreviewMetadataBindingVpcService | CreateScriptEdgePreviewMetadataBindingVpcNetwork | CreateScriptEdgePreviewMetadataBindingInherit;
export type CreateScriptEdgePreviewMetadataBindingsList = Array<CreateScriptEdgePreviewMetadataBinding>;
export type CreateScriptEdgePreviewMetadataMigrationRenamedClass = BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem;
export type CreateScriptEdgePreviewMetadataMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem>;
export interface CreateScriptEdgePreviewMetadataMigrationStep {
    newClasses?: CreateScriptEdgePreviewMetadataStringList;
    newSqliteClasses?: CreateScriptEdgePreviewMetadataStringList;
    renamedClasses?: CreateScriptEdgePreviewMetadataMigrationRenamedClassesList;
    deletedClasses?: CreateScriptEdgePreviewMetadataStringList;
}
export type CreateScriptEdgePreviewMetadataMigrationStepsList = Array<CreateScriptEdgePreviewMetadataMigrationStep>;
export interface CreateScriptEdgePreviewMetadataMigrations {
    oldTag?: string;
    newTag?: string;
    steps?: CreateScriptEdgePreviewMetadataMigrationStepsList;
}
export type CreateScriptEdgePreviewMetadataPlacementSmartMode = "smart";
export interface CreateScriptEdgePreviewMetadataPlacementSmart {
    mode: CreateScriptEdgePreviewMetadataPlacementSmartMode;
    hint?: string;
}
export interface CreateScriptEdgePreviewMetadataPlacementRegion {
    region: string;
}
export interface CreateScriptEdgePreviewMetadataPlacementHost {
    host: string;
}
export interface CreateScriptEdgePreviewMetadataPlacementHostname {
    hostname: string;
}
export type CreateScriptEdgePreviewMetadataPlacement = CreateScriptEdgePreviewMetadataPlacementSmart | CreateScriptEdgePreviewMetadataPlacementRegion | CreateScriptEdgePreviewMetadataPlacementHost | CreateScriptEdgePreviewMetadataPlacementHostname;
export interface CreateScriptEdgePreviewMetadataTailConsumer {
    service: string;
    environment?: string;
}
export type CreateScriptEdgePreviewMetadataTailConsumersList = Array<CreateScriptEdgePreviewMetadataTailConsumer>;
export interface CreateScriptEdgePreviewMetadataLimits {
    cpuMs?: number;
    subrequests?: number;
}
export type CreateScriptEdgePreviewMetadataAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export type CreateScriptEdgePreviewMetadataAssetsConfigNotFoundHandling = "single-page-application" | "404-page" | "none";
export type CreateScriptEdgePreviewMetadataAssetsConfigRunWorkerFirst = boolean | CreateScriptEdgePreviewMetadataStringList;
export interface CreateScriptEdgePreviewMetadataAssetsConfig {
    htmlHandling?: CreateScriptEdgePreviewMetadataAssetsConfigHtmlHandling | (string & {});
    notFoundHandling?: CreateScriptEdgePreviewMetadataAssetsConfigNotFoundHandling | (string & {});
    runWorkerFirst?: CreateScriptEdgePreviewMetadataAssetsConfigRunWorkerFirst;
    redirects?: string;
    headers?: string;
}
export interface CreateScriptEdgePreviewMetadataAssets {
    jwt?: string;
    config?: CreateScriptEdgePreviewMetadataAssetsConfig;
}
export interface CreateScriptEdgePreviewMetadataObservabilityLogs {
    enabled?: boolean;
    headSamplingRate?: number;
    invocationLogs?: boolean;
    persist?: boolean;
    destinations?: CreateScriptEdgePreviewMetadataStringList;
}
export interface CreateScriptEdgePreviewMetadataObservabilityIssues {
    enabled?: boolean;
}
export interface CreateScriptEdgePreviewMetadataObservabilityTraces {
    enabled?: boolean;
    headSamplingRate?: number;
    persist?: boolean;
    destinations?: CreateScriptEdgePreviewMetadataStringList;
}
export interface CreateScriptEdgePreviewMetadataObservability {
    enabled?: boolean;
    headSamplingRate?: number;
    logs?: CreateScriptEdgePreviewMetadataObservabilityLogs;
    redactQueryString?: boolean;
    issues?: CreateScriptEdgePreviewMetadataObservabilityIssues;
    traces?: CreateScriptEdgePreviewMetadataObservabilityTraces;
}
export type CreateScriptEdgePreviewMetadataContainer = CreatePreviewDeploymentMetadataContainer;
export type CreateScriptEdgePreviewMetadataContainersList = Array<CreatePreviewDeploymentMetadataContainer>;
export interface CreateScriptEdgePreviewMetadata {
    mainModule?: string;
    bodyPart?: string;
    compatibilityDate?: string;
    compatibilityFlags?: CreateScriptEdgePreviewMetadataStringList;
    usageModel?: CreateScriptEdgePreviewMetadataUsageModel | (string & {});
    bindings?: CreateScriptEdgePreviewMetadataBindingsList;
    keepBindings?: CreateScriptEdgePreviewMetadataStringList;
    migrations?: CreateScriptEdgePreviewMetadataMigrations;
    capnpSchema?: string;
    logpush?: boolean;
    placement?: CreateScriptEdgePreviewMetadataPlacement;
    tailConsumers?: CreateScriptEdgePreviewMetadataTailConsumersList;
    streamingTailConsumers?: CreateScriptEdgePreviewMetadataTailConsumersList;
    limits?: CreateScriptEdgePreviewMetadataLimits;
    assets?: CreateScriptEdgePreviewMetadataAssets;
    observability?: CreateScriptEdgePreviewMetadataObservability;
    containers?: CreateScriptEdgePreviewMetadataContainersList;
    annotations?: unknown;
    keepAssets?: boolean;
    tags?: CreateScriptEdgePreviewMetadataStringList;
}
export interface CreateScriptEdgePreviewRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** The session token returned by createSubdomainEdgePreviewSession. */
    cfPreviewUploadConfigToken: string;
    /** Module files comprising the worker script, appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
    /** JSON-encoded multipart part selecting how the preview is routed (workers.dev or explicit routes); without it edge previews cannot opt into workers.dev routing. */
    wranglerSessionConfig?: CreateScriptEdgePreviewWranglerSessionConfig;
    /** JSON-encoded multipart `metadata` part: the preview worker's modules, bindings and settings. */
    metadata?: CreateScriptEdgePreviewMetadata;
}
export interface CreateScriptEdgePreviewResponse {
    /** Token to send as cf-workers-preview-token header when making requests to the preview host. */
    previewToken: string;
    /** URL for tailing live logs from the preview worker. */
    tailUrl?: string | null;
}
export interface CreateScriptSubdomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** Whether the Worker should be available on the workers.dev subdomain. */
    enabled: boolean;
    /** Whether the Worker's Preview URLs should be available on the workers.dev subdomain. */
    previewsEnabled?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScriptSubdomainResponse {
    /** Whether the Worker is available on the workers.dev subdomain. */
    enabled: boolean;
    /** Whether the Worker's Preview URLs are available on the workers.dev subdomain. */
    previewsEnabled: boolean;
}
export type CreateScriptTailFiltersList = Array<unknown>;
export interface CreateScriptTailRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** Tail event filters; an empty list tails everything. */
    filters?: CreateScriptTailFiltersList;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScriptTailResponse {
    /** Identifier. */
    id: string;
    expiresAt: string;
    url: string;
}
export type ScriptsVersionsCreateRequestBindingsInherit = "strict";
export interface PutScriptMetadataAnnotations {
    workersMessage?: string;
    workersTag?: string;
    /** Alias to point at this version (e.g. for gradual deployments). */
    workersAlias?: string;
}
export type PutScriptAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export type PutScriptAssetsConfigNotFoundHandling = "none" | "404-page" | "single-page-application";
export type PutScriptMetadataStringList = Array<string>;
export type PutScriptAssetsConfigRunWorkerFirst = PutScriptMetadataStringList | boolean;
export interface PutScriptAssetsConfig {
    htmlHandling?: PutScriptAssetsConfigHtmlHandling | (string & {});
    notFoundHandling?: PutScriptAssetsConfigNotFoundHandling | (string & {});
    runWorkerFirst?: PutScriptAssetsConfigRunWorkerFirst;
    serveDirectly?: boolean;
    headers?: string;
    redirects?: string;
}
export interface PutScriptMetadataAssets {
    config?: PutScriptAssetsConfig;
    jwt?: string;
}
export type PutScriptBindingAiType = "ai";
export interface PutScriptBindingAi {
    name: string;
    type: PutScriptBindingAiType;
}
export type PutScriptBindingAiSearchType = "ai_search";
export interface PutScriptBindingAiSearch {
    instanceName: string;
    name: string;
    namespace?: string;
    type: PutScriptBindingAiSearchType;
}
export type PutScriptBindingAiSearchNamespaceType = "ai_search_namespace";
export interface PutScriptBindingAiSearchNamespace {
    name: string;
    namespace: string;
    type: PutScriptBindingAiSearchNamespaceType;
}
export type PutScriptBindingAnalyticsEngineType = "analytics_engine";
export interface PutScriptBindingAnalyticsEngine {
    dataset: string;
    name: string;
    type: PutScriptBindingAnalyticsEngineType;
}
export type PutScriptBindingAssetsType = "assets";
export interface PutScriptBindingAssets {
    name: string;
    type: PutScriptBindingAssetsType;
}
export type PutScriptBindingBrowserType = "browser";
export interface PutScriptBindingBrowser {
    name: string;
    type: PutScriptBindingBrowserType;
}
export type PutScriptBindingD1Type = "d1";
export interface PutScriptBindingD1 {
    databaseId: string;
    name: string;
    id?: string;
    type: PutScriptBindingD1Type;
}
export type PutScriptBindingDataBlobType = "data_blob";
export interface PutScriptBindingDataBlob {
    name: string;
    part: string;
    type: PutScriptBindingDataBlobType;
}
export type PutScriptBindingDispatchNamespaceOutboundParam = PreviewTailConsumer;
export type PutScriptBindingDispatchNamespaceOutboundParamsList = Array<PreviewTailConsumer>;
export interface PutScriptBindingDispatchNamespaceOutboundWorker {
    entrypoint?: string;
    environment?: string;
    service?: string;
}
export interface PutScriptBindingDispatchNamespaceOutbound {
    params?: PutScriptBindingDispatchNamespaceOutboundParamsList;
    worker?: PutScriptBindingDispatchNamespaceOutboundWorker;
}
export type PutScriptBindingDispatchNamespaceType = "dispatch_namespace";
export interface PutScriptBindingDispatchNamespace {
    name: string;
    namespace: string;
    outbound?: PutScriptBindingDispatchNamespaceOutbound;
    type: PutScriptBindingDispatchNamespaceType;
}
export type PutScriptBindingDurableObjectNamespaceType = "durable_object_namespace";
export interface PutScriptBindingDurableObjectNamespace {
    name: string;
    className: string;
    dispatchNamespace?: string;
    environment?: string;
    namespaceId?: string;
    scriptName?: string;
    type: PutScriptBindingDurableObjectNamespaceType;
}
export type PutScriptBindingHyperdriveType = "hyperdrive";
export interface PutScriptBindingHyperdrive {
    id: string;
    name: string;
    type: PutScriptBindingHyperdriveType;
}
export type PutScriptBindingInheritType = "inherit";
export interface PutScriptBindingInherit {
    name: string;
    oldName?: string;
    versionId?: string;
    type: PutScriptBindingInheritType;
}
export type PutScriptBindingImagesType = "images";
export interface PutScriptBindingImages {
    name: string;
    type: PutScriptBindingImagesType;
}
export type PutScriptBindingJsonType = "json";
export interface PutScriptBindingJson {
    json: unknown;
    name: string;
    type: PutScriptBindingJsonType;
}
export type PutScriptBindingKvNamespaceType = "kv_namespace";
export interface PutScriptBindingKvNamespace {
    name: string;
    namespaceId: string;
    type: PutScriptBindingKvNamespaceType;
}
export type PutScriptBindingMediaType = "media";
export interface PutScriptBindingMedia {
    name: string;
    type: PutScriptBindingMediaType;
}
export type PutScriptBindingMtlsCertificateType = "mtls_certificate";
export interface PutScriptBindingMtlsCertificate {
    certificateId: string;
    name: string;
    type: PutScriptBindingMtlsCertificateType;
}
export type PutScriptBindingPlainTextType = "plain_text";
export interface PutScriptBindingPlainText {
    name: string;
    text: string;
    type: PutScriptBindingPlainTextType;
}
export type PutScriptBindingPipelinesType = "pipelines";
export interface PutScriptBindingPipelines {
    name: string;
    pipeline: string;
    type: PutScriptBindingPipelinesType;
}
export type PutScriptBindingQueueType = "queue";
export interface PutScriptBindingQueue {
    name: string;
    queueName: string;
    type: PutScriptBindingQueueType;
}
export interface PutScriptBindingRatelimitSimple {
    limit: number;
    period: number;
    mitigationTimeout?: number;
}
export type PutScriptBindingRatelimitType = "ratelimit";
export interface PutScriptBindingRatelimit {
    name: string;
    namespaceId: string;
    simple: PutScriptBindingRatelimitSimple;
    type: PutScriptBindingRatelimitType;
}
export type PutScriptBindingR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export type PutScriptBindingR2BucketType = "r2_bucket";
export interface PutScriptBindingR2Bucket {
    bucketName: string;
    name: string;
    jurisdiction?: PutScriptBindingR2BucketJurisdiction | (string & {});
    type: PutScriptBindingR2BucketType;
}
export type PutScriptBindingSecretTextType = "secret_text";
export interface PutScriptBindingSecretText {
    name: string;
    text: string;
    type: PutScriptBindingSecretTextType;
}
export type PutScriptBindingSendEmailType = "send_email";
export interface PutScriptBindingSendEmail {
    name: string;
    allowedDestinationAddresses?: PutScriptMetadataStringList;
    allowedSenderAddresses?: PutScriptMetadataStringList;
    destinationAddress?: string;
    type: PutScriptBindingSendEmailType;
}
export type PutScriptBindingServiceType = "service";
export interface PutScriptBindingService {
    name: string;
    service: string;
    entrypoint?: string;
    environment?: string;
    type: PutScriptBindingServiceType;
}
export type PutScriptBindingTextBlobType = "text_blob";
export interface PutScriptBindingTextBlob {
    name: string;
    part: string;
    type: PutScriptBindingTextBlobType;
}
export type PutScriptBindingVectorizeType = "vectorize";
export interface PutScriptBindingVectorize {
    indexName: string;
    name: string;
    type: PutScriptBindingVectorizeType;
}
export type PutScriptBindingVersionMetadataType = "version_metadata";
export interface PutScriptBindingVersionMetadata {
    name: string;
    type: PutScriptBindingVersionMetadataType;
}
export type PutScriptBindingSecretsStoreSecretType = "secrets_store_secret";
export interface PutScriptBindingSecretsStoreSecret {
    name: string;
    secretName: string;
    storeId: string;
    type: PutScriptBindingSecretsStoreSecretType;
}
export type PutScriptBindingFlagshipType = "flagship";
export interface PutScriptBindingFlagship {
    appId: string;
    name: string;
    type: PutScriptBindingFlagshipType;
}
export type PutScriptBindingSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type PutScriptBindingSecretKeyUsage = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type PutScriptBindingSecretKeyUsagesList = Array<PutScriptBindingSecretKeyUsage | (string & {})>;
export type PutScriptBindingSecretKeyType = "secret_key";
export interface PutScriptBindingSecretKey {
    algorithm: unknown;
    format: PutScriptBindingSecretKeyFormat | (string & {});
    name: string;
    usages: PutScriptBindingSecretKeyUsagesList;
    keyBase64?: string;
    keyJwk?: unknown;
    type: PutScriptBindingSecretKeyType;
}
export type PutScriptBindingWorkflowType = "workflow";
export interface PutScriptBindingWorkflow {
    name: string;
    workflowName: string;
    className: string;
    scriptName?: string;
    type: PutScriptBindingWorkflowType;
}
export type PutScriptBindingWasmModuleType = "wasm_module";
export interface PutScriptBindingWasmModule {
    name: string;
    part: string;
    type: PutScriptBindingWasmModuleType;
}
export type PutScriptBindingVpcServiceType = "vpc_service";
export interface PutScriptBindingVpcService {
    name: string;
    serviceId: string;
    type: PutScriptBindingVpcServiceType;
}
export type PutScriptBindingVpcNetworkType = "vpc_network";
export interface PutScriptBindingVpcNetwork {
    name: string;
    networkId?: string;
    tunnelId?: string;
    type: PutScriptBindingVpcNetworkType;
}
export type PutScriptBindingWorkerLoaderType = "worker_loader";
export interface PutScriptBindingWorkerLoader {
    name: string;
    type: PutScriptBindingWorkerLoaderType;
}
export type PutScriptBindingArtifactsType = "artifacts";
export interface PutScriptBindingArtifacts {
    name: string;
    namespace: string;
    type: PutScriptBindingArtifactsType;
}
export type PutScriptBindingStreamType = "stream";
export interface PutScriptBindingStream {
    name: string;
    type: PutScriptBindingStreamType;
}
export type PutScriptBindingK2Type = "k2";
export interface PutScriptBindingK2 {
    name: string;
    /** ID of a K2 stream owned by the account deploying the Worker (32 lowercase hex characters). */
    stream: string;
    type: PutScriptBindingK2Type;
}
export type PutScriptBinding = PutScriptBindingAi | PutScriptBindingAiSearch | PutScriptBindingAiSearchNamespace | PutScriptBindingAnalyticsEngine | PutScriptBindingAssets | PutScriptBindingBrowser | PutScriptBindingD1 | PutScriptBindingDataBlob | PutScriptBindingDispatchNamespace | PutScriptBindingDurableObjectNamespace | PutScriptBindingHyperdrive | PutScriptBindingInherit | PutScriptBindingImages | PutScriptBindingJson | PutScriptBindingKvNamespace | PutScriptBindingMedia | PutScriptBindingMtlsCertificate | PutScriptBindingPlainText | PutScriptBindingPipelines | PutScriptBindingQueue | PutScriptBindingRatelimit | PutScriptBindingR2Bucket | PutScriptBindingSecretText | PutScriptBindingSendEmail | PutScriptBindingService | PutScriptBindingTextBlob | PutScriptBindingVectorize | PutScriptBindingVersionMetadata | PutScriptBindingSecretsStoreSecret | PutScriptBindingFlagship | PutScriptBindingSecretKey | PutScriptBindingWorkflow | PutScriptBindingWasmModule | PutScriptBindingVpcService | PutScriptBindingVpcNetwork | PutScriptBindingWorkerLoader | PutScriptBindingArtifacts | PutScriptBindingStream | PutScriptBindingK2;
export type PutScriptMetadataBindingsList = Array<PutScriptBinding>;
export type PutScriptContainer = CreatePreviewDeploymentMetadataContainer;
export type PutScriptMetadataContainersList = Array<CreatePreviewDeploymentMetadataContainer>;
export type PutScriptMetadataLimits = CreateScriptEdgePreviewMetadataLimits;
export type PutScriptMigrationRenamedClass = BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem;
export type PutScriptMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem>;
export type PutScriptMigrationTransferredClass = BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem;
export type PutScriptMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem>;
export interface PutScriptSingleStepMigration {
    deletedClasses?: PutScriptMetadataStringList;
    newClasses?: PutScriptMetadataStringList;
    newSqliteClasses?: PutScriptMetadataStringList;
    newTag?: string;
    oldTag?: string;
    renamedClasses?: PutScriptMigrationRenamedClassesList;
    transferredClasses?: PutScriptMigrationTransferredClassesList;
}
export interface PutScriptMigrationStep {
    deletedClasses?: PutScriptMetadataStringList;
    newClasses?: PutScriptMetadataStringList;
    newSqliteClasses?: PutScriptMetadataStringList;
    renamedClasses?: PutScriptMigrationRenamedClassesList;
    transferredClasses?: PutScriptMigrationTransferredClassesList;
}
export type PutScriptMigrationStepsList = Array<PutScriptMigrationStep>;
export interface PutScriptMultipleStepMigrations {
    newTag?: string;
    oldTag?: string;
    steps?: PutScriptMigrationStepsList;
}
export type PutScriptMetadataMigrations = PutScriptSingleStepMigration | PutScriptMultipleStepMigrations;
export interface PutScriptObservabilityLogs {
    enabled: boolean;
    invocationLogs: boolean;
    destinations?: PutScriptMetadataStringList;
    headSamplingRate?: number | null;
    persist?: boolean;
}
export type PutScriptObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface PutScriptObservabilityTraces {
    destinations?: PutScriptMetadataStringList;
    enabled?: boolean;
    headSamplingRate?: number | null;
    persist?: boolean;
    propagationPolicy?: PutScriptObservabilityTracesPropagationPolicy | (string & {});
}
export interface PutScriptObservabilityIssues {
    /** Whether Workers Issues error monitoring is enabled. */
    enabled: boolean;
}
export interface PutScriptMetadataObservability {
    enabled?: boolean;
    headSamplingRate?: number | null;
    logs?: PutScriptObservabilityLogs | null;
    traces?: PutScriptObservabilityTraces | null;
    issues?: PutScriptObservabilityIssues;
    redactQueryString?: boolean;
}
export type PutScriptPlacementSmartMode = "smart";
export interface PutScriptPlacementSmart {
    mode: PutScriptPlacementSmartMode;
}
export type PutScriptPlacementRegion = CreateScriptEdgePreviewMetadataPlacementRegion;
export type PutScriptPlacementHostname = CreateScriptEdgePreviewMetadataPlacementHostname;
export type PutScriptPlacementHost = CreateScriptEdgePreviewMetadataPlacementHost;
export type PutScriptPlacementTargetedMode = "targeted";
export interface PutScriptPlacementTargetedRegion {
    mode: PutScriptPlacementTargetedMode;
    region: string;
}
export interface PutScriptPlacementTargetedHostname {
    hostname: string;
    mode: PutScriptPlacementTargetedMode;
}
export interface PutScriptPlacementTargetedHost {
    host: string;
    mode: PutScriptPlacementTargetedMode;
}
export type PutScriptPlacementTargetRegion = CreateScriptEdgePreviewMetadataPlacementRegion;
export type PutScriptPlacementTargetHostname = CreateScriptEdgePreviewMetadataPlacementHostname;
export type PutScriptPlacementTargetHost = CreateScriptEdgePreviewMetadataPlacementHost;
export type PutScriptPlacementTarget = CreateScriptEdgePreviewMetadataPlacementRegion | CreateScriptEdgePreviewMetadataPlacementHostname | CreateScriptEdgePreviewMetadataPlacementHost;
export type PutScriptPlacementTargetsList = Array<PutScriptPlacementTarget>;
export interface PutScriptPlacementTargetedList {
    mode: PutScriptPlacementTargetedMode;
    target: PutScriptPlacementTargetsList;
}
export type PutScriptMetadataPlacement = PutScriptPlacementSmart | CreateScriptEdgePreviewMetadataPlacementRegion | CreateScriptEdgePreviewMetadataPlacementHostname | CreateScriptEdgePreviewMetadataPlacementHost | PutScriptPlacementTargetedRegion | PutScriptPlacementTargetedHostname | PutScriptPlacementTargetedHost | PutScriptPlacementTargetedList;
export interface PutScriptTailConsumer {
    service: string;
    environment?: string;
    namespace?: string;
}
export type PutScriptMetadataTailConsumersList = Array<PutScriptTailConsumer>;
export type PutScriptMetadataUsageModel = "standard" | "bundled" | "unbound";
export type PutScriptMetadataStreamingTailConsumersList = Array<PutScriptTailConsumer>;
export interface PutScriptMetadata {
    annotations?: PutScriptMetadataAnnotations;
    assets?: PutScriptMetadataAssets;
    bindings?: PutScriptMetadataBindingsList;
    bodyPart?: string;
    compatibilityDate?: string;
    compatibilityFlags?: PutScriptMetadataStringList;
    containers?: PutScriptMetadataContainersList;
    keepAssets?: boolean;
    keepBindings?: PutScriptMetadataStringList;
    limits?: CreateScriptEdgePreviewMetadataLimits;
    logpush?: boolean;
    mainModule?: string;
    migrations?: PutScriptMetadataMigrations;
    observability?: PutScriptMetadataObservability;
    placement?: PutScriptMetadataPlacement;
    tags?: PutScriptMetadataStringList;
    tailConsumers?: PutScriptMetadataTailConsumersList | null;
    usageModel?: PutScriptMetadataUsageModel | (string & {});
    cacheOptions?: PutScriptMetadataCache;
    streamingTailConsumers?: PutScriptMetadataStreamingTailConsumersList | null;
    /** Per-export settings keyed by the verbatim export name (default for the default export). */
    exports?: PutScriptMetadataExports;
}
export interface CreateScriptVersionRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** When set to "strict", the upload will fail with error 10057 if any `inherit` type bindings cannot be resolved against the latest uploaded version of the Worker, which may not be the deployed version. Without this, unresolvable inherit bindings are silently dropped. */
    bindingsInherit?: ScriptsVersionsCreateRequestBindingsInherit | (string & {});
    metadata: PutScriptMetadata;
    /** Module / asset file parts, appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
}
export type ScriptsVersionsCreateResponseResourcesScriptHandlersList = Array<string>;
export type ScriptsVersionsCreateResponseResourcesScriptNamedHandlersItemHandlersList = Array<string>;
export interface ScriptsVersionsCreateResponseResourcesScriptNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: ScriptsVersionsCreateResponseResourcesScriptNamedHandlersItemHandlersList | null;
    /** The name of the exported class or entrypoint. */
    name?: string | null;
}
export type ScriptsVersionsCreateResponseResourcesScriptNamedHandlersList = Array<ScriptsVersionsCreateResponseResourcesScriptNamedHandlersItem>;
export interface ScriptsVersionsCreateResponseResourcesScript {
    /** Hashed script content */
    etag?: string | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: ScriptsVersionsCreateResponseResourcesScriptHandlersList | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: ScriptsVersionsCreateResponseResourcesScriptNamedHandlersList | null;
}
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeCompatibilityFlagsList = Array<string>;
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkerType = "worker";
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkerCache = BetaWorkersVersionsCreateRequestExportsValueWorkerCache;
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkerState = "created";
export interface ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: BetaWorkersVersionsCreateRequestExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkerState | null;
}
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExportType = "durable-object";
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExportState = "created";
export interface ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExportState | null;
}
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectDeletedExportType;
}
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectRenamedExportType;
}
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectTransferredExportType;
}
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValue = ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorker | ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExport | ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectDeletedExport | ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectRenamedExport | ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectTransferredExport | ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExport;
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsMap = {
    [key: string]: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsValue | undefined;
};
export interface ScriptsVersionsCreateResponseResourcesScriptRuntimeLimits {
    /** The amount of CPU time this Worker can use in milliseconds. */
    cpuMs?: number | null;
}
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeUsageModel = "bundled" | "unbound" | "standard";
export interface ScriptsVersionsCreateResponseResourcesScriptRuntime {
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. */
    compatibilityFlags?: ScriptsVersionsCreateResponseResourcesScriptRuntimeCompatibilityFlagsList | null;
    /** Declarative exports for this version, including Durable Object classes (with their `storage` backend) and named Worker entrypoints. Tombstoned lifecycle entries are omitted, so only live exports (`created` and `expecting-transfer`) are returned. */
    exports?: ScriptsVersionsCreateResponseResourcesScriptRuntimeExportsMap | null;
    /** Resource limits for the Worker. */
    limits?: ScriptsVersionsCreateResponseResourcesScriptRuntimeLimits | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsVersionsCreateResponseResourcesScriptRuntimeUsageModel | null;
    containers?: BetaWorkersVersionsCreateResponseContainersList | null;
}
export interface ScriptsVersionsCreateResponseResources {
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings: unknown;
    script?: ScriptsVersionsCreateResponseResourcesScript | null;
    /** Runtime configuration for the Worker. */
    scriptRuntime?: ScriptsVersionsCreateResponseResourcesScriptRuntime | null;
}
export type ScriptsVersionsCreateResponseExportsReconciliationCreatedList = Array<string>;
export type ScriptsVersionsCreateResponseExportsReconciliationDeletedList = Array<string>;
export type ScriptsVersionsCreateResponseExportsReconciliationInfoItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export type ScriptsVersionsCreateResponseExportsReconciliationInfoItemReferencingScriptsList = Array<string>;
export interface ScriptsVersionsCreateResponseExportsReconciliationInfoItem {
    /** The class name the info entry is about. */
    class: string;
    /** Human-readable explanation. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: ScriptsVersionsCreateResponseExportsReconciliationInfoItemScenario;
    /** The provisioned namespace the entry relates to, when applicable. */
    namespaceId?: string | null;
    /** Other Workers in the account that still bind to the affected class. Advisory: while non-empty the tombstone is not yet safe to remove -- redeploy these Workers with bindings re-pointed first. */
    referencingScripts?: ScriptsVersionsCreateResponseExportsReconciliationInfoItemReferencingScriptsList | null;
}
export type ScriptsVersionsCreateResponseExportsReconciliationInfoList = Array<ScriptsVersionsCreateResponseExportsReconciliationInfoItem>;
export type ScriptsVersionsCreateResponseExportsReconciliationRemovableEntriesList = Array<string>;
export type ScriptsVersionsCreateResponseExportsReconciliationRenamedItem = BetaWorkersVersionsCreateResponseExportsReconciliationRenamedItem;
export type ScriptsVersionsCreateResponseExportsReconciliationRenamedList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationRenamedItem>;
export type ScriptsVersionsCreateResponseExportsReconciliationTransferPendingItem = BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingItem;
export type ScriptsVersionsCreateResponseExportsReconciliationTransferPendingList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingItem>;
export type ScriptsVersionsCreateResponseExportsReconciliationTransferredItemPhase = "committed";
export interface ScriptsVersionsCreateResponseExportsReconciliationTransferredItem {
    /** The source class name that was transferred. */
    class: string;
    /** The transfer phase. Currently always `committed`. */
    phase: ScriptsVersionsCreateResponseExportsReconciliationTransferredItemPhase;
    /** The destination script that now owns the namespace. */
    to: string;
}
export type ScriptsVersionsCreateResponseExportsReconciliationTransferredList = Array<ScriptsVersionsCreateResponseExportsReconciliationTransferredItem>;
export type ScriptsVersionsCreateResponseExportsReconciliationUpdatedList = Array<string>;
export type ScriptsVersionsCreateResponseExportsReconciliationWarningsItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export interface ScriptsVersionsCreateResponseExportsReconciliationWarningsItem {
    /** The class name the warning is about. */
    class: string;
    /** Human-readable explanation of the warning. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: ScriptsVersionsCreateResponseExportsReconciliationWarningsItemScenario;
    /** The provisioned namespace the warning relates to, when applicable. */
    namespaceId?: string | null;
}
export type ScriptsVersionsCreateResponseExportsReconciliationWarningsList = Array<ScriptsVersionsCreateResponseExportsReconciliationWarningsItem>;
export interface ScriptsVersionsCreateResponseExportsReconciliation {
    /** Class names for which a new namespace was provisioned. */
    created: ScriptsVersionsCreateResponseExportsReconciliationCreatedList;
    /** Class names whose namespace was deleted by a `deleted` tombstone. */
    deleted: ScriptsVersionsCreateResponseExportsReconciliationDeletedList;
    /** Non-blocking info entries (stale tombstones, tombstone applied with class still in code). See `exports_reconciliation_info`. */
    info: ScriptsVersionsCreateResponseExportsReconciliationInfoList;
    /** Source class names whose tombstone entry is now stale and safe to delete from `exports` (no remaining referencing scripts). */
    removableEntries: ScriptsVersionsCreateResponseExportsReconciliationRemovableEntriesList;
    /** Applied `renamed` tombstones. */
    renamed: ScriptsVersionsCreateResponseExportsReconciliationRenamedList;
    /** Phase-1 transfer hints recorded on the target side. */
    transferPending: ScriptsVersionsCreateResponseExportsReconciliationTransferPendingList;
    /** Committed `transferred` tombstones (phase-2). */
    transferred: ScriptsVersionsCreateResponseExportsReconciliationTransferredList;
    /** Class names whose provisioned namespace was mutated in place. */
    updated: ScriptsVersionsCreateResponseExportsReconciliationUpdatedList;
    /** Non-blocking warnings. See `exports_reconciliation_warning`. */
    warnings: ScriptsVersionsCreateResponseExportsReconciliationWarningsList;
}
export type ScriptsVersionsCreateResponseMetadataSource = "unknown" | "api" | "wrangler" | "terraform" | "dash" | "cf_cli" | "dash_template" | "integration" | "quick_editor" | "playground" | "workersci";
export interface ScriptsVersionsCreateResponseMetadata {
    /** Email of the user who created the version. */
    authorEmail?: string | null;
    /** Identifier of the user who created the version. */
    authorId?: string | null;
    /** When the version was created. */
    createdOn?: string | null;
    /** Whether the version can be previewed. */
    hasPreview?: boolean | null;
    /** When the version was last modified. */
    modifiedOn?: string | null;
    /** The source of the version upload. */
    source?: ScriptsVersionsCreateResponseMetadataSource | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScriptVersionResponse {
    resources: ScriptsVersionsCreateResponseResources;
    /** Unique identifier for the version. */
    id?: string | null;
    /** Summary of the declarative exports reconciliation that ran on this upload. Populated only when the uploaded metadata included an `exports` block. Durable Object entries drive reconciliation; `type: worker` entries do not contribute to this summary. */
    exportsReconciliation?: ScriptsVersionsCreateResponseExportsReconciliation | null;
    metadata?: ScriptsVersionsCreateResponseMetadata | null;
    /** Sequential version number. */
    number?: number | null;
    /** Time in milliseconds spent on [Worker startup](https://developers.cloudflare.com/workers/platform/limits/#worker-startup-time). */
    startupTimeMs?: number | null;
}
export interface CreateServiceEdgePreviewRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Worker service. */
    serviceName: string;
    /** Name of the environment within the service. */
    environmentName: string;
    /** The session token returned by createSubdomainEdgePreviewSession. */
    cfPreviewUploadConfigToken: string;
    /** JSON-encoded multipart `metadata` part: the preview worker's modules, bindings and settings. */
    metadata?: CreateScriptEdgePreviewMetadata;
    /** Module files comprising the worker script, appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
    /** JSON-encoded multipart part selecting how the preview is routed (workers.dev or explicit routes); without it edge previews cannot opt into workers.dev routing. */
    wranglerSessionConfig?: CreateScriptEdgePreviewWranglerSessionConfig;
}
export interface CreateServiceEdgePreviewResponse {
    /** Token to send as cf-workers-preview-token header when making requests to the preview host. */
    previewToken: string;
    /** URL for tailing live logs from the preview worker. */
    tailUrl?: string | null;
}
export interface CreateSubdomainEdgePreviewSessionRequest {
    /** Identifier. */
    accountId: string;
}
export interface CreateSubdomainEdgePreviewSessionResponse {
    /** Session token used as cf-preview-upload-config-token when uploading a preview worker. */
    token: string;
    /** Optional URL to exchange the token for a re-encoded version. */
    exchangeUrl?: string | null;
}
export interface CreateZoneEdgePreviewSessionRequest {
    /** Identifier. */
    zoneId: string;
}
export interface CreateZoneEdgePreviewSessionResponse {
    /** Session token used as cf-preview-upload-config-token when uploading a preview worker. */
    token: string;
    /** Optional URL to exchange the token for a re-encoded version. */
    exchangeUrl?: string | null;
}
export interface DeleteBetaWorkerRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** If true, delete the Worker even when other Workers still reference it. Service bindings in those Workers may be left broken. Durable Object namespaces implemented by the deleted Worker are deleted even if other Workers reference them. */
    force?: boolean;
}
export interface DeleteBetaWorkerResponse {
}
export interface DeleteBetaWorkerVersionRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** Identifier for the version, which can be a UUID, a UUID prefix (minimum length 8), or the literal "latest" to operate on the most recently created version. */
    versionId: string;
}
export interface DeleteBetaWorkerVersionResponse {
}
export interface DeleteDomainRequest {
    /** Identifier. */
    accountId: string;
    /** ID of the domain. */
    domainId: string;
}
export interface DeleteDomainResponse {
}
export interface DeleteObservabilityDestinationRequest {
    accountId: string;
    slug: string;
}
export type ObservabilityDestinationsDeleteResponseConfigurationHeadersMap = {
    [key: string]: string | undefined;
};
export type ObservabilityDestinationsDeleteResponseConfigurationJobStatus = ObservabilityDestinationsCreateResponseConfigurationJobStatus;
export type ObservabilityDestinationsDeleteResponseConfigurationLogpushDataset = "opentelemetry-traces" | "opentelemetry-logs" | "opentelemetry-metrics";
export type ObservabilityDestinationsDeleteResponseConfigurationType = "logpush";
export interface ObservabilityDestinationsDeleteResponseConfiguration {
    headers: ObservabilityDestinationsDeleteResponseConfigurationHeadersMap;
    jobStatus: ObservabilityDestinationsCreateResponseConfigurationJobStatus;
    logpushDataset: ObservabilityDestinationsDeleteResponseConfigurationLogpushDataset;
    type: ObservabilityDestinationsDeleteResponseConfigurationType;
    url: string;
    /** The underlying Logpush destination string: the URL with the configured headers encoded as query parameters, so it can carry credentials. Optional: the 2026-10-21 spec omits it. */
    destinationConf?: string | null;
}
export type ObservabilityDestinationsDeleteResponseScriptsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteObservabilityDestinationResponse {
    configuration: ObservabilityDestinationsDeleteResponseConfiguration;
    enabled: boolean;
    name: string;
    scripts: ObservabilityDestinationsDeleteResponseScriptsList;
    slug: string;
}
export interface DeleteObservabilityIssueAutomationRequest {
    accountId: string;
    automationId: string;
}
export interface DeletePreviewRequest {
    accountId: string;
    workerId: string;
    previewId: string;
}
export interface DeletePreviewResponse {
}
export interface DeleteRouteRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    routeId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRouteResponse {
    /** Identifier. */
    id?: string | null;
}
export interface DeleteScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** If true, delete the Worker even when other Workers still reference it. Service bindings in those Workers may be left broken. Durable Object namespaces implemented by the deleted Worker are deleted even if other Workers reference them. */
    force?: boolean;
}
export type DeleteScriptResponse = unknown;
export interface DeleteScriptDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    deploymentId: string;
}
export interface DeleteScriptDeploymentResponse {
}
export interface DeleteScriptSecretRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** A JavaScript variable name for the secret binding. */
    secretName: string;
    /** Flag that indicates whether the secret name is URL encoded. */
    urlEncoded?: boolean;
}
export type DeleteScriptSecretResponse = unknown;
export interface DeleteScriptSubdomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteScriptSubdomainResponse {
    /** Whether the Worker is available on the workers.dev subdomain. */
    enabled: boolean;
    /** Whether the Worker's Preview URLs are available on the workers.dev subdomain. */
    previewsEnabled: boolean;
}
export interface DeleteScriptTailRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** Identifier. */
    id: string;
}
export interface DeleteScriptTailResponse {
}
export interface DeleteSubdomainRequest {
    /** Identifier. */
    accountId: string;
}
export interface DeleteSubdomainResponse {
}
export interface GetAccountSettingRequest {
    /** Identifier. */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAccountSettingResponse {
    defaultUsageModel?: string | null;
    greenCompute?: boolean | null;
}
export interface GetBetaWorkerRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
}
export type BetaWorkersGetResponseObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type BetaWorkersGetResponseObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersGetResponseObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersGetResponseObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type BetaWorkersGetResponseObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersGetResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersGetResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersGetResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersGetResponseObservabilityTracesPropagationPolicy | null;
}
export interface BetaWorkersGetResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersGetResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersGetResponseObservabilityTraces | null;
}
export type BetaWorkersGetResponseReferencesDispatchNamespaceOutboundsItem = BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem;
export type BetaWorkersGetResponseReferencesDispatchNamespaceOutboundsList = Array<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export type BetaWorkersGetResponseReferencesDomainsItem = BetaWorkersCreateResponseReferencesDomainsItem;
export type BetaWorkersGetResponseReferencesDomainsList = Array<BetaWorkersCreateResponseReferencesDomainsItem>;
export type BetaWorkersGetResponseReferencesDurableObjectsItem = BetaWorkersCreateResponseReferencesDurableObjectsItem;
export type BetaWorkersGetResponseReferencesDurableObjectsList = Array<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export type BetaWorkersGetResponseReferencesQueuesItem = BetaWorkersCreateResponseReferencesQueuesItem;
export type BetaWorkersGetResponseReferencesQueuesList = Array<BetaWorkersCreateResponseReferencesQueuesItem>;
export type BetaWorkersGetResponseReferencesWorkersItem = BetaWorkersCreateResponseReferencesWorkersItem;
export type BetaWorkersGetResponseReferencesWorkersList = Array<BetaWorkersCreateResponseReferencesWorkersItem>;
export interface BetaWorkersGetResponseReferences {
    /** Other Workers that reference the Worker as an outbound for a dispatch namespace. */
    dispatchNamespaceOutbounds: BetaWorkersGetResponseReferencesDispatchNamespaceOutboundsList;
    /** Custom domains connected to the Worker. */
    domains: BetaWorkersGetResponseReferencesDomainsList;
    /** Other Workers that reference Durable Object classes implemented by the Worker. */
    durableObjects: BetaWorkersGetResponseReferencesDurableObjectsList;
    /** Queues that send messages to the Worker. */
    queues: BetaWorkersGetResponseReferencesQueuesList;
    /** Other Workers that reference the Worker using [service bindings](https://developers.cloudflare.com/workers/runtime-apis/bindings/service-bindings/). */
    workers: BetaWorkersGetResponseReferencesWorkersList;
}
export type BetaWorkersGetResponseSubdomain = BetaWorkersCreateResponseSubdomain;
export type BetaWorkersGetResponseTagsList = Array<string>;
export type BetaWorkersGetResponseTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersGetResponseTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export type BetaWorkersGetResponsePreviewsBaseConfigCacheOptions = BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions;
export type BetaWorkersGetResponsePreviewsBaseConfigEnvValue = BetaWorkersCreateRequestPreviewsBaseConfigEnvValue;
export type BetaWorkersGetResponsePreviewsBaseConfigEnvMap = {
    [key: string]: BetaWorkersCreateRequestPreviewsBaseConfigEnvValue | undefined;
};
export type BetaWorkersGetResponsePreviewsBaseConfigLimits = BetaWorkersCreateResponsePreviewsBaseConfigLimits;
export type BetaWorkersGetResponsePreviewsBaseConfigObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type BetaWorkersGetResponsePreviewsBaseConfigObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersGetResponsePreviewsBaseConfigObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersGetResponsePreviewsBaseConfigObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type BetaWorkersGetResponsePreviewsBaseConfigObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersGetResponsePreviewsBaseConfigObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersGetResponsePreviewsBaseConfigObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersGetResponsePreviewsBaseConfigObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersGetResponsePreviewsBaseConfigObservabilityTracesPropagationPolicy | null;
}
export interface BetaWorkersGetResponsePreviewsBaseConfigObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersGetResponsePreviewsBaseConfigObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersGetResponsePreviewsBaseConfigObservabilityTraces | null;
}
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementModeMode = "smart";
export interface BetaWorkersGetResponsePreviewsBaseConfigPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersGetResponsePreviewsBaseConfigPlacementModeMode;
}
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementCase4Mode = "targeted";
export interface BetaWorkersGetResponsePreviewsBaseConfigPlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersGetResponsePreviewsBaseConfigPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementCase5Mode = "targeted";
export interface BetaWorkersGetResponsePreviewsBaseConfigPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersGetResponsePreviewsBaseConfigPlacementCase5Mode;
}
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementCase6Mode = "targeted";
export interface BetaWorkersGetResponsePreviewsBaseConfigPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersGetResponsePreviewsBaseConfigPlacementCase6Mode;
}
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementCase7Mode = "targeted";
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersGetResponsePreviewsBaseConfigPlacementCase7TargetList = Array<BetaWorkersGetResponsePreviewsBaseConfigPlacementCase7TargetItem>;
export interface BetaWorkersGetResponsePreviewsBaseConfigPlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersGetResponsePreviewsBaseConfigPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersGetResponsePreviewsBaseConfigPlacementCase7TargetList;
}
export type BetaWorkersGetResponsePreviewsBaseConfigPlacement = BetaWorkersGetResponsePreviewsBaseConfigPlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | BetaWorkersGetResponsePreviewsBaseConfigPlacementCase4 | BetaWorkersGetResponsePreviewsBaseConfigPlacementCase5 | BetaWorkersGetResponsePreviewsBaseConfigPlacementCase6 | BetaWorkersGetResponsePreviewsBaseConfigPlacementCase7;
export type BetaWorkersGetResponsePreviewsBaseConfigTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersGetResponsePreviewsBaseConfigTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export interface BetaWorkersGetResponsePreviewsBaseConfig {
    /** Cache options used when creating new Previews. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Bindings used when creating new Previews, keyed by binding name. */
    env?: BetaWorkersGetResponsePreviewsBaseConfigEnvMap | null;
    /** Resource limits enforced at runtime for newly created Previews. */
    limits?: BetaWorkersCreateResponsePreviewsBaseConfigLimits | null;
    /** Whether logpush is enabled when creating new Previews. */
    logpush?: boolean | null;
    /** Observability settings used when creating new Previews. */
    observability?: BetaWorkersGetResponsePreviewsBaseConfigObservability | null;
    /** Placement configuration used when creating new Previews. */
    placement?: BetaWorkersGetResponsePreviewsBaseConfigPlacement | null;
    /** Other Workers that should consume logs from newly created Previews. */
    tailConsumers?: BetaWorkersGetResponsePreviewsBaseConfigTailConsumersList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBetaWorkerResponse {
    /** Immutable ID of the Worker. */
    id: string;
    /** When the Worker was created. */
    createdOn: string;
    /** Whether logpush is enabled for the Worker. */
    logpush: boolean;
    /** Name of the Worker. */
    name: string;
    /** Observability settings for the Worker. */
    observability: BetaWorkersGetResponseObservability;
    /** Other resources that reference the Worker and depend on it existing. */
    references: BetaWorkersGetResponseReferences;
    /** Subdomain settings for the Worker. */
    subdomain: BetaWorkersCreateResponseSubdomain;
    /** Tags associated with the Worker. */
    tags: BetaWorkersGetResponseTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers: BetaWorkersGetResponseTailConsumersList;
    /** When the Worker was most recently updated. */
    updatedOn: string;
    /** When the Worker's most recent deployment was created. `null` if the Worker has never been deployed. */
    deployedOn?: string | null;
    /** Template configuration used when creating new Previews for this Worker. */
    previewsBaseConfig?: BetaWorkersGetResponsePreviewsBaseConfig | null;
}
export type BetaWorkersVersionsGetRequestInclude = "modules";
export interface GetBetaWorkerVersionRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** Identifier for the version, which can be a UUID, a UUID prefix (minimum length 8), or the literal "latest" to operate on the most recently created version. */
    versionId: string;
    /** Whether to include the `modules` property of the version in the response, which contains code and sourcemap content and may add several megabytes to the response size. */
    include?: BetaWorkersVersionsGetRequestInclude | (string & {});
}
export type BetaWorkersVersionsGetResponseUrlsList = Array<string>;
export type BetaWorkersVersionsGetResponseAnnotations = BetaWorkersVersionsCreateResponseAnnotations;
export type BetaWorkersVersionsGetResponseAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export type BetaWorkersVersionsGetResponseAssetsConfigNotFoundHandling = "none" | "404-page" | "single-page-application";
export type BetaWorkersVersionsGetResponseAssetsConfigRunWorkerFirstCase0List = Array<string>;
export type BetaWorkersVersionsGetResponseAssetsConfigRunWorkerFirst = boolean | BetaWorkersVersionsGetResponseAssetsConfigRunWorkerFirstCase0List;
export interface BetaWorkersVersionsGetResponseAssetsConfig {
    /** The public URL path prefix under which assets are served. A null request value resets it to `/`; responses represent the root as `/`. All versions in a gradual deployment must use the same canonical value. To change it, first deploy the version containing the change at 100%. */
    basePath?: string | null;
    /** Determines the redirects and rewrites of requests for HTML content. */
    htmlHandling?: BetaWorkersVersionsGetResponseAssetsConfigHtmlHandling | null;
    /** Determines the response when a request does not match a static asset, and there is no Worker script. */
    notFoundHandling?: BetaWorkersVersionsGetResponseAssetsConfigNotFoundHandling | null;
    /** Contains a list path rules to control routing to either the Worker or assets. Glob (*) and negative (!) rules are supported. Rules must start with either '/' or '!/'. At least one non-negative rule must be provided, and negative rules have higher precedence than non-negative rules. */
    runWorkerFirst?: BetaWorkersVersionsGetResponseAssetsConfigRunWorkerFirst | null;
}
export interface BetaWorkersVersionsGetResponseAssets {
    /** Configuration for assets within a Worker. */
    config?: BetaWorkersVersionsGetResponseAssetsConfig | null;
    /** Token provided upon successful upload of all files from a registered manifest. */
    jwt?: string | null;
}
export type BetaWorkersVersionsGetResponseBindingsItemAIType = "ai";
export interface BetaWorkersVersionsGetResponseBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemAIType;
}
export type BetaWorkersVersionsGetResponseBindingsItemAISearchType = "ai_search";
export interface BetaWorkersVersionsGetResponseBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export type BetaWorkersVersionsGetResponseBindingsItemAISearchNamespaceType = "ai_search_namespace";
export interface BetaWorkersVersionsGetResponseBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemAISearchNamespaceType;
}
export type BetaWorkersVersionsGetResponseBindingsItemMessagingType = "messaging";
export interface BetaWorkersVersionsGetResponseBindingsItemMessaging {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Messaging namespace to bind to. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemMessagingType;
}
export type BetaWorkersVersionsGetResponseBindingsItemAnalyticsEngineType = "analytics_engine";
export interface BetaWorkersVersionsGetResponseBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemAnalyticsEngineType;
}
export type BetaWorkersVersionsGetResponseBindingsItemArtifactsType = "artifacts";
export interface BetaWorkersVersionsGetResponseBindingsItemArtifacts {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Artifacts namespace exposed to the Worker in the Worker's account. Must be 2-63 characters, start with an ASCII alphanumeric character, contain only ASCII alphanumeric characters, dots, underscores, and hyphens, and must not end with a hyphen. The namespace does not need to be created before binding it. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemArtifactsType;
}
export type BetaWorkersVersionsGetResponseBindingsItemAssetsType = "assets";
export interface BetaWorkersVersionsGetResponseBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemAssetsType;
}
export type BetaWorkersVersionsGetResponseBindingsItemBrowserType = "browser";
export interface BetaWorkersVersionsGetResponseBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemBrowserType;
}
export type BetaWorkersVersionsGetResponseBindingsItemD1Type = "d1";
export interface BetaWorkersVersionsGetResponseBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemD1Type;
    /** This property has been renamed to `database_id`. */
    id?: string | null;
}
export type BetaWorkersVersionsGetResponseBindingsItemDataBlobType = "data_blob";
export interface BetaWorkersVersionsGetResponseBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemDataBlobType;
}
export type BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceType = "dispatch_namespace";
export type BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutboundParamsItem = BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem;
export type BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export type BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutboundWorker = BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker;
export interface BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker | null;
}
export interface BetaWorkersVersionsGetResponseBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutbound | null;
}
export type BetaWorkersVersionsGetResponseBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export interface BetaWorkersVersionsGetResponseBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export type BetaWorkersVersionsGetResponseBindingsItemHyperdriveType = "hyperdrive";
export interface BetaWorkersVersionsGetResponseBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemHyperdriveType;
}
export type BetaWorkersVersionsGetResponseBindingsItemInheritType = "inherit";
export interface BetaWorkersVersionsGetResponseBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from. This can be a version ID, or the literal "latest" to inherit from the most recently uploaded version, which may not be the deployed version. Defaults to "latest". Only the Workers API version endpoints under `/accounts/{account_id}/workers/workers/{worker_id}/versions` accept a version ID. Other endpoints, including script upload and script version upload, accept only "latest" and reject a version ID with error 10057. */
    versionId?: string | null;
}
export type BetaWorkersVersionsGetResponseBindingsItemImagesType = "images";
export interface BetaWorkersVersionsGetResponseBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemImagesType;
}
export type BetaWorkersVersionsGetResponseBindingsItemJsonType = "json";
export interface BetaWorkersVersionsGetResponseBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemJsonType;
}
export type BetaWorkersVersionsGetResponseBindingsItemKVNamespaceType = "kv_namespace";
export interface BetaWorkersVersionsGetResponseBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemKVNamespaceType;
}
export type BetaWorkersVersionsGetResponseBindingsItemMediaType = "media";
export interface BetaWorkersVersionsGetResponseBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemMediaType;
}
export type BetaWorkersVersionsGetResponseBindingsItemMTLSCertificateType = "mtls_certificate";
export interface BetaWorkersVersionsGetResponseBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemMTLSCertificateType;
}
export type BetaWorkersVersionsGetResponseBindingsItemPlainTextType = "plain_text";
export interface BetaWorkersVersionsGetResponseBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemPlainTextType;
}
export type BetaWorkersVersionsGetResponseBindingsItemPipelinesType = "pipelines";
export interface BetaWorkersVersionsGetResponseBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemPipelinesType;
}
export type BetaWorkersVersionsGetResponseBindingsItemK2Type = "k2";
export interface BetaWorkersVersionsGetResponseBindingsItemK2 {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** ID of a K2 stream owned by the account deploying the Worker. */
    stream: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemK2Type;
}
export type BetaWorkersVersionsGetResponseBindingsItemQueueType = "queue";
export interface BetaWorkersVersionsGetResponseBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemQueueType;
}
export type BetaWorkersVersionsGetResponseBindingsItemRatelimitSimple = BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
export type BetaWorkersVersionsGetResponseBindingsItemRatelimitType = "ratelimit";
export interface BetaWorkersVersionsGetResponseBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemRatelimitType;
}
export type BetaWorkersVersionsGetResponseBindingsItemR2BucketType = "r2_bucket";
export type BetaWorkersVersionsGetResponseBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high" | "us";
export interface BetaWorkersVersionsGetResponseBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: BetaWorkersVersionsGetResponseBindingsItemR2BucketJurisdiction | null;
}
export type BetaWorkersVersionsGetResponseBindingsItemSecretTextType = "secret_text";
export interface BetaWorkersVersionsGetResponseBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemSecretTextType;
}
export type BetaWorkersVersionsGetResponseBindingsItemSendEmailType = "send_email";
export type BetaWorkersVersionsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export type BetaWorkersVersionsGetResponseBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export interface BetaWorkersVersionsGetResponseBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: BetaWorkersVersionsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: BetaWorkersVersionsGetResponseBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export type BetaWorkersVersionsGetResponseBindingsItemServiceType = "service";
export interface BetaWorkersVersionsGetResponseBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export type BetaWorkersVersionsGetResponseBindingsItemTextBlobType = "text_blob";
export interface BetaWorkersVersionsGetResponseBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemTextBlobType;
}
export type BetaWorkersVersionsGetResponseBindingsItemVectorizeType = "vectorize";
export interface BetaWorkersVersionsGetResponseBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemVectorizeType;
}
export type BetaWorkersVersionsGetResponseBindingsItemVersionMetadataType = "version_metadata";
export interface BetaWorkersVersionsGetResponseBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemVersionMetadataType;
}
export type BetaWorkersVersionsGetResponseBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export interface BetaWorkersVersionsGetResponseBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemSecretsStoreSecretType;
}
export type BetaWorkersVersionsGetResponseBindingsItemFlagshipType = "flagship";
export interface BetaWorkersVersionsGetResponseBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemFlagshipType;
}
export type BetaWorkersVersionsGetResponseBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type BetaWorkersVersionsGetResponseBindingsItemSecretKeyType = "secret_key";
export type BetaWorkersVersionsGetResponseBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type BetaWorkersVersionsGetResponseBindingsItemSecretKeyUsagesList = Array<BetaWorkersVersionsGetResponseBindingsItemSecretKeyUsagesItem>;
export interface BetaWorkersVersionsGetResponseBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: BetaWorkersVersionsGetResponseBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: BetaWorkersVersionsGetResponseBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type BetaWorkersVersionsGetResponseBindingsItemWorkflowType = "workflow";
export interface BetaWorkersVersionsGetResponseBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export type BetaWorkersVersionsGetResponseBindingsItemWasmModuleType = "wasm_module";
export interface BetaWorkersVersionsGetResponseBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemWasmModuleType;
}
export type BetaWorkersVersionsGetResponseBindingsItemVPCServiceType = "vpc_service";
export interface BetaWorkersVersionsGetResponseBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemVPCServiceType;
}
export type BetaWorkersVersionsGetResponseBindingsItemVPCNetworkType = "vpc_network";
export type BetaWorkersVersionsGetResponseBindingsItemVPCNetworkIdentity = "runtime-email-alpha";
export interface BetaWorkersVersionsGetResponseBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemVPCNetworkType;
    /** Enables Gateway identity for the binding. Requires network_id to be "cf1:network" and cannot be combined with tunnel_id. */
    identity?: BetaWorkersVersionsGetResponseBindingsItemVPCNetworkIdentity | null;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export type BetaWorkersVersionsGetResponseBindingsItem = BetaWorkersVersionsGetResponseBindingsItemAI | BetaWorkersVersionsGetResponseBindingsItemAISearch | BetaWorkersVersionsGetResponseBindingsItemAISearchNamespace | BetaWorkersVersionsGetResponseBindingsItemMessaging | BetaWorkersVersionsGetResponseBindingsItemAnalyticsEngine | BetaWorkersVersionsGetResponseBindingsItemArtifacts | BetaWorkersVersionsGetResponseBindingsItemAssets | BetaWorkersVersionsGetResponseBindingsItemBrowser | BetaWorkersVersionsGetResponseBindingsItemD1 | BetaWorkersVersionsGetResponseBindingsItemDataBlob | BetaWorkersVersionsGetResponseBindingsItemDispatchNamespace | BetaWorkersVersionsGetResponseBindingsItemDurableObjectNamespace | BetaWorkersVersionsGetResponseBindingsItemHyperdrive | BetaWorkersVersionsGetResponseBindingsItemInherit | BetaWorkersVersionsGetResponseBindingsItemImages | BetaWorkersVersionsGetResponseBindingsItemJson | BetaWorkersVersionsGetResponseBindingsItemKVNamespace | BetaWorkersVersionsGetResponseBindingsItemMedia | BetaWorkersVersionsGetResponseBindingsItemMTLSCertificate | BetaWorkersVersionsGetResponseBindingsItemPlainText | BetaWorkersVersionsGetResponseBindingsItemPipelines | BetaWorkersVersionsGetResponseBindingsItemK2 | BetaWorkersVersionsGetResponseBindingsItemQueue | BetaWorkersVersionsGetResponseBindingsItemRatelimit | BetaWorkersVersionsGetResponseBindingsItemR2Bucket | BetaWorkersVersionsGetResponseBindingsItemSecretText | BetaWorkersVersionsGetResponseBindingsItemSendEmail | BetaWorkersVersionsGetResponseBindingsItemService | BetaWorkersVersionsGetResponseBindingsItemTextBlob | BetaWorkersVersionsGetResponseBindingsItemVectorize | BetaWorkersVersionsGetResponseBindingsItemVersionMetadata | BetaWorkersVersionsGetResponseBindingsItemSecretsStoreSecret | BetaWorkersVersionsGetResponseBindingsItemFlagship | BetaWorkersVersionsGetResponseBindingsItemSecretKey | BetaWorkersVersionsGetResponseBindingsItemWorkflow | BetaWorkersVersionsGetResponseBindingsItemWasmModule | BetaWorkersVersionsGetResponseBindingsItemVPCService | BetaWorkersVersionsGetResponseBindingsItemVPCNetwork;
export type BetaWorkersVersionsGetResponseBindingsList = Array<BetaWorkersVersionsGetResponseBindingsItem>;
export type BetaWorkersVersionsGetResponseCacheOptions = BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions;
export type BetaWorkersVersionsGetResponseCompatibilityFlagsList = Array<string>;
export type BetaWorkersVersionsGetResponseContainersItem = BetaWorkersVersionsCreateResponseContainersItem;
export type BetaWorkersVersionsGetResponseContainersList = Array<BetaWorkersVersionsCreateResponseContainersItem>;
export type BetaWorkersVersionsGetResponseExportsValueWorkerType = "worker";
export type BetaWorkersVersionsGetResponseExportsValueWorkerCache = BetaWorkersVersionsCreateRequestExportsValueWorkerCache;
export type BetaWorkersVersionsGetResponseExportsValueWorkerState = "created";
export interface BetaWorkersVersionsGetResponseExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: BetaWorkersVersionsGetResponseExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: BetaWorkersVersionsCreateRequestExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: BetaWorkersVersionsGetResponseExportsValueWorkerState | null;
}
export type BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExportType = "durable-object";
export type BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExportState = "created";
export interface BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExportState | null;
}
export type BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectDeletedExportType;
}
export type BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectRenamedExportType;
}
export type BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectTransferredExportType;
}
export type BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type BetaWorkersVersionsGetResponseExportsValue = BetaWorkersVersionsGetResponseExportsValueWorker | BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExport | BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectDeletedExport | BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectRenamedExport | BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectTransferredExport | BetaWorkersVersionsGetResponseExportsValueWorkersDurableObjectExpectingTransferExport;
export type BetaWorkersVersionsGetResponseExportsMap = {
    [key: string]: BetaWorkersVersionsGetResponseExportsValue | undefined;
};
export type BetaWorkersVersionsGetResponseExportsReconciliationCreatedList = Array<string>;
export type BetaWorkersVersionsGetResponseExportsReconciliationDeletedList = Array<string>;
export type BetaWorkersVersionsGetResponseExportsReconciliationInfoItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export type BetaWorkersVersionsGetResponseExportsReconciliationInfoItemReferencingScriptsList = Array<string>;
export interface BetaWorkersVersionsGetResponseExportsReconciliationInfoItem {
    /** The class name the info entry is about. */
    class: string;
    /** Human-readable explanation. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: BetaWorkersVersionsGetResponseExportsReconciliationInfoItemScenario;
    /** The provisioned namespace the entry relates to, when applicable. */
    namespaceId?: string | null;
    /** Other Workers in the account that still bind to the affected class. Advisory: while non-empty the tombstone is not yet safe to remove -- redeploy these Workers with bindings re-pointed first. */
    referencingScripts?: BetaWorkersVersionsGetResponseExportsReconciliationInfoItemReferencingScriptsList | null;
}
export type BetaWorkersVersionsGetResponseExportsReconciliationInfoList = Array<BetaWorkersVersionsGetResponseExportsReconciliationInfoItem>;
export type BetaWorkersVersionsGetResponseExportsReconciliationRemovableEntriesList = Array<string>;
export type BetaWorkersVersionsGetResponseExportsReconciliationRenamedItem = BetaWorkersVersionsCreateResponseExportsReconciliationRenamedItem;
export type BetaWorkersVersionsGetResponseExportsReconciliationRenamedList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationRenamedItem>;
export type BetaWorkersVersionsGetResponseExportsReconciliationTransferPendingItem = BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingItem;
export type BetaWorkersVersionsGetResponseExportsReconciliationTransferPendingList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingItem>;
export type BetaWorkersVersionsGetResponseExportsReconciliationTransferredItemPhase = "committed";
export interface BetaWorkersVersionsGetResponseExportsReconciliationTransferredItem {
    /** The source class name that was transferred. */
    class: string;
    /** The transfer phase. Currently always `committed`. */
    phase: BetaWorkersVersionsGetResponseExportsReconciliationTransferredItemPhase;
    /** The destination script that now owns the namespace. */
    to: string;
}
export type BetaWorkersVersionsGetResponseExportsReconciliationTransferredList = Array<BetaWorkersVersionsGetResponseExportsReconciliationTransferredItem>;
export type BetaWorkersVersionsGetResponseExportsReconciliationUpdatedList = Array<string>;
export type BetaWorkersVersionsGetResponseExportsReconciliationWarningsItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export interface BetaWorkersVersionsGetResponseExportsReconciliationWarningsItem {
    /** The class name the warning is about. */
    class: string;
    /** Human-readable explanation of the warning. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: BetaWorkersVersionsGetResponseExportsReconciliationWarningsItemScenario;
    /** The provisioned namespace the warning relates to, when applicable. */
    namespaceId?: string | null;
}
export type BetaWorkersVersionsGetResponseExportsReconciliationWarningsList = Array<BetaWorkersVersionsGetResponseExportsReconciliationWarningsItem>;
export interface BetaWorkersVersionsGetResponseExportsReconciliation {
    /** Class names for which a new namespace was provisioned. */
    created: BetaWorkersVersionsGetResponseExportsReconciliationCreatedList;
    /** Class names whose namespace was deleted by a `deleted` tombstone. */
    deleted: BetaWorkersVersionsGetResponseExportsReconciliationDeletedList;
    /** Non-blocking info entries (stale tombstones, tombstone applied with class still in code). See `exports_reconciliation_info`. */
    info: BetaWorkersVersionsGetResponseExportsReconciliationInfoList;
    /** Source class names whose tombstone entry is now stale and safe to delete from `exports` (no remaining referencing scripts). */
    removableEntries: BetaWorkersVersionsGetResponseExportsReconciliationRemovableEntriesList;
    /** Applied `renamed` tombstones. */
    renamed: BetaWorkersVersionsGetResponseExportsReconciliationRenamedList;
    /** Phase-1 transfer hints recorded on the target side. */
    transferPending: BetaWorkersVersionsGetResponseExportsReconciliationTransferPendingList;
    /** Committed `transferred` tombstones (phase-2). */
    transferred: BetaWorkersVersionsGetResponseExportsReconciliationTransferredList;
    /** Class names whose provisioned namespace was mutated in place. */
    updated: BetaWorkersVersionsGetResponseExportsReconciliationUpdatedList;
    /** Non-blocking warnings. See `exports_reconciliation_warning`. */
    warnings: BetaWorkersVersionsGetResponseExportsReconciliationWarningsList;
}
export type BetaWorkersVersionsGetResponseLimits = BetaWorkersVersionsCreateResponseLimits;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationNewClassesList = Array<string>;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface BetaWorkersVersionsGetResponseMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationTransferredClassesList | null;
}
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList = Array<BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export interface BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export type BetaWorkersVersionsGetResponseMigrations = BetaWorkersVersionsGetResponseMigrationsSingleStepMigration | BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrations;
export type BetaWorkersVersionsGetResponseModulesItem = BetaWorkersVersionsCreateRequestModulesItem;
export type BetaWorkersVersionsGetResponseModulesList = Array<BetaWorkersVersionsCreateRequestModulesItem>;
export type BetaWorkersVersionsGetResponsePackageDependenciesItem = BetaWorkersVersionsCreateRequestPackageDependenciesItem;
export type BetaWorkersVersionsGetResponsePackageDependenciesList = Array<BetaWorkersVersionsCreateRequestPackageDependenciesItem>;
export type BetaWorkersVersionsGetResponsePlacementModeMode = "smart";
export interface BetaWorkersVersionsGetResponsePlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersVersionsGetResponsePlacementModeMode;
}
export type BetaWorkersVersionsGetResponsePlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type BetaWorkersVersionsGetResponsePlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersVersionsGetResponsePlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type BetaWorkersVersionsGetResponsePlacementCase4Mode = "targeted";
export interface BetaWorkersVersionsGetResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsGetResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type BetaWorkersVersionsGetResponsePlacementCase5Mode = "targeted";
export interface BetaWorkersVersionsGetResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsGetResponsePlacementCase5Mode;
}
export type BetaWorkersVersionsGetResponsePlacementCase6Mode = "targeted";
export interface BetaWorkersVersionsGetResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsGetResponsePlacementCase6Mode;
}
export type BetaWorkersVersionsGetResponsePlacementCase7Mode = "targeted";
export type BetaWorkersVersionsGetResponsePlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type BetaWorkersVersionsGetResponsePlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersVersionsGetResponsePlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersVersionsGetResponsePlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersVersionsGetResponsePlacementCase7TargetList = Array<BetaWorkersVersionsGetResponsePlacementCase7TargetItem>;
export interface BetaWorkersVersionsGetResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsGetResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersVersionsGetResponsePlacementCase7TargetList;
}
export type BetaWorkersVersionsGetResponsePlacement = BetaWorkersVersionsGetResponsePlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | BetaWorkersVersionsGetResponsePlacementCase4 | BetaWorkersVersionsGetResponsePlacementCase5 | BetaWorkersVersionsGetResponsePlacementCase6 | BetaWorkersVersionsGetResponsePlacementCase7;
export type BetaWorkersVersionsGetResponseUsageModel = "standard" | "bundled" | "unbound";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBetaWorkerVersionResponse {
    /** Version identifier. */
    id: string;
    /** When the version was created. */
    createdOn: string;
    /** The integer version number, starting from one. */
    number: number;
    /** All routable URLs that always point to this version. Does not include alias URLs, since aliases can be updated to point to a different version. */
    urls: BetaWorkersVersionsGetResponseUrlsList;
    /** Metadata about the version. */
    annotations?: BetaWorkersVersionsCreateResponseAnnotations | null;
    /** Configuration for assets within a Worker. */
    assets?: BetaWorkersVersionsGetResponseAssets | null;
    /** Email of the user who created the version. */
    authorEmail?: string | null;
    /** Identifier of the user who created the version. */
    authorId?: string | null;
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: BetaWorkersVersionsGetResponseBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: BetaWorkersVersionsGetResponseCompatibilityFlagsList | null;
    /** List of containers attached to a Worker. Containers can only be attached to Durable Object classes of this Worker script. */
    containers?: BetaWorkersVersionsGetResponseContainersList | null;
    /** Declarative exports for the version, including Durable Object classes (with their `storage` backend) and named Worker entrypoints. On reads, tombstoned lifecycle entries are omitted, so only live exports (`created` and `expecting-transfer`) are returned. `exports` and `migrations` are mutually exclusive on upload. */
    exports?: BetaWorkersVersionsGetResponseExportsMap | null;
    /** Summary of the declarative exports reconciliation that ran on this upload. Populated only when the uploaded metadata included an `exports` block. Durable Object entries drive reconciliation; `type: worker` entries do not contribute to this summary. */
    exportsReconciliation?: BetaWorkersVersionsGetResponseExportsReconciliation | null;
    /** Resource limits enforced at runtime. */
    limits?: BetaWorkersVersionsCreateResponseLimits | null;
    /** The name of the main module in the `modules` array (e.g. the name of the module that exports a `fetch` handler). */
    mainModule?: string | null;
    /** Durable Object migration tag. Set when the version is deployed. Omitted if the version has not been deployed or the Worker does not use Durable Objects. */
    migrationTag?: string | null;
    /** Migrations for Durable Objects associated with the version. Migrations are applied when the version is deployed. */
    migrations?: BetaWorkersVersionsGetResponseMigrations | null;
    /** Code, sourcemaps, and other content used at runtime. */
    modules?: BetaWorkersVersionsGetResponseModulesList | null;
    /** The list of npm packages that were installed and used when this Worker version was built. */
    packageDependencies?: BetaWorkersVersionsGetResponsePackageDependenciesList | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: BetaWorkersVersionsGetResponsePlacement | null;
    /** The client used to create the version. */
    source?: string | null;
    /** Time in milliseconds spent on [Worker startup](https://developers.cloudflare.com/workers/platform/limits/#worker-startup-time). */
    startupTimeMs?: number | null;
    /** Usage model for the version. */
    usageModel?: BetaWorkersVersionsGetResponseUsageModel | null;
}
export interface GetDomainRequest {
    /** Identifier. */
    accountId: string;
    /** ID of the domain. */
    domainId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDomainResponse {
    /** Immutable ID of the domain. */
    id: string;
    /** ID of the TLS certificate issued for the domain. */
    certId: string;
    /** Whether the configured hostname is routable for the domain. If disabled, then requests to the configured hostname will not be routed to the configured Worker. If disabled, then preview routing must be enabled, and only subdomains of the configured hostname will be routable. */
    enabled: boolean;
    /** Worker environment associated with the domain. */
    environment: string;
    /** Hostname of the domain. Can be either the zone apex or a subdomain of the zone. Requests to this hostname will be routed to the configured Worker. */
    hostname: string;
    /** Whether Worker Previews are served on this custom domain. */
    previewsEnabled?: boolean | null;
    /** Name of the Worker associated with the domain. Requests to the configured hostname will be routed to this Worker. */
    service: string;
    /** ID of the zone containing the domain hostname. */
    zoneId: string;
    /** Name of the zone containing the domain hostname. */
    zoneName: string;
}
export interface GetObservabilityIssueAutomationRequest {
    accountId: string;
    automationId: string;
}
export type ObservabilitySharedQueriesGetRequestView = "events" | "invocations" | "calculations";
export interface GetObservabilitySharedQueryRequest {
    accountId: string;
    /** Specify the ID of the shared query. */
    id: string;
    /** Select the view of the query result to return, defaults to events. */
    view?: ObservabilitySharedQueriesGetRequestView | (string & {});
}
export type ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemCase0Operator = "count" | "COUNT";
export type ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemCase0KeyType = "string" | "number" | "boolean";
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemCase0 {
    operator: ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemCase0Operator;
    alias?: string | null;
    key?: string | null;
    keyType?: ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemCase0KeyType | null;
}
export type ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemCase1Operator = "uniq" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export type ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemCase1KeyType = "string" | "number" | "boolean";
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemCase1 {
    key: string;
    operator: ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemCase1Operator;
    alias?: string | null;
    keyType?: ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemCase1KeyType | null;
}
export type ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItem = ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemCase0 | ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemCase1;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsList = Array<ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItem>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersDatasetsList = Array<string>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0FiltersList = Array<unknown>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0Kind = "group";
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0 {
    filterCombination: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0FilterCombination;
    filters: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0FiltersList;
    kind: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0Kind;
}
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafOperation;
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafType;
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafKind | null;
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafValue | null;
}
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItem = ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0 | ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersList = Array<ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItem>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysItemType = "string" | "number" | "boolean";
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysItem {
    type: ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysItemType;
    value: string;
}
export type ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysList = Array<ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysItem>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsItem {
    key: string;
    operation: ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsItemOperation;
    value: number;
}
export type ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsList = Array<ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsItem>;
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersNeedle {
    value: unknown;
    isRegex?: boolean | null;
    matchCase?: boolean | null;
}
export type ObservabilitySharedQueriesGetResponseRunQueryParametersOrderByOrder = "asc" | "desc";
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersOrderBy {
    /** Configure which Calculation to order the results by. */
    value: string;
    /** Set the order of the results */
    order?: ObservabilitySharedQueriesGetResponseRunQueryParametersOrderByOrder | null;
}
export interface ObservabilitySharedQueriesGetResponseRunQueryParameters {
    /** Create Calculations to compute as part of the query. */
    calculations?: ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsList | null;
    /** Set the Datasets to query. Leave it empty to query all the datasets. */
    datasets?: ObservabilitySharedQueriesGetResponseRunQueryParametersDatasetsList | null;
    /** Set a Flag to describe how to combine the filters on the query. */
    filterCombination?: ObservabilitySharedQueriesGetResponseRunQueryParametersFilterCombination | null;
    /** Configure the Filters to apply to the query. Supports nested groups via kind: 'group'. */
    filters?: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersList | null;
    /** Define how to group the results of the query. */
    groupBys?: ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysList | null;
    /** Configure the Having clauses that filter on calculations in the query result. */
    havings?: ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsList | null;
    /** Set a limit on the number of results / records returned by the query */
    limit?: number | null;
    /** Define an expression to search using full-text search. */
    needle?: ObservabilitySharedQueriesGetResponseRunQueryParametersNeedle | null;
    /** Configure the order of the results returned by the query. */
    orderBy?: ObservabilitySharedQueriesGetResponseRunQueryParametersOrderBy | null;
}
export interface ObservabilitySharedQueriesGetResponseRunQuery {
    id: string;
    /** If the query wasn't explcitly saved */
    adhoc: boolean;
    created: string;
    createdBy: string;
    description: string;
    /** Query name */
    name: string;
    parameters: ObservabilitySharedQueriesGetResponseRunQueryParameters;
    updated: string;
    updatedBy: string;
}
export type ObservabilitySharedQueriesGetResponseRunStatus = "STARTED" | "COMPLETED";
export type ObservabilitySharedQueriesGetResponseRunTimeframe = ObservabilitySharedQueriesCreateRequestTimeframe;
export interface ObservabilitySharedQueriesGetResponseRunStatistics {
    /** Number of uncompressed bytes read from the table. */
    bytesRead: number;
    /** Time in seconds for the query to run. */
    elapsed: number;
    /** Number of rows scanned from the table. */
    rowsRead: number;
    /** The level of Adaptive Bit Rate (ABR) sampling used for the query. If empty the ABR level is 1 */
    abrLevel?: number | null;
}
export interface ObservabilitySharedQueriesGetResponseRun {
    /** Unique identifier for this query run. */
    id: string;
    /** Cloudflare account ID that owns this query run. */
    accountId: string;
    /** Whether this was a dry run (results not persisted). */
    dry: boolean;
    /** Number of time-series buckets used for the query. Higher values produce more detailed series data. */
    granularity: number;
    /** A saved query definition with its parameters, metadata, and ownership information. */
    query: ObservabilitySharedQueriesGetResponseRunQuery;
    /** Current execution status of the query run. */
    status: ObservabilitySharedQueriesGetResponseRunStatus;
    /** Time range for the query execution. 'from' must be earlier than 'to'. No fractional milliseconds. */
    timeframe: ObservabilitySharedQueriesCreateRequestTimeframe;
    /** ID of the user who initiated the query run. */
    userId: string;
    /** ISO-8601 timestamp when the query run was created. */
    created?: string | null;
    /** Query performance statistics from the database (does not include network latency). */
    statistics?: ObservabilitySharedQueriesGetResponseRunStatistics | null;
    /** ISO-8601 timestamp when the query run was last updated. */
    updated?: string | null;
}
export type ObservabilitySharedQueriesGetResponseStatistics = ObservabilitySharedQueriesGetResponseRunStatistics;
export type ObservabilitySharedQueriesGetResponseAgentsItemErrorsList = Array<string>;
export type ObservabilitySharedQueriesGetResponseAgentsItemModelsList = Array<string>;
export type ObservabilitySharedQueriesGetResponseAgentsItemProvidersList = Array<string>;
export type ObservabilitySharedQueriesGetResponseAgentsItemServicesList = Array<string>;
export type ObservabilitySharedQueriesGetResponseAgentsItemStatus = "completed" | "error";
export interface ObservabilitySharedQueriesGetResponseAgentsItem {
    /** Stable pagination cursor for this agent run. */
    id: string;
    /** Distinct errors reported by spans in the run. */
    errors: ObservabilitySharedQueriesGetResponseAgentsItemErrorsList;
    /** Distinct models reported by chat spans across the run's trace. */
    models: ObservabilitySharedQueriesGetResponseAgentsItemModelsList;
    /** Distinct GenAI providers reported by chat spans in the run. */
    providers: ObservabilitySharedQueriesGetResponseAgentsItemProvidersList;
    /** Worker services represented in the run's trace. */
    services: ObservabilitySharedQueriesGetResponseAgentsItemServicesList;
    /** Number of spans in the run's trace. */
    spans: number;
    /** Observed run status. */
    status: ObservabilitySharedQueriesGetResponseAgentsItemStatus;
    /** Total trace duration in milliseconds. */
    traceDurationMs: number;
    /** End of the run's trace as a Unix epoch in milliseconds. */
    traceEndMs: number;
    /** Trace identifier for this agent run. */
    traceId: string;
    /** Start of the run's trace as a Unix epoch in milliseconds. */
    traceStartMs: number;
    /** ID from the earliest agent invocation that provides one. */
    agentId?: string | null;
    /** Name from the earliest agent invocation that provides one. */
    agentName?: string | null;
    /** Conversation ID from the earliest invocation that provides one. */
    conversationId?: string | null;
    /** Input tokens summed across chat spans in the run's trace; informational, not billing data. */
    inputTokens?: number | null;
    /** Output tokens summed across chat spans in the run's trace; informational, not billing data. */
    outputTokens?: number | null;
}
export type ObservabilitySharedQueriesGetResponseAgentsList = Array<ObservabilitySharedQueriesGetResponseAgentsItem>;
export type ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsItemValue = string | number | boolean;
export interface ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsItem {
    key: string;
    value: ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsItemValue;
}
export type ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsList = Array<ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsItem>;
export interface ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItem {
    /** Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1. */
    count: number;
    /** Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead. */
    interval: number;
    /** Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker's head_sampling_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr_level. */
    sampleInterval: number;
    /** Result of the calculation. count, sum, avg, median, and percentiles are weighted by each event's sample interval */
    value: number;
    groups?: ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsList | null;
}
export type ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesList = Array<ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItem>;
export type ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsItemValue = string | number | boolean;
export interface ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsItem {
    key: string;
    value: ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsItemValue;
}
export type ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsList = Array<ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsItem>;
export interface ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItem {
    /** Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1. */
    count: number;
    /** Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead. */
    interval: number;
    /** Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker's head_sampling_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr_level. */
    sampleInterval: number;
    /** Result of the calculation. count, sum, avg, median, and percentiles are weighted by each event's sample interval */
    value: number;
    firstSeen?: string | null;
    groups?: ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsList | null;
    lastSeen?: string | null;
}
export type ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataList = Array<ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItem>;
export interface ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItem {
    data: ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataList;
    time: string;
}
export type ObservabilitySharedQueriesGetResponseCalculationsItemSeriesList = Array<ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItem>;
export interface ObservabilitySharedQueriesGetResponseCalculationsItem {
    aggregates: ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesList;
    calculation: string;
    series: ObservabilitySharedQueriesGetResponseCalculationsItemSeriesList;
    alias?: string | null;
}
export type ObservabilitySharedQueriesGetResponseCalculationsList = Array<ObservabilitySharedQueriesGetResponseCalculationsItem>;
export type ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsItemValue = string | number | boolean;
export interface ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsItem {
    key: string;
    value: ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsItemValue;
}
export type ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsList = Array<ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsItem>;
export interface ObservabilitySharedQueriesGetResponseCompareItemAggregatesItem {
    /** Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1. */
    count: number;
    /** Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead. */
    interval: number;
    /** Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker's head_sampling_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr_level. */
    sampleInterval: number;
    /** Result of the calculation. count, sum, avg, median, and percentiles are weighted by each event's sample interval */
    value: number;
    groups?: ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsList | null;
}
export type ObservabilitySharedQueriesGetResponseCompareItemAggregatesList = Array<ObservabilitySharedQueriesGetResponseCompareItemAggregatesItem>;
export type ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsItemValue = string | number | boolean;
export interface ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsItem {
    key: string;
    value: ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsItemValue;
}
export type ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsList = Array<ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsItem>;
export interface ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItem {
    /** Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1. */
    count: number;
    /** Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead. */
    interval: number;
    /** Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker's head_sampling_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr_level. */
    sampleInterval: number;
    /** Result of the calculation. count, sum, avg, median, and percentiles are weighted by each event's sample interval */
    value: number;
    firstSeen?: string | null;
    groups?: ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsList | null;
    lastSeen?: string | null;
}
export type ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataList = Array<ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItem>;
export interface ObservabilitySharedQueriesGetResponseCompareItemSeriesItem {
    data: ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataList;
    time: string;
}
export type ObservabilitySharedQueriesGetResponseCompareItemSeriesList = Array<ObservabilitySharedQueriesGetResponseCompareItemSeriesItem>;
export interface ObservabilitySharedQueriesGetResponseCompareItem {
    aggregates: ObservabilitySharedQueriesGetResponseCompareItemAggregatesList;
    calculation: string;
    series: ObservabilitySharedQueriesGetResponseCompareItemSeriesList;
    alias?: string | null;
}
export type ObservabilitySharedQueriesGetResponseCompareList = Array<ObservabilitySharedQueriesGetResponseCompareItem>;
export type ObservabilitySharedQueriesGetResponseDistributionBinsList = Array<string>;
export type ObservabilitySharedQueriesGetResponseDistributionBucketBoundariesList = Array<number>;
export type ObservabilitySharedQueriesGetResponseDistributionBucketMode = "log" | "linear";
export type ObservabilitySharedQueriesGetResponseDistributionBucketsList = Array<string>;
export type ObservabilitySharedQueriesGetResponseDistributionMatrixItemList = Array<number>;
export type ObservabilitySharedQueriesGetResponseDistributionMatrixList = Array<ObservabilitySharedQueriesGetResponseDistributionMatrixItemList>;
export interface ObservabilitySharedQueriesGetResponseDistribution {
    /** Time-bucket labels (ISO-8601 strings), one per matrix column. */
    bins: ObservabilitySharedQueriesGetResponseDistributionBinsList;
    /** Raw bucket edges in the value's native unit, length buckets.length + 1. Used for the colour scale and percentile mapping. */
    bucketBoundaries: ObservabilitySharedQueriesGetResponseDistributionBucketBoundariesList;
    /** Bucketing scheme used to derive the boundaries. 'log' produces geometric edges; 'linear' produces fixed-width edges. */
    bucketMode: ObservabilitySharedQueriesGetResponseDistributionBucketMode;
    /** Value-range labels, one per matrix row (e.g. '50-100ms'). */
    buckets: ObservabilitySharedQueriesGetResponseDistributionBucketsList;
    /** Sampling-corrected counts. matrix[bucketIdx][binIdx] is the estimated number of events in value-bucket 'bucketIdx' during time-bin 'binIdx'. */
    matrix: ObservabilitySharedQueriesGetResponseDistributionMatrixList;
}
export interface ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata {
    /** Unique event ID. Use as the cursor value for offset-based pagination. */
    id: string;
    /** Cloudflare account identifier. */
    account?: string | null;
    /** Cloudflare product that generated this event (e.g. workers, pages). */
    cloudService?: string | null;
    /** exclusiveMinimum */
    coldStart?: number | null;
    /** Estimated cost units for this invocation. */
    cost?: number | null;
    /** Span duration in milliseconds. */
    duration?: number | null;
    /** Span end time as a Unix epoch in milliseconds. */
    endTime?: number | null;
    /** Span end time as a Unix epoch in nanoseconds. */
    endTimeNs?: string | null;
    /** Error message, present when the log represents an error. */
    error?: string | null;
    /** Templatized version of the error message used for grouping similar errors. */
    errorTemplate?: string | null;
    /** Size of the stored telemetry event in bytes. */
    eventSize?: number | null;
    /** Content-based fingerprint used to group similar events. */
    fingerprint?: string | null;
    /** Log level (e.g. log, debug, info, warn, error). */
    level?: string | null;
    /** Log message text. */
    message?: string | null;
    /** Templatized version of the log message used for grouping similar messages. */
    messageTemplate?: string | null;
    /** Metric name when the event represents a metric data point. */
    metricName?: string | null;
    /** Origin of the event (e.g. fetch, scheduled, queue). */
    origin?: string | null;
    /** Span ID of the parent span in the trace hierarchy. */
    parentSpanId?: string | null;
    /** Infrastructure provider identifier. */
    provider?: string | null;
    /** Cloudflare Ray ID from the `cf-ray` header of the request that triggered the invocation. */
    rayId?: string | null;
    /** Cloudflare data center / region that handled the request. */
    region?: string | null;
    /** Cloudflare request ID that ties all logs from a single invocation together. */
    requestId?: string | null;
    /** Worker script name that produced this event. */
    service?: string | null;
    /** Span ID for this individual unit of work within a trace. */
    spanId?: string | null;
    /** Human-readable name for this span. */
    spanName?: string | null;
    /** Stack / deployment identifier. */
    stackId?: string | null;
    /** Span start time as a Unix epoch in milliseconds. */
    startTime?: number | null;
    /** Span start time as a Unix epoch in nanoseconds. */
    startTimeNs?: string | null;
    /** HTTP response status code returned by the Worker. */
    statusCode?: number | null;
    /** Event time as a Unix epoch in nanoseconds. */
    timestampNs?: string | null;
    /** Total duration of the entire trace in milliseconds. */
    traceDuration?: number | null;
    /** Distributed trace ID linking spans across services. */
    traceId?: string | null;
    /** Logical transaction name for this request. */
    transactionName?: string | null;
    /** What triggered the invocation (e.g. GET /users, POST /orders, queue message). */
    trigger?: string | null;
    /** Event type classifier (e.g. cf-worker-event, cf-worker-log). */
    type?: string | null;
    /** Request URL that triggered the Worker invocation. */
    url?: string | null;
}
export type ObservabilitySharedQueriesGetResponseEventsEventsItemSourceCase1Map = {
    [key: string]: unknown | undefined;
};
export type ObservabilitySharedQueriesGetResponseEventsEventsItemSource = string | ObservabilitySharedQueriesGetResponseEventsEventsItemSourceCase1Map;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemContainersMap = {
    [key: string]: unknown | undefined;
};
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0EventMap = {
    [key: string]: unknown | undefined;
};
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ExecutionModel = "durableObject" | "stateless";
export interface ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview {
    id?: string | null;
    name?: string | null;
    slug?: string | null;
}
export interface ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion {
    id?: string | null;
    message?: string | null;
    tag?: string | null;
}
export interface ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0 {
    eventType: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0EventType;
    scriptName: string;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0EventMap | null;
    executionModel?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ExecutionModel | null;
    outcome?: string | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    requestId?: string | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export interface ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem {
    channel: string;
    message: string;
    timestamp: number;
}
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsList = Array<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem>;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1EventMap = {
    [key: string]: unknown | undefined;
};
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1ExecutionModel = "durableObject" | "stateless";
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export interface ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1 {
    cpuTimeMs: number;
    eventType: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1EventType;
    outcome: string;
    scriptName: string;
    wallTimeMs: number;
    diagnosticsChannelEvents?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsList | null;
    dispatchNamespace?: string | null;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1EventMap | null;
    executionModel?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1ExecutionModel | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    requestId?: string | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkers = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0 | ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1;
export interface ObservabilitySharedQueriesGetResponseEventsEventsItem {
    /** Structured metadata extracted from the event. These fields are indexed and available for filtering and aggregation. */
    metadata: ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
    /** The dataset this event belongs to (e.g. cloudflare-workers). */
    dataset: string;
    /** Raw log payload. May be a string or a structured object depending on how the log was emitted. */
    source: ObservabilitySharedQueriesGetResponseEventsEventsItemSource;
    /** Event timestamp as a Unix epoch in milliseconds. */
    timestamp: number;
    /** Cloudflare Containers event information that enriches your logs for identifying and debugging issues. */
    containers?: ObservabilitySharedQueriesGetResponseEventsEventsItemContainersMap | null;
    /** Cloudflare Workers event information that enriches your logs for identifying and debugging issues. */
    workers?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkers | null;
}
export type ObservabilitySharedQueriesGetResponseEventsEventsList = Array<ObservabilitySharedQueriesGetResponseEventsEventsItem>;
export interface ObservabilitySharedQueriesGetResponseEventsFieldsItem {
    /** Field name present in the matched events. */
    key: string;
    /** Data type of the field (string, number, or boolean). */
    type: string;
}
export type ObservabilitySharedQueriesGetResponseEventsFieldsList = Array<ObservabilitySharedQueriesGetResponseEventsFieldsItem>;
export interface ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemAggregates {
    /** exclusiveMinimum */
    count: number;
    /** exclusiveMinimum */
    interval: number;
    firstSeen?: string | null;
    lastSeen?: string | null;
    bin?: unknown | null;
}
export type ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemGroupsValue = string | number | boolean;
export type ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemGroupsMap = {
    [key: string]: ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemGroupsValue | undefined;
};
export interface ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItem {
    aggregates: ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemAggregates;
    /** Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1. */
    count: number;
    /** Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead. */
    interval: number;
    /** Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker's head_sampling_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr_level. */
    sampleInterval: number;
    errors?: number | null;
    /** Groups in the query results. */
    groups?: ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemGroupsMap | null;
}
export type ObservabilitySharedQueriesGetResponseEventsSeriesItemDataList = Array<ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItem>;
export interface ObservabilitySharedQueriesGetResponseEventsSeriesItem {
    data: ObservabilitySharedQueriesGetResponseEventsSeriesItemDataList;
    time: string;
}
export type ObservabilitySharedQueriesGetResponseEventsSeriesList = Array<ObservabilitySharedQueriesGetResponseEventsSeriesItem>;
export interface ObservabilitySharedQueriesGetResponseEvents {
    /** Total number of events matching the query (may exceed the number returned due to limits). */
    count?: number | null;
    /** List of individual telemetry events matching the query. */
    events?: ObservabilitySharedQueriesGetResponseEventsEventsList | null;
    /** List of fields discovered in the matched events. Useful for building dynamic UIs. */
    fields?: ObservabilitySharedQueriesGetResponseEventsFieldsList | null;
    /** Time-series data for the matched events, bucketed by the query granularity. */
    series?: ObservabilitySharedQueriesGetResponseEventsSeriesList | null;
}
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemMetadata = ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemSourceCase1Map = {
    [key: string]: unknown | undefined;
};
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemSource = string | ObservabilitySharedQueriesGetResponseInvocationsValueItemSourceCase1Map;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemContainersMap = {
    [key: string]: unknown | undefined;
};
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0EventMap = {
    [key: string]: unknown | undefined;
};
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0ExecutionModel = "durableObject" | "stateless";
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export interface ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0 {
    eventType: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0EventType;
    scriptName: string;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0EventMap | null;
    executionModel?: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0ExecutionModel | null;
    outcome?: string | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    requestId?: string | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsItem = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsList = Array<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1EventMap = {
    [key: string]: unknown | undefined;
};
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1ExecutionModel = "durableObject" | "stateless";
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export interface ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1 {
    cpuTimeMs: number;
    eventType: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1EventType;
    outcome: string;
    scriptName: string;
    wallTimeMs: number;
    diagnosticsChannelEvents?: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsList | null;
    dispatchNamespace?: string | null;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1EventMap | null;
    executionModel?: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1ExecutionModel | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    requestId?: string | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkers = ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0 | ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1;
export interface ObservabilitySharedQueriesGetResponseInvocationsValueItem {
    /** Structured metadata extracted from the event. These fields are indexed and available for filtering and aggregation. */
    metadata: ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
    /** The dataset this event belongs to (e.g. cloudflare-workers). */
    dataset: string;
    /** Raw log payload. May be a string or a structured object depending on how the log was emitted. */
    source: ObservabilitySharedQueriesGetResponseInvocationsValueItemSource;
    /** Event timestamp as a Unix epoch in milliseconds. */
    timestamp: number;
    /** Cloudflare Containers event information that enriches your logs for identifying and debugging issues. */
    containers?: ObservabilitySharedQueriesGetResponseInvocationsValueItemContainersMap | null;
    /** Cloudflare Workers event information that enriches your logs for identifying and debugging issues. */
    workers?: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkers | null;
}
export type ObservabilitySharedQueriesGetResponseInvocationsValueList = Array<ObservabilitySharedQueriesGetResponseInvocationsValueItem>;
export type ObservabilitySharedQueriesGetResponseInvocationsMap = {
    [key: string]: ObservabilitySharedQueriesGetResponseInvocationsValueList | undefined;
};
export type ObservabilitySharedQueriesGetResponseTracesItemServiceList = Array<string>;
export type ObservabilitySharedQueriesGetResponseTracesItemErrorsList = Array<string>;
export interface ObservabilitySharedQueriesGetResponseTracesItem {
    /** Name of the root span that initiated the trace. */
    rootSpanName: string;
    /** Logical transaction name for the root span. */
    rootTransactionName: string;
    /** List of Worker services involved in the trace. */
    service: ObservabilitySharedQueriesGetResponseTracesItemServiceList;
    /** Total number of spans in the trace. */
    spans: number;
    /** Total duration of the trace in milliseconds. */
    traceDurationMs: number;
    /** Trace end time as a Unix epoch in milliseconds. */
    traceEndMs: number;
    /** Unique identifier for the distributed trace. */
    traceId: string;
    /** Trace start time as a Unix epoch in milliseconds. */
    traceStartMs: number;
    /** Error messages encountered during the trace, if any. */
    errors?: ObservabilitySharedQueriesGetResponseTracesItemErrorsList | null;
}
export type ObservabilitySharedQueriesGetResponseTracesList = Array<ObservabilitySharedQueriesGetResponseTracesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetObservabilitySharedQueryResponse {
    /** Represents a single execution of a query against Workers Observability data, including the query definition, execution status, and performance statistics. */
    run: ObservabilitySharedQueriesGetResponseRun;
    /** Query performance statistics from the database. Includes execution time, rows scanned, and bytes read. Does not include network latency. */
    statistics: ObservabilitySharedQueriesGetResponseRunStatistics;
    /** Agent run summaries. Present when the query view is 'agents'. Each entry represents one trace containing at least one agent invocation. */
    agents?: ObservabilitySharedQueriesGetResponseAgentsList | null;
    /** Aggregated calculation results. Present when the query view is 'calculations'. Contains computed metrics (count, avg, p99, etc.) with optional group-by breakdowns and time-series data. */
    calculations?: ObservabilitySharedQueriesGetResponseCalculationsList | null;
    /** Comparison calculation results from the previous time period. Present when the compare option is enabled. Same structure as calculations. */
    compare?: ObservabilitySharedQueriesGetResponseCompareList | null;
    /** Bucketed 2D histogram of a numeric field over time. Present when chartType is 'distribution'. */
    distribution?: ObservabilitySharedQueriesGetResponseDistribution | null;
    /** Individual event results. Present when the query view is 'events'. Contains the matching log lines and their metadata. */
    events?: ObservabilitySharedQueriesGetResponseEvents | null;
    /** Events grouped by invocation (request ID). Present when the query view is 'invocations'. Each key is a request ID mapping to all events from that invocation. */
    invocations?: ObservabilitySharedQueriesGetResponseInvocationsMap | null;
    /** Trace summaries matching the query. Present when the query view is 'traces'. Each entry represents a distributed trace with its spans, duration, and services involved. */
    traces?: ObservabilitySharedQueriesGetResponseTracesList | null;
}
export interface GetPreviewRequest {
    accountId: string;
    /** Parent Worker id or script name. */
    workerId: string;
    /** Preview id or name. */
    previewId: string;
}
export interface GetPreviewDeploymentRequest {
    accountId: string;
    workerId: string;
    previewId: string;
    /** Deployment id, or `latest`. */
    deploymentId: string;
}
export interface GetRouteRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    routeId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRouteResponse {
    /** Identifier. */
    id: string;
    /** Pattern to match incoming requests against. [Learn more](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior). */
    pattern: string;
    /** Name of the script to run if the route matches. */
    script?: string | null;
}
export interface GetScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
}
export interface GetScriptResponse {
}
export interface GetScriptContentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
}
export interface GetScriptContentResponse {
}
export interface GetScriptDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    deploymentId: string;
}
export type ScriptsDeploymentsGetResponseStrategy = "percentage";
export type ScriptsDeploymentsGetResponseVersionsItem = ScriptsDeploymentsCreateRequestVersionsItem;
export type ScriptsDeploymentsGetResponseVersionsList = Array<ScriptsDeploymentsCreateRequestVersionsItem>;
export type ScriptsDeploymentsGetResponseAnnotations = ScriptsDeploymentsCreateResponseAnnotations;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptDeploymentResponse {
    id: string;
    createdOn: string;
    source: string;
    strategy: ScriptsDeploymentsGetResponseStrategy;
    /** Worker versions included in this deployment. Each object must contain a `version_id` UUID and a `percentage`; percentages across all objects must total 100. In the `cf` CLI, pass the entire array as one JSON value to `--versions`, either inline, for example `--versions '[{"version_id":"023e105f-2a42-4f8b-a1c1-73f6a2a30c0f","percentage":100}]'`, or from a JSON file with `--versions @versions.json`. */
    versions: ScriptsDeploymentsGetResponseVersionsList;
    annotations?: ScriptsDeploymentsCreateResponseAnnotations | null;
    authorEmail?: string | null;
}
export interface GetScriptEventTriggersRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
}
export interface EventTriggerFilter {
    /** Only events from this Artifacts namespace. */
    namespace?: string | null;
    /** Only events from this Artifacts repository. */
    repoName?: string | null;
}
export interface EventTriggerTarget {
    /** Target kind: `workflow`. */
    type: string;
    /** The Workflow that receives the event as an instance's params. */
    workflowName: string;
    /** The script that hosts the Workflow: the script the trigger belongs to. */
    scriptName?: string | null;
}
export type EventTriggerTargetList = Array<EventTriggerTarget>;
export interface EventTrigger {
    /** Event type, e.g. `cf.artifacts.repo.pushed`. */
    type: string;
    filter?: EventTriggerFilter | null;
    targets: EventTriggerTargetList;
}
export type EventTriggerList = Array<EventTrigger>;
export interface ScriptEventTriggers {
    scriptName: string;
    triggers: EventTriggerList;
}
export type GetScriptEventTriggersResponse = ScriptEventTriggers;
export interface GetScriptScheduleRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
}
export interface ScriptsSchedulesGetResponseSchedulesItem {
    cron: string;
    createdOn?: string | null;
    modifiedOn?: string | null;
}
export type ScriptsSchedulesGetResponseSchedulesList = Array<ScriptsSchedulesGetResponseSchedulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptScheduleResponse {
    schedules: ScriptsSchedulesGetResponseSchedulesList;
}
export interface GetScriptScriptAndVersionSettingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
}
export interface ScriptsScriptAndVersionSettingsGetResponseAnnotations {
    /** Human-readable message about the version. Truncated to 1000 bytes if longer. */
    workersMessage?: string | null;
    /** User-provided identifier for the version. Maximum 100 bytes. */
    workersTag?: string | null;
    /** Operation that triggered the creation of the version. This is read-only and set by the server. */
    workersTriggeredBy?: string | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemAIType = "ai";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemAIType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchType = "ai_search";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchNamespaceType = "ai_search_namespace";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchNamespaceType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemMessagingType = "messaging";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemMessaging {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Messaging namespace to bind to. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemMessagingType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemAnalyticsEngineType = "analytics_engine";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemAnalyticsEngineType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemArtifactsType = "artifacts";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemArtifacts {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Artifacts namespace exposed to the Worker in the Worker's account. Must be 2-63 characters, start with an ASCII alphanumeric character, contain only ASCII alphanumeric characters, dots, underscores, and hyphens, and must not end with a hyphen. The namespace does not need to be created before binding it. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemArtifactsType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemAssetsType = "assets";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemAssetsType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemBrowserType = "browser";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemBrowserType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemD1Type = "d1";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemD1Type;
    /** This property has been renamed to `database_id`. */
    id?: string | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemDataBlobType = "data_blob";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemDataBlobType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceType = "dispatch_namespace";
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsItem = BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutboundWorker = BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker | null;
}
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutbound | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemHyperdriveType = "hyperdrive";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemHyperdriveType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemInheritType = "inherit";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from. This can be a version ID, or the literal "latest" to inherit from the most recently uploaded version, which may not be the deployed version. Defaults to "latest". Only the Workers API version endpoints under `/accounts/{account_id}/workers/workers/{worker_id}/versions` accept a version ID. Other endpoints, including script upload and script version upload, accept only "latest" and reject a version ID with error 10057. */
    versionId?: string | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemImagesType = "images";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemImagesType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemJsonType = "json";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemJsonType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemKVNamespaceType = "kv_namespace";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemKVNamespaceType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemMediaType = "media";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemMediaType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemMTLSCertificateType = "mtls_certificate";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemMTLSCertificateType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemPlainTextType = "plain_text";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemPlainTextType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemPipelinesType = "pipelines";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemPipelinesType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemK2Type = "k2";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemK2 {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** ID of a K2 stream owned by the account deploying the Worker. */
    stream: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemK2Type;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemQueueType = "queue";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemQueueType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimitSimple = BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimitType = "ratelimit";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimitType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2BucketType = "r2_bucket";
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high" | "us";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2BucketJurisdiction | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretTextType = "secret_text";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretTextType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailType = "send_email";
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemServiceType = "service";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemTextBlobType = "text_blob";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemTextBlobType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemVectorizeType = "vectorize";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemVectorizeType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemVersionMetadataType = "version_metadata";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemVersionMetadataType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretsStoreSecretType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemFlagshipType = "flagship";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemFlagshipType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyType = "secret_key";
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyUsagesList = Array<ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyUsagesItem>;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemWorkflowType = "workflow";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemWasmModuleType = "wasm_module";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemWasmModuleType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCServiceType = "vpc_service";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCServiceType;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetworkType = "vpc_network";
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetworkIdentity = "runtime-email-alpha";
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetworkType;
    /** Enables Gateway identity for the binding. Requires network_id to be "cf1:network" and cannot be combined with tunnel_id. */
    identity?: ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetworkIdentity | null;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItem = ScriptsScriptAndVersionSettingsGetResponseBindingsItemAI | ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearch | ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchNamespace | ScriptsScriptAndVersionSettingsGetResponseBindingsItemMessaging | ScriptsScriptAndVersionSettingsGetResponseBindingsItemAnalyticsEngine | ScriptsScriptAndVersionSettingsGetResponseBindingsItemArtifacts | ScriptsScriptAndVersionSettingsGetResponseBindingsItemAssets | ScriptsScriptAndVersionSettingsGetResponseBindingsItemBrowser | ScriptsScriptAndVersionSettingsGetResponseBindingsItemD1 | ScriptsScriptAndVersionSettingsGetResponseBindingsItemDataBlob | ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespace | ScriptsScriptAndVersionSettingsGetResponseBindingsItemDurableObjectNamespace | ScriptsScriptAndVersionSettingsGetResponseBindingsItemHyperdrive | ScriptsScriptAndVersionSettingsGetResponseBindingsItemInherit | ScriptsScriptAndVersionSettingsGetResponseBindingsItemImages | ScriptsScriptAndVersionSettingsGetResponseBindingsItemJson | ScriptsScriptAndVersionSettingsGetResponseBindingsItemKVNamespace | ScriptsScriptAndVersionSettingsGetResponseBindingsItemMedia | ScriptsScriptAndVersionSettingsGetResponseBindingsItemMTLSCertificate | ScriptsScriptAndVersionSettingsGetResponseBindingsItemPlainText | ScriptsScriptAndVersionSettingsGetResponseBindingsItemPipelines | ScriptsScriptAndVersionSettingsGetResponseBindingsItemK2 | ScriptsScriptAndVersionSettingsGetResponseBindingsItemQueue | ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimit | ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2Bucket | ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretText | ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmail | ScriptsScriptAndVersionSettingsGetResponseBindingsItemService | ScriptsScriptAndVersionSettingsGetResponseBindingsItemTextBlob | ScriptsScriptAndVersionSettingsGetResponseBindingsItemVectorize | ScriptsScriptAndVersionSettingsGetResponseBindingsItemVersionMetadata | ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretsStoreSecret | ScriptsScriptAndVersionSettingsGetResponseBindingsItemFlagship | ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKey | ScriptsScriptAndVersionSettingsGetResponseBindingsItemWorkflow | ScriptsScriptAndVersionSettingsGetResponseBindingsItemWasmModule | ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCService | ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetwork;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsList = Array<ScriptsScriptAndVersionSettingsGetResponseBindingsItem>;
export type ScriptsScriptAndVersionSettingsGetResponseCacheOptions = BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions;
export type ScriptsScriptAndVersionSettingsGetResponseCompatibilityFlagsList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkerType = "worker";
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkerCache = BetaWorkersVersionsCreateRequestExportsValueWorkerCache;
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkerState = "created";
export interface ScriptsScriptAndVersionSettingsGetResponseExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: BetaWorkersVersionsCreateRequestExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkerState | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExportType = "durable-object";
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExportState = "created";
export interface ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExportState | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectDeletedExportType;
}
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectRenamedExportType;
}
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectTransferredExportType;
}
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseExportsValue = ScriptsScriptAndVersionSettingsGetResponseExportsValueWorker | ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExport | ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectDeletedExport | ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectRenamedExport | ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectTransferredExport | ScriptsScriptAndVersionSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExport;
export type ScriptsScriptAndVersionSettingsGetResponseExportsMap = {
    [key: string]: ScriptsScriptAndVersionSettingsGetResponseExportsValue | undefined;
};
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationCreatedList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationDeletedList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationInfoItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationInfoItemReferencingScriptsList = Array<string>;
export interface ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationInfoItem {
    /** The class name the info entry is about. */
    class: string;
    /** Human-readable explanation. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationInfoItemScenario;
    /** The provisioned namespace the entry relates to, when applicable. */
    namespaceId?: string | null;
    /** Other Workers in the account that still bind to the affected class. Advisory: while non-empty the tombstone is not yet safe to remove -- redeploy these Workers with bindings re-pointed first. */
    referencingScripts?: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationInfoItemReferencingScriptsList | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationInfoList = Array<ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationInfoItem>;
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationRemovableEntriesList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationRenamedItem = BetaWorkersVersionsCreateResponseExportsReconciliationRenamedItem;
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationRenamedList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationRenamedItem>;
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationTransferPendingItem = BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingItem;
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationTransferPendingList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingItem>;
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationTransferredItemPhase = "committed";
export interface ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationTransferredItem {
    /** The source class name that was transferred. */
    class: string;
    /** The transfer phase. Currently always `committed`. */
    phase: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationTransferredItemPhase;
    /** The destination script that now owns the namespace. */
    to: string;
}
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationTransferredList = Array<ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationTransferredItem>;
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationUpdatedList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationWarningsItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export interface ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationWarningsItem {
    /** The class name the warning is about. */
    class: string;
    /** Human-readable explanation of the warning. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationWarningsItemScenario;
    /** The provisioned namespace the warning relates to, when applicable. */
    namespaceId?: string | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationWarningsList = Array<ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationWarningsItem>;
export interface ScriptsScriptAndVersionSettingsGetResponseExportsReconciliation {
    /** Class names for which a new namespace was provisioned. */
    created: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationCreatedList;
    /** Class names whose namespace was deleted by a `deleted` tombstone. */
    deleted: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationDeletedList;
    /** Non-blocking info entries (stale tombstones, tombstone applied with class still in code). See `exports_reconciliation_info`. */
    info: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationInfoList;
    /** Source class names whose tombstone entry is now stale and safe to delete from `exports` (no remaining referencing scripts). */
    removableEntries: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationRemovableEntriesList;
    /** Applied `renamed` tombstones. */
    renamed: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationRenamedList;
    /** Phase-1 transfer hints recorded on the target side. */
    transferPending: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationTransferPendingList;
    /** Committed `transferred` tombstones (phase-2). */
    transferred: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationTransferredList;
    /** Class names whose provisioned namespace was mutated in place. */
    updated: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationUpdatedList;
    /** Non-blocking warnings. See `exports_reconciliation_warning`. */
    warnings: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliationWarningsList;
}
export type ScriptsScriptAndVersionSettingsGetResponseLimits = BetaWorkersCreateResponsePreviewsBaseConfigLimits;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationNewClassesList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesList | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList = Array<ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export interface ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseMigrations = ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigration | ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrations;
export type ScriptsScriptAndVersionSettingsGetResponseObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type ScriptsScriptAndVersionSettingsGetResponseObservabilityLogsDestinationsList = Array<string>;
export interface ScriptsScriptAndVersionSettingsGetResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsScriptAndVersionSettingsGetResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseObservabilityTracesDestinationsList = Array<string>;
export type ScriptsScriptAndVersionSettingsGetResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface ScriptsScriptAndVersionSettingsGetResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsScriptAndVersionSettingsGetResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: ScriptsScriptAndVersionSettingsGetResponseObservabilityTracesPropagationPolicy | null;
}
export interface ScriptsScriptAndVersionSettingsGetResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: ScriptsScriptAndVersionSettingsGetResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsScriptAndVersionSettingsGetResponseObservabilityTraces | null;
}
export type ScriptsScriptAndVersionSettingsGetResponsePlacementModeMode = "smart";
export interface ScriptsScriptAndVersionSettingsGetResponsePlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: ScriptsScriptAndVersionSettingsGetResponsePlacementModeMode;
}
export type ScriptsScriptAndVersionSettingsGetResponsePlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase4Mode = "targeted";
export interface ScriptsScriptAndVersionSettingsGetResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsGetResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase5Mode = "targeted";
export interface ScriptsScriptAndVersionSettingsGetResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsGetResponsePlacementCase5Mode;
}
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase6Mode = "targeted";
export interface ScriptsScriptAndVersionSettingsGetResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsGetResponsePlacementCase6Mode;
}
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase7Mode = "targeted";
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetList = Array<ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItem>;
export interface ScriptsScriptAndVersionSettingsGetResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsGetResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetList;
}
export type ScriptsScriptAndVersionSettingsGetResponsePlacement = ScriptsScriptAndVersionSettingsGetResponsePlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | ScriptsScriptAndVersionSettingsGetResponsePlacementCase4 | ScriptsScriptAndVersionSettingsGetResponsePlacementCase5 | ScriptsScriptAndVersionSettingsGetResponsePlacementCase6 | ScriptsScriptAndVersionSettingsGetResponsePlacementCase7;
export type ScriptsScriptAndVersionSettingsGetResponseTagsList = Array<string>;
export interface ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem {
    /** Name of Worker that is to be the consumer. */
    service: string;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
    /** Optional dispatch namespace the script belongs to. */
    namespace?: string | null;
}
export type ScriptsScriptAndVersionSettingsGetResponseTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export type ScriptsScriptAndVersionSettingsGetResponseUsageModel = "standard" | "bundled" | "unbound";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptScriptAndVersionSettingResponse {
    /** Annotations for the Worker version. Annotations are not inherited across settings updates; omitting this field means the new version will have no annotations. */
    annotations?: ScriptsScriptAndVersionSettingsGetResponseAnnotations | null;
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: ScriptsScriptAndVersionSettingsGetResponseBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: ScriptsScriptAndVersionSettingsGetResponseCompatibilityFlagsList | null;
    /** Declarative exports for the Worker. Worker entrypoint entries (`type: worker`) carry cache configuration for that entrypoint. */
    exports?: ScriptsScriptAndVersionSettingsGetResponseExportsMap | null;
    /** Summary of the declarative exports reconciliation that ran on this upload. Populated only when the uploaded metadata included an `exports` block. Durable Object entries drive reconciliation; `type: worker` entries do not contribute to this summary. */
    exportsReconciliation?: ScriptsScriptAndVersionSettingsGetResponseExportsReconciliation | null;
    /** Limits to apply for this Worker. */
    limits?: BetaWorkersCreateResponsePreviewsBaseConfigLimits | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** Migrations to apply for Durable Objects associated with this Worker. */
    migrations?: ScriptsScriptAndVersionSettingsGetResponseMigrations | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsScriptAndVersionSettingsGetResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: ScriptsScriptAndVersionSettingsGetResponsePlacement | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsScriptAndVersionSettingsGetResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsScriptAndVersionSettingsGetResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsScriptAndVersionSettingsGetResponseUsageModel | null;
}
export interface GetScriptSecretRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** A JavaScript variable name for the secret binding. */
    secretName: string;
    /** Flag that indicates whether the secret name is URL encoded. */
    urlEncoded?: boolean;
}
export type ScriptsSecretsGetResultSecretTextType = "secret_text";
export interface ScriptsSecretsGetResultSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsGetResultSecretTextType;
}
export type ScriptsSecretsGetResultSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type ScriptsSecretsGetResultSecretKeyType = "secret_key";
export type ScriptsSecretsGetResultSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type ScriptsSecretsGetResultSecretKeyUsagesList = Array<ScriptsSecretsGetResultSecretKeyUsagesItem>;
export interface ScriptsSecretsGetResultSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsSecretsGetResultSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsGetResultSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsSecretsGetResultSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type ScriptsSecretsGetResult = ScriptsSecretsGetResultSecretText | ScriptsSecretsGetResultSecretKey;
export type GetScriptSecretResponse = ScriptsSecretsGetResult;
export interface GetScriptSettingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
}
export type ScriptsSettingsGetResponseObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type ScriptsSettingsGetResponseObservabilityLogsDestinationsList = Array<string>;
export interface ScriptsSettingsGetResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsSettingsGetResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type ScriptsSettingsGetResponseObservabilityTracesDestinationsList = Array<string>;
export type ScriptsSettingsGetResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface ScriptsSettingsGetResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsSettingsGetResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: ScriptsSettingsGetResponseObservabilityTracesPropagationPolicy | null;
}
export interface ScriptsSettingsGetResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: ScriptsSettingsGetResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsSettingsGetResponseObservabilityTraces | null;
}
export type ScriptsSettingsGetResponseTagsList = Array<string>;
export type ScriptsSettingsGetResponseTailConsumersItem = ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem;
export type ScriptsSettingsGetResponseTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptSettingResponse {
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsSettingsGetResponseObservability | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsSettingsGetResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsSettingsGetResponseTailConsumersList | null;
}
export interface GetScriptSubdomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptSubdomainResponse {
    /** Whether the Worker is available on the workers.dev subdomain. */
    enabled: boolean;
    /** Whether the Worker's Preview URLs are available on the workers.dev subdomain. */
    previewsEnabled: boolean;
}
export interface GetScriptTailRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptTailResponse {
    /** Identifier. */
    id: string;
    expiresAt: string;
    url: string;
}
export interface GetScriptVersionRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    versionId: string;
}
export type ScriptsVersionsGetResponseResourcesScriptHandlersList = Array<string>;
export type ScriptsVersionsGetResponseResourcesScriptNamedHandlersItemHandlersList = Array<string>;
export interface ScriptsVersionsGetResponseResourcesScriptNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: ScriptsVersionsGetResponseResourcesScriptNamedHandlersItemHandlersList | null;
    /** The name of the exported class or entrypoint. */
    name?: string | null;
}
export type ScriptsVersionsGetResponseResourcesScriptNamedHandlersList = Array<ScriptsVersionsGetResponseResourcesScriptNamedHandlersItem>;
export interface ScriptsVersionsGetResponseResourcesScript {
    /** Hashed script content */
    etag?: string | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: ScriptsVersionsGetResponseResourcesScriptHandlersList | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: ScriptsVersionsGetResponseResourcesScriptNamedHandlersList | null;
}
export type ScriptsVersionsGetResponseResourcesScriptRuntimeCompatibilityFlagsList = Array<string>;
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkerType = "worker";
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkerCache = BetaWorkersVersionsCreateRequestExportsValueWorkerCache;
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkerState = "created";
export interface ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: BetaWorkersVersionsCreateRequestExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkerState | null;
}
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExportType = "durable-object";
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExportState = "created";
export interface ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExportState | null;
}
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectDeletedExportType;
}
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectRenamedExportType;
}
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectTransferredExportType;
}
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValue = ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorker | ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExport | ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectDeletedExport | ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectRenamedExport | ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectTransferredExport | ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValueWorkersDurableObjectExpectingTransferExport;
export type ScriptsVersionsGetResponseResourcesScriptRuntimeExportsMap = {
    [key: string]: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsValue | undefined;
};
export type ScriptsVersionsGetResponseResourcesScriptRuntimeLimits = ScriptsVersionsCreateResponseResourcesScriptRuntimeLimits;
export type ScriptsVersionsGetResponseResourcesScriptRuntimeUsageModel = "bundled" | "unbound" | "standard";
export interface ScriptsVersionsGetResponseResourcesScriptRuntime {
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. */
    compatibilityFlags?: ScriptsVersionsGetResponseResourcesScriptRuntimeCompatibilityFlagsList | null;
    /** Declarative exports for this version, including Durable Object classes (with their `storage` backend) and named Worker entrypoints. Tombstoned lifecycle entries are omitted, so only live exports (`created` and `expecting-transfer`) are returned. */
    exports?: ScriptsVersionsGetResponseResourcesScriptRuntimeExportsMap | null;
    /** Resource limits for the Worker. */
    limits?: ScriptsVersionsCreateResponseResourcesScriptRuntimeLimits | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsVersionsGetResponseResourcesScriptRuntimeUsageModel | null;
    containers?: BetaWorkersVersionsGetResponseContainersList | null;
}
export interface ScriptsVersionsGetResponseResources {
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings: unknown;
    script?: ScriptsVersionsGetResponseResourcesScript | null;
    /** Runtime configuration for the Worker. */
    scriptRuntime?: ScriptsVersionsGetResponseResourcesScriptRuntime | null;
}
export type ScriptsVersionsGetResponseMetadataSource = "unknown" | "api" | "wrangler" | "terraform" | "dash" | "cf_cli" | "dash_template" | "integration" | "quick_editor" | "playground" | "workersci";
export interface ScriptsVersionsGetResponseMetadata {
    /** Email of the user who created the version. */
    authorEmail?: string | null;
    /** Identifier of the user who created the version. */
    authorId?: string | null;
    /** When the version was created. */
    createdOn?: string | null;
    /** Whether the version can be previewed. */
    hasPreview?: boolean | null;
    /** When the version was last modified. */
    modifiedOn?: string | null;
    /** The source of the version upload. */
    source?: ScriptsVersionsGetResponseMetadataSource | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptVersionResponse {
    resources: ScriptsVersionsGetResponseResources;
    /** Unique identifier for the version. */
    id?: string | null;
    metadata?: ScriptsVersionsGetResponseMetadata | null;
    /** Sequential version number. */
    number?: number | null;
}
export interface GetSubdomainRequest {
    /** Identifier. */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSubdomainResponse {
    subdomain: string;
}
export type ObservabilityTelemetryKeysRequestDatasetsList = Array<string>;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0FiltersList = Array<unknown>;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0Kind = "group";
export interface ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0 {
    filterCombination: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0Kind;
}
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue;
}
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItem = ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0 | ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersList = Array<ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItem>;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0Kind = "group";
export interface ObservabilityTelemetryKeysRequestFiltersItemCase0 {
    filterCombination: ObservabilityTelemetryKeysRequestFiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryKeysRequestFiltersItemCase0Kind;
}
export type ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafValue;
}
export type ObservabilityTelemetryKeysRequestFiltersItem = ObservabilityTelemetryKeysRequestFiltersItemCase0 | ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilityTelemetryKeysRequestFiltersList = Array<ObservabilityTelemetryKeysRequestFiltersItem>;
export type ObservabilityTelemetryKeysRequestKeyNeedleValue = string | number | boolean;
export interface ObservabilityTelemetryKeysRequestKeyNeedle {
    /** The text or pattern to search for. */
    value: ObservabilityTelemetryKeysRequestKeyNeedleValue;
    /** When true, treats the value as a regular expression (RE2 syntax). */
    isRegex?: boolean;
    /** When true, performs a case-sensitive search. Defaults to case-insensitive. */
    matchCase?: boolean;
}
export type ObservabilityTelemetryKeysRequestNeedleValue = string | number | boolean;
export interface ObservabilityTelemetryKeysRequestNeedle {
    /** The text or pattern to search for. */
    value: ObservabilityTelemetryKeysRequestNeedleValue;
    /** When true, treats the value as a regular expression (RE2 syntax). */
    isRegex?: boolean;
    /** When true, performs a case-sensitive search. Defaults to case-insensitive. */
    matchCase?: boolean;
}
export interface KeysObservabilityTelemetryRequest {
    accountId: string;
    /** Leave this empty to use the default datasets */
    datasets?: ObservabilityTelemetryKeysRequestDatasetsList;
    /** Apply filters to narrow key discovery. Supports nested groups via kind: 'group'. Maximum nesting depth is 4. */
    filters?: ObservabilityTelemetryKeysRequestFiltersList;
    from?: number;
    /** If the user suggests a key, use this to narrow down the list of keys returned. Make sure matchCase is false to avoid case sensitivity issues. */
    keyNeedle?: ObservabilityTelemetryKeysRequestKeyNeedle;
    /** Advanced usage: set limit=1000+ to retrieve comprehensive key options without needing additional filtering. */
    limit?: number;
    /** Search for a specific substring in any of the events */
    needle?: ObservabilityTelemetryKeysRequestNeedle;
    to?: number;
}
export type ObservabilityTelemetryKeysResultItemType = "string" | "boolean" | "number";
export interface ObservabilityTelemetryKeysResultItem {
    key: string;
    lastSeenAt: number;
    type: ObservabilityTelemetryKeysResultItemType;
}
export type ObservabilityTelemetryKeysResultList = Array<ObservabilityTelemetryKeysResultItem>;
export interface KeysObservabilityTelemetryResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ObservabilityTelemetryKeysResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type BetaWorkersListRequestOrder = "asc" | "desc";
export type BetaWorkersListRequestOrderBy = "deployed_on" | "updated_on" | "created_on" | "name";
export interface ListBetaWorkersRequest {
    /** Identifier. */
    accountId: string;
    /** Sort direction. */
    order?: BetaWorkersListRequestOrder | (string & {});
    /** Property to sort results by. */
    orderBy?: BetaWorkersListRequestOrderBy | (string & {});
    /** Current page. */
    page?: number;
    /** Items per-page. */
    perPage?: number;
}
export type BetaWorkersListResultItemObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type BetaWorkersListResultItemObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersListResultItemObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersListResultItemObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type BetaWorkersListResultItemObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersListResultItemObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersListResultItemObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersListResultItemObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersListResultItemObservabilityTracesPropagationPolicy | null;
}
export interface BetaWorkersListResultItemObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersListResultItemObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersListResultItemObservabilityTraces | null;
}
export type BetaWorkersListResultItemReferencesDispatchNamespaceOutboundsItem = BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem;
export type BetaWorkersListResultItemReferencesDispatchNamespaceOutboundsList = Array<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export type BetaWorkersListResultItemReferencesDomainsItem = BetaWorkersCreateResponseReferencesDomainsItem;
export type BetaWorkersListResultItemReferencesDomainsList = Array<BetaWorkersCreateResponseReferencesDomainsItem>;
export type BetaWorkersListResultItemReferencesDurableObjectsItem = BetaWorkersCreateResponseReferencesDurableObjectsItem;
export type BetaWorkersListResultItemReferencesDurableObjectsList = Array<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export type BetaWorkersListResultItemReferencesQueuesItem = BetaWorkersCreateResponseReferencesQueuesItem;
export type BetaWorkersListResultItemReferencesQueuesList = Array<BetaWorkersCreateResponseReferencesQueuesItem>;
export type BetaWorkersListResultItemReferencesWorkersItem = BetaWorkersCreateResponseReferencesWorkersItem;
export type BetaWorkersListResultItemReferencesWorkersList = Array<BetaWorkersCreateResponseReferencesWorkersItem>;
export interface BetaWorkersListResultItemReferences {
    /** Other Workers that reference the Worker as an outbound for a dispatch namespace. */
    dispatchNamespaceOutbounds: BetaWorkersListResultItemReferencesDispatchNamespaceOutboundsList;
    /** Custom domains connected to the Worker. */
    domains: BetaWorkersListResultItemReferencesDomainsList;
    /** Other Workers that reference Durable Object classes implemented by the Worker. */
    durableObjects: BetaWorkersListResultItemReferencesDurableObjectsList;
    /** Queues that send messages to the Worker. */
    queues: BetaWorkersListResultItemReferencesQueuesList;
    /** Other Workers that reference the Worker using [service bindings](https://developers.cloudflare.com/workers/runtime-apis/bindings/service-bindings/). */
    workers: BetaWorkersListResultItemReferencesWorkersList;
}
export type BetaWorkersListResultItemSubdomain = BetaWorkersCreateResponseSubdomain;
export type BetaWorkersListResultItemTagsList = Array<string>;
export type BetaWorkersListResultItemTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersListResultItemTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export type BetaWorkersListResultItemPreviewsBaseConfigCacheOptions = BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions;
export type BetaWorkersListResultItemPreviewsBaseConfigEnvValue = BetaWorkersCreateRequestPreviewsBaseConfigEnvValue;
export type BetaWorkersListResultItemPreviewsBaseConfigEnvMap = {
    [key: string]: BetaWorkersCreateRequestPreviewsBaseConfigEnvValue | undefined;
};
export type BetaWorkersListResultItemPreviewsBaseConfigLimits = BetaWorkersCreateResponsePreviewsBaseConfigLimits;
export type BetaWorkersListResultItemPreviewsBaseConfigObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type BetaWorkersListResultItemPreviewsBaseConfigObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersListResultItemPreviewsBaseConfigObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersListResultItemPreviewsBaseConfigObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type BetaWorkersListResultItemPreviewsBaseConfigObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersListResultItemPreviewsBaseConfigObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersListResultItemPreviewsBaseConfigObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersListResultItemPreviewsBaseConfigObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersListResultItemPreviewsBaseConfigObservabilityTracesPropagationPolicy | null;
}
export interface BetaWorkersListResultItemPreviewsBaseConfigObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersListResultItemPreviewsBaseConfigObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersListResultItemPreviewsBaseConfigObservabilityTraces | null;
}
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementModeMode = "smart";
export interface BetaWorkersListResultItemPreviewsBaseConfigPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersListResultItemPreviewsBaseConfigPlacementModeMode;
}
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementCase4Mode = "targeted";
export interface BetaWorkersListResultItemPreviewsBaseConfigPlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersListResultItemPreviewsBaseConfigPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementCase5Mode = "targeted";
export interface BetaWorkersListResultItemPreviewsBaseConfigPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersListResultItemPreviewsBaseConfigPlacementCase5Mode;
}
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementCase6Mode = "targeted";
export interface BetaWorkersListResultItemPreviewsBaseConfigPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersListResultItemPreviewsBaseConfigPlacementCase6Mode;
}
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementCase7Mode = "targeted";
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersListResultItemPreviewsBaseConfigPlacementCase7TargetList = Array<BetaWorkersListResultItemPreviewsBaseConfigPlacementCase7TargetItem>;
export interface BetaWorkersListResultItemPreviewsBaseConfigPlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersListResultItemPreviewsBaseConfigPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersListResultItemPreviewsBaseConfigPlacementCase7TargetList;
}
export type BetaWorkersListResultItemPreviewsBaseConfigPlacement = BetaWorkersListResultItemPreviewsBaseConfigPlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | BetaWorkersListResultItemPreviewsBaseConfigPlacementCase4 | BetaWorkersListResultItemPreviewsBaseConfigPlacementCase5 | BetaWorkersListResultItemPreviewsBaseConfigPlacementCase6 | BetaWorkersListResultItemPreviewsBaseConfigPlacementCase7;
export type BetaWorkersListResultItemPreviewsBaseConfigTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersListResultItemPreviewsBaseConfigTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export interface BetaWorkersListResultItemPreviewsBaseConfig {
    /** Cache options used when creating new Previews. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Bindings used when creating new Previews, keyed by binding name. */
    env?: BetaWorkersListResultItemPreviewsBaseConfigEnvMap | null;
    /** Resource limits enforced at runtime for newly created Previews. */
    limits?: BetaWorkersCreateResponsePreviewsBaseConfigLimits | null;
    /** Whether logpush is enabled when creating new Previews. */
    logpush?: boolean | null;
    /** Observability settings used when creating new Previews. */
    observability?: BetaWorkersListResultItemPreviewsBaseConfigObservability | null;
    /** Placement configuration used when creating new Previews. */
    placement?: BetaWorkersListResultItemPreviewsBaseConfigPlacement | null;
    /** Other Workers that should consume logs from newly created Previews. */
    tailConsumers?: BetaWorkersListResultItemPreviewsBaseConfigTailConsumersList | null;
}
export interface BetaWorkersListResultItem {
    /** Immutable ID of the Worker. */
    id: string;
    /** When the Worker was created. */
    createdOn: string;
    /** Whether logpush is enabled for the Worker. */
    logpush: boolean;
    /** Name of the Worker. */
    name: string;
    /** Observability settings for the Worker. */
    observability: BetaWorkersListResultItemObservability;
    /** Other resources that reference the Worker and depend on it existing. */
    references: BetaWorkersListResultItemReferences;
    /** Subdomain settings for the Worker. */
    subdomain: BetaWorkersCreateResponseSubdomain;
    /** Tags associated with the Worker. */
    tags: BetaWorkersListResultItemTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers: BetaWorkersListResultItemTailConsumersList;
    /** When the Worker was most recently updated. */
    updatedOn: string;
    /** When the Worker's most recent deployment was created. `null` if the Worker has never been deployed. */
    deployedOn?: string | null;
    /** Template configuration used when creating new Previews for this Worker. */
    previewsBaseConfig?: BetaWorkersListResultItemPreviewsBaseConfig | null;
}
export type BetaWorkersListResultList = Array<BetaWorkersListResultItem>;
export interface ListBetaWorkersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: BetaWorkersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListBetaWorkerVersionsRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** Current page. */
    page?: number;
    /** Items per-page. */
    perPage?: number;
}
export type BetaWorkersVersionsListResultItemUrlsList = Array<string>;
export type BetaWorkersVersionsListResultItemAnnotations = BetaWorkersVersionsCreateResponseAnnotations;
export type BetaWorkersVersionsListResultItemAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export type BetaWorkersVersionsListResultItemAssetsConfigNotFoundHandling = "none" | "404-page" | "single-page-application";
export type BetaWorkersVersionsListResultItemAssetsConfigRunWorkerFirstCase0List = Array<string>;
export type BetaWorkersVersionsListResultItemAssetsConfigRunWorkerFirst = boolean | BetaWorkersVersionsListResultItemAssetsConfigRunWorkerFirstCase0List;
export interface BetaWorkersVersionsListResultItemAssetsConfig {
    /** The public URL path prefix under which assets are served. A null request value resets it to `/`; responses represent the root as `/`. All versions in a gradual deployment must use the same canonical value. To change it, first deploy the version containing the change at 100%. */
    basePath?: string | null;
    /** Determines the redirects and rewrites of requests for HTML content. */
    htmlHandling?: BetaWorkersVersionsListResultItemAssetsConfigHtmlHandling | null;
    /** Determines the response when a request does not match a static asset, and there is no Worker script. */
    notFoundHandling?: BetaWorkersVersionsListResultItemAssetsConfigNotFoundHandling | null;
    /** Contains a list path rules to control routing to either the Worker or assets. Glob (*) and negative (!) rules are supported. Rules must start with either '/' or '!/'. At least one non-negative rule must be provided, and negative rules have higher precedence than non-negative rules. */
    runWorkerFirst?: BetaWorkersVersionsListResultItemAssetsConfigRunWorkerFirst | null;
}
export interface BetaWorkersVersionsListResultItemAssets {
    /** Configuration for assets within a Worker. */
    config?: BetaWorkersVersionsListResultItemAssetsConfig | null;
    /** Token provided upon successful upload of all files from a registered manifest. */
    jwt?: string | null;
}
export type BetaWorkersVersionsListResultItemBindingsItemAIType = "ai";
export interface BetaWorkersVersionsListResultItemBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemAIType;
}
export type BetaWorkersVersionsListResultItemBindingsItemAISearchType = "ai_search";
export interface BetaWorkersVersionsListResultItemBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export type BetaWorkersVersionsListResultItemBindingsItemAISearchNamespaceType = "ai_search_namespace";
export interface BetaWorkersVersionsListResultItemBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemAISearchNamespaceType;
}
export type BetaWorkersVersionsListResultItemBindingsItemMessagingType = "messaging";
export interface BetaWorkersVersionsListResultItemBindingsItemMessaging {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Messaging namespace to bind to. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemMessagingType;
}
export type BetaWorkersVersionsListResultItemBindingsItemAnalyticsEngineType = "analytics_engine";
export interface BetaWorkersVersionsListResultItemBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemAnalyticsEngineType;
}
export type BetaWorkersVersionsListResultItemBindingsItemArtifactsType = "artifacts";
export interface BetaWorkersVersionsListResultItemBindingsItemArtifacts {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Artifacts namespace exposed to the Worker in the Worker's account. Must be 2-63 characters, start with an ASCII alphanumeric character, contain only ASCII alphanumeric characters, dots, underscores, and hyphens, and must not end with a hyphen. The namespace does not need to be created before binding it. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemArtifactsType;
}
export type BetaWorkersVersionsListResultItemBindingsItemAssetsType = "assets";
export interface BetaWorkersVersionsListResultItemBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemAssetsType;
}
export type BetaWorkersVersionsListResultItemBindingsItemBrowserType = "browser";
export interface BetaWorkersVersionsListResultItemBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemBrowserType;
}
export type BetaWorkersVersionsListResultItemBindingsItemD1Type = "d1";
export interface BetaWorkersVersionsListResultItemBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemD1Type;
    /** This property has been renamed to `database_id`. */
    id?: string | null;
}
export type BetaWorkersVersionsListResultItemBindingsItemDataBlobType = "data_blob";
export interface BetaWorkersVersionsListResultItemBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemDataBlobType;
}
export type BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceType = "dispatch_namespace";
export type BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutboundParamsItem = BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem;
export type BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export type BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutboundWorker = BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker;
export interface BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker | null;
}
export interface BetaWorkersVersionsListResultItemBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutbound | null;
}
export type BetaWorkersVersionsListResultItemBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export interface BetaWorkersVersionsListResultItemBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export type BetaWorkersVersionsListResultItemBindingsItemHyperdriveType = "hyperdrive";
export interface BetaWorkersVersionsListResultItemBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemHyperdriveType;
}
export type BetaWorkersVersionsListResultItemBindingsItemInheritType = "inherit";
export interface BetaWorkersVersionsListResultItemBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from. This can be a version ID, or the literal "latest" to inherit from the most recently uploaded version, which may not be the deployed version. Defaults to "latest". Only the Workers API version endpoints under `/accounts/{account_id}/workers/workers/{worker_id}/versions` accept a version ID. Other endpoints, including script upload and script version upload, accept only "latest" and reject a version ID with error 10057. */
    versionId?: string | null;
}
export type BetaWorkersVersionsListResultItemBindingsItemImagesType = "images";
export interface BetaWorkersVersionsListResultItemBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemImagesType;
}
export type BetaWorkersVersionsListResultItemBindingsItemJsonType = "json";
export interface BetaWorkersVersionsListResultItemBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemJsonType;
}
export type BetaWorkersVersionsListResultItemBindingsItemKVNamespaceType = "kv_namespace";
export interface BetaWorkersVersionsListResultItemBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemKVNamespaceType;
}
export type BetaWorkersVersionsListResultItemBindingsItemMediaType = "media";
export interface BetaWorkersVersionsListResultItemBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemMediaType;
}
export type BetaWorkersVersionsListResultItemBindingsItemMTLSCertificateType = "mtls_certificate";
export interface BetaWorkersVersionsListResultItemBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemMTLSCertificateType;
}
export type BetaWorkersVersionsListResultItemBindingsItemPlainTextType = "plain_text";
export interface BetaWorkersVersionsListResultItemBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemPlainTextType;
}
export type BetaWorkersVersionsListResultItemBindingsItemPipelinesType = "pipelines";
export interface BetaWorkersVersionsListResultItemBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemPipelinesType;
}
export type BetaWorkersVersionsListResultItemBindingsItemK2Type = "k2";
export interface BetaWorkersVersionsListResultItemBindingsItemK2 {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** ID of a K2 stream owned by the account deploying the Worker. */
    stream: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemK2Type;
}
export type BetaWorkersVersionsListResultItemBindingsItemQueueType = "queue";
export interface BetaWorkersVersionsListResultItemBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemQueueType;
}
export type BetaWorkersVersionsListResultItemBindingsItemRatelimitSimple = BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
export type BetaWorkersVersionsListResultItemBindingsItemRatelimitType = "ratelimit";
export interface BetaWorkersVersionsListResultItemBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemRatelimitType;
}
export type BetaWorkersVersionsListResultItemBindingsItemR2BucketType = "r2_bucket";
export type BetaWorkersVersionsListResultItemBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high" | "us";
export interface BetaWorkersVersionsListResultItemBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: BetaWorkersVersionsListResultItemBindingsItemR2BucketJurisdiction | null;
}
export type BetaWorkersVersionsListResultItemBindingsItemSecretTextType = "secret_text";
export interface BetaWorkersVersionsListResultItemBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemSecretTextType;
}
export type BetaWorkersVersionsListResultItemBindingsItemSendEmailType = "send_email";
export type BetaWorkersVersionsListResultItemBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export type BetaWorkersVersionsListResultItemBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export interface BetaWorkersVersionsListResultItemBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: BetaWorkersVersionsListResultItemBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: BetaWorkersVersionsListResultItemBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export type BetaWorkersVersionsListResultItemBindingsItemServiceType = "service";
export interface BetaWorkersVersionsListResultItemBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export type BetaWorkersVersionsListResultItemBindingsItemTextBlobType = "text_blob";
export interface BetaWorkersVersionsListResultItemBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemTextBlobType;
}
export type BetaWorkersVersionsListResultItemBindingsItemVectorizeType = "vectorize";
export interface BetaWorkersVersionsListResultItemBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemVectorizeType;
}
export type BetaWorkersVersionsListResultItemBindingsItemVersionMetadataType = "version_metadata";
export interface BetaWorkersVersionsListResultItemBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemVersionMetadataType;
}
export type BetaWorkersVersionsListResultItemBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export interface BetaWorkersVersionsListResultItemBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemSecretsStoreSecretType;
}
export type BetaWorkersVersionsListResultItemBindingsItemFlagshipType = "flagship";
export interface BetaWorkersVersionsListResultItemBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemFlagshipType;
}
export type BetaWorkersVersionsListResultItemBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type BetaWorkersVersionsListResultItemBindingsItemSecretKeyType = "secret_key";
export type BetaWorkersVersionsListResultItemBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type BetaWorkersVersionsListResultItemBindingsItemSecretKeyUsagesList = Array<BetaWorkersVersionsListResultItemBindingsItemSecretKeyUsagesItem>;
export interface BetaWorkersVersionsListResultItemBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: BetaWorkersVersionsListResultItemBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: BetaWorkersVersionsListResultItemBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type BetaWorkersVersionsListResultItemBindingsItemWorkflowType = "workflow";
export interface BetaWorkersVersionsListResultItemBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export type BetaWorkersVersionsListResultItemBindingsItemWasmModuleType = "wasm_module";
export interface BetaWorkersVersionsListResultItemBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemWasmModuleType;
}
export type BetaWorkersVersionsListResultItemBindingsItemVPCServiceType = "vpc_service";
export interface BetaWorkersVersionsListResultItemBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemVPCServiceType;
}
export type BetaWorkersVersionsListResultItemBindingsItemVPCNetworkType = "vpc_network";
export type BetaWorkersVersionsListResultItemBindingsItemVPCNetworkIdentity = "runtime-email-alpha";
export interface BetaWorkersVersionsListResultItemBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemVPCNetworkType;
    /** Enables Gateway identity for the binding. Requires network_id to be "cf1:network" and cannot be combined with tunnel_id. */
    identity?: BetaWorkersVersionsListResultItemBindingsItemVPCNetworkIdentity | null;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export type BetaWorkersVersionsListResultItemBindingsItem = BetaWorkersVersionsListResultItemBindingsItemAI | BetaWorkersVersionsListResultItemBindingsItemAISearch | BetaWorkersVersionsListResultItemBindingsItemAISearchNamespace | BetaWorkersVersionsListResultItemBindingsItemMessaging | BetaWorkersVersionsListResultItemBindingsItemAnalyticsEngine | BetaWorkersVersionsListResultItemBindingsItemArtifacts | BetaWorkersVersionsListResultItemBindingsItemAssets | BetaWorkersVersionsListResultItemBindingsItemBrowser | BetaWorkersVersionsListResultItemBindingsItemD1 | BetaWorkersVersionsListResultItemBindingsItemDataBlob | BetaWorkersVersionsListResultItemBindingsItemDispatchNamespace | BetaWorkersVersionsListResultItemBindingsItemDurableObjectNamespace | BetaWorkersVersionsListResultItemBindingsItemHyperdrive | BetaWorkersVersionsListResultItemBindingsItemInherit | BetaWorkersVersionsListResultItemBindingsItemImages | BetaWorkersVersionsListResultItemBindingsItemJson | BetaWorkersVersionsListResultItemBindingsItemKVNamespace | BetaWorkersVersionsListResultItemBindingsItemMedia | BetaWorkersVersionsListResultItemBindingsItemMTLSCertificate | BetaWorkersVersionsListResultItemBindingsItemPlainText | BetaWorkersVersionsListResultItemBindingsItemPipelines | BetaWorkersVersionsListResultItemBindingsItemK2 | BetaWorkersVersionsListResultItemBindingsItemQueue | BetaWorkersVersionsListResultItemBindingsItemRatelimit | BetaWorkersVersionsListResultItemBindingsItemR2Bucket | BetaWorkersVersionsListResultItemBindingsItemSecretText | BetaWorkersVersionsListResultItemBindingsItemSendEmail | BetaWorkersVersionsListResultItemBindingsItemService | BetaWorkersVersionsListResultItemBindingsItemTextBlob | BetaWorkersVersionsListResultItemBindingsItemVectorize | BetaWorkersVersionsListResultItemBindingsItemVersionMetadata | BetaWorkersVersionsListResultItemBindingsItemSecretsStoreSecret | BetaWorkersVersionsListResultItemBindingsItemFlagship | BetaWorkersVersionsListResultItemBindingsItemSecretKey | BetaWorkersVersionsListResultItemBindingsItemWorkflow | BetaWorkersVersionsListResultItemBindingsItemWasmModule | BetaWorkersVersionsListResultItemBindingsItemVPCService | BetaWorkersVersionsListResultItemBindingsItemVPCNetwork;
export type BetaWorkersVersionsListResultItemBindingsList = Array<BetaWorkersVersionsListResultItemBindingsItem>;
export type BetaWorkersVersionsListResultItemCacheOptions = BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions;
export type BetaWorkersVersionsListResultItemCompatibilityFlagsList = Array<string>;
export type BetaWorkersVersionsListResultItemContainersItem = BetaWorkersVersionsCreateResponseContainersItem;
export type BetaWorkersVersionsListResultItemContainersList = Array<BetaWorkersVersionsCreateResponseContainersItem>;
export type BetaWorkersVersionsListResultItemExportsValueWorkerType = "worker";
export type BetaWorkersVersionsListResultItemExportsValueWorkerCache = BetaWorkersVersionsCreateRequestExportsValueWorkerCache;
export type BetaWorkersVersionsListResultItemExportsValueWorkerState = "created";
export interface BetaWorkersVersionsListResultItemExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: BetaWorkersVersionsListResultItemExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: BetaWorkersVersionsCreateRequestExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: BetaWorkersVersionsListResultItemExportsValueWorkerState | null;
}
export type BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExportType = "durable-object";
export type BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExportState = "created";
export interface BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExportState | null;
}
export type BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectDeletedExportType;
}
export type BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectRenamedExportType;
}
export type BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectTransferredExportType;
}
export type BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type BetaWorkersVersionsListResultItemExportsValue = BetaWorkersVersionsListResultItemExportsValueWorker | BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExport | BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectDeletedExport | BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectRenamedExport | BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectTransferredExport | BetaWorkersVersionsListResultItemExportsValueWorkersDurableObjectExpectingTransferExport;
export type BetaWorkersVersionsListResultItemExportsMap = {
    [key: string]: BetaWorkersVersionsListResultItemExportsValue | undefined;
};
export type BetaWorkersVersionsListResultItemExportsReconciliationCreatedList = Array<string>;
export type BetaWorkersVersionsListResultItemExportsReconciliationDeletedList = Array<string>;
export type BetaWorkersVersionsListResultItemExportsReconciliationInfoItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export type BetaWorkersVersionsListResultItemExportsReconciliationInfoItemReferencingScriptsList = Array<string>;
export interface BetaWorkersVersionsListResultItemExportsReconciliationInfoItem {
    /** The class name the info entry is about. */
    class: string;
    /** Human-readable explanation. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: BetaWorkersVersionsListResultItemExportsReconciliationInfoItemScenario;
    /** The provisioned namespace the entry relates to, when applicable. */
    namespaceId?: string | null;
    /** Other Workers in the account that still bind to the affected class. Advisory: while non-empty the tombstone is not yet safe to remove -- redeploy these Workers with bindings re-pointed first. */
    referencingScripts?: BetaWorkersVersionsListResultItemExportsReconciliationInfoItemReferencingScriptsList | null;
}
export type BetaWorkersVersionsListResultItemExportsReconciliationInfoList = Array<BetaWorkersVersionsListResultItemExportsReconciliationInfoItem>;
export type BetaWorkersVersionsListResultItemExportsReconciliationRemovableEntriesList = Array<string>;
export type BetaWorkersVersionsListResultItemExportsReconciliationRenamedItem = BetaWorkersVersionsCreateResponseExportsReconciliationRenamedItem;
export type BetaWorkersVersionsListResultItemExportsReconciliationRenamedList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationRenamedItem>;
export type BetaWorkersVersionsListResultItemExportsReconciliationTransferPendingItem = BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingItem;
export type BetaWorkersVersionsListResultItemExportsReconciliationTransferPendingList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingItem>;
export type BetaWorkersVersionsListResultItemExportsReconciliationTransferredItemPhase = "committed";
export interface BetaWorkersVersionsListResultItemExportsReconciliationTransferredItem {
    /** The source class name that was transferred. */
    class: string;
    /** The transfer phase. Currently always `committed`. */
    phase: BetaWorkersVersionsListResultItemExportsReconciliationTransferredItemPhase;
    /** The destination script that now owns the namespace. */
    to: string;
}
export type BetaWorkersVersionsListResultItemExportsReconciliationTransferredList = Array<BetaWorkersVersionsListResultItemExportsReconciliationTransferredItem>;
export type BetaWorkersVersionsListResultItemExportsReconciliationUpdatedList = Array<string>;
export type BetaWorkersVersionsListResultItemExportsReconciliationWarningsItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export interface BetaWorkersVersionsListResultItemExportsReconciliationWarningsItem {
    /** The class name the warning is about. */
    class: string;
    /** Human-readable explanation of the warning. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: BetaWorkersVersionsListResultItemExportsReconciliationWarningsItemScenario;
    /** The provisioned namespace the warning relates to, when applicable. */
    namespaceId?: string | null;
}
export type BetaWorkersVersionsListResultItemExportsReconciliationWarningsList = Array<BetaWorkersVersionsListResultItemExportsReconciliationWarningsItem>;
export interface BetaWorkersVersionsListResultItemExportsReconciliation {
    /** Class names for which a new namespace was provisioned. */
    created: BetaWorkersVersionsListResultItemExportsReconciliationCreatedList;
    /** Class names whose namespace was deleted by a `deleted` tombstone. */
    deleted: BetaWorkersVersionsListResultItemExportsReconciliationDeletedList;
    /** Non-blocking info entries (stale tombstones, tombstone applied with class still in code). See `exports_reconciliation_info`. */
    info: BetaWorkersVersionsListResultItemExportsReconciliationInfoList;
    /** Source class names whose tombstone entry is now stale and safe to delete from `exports` (no remaining referencing scripts). */
    removableEntries: BetaWorkersVersionsListResultItemExportsReconciliationRemovableEntriesList;
    /** Applied `renamed` tombstones. */
    renamed: BetaWorkersVersionsListResultItemExportsReconciliationRenamedList;
    /** Phase-1 transfer hints recorded on the target side. */
    transferPending: BetaWorkersVersionsListResultItemExportsReconciliationTransferPendingList;
    /** Committed `transferred` tombstones (phase-2). */
    transferred: BetaWorkersVersionsListResultItemExportsReconciliationTransferredList;
    /** Class names whose provisioned namespace was mutated in place. */
    updated: BetaWorkersVersionsListResultItemExportsReconciliationUpdatedList;
    /** Non-blocking warnings. See `exports_reconciliation_warning`. */
    warnings: BetaWorkersVersionsListResultItemExportsReconciliationWarningsList;
}
export type BetaWorkersVersionsListResultItemLimits = BetaWorkersVersionsCreateResponseLimits;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationNewClassesList = Array<string>;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface BetaWorkersVersionsListResultItemMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationTransferredClassesList | null;
}
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsList = Array<BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItem>;
export interface BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export type BetaWorkersVersionsListResultItemMigrations = BetaWorkersVersionsListResultItemMigrationsSingleStepMigration | BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrations;
export type BetaWorkersVersionsListResultItemModulesItem = BetaWorkersVersionsCreateRequestModulesItem;
export type BetaWorkersVersionsListResultItemModulesList = Array<BetaWorkersVersionsCreateRequestModulesItem>;
export type BetaWorkersVersionsListResultItemPackageDependenciesItem = BetaWorkersVersionsCreateRequestPackageDependenciesItem;
export type BetaWorkersVersionsListResultItemPackageDependenciesList = Array<BetaWorkersVersionsCreateRequestPackageDependenciesItem>;
export type BetaWorkersVersionsListResultItemPlacementModeMode = "smart";
export interface BetaWorkersVersionsListResultItemPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersVersionsListResultItemPlacementModeMode;
}
export type BetaWorkersVersionsListResultItemPlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type BetaWorkersVersionsListResultItemPlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersVersionsListResultItemPlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type BetaWorkersVersionsListResultItemPlacementCase4Mode = "targeted";
export interface BetaWorkersVersionsListResultItemPlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsListResultItemPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type BetaWorkersVersionsListResultItemPlacementCase5Mode = "targeted";
export interface BetaWorkersVersionsListResultItemPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsListResultItemPlacementCase5Mode;
}
export type BetaWorkersVersionsListResultItemPlacementCase6Mode = "targeted";
export interface BetaWorkersVersionsListResultItemPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsListResultItemPlacementCase6Mode;
}
export type BetaWorkersVersionsListResultItemPlacementCase7Mode = "targeted";
export type BetaWorkersVersionsListResultItemPlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type BetaWorkersVersionsListResultItemPlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersVersionsListResultItemPlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersVersionsListResultItemPlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersVersionsListResultItemPlacementCase7TargetList = Array<BetaWorkersVersionsListResultItemPlacementCase7TargetItem>;
export interface BetaWorkersVersionsListResultItemPlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsListResultItemPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersVersionsListResultItemPlacementCase7TargetList;
}
export type BetaWorkersVersionsListResultItemPlacement = BetaWorkersVersionsListResultItemPlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | BetaWorkersVersionsListResultItemPlacementCase4 | BetaWorkersVersionsListResultItemPlacementCase5 | BetaWorkersVersionsListResultItemPlacementCase6 | BetaWorkersVersionsListResultItemPlacementCase7;
export type BetaWorkersVersionsListResultItemUsageModel = "standard" | "bundled" | "unbound";
export interface BetaWorkersVersionsListResultItem {
    /** Version identifier. */
    id: string;
    /** When the version was created. */
    createdOn: string;
    /** The integer version number, starting from one. */
    number: number;
    /** All routable URLs that always point to this version. Does not include alias URLs, since aliases can be updated to point to a different version. */
    urls: BetaWorkersVersionsListResultItemUrlsList;
    /** Metadata about the version. */
    annotations?: BetaWorkersVersionsCreateResponseAnnotations | null;
    /** Configuration for assets within a Worker. */
    assets?: BetaWorkersVersionsListResultItemAssets | null;
    /** Email of the user who created the version. */
    authorEmail?: string | null;
    /** Identifier of the user who created the version. */
    authorId?: string | null;
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: BetaWorkersVersionsListResultItemBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: BetaWorkersVersionsListResultItemCompatibilityFlagsList | null;
    /** List of containers attached to a Worker. Containers can only be attached to Durable Object classes of this Worker script. */
    containers?: BetaWorkersVersionsListResultItemContainersList | null;
    /** Declarative exports for the version, including Durable Object classes (with their `storage` backend) and named Worker entrypoints. On reads, tombstoned lifecycle entries are omitted, so only live exports (`created` and `expecting-transfer`) are returned. `exports` and `migrations` are mutually exclusive on upload. */
    exports?: BetaWorkersVersionsListResultItemExportsMap | null;
    /** Summary of the declarative exports reconciliation that ran on this upload. Populated only when the uploaded metadata included an `exports` block. Durable Object entries drive reconciliation; `type: worker` entries do not contribute to this summary. */
    exportsReconciliation?: BetaWorkersVersionsListResultItemExportsReconciliation | null;
    /** Resource limits enforced at runtime. */
    limits?: BetaWorkersVersionsCreateResponseLimits | null;
    /** The name of the main module in the `modules` array (e.g. the name of the module that exports a `fetch` handler). */
    mainModule?: string | null;
    /** Durable Object migration tag. Set when the version is deployed. Omitted if the version has not been deployed or the Worker does not use Durable Objects. */
    migrationTag?: string | null;
    /** Migrations for Durable Objects associated with the version. Migrations are applied when the version is deployed. */
    migrations?: BetaWorkersVersionsListResultItemMigrations | null;
    /** Code, sourcemaps, and other content used at runtime. */
    modules?: BetaWorkersVersionsListResultItemModulesList | null;
    /** The list of npm packages that were installed and used when this Worker version was built. */
    packageDependencies?: BetaWorkersVersionsListResultItemPackageDependenciesList | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: BetaWorkersVersionsListResultItemPlacement | null;
    /** The client used to create the version. */
    source?: string | null;
    /** Time in milliseconds spent on [Worker startup](https://developers.cloudflare.com/workers/platform/limits/#worker-startup-time). */
    startupTimeMs?: number | null;
    /** Usage model for the version. */
    usageModel?: BetaWorkersVersionsListResultItemUsageModel | null;
}
export type BetaWorkersVersionsListResultList = Array<BetaWorkersVersionsListResultItem>;
export interface ListBetaWorkerVersionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: BetaWorkersVersionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListDomainsRequest {
    /** Identifier. */
    accountId: string;
    /** Whether the configured hostname is routable for the domain. */
    enabled?: boolean;
    /** Worker environment associated with the domain. */
    environment?: string;
    /** Hostname of the domain. */
    hostname?: string;
    /** Whether previews are routable for the domain. */
    previewsEnabled?: boolean;
    /** Name of the Worker associated with the domain. */
    service?: string;
    /** ID of the zone containing the domain hostname. */
    zoneId?: string;
    /** Name of the zone containing the domain hostname. */
    zoneName?: string;
}
export interface DomainsListResultItem {
    /** Immutable ID of the domain. */
    id: string;
    /** ID of the TLS certificate issued for the domain. */
    certId: string;
    /** Whether the configured hostname is routable for the domain. If disabled, then requests to the configured hostname will not be routed to the configured Worker. If disabled, then preview routing must be enabled, and only subdomains of the configured hostname will be routable. */
    enabled: boolean;
    /** Worker environment associated with the domain. */
    environment: string;
    /** Hostname of the domain. Can be either the zone apex or a subdomain of the zone. Requests to this hostname will be routed to the configured Worker. */
    hostname: string;
    /** Whether Worker Previews are served on this custom domain. */
    previewsEnabled?: boolean | null;
    /** Name of the Worker associated with the domain. Requests to the configured hostname will be routed to this Worker. */
    service: string;
    /** ID of the zone containing the domain hostname. */
    zoneId: string;
    /** Name of the zone containing the domain hostname. */
    zoneName: string;
}
export type DomainsListResultList = Array<DomainsListResultItem>;
export interface ListDomainsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DomainsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ObservabilityDestinationsListRequestOrder = "asc" | "desc";
export type ObservabilityDestinationsListRequestOrderBy = "created" | "updated";
export interface ListObservabilityDestinationsRequest {
    accountId: string;
    order?: ObservabilityDestinationsListRequestOrder | (string & {});
    orderBy?: ObservabilityDestinationsListRequestOrderBy | (string & {});
    page?: number;
    perPage?: number;
}
export type ObservabilityDestinationsListResultItemConfigurationHeadersMap = {
    [key: string]: string | undefined;
};
export type ObservabilityDestinationsListResultItemConfigurationJobStatus = ObservabilityDestinationsCreateResponseConfigurationJobStatus;
export type ObservabilityDestinationsListResultItemConfigurationLogpushDataset = "opentelemetry-traces" | "opentelemetry-logs" | "opentelemetry-metrics";
export type ObservabilityDestinationsListResultItemConfigurationType = "logpush";
export interface ObservabilityDestinationsListResultItemConfiguration {
    headers: ObservabilityDestinationsListResultItemConfigurationHeadersMap;
    jobStatus: ObservabilityDestinationsCreateResponseConfigurationJobStatus;
    logpushDataset: ObservabilityDestinationsListResultItemConfigurationLogpushDataset;
    type: ObservabilityDestinationsListResultItemConfigurationType;
    url: string;
    /** The underlying Logpush destination string: the URL with the configured headers encoded as query parameters, so it can carry credentials. Optional: the 2026-10-21 spec omits it. */
    destinationConf?: string | null;
}
export type ObservabilityDestinationsListResultItemScriptsList = Array<string>;
export interface ObservabilityDestinationsListResultItem {
    configuration: ObservabilityDestinationsListResultItemConfiguration;
    enabled: boolean;
    name: string;
    scripts: ObservabilityDestinationsListResultItemScriptsList;
    slug: string;
}
export type ObservabilityDestinationsListResultList = Array<ObservabilityDestinationsListResultItem>;
export interface ListObservabilityDestinationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ObservabilityDestinationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListObservabilityIssueAutomationsRequest {
    accountId: string;
    /** Only automations scoped to this Worker. */
    service?: string;
}
export type ObservabilityIssueAutomationList = Array<ObservabilityIssueAutomation>;
export interface ListObservabilityIssueAutomationsResponse {
    automations: ObservabilityIssueAutomationList;
}
export type ObservabilityQueriesListRequestOrder = "asc" | "desc";
export type ObservabilityQueriesListRequestOrderBy = "created" | "updated";
export interface ListObservabilityQueriesRequest {
    accountId: string;
    order?: ObservabilityQueriesListRequestOrder | (string & {});
    orderBy?: ObservabilityQueriesListRequestOrderBy | (string & {});
    page?: number;
    perPage?: number;
}
export type ObservabilityQueriesListResultItemParametersCalculationsItemCase0Operator = "count" | "COUNT";
export type ObservabilityQueriesListResultItemParametersCalculationsItemCase0KeyType = "string" | "number" | "boolean";
export interface ObservabilityQueriesListResultItemParametersCalculationsItemCase0 {
    operator: ObservabilityQueriesListResultItemParametersCalculationsItemCase0Operator;
    alias?: string | null;
    key?: string | null;
    keyType?: ObservabilityQueriesListResultItemParametersCalculationsItemCase0KeyType | null;
}
export type ObservabilityQueriesListResultItemParametersCalculationsItemCase1Operator = "uniq" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export type ObservabilityQueriesListResultItemParametersCalculationsItemCase1KeyType = "string" | "number" | "boolean";
export interface ObservabilityQueriesListResultItemParametersCalculationsItemCase1 {
    key: string;
    operator: ObservabilityQueriesListResultItemParametersCalculationsItemCase1Operator;
    alias?: string | null;
    keyType?: ObservabilityQueriesListResultItemParametersCalculationsItemCase1KeyType | null;
}
export type ObservabilityQueriesListResultItemParametersCalculationsItem = ObservabilityQueriesListResultItemParametersCalculationsItemCase0 | ObservabilityQueriesListResultItemParametersCalculationsItemCase1;
export type ObservabilityQueriesListResultItemParametersCalculationsList = Array<ObservabilityQueriesListResultItemParametersCalculationsItem>;
export type ObservabilityQueriesListResultItemParametersDatasetsList = Array<string>;
export type ObservabilityQueriesListResultItemParametersFilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityQueriesListResultItemParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityQueriesListResultItemParametersFiltersItemCase0FiltersList = Array<unknown>;
export type ObservabilityQueriesListResultItemParametersFiltersItemCase0Kind = "group";
export interface ObservabilityQueriesListResultItemParametersFiltersItemCase0 {
    filterCombination: ObservabilityQueriesListResultItemParametersFiltersItemCase0FilterCombination;
    filters: ObservabilityQueriesListResultItemParametersFiltersItemCase0FiltersList;
    kind: ObservabilityQueriesListResultItemParametersFiltersItemCase0Kind;
}
export type ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafOperation;
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafType;
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafKind | null;
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafValue | null;
}
export type ObservabilityQueriesListResultItemParametersFiltersItem = ObservabilityQueriesListResultItemParametersFiltersItemCase0 | ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilityQueriesListResultItemParametersFiltersList = Array<ObservabilityQueriesListResultItemParametersFiltersItem>;
export type ObservabilityQueriesListResultItemParametersGroupBysItemType = "string" | "number" | "boolean";
export interface ObservabilityQueriesListResultItemParametersGroupBysItem {
    type: ObservabilityQueriesListResultItemParametersGroupBysItemType;
    value: string;
}
export type ObservabilityQueriesListResultItemParametersGroupBysList = Array<ObservabilityQueriesListResultItemParametersGroupBysItem>;
export type ObservabilityQueriesListResultItemParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export interface ObservabilityQueriesListResultItemParametersHavingsItem {
    key: string;
    operation: ObservabilityQueriesListResultItemParametersHavingsItemOperation;
    value: number;
}
export type ObservabilityQueriesListResultItemParametersHavingsList = Array<ObservabilityQueriesListResultItemParametersHavingsItem>;
export type ObservabilityQueriesListResultItemParametersNeedleValue = string | number | boolean;
export interface ObservabilityQueriesListResultItemParametersNeedle {
    value: ObservabilityQueriesListResultItemParametersNeedleValue;
    isRegex?: boolean | null;
    matchCase?: boolean | null;
}
export type ObservabilityQueriesListResultItemParametersOrderByOrder = "asc" | "desc";
export interface ObservabilityQueriesListResultItemParametersOrderBy {
    /** Configure which Calculation to order the results by. */
    value: string;
    /** Set the order of the results */
    order?: ObservabilityQueriesListResultItemParametersOrderByOrder | null;
}
export interface ObservabilityQueriesListResultItemParameters {
    /** Create Calculations to compute as part of the query. */
    calculations?: ObservabilityQueriesListResultItemParametersCalculationsList | null;
    /** Set the Datasets to query. Leave it empty to query all the datasets. */
    datasets?: ObservabilityQueriesListResultItemParametersDatasetsList | null;
    /** Set a Flag to describe how to combine the filters on the query. */
    filterCombination?: ObservabilityQueriesListResultItemParametersFilterCombination | null;
    /** Configure the Filters to apply to the query. Supports nested groups via kind: 'group'. */
    filters?: ObservabilityQueriesListResultItemParametersFiltersList | null;
    /** Define how to group the results of the query. */
    groupBys?: ObservabilityQueriesListResultItemParametersGroupBysList | null;
    /** Configure the Having clauses that filter on calculations in the query result. */
    havings?: ObservabilityQueriesListResultItemParametersHavingsList | null;
    /** Set a limit on the number of results / records returned by the query */
    limit?: number | null;
    /** Define an expression to search using full-text search. */
    needle?: ObservabilityQueriesListResultItemParametersNeedle | null;
    /** Configure the order of the results returned by the query. */
    orderBy?: ObservabilityQueriesListResultItemParametersOrderBy | null;
}
export interface ObservabilityQueriesListResultItem {
    id: string;
    /** If the query wasn't explcitly saved */
    adhoc: boolean;
    created: string;
    createdBy: string;
    description: string;
    /** Query name */
    name: string;
    parameters: ObservabilityQueriesListResultItemParameters;
    updated: string;
    updatedBy: string;
}
export type ObservabilityQueriesListResultList = Array<ObservabilityQueriesListResultItem>;
export interface ListObservabilityQueriesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ObservabilityQueriesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListRoutesRequest {
    /** Identifier. */
    zoneId: string;
}
export interface RoutesListResultItem {
    /** Identifier. */
    id: string;
    /** Pattern to match incoming requests against. [Learn more](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior). */
    pattern: string;
    /** Name of the script to run if the route matches. */
    script?: string | null;
}
export type RoutesListResultList = Array<RoutesListResultItem>;
export interface ListRoutesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RoutesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListScriptDeploymentsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** Current page. */
    page?: number;
    /** Items per page. */
    perPage?: number;
    /** Start of the deployment creation time range, inclusive. */
    since?: string;
    /** End of the deployment creation time range, inclusive. */
    until?: string;
}
export type ScriptsDeploymentsListResponseDeploymentsItemStrategy = "percentage";
export type ScriptsDeploymentsListResponseDeploymentsItemVersionsItem = ScriptsDeploymentsCreateRequestVersionsItem;
export type ScriptsDeploymentsListResponseDeploymentsItemVersionsList = Array<ScriptsDeploymentsCreateRequestVersionsItem>;
export type ScriptsDeploymentsListResponseDeploymentsItemAnnotations = ScriptsDeploymentsCreateResponseAnnotations;
export interface ScriptsDeploymentsListResponseDeploymentsItem {
    id: string;
    createdOn: string;
    source: string;
    strategy: ScriptsDeploymentsListResponseDeploymentsItemStrategy;
    /** Worker versions included in this deployment. Each object must contain a `version_id` UUID and a `percentage`; percentages across all objects must total 100. In the `cf` CLI, pass the entire array as one JSON value to `--versions`, either inline, for example `--versions '[{"version_id":"023e105f-2a42-4f8b-a1c1-73f6a2a30c0f","percentage":100}]'`, or from a JSON file with `--versions @versions.json`. */
    versions: ScriptsDeploymentsListResponseDeploymentsItemVersionsList;
    annotations?: ScriptsDeploymentsCreateResponseAnnotations | null;
    authorEmail?: string | null;
}
export type ScriptsDeploymentsListResponseDeploymentsList = Array<ScriptsDeploymentsListResponseDeploymentsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListScriptDeploymentsResponse {
    deployments: ScriptsDeploymentsListResponseDeploymentsList;
}
export interface ListScriptsRequest {
    /** Identifier. */
    accountId: string;
    /** Filter scripts by tags. Format: comma-separated list of tag:allowed pairs where allowed is 'yes' or 'no'. */
    tags?: string;
}
export type ScriptsListResultItemCacheOptions = BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions;
export type ScriptsListResultItemCompatibilityFlagsList = Array<string>;
export type ScriptsListResultItemExportsValueWorkerType = "worker";
export type ScriptsListResultItemExportsValueWorkerCache = BetaWorkersVersionsCreateRequestExportsValueWorkerCache;
export type ScriptsListResultItemExportsValueWorkerState = "created";
export interface ScriptsListResultItemExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: ScriptsListResultItemExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: BetaWorkersVersionsCreateRequestExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsListResultItemExportsValueWorkerState | null;
}
export type ScriptsListResultItemExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type ScriptsListResultItemExportsValueWorkersDurableObjectExportType = "durable-object";
export type ScriptsListResultItemExportsValueWorkersDurableObjectExportState = "created";
export interface ScriptsListResultItemExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsListResultItemExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsListResultItemExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsListResultItemExportsValueWorkersDurableObjectExportState | null;
}
export type ScriptsListResultItemExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type ScriptsListResultItemExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface ScriptsListResultItemExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: ScriptsListResultItemExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsListResultItemExportsValueWorkersDurableObjectDeletedExportType;
}
export type ScriptsListResultItemExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type ScriptsListResultItemExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface ScriptsListResultItemExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: ScriptsListResultItemExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsListResultItemExportsValueWorkersDurableObjectRenamedExportType;
}
export type ScriptsListResultItemExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type ScriptsListResultItemExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface ScriptsListResultItemExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: ScriptsListResultItemExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsListResultItemExportsValueWorkersDurableObjectTransferredExportType;
}
export type ScriptsListResultItemExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type ScriptsListResultItemExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type ScriptsListResultItemExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface ScriptsListResultItemExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: ScriptsListResultItemExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsListResultItemExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsListResultItemExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type ScriptsListResultItemExportsValue = ScriptsListResultItemExportsValueWorker | ScriptsListResultItemExportsValueWorkersDurableObjectExport | ScriptsListResultItemExportsValueWorkersDurableObjectDeletedExport | ScriptsListResultItemExportsValueWorkersDurableObjectRenamedExport | ScriptsListResultItemExportsValueWorkersDurableObjectTransferredExport | ScriptsListResultItemExportsValueWorkersDurableObjectExpectingTransferExport;
export type ScriptsListResultItemExportsMap = {
    [key: string]: ScriptsListResultItemExportsValue | undefined;
};
export type ScriptsListResultItemHandlersList = Array<string>;
export type ScriptsListResultItemNamedHandlersItemHandlersList = Array<string>;
export interface ScriptsListResultItemNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: ScriptsListResultItemNamedHandlersItemHandlersList | null;
    /** The name of the export. */
    name?: string | null;
}
export type ScriptsListResultItemNamedHandlersList = Array<ScriptsListResultItemNamedHandlersItem>;
export type ScriptsListResultItemObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type ScriptsListResultItemObservabilityLogsDestinationsList = Array<string>;
export interface ScriptsListResultItemObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsListResultItemObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type ScriptsListResultItemObservabilityTracesDestinationsList = Array<string>;
export type ScriptsListResultItemObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface ScriptsListResultItemObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsListResultItemObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: ScriptsListResultItemObservabilityTracesPropagationPolicy | null;
}
export interface ScriptsListResultItemObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: ScriptsListResultItemObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsListResultItemObservabilityTraces | null;
}
export type ScriptsListResultItemPlacementCase0Mode = "smart";
export type ScriptsListResultItemPlacementCase0Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsListResultItemPlacementCase0 {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: ScriptsListResultItemPlacementCase0Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase0Status | null;
}
export type ScriptsListResultItemPlacementCase1Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsListResultItemPlacementCase1 {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase1Status | null;
}
export type ScriptsListResultItemPlacementCase2Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsListResultItemPlacementCase2 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase2Status | null;
}
export type ScriptsListResultItemPlacementCase3Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsListResultItemPlacementCase3 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase3Status | null;
}
export type ScriptsListResultItemPlacementCase4Mode = "targeted";
export type ScriptsListResultItemPlacementCase4Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsListResultItemPlacementCase4 {
    /** Targeted placement mode. */
    mode: ScriptsListResultItemPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase4Status | null;
}
export type ScriptsListResultItemPlacementCase5Mode = "targeted";
export type ScriptsListResultItemPlacementCase5Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsListResultItemPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: ScriptsListResultItemPlacementCase5Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase5Status | null;
}
export type ScriptsListResultItemPlacementCase6Mode = "targeted";
export type ScriptsListResultItemPlacementCase6Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsListResultItemPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: ScriptsListResultItemPlacementCase6Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase6Status | null;
}
export type ScriptsListResultItemPlacementCase7Mode = "targeted";
export type ScriptsListResultItemPlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type ScriptsListResultItemPlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type ScriptsListResultItemPlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type ScriptsListResultItemPlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type ScriptsListResultItemPlacementCase7TargetList = Array<ScriptsListResultItemPlacementCase7TargetItem>;
export type ScriptsListResultItemPlacementCase7Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsListResultItemPlacementCase7 {
    /** Targeted placement mode. */
    mode: ScriptsListResultItemPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: ScriptsListResultItemPlacementCase7TargetList;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase7Status | null;
}
export type ScriptsListResultItemPlacement = ScriptsListResultItemPlacementCase0 | ScriptsListResultItemPlacementCase1 | ScriptsListResultItemPlacementCase2 | ScriptsListResultItemPlacementCase3 | ScriptsListResultItemPlacementCase4 | ScriptsListResultItemPlacementCase5 | ScriptsListResultItemPlacementCase6 | ScriptsListResultItemPlacementCase7;
export type ScriptsListResultItemPlacementMode = "smart" | "targeted";
export type ScriptsListResultItemPlacementStatus = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export type ScriptsListResultItemRoutesItem = RoutesListResultItem;
export type ScriptsListResultItemRoutesList = Array<RoutesListResultItem>;
export type ScriptsListResultItemTagsList = Array<string>;
export type ScriptsListResultItemTailConsumersItem = ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem;
export type ScriptsListResultItemTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export type ScriptsListResultItemUsageModel = "standard" | "bundled" | "unbound";
export interface ScriptsListResultItem {
    /** The name used to identify the script. */
    id?: string | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: ScriptsListResultItemCompatibilityFlagsList | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Hashed script content, can be used in a If-None-Match header when updating. */
    etag?: string | null;
    /** Declarative exports for the Worker's most recent version, including Durable Object classes (with their `storage` backend) and named Worker entrypoints. Tombstoned lifecycle entries are omitted, so only live exports (`created` and `expecting-transfer`) are returned. */
    exports?: ScriptsListResultItemExportsMap | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: ScriptsListResultItemHandlersList | null;
    /** Whether a Worker contains assets. */
    hasAssets?: boolean | null;
    /** Whether a Worker contains modules. */
    hasModules?: boolean | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: ScriptsListResultItemNamedHandlersList | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsListResultItemObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: ScriptsListResultItemPlacement | null;
    placementMode?: ScriptsListResultItemPlacementMode | null;
    placementStatus?: ScriptsListResultItemPlacementStatus | null;
    /** Routes associated with the Worker. */
    routes?: ScriptsListResultItemRoutesList | null;
    /** The immutable ID of the script. */
    tag?: string | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsListResultItemTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsListResultItemTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsListResultItemUsageModel | null;
}
export type ScriptsListResultList = Array<ScriptsListResultItem>;
export interface ListScriptsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ScriptsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListScriptSecretsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
}
export type ScriptsSecretsListResultItemSecretTextType = "secret_text";
export interface ScriptsSecretsListResultItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsListResultItemSecretTextType;
}
export type ScriptsSecretsListResultItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type ScriptsSecretsListResultItemSecretKeyType = "secret_key";
export type ScriptsSecretsListResultItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type ScriptsSecretsListResultItemSecretKeyUsagesList = Array<ScriptsSecretsListResultItemSecretKeyUsagesItem>;
export interface ScriptsSecretsListResultItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsSecretsListResultItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsListResultItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsSecretsListResultItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type ScriptsSecretsListResultItem = ScriptsSecretsListResultItemSecretText | ScriptsSecretsListResultItemSecretKey;
export type ScriptsSecretsListResultList = Array<ScriptsSecretsListResultItem>;
export interface ListScriptSecretsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ScriptsSecretsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListScriptVersionsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** Only return versions that can be used in a deployment. Ignores pagination. */
    deployable?: boolean;
    /** Current page. */
    page?: number;
    /** Items per-page. */
    perPage?: number;
}
export type ScriptsVersionsListResponseItemsItemMetadataSource = "unknown" | "api" | "wrangler" | "terraform" | "dash" | "cf_cli" | "dash_template" | "integration" | "quick_editor" | "playground" | "workersci";
export interface ScriptsVersionsListResponseItemsItemMetadata {
    /** Email of the user who created the version. */
    authorEmail?: string | null;
    /** Identifier of the user who created the version. */
    authorId?: string | null;
    /** When the version was created. */
    createdOn?: string | null;
    /** Whether the version can be previewed. */
    hasPreview?: boolean | null;
    /** When the version was last modified. */
    modifiedOn?: string | null;
    /** The source of the version upload. */
    source?: ScriptsVersionsListResponseItemsItemMetadataSource | null;
}
export interface ScriptsVersionsListResponseItemsItem {
    /** Unique identifier for the version. */
    id?: string | null;
    metadata?: ScriptsVersionsListResponseItemsItemMetadata | null;
    /** Sequential version number. */
    number?: number | null;
}
export type ScriptsVersionsListResponseItemsList = Array<ScriptsVersionsListResponseItemsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListScriptVersionsResponse {
    items?: ScriptsVersionsListResponseItemsList | null;
}
export interface LiveTailHeartbeatObservabilityTelemetryRequest {
    accountId: string;
    scriptId?: string;
}
export type LiveTailHeartbeatObservabilityTelemetryResponse = unknown;
export type ObservabilityTelemetryLiveTailRequestFilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0FiltersList = Array<unknown>;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0Kind = "group";
export interface ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0 {
    filterCombination: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0Kind;
}
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue;
}
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItem = ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0 | ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersList = Array<ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItem>;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0Kind = "group";
export interface ObservabilityTelemetryLiveTailRequestFiltersItemCase0 {
    filterCombination: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryLiveTailRequestFiltersItemCase0Kind;
}
export type ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafValue;
}
export type ObservabilityTelemetryLiveTailRequestFiltersItem = ObservabilityTelemetryLiveTailRequestFiltersItemCase0 | ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilityTelemetryLiveTailRequestFiltersList = Array<ObservabilityTelemetryLiveTailRequestFiltersItem>;
export interface LiveTailObservabilityTelemetryRequest {
    accountId: string;
    /** Set a flag to describe how to combine the filters on the query. */
    filterCombination?: ObservabilityTelemetryLiveTailRequestFilterCombination | (string & {});
    /** Apply filters to the query. Supports nested groups via kind: 'group'. */
    filters?: ObservabilityTelemetryLiveTailRequestFiltersList;
    scriptId?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface LiveTailObservabilityTelemetryResponse {
    /** WebSocket URL clients connect to in order to stream live tail events. */
    wsUrl: string;
}
export type BetaWorkersEditRequestObservabilityIssues = BetaWorkersCreateRequestObservabilityIssues;
export type BetaWorkersEditRequestObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersEditRequestObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersEditRequestObservabilityLogsDestinationsList;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean;
}
export type BetaWorkersEditRequestObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersEditRequestObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersEditRequestObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersEditRequestObservabilityTracesDestinationsList;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersEditRequestObservabilityTracesPropagationPolicy | (string & {});
}
export interface BetaWorkersEditRequestObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateRequestObservabilityIssues;
    /** Log settings for the Worker. */
    logs?: BetaWorkersEditRequestObservabilityLogs;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersEditRequestObservabilityTraces;
}
export type BetaWorkersEditRequestSubdomain = BetaWorkersCreateRequestSubdomain;
export type BetaWorkersEditRequestTagsList = Array<string>;
export type BetaWorkersEditRequestTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersEditRequestTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export type BetaWorkersEditRequestPreviewsBaseConfigCacheOptions = BetaWorkersCreateRequestPreviewsBaseConfigCacheOptions;
export type BetaWorkersEditRequestPreviewsBaseConfigEnvValue = BetaWorkersCreateRequestPreviewsBaseConfigEnvValue;
export type BetaWorkersEditRequestPreviewsBaseConfigEnvMap = {
    [key: string]: BetaWorkersCreateRequestPreviewsBaseConfigEnvValue | undefined;
};
export type BetaWorkersEditRequestPreviewsBaseConfigLimits = BetaWorkersCreateRequestPreviewsBaseConfigLimits;
export type BetaWorkersEditRequestPreviewsBaseConfigObservabilityIssues = BetaWorkersCreateRequestObservabilityIssues;
export type BetaWorkersEditRequestPreviewsBaseConfigObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersEditRequestPreviewsBaseConfigObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersEditRequestPreviewsBaseConfigObservabilityLogsDestinationsList;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean;
}
export type BetaWorkersEditRequestPreviewsBaseConfigObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersEditRequestPreviewsBaseConfigObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersEditRequestPreviewsBaseConfigObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersEditRequestPreviewsBaseConfigObservabilityTracesDestinationsList;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersEditRequestPreviewsBaseConfigObservabilityTracesPropagationPolicy | (string & {});
}
export interface BetaWorkersEditRequestPreviewsBaseConfigObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateRequestObservabilityIssues;
    /** Log settings for the Worker. */
    logs?: BetaWorkersEditRequestPreviewsBaseConfigObservabilityLogs;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersEditRequestPreviewsBaseConfigObservabilityTraces;
}
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementModeMode = "smart";
export interface BetaWorkersEditRequestPreviewsBaseConfigPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersEditRequestPreviewsBaseConfigPlacementModeMode;
}
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementCase4Mode = "targeted";
export interface BetaWorkersEditRequestPreviewsBaseConfigPlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersEditRequestPreviewsBaseConfigPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementCase5Mode = "targeted";
export interface BetaWorkersEditRequestPreviewsBaseConfigPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersEditRequestPreviewsBaseConfigPlacementCase5Mode;
}
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementCase6Mode = "targeted";
export interface BetaWorkersEditRequestPreviewsBaseConfigPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersEditRequestPreviewsBaseConfigPlacementCase6Mode;
}
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementCase7Mode = "targeted";
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersEditRequestPreviewsBaseConfigPlacementCase7TargetList = Array<BetaWorkersEditRequestPreviewsBaseConfigPlacementCase7TargetItem>;
export interface BetaWorkersEditRequestPreviewsBaseConfigPlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersEditRequestPreviewsBaseConfigPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersEditRequestPreviewsBaseConfigPlacementCase7TargetList;
}
export type BetaWorkersEditRequestPreviewsBaseConfigPlacement = BetaWorkersEditRequestPreviewsBaseConfigPlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | BetaWorkersEditRequestPreviewsBaseConfigPlacementCase4 | BetaWorkersEditRequestPreviewsBaseConfigPlacementCase5 | BetaWorkersEditRequestPreviewsBaseConfigPlacementCase6 | BetaWorkersEditRequestPreviewsBaseConfigPlacementCase7;
export type BetaWorkersEditRequestPreviewsBaseConfigTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersEditRequestPreviewsBaseConfigTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export interface BetaWorkersEditRequestPreviewsBaseConfig {
    /** Cache options used when creating new Previews. */
    cacheOptions?: BetaWorkersCreateRequestPreviewsBaseConfigCacheOptions;
    /** Bindings used when creating new Previews, keyed by binding name. */
    env?: BetaWorkersEditRequestPreviewsBaseConfigEnvMap;
    /** Resource limits enforced at runtime for newly created Previews. */
    limits?: BetaWorkersCreateRequestPreviewsBaseConfigLimits;
    /** Whether logpush is enabled when creating new Previews. */
    logpush?: boolean;
    /** Observability settings used when creating new Previews. */
    observability?: BetaWorkersEditRequestPreviewsBaseConfigObservability;
    /** Placement configuration used when creating new Previews. */
    placement?: BetaWorkersEditRequestPreviewsBaseConfigPlacement;
    /** Other Workers that should consume logs from newly created Previews. */
    tailConsumers?: BetaWorkersEditRequestPreviewsBaseConfigTailConsumersList;
}
export interface PatchBetaWorkerRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** Whether logpush is enabled for the Worker. */
    logpush: boolean;
    /** Name of the Worker. */
    name: string;
    /** Observability settings for the Worker. */
    observability: BetaWorkersEditRequestObservability;
    /** Subdomain settings for the Worker. */
    subdomain: BetaWorkersCreateRequestSubdomain;
    /** Tags associated with the Worker. */
    tags: BetaWorkersEditRequestTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers: BetaWorkersEditRequestTailConsumersList;
    /** Template configuration used when creating new Previews for this Worker. */
    previewsBaseConfig?: BetaWorkersEditRequestPreviewsBaseConfig;
}
export type BetaWorkersEditResponseObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type BetaWorkersEditResponseObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersEditResponseObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersEditResponseObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type BetaWorkersEditResponseObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersEditResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersEditResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersEditResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersEditResponseObservabilityTracesPropagationPolicy | null;
}
export interface BetaWorkersEditResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersEditResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersEditResponseObservabilityTraces | null;
}
export type BetaWorkersEditResponseReferencesDispatchNamespaceOutboundsItem = BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem;
export type BetaWorkersEditResponseReferencesDispatchNamespaceOutboundsList = Array<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export type BetaWorkersEditResponseReferencesDomainsItem = BetaWorkersCreateResponseReferencesDomainsItem;
export type BetaWorkersEditResponseReferencesDomainsList = Array<BetaWorkersCreateResponseReferencesDomainsItem>;
export type BetaWorkersEditResponseReferencesDurableObjectsItem = BetaWorkersCreateResponseReferencesDurableObjectsItem;
export type BetaWorkersEditResponseReferencesDurableObjectsList = Array<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export type BetaWorkersEditResponseReferencesQueuesItem = BetaWorkersCreateResponseReferencesQueuesItem;
export type BetaWorkersEditResponseReferencesQueuesList = Array<BetaWorkersCreateResponseReferencesQueuesItem>;
export type BetaWorkersEditResponseReferencesWorkersItem = BetaWorkersCreateResponseReferencesWorkersItem;
export type BetaWorkersEditResponseReferencesWorkersList = Array<BetaWorkersCreateResponseReferencesWorkersItem>;
export interface BetaWorkersEditResponseReferences {
    /** Other Workers that reference the Worker as an outbound for a dispatch namespace. */
    dispatchNamespaceOutbounds: BetaWorkersEditResponseReferencesDispatchNamespaceOutboundsList;
    /** Custom domains connected to the Worker. */
    domains: BetaWorkersEditResponseReferencesDomainsList;
    /** Other Workers that reference Durable Object classes implemented by the Worker. */
    durableObjects: BetaWorkersEditResponseReferencesDurableObjectsList;
    /** Queues that send messages to the Worker. */
    queues: BetaWorkersEditResponseReferencesQueuesList;
    /** Other Workers that reference the Worker using [service bindings](https://developers.cloudflare.com/workers/runtime-apis/bindings/service-bindings/). */
    workers: BetaWorkersEditResponseReferencesWorkersList;
}
export type BetaWorkersEditResponseSubdomain = BetaWorkersCreateResponseSubdomain;
export type BetaWorkersEditResponseTagsList = Array<string>;
export type BetaWorkersEditResponseTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersEditResponseTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export type BetaWorkersEditResponsePreviewsBaseConfigCacheOptions = BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions;
export type BetaWorkersEditResponsePreviewsBaseConfigEnvValue = BetaWorkersCreateRequestPreviewsBaseConfigEnvValue;
export type BetaWorkersEditResponsePreviewsBaseConfigEnvMap = {
    [key: string]: BetaWorkersCreateRequestPreviewsBaseConfigEnvValue | undefined;
};
export type BetaWorkersEditResponsePreviewsBaseConfigLimits = BetaWorkersCreateResponsePreviewsBaseConfigLimits;
export type BetaWorkersEditResponsePreviewsBaseConfigObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type BetaWorkersEditResponsePreviewsBaseConfigObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersEditResponsePreviewsBaseConfigObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersEditResponsePreviewsBaseConfigObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type BetaWorkersEditResponsePreviewsBaseConfigObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersEditResponsePreviewsBaseConfigObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersEditResponsePreviewsBaseConfigObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersEditResponsePreviewsBaseConfigObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersEditResponsePreviewsBaseConfigObservabilityTracesPropagationPolicy | null;
}
export interface BetaWorkersEditResponsePreviewsBaseConfigObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersEditResponsePreviewsBaseConfigObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersEditResponsePreviewsBaseConfigObservabilityTraces | null;
}
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementModeMode = "smart";
export interface BetaWorkersEditResponsePreviewsBaseConfigPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersEditResponsePreviewsBaseConfigPlacementModeMode;
}
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementCase4Mode = "targeted";
export interface BetaWorkersEditResponsePreviewsBaseConfigPlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersEditResponsePreviewsBaseConfigPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementCase5Mode = "targeted";
export interface BetaWorkersEditResponsePreviewsBaseConfigPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersEditResponsePreviewsBaseConfigPlacementCase5Mode;
}
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementCase6Mode = "targeted";
export interface BetaWorkersEditResponsePreviewsBaseConfigPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersEditResponsePreviewsBaseConfigPlacementCase6Mode;
}
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementCase7Mode = "targeted";
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersEditResponsePreviewsBaseConfigPlacementCase7TargetList = Array<BetaWorkersEditResponsePreviewsBaseConfigPlacementCase7TargetItem>;
export interface BetaWorkersEditResponsePreviewsBaseConfigPlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersEditResponsePreviewsBaseConfigPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersEditResponsePreviewsBaseConfigPlacementCase7TargetList;
}
export type BetaWorkersEditResponsePreviewsBaseConfigPlacement = BetaWorkersEditResponsePreviewsBaseConfigPlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | BetaWorkersEditResponsePreviewsBaseConfigPlacementCase4 | BetaWorkersEditResponsePreviewsBaseConfigPlacementCase5 | BetaWorkersEditResponsePreviewsBaseConfigPlacementCase6 | BetaWorkersEditResponsePreviewsBaseConfigPlacementCase7;
export type BetaWorkersEditResponsePreviewsBaseConfigTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersEditResponsePreviewsBaseConfigTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export interface BetaWorkersEditResponsePreviewsBaseConfig {
    /** Cache options used when creating new Previews. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Bindings used when creating new Previews, keyed by binding name. */
    env?: BetaWorkersEditResponsePreviewsBaseConfigEnvMap | null;
    /** Resource limits enforced at runtime for newly created Previews. */
    limits?: BetaWorkersCreateResponsePreviewsBaseConfigLimits | null;
    /** Whether logpush is enabled when creating new Previews. */
    logpush?: boolean | null;
    /** Observability settings used when creating new Previews. */
    observability?: BetaWorkersEditResponsePreviewsBaseConfigObservability | null;
    /** Placement configuration used when creating new Previews. */
    placement?: BetaWorkersEditResponsePreviewsBaseConfigPlacement | null;
    /** Other Workers that should consume logs from newly created Previews. */
    tailConsumers?: BetaWorkersEditResponsePreviewsBaseConfigTailConsumersList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchBetaWorkerResponse {
    /** Immutable ID of the Worker. */
    id: string;
    /** When the Worker was created. */
    createdOn: string;
    /** Whether logpush is enabled for the Worker. */
    logpush: boolean;
    /** Name of the Worker. */
    name: string;
    /** Observability settings for the Worker. */
    observability: BetaWorkersEditResponseObservability;
    /** Other resources that reference the Worker and depend on it existing. */
    references: BetaWorkersEditResponseReferences;
    /** Subdomain settings for the Worker. */
    subdomain: BetaWorkersCreateResponseSubdomain;
    /** Tags associated with the Worker. */
    tags: BetaWorkersEditResponseTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers: BetaWorkersEditResponseTailConsumersList;
    /** When the Worker was most recently updated. */
    updatedOn: string;
    /** When the Worker's most recent deployment was created. `null` if the Worker has never been deployed. */
    deployedOn?: string | null;
    /** Template configuration used when creating new Previews for this Worker. */
    previewsBaseConfig?: BetaWorkersEditResponsePreviewsBaseConfig | null;
}
export type ObservabilityDestinationsUpdateRequestConfigurationHeadersMap = {
    [key: string]: string | undefined;
};
export type ObservabilityDestinationsUpdateRequestConfigurationType = "logpush";
export interface ObservabilityDestinationsUpdateRequestConfiguration {
    headers: ObservabilityDestinationsUpdateRequestConfigurationHeadersMap;
    type: ObservabilityDestinationsUpdateRequestConfigurationType | (string & {});
    url: string;
    replaceHeaders?: boolean;
}
export interface PatchObservabilityDestinationRequest {
    accountId: string;
    slug: string;
    enabled: boolean;
    configuration?: ObservabilityDestinationsUpdateRequestConfiguration;
}
export type ObservabilityDestinationsUpdateResponseConfigurationHeadersMap = {
    [key: string]: string | undefined;
};
export type ObservabilityDestinationsUpdateResponseConfigurationJobStatus = ObservabilityDestinationsCreateResponseConfigurationJobStatus;
export type ObservabilityDestinationsUpdateResponseConfigurationLogpushDataset = "opentelemetry-traces" | "opentelemetry-logs" | "opentelemetry-metrics";
export type ObservabilityDestinationsUpdateResponseConfigurationType = "logpush";
export interface ObservabilityDestinationsUpdateResponseConfiguration {
    headers: ObservabilityDestinationsUpdateResponseConfigurationHeadersMap;
    jobStatus: ObservabilityDestinationsCreateResponseConfigurationJobStatus;
    logpushDataset: ObservabilityDestinationsUpdateResponseConfigurationLogpushDataset;
    type: ObservabilityDestinationsUpdateResponseConfigurationType;
    url: string;
    /** The underlying Logpush destination string: the URL with the configured headers encoded as query parameters, so it can carry credentials. Optional: the 2026-10-21 spec omits it. */
    destinationConf?: string | null;
}
export type ObservabilityDestinationsUpdateResponseScriptsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchObservabilityDestinationResponse {
    configuration: ObservabilityDestinationsUpdateResponseConfiguration;
    enabled: boolean;
    name: string;
    scripts: ObservabilityDestinationsUpdateResponseScriptsList;
    slug: string;
}
export interface PatchScriptScriptAndVersionSettingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** Worker settings to patch (bindings, tags, tail consumers, ...), JSON-encoded as the multipart `settings` part. */
    settings?: unknown;
}
export type ScriptsScriptAndVersionSettingsEditResponseAnnotations = ScriptsScriptAndVersionSettingsGetResponseAnnotations;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemAIType = "ai";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemAIType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchType = "ai_search";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchNamespaceType = "ai_search_namespace";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchNamespaceType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemMessagingType = "messaging";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemMessaging {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Messaging namespace to bind to. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemMessagingType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemAnalyticsEngineType = "analytics_engine";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemAnalyticsEngineType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemArtifactsType = "artifacts";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemArtifacts {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Artifacts namespace exposed to the Worker in the Worker's account. Must be 2-63 characters, start with an ASCII alphanumeric character, contain only ASCII alphanumeric characters, dots, underscores, and hyphens, and must not end with a hyphen. The namespace does not need to be created before binding it. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemArtifactsType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemAssetsType = "assets";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemAssetsType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemBrowserType = "browser";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemBrowserType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemD1Type = "d1";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemD1Type;
    /** This property has been renamed to `database_id`. */
    id?: string | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemDataBlobType = "data_blob";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemDataBlobType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceType = "dispatch_namespace";
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsItem = BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutboundWorker = BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker | null;
}
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutbound | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemHyperdriveType = "hyperdrive";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemHyperdriveType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemInheritType = "inherit";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from. This can be a version ID, or the literal "latest" to inherit from the most recently uploaded version, which may not be the deployed version. Defaults to "latest". Only the Workers API version endpoints under `/accounts/{account_id}/workers/workers/{worker_id}/versions` accept a version ID. Other endpoints, including script upload and script version upload, accept only "latest" and reject a version ID with error 10057. */
    versionId?: string | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemImagesType = "images";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemImagesType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemJsonType = "json";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemJsonType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemKVNamespaceType = "kv_namespace";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemKVNamespaceType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemMediaType = "media";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemMediaType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemMTLSCertificateType = "mtls_certificate";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemMTLSCertificateType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemPlainTextType = "plain_text";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemPlainTextType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemPipelinesType = "pipelines";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemPipelinesType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemK2Type = "k2";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemK2 {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** ID of a K2 stream owned by the account deploying the Worker. */
    stream: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemK2Type;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemQueueType = "queue";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemQueueType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimitSimple = BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimitType = "ratelimit";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimitType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2BucketType = "r2_bucket";
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high" | "us";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2BucketJurisdiction | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretTextType = "secret_text";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretTextType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailType = "send_email";
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemServiceType = "service";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemTextBlobType = "text_blob";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemTextBlobType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemVectorizeType = "vectorize";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemVectorizeType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemVersionMetadataType = "version_metadata";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemVersionMetadataType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretsStoreSecretType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemFlagshipType = "flagship";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemFlagshipType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyType = "secret_key";
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyUsagesList = Array<ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyUsagesItem>;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemWorkflowType = "workflow";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemWasmModuleType = "wasm_module";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemWasmModuleType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCServiceType = "vpc_service";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCServiceType;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetworkType = "vpc_network";
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetworkIdentity = "runtime-email-alpha";
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetworkType;
    /** Enables Gateway identity for the binding. Requires network_id to be "cf1:network" and cannot be combined with tunnel_id. */
    identity?: ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetworkIdentity | null;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItem = ScriptsScriptAndVersionSettingsEditResponseBindingsItemAI | ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearch | ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchNamespace | ScriptsScriptAndVersionSettingsEditResponseBindingsItemMessaging | ScriptsScriptAndVersionSettingsEditResponseBindingsItemAnalyticsEngine | ScriptsScriptAndVersionSettingsEditResponseBindingsItemArtifacts | ScriptsScriptAndVersionSettingsEditResponseBindingsItemAssets | ScriptsScriptAndVersionSettingsEditResponseBindingsItemBrowser | ScriptsScriptAndVersionSettingsEditResponseBindingsItemD1 | ScriptsScriptAndVersionSettingsEditResponseBindingsItemDataBlob | ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespace | ScriptsScriptAndVersionSettingsEditResponseBindingsItemDurableObjectNamespace | ScriptsScriptAndVersionSettingsEditResponseBindingsItemHyperdrive | ScriptsScriptAndVersionSettingsEditResponseBindingsItemInherit | ScriptsScriptAndVersionSettingsEditResponseBindingsItemImages | ScriptsScriptAndVersionSettingsEditResponseBindingsItemJson | ScriptsScriptAndVersionSettingsEditResponseBindingsItemKVNamespace | ScriptsScriptAndVersionSettingsEditResponseBindingsItemMedia | ScriptsScriptAndVersionSettingsEditResponseBindingsItemMTLSCertificate | ScriptsScriptAndVersionSettingsEditResponseBindingsItemPlainText | ScriptsScriptAndVersionSettingsEditResponseBindingsItemPipelines | ScriptsScriptAndVersionSettingsEditResponseBindingsItemK2 | ScriptsScriptAndVersionSettingsEditResponseBindingsItemQueue | ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimit | ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2Bucket | ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretText | ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmail | ScriptsScriptAndVersionSettingsEditResponseBindingsItemService | ScriptsScriptAndVersionSettingsEditResponseBindingsItemTextBlob | ScriptsScriptAndVersionSettingsEditResponseBindingsItemVectorize | ScriptsScriptAndVersionSettingsEditResponseBindingsItemVersionMetadata | ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretsStoreSecret | ScriptsScriptAndVersionSettingsEditResponseBindingsItemFlagship | ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKey | ScriptsScriptAndVersionSettingsEditResponseBindingsItemWorkflow | ScriptsScriptAndVersionSettingsEditResponseBindingsItemWasmModule | ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCService | ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetwork;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsList = Array<ScriptsScriptAndVersionSettingsEditResponseBindingsItem>;
export type ScriptsScriptAndVersionSettingsEditResponseCacheOptions = BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions;
export type ScriptsScriptAndVersionSettingsEditResponseCompatibilityFlagsList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkerType = "worker";
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkerCache = BetaWorkersVersionsCreateRequestExportsValueWorkerCache;
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkerState = "created";
export interface ScriptsScriptAndVersionSettingsEditResponseExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: BetaWorkersVersionsCreateRequestExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkerState | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExportType = "durable-object";
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExportState = "created";
export interface ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExportState | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectDeletedExportType;
}
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectRenamedExportType;
}
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectTransferredExportType;
}
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseExportsValue = ScriptsScriptAndVersionSettingsEditResponseExportsValueWorker | ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExport | ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectDeletedExport | ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectRenamedExport | ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectTransferredExport | ScriptsScriptAndVersionSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExport;
export type ScriptsScriptAndVersionSettingsEditResponseExportsMap = {
    [key: string]: ScriptsScriptAndVersionSettingsEditResponseExportsValue | undefined;
};
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationCreatedList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationDeletedList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationInfoItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationInfoItemReferencingScriptsList = Array<string>;
export interface ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationInfoItem {
    /** The class name the info entry is about. */
    class: string;
    /** Human-readable explanation. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationInfoItemScenario;
    /** The provisioned namespace the entry relates to, when applicable. */
    namespaceId?: string | null;
    /** Other Workers in the account that still bind to the affected class. Advisory: while non-empty the tombstone is not yet safe to remove -- redeploy these Workers with bindings re-pointed first. */
    referencingScripts?: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationInfoItemReferencingScriptsList | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationInfoList = Array<ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationInfoItem>;
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationRemovableEntriesList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationRenamedItem = BetaWorkersVersionsCreateResponseExportsReconciliationRenamedItem;
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationRenamedList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationRenamedItem>;
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationTransferPendingItem = BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingItem;
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationTransferPendingList = Array<BetaWorkersVersionsCreateResponseExportsReconciliationTransferPendingItem>;
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationTransferredItemPhase = "committed";
export interface ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationTransferredItem {
    /** The source class name that was transferred. */
    class: string;
    /** The transfer phase. Currently always `committed`. */
    phase: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationTransferredItemPhase;
    /** The destination script that now owns the namespace. */
    to: string;
}
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationTransferredList = Array<ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationTransferredItem>;
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationUpdatedList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationWarningsItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export interface ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationWarningsItem {
    /** The class name the warning is about. */
    class: string;
    /** Human-readable explanation of the warning. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationWarningsItemScenario;
    /** The provisioned namespace the warning relates to, when applicable. */
    namespaceId?: string | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationWarningsList = Array<ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationWarningsItem>;
export interface ScriptsScriptAndVersionSettingsEditResponseExportsReconciliation {
    /** Class names for which a new namespace was provisioned. */
    created: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationCreatedList;
    /** Class names whose namespace was deleted by a `deleted` tombstone. */
    deleted: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationDeletedList;
    /** Non-blocking info entries (stale tombstones, tombstone applied with class still in code). See `exports_reconciliation_info`. */
    info: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationInfoList;
    /** Source class names whose tombstone entry is now stale and safe to delete from `exports` (no remaining referencing scripts). */
    removableEntries: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationRemovableEntriesList;
    /** Applied `renamed` tombstones. */
    renamed: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationRenamedList;
    /** Phase-1 transfer hints recorded on the target side. */
    transferPending: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationTransferPendingList;
    /** Committed `transferred` tombstones (phase-2). */
    transferred: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationTransferredList;
    /** Class names whose provisioned namespace was mutated in place. */
    updated: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationUpdatedList;
    /** Non-blocking warnings. See `exports_reconciliation_warning`. */
    warnings: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliationWarningsList;
}
export type ScriptsScriptAndVersionSettingsEditResponseLimits = BetaWorkersCreateResponsePreviewsBaseConfigLimits;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationNewClassesList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesList | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsList = Array<ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export interface ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseMigrations = ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigration | ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrations;
export type ScriptsScriptAndVersionSettingsEditResponseObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type ScriptsScriptAndVersionSettingsEditResponseObservabilityLogsDestinationsList = Array<string>;
export interface ScriptsScriptAndVersionSettingsEditResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsScriptAndVersionSettingsEditResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type ScriptsScriptAndVersionSettingsEditResponseObservabilityTracesDestinationsList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface ScriptsScriptAndVersionSettingsEditResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsScriptAndVersionSettingsEditResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: ScriptsScriptAndVersionSettingsEditResponseObservabilityTracesPropagationPolicy | null;
}
export interface ScriptsScriptAndVersionSettingsEditResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: ScriptsScriptAndVersionSettingsEditResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsScriptAndVersionSettingsEditResponseObservabilityTraces | null;
}
export type ScriptsScriptAndVersionSettingsEditResponsePlacementModeMode = "smart";
export interface ScriptsScriptAndVersionSettingsEditResponsePlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: ScriptsScriptAndVersionSettingsEditResponsePlacementModeMode;
}
export type ScriptsScriptAndVersionSettingsEditResponsePlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase4Mode = "targeted";
export interface ScriptsScriptAndVersionSettingsEditResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsEditResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase5Mode = "targeted";
export interface ScriptsScriptAndVersionSettingsEditResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsEditResponsePlacementCase5Mode;
}
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase6Mode = "targeted";
export interface ScriptsScriptAndVersionSettingsEditResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsEditResponsePlacementCase6Mode;
}
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase7Mode = "targeted";
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetList = Array<ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItem>;
export interface ScriptsScriptAndVersionSettingsEditResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsEditResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetList;
}
export type ScriptsScriptAndVersionSettingsEditResponsePlacement = ScriptsScriptAndVersionSettingsEditResponsePlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | ScriptsScriptAndVersionSettingsEditResponsePlacementCase4 | ScriptsScriptAndVersionSettingsEditResponsePlacementCase5 | ScriptsScriptAndVersionSettingsEditResponsePlacementCase6 | ScriptsScriptAndVersionSettingsEditResponsePlacementCase7;
export type ScriptsScriptAndVersionSettingsEditResponseTagsList = Array<string>;
export type ScriptsScriptAndVersionSettingsEditResponseTailConsumersItem = ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem;
export type ScriptsScriptAndVersionSettingsEditResponseTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export type ScriptsScriptAndVersionSettingsEditResponseUsageModel = "standard" | "bundled" | "unbound";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchScriptScriptAndVersionSettingResponse {
    /** Annotations for the Worker version. Annotations are not inherited across settings updates; omitting this field means the new version will have no annotations. */
    annotations?: ScriptsScriptAndVersionSettingsGetResponseAnnotations | null;
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: ScriptsScriptAndVersionSettingsEditResponseBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: ScriptsScriptAndVersionSettingsEditResponseCompatibilityFlagsList | null;
    /** Declarative exports for the Worker. Worker entrypoint entries (`type: worker`) carry cache configuration for that entrypoint. */
    exports?: ScriptsScriptAndVersionSettingsEditResponseExportsMap | null;
    /** Summary of the declarative exports reconciliation that ran on this upload. Populated only when the uploaded metadata included an `exports` block. Durable Object entries drive reconciliation; `type: worker` entries do not contribute to this summary. */
    exportsReconciliation?: ScriptsScriptAndVersionSettingsEditResponseExportsReconciliation | null;
    /** Limits to apply for this Worker. */
    limits?: BetaWorkersCreateResponsePreviewsBaseConfigLimits | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** Migrations to apply for Durable Objects associated with this Worker. */
    migrations?: ScriptsScriptAndVersionSettingsEditResponseMigrations | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsScriptAndVersionSettingsEditResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: ScriptsScriptAndVersionSettingsEditResponsePlacement | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsScriptAndVersionSettingsEditResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsScriptAndVersionSettingsEditResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsScriptAndVersionSettingsEditResponseUsageModel | null;
}
export type ScriptsSettingsEditRequestObservabilityIssues = BetaWorkersCreateRequestObservabilityIssues;
export type ScriptsSettingsEditRequestObservabilityLogsDestinationsList = Array<string>;
export interface ScriptsSettingsEditRequestObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsSettingsEditRequestObservabilityLogsDestinationsList;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean;
}
export type ScriptsSettingsEditRequestObservabilityTracesDestinationsList = Array<string>;
export type ScriptsSettingsEditRequestObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface ScriptsSettingsEditRequestObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsSettingsEditRequestObservabilityTracesDestinationsList;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: ScriptsSettingsEditRequestObservabilityTracesPropagationPolicy | (string & {});
}
export interface ScriptsSettingsEditRequestObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateRequestObservabilityIssues;
    /** Log settings for the Worker. */
    logs?: ScriptsSettingsEditRequestObservabilityLogs;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean;
    /** Trace settings for the Worker. */
    traces?: ScriptsSettingsEditRequestObservabilityTraces;
}
export type ScriptsSettingsEditRequestTagsList = Array<string>;
export interface ScriptsSettingsEditRequestTailConsumersItem {
    /** Name of Worker that is to be the consumer. */
    service: string;
    /** Optional environment if the Worker utilizes one. */
    environment?: string;
    /** Optional dispatch namespace the script belongs to. */
    namespace?: string;
}
export type ScriptsSettingsEditRequestTailConsumersList = Array<ScriptsSettingsEditRequestTailConsumersItem>;
export interface PatchScriptSettingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean;
    /** Observability settings for the Worker. */
    observability?: ScriptsSettingsEditRequestObservability;
    /** Tags associated with the Worker. */
    tags?: ScriptsSettingsEditRequestTagsList;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsSettingsEditRequestTailConsumersList;
}
export type ScriptsSettingsEditResponseObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type ScriptsSettingsEditResponseObservabilityLogsDestinationsList = Array<string>;
export interface ScriptsSettingsEditResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsSettingsEditResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type ScriptsSettingsEditResponseObservabilityTracesDestinationsList = Array<string>;
export type ScriptsSettingsEditResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface ScriptsSettingsEditResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsSettingsEditResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: ScriptsSettingsEditResponseObservabilityTracesPropagationPolicy | null;
}
export interface ScriptsSettingsEditResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: ScriptsSettingsEditResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsSettingsEditResponseObservabilityTraces | null;
}
export type ScriptsSettingsEditResponseTagsList = Array<string>;
export type ScriptsSettingsEditResponseTailConsumersItem = ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem;
export type ScriptsSettingsEditResponseTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchScriptSettingResponse {
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsSettingsEditResponseObservability | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsSettingsEditResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsSettingsEditResponseTailConsumersList | null;
}
export interface PutAccountSettingRequest {
    /** Identifier. */
    accountId: string;
    defaultUsageModel?: string;
    greenCompute?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutAccountSettingResponse {
    defaultUsageModel?: string | null;
    greenCompute?: boolean | null;
}
export interface PutDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Hostname of the domain. Can be either the zone apex or a subdomain of the zone. Requests to this hostname will be routed to the configured Worker. */
    hostname: string;
    /** Name of the Worker associated with the domain. Requests to the configured hostname will be routed to this Worker. */
    service: string;
    /** Whether the configured hostname is routable for the domain. If disabled, then requests to the configured hostname will not be routed to the configured Worker. If disabled, then preview routing must be enabled, and only subdomains of the configured hostname will be routable. */
    enabled?: boolean;
    /** Serve Worker Previews on this custom domain as `<preview-name>.<hostname>`. */
    previewsEnabled?: boolean;
    /** ID of the zone containing the domain hostname. */
    zoneId?: string;
    /** Name of the zone containing the domain hostname. */
    zoneName?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutDomainResponse {
    /** Immutable ID of the domain. */
    id: string;
    /** ID of the TLS certificate issued for the domain. */
    certId: string;
    /** Whether the configured hostname is routable for the domain. If disabled, then requests to the configured hostname will not be routed to the configured Worker. If disabled, then preview routing must be enabled, and only subdomains of the configured hostname will be routable. */
    enabled: boolean;
    /** Worker environment associated with the domain. */
    environment: string;
    /** Hostname of the domain. Can be either the zone apex or a subdomain of the zone. Requests to this hostname will be routed to the configured Worker. */
    hostname: string;
    /** Whether Worker Previews are served on this custom domain. */
    previewsEnabled?: boolean | null;
    /** Name of the Worker associated with the domain. Requests to the configured hostname will be routed to this Worker. */
    service: string;
    /** ID of the zone containing the domain hostname. */
    zoneId: string;
    /** Name of the zone containing the domain hostname. */
    zoneName: string;
}
export type ScriptsUpdateRequestBindingsInherit = "strict";
export interface PutScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** When set to "strict", the upload will fail with error 10057 if any `inherit` type bindings cannot be resolved against the latest uploaded version of the Worker, which may not be the deployed version. Without this, unresolvable inherit bindings are silently dropped. */
    bindingsInherit?: ScriptsUpdateRequestBindingsInherit | (string & {});
    metadata: PutScriptMetadata;
    /** Module / asset file parts, appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
}
export type ScriptsUpdateResponseCacheOptions = BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions;
export type ScriptsUpdateResponseCompatibilityFlagsList = Array<string>;
export type ScriptsUpdateResponseExportsValueWorkerType = "worker";
export type ScriptsUpdateResponseExportsValueWorkerCache = BetaWorkersVersionsCreateRequestExportsValueWorkerCache;
export type ScriptsUpdateResponseExportsValueWorkerState = "created";
export interface ScriptsUpdateResponseExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: ScriptsUpdateResponseExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: BetaWorkersVersionsCreateRequestExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsUpdateResponseExportsValueWorkerState | null;
}
export type ScriptsUpdateResponseExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type ScriptsUpdateResponseExportsValueWorkersDurableObjectExportType = "durable-object";
export type ScriptsUpdateResponseExportsValueWorkersDurableObjectExportState = "created";
export interface ScriptsUpdateResponseExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsUpdateResponseExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsUpdateResponseExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsUpdateResponseExportsValueWorkersDurableObjectExportState | null;
}
export type ScriptsUpdateResponseExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type ScriptsUpdateResponseExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface ScriptsUpdateResponseExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: ScriptsUpdateResponseExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsUpdateResponseExportsValueWorkersDurableObjectDeletedExportType;
}
export type ScriptsUpdateResponseExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type ScriptsUpdateResponseExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface ScriptsUpdateResponseExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: ScriptsUpdateResponseExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsUpdateResponseExportsValueWorkersDurableObjectRenamedExportType;
}
export type ScriptsUpdateResponseExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type ScriptsUpdateResponseExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface ScriptsUpdateResponseExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: ScriptsUpdateResponseExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsUpdateResponseExportsValueWorkersDurableObjectTransferredExportType;
}
export type ScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type ScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type ScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface ScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: ScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type ScriptsUpdateResponseExportsValue = ScriptsUpdateResponseExportsValueWorker | ScriptsUpdateResponseExportsValueWorkersDurableObjectExport | ScriptsUpdateResponseExportsValueWorkersDurableObjectDeletedExport | ScriptsUpdateResponseExportsValueWorkersDurableObjectRenamedExport | ScriptsUpdateResponseExportsValueWorkersDurableObjectTransferredExport | ScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExport;
export type ScriptsUpdateResponseExportsMap = {
    [key: string]: ScriptsUpdateResponseExportsValue | undefined;
};
export type ScriptsUpdateResponseHandlersList = Array<string>;
export type ScriptsUpdateResponseNamedHandlersItemHandlersList = Array<string>;
export interface ScriptsUpdateResponseNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: ScriptsUpdateResponseNamedHandlersItemHandlersList | null;
    /** The name of the export. */
    name?: string | null;
}
export type ScriptsUpdateResponseNamedHandlersList = Array<ScriptsUpdateResponseNamedHandlersItem>;
export type ScriptsUpdateResponseObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type ScriptsUpdateResponseObservabilityLogsDestinationsList = Array<string>;
export interface ScriptsUpdateResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsUpdateResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type ScriptsUpdateResponseObservabilityTracesDestinationsList = Array<string>;
export type ScriptsUpdateResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface ScriptsUpdateResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsUpdateResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: ScriptsUpdateResponseObservabilityTracesPropagationPolicy | null;
}
export interface ScriptsUpdateResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: ScriptsUpdateResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsUpdateResponseObservabilityTraces | null;
}
export type ScriptsUpdateResponsePlacementCase0Mode = "smart";
export type ScriptsUpdateResponsePlacementCase0Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsUpdateResponsePlacementCase0 {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: ScriptsUpdateResponsePlacementCase0Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase0Status | null;
}
export type ScriptsUpdateResponsePlacementCase1Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsUpdateResponsePlacementCase1 {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase1Status | null;
}
export type ScriptsUpdateResponsePlacementCase2Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsUpdateResponsePlacementCase2 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase2Status | null;
}
export type ScriptsUpdateResponsePlacementCase3Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsUpdateResponsePlacementCase3 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase3Status | null;
}
export type ScriptsUpdateResponsePlacementCase4Mode = "targeted";
export type ScriptsUpdateResponsePlacementCase4Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsUpdateResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: ScriptsUpdateResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase4Status | null;
}
export type ScriptsUpdateResponsePlacementCase5Mode = "targeted";
export type ScriptsUpdateResponsePlacementCase5Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsUpdateResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: ScriptsUpdateResponsePlacementCase5Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase5Status | null;
}
export type ScriptsUpdateResponsePlacementCase6Mode = "targeted";
export type ScriptsUpdateResponsePlacementCase6Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsUpdateResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: ScriptsUpdateResponsePlacementCase6Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase6Status | null;
}
export type ScriptsUpdateResponsePlacementCase7Mode = "targeted";
export type ScriptsUpdateResponsePlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type ScriptsUpdateResponsePlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type ScriptsUpdateResponsePlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type ScriptsUpdateResponsePlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type ScriptsUpdateResponsePlacementCase7TargetList = Array<ScriptsUpdateResponsePlacementCase7TargetItem>;
export type ScriptsUpdateResponsePlacementCase7Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsUpdateResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: ScriptsUpdateResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: ScriptsUpdateResponsePlacementCase7TargetList;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase7Status | null;
}
export interface ScriptsUpdateResponsePlacementCase8 {
    /** Targeted placement mode (no target echoed). */
    mode: ScriptsUpdateResponsePlacementCase7Mode;
}
export type ScriptsUpdateResponsePlacement = ScriptsUpdateResponsePlacementCase0 | ScriptsUpdateResponsePlacementCase1 | ScriptsUpdateResponsePlacementCase2 | ScriptsUpdateResponsePlacementCase3 | ScriptsUpdateResponsePlacementCase4 | ScriptsUpdateResponsePlacementCase5 | ScriptsUpdateResponsePlacementCase6 | ScriptsUpdateResponsePlacementCase7 | ScriptsUpdateResponsePlacementCase8;
export type ScriptsUpdateResponsePlacementMode = "smart" | "targeted";
export type ScriptsUpdateResponsePlacementStatus = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export type ScriptsUpdateResponseTagsList = Array<string>;
export type ScriptsUpdateResponseTailConsumersItem = ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem;
export type ScriptsUpdateResponseTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export type ScriptsUpdateResponseUsageModel = "standard" | "bundled" | "unbound";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutScriptResponse {
    startupTimeMs: number;
    /** The name used to identify the script. */
    id?: string | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: ScriptsUpdateResponseCompatibilityFlagsList | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** The entry point for the script. */
    entryPoint?: string | null;
    /** Hashed script content, can be used in a If-None-Match header when updating. */
    etag?: string | null;
    /** Declarative exports for the Worker's most recent version, including Durable Object classes (with their `storage` backend) and named Worker entrypoints. Tombstoned lifecycle entries are omitted, so only live exports (`created` and `expecting-transfer`) are returned. */
    exports?: ScriptsUpdateResponseExportsMap | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: ScriptsUpdateResponseHandlersList | null;
    /** Whether a Worker contains assets. */
    hasAssets?: boolean | null;
    /** Whether a Worker contains modules. */
    hasModules?: boolean | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: ScriptsUpdateResponseNamedHandlersList | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsUpdateResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: ScriptsUpdateResponsePlacement | null;
    placementMode?: ScriptsUpdateResponsePlacementMode | null;
    placementStatus?: ScriptsUpdateResponsePlacementStatus | null;
    /** The immutable ID of the script. */
    tag?: string | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsUpdateResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsUpdateResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsUpdateResponseUsageModel | null;
}
export interface ScriptsContentUpdateRequestMetadata {
    /** Name of the uploaded file that contains the Worker script (e.g. the file adding a listener to the `fetch` event). Indicates a `service worker syntax` Worker. */
    bodyPart?: string;
    /** Name of the uploaded file that contains the main module (e.g. the file exporting a `fetch` handler). Indicates a `module syntax` Worker. */
    mainModule?: string;
}
export type ScriptsContentUpdateRequestFilesList = Array<string>;
export interface PutScriptContentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** JSON-encoded metadata about the uploaded parts and Worker configuration. */
    metadata: ScriptsContentUpdateRequestMetadata;
    /** An array of modules (often JavaScript files) comprising a Worker script. At least one module must be present and referenced in the metadata as `main_module` or `body_part` by filename. Possible Content-Type(s) are: `application/javascript+module`, `text/javascript+module`, `application/javascript`, `text/javascript`, `text/x-python`, `text/x-python-requirement`, `application/wasm`, `text/plain`, `application/octet-stream`, `application/source-map`. */
    files?: ScriptsContentUpdateRequestFilesList;
    cfworkerbodypart?: string;
    cfworkermainmodulepart?: string;
}
export type ScriptsContentUpdateResponseCacheOptions = BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions;
export type ScriptsContentUpdateResponseCompatibilityFlagsList = Array<string>;
export type ScriptsContentUpdateResponseExportsValueWorkerType = "worker";
export type ScriptsContentUpdateResponseExportsValueWorkerCache = BetaWorkersVersionsCreateRequestExportsValueWorkerCache;
export type ScriptsContentUpdateResponseExportsValueWorkerState = "created";
export interface ScriptsContentUpdateResponseExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: ScriptsContentUpdateResponseExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: BetaWorkersVersionsCreateRequestExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsContentUpdateResponseExportsValueWorkerState | null;
}
export type ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExportType = "durable-object";
export type ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExportState = "created";
export interface ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExportState | null;
}
export type ScriptsContentUpdateResponseExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type ScriptsContentUpdateResponseExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface ScriptsContentUpdateResponseExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: ScriptsContentUpdateResponseExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsContentUpdateResponseExportsValueWorkersDurableObjectDeletedExportType;
}
export type ScriptsContentUpdateResponseExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type ScriptsContentUpdateResponseExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface ScriptsContentUpdateResponseExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: ScriptsContentUpdateResponseExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsContentUpdateResponseExportsValueWorkersDurableObjectRenamedExportType;
}
export type ScriptsContentUpdateResponseExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type ScriptsContentUpdateResponseExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface ScriptsContentUpdateResponseExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: ScriptsContentUpdateResponseExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsContentUpdateResponseExportsValueWorkersDurableObjectTransferredExportType;
}
export type ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type ScriptsContentUpdateResponseExportsValue = ScriptsContentUpdateResponseExportsValueWorker | ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExport | ScriptsContentUpdateResponseExportsValueWorkersDurableObjectDeletedExport | ScriptsContentUpdateResponseExportsValueWorkersDurableObjectRenamedExport | ScriptsContentUpdateResponseExportsValueWorkersDurableObjectTransferredExport | ScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExport;
export type ScriptsContentUpdateResponseExportsMap = {
    [key: string]: ScriptsContentUpdateResponseExportsValue | undefined;
};
export type ScriptsContentUpdateResponseHandlersList = Array<string>;
export type ScriptsContentUpdateResponseNamedHandlersItemHandlersList = Array<string>;
export interface ScriptsContentUpdateResponseNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: ScriptsContentUpdateResponseNamedHandlersItemHandlersList | null;
    /** The name of the export. */
    name?: string | null;
}
export type ScriptsContentUpdateResponseNamedHandlersList = Array<ScriptsContentUpdateResponseNamedHandlersItem>;
export type ScriptsContentUpdateResponseObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type ScriptsContentUpdateResponseObservabilityLogsDestinationsList = Array<string>;
export interface ScriptsContentUpdateResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsContentUpdateResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type ScriptsContentUpdateResponseObservabilityTracesDestinationsList = Array<string>;
export type ScriptsContentUpdateResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface ScriptsContentUpdateResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsContentUpdateResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: ScriptsContentUpdateResponseObservabilityTracesPropagationPolicy | null;
}
export interface ScriptsContentUpdateResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: ScriptsContentUpdateResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsContentUpdateResponseObservabilityTraces | null;
}
export type ScriptsContentUpdateResponsePlacementCase0Mode = "smart";
export type ScriptsContentUpdateResponsePlacementCase0Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsContentUpdateResponsePlacementCase0 {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: ScriptsContentUpdateResponsePlacementCase0Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase0Status | null;
}
export type ScriptsContentUpdateResponsePlacementCase1Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsContentUpdateResponsePlacementCase1 {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase1Status | null;
}
export type ScriptsContentUpdateResponsePlacementCase2Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsContentUpdateResponsePlacementCase2 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase2Status | null;
}
export type ScriptsContentUpdateResponsePlacementCase3Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsContentUpdateResponsePlacementCase3 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase3Status | null;
}
export type ScriptsContentUpdateResponsePlacementCase4Mode = "targeted";
export type ScriptsContentUpdateResponsePlacementCase4Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsContentUpdateResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: ScriptsContentUpdateResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase4Status | null;
}
export type ScriptsContentUpdateResponsePlacementCase5Mode = "targeted";
export type ScriptsContentUpdateResponsePlacementCase5Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsContentUpdateResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: ScriptsContentUpdateResponsePlacementCase5Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase5Status | null;
}
export type ScriptsContentUpdateResponsePlacementCase6Mode = "targeted";
export type ScriptsContentUpdateResponsePlacementCase6Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsContentUpdateResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: ScriptsContentUpdateResponsePlacementCase6Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase6Status | null;
}
export type ScriptsContentUpdateResponsePlacementCase7Mode = "targeted";
export type ScriptsContentUpdateResponsePlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type ScriptsContentUpdateResponsePlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type ScriptsContentUpdateResponsePlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type ScriptsContentUpdateResponsePlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type ScriptsContentUpdateResponsePlacementCase7TargetList = Array<ScriptsContentUpdateResponsePlacementCase7TargetItem>;
export type ScriptsContentUpdateResponsePlacementCase7Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface ScriptsContentUpdateResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: ScriptsContentUpdateResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: ScriptsContentUpdateResponsePlacementCase7TargetList;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase7Status | null;
}
export type ScriptsContentUpdateResponsePlacement = ScriptsContentUpdateResponsePlacementCase0 | ScriptsContentUpdateResponsePlacementCase1 | ScriptsContentUpdateResponsePlacementCase2 | ScriptsContentUpdateResponsePlacementCase3 | ScriptsContentUpdateResponsePlacementCase4 | ScriptsContentUpdateResponsePlacementCase5 | ScriptsContentUpdateResponsePlacementCase6 | ScriptsContentUpdateResponsePlacementCase7;
export type ScriptsContentUpdateResponsePlacementMode = "smart" | "targeted";
export type ScriptsContentUpdateResponsePlacementStatus = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export type ScriptsContentUpdateResponseTagsList = Array<string>;
export type ScriptsContentUpdateResponseTailConsumersItem = ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem;
export type ScriptsContentUpdateResponseTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export type ScriptsContentUpdateResponseUsageModel = "standard" | "bundled" | "unbound";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutScriptContentResponse {
    /** The name used to identify the script. */
    id?: string | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: ScriptsContentUpdateResponseCompatibilityFlagsList | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Hashed script content, can be used in a If-None-Match header when updating. */
    etag?: string | null;
    /** Declarative exports for the Worker's most recent version, including Durable Object classes (with their `storage` backend) and named Worker entrypoints. Tombstoned lifecycle entries are omitted, so only live exports (`created` and `expecting-transfer`) are returned. */
    exports?: ScriptsContentUpdateResponseExportsMap | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: ScriptsContentUpdateResponseHandlersList | null;
    /** Whether a Worker contains assets. */
    hasAssets?: boolean | null;
    /** Whether a Worker contains modules. */
    hasModules?: boolean | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: ScriptsContentUpdateResponseNamedHandlersList | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsContentUpdateResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: ScriptsContentUpdateResponsePlacement | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placementMode?: ScriptsContentUpdateResponsePlacementMode | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    placementStatus?: ScriptsContentUpdateResponsePlacementStatus | null;
    /** The immutable ID of the script. */
    tag?: string | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsContentUpdateResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsContentUpdateResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsContentUpdateResponseUsageModel | null;
}
export interface PutScriptEventTriggersRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    body: EventTriggerList;
}
export type PutScriptEventTriggersResponse = ScriptEventTriggers;
export interface ScriptsSchedulesUpdateRequestBodyItem {
    cron: string;
    createdOn?: string;
    modifiedOn?: string;
}
export type ScriptsSchedulesUpdateRequestBodyList = Array<ScriptsSchedulesUpdateRequestBodyItem>;
export interface PutScriptScheduleRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    body: ScriptsSchedulesUpdateRequestBodyList;
}
export type ScriptsSchedulesUpdateResponseSchedulesItem = ScriptsSchedulesGetResponseSchedulesItem;
export type ScriptsSchedulesUpdateResponseSchedulesList = Array<ScriptsSchedulesGetResponseSchedulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutScriptScheduleResponse {
    schedules: ScriptsSchedulesUpdateResponseSchedulesList;
}
export type ScriptsSecretsUpdateRequestType = "secret_text" | "secret_key";
export type ScriptsSecretsUpdateRequestFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type ScriptsSecretsUpdateRequestUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type ScriptsSecretsUpdateRequestUsagesList = Array<ScriptsSecretsUpdateRequestUsagesItem | (string & {})>;
export interface PutScriptSecretRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text?: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsUpdateRequestType | (string & {});
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm?: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format?: ScriptsSecretsUpdateRequestFormat | (string & {});
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages?: ScriptsSecretsUpdateRequestUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown;
}
export type ScriptsSecretsUpdateResultSecretTextType = "secret_text";
export interface ScriptsSecretsUpdateResultSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsUpdateResultSecretTextType;
}
export type ScriptsSecretsUpdateResultSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type ScriptsSecretsUpdateResultSecretKeyType = "secret_key";
export type ScriptsSecretsUpdateResultSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type ScriptsSecretsUpdateResultSecretKeyUsagesList = Array<ScriptsSecretsUpdateResultSecretKeyUsagesItem>;
export interface ScriptsSecretsUpdateResultSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsSecretsUpdateResultSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsUpdateResultSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsSecretsUpdateResultSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type ScriptsSecretsUpdateResult = ScriptsSecretsUpdateResultSecretText | ScriptsSecretsUpdateResultSecretKey;
export type PutScriptSecretResponse = ScriptsSecretsUpdateResult;
export interface PutSubdomainRequest {
    /** Identifier. */
    accountId: string;
    subdomain: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSubdomainResponse {
    subdomain: string;
}
export type ObservabilityTelemetryQueryRequestTimeframe = ObservabilitySharedQueriesCreateRequestTimeframe;
export type ObservabilityTelemetryQueryRequestChartType = "timeseries_and_aggregate" | "timeseries" | "aggregate" | "distribution";
export type ObservabilityTelemetryQueryRequestDistributionScale = "log" | "linear";
export type ObservabilityTelemetryQueryRequestParametersCalculationsItemCase0Operator = "count" | "COUNT";
export type ObservabilityTelemetryQueryRequestParametersCalculationsItemCase0KeyType = "string" | "number" | "boolean";
export interface ObservabilityTelemetryQueryRequestParametersCalculationsItemCase0 {
    /** Aggregation operator to apply. Examples: count, avg, sum, min, max, median, p90, p95, p99, uniq, stddev, variance. */
    operator: ObservabilityTelemetryQueryRequestParametersCalculationsItemCase0Operator | (string & {});
    /** Custom label for this calculation in the results. Useful for distinguishing multiple calculations. */
    alias?: string;
    /** Field name to calculate over. Must exist in the data. Verify with the keys endpoint. Required for every operator except `count`, which aggregates whole rows and may omit it. */
    key?: string;
    /** Data type of the key. Required when key is provided to ensure correct aggregation. */
    keyType?: ObservabilityTelemetryQueryRequestParametersCalculationsItemCase0KeyType | (string & {});
}
export type ObservabilityTelemetryQueryRequestParametersCalculationsItemCase1Operator = "uniq" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export type ObservabilityTelemetryQueryRequestParametersCalculationsItemCase1KeyType = "string" | "number" | "boolean";
export interface ObservabilityTelemetryQueryRequestParametersCalculationsItemCase1 {
    /** Field name to calculate over. Must exist in the data. Verify with the keys endpoint. Required for every operator except `count`, which aggregates whole rows and may omit it. */
    key: string;
    /** Aggregation operator to apply. Examples: count, avg, sum, min, max, median, p90, p95, p99, uniq, stddev, variance. */
    operator: ObservabilityTelemetryQueryRequestParametersCalculationsItemCase1Operator | (string & {});
    /** Custom label for this calculation in the results. Useful for distinguishing multiple calculations. */
    alias?: string;
    /** Data type of the key. Required when key is provided to ensure correct aggregation. */
    keyType?: ObservabilityTelemetryQueryRequestParametersCalculationsItemCase1KeyType | (string & {});
}
export type ObservabilityTelemetryQueryRequestParametersCalculationsItem = ObservabilityTelemetryQueryRequestParametersCalculationsItemCase0 | ObservabilityTelemetryQueryRequestParametersCalculationsItemCase1;
export type ObservabilityTelemetryQueryRequestParametersCalculationsList = Array<ObservabilityTelemetryQueryRequestParametersCalculationsItem>;
export type ObservabilityTelemetryQueryRequestParametersDatasetsList = Array<string>;
export type ObservabilityTelemetryQueryRequestParametersFilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0FiltersList = Array<unknown>;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0Kind = "group";
export interface ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0 {
    filterCombination: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0Kind;
}
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue;
}
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItem = ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0 | ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersList = Array<ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItem>;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0Kind = "group";
export interface ObservabilityTelemetryQueryRequestParametersFiltersItemCase0 {
    filterCombination: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0Kind;
}
export type ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafValue;
}
export type ObservabilityTelemetryQueryRequestParametersFiltersItem = ObservabilityTelemetryQueryRequestParametersFiltersItemCase0 | ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilityTelemetryQueryRequestParametersFiltersList = Array<ObservabilityTelemetryQueryRequestParametersFiltersItem>;
export type ObservabilityTelemetryQueryRequestParametersGroupBysItemType = "string" | "number" | "boolean";
export interface ObservabilityTelemetryQueryRequestParametersGroupBysItem {
    /** Data type of the group-by field. */
    type: ObservabilityTelemetryQueryRequestParametersGroupBysItemType | (string & {});
    /** Field name to group results by (e.g. $metadata.service, $metadata.statusCode). */
    value: string;
}
export type ObservabilityTelemetryQueryRequestParametersGroupBysList = Array<ObservabilityTelemetryQueryRequestParametersGroupBysItem>;
export type ObservabilityTelemetryQueryRequestParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export interface ObservabilityTelemetryQueryRequestParametersHavingsItem {
    /** Calculation alias or operator to filter on after aggregation. */
    key: string;
    /** Numeric comparison operator: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryQueryRequestParametersHavingsItemOperation | (string & {});
    /** Threshold value to compare the calculation result against. */
    value: number;
}
export type ObservabilityTelemetryQueryRequestParametersHavingsList = Array<ObservabilityTelemetryQueryRequestParametersHavingsItem>;
export type ObservabilityTelemetryQueryRequestParametersNeedleValue = string | number | boolean;
export interface ObservabilityTelemetryQueryRequestParametersNeedle {
    /** The text or pattern to search for. */
    value: ObservabilityTelemetryQueryRequestParametersNeedleValue;
    /** When true, treats the value as a regular expression (RE2 syntax). */
    isRegex?: boolean;
    /** When true, performs a case-sensitive search. Defaults to case-insensitive. */
    matchCase?: boolean;
}
export type ObservabilityTelemetryQueryRequestParametersOrderByOrder = "asc" | "desc";
export interface ObservabilityTelemetryQueryRequestParametersOrderBy {
    /** Alias of the calculation to order results by. Must match the alias (or operator) of a calculation in the query. */
    value: string;
    /** Sort direction: 'asc' for ascending, 'desc' for descending. */
    order?: ObservabilityTelemetryQueryRequestParametersOrderByOrder | (string & {});
}
export interface ObservabilityTelemetryQueryRequestParameters {
    /** Aggregation calculations to compute (e.g. count, avg, p99). Each calculation produces aggregate values and optional time-series data. */
    calculations?: ObservabilityTelemetryQueryRequestParametersCalculationsList;
    /** Datasets to query. Leave empty to query all available datasets. */
    datasets?: ObservabilityTelemetryQueryRequestParametersDatasetsList;
    /** Logical operator for combining top-level filters: 'and' (all must match) or 'or' (any must match). Defaults to 'and'. */
    filterCombination?: ObservabilityTelemetryQueryRequestParametersFilterCombination | (string & {});
    /** Filters to narrow query results. Use the keys and values endpoints to discover available fields before building filters. Supports nested groups via kind: 'group'. Maximum nesting depth is 4. */
    filters?: ObservabilityTelemetryQueryRequestParametersFiltersList;
    /** Fields to group calculation results by. Only applicable when the query view is 'calculations'. Produces per-group aggregate values. */
    groupBys?: ObservabilityTelemetryQueryRequestParametersGroupBysList;
    /** Post-aggregation filters applied to calculation results. Use to filter groups after aggregation (e.g. only groups where count &gt; 100). */
    havings?: ObservabilityTelemetryQueryRequestParametersHavingsList;
    /** Maximum number of group-by rows to return in calculation results. A value of 10 is a sensible default for most use cases. */
    limit?: number;
    /** Full-text search expression applied across all event fields. Matches events containing the specified text. */
    needle?: ObservabilityTelemetryQueryRequestParametersNeedle;
    /** Ordering for grouped calculation results. Only effective when a group-by is present. */
    orderBy?: ObservabilityTelemetryQueryRequestParametersOrderBy;
}
export type ObservabilityTelemetryQueryRequestView = "traces" | "events" | "calculations" | "invocations" | "requests" | "agents";
export interface QueryObservabilityTelemetryRequest {
    accountId: string;
    /** Identifier for the query. When parameters are omitted, this ID is used to load a previously saved query's parameters. When providing parameters inline, pass any identifier (e.g. an ad-hoc ID). */
    queryId: string;
    /** Timeframe for the query using Unix timestamps in milliseconds. 'from' must be earlier than 'to'. Narrower timeframes produce faster responses and more specific results. */
    timeframe: ObservabilitySharedQueriesCreateRequestTimeframe;
    /** When true, includes time-series data in the response. */
    chart?: boolean;
    /** Controls the SQL shape and response payload for the 'calculations' view. Omitted or 'timeseries_and_aggregate': current behaviour -- both the time-series and aggregate queries. 'timeseries': time-series only. 'aggregate': aggregate only. 'distribution': a bucketed 2D histogram (time × value buckets) returned in 'distribution' instead of 'calculations'. 'distribution' is not compatible with 'compare' -- combining them returns a 400. */
    chartType?: ObservabilityTelemetryQueryRequestChartType | (string & {});
    /** When true, includes a comparison dataset from the previous time period of equal length. */
    compare?: boolean;
    /** Value-axis bucketing for chartType 'distribution'. Omitted or 'log': geometric buckets, best for heavy-tailed latency. 'linear': fixed-width buckets, clearer for narrow or additive ranges. Ignored for other chartTypes. The response echoes the scheme used in distribution.bucketMode. */
    distributionScale?: ObservabilityTelemetryQueryRequestDistributionScale | (string & {});
    /** When true, executes the query without persisting the results. Useful for validation or previewing. */
    dry?: boolean;
    /** Number of time-series buckets. Only used when view is 'calculations'. Omit to let the system auto-detect an appropriate granularity. */
    granularity?: number;
    /** When true, omits time-series data from the response and returns only aggregated values. Reduces response size when series are not needed. */
    ignoreSeries?: boolean;
    /** Maximum number of events to return when view is 'events'. Also controls the number of group-by rows when view is 'calculations'. */
    limit?: number;
    /** Cursor for pagination in event, trace, invocation, and agent views. Pass the $metadata.id of the last event, the trace cursor, or AgentRun.id to fetch the next page. */
    offset?: string;
    /** Numeric offset for paginating grouped/pattern results (top-N lists). Use together with limit. Not used by cursor-based pagination. */
    offsetBy?: number;
    /** Pagination direction: 'next' for forward, 'prev' for backward. */
    offsetDirection?: string;
    /** Query parameters defining what data to retrieve -- filters, calculations, group-bys, and ordering. In practice this should always be provided for ad-hoc queries. Only omit when executing a previously saved query by queryId. Use the keys and values endpoints to discover available fields before building filters. */
    parameters?: ObservabilityTelemetryQueryRequestParameters;
    /** Controls the shape of the response. 'events': individual log lines matching the query. 'calculations': aggregated metrics (count, avg, p99, etc.) with optional group-by breakdowns and time-series. 'invocations': events grouped by request ID. 'traces': distributed trace summaries. 'agents': agent-specific trace summaries. */
    view?: ObservabilityTelemetryQueryRequestView | (string & {});
}
export type ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemCase0Operator = "count" | "COUNT";
export type ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemCase0KeyType = "string" | "number" | "boolean";
export interface ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemCase0 {
    operator: ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemCase0Operator;
    alias?: string | null;
    key?: string | null;
    keyType?: ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemCase0KeyType | null;
}
export type ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemCase1Operator = "uniq" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export type ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemCase1KeyType = "string" | "number" | "boolean";
export interface ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemCase1 {
    key: string;
    operator: ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemCase1Operator;
    alias?: string | null;
    keyType?: ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemCase1KeyType | null;
}
export type ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItem = ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemCase0 | ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemCase1;
export type ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsList = Array<ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItem>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersDatasetsList = Array<string>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0FiltersList = Array<unknown>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0Kind = "group";
export interface ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0 {
    filterCombination: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0FilterCombination;
    filters: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0Kind;
}
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafOperation;
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafType;
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafKind | null;
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafValue | null;
}
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItem = ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0 | ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersList = Array<ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItem>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysItemType = "string" | "number" | "boolean";
export interface ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysItem {
    type: ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysItemType;
    value: string;
}
export type ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysList = Array<ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysItem>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export interface ObservabilityTelemetryQueryResponseRunQueryParametersHavingsItem {
    key: string;
    operation: ObservabilityTelemetryQueryResponseRunQueryParametersHavingsItemOperation;
    value: number;
}
export type ObservabilityTelemetryQueryResponseRunQueryParametersHavingsList = Array<ObservabilityTelemetryQueryResponseRunQueryParametersHavingsItem>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersNeedle = ObservabilitySharedQueriesGetResponseRunQueryParametersNeedle;
export type ObservabilityTelemetryQueryResponseRunQueryParametersOrderByOrder = "asc" | "desc";
export interface ObservabilityTelemetryQueryResponseRunQueryParametersOrderBy {
    /** Configure which Calculation to order the results by. */
    value: string;
    /** Set the order of the results */
    order?: ObservabilityTelemetryQueryResponseRunQueryParametersOrderByOrder | null;
}
export interface ObservabilityTelemetryQueryResponseRunQueryParameters {
    /** Create Calculations to compute as part of the query. */
    calculations?: ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsList | null;
    /** Set the Datasets to query. Leave it empty to query all the datasets. */
    datasets?: ObservabilityTelemetryQueryResponseRunQueryParametersDatasetsList | null;
    /** Set a Flag to describe how to combine the filters on the query. */
    filterCombination?: ObservabilityTelemetryQueryResponseRunQueryParametersFilterCombination | null;
    /** Configure the Filters to apply to the query. Supports nested groups via kind: 'group'. */
    filters?: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersList | null;
    /** Define how to group the results of the query. */
    groupBys?: ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysList | null;
    /** Configure the Having clauses that filter on calculations in the query result. */
    havings?: ObservabilityTelemetryQueryResponseRunQueryParametersHavingsList | null;
    /** Set a limit on the number of results / records returned by the query */
    limit?: number | null;
    /** Define an expression to search using full-text search. */
    needle?: ObservabilitySharedQueriesGetResponseRunQueryParametersNeedle | null;
    /** Configure the order of the results returned by the query. */
    orderBy?: ObservabilityTelemetryQueryResponseRunQueryParametersOrderBy | null;
}
export interface ObservabilityTelemetryQueryResponseRunQuery {
    id: string;
    /** If the query wasn't explcitly saved */
    adhoc: boolean;
    created: string;
    createdBy: string;
    description: string;
    /** Query name */
    name: string;
    parameters: ObservabilityTelemetryQueryResponseRunQueryParameters;
    updated: string;
    updatedBy: string;
}
export type ObservabilityTelemetryQueryResponseRunStatus = "STARTED" | "COMPLETED";
export type ObservabilityTelemetryQueryResponseRunTimeframe = ObservabilitySharedQueriesCreateRequestTimeframe;
export type ObservabilityTelemetryQueryResponseRunStatistics = ObservabilitySharedQueriesGetResponseRunStatistics;
export interface ObservabilityTelemetryQueryResponseRun {
    /** Unique identifier for this query run. */
    id: string;
    /** Cloudflare account ID that owns this query run. */
    accountId: string;
    /** Whether this was a dry run (results not persisted). */
    dry: boolean;
    /** Number of time-series buckets used for the query. Higher values produce more detailed series data. */
    granularity: number;
    /** A saved query definition with its parameters, metadata, and ownership information. */
    query: ObservabilityTelemetryQueryResponseRunQuery;
    /** Current execution status of the query run. */
    status: ObservabilityTelemetryQueryResponseRunStatus;
    /** Time range for the query execution. 'from' must be earlier than 'to'. No fractional milliseconds. */
    timeframe: ObservabilitySharedQueriesCreateRequestTimeframe;
    /** ID of the user who initiated the query run. */
    userId: string;
    /** ISO-8601 timestamp when the query run was created. */
    created?: string | null;
    /** Query performance statistics from the database (does not include network latency). */
    statistics?: ObservabilitySharedQueriesGetResponseRunStatistics | null;
    /** ISO-8601 timestamp when the query run was last updated. */
    updated?: string | null;
}
export type ObservabilityTelemetryQueryResponseStatistics = ObservabilitySharedQueriesGetResponseRunStatistics;
export type ObservabilityTelemetryQueryResponseAgentsItemErrorsList = Array<string>;
export type ObservabilityTelemetryQueryResponseAgentsItemModelsList = Array<string>;
export type ObservabilityTelemetryQueryResponseAgentsItemProvidersList = Array<string>;
export type ObservabilityTelemetryQueryResponseAgentsItemServicesList = Array<string>;
export type ObservabilityTelemetryQueryResponseAgentsItemStatus = "completed" | "error";
export interface ObservabilityTelemetryQueryResponseAgentsItem {
    /** Stable pagination cursor for this agent run. */
    id: string;
    /** Distinct errors reported by spans in the run. */
    errors: ObservabilityTelemetryQueryResponseAgentsItemErrorsList;
    /** Distinct models reported by chat spans across the run's trace. */
    models: ObservabilityTelemetryQueryResponseAgentsItemModelsList;
    /** Distinct GenAI providers reported by chat spans in the run. */
    providers: ObservabilityTelemetryQueryResponseAgentsItemProvidersList;
    /** Worker services represented in the run's trace. */
    services: ObservabilityTelemetryQueryResponseAgentsItemServicesList;
    /** Number of spans in the run's trace. */
    spans: number;
    /** Observed run status. */
    status: ObservabilityTelemetryQueryResponseAgentsItemStatus;
    /** Total trace duration in milliseconds. */
    traceDurationMs: number;
    /** End of the run's trace as a Unix epoch in milliseconds. */
    traceEndMs: number;
    /** Trace identifier for this agent run. */
    traceId: string;
    /** Start of the run's trace as a Unix epoch in milliseconds. */
    traceStartMs: number;
    /** ID from the earliest agent invocation that provides one. */
    agentId?: string | null;
    /** Name from the earliest agent invocation that provides one. */
    agentName?: string | null;
    /** Conversation ID from the earliest invocation that provides one. */
    conversationId?: string | null;
    /** Input tokens summed across chat spans in the run's trace; informational, not billing data. */
    inputTokens?: number | null;
    /** Output tokens summed across chat spans in the run's trace; informational, not billing data. */
    outputTokens?: number | null;
}
export type ObservabilityTelemetryQueryResponseAgentsList = Array<ObservabilityTelemetryQueryResponseAgentsItem>;
export type ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsItemValue = string | number | boolean;
export interface ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsItem {
    key: string;
    value: ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsItemValue;
}
export type ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsList = Array<ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsItem>;
export interface ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItem {
    /** Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1. */
    count: number;
    /** Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead. */
    interval: number;
    /** Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker's head_sampling_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr_level. */
    sampleInterval: number;
    /** Result of the calculation. count, sum, avg, median, and percentiles are weighted by each event's sample interval */
    value: number;
    groups?: ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsList | null;
}
export type ObservabilityTelemetryQueryResponseCalculationsItemAggregatesList = Array<ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItem>;
export type ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsItemValue = string | number | boolean;
export interface ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsItem {
    key: string;
    value: ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsItemValue;
}
export type ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsList = Array<ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsItem>;
export interface ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItem {
    /** Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1. */
    count: number;
    /** Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead. */
    interval: number;
    /** Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker's head_sampling_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr_level. */
    sampleInterval: number;
    /** Result of the calculation. count, sum, avg, median, and percentiles are weighted by each event's sample interval */
    value: number;
    firstSeen?: string | null;
    groups?: ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsList | null;
    lastSeen?: string | null;
}
export type ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataList = Array<ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItem>;
export interface ObservabilityTelemetryQueryResponseCalculationsItemSeriesItem {
    data: ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataList;
    time: string;
}
export type ObservabilityTelemetryQueryResponseCalculationsItemSeriesList = Array<ObservabilityTelemetryQueryResponseCalculationsItemSeriesItem>;
export interface ObservabilityTelemetryQueryResponseCalculationsItem {
    aggregates: ObservabilityTelemetryQueryResponseCalculationsItemAggregatesList;
    calculation: string;
    series: ObservabilityTelemetryQueryResponseCalculationsItemSeriesList;
    alias?: string | null;
}
export type ObservabilityTelemetryQueryResponseCalculationsList = Array<ObservabilityTelemetryQueryResponseCalculationsItem>;
export type ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsItemValue = string | number | boolean;
export interface ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsItem {
    key: string;
    value: ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsItemValue;
}
export type ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsList = Array<ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsItem>;
export interface ObservabilityTelemetryQueryResponseCompareItemAggregatesItem {
    /** Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1. */
    count: number;
    /** Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead. */
    interval: number;
    /** Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker's head_sampling_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr_level. */
    sampleInterval: number;
    /** Result of the calculation. count, sum, avg, median, and percentiles are weighted by each event's sample interval */
    value: number;
    groups?: ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsList | null;
}
export type ObservabilityTelemetryQueryResponseCompareItemAggregatesList = Array<ObservabilityTelemetryQueryResponseCompareItemAggregatesItem>;
export type ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsItemValue = string | number | boolean;
export interface ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsItem {
    key: string;
    value: ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsItemValue;
}
export type ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsList = Array<ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsItem>;
export interface ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItem {
    /** Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1. */
    count: number;
    /** Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead. */
    interval: number;
    /** Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker's head_sampling_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr_level. */
    sampleInterval: number;
    /** Result of the calculation. count, sum, avg, median, and percentiles are weighted by each event's sample interval */
    value: number;
    firstSeen?: string | null;
    groups?: ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsList | null;
    lastSeen?: string | null;
}
export type ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataList = Array<ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItem>;
export interface ObservabilityTelemetryQueryResponseCompareItemSeriesItem {
    data: ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataList;
    time: string;
}
export type ObservabilityTelemetryQueryResponseCompareItemSeriesList = Array<ObservabilityTelemetryQueryResponseCompareItemSeriesItem>;
export interface ObservabilityTelemetryQueryResponseCompareItem {
    aggregates: ObservabilityTelemetryQueryResponseCompareItemAggregatesList;
    calculation: string;
    series: ObservabilityTelemetryQueryResponseCompareItemSeriesList;
    alias?: string | null;
}
export type ObservabilityTelemetryQueryResponseCompareList = Array<ObservabilityTelemetryQueryResponseCompareItem>;
export type ObservabilityTelemetryQueryResponseDistributionBinsList = Array<string>;
export type ObservabilityTelemetryQueryResponseDistributionBucketBoundariesList = Array<number>;
export type ObservabilityTelemetryQueryResponseDistributionBucketMode = "log" | "linear";
export type ObservabilityTelemetryQueryResponseDistributionBucketsList = Array<string>;
export type ObservabilityTelemetryQueryResponseDistributionMatrixItemList = Array<number>;
export type ObservabilityTelemetryQueryResponseDistributionMatrixList = Array<ObservabilityTelemetryQueryResponseDistributionMatrixItemList>;
export interface ObservabilityTelemetryQueryResponseDistribution {
    /** Time-bucket labels (ISO-8601 strings), one per matrix column. */
    bins: ObservabilityTelemetryQueryResponseDistributionBinsList;
    /** Raw bucket edges in the value's native unit, length buckets.length + 1. Used for the colour scale and percentile mapping. */
    bucketBoundaries: ObservabilityTelemetryQueryResponseDistributionBucketBoundariesList;
    /** Bucketing scheme used to derive the boundaries. 'log' produces geometric edges; 'linear' produces fixed-width edges. */
    bucketMode: ObservabilityTelemetryQueryResponseDistributionBucketMode;
    /** Value-range labels, one per matrix row (e.g. '50-100ms'). */
    buckets: ObservabilityTelemetryQueryResponseDistributionBucketsList;
    /** Sampling-corrected counts. matrix[bucketIdx][binIdx] is the estimated number of events in value-bucket 'bucketIdx' during time-bin 'binIdx'. */
    matrix: ObservabilityTelemetryQueryResponseDistributionMatrixList;
}
export type ObservabilityTelemetryQueryResponseEventsEventsItemMetadata = ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
export type ObservabilityTelemetryQueryResponseEventsEventsItemSourceCase1Map = {
    [key: string]: unknown | undefined;
};
export type ObservabilityTelemetryQueryResponseEventsEventsItemSource = string | ObservabilityTelemetryQueryResponseEventsEventsItemSourceCase1Map;
export type ObservabilityTelemetryQueryResponseEventsEventsItemContainersMap = {
    [key: string]: unknown | undefined;
};
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0EventMap = {
    [key: string]: unknown | undefined;
};
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0ExecutionModel = "durableObject" | "stateless";
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export interface ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0 {
    eventType: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0EventType;
    scriptName: string;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0EventMap | null;
    executionModel?: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0ExecutionModel | null;
    outcome?: string | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    requestId?: string | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsList = Array<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1EventMap = {
    [key: string]: unknown | undefined;
};
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1ExecutionModel = "durableObject" | "stateless";
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export interface ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1 {
    cpuTimeMs: number;
    eventType: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1EventType;
    outcome: string;
    scriptName: string;
    wallTimeMs: number;
    diagnosticsChannelEvents?: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsList | null;
    dispatchNamespace?: string | null;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1EventMap | null;
    executionModel?: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1ExecutionModel | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    requestId?: string | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkers = ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0 | ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1;
export interface ObservabilityTelemetryQueryResponseEventsEventsItem {
    /** Structured metadata extracted from the event. These fields are indexed and available for filtering and aggregation. */
    metadata: ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
    /** The dataset this event belongs to (e.g. cloudflare-workers). */
    dataset: string;
    /** Raw log payload. May be a string or a structured object depending on how the log was emitted. */
    source: ObservabilityTelemetryQueryResponseEventsEventsItemSource;
    /** Event timestamp as a Unix epoch in milliseconds. */
    timestamp: number;
    /** Cloudflare Containers event information that enriches your logs for identifying and debugging issues. */
    containers?: ObservabilityTelemetryQueryResponseEventsEventsItemContainersMap | null;
    /** Cloudflare Workers event information that enriches your logs for identifying and debugging issues. */
    workers?: ObservabilityTelemetryQueryResponseEventsEventsItemWorkers | null;
}
export type ObservabilityTelemetryQueryResponseEventsEventsList = Array<ObservabilityTelemetryQueryResponseEventsEventsItem>;
export type ObservabilityTelemetryQueryResponseEventsFieldsItem = ObservabilitySharedQueriesGetResponseEventsFieldsItem;
export type ObservabilityTelemetryQueryResponseEventsFieldsList = Array<ObservabilitySharedQueriesGetResponseEventsFieldsItem>;
export type ObservabilityTelemetryQueryResponseEventsSeriesItemDataItemAggregates = ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemAggregates;
export type ObservabilityTelemetryQueryResponseEventsSeriesItemDataItemGroupsValue = string | number | boolean;
export type ObservabilityTelemetryQueryResponseEventsSeriesItemDataItemGroupsMap = {
    [key: string]: ObservabilityTelemetryQueryResponseEventsSeriesItemDataItemGroupsValue | undefined;
};
export interface ObservabilityTelemetryQueryResponseEventsSeriesItemDataItem {
    aggregates: ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemAggregates;
    /** Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1. */
    count: number;
    /** Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead. */
    interval: number;
    /** Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker's head_sampling_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr_level. */
    sampleInterval: number;
    errors?: number | null;
    /** Groups in the query results. */
    groups?: ObservabilityTelemetryQueryResponseEventsSeriesItemDataItemGroupsMap | null;
}
export type ObservabilityTelemetryQueryResponseEventsSeriesItemDataList = Array<ObservabilityTelemetryQueryResponseEventsSeriesItemDataItem>;
export interface ObservabilityTelemetryQueryResponseEventsSeriesItem {
    data: ObservabilityTelemetryQueryResponseEventsSeriesItemDataList;
    time: string;
}
export type ObservabilityTelemetryQueryResponseEventsSeriesList = Array<ObservabilityTelemetryQueryResponseEventsSeriesItem>;
export interface ObservabilityTelemetryQueryResponseEvents {
    /** Total number of events matching the query (may exceed the number returned due to limits). */
    count?: number | null;
    /** List of individual telemetry events matching the query. */
    events?: ObservabilityTelemetryQueryResponseEventsEventsList | null;
    /** List of fields discovered in the matched events. Useful for building dynamic UIs. */
    fields?: ObservabilityTelemetryQueryResponseEventsFieldsList | null;
    /** Time-series data for the matched events, bucketed by the query granularity. */
    series?: ObservabilityTelemetryQueryResponseEventsSeriesList | null;
}
export type ObservabilityTelemetryQueryResponseInvocationsValueItemMetadata = ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemSourceCase1Map = {
    [key: string]: unknown | undefined;
};
export type ObservabilityTelemetryQueryResponseInvocationsValueItemSource = string | ObservabilityTelemetryQueryResponseInvocationsValueItemSourceCase1Map;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemContainersMap = {
    [key: string]: unknown | undefined;
};
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0EventMap = {
    [key: string]: unknown | undefined;
};
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0ExecutionModel = "durableObject" | "stateless";
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export interface ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0 {
    eventType: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0EventType;
    scriptName: string;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0EventMap | null;
    executionModel?: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0ExecutionModel | null;
    outcome?: string | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    requestId?: string | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsItem = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsList = Array<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1EventMap = {
    [key: string]: unknown | undefined;
};
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1ExecutionModel = "durableObject" | "stateless";
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export interface ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1 {
    cpuTimeMs: number;
    eventType: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1EventType;
    outcome: string;
    scriptName: string;
    wallTimeMs: number;
    diagnosticsChannelEvents?: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsList | null;
    dispatchNamespace?: string | null;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1EventMap | null;
    executionModel?: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1ExecutionModel | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    requestId?: string | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkers = ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0 | ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1;
export interface ObservabilityTelemetryQueryResponseInvocationsValueItem {
    /** Structured metadata extracted from the event. These fields are indexed and available for filtering and aggregation. */
    metadata: ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
    /** The dataset this event belongs to (e.g. cloudflare-workers). */
    dataset: string;
    /** Raw log payload. May be a string or a structured object depending on how the log was emitted. */
    source: ObservabilityTelemetryQueryResponseInvocationsValueItemSource;
    /** Event timestamp as a Unix epoch in milliseconds. */
    timestamp: number;
    /** Cloudflare Containers event information that enriches your logs for identifying and debugging issues. */
    containers?: ObservabilityTelemetryQueryResponseInvocationsValueItemContainersMap | null;
    /** Cloudflare Workers event information that enriches your logs for identifying and debugging issues. */
    workers?: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkers | null;
}
export type ObservabilityTelemetryQueryResponseInvocationsValueList = Array<ObservabilityTelemetryQueryResponseInvocationsValueItem>;
export type ObservabilityTelemetryQueryResponseInvocationsMap = {
    [key: string]: ObservabilityTelemetryQueryResponseInvocationsValueList | undefined;
};
export type ObservabilityTelemetryQueryResponseTracesItemServiceList = Array<string>;
export type ObservabilityTelemetryQueryResponseTracesItemErrorsList = Array<string>;
export interface ObservabilityTelemetryQueryResponseTracesItem {
    /** Name of the root span that initiated the trace. */
    rootSpanName: string;
    /** Logical transaction name for the root span. */
    rootTransactionName: string;
    /** List of Worker services involved in the trace. */
    service: ObservabilityTelemetryQueryResponseTracesItemServiceList;
    /** Total number of spans in the trace. */
    spans: number;
    /** Total duration of the trace in milliseconds. */
    traceDurationMs: number;
    /** Trace end time as a Unix epoch in milliseconds. */
    traceEndMs: number;
    /** Unique identifier for the distributed trace. */
    traceId: string;
    /** Trace start time as a Unix epoch in milliseconds. */
    traceStartMs: number;
    /** Error messages encountered during the trace, if any. */
    errors?: ObservabilityTelemetryQueryResponseTracesItemErrorsList | null;
}
export type ObservabilityTelemetryQueryResponseTracesList = Array<ObservabilityTelemetryQueryResponseTracesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface QueryObservabilityTelemetryResponse {
    /** Represents a single execution of a query against Workers Observability data, including the query definition, execution status, and performance statistics. */
    run: ObservabilityTelemetryQueryResponseRun;
    /** Query performance statistics from the database. Includes execution time, rows scanned, and bytes read. Does not include network latency. */
    statistics: ObservabilitySharedQueriesGetResponseRunStatistics;
    /** Agent run summaries. Present when the query view is 'agents'. Each entry represents one trace containing at least one agent invocation. */
    agents?: ObservabilityTelemetryQueryResponseAgentsList | null;
    /** Aggregated calculation results. Present when the query view is 'calculations'. Contains computed metrics (count, avg, p99, etc.) with optional group-by breakdowns and time-series data. */
    calculations?: ObservabilityTelemetryQueryResponseCalculationsList | null;
    /** Comparison calculation results from the previous time period. Present when the compare option is enabled. Same structure as calculations. */
    compare?: ObservabilityTelemetryQueryResponseCompareList | null;
    /** Bucketed 2D histogram of a numeric field over time. Present when chartType is 'distribution'. */
    distribution?: ObservabilityTelemetryQueryResponseDistribution | null;
    /** Individual event results. Present when the query view is 'events'. Contains the matching log lines and their metadata. */
    events?: ObservabilityTelemetryQueryResponseEvents | null;
    /** Events grouped by invocation (request ID). Present when the query view is 'invocations'. Each key is a request ID mapping to all events from that invocation. */
    invocations?: ObservabilityTelemetryQueryResponseInvocationsMap | null;
    /** Trace summaries matching the query. Present when the query view is 'traces'. Each entry represents a distributed trace with its spans, duration, and services involved. */
    traces?: ObservabilityTelemetryQueryResponseTracesList | null;
}
export type ScriptsSearchRequestOrderBy = "created_on" | "modified_on" | "name";
export interface SearchScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Worker ID (also called tag) to search for. Only exact matches are returned. */
    id?: string;
    /** Worker name to search for. Both exact and partial matches are returned. */
    name?: string;
    /** Property to sort results by. Results are sorted in ascending order. */
    orderBy?: ScriptsSearchRequestOrderBy | (string & {});
    /** Current page. */
    page?: number;
    /** Items per page. */
    perPage?: number;
}
export interface ScriptsSearchResultItem {
    /** Identifier. */
    id: string;
    /** When the script was created. */
    createdOn: string;
    /** When the script was last modified. */
    modifiedOn: string;
    /** Name of the script. */
    scriptName: string;
    /** Whether the environment is the default environment. */
    environmentIsDefault?: boolean | null;
    /** Name of the environment. */
    environmentName?: string | null;
    /** Name of the service. */
    serviceName?: string | null;
}
export type ScriptsSearchResultList = Array<ScriptsSearchResultItem>;
export type SearchScriptResponse = ScriptsSearchResultList;
export type BetaWorkersUpdateRequestObservabilityIssues = BetaWorkersCreateRequestObservabilityIssues;
export type BetaWorkersUpdateRequestObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersUpdateRequestObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersUpdateRequestObservabilityLogsDestinationsList;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean;
}
export type BetaWorkersUpdateRequestObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersUpdateRequestObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersUpdateRequestObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersUpdateRequestObservabilityTracesDestinationsList;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersUpdateRequestObservabilityTracesPropagationPolicy | (string & {});
}
export interface BetaWorkersUpdateRequestObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateRequestObservabilityIssues;
    /** Log settings for the Worker. */
    logs?: BetaWorkersUpdateRequestObservabilityLogs;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersUpdateRequestObservabilityTraces;
}
export type BetaWorkersUpdateRequestPreviewsBaseConfigCacheOptions = BetaWorkersCreateRequestPreviewsBaseConfigCacheOptions;
export type BetaWorkersUpdateRequestPreviewsBaseConfigEnvValue = BetaWorkersCreateRequestPreviewsBaseConfigEnvValue;
export type BetaWorkersUpdateRequestPreviewsBaseConfigEnvMap = {
    [key: string]: BetaWorkersCreateRequestPreviewsBaseConfigEnvValue | undefined;
};
export type BetaWorkersUpdateRequestPreviewsBaseConfigLimits = BetaWorkersCreateRequestPreviewsBaseConfigLimits;
export type BetaWorkersUpdateRequestPreviewsBaseConfigObservabilityIssues = BetaWorkersCreateRequestObservabilityIssues;
export type BetaWorkersUpdateRequestPreviewsBaseConfigObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersUpdateRequestPreviewsBaseConfigObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersUpdateRequestPreviewsBaseConfigObservabilityLogsDestinationsList;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean;
}
export type BetaWorkersUpdateRequestPreviewsBaseConfigObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersUpdateRequestPreviewsBaseConfigObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersUpdateRequestPreviewsBaseConfigObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersUpdateRequestPreviewsBaseConfigObservabilityTracesDestinationsList;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersUpdateRequestPreviewsBaseConfigObservabilityTracesPropagationPolicy | (string & {});
}
export interface BetaWorkersUpdateRequestPreviewsBaseConfigObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateRequestObservabilityIssues;
    /** Log settings for the Worker. */
    logs?: BetaWorkersUpdateRequestPreviewsBaseConfigObservabilityLogs;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersUpdateRequestPreviewsBaseConfigObservabilityTraces;
}
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementModeMode = "smart";
export interface BetaWorkersUpdateRequestPreviewsBaseConfigPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersUpdateRequestPreviewsBaseConfigPlacementModeMode;
}
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase4Mode = "targeted";
export interface BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase5Mode = "targeted";
export interface BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase5Mode;
}
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase6Mode = "targeted";
export interface BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase6Mode;
}
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase7Mode = "targeted";
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase7TargetList = Array<BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase7TargetItem>;
export interface BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase7TargetList;
}
export type BetaWorkersUpdateRequestPreviewsBaseConfigPlacement = BetaWorkersUpdateRequestPreviewsBaseConfigPlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase4 | BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase5 | BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase6 | BetaWorkersUpdateRequestPreviewsBaseConfigPlacementCase7;
export type BetaWorkersUpdateRequestPreviewsBaseConfigTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersUpdateRequestPreviewsBaseConfigTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export interface BetaWorkersUpdateRequestPreviewsBaseConfig {
    /** Cache options used when creating new Previews. */
    cacheOptions?: BetaWorkersCreateRequestPreviewsBaseConfigCacheOptions;
    /** Bindings used when creating new Previews, keyed by binding name. */
    env?: BetaWorkersUpdateRequestPreviewsBaseConfigEnvMap;
    /** Resource limits enforced at runtime for newly created Previews. */
    limits?: BetaWorkersCreateRequestPreviewsBaseConfigLimits;
    /** Whether logpush is enabled when creating new Previews. */
    logpush?: boolean;
    /** Observability settings used when creating new Previews. */
    observability?: BetaWorkersUpdateRequestPreviewsBaseConfigObservability;
    /** Placement configuration used when creating new Previews. */
    placement?: BetaWorkersUpdateRequestPreviewsBaseConfigPlacement;
    /** Other Workers that should consume logs from newly created Previews. */
    tailConsumers?: BetaWorkersUpdateRequestPreviewsBaseConfigTailConsumersList;
}
export type BetaWorkersUpdateRequestSubdomain = BetaWorkersCreateRequestSubdomain;
export type BetaWorkersUpdateRequestTagsList = Array<string>;
export type BetaWorkersUpdateRequestTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersUpdateRequestTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export interface UpdateBetaWorkerRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** Name of the Worker. */
    name: string;
    /** Whether logpush is enabled for the Worker. */
    logpush?: boolean;
    /** Observability settings for the Worker. */
    observability?: BetaWorkersUpdateRequestObservability;
    /** Template configuration used when creating new Previews for this Worker. */
    previewsBaseConfig?: BetaWorkersUpdateRequestPreviewsBaseConfig;
    /** Subdomain settings for the Worker. */
    subdomain?: BetaWorkersCreateRequestSubdomain;
    /** Tags associated with the Worker. */
    tags?: BetaWorkersUpdateRequestTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers?: BetaWorkersUpdateRequestTailConsumersList;
}
export type BetaWorkersUpdateResponseObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type BetaWorkersUpdateResponseObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersUpdateResponseObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersUpdateResponseObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type BetaWorkersUpdateResponseObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersUpdateResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersUpdateResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersUpdateResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersUpdateResponseObservabilityTracesPropagationPolicy | null;
}
export interface BetaWorkersUpdateResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersUpdateResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersUpdateResponseObservabilityTraces | null;
}
export type BetaWorkersUpdateResponseReferencesDispatchNamespaceOutboundsItem = BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem;
export type BetaWorkersUpdateResponseReferencesDispatchNamespaceOutboundsList = Array<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export type BetaWorkersUpdateResponseReferencesDomainsItem = BetaWorkersCreateResponseReferencesDomainsItem;
export type BetaWorkersUpdateResponseReferencesDomainsList = Array<BetaWorkersCreateResponseReferencesDomainsItem>;
export type BetaWorkersUpdateResponseReferencesDurableObjectsItem = BetaWorkersCreateResponseReferencesDurableObjectsItem;
export type BetaWorkersUpdateResponseReferencesDurableObjectsList = Array<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export type BetaWorkersUpdateResponseReferencesQueuesItem = BetaWorkersCreateResponseReferencesQueuesItem;
export type BetaWorkersUpdateResponseReferencesQueuesList = Array<BetaWorkersCreateResponseReferencesQueuesItem>;
export type BetaWorkersUpdateResponseReferencesWorkersItem = BetaWorkersCreateResponseReferencesWorkersItem;
export type BetaWorkersUpdateResponseReferencesWorkersList = Array<BetaWorkersCreateResponseReferencesWorkersItem>;
export interface BetaWorkersUpdateResponseReferences {
    /** Other Workers that reference the Worker as an outbound for a dispatch namespace. */
    dispatchNamespaceOutbounds: BetaWorkersUpdateResponseReferencesDispatchNamespaceOutboundsList;
    /** Custom domains connected to the Worker. */
    domains: BetaWorkersUpdateResponseReferencesDomainsList;
    /** Other Workers that reference Durable Object classes implemented by the Worker. */
    durableObjects: BetaWorkersUpdateResponseReferencesDurableObjectsList;
    /** Queues that send messages to the Worker. */
    queues: BetaWorkersUpdateResponseReferencesQueuesList;
    /** Other Workers that reference the Worker using [service bindings](https://developers.cloudflare.com/workers/runtime-apis/bindings/service-bindings/). */
    workers: BetaWorkersUpdateResponseReferencesWorkersList;
}
export type BetaWorkersUpdateResponseSubdomain = BetaWorkersCreateResponseSubdomain;
export type BetaWorkersUpdateResponseTagsList = Array<string>;
export type BetaWorkersUpdateResponseTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersUpdateResponseTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export type BetaWorkersUpdateResponsePreviewsBaseConfigCacheOptions = BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions;
export type BetaWorkersUpdateResponsePreviewsBaseConfigEnvValue = BetaWorkersCreateRequestPreviewsBaseConfigEnvValue;
export type BetaWorkersUpdateResponsePreviewsBaseConfigEnvMap = {
    [key: string]: BetaWorkersCreateRequestPreviewsBaseConfigEnvValue | undefined;
};
export type BetaWorkersUpdateResponsePreviewsBaseConfigLimits = BetaWorkersCreateResponsePreviewsBaseConfigLimits;
export type BetaWorkersUpdateResponsePreviewsBaseConfigObservabilityIssues = BetaWorkersCreateResponseObservabilityIssues;
export type BetaWorkersUpdateResponsePreviewsBaseConfigObservabilityLogsDestinationsList = Array<string>;
export interface BetaWorkersUpdateResponsePreviewsBaseConfigObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersUpdateResponsePreviewsBaseConfigObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type BetaWorkersUpdateResponsePreviewsBaseConfigObservabilityTracesDestinationsList = Array<string>;
export type BetaWorkersUpdateResponsePreviewsBaseConfigObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface BetaWorkersUpdateResponsePreviewsBaseConfigObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersUpdateResponsePreviewsBaseConfigObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: BetaWorkersUpdateResponsePreviewsBaseConfigObservabilityTracesPropagationPolicy | null;
}
export interface BetaWorkersUpdateResponsePreviewsBaseConfigObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: BetaWorkersCreateResponseObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersUpdateResponsePreviewsBaseConfigObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersUpdateResponsePreviewsBaseConfigObservabilityTraces | null;
}
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementModeMode = "smart";
export interface BetaWorkersUpdateResponsePreviewsBaseConfigPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersUpdateResponsePreviewsBaseConfigPlacementModeMode;
}
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion;
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost;
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase4Mode = "targeted";
export interface BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase5Mode = "targeted";
export interface BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase5Mode;
}
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase6Mode = "targeted";
export interface BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase6Mode;
}
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase7Mode = "targeted";
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase7TargetItemRegion = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion;
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase7TargetItemHostname = BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname;
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase7TargetItemHost = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase7TargetItem = BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementCase7TargetItemHost;
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase7TargetList = Array<BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase7TargetItem>;
export interface BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase7TargetList;
}
export type BetaWorkersUpdateResponsePreviewsBaseConfigPlacement = BetaWorkersUpdateResponsePreviewsBaseConfigPlacementMode | BetaWorkersCreateRequestPreviewsBaseConfigPlacementRegion | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHostname | BetaWorkersCreateRequestPreviewsBaseConfigPlacementHost | BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase4 | BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase5 | BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase6 | BetaWorkersUpdateResponsePreviewsBaseConfigPlacementCase7;
export type BetaWorkersUpdateResponsePreviewsBaseConfigTailConsumersItem = BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem;
export type BetaWorkersUpdateResponsePreviewsBaseConfigTailConsumersList = Array<BetaWorkersCreateRequestPreviewsBaseConfigTailConsumersItem>;
export interface BetaWorkersUpdateResponsePreviewsBaseConfig {
    /** Cache options used when creating new Previews. */
    cacheOptions?: BetaWorkersCreateResponsePreviewsBaseConfigCacheOptions | null;
    /** Bindings used when creating new Previews, keyed by binding name. */
    env?: BetaWorkersUpdateResponsePreviewsBaseConfigEnvMap | null;
    /** Resource limits enforced at runtime for newly created Previews. */
    limits?: BetaWorkersCreateResponsePreviewsBaseConfigLimits | null;
    /** Whether logpush is enabled when creating new Previews. */
    logpush?: boolean | null;
    /** Observability settings used when creating new Previews. */
    observability?: BetaWorkersUpdateResponsePreviewsBaseConfigObservability | null;
    /** Placement configuration used when creating new Previews. */
    placement?: BetaWorkersUpdateResponsePreviewsBaseConfigPlacement | null;
    /** Other Workers that should consume logs from newly created Previews. */
    tailConsumers?: BetaWorkersUpdateResponsePreviewsBaseConfigTailConsumersList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateBetaWorkerResponse {
    /** Immutable ID of the Worker. */
    id: string;
    /** When the Worker was created. */
    createdOn: string;
    /** Whether logpush is enabled for the Worker. */
    logpush: boolean;
    /** Name of the Worker. */
    name: string;
    /** Observability settings for the Worker. */
    observability: BetaWorkersUpdateResponseObservability;
    /** Other resources that reference the Worker and depend on it existing. */
    references: BetaWorkersUpdateResponseReferences;
    /** Subdomain settings for the Worker. */
    subdomain: BetaWorkersCreateResponseSubdomain;
    /** Tags associated with the Worker. */
    tags: BetaWorkersUpdateResponseTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers: BetaWorkersUpdateResponseTailConsumersList;
    /** When the Worker was most recently updated. */
    updatedOn: string;
    /** When the Worker's most recent deployment was created. `null` if the Worker has never been deployed. */
    deployedOn?: string | null;
    /** Template configuration used when creating new Previews for this Worker. */
    previewsBaseConfig?: BetaWorkersUpdateResponsePreviewsBaseConfig | null;
}
export interface UpdateObservabilityIssueAutomationRequest {
    accountId: string;
    automationId: string;
    /** Id of the notification policy to notify, normally one with alert type `workers_observability_real_time_issue`. Cloudflare does not validate that it exists. */
    policyId: string;
    /** Automation name (1-200 characters). Cloudflare generates one when omitted. */
    name?: string;
    /** Whether the automation is enabled. Defaults to true. */
    enabled?: boolean;
    /** Limit the automation to one Worker (script name). Omit for every Worker in the account. */
    service?: string;
    /** Notify once an issue has occurred this many times. Exactly one of `afterOccurrences` or `afterInactivitySeconds` is required. */
    afterOccurrences?: number;
    /** Notify when an issue recurs after this many seconds of inactivity (3600-31536000). Exactly one of `afterOccurrences` or `afterInactivitySeconds` is required. */
    afterInactivitySeconds?: number;
}
export interface UpdateRouteRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    routeId: string;
    /** Pattern to match incoming requests against. [Learn more](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior). */
    pattern: string;
    /** Name of the script to run if the route matches. */
    script?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRouteResponse {
    /** Identifier. */
    id: string;
    /** Pattern to match incoming requests against. [Learn more](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior). */
    pattern: string;
    /** Name of the script to run if the route matches. */
    script?: string | null;
}
export type ObservabilityTelemetryValuesRequestDatasetsList = Array<string>;
export interface ObservabilityTelemetryValuesRequestTimeframe {
    from: number;
    to: number;
}
export type ObservabilityTelemetryValuesRequestType = "string" | "boolean" | "number";
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0FiltersList = Array<unknown>;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0Kind = "group";
export interface ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0 {
    filterCombination: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0Kind;
}
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue;
}
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItem = ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0 | ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersList = Array<ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItem>;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0Kind = "group";
export interface ObservabilityTelemetryValuesRequestFiltersItemCase0 {
    filterCombination: ObservabilityTelemetryValuesRequestFiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryValuesRequestFiltersItemCase0Kind;
}
export type ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export type ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export type ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export type ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export interface ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data -- verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafValue;
}
export type ObservabilityTelemetryValuesRequestFiltersItem = ObservabilityTelemetryValuesRequestFiltersItemCase0 | ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeaf;
export type ObservabilityTelemetryValuesRequestFiltersList = Array<ObservabilityTelemetryValuesRequestFiltersItem>;
export type ObservabilityTelemetryValuesRequestNeedleValue = string | number | boolean;
export interface ObservabilityTelemetryValuesRequestNeedle {
    /** The text or pattern to search for. */
    value: ObservabilityTelemetryValuesRequestNeedleValue;
    /** When true, treats the value as a regular expression (RE2 syntax). */
    isRegex?: boolean;
    /** When true, performs a case-sensitive search. Defaults to case-insensitive. */
    matchCase?: boolean;
}
export interface ValuesObservabilityTelemetryRequest {
    accountId: string;
    /** Leave this empty to use the default datasets */
    datasets: ObservabilityTelemetryValuesRequestDatasetsList;
    key: string;
    timeframe: ObservabilityTelemetryValuesRequestTimeframe;
    type: ObservabilityTelemetryValuesRequestType | (string & {});
    /** Apply filters before listing values. Supports nested groups via kind: 'group'. Maximum nesting depth is 4. */
    filters?: ObservabilityTelemetryValuesRequestFiltersList;
    limit?: number;
    /** Full-text search expression to match events containing the specified text or pattern. */
    needle?: ObservabilityTelemetryValuesRequestNeedle;
}
export type ObservabilityTelemetryValuesResultItemType = "string" | "boolean" | "number";
export type ObservabilityTelemetryValuesResultItemValue = string | number | boolean;
export interface ObservabilityTelemetryValuesResultItem {
    dataset: string;
    key: string;
    type: ObservabilityTelemetryValuesResultItemType;
    value: ObservabilityTelemetryValuesResultItemValue;
}
export type ObservabilityTelemetryValuesResultList = Array<ObservabilityTelemetryValuesResultItem>;
export interface ValuesObservabilityTelemetryResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ObservabilityTelemetryValuesResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type BetaWorkersVersionsProfileError = CloudflareOpError;
/** Captures a CPU or heap profile from a recently active isolate running the specified Worker version. This endpoint requires the Worker profiling feature to be enabled for the account. */
export declare const betaWorkersVersionsProfile: API.OperationMethod<BetaWorkersVersionsProfileRequest, BetaWorkersVersionsProfileResponse, BetaWorkersVersionsProfileError, CloudflareOpContext>;
export type BulkUpdateScriptSecretsError = CloudflareOpError;
/** Create, update, or delete multiple secrets on a Worker script in a single operation using JSON Merge Patch (RFC 7396). This operation creates a single version with all changes included. Prefer this API instead of changing many secrets individually. Usage: - To create or update a secret, set its value to a secret object. - To delete a secret, set its value to `null`. - Secrets not included in the request are left unchanged. */
export declare const bulkUpdateScriptSecrets: API.OperationMethod<BulkUpdateScriptSecretsRequest, BulkUpdateScriptSecretsResponse, BulkUpdateScriptSecretsError, CloudflareOpContext>;
export type CreateAssetUploadError = InvalidRoute | CloudflareOpError;
/** Upload Worker assets ahead of creating a Worker version. To learn more about the direct uploads of assets, see https://developers.cloudflare.com/workers/static-assets/direct-upload/. */
export declare const createAssetUpload: API.OperationMethod<CreateAssetUploadRequest, CreateAssetUploadResponse, CreateAssetUploadError, CloudflareOpContext>;
export type CreateBetaWorkerError = InvalidRoute | CloudflareOpError;
/** Create a new Worker. */
export declare const createBetaWorker: API.OperationMethod<CreateBetaWorkerRequest, CreateBetaWorkerResponse, CreateBetaWorkerError, CloudflareOpContext>;
export type CreateBetaWorkerVersionError = WorkerNotFound | CloudflareOpError;
/** Create a new version for a Worker. */
export declare const createBetaWorkerVersion: API.OperationMethod<CreateBetaWorkerVersionRequest, CreateBetaWorkerVersionResponse, CreateBetaWorkerVersionError, CloudflareOpContext>;
export type CreateObservabilityDestinationError = ObservabilityDestinationCreateFailed | Forbidden | CloudflareOpError;
/** Create a new Workers Observability Telemetry Destination. */
export declare const createObservabilityDestination: API.OperationMethod<CreateObservabilityDestinationRequest, CreateObservabilityDestinationResponse, CreateObservabilityDestinationError, CloudflareOpContext>;
export type CreateObservabilityIssueAutomationError = ObservabilityIssueAutomationInvalid | Forbidden | CloudflareOpError;
/** Create a Workers Issues automation that notifies a notification policy when an issue crosses an occurrence or inactivity threshold. */
export declare const createObservabilityIssueAutomation: API.OperationMethod<CreateObservabilityIssueAutomationRequest, ObservabilityIssueAutomationResponse, CreateObservabilityIssueAutomationError, CloudflareOpContext>;
export type CreateObservabilityQueryError = CloudflareOpError;
/** Persist query for later use. */
export declare const createObservabilityQuery: API.OperationMethod<CreateObservabilityQueryRequest, CreateObservabilityQueryResponse, CreateObservabilityQueryError, CloudflareOpContext>;
export type CreateObservabilitySharedQueryError = CloudflareOpError;
/** Shared queries store the results of a previously run query, allowing you to share the results with others. */
export declare const createObservabilitySharedQuery: API.OperationMethod<CreateObservabilitySharedQueryRequest, CreateObservabilitySharedQueryResponse, CreateObservabilitySharedQueryError, CloudflareOpContext>;
export type CreatePreviewError = WorkerNotFound | PreviewAlreadyExists | CloudflareOpError;
/** Create a Worker Preview. Does not deploy code; follow with createPreviewDeployment. */
export declare const createPreview: API.OperationMethod<CreatePreviewRequest, PreviewResource, CreatePreviewError, CloudflareOpContext>;
export type CreatePreviewDeploymentError = PreviewNotFound | WorkerNotFound | CloudflareOpError;
/** Upload code, bindings, and assets as a new deployment of a Preview. */
export declare const createPreviewDeployment: API.OperationMethod<CreatePreviewDeploymentRequest, PreviewDeploymentResource, CreatePreviewDeploymentError, CloudflareOpContext>;
export type CreateRouteError = InvalidRoutePattern | InvalidRoute | Forbidden | RouteScriptNotFound | CloudflareOpError;
/** Creates a route that maps a URL pattern to a Worker. */
export declare const createRoute: API.OperationMethod<CreateRouteRequest, CreateRouteResponse, CreateRouteError, CloudflareOpContext>;
export type CreateScriptAssetUploadError = CloudflareOpError;
/** Start uploading a collection of assets for use in a Worker version. To learn more about the direct uploads of assets, see https://developers.cloudflare.com/workers/static-assets/direct-upload/. */
export declare const createScriptAssetUpload: API.OperationMethod<CreateScriptAssetUploadRequest, CreateScriptAssetUploadResponse, CreateScriptAssetUploadError, CloudflareOpContext>;
export type CreateScriptDeploymentError = WorkerNotFound | CloudflareOpError;
/** Deployments configure how [Worker Versions](https://developers.cloudflare.com/api/operations/worker-versions-list-versions) are deployed to traffic. A deployment can consist of multiple versions of a Worker. */
export declare const createScriptDeployment: API.OperationMethod<CreateScriptDeploymentRequest, CreateScriptDeploymentResponse, CreateScriptDeploymentError, CloudflareOpContext>;
export type CreateScriptEdgePreviewError = InvalidRoute | CloudflareOpError;
/** Upload a preview worker under an edge-preview session (undocumented endpoint). */
export declare const createScriptEdgePreview: API.OperationMethod<CreateScriptEdgePreviewRequest, CreateScriptEdgePreviewResponse, CreateScriptEdgePreviewError, CloudflareOpContext>;
export type CreateScriptSubdomainError = WorkerNotFound | CloudflareOpError;
/** Enable or disable a Worker script on the workers.dev subdomain. */
export declare const createScriptSubdomain: API.OperationMethod<CreateScriptSubdomainRequest, CreateScriptSubdomainResponse, CreateScriptSubdomainError, CloudflareOpContext>;
export type CreateScriptTailError = WorkerNotFound | CloudflareOpError;
/** Starts a tail that receives logs and exceptions from a Worker. */
export declare const createScriptTail: API.OperationMethod<CreateScriptTailRequest, CreateScriptTailResponse, CreateScriptTailError, CloudflareOpContext>;
export type CreateScriptVersionError = WorkerNotFound | CloudflareOpError;
/** Upload a Worker Version without deploying to Cloudflare's network. You can find more about the multipart metadata on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/. */
export declare const createScriptVersion: API.OperationMethod<CreateScriptVersionRequest, CreateScriptVersionResponse, CreateScriptVersionError, CloudflareOpContext>;
export type CreateServiceEdgePreviewError = InvalidRoute | CloudflareOpError;
/** Upload a preview worker for one environment of a service under an edge-preview session (undocumented endpoint). */
export declare const createServiceEdgePreview: API.OperationMethod<CreateServiceEdgePreviewRequest, CreateServiceEdgePreviewResponse, CreateServiceEdgePreviewError, CloudflareOpContext>;
export type CreateSubdomainEdgePreviewSessionError = InvalidRoute | CloudflareOpError;
/** Create an edge-preview session for the account's workers.dev subdomain (undocumented endpoint). */
export declare const createSubdomainEdgePreviewSession: API.OperationMethod<CreateSubdomainEdgePreviewSessionRequest, CreateSubdomainEdgePreviewSessionResponse, CreateSubdomainEdgePreviewSessionError, CloudflareOpContext>;
export type CreateZoneEdgePreviewSessionError = InvalidRoute | CloudflareOpError;
/** Create an edge-preview session scoped to a zone (undocumented endpoint). */
export declare const createZoneEdgePreviewSession: API.OperationMethod<CreateZoneEdgePreviewSessionRequest, CreateZoneEdgePreviewSessionResponse, CreateZoneEdgePreviewSessionError, CloudflareOpContext>;
export type DeleteBetaWorkerError = WorkerNotFound | CloudflareOpError;
/** Delete a Worker and all its associated resources (versions, deployments, etc.). */
export declare const deleteBetaWorker: API.OperationMethod<DeleteBetaWorkerRequest, DeleteBetaWorkerResponse, DeleteBetaWorkerError, CloudflareOpContext>;
export type DeleteBetaWorkerVersionError = WorkerNotFound | WorkerVersionNotFound | CloudflareOpError;
/** Delete a Worker version. */
export declare const deleteBetaWorkerVersion: API.OperationMethod<DeleteBetaWorkerVersionRequest, DeleteBetaWorkerVersionResponse, DeleteBetaWorkerVersionError, CloudflareOpContext>;
export type DeleteDomainError = DomainNotFound | CloudflareOpError;
/** Detaches a domain from a Worker. Both the Worker and all of its previews are no longer routable using this domain. */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest, DeleteDomainResponse, DeleteDomainError, CloudflareOpContext>;
export type DeleteObservabilityDestinationError = ObservabilityDestinationNotFound | Forbidden | CloudflareOpError;
/** Delete a Workers Observability Telemetry Destination. */
export declare const deleteObservabilityDestination: API.OperationMethod<DeleteObservabilityDestinationRequest, DeleteObservabilityDestinationResponse, DeleteObservabilityDestinationError, CloudflareOpContext>;
export type DeleteObservabilityIssueAutomationError = ObservabilityIssueAutomationNotFound | Forbidden | CloudflareOpError;
/** Delete a Workers Issues automation. Returns the deleted automation. */
export declare const deleteObservabilityIssueAutomation: API.OperationMethod<DeleteObservabilityIssueAutomationRequest, ObservabilityIssueAutomationResponse, DeleteObservabilityIssueAutomationError, CloudflareOpContext>;
export type DeletePreviewError = PreviewNotFound | WorkerNotFound | CloudflareOpError;
/** Delete a Worker Preview and all its deployments. */
export declare const deletePreview: API.OperationMethod<DeletePreviewRequest, DeletePreviewResponse, DeletePreviewError, CloudflareOpContext>;
export type DeleteRouteError = RouteNotFound | CloudflareOpError;
/** Deletes a Worker route. */
export declare const deleteRoute: API.OperationMethod<DeleteRouteRequest, DeleteRouteResponse, DeleteRouteError, CloudflareOpContext>;
export type DeleteScriptError = WorkerNotFound | QueueConsumerConflict | ServiceBindingConflict | CloudflareOpError;
/** Delete your worker. This call has no response body on a successful delete. */
export declare const deleteScript: API.OperationMethod<DeleteScriptRequest, DeleteScriptResponse, DeleteScriptError, CloudflareOpContext>;
export type DeleteScriptDeploymentError = WorkerNotFound | DeploymentNotFound | CloudflareOpError;
/** Delete a Worker Deployment. The latest deployment, which is actively serving traffic, cannot be deleted. All other deployments can be deleted. */
export declare const deleteScriptDeployment: API.OperationMethod<DeleteScriptDeploymentRequest, DeleteScriptDeploymentResponse, DeleteScriptDeploymentError, CloudflareOpContext>;
export type DeleteScriptSecretError = WorkerNotFound | SecretNotFound | CloudflareOpError;
/** Remove a secret from a Worker script by creating a new version without that secret. When changing more than one secret at a time, prefer the "Patch multiple script secrets" API instead of changing many secrets individually. */
export declare const deleteScriptSecret: API.OperationMethod<DeleteScriptSecretRequest, DeleteScriptSecretResponse, DeleteScriptSecretError, CloudflareOpContext>;
export type DeleteScriptSubdomainError = WorkerNotFound | CloudflareOpError;
/** Disable all workers.dev subdomains for a Worker script. */
export declare const deleteScriptSubdomain: API.OperationMethod<DeleteScriptSubdomainRequest, DeleteScriptSubdomainResponse, DeleteScriptSubdomainError, CloudflareOpContext>;
export type DeleteScriptTailError = WorkerNotFound | CloudflareOpError;
/** Deletes a tail from a Worker. */
export declare const deleteScriptTail: API.OperationMethod<DeleteScriptTailRequest, DeleteScriptTailResponse, DeleteScriptTailError, CloudflareOpContext>;
export type DeleteSubdomainError = InvalidRoute | SubdomainNotFound | Forbidden | CloudflareOpError;
/** Deletes a Workers subdomain for an account. */
export declare const deleteSubdomain: API.OperationMethod<DeleteSubdomainRequest, DeleteSubdomainResponse, DeleteSubdomainError, CloudflareOpContext>;
export type GetAccountSettingError = InvalidRoute | Forbidden | CloudflareOpError;
/** Fetches Workers account settings for an account. */
export declare const getAccountSetting: API.OperationMethod<GetAccountSettingRequest, GetAccountSettingResponse, GetAccountSettingError, CloudflareOpContext>;
export type GetBetaWorkerError = WorkerNotFound | InvalidRoute | CloudflareOpError;
/** Get details about a specific Worker. */
export declare const getBetaWorker: API.OperationMethod<GetBetaWorkerRequest, GetBetaWorkerResponse, GetBetaWorkerError, CloudflareOpContext>;
export type GetBetaWorkerVersionError = WorkerNotFound | WorkerVersionNotFound | CloudflareOpError;
/** Get details about a specific Worker version. */
export declare const getBetaWorkerVersion: API.OperationMethod<GetBetaWorkerVersionRequest, GetBetaWorkerVersionResponse, GetBetaWorkerVersionError, CloudflareOpContext>;
export type GetDomainError = DomainNotFound | InvalidRoute | CloudflareOpError;
/** Gets information about a Worker domain. */
export declare const getDomain: API.OperationMethod<GetDomainRequest, GetDomainResponse, GetDomainError, CloudflareOpContext>;
export type GetObservabilityIssueAutomationError = ObservabilityIssueAutomationNotFound | Forbidden | CloudflareOpError;
/** Get a Workers Issues automation. */
export declare const getObservabilityIssueAutomation: API.OperationMethod<GetObservabilityIssueAutomationRequest, ObservabilityIssueAutomationResponse, GetObservabilityIssueAutomationError, CloudflareOpContext>;
export type GetObservabilitySharedQueryError = CloudflareOpError;
/** Shared queries store the results of a previously run query, allowing you to share the results with others. */
export declare const getObservabilitySharedQuery: API.OperationMethod<GetObservabilitySharedQueryRequest, GetObservabilitySharedQueryResponse, GetObservabilitySharedQueryError, CloudflareOpContext>;
export type GetPreviewError = PreviewNotFound | WorkerNotFound | CloudflareOpError;
/** Get a Worker Preview by id or name. */
export declare const getPreview: API.OperationMethod<GetPreviewRequest, PreviewResource, GetPreviewError, CloudflareOpContext>;
export type GetPreviewDeploymentError = PreviewNotFound | PreviewDeploymentNotFound | WorkerNotFound | CloudflareOpError;
/** Get a Preview deployment by id, or `latest`. */
export declare const getPreviewDeployment: API.OperationMethod<GetPreviewDeploymentRequest, PreviewDeploymentResource, GetPreviewDeploymentError, CloudflareOpContext>;
export type GetRouteError = WorkerNotFound | RouteNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Returns information about a Worker route, including URL pattern and Worker. */
export declare const getRoute: API.OperationMethod<GetRouteRequest, GetRouteResponse, GetRouteError, CloudflareOpContext>;
export type GetScriptError = WorkerNotFound | InvalidRoute | WorkerHasNoVersions | CloudflareOpError;
/** Fetch raw content for a Worker script. Note this is the original script content, not JSON encoded. */
export declare const getScript: API.OperationMethod<GetScriptRequest, GetScriptResponse, GetScriptError, CloudflareOpContext>;
export type GetScriptContentError = WorkerNotFound | CloudflareOpError;
/** Fetch Worker script content only. */
export declare const getScriptContent: API.OperationMethod<GetScriptContentRequest, GetScriptContentResponse, GetScriptContentError, CloudflareOpContext>;
export type GetScriptDeploymentError = WorkerNotFound | DeploymentNotFound | CloudflareOpError;
/** Get information about a Worker Deployment. */
export declare const getScriptDeployment: API.OperationMethod<GetScriptDeploymentRequest, GetScriptDeploymentResponse, GetScriptDeploymentError, CloudflareOpContext>;
export type GetScriptEventTriggersError = CloudflareOpError;
/** The script's event triggers. A script with none, or no script by that name, has an empty list. */
export declare const getScriptEventTriggers: API.OperationMethod<GetScriptEventTriggersRequest, GetScriptEventTriggersResponse, GetScriptEventTriggersError, CloudflareOpContext>;
export type GetScriptScheduleError = WorkerNotFound | CloudflareOpError;
/** Get the schedules (Cron Triggers) for a Worker script. */
export declare const getScriptSchedule: API.OperationMethod<GetScriptScheduleRequest, GetScriptScheduleResponse, GetScriptScheduleError, CloudflareOpContext>;
export type GetScriptScriptAndVersionSettingError = WorkerNotFound | WorkerHasNoVersions | CloudflareOpError;
/** Get Worker script metadata and config, such as bindings or usage model. */
export declare const getScriptScriptAndVersionSetting: API.OperationMethod<GetScriptScriptAndVersionSettingRequest, GetScriptScriptAndVersionSettingResponse, GetScriptScriptAndVersionSettingError, CloudflareOpContext>;
export type GetScriptSecretError = WorkerNotFound | SecretNotFound | CloudflareOpError;
/** Get a given secret binding (value omitted) on a Worker script. */
export declare const getScriptSecret: API.OperationMethod<GetScriptSecretRequest, GetScriptSecretResponse, GetScriptSecretError, CloudflareOpContext>;
export type GetScriptSettingError = WorkerNotFound | WorkerHasNoVersions | CloudflareOpError;
/** Get Worker script-level settings when using [Worker Versions](https://developers.cloudflare.com/api/operations/worker-versions-list-versions). Includes Logpush and Tail Consumers. */
export declare const getScriptSetting: API.OperationMethod<GetScriptSettingRequest, GetScriptSettingResponse, GetScriptSettingError, CloudflareOpContext>;
export type GetScriptSubdomainError = WorkerNotFound | CloudflareOpError;
/** Get whether a Worker script is available on the workers.dev subdomain. */
export declare const getScriptSubdomain: API.OperationMethod<GetScriptSubdomainRequest, GetScriptSubdomainResponse, GetScriptSubdomainError, CloudflareOpContext>;
export type GetScriptTailError = WorkerNotFound | CloudflareOpError;
/** Get a list of tails currently deployed on a Worker. */
export declare const getScriptTail: API.OperationMethod<GetScriptTailRequest, GetScriptTailResponse, GetScriptTailError, CloudflareOpContext>;
export type GetScriptVersionError = WorkerNotFound | VersionNotFound | CloudflareOpError;
/** Retrieves detailed information about a specific version of a Worker script. */
export declare const getScriptVersion: API.OperationMethod<GetScriptVersionRequest, GetScriptVersionResponse, GetScriptVersionError, CloudflareOpContext>;
export type GetSubdomainError = InvalidRoute | SubdomainNotFound | Forbidden | CloudflareOpError;
/** Returns a Workers subdomain for an account. */
export declare const getSubdomain: API.OperationMethod<GetSubdomainRequest, GetSubdomainResponse, GetSubdomainError, CloudflareOpContext>;
export type KeysObservabilityTelemetryError = InvalidRoute | CloudflareOpError;
/** List all the keys in your telemetry events. */
export declare const keysObservabilityTelemetry: API.PaginatedOperationMethod<KeysObservabilityTelemetryRequest, KeysObservabilityTelemetryResponse, KeysObservabilityTelemetryError, CloudflareOpContext, ObservabilityTelemetryKeysResultItem>;
export type ListBetaWorkersError = InvalidRoute | CloudflareOpError;
/** List all Workers for an account. */
export declare const listBetaWorkers: API.PaginatedOperationMethod<ListBetaWorkersRequest, ListBetaWorkersResponse, ListBetaWorkersError, CloudflareOpContext, BetaWorkersListResultItem>;
export type ListBetaWorkerVersionsError = WorkerNotFound | CloudflareOpError;
/** List all versions for a Worker. */
export declare const listBetaWorkerVersions: API.PaginatedOperationMethod<ListBetaWorkerVersionsRequest, ListBetaWorkerVersionsResponse, ListBetaWorkerVersionsError, CloudflareOpContext, BetaWorkersVersionsListResultItem>;
export type ListDomainsError = InvalidRoute | CloudflareOpError;
/** Lists all Worker domains for an account. */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest, ListDomainsResponse, ListDomainsError, CloudflareOpContext, DomainsListResultItem>;
export type ListObservabilityDestinationsError = Forbidden | CloudflareOpError;
/** List your Workers Observability Telemetry Destinations. */
export declare const listObservabilityDestinations: API.PaginatedOperationMethod<ListObservabilityDestinationsRequest, ListObservabilityDestinationsResponse, ListObservabilityDestinationsError, CloudflareOpContext, ObservabilityDestinationsListResultItem>;
export type ListObservabilityIssueAutomationsError = Forbidden | CloudflareOpError;
/** List Workers Issues automations (account- and service-scoped). */
export declare const listObservabilityIssueAutomations: API.OperationMethod<ListObservabilityIssueAutomationsRequest, ListObservabilityIssueAutomationsResponse, ListObservabilityIssueAutomationsError, CloudflareOpContext>;
export type ListObservabilityQueriesError = CloudflareOpError;
/** List saved queries. */
export declare const listObservabilityQueries: API.PaginatedOperationMethod<ListObservabilityQueriesRequest, ListObservabilityQueriesResponse, ListObservabilityQueriesError, CloudflareOpContext, ObservabilityQueriesListResultItem>;
export type ListRoutesError = InvalidRoute | Forbidden | CloudflareOpError;
/** Returns Worker routes for a zone. */
export declare const listRoutes: API.PaginatedOperationMethod<ListRoutesRequest, ListRoutesResponse, ListRoutesError, CloudflareOpContext, RoutesListResultItem>;
export type ListScriptDeploymentsError = WorkerNotFound | CloudflareOpError;
/** List Worker deployments. The first deployment in the list is the latest deployment actively serving traffic. */
export declare const listScriptDeployments: API.OperationMethod<ListScriptDeploymentsRequest, ListScriptDeploymentsResponse, ListScriptDeploymentsError, CloudflareOpContext>;
export type ListScriptsError = InvalidRoute | CloudflareOpError;
/** Fetch a list of uploaded Worker scripts. */
export declare const listScripts: API.PaginatedOperationMethod<ListScriptsRequest, ListScriptsResponse, ListScriptsError, CloudflareOpContext, ScriptsListResultItem>;
export type ListScriptSecretsError = WorkerNotFound | CloudflareOpError;
/** List the names of secrets bound to a Worker script. */
export declare const listScriptSecrets: API.PaginatedOperationMethod<ListScriptSecretsRequest, ListScriptSecretsResponse, ListScriptSecretsError, CloudflareOpContext, ScriptsSecretsListResultItem>;
export type ListScriptVersionsError = WorkerNotFound | CloudflareOpError;
/** List of Worker Versions. The first version in the list is the latest version. */
export declare const listScriptVersions: API.OperationMethod<ListScriptVersionsRequest, ListScriptVersionsResponse, ListScriptVersionsError, CloudflareOpContext>;
export type LiveTailHeartbeatObservabilityTelemetryError = CloudflareOpError;
/** Notify live tail that user is still eligible to receive live events. */
export declare const liveTailHeartbeatObservabilityTelemetry: API.OperationMethod<LiveTailHeartbeatObservabilityTelemetryRequest, LiveTailHeartbeatObservabilityTelemetryResponse, LiveTailHeartbeatObservabilityTelemetryError, CloudflareOpContext>;
export type LiveTailObservabilityTelemetryError = CloudflareOpError;
/** Prepare websocket server for live tail. */
export declare const liveTailObservabilityTelemetry: API.OperationMethod<LiveTailObservabilityTelemetryRequest, LiveTailObservabilityTelemetryResponse, LiveTailObservabilityTelemetryError, CloudflareOpContext>;
export type PatchBetaWorkerError = WorkerNotFound | CloudflareOpError;
/** Perform a partial update on a Worker, where omitted properties are left unchanged from their current values. */
export declare const patchBetaWorker: API.OperationMethod<PatchBetaWorkerRequest, PatchBetaWorkerResponse, PatchBetaWorkerError, CloudflareOpContext>;
export type PatchObservabilityDestinationError = ObservabilityDestinationNotFound | ObservabilityDestinationPreflightFailed | Forbidden | CloudflareOpError;
/** Update an existing Workers Observability Telemetry Destination. */
export declare const patchObservabilityDestination: API.OperationMethod<PatchObservabilityDestinationRequest, PatchObservabilityDestinationResponse, PatchObservabilityDestinationError, CloudflareOpContext>;
export type PatchScriptScriptAndVersionSettingError = WorkerNotFound | ContentTypeRequired | CloudflareOpError;
/** Patch Worker script metadata or config, such as bindings or usage model. */
export declare const patchScriptScriptAndVersionSetting: API.OperationMethod<PatchScriptScriptAndVersionSettingRequest, PatchScriptScriptAndVersionSettingResponse, PatchScriptScriptAndVersionSettingError, CloudflareOpContext>;
export type PatchScriptSettingError = WorkerNotFound | CloudflareOpError;
/** Patch Worker script-level settings when using [Worker Versions](https://developers.cloudflare.com/api/operations/worker-versions-list-versions). Including but not limited to Logpush and Tail Consumers. */
export declare const patchScriptSetting: API.OperationMethod<PatchScriptSettingRequest, PatchScriptSettingResponse, PatchScriptSettingError, CloudflareOpContext>;
export type PutAccountSettingError = InvalidRoute | Forbidden | CloudflareOpError;
/** Configure Workers account settings for an account. */
export declare const putAccountSetting: API.OperationMethod<PutAccountSettingRequest, PutAccountSettingResponse, PutAccountSettingError, CloudflareOpContext>;
export type PutDomainError = WorkerNotFound | InvalidRoute | HostnameAlreadyInUse | CloudflareOpError;
/** Attaches a domain that routes traffic to a Worker. */
export declare const putDomain: API.OperationMethod<PutDomainRequest, PutDomainResponse, PutDomainError, CloudflareOpContext>;
export type PutScriptError = InvalidRoute | InvalidWorkerScript | DurableObjectMustBeSqlite | DuplicateMigrationTarget | ScriptStartupError | ScriptModuleNotFound | SecretsStoreBindingNotFound | KVNamespaceNotFound | R2BucketNotFound | D1DatabaseNotFound | QueueNotFound | ServiceBindingNotFound | DurableObjectClassNotFound | HyperdriveConfigNotFound | VectorizeIndexNotFound | DispatchNamespaceNotFound | MtlsCertificateNotFound | CloudflareOpError;
/** Upload a worker module. You can find more about the multipart metadata on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/. */
export declare const putScript: API.OperationMethod<PutScriptRequest, PutScriptResponse, PutScriptError, CloudflareOpContext>;
export type PutScriptContentError = WorkerNotFound | InvalidWorkerScript | ScriptStartupError | ScriptModuleNotFound | CloudflareOpError;
/** Replace Worker script content without touching config or metadata. */
export declare const putScriptContent: API.OperationMethod<PutScriptContentRequest, PutScriptContentResponse, PutScriptContentError, CloudflareOpContext>;
export type PutScriptEventTriggersError = EventTriggerWorkflowNotFound | InvalidEventTriggers | CloudflareOpError;
/** Replace the script's event triggers; an empty list removes them. Each target names a Workflow the script hosts, which must exist first. */
export declare const putScriptEventTriggers: API.OperationMethod<PutScriptEventTriggersRequest, PutScriptEventTriggersResponse, PutScriptEventTriggersError, CloudflareOpContext>;
export type PutScriptScheduleError = WorkerNotFound | CloudflareOpError;
/** Update the schedules (Cron Triggers) for a Worker script. */
export declare const putScriptSchedule: API.OperationMethod<PutScriptScheduleRequest, PutScriptScheduleResponse, PutScriptScheduleError, CloudflareOpContext>;
export type PutScriptSecretError = WorkerNotFound | CloudflareOpError;
/** Add a secret to a Worker script by creating a new version with that secret. When changing more than one secret at a time, prefer the "Patch multiple script secrets" API instead of changing many secrets individually. */
export declare const putScriptSecret: API.OperationMethod<PutScriptSecretRequest, PutScriptSecretResponse, PutScriptSecretError, CloudflareOpContext>;
export type PutSubdomainError = SubdomainAlreadyExists | InvalidRoute | Forbidden | CloudflareOpError;
/** Creates a Workers subdomain for an account. */
export declare const putSubdomain: API.OperationMethod<PutSubdomainRequest, PutSubdomainResponse, PutSubdomainError, CloudflareOpContext>;
export type QueryObservabilityTelemetryError = InvalidRoute | CloudflareOpError;
/** Run a temporary or saved query. */
export declare const queryObservabilityTelemetry: API.OperationMethod<QueryObservabilityTelemetryRequest, QueryObservabilityTelemetryResponse, QueryObservabilityTelemetryError, CloudflareOpContext>;
export type SearchScriptError = InvalidRoute | CloudflareOpError;
/** Search for Worker scripts in an account. */
export declare const searchScript: API.OperationMethod<SearchScriptRequest, SearchScriptResponse, SearchScriptError, CloudflareOpContext>;
export type UpdateBetaWorkerError = WorkerNotFound | CloudflareOpError;
/** Perform a complete replacement of a Worker, where omitted properties are set to their default values. This is the exact same as the Create Worker endpoint, but operates on an existing Worker. To perform a partial update instead, use the Edit Worker endpoint. */
export declare const updateBetaWorker: API.OperationMethod<UpdateBetaWorkerRequest, UpdateBetaWorkerResponse, UpdateBetaWorkerError, CloudflareOpContext>;
export type UpdateObservabilityIssueAutomationError = ObservabilityIssueAutomationNotFound | ObservabilityIssueAutomationInvalid | Forbidden | CloudflareOpError;
/** Replace a Workers Issues automation. PUT is a full replace: omitted fields reset (an omitted `name` is regenerated). */
export declare const updateObservabilityIssueAutomation: API.OperationMethod<UpdateObservabilityIssueAutomationRequest, ObservabilityIssueAutomationResponse, UpdateObservabilityIssueAutomationError, CloudflareOpContext>;
export type UpdateRouteError = RouteNotFound | InvalidRoutePattern | CloudflareOpError;
/** Replaces the URL pattern or Worker associated with a Worker route. */
export declare const updateRoute: API.OperationMethod<UpdateRouteRequest, UpdateRouteResponse, UpdateRouteError, CloudflareOpContext>;
export type ValuesObservabilityTelemetryError = InvalidRoute | CloudflareOpError;
/** List unique values found in your events. */
export declare const valuesObservabilityTelemetry: API.PaginatedOperationMethod<ValuesObservabilityTelemetryRequest, ValuesObservabilityTelemetryResponse, ValuesObservabilityTelemetryError, CloudflareOpContext, ObservabilityTelemetryValuesResultItem>;
//# sourceMappingURL=workers.d.ts.map