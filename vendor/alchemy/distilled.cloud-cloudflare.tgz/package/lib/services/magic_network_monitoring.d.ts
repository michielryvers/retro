import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const DuplicateMnmRuleName_base: S.TaggedErrorClass<"DuplicateMnmRuleName", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DuplicateMnmRuleName extends /*@__PURE__*/ DuplicateMnmRuleName_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidMnmConfig_base: S.TaggedErrorClass<"InvalidMnmConfig", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidMnmConfig extends /*@__PURE__*/ InvalidMnmConfig_base {
}
declare const MnmConfigAlreadyExists_base: S.TaggedErrorClass<"MnmConfigAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MnmConfigAlreadyExists extends /*@__PURE__*/ MnmConfigAlreadyExists_base {
}
declare const MnmConfigMissing_base: S.TaggedErrorClass<"MnmConfigMissing", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MnmConfigMissing extends /*@__PURE__*/ MnmConfigMissing_base {
}
declare const MnmConfigNotFound_base: S.TaggedErrorClass<"MnmConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MnmConfigNotFound extends /*@__PURE__*/ MnmConfigNotFound_base {
}
declare const MnmRuleNotFound_base: S.TaggedErrorClass<"MnmRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MnmRuleNotFound extends /*@__PURE__*/ MnmRuleNotFound_base {
}
export type ConfigsCreateRequestRouterIpsList = Array<string>;
export interface ConfigsCreateRequestWarpDevicesItem {
    /** Unique identifier for the warp device. */
    id: string;
    /** Name of the warp device. */
    name: string;
    /** IPv4 CIDR of the router sourcing flow data associated with this warp device. Only /32 addresses are currently supported. */
    routerIp: string;
}
export type ConfigsCreateRequestWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
export interface CreateConfigRequest {
    accountId: string;
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps?: ConfigsCreateRequestRouterIpsList;
    warpDevices?: ConfigsCreateRequestWarpDevicesList;
}
export type ConfigsCreateResponseRouterIpsList = Array<string>;
export type ConfigsCreateResponseWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export type ConfigsCreateResponseWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateConfigResponse {
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps: ConfigsCreateResponseRouterIpsList;
    warpDevices: ConfigsCreateResponseWarpDevicesList;
}
export type RulesCreateRequestPrefixesList = Array<string>;
export type RulesCreateRequestType = "threshold" | "zscore" | "advanced_ddos";
export type RulesCreateRequestDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export type RulesCreateRequestPrefixMatch = "exact" | "subnet" | "supernet";
export type RulesCreateRequestZscoreSensitivity = "low" | "medium" | "high";
export type RulesCreateRequestZscoreTarget = "bits" | "packets";
export interface CreateRuleRequest {
    accountId: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can't have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesCreateRequestPrefixesList;
    /** MNM rule type. */
    type: RulesCreateRequestType | (string & {});
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesCreateRequestDuration | (string & {});
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesCreateRequestPrefixMatch | (string & {});
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesCreateRequestZscoreSensitivity | (string & {});
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesCreateRequestZscoreTarget | (string & {});
}
export type RulesCreateResponsePrefixesList = Array<string>;
export type RulesCreateResponseType = "threshold" | "zscore" | "advanced_ddos";
export type RulesCreateResponseDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export type RulesCreateResponsePrefixMatch = "exact" | "subnet" | "supernet";
export type RulesCreateResponseZscoreSensitivity = "low" | "medium" | "high";
export type RulesCreateResponseZscoreTarget = "bits" | "packets";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRuleResponse {
    /** The id of the rule. Must be unique. */
    id: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can't have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesCreateResponsePrefixesList;
    /** MNM rule type. */
    type: RulesCreateResponseType;
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number | null;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesCreateResponseDuration | null;
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number | null;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesCreateResponsePrefixMatch | null;
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesCreateResponseZscoreSensitivity | null;
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesCreateResponseZscoreTarget | null;
}
export interface CreateVpcFlowTokenRequest {
    accountId: string;
}
export type CreateVpcFlowTokenResponse = string;
export interface DeleteConfigRequest {
    accountId: string;
}
export type ConfigsDeleteResponseRouterIpsList = Array<string>;
export type ConfigsDeleteResponseWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export type ConfigsDeleteResponseWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteConfigResponse {
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps: ConfigsDeleteResponseRouterIpsList;
    warpDevices: ConfigsDeleteResponseWarpDevicesList;
}
export interface DeleteRuleRequest {
    accountId: string;
    /** The id of the rule. Must be unique. */
    ruleId: string;
}
export type RulesDeleteResponsePrefixesList = Array<string>;
export type RulesDeleteResponseType = "threshold" | "zscore" | "advanced_ddos";
export type RulesDeleteResponseDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export type RulesDeleteResponsePrefixMatch = "exact" | "subnet" | "supernet";
export type RulesDeleteResponseZscoreSensitivity = "low" | "medium" | "high";
export type RulesDeleteResponseZscoreTarget = "bits" | "packets";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRuleResponse {
    /** The id of the rule. Must be unique. */
    id: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can't have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesDeleteResponsePrefixesList;
    /** MNM rule type. */
    type: RulesDeleteResponseType;
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number | null;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesDeleteResponseDuration | null;
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number | null;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesDeleteResponsePrefixMatch | null;
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesDeleteResponseZscoreSensitivity | null;
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesDeleteResponseZscoreTarget | null;
}
export interface GetConfigRequest {
    accountId: string;
}
export type ConfigsGetResponseRouterIpsList = Array<string>;
export type ConfigsGetResponseWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export type ConfigsGetResponseWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigResponse {
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps: ConfigsGetResponseRouterIpsList;
    warpDevices: ConfigsGetResponseWarpDevicesList;
}
export interface GetConfigFullRequest {
    accountId: string;
}
export type ConfigsFullGetResponseRouterIpsList = Array<string>;
export type ConfigsFullGetResponseWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export type ConfigsFullGetResponseWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigFullResponse {
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps: ConfigsFullGetResponseRouterIpsList;
    warpDevices: ConfigsFullGetResponseWarpDevicesList;
}
export interface GetRuleRequest {
    accountId: string;
    /** The id of the rule. Must be unique. */
    ruleId: string;
}
export type RulesGetResponsePrefixesList = Array<string>;
export type RulesGetResponseType = "threshold" | "zscore" | "advanced_ddos";
export type RulesGetResponseDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export type RulesGetResponsePrefixMatch = "exact" | "subnet" | "supernet";
export type RulesGetResponseZscoreSensitivity = "low" | "medium" | "high";
export type RulesGetResponseZscoreTarget = "bits" | "packets";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRuleResponse {
    /** The id of the rule. Must be unique. */
    id: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can't have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesGetResponsePrefixesList;
    /** MNM rule type. */
    type: RulesGetResponseType;
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number | null;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesGetResponseDuration | null;
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number | null;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesGetResponsePrefixMatch | null;
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesGetResponseZscoreSensitivity | null;
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesGetResponseZscoreTarget | null;
}
export interface ListRulesRequest {
    accountId: string;
}
export type RulesListResultItemPrefixesList = Array<string>;
export type RulesListResultItemType = "threshold" | "zscore" | "advanced_ddos";
export type RulesListResultItemDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export type RulesListResultItemPrefixMatch = "exact" | "subnet" | "supernet";
export type RulesListResultItemZscoreSensitivity = "low" | "medium" | "high";
export type RulesListResultItemZscoreTarget = "bits" | "packets";
export interface RulesListResultItem {
    /** The id of the rule. Must be unique. */
    id: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can't have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesListResultItemPrefixesList;
    /** MNM rule type. */
    type: RulesListResultItemType;
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number | null;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesListResultItemDuration | null;
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number | null;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesListResultItemPrefixMatch | null;
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesListResultItemZscoreSensitivity | null;
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesListResultItemZscoreTarget | null;
}
export type RulesListResultList = Array<RulesListResultItem>;
export interface ListRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ConfigsEditRequestRouterIpsList = Array<string>;
export type ConfigsEditRequestWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export type ConfigsEditRequestWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
export interface PatchConfigRequest {
    accountId: string;
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling?: number;
    /** The account name. */
    name?: string;
    routerIps?: ConfigsEditRequestRouterIpsList;
    warpDevices?: ConfigsEditRequestWarpDevicesList;
}
export type ConfigsEditResponseRouterIpsList = Array<string>;
export type ConfigsEditResponseWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export type ConfigsEditResponseWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchConfigResponse {
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps: ConfigsEditResponseRouterIpsList;
    warpDevices: ConfigsEditResponseWarpDevicesList;
}
export type RulesEditRequestPrefixesList = Array<string>;
export type RulesEditRequestType = "threshold" | "zscore" | "advanced_ddos";
export type RulesEditRequestDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export type RulesEditRequestPrefixMatch = "exact" | "subnet" | "supernet";
export type RulesEditRequestZscoreSensitivity = "low" | "medium" | "high";
export type RulesEditRequestZscoreTarget = "bits" | "packets";
export interface PatchRuleRequest {
    accountId: string;
    /** The id of the rule. Must be unique. */
    ruleId: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can't have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesEditRequestPrefixesList;
    /** MNM rule type. */
    type: RulesEditRequestType | (string & {});
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesEditRequestDuration | (string & {});
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesEditRequestPrefixMatch | (string & {});
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesEditRequestZscoreSensitivity | (string & {});
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesEditRequestZscoreTarget | (string & {});
}
export type RulesEditResponsePrefixesList = Array<string>;
export type RulesEditResponseType = "threshold" | "zscore" | "advanced_ddos";
export type RulesEditResponseDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export type RulesEditResponsePrefixMatch = "exact" | "subnet" | "supernet";
export type RulesEditResponseZscoreSensitivity = "low" | "medium" | "high";
export type RulesEditResponseZscoreTarget = "bits" | "packets";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchRuleResponse {
    /** The id of the rule. Must be unique. */
    id: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can't have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesEditResponsePrefixesList;
    /** MNM rule type. */
    type: RulesEditResponseType;
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number | null;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesEditResponseDuration | null;
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number | null;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesEditResponsePrefixMatch | null;
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesEditResponseZscoreSensitivity | null;
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesEditResponseZscoreTarget | null;
}
export interface PatchRuleAdvertisementRequest {
    accountId: string;
    /** The id of the rule. Must be unique. */
    ruleId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchRuleAdvertisementResponse {
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
}
export type ConfigsUpdateRequestRouterIpsList = Array<string>;
export type ConfigsUpdateRequestWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export type ConfigsUpdateRequestWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
export interface UpdateConfigRequest {
    accountId: string;
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps?: ConfigsUpdateRequestRouterIpsList;
    warpDevices?: ConfigsUpdateRequestWarpDevicesList;
}
export type ConfigsUpdateResponseRouterIpsList = Array<string>;
export type ConfigsUpdateResponseWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export type ConfigsUpdateResponseWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateConfigResponse {
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps: ConfigsUpdateResponseRouterIpsList;
    warpDevices: ConfigsUpdateResponseWarpDevicesList;
}
export type RulesUpdateRequestPrefixesList = Array<string>;
export type RulesUpdateRequestType = "threshold" | "zscore" | "advanced_ddos";
export type RulesUpdateRequestDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export type RulesUpdateRequestPrefixMatch = "exact" | "subnet" | "supernet";
export type RulesUpdateRequestZscoreSensitivity = "low" | "medium" | "high";
export type RulesUpdateRequestZscoreTarget = "bits" | "packets";
export interface UpdateRuleRequest {
    accountId: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can't have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesUpdateRequestPrefixesList;
    /** MNM rule type. */
    type: RulesUpdateRequestType | (string & {});
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesUpdateRequestDuration | (string & {});
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesUpdateRequestPrefixMatch | (string & {});
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesUpdateRequestZscoreSensitivity | (string & {});
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesUpdateRequestZscoreTarget | (string & {});
}
export type RulesUpdateResponsePrefixesList = Array<string>;
export type RulesUpdateResponseType = "threshold" | "zscore" | "advanced_ddos";
export type RulesUpdateResponseDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export type RulesUpdateResponsePrefixMatch = "exact" | "subnet" | "supernet";
export type RulesUpdateResponseZscoreSensitivity = "low" | "medium" | "high";
export type RulesUpdateResponseZscoreTarget = "bits" | "packets";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRuleResponse {
    /** The id of the rule. Must be unique. */
    id: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can't have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesUpdateResponsePrefixesList;
    /** MNM rule type. */
    type: RulesUpdateResponseType;
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number | null;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesUpdateResponseDuration | null;
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number | null;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesUpdateResponsePrefixMatch | null;
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesUpdateResponseZscoreSensitivity | null;
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesUpdateResponseZscoreTarget | null;
}
export type CreateConfigError = MnmConfigAlreadyExists | InvalidMnmConfig | Forbidden | CloudflareOpError;
/** Create a new network monitoring configuration. */
export declare const createConfig: API.OperationMethod<CreateConfigRequest, CreateConfigResponse, CreateConfigError, CloudflareOpContext>;
export type CreateRuleError = DuplicateMnmRuleName | MnmConfigMissing | Forbidden | CloudflareOpError;
/** Create network monitoring rules for account. Currently only supports creating a single rule per API request. */
export declare const createRule: API.OperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, CloudflareOpContext>;
export type CreateVpcFlowTokenError = CloudflareOpError;
/** Generate authentication token for VPC flow logs export. */
export declare const createVpcFlowToken: API.OperationMethod<CreateVpcFlowTokenRequest, CreateVpcFlowTokenResponse, CreateVpcFlowTokenError, CloudflareOpContext>;
export type DeleteConfigError = MnmConfigNotFound | Forbidden | CloudflareOpError;
/** Delete an existing network monitoring configuration. */
export declare const deleteConfig: API.OperationMethod<DeleteConfigRequest, DeleteConfigResponse, DeleteConfigError, CloudflareOpContext>;
export type DeleteRuleError = MnmRuleNotFound | Forbidden | CloudflareOpError;
/** Delete a network monitoring rule for account. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type GetConfigError = Forbidden | CloudflareOpError;
/** Lists default sampling, router IPs and warp devices for account. */
export declare const getConfig: API.OperationMethod<GetConfigRequest, GetConfigResponse, GetConfigError, CloudflareOpContext>;
export type GetConfigFullError = CloudflareOpError;
/** Lists default sampling, router IPs, warp devices, and rules for account. */
export declare const getConfigFull: API.OperationMethod<GetConfigFullRequest, GetConfigFullResponse, GetConfigFullError, CloudflareOpContext>;
export type GetRuleError = MnmRuleNotFound | Forbidden | CloudflareOpError;
/** List a single network monitoring rule for account. */
export declare const getRule: API.OperationMethod<GetRuleRequest, GetRuleResponse, GetRuleError, CloudflareOpContext>;
export type ListRulesError = Forbidden | CloudflareOpError;
/** Lists network monitoring rules for account. */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext, RulesListResultItem>;
export type PatchConfigError = CloudflareOpError;
/** Update fields in an existing network monitoring configuration. */
export declare const patchConfig: API.OperationMethod<PatchConfigRequest, PatchConfigResponse, PatchConfigError, CloudflareOpContext>;
export type PatchRuleError = MnmRuleNotFound | Forbidden | CloudflareOpError;
/** Update a network monitoring rule for account. */
export declare const patchRule: API.OperationMethod<PatchRuleRequest, PatchRuleResponse, PatchRuleError, CloudflareOpContext>;
export type PatchRuleAdvertisementError = CloudflareOpError;
/** Update advertisement for rule. */
export declare const patchRuleAdvertisement: API.OperationMethod<PatchRuleAdvertisementRequest, PatchRuleAdvertisementResponse, PatchRuleAdvertisementError, CloudflareOpContext>;
export type UpdateConfigError = Forbidden | InvalidMnmConfig | CloudflareOpError;
/** Update an existing network monitoring configuration, requires the entire configuration to be updated at once. */
export declare const updateConfig: API.OperationMethod<UpdateConfigRequest, UpdateConfigResponse, UpdateConfigError, CloudflareOpContext>;
export type UpdateRuleError = CloudflareOpError;
/** Update network monitoring rules for account. */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, CloudflareOpContext>;
//# sourceMappingURL=magic_network_monitoring.d.ts.map