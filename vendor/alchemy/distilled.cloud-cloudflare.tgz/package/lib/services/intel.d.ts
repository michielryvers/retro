import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const IndicatorFeedNotFound_base: S.TaggedErrorClass<"IndicatorFeedNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class IndicatorFeedNotFound extends /*@__PURE__*/ IndicatorFeedNotFound_base {
}
declare const IndicatorFeedsNotEntitled_base: S.TaggedErrorClass<"IndicatorFeedsNotEntitled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class IndicatorFeedsNotEntitled extends /*@__PURE__*/ IndicatorFeedsNotEntitled_base {
}
export type AttackSurfaceReportIssuesClassRequestIssueClassList = Array<string>;
export type AttackSurfaceReportIssuesClassRequestIssueClassNeqList = Array<string>;
export type AttackSurfaceReportIssuesClassRequestIssueTypeList = Array<string>;
export type AttackSurfaceReportIssuesClassRequestIssueTypeNeqList = Array<string>;
export type AttackSurfaceReportIssuesClassRequestProductList = Array<string>;
export type AttackSurfaceReportIssuesClassRequestProductNeqList = Array<string>;
export type AttackSurfaceReportIssuesClassRequestSeverityList = Array<string>;
export type AttackSurfaceReportIssuesClassRequestSeverityNeqList = Array<string>;
export type AttackSurfaceReportIssuesClassRequestSource = "cloudflare" | "riskrecon";
export type AttackSurfaceReportIssuesClassRequestSourceList = Array<AttackSurfaceReportIssuesClassRequestSource | (string & {})>;
export type AttackSurfaceReportIssuesClassRequestSubjectList = Array<string>;
export type AttackSurfaceReportIssuesClassRequestSubjectNeqList = Array<string>;
export interface ClassAttackSurfaceReportIssueRequest {
    /** Identifier. */
    accountId: string;
    dismissed?: boolean;
    issueClass?: AttackSurfaceReportIssuesClassRequestIssueClassList;
    issueClassNeq?: AttackSurfaceReportIssuesClassRequestIssueClassNeqList;
    issueType?: AttackSurfaceReportIssuesClassRequestIssueTypeList;
    issueTypeNeq?: AttackSurfaceReportIssuesClassRequestIssueTypeNeqList;
    product?: AttackSurfaceReportIssuesClassRequestProductList;
    productNeq?: AttackSurfaceReportIssuesClassRequestProductNeqList;
    severity?: AttackSurfaceReportIssuesClassRequestSeverityList;
    severityNeq?: AttackSurfaceReportIssuesClassRequestSeverityNeqList;
    source?: AttackSurfaceReportIssuesClassRequestSourceList;
    subject?: AttackSurfaceReportIssuesClassRequestSubjectList;
    subjectNeq?: AttackSurfaceReportIssuesClassRequestSubjectNeqList;
}
export interface AttackSurfaceReportIssuesClassResultItem {
    count?: number | null;
    value?: string | null;
}
export type AttackSurfaceReportIssuesClassResultList = Array<AttackSurfaceReportIssuesClassResultItem>;
export type ClassAttackSurfaceReportIssueResponse = AttackSurfaceReportIssuesClassResultList;
export interface CreateIndicatorFeedRequest {
    /** Identifier */
    accountId: string;
    /** The description of the example test */
    description?: string;
    /** The name of the indicator feed */
    name?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateIndicatorFeedResponse {
    /** The unique identifier for the indicator feed */
    id?: number | null;
    /** The date and time when the data entry was created */
    createdOn?: string | null;
    /** The description of the example test */
    description?: string | null;
    /** Whether the indicator feed can be attributed to a provider */
    isAttributable?: boolean | null;
    /** Whether the indicator feed can be downloaded */
    isDownloadable?: boolean | null;
    /** Whether the indicator feed is exposed to customers */
    isPublic?: boolean | null;
    /** The date and time when the data entry was last modified */
    modifiedOn?: string | null;
    /** The name of the indicator feed */
    name?: string | null;
}
export interface CreateIndicatorFeedPermissionRequest {
    /** Identifier */
    accountId: string;
    /** The Cloudflare account tag of the account to change permissions on */
    accountTag?: string;
    /** The ID of the feed to add/remove permissions on */
    feedId?: number;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateIndicatorFeedPermissionResponse {
    /** Whether the update succeeded or not */
    success?: boolean | null;
}
export type MiscategorizationsCreateRequestContentAddsList = Array<number>;
export type MiscategorizationsCreateRequestContentRemovesList = Array<number>;
export type MiscategorizationsCreateRequestIndicatorType = "domain" | "ipv4" | "ipv6" | "url";
export type MiscategorizationsCreateRequestSecurityAddsList = Array<number>;
export type MiscategorizationsCreateRequestSecurityRemovesList = Array<number>;
export interface CreateMiscategorizationRequest {
    /** Identifier. */
    accountId: string;
    /** Content category IDs to add. */
    contentAdds?: MiscategorizationsCreateRequestContentAddsList;
    /** Content category IDs to remove. */
    contentRemoves?: MiscategorizationsCreateRequestContentRemovesList;
    indicatorType?: MiscategorizationsCreateRequestIndicatorType | (string & {});
    /** Provide only if indicator_type is `ipv4` or `ipv6`. */
    ip?: string;
    /** Security category IDs to add. */
    securityAdds?: MiscategorizationsCreateRequestSecurityAddsList;
    /** Security category IDs to remove. */
    securityRemoves?: MiscategorizationsCreateRequestSecurityRemovesList;
    /** Provide only if indicator_type is `domain` or `url`. Example if indicator_type is `domain`: `example.com`. Example if indicator_type is `url`: `https://example.com/news/`. */
    url?: string;
}
export interface CreateMiscategorizationResponse {
}
export interface CreateSinkholeRequest {
    /** An identifier for the resource. */
    accountId: string;
    /** The name of the sinkhole. */
    name: string;
    /** The name of the R2 bucket to store results. Required if you want to store large request bodies in R2. */
    r2Bucket?: string;
    /** The id of the R2 instance. Required if you want to store large request bodies in R2. */
    r2Id?: string;
    /** The secret key for the R2 API token. Required if you want to store large request bodies in R2. */
    r2Secret?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSinkholeResponse {
    /** The unique identifier for the sinkhole. */
    id?: string | null;
    /** The account tag that owns this sinkhole. */
    accountTag?: string | null;
    /** The date and time when the sinkhole was created. */
    createdOn?: string | null;
    /** The date and time when the sinkhole was last modified. */
    modifiedOn?: string | null;
    /** The name of the sinkhole. */
    name?: string | null;
    /** The name of the R2 bucket to store results. */
    r2Bucket?: string | null;
    /** The id of the R2 instance. */
    r2Id?: string | null;
}
export interface CreateSinkholesIngressRequest {
    /** An identifier for the resource. */
    zoneId: string;
    sinkholeId: string;
    /** The CIDR block for the ingress rule in IPv4 or IPv6 notation (e.g., 192.0.2.0/24). Provide a Cloudflare BYOIP CIDR that your account owns. */
    cidr: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSinkholesIngressResponse {
    /** The unique identifier for the ingress rule. */
    id?: string | null;
    /** The CIDR block for the ingress rule. */
    cidr?: string | null;
    /** The date and time when the ingress rule was created. */
    createdOn?: string | null;
    /** The date and time when the ingress rule was last modified. */
    modifiedOn?: string | null;
    /** The sinkhole this ingress rule belongs to. */
    sinkholeId?: string | null;
    /** The zone tag associated with this ingress rule. */
    zoneTag?: string | null;
}
export interface DataIndicatorFeedRequest {
    /** Identifier */
    accountId: string;
    /** Indicator feed ID */
    feedId: number;
}
export interface DataIndicatorFeedResponse {
}
export interface DeleteIndicatorFeedPermissionRequest {
    /** Identifier */
    accountId: string;
    /** The Cloudflare account tag of the account to change permissions on */
    accountTag?: string;
    /** The ID of the feed to add/remove permissions on */
    feedId?: number;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteIndicatorFeedPermissionResponse {
    /** Whether the update succeeded or not */
    success?: boolean | null;
}
export interface DeleteSinkholeRequest {
    /** An identifier for the resource. */
    accountId: string;
    sinkholeId: string;
}
export type DeleteSinkholeResponse = unknown;
export interface DeleteSinkholesIngressRequest {
    /** An identifier for the resource. */
    zoneId: string;
    sinkholeId: string;
    ingressId: string;
}
export type DeleteSinkholesIngressResponse = unknown;
export interface DismissAttackSurfaceReportIssueRequest {
    /** Identifier. */
    accountId: string;
    issueId: string;
    dismiss?: boolean;
}
export interface DismissAttackSurfaceReportIssueResponse {
}
export interface GetAsnRequest {
    /** Identifier. */
    accountId: string;
    asn: string;
}
export type GetAsnResponse = unknown;
export interface GetAsnSubnetRequest {
    /** Identifier. */
    accountId: string;
    asn: string;
}
export type AsnSubnetsGetResponseSubnetsList = Array<string>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetAsnSubnetResponse {
    asn?: unknown | null;
    /** Total results returned based on your search parameters. */
    count?: number | null;
    ipCountTotal?: number | null;
    /** Current page within paginated list of results. */
    page?: number | null;
    /** Number of results per page of results. */
    perPage?: number | null;
    subnets?: AsnSubnetsGetResponseSubnetsList | null;
}
export interface GetAttackSurfaceReportIssueTypeRequest {
    /** Identifier. */
    accountId: string;
}
export type AttackSurfaceReportIssueTypesGetResultList = Array<string>;
export interface GetAttackSurfaceReportIssueTypeResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AttackSurfaceReportIssueTypesGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetDomainRequest {
    /** Identifier. */
    accountId: string;
    domain?: string;
    /** Skip DNS resolution lookups for faster response. */
    skipDns?: boolean;
    /** Skip the domain ranking lookup for faster responses. Defaults to `false` (ranking is included). Set to `true` to opt out -- primarily used by callers like Cloudflare Radar that need to avoid a circular dependency when building the domain details page. Note: the bulk endpoint (`/intel/domain/bulk`) uses opposite defaults -- see `include_ranking` there. */
    skipRanking?: boolean;
}
export interface DomainsGetResponseAdditionalInformation {
    /** Suspected DGA malware family. */
    suspectedMalwareFamily?: string | null;
}
export interface DomainsGetResponseApplication {
    id?: number | null;
    name?: string | null;
}
export interface DomainsGetResponseContentCategoriesItem {
    id?: number | null;
    name?: string | null;
    superCategoryId?: number | null;
}
export type DomainsGetResponseContentCategoriesList = Array<DomainsGetResponseContentCategoriesItem>;
export type DomainsGetResponseInheritedContentCategoriesItem = DomainsGetResponseContentCategoriesItem;
export type DomainsGetResponseInheritedContentCategoriesList = Array<DomainsGetResponseContentCategoriesItem>;
export type DomainsGetResponseInheritedRiskTypesItem = DomainsGetResponseContentCategoriesItem;
export type DomainsGetResponseInheritedRiskTypesList = Array<DomainsGetResponseContentCategoriesItem>;
export interface DomainsGetResponseResolvesToRefsItem {
    /** STIX 2.1 identifier: https://docs.oasis-open.org/cti/stix/v2.1/cs02/stix-v2.1-cs02.html#_64yvzeku5a5c. */
    id?: string | null;
    /** IP address or domain name. */
    value?: string | null;
}
export type DomainsGetResponseResolvesToRefsList = Array<DomainsGetResponseResolvesToRefsItem>;
export type DomainsGetResponseRiskTypesItem = DomainsGetResponseContentCategoriesItem;
export type DomainsGetResponseRiskTypesList = Array<DomainsGetResponseContentCategoriesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDomainResponse {
    /** Additional information related to the host name. */
    additionalInformation?: DomainsGetResponseAdditionalInformation | null;
    /** Application that the hostname belongs to. */
    application?: DomainsGetResponseApplication | null;
    contentCategories?: DomainsGetResponseContentCategoriesList | null;
    domain?: string | null;
    inheritedContentCategories?: DomainsGetResponseInheritedContentCategoriesList | null;
    /** Domain from which `inherited_content_categories` and `inherited_risk_types` are inherited, if applicable. */
    inheritedFrom?: string | null;
    inheritedRiskTypes?: DomainsGetResponseInheritedRiskTypesList | null;
    /** Global Cloudflare 100k ranking for the last 30 days, if available for the hostname. The top ranked domain is 1, the lowest ranked domain is 100,000. */
    popularityRank?: number | null;
    /** Specifies a list of references to one or more IP addresses or domain names that the domain name currently resolves to. */
    resolvesToRefs?: DomainsGetResponseResolvesToRefsList | null;
    /** Hostname risk score, which is a value between 0 (lowest risk) to 1 (highest risk). */
    riskScore?: number | null;
    riskTypes?: DomainsGetResponseRiskTypesList | null;
}
export type DomainsBulksGetRequestDomainList = Array<string>;
export interface GetDomainBulkRequest {
    /** Identifier. */
    accountId: string;
    /** Accepts multiple values like `?domain=cloudflare.com&domain=example.com`. */
    domain?: DomainsBulksGetRequestDomainList;
    /** Whether to include domain ranking data in the response. Defaults to `false` -- ranking lookups are expensive at bulk scale and most callers do not need them. Set to `true` to opt in. This parameter replaces the deprecated `skip_ranking` (see below). */
    includeRanking?: boolean;
    /** **Deprecated.** Previously controlled whether the ranking lookup was skipped (defaulted to `false`, meaning ranking ran). The endpoint's default behavior is being flipped -- ranking is now opt-in via `include_ranking=true` -- and this parameter will be silently ignored. Remove it from your callers and use `include_ranking` instead. */
    skipRanking?: boolean;
}
export type DomainsBulksGetResultItemAdditionalInformation = DomainsGetResponseAdditionalInformation;
export type DomainsBulksGetResultItemApplication = DomainsGetResponseApplication;
export type DomainsBulksGetResultItemContentCategoriesItem = DomainsGetResponseContentCategoriesItem;
export type DomainsBulksGetResultItemContentCategoriesList = Array<DomainsGetResponseContentCategoriesItem>;
export type DomainsBulksGetResultItemInheritedContentCategoriesItem = DomainsGetResponseContentCategoriesItem;
export type DomainsBulksGetResultItemInheritedContentCategoriesList = Array<DomainsGetResponseContentCategoriesItem>;
export type DomainsBulksGetResultItemInheritedRiskTypesItem = DomainsGetResponseContentCategoriesItem;
export type DomainsBulksGetResultItemInheritedRiskTypesList = Array<DomainsGetResponseContentCategoriesItem>;
export type DomainsBulksGetResultItemRiskTypesItem = DomainsGetResponseContentCategoriesItem;
export type DomainsBulksGetResultItemRiskTypesList = Array<DomainsGetResponseContentCategoriesItem>;
export interface DomainsBulksGetResultItem {
    /** Additional information related to the host name. */
    additionalInformation?: DomainsGetResponseAdditionalInformation | null;
    /** Application that the hostname belongs to. */
    application?: DomainsGetResponseApplication | null;
    contentCategories?: DomainsBulksGetResultItemContentCategoriesList | null;
    domain?: string | null;
    inheritedContentCategories?: DomainsBulksGetResultItemInheritedContentCategoriesList | null;
    /** Domain from which `inherited_content_categories` and `inherited_risk_types` are inherited, if applicable. */
    inheritedFrom?: string | null;
    inheritedRiskTypes?: DomainsBulksGetResultItemInheritedRiskTypesList | null;
    /** Global Cloudflare 100k ranking for the last 30 days, if available for the hostname. The top ranked domain is 1, the lowest ranked domain is 100,000. */
    popularityRank?: number | null;
    /** Hostname risk score, which is a value between 0 (lowest risk) to 1 (highest risk). */
    riskScore?: number | null;
    riskTypes?: DomainsBulksGetResultItemRiskTypesList | null;
}
export type DomainsBulksGetResultList = Array<DomainsBulksGetResultItem>;
export type GetDomainBulkResponse = DomainsBulksGetResultList;
export interface GetDomainHistoryRequest {
    /** Identifier. */
    accountId: string;
    domain?: string;
}
export type DomainHistoryGetResultItemCategorizationsItemCategoriesItem = DomainsGetResponseApplication;
export type DomainHistoryGetResultItemCategorizationsItemCategoriesList = Array<DomainsGetResponseApplication>;
export interface DomainHistoryGetResultItemCategorizationsItem {
    categories?: DomainHistoryGetResultItemCategorizationsItemCategoriesList | null;
    end?: string | null;
    start?: string | null;
}
export type DomainHistoryGetResultItemCategorizationsList = Array<DomainHistoryGetResultItemCategorizationsItem>;
export interface DomainHistoryGetResultItem {
    categorizations?: DomainHistoryGetResultItemCategorizationsList | null;
    domain?: string | null;
}
export type DomainHistoryGetResultList = Array<DomainHistoryGetResultItem>;
export type GetDomainHistoryResponse = DomainHistoryGetResultList;
export interface GetIndicatorFeedRequest {
    /** Identifier */
    accountId: string;
    /** Indicator feed ID */
    feedId: number;
}
export interface IndicatorFeedsGetResponseLastUploadSummaryPersisted {
    domainsAdded?: number | null;
    domainsRemoved?: number | null;
    ipsAdded?: number | null;
    ipsRemoved?: number | null;
    urlsAdded?: number | null;
    urlsRemoved?: number | null;
}
export interface IndicatorFeedsGetResponseLastUploadSummarySkipped {
    /** Domains filtered by the global popularity allowlist at QS provisioning time. Popular domains (bing.com, naver.com, etc.) are protected from custom-threat-feed enforcement. */
    allowlistedDomains?: number | null;
    /** Indicators in the upload whose valid_until is already in the past. These are not added to QS; the expiration cron handles cleanup. */
    expiredIndicators?: number | null;
    /** Reserved for future use. Currently always 0 -- the unifier aborts the entire upload on a single bad indicator. */
    invalidIndicators?: number | null;
}
export interface IndicatorFeedsGetResponseLastUploadSummaryUploaded {
    /** Number of domain indicators in the upload */
    domains?: number | null;
    /** Number of IP indicators in the upload */
    ips?: number | null;
    /** Number of URL indicators in the upload */
    urls?: number | null;
}
export interface IndicatorFeedsGetResponseLastUploadSummary {
    /** Net delta applied to feed indicators by this upload. Snapshot uploads emit both *_added and *_removed; delta-add emits only *_added; delta-remove emits only *_removed. */
    persisted?: IndicatorFeedsGetResponseLastUploadSummaryPersisted | null;
    /** Counts of indicators that were uploaded but did not reach QuickSilver, broken down by reason. */
    skipped?: IndicatorFeedsGetResponseLastUploadSummarySkipped | null;
    /** Indicator counts from the unified file the loader received */
    uploaded?: IndicatorFeedsGetResponseLastUploadSummaryUploaded | null;
}
export type IndicatorFeedsGetResponseLatestUploadStatus = "Mirroring" | "Unifying" | "Loading" | "Provisioning" | "Complete" | "Error";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetIndicatorFeedResponse {
    /** The unique identifier for the indicator feed */
    id?: number | null;
    /** The date and time when the data entry was created */
    createdOn?: string | null;
    /** The description of the example test */
    description?: string | null;
    /** Whether the indicator feed can be attributed to a provider */
    isAttributable?: boolean | null;
    /** Whether the indicator feed can be downloaded */
    isDownloadable?: boolean | null;
    /** Whether the indicator feed is exposed to customers */
    isPublic?: boolean | null;
    /** Summary of indicator counts from the last successful upload to this feed. Populated by the custom-threat-feeds loader at the end of each successful load. Absent (omitted) when no upload has completed successfully or the upload errored before the summary write. Surfaces silent-failure paths so operators can see when their indicators were dropped (popularity allowlist, expired valid_until, etc.) without reading loader logs. */
    lastUploadSummary?: IndicatorFeedsGetResponseLastUploadSummary | null;
    /** Human-readable error message describing why the latest upload failed. Populated only when `latest_upload_status` is `Error`. Returns one of a small fixed set of category-level messages (invalid domain / IP / URL entries, malformed row or header, invalid valid_until timestamp, etc.) or the generic `Upload failed` for unknown or infrastructure-level errors. Never echoes raw error text from the underlying loader. Intel accounts receive the verbatim loader/API error text (including specific offending values) instead of these category-level messages. */
    latestUploadError?: string | null;
    /** Status of the latest snapshot uploaded */
    latestUploadStatus?: IndicatorFeedsGetResponseLatestUploadStatus | null;
    /** The date and time when the data entry was last modified */
    modifiedOn?: string | null;
    /** The name of the indicator feed */
    name?: string | null;
    /** The unique identifier for the provider */
    providerId?: number | null;
    /** The provider of the indicator feed */
    providerName?: string | null;
}
export interface GetIpRequest {
    /** Identifier. */
    accountId: string;
    ipv4?: string;
    ipv6?: string;
}
export type IpsGetResultItemBelongsToRefType = "hosting_provider" | "isp" | "organization";
export interface IpsGetResultItemBelongsToRef {
    id?: string | null;
    country?: string | null;
    description?: string | null;
    /** Infrastructure type of this ASN. */
    type?: IpsGetResultItemBelongsToRefType | null;
    value?: string | null;
}
export type IpsGetResultItemRiskTypesItem = DomainsGetResponseContentCategoriesItem;
export type IpsGetResultItemRiskTypesList = Array<DomainsGetResponseContentCategoriesItem>;
export interface IpsGetResultItem {
    /** Specifies a reference to the autonomous systems (AS) that the IP address belongs to. */
    belongsToRef?: IpsGetResultItemBelongsToRef | null;
    ip?: string | null;
    riskTypes?: IpsGetResultItemRiskTypesList | null;
}
export type IpsGetResultList = Array<IpsGetResultItem>;
export type GetIpResponse = IpsGetResultList;
export interface GetSinkholeRequest {
    /** An identifier for the resource. */
    accountId: string;
    sinkholeId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSinkholeResponse {
    /** The unique identifier for the sinkhole. */
    id?: string | null;
    /** The account tag that owns this sinkhole. */
    accountTag?: string | null;
    /** The date and time when the sinkhole was created. */
    createdOn?: string | null;
    /** The date and time when the sinkhole was last modified. */
    modifiedOn?: string | null;
    /** The name of the sinkhole. */
    name?: string | null;
    /** The name of the R2 bucket to store results. */
    r2Bucket?: string | null;
    /** The id of the R2 instance. */
    r2Id?: string | null;
}
export interface GetSinkholesIngressRequest {
    /** An identifier for the resource. */
    zoneId: string;
    sinkholeId: string;
    ingressId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSinkholesIngressResponse {
    /** The unique identifier for the ingress rule. */
    id?: string | null;
    /** The CIDR block for the ingress rule. */
    cidr?: string | null;
    /** The date and time when the ingress rule was created. */
    createdOn?: string | null;
    /** The date and time when the ingress rule was last modified. */
    modifiedOn?: string | null;
    /** The sinkhole this ingress rule belongs to. */
    sinkholeId?: string | null;
    /** The zone tag associated with this ingress rule. */
    zoneTag?: string | null;
}
export interface GetUrlRequest {
    /** Identifier. */
    accountId: string;
    /** The URL to look up. */
    url: string;
}
export interface GetUrlResponseContentCategoriesItem {
    id?: number | null;
    name?: string | null;
    sourceId?: number | null;
    superCategoryId?: number | null;
}
export type GetUrlResponseContentCategoriesList = Array<GetUrlResponseContentCategoriesItem>;
export type GetUrlResponseRiskTypeItem = GetUrlResponseContentCategoriesItem;
export type GetUrlResponseRiskTypeList = Array<GetUrlResponseContentCategoriesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUrlResponse {
    /** Content categories associated with this URL. */
    contentCategories: GetUrlResponseContentCategoriesList;
    /** The full URL that was looked up. */
    fullUrl: string;
    /** The hostname of the URL. */
    hostname: string;
    /** Security risk types associated with this URL. */
    riskType: GetUrlResponseRiskTypeList;
    /** The path component of the URL. */
    urlPath: string;
}
export interface GetWhoiRequest {
    /** Use to uniquely identify or reference the resource. */
    accountId: string;
    domain?: string;
}
export type WhoisGetResponseNameserversList = Array<string>;
export type WhoisGetResponseStatusList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetWhoiResponse {
    dnssec: boolean;
    domain: string;
    extension: string;
    found: boolean;
    nameservers: WhoisGetResponseNameserversList;
    punycode: string;
    registrant: string;
    registrar: string;
    id?: string | null;
    administrativeCity?: string | null;
    administrativeCountry?: string | null;
    administrativeEmail?: string | null;
    administrativeFax?: string | null;
    administrativeFaxExt?: string | null;
    administrativeId?: string | null;
    administrativeName?: string | null;
    administrativeOrg?: string | null;
    administrativePhone?: string | null;
    administrativePhoneExt?: string | null;
    administrativePostalCode?: string | null;
    administrativeProvince?: string | null;
    administrativeReferralUrl?: string | null;
    administrativeStreet?: string | null;
    billingCity?: string | null;
    billingCountry?: string | null;
    billingEmail?: string | null;
    billingFax?: string | null;
    billingFaxExt?: string | null;
    billingId?: string | null;
    billingName?: string | null;
    billingOrg?: string | null;
    billingPhone?: string | null;
    billingPhoneExt?: string | null;
    billingPostalCode?: string | null;
    billingProvince?: string | null;
    billingReferralUrl?: string | null;
    billingStreet?: string | null;
    createdDate?: string | null;
    createdDateRaw?: string | null;
    expirationDate?: string | null;
    expirationDateRaw?: string | null;
    registrantCity?: string | null;
    registrantCountry?: string | null;
    registrantEmail?: string | null;
    registrantFax?: string | null;
    registrantFaxExt?: string | null;
    registrantId?: string | null;
    registrantName?: string | null;
    registrantOrg?: string | null;
    registrantPhone?: string | null;
    registrantPhoneExt?: string | null;
    registrantPostalCode?: string | null;
    registrantProvince?: string | null;
    registrantReferralUrl?: string | null;
    registrantStreet?: string | null;
    registrarCity?: string | null;
    registrarCountry?: string | null;
    registrarEmail?: string | null;
    registrarFax?: string | null;
    registrarFaxExt?: string | null;
    registrarId?: string | null;
    registrarName?: string | null;
    registrarOrg?: string | null;
    registrarPhone?: string | null;
    registrarPhoneExt?: string | null;
    registrarPostalCode?: string | null;
    registrarProvince?: string | null;
    registrarReferralUrl?: string | null;
    registrarStreet?: string | null;
    status?: WhoisGetResponseStatusList | null;
    technicalCity?: string | null;
    technicalCountry?: string | null;
    technicalEmail?: string | null;
    technicalFax?: string | null;
    technicalFaxExt?: string | null;
    technicalId?: string | null;
    technicalName?: string | null;
    technicalOrg?: string | null;
    technicalPhone?: string | null;
    technicalPhoneExt?: string | null;
    technicalPostalCode?: string | null;
    technicalProvince?: string | null;
    technicalReferralUrl?: string | null;
    technicalStreet?: string | null;
    updatedDate?: string | null;
    updatedDateRaw?: string | null;
    whoisServer?: string | null;
}
export type AttackSurfaceReportIssuesListRequestIssueClassList = Array<string>;
export type AttackSurfaceReportIssuesListRequestIssueClassNeqList = Array<string>;
export type AttackSurfaceReportIssuesListRequestIssueTypeList = Array<string>;
export type AttackSurfaceReportIssuesListRequestIssueTypeNeqList = Array<string>;
export type AttackSurfaceReportIssuesListRequestProductList = Array<string>;
export type AttackSurfaceReportIssuesListRequestProductNeqList = Array<string>;
export type AttackSurfaceReportIssuesListRequestSeverityList = Array<string>;
export type AttackSurfaceReportIssuesListRequestSeverityNeqList = Array<string>;
export type AttackSurfaceReportIssuesListRequestSource = "cloudflare" | "riskrecon";
export type AttackSurfaceReportIssuesListRequestSourceList = Array<AttackSurfaceReportIssuesListRequestSource | (string & {})>;
export type AttackSurfaceReportIssuesListRequestSubjectList = Array<string>;
export type AttackSurfaceReportIssuesListRequestSubjectNeqList = Array<string>;
export interface ListAttackSurfaceReportIssuesRequest {
    /** Identifier. */
    accountId: string;
    dismissed?: boolean;
    issueClass?: AttackSurfaceReportIssuesListRequestIssueClassList;
    issueClassNeq?: AttackSurfaceReportIssuesListRequestIssueClassNeqList;
    issueType?: AttackSurfaceReportIssuesListRequestIssueTypeList;
    issueTypeNeq?: AttackSurfaceReportIssuesListRequestIssueTypeNeqList;
    /** Specifies the current page within paginated list of results. */
    page?: number;
    /** Sets the number of results per page of results. */
    perPage?: number;
    product?: AttackSurfaceReportIssuesListRequestProductList;
    productNeq?: AttackSurfaceReportIssuesListRequestProductNeqList;
    severity?: AttackSurfaceReportIssuesListRequestSeverityList;
    severityNeq?: AttackSurfaceReportIssuesListRequestSeverityNeqList;
    source?: AttackSurfaceReportIssuesListRequestSourceList;
    subject?: AttackSurfaceReportIssuesListRequestSubjectList;
    subjectNeq?: AttackSurfaceReportIssuesListRequestSubjectNeqList;
}
export type AttackSurfaceReportIssuesListResponseIssuesItemIssueType = "compliance_violation" | "email_security" | "exposed_infrastructure" | "insecure_configuration" | "weak_authentication" | "configuration_suggestion";
export interface AttackSurfaceReportIssuesListResponseIssuesItemPayload {
    /** Describes the method used to detect insight. */
    detectionMethod?: string | null;
    zoneTag?: string | null;
}
export type AttackSurfaceReportIssuesListResponseIssuesItemSeverity = "Low" | "Moderate" | "Critical";
export type AttackSurfaceReportIssuesListResponseIssuesItemSource = "cloudflare" | "riskrecon";
export type AttackSurfaceReportIssuesListResponseIssuesItemStatus = "active" | "resolved";
export type AttackSurfaceReportIssuesListResponseIssuesItemUserClassification = "false_positive" | "accept_risk" | "other";
export interface AttackSurfaceReportIssuesListResponseIssuesItem {
    id?: string | null;
    dismissed?: boolean | null;
    /** Indicates whether the insight has a large payload that requires fetching via the context endpoint. */
    hasExtendedContext?: boolean | null;
    issueClass?: string | null;
    issueType?: AttackSurfaceReportIssuesListResponseIssuesItemIssueType | null;
    payload?: AttackSurfaceReportIssuesListResponseIssuesItemPayload | null;
    resolveLink?: string | null;
    resolveText?: string | null;
    severity?: AttackSurfaceReportIssuesListResponseIssuesItemSeverity | null;
    since?: string | null;
    /** Who generated the insight. `cloudflare` for Cloudflare-generated insights, otherwise the partner. */
    source?: AttackSurfaceReportIssuesListResponseIssuesItemSource | null;
    /** The current status of the insight. */
    status?: AttackSurfaceReportIssuesListResponseIssuesItemStatus | null;
    subject?: string | null;
    timestamp?: string | null;
    /** User-defined classification for the insight. Can be 'false_positive', 'accept_risk', 'other', or null. */
    userClassification?: AttackSurfaceReportIssuesListResponseIssuesItemUserClassification | null;
}
export type AttackSurfaceReportIssuesListResponseIssuesList = Array<AttackSurfaceReportIssuesListResponseIssuesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListAttackSurfaceReportIssuesResponse {
    /** Indicates the total number of results. */
    count?: number | null;
    issues?: AttackSurfaceReportIssuesListResponseIssuesList | null;
    /** Specifies the current page within paginated list of results. */
    page?: number | null;
    /** Sets the number of results per page of results. */
    perPage?: number | null;
}
export interface DnsListRequestStartEndParams {
    /** Defaults to the current date. */
    end?: string;
    /** Defaults to 30 days before the end parameter value. */
    start?: string;
}
export interface ListDnsRequest {
    /** Identifier. */
    accountId: string;
    ipv4?: string;
    /** Requested page within paginated list of results. */
    page?: number;
    /** Maximum number of results requested. */
    perPage?: number;
    startEndParams?: DnsListRequestStartEndParams;
}
export interface DnsListResponseReverseRecordsItem {
    /** First seen date of the DNS record during the time period. */
    firstSeen?: string | null;
    /** Hostname that the IP was observed resolving to. */
    hostname?: string | null;
    /** Last seen date of the DNS record during the time period. */
    lastSeen?: string | null;
}
export type DnsListResponseReverseRecordsList = Array<DnsListResponseReverseRecordsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListDnsResponse {
    /** Total results returned based on your search parameters. */
    count?: number | null;
    /** Current page within paginated list of results. */
    page?: number | null;
    /** Number of results per page of results. */
    perPage?: number | null;
    /** Reverse DNS look-ups observed during the time period. */
    reverseRecords?: DnsListResponseReverseRecordsList | null;
}
export interface ListIndicatorFeedPermissionsRequest {
    /** Identifier */
    accountId: string;
}
export interface IndicatorFeedsPermissionsListResultItem {
    /** The unique identifier for the indicator feed */
    id?: number | null;
    /** The description of the example test */
    description?: string | null;
    /** Whether the indicator feed can be attributed to a provider */
    isAttributable?: boolean | null;
    /** Whether the indicator feed can be downloaded */
    isDownloadable?: boolean | null;
    /** Whether the indicator feed is exposed to customers */
    isPublic?: boolean | null;
    /** The name of the indicator feed */
    name?: string | null;
}
export type IndicatorFeedsPermissionsListResultList = Array<IndicatorFeedsPermissionsListResultItem>;
export type ListIndicatorFeedPermissionsResponse = IndicatorFeedsPermissionsListResultList;
export interface ListIndicatorFeedsRequest {
    /** Identifier */
    accountId: string;
}
export interface IndicatorFeedsListResultItem {
    /** The unique identifier for the indicator feed */
    id?: number | null;
    /** The date and time when the data entry was created */
    createdOn?: string | null;
    /** The description of the example test */
    description?: string | null;
    /** Whether the indicator feed can be attributed to a provider */
    isAttributable?: boolean | null;
    /** Whether the indicator feed can be downloaded */
    isDownloadable?: boolean | null;
    /** Whether the indicator feed is exposed to customers */
    isPublic?: boolean | null;
    /** The date and time when the data entry was last modified */
    modifiedOn?: string | null;
    /** The name of the indicator feed */
    name?: string | null;
}
export type IndicatorFeedsListResultList = Array<IndicatorFeedsListResultItem>;
export interface ListIndicatorFeedsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: IndicatorFeedsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListSinkholesRequest {
    /** An identifier for the resource. */
    accountId: string;
}
export interface SinkholesListResultItem {
    /** The unique identifier for the sinkhole. */
    id?: string | null;
    /** The account tag that owns this sinkhole. */
    accountTag?: string | null;
    /** The date and time when the sinkhole was created. */
    createdOn?: string | null;
    /** The date and time when the sinkhole was last modified. */
    modifiedOn?: string | null;
    /** The name of the sinkhole. */
    name?: string | null;
    /** The name of the R2 bucket to store results. */
    r2Bucket?: string | null;
    /** The id of the R2 instance. */
    r2Id?: string | null;
}
export type SinkholesListResultList = Array<SinkholesListResultItem>;
export interface ListSinkholesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SinkholesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type IndicatorFeedsSnapshotsUpdateRequestCfAsyncUpload = "1";
export interface PutIndicatorFeedSnapshotRequest {
    /** Identifier */
    accountId: string;
    /** Indicator feed ID */
    feedId: number;
    cfAsyncUpload?: IndicatorFeedsSnapshotsUpdateRequestCfAsyncUpload | (string & {});
    /** The file to upload. Either a plain STIX2/CRDF body or a gzipped one (recognised by 0x1f 0x8b magic bytes or a .gz filename suffix). */
    source?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutIndicatorFeedSnapshotResponse {
    /** Feed id */
    fileId?: number | null;
    /** Name of the file unified in our system */
    filename?: string | null;
    /** Account-relative polling path. Prepend `/accounts/{account_id}` using the same account identifier and API host as the upload request. The path omits the account segment because the service does not have your account identifier in this context. */
    pollUrl?: string | null;
    /** Current status of the upload at the moment the request returned. This is NOT a terminal state: the file is unified inline, but the durable loader has only accepted it, so the upload is still `Unifying`. Poll `poll_url` until the status reaches a terminal value (`Unified` or `Error`). */
    status?: string | null;
    /** Identifier of the upload row, for polling this upload to a terminal state via `poll_url`. */
    uploadId?: number | null;
}
export type AttackSurfaceReportIssuesSeverityRequestIssueClassList = Array<string>;
export type AttackSurfaceReportIssuesSeverityRequestIssueClassNeqList = Array<string>;
export type AttackSurfaceReportIssuesSeverityRequestIssueTypeList = Array<string>;
export type AttackSurfaceReportIssuesSeverityRequestIssueTypeNeqList = Array<string>;
export type AttackSurfaceReportIssuesSeverityRequestProductList = Array<string>;
export type AttackSurfaceReportIssuesSeverityRequestProductNeqList = Array<string>;
export type AttackSurfaceReportIssuesSeverityRequestSeverityList = Array<string>;
export type AttackSurfaceReportIssuesSeverityRequestSeverityNeqList = Array<string>;
export type AttackSurfaceReportIssuesSeverityRequestSource = "cloudflare" | "riskrecon";
export type AttackSurfaceReportIssuesSeverityRequestSourceList = Array<AttackSurfaceReportIssuesSeverityRequestSource | (string & {})>;
export type AttackSurfaceReportIssuesSeverityRequestSubjectList = Array<string>;
export type AttackSurfaceReportIssuesSeverityRequestSubjectNeqList = Array<string>;
export interface SeverityAttackSurfaceReportIssueRequest {
    /** Identifier. */
    accountId: string;
    dismissed?: boolean;
    issueClass?: AttackSurfaceReportIssuesSeverityRequestIssueClassList;
    issueClassNeq?: AttackSurfaceReportIssuesSeverityRequestIssueClassNeqList;
    issueType?: AttackSurfaceReportIssuesSeverityRequestIssueTypeList;
    issueTypeNeq?: AttackSurfaceReportIssuesSeverityRequestIssueTypeNeqList;
    product?: AttackSurfaceReportIssuesSeverityRequestProductList;
    productNeq?: AttackSurfaceReportIssuesSeverityRequestProductNeqList;
    severity?: AttackSurfaceReportIssuesSeverityRequestSeverityList;
    severityNeq?: AttackSurfaceReportIssuesSeverityRequestSeverityNeqList;
    source?: AttackSurfaceReportIssuesSeverityRequestSourceList;
    subject?: AttackSurfaceReportIssuesSeverityRequestSubjectList;
    subjectNeq?: AttackSurfaceReportIssuesSeverityRequestSubjectNeqList;
}
export type AttackSurfaceReportIssuesSeverityResultItem = AttackSurfaceReportIssuesClassResultItem;
export type AttackSurfaceReportIssuesSeverityResultList = Array<AttackSurfaceReportIssuesClassResultItem>;
export type SeverityAttackSurfaceReportIssueResponse = AttackSurfaceReportIssuesSeverityResultList;
export type AttackSurfaceReportIssuesTypeRequestIssueClassList = Array<string>;
export type AttackSurfaceReportIssuesTypeRequestIssueClassNeqList = Array<string>;
export type AttackSurfaceReportIssuesTypeRequestIssueTypeList = Array<string>;
export type AttackSurfaceReportIssuesTypeRequestIssueTypeNeqList = Array<string>;
export type AttackSurfaceReportIssuesTypeRequestProductList = Array<string>;
export type AttackSurfaceReportIssuesTypeRequestProductNeqList = Array<string>;
export type AttackSurfaceReportIssuesTypeRequestSeverityList = Array<string>;
export type AttackSurfaceReportIssuesTypeRequestSeverityNeqList = Array<string>;
export type AttackSurfaceReportIssuesTypeRequestSource = "cloudflare" | "riskrecon";
export type AttackSurfaceReportIssuesTypeRequestSourceList = Array<AttackSurfaceReportIssuesTypeRequestSource | (string & {})>;
export type AttackSurfaceReportIssuesTypeRequestSubjectList = Array<string>;
export type AttackSurfaceReportIssuesTypeRequestSubjectNeqList = Array<string>;
export interface TypeAttackSurfaceReportIssueRequest {
    /** Identifier. */
    accountId: string;
    dismissed?: boolean;
    issueClass?: AttackSurfaceReportIssuesTypeRequestIssueClassList;
    issueClassNeq?: AttackSurfaceReportIssuesTypeRequestIssueClassNeqList;
    issueType?: AttackSurfaceReportIssuesTypeRequestIssueTypeList;
    issueTypeNeq?: AttackSurfaceReportIssuesTypeRequestIssueTypeNeqList;
    product?: AttackSurfaceReportIssuesTypeRequestProductList;
    productNeq?: AttackSurfaceReportIssuesTypeRequestProductNeqList;
    severity?: AttackSurfaceReportIssuesTypeRequestSeverityList;
    severityNeq?: AttackSurfaceReportIssuesTypeRequestSeverityNeqList;
    source?: AttackSurfaceReportIssuesTypeRequestSourceList;
    subject?: AttackSurfaceReportIssuesTypeRequestSubjectList;
    subjectNeq?: AttackSurfaceReportIssuesTypeRequestSubjectNeqList;
}
export type AttackSurfaceReportIssuesTypeResultItem = AttackSurfaceReportIssuesClassResultItem;
export type AttackSurfaceReportIssuesTypeResultList = Array<AttackSurfaceReportIssuesClassResultItem>;
export type TypeAttackSurfaceReportIssueResponse = AttackSurfaceReportIssuesTypeResultList;
export interface UpdateIndicatorFeedRequest {
    /** Identifier */
    accountId: string;
    /** Indicator feed ID */
    feedId: number;
    /** The new description of the feed */
    description?: string;
    /** The new is_attributable value of the feed */
    isAttributable?: boolean;
    /** The new is_downloadable value of the feed */
    isDownloadable?: boolean;
    /** The new is_public value of the feed */
    isPublic?: boolean;
    /** The new name of the feed */
    name?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateIndicatorFeedResponse {
    /** The unique identifier for the indicator feed */
    id?: number | null;
    /** The date and time when the data entry was created */
    createdOn?: string | null;
    /** The description of the example test */
    description?: string | null;
    /** Whether the indicator feed can be attributed to a provider */
    isAttributable?: boolean | null;
    /** Whether the indicator feed can be downloaded */
    isDownloadable?: boolean | null;
    /** Whether the indicator feed is exposed to customers */
    isPublic?: boolean | null;
    /** The date and time when the data entry was last modified */
    modifiedOn?: string | null;
    /** The name of the indicator feed */
    name?: string | null;
}
export interface UpdateSinkholeRequest {
    /** An identifier for the resource. */
    accountId: string;
    sinkholeId: string;
    /** The name of the sinkhole. */
    name: string;
    /** The name of the R2 bucket to store results. Required if you want to store large request bodies in R2. */
    r2Bucket?: string;
    /** The id of the R2 instance. Required if you want to store large request bodies in R2. */
    r2Id?: string;
    /** The secret key for the R2 API token. Required if you want to store large request bodies in R2. */
    r2Secret?: string;
}
export type UpdateSinkholeResponse = unknown;
export interface UpdateSinkholesIngressRequest {
    /** An identifier for the resource. */
    zoneId: string;
    sinkholeId: string;
    ingressId: string;
    /** The CIDR block for the ingress rule in IPv4 or IPv6 notation (e.g., 192.0.2.0/24). Provide a Cloudflare BYOIP CIDR that your account owns. */
    cidr: string;
}
export type UpdateSinkholesIngressResponse = unknown;
export type ClassAttackSurfaceReportIssueError = CloudflareOpError;
/** Retrieves Security Center issue counts aggregated by classification class. */
export declare const classAttackSurfaceReportIssue: API.OperationMethod<ClassAttackSurfaceReportIssueRequest, ClassAttackSurfaceReportIssueResponse, ClassAttackSurfaceReportIssueError, CloudflareOpContext>;
export type CreateIndicatorFeedError = IndicatorFeedsNotEntitled | Forbidden | CloudflareOpError;
/** Creates a new custom threat indicator feed for sharing threat intelligence data. */
export declare const createIndicatorFeed: API.OperationMethod<CreateIndicatorFeedRequest, CreateIndicatorFeedResponse, CreateIndicatorFeedError, CloudflareOpContext>;
export type CreateIndicatorFeedPermissionError = IndicatorFeedNotFound | Forbidden | CloudflareOpError;
/** Grants access permissions for a custom threat indicator feed to other accounts. */
export declare const createIndicatorFeedPermission: API.OperationMethod<CreateIndicatorFeedPermissionRequest, CreateIndicatorFeedPermissionResponse, CreateIndicatorFeedPermissionError, CloudflareOpContext>;
export type CreateMiscategorizationError = CloudflareOpError;
/** Allows you to submit requests to change a domain's category. Requests that include category `169` (New Domains) or category `177` (Newly Seen) in any of `content_adds`, `content_removes`, `security_adds`, or `security_removes` will be rejected with a `400 Bad Request`. These categories are automatically managed and fall off 30 days after they are applied. */
export declare const createMiscategorization: API.OperationMethod<CreateMiscategorizationRequest, CreateMiscategorizationResponse, CreateMiscategorizationError, CloudflareOpContext>;
export type CreateSinkholeError = CloudflareOpError;
/** Create a new sinkhole. Logs of large request bodies will be truncated, but the full request body can be recorded in R2. If you wish to record large request bodies in R2, include the R2 key ID, key secret, and bucket name in the request body. */
export declare const createSinkhole: API.OperationMethod<CreateSinkholeRequest, CreateSinkholeResponse, CreateSinkholeError, CloudflareOpContext>;
export type CreateSinkholesIngressError = CloudflareOpError;
/** Create a new ingress rule for the specified sinkhole. The CIDR block must be a Cloudflare BYOIP associated with your account. The zone_id must be a zone with the ability to create Spectrum Apps. The sinkhole must belong to the same account as the zone. */
export declare const createSinkholesIngress: API.OperationMethod<CreateSinkholesIngressRequest, CreateSinkholesIngressResponse, CreateSinkholesIngressError, CloudflareOpContext>;
export type DataIndicatorFeedError = CloudflareOpError;
/** Retrieves the raw data entries in a custom threat indicator feed. */
export declare const dataIndicatorFeed: API.OperationMethod<DataIndicatorFeedRequest, DataIndicatorFeedResponse, DataIndicatorFeedError, CloudflareOpContext>;
export type DeleteIndicatorFeedPermissionError = IndicatorFeedNotFound | Forbidden | CloudflareOpError;
/** Revokes access permissions for a custom threat indicator feed. */
export declare const deleteIndicatorFeedPermission: API.OperationMethod<DeleteIndicatorFeedPermissionRequest, DeleteIndicatorFeedPermissionResponse, DeleteIndicatorFeedPermissionError, CloudflareOpContext>;
export type DeleteSinkholeError = CloudflareOpError;
/** Delete the specified sinkhole. The sinkhole must not have any active ingress rules defined. A 409 response code indicates that this condition is not met. */
export declare const deleteSinkhole: API.OperationMethod<DeleteSinkholeRequest, DeleteSinkholeResponse, DeleteSinkholeError, CloudflareOpContext>;
export type DeleteSinkholesIngressError = CloudflareOpError;
/** Delete the specified ingress rule. The sinkhole must belong to the same account as the zone. */
export declare const deleteSinkholesIngress: API.OperationMethod<DeleteSinkholesIngressRequest, DeleteSinkholesIngressResponse, DeleteSinkholesIngressError, CloudflareOpContext>;
export type DismissAttackSurfaceReportIssueError = CloudflareOpError;
/** Deprecated endpoint for archiving Security Center insights. Use the newer archive-security-center-insight endpoint instead. */
export declare const dismissAttackSurfaceReportIssue: API.OperationMethod<DismissAttackSurfaceReportIssueRequest, DismissAttackSurfaceReportIssueResponse, DismissAttackSurfaceReportIssueError, CloudflareOpContext>;
export type GetAsnError = CloudflareOpError;
/** Gets an overview of the Autonomous System Number (ASN) and a list of subnets for it. */
export declare const getAsn: API.OperationMethod<GetAsnRequest, GetAsnResponse, GetAsnError, CloudflareOpContext>;
export type GetAsnSubnetError = CloudflareOpError;
/** Get ASN Subnets. */
export declare const getAsnSubnet: API.OperationMethod<GetAsnSubnetRequest, GetAsnSubnetResponse, GetAsnSubnetError, CloudflareOpContext>;
export type GetAttackSurfaceReportIssueTypeError = CloudflareOpError;
/** Lists all available issue types in Security Center, describing categories of security issues. */
export declare const getAttackSurfaceReportIssueType: API.PaginatedOperationMethod<GetAttackSurfaceReportIssueTypeRequest, GetAttackSurfaceReportIssueTypeResponse, GetAttackSurfaceReportIssueTypeError, CloudflareOpContext, string>;
export type GetDomainError = CloudflareOpError;
/** Gets security details and statistics about a domain. */
export declare const getDomain: API.OperationMethod<GetDomainRequest, GetDomainResponse, GetDomainError, CloudflareOpContext>;
export type GetDomainBulkError = CloudflareOpError;
/** Returns security details and statistics about multiple domains in a single request. **Behavior change -- domain ranking is becoming opt-in.** This endpoint previously included domain ranking data in every response and accepted a `skip_ranking=true` query parameter to opt out. That parameter is being deprecated and ranking will no longer be returned by default. Callers that want ranking data must pass `include_ranking=true`. The `skip_ranking` parameter will be silently ignored once the change ships. */
export declare const getDomainBulk: API.OperationMethod<GetDomainBulkRequest, GetDomainBulkResponse, GetDomainBulkError, CloudflareOpContext>;
export type GetDomainHistoryError = CloudflareOpError;
/** Gets historical security threat and content categories currently and previously assigned to a domain. */
export declare const getDomainHistory: API.OperationMethod<GetDomainHistoryRequest, GetDomainHistoryResponse, GetDomainHistoryError, CloudflareOpContext>;
export type GetIndicatorFeedError = IndicatorFeedNotFound | Forbidden | CloudflareOpError;
/** Retrieves details for a specific custom threat indicator feed. */
export declare const getIndicatorFeed: API.OperationMethod<GetIndicatorFeedRequest, GetIndicatorFeedResponse, GetIndicatorFeedError, CloudflareOpContext>;
export type GetIpError = CloudflareOpError;
/** Gets the geolocation, ASN, infrastructure type of the ASN, and any security threat categories of an IP address. **Must provide ip query parameters.** For example, `/intel/ip?ipv4=1.1.1.1` or `/intel/ip?ipv6=2001:db8::1`. */
export declare const getIp: API.OperationMethod<GetIpRequest, GetIpResponse, GetIpError, CloudflareOpContext>;
export type GetSinkholeError = CloudflareOpError;
/** Get the specified sinkhole by its unique identifier. */
export declare const getSinkhole: API.OperationMethod<GetSinkholeRequest, GetSinkholeResponse, GetSinkholeError, CloudflareOpContext>;
export type GetSinkholesIngressError = CloudflareOpError;
/** Get the specified ingress rule associated with a sinkhole. The sinkhole must belong to the same account as the zone. */
export declare const getSinkholesIngress: API.OperationMethod<GetSinkholesIngressRequest, GetSinkholesIngressResponse, GetSinkholesIngressError, CloudflareOpContext>;
export type GetUrlError = CloudflareOpError;
/** Gets security information about a URL, including content categories and risk types. The URL must be provided as a query parameter. */
export declare const getUrl: API.OperationMethod<GetUrlRequest, GetUrlResponse, GetUrlError, CloudflareOpContext>;
export type GetWhoiError = CloudflareOpError;
/** Retrieves WHOIS registration data for a domain, including registrant and nameserver information. */
export declare const getWhoi: API.OperationMethod<GetWhoiRequest, GetWhoiResponse, GetWhoiError, CloudflareOpContext>;
export type ListAttackSurfaceReportIssuesError = CloudflareOpError;
/** Lists all Security Center issues for the account, showing active security problems requiring attention. */
export declare const listAttackSurfaceReportIssues: API.OperationMethod<ListAttackSurfaceReportIssuesRequest, ListAttackSurfaceReportIssuesResponse, ListAttackSurfaceReportIssuesError, CloudflareOpContext>;
export type ListDnsError = CloudflareOpError;
/** Gets a list of all the domains that have resolved to a specific IP address. */
export declare const listDns: API.OperationMethod<ListDnsRequest, ListDnsResponse, ListDnsError, CloudflareOpContext>;
export type ListIndicatorFeedPermissionsError = Forbidden | CloudflareOpError;
/** Lists current access permissions for custom threat indicator feeds. */
export declare const listIndicatorFeedPermissions: API.OperationMethod<ListIndicatorFeedPermissionsRequest, ListIndicatorFeedPermissionsResponse, ListIndicatorFeedPermissionsError, CloudflareOpContext>;
export type ListIndicatorFeedsError = Forbidden | CloudflareOpError;
/** Retrieves details for all accessible custom threat indicator feeds. */
export declare const listIndicatorFeeds: API.PaginatedOperationMethod<ListIndicatorFeedsRequest, ListIndicatorFeedsResponse, ListIndicatorFeedsError, CloudflareOpContext, IndicatorFeedsListResultItem>;
export type ListSinkholesError = CloudflareOpError;
/** Lists sinkholes owned by the account for redirecting malicious traffic. */
export declare const listSinkholes: API.PaginatedOperationMethod<ListSinkholesRequest, ListSinkholesResponse, ListSinkholesError, CloudflareOpContext, SinkholesListResultItem>;
export type PutIndicatorFeedSnapshotError = IndicatorFeedNotFound | Forbidden | CloudflareOpError;
/** Revises the raw data entries in a custom threat indicator feed. Accepts both plain and gzipped STIX2/CRDF bodies. Gzip is detected by RFC 1952 magic bytes (`0x1f 0x8b`) and/or a `.gz` filename suffix (case-insensitive) -- either signal alone is sufficient to trigger the gzip path; if the body is not valid gzip, the upload fails fast. Customers are encouraged to gzip larger uploads -- the api-gateway 500 MB body cap applies to the on-the-wire (compressed) size, so gzip lets a single upload carry several GiB of decompressed STIX. */
export declare const putIndicatorFeedSnapshot: API.OperationMethod<PutIndicatorFeedSnapshotRequest, PutIndicatorFeedSnapshotResponse, PutIndicatorFeedSnapshotError, CloudflareOpContext>;
export type SeverityAttackSurfaceReportIssueError = CloudflareOpError;
/** Retrieves Security Center issue counts aggregated by severity level. */
export declare const severityAttackSurfaceReportIssue: API.OperationMethod<SeverityAttackSurfaceReportIssueRequest, SeverityAttackSurfaceReportIssueResponse, SeverityAttackSurfaceReportIssueError, CloudflareOpContext>;
export type TypeAttackSurfaceReportIssueError = CloudflareOpError;
/** Retrieves Security Center issue counts aggregated by issue type. */
export declare const typeAttackSurfaceReportIssue: API.OperationMethod<TypeAttackSurfaceReportIssueRequest, TypeAttackSurfaceReportIssueResponse, TypeAttackSurfaceReportIssueError, CloudflareOpContext>;
export type UpdateIndicatorFeedError = IndicatorFeedNotFound | Forbidden | CloudflareOpError;
/** Revises details for a specific custom threat indicator feed. */
export declare const updateIndicatorFeed: API.OperationMethod<UpdateIndicatorFeedRequest, UpdateIndicatorFeedResponse, UpdateIndicatorFeedError, CloudflareOpContext>;
export type UpdateSinkholeError = CloudflareOpError;
/** Replaces the name or R2 configuration of the specified sinkhole. This is a full replacement. All fields, including r2_secret, must be re-supplied. Omitting r2_secret overwrites the stored value with an empty string. */
export declare const updateSinkhole: API.OperationMethod<UpdateSinkholeRequest, UpdateSinkholeResponse, UpdateSinkholeError, CloudflareOpContext>;
export type UpdateSinkholesIngressError = CloudflareOpError;
/** Replaces the specified ingress rule. The sinkhole must belong to the same account as the zone. */
export declare const updateSinkholesIngress: API.OperationMethod<UpdateSinkholesIngressRequest, UpdateSinkholesIngressResponse, UpdateSinkholesIngressError, CloudflareOpContext>;
//# sourceMappingURL=intel.d.ts.map