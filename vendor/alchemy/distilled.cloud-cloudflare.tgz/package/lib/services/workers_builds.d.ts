import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const RepositoryConfigNotFound_base: S.TaggedErrorClass<"RepositoryConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class RepositoryConfigNotFound extends /*@__PURE__*/ RepositoryConfigNotFound_base {
}
export interface CancelBuildRequest {
    /** Account identifier. */
    accountId: string;
    /** Build UUID. */
    buildUuid: string;
}
export type CancelBuildResponseBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CancelBuildResponse {
    buildOutcome?: CancelBuildResponseBuildOutcome | null;
    /** Build UUID. */
    buildUuid?: string | null;
    stoppedOn?: string | null;
}
export interface CreateTokenRequest {
    /** Account identifier. */
    accountId: string;
    buildTokenName: string;
    buildTokenSecret: string;
    cloudflareTokenId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    buildTokenName?: string | null;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null;
    cloudflareTokenId?: string | null;
    ownerType?: string | null;
}
export type CreateTriggerRequestBranchExcludesList = Array<string>;
export type CreateTriggerRequestBranchIncludesList = Array<string>;
export type CreateTriggerRequestPathExcludesList = Array<string>;
export type CreateTriggerRequestPathIncludesList = Array<string>;
export interface CreateTriggerRequest {
    /** Account identifier. */
    accountId: string;
    /** Branch patterns that must not start builds. */
    branchExcludes: CreateTriggerRequestBranchExcludesList;
    /** Branch patterns that can start builds. */
    branchIncludes: CreateTriggerRequestBranchIncludesList;
    /** Command to build the Worker. */
    buildCommand: string;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid: string;
    /** Command to deploy the Worker. */
    deployCommand: string;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId: string;
    /** Path patterns that must not start builds. */
    pathExcludes: CreateTriggerRequestPathExcludesList;
    /** Path patterns that can start builds. */
    pathIncludes: CreateTriggerRequestPathIncludesList;
    /** Repository connection UUID. */
    repoConnectionUuid: string;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory: string;
    /** Human-readable name of the build trigger. */
    triggerName: string;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean;
}
export type CreateTriggerResponseBranchExcludesList = Array<string>;
export type CreateTriggerResponseBranchIncludesList = Array<string>;
export type CreateTriggerResponsePathExcludesList = Array<string>;
export type CreateTriggerResponsePathIncludesList = Array<string>;
export type CreateTriggerResponseRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface CreateTriggerResponseRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: CreateTriggerResponseRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Provider-specific repository identifier. */
    repoId?: string | null;
    /** Human-readable repository name. */
    repoName?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTriggerResponse {
    /** Branch patterns that must not start builds. */
    branchExcludes?: CreateTriggerResponseBranchExcludesList | null;
    /** Branch patterns that can start builds. */
    branchIncludes?: CreateTriggerResponseBranchIncludesList | null;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    /** Path patterns that must not start builds. */
    pathExcludes?: CreateTriggerResponsePathExcludesList | null;
    /** Path patterns that can start builds. */
    pathIncludes?: CreateTriggerResponsePathIncludesList | null;
    repoConnection?: CreateTriggerResponseRepoConnection | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export interface DeleteReposConnectionRequest {
    /** Account identifier. */
    accountId: string;
    /** Repository connection UUID. */
    repoConnectionUuid: string;
}
export type DeleteReposConnectionResponse = unknown;
export interface DeleteTokenRequest {
    /** Account identifier. */
    accountId: string;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid: string;
}
export type DeleteTokenResponse = unknown;
export interface DeleteTriggerRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
}
export type DeleteTriggerResponse = unknown;
export interface DeleteTriggersEnvironmentVariableRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
    /** Environment variable key. */
    environmentVariableKey: string;
}
export type DeleteTriggersEnvironmentVariableResponse = unknown;
export interface DeployHooksCreateRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the Worker. */
    scriptName: string;
    /** Git branch name. */
    branch: string;
    /** Deploy hook name (1-58 characters). */
    deployHookName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeployHooksCreateResponse {
    /** Git branch name. */
    branch?: string | null;
    createdOn?: string | null;
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null;
    /** Deploy hook UUID. */
    deployHookUuid?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
}
export interface DeployHooksDeleteRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the Worker. */
    scriptName: string;
    /** Deploy hook UUID. */
    deployHookUuid: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeployHooksDeleteResponse {
    /** Git branch name. */
    branch?: string | null;
    createdOn?: string | null;
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null;
    /** Deploy hook UUID. */
    deployHookUuid?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
}
export interface DeployHooksGetRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the Worker. */
    scriptName: string;
    /** Deploy hook UUID. */
    deployHookUuid: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeployHooksGetResponse {
    /** Git branch name. */
    branch?: string | null;
    createdOn?: string | null;
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null;
    /** Deploy hook UUID. */
    deployHookUuid?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
}
export interface DeployHooksListRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the Worker. */
    scriptName: string;
}
export interface DeployHooksListResultItemLatestBuild {
    createdOn?: string | null;
}
export interface DeployHooksListResultItem {
    /** Git branch name. */
    branch?: string | null;
    createdOn?: string | null;
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null;
    /** Deploy hook UUID. */
    deployHookUuid?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    latestBuild?: DeployHooksListResultItemLatestBuild | null;
    modifiedOn?: string | null;
}
export type DeployHooksListResultList = Array<DeployHooksListResultItem>;
export type DeployHooksListResponse = DeployHooksListResultList;
export interface DeployHooksTriggerRequest {
    /** Deploy hook UUID. */
    deployHookUuid: string;
}
export type DeployHooksTriggerResponseStatus = "queued" | "initializing" | "running" | "stopped";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeployHooksTriggerResponse {
    /** True if a pending build already exists for this branch */
    alreadyExists?: boolean | null;
    /** Build UUID. */
    buildUuid?: string | null;
    createdOn?: string | null;
    status?: DeployHooksTriggerResponseStatus | null;
}
export interface DeployHooksUpdateRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the Worker. */
    scriptName: string;
    /** Deploy hook UUID. */
    deployHookUuid: string;
    /** Git branch name. */
    branch: string;
    /** Deploy hook name (1-58 characters). */
    deployHookName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeployHooksUpdateResponse {
    /** Git branch name. */
    branch?: string | null;
    createdOn?: string | null;
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null;
    /** Deploy hook UUID. */
    deployHookUuid?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
}
export interface GetAccountLimitsRequest {
    /** Account identifier. */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAccountLimitsResponse {
    /** When build minutes will refresh (only for non-paid plans) */
    buildMinutesRefreshOn?: string | null;
    /** Whether build minutes limit has been reached (only for non-paid plans) */
    hasReachedBuildMinutesLimit?: boolean | null;
}
export interface GetBuildRequest {
    /** Account identifier. */
    accountId: string;
    /** Build UUID. */
    buildUuid: string;
}
export type GetBuildResponseBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export type GetBuildResponseBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export type GetBuildResponseBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type GetBuildResponseBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetBuildResponseBuildTriggerMetadata {
    author?: string | null;
    /** Git branch name. */
    branch?: string | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null;
    buildTriggerSource?: GetBuildResponseBuildTriggerMetadataBuildTriggerSource | null;
    /** Git commit hash */
    commitHash?: string | null;
    commitMessage?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    environmentVariables?: GetBuildResponseBuildTriggerMetadataEnvironmentVariablesMap | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: GetBuildResponseBuildTriggerMetadataProviderType | null;
    /** Human-readable repository name. */
    repoName?: string | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
}
export interface GetBuildResponseDeployHook {
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null;
}
export interface GetBuildResponsePullRequest {
    closedOn?: string | null;
    createdOn?: string | null;
    pullRequestUrl?: string | null;
}
export type GetBuildResponseStatus = "queued" | "initializing" | "running" | "stopped";
export type GetBuildResponseTriggerBranchExcludesList = Array<string>;
export type GetBuildResponseTriggerBranchIncludesList = Array<string>;
export type GetBuildResponseTriggerPathExcludesList = Array<string>;
export type GetBuildResponseTriggerPathIncludesList = Array<string>;
export type GetBuildResponseTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetBuildResponseTriggerRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: GetBuildResponseTriggerRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Provider-specific repository identifier. */
    repoId?: string | null;
    /** Human-readable repository name. */
    repoName?: string | null;
}
export interface GetBuildResponseTrigger {
    /** Branch patterns that must not start builds. */
    branchExcludes?: GetBuildResponseTriggerBranchExcludesList | null;
    /** Branch patterns that can start builds. */
    branchIncludes?: GetBuildResponseTriggerBranchIncludesList | null;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    /** Path patterns that must not start builds. */
    pathExcludes?: GetBuildResponseTriggerPathExcludesList | null;
    /** Path patterns that can start builds. */
    pathIncludes?: GetBuildResponseTriggerPathIncludesList | null;
    repoConnection?: GetBuildResponseTriggerRepoConnection | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBuildResponse {
    buildOutcome?: GetBuildResponseBuildOutcome | null;
    buildTriggerMetadata?: GetBuildResponseBuildTriggerMetadata | null;
    /** Build UUID. */
    buildUuid?: string | null;
    createdOn?: string | null;
    deployHook?: GetBuildResponseDeployHook | null;
    initializingOn?: string | null;
    modifiedOn?: string | null;
    /** URL serving the Worker version this build deployed. Only returned by Get build by UUID, and only once the build has produced a preview artifact. */
    previewUrl?: string | null;
    pullRequest?: GetBuildResponsePullRequest | null;
    runningOn?: string | null;
    status?: GetBuildResponseStatus | null;
    stoppedOn?: string | null;
    /** Trigger information without build_token_uuid */
    trigger?: GetBuildResponseTrigger | null;
}
export interface GetBuildsByVersionRequest {
    /** Account identifier. */
    accountId: string;
    /** Comma-separated list of version UUIDs (max 20). */
    versionIds: string;
}
export type GetBuildsByVersionResponseBuildsValueBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export type GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export type GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetBuildsByVersionResponseBuildsValueBuildTriggerMetadata {
    author?: string | null;
    /** Git branch name. */
    branch?: string | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null;
    buildTriggerSource?: GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataBuildTriggerSource | null;
    /** Git commit hash */
    commitHash?: string | null;
    commitMessage?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    environmentVariables?: GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataEnvironmentVariablesMap | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataProviderType | null;
    /** Human-readable repository name. */
    repoName?: string | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
}
export type GetBuildsByVersionResponseBuildsValueDeployHook = GetBuildResponseDeployHook;
export type GetBuildsByVersionResponseBuildsValuePullRequest = GetBuildResponsePullRequest;
export type GetBuildsByVersionResponseBuildsValueStatus = "queued" | "initializing" | "running" | "stopped";
export type GetBuildsByVersionResponseBuildsValueTriggerBranchExcludesList = Array<string>;
export type GetBuildsByVersionResponseBuildsValueTriggerBranchIncludesList = Array<string>;
export type GetBuildsByVersionResponseBuildsValueTriggerPathExcludesList = Array<string>;
export type GetBuildsByVersionResponseBuildsValueTriggerPathIncludesList = Array<string>;
export type GetBuildsByVersionResponseBuildsValueTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetBuildsByVersionResponseBuildsValueTriggerRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: GetBuildsByVersionResponseBuildsValueTriggerRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Provider-specific repository identifier. */
    repoId?: string | null;
    /** Human-readable repository name. */
    repoName?: string | null;
}
export interface GetBuildsByVersionResponseBuildsValueTrigger {
    /** Branch patterns that must not start builds. */
    branchExcludes?: GetBuildsByVersionResponseBuildsValueTriggerBranchExcludesList | null;
    /** Branch patterns that can start builds. */
    branchIncludes?: GetBuildsByVersionResponseBuildsValueTriggerBranchIncludesList | null;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    /** Path patterns that must not start builds. */
    pathExcludes?: GetBuildsByVersionResponseBuildsValueTriggerPathExcludesList | null;
    /** Path patterns that can start builds. */
    pathIncludes?: GetBuildsByVersionResponseBuildsValueTriggerPathIncludesList | null;
    repoConnection?: GetBuildsByVersionResponseBuildsValueTriggerRepoConnection | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export interface GetBuildsByVersionResponseBuildsValue {
    buildOutcome?: GetBuildsByVersionResponseBuildsValueBuildOutcome | null;
    buildTriggerMetadata?: GetBuildsByVersionResponseBuildsValueBuildTriggerMetadata | null;
    /** Build UUID. */
    buildUuid?: string | null;
    createdOn?: string | null;
    deployHook?: GetBuildResponseDeployHook | null;
    initializingOn?: string | null;
    modifiedOn?: string | null;
    /** URL serving the Worker version this build deployed. Only returned by Get build by UUID, and only once the build has produced a preview artifact. */
    previewUrl?: string | null;
    pullRequest?: GetBuildResponsePullRequest | null;
    runningOn?: string | null;
    status?: GetBuildsByVersionResponseBuildsValueStatus | null;
    stoppedOn?: string | null;
    /** Trigger information without build_token_uuid */
    trigger?: GetBuildsByVersionResponseBuildsValueTrigger | null;
}
export type GetBuildsByVersionResponseBuildsMap = {
    [key: string]: GetBuildsByVersionResponseBuildsValue | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBuildsByVersionResponse {
    builds?: GetBuildsByVersionResponseBuildsMap | null;
}
export interface GetBuildsLogRequest {
    /** Account identifier. */
    accountId: string;
    /** Build UUID. */
    buildUuid: string;
    /** Pagination cursor for log retrieval. */
    cursor?: string;
}
export type GetBuildsLogResponseLinesItem = string | number;
export type GetBuildsLogResponseLinesList = Array<GetBuildsLogResponseLinesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBuildsLogResponse {
    /** Pagination cursor for log retrieval. */
    cursor?: string | null;
    lines?: GetBuildsLogResponseLinesList | null;
    truncated?: boolean | null;
}
export interface GetLatestBuildsRequest {
    /** Account identifier. */
    accountId: string;
    /** Comma-separated list of system-generated worker script tags (max 20). */
    externalScriptIds: string;
}
export type GetLatestBuildsResponseBuildsValueBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export type GetLatestBuildsResponseBuildsValueBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export type GetLatestBuildsResponseBuildsValueBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type GetLatestBuildsResponseBuildsValueBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetLatestBuildsResponseBuildsValueBuildTriggerMetadata {
    author?: string | null;
    /** Git branch name. */
    branch?: string | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null;
    buildTriggerSource?: GetLatestBuildsResponseBuildsValueBuildTriggerMetadataBuildTriggerSource | null;
    /** Git commit hash */
    commitHash?: string | null;
    commitMessage?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    environmentVariables?: GetLatestBuildsResponseBuildsValueBuildTriggerMetadataEnvironmentVariablesMap | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: GetLatestBuildsResponseBuildsValueBuildTriggerMetadataProviderType | null;
    /** Human-readable repository name. */
    repoName?: string | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
}
export type GetLatestBuildsResponseBuildsValueDeployHook = GetBuildResponseDeployHook;
export type GetLatestBuildsResponseBuildsValuePullRequest = GetBuildResponsePullRequest;
export type GetLatestBuildsResponseBuildsValueStatus = "queued" | "initializing" | "running" | "stopped";
export type GetLatestBuildsResponseBuildsValueTriggerBranchExcludesList = Array<string>;
export type GetLatestBuildsResponseBuildsValueTriggerBranchIncludesList = Array<string>;
export type GetLatestBuildsResponseBuildsValueTriggerPathExcludesList = Array<string>;
export type GetLatestBuildsResponseBuildsValueTriggerPathIncludesList = Array<string>;
export type GetLatestBuildsResponseBuildsValueTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetLatestBuildsResponseBuildsValueTriggerRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: GetLatestBuildsResponseBuildsValueTriggerRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Provider-specific repository identifier. */
    repoId?: string | null;
    /** Human-readable repository name. */
    repoName?: string | null;
}
export interface GetLatestBuildsResponseBuildsValueTrigger {
    /** Branch patterns that must not start builds. */
    branchExcludes?: GetLatestBuildsResponseBuildsValueTriggerBranchExcludesList | null;
    /** Branch patterns that can start builds. */
    branchIncludes?: GetLatestBuildsResponseBuildsValueTriggerBranchIncludesList | null;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    /** Path patterns that must not start builds. */
    pathExcludes?: GetLatestBuildsResponseBuildsValueTriggerPathExcludesList | null;
    /** Path patterns that can start builds. */
    pathIncludes?: GetLatestBuildsResponseBuildsValueTriggerPathIncludesList | null;
    repoConnection?: GetLatestBuildsResponseBuildsValueTriggerRepoConnection | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export interface GetLatestBuildsResponseBuildsValue {
    buildOutcome?: GetLatestBuildsResponseBuildsValueBuildOutcome | null;
    buildTriggerMetadata?: GetLatestBuildsResponseBuildsValueBuildTriggerMetadata | null;
    /** Build UUID. */
    buildUuid?: string | null;
    createdOn?: string | null;
    deployHook?: GetBuildResponseDeployHook | null;
    initializingOn?: string | null;
    modifiedOn?: string | null;
    /** URL serving the Worker version this build deployed. Only returned by Get build by UUID, and only once the build has produced a preview artifact. */
    previewUrl?: string | null;
    pullRequest?: GetBuildResponsePullRequest | null;
    runningOn?: string | null;
    status?: GetLatestBuildsResponseBuildsValueStatus | null;
    stoppedOn?: string | null;
    /** Trigger information without build_token_uuid */
    trigger?: GetLatestBuildsResponseBuildsValueTrigger | null;
}
export type GetLatestBuildsResponseBuildsMap = {
    [key: string]: GetLatestBuildsResponseBuildsValue | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLatestBuildsResponse {
    builds?: GetLatestBuildsResponseBuildsMap | null;
}
export type GetReposConfigAutofillRequestProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetReposConfigAutofillRequest {
    /** Account identifier. */
    accountId: string;
    /** Source control provider. */
    providerType: GetReposConfigAutofillRequestProviderType | (string & {});
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId: string;
    /** Provider-specific repository identifier. */
    repoId: string;
    /** Git branch name. */
    branch: string;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string;
}
export type GetReposConfigAutofillResponseEnvWorkerNamesMap = {
    [key: string]: string | undefined;
};
export type GetReposConfigAutofillResponsePackageManager = "npm" | "yarn" | "pnpm" | "bun" | "uv";
export type GetReposConfigAutofillResponseScriptsMap = {
    [key: string]: string | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetReposConfigAutofillResponse {
    configFile?: string | null;
    defaultWorkerName?: string | null;
    envWorkerNames?: GetReposConfigAutofillResponseEnvWorkerNamesMap | null;
    /** Package manager inferred from repository lockfiles; defaults to npm when none is detected. */
    packageManager?: GetReposConfigAutofillResponsePackageManager | null;
    scripts?: GetReposConfigAutofillResponseScriptsMap | null;
}
export interface ListBuildsRequest {
    /** Account identifier. */
    accountId: string;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId: string;
    /** Page number for pagination */
    page?: number;
    /** Number of items per page */
    perPage?: number;
}
export type ListBuildsResultItemBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export type ListBuildsResultItemBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export type ListBuildsResultItemBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type ListBuildsResultItemBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface ListBuildsResultItemBuildTriggerMetadata {
    author?: string | null;
    /** Git branch name. */
    branch?: string | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null;
    buildTriggerSource?: ListBuildsResultItemBuildTriggerMetadataBuildTriggerSource | null;
    /** Git commit hash */
    commitHash?: string | null;
    commitMessage?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    environmentVariables?: ListBuildsResultItemBuildTriggerMetadataEnvironmentVariablesMap | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: ListBuildsResultItemBuildTriggerMetadataProviderType | null;
    /** Human-readable repository name. */
    repoName?: string | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
}
export type ListBuildsResultItemDeployHook = GetBuildResponseDeployHook;
export type ListBuildsResultItemPullRequest = GetBuildResponsePullRequest;
export type ListBuildsResultItemStatus = "queued" | "initializing" | "running" | "stopped";
export type ListBuildsResultItemTriggerBranchExcludesList = Array<string>;
export type ListBuildsResultItemTriggerBranchIncludesList = Array<string>;
export type ListBuildsResultItemTriggerPathExcludesList = Array<string>;
export type ListBuildsResultItemTriggerPathIncludesList = Array<string>;
export type ListBuildsResultItemTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface ListBuildsResultItemTriggerRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: ListBuildsResultItemTriggerRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Provider-specific repository identifier. */
    repoId?: string | null;
    /** Human-readable repository name. */
    repoName?: string | null;
}
export interface ListBuildsResultItemTrigger {
    /** Branch patterns that must not start builds. */
    branchExcludes?: ListBuildsResultItemTriggerBranchExcludesList | null;
    /** Branch patterns that can start builds. */
    branchIncludes?: ListBuildsResultItemTriggerBranchIncludesList | null;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    /** Path patterns that must not start builds. */
    pathExcludes?: ListBuildsResultItemTriggerPathExcludesList | null;
    /** Path patterns that can start builds. */
    pathIncludes?: ListBuildsResultItemTriggerPathIncludesList | null;
    repoConnection?: ListBuildsResultItemTriggerRepoConnection | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export interface ListBuildsResultItem {
    buildOutcome?: ListBuildsResultItemBuildOutcome | null;
    buildTriggerMetadata?: ListBuildsResultItemBuildTriggerMetadata | null;
    /** Build UUID. */
    buildUuid?: string | null;
    createdOn?: string | null;
    deployHook?: GetBuildResponseDeployHook | null;
    initializingOn?: string | null;
    modifiedOn?: string | null;
    /** URL serving the Worker version this build deployed. Only returned by Get build by UUID, and only once the build has produced a preview artifact. */
    previewUrl?: string | null;
    pullRequest?: GetBuildResponsePullRequest | null;
    runningOn?: string | null;
    status?: ListBuildsResultItemStatus | null;
    stoppedOn?: string | null;
    /** Trigger information without build_token_uuid */
    trigger?: ListBuildsResultItemTrigger | null;
}
export type ListBuildsResultList = Array<ListBuildsResultItem>;
export type ListBuildsResponse = ListBuildsResultList;
export interface ListTokensRequest {
    /** Account identifier. */
    accountId: string;
    /** Page number for pagination */
    page?: number;
    /** Number of items per page */
    perPage?: number;
}
export interface ListTokensResultItem {
    buildTokenName?: string | null;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null;
    cloudflareTokenId?: string | null;
    ownerType?: string | null;
}
export type ListTokensResultList = Array<ListTokensResultItem>;
export type ListTokensResponse = ListTokensResultList;
export interface ListTriggersRequest {
    /** Account identifier. */
    accountId: string;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId: string;
}
export type ListTriggersResultItemBranchExcludesList = Array<string>;
export type ListTriggersResultItemBranchIncludesList = Array<string>;
export type ListTriggersResultItemPathExcludesList = Array<string>;
export type ListTriggersResultItemPathIncludesList = Array<string>;
export type ListTriggersResultItemRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface ListTriggersResultItemRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: ListTriggersResultItemRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Provider-specific repository identifier. */
    repoId?: string | null;
    /** Human-readable repository name. */
    repoName?: string | null;
}
export interface ListTriggersResultItem {
    /** Branch patterns that must not start builds. */
    branchExcludes?: ListTriggersResultItemBranchExcludesList | null;
    /** Branch patterns that can start builds. */
    branchIncludes?: ListTriggersResultItemBranchIncludesList | null;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    /** Path patterns that must not start builds. */
    pathExcludes?: ListTriggersResultItemPathExcludesList | null;
    /** Path patterns that can start builds. */
    pathIncludes?: ListTriggersResultItemPathIncludesList | null;
    repoConnection?: ListTriggersResultItemRepoConnection | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export type ListTriggersResultList = Array<ListTriggersResultItem>;
export type ListTriggersResponse = ListTriggersResultList;
export interface ListTriggersEnvironmentVariablesRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
}
export interface ListTriggersEnvironmentVariablesResultValue {
    createdOn: string;
    /** Whether to hide the value after it is saved. Secret values remain available to builds but appear as `null` when you list variables; non-secret values remain visible. */
    isSecret: boolean;
    /** Value is null for secret environment variables */
    value?: string | null;
}
export type ListTriggersEnvironmentVariablesResultMap = {
    [key: string]: ListTriggersEnvironmentVariablesResultValue | undefined;
};
export type ListTriggersEnvironmentVariablesResponse = ListTriggersEnvironmentVariablesResultMap;
export type TriggersCreateBuildRequestSeedRepoProvider = "github" | "gitlab";
export interface TriggersCreateBuildRequestSeedRepoFilesItem {
    content: string;
    filename: string;
    /** Whether content is Base64-encoded. */
    isBase64?: boolean;
    /** Existing text in the target file to replace with content. */
    replace?: string;
}
export type TriggersCreateBuildRequestSeedRepoFilesList = Array<TriggersCreateBuildRequestSeedRepoFilesItem>;
export interface TriggersCreateBuildRequestSeedRepo {
    /** Repository owner or namespace. */
    owner: string;
    /** Source control provider for the seed repository. */
    provider: TriggersCreateBuildRequestSeedRepoProvider | (string & {});
    /** Repository name. */
    repository: string;
    /** Repository branch to seed. */
    branch?: string;
    /** Files to add or replace for this build. Maximum 2. */
    files?: TriggersCreateBuildRequestSeedRepoFilesList;
    /** Path within the repository to seed. */
    path?: string;
}
export interface TriggersCreateBuildRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
    /** Git branch name (required if commit_hash not provided) */
    branch?: string;
    /** Git commit hash (required if branch not provided) */
    commitHash?: string;
    /** Optional repository and file overrides used to seed this build. */
    seedRepo?: TriggersCreateBuildRequestSeedRepo;
}
export type TriggersCreateBuildResponseBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export type TriggersCreateBuildResponseBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export type TriggersCreateBuildResponseBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type TriggersCreateBuildResponseBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface TriggersCreateBuildResponseBuildTriggerMetadata {
    author?: string | null;
    /** Git branch name. */
    branch?: string | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null;
    buildTriggerSource?: TriggersCreateBuildResponseBuildTriggerMetadataBuildTriggerSource | null;
    /** Git commit hash */
    commitHash?: string | null;
    commitMessage?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    environmentVariables?: TriggersCreateBuildResponseBuildTriggerMetadataEnvironmentVariablesMap | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: TriggersCreateBuildResponseBuildTriggerMetadataProviderType | null;
    /** Human-readable repository name. */
    repoName?: string | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
}
export type TriggersCreateBuildResponseDeployHook = GetBuildResponseDeployHook;
export type TriggersCreateBuildResponsePullRequest = GetBuildResponsePullRequest;
export type TriggersCreateBuildResponseStatus = "queued" | "initializing" | "running" | "stopped";
export type TriggersCreateBuildResponseTriggerBranchExcludesList = Array<string>;
export type TriggersCreateBuildResponseTriggerBranchIncludesList = Array<string>;
export type TriggersCreateBuildResponseTriggerPathExcludesList = Array<string>;
export type TriggersCreateBuildResponseTriggerPathIncludesList = Array<string>;
export type TriggersCreateBuildResponseTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface TriggersCreateBuildResponseTriggerRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: TriggersCreateBuildResponseTriggerRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Provider-specific repository identifier. */
    repoId?: string | null;
    /** Human-readable repository name. */
    repoName?: string | null;
}
export interface TriggersCreateBuildResponseTrigger {
    /** Branch patterns that must not start builds. */
    branchExcludes?: TriggersCreateBuildResponseTriggerBranchExcludesList | null;
    /** Branch patterns that can start builds. */
    branchIncludes?: TriggersCreateBuildResponseTriggerBranchIncludesList | null;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    /** Path patterns that must not start builds. */
    pathExcludes?: TriggersCreateBuildResponseTriggerPathExcludesList | null;
    /** Path patterns that can start builds. */
    pathIncludes?: TriggersCreateBuildResponseTriggerPathIncludesList | null;
    repoConnection?: TriggersCreateBuildResponseTriggerRepoConnection | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface TriggersCreateBuildResponse {
    buildOutcome?: TriggersCreateBuildResponseBuildOutcome | null;
    buildTriggerMetadata?: TriggersCreateBuildResponseBuildTriggerMetadata | null;
    /** Build UUID. */
    buildUuid?: string | null;
    createdOn?: string | null;
    deployHook?: GetBuildResponseDeployHook | null;
    initializingOn?: string | null;
    modifiedOn?: string | null;
    /** URL serving the Worker version this build deployed. Only returned by Get build by UUID, and only once the build has produced a preview artifact. */
    previewUrl?: string | null;
    pullRequest?: GetBuildResponsePullRequest | null;
    runningOn?: string | null;
    status?: TriggersCreateBuildResponseStatus | null;
    stoppedOn?: string | null;
    /** Trigger information without build_token_uuid */
    trigger?: TriggersCreateBuildResponseTrigger | null;
}
export interface TriggersPurgeCacheRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
}
export type TriggersPurgeCacheResponse = unknown;
export type UpdateTriggerRequestBranchExcludesList = Array<string>;
export type UpdateTriggerRequestBranchIncludesList = Array<string>;
export type UpdateTriggerRequestPathExcludesList = Array<string>;
export type UpdateTriggerRequestPathIncludesList = Array<string>;
export interface UpdateTriggerRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
    /** Branch patterns that must not start builds. */
    branchExcludes?: UpdateTriggerRequestBranchExcludesList;
    /** Branch patterns that can start builds. */
    branchIncludes?: UpdateTriggerRequestBranchIncludesList;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean;
    /** Command to build the Worker. */
    buildCommand?: string;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string;
    /** Command to deploy the Worker. */
    deployCommand?: string;
    /** Path patterns that must not start builds. */
    pathExcludes?: UpdateTriggerRequestPathExcludesList;
    /** Path patterns that can start builds. */
    pathIncludes?: UpdateTriggerRequestPathIncludesList;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string;
    /** Human-readable name of the build trigger. */
    triggerName?: string;
}
export type UpdateTriggerResponseBranchExcludesList = Array<string>;
export type UpdateTriggerResponseBranchIncludesList = Array<string>;
export type UpdateTriggerResponsePathExcludesList = Array<string>;
export type UpdateTriggerResponsePathIncludesList = Array<string>;
export type UpdateTriggerResponseRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface UpdateTriggerResponseRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: UpdateTriggerResponseRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Provider-specific repository identifier. */
    repoId?: string | null;
    /** Human-readable repository name. */
    repoName?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTriggerResponse {
    /** Branch patterns that must not start builds. */
    branchExcludes?: UpdateTriggerResponseBranchExcludesList | null;
    /** Branch patterns that can start builds. */
    branchIncludes?: UpdateTriggerResponseBranchIncludesList | null;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null;
    /** Command to build the Worker. */
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    /** Command to deploy the Worker. */
    deployCommand?: string | null;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    /** Path patterns that must not start builds. */
    pathExcludes?: UpdateTriggerResponsePathExcludesList | null;
    /** Path patterns that can start builds. */
    pathIncludes?: UpdateTriggerResponsePathIncludesList | null;
    repoConnection?: UpdateTriggerResponseRepoConnection | null;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export type UpsertReposConnectionRequestProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface UpsertReposConnectionRequest {
    /** Account identifier. */
    accountId: string;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId: string;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName: string;
    /** Source control provider. */
    providerType: UpsertReposConnectionRequestProviderType | (string & {});
    /** Provider-specific repository identifier. */
    repoId: string;
    /** Human-readable repository name. */
    repoName: string;
}
export type UpsertReposConnectionResponseProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpsertReposConnectionResponse {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null;
    /** Source control provider. */
    providerType?: UpsertReposConnectionResponseProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Provider-specific repository identifier. */
    repoId?: string | null;
    /** Human-readable repository name. */
    repoName?: string | null;
}
export interface UpsertTriggersEnvironmentVariableRequestBodyValue {
    /** Whether to hide the value after it is saved. Secret values remain available to builds but appear as `null` when you list variables; non-secret values remain visible. */
    isSecret: boolean;
    /** Value made available to the build. Maximum length is 5000 characters. */
    value: string;
}
export type UpsertTriggersEnvironmentVariableRequestBodyMap = {
    [key: string]: UpsertTriggersEnvironmentVariableRequestBodyValue | undefined;
};
export interface UpsertTriggersEnvironmentVariableRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
    /** Map of environment-variable names to build-time values. Names must begin with a letter or underscore and contain only letters, numbers, and underscores. */
    body: UpsertTriggersEnvironmentVariableRequestBodyMap;
}
export type UpsertTriggersEnvironmentVariableResultValue = ListTriggersEnvironmentVariablesResultValue;
export type UpsertTriggersEnvironmentVariableResultMap = {
    [key: string]: ListTriggersEnvironmentVariablesResultValue | undefined;
};
export type UpsertTriggersEnvironmentVariableResponse = UpsertTriggersEnvironmentVariableResultMap;
export type CancelBuildError = CloudflareOpError;
/** Cancel a queued or running build. */
export declare const cancelBuild: API.OperationMethod<CancelBuildRequest, CancelBuildResponse, CancelBuildError, CloudflareOpContext>;
export type CreateTokenError = CloudflareOpError;
/** Create a new build authentication token */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type CreateTriggerError = CloudflareOpError;
/** Create a trigger defining the repository connection, Worker tag, commands, filters, cache setting, and build token. */
export declare const createTrigger: API.OperationMethod<CreateTriggerRequest, CreateTriggerResponse, CreateTriggerError, CloudflareOpContext>;
export type DeleteReposConnectionError = CloudflareOpError;
/** Delete a saved repository connection. */
export declare const deleteReposConnection: API.OperationMethod<DeleteReposConnectionRequest, DeleteReposConnectionResponse, DeleteReposConnectionError, CloudflareOpContext>;
export type DeleteTokenError = CloudflareOpError;
/** Delete a stored build token owned by the current user. */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, CloudflareOpContext>;
export type DeleteTriggerError = CloudflareOpError;
/** Delete a trigger and cancel its unfinished builds. */
export declare const deleteTrigger: API.OperationMethod<DeleteTriggerRequest, DeleteTriggerResponse, DeleteTriggerError, CloudflareOpContext>;
export type DeleteTriggersEnvironmentVariableError = CloudflareOpError;
/** Delete one build-time variable or secret by key. */
export declare const deleteTriggersEnvironmentVariable: API.OperationMethod<DeleteTriggersEnvironmentVariableRequest, DeleteTriggersEnvironmentVariableResponse, DeleteTriggersEnvironmentVariableError, CloudflareOpContext>;
export type DeployHooksCreateError = CloudflareOpError;
/** Create an HTTP hook that starts a build for a selected Worker branch. */
export declare const deployHooksCreate: API.OperationMethod<DeployHooksCreateRequest, DeployHooksCreateResponse, DeployHooksCreateError, CloudflareOpContext>;
export type DeployHooksDeleteError = CloudflareOpError;
/** Delete a deploy hook so its UUID can no longer start builds. */
export declare const deployHooksDelete: API.OperationMethod<DeployHooksDeleteRequest, DeployHooksDeleteResponse, DeployHooksDeleteError, CloudflareOpContext>;
export type DeployHooksGetError = CloudflareOpError;
/** Retrieve the name, branch, Worker identifier, and timestamps for a deploy hook. */
export declare const deployHooksGet: API.OperationMethod<DeployHooksGetRequest, DeployHooksGetResponse, DeployHooksGetError, CloudflareOpContext>;
export type DeployHooksListError = CloudflareOpError;
/** List the branch-specific deploy hooks configured for a Worker. */
export declare const deployHooksList: API.OperationMethod<DeployHooksListRequest, DeployHooksListResponse, DeployHooksListError, CloudflareOpContext>;
export type DeployHooksTriggerError = CloudflareOpError;
/** Trigger a build using a deploy hook. This endpoint does not require authentication - the deploy_hook_uuid acts as a secret token. */
export declare const deployHooksTrigger: API.OperationMethod<DeployHooksTriggerRequest, DeployHooksTriggerResponse, DeployHooksTriggerError, CloudflareOpContext>;
export type DeployHooksUpdateError = CloudflareOpError;
/** Replace the name and target branch for a deploy hook. */
export declare const deployHooksUpdate: API.OperationMethod<DeployHooksUpdateRequest, DeployHooksUpdateResponse, DeployHooksUpdateError, CloudflareOpContext>;
export type GetAccountLimitsError = CloudflareOpError;
/** Return whether the account's build-minute allowance is exhausted and when it refreshes. */
export declare const getAccountLimits: API.OperationMethod<GetAccountLimitsRequest, GetAccountLimitsResponse, GetAccountLimitsError, CloudflareOpContext>;
export type GetBuildError = CloudflareOpError;
/** Retrieve status, outcome, timestamps, trigger settings, and source metadata for a build UUID. */
export declare const getBuild: API.OperationMethod<GetBuildRequest, GetBuildResponse, GetBuildError, CloudflareOpContext>;
export type GetBuildsByVersionError = CloudflareOpError;
/** Retrieve builds associated with one or more Worker version IDs. */
export declare const getBuildsByVersion: API.OperationMethod<GetBuildsByVersionRequest, GetBuildsByVersionResponse, GetBuildsByVersionError, CloudflareOpContext>;
export type GetBuildsLogError = CloudflareOpError;
/** Retrieve cursor-paginated log lines for a build UUID. */
export declare const getBuildsLog: API.OperationMethod<GetBuildsLogRequest, GetBuildsLogResponse, GetBuildsLogError, CloudflareOpContext>;
export type GetLatestBuildsError = CloudflareOpError;
/** Retrieve the most recent builds for multiple worker scripts */
export declare const getLatestBuilds: API.OperationMethod<GetLatestBuildsRequest, GetLatestBuildsResponse, GetLatestBuildsError, CloudflareOpContext>;
export type GetReposConfigAutofillError = RepositoryConfigNotFound | CloudflareOpError;
/** Analyze repository for automatic configuration detection */
export declare const getReposConfigAutofill: API.OperationMethod<GetReposConfigAutofillRequest, GetReposConfigAutofillResponse, GetReposConfigAutofillError, CloudflareOpContext>;
export type ListBuildsError = CloudflareOpError;
/** List paginated build records associated with a Worker tag. */
export declare const listBuilds: API.OperationMethod<ListBuildsRequest, ListBuildsResponse, ListBuildsError, CloudflareOpContext>;
export type ListTokensError = CloudflareOpError;
/** List metadata for build tokens available to the current user without returning their secrets. */
export declare const listTokens: API.OperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, CloudflareOpContext>;
export type ListTriggersError = CloudflareOpError;
/** List trigger UUIDs and build settings associated with a Worker tag. */
export declare const listTriggers: API.OperationMethod<ListTriggersRequest, ListTriggersResponse, ListTriggersError, CloudflareOpContext>;
export type ListTriggersEnvironmentVariablesError = CloudflareOpError;
/** List build-time variables configured for a trigger. Secret values are not returned. */
export declare const listTriggersEnvironmentVariables: API.OperationMethod<ListTriggersEnvironmentVariablesRequest, ListTriggersEnvironmentVariablesResponse, ListTriggersEnvironmentVariablesError, CloudflareOpContext>;
export type TriggersCreateBuildError = CloudflareOpError;
/** Start a build for a branch or commit using the selected trigger. */
export declare const triggersCreateBuild: API.OperationMethod<TriggersCreateBuildRequest, TriggersCreateBuildResponse, TriggersCreateBuildError, CloudflareOpContext>;
export type TriggersPurgeCacheError = CloudflareOpError;
/** Delete cached dependencies and build artifacts associated with a trigger. */
export declare const triggersPurgeCache: API.OperationMethod<TriggersPurgeCacheRequest, TriggersPurgeCacheResponse, TriggersPurgeCacheError, CloudflareOpContext>;
export type UpdateTriggerError = CloudflareOpError;
/** Update commands, cache settings, or branch and path filters for a trigger. */
export declare const updateTrigger: API.OperationMethod<UpdateTriggerRequest, UpdateTriggerResponse, UpdateTriggerError, CloudflareOpContext>;
export type UpsertReposConnectionError = CloudflareOpError;
/** Save the repository connection required by build triggers. */
export declare const upsertReposConnection: API.OperationMethod<UpsertReposConnectionRequest, UpsertReposConnectionResponse, UpsertReposConnectionError, CloudflareOpContext>;
export type UpsertTriggersEnvironmentVariableError = CloudflareOpError;
/** Add or replace build-time variables and secrets without changing unspecified keys. */
export declare const upsertTriggersEnvironmentVariable: API.OperationMethod<UpsertTriggersEnvironmentVariableRequest, UpsertTriggersEnvironmentVariableResponse, UpsertTriggersEnvironmentVariableError, CloudflareOpContext>;
//# sourceMappingURL=workers_builds.d.ts.map