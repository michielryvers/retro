import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const SnippetInUse_base: S.TaggedErrorClass<"SnippetInUse", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SnippetInUse extends /*@__PURE__*/ SnippetInUse_base {
}
declare const SnippetNotFound_base: S.TaggedErrorClass<"SnippetNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SnippetNotFound extends /*@__PURE__*/ SnippetNotFound_base {
}
declare const SnippetRulesNotFound_base: S.TaggedErrorClass<"SnippetRulesNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SnippetRulesNotFound extends /*@__PURE__*/ SnippetRulesNotFound_base {
}
declare const SnippetZoneNotFound_base: S.TaggedErrorClass<"SnippetZoneNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SnippetZoneNotFound extends /*@__PURE__*/ SnippetZoneNotFound_base {
}
export interface DeleteRuleRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
}
export interface RulesDeleteResultItem {
    /** Specify the unique ID of the rule. */
    id: string;
    /** Define the expression that determines which traffic matches the rule. */
    expression: string;
    /** Specify the timestamp of when the rule was last modified. */
    lastUpdated: string;
    /** Identify the snippet. */
    snippetName: string;
    /** Provide an informative description of the rule. */
    description?: string | null;
    /** Indicate whether to execute the rule. */
    enabled?: boolean | null;
}
export type RulesDeleteResultList = Array<RulesDeleteResultItem>;
export type DeleteRuleResponse = RulesDeleteResultList;
export interface DeleteSnippetRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
    /** Identify the snippet. */
    snippetName: string;
}
export type DeleteSnippetResponse = unknown;
export interface GetContentRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
    /** Identify the snippet. */
    snippetName: string;
}
export interface GetContentResponse {
}
export interface GetSnippetRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
    /** Identify the snippet. */
    snippetName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSnippetResponse {
    /** Indicates when the snippet was created. */
    createdOn: string;
    /** Identify the snippet. */
    snippetName: string;
    /** Indicates when the snippet was last modified. */
    modifiedOn?: string | null;
}
export interface ListRulesRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
}
export type RulesGetResultItem = RulesDeleteResultItem;
export type RulesGetResultList = Array<RulesDeleteResultItem>;
export type ListRulesResponse = RulesGetResultList;
export interface ListSnippetsRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
    /** Specifies the current page number. */
    page?: number;
    /** Specifies how many results to return per page. */
    perPage?: number;
}
export interface ListResultItem {
    /** Indicates when the snippet was created. */
    createdOn: string;
    /** Identify the snippet. */
    snippetName: string;
    /** Indicates when the snippet was last modified. */
    modifiedOn?: string | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListSnippetsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface RulesUpdateRequestRulesItem {
    /** Define the expression that determines which traffic matches the rule. */
    expression: string;
    /** Identify the snippet. */
    snippetName: string;
    /** Provide an informative description of the rule. */
    description?: string;
    /** Indicate whether to execute the rule. */
    enabled?: boolean;
}
export type RulesUpdateRequestRulesList = Array<RulesUpdateRequestRulesItem>;
export interface PutRuleRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
    /** Lists snippet rules. */
    rules: RulesUpdateRequestRulesList;
}
export type RulesUpdateResultItem = RulesDeleteResultItem;
export type RulesUpdateResultList = Array<RulesDeleteResultItem>;
export type PutRuleResponse = RulesUpdateResultList;
export interface PutSnippetRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
    /** Identify the snippet. */
    snippetName: string;
    /** Snippet metadata ({ mainModule }), JSON-encoded as the multipart `metadata` part. */
    metadata: unknown;
    /** Snippet module file(s), appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSnippetResponse {
    /** Indicates when the snippet was created. */
    createdOn: string;
    /** Identify the snippet. */
    snippetName: string;
    /** Indicates when the snippet was last modified. */
    modifiedOn?: string | null;
}
export type DeleteRuleError = SnippetRulesNotFound | Forbidden | SnippetZoneNotFound | CloudflareOpError;
/** Deletes all snippet rules belonging to the zone. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type DeleteSnippetError = SnippetNotFound | SnippetInUse | CloudflareOpError;
/** Deletes a snippet belonging to the zone. Returns a 4XX response if the zone or snippet no longer exists. */
export declare const deleteSnippet: API.OperationMethod<DeleteSnippetRequest, DeleteSnippetResponse, DeleteSnippetError, CloudflareOpContext>;
export type GetContentError = CloudflareOpError;
/** Fetches the content of a snippet belonging to the zone. */
export declare const getContent: API.OperationMethod<GetContentRequest, GetContentResponse, GetContentError, CloudflareOpContext>;
export type GetSnippetError = SnippetNotFound | CloudflareOpError;
/** Fetches a snippet belonging to the zone. */
export declare const getSnippet: API.OperationMethod<GetSnippetRequest, GetSnippetResponse, GetSnippetError, CloudflareOpContext>;
export type ListRulesError = SnippetRulesNotFound | Forbidden | CloudflareOpError;
/** Fetches all snippet rules belonging to the zone. */
export declare const listRules: API.OperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext>;
export type ListSnippetsError = Forbidden | CloudflareOpError;
/** Fetches all snippets belonging to the zone. */
export declare const listSnippets: API.PaginatedOperationMethod<ListSnippetsRequest, ListSnippetsResponse, ListSnippetsError, CloudflareOpContext, ListResultItem>;
export type PutRuleError = CloudflareOpError;
/** Updates all snippet rules belonging to the zone. */
export declare const putRule: API.OperationMethod<PutRuleRequest, PutRuleResponse, PutRuleError, CloudflareOpContext>;
export type PutSnippetError = CloudflareOpError;
/** Creates or updates a snippet belonging to the zone. */
export declare const putSnippet: API.OperationMethod<PutSnippetRequest, PutSnippetResponse, PutSnippetError, CloudflareOpContext>;
//# sourceMappingURL=snippets.d.ts.map