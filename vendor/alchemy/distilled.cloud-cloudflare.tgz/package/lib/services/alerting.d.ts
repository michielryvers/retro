import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const FiltersRequired_base: S.TaggedErrorClass<"FiltersRequired", {
    readonly code: any;
    readonly message: any;
}>;
export declare class FiltersRequired extends /*@__PURE__*/ FiltersRequired_base {
}
declare const InvalidAlertQuery_base: S.TaggedErrorClass<"InvalidAlertQuery", {
    readonly code: any;
    readonly message: any;
}>;
/** The SQL API rejected a `custom_analytics` alert query. */
export declare class InvalidAlertQuery extends /*@__PURE__*/ InvalidAlertQuery_base {
}
declare const InvalidAlertType_base: S.TaggedErrorClass<"InvalidAlertType", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidAlertType extends /*@__PURE__*/ InvalidAlertType_base {
}
declare const InvalidPolicyFilters_base: S.TaggedErrorClass<"InvalidPolicyFilters", {
    readonly code: any;
    readonly message: any;
}>;
/** A filter key is invalid, missing or out of range for the alert type (e.g. a `custom_analytics` threshold without `alert_trigger_preferences_short_window`, or a window under 1m, which Cloudflare reports without a code). */
export declare class InvalidPolicyFilters extends /*@__PURE__*/ InvalidPolicyFilters_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidSilence_base: S.TaggedErrorClass<"InvalidSilence", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidSilence extends /*@__PURE__*/ InvalidSilence_base {
}
declare const InvalidWebhookId_base: S.TaggedErrorClass<"InvalidWebhookId", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidWebhookId extends /*@__PURE__*/ InvalidWebhookId_base {
}
declare const MechanismRequired_base: S.TaggedErrorClass<"MechanismRequired", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MechanismRequired extends /*@__PURE__*/ MechanismRequired_base {
}
declare const PolicyNotFound_base: S.TaggedErrorClass<"PolicyNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PolicyNotFound extends /*@__PURE__*/ PolicyNotFound_base {
}
declare const SilenceAlreadyExists_base: S.TaggedErrorClass<"SilenceAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SilenceAlreadyExists extends /*@__PURE__*/ SilenceAlreadyExists_base {
}
declare const SilenceNotFound_base: S.TaggedErrorClass<"SilenceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SilenceNotFound extends /*@__PURE__*/ SilenceNotFound_base {
}
declare const WebhookNotFound_base: S.TaggedErrorClass<"WebhookNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WebhookNotFound extends /*@__PURE__*/ WebhookNotFound_base {
}
declare const WebhookTestFailed_base: S.TaggedErrorClass<"WebhookTestFailed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WebhookTestFailed extends /*@__PURE__*/ WebhookTestFailed_base {
}
export interface CreateDestinationPagerdutyRequest {
    /** The account id */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDestinationPagerdutyResponse {
    /** token in form of UUID */
    id?: string | null;
}
export interface CreateDestinationWebhookRequest {
    /** The account id */
    accountId: string;
    /** The name of the webhook destination. This will be included in the request body when you receive a webhook notification. */
    name: string;
    /** The POST endpoint to call when dispatching a notification. */
    url: string;
    /** Optional secret that will be passed in the `cf-webhook-auth` header when dispatching generic webhook notifications or formatted for supported destinations. Secrets are not returned in any API response body. */
    secret?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDestinationWebhookResponse {
    /** UUID */
    id?: string | null;
}
export type PoliciesCreateRequestAlertType = "abuse_report_alert" | "access_custom_certificate_expiration_type" | "advanced_ddos_attack_l4_alert" | "advanced_ddos_attack_l7_alert" | "advanced_http_alert_error" | "bgp_hijack_notification" | "billing_usage_alert" | "block_notification_block_removed" | "block_notification_new_block" | "block_notification_review_rejected" | "bot_traffic_basic_alert" | "brand_protection_alert" | "brand_protection_digest" | "clickhouse_alert_fw_anomaly" | "clickhouse_alert_fw_ent_anomaly" | "cloudforce_one_request_notification" | "cni_maintenance_notification" | "custom_analytics" | "custom_bot_detection_alert" | "custom_ssl_certificate_event_type" | "dedicated_ssl_certificate_event_type" | "device_connectivity_anomaly_alert" | "dos_attack_l4" | "dos_attack_l7" | "expiring_service_token_alert" | "failing_logpush_job_disabled_alert" | "fbm_auto_advertisement" | "fbm_dosd_attack" | "fbm_volumetric_attack" | "health_check_status_notification" | "hostname_aop_custom_certificate_expiration_type" | "http_alert_edge_error" | "http_alert_origin_error" | "image_notification" | "image_resizing_notification" | "incident_alert" | "load_balancing_health_alert" | "load_balancing_pool_enablement_alert" | "logo_match_alert" | "magic_tunnel_health_check_event" | "magic_wan_tunnel_health" | "maintenance_event_notification" | "mtls_certificate_store_certificate_expiration_type" | "pages_event_alert" | "radar_notification" | "real_origin_monitoring" | "scriptmonitor_alert_new_code_change_detections" | "scriptmonitor_alert_new_hosts" | "scriptmonitor_alert_new_malicious_hosts" | "scriptmonitor_alert_new_malicious_scripts" | "scriptmonitor_alert_new_malicious_url" | "scriptmonitor_alert_new_max_length_resource_url" | "scriptmonitor_alert_new_resources" | "secondary_dns_all_primaries_failing" | "secondary_dns_primaries_failing" | "secondary_dns_warning" | "secondary_dns_zone_successfully_updated" | "secondary_dns_zone_validation_warning" | "security_insights_alert" | "sentinel_alert" | "stream_live_notifications" | "synthetic_test_latency_alert" | "synthetic_test_low_availability_alert" | "traffic_anomalies_alert" | "tunnel_health_event" | "tunnel_update_event" | "universal_ssl_event_type" | "web_analytics_metrics_update" | "zone_aop_custom_certificate_expiration_type" | "workers_observability_alert" | "workers_observability_real_time_issue" | "log_explorer_scheduled_query_results_alert" | "log_explorer_ingest_rate_limit";
export interface PoliciesCreateRequestMechanismsEmailItem {
    /** The email address */
    id?: string;
}
export type PoliciesCreateRequestMechanismsEmailList = Array<PoliciesCreateRequestMechanismsEmailItem>;
export interface PoliciesCreateRequestMechanismsPagerdutyItem {
    /** UUID */
    id?: string;
}
export type PoliciesCreateRequestMechanismsPagerdutyList = Array<PoliciesCreateRequestMechanismsPagerdutyItem>;
export type PoliciesCreateRequestMechanismsWebhooksItem = PoliciesCreateRequestMechanismsPagerdutyItem;
export type PoliciesCreateRequestMechanismsWebhooksList = Array<PoliciesCreateRequestMechanismsPagerdutyItem>;
export interface PoliciesCreateRequestMechanisms {
    email?: PoliciesCreateRequestMechanismsEmailList;
    pagerduty?: PoliciesCreateRequestMechanismsPagerdutyList;
    webhooks?: PoliciesCreateRequestMechanismsWebhooksList;
}
export type PoliciesCreateRequestFiltersActionsList = Array<string>;
export type PoliciesCreateRequestFiltersAffectedAsnsList = Array<string>;
export type PoliciesCreateRequestFiltersAffectedComponentsList = Array<string>;
export type PoliciesCreateRequestFiltersAffectedLocationsList = Array<string>;
export type PoliciesCreateRequestFiltersAirportCodeList = Array<string>;
export type PoliciesCreateRequestFiltersAlertTriggerPreferencesList = Array<string>;
export type PoliciesCreateRequestFiltersAlertTriggerPreferencesValueList = Array<string>;
export type PoliciesCreateRequestFiltersEnabledList = Array<string>;
export type PoliciesCreateRequestFiltersEnvironmentList = Array<string>;
export type PoliciesCreateRequestFiltersEventList = Array<string>;
export type PoliciesCreateRequestFiltersEventSourceList = Array<string>;
export type PoliciesCreateRequestFiltersEventTypeList = Array<string>;
export type PoliciesCreateRequestFiltersGroupByList = Array<string>;
export type PoliciesCreateRequestFiltersHealthCheckIdList = Array<string>;
export type PoliciesCreateRequestFiltersIncidentImpactItem = "INCIDENT_IMPACT_NONE" | "INCIDENT_IMPACT_MINOR" | "INCIDENT_IMPACT_MAJOR" | "INCIDENT_IMPACT_CRITICAL";
export type PoliciesCreateRequestFiltersIncidentImpactList = Array<PoliciesCreateRequestFiltersIncidentImpactItem | (string & {})>;
export type PoliciesCreateRequestFiltersInputIdList = Array<string>;
export type PoliciesCreateRequestFiltersInsightClassList = Array<string>;
export type PoliciesCreateRequestFiltersLimitList = Array<string>;
export type PoliciesCreateRequestFiltersLogoTagList = Array<string>;
export type PoliciesCreateRequestFiltersMegabitsPerSecondList = Array<string>;
export type PoliciesCreateRequestFiltersNewHealthList = Array<string>;
export type PoliciesCreateRequestFiltersNewStatusList = Array<string>;
export type PoliciesCreateRequestFiltersPacketsPerSecondList = Array<string>;
export type PoliciesCreateRequestFiltersPoolIdList = Array<string>;
export type PoliciesCreateRequestFiltersPopNamesList = Array<string>;
export type PoliciesCreateRequestFiltersProductList = Array<string>;
export type PoliciesCreateRequestFiltersProjectIdList = Array<string>;
export type PoliciesCreateRequestFiltersProtocolList = Array<string>;
export type PoliciesCreateRequestFiltersQueryTagList = Array<string>;
export type PoliciesCreateRequestFiltersRequestsPerSecondList = Array<string>;
export type PoliciesCreateRequestFiltersSelectorsList = Array<string>;
export type PoliciesCreateRequestFiltersServicesList = Array<string>;
export type PoliciesCreateRequestFiltersSloList = Array<string>;
export type PoliciesCreateRequestFiltersStatusList = Array<string>;
export type PoliciesCreateRequestFiltersTargetHostnameList = Array<string>;
export type PoliciesCreateRequestFiltersTargetIpList = Array<string>;
export type PoliciesCreateRequestFiltersTargetZoneNameList = Array<string>;
export type PoliciesCreateRequestFiltersTokenIdList = Array<string>;
export type PoliciesCreateRequestFiltersTrafficExclusionsItem = "security_events";
export type PoliciesCreateRequestFiltersTrafficExclusionsList = Array<PoliciesCreateRequestFiltersTrafficExclusionsItem | (string & {})>;
export type PoliciesCreateRequestFiltersTunnelIdList = Array<string>;
export type PoliciesCreateRequestFiltersTunnelNameList = Array<string>;
export type PoliciesCreateRequestFiltersTypeList = Array<string>;
export type PoliciesCreateRequestFiltersWhereList = Array<string>;
export type PoliciesCreateRequestFiltersZonesList = Array<string>;
export type PoliciesCreateRequestFiltersCustomAnalyticsList = Array<string>;
export interface PoliciesCreateRequestFilters {
    /** Usage depends on specific alert type */
    actions?: PoliciesCreateRequestFiltersActionsList;
    /** Used for configuring radar_notification */
    affectedAsns?: PoliciesCreateRequestFiltersAffectedAsnsList;
    /** Used for configuring incident_alert */
    affectedComponents?: PoliciesCreateRequestFiltersAffectedComponentsList;
    /** Used for configuring radar_notification */
    affectedLocations?: PoliciesCreateRequestFiltersAffectedLocationsList;
    /** Used for configuring maintenance_event_notification */
    airportCode?: PoliciesCreateRequestFiltersAirportCodeList;
    /** Usage depends on specific alert type */
    alertTriggerPreferences?: PoliciesCreateRequestFiltersAlertTriggerPreferencesList;
    /** Usage depends on specific alert type */
    alertTriggerPreferencesValue?: PoliciesCreateRequestFiltersAlertTriggerPreferencesValueList;
    /** Used for configuring load_balancing_pool_enablement_alert */
    enabled?: PoliciesCreateRequestFiltersEnabledList;
    /** Used for configuring pages_event_alert */
    environment?: PoliciesCreateRequestFiltersEnvironmentList;
    /** Used for configuring pages_event_alert */
    event?: PoliciesCreateRequestFiltersEventList;
    /** Used for configuring load_balancing_health_alert */
    eventSource?: PoliciesCreateRequestFiltersEventSourceList;
    /** Usage depends on specific alert type */
    eventType?: PoliciesCreateRequestFiltersEventTypeList;
    /** Usage depends on specific alert type */
    groupBy?: PoliciesCreateRequestFiltersGroupByList;
    /** Used for configuring health_check_status_notification */
    healthCheckId?: PoliciesCreateRequestFiltersHealthCheckIdList;
    /** Used for configuring incident_alert */
    incidentImpact?: PoliciesCreateRequestFiltersIncidentImpactList;
    /** Used for configuring stream_live_notifications */
    inputId?: PoliciesCreateRequestFiltersInputIdList;
    /** Used for configuring security_insights_alert */
    insightClass?: PoliciesCreateRequestFiltersInsightClassList;
    /** Used for configuring billing_usage_alert */
    limit?: PoliciesCreateRequestFiltersLimitList;
    /** Used for configuring logo_match_alert */
    logoTag?: PoliciesCreateRequestFiltersLogoTagList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    megabitsPerSecond?: PoliciesCreateRequestFiltersMegabitsPerSecondList;
    /** Used for configuring load_balancing_health_alert */
    newHealth?: PoliciesCreateRequestFiltersNewHealthList;
    /** Used for configuring tunnel_health_event */
    newStatus?: PoliciesCreateRequestFiltersNewStatusList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    packetsPerSecond?: PoliciesCreateRequestFiltersPacketsPerSecondList;
    /** Usage depends on specific alert type */
    poolId?: PoliciesCreateRequestFiltersPoolIdList;
    /** Usage depends on specific alert type */
    popNames?: PoliciesCreateRequestFiltersPopNamesList;
    /** Used for configuring billing_usage_alert */
    product?: PoliciesCreateRequestFiltersProductList;
    /** Used for configuring pages_event_alert */
    projectId?: PoliciesCreateRequestFiltersProjectIdList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    protocol?: PoliciesCreateRequestFiltersProtocolList;
    /** Usage depends on specific alert type */
    queryTag?: PoliciesCreateRequestFiltersQueryTagList;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    requestsPerSecond?: PoliciesCreateRequestFiltersRequestsPerSecondList;
    /** Usage depends on specific alert type */
    selectors?: PoliciesCreateRequestFiltersSelectorsList;
    /** Used for configuring clickhouse_alert_fw_ent_anomaly */
    services?: PoliciesCreateRequestFiltersServicesList;
    /** Usage depends on specific alert type */
    slo?: PoliciesCreateRequestFiltersSloList;
    /** Used for configuring health_check_status_notification */
    status?: PoliciesCreateRequestFiltersStatusList;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetHostname?: PoliciesCreateRequestFiltersTargetHostnameList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    targetIp?: PoliciesCreateRequestFiltersTargetIpList;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetZoneName?: PoliciesCreateRequestFiltersTargetZoneNameList;
    /** Access service token IDs to include for expiring_service_token_alert. Omit this property to include all current and future service tokens. */
    tokenId?: PoliciesCreateRequestFiltersTokenIdList;
    /** Used for configuring traffic_anomalies_alert */
    trafficExclusions?: PoliciesCreateRequestFiltersTrafficExclusionsList;
    /** Used for configuring tunnel_health_event */
    tunnelId?: PoliciesCreateRequestFiltersTunnelIdList;
    /** Usage depends on specific alert type */
    tunnelName?: PoliciesCreateRequestFiltersTunnelNameList;
    /** Usage depends on specific alert type */
    type?: PoliciesCreateRequestFiltersTypeList;
    /** Usage depends on specific alert type */
    where?: PoliciesCreateRequestFiltersWhereList;
    /** Usage depends on specific alert type */
    zones?: PoliciesCreateRequestFiltersZonesList;
    /** Comparison operator for a `threshold` trigger on a `custom_analytics` alert: one of `<`, `>`, `<=`, `>=`, `==`, `!=`. */
    alertTriggerPreferencesOperator?: PoliciesCreateRequestFiltersCustomAnalyticsList;
    /** Short evaluation window for a `custom_analytics` alert (e.g. `5m`). */
    alertTriggerPreferencesShortWindow?: PoliciesCreateRequestFiltersCustomAnalyticsList;
    /** Long evaluation window for a `custom_analytics` alert (e.g. `1h`). */
    alertTriggerPreferencesLongWindow?: PoliciesCreateRequestFiltersCustomAnalyticsList;
    /** Minimum value below which a `custom_analytics` anomaly or SLO trigger does not fire. */
    alertTriggerPreferencesMinimumThreshold?: PoliciesCreateRequestFiltersCustomAnalyticsList;
    /** Data source of a `custom_analytics` alert: `sql_api` (the condition in `selectors` is a SQL API query) or `workers_analytics_engine`. */
    source?: PoliciesCreateRequestFiltersCustomAnalyticsList;
    /** How often a `custom_analytics` alert evaluates its query (e.g. `5m`). */
    executionInterval?: PoliciesCreateRequestFiltersCustomAnalyticsList;
}
export interface CreatePolicyRequest {
    /** The account id */
    accountId: string;
    /** Refers to which event will trigger a Notification dispatch. You can use the endpoint to get available alert types which then will give you a list of possible values. */
    alertType: PoliciesCreateRequestAlertType | (string & {});
    /** Whether or not the Notification policy is enabled. */
    enabled: boolean;
    /** List of IDs that will be used when dispatching a notification. IDs for email type will be the email address. */
    mechanisms: PoliciesCreateRequestMechanisms;
    /** Name of the policy. */
    name: string;
    /** Optional specification of how often to re-alert from the same incident, not support on all alert types. */
    alertInterval?: string;
    /** Optional description for the Notification policy. */
    description?: string;
    /** Optional filters that allow you to be alerted only on a subset of events for that alert type based on some criteria. This is only available for select alert types. See alert type documentation for more details. */
    filters?: PoliciesCreateRequestFilters;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePolicyResponse {
    /** UUID */
    id?: string | null;
}
export interface SilencesCreateRequestBodyItem {
    /** When the silence ends. */
    endTime?: string;
    /** The unique identifier of a notification policy */
    policyId?: string;
    /** When the silence starts. */
    startTime?: string;
}
export type SilencesCreateRequestBodyList = Array<SilencesCreateRequestBodyItem>;
export interface CreateSilenceRequest {
    /** The account id */
    accountId: string;
    body: SilencesCreateRequestBodyList;
}
export interface CreateSilenceResponse {
}
export interface DeleteDestinationPagerdutyRequest {
    /** The account id */
    accountId: string;
}
export interface DeleteDestinationPagerdutyResponse {
}
export interface DeleteDestinationWebhookRequest {
    /** The account id */
    accountId: string;
    /** The unique identifier of a webhook */
    webhookId: string;
}
export interface DeleteDestinationWebhookResponse {
}
export interface DeletePolicyRequest {
    /** The account id */
    accountId: string;
    /** The unique identifier of a notification policy */
    policyId: string;
}
export interface DeletePolicyResponse {
}
export interface DeleteSilenceRequest {
    /** The account id */
    accountId: string;
    /** Silence ID */
    silenceId: string;
}
export interface DeleteSilenceResponse {
}
export interface GetDestinationEligibleRequest {
    /** The account id */
    accountId: string;
}
export type DestinationsEligibleGetResultValueItemType = "email" | "pagerduty" | "webhook";
export interface DestinationsEligibleGetResultValueItem {
    /** Determines whether or not the account is eligible for the delivery mechanism. */
    eligible?: boolean | null;
    /** Beta flag. Users can create a policy with a mechanism that is not ready, but we cannot guarantee successful delivery of notifications. */
    ready?: boolean | null;
    /** Determines type of delivery mechanism. */
    type?: DestinationsEligibleGetResultValueItemType | null;
}
export type DestinationsEligibleGetResultValueList = Array<DestinationsEligibleGetResultValueItem>;
export type DestinationsEligibleGetResultMap = {
    [key: string]: DestinationsEligibleGetResultValueList | undefined;
};
export type GetDestinationEligibleResponse = DestinationsEligibleGetResultMap;
export interface GetDestinationPagerdutyRequest {
    /** The account id */
    accountId: string;
}
export interface DestinationsPagerdutyGetResultItem {
    /** UUID */
    id?: string | null;
    /** The name of the pagerduty service. */
    name?: string | null;
}
export type DestinationsPagerdutyGetResultList = Array<DestinationsPagerdutyGetResultItem>;
export interface GetDestinationPagerdutyResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DestinationsPagerdutyGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetDestinationWebhookRequest {
    /** The account id */
    accountId: string;
    /** The unique identifier of a webhook */
    webhookId: string;
}
export type DestinationsWebhooksGetResponseType = "datadog" | "discord" | "feishu" | "gchat" | "generic" | "opsgenie" | "slack" | "splunk";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDestinationWebhookResponse {
    /** The unique identifier of a webhook */
    id?: string | null;
    /** Timestamp of when the webhook destination was created. */
    createdAt?: string | null;
    /** Timestamp of the last time an attempt to dispatch a notification to this webhook failed. */
    lastFailure?: string | null;
    /** Timestamp of the last time Cloudflare was able to successfully dispatch a notification using this webhook. */
    lastSuccess?: string | null;
    /** The name of the webhook destination. This will be included in the request body when you receive a webhook notification. */
    name?: string | null;
    /** Optional secret that will be passed in the `cf-webhook-auth` header when dispatching generic webhook notifications or formatted for supported destinations. Secrets are not returned in any API response body. */
    secret?: string | null;
    /** Type of webhook endpoint. */
    type?: DestinationsWebhooksGetResponseType | null;
    /** The POST endpoint to call when dispatching a notification. */
    url?: string | null;
}
export interface GetPolicyRequest {
    /** The account id */
    accountId: string;
    /** The unique identifier of a notification policy */
    policyId: string;
}
export type PoliciesGetResponseAlertType = "abuse_report_alert" | "access_custom_certificate_expiration_type" | "advanced_ddos_attack_l4_alert" | "advanced_ddos_attack_l7_alert" | "advanced_http_alert_error" | "bgp_hijack_notification" | "billing_usage_alert" | "block_notification_block_removed" | "block_notification_new_block" | "block_notification_review_rejected" | "bot_traffic_basic_alert" | "brand_protection_alert" | "brand_protection_digest" | "clickhouse_alert_fw_anomaly" | "clickhouse_alert_fw_ent_anomaly" | "cloudforce_one_request_notification" | "cni_maintenance_notification" | "custom_analytics" | "custom_bot_detection_alert" | "custom_ssl_certificate_event_type" | "dedicated_ssl_certificate_event_type" | "device_connectivity_anomaly_alert" | "dos_attack_l4" | "dos_attack_l7" | "expiring_service_token_alert" | "failing_logpush_job_disabled_alert" | "fbm_auto_advertisement" | "fbm_dosd_attack" | "fbm_volumetric_attack" | "health_check_status_notification" | "hostname_aop_custom_certificate_expiration_type" | "http_alert_edge_error" | "http_alert_origin_error" | "image_notification" | "image_resizing_notification" | "incident_alert" | "load_balancing_health_alert" | "load_balancing_pool_enablement_alert" | "logo_match_alert" | "magic_tunnel_health_check_event" | "magic_wan_tunnel_health" | "maintenance_event_notification" | "mtls_certificate_store_certificate_expiration_type" | "pages_event_alert" | "radar_notification" | "real_origin_monitoring" | "scriptmonitor_alert_new_code_change_detections" | "scriptmonitor_alert_new_hosts" | "scriptmonitor_alert_new_malicious_hosts" | "scriptmonitor_alert_new_malicious_scripts" | "scriptmonitor_alert_new_malicious_url" | "scriptmonitor_alert_new_max_length_resource_url" | "scriptmonitor_alert_new_resources" | "secondary_dns_all_primaries_failing" | "secondary_dns_primaries_failing" | "secondary_dns_warning" | "secondary_dns_zone_successfully_updated" | "secondary_dns_zone_validation_warning" | "security_insights_alert" | "sentinel_alert" | "stream_live_notifications" | "synthetic_test_latency_alert" | "synthetic_test_low_availability_alert" | "traffic_anomalies_alert" | "tunnel_health_event" | "tunnel_update_event" | "universal_ssl_event_type" | "web_analytics_metrics_update" | "zone_aop_custom_certificate_expiration_type" | "workers_observability_alert" | "workers_observability_real_time_issue" | "log_explorer_scheduled_query_results_alert" | "log_explorer_ingest_rate_limit";
export type PoliciesGetResponseFiltersActionsList = Array<string>;
export type PoliciesGetResponseFiltersAffectedAsnsList = Array<string>;
export type PoliciesGetResponseFiltersAffectedComponentsList = Array<string>;
export type PoliciesGetResponseFiltersAffectedLocationsList = Array<string>;
export type PoliciesGetResponseFiltersAirportCodeList = Array<string>;
export type PoliciesGetResponseFiltersAlertTriggerPreferencesList = Array<string>;
export type PoliciesGetResponseFiltersAlertTriggerPreferencesValueList = Array<string>;
export type PoliciesGetResponseFiltersEnabledList = Array<string>;
export type PoliciesGetResponseFiltersEnvironmentList = Array<string>;
export type PoliciesGetResponseFiltersEventList = Array<string>;
export type PoliciesGetResponseFiltersEventSourceList = Array<string>;
export type PoliciesGetResponseFiltersEventTypeList = Array<string>;
export type PoliciesGetResponseFiltersGroupByList = Array<string>;
export type PoliciesGetResponseFiltersHealthCheckIdList = Array<string>;
export type PoliciesGetResponseFiltersIncidentImpactItem = "INCIDENT_IMPACT_NONE" | "INCIDENT_IMPACT_MINOR" | "INCIDENT_IMPACT_MAJOR" | "INCIDENT_IMPACT_CRITICAL";
export type PoliciesGetResponseFiltersIncidentImpactList = Array<PoliciesGetResponseFiltersIncidentImpactItem>;
export type PoliciesGetResponseFiltersInputIdList = Array<string>;
export type PoliciesGetResponseFiltersInsightClassList = Array<string>;
export type PoliciesGetResponseFiltersLimitList = Array<string>;
export type PoliciesGetResponseFiltersLogoTagList = Array<string>;
export type PoliciesGetResponseFiltersMegabitsPerSecondList = Array<string>;
export type PoliciesGetResponseFiltersNewHealthList = Array<string>;
export type PoliciesGetResponseFiltersNewStatusList = Array<string>;
export type PoliciesGetResponseFiltersPacketsPerSecondList = Array<string>;
export type PoliciesGetResponseFiltersPoolIdList = Array<string>;
export type PoliciesGetResponseFiltersPopNamesList = Array<string>;
export type PoliciesGetResponseFiltersProductList = Array<string>;
export type PoliciesGetResponseFiltersProjectIdList = Array<string>;
export type PoliciesGetResponseFiltersProtocolList = Array<string>;
export type PoliciesGetResponseFiltersQueryTagList = Array<string>;
export type PoliciesGetResponseFiltersRequestsPerSecondList = Array<string>;
export type PoliciesGetResponseFiltersSelectorsList = Array<string>;
export type PoliciesGetResponseFiltersServicesList = Array<string>;
export type PoliciesGetResponseFiltersSloList = Array<string>;
export type PoliciesGetResponseFiltersStatusList = Array<string>;
export type PoliciesGetResponseFiltersTargetHostnameList = Array<string>;
export type PoliciesGetResponseFiltersTargetIpList = Array<string>;
export type PoliciesGetResponseFiltersTargetZoneNameList = Array<string>;
export type PoliciesGetResponseFiltersTokenIdList = Array<string>;
export type PoliciesGetResponseFiltersTrafficExclusionsItem = "security_events";
export type PoliciesGetResponseFiltersTrafficExclusionsList = Array<PoliciesGetResponseFiltersTrafficExclusionsItem>;
export type PoliciesGetResponseFiltersTunnelIdList = Array<string>;
export type PoliciesGetResponseFiltersTunnelNameList = Array<string>;
export type PoliciesGetResponseFiltersTypeList = Array<string>;
export type PoliciesGetResponseFiltersWhereList = Array<string>;
export type PoliciesGetResponseFiltersZonesList = Array<string>;
export type PoliciesGetResponseFiltersCustomAnalyticsList = Array<string>;
export interface PoliciesGetResponseFilters {
    /** Usage depends on specific alert type */
    actions?: PoliciesGetResponseFiltersActionsList | null;
    /** Used for configuring radar_notification */
    affectedAsns?: PoliciesGetResponseFiltersAffectedAsnsList | null;
    /** Used for configuring incident_alert */
    affectedComponents?: PoliciesGetResponseFiltersAffectedComponentsList | null;
    /** Used for configuring radar_notification */
    affectedLocations?: PoliciesGetResponseFiltersAffectedLocationsList | null;
    /** Used for configuring maintenance_event_notification */
    airportCode?: PoliciesGetResponseFiltersAirportCodeList | null;
    /** Usage depends on specific alert type */
    alertTriggerPreferences?: PoliciesGetResponseFiltersAlertTriggerPreferencesList | null;
    /** Usage depends on specific alert type */
    alertTriggerPreferencesValue?: PoliciesGetResponseFiltersAlertTriggerPreferencesValueList | null;
    /** Used for configuring load_balancing_pool_enablement_alert */
    enabled?: PoliciesGetResponseFiltersEnabledList | null;
    /** Used for configuring pages_event_alert */
    environment?: PoliciesGetResponseFiltersEnvironmentList | null;
    /** Used for configuring pages_event_alert */
    event?: PoliciesGetResponseFiltersEventList | null;
    /** Used for configuring load_balancing_health_alert */
    eventSource?: PoliciesGetResponseFiltersEventSourceList | null;
    /** Usage depends on specific alert type */
    eventType?: PoliciesGetResponseFiltersEventTypeList | null;
    /** Usage depends on specific alert type */
    groupBy?: PoliciesGetResponseFiltersGroupByList | null;
    /** Used for configuring health_check_status_notification */
    healthCheckId?: PoliciesGetResponseFiltersHealthCheckIdList | null;
    /** Used for configuring incident_alert */
    incidentImpact?: PoliciesGetResponseFiltersIncidentImpactList | null;
    /** Used for configuring stream_live_notifications */
    inputId?: PoliciesGetResponseFiltersInputIdList | null;
    /** Used for configuring security_insights_alert */
    insightClass?: PoliciesGetResponseFiltersInsightClassList | null;
    /** Used for configuring billing_usage_alert */
    limit?: PoliciesGetResponseFiltersLimitList | null;
    /** Used for configuring logo_match_alert */
    logoTag?: PoliciesGetResponseFiltersLogoTagList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    megabitsPerSecond?: PoliciesGetResponseFiltersMegabitsPerSecondList | null;
    /** Used for configuring load_balancing_health_alert */
    newHealth?: PoliciesGetResponseFiltersNewHealthList | null;
    /** Used for configuring tunnel_health_event */
    newStatus?: PoliciesGetResponseFiltersNewStatusList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    packetsPerSecond?: PoliciesGetResponseFiltersPacketsPerSecondList | null;
    /** Usage depends on specific alert type */
    poolId?: PoliciesGetResponseFiltersPoolIdList | null;
    /** Usage depends on specific alert type */
    popNames?: PoliciesGetResponseFiltersPopNamesList | null;
    /** Used for configuring billing_usage_alert */
    product?: PoliciesGetResponseFiltersProductList | null;
    /** Used for configuring pages_event_alert */
    projectId?: PoliciesGetResponseFiltersProjectIdList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    protocol?: PoliciesGetResponseFiltersProtocolList | null;
    /** Usage depends on specific alert type */
    queryTag?: PoliciesGetResponseFiltersQueryTagList | null;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    requestsPerSecond?: PoliciesGetResponseFiltersRequestsPerSecondList | null;
    /** Usage depends on specific alert type */
    selectors?: PoliciesGetResponseFiltersSelectorsList | null;
    /** Used for configuring clickhouse_alert_fw_ent_anomaly */
    services?: PoliciesGetResponseFiltersServicesList | null;
    /** Usage depends on specific alert type */
    slo?: PoliciesGetResponseFiltersSloList | null;
    /** Used for configuring health_check_status_notification */
    status?: PoliciesGetResponseFiltersStatusList | null;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetHostname?: PoliciesGetResponseFiltersTargetHostnameList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    targetIp?: PoliciesGetResponseFiltersTargetIpList | null;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetZoneName?: PoliciesGetResponseFiltersTargetZoneNameList | null;
    /** Access service token IDs to include for expiring_service_token_alert. Omit this property to include all current and future service tokens. */
    tokenId?: PoliciesGetResponseFiltersTokenIdList | null;
    /** Used for configuring traffic_anomalies_alert */
    trafficExclusions?: PoliciesGetResponseFiltersTrafficExclusionsList | null;
    /** Used for configuring tunnel_health_event */
    tunnelId?: PoliciesGetResponseFiltersTunnelIdList | null;
    /** Usage depends on specific alert type */
    tunnelName?: PoliciesGetResponseFiltersTunnelNameList | null;
    /** Usage depends on specific alert type */
    type?: PoliciesGetResponseFiltersTypeList | null;
    /** Usage depends on specific alert type */
    where?: PoliciesGetResponseFiltersWhereList | null;
    /** Usage depends on specific alert type */
    zones?: PoliciesGetResponseFiltersZonesList | null;
    /** Comparison operator for a `threshold` trigger on a `custom_analytics` alert: one of `<`, `>`, `<=`, `>=`, `==`, `!=`. */
    alertTriggerPreferencesOperator?: PoliciesGetResponseFiltersCustomAnalyticsList | null;
    /** Short evaluation window for a `custom_analytics` alert (e.g. `5m`). */
    alertTriggerPreferencesShortWindow?: PoliciesGetResponseFiltersCustomAnalyticsList | null;
    /** Long evaluation window for a `custom_analytics` alert (e.g. `1h`). */
    alertTriggerPreferencesLongWindow?: PoliciesGetResponseFiltersCustomAnalyticsList | null;
    /** Minimum value below which a `custom_analytics` anomaly or SLO trigger does not fire. */
    alertTriggerPreferencesMinimumThreshold?: PoliciesGetResponseFiltersCustomAnalyticsList | null;
    /** Data source of a `custom_analytics` alert: `sql_api` (the condition in `selectors` is a SQL API query) or `workers_analytics_engine`. */
    source?: PoliciesGetResponseFiltersCustomAnalyticsList | null;
    /** How often a `custom_analytics` alert evaluates its query (e.g. `5m`). */
    executionInterval?: PoliciesGetResponseFiltersCustomAnalyticsList | null;
}
export interface PoliciesGetResponseMechanismsEmailItem {
    /** The email address */
    id?: string | null;
}
export type PoliciesGetResponseMechanismsEmailList = Array<PoliciesGetResponseMechanismsEmailItem>;
export interface PoliciesGetResponseMechanismsPagerdutyItem {
    /** UUID */
    id?: string | null;
}
export type PoliciesGetResponseMechanismsPagerdutyList = Array<PoliciesGetResponseMechanismsPagerdutyItem>;
export type PoliciesGetResponseMechanismsWebhooksItem = PoliciesGetResponseMechanismsPagerdutyItem;
export type PoliciesGetResponseMechanismsWebhooksList = Array<PoliciesGetResponseMechanismsPagerdutyItem>;
export interface PoliciesGetResponseMechanisms {
    email?: PoliciesGetResponseMechanismsEmailList | null;
    pagerduty?: PoliciesGetResponseMechanismsPagerdutyList | null;
    webhooks?: PoliciesGetResponseMechanismsWebhooksList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPolicyResponse {
    /** The unique identifier of a notification policy */
    id?: string | null;
    /** Optional specification of how often to re-alert from the same incident, not support on all alert types. */
    alertInterval?: string | null;
    /** Refers to which event will trigger a Notification dispatch. You can use the endpoint to get available alert types which then will give you a list of possible values. */
    alertType?: PoliciesGetResponseAlertType | null;
    created?: string | null;
    /** Optional description for the Notification policy. */
    description?: string | null;
    /** Whether or not the Notification policy is enabled. */
    enabled?: boolean | null;
    /** Optional filters that allow you to be alerted only on a subset of events for that alert type based on some criteria. This is only available for select alert types. See alert type documentation for more details. */
    filters?: PoliciesGetResponseFilters | null;
    /** List of IDs that will be used when dispatching a notification. IDs for email type will be the email address. */
    mechanisms?: PoliciesGetResponseMechanisms | null;
    modified?: string | null;
    /** Name of the policy. */
    name?: string | null;
}
export interface GetSilenceRequest {
    /** The account id */
    accountId: string;
    /** Silence ID */
    silenceId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSilenceResponse {
    /** Silence ID */
    id?: string | null;
    /** When the silence was created. */
    createdAt?: string | null;
    /** When the silence ends. */
    endTime?: string | null;
    /** The unique identifier of a notification policy */
    policyId?: string | null;
    /** When the silence starts. */
    startTime?: string | null;
    /** When the silence was modified. */
    updatedAt?: string | null;
}
export interface LinkDestinationPagerdutyRequest {
    /** The account id */
    accountId: string;
    /** The token integration key */
    tokenId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface LinkDestinationPagerdutyResponse {
    /** UUID */
    id?: string | null;
}
export interface ListAvailableAlertsRequest {
    /** The account id */
    accountId: string;
}
export type AvailableAlertsListResultValueItemFilterOptionsList = Array<unknown>;
export interface AvailableAlertsListResultValueItem {
    /** Describes the alert type. */
    description?: string | null;
    /** Alert type name. */
    displayName?: string | null;
    /** Format of additional configuration options (filters) for the alert type. Data type of filters during policy creation: Array of strings. */
    filterOptions?: AvailableAlertsListResultValueItemFilterOptionsList | null;
    /** Use this value when creating and updating a notification policy. */
    type?: string | null;
}
export type AvailableAlertsListResultValueList = Array<AvailableAlertsListResultValueItem>;
export type AvailableAlertsListResultMap = {
    [key: string]: AvailableAlertsListResultValueList | undefined;
};
export type ListAvailableAlertsResponse = AvailableAlertsListResultMap;
export interface ListDestinationWebhooksRequest {
    /** The account id */
    accountId: string;
}
export type DestinationsWebhooksListResultItemType = "datadog" | "discord" | "feishu" | "gchat" | "generic" | "opsgenie" | "slack" | "splunk";
export interface DestinationsWebhooksListResultItem {
    /** The unique identifier of a webhook */
    id?: string | null;
    /** Timestamp of when the webhook destination was created. */
    createdAt?: string | null;
    /** Timestamp of the last time an attempt to dispatch a notification to this webhook failed. */
    lastFailure?: string | null;
    /** Timestamp of the last time Cloudflare was able to successfully dispatch a notification using this webhook. */
    lastSuccess?: string | null;
    /** The name of the webhook destination. This will be included in the request body when you receive a webhook notification. */
    name?: string | null;
    /** Optional secret that will be passed in the `cf-webhook-auth` header when dispatching generic webhook notifications or formatted for supported destinations. Secrets are not returned in any API response body. */
    secret?: string | null;
    /** Type of webhook endpoint. */
    type?: DestinationsWebhooksListResultItemType | null;
    /** The POST endpoint to call when dispatching a notification. */
    url?: string | null;
}
export type DestinationsWebhooksListResultList = Array<DestinationsWebhooksListResultItem>;
export interface ListDestinationWebhooksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DestinationsWebhooksListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListHistoriesRequest {
    /** The account id */
    accountId: string;
    /** Limit the returned results to history records older than the specified date. This must be a timestamp that conforms to RFC3339. */
    before?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
    /** Limit the returned results to history records newer than the specified date. This must be a timestamp that conforms to RFC3339. */
    since?: string;
}
export type HistoryListResultItemMechanismType = "email" | "pagerduty" | "webhook";
export interface HistoryListResultItem {
    /** UUID */
    id?: string | null;
    /** Message body included in the notification sent. */
    alertBody?: string | null;
    /** Type of notification that has been dispatched. */
    alertType?: string | null;
    /** Description of the notification policy (if present). */
    description?: string | null;
    /** The mechanism to which the notification has been dispatched. */
    mechanism?: string | null;
    /** The type of mechanism to which the notification has been dispatched. This can be email/pagerduty/webhook based on the mechanism configured. */
    mechanismType?: HistoryListResultItemMechanismType | null;
    /** Name of the policy. */
    name?: string | null;
    /** The unique identifier of a notification policy */
    policyId?: string | null;
    /** Timestamp of when the notification was dispatched in ISO 8601 format. */
    sent?: string | null;
}
export type HistoryListResultList = Array<HistoryListResultItem>;
export interface ListHistoriesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: HistoryListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListPoliciesRequest {
    /** The account id */
    accountId: string;
}
export type PoliciesListResultItemAlertType = "abuse_report_alert" | "access_custom_certificate_expiration_type" | "advanced_ddos_attack_l4_alert" | "advanced_ddos_attack_l7_alert" | "advanced_http_alert_error" | "bgp_hijack_notification" | "billing_usage_alert" | "block_notification_block_removed" | "block_notification_new_block" | "block_notification_review_rejected" | "bot_traffic_basic_alert" | "brand_protection_alert" | "brand_protection_digest" | "clickhouse_alert_fw_anomaly" | "clickhouse_alert_fw_ent_anomaly" | "cloudforce_one_request_notification" | "cni_maintenance_notification" | "custom_analytics" | "custom_bot_detection_alert" | "custom_ssl_certificate_event_type" | "dedicated_ssl_certificate_event_type" | "device_connectivity_anomaly_alert" | "dos_attack_l4" | "dos_attack_l7" | "expiring_service_token_alert" | "failing_logpush_job_disabled_alert" | "fbm_auto_advertisement" | "fbm_dosd_attack" | "fbm_volumetric_attack" | "health_check_status_notification" | "hostname_aop_custom_certificate_expiration_type" | "http_alert_edge_error" | "http_alert_origin_error" | "image_notification" | "image_resizing_notification" | "incident_alert" | "load_balancing_health_alert" | "load_balancing_pool_enablement_alert" | "logo_match_alert" | "magic_tunnel_health_check_event" | "magic_wan_tunnel_health" | "maintenance_event_notification" | "mtls_certificate_store_certificate_expiration_type" | "pages_event_alert" | "radar_notification" | "real_origin_monitoring" | "scriptmonitor_alert_new_code_change_detections" | "scriptmonitor_alert_new_hosts" | "scriptmonitor_alert_new_malicious_hosts" | "scriptmonitor_alert_new_malicious_scripts" | "scriptmonitor_alert_new_malicious_url" | "scriptmonitor_alert_new_max_length_resource_url" | "scriptmonitor_alert_new_resources" | "secondary_dns_all_primaries_failing" | "secondary_dns_primaries_failing" | "secondary_dns_warning" | "secondary_dns_zone_successfully_updated" | "secondary_dns_zone_validation_warning" | "security_insights_alert" | "sentinel_alert" | "stream_live_notifications" | "synthetic_test_latency_alert" | "synthetic_test_low_availability_alert" | "traffic_anomalies_alert" | "tunnel_health_event" | "tunnel_update_event" | "universal_ssl_event_type" | "web_analytics_metrics_update" | "zone_aop_custom_certificate_expiration_type" | "workers_observability_alert" | "workers_observability_real_time_issue" | "log_explorer_scheduled_query_results_alert" | "log_explorer_ingest_rate_limit";
export type PoliciesListResultItemFiltersActionsList = Array<string>;
export type PoliciesListResultItemFiltersAffectedAsnsList = Array<string>;
export type PoliciesListResultItemFiltersAffectedComponentsList = Array<string>;
export type PoliciesListResultItemFiltersAffectedLocationsList = Array<string>;
export type PoliciesListResultItemFiltersAirportCodeList = Array<string>;
export type PoliciesListResultItemFiltersAlertTriggerPreferencesList = Array<string>;
export type PoliciesListResultItemFiltersAlertTriggerPreferencesValueList = Array<string>;
export type PoliciesListResultItemFiltersEnabledList = Array<string>;
export type PoliciesListResultItemFiltersEnvironmentList = Array<string>;
export type PoliciesListResultItemFiltersEventList = Array<string>;
export type PoliciesListResultItemFiltersEventSourceList = Array<string>;
export type PoliciesListResultItemFiltersEventTypeList = Array<string>;
export type PoliciesListResultItemFiltersGroupByList = Array<string>;
export type PoliciesListResultItemFiltersHealthCheckIdList = Array<string>;
export type PoliciesListResultItemFiltersIncidentImpactItem = "INCIDENT_IMPACT_NONE" | "INCIDENT_IMPACT_MINOR" | "INCIDENT_IMPACT_MAJOR" | "INCIDENT_IMPACT_CRITICAL";
export type PoliciesListResultItemFiltersIncidentImpactList = Array<PoliciesListResultItemFiltersIncidentImpactItem>;
export type PoliciesListResultItemFiltersInputIdList = Array<string>;
export type PoliciesListResultItemFiltersInsightClassList = Array<string>;
export type PoliciesListResultItemFiltersLimitList = Array<string>;
export type PoliciesListResultItemFiltersLogoTagList = Array<string>;
export type PoliciesListResultItemFiltersMegabitsPerSecondList = Array<string>;
export type PoliciesListResultItemFiltersNewHealthList = Array<string>;
export type PoliciesListResultItemFiltersNewStatusList = Array<string>;
export type PoliciesListResultItemFiltersPacketsPerSecondList = Array<string>;
export type PoliciesListResultItemFiltersPoolIdList = Array<string>;
export type PoliciesListResultItemFiltersPopNamesList = Array<string>;
export type PoliciesListResultItemFiltersProductList = Array<string>;
export type PoliciesListResultItemFiltersProjectIdList = Array<string>;
export type PoliciesListResultItemFiltersProtocolList = Array<string>;
export type PoliciesListResultItemFiltersQueryTagList = Array<string>;
export type PoliciesListResultItemFiltersRequestsPerSecondList = Array<string>;
export type PoliciesListResultItemFiltersSelectorsList = Array<string>;
export type PoliciesListResultItemFiltersServicesList = Array<string>;
export type PoliciesListResultItemFiltersSloList = Array<string>;
export type PoliciesListResultItemFiltersStatusList = Array<string>;
export type PoliciesListResultItemFiltersTargetHostnameList = Array<string>;
export type PoliciesListResultItemFiltersTargetIpList = Array<string>;
export type PoliciesListResultItemFiltersTargetZoneNameList = Array<string>;
export type PoliciesListResultItemFiltersTokenIdList = Array<string>;
export type PoliciesListResultItemFiltersTrafficExclusionsItem = "security_events";
export type PoliciesListResultItemFiltersTrafficExclusionsList = Array<PoliciesListResultItemFiltersTrafficExclusionsItem>;
export type PoliciesListResultItemFiltersTunnelIdList = Array<string>;
export type PoliciesListResultItemFiltersTunnelNameList = Array<string>;
export type PoliciesListResultItemFiltersTypeList = Array<string>;
export type PoliciesListResultItemFiltersWhereList = Array<string>;
export type PoliciesListResultItemFiltersZonesList = Array<string>;
export type PoliciesListResultItemFiltersCustomAnalyticsList = Array<string>;
export interface PoliciesListResultItemFilters {
    /** Usage depends on specific alert type */
    actions?: PoliciesListResultItemFiltersActionsList | null;
    /** Used for configuring radar_notification */
    affectedAsns?: PoliciesListResultItemFiltersAffectedAsnsList | null;
    /** Used for configuring incident_alert */
    affectedComponents?: PoliciesListResultItemFiltersAffectedComponentsList | null;
    /** Used for configuring radar_notification */
    affectedLocations?: PoliciesListResultItemFiltersAffectedLocationsList | null;
    /** Used for configuring maintenance_event_notification */
    airportCode?: PoliciesListResultItemFiltersAirportCodeList | null;
    /** Usage depends on specific alert type */
    alertTriggerPreferences?: PoliciesListResultItemFiltersAlertTriggerPreferencesList | null;
    /** Usage depends on specific alert type */
    alertTriggerPreferencesValue?: PoliciesListResultItemFiltersAlertTriggerPreferencesValueList | null;
    /** Used for configuring load_balancing_pool_enablement_alert */
    enabled?: PoliciesListResultItemFiltersEnabledList | null;
    /** Used for configuring pages_event_alert */
    environment?: PoliciesListResultItemFiltersEnvironmentList | null;
    /** Used for configuring pages_event_alert */
    event?: PoliciesListResultItemFiltersEventList | null;
    /** Used for configuring load_balancing_health_alert */
    eventSource?: PoliciesListResultItemFiltersEventSourceList | null;
    /** Usage depends on specific alert type */
    eventType?: PoliciesListResultItemFiltersEventTypeList | null;
    /** Usage depends on specific alert type */
    groupBy?: PoliciesListResultItemFiltersGroupByList | null;
    /** Used for configuring health_check_status_notification */
    healthCheckId?: PoliciesListResultItemFiltersHealthCheckIdList | null;
    /** Used for configuring incident_alert */
    incidentImpact?: PoliciesListResultItemFiltersIncidentImpactList | null;
    /** Used for configuring stream_live_notifications */
    inputId?: PoliciesListResultItemFiltersInputIdList | null;
    /** Used for configuring security_insights_alert */
    insightClass?: PoliciesListResultItemFiltersInsightClassList | null;
    /** Used for configuring billing_usage_alert */
    limit?: PoliciesListResultItemFiltersLimitList | null;
    /** Used for configuring logo_match_alert */
    logoTag?: PoliciesListResultItemFiltersLogoTagList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    megabitsPerSecond?: PoliciesListResultItemFiltersMegabitsPerSecondList | null;
    /** Used for configuring load_balancing_health_alert */
    newHealth?: PoliciesListResultItemFiltersNewHealthList | null;
    /** Used for configuring tunnel_health_event */
    newStatus?: PoliciesListResultItemFiltersNewStatusList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    packetsPerSecond?: PoliciesListResultItemFiltersPacketsPerSecondList | null;
    /** Usage depends on specific alert type */
    poolId?: PoliciesListResultItemFiltersPoolIdList | null;
    /** Usage depends on specific alert type */
    popNames?: PoliciesListResultItemFiltersPopNamesList | null;
    /** Used for configuring billing_usage_alert */
    product?: PoliciesListResultItemFiltersProductList | null;
    /** Used for configuring pages_event_alert */
    projectId?: PoliciesListResultItemFiltersProjectIdList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    protocol?: PoliciesListResultItemFiltersProtocolList | null;
    /** Usage depends on specific alert type */
    queryTag?: PoliciesListResultItemFiltersQueryTagList | null;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    requestsPerSecond?: PoliciesListResultItemFiltersRequestsPerSecondList | null;
    /** Usage depends on specific alert type */
    selectors?: PoliciesListResultItemFiltersSelectorsList | null;
    /** Used for configuring clickhouse_alert_fw_ent_anomaly */
    services?: PoliciesListResultItemFiltersServicesList | null;
    /** Usage depends on specific alert type */
    slo?: PoliciesListResultItemFiltersSloList | null;
    /** Used for configuring health_check_status_notification */
    status?: PoliciesListResultItemFiltersStatusList | null;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetHostname?: PoliciesListResultItemFiltersTargetHostnameList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    targetIp?: PoliciesListResultItemFiltersTargetIpList | null;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetZoneName?: PoliciesListResultItemFiltersTargetZoneNameList | null;
    /** Access service token IDs to include for expiring_service_token_alert. Omit this property to include all current and future service tokens. */
    tokenId?: PoliciesListResultItemFiltersTokenIdList | null;
    /** Used for configuring traffic_anomalies_alert */
    trafficExclusions?: PoliciesListResultItemFiltersTrafficExclusionsList | null;
    /** Used for configuring tunnel_health_event */
    tunnelId?: PoliciesListResultItemFiltersTunnelIdList | null;
    /** Usage depends on specific alert type */
    tunnelName?: PoliciesListResultItemFiltersTunnelNameList | null;
    /** Usage depends on specific alert type */
    type?: PoliciesListResultItemFiltersTypeList | null;
    /** Usage depends on specific alert type */
    where?: PoliciesListResultItemFiltersWhereList | null;
    /** Usage depends on specific alert type */
    zones?: PoliciesListResultItemFiltersZonesList | null;
    /** Comparison operator for a `threshold` trigger on a `custom_analytics` alert: one of `<`, `>`, `<=`, `>=`, `==`, `!=`. */
    alertTriggerPreferencesOperator?: PoliciesListResultItemFiltersCustomAnalyticsList | null;
    /** Short evaluation window for a `custom_analytics` alert (e.g. `5m`). */
    alertTriggerPreferencesShortWindow?: PoliciesListResultItemFiltersCustomAnalyticsList | null;
    /** Long evaluation window for a `custom_analytics` alert (e.g. `1h`). */
    alertTriggerPreferencesLongWindow?: PoliciesListResultItemFiltersCustomAnalyticsList | null;
    /** Minimum value below which a `custom_analytics` anomaly or SLO trigger does not fire. */
    alertTriggerPreferencesMinimumThreshold?: PoliciesListResultItemFiltersCustomAnalyticsList | null;
    /** Data source of a `custom_analytics` alert: `sql_api` (the condition in `selectors` is a SQL API query) or `workers_analytics_engine`. */
    source?: PoliciesListResultItemFiltersCustomAnalyticsList | null;
    /** How often a `custom_analytics` alert evaluates its query (e.g. `5m`). */
    executionInterval?: PoliciesListResultItemFiltersCustomAnalyticsList | null;
}
export type PoliciesListResultItemMechanismsEmailItem = PoliciesGetResponseMechanismsEmailItem;
export type PoliciesListResultItemMechanismsEmailList = Array<PoliciesGetResponseMechanismsEmailItem>;
export type PoliciesListResultItemMechanismsPagerdutyItem = PoliciesGetResponseMechanismsPagerdutyItem;
export type PoliciesListResultItemMechanismsPagerdutyList = Array<PoliciesGetResponseMechanismsPagerdutyItem>;
export type PoliciesListResultItemMechanismsWebhooksItem = PoliciesGetResponseMechanismsPagerdutyItem;
export type PoliciesListResultItemMechanismsWebhooksList = Array<PoliciesGetResponseMechanismsPagerdutyItem>;
export interface PoliciesListResultItemMechanisms {
    email?: PoliciesListResultItemMechanismsEmailList | null;
    pagerduty?: PoliciesListResultItemMechanismsPagerdutyList | null;
    webhooks?: PoliciesListResultItemMechanismsWebhooksList | null;
}
export interface PoliciesListResultItem {
    /** The unique identifier of a notification policy */
    id?: string | null;
    /** Optional specification of how often to re-alert from the same incident, not support on all alert types. */
    alertInterval?: string | null;
    /** Refers to which event will trigger a Notification dispatch. You can use the endpoint to get available alert types which then will give you a list of possible values. */
    alertType?: PoliciesListResultItemAlertType | null;
    created?: string | null;
    /** Optional description for the Notification policy. */
    description?: string | null;
    /** Whether or not the Notification policy is enabled. */
    enabled?: boolean | null;
    /** Optional filters that allow you to be alerted only on a subset of events for that alert type based on some criteria. This is only available for select alert types. See alert type documentation for more details. */
    filters?: PoliciesListResultItemFilters | null;
    /** List of IDs that will be used when dispatching a notification. IDs for email type will be the email address. */
    mechanisms?: PoliciesListResultItemMechanisms | null;
    modified?: string | null;
    /** Name of the policy. */
    name?: string | null;
}
export type PoliciesListResultList = Array<PoliciesListResultItem>;
export interface ListPoliciesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PoliciesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListSilencesRequest {
    /** The account id */
    accountId: string;
}
export interface SilencesListResultItem {
    /** Silence ID */
    id?: string | null;
    /** When the silence was created. */
    createdAt?: string | null;
    /** When the silence ends. */
    endTime?: string | null;
    /** The unique identifier of a notification policy */
    policyId?: string | null;
    /** When the silence starts. */
    startTime?: string | null;
    /** When the silence was modified. */
    updatedAt?: string | null;
}
export type SilencesListResultList = Array<SilencesListResultItem>;
export interface ListSilencesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SilencesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface UpdateDestinationWebhookRequest {
    /** The account id */
    accountId: string;
    /** The unique identifier of a webhook */
    webhookId: string;
    /** The name of the webhook destination. This will be included in the request body when you receive a webhook notification. */
    name: string;
    /** The POST endpoint to call when dispatching a notification. */
    url: string;
    /** Optional secret that will be passed in the `cf-webhook-auth` header when dispatching generic webhook notifications or formatted for supported destinations. Secrets are not returned in any API response body. */
    secret?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateDestinationWebhookResponse {
    /** UUID */
    id?: string | null;
}
export type PoliciesUpdateRequestAlertType = "abuse_report_alert" | "access_custom_certificate_expiration_type" | "advanced_ddos_attack_l4_alert" | "advanced_ddos_attack_l7_alert" | "advanced_http_alert_error" | "bgp_hijack_notification" | "billing_usage_alert" | "block_notification_block_removed" | "block_notification_new_block" | "block_notification_review_rejected" | "bot_traffic_basic_alert" | "brand_protection_alert" | "brand_protection_digest" | "clickhouse_alert_fw_anomaly" | "clickhouse_alert_fw_ent_anomaly" | "cloudforce_one_request_notification" | "cni_maintenance_notification" | "custom_analytics" | "custom_bot_detection_alert" | "custom_ssl_certificate_event_type" | "dedicated_ssl_certificate_event_type" | "device_connectivity_anomaly_alert" | "dos_attack_l4" | "dos_attack_l7" | "expiring_service_token_alert" | "failing_logpush_job_disabled_alert" | "fbm_auto_advertisement" | "fbm_dosd_attack" | "fbm_volumetric_attack" | "health_check_status_notification" | "hostname_aop_custom_certificate_expiration_type" | "http_alert_edge_error" | "http_alert_origin_error" | "image_notification" | "image_resizing_notification" | "incident_alert" | "load_balancing_health_alert" | "load_balancing_pool_enablement_alert" | "logo_match_alert" | "magic_tunnel_health_check_event" | "magic_wan_tunnel_health" | "maintenance_event_notification" | "mtls_certificate_store_certificate_expiration_type" | "pages_event_alert" | "radar_notification" | "real_origin_monitoring" | "scriptmonitor_alert_new_code_change_detections" | "scriptmonitor_alert_new_hosts" | "scriptmonitor_alert_new_malicious_hosts" | "scriptmonitor_alert_new_malicious_scripts" | "scriptmonitor_alert_new_malicious_url" | "scriptmonitor_alert_new_max_length_resource_url" | "scriptmonitor_alert_new_resources" | "secondary_dns_all_primaries_failing" | "secondary_dns_primaries_failing" | "secondary_dns_warning" | "secondary_dns_zone_successfully_updated" | "secondary_dns_zone_validation_warning" | "security_insights_alert" | "sentinel_alert" | "stream_live_notifications" | "synthetic_test_latency_alert" | "synthetic_test_low_availability_alert" | "traffic_anomalies_alert" | "tunnel_health_event" | "tunnel_update_event" | "universal_ssl_event_type" | "web_analytics_metrics_update" | "zone_aop_custom_certificate_expiration_type" | "workers_observability_alert" | "workers_observability_real_time_issue" | "log_explorer_scheduled_query_results_alert" | "log_explorer_ingest_rate_limit";
export type PoliciesUpdateRequestFiltersActionsList = Array<string>;
export type PoliciesUpdateRequestFiltersAffectedAsnsList = Array<string>;
export type PoliciesUpdateRequestFiltersAffectedComponentsList = Array<string>;
export type PoliciesUpdateRequestFiltersAffectedLocationsList = Array<string>;
export type PoliciesUpdateRequestFiltersAirportCodeList = Array<string>;
export type PoliciesUpdateRequestFiltersAlertTriggerPreferencesList = Array<string>;
export type PoliciesUpdateRequestFiltersAlertTriggerPreferencesValueList = Array<string>;
export type PoliciesUpdateRequestFiltersEnabledList = Array<string>;
export type PoliciesUpdateRequestFiltersEnvironmentList = Array<string>;
export type PoliciesUpdateRequestFiltersEventList = Array<string>;
export type PoliciesUpdateRequestFiltersEventSourceList = Array<string>;
export type PoliciesUpdateRequestFiltersEventTypeList = Array<string>;
export type PoliciesUpdateRequestFiltersGroupByList = Array<string>;
export type PoliciesUpdateRequestFiltersHealthCheckIdList = Array<string>;
export type PoliciesUpdateRequestFiltersIncidentImpactItem = "INCIDENT_IMPACT_NONE" | "INCIDENT_IMPACT_MINOR" | "INCIDENT_IMPACT_MAJOR" | "INCIDENT_IMPACT_CRITICAL";
export type PoliciesUpdateRequestFiltersIncidentImpactList = Array<PoliciesUpdateRequestFiltersIncidentImpactItem | (string & {})>;
export type PoliciesUpdateRequestFiltersInputIdList = Array<string>;
export type PoliciesUpdateRequestFiltersInsightClassList = Array<string>;
export type PoliciesUpdateRequestFiltersLimitList = Array<string>;
export type PoliciesUpdateRequestFiltersLogoTagList = Array<string>;
export type PoliciesUpdateRequestFiltersMegabitsPerSecondList = Array<string>;
export type PoliciesUpdateRequestFiltersNewHealthList = Array<string>;
export type PoliciesUpdateRequestFiltersNewStatusList = Array<string>;
export type PoliciesUpdateRequestFiltersPacketsPerSecondList = Array<string>;
export type PoliciesUpdateRequestFiltersPoolIdList = Array<string>;
export type PoliciesUpdateRequestFiltersPopNamesList = Array<string>;
export type PoliciesUpdateRequestFiltersProductList = Array<string>;
export type PoliciesUpdateRequestFiltersProjectIdList = Array<string>;
export type PoliciesUpdateRequestFiltersProtocolList = Array<string>;
export type PoliciesUpdateRequestFiltersQueryTagList = Array<string>;
export type PoliciesUpdateRequestFiltersRequestsPerSecondList = Array<string>;
export type PoliciesUpdateRequestFiltersSelectorsList = Array<string>;
export type PoliciesUpdateRequestFiltersServicesList = Array<string>;
export type PoliciesUpdateRequestFiltersSloList = Array<string>;
export type PoliciesUpdateRequestFiltersStatusList = Array<string>;
export type PoliciesUpdateRequestFiltersTargetHostnameList = Array<string>;
export type PoliciesUpdateRequestFiltersTargetIpList = Array<string>;
export type PoliciesUpdateRequestFiltersTargetZoneNameList = Array<string>;
export type PoliciesUpdateRequestFiltersTokenIdList = Array<string>;
export type PoliciesUpdateRequestFiltersTrafficExclusionsItem = "security_events";
export type PoliciesUpdateRequestFiltersTrafficExclusionsList = Array<PoliciesUpdateRequestFiltersTrafficExclusionsItem | (string & {})>;
export type PoliciesUpdateRequestFiltersTunnelIdList = Array<string>;
export type PoliciesUpdateRequestFiltersTunnelNameList = Array<string>;
export type PoliciesUpdateRequestFiltersTypeList = Array<string>;
export type PoliciesUpdateRequestFiltersWhereList = Array<string>;
export type PoliciesUpdateRequestFiltersZonesList = Array<string>;
export type PoliciesUpdateRequestFiltersCustomAnalyticsList = Array<string>;
export interface PoliciesUpdateRequestFilters {
    /** Usage depends on specific alert type */
    actions?: PoliciesUpdateRequestFiltersActionsList;
    /** Used for configuring radar_notification */
    affectedAsns?: PoliciesUpdateRequestFiltersAffectedAsnsList;
    /** Used for configuring incident_alert */
    affectedComponents?: PoliciesUpdateRequestFiltersAffectedComponentsList;
    /** Used for configuring radar_notification */
    affectedLocations?: PoliciesUpdateRequestFiltersAffectedLocationsList;
    /** Used for configuring maintenance_event_notification */
    airportCode?: PoliciesUpdateRequestFiltersAirportCodeList;
    /** Usage depends on specific alert type */
    alertTriggerPreferences?: PoliciesUpdateRequestFiltersAlertTriggerPreferencesList;
    /** Usage depends on specific alert type */
    alertTriggerPreferencesValue?: PoliciesUpdateRequestFiltersAlertTriggerPreferencesValueList;
    /** Used for configuring load_balancing_pool_enablement_alert */
    enabled?: PoliciesUpdateRequestFiltersEnabledList;
    /** Used for configuring pages_event_alert */
    environment?: PoliciesUpdateRequestFiltersEnvironmentList;
    /** Used for configuring pages_event_alert */
    event?: PoliciesUpdateRequestFiltersEventList;
    /** Used for configuring load_balancing_health_alert */
    eventSource?: PoliciesUpdateRequestFiltersEventSourceList;
    /** Usage depends on specific alert type */
    eventType?: PoliciesUpdateRequestFiltersEventTypeList;
    /** Usage depends on specific alert type */
    groupBy?: PoliciesUpdateRequestFiltersGroupByList;
    /** Used for configuring health_check_status_notification */
    healthCheckId?: PoliciesUpdateRequestFiltersHealthCheckIdList;
    /** Used for configuring incident_alert */
    incidentImpact?: PoliciesUpdateRequestFiltersIncidentImpactList;
    /** Used for configuring stream_live_notifications */
    inputId?: PoliciesUpdateRequestFiltersInputIdList;
    /** Used for configuring security_insights_alert */
    insightClass?: PoliciesUpdateRequestFiltersInsightClassList;
    /** Used for configuring billing_usage_alert */
    limit?: PoliciesUpdateRequestFiltersLimitList;
    /** Used for configuring logo_match_alert */
    logoTag?: PoliciesUpdateRequestFiltersLogoTagList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    megabitsPerSecond?: PoliciesUpdateRequestFiltersMegabitsPerSecondList;
    /** Used for configuring load_balancing_health_alert */
    newHealth?: PoliciesUpdateRequestFiltersNewHealthList;
    /** Used for configuring tunnel_health_event */
    newStatus?: PoliciesUpdateRequestFiltersNewStatusList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    packetsPerSecond?: PoliciesUpdateRequestFiltersPacketsPerSecondList;
    /** Usage depends on specific alert type */
    poolId?: PoliciesUpdateRequestFiltersPoolIdList;
    /** Usage depends on specific alert type */
    popNames?: PoliciesUpdateRequestFiltersPopNamesList;
    /** Used for configuring billing_usage_alert */
    product?: PoliciesUpdateRequestFiltersProductList;
    /** Used for configuring pages_event_alert */
    projectId?: PoliciesUpdateRequestFiltersProjectIdList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    protocol?: PoliciesUpdateRequestFiltersProtocolList;
    /** Usage depends on specific alert type */
    queryTag?: PoliciesUpdateRequestFiltersQueryTagList;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    requestsPerSecond?: PoliciesUpdateRequestFiltersRequestsPerSecondList;
    /** Usage depends on specific alert type */
    selectors?: PoliciesUpdateRequestFiltersSelectorsList;
    /** Used for configuring clickhouse_alert_fw_ent_anomaly */
    services?: PoliciesUpdateRequestFiltersServicesList;
    /** Usage depends on specific alert type */
    slo?: PoliciesUpdateRequestFiltersSloList;
    /** Used for configuring health_check_status_notification */
    status?: PoliciesUpdateRequestFiltersStatusList;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetHostname?: PoliciesUpdateRequestFiltersTargetHostnameList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    targetIp?: PoliciesUpdateRequestFiltersTargetIpList;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetZoneName?: PoliciesUpdateRequestFiltersTargetZoneNameList;
    /** Access service token IDs to include for expiring_service_token_alert. Omit this property to include all current and future service tokens. */
    tokenId?: PoliciesUpdateRequestFiltersTokenIdList;
    /** Used for configuring traffic_anomalies_alert */
    trafficExclusions?: PoliciesUpdateRequestFiltersTrafficExclusionsList;
    /** Used for configuring tunnel_health_event */
    tunnelId?: PoliciesUpdateRequestFiltersTunnelIdList;
    /** Usage depends on specific alert type */
    tunnelName?: PoliciesUpdateRequestFiltersTunnelNameList;
    /** Usage depends on specific alert type */
    type?: PoliciesUpdateRequestFiltersTypeList;
    /** Usage depends on specific alert type */
    where?: PoliciesUpdateRequestFiltersWhereList;
    /** Usage depends on specific alert type */
    zones?: PoliciesUpdateRequestFiltersZonesList;
    /** Comparison operator for a `threshold` trigger on a `custom_analytics` alert: one of `<`, `>`, `<=`, `>=`, `==`, `!=`. */
    alertTriggerPreferencesOperator?: PoliciesUpdateRequestFiltersCustomAnalyticsList;
    /** Short evaluation window for a `custom_analytics` alert (e.g. `5m`). */
    alertTriggerPreferencesShortWindow?: PoliciesUpdateRequestFiltersCustomAnalyticsList;
    /** Long evaluation window for a `custom_analytics` alert (e.g. `1h`). */
    alertTriggerPreferencesLongWindow?: PoliciesUpdateRequestFiltersCustomAnalyticsList;
    /** Minimum value below which a `custom_analytics` anomaly or SLO trigger does not fire. */
    alertTriggerPreferencesMinimumThreshold?: PoliciesUpdateRequestFiltersCustomAnalyticsList;
    /** Data source of a `custom_analytics` alert: `sql_api` (the condition in `selectors` is a SQL API query) or `workers_analytics_engine`. */
    source?: PoliciesUpdateRequestFiltersCustomAnalyticsList;
    /** How often a `custom_analytics` alert evaluates its query (e.g. `5m`). */
    executionInterval?: PoliciesUpdateRequestFiltersCustomAnalyticsList;
}
export type PoliciesUpdateRequestMechanismsEmailItem = PoliciesCreateRequestMechanismsEmailItem;
export type PoliciesUpdateRequestMechanismsEmailList = Array<PoliciesCreateRequestMechanismsEmailItem>;
export type PoliciesUpdateRequestMechanismsPagerdutyItem = PoliciesCreateRequestMechanismsPagerdutyItem;
export type PoliciesUpdateRequestMechanismsPagerdutyList = Array<PoliciesCreateRequestMechanismsPagerdutyItem>;
export type PoliciesUpdateRequestMechanismsWebhooksItem = PoliciesCreateRequestMechanismsPagerdutyItem;
export type PoliciesUpdateRequestMechanismsWebhooksList = Array<PoliciesCreateRequestMechanismsPagerdutyItem>;
export interface PoliciesUpdateRequestMechanisms {
    email?: PoliciesUpdateRequestMechanismsEmailList;
    pagerduty?: PoliciesUpdateRequestMechanismsPagerdutyList;
    webhooks?: PoliciesUpdateRequestMechanismsWebhooksList;
}
export interface UpdatePolicyRequest {
    /** The account id */
    accountId: string;
    /** The unique identifier of a notification policy */
    policyId: string;
    /** Optional specification of how often to re-alert from the same incident, not support on all alert types. */
    alertInterval?: string;
    /** Refers to which event will trigger a Notification dispatch. You can use the endpoint to get available alert types which then will give you a list of possible values. */
    alertType?: PoliciesUpdateRequestAlertType | (string & {});
    /** Optional description for the Notification policy. */
    description?: string;
    /** Whether or not the Notification policy is enabled. */
    enabled?: boolean;
    /** Optional filters that allow you to be alerted only on a subset of events for that alert type based on some criteria. This is only available for select alert types. See alert type documentation for more details. */
    filters?: PoliciesUpdateRequestFilters;
    /** List of IDs that will be used when dispatching a notification. IDs for email type will be the email address. */
    mechanisms?: PoliciesUpdateRequestMechanisms;
    /** Name of the policy. */
    name?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdatePolicyResponse {
    /** UUID */
    id?: string | null;
}
export interface SilencesUpdateRequestBodyItem {
    /** Silence ID */
    id?: string;
    /** When the silence ends. */
    endTime?: string;
    /** When the silence starts. */
    startTime?: string;
}
export type SilencesUpdateRequestBodyList = Array<SilencesUpdateRequestBodyItem>;
export interface UpdateSilenceRequest {
    /** The account id */
    accountId: string;
    body: SilencesUpdateRequestBodyList;
}
export type SilencesUpdateResultItem = SilencesListResultItem;
export type SilencesUpdateResultList = Array<SilencesListResultItem>;
export interface UpdateSilenceResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SilencesUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type CreateDestinationPagerdutyError = InvalidRoute | CloudflareOpError;
/** Creates a new token for integrating with PagerDuty. */
export declare const createDestinationPagerduty: API.OperationMethod<CreateDestinationPagerdutyRequest, CreateDestinationPagerdutyResponse, CreateDestinationPagerdutyError, CloudflareOpContext>;
export type CreateDestinationWebhookError = InvalidRoute | WebhookTestFailed | CloudflareOpError;
/** Creates a new webhook destination. */
export declare const createDestinationWebhook: API.OperationMethod<CreateDestinationWebhookRequest, CreateDestinationWebhookResponse, CreateDestinationWebhookError, CloudflareOpContext>;
export type CreatePolicyError = InvalidRoute | FiltersRequired | MechanismRequired | InvalidPolicyFilters | InvalidAlertQuery | CloudflareOpError;
/** Creates a new Notification policy. */
export declare const createPolicy: API.OperationMethod<CreatePolicyRequest, CreatePolicyResponse, CreatePolicyError, CloudflareOpContext>;
export type CreateSilenceError = InvalidRoute | InvalidSilence | SilenceAlreadyExists | CloudflareOpError;
/** Creates a new silence for an account. */
export declare const createSilence: API.OperationMethod<CreateSilenceRequest, CreateSilenceResponse, CreateSilenceError, CloudflareOpContext>;
export type DeleteDestinationPagerdutyError = InvalidRoute | CloudflareOpError;
/** Deletes all the PagerDuty Services connected to the account. */
export declare const deleteDestinationPagerduty: API.OperationMethod<DeleteDestinationPagerdutyRequest, DeleteDestinationPagerdutyResponse, DeleteDestinationPagerdutyError, CloudflareOpContext>;
export type DeleteDestinationWebhookError = InvalidRoute | CloudflareOpError;
/** Delete a configured webhook destination. */
export declare const deleteDestinationWebhook: API.OperationMethod<DeleteDestinationWebhookRequest, DeleteDestinationWebhookResponse, DeleteDestinationWebhookError, CloudflareOpContext>;
export type DeletePolicyError = InvalidRoute | PolicyNotFound | CloudflareOpError;
/** Delete a Notification policy. */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest, DeletePolicyResponse, DeletePolicyError, CloudflareOpContext>;
export type DeleteSilenceError = InvalidRoute | SilenceNotFound | CloudflareOpError;
/** Deletes an existing silence for an account. */
export declare const deleteSilence: API.OperationMethod<DeleteSilenceRequest, DeleteSilenceResponse, DeleteSilenceError, CloudflareOpContext>;
export type GetDestinationEligibleError = InvalidRoute | CloudflareOpError;
/** Get a list of all delivery mechanism types for which an account is eligible. */
export declare const getDestinationEligible: API.OperationMethod<GetDestinationEligibleRequest, GetDestinationEligibleResponse, GetDestinationEligibleError, CloudflareOpContext>;
export type GetDestinationPagerdutyError = CloudflareOpError;
/** Get a list of all configured PagerDuty services. */
export declare const getDestinationPagerduty: API.PaginatedOperationMethod<GetDestinationPagerdutyRequest, GetDestinationPagerdutyResponse, GetDestinationPagerdutyError, CloudflareOpContext, DestinationsPagerdutyGetResultItem>;
export type GetDestinationWebhookError = InvalidRoute | WebhookNotFound | CloudflareOpError;
/** Get details for a single webhooks destination. */
export declare const getDestinationWebhook: API.OperationMethod<GetDestinationWebhookRequest, GetDestinationWebhookResponse, GetDestinationWebhookError, CloudflareOpContext>;
export type GetPolicyError = InvalidRoute | PolicyNotFound | CloudflareOpError;
/** Get details for a single policy. */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest, GetPolicyResponse, GetPolicyError, CloudflareOpContext>;
export type GetSilenceError = InvalidRoute | SilenceNotFound | CloudflareOpError;
/** Gets a specific silence for an account. */
export declare const getSilence: API.OperationMethod<GetSilenceRequest, GetSilenceResponse, GetSilenceError, CloudflareOpContext>;
export type LinkDestinationPagerdutyError = InvalidRoute | CloudflareOpError;
/** Links PagerDuty with the account using the integration token. */
export declare const linkDestinationPagerduty: API.OperationMethod<LinkDestinationPagerdutyRequest, LinkDestinationPagerdutyResponse, LinkDestinationPagerdutyError, CloudflareOpContext>;
export type ListAvailableAlertsError = InvalidRoute | CloudflareOpError;
/** Gets a list of all alert types for which an account is eligible. */
export declare const listAvailableAlerts: API.OperationMethod<ListAvailableAlertsRequest, ListAvailableAlertsResponse, ListAvailableAlertsError, CloudflareOpContext>;
export type ListDestinationWebhooksError = CloudflareOpError;
/** Gets a list of all configured webhook destinations. */
export declare const listDestinationWebhooks: API.PaginatedOperationMethod<ListDestinationWebhooksRequest, ListDestinationWebhooksResponse, ListDestinationWebhooksError, CloudflareOpContext, DestinationsWebhooksListResultItem>;
export type ListHistoriesError = CloudflareOpError;
/** Gets a list of history records for notifications sent to an account. The records are displayed for last `x` number of days based on the zone plan (free = 30, pro = 30, biz = 30, ent = 90). */
export declare const listHistories: API.PaginatedOperationMethod<ListHistoriesRequest, ListHistoriesResponse, ListHistoriesError, CloudflareOpContext, HistoryListResultItem>;
export type ListPoliciesError = CloudflareOpError;
/** Get a list of all Notification policies. */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesRequest, ListPoliciesResponse, ListPoliciesError, CloudflareOpContext, PoliciesListResultItem>;
export type ListSilencesError = CloudflareOpError;
/** Gets a list of silences for an account. */
export declare const listSilences: API.PaginatedOperationMethod<ListSilencesRequest, ListSilencesResponse, ListSilencesError, CloudflareOpContext, SilencesListResultItem>;
export type UpdateDestinationWebhookError = InvalidRoute | InvalidWebhookId | WebhookTestFailed | CloudflareOpError;
/** Update a webhook destination. */
export declare const updateDestinationWebhook: API.OperationMethod<UpdateDestinationWebhookRequest, UpdateDestinationWebhookResponse, UpdateDestinationWebhookError, CloudflareOpContext>;
export type UpdatePolicyError = InvalidRoute | PolicyNotFound | InvalidAlertType | MechanismRequired | InvalidPolicyFilters | InvalidAlertQuery | CloudflareOpError;
/** Update a Notification policy. */
export declare const updatePolicy: API.OperationMethod<UpdatePolicyRequest, UpdatePolicyResponse, UpdatePolicyError, CloudflareOpContext>;
export type UpdateSilenceError = SilenceNotFound | InvalidSilence | CloudflareOpError;
/** Updates existing silences for an account. */
export declare const updateSilence: API.PaginatedOperationMethod<UpdateSilenceRequest, UpdateSilenceResponse, UpdateSilenceError, CloudflareOpContext, SilencesListResultItem>;
//# sourceMappingURL=alerting.d.ts.map