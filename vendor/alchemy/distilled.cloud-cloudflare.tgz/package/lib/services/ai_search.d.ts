import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AiSearchInstanceNotFound_base: S.TaggedErrorClass<"AiSearchInstanceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class AiSearchInstanceNotFound extends /*@__PURE__*/ AiSearchInstanceNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InstanceAlreadyExists_base: S.TaggedErrorClass<"InstanceAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InstanceAlreadyExists extends /*@__PURE__*/ InstanceAlreadyExists_base {
}
declare const InstanceDeletionInProgress_base: S.TaggedErrorClass<"InstanceDeletionInProgress", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InstanceDeletionInProgress extends /*@__PURE__*/ InstanceDeletionInProgress_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidTokenCredentials_base: S.TaggedErrorClass<"InvalidTokenCredentials", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidTokenCredentials extends /*@__PURE__*/ InvalidTokenCredentials_base {
}
declare const MissingSitemap_base: S.TaggedErrorClass<"MissingSitemap", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MissingSitemap extends /*@__PURE__*/ MissingSitemap_base {
}
declare const NamespaceAlreadyExists_base: S.TaggedErrorClass<"NamespaceAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NamespaceAlreadyExists extends /*@__PURE__*/ NamespaceAlreadyExists_base {
}
declare const NamespaceNotFound_base: S.TaggedErrorClass<"NamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NamespaceNotFound extends /*@__PURE__*/ NamespaceNotFound_base {
}
declare const NotFound_base: S.TaggedErrorClass<"NotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
declare const SyncInCooldown_base: S.TaggedErrorClass<"SyncInCooldown", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SyncInCooldown extends /*@__PURE__*/ SyncInCooldown_base {
}
declare const TokenInUseByInstances_base: S.TaggedErrorClass<"TokenInUseByInstances", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TokenInUseByInstances extends /*@__PURE__*/ TokenInUseByInstances_base {
}
declare const TokenNotFound_base: S.TaggedErrorClass<"TokenNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TokenNotFound extends /*@__PURE__*/ TokenNotFound_base {
}
declare const UnableToConnect_base: S.TaggedErrorClass<"UnableToConnect", {
    readonly code: any;
    readonly message: any;
}>;
export declare class UnableToConnect extends /*@__PURE__*/ UnableToConnect_base {
}
declare const ValidationError_base: S.TaggedErrorClass<"ValidationError", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ValidationError extends /*@__PURE__*/ ValidationError_base {
}
declare const WebCrawlerDomainNotOwned_base: S.TaggedErrorClass<"WebCrawlerDomainNotOwned", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WebCrawlerDomainNotOwned extends /*@__PURE__*/ WebCrawlerDomainNotOwned_base {
}
export type InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type = "text";
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type;
}
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl {
    url: string;
}
export type InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type;
}
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File {
    filename: string;
    fileData?: string;
    fileId?: string;
}
export type InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2Type = "file";
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2 {
    file: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
    type: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2Type;
}
export type InstancesChatCompletionsRequestMessagesItemContentCase1Item = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0 | InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1 | InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2;
export type InstancesChatCompletionsRequestMessagesItemContentCase1List = Array<InstancesChatCompletionsRequestMessagesItemContentCase1Item>;
export type InstancesChatCompletionsRequestMessagesItemContent = string | InstancesChatCompletionsRequestMessagesItemContentCase1List;
export type InstancesChatCompletionsRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface InstancesChatCompletionsRequestMessagesItem {
    content?: InstancesChatCompletionsRequestMessagesItemContent | null;
    role: InstancesChatCompletionsRequestMessagesItemRole | (string & {});
}
export type InstancesChatCompletionsRequestMessagesList = Array<InstancesChatCompletionsRequestMessagesItem>;
export type InstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export interface InstancesChatCompletionsRequestAiSearchOptionsCache {
    cacheThreshold?: InstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold | (string & {});
    enabled?: boolean;
}
export type InstancesChatCompletionsRequestAiSearchOptionsCustomMetadataValue = string | number | boolean;
export type InstancesChatCompletionsRequestAiSearchOptionsCustomMetadataMap = {
    [key: string]: InstancesChatCompletionsRequestAiSearchOptionsCustomMetadataValue | undefined;
};
export interface InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite {
    enabled?: boolean;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    model?: string;
    rewritePrompt?: string;
}
export interface InstancesChatCompletionsRequestAiSearchOptionsReranking {
    enabled?: boolean;
    matchThreshold?: number;
    model?: string;
}
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {});
}
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList = Array<InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem>;
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export interface InstancesChatCompletionsRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList;
    contextExpansion?: number;
    filters?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap;
    fusionMethod?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod | (string & {});
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {});
    /** Minimum similarity score a chunk must reach to be returned. When omitted, falls back to the instance-level score_threshold, then to 0.4. */
    matchThreshold?: number;
    /** Maximum number of results to return. When omitted, falls back to the instance-level max_num_results, then to 10. */
    maxNumResults?: number;
    retrievalType?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType | (string & {});
    returnOnFailure?: boolean;
}
export interface InstancesChatCompletionsRequestAiSearchOptions {
    cache?: InstancesChatCompletionsRequestAiSearchOptionsCache;
    /** Metadata added to AI Gateway logs for requests this operation triggers. Accepts up to 2 string, number, or boolean entries. Reserved keys: 'ai-search', 'task', 'origin', and any key beginning with 'cf.'. */
    customMetadata?: InstancesChatCompletionsRequestAiSearchOptionsCustomMetadataMap;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking;
    retrieval?: InstancesChatCompletionsRequestAiSearchOptionsRetrieval;
}
export interface ChatCompletionsInstanceRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    messages: InstancesChatCompletionsRequestMessagesList;
    aiSearchOptions?: InstancesChatCompletionsRequestAiSearchOptions;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    model?: string;
    stream?: boolean;
}
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type = "text";
export interface InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 {
    text: string;
    type: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type;
}
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type = "image_url";
export interface InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type;
}
export interface InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File {
    filename: string;
    fileData?: string | null;
    fileId?: string | null;
}
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2Type = "file";
export interface InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2 {
    file: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File;
    type: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2Type;
}
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1Item = InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 | InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 | InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2;
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1List = Array<InstancesChatCompletionsResponseChoicesItemMessageContentCase1Item>;
export type InstancesChatCompletionsResponseChoicesItemMessageContent = string | InstancesChatCompletionsResponseChoicesItemMessageContentCase1List;
export type InstancesChatCompletionsResponseChoicesItemMessageRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface InstancesChatCompletionsResponseChoicesItemMessage {
    content: InstancesChatCompletionsResponseChoicesItemMessageContent;
    role: InstancesChatCompletionsResponseChoicesItemMessageRole;
}
export interface InstancesChatCompletionsResponseChoicesItem {
    message: InstancesChatCompletionsResponseChoicesItemMessage;
    index?: number | null;
}
export type InstancesChatCompletionsResponseChoicesList = Array<InstancesChatCompletionsResponseChoicesItem>;
export type InstancesChatCompletionsResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface InstancesChatCompletionsResponseChunksItemItem {
    key: string;
    metadata?: InstancesChatCompletionsResponseChunksItemItemMetadataMap | null;
    timestamp?: number | null;
}
export type InstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export interface InstancesChatCompletionsResponseChunksItemScoringDetails {
    fusionMethod?: InstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod | null;
    keywordRank?: number | null;
    keywordScore?: number | null;
    rerankingScore?: number | null;
    vectorRank?: number | null;
    vectorScore?: number | null;
}
export type InstancesChatCompletionsResponseChunksItemSourceMediaType = "audio" | "video";
export interface InstancesChatCompletionsResponseChunksItem {
    id: string;
    score: number;
    text: string;
    type: string;
    item?: InstancesChatCompletionsResponseChunksItemItem | null;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the matched chunk covers. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaEndMs?: number | null;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the matched chunk begins in. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaStartMs?: number | null;
    scoringDetails?: InstancesChatCompletionsResponseChunksItemScoringDetails | null;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: InstancesChatCompletionsResponseChunksItemSourceMediaType | null;
}
export type InstancesChatCompletionsResponseChunksList = Array<InstancesChatCompletionsResponseChunksItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ChatCompletionsInstanceResponse {
    choices: InstancesChatCompletionsResponseChoicesList;
    chunks: InstancesChatCompletionsResponseChunksList;
    id?: string | null;
    model?: string | null;
    object?: string | null;
}
export type NamespacesChatCompletionsRequestAiSearchOptionsInstanceIdsList = Array<string>;
export type NamespacesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export interface NamespacesChatCompletionsRequestAiSearchOptionsCache {
    cacheThreshold?: NamespacesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold | (string & {});
    enabled?: boolean;
}
export type NamespacesChatCompletionsRequestAiSearchOptionsCustomMetadataValue = string | number | boolean;
export type NamespacesChatCompletionsRequestAiSearchOptionsCustomMetadataMap = {
    [key: string]: NamespacesChatCompletionsRequestAiSearchOptionsCustomMetadataValue | undefined;
};
export type NamespacesChatCompletionsRequestAiSearchOptionsQueryRewrite = InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
export type NamespacesChatCompletionsRequestAiSearchOptionsReranking = InstancesChatCompletionsRequestAiSearchOptionsReranking;
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {});
}
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList = Array<NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem>;
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export interface NamespacesChatCompletionsRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList;
    contextExpansion?: number;
    filters?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap;
    fusionMethod?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod | (string & {});
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {});
    /** Minimum score a chunk must reach to be returned. When omitted, each instance's chunks are filtered by that instance's score_threshold, capped at the lower of the first instance's score_threshold and 0.4. */
    matchThreshold?: number;
    /** Maximum number of merged results to return. When omitted, defaults to the first instance's max_num_results, then 10. */
    maxNumResults?: number;
    retrievalType?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType | (string & {});
    returnOnFailure?: boolean;
}
export interface NamespacesChatCompletionsRequestAiSearchOptions {
    instanceIds: NamespacesChatCompletionsRequestAiSearchOptionsInstanceIdsList;
    cache?: NamespacesChatCompletionsRequestAiSearchOptionsCache;
    /** Metadata added to AI Gateway logs for requests this operation triggers. Accepts up to 2 string, number, or boolean entries. Reserved keys: 'ai-search', 'task', 'origin', and any key beginning with 'cf.'. */
    customMetadata?: NamespacesChatCompletionsRequestAiSearchOptionsCustomMetadataMap;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking;
    retrieval?: NamespacesChatCompletionsRequestAiSearchOptionsRetrieval;
}
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type = "text";
export interface NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type;
}
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export interface NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type;
}
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase2File = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase2Type = "file";
export interface NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase2 {
    file: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
    type: NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase2Type;
}
export type NamespacesChatCompletionsRequestMessagesItemContentCase1Item = NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0 | NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1 | NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase2;
export type NamespacesChatCompletionsRequestMessagesItemContentCase1List = Array<NamespacesChatCompletionsRequestMessagesItemContentCase1Item>;
export type NamespacesChatCompletionsRequestMessagesItemContent = string | NamespacesChatCompletionsRequestMessagesItemContentCase1List;
export type NamespacesChatCompletionsRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface NamespacesChatCompletionsRequestMessagesItem {
    content?: NamespacesChatCompletionsRequestMessagesItemContent | null;
    role: NamespacesChatCompletionsRequestMessagesItemRole | (string & {});
}
export type NamespacesChatCompletionsRequestMessagesList = Array<NamespacesChatCompletionsRequestMessagesItem>;
export interface ChatCompletionsNamespaceRequest {
    accountId: string;
    name: string;
    aiSearchOptions: NamespacesChatCompletionsRequestAiSearchOptions;
    messages: NamespacesChatCompletionsRequestMessagesList;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    model?: string;
    stream?: boolean;
}
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type = "text";
export interface NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 {
    text: string;
    type: NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type;
}
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type = "image_url";
export interface NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type;
}
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File = InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File;
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2Type = "file";
export interface NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2 {
    file: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File;
    type: NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2Type;
}
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1Item = NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 | NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 | NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2;
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1List = Array<NamespacesChatCompletionsResponseChoicesItemMessageContentCase1Item>;
export type NamespacesChatCompletionsResponseChoicesItemMessageContent = string | NamespacesChatCompletionsResponseChoicesItemMessageContentCase1List;
export type NamespacesChatCompletionsResponseChoicesItemMessageRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface NamespacesChatCompletionsResponseChoicesItemMessage {
    content: NamespacesChatCompletionsResponseChoicesItemMessageContent;
    role: NamespacesChatCompletionsResponseChoicesItemMessageRole;
}
export interface NamespacesChatCompletionsResponseChoicesItem {
    message: NamespacesChatCompletionsResponseChoicesItemMessage;
    index?: number | null;
}
export type NamespacesChatCompletionsResponseChoicesList = Array<NamespacesChatCompletionsResponseChoicesItem>;
export type NamespacesChatCompletionsResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface NamespacesChatCompletionsResponseChunksItemItem {
    key: string;
    metadata?: NamespacesChatCompletionsResponseChunksItemItemMetadataMap | null;
    timestamp?: number | null;
}
export type NamespacesChatCompletionsResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export interface NamespacesChatCompletionsResponseChunksItemScoringDetails {
    fusionMethod?: NamespacesChatCompletionsResponseChunksItemScoringDetailsFusionMethod | null;
    keywordRank?: number | null;
    keywordScore?: number | null;
    rerankingScore?: number | null;
    vectorRank?: number | null;
    vectorScore?: number | null;
}
export type NamespacesChatCompletionsResponseChunksItemSourceMediaType = "audio" | "video";
export interface NamespacesChatCompletionsResponseChunksItem {
    id: string;
    instanceId: string;
    score: number;
    text: string;
    type: string;
    item?: NamespacesChatCompletionsResponseChunksItemItem | null;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the matched chunk covers. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaEndMs?: number | null;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the matched chunk begins in. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaStartMs?: number | null;
    scoringDetails?: NamespacesChatCompletionsResponseChunksItemScoringDetails | null;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: NamespacesChatCompletionsResponseChunksItemSourceMediaType | null;
}
export type NamespacesChatCompletionsResponseChunksList = Array<NamespacesChatCompletionsResponseChunksItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ChatCompletionsNamespaceResponse {
    choices: NamespacesChatCompletionsResponseChoicesList;
    chunks: NamespacesChatCompletionsResponseChunksList;
    id?: string | null;
    model?: string | null;
    object?: string | null;
}
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type = "text";
export interface NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type;
}
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export interface NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type;
}
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2Type = "file";
export interface NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2 {
    file: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
    type: NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2Type;
}
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1Item = NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0 | NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1 | NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1List = Array<NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1Item>;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContent = string | NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1List;
export type NamespacesInstancesChatCompletionsRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface NamespacesInstancesChatCompletionsRequestMessagesItem {
    content?: NamespacesInstancesChatCompletionsRequestMessagesItemContent | null;
    role: NamespacesInstancesChatCompletionsRequestMessagesItemRole | (string & {});
}
export type NamespacesInstancesChatCompletionsRequestMessagesList = Array<NamespacesInstancesChatCompletionsRequestMessagesItem>;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptionsCache {
    cacheThreshold?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold | (string & {});
    enabled?: boolean;
}
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsCustomMetadataValue = string | number | boolean;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsCustomMetadataMap = {
    [key: string]: NamespacesInstancesChatCompletionsRequestAiSearchOptionsCustomMetadataValue | undefined;
};
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsQueryRewrite = InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsReranking = InstancesChatCompletionsRequestAiSearchOptionsReranking;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {});
}
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList = Array<NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem>;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList;
    contextExpansion?: number;
    filters?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap;
    fusionMethod?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod | (string & {});
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {});
    /** Minimum similarity score a chunk must reach to be returned. When omitted, falls back to the instance-level score_threshold, then to 0.4. */
    matchThreshold?: number;
    /** Maximum number of results to return. When omitted, falls back to the instance-level max_num_results, then to 10. */
    maxNumResults?: number;
    retrievalType?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType | (string & {});
    returnOnFailure?: boolean;
}
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptions {
    cache?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsCache;
    /** Metadata added to AI Gateway logs for requests this operation triggers. Accepts up to 2 string, number, or boolean entries. Reserved keys: 'ai-search', 'task', 'origin', and any key beginning with 'cf.'. */
    customMetadata?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsCustomMetadataMap;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking;
    retrieval?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrieval;
}
export interface ChatCompletionsNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    messages: NamespacesInstancesChatCompletionsRequestMessagesList;
    aiSearchOptions?: NamespacesInstancesChatCompletionsRequestAiSearchOptions;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    model?: string;
    stream?: boolean;
}
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type = "text";
export interface NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 {
    text: string;
    type: NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type;
}
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type = "image_url";
export interface NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type;
}
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File = InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2Type = "file";
export interface NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2 {
    file: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File;
    type: NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2Type;
}
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1Item = NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 | NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 | NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1List = Array<NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1Item>;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContent = string | NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1List;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface NamespacesInstancesChatCompletionsResponseChoicesItemMessage {
    content: NamespacesInstancesChatCompletionsResponseChoicesItemMessageContent;
    role: NamespacesInstancesChatCompletionsResponseChoicesItemMessageRole;
}
export interface NamespacesInstancesChatCompletionsResponseChoicesItem {
    message: NamespacesInstancesChatCompletionsResponseChoicesItemMessage;
    index?: number | null;
}
export type NamespacesInstancesChatCompletionsResponseChoicesList = Array<NamespacesInstancesChatCompletionsResponseChoicesItem>;
export type NamespacesInstancesChatCompletionsResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface NamespacesInstancesChatCompletionsResponseChunksItemItem {
    key: string;
    metadata?: NamespacesInstancesChatCompletionsResponseChunksItemItemMetadataMap | null;
    timestamp?: number | null;
}
export type NamespacesInstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export interface NamespacesInstancesChatCompletionsResponseChunksItemScoringDetails {
    fusionMethod?: NamespacesInstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod | null;
    keywordRank?: number | null;
    keywordScore?: number | null;
    rerankingScore?: number | null;
    vectorRank?: number | null;
    vectorScore?: number | null;
}
export type NamespacesInstancesChatCompletionsResponseChunksItemSourceMediaType = "audio" | "video";
export interface NamespacesInstancesChatCompletionsResponseChunksItem {
    id: string;
    score: number;
    text: string;
    type: string;
    item?: NamespacesInstancesChatCompletionsResponseChunksItemItem | null;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the matched chunk covers. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaEndMs?: number | null;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the matched chunk begins in. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaStartMs?: number | null;
    scoringDetails?: NamespacesInstancesChatCompletionsResponseChunksItemScoringDetails | null;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: NamespacesInstancesChatCompletionsResponseChunksItemSourceMediaType | null;
}
export type NamespacesInstancesChatCompletionsResponseChunksList = Array<NamespacesInstancesChatCompletionsResponseChunksItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ChatCompletionsNamespaceInstanceResponse {
    choices: NamespacesInstancesChatCompletionsResponseChoicesList;
    chunks: NamespacesInstancesChatCompletionsResponseChunksList;
    id?: string | null;
    model?: string | null;
    object?: string | null;
}
export interface ChunksNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
    limit?: number;
    offset?: number;
}
export type NamespacesInstancesItemsChunksResultItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface NamespacesInstancesItemsChunksResultItemItem {
    key: string;
    metadata?: NamespacesInstancesItemsChunksResultItemItemMetadataMap | null;
    timestamp?: number | null;
}
export interface NamespacesInstancesItemsChunksResultItem {
    id: string;
    item: NamespacesInstancesItemsChunksResultItemItem;
    text: string;
    endByte?: number | null;
    startByte?: number | null;
}
export type NamespacesInstancesItemsChunksResultList = Array<NamespacesInstancesItemsChunksResultItem>;
export type ChunksNamespaceInstanceItemResponse = NamespacesInstancesItemsChunksResultList;
export type InstancesCreateRequestCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesCreateRequestCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesCreateRequestCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesCreateRequestCustomMetadataItem {
    dataType: InstancesCreateRequestCustomMetadataItemDataType | (string & {});
    fieldName: string;
}
export type InstancesCreateRequestCustomMetadataList = Array<InstancesCreateRequestCustomMetadataItem>;
export type InstancesCreateRequestFusionMethod = "max" | "rrf";
export interface InstancesCreateRequestIndexMethod {
    /** Enable keyword (BM25) storage backend. */
    keyword: boolean;
    /** Enable vector (embedding) storage backend. */
    vector: boolean;
}
export type InstancesCreateRequestIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesCreateRequestIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesCreateRequestIndexingOptionsKeywordTokenizer | (string & {});
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean;
}
export type InstancesCreateRequestMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesCreateRequestMetadataCreatedFromEmdashPlugin {
    type: InstancesCreateRequestMetadataCreatedFromEmdashPluginType | (string & {});
    version: string;
}
export interface InstancesCreateRequestMetadata {
    createdFromAisearchWizard?: boolean;
    createdFromEmdashPlugin?: InstancesCreateRequestMetadataCreatedFromEmdashPlugin;
    workerDomain?: string;
}
export type InstancesCreateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export interface InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint {
    /** Disable chat completions endpoint for this public endpoint. */
    disabled?: boolean;
}
export type InstancesCreateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export interface InstancesCreateRequestPublicEndpointParamsMcp {
    description?: string;
    /** Disable MCP endpoint for this public endpoint. */
    disabled?: boolean;
}
export type InstancesCreateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesCreateRequestPublicEndpointParamsRateLimit {
    periodMs?: number;
    requests?: number;
    technique?: InstancesCreateRequestPublicEndpointParamsRateLimitTechnique | (string & {});
}
export interface InstancesCreateRequestPublicEndpointParamsSearchEndpoint {
    /** Disable search endpoint for this public endpoint. */
    disabled?: boolean;
}
export interface InstancesCreateRequestPublicEndpointParams {
    authorizedHosts?: InstancesCreateRequestPublicEndpointParamsAuthorizedHostsList;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesCreateRequestPublicEndpointParamsCustomDomainsList;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean;
    enabled?: boolean;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp;
    rateLimit?: InstancesCreateRequestPublicEndpointParamsRateLimit;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
}
export type InstancesCreateRequestRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesCreateRequestRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesCreateRequestRetrievalOptionsBoostByItemDirection | (string & {});
}
export type InstancesCreateRequestRetrievalOptionsBoostByList = Array<InstancesCreateRequestRetrievalOptionsBoostByItem>;
export type InstancesCreateRequestRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesCreateRequestRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesCreateRequestRetrievalOptionsBoostByList;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: InstancesCreateRequestRetrievalOptionsKeywordMatchMode | (string & {});
}
export type InstancesCreateRequestSourceParamsExcludeItemsList = Array<string>;
export type InstancesCreateRequestSourceParamsIncludeItemsList = Array<string>;
export type InstancesCreateRequestSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesCreateRequestSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: InstancesCreateRequestSourceParamsWebCrawlerDiscoverOptionsSource | (string & {});
}
export interface InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem {
    /** Glob pattern to match against the page URL path. Uses standard glob syntax: * matches within a segment, ** crosses directories. */
    path: string;
    /** CSS selector to extract content from pages matching the path pattern. Disallowed characters: ;, `, $, {, }, . Must target a single element; if multiple elements match, the crawler ignores the selector and uses the full page. */
    selector: string;
}
export type InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesCreateRequestSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: InstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap;
    includeImages?: boolean;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList;
    useBrowserRendering?: boolean;
}
export type InstancesCreateRequestSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export type WebCrawlerCrawlOptionsSource = "all" | "sitemaps" | "links";
export interface WebCrawlerCrawlOptions {
    /** Maximum crawl depth from the seed URL. */
    depth?: number | null;
    includeExternalLinks?: boolean | null;
    includeSubdomains?: boolean | null;
    maxAge?: number | null;
    /** Where the crawler discovers URLs: sitemaps, page links, or both. Use links for sitemap-less seeds (avoids missing_sitemap rejections). */
    source?: WebCrawlerCrawlOptionsSource | (string & {}) | null;
}
export interface InstancesCreateRequestSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: InstancesCreateRequestSourceParamsWebCrawlerDiscoverOptions;
    parseOptions?: InstancesCreateRequestSourceParamsWebCrawlerParseOptions;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: InstancesCreateRequestSourceParamsWebCrawlerParseType | (string & {});
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions;
}
export interface InstancesCreateRequestSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: InstancesCreateRequestSourceParamsExcludeItemsList;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: InstancesCreateRequestSourceParamsIncludeItemsList;
    prefix?: string;
    r2Jurisdiction?: string;
    webCrawler?: InstancesCreateRequestSourceParamsWebCrawler;
}
export type InstancesCreateRequestSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type InstancesCreateRequestType = "r2" | "web-crawler";
export interface CreateInstanceRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    aiGatewayId?: string;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string;
    cache?: boolean;
    cacheThreshold?: InstancesCreateRequestCacheThreshold | (string & {});
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesCreateRequestCacheTtl | (number & {});
    chunk?: boolean;
    chunkOverlap?: number;
    chunkSize?: number;
    customMetadata?: InstancesCreateRequestCustomMetadataList;
    embeddingModel?: string;
    fusionMethod?: InstancesCreateRequestFusionMethod | (string & {});
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod;
    indexingOptions?: InstancesCreateRequestIndexingOptions;
    maxNumResults?: number;
    metadata?: InstancesCreateRequestMetadata;
    publicEndpointParams?: InstancesCreateRequestPublicEndpointParams;
    reranking?: boolean;
    rerankingModel?: string;
    retrievalOptions?: InstancesCreateRequestRetrievalOptions;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string;
    rewriteQuery?: boolean;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number;
    source?: string;
    sourceParams?: InstancesCreateRequestSourceParams;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 21600 (6h); instances crawling a domain outside the account may be set to 86400. */
    syncInterval?: InstancesCreateRequestSyncInterval | (number & {});
    tokenId?: string;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: InstancesCreateRequestType | (string & {});
}
export type InstancesCreateResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesCreateResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesCreateResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesCreateResponseCustomMetadataItem {
    dataType: InstancesCreateResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type InstancesCreateResponseCustomMetadataList = Array<InstancesCreateResponseCustomMetadataItem>;
export type InstancesCreateResponseFusionMethod = "max" | "rrf";
export type InstancesCreateResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type InstancesCreateResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesCreateResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesCreateResponseIndexingOptionsKeywordTokenizer | null;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null;
}
export type InstancesCreateResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesCreateResponseMetadataCreatedFromEmdashPlugin {
    type: InstancesCreateResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface InstancesCreateResponseMetadata {
    createdFromAisearchWizard?: boolean | null;
    createdFromEmdashPlugin?: InstancesCreateResponseMetadataCreatedFromEmdashPlugin | null;
    workerDomain?: string | null;
}
export type InstancesCreateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export interface InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint {
    /** Disable chat completions endpoint for this public endpoint. */
    disabled?: boolean | null;
}
export type InstancesCreateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export interface InstancesCreateResponsePublicEndpointParamsMcp {
    description?: string | null;
    /** Disable MCP endpoint for this public endpoint. */
    disabled?: boolean | null;
}
export type InstancesCreateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesCreateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: InstancesCreateResponsePublicEndpointParamsRateLimitTechnique | null;
}
export interface InstancesCreateResponsePublicEndpointParamsSearchEndpoint {
    /** Disable search endpoint for this public endpoint. */
    disabled?: boolean | null;
}
export interface InstancesCreateResponsePublicEndpointParams {
    authorizedHosts?: InstancesCreateResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesCreateResponsePublicEndpointParamsCustomDomainsList | null;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: InstancesCreateResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export type InstancesCreateResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesCreateResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesCreateResponseRetrievalOptionsBoostByItemDirection | null;
}
export type InstancesCreateResponseRetrievalOptionsBoostByList = Array<InstancesCreateResponseRetrievalOptionsBoostByItem>;
export type InstancesCreateResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesCreateResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesCreateResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: InstancesCreateResponseRetrievalOptionsKeywordMatchMode | null;
}
export type InstancesCreateResponseSourceParamsExcludeItemsList = Array<string>;
export type InstancesCreateResponseSourceParamsIncludeItemsList = Array<string>;
export type InstancesCreateResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesCreateResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: InstancesCreateResponseSourceParamsWebCrawlerDiscoverOptionsSource | null;
}
export type InstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type InstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesCreateResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: InstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: InstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export type InstancesCreateResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface InstancesCreateResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: InstancesCreateResponseSourceParamsWebCrawlerDiscoverOptions | null;
    parseOptions?: InstancesCreateResponseSourceParamsWebCrawlerParseOptions | null;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: InstancesCreateResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export interface InstancesCreateResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: InstancesCreateResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: InstancesCreateResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: InstancesCreateResponseSourceParamsWebCrawler | null;
}
export type InstancesCreateResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type InstancesCreateResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null;
    cache?: boolean | null;
    cacheThreshold?: InstancesCreateResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesCreateResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: InstancesCreateResponseCustomMetadataList | null;
    embeddingModel?: string | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: InstancesCreateResponseFusionMethod | null;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: InstancesCreateResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesCreateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: InstancesCreateResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: string | null;
    retrievalOptions?: InstancesCreateResponseRetrievalOptions | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null;
    rewriteQuery?: boolean | null;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: InstancesCreateResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 21600 (6h); instances crawling a domain outside the account may be set to 86400. */
    syncInterval?: InstancesCreateResponseSyncInterval | null;
    tokenId?: string | null;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: InstancesCreateResponseType | null;
}
export interface CreateInstanceJobRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    description?: string;
}
export type InstancesJobsCreateResponseSource = "user" | "schedule";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInstanceJobResponse {
    id: string;
    source: InstancesJobsCreateResponseSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export type NamespacesCreateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesCreateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesCreateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesCreateRequestPublicEndpointParamsInstancesAllowedList = Array<string>;
export type NamespacesCreateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export type NamespacesCreateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesCreateRequestPublicEndpointParamsRateLimit {
    periodMs?: number;
    requests?: number;
    technique?: NamespacesCreateRequestPublicEndpointParamsRateLimitTechnique | (string & {});
}
export type NamespacesCreateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export interface NamespacesCreateRequestPublicEndpointParams {
    authorizedHosts?: NamespacesCreateRequestPublicEndpointParamsAuthorizedHostsList;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesCreateRequestPublicEndpointParamsCustomDomainsList;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean;
    enabled?: boolean;
    /** Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must reference an existing instance in this namespace, and the list must stay within the account's multi-instance search limit. */
    instancesAllowed?: NamespacesCreateRequestPublicEndpointParamsInstancesAllowedList;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp;
    rateLimit?: NamespacesCreateRequestPublicEndpointParamsRateLimit;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
}
export interface CreateNamespaceRequest {
    accountId: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string;
    publicEndpointParams?: NamespacesCreateRequestPublicEndpointParams;
}
export type NamespacesCreateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesCreateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesCreateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesCreateResponsePublicEndpointParamsInstancesAllowedList = Array<string>;
export type NamespacesCreateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesCreateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesCreateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesCreateResponsePublicEndpointParamsRateLimitTechnique | null;
}
export type NamespacesCreateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesCreateResponsePublicEndpointParams {
    authorizedHosts?: NamespacesCreateResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesCreateResponsePublicEndpointParamsCustomDomainsList | null;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    /** Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must reference an existing instance in this namespace, and the list must stay within the account's multi-instance search limit. */
    instancesAllowed?: NamespacesCreateResponsePublicEndpointParamsInstancesAllowedList | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesCreateResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateNamespaceResponse {
    createdAt: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesCreateResponsePublicEndpointParams | null;
}
export type NamespacesInstancesCreateRequestCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesCreateRequestCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesCreateRequestCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesCreateRequestCustomMetadataItem {
    dataType: NamespacesInstancesCreateRequestCustomMetadataItemDataType | (string & {});
    fieldName: string;
}
export type NamespacesInstancesCreateRequestCustomMetadataList = Array<NamespacesInstancesCreateRequestCustomMetadataItem>;
export type NamespacesInstancesCreateRequestFusionMethod = "max" | "rrf";
export type NamespacesInstancesCreateRequestIndexMethod = InstancesCreateRequestIndexMethod;
export type NamespacesInstancesCreateRequestIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesCreateRequestIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesCreateRequestIndexingOptionsKeywordTokenizer | (string & {});
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean;
}
export type NamespacesInstancesCreateRequestMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesCreateRequestMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesCreateRequestMetadataCreatedFromEmdashPluginType | (string & {});
    version: string;
}
export interface NamespacesInstancesCreateRequestMetadata {
    createdFromAisearchWizard?: boolean;
    createdFromEmdashPlugin?: NamespacesInstancesCreateRequestMetadataCreatedFromEmdashPlugin;
    workerDomain?: string;
}
export type NamespacesInstancesCreateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesCreateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesCreateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export type NamespacesInstancesCreateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesCreateRequestPublicEndpointParamsRateLimit {
    periodMs?: number;
    requests?: number;
    technique?: NamespacesInstancesCreateRequestPublicEndpointParamsRateLimitTechnique | (string & {});
}
export type NamespacesInstancesCreateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export interface NamespacesInstancesCreateRequestPublicEndpointParams {
    authorizedHosts?: NamespacesInstancesCreateRequestPublicEndpointParamsAuthorizedHostsList;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesCreateRequestPublicEndpointParamsCustomDomainsList;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean;
    enabled?: boolean;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp;
    rateLimit?: NamespacesInstancesCreateRequestPublicEndpointParamsRateLimit;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
}
export type NamespacesInstancesCreateRequestRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesCreateRequestRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesCreateRequestRetrievalOptionsBoostByItemDirection | (string & {});
}
export type NamespacesInstancesCreateRequestRetrievalOptionsBoostByList = Array<NamespacesInstancesCreateRequestRetrievalOptionsBoostByItem>;
export type NamespacesInstancesCreateRequestRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesCreateRequestRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesCreateRequestRetrievalOptionsBoostByList;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: NamespacesInstancesCreateRequestRetrievalOptionsKeywordMatchMode | (string & {});
}
export type NamespacesInstancesCreateRequestSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesCreateRequestSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesCreateRequestSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerDiscoverOptionsSource | (string & {});
}
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap;
    includeImages?: boolean;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList;
    useBrowserRendering?: boolean;
}
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesCreateRequestSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerDiscoverOptions;
    parseOptions?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptions;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseType | (string & {});
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions;
}
export interface NamespacesInstancesCreateRequestSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: NamespacesInstancesCreateRequestSourceParamsExcludeItemsList;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: NamespacesInstancesCreateRequestSourceParamsIncludeItemsList;
    prefix?: string;
    r2Jurisdiction?: string;
    webCrawler?: NamespacesInstancesCreateRequestSourceParamsWebCrawler;
}
export type NamespacesInstancesCreateRequestSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type NamespacesInstancesCreateRequestType = "r2" | "web-crawler";
export interface CreateNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    aiGatewayId?: string;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string;
    cache?: boolean;
    cacheThreshold?: NamespacesInstancesCreateRequestCacheThreshold | (string & {});
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesCreateRequestCacheTtl | (number & {});
    chunk?: boolean;
    chunkOverlap?: number;
    chunkSize?: number;
    customMetadata?: NamespacesInstancesCreateRequestCustomMetadataList;
    embeddingModel?: string;
    fusionMethod?: NamespacesInstancesCreateRequestFusionMethod | (string & {});
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod;
    indexingOptions?: NamespacesInstancesCreateRequestIndexingOptions;
    maxNumResults?: number;
    metadata?: NamespacesInstancesCreateRequestMetadata;
    publicEndpointParams?: NamespacesInstancesCreateRequestPublicEndpointParams;
    reranking?: boolean;
    rerankingModel?: string;
    retrievalOptions?: NamespacesInstancesCreateRequestRetrievalOptions;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string;
    rewriteQuery?: boolean;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number;
    source?: string;
    sourceParams?: NamespacesInstancesCreateRequestSourceParams;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 21600 (6h); instances crawling a domain outside the account may be set to 86400. */
    syncInterval?: NamespacesInstancesCreateRequestSyncInterval | (number & {});
    tokenId?: string;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: NamespacesInstancesCreateRequestType | (string & {});
}
export type NamespacesInstancesCreateResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesCreateResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesCreateResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesCreateResponseCustomMetadataItem {
    dataType: NamespacesInstancesCreateResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type NamespacesInstancesCreateResponseCustomMetadataList = Array<NamespacesInstancesCreateResponseCustomMetadataItem>;
export type NamespacesInstancesCreateResponseFusionMethod = "max" | "rrf";
export type NamespacesInstancesCreateResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type NamespacesInstancesCreateResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesCreateResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesCreateResponseIndexingOptionsKeywordTokenizer | null;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null;
}
export type NamespacesInstancesCreateResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesCreateResponseMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesCreateResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface NamespacesInstancesCreateResponseMetadata {
    createdFromAisearchWizard?: boolean | null;
    createdFromEmdashPlugin?: NamespacesInstancesCreateResponseMetadataCreatedFromEmdashPlugin | null;
    workerDomain?: string | null;
}
export type NamespacesInstancesCreateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesCreateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesCreateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesInstancesCreateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesCreateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesInstancesCreateResponsePublicEndpointParamsRateLimitTechnique | null;
}
export type NamespacesInstancesCreateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesInstancesCreateResponsePublicEndpointParams {
    authorizedHosts?: NamespacesInstancesCreateResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesCreateResponsePublicEndpointParamsCustomDomainsList | null;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesInstancesCreateResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export type NamespacesInstancesCreateResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesCreateResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesCreateResponseRetrievalOptionsBoostByItemDirection | null;
}
export type NamespacesInstancesCreateResponseRetrievalOptionsBoostByList = Array<NamespacesInstancesCreateResponseRetrievalOptionsBoostByItem>;
export type NamespacesInstancesCreateResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesCreateResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesCreateResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: NamespacesInstancesCreateResponseRetrievalOptionsKeywordMatchMode | null;
}
export type NamespacesInstancesCreateResponseSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesCreateResponseSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesCreateResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerDiscoverOptionsSource | null;
}
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesCreateResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerDiscoverOptions | null;
    parseOptions?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptions | null;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export interface NamespacesInstancesCreateResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: NamespacesInstancesCreateResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: NamespacesInstancesCreateResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: NamespacesInstancesCreateResponseSourceParamsWebCrawler | null;
}
export type NamespacesInstancesCreateResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type NamespacesInstancesCreateResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateNamespaceInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null;
    cache?: boolean | null;
    cacheThreshold?: NamespacesInstancesCreateResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesCreateResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: NamespacesInstancesCreateResponseCustomMetadataList | null;
    embeddingModel?: string | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: NamespacesInstancesCreateResponseFusionMethod | null;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: NamespacesInstancesCreateResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: NamespacesInstancesCreateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesInstancesCreateResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: string | null;
    retrievalOptions?: NamespacesInstancesCreateResponseRetrievalOptions | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null;
    rewriteQuery?: boolean | null;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: NamespacesInstancesCreateResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 21600 (6h); instances crawling a domain outside the account may be set to 86400. */
    syncInterval?: NamespacesInstancesCreateResponseSyncInterval | null;
    tokenId?: string | null;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: NamespacesInstancesCreateResponseType | null;
}
export interface CreateNamespaceInstanceJobRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    description?: string;
}
export type NamespacesInstancesJobsCreateResponseSource = "user" | "schedule";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateNamespaceInstanceJobResponse {
    id: string;
    source: NamespacesInstancesJobsCreateResponseSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export type NamespacesInstancesItemsCreateOrUpdateRequestNextAction = "INDEX";
export interface CreateOrUpdateNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    /** Item key / filename. Must not exceed 128 characters. */
    key: string;
    nextAction: NamespacesInstancesItemsCreateOrUpdateRequestNextAction | (string & {});
    /** Wait for indexing before responding. After processing, vector-indexed instances use any time remaining in a 25s wait budget to confirm Vectorize ingestion. Processing itself continues uninterrupted and can exceed that budget. If confirmation times out, the response returns the current item state and background indexing continues. Defaults to false. */
    waitForCompletion?: boolean;
}
export type NamespacesInstancesItemsCreateOrUpdateResponseMetadataValue = string | number | boolean;
export type NamespacesInstancesItemsCreateOrUpdateResponseMetadataMap = {
    [key: string]: NamespacesInstancesItemsCreateOrUpdateResponseMetadataValue | undefined;
};
export type NamespacesInstancesItemsCreateOrUpdateResponseNextAction = "INDEX" | "DELETE";
export type NamespacesInstancesItemsCreateOrUpdateResponseStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOrUpdateNamespaceInstanceItemResponse {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    /** Built-in, configured filterable, and retained source metadata for the item. */
    metadata: NamespacesInstancesItemsCreateOrUpdateResponseMetadataMap;
    namespace: string;
    nextAction: NamespacesInstancesItemsCreateOrUpdateResponseNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsCreateOrUpdateResponseStatus;
    error?: string | null;
}
export interface CreateTokenRequest {
    accountId: string;
    cfApiId: string;
    cfApiKey: string;
    name: string;
    legacy?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    id: string;
    cfApiId: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    createdBy?: string | null;
    enabled?: boolean | null;
    legacy?: boolean | null;
    modifiedBy?: string | null;
}
export interface DeleteInstanceRequest {
    accountId: string;
    id: string;
}
export type InstancesDeleteResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesDeleteResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesDeleteResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesDeleteResponseCustomMetadataItem {
    dataType: InstancesDeleteResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type InstancesDeleteResponseCustomMetadataList = Array<InstancesDeleteResponseCustomMetadataItem>;
export type InstancesDeleteResponseFusionMethod = "max" | "rrf";
export type InstancesDeleteResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type InstancesDeleteResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesDeleteResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesDeleteResponseIndexingOptionsKeywordTokenizer | null;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null;
}
export type InstancesDeleteResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesDeleteResponseMetadataCreatedFromEmdashPlugin {
    type: InstancesDeleteResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface InstancesDeleteResponseMetadata {
    createdFromAisearchWizard?: boolean | null;
    createdFromEmdashPlugin?: InstancesDeleteResponseMetadataCreatedFromEmdashPlugin | null;
    workerDomain?: string | null;
}
export type InstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type InstancesDeleteResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type InstancesDeleteResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type InstancesDeleteResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type InstancesDeleteResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesDeleteResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: InstancesDeleteResponsePublicEndpointParamsRateLimitTechnique | null;
}
export type InstancesDeleteResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface InstancesDeleteResponsePublicEndpointParams {
    authorizedHosts?: InstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesDeleteResponsePublicEndpointParamsCustomDomainsList | null;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: InstancesDeleteResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export type InstancesDeleteResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesDeleteResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesDeleteResponseRetrievalOptionsBoostByItemDirection | null;
}
export type InstancesDeleteResponseRetrievalOptionsBoostByList = Array<InstancesDeleteResponseRetrievalOptionsBoostByItem>;
export type InstancesDeleteResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesDeleteResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesDeleteResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: InstancesDeleteResponseRetrievalOptionsKeywordMatchMode | null;
}
export type InstancesDeleteResponseSourceParamsExcludeItemsList = Array<string>;
export type InstancesDeleteResponseSourceParamsIncludeItemsList = Array<string>;
export type InstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: InstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptionsSource | null;
}
export type InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesDeleteResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export type InstancesDeleteResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface InstancesDeleteResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: InstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptions | null;
    parseOptions?: InstancesDeleteResponseSourceParamsWebCrawlerParseOptions | null;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: InstancesDeleteResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export interface InstancesDeleteResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: InstancesDeleteResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: InstancesDeleteResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: InstancesDeleteResponseSourceParamsWebCrawler | null;
}
export type InstancesDeleteResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type InstancesDeleteResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null;
    cache?: boolean | null;
    cacheThreshold?: InstancesDeleteResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesDeleteResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: InstancesDeleteResponseCustomMetadataList | null;
    embeddingModel?: string | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: InstancesDeleteResponseFusionMethod | null;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: InstancesDeleteResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesDeleteResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: InstancesDeleteResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: string | null;
    retrievalOptions?: InstancesDeleteResponseRetrievalOptions | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null;
    rewriteQuery?: boolean | null;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: InstancesDeleteResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 21600 (6h); instances crawling a domain outside the account may be set to 86400. */
    syncInterval?: InstancesDeleteResponseSyncInterval | null;
    tokenId?: string | null;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: InstancesDeleteResponseType | null;
}
export interface DeleteNamespaceRequest {
    accountId: string;
    name: string;
}
export type DeleteNamespaceResponse = unknown;
export interface DeleteNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    id: string;
}
export type NamespacesInstancesDeleteResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesDeleteResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesDeleteResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesDeleteResponseCustomMetadataItem {
    dataType: NamespacesInstancesDeleteResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type NamespacesInstancesDeleteResponseCustomMetadataList = Array<NamespacesInstancesDeleteResponseCustomMetadataItem>;
export type NamespacesInstancesDeleteResponseFusionMethod = "max" | "rrf";
export type NamespacesInstancesDeleteResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type NamespacesInstancesDeleteResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesDeleteResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesDeleteResponseIndexingOptionsKeywordTokenizer | null;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null;
}
export type NamespacesInstancesDeleteResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesDeleteResponseMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesDeleteResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface NamespacesInstancesDeleteResponseMetadata {
    createdFromAisearchWizard?: boolean | null;
    createdFromEmdashPlugin?: NamespacesInstancesDeleteResponseMetadataCreatedFromEmdashPlugin | null;
    workerDomain?: string | null;
}
export type NamespacesInstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimitTechnique | null;
}
export type NamespacesInstancesDeleteResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesInstancesDeleteResponsePublicEndpointParams {
    authorizedHosts?: NamespacesInstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesDeleteResponsePublicEndpointParamsCustomDomainsList | null;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export type NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItemDirection | null;
}
export type NamespacesInstancesDeleteResponseRetrievalOptionsBoostByList = Array<NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItem>;
export type NamespacesInstancesDeleteResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesDeleteResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesDeleteResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: NamespacesInstancesDeleteResponseRetrievalOptionsKeywordMatchMode | null;
}
export type NamespacesInstancesDeleteResponseSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesDeleteResponseSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptionsSource | null;
}
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesDeleteResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptions | null;
    parseOptions?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptions | null;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export interface NamespacesInstancesDeleteResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: NamespacesInstancesDeleteResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: NamespacesInstancesDeleteResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: NamespacesInstancesDeleteResponseSourceParamsWebCrawler | null;
}
export type NamespacesInstancesDeleteResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type NamespacesInstancesDeleteResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteNamespaceInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null;
    cache?: boolean | null;
    cacheThreshold?: NamespacesInstancesDeleteResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesDeleteResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: NamespacesInstancesDeleteResponseCustomMetadataList | null;
    embeddingModel?: string | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: NamespacesInstancesDeleteResponseFusionMethod | null;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: NamespacesInstancesDeleteResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: NamespacesInstancesDeleteResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesInstancesDeleteResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: string | null;
    retrievalOptions?: NamespacesInstancesDeleteResponseRetrievalOptions | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null;
    rewriteQuery?: boolean | null;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: NamespacesInstancesDeleteResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 21600 (6h); instances crawling a domain outside the account may be set to 86400. */
    syncInterval?: NamespacesInstancesDeleteResponseSyncInterval | null;
    tokenId?: string | null;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: NamespacesInstancesDeleteResponseType | null;
}
export interface DeleteNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteNamespaceInstanceItemResponse {
    key: string;
}
export interface DeleteTokenRequest {
    accountId: string;
    id: string;
}
export type DeleteTokenResponse = unknown;
export interface DownloadNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
}
export interface DownloadNamespaceInstanceItemResponse {
}
export interface GetInstanceJobRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
}
export type InstancesJobsGetResponseSource = "user" | "schedule";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInstanceJobResponse {
    id: string;
    source: InstancesJobsGetResponseSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export interface GetNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
}
export type NamespacesInstancesItemsGetResponseMetadataValue = string | number | boolean;
export type NamespacesInstancesItemsGetResponseMetadataMap = {
    [key: string]: NamespacesInstancesItemsGetResponseMetadataValue | undefined;
};
export type NamespacesInstancesItemsGetResponseNextAction = "INDEX" | "DELETE";
export type NamespacesInstancesItemsGetResponseStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetNamespaceInstanceItemResponse {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    /** Built-in, configured filterable, and retained source metadata for the item. */
    metadata: NamespacesInstancesItemsGetResponseMetadataMap;
    namespace: string;
    nextAction: NamespacesInstancesItemsGetResponseNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsGetResponseStatus;
    error?: string | null;
}
export interface GetNamespaceInstanceJobRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
}
export type NamespacesInstancesJobsGetResponseSource = "user" | "schedule";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetNamespaceInstanceJobResponse {
    id: string;
    source: NamespacesInstancesJobsGetResponseSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export interface ListInstanceJobsRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    page?: number;
    perPage?: number;
}
export type InstancesJobsListResultItemSource = "user" | "schedule";
export interface InstancesJobsListResultItem {
    id: string;
    source: InstancesJobsListResultItemSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export type InstancesJobsListResultList = Array<InstancesJobsListResultItem>;
export interface ListInstanceJobsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InstancesJobsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type InstancesListRequestOrderBy = "created_at";
export type InstancesListRequestOrderByDirection = "asc" | "desc";
export interface ListInstancesRequest {
    accountId: string;
    /** Return only instances with this exact Search for Agents hostname (case-insensitive). */
    hostname?: string;
    /** Return only instances in this namespace. */
    namespace?: string;
    /** Field to order results by. */
    orderBy?: InstancesListRequestOrderBy | (string & {});
    /** Order direction. */
    orderByDirection?: InstancesListRequestOrderByDirection | (string & {});
    /** Page number (1-indexed). */
    page?: number;
    /** Number of results per page. */
    perPage?: number;
    /** Filter instances whose id contains this string (case-insensitive). */
    search?: string;
}
export type InstancesListResultItemCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesListResultItemCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesListResultItemCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesListResultItemCustomMetadataItem {
    dataType: InstancesListResultItemCustomMetadataItemDataType;
    fieldName: string;
}
export type InstancesListResultItemCustomMetadataList = Array<InstancesListResultItemCustomMetadataItem>;
export type InstancesListResultItemFusionMethod = "max" | "rrf";
export interface InstancesListResultItemIndexMethod {
    keyword: boolean;
    vector: boolean;
}
export type InstancesListResultItemIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesListResultItemIndexingOptions {
    keywordTokenizer?: InstancesListResultItemIndexingOptionsKeywordTokenizer | null;
    useOcr?: boolean | null;
}
export type InstancesListResultItemMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesListResultItemMetadataCreatedFromEmdashPlugin {
    type: InstancesListResultItemMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface InstancesListResultItemMetadata {
    createdFromAisearchWizard?: boolean | null;
    createdFromEmdashPlugin?: InstancesListResultItemMetadataCreatedFromEmdashPlugin | null;
    workerDomain?: string | null;
}
export type InstancesListResultItemPublicEndpointParamsAuthorizedHostsList = Array<string>;
export interface InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint {
    disabled?: boolean | null;
}
export type InstancesListResultItemPublicEndpointParamsCustomDomainsList = Array<string>;
export interface InstancesListResultItemPublicEndpointParamsMcp {
    description?: string | null;
    disabled?: boolean | null;
}
export type InstancesListResultItemPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesListResultItemPublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: InstancesListResultItemPublicEndpointParamsRateLimitTechnique | null;
}
export type InstancesListResultItemPublicEndpointParamsSearchEndpoint = InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint;
export interface InstancesListResultItemPublicEndpointParams {
    authorizedHosts?: InstancesListResultItemPublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint | null;
    customDomains?: InstancesListResultItemPublicEndpointParamsCustomDomainsList | null;
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    mcp?: InstancesListResultItemPublicEndpointParamsMcp | null;
    rateLimit?: InstancesListResultItemPublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint | null;
}
export type InstancesListResultItemRetrievalOptionsBoostByItemDataType = "number" | "datetime" | "text" | "boolean";
export type InstancesListResultItemRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesListResultItemRetrievalOptionsBoostByItem {
    field: string;
    dataType?: InstancesListResultItemRetrievalOptionsBoostByItemDataType | null;
    direction?: InstancesListResultItemRetrievalOptionsBoostByItemDirection | null;
}
export type InstancesListResultItemRetrievalOptionsBoostByList = Array<InstancesListResultItemRetrievalOptionsBoostByItem>;
export type InstancesListResultItemRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesListResultItemRetrievalOptions {
    boostBy?: InstancesListResultItemRetrievalOptionsBoostByList | null;
    keywordMatchMode?: InstancesListResultItemRetrievalOptionsKeywordMatchMode | null;
}
export type InstancesListResultItemSourceParamsExcludeItemsList = Array<string>;
export type InstancesListResultItemSourceParamsIncludeItemsList = Array<string>;
export type InstancesListResultItemSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesListResultItemSourceParamsWebCrawlerDiscoverOptions {
    depth?: number | null;
    includeExternalLinks?: boolean | null;
    includeSubdomains?: boolean | null;
    /** Maximum number of pages to crawl. New values have a maximum of 100000; instances configured before that cap may report a higher stored value, which the crawler clamps at run time. */
    limit?: number | null;
    maxAge?: number | null;
    source?: InstancesListResultItemSourceParamsWebCrawlerDiscoverOptionsSource | null;
}
export interface InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem {
    path: string;
    selector: string;
}
export type InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesListResultItemSourceParamsWebCrawlerParseOptions {
    contentSelector?: InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    includeHeaders?: InstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    specificSitemaps?: InstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export type InstancesListResultItemSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface InstancesListResultItemSourceParamsWebCrawler {
    discoverOptions?: InstancesListResultItemSourceParamsWebCrawlerDiscoverOptions | null;
    parseOptions?: InstancesListResultItemSourceParamsWebCrawlerParseOptions | null;
    parseType?: InstancesListResultItemSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export interface InstancesListResultItemSourceParams {
    excludeItems?: InstancesListResultItemSourceParamsExcludeItemsList | null;
    includeItems?: InstancesListResultItemSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: InstancesListResultItemSourceParamsWebCrawler | null;
}
export type InstancesListResultItemSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type InstancesListResultItemType = "r2" | "web-crawler";
export interface InstancesListResultItem {
    id: string;
    aiGatewayId: string;
    aiSearchModel: string;
    cache: boolean;
    cacheThreshold: InstancesListResultItemCacheThreshold;
    cacheTtl: InstancesListResultItemCacheTtl;
    chunk: boolean;
    chunkOverlap: number;
    chunkSize: number;
    createdAt: string;
    createdBy: string;
    customMetadata: InstancesListResultItemCustomMetadataList;
    embeddingModel: string;
    enable: boolean;
    engineVersion: number;
    fusionMethod: InstancesListResultItemFusionMethod;
    hybridSearchEnabled: boolean;
    indexMethod: InstancesListResultItemIndexMethod;
    indexingOptions: InstancesListResultItemIndexingOptions;
    lastActivity: string;
    maxNumResults: number;
    metadata: InstancesListResultItemMetadata;
    modifiedAt: string;
    modifiedBy: string;
    namespace: string;
    paused: boolean;
    publicEndpointId: string;
    publicEndpointParams: InstancesListResultItemPublicEndpointParams;
    reranking: boolean;
    rerankingModel: string;
    retrievalOptions: InstancesListResultItemRetrievalOptions;
    rewriteModel: string;
    rewriteQuery: boolean;
    scoreThreshold: number;
    source: string;
    sourceParams: InstancesListResultItemSourceParams;
    status: string;
    summarization: boolean;
    summarizationModel: string;
    syncInterval: InstancesListResultItemSyncInterval;
    systemPromptAiSearch: string;
    systemPromptIndexSummarization: string;
    systemPromptRewriteQuery: string;
    tokenId: string;
    type: InstancesListResultItemType;
}
export type InstancesListResultList = Array<InstancesListResultItem>;
export interface ListInstancesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InstancesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type NamespacesInstancesItemsListRequestSortBy = "status" | "modified_at";
export type NamespacesInstancesItemsListRequestStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
export interface ListNamespaceInstanceItemsRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    /** Return only the item with this unique ID. Returns at most one item. */
    itemId?: string;
    /** Return only items with this exact key (object key / filename). Each key is unique within a source, so combine with `source` to disambiguate across data sources. */
    key?: string;
    /** JSON-encoded metadata filter using Vectorize filter syntax. Examples: {"folder":"reports/"}, {"timestamp":{"$gte":1700000000000}}, {"folder":{"$in":["docs/","reports/"]}}. */
    metadataFilter?: string;
    page?: number;
    perPage?: number;
    search?: string;
    /** Sort order for items. "status" (default) sorts items according to status priority, then last_seen_at. "modified_at" sorts items according to file modification time (most recent first), falling back to created_at. */
    sortBy?: NamespacesInstancesItemsListRequestSortBy | (string & {});
    /** Return only items with this source_id. Use "builtin" for uploaded files, or a source identifier like "web-crawler: https://example.com". */
    source?: string;
    status?: NamespacesInstancesItemsListRequestStatus | (string & {});
}
export type NamespacesInstancesItemsListResultItemMetadataValue = string | number | boolean;
export type NamespacesInstancesItemsListResultItemMetadataMap = {
    [key: string]: NamespacesInstancesItemsListResultItemMetadataValue | undefined;
};
export type NamespacesInstancesItemsListResultItemNextAction = "INDEX" | "DELETE";
export type NamespacesInstancesItemsListResultItemStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
export interface NamespacesInstancesItemsListResultItem {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    /** Built-in, configured filterable, and retained source metadata for the item. */
    metadata: NamespacesInstancesItemsListResultItemMetadataMap;
    namespace: string;
    nextAction: NamespacesInstancesItemsListResultItemNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsListResultItemStatus;
    error?: string | null;
}
export type NamespacesInstancesItemsListResultList = Array<NamespacesInstancesItemsListResultItem>;
export interface ListNamespaceInstanceItemsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesInstancesItemsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListNamespaceInstanceJobsRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    page?: number;
    perPage?: number;
}
export type NamespacesInstancesJobsListResultItemSource = "user" | "schedule";
export interface NamespacesInstancesJobsListResultItem {
    id: string;
    source: NamespacesInstancesJobsListResultItemSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export type NamespacesInstancesJobsListResultList = Array<NamespacesInstancesJobsListResultItem>;
export interface ListNamespaceInstanceJobsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesInstancesJobsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type NamespacesInstancesListRequestOrderBy = "created_at";
export type NamespacesInstancesListRequestOrderByDirection = "asc" | "desc";
export interface ListNamespaceInstancesRequest {
    accountId: string;
    namespace: string;
    /** Return only instances with this exact Search for Agents hostname (case-insensitive). */
    hostname?: string;
    /** Field to order results by. */
    orderBy?: NamespacesInstancesListRequestOrderBy | (string & {});
    /** Order direction. */
    orderByDirection?: NamespacesInstancesListRequestOrderByDirection | (string & {});
    /** Page number (1-indexed). */
    page?: number;
    /** Number of results per page. */
    perPage?: number;
    /** Filter instances whose id contains this string (case-insensitive). */
    search?: string;
}
export type NamespacesInstancesListResultItemCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesListResultItemCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesListResultItemCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesListResultItemCustomMetadataItem {
    dataType: NamespacesInstancesListResultItemCustomMetadataItemDataType;
    fieldName: string;
}
export type NamespacesInstancesListResultItemCustomMetadataList = Array<NamespacesInstancesListResultItemCustomMetadataItem>;
export type NamespacesInstancesListResultItemFusionMethod = "max" | "rrf";
export type NamespacesInstancesListResultItemIndexMethod = InstancesListResultItemIndexMethod;
export type NamespacesInstancesListResultItemIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesListResultItemIndexingOptions {
    keywordTokenizer?: NamespacesInstancesListResultItemIndexingOptionsKeywordTokenizer | null;
    useOcr?: boolean | null;
}
export type NamespacesInstancesListResultItemMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesListResultItemMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesListResultItemMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface NamespacesInstancesListResultItemMetadata {
    createdFromAisearchWizard?: boolean | null;
    createdFromEmdashPlugin?: NamespacesInstancesListResultItemMetadataCreatedFromEmdashPlugin | null;
    workerDomain?: string | null;
}
export type NamespacesInstancesListResultItemPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint = InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesListResultItemPublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesListResultItemPublicEndpointParamsMcp = InstancesListResultItemPublicEndpointParamsMcp;
export type NamespacesInstancesListResultItemPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesListResultItemPublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesInstancesListResultItemPublicEndpointParamsRateLimitTechnique | null;
}
export type NamespacesInstancesListResultItemPublicEndpointParamsSearchEndpoint = InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint;
export interface NamespacesInstancesListResultItemPublicEndpointParams {
    authorizedHosts?: NamespacesInstancesListResultItemPublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint | null;
    customDomains?: NamespacesInstancesListResultItemPublicEndpointParamsCustomDomainsList | null;
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    mcp?: InstancesListResultItemPublicEndpointParamsMcp | null;
    rateLimit?: NamespacesInstancesListResultItemPublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint | null;
}
export type NamespacesInstancesListResultItemRetrievalOptionsBoostByItemDataType = "number" | "datetime" | "text" | "boolean";
export type NamespacesInstancesListResultItemRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesListResultItemRetrievalOptionsBoostByItem {
    field: string;
    dataType?: NamespacesInstancesListResultItemRetrievalOptionsBoostByItemDataType | null;
    direction?: NamespacesInstancesListResultItemRetrievalOptionsBoostByItemDirection | null;
}
export type NamespacesInstancesListResultItemRetrievalOptionsBoostByList = Array<NamespacesInstancesListResultItemRetrievalOptionsBoostByItem>;
export type NamespacesInstancesListResultItemRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesListResultItemRetrievalOptions {
    boostBy?: NamespacesInstancesListResultItemRetrievalOptionsBoostByList | null;
    keywordMatchMode?: NamespacesInstancesListResultItemRetrievalOptionsKeywordMatchMode | null;
}
export type NamespacesInstancesListResultItemSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesListResultItemSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesListResultItemSourceParamsWebCrawlerDiscoverOptions {
    depth?: number | null;
    includeExternalLinks?: boolean | null;
    includeSubdomains?: boolean | null;
    /** Maximum number of pages to crawl. New values have a maximum of 100000; instances configured before that cap may report a higher stored value, which the crawler clamps at run time. */
    limit?: number | null;
    maxAge?: number | null;
    source?: NamespacesInstancesListResultItemSourceParamsWebCrawlerDiscoverOptionsSource | null;
}
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptions {
    contentSelector?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    includeHeaders?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    specificSitemaps?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesListResultItemSourceParamsWebCrawler {
    discoverOptions?: NamespacesInstancesListResultItemSourceParamsWebCrawlerDiscoverOptions | null;
    parseOptions?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptions | null;
    parseType?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export interface NamespacesInstancesListResultItemSourceParams {
    excludeItems?: NamespacesInstancesListResultItemSourceParamsExcludeItemsList | null;
    includeItems?: NamespacesInstancesListResultItemSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: NamespacesInstancesListResultItemSourceParamsWebCrawler | null;
}
export type NamespacesInstancesListResultItemSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type NamespacesInstancesListResultItemType = "r2" | "web-crawler";
export interface NamespacesInstancesListResultItem {
    id: string;
    aiGatewayId: string;
    aiSearchModel: string;
    cache: boolean;
    cacheThreshold: NamespacesInstancesListResultItemCacheThreshold;
    cacheTtl: NamespacesInstancesListResultItemCacheTtl;
    chunk: boolean;
    chunkOverlap: number;
    chunkSize: number;
    createdAt: string;
    createdBy: string;
    customMetadata: NamespacesInstancesListResultItemCustomMetadataList;
    embeddingModel: string;
    enable: boolean;
    engineVersion: number;
    fusionMethod: NamespacesInstancesListResultItemFusionMethod;
    hybridSearchEnabled: boolean;
    indexMethod: InstancesListResultItemIndexMethod;
    indexingOptions: NamespacesInstancesListResultItemIndexingOptions;
    lastActivity: string;
    maxNumResults: number;
    metadata: NamespacesInstancesListResultItemMetadata;
    modifiedAt: string;
    modifiedBy: string;
    namespace: string;
    paused: boolean;
    publicEndpointId: string;
    publicEndpointParams: NamespacesInstancesListResultItemPublicEndpointParams;
    reranking: boolean;
    rerankingModel: string;
    retrievalOptions: NamespacesInstancesListResultItemRetrievalOptions;
    rewriteModel: string;
    rewriteQuery: boolean;
    scoreThreshold: number;
    source: string;
    sourceParams: NamespacesInstancesListResultItemSourceParams;
    status: string;
    summarization: boolean;
    summarizationModel: string;
    syncInterval: NamespacesInstancesListResultItemSyncInterval;
    systemPromptAiSearch: string;
    systemPromptIndexSummarization: string;
    systemPromptRewriteQuery: string;
    tokenId: string;
    type: NamespacesInstancesListResultItemType;
}
export type NamespacesInstancesListResultList = Array<NamespacesInstancesListResultItem>;
export interface ListNamespaceInstancesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesInstancesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListNamespacesRequest {
    accountId: string;
    /** Page number (1-indexed). */
    page?: number;
    /** Number of results per page. */
    perPage?: number;
    /** Filter namespaces whose name or description contains this string (case-insensitive). */
    search?: string;
}
export type NamespacesListResultItemPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesListResultItemPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesListResultItemPublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesListResultItemPublicEndpointParamsInstancesAllowedList = Array<string>;
export type NamespacesListResultItemPublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesListResultItemPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesListResultItemPublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesListResultItemPublicEndpointParamsRateLimitTechnique | null;
}
export type NamespacesListResultItemPublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesListResultItemPublicEndpointParams {
    authorizedHosts?: NamespacesListResultItemPublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesListResultItemPublicEndpointParamsCustomDomainsList | null;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    /** Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must reference an existing instance in this namespace, and the list must stay within the account's multi-instance search limit. */
    instancesAllowed?: NamespacesListResultItemPublicEndpointParamsInstancesAllowedList | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesListResultItemPublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export interface NamespacesListResultItem {
    createdAt: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesListResultItemPublicEndpointParams | null;
}
export type NamespacesListResultList = Array<NamespacesListResultItem>;
export interface ListNamespacesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListTokensRequest {
    accountId: string;
    /** Page number (1-indexed). */
    page?: number;
    /** Number of results per page. */
    perPage?: number;
    /** Filter tokens whose name contains this string (case-insensitive). */
    search?: string;
}
export interface TokensListResultItem {
    id: string;
    cfApiId: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    createdBy?: string | null;
    enabled?: boolean | null;
    legacy?: boolean | null;
    modifiedBy?: string | null;
}
export type TokensListResultList = Array<TokensListResultItem>;
export interface ListTokensResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TokensListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface LogsInstanceJobRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
    page?: number;
    perPage?: number;
}
export interface InstancesJobsLogsResultItem {
    id: number;
    createdAt: number;
    message: string;
    messageType: number;
}
export type InstancesJobsLogsResultList = Array<InstancesJobsLogsResultItem>;
export type LogsInstanceJobResponse = InstancesJobsLogsResultList;
export interface LogsNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
    cursor?: string;
    limit?: number;
}
export interface NamespacesInstancesItemsLogsResultItem {
    action: string;
    chunkCount: number;
    errorType: string;
    fileKey: string;
    message: string;
    processingTimeMs: number;
    timestamp: string;
}
export type NamespacesInstancesItemsLogsResultList = Array<NamespacesInstancesItemsLogsResultItem>;
export type LogsNamespaceInstanceItemResponse = NamespacesInstancesItemsLogsResultList;
export interface LogsNamespaceInstanceJobRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
    page?: number;
    perPage?: number;
}
export type NamespacesInstancesJobsLogsResultItem = InstancesJobsLogsResultItem;
export type NamespacesInstancesJobsLogsResultList = Array<InstancesJobsLogsResultItem>;
export type LogsNamespaceInstanceJobResponse = NamespacesInstancesJobsLogsResultList;
export interface MoveNamespacesInstanceRequest {
    accountId: string;
    /** Current namespace of the instance. */
    namespace: string;
    /** Instance id. */
    id: string;
    /** Target namespace to move the instance into. */
    newNamespace: string;
}
export type MoveNamespacesInstanceResponse = unknown;
export type NamespacesInstancesJobsUpdateRequestAction = "cancel";
export interface PatchNamespaceInstanceJobRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
    action: NamespacesInstancesJobsUpdateRequestAction | (string & {});
}
export type NamespacesInstancesJobsUpdateResponseSource = "user" | "schedule";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchNamespaceInstanceJobResponse {
    id: string;
    source: NamespacesInstancesJobsUpdateResponseSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export interface ReadInstanceRequest {
    accountId: string;
    id: string;
}
export type InstancesReadResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesReadResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesReadResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesReadResponseCustomMetadataItem {
    dataType: InstancesReadResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type InstancesReadResponseCustomMetadataList = Array<InstancesReadResponseCustomMetadataItem>;
export type InstancesReadResponseFusionMethod = "max" | "rrf";
export type InstancesReadResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type InstancesReadResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesReadResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesReadResponseIndexingOptionsKeywordTokenizer | null;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null;
}
export type InstancesReadResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesReadResponseMetadataCreatedFromEmdashPlugin {
    type: InstancesReadResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface InstancesReadResponseMetadata {
    createdFromAisearchWizard?: boolean | null;
    createdFromEmdashPlugin?: InstancesReadResponseMetadataCreatedFromEmdashPlugin | null;
    workerDomain?: string | null;
}
export type InstancesReadResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type InstancesReadResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type InstancesReadResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type InstancesReadResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type InstancesReadResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesReadResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: InstancesReadResponsePublicEndpointParamsRateLimitTechnique | null;
}
export type InstancesReadResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface InstancesReadResponsePublicEndpointParams {
    authorizedHosts?: InstancesReadResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesReadResponsePublicEndpointParamsCustomDomainsList | null;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: InstancesReadResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export type InstancesReadResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesReadResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesReadResponseRetrievalOptionsBoostByItemDirection | null;
}
export type InstancesReadResponseRetrievalOptionsBoostByList = Array<InstancesReadResponseRetrievalOptionsBoostByItem>;
export type InstancesReadResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesReadResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesReadResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: InstancesReadResponseRetrievalOptionsKeywordMatchMode | null;
}
export type InstancesReadResponseSourceParamsExcludeItemsList = Array<string>;
export type InstancesReadResponseSourceParamsIncludeItemsList = Array<string>;
export type InstancesReadResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesReadResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: InstancesReadResponseSourceParamsWebCrawlerDiscoverOptionsSource | null;
}
export type InstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type InstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesReadResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: InstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: InstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export type InstancesReadResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface InstancesReadResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: InstancesReadResponseSourceParamsWebCrawlerDiscoverOptions | null;
    parseOptions?: InstancesReadResponseSourceParamsWebCrawlerParseOptions | null;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: InstancesReadResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export interface InstancesReadResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: InstancesReadResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: InstancesReadResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: InstancesReadResponseSourceParamsWebCrawler | null;
}
export type InstancesReadResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type InstancesReadResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ReadInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null;
    cache?: boolean | null;
    cacheThreshold?: InstancesReadResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesReadResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: InstancesReadResponseCustomMetadataList | null;
    embeddingModel?: string | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: InstancesReadResponseFusionMethod | null;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: InstancesReadResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesReadResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: InstancesReadResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: string | null;
    retrievalOptions?: InstancesReadResponseRetrievalOptions | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null;
    rewriteQuery?: boolean | null;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: InstancesReadResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 21600 (6h); instances crawling a domain outside the account may be set to 86400. */
    syncInterval?: InstancesReadResponseSyncInterval | null;
    tokenId?: string | null;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: InstancesReadResponseType | null;
}
export interface ReadNamespaceRequest {
    accountId: string;
    name: string;
}
export type NamespacesReadResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesReadResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesReadResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesReadResponsePublicEndpointParamsInstancesAllowedList = Array<string>;
export type NamespacesReadResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesReadResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesReadResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesReadResponsePublicEndpointParamsRateLimitTechnique | null;
}
export type NamespacesReadResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesReadResponsePublicEndpointParams {
    authorizedHosts?: NamespacesReadResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesReadResponsePublicEndpointParamsCustomDomainsList | null;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    /** Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must reference an existing instance in this namespace, and the list must stay within the account's multi-instance search limit. */
    instancesAllowed?: NamespacesReadResponsePublicEndpointParamsInstancesAllowedList | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesReadResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ReadNamespaceResponse {
    createdAt: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesReadResponsePublicEndpointParams | null;
}
export interface ReadNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    id: string;
}
export type NamespacesInstancesReadResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesReadResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesReadResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesReadResponseCustomMetadataItem {
    dataType: NamespacesInstancesReadResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type NamespacesInstancesReadResponseCustomMetadataList = Array<NamespacesInstancesReadResponseCustomMetadataItem>;
export type NamespacesInstancesReadResponseFusionMethod = "max" | "rrf";
export type NamespacesInstancesReadResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type NamespacesInstancesReadResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesReadResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesReadResponseIndexingOptionsKeywordTokenizer | null;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null;
}
export type NamespacesInstancesReadResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesReadResponseMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesReadResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface NamespacesInstancesReadResponseMetadata {
    createdFromAisearchWizard?: boolean | null;
    createdFromEmdashPlugin?: NamespacesInstancesReadResponseMetadataCreatedFromEmdashPlugin | null;
    workerDomain?: string | null;
}
export type NamespacesInstancesReadResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesReadResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesReadResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesReadResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesInstancesReadResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesReadResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesInstancesReadResponsePublicEndpointParamsRateLimitTechnique | null;
}
export type NamespacesInstancesReadResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesInstancesReadResponsePublicEndpointParams {
    authorizedHosts?: NamespacesInstancesReadResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesReadResponsePublicEndpointParamsCustomDomainsList | null;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesInstancesReadResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export type NamespacesInstancesReadResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesReadResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesReadResponseRetrievalOptionsBoostByItemDirection | null;
}
export type NamespacesInstancesReadResponseRetrievalOptionsBoostByList = Array<NamespacesInstancesReadResponseRetrievalOptionsBoostByItem>;
export type NamespacesInstancesReadResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesReadResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesReadResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: NamespacesInstancesReadResponseRetrievalOptionsKeywordMatchMode | null;
}
export type NamespacesInstancesReadResponseSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesReadResponseSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesReadResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: NamespacesInstancesReadResponseSourceParamsWebCrawlerDiscoverOptionsSource | null;
}
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesReadResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: NamespacesInstancesReadResponseSourceParamsWebCrawlerDiscoverOptions | null;
    parseOptions?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptions | null;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export interface NamespacesInstancesReadResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: NamespacesInstancesReadResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: NamespacesInstancesReadResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: NamespacesInstancesReadResponseSourceParamsWebCrawler | null;
}
export type NamespacesInstancesReadResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type NamespacesInstancesReadResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ReadNamespaceInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null;
    cache?: boolean | null;
    cacheThreshold?: NamespacesInstancesReadResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesReadResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: NamespacesInstancesReadResponseCustomMetadataList | null;
    embeddingModel?: string | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: NamespacesInstancesReadResponseFusionMethod | null;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: NamespacesInstancesReadResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: NamespacesInstancesReadResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesInstancesReadResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: string | null;
    retrievalOptions?: NamespacesInstancesReadResponseRetrievalOptions | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null;
    rewriteQuery?: boolean | null;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: NamespacesInstancesReadResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 21600 (6h); instances crawling a domain outside the account may be set to 86400. */
    syncInterval?: NamespacesInstancesReadResponseSyncInterval | null;
    tokenId?: string | null;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: NamespacesInstancesReadResponseType | null;
}
export interface ReadTokenRequest {
    accountId: string;
    id: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ReadTokenResponse {
    id: string;
    cfApiId: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    createdBy?: string | null;
    enabled?: boolean | null;
    legacy?: boolean | null;
    modifiedBy?: string | null;
}
export type InstancesSearchRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export interface InstancesSearchRequestAiSearchOptionsCache {
    cacheThreshold?: InstancesSearchRequestAiSearchOptionsCacheCacheThreshold | (string & {});
    enabled?: boolean;
}
export type InstancesSearchRequestAiSearchOptionsCustomMetadataValue = string | number | boolean;
export type InstancesSearchRequestAiSearchOptionsCustomMetadataMap = {
    [key: string]: InstancesSearchRequestAiSearchOptionsCustomMetadataValue | undefined;
};
export type InstancesSearchRequestAiSearchOptionsQueryRewrite = InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
export type InstancesSearchRequestAiSearchOptionsReranking = InstancesChatCompletionsRequestAiSearchOptionsReranking;
export type InstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesSearchRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {});
}
export type InstancesSearchRequestAiSearchOptionsRetrievalBoostByList = Array<InstancesSearchRequestAiSearchOptionsRetrievalBoostByItem>;
export type InstancesSearchRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export type InstancesSearchRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export type InstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export type InstancesSearchRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export interface InstancesSearchRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesSearchRequestAiSearchOptionsRetrievalBoostByList;
    contextExpansion?: number;
    filters?: InstancesSearchRequestAiSearchOptionsRetrievalFiltersMap;
    fusionMethod?: InstancesSearchRequestAiSearchOptionsRetrievalFusionMethod | (string & {});
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: InstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {});
    /** Minimum similarity score a chunk must reach to be returned. When omitted, falls back to the instance-level score_threshold, then to 0.4. */
    matchThreshold?: number;
    /** Maximum number of results to return. When omitted, falls back to the instance-level max_num_results, then to 10. */
    maxNumResults?: number;
    retrievalType?: InstancesSearchRequestAiSearchOptionsRetrievalRetrievalType | (string & {});
    returnOnFailure?: boolean;
}
export interface InstancesSearchRequestAiSearchOptions {
    cache?: InstancesSearchRequestAiSearchOptionsCache;
    /** Metadata added to AI Gateway logs for requests this operation triggers. Accepts up to 2 string, number, or boolean entries. Reserved keys: 'ai-search', 'task', 'origin', and any key beginning with 'cf.'. */
    customMetadata?: InstancesSearchRequestAiSearchOptionsCustomMetadataMap;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking;
    retrieval?: InstancesSearchRequestAiSearchOptionsRetrieval;
}
export type InstancesSearchRequestMessagesItemContentCase1ItemCase0Type = "text";
export interface InstancesSearchRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: InstancesSearchRequestMessagesItemContentCase1ItemCase0Type;
}
export type InstancesSearchRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type InstancesSearchRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export interface InstancesSearchRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: InstancesSearchRequestMessagesItemContentCase1ItemCase1Type;
}
export type InstancesSearchRequestMessagesItemContentCase1ItemCase2File = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
export type InstancesSearchRequestMessagesItemContentCase1ItemCase2Type = "file";
export interface InstancesSearchRequestMessagesItemContentCase1ItemCase2 {
    file: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
    type: InstancesSearchRequestMessagesItemContentCase1ItemCase2Type;
}
export type InstancesSearchRequestMessagesItemContentCase1Item = InstancesSearchRequestMessagesItemContentCase1ItemCase0 | InstancesSearchRequestMessagesItemContentCase1ItemCase1 | InstancesSearchRequestMessagesItemContentCase1ItemCase2;
export type InstancesSearchRequestMessagesItemContentCase1List = Array<InstancesSearchRequestMessagesItemContentCase1Item>;
export type InstancesSearchRequestMessagesItemContent = string | InstancesSearchRequestMessagesItemContentCase1List;
export type InstancesSearchRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface InstancesSearchRequestMessagesItem {
    content: InstancesSearchRequestMessagesItemContent;
    role: InstancesSearchRequestMessagesItemRole | (string & {});
}
export type InstancesSearchRequestMessagesList = Array<InstancesSearchRequestMessagesItem>;
export interface SearchInstanceRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    aiSearchOptions?: InstancesSearchRequestAiSearchOptions;
    /** OpenAI-compatible message array. For multimodal queries, set the last user message's `content` to an array of typed parts: `[{type:'text', text:'...'}, {type:'image_url', image_url:{url:'...'}}]`. Image inputs require the RAG's embedding_model to declare 'image' in supported_modalities. */
    messages?: InstancesSearchRequestMessagesList;
    /** A simple text query string. Alternative to 'messages' -- provide either this or 'messages', not both. */
    query?: string;
}
export type InstancesSearchResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface InstancesSearchResponseChunksItemItem {
    key: string;
    metadata?: InstancesSearchResponseChunksItemItemMetadataMap | null;
    timestamp?: number | null;
}
export type InstancesSearchResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export interface InstancesSearchResponseChunksItemScoringDetails {
    fusionMethod?: InstancesSearchResponseChunksItemScoringDetailsFusionMethod | null;
    keywordRank?: number | null;
    keywordScore?: number | null;
    rerankingScore?: number | null;
    vectorRank?: number | null;
    vectorScore?: number | null;
}
export type InstancesSearchResponseChunksItemSourceMediaType = "audio" | "video";
export interface InstancesSearchResponseChunksItem {
    id: string;
    score: number;
    text: string;
    type: string;
    item?: InstancesSearchResponseChunksItemItem | null;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the matched chunk covers. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaEndMs?: number | null;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the matched chunk begins in. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaStartMs?: number | null;
    scoringDetails?: InstancesSearchResponseChunksItemScoringDetails | null;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: InstancesSearchResponseChunksItemSourceMediaType | null;
}
export type InstancesSearchResponseChunksList = Array<InstancesSearchResponseChunksItem>;
export type InstancesSearchResponseQueryKind = "text" | "image" | "multimodal";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchInstanceResponse {
    chunks: InstancesSearchResponseChunksList;
    queryKind: InstancesSearchResponseQueryKind;
    searchQuery?: string | null;
}
export type NamespacesSearchRequestAiSearchOptionsInstanceIdsList = Array<string>;
export type NamespacesSearchRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export interface NamespacesSearchRequestAiSearchOptionsCache {
    cacheThreshold?: NamespacesSearchRequestAiSearchOptionsCacheCacheThreshold | (string & {});
    enabled?: boolean;
}
export type NamespacesSearchRequestAiSearchOptionsCustomMetadataValue = string | number | boolean;
export type NamespacesSearchRequestAiSearchOptionsCustomMetadataMap = {
    [key: string]: NamespacesSearchRequestAiSearchOptionsCustomMetadataValue | undefined;
};
export type NamespacesSearchRequestAiSearchOptionsQueryRewrite = InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
export type NamespacesSearchRequestAiSearchOptionsReranking = InstancesChatCompletionsRequestAiSearchOptionsReranking;
export type NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {});
}
export type NamespacesSearchRequestAiSearchOptionsRetrievalBoostByList = Array<NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItem>;
export type NamespacesSearchRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export type NamespacesSearchRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export type NamespacesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export type NamespacesSearchRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export interface NamespacesSearchRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesSearchRequestAiSearchOptionsRetrievalBoostByList;
    contextExpansion?: number;
    filters?: NamespacesSearchRequestAiSearchOptionsRetrievalFiltersMap;
    fusionMethod?: NamespacesSearchRequestAiSearchOptionsRetrievalFusionMethod | (string & {});
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: NamespacesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {});
    /** Minimum score a chunk must reach to be returned. When omitted, each instance's chunks are filtered by that instance's score_threshold, capped at 0.4. */
    matchThreshold?: number;
    /** Maximum number of merged results to return. When omitted, defaults to the sum of the searched instances' max_num_results (each falling back to 10), up to 50. */
    maxNumResults?: number;
    retrievalType?: NamespacesSearchRequestAiSearchOptionsRetrievalRetrievalType | (string & {});
    returnOnFailure?: boolean;
}
export interface NamespacesSearchRequestAiSearchOptions {
    instanceIds: NamespacesSearchRequestAiSearchOptionsInstanceIdsList;
    cache?: NamespacesSearchRequestAiSearchOptionsCache;
    /** Metadata added to AI Gateway logs for requests this operation triggers. Accepts up to 2 string, number, or boolean entries. Reserved keys: 'ai-search', 'task', 'origin', and any key beginning with 'cf.'. */
    customMetadata?: NamespacesSearchRequestAiSearchOptionsCustomMetadataMap;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking;
    retrieval?: NamespacesSearchRequestAiSearchOptionsRetrieval;
}
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase0Type = "text";
export interface NamespacesSearchRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: NamespacesSearchRequestMessagesItemContentCase1ItemCase0Type;
}
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export interface NamespacesSearchRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesSearchRequestMessagesItemContentCase1ItemCase1Type;
}
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase2File = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase2Type = "file";
export interface NamespacesSearchRequestMessagesItemContentCase1ItemCase2 {
    file: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
    type: NamespacesSearchRequestMessagesItemContentCase1ItemCase2Type;
}
export type NamespacesSearchRequestMessagesItemContentCase1Item = NamespacesSearchRequestMessagesItemContentCase1ItemCase0 | NamespacesSearchRequestMessagesItemContentCase1ItemCase1 | NamespacesSearchRequestMessagesItemContentCase1ItemCase2;
export type NamespacesSearchRequestMessagesItemContentCase1List = Array<NamespacesSearchRequestMessagesItemContentCase1Item>;
export type NamespacesSearchRequestMessagesItemContent = string | NamespacesSearchRequestMessagesItemContentCase1List;
export type NamespacesSearchRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface NamespacesSearchRequestMessagesItem {
    content: NamespacesSearchRequestMessagesItemContent;
    role: NamespacesSearchRequestMessagesItemRole | (string & {});
}
export type NamespacesSearchRequestMessagesList = Array<NamespacesSearchRequestMessagesItem>;
export interface SearchNamespaceRequest {
    accountId: string;
    name: string;
    aiSearchOptions: NamespacesSearchRequestAiSearchOptions;
    /** OpenAI-compatible message array. For multimodal queries, set the last user message's `content` to an array of typed parts: `[{type:'text', text:'...'}, {type:'image_url', image_url:{url:'...'}}]`. Image inputs require the RAG's embedding_model to declare 'image' in supported_modalities. */
    messages?: NamespacesSearchRequestMessagesList;
    /** A simple text query string. Alternative to 'messages' -- provide either this or 'messages', not both. */
    query?: string;
}
export type NamespacesSearchResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface NamespacesSearchResponseChunksItemItem {
    key: string;
    metadata?: NamespacesSearchResponseChunksItemItemMetadataMap | null;
    timestamp?: number | null;
}
export type NamespacesSearchResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export interface NamespacesSearchResponseChunksItemScoringDetails {
    fusionMethod?: NamespacesSearchResponseChunksItemScoringDetailsFusionMethod | null;
    keywordRank?: number | null;
    keywordScore?: number | null;
    rerankingScore?: number | null;
    vectorRank?: number | null;
    vectorScore?: number | null;
}
export type NamespacesSearchResponseChunksItemSourceMediaType = "audio" | "video";
export interface NamespacesSearchResponseChunksItem {
    id: string;
    instanceId: string;
    score: number;
    text: string;
    type: string;
    item?: NamespacesSearchResponseChunksItemItem | null;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the matched chunk covers. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaEndMs?: number | null;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the matched chunk begins in. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaStartMs?: number | null;
    scoringDetails?: NamespacesSearchResponseChunksItemScoringDetails | null;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: NamespacesSearchResponseChunksItemSourceMediaType | null;
}
export type NamespacesSearchResponseChunksList = Array<NamespacesSearchResponseChunksItem>;
export type NamespacesSearchResponseQueryKind = "text" | "image" | "multimodal";
export interface NamespacesSearchResponseErrorsItem {
    instanceId: string;
    message: string;
}
export type NamespacesSearchResponseErrorsList = Array<NamespacesSearchResponseErrorsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchNamespaceResponse {
    chunks: NamespacesSearchResponseChunksList;
    queryKind: NamespacesSearchResponseQueryKind;
    errors?: NamespacesSearchResponseErrorsList | null;
    searchQuery?: string | null;
}
export type NamespacesInstancesSearchRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export interface NamespacesInstancesSearchRequestAiSearchOptionsCache {
    cacheThreshold?: NamespacesInstancesSearchRequestAiSearchOptionsCacheCacheThreshold | (string & {});
    enabled?: boolean;
}
export type NamespacesInstancesSearchRequestAiSearchOptionsCustomMetadataValue = string | number | boolean;
export type NamespacesInstancesSearchRequestAiSearchOptionsCustomMetadataMap = {
    [key: string]: NamespacesInstancesSearchRequestAiSearchOptionsCustomMetadataValue | undefined;
};
export type NamespacesInstancesSearchRequestAiSearchOptionsQueryRewrite = InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
export type NamespacesInstancesSearchRequestAiSearchOptionsReranking = InstancesChatCompletionsRequestAiSearchOptionsReranking;
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {});
}
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByList = Array<NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItem>;
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export interface NamespacesInstancesSearchRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByList;
    contextExpansion?: number;
    filters?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFiltersMap;
    fusionMethod?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFusionMethod | (string & {});
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {});
    /** Minimum similarity score a chunk must reach to be returned. When omitted, falls back to the instance-level score_threshold, then to 0.4. */
    matchThreshold?: number;
    /** Maximum number of results to return. When omitted, falls back to the instance-level max_num_results, then to 10. */
    maxNumResults?: number;
    retrievalType?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalRetrievalType | (string & {});
    returnOnFailure?: boolean;
}
export interface NamespacesInstancesSearchRequestAiSearchOptions {
    cache?: NamespacesInstancesSearchRequestAiSearchOptionsCache;
    /** Metadata added to AI Gateway logs for requests this operation triggers. Accepts up to 2 string, number, or boolean entries. Reserved keys: 'ai-search', 'task', 'origin', and any key beginning with 'cf.'. */
    customMetadata?: NamespacesInstancesSearchRequestAiSearchOptionsCustomMetadataMap;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking;
    retrieval?: NamespacesInstancesSearchRequestAiSearchOptionsRetrieval;
}
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0Type = "text";
export interface NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0Type;
}
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export interface NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1Type;
}
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase2File = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase2Type = "file";
export interface NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase2 {
    file: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
    type: NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase2Type;
}
export type NamespacesInstancesSearchRequestMessagesItemContentCase1Item = NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0 | NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1 | NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase2;
export type NamespacesInstancesSearchRequestMessagesItemContentCase1List = Array<NamespacesInstancesSearchRequestMessagesItemContentCase1Item>;
export type NamespacesInstancesSearchRequestMessagesItemContent = string | NamespacesInstancesSearchRequestMessagesItemContentCase1List;
export type NamespacesInstancesSearchRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface NamespacesInstancesSearchRequestMessagesItem {
    content: NamespacesInstancesSearchRequestMessagesItemContent;
    role: NamespacesInstancesSearchRequestMessagesItemRole | (string & {});
}
export type NamespacesInstancesSearchRequestMessagesList = Array<NamespacesInstancesSearchRequestMessagesItem>;
export interface SearchNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    aiSearchOptions?: NamespacesInstancesSearchRequestAiSearchOptions;
    /** OpenAI-compatible message array. For multimodal queries, set the last user message's `content` to an array of typed parts: `[{type:'text', text:'...'}, {type:'image_url', image_url:{url:'...'}}]`. Image inputs require the RAG's embedding_model to declare 'image' in supported_modalities. */
    messages?: NamespacesInstancesSearchRequestMessagesList;
    /** A simple text query string. Alternative to 'messages' -- provide either this or 'messages', not both. */
    query?: string;
}
export type NamespacesInstancesSearchResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface NamespacesInstancesSearchResponseChunksItemItem {
    key: string;
    metadata?: NamespacesInstancesSearchResponseChunksItemItemMetadataMap | null;
    timestamp?: number | null;
}
export type NamespacesInstancesSearchResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export interface NamespacesInstancesSearchResponseChunksItemScoringDetails {
    fusionMethod?: NamespacesInstancesSearchResponseChunksItemScoringDetailsFusionMethod | null;
    keywordRank?: number | null;
    keywordScore?: number | null;
    rerankingScore?: number | null;
    vectorRank?: number | null;
    vectorScore?: number | null;
}
export type NamespacesInstancesSearchResponseChunksItemSourceMediaType = "audio" | "video";
export interface NamespacesInstancesSearchResponseChunksItem {
    id: string;
    score: number;
    text: string;
    type: string;
    item?: NamespacesInstancesSearchResponseChunksItemItem | null;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the matched chunk covers. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaEndMs?: number | null;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the matched chunk begins in. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaStartMs?: number | null;
    scoringDetails?: NamespacesInstancesSearchResponseChunksItemScoringDetails | null;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: NamespacesInstancesSearchResponseChunksItemSourceMediaType | null;
}
export type NamespacesInstancesSearchResponseChunksList = Array<NamespacesInstancesSearchResponseChunksItem>;
export type NamespacesInstancesSearchResponseQueryKind = "text" | "image" | "multimodal";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchNamespaceInstanceResponse {
    chunks: NamespacesInstancesSearchResponseChunksList;
    queryKind: NamespacesInstancesSearchResponseQueryKind;
    searchQuery?: string | null;
}
export interface StatsInstanceRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
}
export interface InstancesStatsResponseEngineR2 {
    metadataSizeBytes: number;
    objectCount: number;
    payloadSizeBytes: number;
}
export interface InstancesStatsResponseEngineVectorize {
    dimensions: number;
    vectorsCount: number;
}
export interface InstancesStatsResponseEngine {
    /** R2 bucket storage usage in bytes. */
    r2?: InstancesStatsResponseEngineR2 | null;
    /** Vectorize index metadata (dimensions, vector count). */
    vectorize?: InstancesStatsResponseEngineVectorize | null;
}
export type InstancesStatsResponseFileEmbedErrorsMap = {
    [key: string]: unknown | undefined;
};
export type InstancesStatsResponseIndexSourceErrorsMap = {
    [key: string]: unknown | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StatsInstanceResponse {
    completed?: number | null;
    /** True when the API cannot compute status counts (e.g. the legacy stats query exceeded the D1 statement-size limit). The response omits counts in this case. */
    degraded?: boolean | null;
    /** Engine-specific metadata. Present only for managed (v3) instances. */
    engine?: InstancesStatsResponseEngine | null;
    error?: number | null;
    fileEmbedErrors?: InstancesStatsResponseFileEmbedErrorsMap | null;
    indexSourceErrors?: InstancesStatsResponseIndexSourceErrorsMap | null;
    lastActivity?: string | null;
    outdated?: number | null;
    queued?: number | null;
    running?: number | null;
    skipped?: number | null;
}
export interface StatsNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
}
export type NamespacesInstancesStatsResponseEngineR2 = InstancesStatsResponseEngineR2;
export type NamespacesInstancesStatsResponseEngineVectorize = InstancesStatsResponseEngineVectorize;
export type NamespacesInstancesStatsResponseEngine = InstancesStatsResponseEngine;
export type NamespacesInstancesStatsResponseFileEmbedErrorsMap = {
    [key: string]: unknown | undefined;
};
export type NamespacesInstancesStatsResponseIndexSourceErrorsMap = {
    [key: string]: unknown | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StatsNamespaceInstanceResponse {
    completed?: number | null;
    /** True when the API cannot compute status counts (e.g. the legacy stats query exceeded the D1 statement-size limit). The response omits counts in this case. */
    degraded?: boolean | null;
    /** Engine-specific metadata. Present only for managed (v3) instances. */
    engine?: InstancesStatsResponseEngine | null;
    error?: number | null;
    fileEmbedErrors?: NamespacesInstancesStatsResponseFileEmbedErrorsMap | null;
    indexSourceErrors?: NamespacesInstancesStatsResponseIndexSourceErrorsMap | null;
    lastActivity?: string | null;
    outdated?: number | null;
    queued?: number | null;
    running?: number | null;
    skipped?: number | null;
}
export type NamespacesInstancesItemsSyncRequestNextAction = "INDEX";
export interface SyncNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
    nextAction: NamespacesInstancesItemsSyncRequestNextAction | (string & {});
    /** Wait for indexing before responding. After processing, vector-indexed instances use any time remaining in a 25s wait budget to confirm Vectorize ingestion. Processing itself continues uninterrupted and can exceed that budget. If confirmation times out, the response returns the current item state and background indexing continues. Defaults to false. */
    waitForCompletion?: boolean;
}
export type NamespacesInstancesItemsSyncResponseMetadataValue = string | number | boolean;
export type NamespacesInstancesItemsSyncResponseMetadataMap = {
    [key: string]: NamespacesInstancesItemsSyncResponseMetadataValue | undefined;
};
export type NamespacesInstancesItemsSyncResponseNextAction = "INDEX" | "DELETE";
export type NamespacesInstancesItemsSyncResponseStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SyncNamespaceInstanceItemResponse {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    /** Built-in, configured filterable, and retained source metadata for the item. */
    metadata: NamespacesInstancesItemsSyncResponseMetadataMap;
    namespace: string;
    nextAction: NamespacesInstancesItemsSyncResponseNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsSyncResponseStatus;
    error?: string | null;
}
export type InstancesUpdateRequestCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesUpdateRequestCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesUpdateRequestCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesUpdateRequestCustomMetadataItem {
    dataType: InstancesUpdateRequestCustomMetadataItemDataType | (string & {});
    fieldName: string;
}
export type InstancesUpdateRequestCustomMetadataList = Array<InstancesUpdateRequestCustomMetadataItem>;
export type InstancesUpdateRequestFusionMethod = "max" | "rrf";
export type InstancesUpdateRequestIndexMethod = InstancesCreateRequestIndexMethod;
export type InstancesUpdateRequestIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesUpdateRequestIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesUpdateRequestIndexingOptionsKeywordTokenizer | (string & {});
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean;
}
export type InstancesUpdateRequestMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesUpdateRequestMetadataCreatedFromEmdashPlugin {
    type: InstancesUpdateRequestMetadataCreatedFromEmdashPluginType | (string & {});
    version: string;
}
export interface InstancesUpdateRequestMetadata {
    createdFromAisearchWizard?: boolean;
    createdFromEmdashPlugin?: InstancesUpdateRequestMetadataCreatedFromEmdashPlugin;
    workerDomain?: string;
}
export type InstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type InstancesUpdateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export type InstancesUpdateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export type InstancesUpdateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export type InstancesUpdateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesUpdateRequestPublicEndpointParamsRateLimit {
    periodMs?: number;
    requests?: number;
    technique?: InstancesUpdateRequestPublicEndpointParamsRateLimitTechnique | (string & {});
}
export type InstancesUpdateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export interface InstancesUpdateRequestPublicEndpointParams {
    authorizedHosts?: InstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesUpdateRequestPublicEndpointParamsCustomDomainsList;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean;
    enabled?: boolean;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp;
    rateLimit?: InstancesUpdateRequestPublicEndpointParamsRateLimit;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
}
export type InstancesUpdateRequestRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesUpdateRequestRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesUpdateRequestRetrievalOptionsBoostByItemDirection | (string & {});
}
export type InstancesUpdateRequestRetrievalOptionsBoostByList = Array<InstancesUpdateRequestRetrievalOptionsBoostByItem>;
export type InstancesUpdateRequestRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesUpdateRequestRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesUpdateRequestRetrievalOptionsBoostByList;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: InstancesUpdateRequestRetrievalOptionsKeywordMatchMode | (string & {});
}
export type InstancesUpdateRequestSourceParamsExcludeItemsList = Array<string>;
export type InstancesUpdateRequestSourceParamsIncludeItemsList = Array<string>;
export type InstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: InstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptionsSource | (string & {});
}
export type InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesUpdateRequestSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap;
    includeImages?: boolean;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList;
    useBrowserRendering?: boolean;
}
export type InstancesUpdateRequestSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface InstancesUpdateRequestSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: InstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptions;
    parseOptions?: InstancesUpdateRequestSourceParamsWebCrawlerParseOptions;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: InstancesUpdateRequestSourceParamsWebCrawlerParseType | (string & {});
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions;
}
export interface InstancesUpdateRequestSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: InstancesUpdateRequestSourceParamsExcludeItemsList;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: InstancesUpdateRequestSourceParamsIncludeItemsList;
    prefix?: string;
    r2Jurisdiction?: string;
    webCrawler?: InstancesUpdateRequestSourceParamsWebCrawler;
}
export type InstancesUpdateRequestSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export interface UpdateInstanceRequest {
    accountId: string;
    id: string;
    aiGatewayId?: string;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string;
    cache?: boolean;
    cacheThreshold?: InstancesUpdateRequestCacheThreshold | (string & {});
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesUpdateRequestCacheTtl | (number & {});
    chunk?: boolean;
    chunkOverlap?: number;
    chunkSize?: number;
    customMetadata?: InstancesUpdateRequestCustomMetadataList;
    embeddingModel?: string;
    fusionMethod?: InstancesUpdateRequestFusionMethod | (string & {});
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod;
    indexingOptions?: InstancesUpdateRequestIndexingOptions;
    maxNumResults?: number;
    metadata?: InstancesUpdateRequestMetadata;
    paused?: boolean;
    publicEndpointParams?: InstancesUpdateRequestPublicEndpointParams;
    reranking?: boolean;
    rerankingModel?: string;
    retrievalOptions?: InstancesUpdateRequestRetrievalOptions;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string;
    rewriteQuery?: boolean;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number;
    source?: string;
    sourceParams?: InstancesUpdateRequestSourceParams;
    summarization?: boolean;
    summarizationModel?: string;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 21600 (6h); instances crawling a domain outside the account may be set to 86400. */
    syncInterval?: InstancesUpdateRequestSyncInterval | (number & {});
    systemPromptAiSearch?: string;
    systemPromptIndexSummarization?: string;
    systemPromptRewriteQuery?: string;
    tokenId?: string;
}
export type InstancesUpdateResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesUpdateResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesUpdateResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesUpdateResponseCustomMetadataItem {
    dataType: InstancesUpdateResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type InstancesUpdateResponseCustomMetadataList = Array<InstancesUpdateResponseCustomMetadataItem>;
export type InstancesUpdateResponseFusionMethod = "max" | "rrf";
export type InstancesUpdateResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type InstancesUpdateResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesUpdateResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesUpdateResponseIndexingOptionsKeywordTokenizer | null;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null;
}
export type InstancesUpdateResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesUpdateResponseMetadataCreatedFromEmdashPlugin {
    type: InstancesUpdateResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface InstancesUpdateResponseMetadata {
    createdFromAisearchWizard?: boolean | null;
    createdFromEmdashPlugin?: InstancesUpdateResponseMetadataCreatedFromEmdashPlugin | null;
    workerDomain?: string | null;
}
export type InstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type InstancesUpdateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type InstancesUpdateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type InstancesUpdateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type InstancesUpdateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesUpdateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: InstancesUpdateResponsePublicEndpointParamsRateLimitTechnique | null;
}
export type InstancesUpdateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface InstancesUpdateResponsePublicEndpointParams {
    authorizedHosts?: InstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesUpdateResponsePublicEndpointParamsCustomDomainsList | null;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: InstancesUpdateResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export type InstancesUpdateResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesUpdateResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesUpdateResponseRetrievalOptionsBoostByItemDirection | null;
}
export type InstancesUpdateResponseRetrievalOptionsBoostByList = Array<InstancesUpdateResponseRetrievalOptionsBoostByItem>;
export type InstancesUpdateResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesUpdateResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesUpdateResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: InstancesUpdateResponseRetrievalOptionsKeywordMatchMode | null;
}
export type InstancesUpdateResponseSourceParamsExcludeItemsList = Array<string>;
export type InstancesUpdateResponseSourceParamsIncludeItemsList = Array<string>;
export type InstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: InstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptionsSource | null;
}
export type InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesUpdateResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export type InstancesUpdateResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface InstancesUpdateResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: InstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptions | null;
    parseOptions?: InstancesUpdateResponseSourceParamsWebCrawlerParseOptions | null;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: InstancesUpdateResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export interface InstancesUpdateResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: InstancesUpdateResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: InstancesUpdateResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: InstancesUpdateResponseSourceParamsWebCrawler | null;
}
export type InstancesUpdateResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type InstancesUpdateResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null;
    cache?: boolean | null;
    cacheThreshold?: InstancesUpdateResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesUpdateResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: InstancesUpdateResponseCustomMetadataList | null;
    embeddingModel?: string | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: InstancesUpdateResponseFusionMethod | null;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: InstancesUpdateResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesUpdateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: InstancesUpdateResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: string | null;
    retrievalOptions?: InstancesUpdateResponseRetrievalOptions | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null;
    rewriteQuery?: boolean | null;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: InstancesUpdateResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 21600 (6h); instances crawling a domain outside the account may be set to 86400. */
    syncInterval?: InstancesUpdateResponseSyncInterval | null;
    tokenId?: string | null;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: InstancesUpdateResponseType | null;
}
export type NamespacesUpdateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesUpdateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesUpdateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesUpdateRequestPublicEndpointParamsInstancesAllowedList = Array<string>;
export type NamespacesUpdateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export type NamespacesUpdateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesUpdateRequestPublicEndpointParamsRateLimit {
    periodMs?: number;
    requests?: number;
    technique?: NamespacesUpdateRequestPublicEndpointParamsRateLimitTechnique | (string & {});
}
export type NamespacesUpdateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export interface NamespacesUpdateRequestPublicEndpointParams {
    authorizedHosts?: NamespacesUpdateRequestPublicEndpointParamsAuthorizedHostsList;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesUpdateRequestPublicEndpointParamsCustomDomainsList;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean;
    enabled?: boolean;
    /** Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must reference an existing instance in this namespace, and the list must stay within the account's multi-instance search limit. */
    instancesAllowed?: NamespacesUpdateRequestPublicEndpointParamsInstancesAllowedList;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp;
    rateLimit?: NamespacesUpdateRequestPublicEndpointParamsRateLimit;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
}
export interface UpdateNamespaceRequest {
    accountId: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null;
    publicEndpointParams?: NamespacesUpdateRequestPublicEndpointParams;
}
export type NamespacesUpdateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesUpdateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesUpdateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesUpdateResponsePublicEndpointParamsInstancesAllowedList = Array<string>;
export type NamespacesUpdateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesUpdateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesUpdateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesUpdateResponsePublicEndpointParamsRateLimitTechnique | null;
}
export type NamespacesUpdateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesUpdateResponsePublicEndpointParams {
    authorizedHosts?: NamespacesUpdateResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesUpdateResponsePublicEndpointParamsCustomDomainsList | null;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    /** Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must reference an existing instance in this namespace, and the list must stay within the account's multi-instance search limit. */
    instancesAllowed?: NamespacesUpdateResponsePublicEndpointParamsInstancesAllowedList | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesUpdateResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateNamespaceResponse {
    createdAt: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesUpdateResponsePublicEndpointParams | null;
}
export type NamespacesInstancesUpdateRequestCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesUpdateRequestCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesUpdateRequestCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesUpdateRequestCustomMetadataItem {
    dataType: NamespacesInstancesUpdateRequestCustomMetadataItemDataType | (string & {});
    fieldName: string;
}
export type NamespacesInstancesUpdateRequestCustomMetadataList = Array<NamespacesInstancesUpdateRequestCustomMetadataItem>;
export type NamespacesInstancesUpdateRequestFusionMethod = "max" | "rrf";
export type NamespacesInstancesUpdateRequestIndexMethod = InstancesCreateRequestIndexMethod;
export type NamespacesInstancesUpdateRequestIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesUpdateRequestIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesUpdateRequestIndexingOptionsKeywordTokenizer | (string & {});
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean;
}
export type NamespacesInstancesUpdateRequestMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesUpdateRequestMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesUpdateRequestMetadataCreatedFromEmdashPluginType | (string & {});
    version: string;
}
export interface NamespacesInstancesUpdateRequestMetadata {
    createdFromAisearchWizard?: boolean;
    createdFromEmdashPlugin?: NamespacesInstancesUpdateRequestMetadataCreatedFromEmdashPlugin;
    workerDomain?: string;
}
export type NamespacesInstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimit {
    periodMs?: number;
    requests?: number;
    technique?: NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimitTechnique | (string & {});
}
export type NamespacesInstancesUpdateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export interface NamespacesInstancesUpdateRequestPublicEndpointParams {
    authorizedHosts?: NamespacesInstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesUpdateRequestPublicEndpointParamsCustomDomainsList;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean;
    enabled?: boolean;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp;
    rateLimit?: NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimit;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
}
export type NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItemDirection | (string & {});
}
export type NamespacesInstancesUpdateRequestRetrievalOptionsBoostByList = Array<NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItem>;
export type NamespacesInstancesUpdateRequestRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesUpdateRequestRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesUpdateRequestRetrievalOptionsBoostByList;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: NamespacesInstancesUpdateRequestRetrievalOptionsKeywordMatchMode | (string & {});
}
export type NamespacesInstancesUpdateRequestSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesUpdateRequestSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptionsSource | (string & {});
}
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap;
    includeImages?: boolean;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList;
    useBrowserRendering?: boolean;
}
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesUpdateRequestSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptions;
    parseOptions?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptions;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseType | (string & {});
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions;
}
export interface NamespacesInstancesUpdateRequestSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: NamespacesInstancesUpdateRequestSourceParamsExcludeItemsList;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: NamespacesInstancesUpdateRequestSourceParamsIncludeItemsList;
    prefix?: string;
    r2Jurisdiction?: string;
    webCrawler?: NamespacesInstancesUpdateRequestSourceParamsWebCrawler;
}
export type NamespacesInstancesUpdateRequestSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export interface UpdateNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    id: string;
    aiGatewayId?: string;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string;
    cache?: boolean;
    cacheThreshold?: NamespacesInstancesUpdateRequestCacheThreshold | (string & {});
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesUpdateRequestCacheTtl | (number & {});
    chunk?: boolean;
    chunkOverlap?: number;
    chunkSize?: number;
    customMetadata?: NamespacesInstancesUpdateRequestCustomMetadataList;
    embeddingModel?: string;
    fusionMethod?: NamespacesInstancesUpdateRequestFusionMethod | (string & {});
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod;
    indexingOptions?: NamespacesInstancesUpdateRequestIndexingOptions;
    maxNumResults?: number;
    metadata?: NamespacesInstancesUpdateRequestMetadata;
    paused?: boolean;
    publicEndpointParams?: NamespacesInstancesUpdateRequestPublicEndpointParams;
    reranking?: boolean;
    rerankingModel?: string;
    retrievalOptions?: NamespacesInstancesUpdateRequestRetrievalOptions;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string;
    rewriteQuery?: boolean;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number;
    source?: string;
    sourceParams?: NamespacesInstancesUpdateRequestSourceParams;
    summarization?: boolean;
    summarizationModel?: string;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 21600 (6h); instances crawling a domain outside the account may be set to 86400. */
    syncInterval?: NamespacesInstancesUpdateRequestSyncInterval | (number & {});
    systemPromptAiSearch?: string;
    systemPromptIndexSummarization?: string;
    systemPromptRewriteQuery?: string;
    tokenId?: string;
}
export type NamespacesInstancesUpdateResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesUpdateResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesUpdateResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesUpdateResponseCustomMetadataItem {
    dataType: NamespacesInstancesUpdateResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type NamespacesInstancesUpdateResponseCustomMetadataList = Array<NamespacesInstancesUpdateResponseCustomMetadataItem>;
export type NamespacesInstancesUpdateResponseFusionMethod = "max" | "rrf";
export type NamespacesInstancesUpdateResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type NamespacesInstancesUpdateResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesUpdateResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesUpdateResponseIndexingOptionsKeywordTokenizer | null;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null;
}
export type NamespacesInstancesUpdateResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesUpdateResponseMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesUpdateResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface NamespacesInstancesUpdateResponseMetadata {
    createdFromAisearchWizard?: boolean | null;
    createdFromEmdashPlugin?: NamespacesInstancesUpdateResponseMetadataCreatedFromEmdashPlugin | null;
    workerDomain?: string | null;
}
export type NamespacesInstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimitTechnique | null;
}
export type NamespacesInstancesUpdateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesInstancesUpdateResponsePublicEndpointParams {
    authorizedHosts?: NamespacesInstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesUpdateResponsePublicEndpointParamsCustomDomainsList | null;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export type NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItemDirection | null;
}
export type NamespacesInstancesUpdateResponseRetrievalOptionsBoostByList = Array<NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItem>;
export type NamespacesInstancesUpdateResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesUpdateResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesUpdateResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: NamespacesInstancesUpdateResponseRetrievalOptionsKeywordMatchMode | null;
}
export type NamespacesInstancesUpdateResponseSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesUpdateResponseSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptionsSource | null;
}
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesUpdateResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptions | null;
    parseOptions?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptions | null;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export interface NamespacesInstancesUpdateResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: NamespacesInstancesUpdateResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: NamespacesInstancesUpdateResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: NamespacesInstancesUpdateResponseSourceParamsWebCrawler | null;
}
export type NamespacesInstancesUpdateResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type NamespacesInstancesUpdateResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateNamespaceInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null;
    cache?: boolean | null;
    cacheThreshold?: NamespacesInstancesUpdateResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesUpdateResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: NamespacesInstancesUpdateResponseCustomMetadataList | null;
    embeddingModel?: string | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: NamespacesInstancesUpdateResponseFusionMethod | null;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: NamespacesInstancesUpdateResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: NamespacesInstancesUpdateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesInstancesUpdateResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: string | null;
    retrievalOptions?: NamespacesInstancesUpdateResponseRetrievalOptions | null;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null;
    rewriteQuery?: boolean | null;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: NamespacesInstancesUpdateResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 21600 (6h); instances crawling a domain outside the account may be set to 86400. */
    syncInterval?: NamespacesInstancesUpdateResponseSyncInterval | null;
    tokenId?: string | null;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: NamespacesInstancesUpdateResponseType | null;
}
export interface UpdateTokenRequest {
    accountId: string;
    id: string;
    cfApiId: string;
    cfApiKey: string;
    name: string;
    legacy?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTokenResponse {
    id: string;
    cfApiId: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    createdBy?: string | null;
    enabled?: boolean | null;
    legacy?: boolean | null;
    modifiedBy?: string | null;
}
export interface NamespacesInstancesItemsUploadRequestFile {
    /** The file to upload. Filename must not exceed 128 characters. */
    file: string;
    /** JSON string of custom metadata key-value pairs. */
    metadata?: string;
    /** Wait for indexing before responding. After processing, vector-indexed instances use any time remaining in a 25s wait budget to confirm Vectorize ingestion. Processing itself continues uninterrupted and can exceed that budget. If confirmation times out, the response returns the current item state and background indexing continues. Defaults to false. */
    waitForCompletion?: boolean;
}
export interface UploadNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    file: NamespacesInstancesItemsUploadRequestFile;
}
export type NamespacesInstancesItemsUploadResponseMetadataValue = string | number | boolean;
export type NamespacesInstancesItemsUploadResponseMetadataMap = {
    [key: string]: NamespacesInstancesItemsUploadResponseMetadataValue | undefined;
};
export type NamespacesInstancesItemsUploadResponseNextAction = "INDEX" | "DELETE";
export type NamespacesInstancesItemsUploadResponseStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
export type NamespacesInstancesItemsUploadResponseWarningsItemCase0Code = "custom_metadata_value_not_indexed";
export type NamespacesInstancesItemsUploadResponseWarningsItemCase0ExpectedType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesItemsUploadResponseWarningsItemCase0 {
    code: NamespacesInstancesItemsUploadResponseWarningsItemCase0Code;
    expectedType: NamespacesInstancesItemsUploadResponseWarningsItemCase0ExpectedType;
    field: string;
}
export type NamespacesInstancesItemsUploadResponseWarningsItemCase1Code = "custom_metadata_field_not_filterable";
export interface NamespacesInstancesItemsUploadResponseWarningsItemCase1 {
    code: NamespacesInstancesItemsUploadResponseWarningsItemCase1Code;
    field: string;
}
export type NamespacesInstancesItemsUploadResponseWarningsItem = NamespacesInstancesItemsUploadResponseWarningsItemCase0 | NamespacesInstancesItemsUploadResponseWarningsItemCase1;
export type NamespacesInstancesItemsUploadResponseWarningsList = Array<NamespacesInstancesItemsUploadResponseWarningsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UploadNamespaceInstanceItemResponse {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    /** Built-in, configured filterable, and retained source metadata for the item. */
    metadata: NamespacesInstancesItemsUploadResponseMetadataMap;
    namespace: string;
    nextAction: NamespacesInstancesItemsUploadResponseNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsUploadResponseStatus;
    error?: string | null;
    warnings?: NamespacesInstancesItemsUploadResponseWarningsList | null;
}
export type ChatCompletionsInstanceError = CloudflareOpError;
/** Performs a chat completion request against an AI Search instance, using indexed content as context for generating responses. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const chatCompletionsInstance: API.OperationMethod<ChatCompletionsInstanceRequest, ChatCompletionsInstanceResponse, ChatCompletionsInstanceError, CloudflareOpContext>;
export type ChatCompletionsNamespaceError = CloudflareOpError;
/** Performs a chat completion request against multiple AI Search instances in parallel, merging retrieved content as context for generating a response. */
export declare const chatCompletionsNamespace: API.OperationMethod<ChatCompletionsNamespaceRequest, ChatCompletionsNamespaceResponse, ChatCompletionsNamespaceError, CloudflareOpContext>;
export type ChatCompletionsNamespaceInstanceError = CloudflareOpError;
/** Performs a chat completion request against an AI Search instance, using indexed content as context for generating responses. */
export declare const chatCompletionsNamespaceInstance: API.OperationMethod<ChatCompletionsNamespaceInstanceRequest, ChatCompletionsNamespaceInstanceResponse, ChatCompletionsNamespaceInstanceError, CloudflareOpContext>;
export type ChunksNamespaceInstanceItemError = CloudflareOpError;
/** Lists chunks for a specific item in an AI Search instance, including their text content. */
export declare const chunksNamespaceInstanceItem: API.OperationMethod<ChunksNamespaceInstanceItemRequest, ChunksNamespaceInstanceItemResponse, ChunksNamespaceInstanceItemError, CloudflareOpContext>;
export type CreateInstanceError = ValidationError | NotFound | InvalidRoute | InstanceAlreadyExists | InvalidTokenCredentials | Forbidden | CloudflareOpError;
/** Create a new AI Search instance with the given configuration. If type is omitted or null, a non-blank HTTP(S) source infers web-crawler and any other source infers r2; r2 sources must name an existing bucket. A missing or blank source without a type creates a managed upload-only instance. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const createInstance: API.OperationMethod<CreateInstanceRequest, CreateInstanceResponse, CreateInstanceError, CloudflareOpContext>;
export type CreateInstanceJobError = ValidationError | NotFound | InvalidRoute | UnableToConnect | SyncInCooldown | CloudflareOpError;
/** Creates a new indexing job for an AI Search instance. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const createInstanceJob: API.OperationMethod<CreateInstanceJobRequest, CreateInstanceJobResponse, CreateInstanceJobError, CloudflareOpContext>;
export type CreateNamespaceError = NamespaceAlreadyExists | Forbidden | CloudflareOpError;
/** Create a namespace for organizing AI Search instances. */
export declare const createNamespace: API.OperationMethod<CreateNamespaceRequest, CreateNamespaceResponse, CreateNamespaceError, CloudflareOpContext>;
export type CreateNamespaceInstanceError = ValidationError | NamespaceNotFound | AiSearchInstanceNotFound | InvalidRoute | InstanceAlreadyExists | InvalidTokenCredentials | WebCrawlerDomainNotOwned | MissingSitemap | Forbidden | InstanceDeletionInProgress | CloudflareOpError;
/** Create a new AI Search instance with the given configuration. If type is omitted or null, a non-blank HTTP(S) source infers web-crawler and any other source infers r2; r2 sources must name an existing bucket. A missing or blank source without a type creates a managed upload-only instance. */
export declare const createNamespaceInstance: API.OperationMethod<CreateNamespaceInstanceRequest, CreateNamespaceInstanceResponse, CreateNamespaceInstanceError, CloudflareOpContext>;
export type CreateNamespaceInstanceJobError = CloudflareOpError;
/** Creates a new indexing job for an AI Search instance. */
export declare const createNamespaceInstanceJob: API.OperationMethod<CreateNamespaceInstanceJobRequest, CreateNamespaceInstanceJobResponse, CreateNamespaceInstanceJobError, CloudflareOpContext>;
export type CreateOrUpdateNamespaceInstanceItemError = CloudflareOpError;
/** Creates or updates an indexed item in an AI Search instance. */
export declare const createOrUpdateNamespaceInstanceItem: API.OperationMethod<CreateOrUpdateNamespaceInstanceItemRequest, CreateOrUpdateNamespaceInstanceItemResponse, CreateOrUpdateNamespaceInstanceItemError, CloudflareOpContext>;
export type CreateTokenError = ValidationError | NotFound | InvalidRoute | InvalidTokenCredentials | Forbidden | CloudflareOpError;
/** Create a stored Cloudflare credential for an AI Search instance to access its data source. */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type DeleteInstanceError = ValidationError | NotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Deletes an AI Search instance and all its indexed data permanently. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const deleteInstance: API.OperationMethod<DeleteInstanceRequest, DeleteInstanceResponse, DeleteInstanceError, CloudflareOpContext>;
export type DeleteNamespaceError = NamespaceNotFound | Forbidden | CloudflareOpError;
/** Deletes a namespace permanently. The namespace must not contain any instances (instances whose deletion is still in progress do not count), and the default namespace cannot be deleted. */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest, DeleteNamespaceResponse, DeleteNamespaceError, CloudflareOpContext>;
export type DeleteNamespaceInstanceError = ValidationError | NamespaceNotFound | AiSearchInstanceNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Deletes an AI Search instance and all its indexed data permanently. */
export declare const deleteNamespaceInstance: API.OperationMethod<DeleteNamespaceInstanceRequest, DeleteNamespaceInstanceResponse, DeleteNamespaceInstanceError, CloudflareOpContext>;
export type DeleteNamespaceInstanceItemError = CloudflareOpError;
/** Deletes a file from a managed AI Search instance and removes its indexed data. */
export declare const deleteNamespaceInstanceItem: API.OperationMethod<DeleteNamespaceInstanceItemRequest, DeleteNamespaceInstanceItemResponse, DeleteNamespaceInstanceItemError, CloudflareOpContext>;
export type DeleteTokenError = ValidationError | NotFound | InvalidRoute | TokenNotFound | TokenInUseByInstances | Forbidden | CloudflareOpError;
/** Deletes a stored AI Search credential permanently. Credentials in use by an instance cannot be deleted. */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, CloudflareOpContext>;
export type DownloadNamespaceInstanceItemError = CloudflareOpError;
/** Downloads the raw file content for a specific item from the managed AI Search instance storage. */
export declare const downloadNamespaceInstanceItem: API.OperationMethod<DownloadNamespaceInstanceItemRequest, DownloadNamespaceInstanceItemResponse, DownloadNamespaceInstanceItemError, CloudflareOpContext>;
export type GetInstanceJobError = ValidationError | NotFound | InvalidRoute | CloudflareOpError;
/** Retrieves details for a specific AI Search indexing job. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const getInstanceJob: API.OperationMethod<GetInstanceJobRequest, GetInstanceJobResponse, GetInstanceJobError, CloudflareOpContext>;
export type GetNamespaceInstanceItemError = CloudflareOpError;
/** Retrieves a specific indexed item from an AI Search instance. */
export declare const getNamespaceInstanceItem: API.OperationMethod<GetNamespaceInstanceItemRequest, GetNamespaceInstanceItemResponse, GetNamespaceInstanceItemError, CloudflareOpContext>;
export type GetNamespaceInstanceJobError = CloudflareOpError;
/** Retrieves details for a specific AI Search indexing job. */
export declare const getNamespaceInstanceJob: API.OperationMethod<GetNamespaceInstanceJobRequest, GetNamespaceInstanceJobResponse, GetNamespaceInstanceJobError, CloudflareOpContext>;
export type ListInstanceJobsError = CloudflareOpError;
/** Lists indexing jobs for an AI Search instance. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const listInstanceJobs: API.PaginatedOperationMethod<ListInstanceJobsRequest, ListInstanceJobsResponse, ListInstanceJobsError, CloudflareOpContext, InstancesJobsListResultItem>;
export type ListInstancesError = InvalidRoute | Forbidden | CloudflareOpError;
/** Lists all AI Search instances in the account. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const listInstances: API.PaginatedOperationMethod<ListInstancesRequest, ListInstancesResponse, ListInstancesError, CloudflareOpContext, InstancesListResultItem>;
export type ListNamespaceInstanceItemsError = CloudflareOpError;
/** Lists indexed items in an AI Search instance. */
export declare const listNamespaceInstanceItems: API.PaginatedOperationMethod<ListNamespaceInstanceItemsRequest, ListNamespaceInstanceItemsResponse, ListNamespaceInstanceItemsError, CloudflareOpContext, NamespacesInstancesItemsListResultItem>;
export type ListNamespaceInstanceJobsError = CloudflareOpError;
/** Lists indexing jobs for an AI Search instance. */
export declare const listNamespaceInstanceJobs: API.PaginatedOperationMethod<ListNamespaceInstanceJobsRequest, ListNamespaceInstanceJobsResponse, ListNamespaceInstanceJobsError, CloudflareOpContext, NamespacesInstancesJobsListResultItem>;
export type ListNamespaceInstancesError = NamespaceNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Lists all AI Search instances in the account. */
export declare const listNamespaceInstances: API.PaginatedOperationMethod<ListNamespaceInstancesRequest, ListNamespaceInstancesResponse, ListNamespaceInstancesError, CloudflareOpContext, NamespacesInstancesListResultItem>;
export type ListNamespacesError = CloudflareOpError;
/** Lists namespaces in the account, including their descriptions and creation times. */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, CloudflareOpContext, NamespacesListResultItem>;
export type ListTokensError = InvalidRoute | Forbidden | CloudflareOpError;
/** Lists stored AI Search credentials in the account without exposing their secrets. */
export declare const listTokens: API.PaginatedOperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, CloudflareOpContext, TokensListResultItem>;
export type LogsInstanceJobError = ValidationError | NotFound | InvalidRoute | CloudflareOpError;
/** Lists log entries for an AI Search indexing job. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const logsInstanceJob: API.OperationMethod<LogsInstanceJobRequest, LogsInstanceJobResponse, LogsInstanceJobError, CloudflareOpContext>;
export type LogsNamespaceInstanceItemError = CloudflareOpError;
/** Lists processing logs for a specific item in an AI Search instance. */
export declare const logsNamespaceInstanceItem: API.OperationMethod<LogsNamespaceInstanceItemRequest, LogsNamespaceInstanceItemResponse, LogsNamespaceInstanceItemError, CloudflareOpContext>;
export type LogsNamespaceInstanceJobError = CloudflareOpError;
/** Lists log entries for an AI Search indexing job. */
export declare const logsNamespaceInstanceJob: API.OperationMethod<LogsNamespaceInstanceJobRequest, LogsNamespaceInstanceJobResponse, LogsNamespaceInstanceJobError, CloudflareOpContext>;
export type MoveNamespacesInstanceError = CloudflareOpError;
/** Moves an instance from its current namespace to the specified target namespace. Use 'default' with --destination-namespace to move the instance back to the default namespace. Fails with 400 if the target namespace already has an instance with the same id (ids must be unique within a namespace -- the same id can exist in different namespaces). */
export declare const moveNamespacesInstance: API.OperationMethod<MoveNamespacesInstanceRequest, MoveNamespacesInstanceResponse, MoveNamespacesInstanceError, CloudflareOpContext>;
export type PatchNamespaceInstanceJobError = CloudflareOpError;
/** Cancels an in-progress indexing job for an AI Search instance. */
export declare const patchNamespaceInstanceJob: API.OperationMethod<PatchNamespaceInstanceJobRequest, PatchNamespaceInstanceJobResponse, PatchNamespaceInstanceJobError, CloudflareOpContext>;
export type ReadInstanceError = ValidationError | NotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Retrieve the configuration and status of an AI Search instance. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const readInstance: API.OperationMethod<ReadInstanceRequest, ReadInstanceResponse, ReadInstanceError, CloudflareOpContext>;
export type ReadNamespaceError = NamespaceNotFound | Forbidden | CloudflareOpError;
/** Retrieve a namespace and its description. */
export declare const readNamespace: API.OperationMethod<ReadNamespaceRequest, ReadNamespaceResponse, ReadNamespaceError, CloudflareOpContext>;
export type ReadNamespaceInstanceError = ValidationError | NamespaceNotFound | AiSearchInstanceNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Retrieve the configuration and status of an AI Search instance. */
export declare const readNamespaceInstance: API.OperationMethod<ReadNamespaceInstanceRequest, ReadNamespaceInstanceResponse, ReadNamespaceInstanceError, CloudflareOpContext>;
export type ReadTokenError = ValidationError | NotFound | InvalidRoute | TokenNotFound | Forbidden | CloudflareOpError;
/** Retrieve a stored AI Search credential without exposing its secret. */
export declare const readToken: API.OperationMethod<ReadTokenRequest, ReadTokenResponse, ReadTokenError, CloudflareOpContext>;
export type SearchInstanceError = CloudflareOpError;
/** Executes a semantic search query against an AI Search instance to find relevant indexed content. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const searchInstance: API.OperationMethod<SearchInstanceRequest, SearchInstanceResponse, SearchInstanceError, CloudflareOpContext>;
export type SearchNamespaceError = CloudflareOpError;
/** Performs a semantic search query against multiple AI Search instances in parallel, merging the retrieved results into a single ranked response. */
export declare const searchNamespace: API.OperationMethod<SearchNamespaceRequest, SearchNamespaceResponse, SearchNamespaceError, CloudflareOpContext>;
export type SearchNamespaceInstanceError = CloudflareOpError;
/** Executes a semantic search query against an AI Search instance to find relevant indexed content. */
export declare const searchNamespaceInstance: API.OperationMethod<SearchNamespaceInstanceRequest, SearchNamespaceInstanceResponse, SearchNamespaceInstanceError, CloudflareOpContext>;
export type StatsInstanceError = ValidationError | NotFound | InvalidRoute | CloudflareOpError;
/** Retrieve usage and indexing statistics for an AI Search instance. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const statsInstance: API.OperationMethod<StatsInstanceRequest, StatsInstanceResponse, StatsInstanceError, CloudflareOpContext>;
export type StatsNamespaceInstanceError = CloudflareOpError;
/** Retrieve usage and indexing statistics for an AI Search instance. */
export declare const statsNamespaceInstance: API.OperationMethod<StatsNamespaceInstanceRequest, StatsNamespaceInstanceResponse, StatsNamespaceInstanceError, CloudflareOpContext>;
export type SyncNamespaceInstanceItemError = CloudflareOpError;
/** Synchronizes an item to an AI Search instance index. */
export declare const syncNamespaceInstanceItem: API.OperationMethod<SyncNamespaceInstanceItemRequest, SyncNamespaceInstanceItemResponse, SyncNamespaceInstanceItemError, CloudflareOpContext>;
export type UpdateInstanceError = ValidationError | NotFound | InvalidRoute | InvalidTokenCredentials | Forbidden | CloudflareOpError;
/** Updates the configuration of an AI Search instance. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const updateInstance: API.OperationMethod<UpdateInstanceRequest, UpdateInstanceResponse, UpdateInstanceError, CloudflareOpContext>;
export type UpdateNamespaceError = NamespaceNotFound | Forbidden | CloudflareOpError;
/** Updates the description and/or the public endpoint configuration of an existing namespace. The default namespace's description cannot be modified, but its public endpoint can. */
export declare const updateNamespace: API.OperationMethod<UpdateNamespaceRequest, UpdateNamespaceResponse, UpdateNamespaceError, CloudflareOpContext>;
export type UpdateNamespaceInstanceError = ValidationError | NamespaceNotFound | AiSearchInstanceNotFound | InvalidRoute | InvalidTokenCredentials | WebCrawlerDomainNotOwned | Forbidden | CloudflareOpError;
/** Updates the configuration of an AI Search instance. */
export declare const updateNamespaceInstance: API.OperationMethod<UpdateNamespaceInstanceRequest, UpdateNamespaceInstanceResponse, UpdateNamespaceInstanceError, CloudflareOpContext>;
export type UpdateTokenError = ValidationError | NotFound | InvalidRoute | TokenNotFound | Forbidden | InvalidTokenCredentials | CloudflareOpError;
/** Replace a stored AI Search credential and invalidate cached credentials for instances that use it. */
export declare const updateToken: API.OperationMethod<UpdateTokenRequest, UpdateTokenResponse, UpdateTokenError, CloudflareOpContext>;
export type UploadNamespaceInstanceItemError = CloudflareOpError;
/** Uploads a file to a managed AI Search instance via multipart/form-data. */
export declare const uploadNamespaceInstanceItem: API.OperationMethod<UploadNamespaceInstanceItemRequest, UploadNamespaceInstanceItemResponse, UploadNamespaceInstanceItemError, CloudflareOpContext>;
//# sourceMappingURL=ai_search.d.ts.map