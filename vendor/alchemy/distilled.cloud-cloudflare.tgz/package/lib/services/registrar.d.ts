import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const RegistrarDomainNotOwned_base: S.TaggedErrorClass<"RegistrarDomainNotOwned", {
    readonly code: any;
    readonly message: any;
}>;
export declare class RegistrarDomainNotOwned extends /*@__PURE__*/ RegistrarDomainNotOwned_base {
}
declare const RegistrarUpdateNotAllowed_base: S.TaggedErrorClass<"RegistrarUpdateNotAllowed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class RegistrarUpdateNotAllowed extends /*@__PURE__*/ RegistrarUpdateNotAllowed_base {
}
export type CheckRequestDomainsList = Array<string>;
export interface CheckRegistrarRequest {
    /** Identifier. */
    accountId: string;
    /** List of fully qualified domain names (FQDNs) to check for availability. Each domain must include the extension. */
    domains: CheckRequestDomainsList;
}
export interface CheckResponseDomainsItemPricing {
    /** ISO-4217 currency code for the prices (e.g., "USD", "EUR", "GBP"). */
    currency: string;
    /** The first-year cost to register this domain. */
    registrationCost: string;
    /** Per-year renewal cost for this domain. Applied to each year beyond the first year of a multi-year registration, and to each annual auto-renewal thereafter. May differ from `registration_cost`, especially for premium domains where initial registration often costs more than renewals. */
    renewalCost: string;
}
export type CheckResponseDomainsItemReason = "extension_not_supported_via_api" | "extension_not_supported" | "extension_disallows_registration" | "domain_premium" | "domain_unavailable";
export type CheckResponseDomainsItemTier = "standard" | "premium";
export interface CheckResponseDomainsItem {
    /** The fully qualified domain name (FQDN) in punycode format for internationalized domain names (IDNs). */
    name: string;
    /** Indicates programmatic registration eligibility according to a real-time registry check. */
    registrable: boolean;
    /** Provides annual pricing information for a given domain. The API returns all per-year prices as strings to preserve decimal precision. */
    pricing?: CheckResponseDomainsItemPricing | null;
    /** Appears only when `registrable` is `false` and explains the result. */
    reason?: CheckResponseDomainsItemReason | null;
    /** The pricing tier for this domain. A `registrable` value of `true` always includes this field, which defaults to `standard` for most domains. A `registrable` value of `false` may omit it. */
    tier?: CheckResponseDomainsItemTier | null;
}
export type CheckResponseDomainsList = Array<CheckResponseDomainsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CheckRegistrarResponse {
    /** Array of domain availability results. Results for unsupported extensions contain `registrable: false` and a `reason` field. The response may omit malformed domain names. */
    domains: CheckResponseDomainsList;
}
export type CreateRegistrationRequestAcknowledgementsMap = {
    [key: string]: unknown | undefined;
};
export type CreateRegistrationRequestContactExtensionsMap = {
    [key: string]: unknown | undefined;
};
export interface CreateRegistrationRequestContactsAdministratorPostalInfoAddress {
    /** City or locality name. */
    city: string;
    /** Two-letter country code per ISO 3166-1 alpha-2 (e.g., `US`, `GB`, `CA`, `DE`). */
    countryCode: string;
    /** Postal or ZIP code. */
    postalCode: string;
    /** State, province, or region. Use the standard abbreviation where applicable (e.g., `TX` for Texas, `ON` for Ontario). */
    state: string;
    /** Street address including building/suite number. */
    street: string;
}
export interface CreateRegistrationRequestContactsAdministratorPostalInfo {
    /** Physical mailing address for the registrant contact. */
    address: CreateRegistrationRequestContactsAdministratorPostalInfoAddress;
    /** Full legal name of the contact, including all required name components for an individual or authorized representative. Some registries require a complete personal name that includes a family or last name where applicable. Provide the complete name in this single field, for example `Ada Lovelace`; do not send separate first-name or last-name fields. */
    name: string;
    /** Organization or company name. Optional for individual registrants. */
    organization?: string;
}
export interface CreateRegistrationRequestContactsAdministrator {
    /** Email address for the registrant. Used for domain-related communications from the registry, including ownership verification and renewal notices. */
    email: string;
    /** Phone number in E.164 format: `+{country_code}.{number}` without spaces or dashes. Examples: `+1.5555555555` (US), `+44.2071234567` (UK), `+81.312345678` (Japan). */
    phone: string;
    /** Postal/mailing information for the contact. The `name` field is the complete contact name in one string. Some registries require a complete personal name, including a family or last name where applicable, but this API does not accept separate first-name and last-name fields for registration contacts. */
    postalInfo: CreateRegistrationRequestContactsAdministratorPostalInfo;
    /** Fax number in E.164 format (e.g., `+1.5555555555`). Optional. Most registrations do not require a fax number. */
    fax?: string;
}
export type CreateRegistrationRequestContactsBillingPostalInfoAddress = CreateRegistrationRequestContactsAdministratorPostalInfoAddress;
export type CreateRegistrationRequestContactsBillingPostalInfo = CreateRegistrationRequestContactsAdministratorPostalInfo;
export type CreateRegistrationRequestContactsBilling = CreateRegistrationRequestContactsAdministrator;
export type CreateRegistrationRequestContactsRegistrantPostalInfoAddress = CreateRegistrationRequestContactsAdministratorPostalInfoAddress;
export type CreateRegistrationRequestContactsRegistrantPostalInfo = CreateRegistrationRequestContactsAdministratorPostalInfo;
export type CreateRegistrationRequestContactsRegistrant = CreateRegistrationRequestContactsAdministrator;
export type CreateRegistrationRequestContactsTechnicalPostalInfoAddress = CreateRegistrationRequestContactsAdministratorPostalInfoAddress;
export type CreateRegistrationRequestContactsTechnicalPostalInfo = CreateRegistrationRequestContactsAdministratorPostalInfo;
export type CreateRegistrationRequestContactsTechnical = CreateRegistrationRequestContactsAdministrator;
export interface CreateRegistrationRequestContacts {
    /** Optional administrator contact. Accepted only when the extension schema includes this role. When the registry requires an omitted contact, Cloudflare may derive it from `contacts.registrant`. */
    administrator?: CreateRegistrationRequestContactsAdministrator;
    /** Optional billing contact. Accepted only when the extension schema includes this role. When the registry requires an omitted contact, Cloudflare may derive it from `contacts.registrant`. */
    billing?: CreateRegistrationRequestContactsAdministrator;
    /** Optional registrant contact. If omitted, the account's default address book entry is used instead. */
    registrant?: CreateRegistrationRequestContactsAdministrator;
    /** Optional technical contact. Accepted only when the extension schema includes this role. When the registry requires an omitted contact, Cloudflare may derive it from `contacts.registrant`. */
    technical?: CreateRegistrationRequestContactsAdministrator;
}
export type CreateRegistrationRequestPrivacyMode = "off" | "redaction";
export interface CreateRegistrationRequest {
    /** Identifier. */
    accountId: string;
    prefer?: string;
    /** Provides a fully qualified domain name (FQDN), including the extension (e.g., `example.com`, `mybrand.app`). The domain name uniquely identifies a registration. Cloudflare permits only one registration per domain, making the domain name a natural idempotency key for registration requests. */
    domainName: string;
    /** Provides user acknowledgements for a specific extension or premium registration flow. The extension registration schema from the extension discovery endpoint identifies the required keys. */
    acknowledgements?: CreateRegistrationRequestAcknowledgementsMap;
    /** Enable or disable automatic renewal. Defaults to `false` if omitted. Setting this field to `true` is an explicit opt-in authorizing Cloudflare to charge the account's default payment method up to 30 days before domain expiry to renew the domain automatically. Renewal pricing may change over time based on registry pricing. */
    autoRenew?: boolean;
    /** Provides registry-specific contact extension values for the registrant. `GET /accounts/{account_id}/registrar/extensions/{extension}` identifies the required keys and allowed values for each extension in the `registration_schema.properties.contact_extensions` object. */
    contactExtensions?: CreateRegistrationRequestContactExtensionsMap;
    /** Provides contact data for the registration request. */
    contacts?: CreateRegistrationRequestContacts;
    /** Sets the WHOIS privacy mode for the registration. Defaults to `redaction`. */
    privacyMode?: CreateRegistrationRequestPrivacyMode | (string & {});
    /** Sets the registration term from 1 to 10 years. When omitted, this field defaults to the registry's minimum registration period for the extension. Most extensions require 1 year, while some require longer minimum terms (e.g., `.ai` requires 2 years). */
    years?: number;
}
export interface CreateRegistrationResponseLinks {
    /** URL to this status resource. */
    self: string;
    /** URL to the domain resource. */
    resource?: string | null;
}
export type CreateRegistrationResponseState = "pending" | "in_progress" | "action_required" | "blocked" | "succeeded" | "failed";
export type CreateRegistrationResponseContextMap = {
    [key: string]: unknown | undefined;
};
export interface CreateRegistrationResponseError {
    /** Machine-readable error code identifying the failure reason. */
    code: string;
    /** Human-readable explanation of the failure. May include registry-specific details. */
    message: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRegistrationResponse {
    /** Indicates whether the workflow reached a terminal state. A `succeeded` or `failed` state returns `true`; `pending`, `in_progress`, `action_required`, and `blocked` return `false`. */
    completed: boolean;
    createdAt: string;
    links: CreateRegistrationResponseLinks;
    /** Describes the workflow lifecycle state. */
    state: CreateRegistrationResponseState;
    updatedAt: string;
    /** Provides workflow-specific data. */
    context?: CreateRegistrationResponseContextMap | null;
    /** Provides error details when a workflow reaches the `failed` state. The workflow type (registration, update, etc.) and underlying registry response determine the specific codes and messages. Workflow error codes differ from immediate HTTP error `errors[].code` values in non-2xx responses. Surface `error.message` to the user for context. */
    error?: CreateRegistrationResponseError | null;
}
export type CreateTransferInRequestContactExtensionsMap = {
    [key: string]: unknown | undefined;
};
export type CreateTransferInRequestContactsAdministratorPostalInfoAddress = CreateRegistrationRequestContactsAdministratorPostalInfoAddress;
export type CreateTransferInRequestContactsAdministratorPostalInfo = CreateRegistrationRequestContactsAdministratorPostalInfo;
export type CreateTransferInRequestContactsAdministrator = CreateRegistrationRequestContactsAdministrator;
export type CreateTransferInRequestContactsBillingPostalInfoAddress = CreateRegistrationRequestContactsAdministratorPostalInfoAddress;
export type CreateTransferInRequestContactsBillingPostalInfo = CreateRegistrationRequestContactsAdministratorPostalInfo;
export type CreateTransferInRequestContactsBilling = CreateRegistrationRequestContactsAdministrator;
export type CreateTransferInRequestContactsRegistrantPostalInfoAddress = CreateRegistrationRequestContactsAdministratorPostalInfoAddress;
export type CreateTransferInRequestContactsRegistrantPostalInfo = CreateRegistrationRequestContactsAdministratorPostalInfo;
export type CreateTransferInRequestContactsRegistrant = CreateRegistrationRequestContactsAdministrator;
export type CreateTransferInRequestContactsTechnicalPostalInfoAddress = CreateRegistrationRequestContactsAdministratorPostalInfoAddress;
export type CreateTransferInRequestContactsTechnicalPostalInfo = CreateRegistrationRequestContactsAdministratorPostalInfo;
export type CreateTransferInRequestContactsTechnical = CreateRegistrationRequestContactsAdministrator;
export type CreateTransferInRequestContacts = CreateRegistrationRequestContacts;
export type CreateTransferInRequestPrivacyMode = "off" | "redaction";
export interface CreateTransferInRequest {
    /** Identifier. */
    accountId: string;
    /** Provides a fully qualified domain name (FQDN), including the extension (e.g., `example.com`, `mybrand.app`). The domain name uniquely identifies a registration. Cloudflare permits only one registration per domain, making the domain name a natural idempotency key for registration requests. */
    domainName: string;
    prefer?: string;
    /** The EPP/authorization code from your current registrar, base64-encoded per RFC 4648 §4. Obtain this from your current registrar's control panel. Required for all extensions, except for UK. */
    authCode?: string;
    /** Enable or disable automatic renewal after transfer. Defaults to `false` if omitted. */
    autoRenew?: boolean;
    /** Registry-specific contact extension values for the registrant. `GET /accounts/{account_id}/registrar/extensions/{extension}` documents the required keys and allowed values for each extension in the `transfer_schema.properties.contact_extensions` object. */
    contactExtensions?: CreateTransferInRequestContactExtensionsMap;
    /** Provides contact data for the registration request. */
    contacts?: CreateRegistrationRequestContacts;
    /** WHOIS privacy mode to apply after transfer completes. Defaults to the extension's default privacy mode (typically `redaction`). */
    privacyMode?: CreateTransferInRequestPrivacyMode | (string & {});
}
export type CreateTransferInResponseLinks = CreateRegistrationResponseLinks;
export type CreateTransferInResponseState = "pending" | "in_progress" | "action_required" | "blocked" | "succeeded" | "failed";
export type CreateTransferInResponseContextMap = {
    [key: string]: unknown | undefined;
};
export type CreateTransferInResponseError = CreateRegistrationResponseError;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTransferInResponse {
    /** Indicates whether the workflow reached a terminal state. A `succeeded` or `failed` state returns `true`; `pending`, `in_progress`, `action_required`, and `blocked` return `false`. */
    completed: boolean;
    createdAt: string;
    links: CreateRegistrationResponseLinks;
    /** Describes the workflow lifecycle state. */
    state: CreateTransferInResponseState;
    updatedAt: string;
    /** Provides workflow-specific data. */
    context?: CreateTransferInResponseContextMap | null;
    /** Provides error details when a workflow reaches the `failed` state. The workflow type (registration, update, etc.) and underlying registry response determine the specific codes and messages. Workflow error codes differ from immediate HTTP error `errors[].code` values in non-2xx responses. Surface `error.message` to the user for context. */
    error?: CreateRegistrationResponseError | null;
}
export type EditRegistrationRequestPrefer = "respond-async";
export interface EditRegistrationRequest {
    /** Identifier. */
    accountId: string;
    /** Provides a fully qualified domain name (FQDN), including the extension (e.g., `example.com`, `mybrand.app`). The domain name uniquely identifies a registration. Cloudflare permits only one registration per domain, making the domain name a natural idempotency key for registration requests. */
    domainName: string;
    prefer?: EditRegistrationRequestPrefer | (string & {});
    /** Enable or disable automatic renewal. Setting this field to `true` authorizes Cloudflare to charge the account's default payment method up to 30 days before domain expiry to renew the domain automatically. Renewal pricing may change over time based on registry pricing. */
    autoRenew?: boolean;
}
export type EditRegistrationResponseLinks = CreateRegistrationResponseLinks;
export type EditRegistrationResponseState = "pending" | "in_progress" | "action_required" | "blocked" | "succeeded" | "failed";
export type EditRegistrationResponseContextMap = {
    [key: string]: unknown | undefined;
};
export type EditRegistrationResponseError = CreateRegistrationResponseError;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditRegistrationResponse {
    /** Indicates whether the workflow reached a terminal state. A `succeeded` or `failed` state returns `true`; `pending`, `in_progress`, `action_required`, and `blocked` return `false`. */
    completed: boolean;
    createdAt: string;
    links: CreateRegistrationResponseLinks;
    /** Describes the workflow lifecycle state. */
    state: EditRegistrationResponseState;
    updatedAt: string;
    /** Provides workflow-specific data. */
    context?: EditRegistrationResponseContextMap | null;
    /** Provides error details when a workflow reaches the `failed` state. The workflow type (registration, update, etc.) and underlying registry response determine the specific codes and messages. Workflow error codes differ from immediate HTTP error `errors[].code` values in non-2xx responses. Surface `error.message` to the user for context. */
    error?: CreateRegistrationResponseError | null;
}
export interface GetDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Provides a fully qualified domain name (FQDN), including the extension (e.g., `example.com`, `mybrand.app`). The domain name uniquely identifies a registration. Cloudflare permits only one registration per domain, making the domain name a natural idempotency key for registration requests. */
    domainName: string;
}
export type GetDomainResponse = unknown;
export interface GetExtensionRequest {
    /** Identifier. */
    accountId: string;
    extension: string;
}
export interface GetExtensionResponseMetadata {
    /** The full name of the extension. For example, "co.uk", or "uk". */
    name: string;
    /** The TLD of the extension. For example, for "co.uk", it is "uk". For "uk", it is "uk". */
    tld: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetExtensionResponse {
    /** Extension metadata. */
    metadata: GetExtensionResponseMetadata;
    /** JSON Schema describing the expected input structure for registration operations on this extension. */
    registrationSchema: unknown;
    /** JSON Schema describing the expected input structure for transfer operations on this extension. */
    transferSchema: unknown;
}
export interface GetRegistrationRequest {
    /** Identifier. */
    accountId: string;
    /** Provides a fully qualified domain name (FQDN), including the extension (e.g., `example.com`, `mybrand.app`). The domain name uniquely identifies a registration. Cloudflare permits only one registration per domain, making the domain name a natural idempotency key for registration requests. */
    domainName: string;
}
export type GetRegistrationResponsePrivacyMode = "off" | "redaction";
export type GetRegistrationResponseStatus = "active" | "registration_pending" | "transfer_pending" | "expired" | "suspended" | "redemption_period" | "pending_delete";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRegistrationResponse {
    /** Whether automatic renewal occurs before expiration. */
    autoRenew: boolean;
    /** When the domain was registered. Present when the registration resource exists. */
    createdAt: string;
    /** Provides a fully qualified domain name (FQDN), including the extension (e.g., `example.com`, `mybrand.app`). The domain name uniquely identifies a registration. Cloudflare permits only one registration per domain, making the domain name a natural idempotency key for registration requests. */
    domainName: string;
    /** When the domain registration expires. Ready registrations include this value; only `registration_pending` and `transfer_pending` may return null. */
    expiresAt: string;
    /** Whether the domain is locked for transfer. */
    locked: boolean;
    /** Current WHOIS privacy mode for the registration. */
    privacyMode: GetRegistrationResponsePrivacyMode;
    /** Current registration status. */
    status: GetRegistrationResponseStatus;
}
export interface GetRegistrationStatusRequest {
    /** Identifier. */
    accountId: string;
    /** Provides a fully qualified domain name (FQDN), including the extension (e.g., `example.com`, `mybrand.app`). The domain name uniquely identifies a registration. Cloudflare permits only one registration per domain, making the domain name a natural idempotency key for registration requests. */
    domainName: string;
}
export type RegistrationStatusGetResponseLinks = CreateRegistrationResponseLinks;
export type RegistrationStatusGetResponseState = "pending" | "in_progress" | "action_required" | "blocked" | "succeeded" | "failed";
export type RegistrationStatusGetResponseContextMap = {
    [key: string]: unknown | undefined;
};
export type RegistrationStatusGetResponseError = CreateRegistrationResponseError;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRegistrationStatusResponse {
    /** Indicates whether the workflow reached a terminal state. A `succeeded` or `failed` state returns `true`; `pending`, `in_progress`, `action_required`, and `blocked` return `false`. */
    completed: boolean;
    createdAt: string;
    links: CreateRegistrationResponseLinks;
    /** Describes the workflow lifecycle state. */
    state: RegistrationStatusGetResponseState;
    updatedAt: string;
    /** Provides workflow-specific data. */
    context?: RegistrationStatusGetResponseContextMap | null;
    /** Provides error details when a workflow reaches the `failed` state. The workflow type (registration, update, etc.) and underlying registry response determine the specific codes and messages. Workflow error codes differ from immediate HTTP error `errors[].code` values in non-2xx responses. Surface `error.message` to the user for context. */
    error?: CreateRegistrationResponseError | null;
}
export interface GetTransferInStatusRequest {
    /** Identifier. */
    accountId: string;
    /** Provides a fully qualified domain name (FQDN), including the extension (e.g., `example.com`, `mybrand.app`). The domain name uniquely identifies a registration. Cloudflare permits only one registration per domain, making the domain name a natural idempotency key for registration requests. */
    domainName: string;
}
export type GetTransferInStatusResponseLinks = CreateRegistrationResponseLinks;
export type GetTransferInStatusResponseState = "pending" | "in_progress" | "action_required" | "blocked" | "succeeded" | "failed";
export type GetTransferInStatusResponseContextMap = {
    [key: string]: unknown | undefined;
};
export type GetTransferInStatusResponseError = CreateRegistrationResponseError;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTransferInStatusResponse {
    /** Indicates whether the workflow reached a terminal state. A `succeeded` or `failed` state returns `true`; `pending`, `in_progress`, `action_required`, and `blocked` return `false`. */
    completed: boolean;
    createdAt: string;
    links: CreateRegistrationResponseLinks;
    /** Describes the workflow lifecycle state. */
    state: GetTransferInStatusResponseState;
    updatedAt: string;
    /** Provides workflow-specific data. */
    context?: GetTransferInStatusResponseContextMap | null;
    /** Provides error details when a workflow reaches the `failed` state. The workflow type (registration, update, etc.) and underlying registry response determine the specific codes and messages. Workflow error codes differ from immediate HTTP error `errors[].code` values in non-2xx responses. Surface `error.message` to the user for context. */
    error?: CreateRegistrationResponseError | null;
}
export interface GetUpdateStatusRequest {
    /** Identifier. */
    accountId: string;
    /** Provides a fully qualified domain name (FQDN), including the extension (e.g., `example.com`, `mybrand.app`). The domain name uniquely identifies a registration. Cloudflare permits only one registration per domain, making the domain name a natural idempotency key for registration requests. */
    domainName: string;
}
export type UpdateStatusGetResponseLinks = CreateRegistrationResponseLinks;
export type UpdateStatusGetResponseState = "pending" | "in_progress" | "action_required" | "blocked" | "succeeded" | "failed";
export type UpdateStatusGetResponseContextMap = {
    [key: string]: unknown | undefined;
};
export type UpdateStatusGetResponseError = CreateRegistrationResponseError;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUpdateStatusResponse {
    /** Indicates whether the workflow reached a terminal state. A `succeeded` or `failed` state returns `true`; `pending`, `in_progress`, `action_required`, and `blocked` return `false`. */
    completed: boolean;
    createdAt: string;
    links: CreateRegistrationResponseLinks;
    /** Describes the workflow lifecycle state. */
    state: UpdateStatusGetResponseState;
    updatedAt: string;
    /** Provides workflow-specific data. */
    context?: UpdateStatusGetResponseContextMap | null;
    /** Provides error details when a workflow reaches the `failed` state. The workflow type (registration, update, etc.) and underlying registry response determine the specific codes and messages. Workflow error codes differ from immediate HTTP error `errors[].code` values in non-2xx responses. Surface `error.message` to the user for context. */
    error?: CreateRegistrationResponseError | null;
}
export interface ListDomainsRequest {
    /** Identifier. */
    accountId: string;
}
export interface DomainsListResultItemRegistrantContact {
    /** Address. */
    address: string;
    /** City. */
    city: string;
    /** The country in which the user lives. */
    country: string;
    /** User's first name. */
    firstName: string;
    /** User's last name. */
    lastName: string;
    /** Name of organization. */
    organization: string;
    /** User's telephone number. */
    phone: string;
    /** State. */
    state: string;
    /** The zipcode or postal code where the user lives. */
    zip: string;
    /** Contact Identifier. */
    id?: string | null;
    /** Optional address line for unit, floor, suite, etc. */
    address2?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Contact fax number. */
    fax?: string | null;
}
export type DomainsListResultItemTransferInAcceptFoa = "needed" | "ok";
export type DomainsListResultItemTransferInApproveTransfer = "needed" | "ok" | "pending" | "trying" | "rejected" | "unknown";
export type DomainsListResultItemTransferInDisablePrivacy = "needed" | "ok" | "unknown";
export type DomainsListResultItemTransferInEnterAuthCode = "needed" | "ok" | "pending" | "trying" | "rejected";
export type DomainsListResultItemTransferInUnlockDomain = "needed" | "ok" | "pending" | "trying" | "unknown";
export interface DomainsListResultItemTransferIn {
    /** Status of the registrant authorization step. */
    acceptFoa?: DomainsListResultItemTransferInAcceptFoa | null;
    /** Status of the registry transfer-approval step. */
    approveTransfer?: DomainsListResultItemTransferInApproveTransfer | null;
    /** Indicates if cancellation is still possible. */
    canCancelTransfer?: boolean | null;
    /** Status of the privacy-guard disabling step at the foreign registrar. */
    disablePrivacy?: DomainsListResultItemTransferInDisablePrivacy | null;
    /** Status of the auth-code entry and verification step. */
    enterAuthCode?: DomainsListResultItemTransferInEnterAuthCode | null;
    /** Status of the domain-unlock step at the foreign registrar. */
    unlockDomain?: DomainsListResultItemTransferInUnlockDomain | null;
}
export interface DomainsListResultItem {
    /** Domain identifier. */
    id?: string | null;
    /** Shows if a domain is available for transferring into Cloudflare Registrar. */
    available?: boolean | null;
    /** Indicates eligibility to register the domain as a new domain. */
    canRegister?: boolean | null;
    /** Shows time of creation. */
    createdAt?: string | null;
    /** Shows name of current registrar. */
    currentRegistrar?: string | null;
    /** Shows when domain name registration expires. */
    expiresAt?: string | null;
    /** Shows whether a registrar lock is in place for a domain. */
    locked?: boolean | null;
    /** Shows contact information for domain registrant. */
    registrantContact?: DomainsListResultItemRegistrantContact | null;
    /** A comma-separated list of registry status codes. Refer to [EPP Status Codes](https://www.icann.org/resources/pages/epp-status-codes-2014-06-16-en) for the full list. */
    registryStatuses?: string | null;
    /** Indicates whether Cloudflare Registrar currently supports a particular TLD. Refer to [TLD Policies](https://www.cloudflare.com/tld-policies/) for a list of supported TLDs. */
    supportedTld?: boolean | null;
    /** Statuses for domain transfers into Cloudflare Registrar. */
    transferIn?: DomainsListResultItemTransferIn | null;
    /** Last updated. */
    updatedAt?: string | null;
    /** Domain name. */
    name?: string | null;
    /** Whether the domain auto-renews. */
    autoRenew?: boolean | null;
    /** Whether WHOIS privacy is enabled. */
    privacy?: boolean | null;
}
export type DomainsListResultList = Array<DomainsListResultItem>;
export interface ListDomainsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DomainsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ListExtensionsRequestDirection = "asc" | "desc";
export type ListExtensionsRequestSortBy = "name" | "created_at" | "updated_at";
export interface ListExtensionsRequest {
    /** Identifier. */
    accountId: string;
    /** Opaque token from a previous response's `result_info.cursor`. Pass this value to fetch the next page of results. Omit (or pass an empty string) for the first page. */
    cursor?: string;
    /** Sort direction for results. Defaults to ascending order. */
    direction?: ListExtensionsRequestDirection | (string & {});
    /** Filter extensions by exact name match. For example, `name=com` returns only the `com` extension. */
    name?: string;
    /** Number of items to return per page. */
    perPage?: number;
    /** Column to sort results by. Defaults to `name` when omitted. */
    sortBy?: ListExtensionsRequestSortBy | (string & {});
}
export type ListExtensionsResultItemMetadata = GetExtensionResponseMetadata;
export interface ListExtensionsResultItem {
    /** Extension metadata. */
    metadata: GetExtensionResponseMetadata;
    /** JSON Schema describing the expected input structure for registration operations on this extension. */
    registrationSchema: unknown;
    /** JSON Schema describing the expected input structure for transfer operations on this extension. */
    transferSchema: unknown;
}
export type ListExtensionsResultList = Array<ListExtensionsResultItem>;
export type ListExtensionsResponse = ListExtensionsResultList;
export type ListRegistrationsRequestDirection = "asc" | "desc";
export type ListRegistrationsRequestSortBy = "registry_created_at" | "registry_expires_at" | "name";
export interface ListRegistrationsRequest {
    /** Identifier. */
    accountId: string;
    /** Opaque token from a previous response's `result_info.cursor`. Pass this value to fetch the next page of results. Omit (or pass an empty string) for the first page. */
    cursor?: string;
    /** Sort direction for results. Defaults to ascending order. */
    direction?: ListRegistrationsRequestDirection | (string & {});
    /** Number of items to return per page. */
    perPage?: number;
    /** Column to sort results by. Defaults to registration date (`registry_created_at`) when omitted. */
    sortBy?: ListRegistrationsRequestSortBy | (string & {});
}
export type ListRegistrationsResultItemPrivacyMode = "off" | "redaction";
export type ListRegistrationsResultItemStatus = "active" | "registration_pending" | "transfer_pending" | "expired" | "suspended" | "redemption_period" | "pending_delete";
export interface ListRegistrationsResultItem {
    /** Whether automatic renewal occurs before expiration. */
    autoRenew: boolean;
    /** When the domain was registered. Present when the registration resource exists. */
    createdAt: string;
    /** Provides a fully qualified domain name (FQDN), including the extension (e.g., `example.com`, `mybrand.app`). The domain name uniquely identifies a registration. Cloudflare permits only one registration per domain, making the domain name a natural idempotency key for registration requests. */
    domainName: string;
    /** When the domain registration expires. Ready registrations include this value; only `registration_pending` and `transfer_pending` may return null. */
    expiresAt: string;
    /** Whether the domain is locked for transfer. */
    locked: boolean;
    /** Current WHOIS privacy mode for the registration. */
    privacyMode: ListRegistrationsResultItemPrivacyMode;
    /** Current registration status. */
    status: ListRegistrationsResultItemStatus;
}
export type ListRegistrationsResultList = Array<ListRegistrationsResultItem>;
export type ListRegistrationsResponse = ListRegistrationsResultList;
export interface PutDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Provides a fully qualified domain name (FQDN), including the extension (e.g., `example.com`, `mybrand.app`). The domain name uniquely identifies a registration. Cloudflare permits only one registration per domain, making the domain name a natural idempotency key for registration requests. */
    domainName: string;
    /** Auto-renew controls whether subscription is automatically renewed upon domain expiration. */
    autoRenew?: boolean;
    /** Shows whether a registrar lock is in place for a domain. */
    locked?: boolean;
    /** Privacy option controls redacting WHOIS information. */
    privacy?: boolean;
}
export type PutDomainResponse = unknown;
export type SearchRequestExtensionsList = Array<string>;
export interface SearchRegistrarRequest {
    /** Identifier. */
    accountId: string;
    /** The search term to find domain suggestions. Accepts keywords, phrases, or full domain names. */
    q: string;
    /** Limits results to specific domain extensions from the supported set. If not specified, returns results across all supported extensions. Extensions not in the supported set are silently ignored. */
    extensions?: SearchRequestExtensionsList;
    /** Maximum number of domain suggestions to return. Defaults to 20 if not specified. */
    limit?: number;
}
export type SearchResponseDomainsItemPricing = CheckResponseDomainsItemPricing;
export type SearchResponseDomainsItemReason = "extension_not_supported_via_api" | "extension_not_supported" | "extension_disallows_registration" | "domain_premium" | "domain_unavailable";
export type SearchResponseDomainsItemTier = "standard" | "premium";
export interface SearchResponseDomainsItem {
    /** The fully qualified domain name (FQDN) in punycode format for internationalized domain names (IDNs). */
    name: string;
    /** Indicates domain availability according to potentially stale, non-authoritative search data. */
    registrable: boolean;
    /** Provides annual pricing information for a given domain. The API returns all per-year prices as strings to preserve decimal precision. */
    pricing?: CheckResponseDomainsItemPricing | null;
    /** Appears only when `registrable` is `false` and explains the advisory search result. Use POST /domain-check for authoritative status. */
    reason?: SearchResponseDomainsItemReason | null;
    /** The pricing tier for this domain. A `registrable` value of `true` always includes this field, which defaults to `standard` for most domains. A `registrable` value of `false` may omit it. */
    tier?: SearchResponseDomainsItemTier | null;
}
export type SearchResponseDomainsList = Array<SearchResponseDomainsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchRegistrarResponse {
    /** Lists domain suggestions in relevance order. An empty array indicates that the search criteria matched zero domains. */
    domains: SearchResponseDomainsList;
}
export interface TransferCheckRequestDomainsItem {
    /** Fully qualified domain name (FQDN) to check for transfer eligibility. */
    domainName: string;
    /** Base64-encoded auth/EPP code from the current registrar. Required for most TLDs. `.uk` namespaces do not use auth codes. */
    authCode?: string;
}
export type TransferCheckRequestDomainsList = Array<TransferCheckRequestDomainsItem>;
export interface TransferCheckRequest {
    /** Identifier. */
    accountId: string;
    /** List of domain objects to evaluate for transfer eligibility. */
    domains: TransferCheckRequestDomainsList;
}
export interface TransferCheckResponseDomainsValueTransferableResultPricing {
    /** ISO-4217 currency code for the prices (e.g., "USD", "EUR", "GBP"). */
    currency: string;
    /** Per-year renewal cost for this domain. Applied to each year beyond the first year of a multi-year registration, and to each annual auto-renewal thereafter. May differ from `registration_cost`, especially for premium domains where initial registration often costs more than renewals. */
    renewalCost: string;
    /** The first-year cost to transfer this domain. */
    transferCost: string;
}
export type TransferCheckResponseDomainsValueTransferableResultReasonsItemCode = "extension_not_supported_via_api" | "extension_not_supported" | "domain_premium" | "extension_disallows_transfer" | "domain_not_exists" | "domain_on_cloudflare" | "domain_locked" | "registry_status" | "domain_outside_transfer_window" | "domain_max_term" | "invalid_auth_code" | "invalid_auth_code_format" | "dnssec_enabled" | "zone_not_found" | "zone_status_invalid" | "invalid_zone_plan" | "domain_unsupported";
export interface TransferCheckResponseDomainsValueTransferableResultReasonsItem {
    /** Transfer eligibility reason code. */
    code: TransferCheckResponseDomainsValueTransferableResultReasonsItemCode;
}
export type TransferCheckResponseDomainsValueTransferableResultReasonsList = Array<TransferCheckResponseDomainsValueTransferableResultReasonsItem>;
export interface TransferCheckResponseDomainsValueTransferableResult {
    /** Provides annual pricing information for a given domain. The API returns all per-year prices as strings to preserve decimal precision. */
    pricing: TransferCheckResponseDomainsValueTransferableResultPricing;
    transferable: boolean;
    /** The check evaluates this domain name. */
    name?: string | null;
    reasons?: TransferCheckResponseDomainsValueTransferableResultReasonsList | null;
}
export type TransferCheckResponseDomainsValueNonTransferableResultPricing = TransferCheckResponseDomainsValueTransferableResultPricing;
export type TransferCheckResponseDomainsValueNonTransferableResultReasonsItemCode = "extension_not_supported_via_api" | "extension_not_supported" | "domain_premium" | "extension_disallows_transfer" | "domain_not_exists" | "domain_on_cloudflare" | "domain_locked" | "registry_status" | "domain_outside_transfer_window" | "domain_max_term" | "invalid_auth_code" | "invalid_auth_code_format" | "dnssec_enabled" | "zone_not_found" | "zone_status_invalid" | "invalid_zone_plan" | "domain_unsupported";
export interface TransferCheckResponseDomainsValueNonTransferableResultReasonsItem {
    /** Transfer eligibility reason code. */
    code: TransferCheckResponseDomainsValueNonTransferableResultReasonsItemCode;
}
export type TransferCheckResponseDomainsValueNonTransferableResultReasonsList = Array<TransferCheckResponseDomainsValueNonTransferableResultReasonsItem>;
export interface TransferCheckResponseDomainsValueNonTransferableResult {
    transferable: boolean;
    /** The check evaluates this domain name. */
    name?: string | null;
    /** Provides annual pricing information for a given domain. The API returns all per-year prices as strings to preserve decimal precision. */
    pricing?: TransferCheckResponseDomainsValueTransferableResultPricing | null;
    reasons?: TransferCheckResponseDomainsValueNonTransferableResultReasonsList | null;
}
export type TransferCheckResponseDomainsValue = TransferCheckResponseDomainsValueTransferableResult | TransferCheckResponseDomainsValueNonTransferableResult;
export type TransferCheckResponseDomainsMap = {
    [key: string]: TransferCheckResponseDomainsValue | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface TransferCheckResponse {
    /** Maps domain names to transfer eligibility results. Each value contains `name`, `transferable`, and `reasons`. */
    domains: TransferCheckResponseDomainsMap;
}
export type CheckRegistrarError = CloudflareOpError;
/** Performs real-time, authoritative availability checks directly against domain registries. Use this endpoint to verify a domain is available before attempting registration via `POST /registrations`. **Important:** Unlike the Search endpoint, these results are authoritative and reflect current registry status. Always check availability immediately before registration as domain status can change rapidly. **Note:** This endpoint uses POST to accept a list of domains in the request body. It is a read-only operation -- it does not create, modify, or reserve any domains. */
export declare const checkRegistrar: API.OperationMethod<CheckRegistrarRequest, CheckRegistrarResponse, CheckRegistrarError, CloudflareOpContext>;
export type CreateRegistrationError = CloudflareOpError;
/** Starts a domain registration workflow. This is a billable operation -- successful registration charges the account's default payment method. All successful domain registrations are non-refundable -- once the workflow completes with `state: succeeded`, the charge cannot be reversed. */
export declare const createRegistration: API.OperationMethod<CreateRegistrationRequest, CreateRegistrationResponse, CreateRegistrationError, CloudflareOpContext>;
export type CreateTransferInError = CloudflareOpError;
/** Starts a domain transfer-in workflow. This is typically a billable operation -- successful transfers charge the account's default payment method, except for extensions with zero transfer pricing (e.g. UK extensions). All successful domain transfers are non-refundable. */
export declare const createTransferIn: API.OperationMethod<CreateTransferInRequest, CreateTransferInResponse, CreateTransferInError, CloudflareOpContext>;
export type EditRegistrationError = CloudflareOpError;
/** Updates an existing domain registration. By default, the server holds the connection for a bounded, server-defined amount of time while the update completes. Most updates finish within this window and return `200 OK` with a completed workflow status. If the update is still processing after this synchronous wait window, the server returns `202 Accepted`. Poll the URL in `links.self` to track progress. To skip the wait and receive an immediate `202`, send `Prefer: respond-async`. This endpoint currently supports updating `auto_renew` only. */
export declare const editRegistration: API.OperationMethod<EditRegistrationRequest, EditRegistrationResponse, EditRegistrationError, CloudflareOpContext>;
export type GetDomainError = Forbidden | CloudflareOpError;
/** Show individual domain. */
export declare const getDomain: API.OperationMethod<GetDomainRequest, GetDomainResponse, GetDomainError, CloudflareOpContext>;
export type GetExtensionError = CloudflareOpError;
/** Returns metadata and JSON Schema documents describing the expected input structure for registration and transfer operations on a specific extension (TLD). Supports HTTP conditional GET via `ETag`. Include the `ETag` value from a previous response in an `If-None-Match` header to receive a `304 Not Modified` when the data has not changed. */
export declare const getExtension: API.OperationMethod<GetExtensionRequest, GetExtensionResponse, GetExtensionError, CloudflareOpContext>;
export type GetRegistrationError = CloudflareOpError;
/** Returns the current state of a domain registration. This is the canonical read endpoint for a domain you own. It returns the full registration resource including current settings and expiration. When the registration resource is ready, both `created_at` and `expires_at` are present in the response. */
export declare const getRegistration: API.OperationMethod<GetRegistrationRequest, GetRegistrationResponse, GetRegistrationError, CloudflareOpContext>;
export type GetRegistrationStatusError = CloudflareOpError;
/** Returns the current status of a domain registration workflow. Use this endpoint to poll for completion when the POST response returned `202 Accepted`. The URL is provided in the `links.self` field of the workflow status response. Poll this endpoint until the workflow reaches a terminal state or a state that requires user attention. **Terminal states:** `succeeded` and `failed` are terminal and always have `completed: true`. **Non-terminal states:** - `action_required` has `completed: false` and will not resolve on its own. The workflow is paused pending user intervention. - `blocked` has `completed: false` and indicates the workflow is waiting on a third party such as the extension registry or losing registrar. Continue polling while informing the user of the delay. Use increasing backoff between polls. When `state: blocked`, use a longer polling interval and do not poll indefinitely. A naive polling loop that only checks `completed` can run indefinitely when `state: action_required`. Break explicitly on `action_required`: */
export declare const getRegistrationStatus: API.OperationMethod<GetRegistrationStatusRequest, GetRegistrationStatusResponse, GetRegistrationStatusError, CloudflareOpContext>;
export type GetTransferInStatusError = CloudflareOpError;
/** Returns the current status of a domain transfer workflow. Use this endpoint to poll transfer progress after initiating a transfer with `POST /accounts/{account_id}/registrar/registrations/{domain_name}/transfer-in`. The URL is provided in the `links.self` field of the transfer response. */
export declare const getTransferInStatus: API.OperationMethod<GetTransferInStatusRequest, GetTransferInStatusResponse, GetTransferInStatusError, CloudflareOpContext>;
export type GetUpdateStatusError = CloudflareOpError;
/** Returns the current status of a domain update workflow. Use this endpoint to poll for completion when the PATCH response returned `202 Accepted`. The URL is provided in the `links.self` field of the workflow status response. Poll this endpoint until the workflow reaches a terminal state or a state that requires user attention. Use increasing backoff between polls. When the workflow remains blocked on a third party, use a longer polling interval and do not poll indefinitely. */
export declare const getUpdateStatus: API.OperationMethod<GetUpdateStatusRequest, GetUpdateStatusResponse, GetUpdateStatusError, CloudflareOpContext>;
export type ListDomainsError = Forbidden | CloudflareOpError;
/** Lists domains handled by Registrar. */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest, ListDomainsResponse, ListDomainsError, CloudflareOpContext, DomainsListResultItem>;
export type ListExtensionsError = CloudflareOpError;
/** Returns metadata and JSON Schema documents describing the expected input structure for registration and transfer operations on each supported extension (TLD). This endpoint uses cursor-based pagination. Results are ordered by extension name by default. To fetch the next page, pass the `cursor` value from the `result_info` object in the response as the `cursor` query parameter in your next request. An empty `cursor` string indicates there are no more pages. Supports HTTP conditional GET via `ETag`. Include the `ETag` value from a previous response in an `If-None-Match` header to receive a `304 Not Modified` when the data has not changed. */
export declare const listExtensions: API.OperationMethod<ListExtensionsRequest, ListExtensionsResponse, ListExtensionsError, CloudflareOpContext>;
export type ListRegistrationsError = CloudflareOpError;
/** Returns a paginated list of domain registrations owned by the account. This endpoint uses cursor-based pagination. Results are ordered by registration date by default. To fetch the next page, pass the `cursor` value from the `result_info` object in the response as the `cursor` query parameter in your next request. An empty `cursor` string indicates there are no more pages. */
export declare const listRegistrations: API.OperationMethod<ListRegistrationsRequest, ListRegistrationsResponse, ListRegistrationsError, CloudflareOpContext>;
export type PutDomainError = RegistrarDomainNotOwned | RegistrarUpdateNotAllowed | Forbidden | CloudflareOpError;
/** Updates an individual domain. */
export declare const putDomain: API.OperationMethod<PutDomainRequest, PutDomainResponse, PutDomainError, CloudflareOpContext>;
export type SearchRegistrarError = CloudflareOpError;
/** Searches for domain name suggestions based on a keyword, phrase, or partial domain name. Returns a list of potentially available domains with pricing information. **Important:** Results are non-authoritative and based on cached data. Always use the `/domain-check` endpoint to verify real-time availability before attempting registration. Suggestions are scoped to extensions supported for programmatic registration via this API (`POST /registrations`). Domains on unsupported extensions will not appear in results, even if they are available at the registry level. */
export declare const searchRegistrar: API.OperationMethod<SearchRegistrarRequest, SearchRegistrarResponse, SearchRegistrarError, CloudflareOpContext>;
export type TransferCheckError = CloudflareOpError;
/** Performs real-time, authoritative eligibility checks directly against needed requirements. Use this endpoint to verify a domain is available before attempting a transfer via `POST /registrations/:domain_name/transfer-in`. **Note:** This endpoint uses POST to accept a list of domains in the request body. It is a read-only operation -- it does not create, modify, or reserve any domains. */
export declare const transferCheck: API.OperationMethod<TransferCheckRequest, TransferCheckResponse, TransferCheckError, CloudflareOpContext>;
//# sourceMappingURL=registrar.d.ts.map