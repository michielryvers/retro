import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const WidgetNotFound_base: S.TaggedErrorClass<"WidgetNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WidgetNotFound extends /*@__PURE__*/ WidgetNotFound_base {
}
export type WidgetsCreateRequestDirection = "asc" | "desc";
export type WidgetsCreateRequestOrder = "id" | "sitekey" | "name" | "created_on" | "modified_on";
export type WidgetsCreateRequestDomainsList = Array<string>;
export type WidgetsCreateRequestMode = "non-interactive" | "invisible" | "managed";
export type WidgetsCreateRequestClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export type WidgetsCreateRequestRegion = "world" | "china";
export interface CreateWidgetRequest {
    /** Identifier */
    accountId: string;
    /** Direction to order widgets. */
    direction?: WidgetsCreateRequestDirection | (string & {});
    /** Filter widgets by field. The `name` field uses case-insensitive substring matching; `sitekey` uses exact matching. Format: `field:value` */
    filter?: string;
    /** Field to order widgets by. */
    order?: WidgetsCreateRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
    domains: WidgetsCreateRequestDomainsList;
    /** Widget Mode */
    mode: WidgetsCreateRequestMode | (string & {});
    /** Human readable widget name. Not unique. Cloudflare suggests that you set this to a meaningful string to make it easier to identify your widget, and where it is used. */
    name: string;
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally expensive challenges in response to malicious bots (ENT only). */
    botFightMode?: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, this setting can determine the clearance level to be set */
    clearanceLevel?: WidgetsCreateRequestClearanceLevel | (string & {});
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId?: boolean;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel?: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region?: WidgetsCreateRequestRegion | (string & {});
}
export type WidgetsCreateResponseClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export type WidgetsCreateResponseDomainsList = Array<string>;
export type WidgetsCreateResponseMode = "non-interactive" | "invisible" | "managed";
export type WidgetsCreateResponseRegion = "world" | "china";
export type WidgetsCreateResponseDeployedVia = "wrangler" | "dashboard" | "spin" | "api" | "unknown";
export type WidgetsCreateResponseLastModifiedVia = "wrangler" | "dashboard" | "spin" | "api" | "unknown";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateWidgetResponse {
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally expensive challenges in response to malicious bots (ENT only). */
    botFightMode: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, this setting can determine the clearance level to be set */
    clearanceLevel: WidgetsCreateResponseClearanceLevel;
    /** When the widget was created. */
    createdOn: string;
    domains: WidgetsCreateResponseDomainsList;
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId: boolean;
    /** Widget Mode */
    mode: WidgetsCreateResponseMode;
    /** When the widget was modified. */
    modifiedOn: string;
    /** Human readable widget name. Not unique. Cloudflare suggests that you set this to a meaningful string to make it easier to identify your widget, and where it is used. */
    name: string;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region: WidgetsCreateResponseRegion;
    /** Secret key for this widget. */
    secret: string;
    /** Unique identifier for a Turnstile widget. */
    sitekey: string;
    /** Origin that created this widget, recorded at creation time and immutable afterward. Server-derived from the create request; not client-settable. Omitted from the response for widgets created before this field existed. */
    deployedVia?: WidgetsCreateResponseDeployedVia | null;
    /** Origin of the most recent mutation (create, update, delete, or secret rotation). Server-derived; not client-settable. Omitted for widgets last mutated before this field existed. */
    lastModifiedVia?: WidgetsCreateResponseLastModifiedVia | null;
}
export interface DeleteWidgetRequest {
    /** Identifier */
    accountId: string;
    /** Unique identifier for a Turnstile widget. */
    sitekey: string;
}
export type WidgetsDeleteResponseClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export type WidgetsDeleteResponseDomainsList = Array<string>;
export type WidgetsDeleteResponseMode = "non-interactive" | "invisible" | "managed";
export type WidgetsDeleteResponseRegion = "world" | "china";
export type WidgetsDeleteResponseDeployedVia = "wrangler" | "dashboard" | "spin" | "api" | "unknown";
export type WidgetsDeleteResponseLastModifiedVia = "wrangler" | "dashboard" | "spin" | "api" | "unknown";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteWidgetResponse {
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally expensive challenges in response to malicious bots (ENT only). */
    botFightMode: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, this setting can determine the clearance level to be set */
    clearanceLevel: WidgetsDeleteResponseClearanceLevel;
    /** When the widget was created. */
    createdOn: string;
    domains: WidgetsDeleteResponseDomainsList;
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId: boolean;
    /** Widget Mode */
    mode: WidgetsDeleteResponseMode;
    /** When the widget was modified. */
    modifiedOn: string;
    /** Human readable widget name. Not unique. Cloudflare suggests that you set this to a meaningful string to make it easier to identify your widget, and where it is used. */
    name: string;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region: WidgetsDeleteResponseRegion;
    /** Secret key for this widget. */
    secret: string;
    /** Unique identifier for a Turnstile widget. */
    sitekey: string;
    /** Origin that created this widget, recorded at creation time and immutable afterward. Server-derived from the create request; not client-settable. Omitted from the response for widgets created before this field existed. */
    deployedVia?: WidgetsDeleteResponseDeployedVia | null;
    /** Origin of the most recent mutation (create, update, delete, or secret rotation). Server-derived; not client-settable. Omitted for widgets last mutated before this field existed. */
    lastModifiedVia?: WidgetsDeleteResponseLastModifiedVia | null;
}
export interface GetWidgetRequest {
    /** Identifier */
    accountId: string;
    /** Unique identifier for a Turnstile widget. */
    sitekey: string;
}
export type WidgetsGetResponseClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export type WidgetsGetResponseDomainsList = Array<string>;
export type WidgetsGetResponseMode = "non-interactive" | "invisible" | "managed";
export type WidgetsGetResponseRegion = "world" | "china";
export type WidgetsGetResponseDeployedVia = "wrangler" | "dashboard" | "spin" | "api" | "unknown";
export type WidgetsGetResponseLastModifiedVia = "wrangler" | "dashboard" | "spin" | "api" | "unknown";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetWidgetResponse {
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally expensive challenges in response to malicious bots (ENT only). */
    botFightMode: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, this setting can determine the clearance level to be set */
    clearanceLevel: WidgetsGetResponseClearanceLevel;
    /** When the widget was created. */
    createdOn: string;
    domains: WidgetsGetResponseDomainsList;
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId: boolean;
    /** Widget Mode */
    mode: WidgetsGetResponseMode;
    /** When the widget was modified. */
    modifiedOn: string;
    /** Human readable widget name. Not unique. Cloudflare suggests that you set this to a meaningful string to make it easier to identify your widget, and where it is used. */
    name: string;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region: WidgetsGetResponseRegion;
    /** Secret key for this widget. */
    secret: string;
    /** Unique identifier for a Turnstile widget. */
    sitekey: string;
    /** Origin that created this widget, recorded at creation time and immutable afterward. Server-derived from the create request; not client-settable. Omitted from the response for widgets created before this field existed. */
    deployedVia?: WidgetsGetResponseDeployedVia | null;
    /** Origin of the most recent mutation (create, update, delete, or secret rotation). Server-derived; not client-settable. Omitted for widgets last mutated before this field existed. */
    lastModifiedVia?: WidgetsGetResponseLastModifiedVia | null;
}
export type WidgetsListRequestDirection = "asc" | "desc";
export type WidgetsListRequestOrder = "id" | "sitekey" | "name" | "created_on" | "modified_on";
export interface ListWidgetsRequest {
    /** Identifier */
    accountId: string;
    /** Direction to order widgets. */
    direction?: WidgetsListRequestDirection | (string & {});
    /** Filter widgets by field. The `name` field uses case-insensitive substring matching; `sitekey` uses exact matching. Format: `field:value` */
    filter?: string;
    /** Field to order widgets by. */
    order?: WidgetsListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
}
export type WidgetsListResultItemClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export type WidgetsListResultItemDomainsList = Array<string>;
export type WidgetsListResultItemMode = "non-interactive" | "invisible" | "managed";
export type WidgetsListResultItemRegion = "world" | "china";
export type WidgetsListResultItemDeployedVia = "wrangler" | "dashboard" | "spin" | "api" | "unknown";
export type WidgetsListResultItemLastModifiedVia = "wrangler" | "dashboard" | "spin" | "api" | "unknown";
export interface WidgetsListResultItem {
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally expensive challenges in response to malicious bots (ENT only). */
    botFightMode: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, this setting can determine the clearance level to be set */
    clearanceLevel: WidgetsListResultItemClearanceLevel;
    /** When the widget was created. */
    createdOn: string;
    domains: WidgetsListResultItemDomainsList;
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId: boolean;
    /** Widget Mode */
    mode: WidgetsListResultItemMode;
    /** When the widget was modified. */
    modifiedOn: string;
    /** Human readable widget name. Not unique. Cloudflare suggests that you set this to a meaningful string to make it easier to identify your widget, and where it is used. */
    name: string;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region: WidgetsListResultItemRegion;
    /** Unique identifier for a Turnstile widget. */
    sitekey: string;
    /** Origin that created this widget, recorded at creation time and immutable afterward. Server-derived from the create request; not client-settable. Omitted from the response for widgets created before this field existed. */
    deployedVia?: WidgetsListResultItemDeployedVia | null;
    /** Origin of the most recent mutation (create, update, delete, or secret rotation). Server-derived; not client-settable. Omitted for widgets last mutated before this field existed. */
    lastModifiedVia?: WidgetsListResultItemLastModifiedVia | null;
}
export type WidgetsListResultList = Array<WidgetsListResultItem>;
export interface ListWidgetsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: WidgetsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface RotateSecretWidgetRequest {
    /** Identifier */
    accountId: string;
    /** Unique identifier for a Turnstile widget. */
    sitekey: string;
    /** If `invalidate_immediately` is set to `false`, the previous secret will remain valid for two hours. Otherwise, the secret is immediately invalidated, and requests using it will be rejected. */
    invalidateImmediately?: boolean;
}
export type WidgetsRotateSecretResponseClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export type WidgetsRotateSecretResponseDomainsList = Array<string>;
export type WidgetsRotateSecretResponseMode = "non-interactive" | "invisible" | "managed";
export type WidgetsRotateSecretResponseRegion = "world" | "china";
export type WidgetsRotateSecretResponseDeployedVia = "wrangler" | "dashboard" | "spin" | "api" | "unknown";
export type WidgetsRotateSecretResponseLastModifiedVia = "wrangler" | "dashboard" | "spin" | "api" | "unknown";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RotateSecretWidgetResponse {
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally expensive challenges in response to malicious bots (ENT only). */
    botFightMode: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, this setting can determine the clearance level to be set */
    clearanceLevel: WidgetsRotateSecretResponseClearanceLevel;
    /** When the widget was created. */
    createdOn: string;
    domains: WidgetsRotateSecretResponseDomainsList;
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId: boolean;
    /** Widget Mode */
    mode: WidgetsRotateSecretResponseMode;
    /** When the widget was modified. */
    modifiedOn: string;
    /** Human readable widget name. Not unique. Cloudflare suggests that you set this to a meaningful string to make it easier to identify your widget, and where it is used. */
    name: string;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region: WidgetsRotateSecretResponseRegion;
    /** Secret key for this widget. */
    secret: string;
    /** Unique identifier for a Turnstile widget. */
    sitekey: string;
    /** Origin that created this widget, recorded at creation time and immutable afterward. Server-derived from the create request; not client-settable. Omitted from the response for widgets created before this field existed. */
    deployedVia?: WidgetsRotateSecretResponseDeployedVia | null;
    /** Origin of the most recent mutation (create, update, delete, or secret rotation). Server-derived; not client-settable. Omitted for widgets last mutated before this field existed. */
    lastModifiedVia?: WidgetsRotateSecretResponseLastModifiedVia | null;
}
export type WidgetsUpdateRequestDomainsList = Array<string>;
export type WidgetsUpdateRequestMode = "non-interactive" | "invisible" | "managed";
export type WidgetsUpdateRequestClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export type WidgetsUpdateRequestRegion = "world" | "china";
export interface UpdateWidgetRequest {
    /** Identifier */
    accountId: string;
    /** Unique identifier for a Turnstile widget. */
    sitekey: string;
    domains: WidgetsUpdateRequestDomainsList;
    /** Widget Mode */
    mode: WidgetsUpdateRequestMode | (string & {});
    /** Human readable widget name. Not unique. Cloudflare suggests that you set this to a meaningful string to make it easier to identify your widget, and where it is used. */
    name: string;
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally expensive challenges in response to malicious bots (ENT only). */
    botFightMode?: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, this setting can determine the clearance level to be set */
    clearanceLevel?: WidgetsUpdateRequestClearanceLevel | (string & {});
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId?: boolean;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel?: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region?: WidgetsUpdateRequestRegion | (string & {});
}
export type WidgetsUpdateResponseClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export type WidgetsUpdateResponseDomainsList = Array<string>;
export type WidgetsUpdateResponseMode = "non-interactive" | "invisible" | "managed";
export type WidgetsUpdateResponseRegion = "world" | "china";
export type WidgetsUpdateResponseDeployedVia = "wrangler" | "dashboard" | "spin" | "api" | "unknown";
export type WidgetsUpdateResponseLastModifiedVia = "wrangler" | "dashboard" | "spin" | "api" | "unknown";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateWidgetResponse {
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally expensive challenges in response to malicious bots (ENT only). */
    botFightMode: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, this setting can determine the clearance level to be set */
    clearanceLevel: WidgetsUpdateResponseClearanceLevel;
    /** When the widget was created. */
    createdOn: string;
    domains: WidgetsUpdateResponseDomainsList;
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId: boolean;
    /** Widget Mode */
    mode: WidgetsUpdateResponseMode;
    /** When the widget was modified. */
    modifiedOn: string;
    /** Human readable widget name. Not unique. Cloudflare suggests that you set this to a meaningful string to make it easier to identify your widget, and where it is used. */
    name: string;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region: WidgetsUpdateResponseRegion;
    /** Secret key for this widget. */
    secret: string;
    /** Unique identifier for a Turnstile widget. */
    sitekey: string;
    /** Origin that created this widget, recorded at creation time and immutable afterward. Server-derived from the create request; not client-settable. Omitted from the response for widgets created before this field existed. */
    deployedVia?: WidgetsUpdateResponseDeployedVia | null;
    /** Origin of the most recent mutation (create, update, delete, or secret rotation). Server-derived; not client-settable. Omitted for widgets last mutated before this field existed. */
    lastModifiedVia?: WidgetsUpdateResponseLastModifiedVia | null;
}
export type CreateWidgetError = CloudflareOpError;
/** Creates a Turnstile widget for an account. */
export declare const createWidget: API.OperationMethod<CreateWidgetRequest, CreateWidgetResponse, CreateWidgetError, CloudflareOpContext>;
export type DeleteWidgetError = WidgetNotFound | Forbidden | CloudflareOpError;
/** Deletes a Turnstile widget from an account. */
export declare const deleteWidget: API.OperationMethod<DeleteWidgetRequest, DeleteWidgetResponse, DeleteWidgetError, CloudflareOpContext>;
export type GetWidgetError = WidgetNotFound | Forbidden | CloudflareOpError;
/** Returns the configuration of a Turnstile widget. */
export declare const getWidget: API.OperationMethod<GetWidgetRequest, GetWidgetResponse, GetWidgetError, CloudflareOpContext>;
export type ListWidgetsError = CloudflareOpError;
/** Lists Turnstile widgets for an account. */
export declare const listWidgets: API.PaginatedOperationMethod<ListWidgetsRequest, ListWidgetsResponse, ListWidgetsError, CloudflareOpContext, WidgetsListResultItem>;
export type RotateSecretWidgetError = CloudflareOpError;
/** Generates a new secret key for this widget. If `invalidate_immediately` is set to `false`, the previous secret remains valid for 2 hours. Note that secrets cannot be rotated again during the grace period. */
export declare const rotateSecretWidget: API.OperationMethod<RotateSecretWidgetRequest, RotateSecretWidgetResponse, RotateSecretWidgetError, CloudflareOpContext>;
export type UpdateWidgetError = CloudflareOpError;
/** Updates the configuration of a Turnstile widget. */
export declare const updateWidget: API.OperationMethod<UpdateWidgetRequest, UpdateWidgetResponse, UpdateWidgetError, CloudflareOpContext>;
//# sourceMappingURL=turnstile.d.ts.map