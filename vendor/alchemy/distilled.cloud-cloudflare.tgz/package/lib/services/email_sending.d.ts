import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const SendingSubdomainAlreadyExists_base: S.TaggedErrorClass<"SendingSubdomainAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SendingSubdomainAlreadyExists extends /*@__PURE__*/ SendingSubdomainAlreadyExists_base {
}
declare const SendingSubdomainNotFound_base: S.TaggedErrorClass<"SendingSubdomainNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SendingSubdomainNotFound extends /*@__PURE__*/ SendingSubdomainNotFound_base {
}
export interface CreateSubdomainRequest {
    /** Identifier. */
    zoneId: string;
    /** The domain name within the zone. A wildcard is allowed only as the complete leftmost label (`*.example.com`) and requires the account wildcard Email Sending entitlement. */
    name: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSubdomainResponse {
    /** Whether Email Sending is enabled on this subdomain. */
    enabled: boolean;
    /** The exact domain name or a leftmost wildcard such as `*.example.com`. */
    name: string;
    /** Sending subdomain identifier. */
    tag: string;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The DKIM selector used for email signing. Wildcard rows publish the selector and sign with `d=&lt;base&gt;`. */
    dkimSelector?: string | null;
    /** Whether a send request that includes a recipient suppressed on this subdomain drops that recipient and still delivers to the rest, instead of failing the entire request. */
    dropSuppressedRecipients?: boolean | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Whether sent messages from this subdomain can be previewed in the activity log. */
    previewEnabled?: boolean | null;
    /** The return-path domain used for bounce handling. Wildcard rows use `cf-bounce.&lt;base&gt;`. */
    returnPathDomain?: string | null;
}
export type CreateSuppressionRequestScopeTypeType = "account";
export interface CreateSuppressionRequestScopeType {
    /** Blocks the recipient for every sending domain of the account. */
    type: CreateSuppressionRequestScopeTypeType;
}
export type CreateSuppressionRequestScopeCase1Type = "sending_domain";
export interface CreateSuppressionRequestScopeCase1 {
    /** Blocks the recipient only for mail whose envelope MAIL FROM uses `value`. */
    type: CreateSuppressionRequestScopeCase1Type;
    /** The sending domain to suppress for: the domain part of the envelope MAIL FROM. It is lowercased and trailing dots are removed. Internationalized domains must use the ASCII (punycode) form. Ownership is not checked; a domain the account does not send from never matches. */
    value: string;
}
export type CreateSuppressionRequestScope = CreateSuppressionRequestScopeType | CreateSuppressionRequestScopeCase1;
export interface CreateSuppressionRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** The email address to suppress. */
    email: string;
    /** Expiration timestamp for the suppression. Omit or set to null for a permanent suppression that never expires. */
    expiresAt?: string;
    /** Advisory note for this suppression. Not enforced or validated beyond length. */
    note?: string;
    /** Where the suppression applies. Omit for `{ "type": "account" }`, which blocks the recipient for every sending domain of the account. */
    scope?: CreateSuppressionRequestScope;
}
export type CreateSuppressionResponseScopeTypeType = "account";
export interface CreateSuppressionResponseScopeType {
    /** Blocks the recipient for every sending domain of the account. */
    type: CreateSuppressionResponseScopeTypeType;
}
export type CreateSuppressionResponseScopeCase1Type = "sending_domain";
export interface CreateSuppressionResponseScopeCase1 {
    /** Blocks the recipient only for mail whose envelope MAIL FROM uses `value`. */
    type: CreateSuppressionResponseScopeCase1Type;
    /** The sending domain: the domain part of the envelope MAIL FROM, lowercase, without a trailing dot. */
    value: string;
}
export type CreateSuppressionResponseScope = CreateSuppressionResponseScopeType | CreateSuppressionResponseScopeCase1;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSuppressionResponse {
    /** The suppression's identifier. */
    id: string;
    /** Where the suppression applies: `account` for every sending domain of the account, or `sending_domain` for one envelope MAIL FROM domain. */
    scope?: CreateSuppressionResponseScope | null;
}
export interface DeleteSubdomainRequest {
    /** Identifier. */
    zoneId: string;
    /** Sending subdomain identifier. */
    subdomainId: string;
}
export interface DeleteSubdomainResponse {
}
export interface DeleteSuppressionRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** The suppression's identifier. */
    suppressionId: string;
}
export type DeleteSuppressionResponseScopeTypeType = "account";
export interface DeleteSuppressionResponseScopeType {
    /** Blocks the recipient for every sending domain of the account. */
    type: DeleteSuppressionResponseScopeTypeType;
}
export type DeleteSuppressionResponseScopeCase1Type = "sending_domain";
export interface DeleteSuppressionResponseScopeCase1 {
    /** Blocks the recipient only for mail whose envelope MAIL FROM uses `value`. */
    type: DeleteSuppressionResponseScopeCase1Type;
    /** The sending domain: the domain part of the envelope MAIL FROM, lowercase, without a trailing dot. */
    value: string;
}
export type DeleteSuppressionResponseScope = DeleteSuppressionResponseScopeType | DeleteSuppressionResponseScopeCase1;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSuppressionResponse {
    /** The suppression's identifier. */
    id: string;
    /** Where the suppression applies: `account` for every sending domain of the account, or `sending_domain` for one envelope MAIL FROM domain. */
    scope?: DeleteSuppressionResponseScope | null;
}
export interface EditSubdomainRequest {
    /** Identifier. */
    zoneId: string;
    /** Sending subdomain identifier. */
    subdomainId: string;
    /** Whether a send request that includes a recipient suppressed on this subdomain drops that recipient and still delivers to the rest, instead of failing the entire request. */
    dropSuppressedRecipients?: boolean;
    /** Whether sent messages from this subdomain can be previewed in the activity log. */
    previewEnabled?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditSubdomainResponse {
    /** Whether Email Sending is enabled on this subdomain. */
    enabled: boolean;
    /** The exact domain name or a leftmost wildcard such as `*.example.com`. */
    name: string;
    /** Sending subdomain identifier. */
    tag: string;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The DKIM selector used for email signing. Wildcard rows publish the selector and sign with `d=&lt;base&gt;`. */
    dkimSelector?: string | null;
    /** Whether a send request that includes a recipient suppressed on this subdomain drops that recipient and still delivers to the rest, instead of failing the entire request. */
    dropSuppressedRecipients?: boolean | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Whether sent messages from this subdomain can be previewed in the activity log. */
    previewEnabled?: boolean | null;
    /** The return-path domain used for bounce handling. Wildcard rows use `cf-bounce.&lt;base&gt;`. */
    returnPathDomain?: string | null;
}
export interface EditSuppressionRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** The suppression's identifier. */
    suppressionId: string;
    /** New expiry. Send `null` to make the suppression permanent; omit to leave it unchanged. */
    expiresAt?: string;
    /** Replacement advisory note. Send an empty string to clear it; omit to leave it unchanged. */
    note?: string;
    /** Not editable. Scope is fixed when the suppression is created; any value returns 400 with code `scope_immutable`. Delete and recreate the suppression to change it. */
    scope?: unknown;
}
export type EditSuppressionResponseScopeTypeType = "account";
export interface EditSuppressionResponseScopeType {
    /** Blocks the recipient for every sending domain of the account. */
    type: EditSuppressionResponseScopeTypeType;
}
export type EditSuppressionResponseScopeCase1Type = "sending_domain";
export interface EditSuppressionResponseScopeCase1 {
    /** Blocks the recipient only for mail whose envelope MAIL FROM uses `value`. */
    type: EditSuppressionResponseScopeCase1Type;
    /** The sending domain: the domain part of the envelope MAIL FROM, lowercase, without a trailing dot. */
    value: string;
}
export type EditSuppressionResponseScope = EditSuppressionResponseScopeType | EditSuppressionResponseScopeCase1;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditSuppressionResponse {
    /** Unique identifier for this suppression. */
    id: string;
    /** When the suppression was created. */
    createdAt: string;
    /** The suppressed email address. */
    email: string;
    /** When the suppression expires. Null for a permanent suppression. */
    expiresAt: string;
    /** Whether clients may mutate this suppression. This is determined by the server and must not be inferred from `reason`. */
    readOnly: boolean;
    /** Why the address is suppressed: `manual`, `complaint`, `hard_bounce`, `soft_bounce`, or `policy`. */
    reason: string;
    /** Advisory note for this suppression, if any. */
    note?: string | null;
    /** Where the suppression applies: `account` for every sending domain of the account, or `sending_domain` for one envelope MAIL FROM domain. */
    scope?: EditSuppressionResponseScope | null;
}
export interface GetSubdomainRequest {
    /** Identifier. */
    zoneId: string;
    /** Sending subdomain identifier. */
    subdomainId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSubdomainResponse {
    /** Whether Email Sending is enabled on this subdomain. */
    enabled: boolean;
    /** The exact domain name or a leftmost wildcard such as `*.example.com`. */
    name: string;
    /** Sending subdomain identifier. */
    tag: string;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The DKIM selector used for email signing. Wildcard rows publish the selector and sign with `d=&lt;base&gt;`. */
    dkimSelector?: string | null;
    /** Whether a send request that includes a recipient suppressed on this subdomain drops that recipient and still delivers to the rest, instead of failing the entire request. */
    dropSuppressedRecipients?: boolean | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Whether sent messages from this subdomain can be previewed in the activity log. */
    previewEnabled?: boolean | null;
    /** The return-path domain used for bounce handling. Wildcard rows use `cf-bounce.&lt;base&gt;`. */
    returnPathDomain?: string | null;
}
export interface GetSubdomainDnsRequest {
    /** Identifier. */
    zoneId: string;
    /** Sending subdomain identifier. */
    subdomainId: string;
}
export type SubdomainsDnsGetResultItemType = "A" | "AAAA" | "CNAME" | "HTTPS" | "TXT" | "SRV" | "LOC" | "MX" | "NS" | "CERT" | "DNSKEY" | "DS" | "NAPTR" | "SMIMEA" | "SSHFP" | "SVCB" | "TLSA" | "URI";
export interface SubdomainsDnsGetResultItem {
    /** DNS record content. */
    content?: string | null;
    /** DNS record name (or @ for the zone apex). */
    name?: string | null;
    /** Required for MX, SRV and URI records. Unused by other record types. Records with lower priorities are preferred. */
    priority?: number | null;
    /** Time to live, in seconds, of the DNS record. Must be between 60 and 86400, or 1 for 'automatic'. */
    ttl?: number | null;
    /** DNS record type. */
    type?: SubdomainsDnsGetResultItemType | null;
}
export type SubdomainsDnsGetResultList = Array<SubdomainsDnsGetResultItem>;
export interface GetSubdomainDnsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubdomainsDnsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetSuppressionRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** The suppression's identifier. */
    suppressionId: string;
}
export type GetSuppressionResponseScopeTypeType = "account";
export interface GetSuppressionResponseScopeType {
    /** Blocks the recipient for every sending domain of the account. */
    type: GetSuppressionResponseScopeTypeType;
}
export type GetSuppressionResponseScopeCase1Type = "sending_domain";
export interface GetSuppressionResponseScopeCase1 {
    /** Blocks the recipient only for mail whose envelope MAIL FROM uses `value`. */
    type: GetSuppressionResponseScopeCase1Type;
    /** The sending domain: the domain part of the envelope MAIL FROM, lowercase, without a trailing dot. */
    value: string;
}
export type GetSuppressionResponseScope = GetSuppressionResponseScopeType | GetSuppressionResponseScopeCase1;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSuppressionResponse {
    /** Unique identifier for this suppression. */
    id: string;
    /** When the suppression was created. */
    createdAt: string;
    /** The suppressed email address. */
    email: string;
    /** When the suppression expires. Null for a permanent suppression. */
    expiresAt: string;
    /** Whether clients may mutate this suppression. This is determined by the server and must not be inferred from `reason`. */
    readOnly: boolean;
    /** Why the address is suppressed: `manual`, `complaint`, `hard_bounce`, `soft_bounce`, or `policy`. */
    reason: string;
    /** Advisory note for this suppression, if any. */
    note?: string | null;
    /** Where the suppression applies: `account` for every sending domain of the account, or `sending_domain` for one envelope MAIL FROM domain. */
    scope?: GetSuppressionResponseScope | null;
}
export type ImportSuppressionRequestItemsItemScopeTypeType = "account";
export interface ImportSuppressionRequestItemsItemScopeType {
    /** Blocks the recipient for every sending domain of the account. */
    type: ImportSuppressionRequestItemsItemScopeTypeType;
}
export type ImportSuppressionRequestItemsItemScopeCase1Type = "sending_domain";
export interface ImportSuppressionRequestItemsItemScopeCase1 {
    /** Blocks the recipient only for mail whose envelope MAIL FROM uses `value`. */
    type: ImportSuppressionRequestItemsItemScopeCase1Type;
    /** The sending domain to suppress for: the domain part of the envelope MAIL FROM. It is lowercased and trailing dots are removed. Internationalized domains must use the ASCII (punycode) form. Ownership is not checked; a domain the account does not send from never matches. */
    value: string;
}
export type ImportSuppressionRequestItemsItemScope = ImportSuppressionRequestItemsItemScopeType | ImportSuppressionRequestItemsItemScopeCase1;
export interface ImportSuppressionRequestItemsItem {
    /** The email address to suppress. */
    email: string;
    /** Expiration timestamp for the suppression. Omit or set to null for a permanent suppression that never expires. */
    expiresAt?: string;
    /** Advisory note for this suppression. Not enforced or validated beyond length. */
    note?: string;
    /** Where the suppression applies. Omit for `{ "type": "account" }`, which blocks the recipient for every sending domain of the account. */
    scope?: ImportSuppressionRequestItemsItemScope;
}
export type ImportSuppressionRequestItemsList = Array<ImportSuppressionRequestItemsItem>;
export interface ImportSuppressionRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** Suppressions to import. Items with the same email address and scope are deduplicated before processing. */
    items: ImportSuppressionRequestItemsList;
}
export type ImportSuppressionResponseItemsItemStatus = "processed" | "invalid" | "error" | "skipped";
export type ImportSuppressionResponseItemsItemScopeTypeType = "account";
export interface ImportSuppressionResponseItemsItemScopeType {
    /** Blocks the recipient for every sending domain of the account. */
    type: ImportSuppressionResponseItemsItemScopeTypeType;
}
export type ImportSuppressionResponseItemsItemScopeCase1Type = "sending_domain";
export interface ImportSuppressionResponseItemsItemScopeCase1 {
    /** Blocks the recipient only for mail whose envelope MAIL FROM uses `value`. */
    type: ImportSuppressionResponseItemsItemScopeCase1Type;
    /** The sending domain: the domain part of the envelope MAIL FROM, lowercase, without a trailing dot. */
    value: string;
}
export type ImportSuppressionResponseItemsItemScope = ImportSuppressionResponseItemsItemScopeType | ImportSuppressionResponseItemsItemScopeCase1;
export interface ImportSuppressionResponseItemsItem {
    /** Zero-based index of this item in the request body. */
    index: number;
    /** Outcome for this item. */
    status: ImportSuppressionResponseItemsItemStatus;
    /** The created or promoted suppression's identifier. Present when `status` is `processed`. */
    id?: string | null;
    /** The submitted email address for this item. */
    email?: string | null;
    /** Human-readable error message. Present when `status` is `invalid`, `error`, or `skipped`. */
    error?: string | null;
    /** Where the suppression applies: `account` for every sending domain of the account, or `sending_domain` for one envelope MAIL FROM domain. */
    scope?: ImportSuppressionResponseItemsItemScope | null;
}
export type ImportSuppressionResponseItemsList = Array<ImportSuppressionResponseItemsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ImportSuppressionResponse {
    /** Number of items dropped because their email address and scope repeated an earlier item in this request. Counted once and excluded from `items`. */
    deduplicated: number;
    /** Number of items that failed to import due to an unexpected error. */
    errors: number;
    /** Number of items with an invalid email address or sending domain. */
    invalid: number;
    /** Per-item results, in the same order as the request body. */
    items: ImportSuppressionResponseItemsList;
    /** Number of items successfully created or promoted. */
    processed: number;
    /** Number of items skipped because the existing suppression is not customer-managed (for example, a read-only policy suppression). */
    skipped: number;
    /** Total number of items in the request body, including duplicates. */
    total: number;
}
export interface ListSubdomainsRequest {
    /** Identifier. */
    zoneId: string;
}
export interface SubdomainsListResultItem {
    /** Whether Email Sending is enabled on this subdomain. */
    enabled: boolean;
    /** The exact domain name or a leftmost wildcard such as `*.example.com`. */
    name: string;
    /** Sending subdomain identifier. */
    tag: string;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The DKIM selector used for email signing. Wildcard rows publish the selector and sign with `d=&lt;base&gt;`. */
    dkimSelector?: string | null;
    /** Whether a send request that includes a recipient suppressed on this subdomain drops that recipient and still delivers to the rest, instead of failing the entire request. */
    dropSuppressedRecipients?: boolean | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Whether sent messages from this subdomain can be previewed in the activity log. */
    previewEnabled?: boolean | null;
    /** The return-path domain used for bounce handling. Wildcard rows use `cf-bounce.&lt;base&gt;`. */
    returnPathDomain?: string | null;
}
export type SubdomainsListResultList = Array<SubdomainsListResultItem>;
export interface ListSubdomainsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubdomainsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ListSuppressionsRequestReason = "manual" | "complaint" | "hard_bounce" | "soft_bounce" | "policy";
export type ListSuppressionsRequestScopeType = "account" | "sending_domain";
export interface ListSuppressionsRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** Opaque pagination cursor returned as `result_info.next_cursor`. It carries the filters that produced it. */
    cursor?: string;
    /** Exact email-address filter. */
    email?: string;
    /** Maximum number of suppressions to return per page. */
    perPage?: number;
    /** Filter to suppressions with this reason. */
    reason?: ListSuppressionsRequestReason | (string & {});
    /** Filter by scope: `account` returns only account-wide suppressions, `sending_domain` only sending-domain suppressions. Omit to list both, sending-domain suppressions first. */
    scopeType?: ListSuppressionsRequestScopeType | (string & {});
    /** Exact sending-domain filter. Requires `scope_type=sending_domain`. */
    scopeValue?: string;
    /** A complete address is an exact match; a value ending in `@` matches that username across every domain. Prefix searches may return short intermediate pages while the bounded account scan advances. */
    search?: string;
}
export type ListSuppressionsResultItemScopeTypeType = "account";
export interface ListSuppressionsResultItemScopeType {
    /** Blocks the recipient for every sending domain of the account. */
    type: ListSuppressionsResultItemScopeTypeType;
}
export type ListSuppressionsResultItemScopeCase1Type = "sending_domain";
export interface ListSuppressionsResultItemScopeCase1 {
    /** Blocks the recipient only for mail whose envelope MAIL FROM uses `value`. */
    type: ListSuppressionsResultItemScopeCase1Type;
    /** The sending domain: the domain part of the envelope MAIL FROM, lowercase, without a trailing dot. */
    value: string;
}
export type ListSuppressionsResultItemScope = ListSuppressionsResultItemScopeType | ListSuppressionsResultItemScopeCase1;
export interface ListSuppressionsResultItem {
    /** Unique identifier for this suppression. */
    id: string;
    /** When the suppression was created. */
    createdAt: string;
    /** The suppressed email address. */
    email: string;
    /** When the suppression expires. Null for a permanent suppression. */
    expiresAt: string;
    /** Whether clients may mutate this suppression. This is determined by the server and must not be inferred from `reason`. */
    readOnly: boolean;
    /** Why the address is suppressed: `manual`, `complaint`, `hard_bounce`, `soft_bounce`, or `policy`. */
    reason: string;
    /** Advisory note for this suppression, if any. */
    note?: string | null;
    /** Where the suppression applies: `account` for every sending domain of the account, or `sending_domain` for one envelope MAIL FROM domain. */
    scope?: ListSuppressionsResultItemScope | null;
}
export type ListSuppressionsResultList = Array<ListSuppressionsResultItem>;
export type ListSuppressionsResponse = ListSuppressionsResultList;
export interface SendEmailSendingRequest {
    /** Identifier of the account. */
    accountId: string;
}
export type SendResponseDeliveredList = Array<string>;
export type SendResponsePermanentBouncesList = Array<string>;
export type SendResponseQueuedList = Array<string>;
export type SendResponseSuppressedRecipientsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SendEmailSendingResponse {
    /** Email addresses to which the message was delivered immediately. */
    delivered: SendResponseDeliveredList;
    /** Message ID of the sent email. */
    messageId: string;
    /** Email addresses that permanently bounced. */
    permanentBounces: SendResponsePermanentBouncesList;
    /** Email addresses for which delivery was queued for later. */
    queued: SendResponseQueuedList;
    /** Email addresses dropped because they are on the suppression list. Returned when suppressed-recipient dropping is enabled for the sending subdomain; otherwise the request fails instead. */
    suppressedRecipients: SendResponseSuppressedRecipientsList;
}
export type SendRawRequestRecipientsList = Array<string>;
export interface SendRawEmailSendingRequest {
    /** Identifier of the account. */
    accountId: string;
    /** Sender email address. */
    from: string;
    /** The full MIME-encoded email message. Should include standard RFC 5322 headers such as From, To, Subject, and Content-Type. The from and recipients fields in the request body control SMTP envelope routing; the From and To headers in the MIME message control what the recipient's email client displays. */
    mimeMessage: string;
    /** List of recipient email addresses. */
    recipients: SendRawRequestRecipientsList;
}
export type SendRawResponseDeliveredList = Array<string>;
export type SendRawResponsePermanentBouncesList = Array<string>;
export type SendRawResponseQueuedList = Array<string>;
export type SendRawResponseSuppressedRecipientsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SendRawEmailSendingResponse {
    /** Email addresses to which the message was delivered immediately. */
    delivered: SendRawResponseDeliveredList;
    /** Message ID of the sent email. */
    messageId: string;
    /** Email addresses that permanently bounced. */
    permanentBounces: SendRawResponsePermanentBouncesList;
    /** Email addresses for which delivery was queued for later. */
    queued: SendRawResponseQueuedList;
    /** Email addresses dropped because they are on the suppression list. Returned when suppressed-recipient dropping is enabled for the sending subdomain; otherwise the request fails instead. */
    suppressedRecipients: SendRawResponseSuppressedRecipientsList;
}
export type CreateSubdomainError = Forbidden | SendingSubdomainAlreadyExists | CloudflareOpError;
/** Creates a new sending subdomain or re-enables sending on an existing subdomain that had it disabled. If zone-level Email Sending has not been enabled yet, the zone flag is automatically set when the entitlement is present. A leftmost wildcard such as `*.example.com` is accepted only for accounts with wildcard Email Sending enabled. Wildcard senders share the base domain's DKIM signing identity and `cf-bounce.<base>` return path. */
export declare const createSubdomain: API.OperationMethod<CreateSubdomainRequest, CreateSubdomainResponse, CreateSubdomainError, CloudflareOpContext>;
export type CreateSuppressionError = CloudflareOpError;
/** Creates a suppression for every sending domain of the account (default) or for one sending domain (`scope.type = sending_domain`). Creating an existing active suppression returns its identifier. If a mutable legacy zone-linked account row already exists, it is promoted without changing its identifier. */
export declare const createSuppression: API.OperationMethod<CreateSuppressionRequest, CreateSuppressionResponse, CreateSuppressionError, CloudflareOpContext>;
export type DeleteSubdomainError = Forbidden | SendingSubdomainNotFound | CloudflareOpError;
/** Disables sending on a subdomain and removes its DNS records. If routing is still active on the subdomain, only sending is disabled. */
export declare const deleteSubdomain: API.OperationMethod<DeleteSubdomainRequest, DeleteSubdomainResponse, DeleteSubdomainError, CloudflareOpContext>;
export type DeleteSuppressionError = CloudflareOpError;
/** Deletes the suppression, its note, and every legacy internal zone membership, allowing future delivery attempts to the address. */
export declare const deleteSuppression: API.OperationMethod<DeleteSuppressionRequest, DeleteSuppressionResponse, DeleteSuppressionError, CloudflareOpContext>;
export type EditSubdomainError = CloudflareOpError;
/** Updates the activity-log preview preference for a sending subdomain. */
export declare const editSubdomain: API.OperationMethod<EditSubdomainRequest, EditSubdomainResponse, EditSubdomainError, CloudflareOpContext>;
export type EditSuppressionError = CloudflareOpError;
/** Updates expiry or advisory note fields without changing legacy internal zone memberships. Scope cannot be changed. */
export declare const editSuppression: API.OperationMethod<EditSuppressionRequest, EditSuppressionResponse, EditSuppressionError, CloudflareOpContext>;
export type GetSubdomainError = Forbidden | SendingSubdomainNotFound | CloudflareOpError;
/** Gets information for a specific sending subdomain. */
export declare const getSubdomain: API.OperationMethod<GetSubdomainRequest, GetSubdomainResponse, GetSubdomainError, CloudflareOpContext>;
export type GetSubdomainDnsError = CloudflareOpError;
/** Returns the expected DNS records for a sending subdomain. */
export declare const getSubdomainDns: API.PaginatedOperationMethod<GetSubdomainDnsRequest, GetSubdomainDnsResponse, GetSubdomainDnsError, CloudflareOpContext, SubdomainsDnsGetResultItem>;
export type GetSuppressionError = CloudflareOpError;
/** Gets an Email Sending suppression owned by the account. */
export declare const getSuppression: API.OperationMethod<GetSuppressionRequest, GetSuppressionResponse, GetSuppressionError, CloudflareOpContext>;
export type ImportSuppressionError = CloudflareOpError;
/** Imports up to 1,000 Email Sending suppressions in one request. Each item applies to every sending domain of the account (default) or to one sending domain. */
export declare const importSuppression: API.OperationMethod<ImportSuppressionRequest, ImportSuppressionResponse, ImportSuppressionError, CloudflareOpContext>;
export type ListSubdomainsError = Forbidden | CloudflareOpError;
/** Lists all sending-enabled subdomains for the zone. */
export declare const listSubdomains: API.PaginatedOperationMethod<ListSubdomainsRequest, ListSubdomainsResponse, ListSubdomainsError, CloudflareOpContext, SubdomainsListResultItem>;
export type ListSuppressionsError = CloudflareOpError;
/** Lists every active Email Sending suppression owned by the account: sending-domain suppressions first, then account-wide suppressions (including legacy rows with internal zone memberships). Each group is newest first. */
export declare const listSuppressions: API.OperationMethod<ListSuppressionsRequest, ListSuppressionsResponse, ListSuppressionsError, CloudflareOpContext>;
export type SendEmailSendingError = CloudflareOpError;
/** Send an email for the specified account using the structured builder. Provide the sender, recipients, subject, and at least one of text or html; attachments are optional. */
export declare const sendEmailSending: API.OperationMethod<SendEmailSendingRequest, SendEmailSendingResponse, SendEmailSendingError, CloudflareOpContext>;
export type SendRawEmailSendingError = CloudflareOpError;
/** Send a raw RFC 5322 (MIME) email for the specified account. Provide the full MIME message plus the SMTP envelope (from and recipients). */
export declare const sendRawEmailSending: API.OperationMethod<SendRawEmailSendingRequest, SendRawEmailSendingResponse, SendRawEmailSendingError, CloudflareOpContext>;
//# sourceMappingURL=email_sending.d.ts.map