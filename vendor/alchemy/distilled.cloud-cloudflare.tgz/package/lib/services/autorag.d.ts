import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type FilesRequestStatus = "completed" | "queued" | "running" | "error";
export interface FilesRequest {
    accountId: string;
    /** rag id */
    id: string;
    page?: number;
    perPage?: number;
    search?: string;
    status?: FilesRequestStatus | (string & {});
}
export interface FilesResultItem {
    error: string;
    key: string;
}
export type FilesResultList = Array<FilesResultItem>;
export type FilesResponse = FilesResultList;
export interface GetJobRequest {
    accountId: string;
    /** rag id */
    id: string;
    jobId: string;
}
export type GetJobResponseSource = "user" | "schedule";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetJobResponse {
    id: string;
    source: GetJobResponseSource;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export interface JobsLogsRequest {
    accountId: string;
    /** rag id */
    id: string;
    jobId: string;
    page?: number;
    perPage?: number;
}
export interface JobsLogsResultItem {
    id: number;
    createdAt: number;
    message: string;
    messageType: number;
}
export type JobsLogsResultList = Array<JobsLogsResultItem>;
export type JobsLogsResponse = JobsLogsResultList;
export interface ListJobsRequest {
    accountId: string;
    /** rag id */
    id: string;
    page?: number;
    perPage?: number;
}
export type ListJobsResultItemSource = "user" | "schedule";
export interface ListJobsResultItem {
    id: string;
    source: ListJobsResultItemSource;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export type ListJobsResultList = Array<ListJobsResultItem>;
export type ListJobsResponse = ListJobsResultList;
export type SearchRequestFiltersCase0Type = "eq" | "ne" | "gt" | "gte" | "lt" | "lte";
export type SearchRequestFiltersCase0Value = string | number | boolean;
export interface SearchRequestFiltersCase0 {
    key: string;
    type: SearchRequestFiltersCase0Type | (string & {});
    value: SearchRequestFiltersCase0Value;
}
export type SearchRequestFiltersCase1FiltersItemType = "eq" | "ne" | "gt" | "gte" | "lt" | "lte";
export type SearchRequestFiltersCase1FiltersItemValue = string | number | boolean;
export interface SearchRequestFiltersCase1FiltersItem {
    key: string;
    type: SearchRequestFiltersCase1FiltersItemType | (string & {});
    value: SearchRequestFiltersCase1FiltersItemValue;
}
export type SearchRequestFiltersCase1FiltersList = Array<SearchRequestFiltersCase1FiltersItem>;
export type SearchRequestFiltersCase1Type = "and" | "or";
export interface SearchRequestFiltersCase1 {
    filters: SearchRequestFiltersCase1FiltersList;
    type: SearchRequestFiltersCase1Type | (string & {});
}
export type SearchRequestFilters = SearchRequestFiltersCase0 | SearchRequestFiltersCase1;
export interface SearchRequestRankingOptions {
    ranker?: string;
    scoreThreshold?: number;
}
export type SearchRequestRerankingModel = "@cf/baai/bge-reranker-base" | "";
export interface SearchRequestReranking {
    enabled?: boolean;
    model?: SearchRequestRerankingModel | (string & {});
}
export interface SearchRequest {
    accountId: string;
    /** rag id */
    id: string;
    query: string;
    filters?: SearchRequestFilters;
    maxNumResults?: number;
    rankingOptions?: SearchRequestRankingOptions;
    reranking?: SearchRequestReranking;
    rewriteQuery?: boolean;
}
export interface SearchResponseDataItemContentItem {
    text?: string | null;
    type?: string | null;
}
export type SearchResponseDataItemContentList = Array<SearchResponseDataItemContentItem>;
export interface SearchResponseDataItem {
    score: number;
    attributes?: unknown | null;
    content?: SearchResponseDataItemContentList | null;
    fileId?: string | null;
    filename?: string | null;
}
export type SearchResponseDataList = Array<SearchResponseDataItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchResponse {
    searchQuery: string;
    data?: SearchResponseDataList | null;
    hasMore?: boolean | null;
    nextPage?: string | null;
    object?: string | null;
}
export type SearchAiRequestFiltersCase0Type = "eq" | "ne" | "gt" | "gte" | "lt" | "lte";
export type SearchAiRequestFiltersCase0Value = string | number | boolean;
export interface SearchAiRequestFiltersCase0 {
    key: string;
    type: SearchAiRequestFiltersCase0Type | (string & {});
    value: SearchAiRequestFiltersCase0Value;
}
export type SearchAiRequestFiltersCase1FiltersItemType = "eq" | "ne" | "gt" | "gte" | "lt" | "lte";
export type SearchAiRequestFiltersCase1FiltersItemValue = string | number | boolean;
export interface SearchAiRequestFiltersCase1FiltersItem {
    key: string;
    type: SearchAiRequestFiltersCase1FiltersItemType | (string & {});
    value: SearchAiRequestFiltersCase1FiltersItemValue;
}
export type SearchAiRequestFiltersCase1FiltersList = Array<SearchAiRequestFiltersCase1FiltersItem>;
export type SearchAiRequestFiltersCase1Type = "and" | "or";
export interface SearchAiRequestFiltersCase1 {
    filters: SearchAiRequestFiltersCase1FiltersList;
    type: SearchAiRequestFiltersCase1Type | (string & {});
}
export type SearchAiRequestFilters = SearchAiRequestFiltersCase0 | SearchAiRequestFiltersCase1;
export type SearchAiRequestModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export type SearchAiRequestRankingOptions = SearchRequestRankingOptions;
export type SearchAiRequestRerankingModel = "@cf/baai/bge-reranker-base" | "";
export interface SearchAiRequestReranking {
    enabled?: boolean;
    model?: SearchAiRequestRerankingModel | (string & {});
}
export interface SearchAiRequest {
    accountId: string;
    /** rag id */
    id: string;
    query: string;
    filters?: SearchAiRequestFilters;
    maxNumResults?: number;
    model?: SearchAiRequestModel | (string & {});
    rankingOptions?: SearchRequestRankingOptions;
    reranking?: SearchAiRequestReranking;
    rewriteQuery?: boolean;
    stream?: boolean;
    systemPrompt?: string;
}
export type SearchAiResponseDataItemContentItem = SearchResponseDataItemContentItem;
export type SearchAiResponseDataItemContentList = Array<SearchResponseDataItemContentItem>;
export interface SearchAiResponseDataItem {
    score: number;
    attributes?: unknown | null;
    content?: SearchAiResponseDataItemContentList | null;
    fileId?: string | null;
    filename?: string | null;
}
export type SearchAiResponseDataList = Array<SearchAiResponseDataItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchAiResponse {
    response: string;
    searchQuery: string;
    data?: SearchAiResponseDataList | null;
    hasMore?: boolean | null;
    nextPage?: string | null;
    object?: string | null;
}
export interface SyncRequest {
    accountId: string;
    /** rag id */
    id: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SyncResponse {
    jobId: string;
}
export type FilesError = CloudflareOpError;
/** Lists files indexed by an AutoRAG. */
export declare const files: API.OperationMethod<FilesRequest, FilesResponse, FilesError, CloudflareOpContext>;
export type GetJobError = CloudflareOpError;
/** Returns details for an AutoRAG job. */
export declare const getJob: API.OperationMethod<GetJobRequest, GetJobResponse, GetJobError, CloudflareOpContext>;
export type JobsLogsError = CloudflareOpError;
/** Lists logs for an AutoRAG job. */
export declare const jobsLogs: API.OperationMethod<JobsLogsRequest, JobsLogsResponse, JobsLogsError, CloudflareOpContext>;
export type ListJobsError = CloudflareOpError;
/** Lists jobs for an AutoRAG. */
export declare const listJobs: API.OperationMethod<ListJobsRequest, ListJobsResponse, ListJobsError, CloudflareOpContext>;
export type SearchError = CloudflareOpError;
/** Searches an AutoRAG. */
export declare const search: API.OperationMethod<SearchRequest, SearchResponse, SearchError, CloudflareOpContext>;
export type SearchAiError = CloudflareOpError;
/** Runs an AI Search query against an AutoRAG. */
export declare const searchAi: API.OperationMethod<SearchAiRequest, SearchAiResponse, SearchAiError, CloudflareOpContext>;
export type SyncError = CloudflareOpError;
/** Starts synchronization for an AutoRAG. */
export declare const sync: API.OperationMethod<SyncRequest, SyncResponse, SyncError, CloudflareOpContext>;
//# sourceMappingURL=autorag.d.ts.map