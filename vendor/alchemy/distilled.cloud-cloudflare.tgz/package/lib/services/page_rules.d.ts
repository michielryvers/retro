import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidZoneIdentifier_base: S.TaggedErrorClass<"InvalidZoneIdentifier", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidZoneIdentifier extends /*@__PURE__*/ InvalidZoneIdentifier_base {
}
declare const PageRuleNotFound_base: S.TaggedErrorClass<"PageRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PageRuleNotFound extends /*@__PURE__*/ PageRuleNotFound_base {
}
export type CreateRequestActionsItemAlwaysUseHTTPSId = "always_use_https";
export interface CreateRequestActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to` https://` through a 301 redirect. */
    id?: CreateRequestActionsItemAlwaysUseHTTPSId | (string & {});
}
export type CreateRequestActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export type CreateRequestActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export interface CreateRequestActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: CreateRequestActionsItemAutomaticHTTPSRewritesId | (string & {});
    /** The status of Automatic HTTPS Rewrites. */
    value?: CreateRequestActionsItemAutomaticHTTPSRewritesValue | (string & {});
}
export type CreateRequestActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export interface CreateRequestActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: CreateRequestActionsItemBrowserCacheTTLId | (string & {});
    /** The number of seconds to cache resources for. Setting this to 0 enables "Respect Existing Headers". */
    value?: number;
}
export type CreateRequestActionsItemBrowserCheckId = "browser_check";
export type CreateRequestActionsItemBrowserCheckValue = "on" | "off";
export interface CreateRequestActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with spammers and certain bots. */
    id?: CreateRequestActionsItemBrowserCheckId | (string & {});
    /** The status of Browser Integrity Check. */
    value?: CreateRequestActionsItemBrowserCheckValue | (string & {});
}
export type CreateRequestActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export interface CreateRequestActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular expression matches against a cookie name present in the request. */
    id?: CreateRequestActionsItemBypassCacheOnCookieId | (string & {});
    /** The regular expression to use for matching cookie names in the request. Refer to [Bypass Cache on Cookie setting](https://developers.cloudflare.com/rules/page-rules/reference/additional-reference/#bypass-cache-on-cookie-setting) to learn about limited regular expression support. */
    value?: string;
}
export type CreateRequestActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export type CreateRequestActionsItemCacheByDeviceTypeValue = "on" | "off";
export interface CreateRequestActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: CreateRequestActionsItemCacheByDeviceTypeId | (string & {});
    /** The status of Cache By Device Type. */
    value?: CreateRequestActionsItemCacheByDeviceTypeValue | (string & {});
}
export type CreateRequestActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export type CreateRequestActionsItemCacheDeceptionArmorValue = "on" | "off";
export interface CreateRequestActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static assets to be cached. This setting verifies that the URL's extension matches the returned `Content-Type`. */
    id?: CreateRequestActionsItemCacheDeceptionArmorId | (string & {});
    /** The status of Cache Deception Armor. */
    value?: CreateRequestActionsItemCacheDeceptionArmorValue | (string & {});
}
export type CreateRequestActionsItemCacheKeyFieldsId = "cache_key_fields";
export type CreateRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export type CreateRequestActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export interface CreateRequestActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without including their actual values. */
    checkPresence?: CreateRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList;
    /** A list of cookies to include. */
    include?: CreateRequestActionsItemCacheKeyFieldsValueCookieIncludeList;
}
export type CreateRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export type CreateRequestActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export type CreateRequestActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export interface CreateRequestActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without including their actual values. */
    checkPresence?: CreateRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList;
    /** A list of headers to ignore. */
    exclude?: CreateRequestActionsItemCacheKeyFieldsValueHeaderExcludeList;
    /** A list of headers to include. */
    include?: CreateRequestActionsItemCacheKeyFieldsValueHeaderIncludeList;
}
export interface CreateRequestActionsItemCacheKeyFieldsValueHost {
    /** Whether to include the Host header in the HTTP request sent to the origin. */
    resolved?: boolean;
}
export type CreateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export type CreateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export type CreateRequestActionsItemCacheKeyFieldsValueQueryStringExclude = CreateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | (string & {}) | CreateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export type CreateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export type CreateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export type CreateRequestActionsItemCacheKeyFieldsValueQueryStringInclude = CreateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | (string & {}) | CreateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export interface CreateRequestActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: CreateRequestActionsItemCacheKeyFieldsValueQueryStringExclude;
    /** Include all query string parameters. */
    include?: CreateRequestActionsItemCacheKeyFieldsValueQueryStringInclude;
}
export interface CreateRequestActionsItemCacheKeyFieldsValueUser {
    /** Classifies a request as `mobile`, `desktop`, or `tablet` based on the User Agent. */
    deviceType?: boolean;
    /** Includes the client's country, derived from the IP address. */
    geo?: boolean;
    /** Includes the first language code contained in the `Accept-Language` header sent by the client. */
    lang?: boolean;
}
export interface CreateRequestActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: CreateRequestActionsItemCacheKeyFieldsValueCookie;
    /** Controls which headers go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    header?: CreateRequestActionsItemCacheKeyFieldsValueHeader;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateRequestActionsItemCacheKeyFieldsValueHost;
    /** Controls which URL query string parameters go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    queryString?: CreateRequestActionsItemCacheKeyFieldsValueQueryString;
    /** Feature fields to add features about the end-user (client) into the Cache Key. */
    user?: CreateRequestActionsItemCacheKeyFieldsValueUser;
}
export interface CreateRequestActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which resources to cache. This allows customers to determine what to cache based on something other than just the URL. */
    id?: CreateRequestActionsItemCacheKeyFieldsId | (string & {});
    value?: CreateRequestActionsItemCacheKeyFieldsValue;
}
export type CreateRequestActionsItemCacheLevelId = "cache_level";
export type CreateRequestActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export interface CreateRequestActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: CreateRequestActionsItemCacheLevelId | (string & {});
    /** - `bypass`: Cloudflare does not cache. - `basic`: Delivers resources from cache when there is no query string. - `simplified`: Delivers the same resource to everyone independent of the query string. - `aggressive`: Caches all static content that has a query string. - `cache_everything`: Treats all content as static and caches all file types beyond the [Cloudflare default cached content](https://developers.cloudflare.com/cache/concepts/default-cache-behavior/#default-cached-file-extensions). */
    value?: CreateRequestActionsItemCacheLevelValue | (string & {});
}
export type CreateRequestActionsItemCacheOnCookieId = "cache_on_cookie";
export interface CreateRequestActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a regular expression match against a cookie name. */
    id?: CreateRequestActionsItemCacheOnCookieId | (string & {});
    /** The regular expression to use for matching cookie names in the request. */
    value?: string;
}
export type CreateRequestActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export type CreateRequestActionsItemCacheTTLByStatusValueValueCase0 = "no-cache" | "no-store";
export type CreateRequestActionsItemCacheTTLByStatusValueValue = number | CreateRequestActionsItemCacheTTLByStatusValueValueCase0 | (string & {});
export type CreateRequestActionsItemCacheTTLByStatusValueMap = {
    [key: string]: CreateRequestActionsItemCacheTTLByStatusValueValue | undefined;
};
export interface CreateRequestActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the response status from the origin web server. Cache TTL refers to the duration of a resource in the Cloudflare network before being marked as stale or discarded from cache. Status codes are returned by a resource's origin. Setting cache TTL based on response status overrides the default cache behavior (standard caching) for static files and overrides cache instructions sent by the origin web server. To cache non-static assets, set a Cache Level of Cache Everything using a Page Rule. Setting no-store Cache-Control or a low TTL (using `max-age`/`s-maxage`) increases requests to origin web servers and decreases performance. */
    id?: CreateRequestActionsItemCacheTTLByStatusId | (string & {});
    /** A JSON object containing status codes and their corresponding TTLs. Each key-value pair in the cache TTL by status cache rule has the following syntax */
    value?: CreateRequestActionsItemCacheTTLByStatusValueMap;
}
export type CreateRequestActionsItemDisableAppsId = "disable_apps";
export interface CreateRequestActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) (deprecated). */
    id?: CreateRequestActionsItemDisableAppsId | (string & {});
}
export type CreateRequestActionsItemDisablePerformanceId = "disable_performance";
export interface CreateRequestActionsItemDisablePerformance {
    /** Turn off [Rocket Loader](https://developers.cloudflare.com/speed/optimization/content/rocket-loader/), and [Polish](https://developers.cloudflare.com/images/polish/). */
    id?: CreateRequestActionsItemDisablePerformanceId | (string & {});
}
export type CreateRequestActionsItemDisableSecurityId = "disable_security";
export interface CreateRequestActionsItemDisableSecurity {
    /** Turn off [Email Obfuscation](https://developers.cloudflare.com/waf/tools/scrape-shield/email-address-obfuscation/), [Rate Limiting (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-rate-limiting/), [Scrape Shield](https://developers.cloudflare.com/waf/tools/scrape-shield/), [URL (Zone) Lockdown](https://developers.cloudflare.com/waf/tools/zone-lockdown/), and [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: CreateRequestActionsItemDisableSecurityId | (string & {});
}
export type CreateRequestActionsItemDisableZarazId = "disable_zaraz";
export interface CreateRequestActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: CreateRequestActionsItemDisableZarazId | (string & {});
}
export type CreateRequestActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export interface CreateRequestActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global network. *Edge Cache TTL* is not visible in response headers. */
    id?: CreateRequestActionsItemEdgeCacheTTLId | (string & {});
    value?: number;
}
export type CreateRequestActionsItemEmailObfuscationId = "email_obfuscation";
export type CreateRequestActionsItemEmailObfuscationValue = "on" | "off";
export interface CreateRequestActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: CreateRequestActionsItemEmailObfuscationId | (string & {});
    /** The status of Email Obfuscation. */
    value?: CreateRequestActionsItemEmailObfuscationValue | (string & {});
}
export type CreateRequestActionsItemExplicitCacheControlId = "explicit_cache_control";
export type CreateRequestActionsItemExplicitCacheControlValue = "on" | "off";
export interface CreateRequestActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and Business domains and disabled by default for Enterprise domains. */
    id?: CreateRequestActionsItemExplicitCacheControlId | (string & {});
    /** The status of Origin Cache Control. */
    value?: CreateRequestActionsItemExplicitCacheControlValue | (string & {});
}
export type CreateRequestActionsItemForwardingURLId = "forwarding_url";
export type CreateRequestActionsItemForwardingURLValueStatusCode = 301 | 302;
export interface CreateRequestActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent redirect. 302 is a temporary redirect. */
    statusCode?: CreateRequestActionsItemForwardingURLValueStatusCode | (number & {});
    /** The URL to redirect the request to. Notes: ${num} refers to the position of '*' in the constraint value. */
    url?: string;
}
export interface CreateRequestActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer to [Wildcard matching and referencing](https://developers.cloudflare.com/rules/page-rules/reference/wildcard-matching/). */
    id?: CreateRequestActionsItemForwardingURLId | (string & {});
    value?: CreateRequestActionsItemForwardingURLValue;
}
export type CreateRequestActionsItemHostHeaderOverrideId = "host_header_override";
export interface CreateRequestActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: CreateRequestActionsItemHostHeaderOverrideId | (string & {});
    /** The hostname to use in the `Host` header */
    value?: string;
}
export type CreateRequestActionsItemIPGeolocationId = "ip_geolocation";
export type CreateRequestActionsItemIPGeolocationValue = "on" | "off";
export interface CreateRequestActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: CreateRequestActionsItemIPGeolocationId | (string & {});
    /** The status of adding the IP Geolocation Header. */
    value?: CreateRequestActionsItemIPGeolocationValue | (string & {});
}
export type CreateRequestActionsItemMirageId = "mirage";
export type CreateRequestActionsItemMirageValue = "on" | "off";
export interface CreateRequestActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. It can accelerate loading of image-heavy websites on very slow mobile connections and HTTP/1. */
    id?: CreateRequestActionsItemMirageId | (string & {});
    /** The status of Mirage. */
    value?: CreateRequestActionsItemMirageValue | (string & {});
}
export type CreateRequestActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export type CreateRequestActionsItemOpportunisticEncryptionValue = "on" | "off";
export interface CreateRequestActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. It's not a substitute for HTTPS, but provides additional security for otherwise vulnerable requests. */
    id?: CreateRequestActionsItemOpportunisticEncryptionId | (string & {});
    /** The status of Opportunistic Encryption. */
    value?: CreateRequestActionsItemOpportunisticEncryptionValue | (string & {});
}
export type CreateRequestActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export type CreateRequestActionsItemOriginErrorPagePassThruValue = "on" | "off";
export interface CreateRequestActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: CreateRequestActionsItemOriginErrorPagePassThruId | (string & {});
    /** The status of Origin Error Page Passthru. */
    value?: CreateRequestActionsItemOriginErrorPagePassThruValue | (string & {});
}
export type CreateRequestActionsItemPolishId = "polish";
export type CreateRequestActionsItemPolishValue = "off" | "lossless" | "lossy";
export interface CreateRequestActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: CreateRequestActionsItemPolishId | (string & {});
    /** The level of Polish you want applied to your origin. */
    value?: CreateRequestActionsItemPolishValue | (string & {});
}
export type CreateRequestActionsItemResolveOverrideId = "resolve_override";
export interface CreateRequestActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: CreateRequestActionsItemResolveOverrideId | (string & {});
    /** The origin address you want to override with. */
    value?: string;
}
export type CreateRequestActionsItemRespectStrongEtagId = "respect_strong_etag";
export type CreateRequestActionsItemRespectStrongEtagValue = "on" | "off";
export interface CreateRequestActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the Cloudflare cache and the origin server. */
    id?: CreateRequestActionsItemRespectStrongEtagId | (string & {});
    /** The status of Respect Strong ETags */
    value?: CreateRequestActionsItemRespectStrongEtagValue | (string & {});
}
export type CreateRequestActionsItemResponseBufferingId = "response_buffering";
export type CreateRequestActionsItemResponseBufferingValue = "on" | "off";
export interface CreateRequestActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file from the origin server before forwarding it to the site visitor. By default, Cloudflare sends packets to the client as they arrive from the origin server. */
    id?: CreateRequestActionsItemResponseBufferingId | (string & {});
    /** The status of Response Buffering */
    value?: CreateRequestActionsItemResponseBufferingValue | (string & {});
}
export type CreateRequestActionsItemRocketLoaderId = "rocket_loader";
export type CreateRequestActionsItemRocketLoaderValue = "on" | "off";
export interface CreateRequestActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: CreateRequestActionsItemRocketLoaderId | (string & {});
    /** The status of Rocket Loader */
    value?: CreateRequestActionsItemRocketLoaderValue | (string & {});
}
export type CreateRequestActionsItemSecurityLevelId = "security_level";
export type CreateRequestActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface CreateRequestActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: CreateRequestActionsItemSecurityLevelId | (string & {});
    value?: CreateRequestActionsItemSecurityLevelValue | (string & {});
}
export type CreateRequestActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export type CreateRequestActionsItemSortQueryStringForCacheValue = "on" | "off";
export interface CreateRequestActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: CreateRequestActionsItemSortQueryStringForCacheId | (string & {});
    /** The status of Query String Sort */
    value?: CreateRequestActionsItemSortQueryStringForCacheValue | (string & {});
}
export type CreateRequestActionsItemSSLId = "ssl";
export type CreateRequestActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export interface CreateRequestActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: CreateRequestActionsItemSSLId | (string & {});
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: CreateRequestActionsItemSSLValue | (string & {});
}
export type CreateRequestActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export type CreateRequestActionsItemTrueClientIPHeaderValue = "on" | "off";
export interface CreateRequestActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: CreateRequestActionsItemTrueClientIPHeaderId | (string & {});
    /** The status of True Client IP Header. */
    value?: CreateRequestActionsItemTrueClientIPHeaderValue | (string & {});
}
export type CreateRequestActionsItemWAFId = "waf";
export type CreateRequestActionsItemWAFValue = "on" | "off";
export interface CreateRequestActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). You cannot enable or disable individual WAF managed rules via Page Rules. */
    id?: CreateRequestActionsItemWAFId | (string & {});
    /** The status of WAF managed rules (previous version). */
    value?: CreateRequestActionsItemWAFValue | (string & {});
}
export type CreateRequestActionsItem = CreateRequestActionsItemAlwaysUseHTTPS | CreateRequestActionsItemAutomaticHTTPSRewrites | CreateRequestActionsItemBrowserCacheTTL | CreateRequestActionsItemBrowserCheck | CreateRequestActionsItemBypassCacheOnCookie | CreateRequestActionsItemCacheByDeviceType | CreateRequestActionsItemCacheDeceptionArmor | CreateRequestActionsItemCacheKeyFields | CreateRequestActionsItemCacheLevel | CreateRequestActionsItemCacheOnCookie | CreateRequestActionsItemCacheTTLByStatus | CreateRequestActionsItemDisableApps | CreateRequestActionsItemDisablePerformance | CreateRequestActionsItemDisableSecurity | CreateRequestActionsItemDisableZaraz | CreateRequestActionsItemEdgeCacheTTL | CreateRequestActionsItemEmailObfuscation | CreateRequestActionsItemExplicitCacheControl | CreateRequestActionsItemForwardingURL | CreateRequestActionsItemHostHeaderOverride | CreateRequestActionsItemIPGeolocation | CreateRequestActionsItemMirage | CreateRequestActionsItemOpportunisticEncryption | CreateRequestActionsItemOriginErrorPagePassThru | CreateRequestActionsItemPolish | CreateRequestActionsItemResolveOverride | CreateRequestActionsItemRespectStrongEtag | CreateRequestActionsItemResponseBuffering | CreateRequestActionsItemRocketLoader | CreateRequestActionsItemSecurityLevel | CreateRequestActionsItemSortQueryStringForCache | CreateRequestActionsItemSSL | CreateRequestActionsItemTrueClientIPHeader | CreateRequestActionsItemWAF;
export type CreateRequestActionsList = Array<CreateRequestActionsItem>;
export type CreateRequestTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export interface CreateRequestTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: CreateRequestTargetsItemConstraintOperator | (string & {});
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export type CreateRequestTargetsItemTarget = "url";
export interface CreateRequestTargetsItem {
    /** String constraint. */
    constraint?: CreateRequestTargetsItemConstraint;
    /** A target based on the URL of the request. */
    target?: CreateRequestTargetsItemTarget | (string & {});
}
export type CreateRequestTargetsList = Array<CreateRequestTargetsItem>;
export type CreateRequestStatus = "active" | "disabled";
export interface CreatePageRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** The set of actions to perform if the targets of this rule match the request. Actions can redirect to another URL or override settings, but not both. */
    actions: CreateRequestActionsList;
    /** The rule targets to evaluate on each request. */
    targets: CreateRequestTargetsList;
    /** The priority of the rule, used to define which Page Rule is processed over another. A higher number indicates a higher priority. For example, if you have a catch-all Page Rule (rule A: `/images/*`) but want a more specific Page Rule to take precedence (rule B: `/images/special/*`), specify a higher priority for rule B so it overrides rule A. */
    priority?: number;
    /** The status of the Page Rule. */
    status?: CreateRequestStatus | (string & {});
}
export type CreateResponseActionsItemAlwaysUseHTTPSId = "always_use_https";
export interface CreateResponseActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to` https://` through a 301 redirect. */
    id?: CreateResponseActionsItemAlwaysUseHTTPSId | null;
}
export type CreateResponseActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export type CreateResponseActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export interface CreateResponseActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: CreateResponseActionsItemAutomaticHTTPSRewritesId | null;
    /** The status of Automatic HTTPS Rewrites. */
    value?: CreateResponseActionsItemAutomaticHTTPSRewritesValue | null;
}
export type CreateResponseActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export interface CreateResponseActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: CreateResponseActionsItemBrowserCacheTTLId | null;
    /** The number of seconds to cache resources for. Setting this to 0 enables "Respect Existing Headers". */
    value?: number | null;
}
export type CreateResponseActionsItemBrowserCheckId = "browser_check";
export type CreateResponseActionsItemBrowserCheckValue = "on" | "off";
export interface CreateResponseActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with spammers and certain bots. */
    id?: CreateResponseActionsItemBrowserCheckId | null;
    /** The status of Browser Integrity Check. */
    value?: CreateResponseActionsItemBrowserCheckValue | null;
}
export type CreateResponseActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export interface CreateResponseActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular expression matches against a cookie name present in the request. */
    id?: CreateResponseActionsItemBypassCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the request. Refer to [Bypass Cache on Cookie setting](https://developers.cloudflare.com/rules/page-rules/reference/additional-reference/#bypass-cache-on-cookie-setting) to learn about limited regular expression support. */
    value?: string | null;
}
export type CreateResponseActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export type CreateResponseActionsItemCacheByDeviceTypeValue = "on" | "off";
export interface CreateResponseActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: CreateResponseActionsItemCacheByDeviceTypeId | null;
    /** The status of Cache By Device Type. */
    value?: CreateResponseActionsItemCacheByDeviceTypeValue | null;
}
export type CreateResponseActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export type CreateResponseActionsItemCacheDeceptionArmorValue = "on" | "off";
export interface CreateResponseActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static assets to be cached. This setting verifies that the URL's extension matches the returned `Content-Type`. */
    id?: CreateResponseActionsItemCacheDeceptionArmorId | null;
    /** The status of Cache Deception Armor. */
    value?: CreateResponseActionsItemCacheDeceptionArmorValue | null;
}
export type CreateResponseActionsItemCacheKeyFieldsId = "cache_key_fields";
export type CreateResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export type CreateResponseActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export interface CreateResponseActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without including their actual values. */
    checkPresence?: CreateResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList | null;
    /** A list of cookies to include. */
    include?: CreateResponseActionsItemCacheKeyFieldsValueCookieIncludeList | null;
}
export type CreateResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export type CreateResponseActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export type CreateResponseActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export interface CreateResponseActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without including their actual values. */
    checkPresence?: CreateResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList | null;
    /** A list of headers to ignore. */
    exclude?: CreateResponseActionsItemCacheKeyFieldsValueHeaderExcludeList | null;
    /** A list of headers to include. */
    include?: CreateResponseActionsItemCacheKeyFieldsValueHeaderIncludeList | null;
}
export interface CreateResponseActionsItemCacheKeyFieldsValueHost {
    /** Whether to include the Host header in the HTTP request sent to the origin. */
    resolved?: boolean | null;
}
export type CreateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export type CreateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export type CreateResponseActionsItemCacheKeyFieldsValueQueryStringExclude = CreateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | CreateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export type CreateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export type CreateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export type CreateResponseActionsItemCacheKeyFieldsValueQueryStringInclude = CreateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | CreateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export interface CreateResponseActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: CreateResponseActionsItemCacheKeyFieldsValueQueryStringExclude | null;
    /** Include all query string parameters. */
    include?: CreateResponseActionsItemCacheKeyFieldsValueQueryStringInclude | null;
}
export interface CreateResponseActionsItemCacheKeyFieldsValueUser {
    /** Classifies a request as `mobile`, `desktop`, or `tablet` based on the User Agent. */
    deviceType?: boolean | null;
    /** Includes the client's country, derived from the IP address. */
    geo?: boolean | null;
    /** Includes the first language code contained in the `Accept-Language` header sent by the client. */
    lang?: boolean | null;
}
export interface CreateResponseActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: CreateResponseActionsItemCacheKeyFieldsValueCookie | null;
    /** Controls which headers go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    header?: CreateResponseActionsItemCacheKeyFieldsValueHeader | null;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateResponseActionsItemCacheKeyFieldsValueHost | null;
    /** Controls which URL query string parameters go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    queryString?: CreateResponseActionsItemCacheKeyFieldsValueQueryString | null;
    /** Feature fields to add features about the end-user (client) into the Cache Key. */
    user?: CreateResponseActionsItemCacheKeyFieldsValueUser | null;
}
export interface CreateResponseActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which resources to cache. This allows customers to determine what to cache based on something other than just the URL. */
    id?: CreateResponseActionsItemCacheKeyFieldsId | null;
    value?: CreateResponseActionsItemCacheKeyFieldsValue | null;
}
export type CreateResponseActionsItemCacheLevelId = "cache_level";
export type CreateResponseActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export interface CreateResponseActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: CreateResponseActionsItemCacheLevelId | null;
    /** - `bypass`: Cloudflare does not cache. - `basic`: Delivers resources from cache when there is no query string. - `simplified`: Delivers the same resource to everyone independent of the query string. - `aggressive`: Caches all static content that has a query string. - `cache_everything`: Treats all content as static and caches all file types beyond the [Cloudflare default cached content](https://developers.cloudflare.com/cache/concepts/default-cache-behavior/#default-cached-file-extensions). */
    value?: CreateResponseActionsItemCacheLevelValue | null;
}
export type CreateResponseActionsItemCacheOnCookieId = "cache_on_cookie";
export interface CreateResponseActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a regular expression match against a cookie name. */
    id?: CreateResponseActionsItemCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the request. */
    value?: string | null;
}
export type CreateResponseActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export type CreateResponseActionsItemCacheTTLByStatusValueValueCase0 = "no-cache" | "no-store";
export type CreateResponseActionsItemCacheTTLByStatusValueValue = number | CreateResponseActionsItemCacheTTLByStatusValueValueCase0;
export type CreateResponseActionsItemCacheTTLByStatusValueMap = {
    [key: string]: CreateResponseActionsItemCacheTTLByStatusValueValue | undefined;
};
export interface CreateResponseActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the response status from the origin web server. Cache TTL refers to the duration of a resource in the Cloudflare network before being marked as stale or discarded from cache. Status codes are returned by a resource's origin. Setting cache TTL based on response status overrides the default cache behavior (standard caching) for static files and overrides cache instructions sent by the origin web server. To cache non-static assets, set a Cache Level of Cache Everything using a Page Rule. Setting no-store Cache-Control or a low TTL (using `max-age`/`s-maxage`) increases requests to origin web servers and decreases performance. */
    id?: CreateResponseActionsItemCacheTTLByStatusId | null;
    /** A JSON object containing status codes and their corresponding TTLs. Each key-value pair in the cache TTL by status cache rule has the following syntax */
    value?: CreateResponseActionsItemCacheTTLByStatusValueMap | null;
}
export type CreateResponseActionsItemDisableAppsId = "disable_apps";
export interface CreateResponseActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) (deprecated). */
    id?: CreateResponseActionsItemDisableAppsId | null;
}
export type CreateResponseActionsItemDisablePerformanceId = "disable_performance";
export interface CreateResponseActionsItemDisablePerformance {
    /** Turn off [Rocket Loader](https://developers.cloudflare.com/speed/optimization/content/rocket-loader/), and [Polish](https://developers.cloudflare.com/images/polish/). */
    id?: CreateResponseActionsItemDisablePerformanceId | null;
}
export type CreateResponseActionsItemDisableSecurityId = "disable_security";
export interface CreateResponseActionsItemDisableSecurity {
    /** Turn off [Email Obfuscation](https://developers.cloudflare.com/waf/tools/scrape-shield/email-address-obfuscation/), [Rate Limiting (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-rate-limiting/), [Scrape Shield](https://developers.cloudflare.com/waf/tools/scrape-shield/), [URL (Zone) Lockdown](https://developers.cloudflare.com/waf/tools/zone-lockdown/), and [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: CreateResponseActionsItemDisableSecurityId | null;
}
export type CreateResponseActionsItemDisableZarazId = "disable_zaraz";
export interface CreateResponseActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: CreateResponseActionsItemDisableZarazId | null;
}
export type CreateResponseActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export interface CreateResponseActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global network. *Edge Cache TTL* is not visible in response headers. */
    id?: CreateResponseActionsItemEdgeCacheTTLId | null;
    value?: number | null;
}
export type CreateResponseActionsItemEmailObfuscationId = "email_obfuscation";
export type CreateResponseActionsItemEmailObfuscationValue = "on" | "off";
export interface CreateResponseActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: CreateResponseActionsItemEmailObfuscationId | null;
    /** The status of Email Obfuscation. */
    value?: CreateResponseActionsItemEmailObfuscationValue | null;
}
export type CreateResponseActionsItemExplicitCacheControlId = "explicit_cache_control";
export type CreateResponseActionsItemExplicitCacheControlValue = "on" | "off";
export interface CreateResponseActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and Business domains and disabled by default for Enterprise domains. */
    id?: CreateResponseActionsItemExplicitCacheControlId | null;
    /** The status of Origin Cache Control. */
    value?: CreateResponseActionsItemExplicitCacheControlValue | null;
}
export type CreateResponseActionsItemForwardingURLId = "forwarding_url";
export type CreateResponseActionsItemForwardingURLValueStatusCode = 301 | 302;
export interface CreateResponseActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent redirect. 302 is a temporary redirect. */
    statusCode?: CreateResponseActionsItemForwardingURLValueStatusCode | null;
    /** The URL to redirect the request to. Notes: ${num} refers to the position of '*' in the constraint value. */
    url?: string | null;
}
export interface CreateResponseActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer to [Wildcard matching and referencing](https://developers.cloudflare.com/rules/page-rules/reference/wildcard-matching/). */
    id?: CreateResponseActionsItemForwardingURLId | null;
    value?: CreateResponseActionsItemForwardingURLValue | null;
}
export type CreateResponseActionsItemHostHeaderOverrideId = "host_header_override";
export interface CreateResponseActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: CreateResponseActionsItemHostHeaderOverrideId | null;
    /** The hostname to use in the `Host` header */
    value?: string | null;
}
export type CreateResponseActionsItemIPGeolocationId = "ip_geolocation";
export type CreateResponseActionsItemIPGeolocationValue = "on" | "off";
export interface CreateResponseActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: CreateResponseActionsItemIPGeolocationId | null;
    /** The status of adding the IP Geolocation Header. */
    value?: CreateResponseActionsItemIPGeolocationValue | null;
}
export type CreateResponseActionsItemMirageId = "mirage";
export type CreateResponseActionsItemMirageValue = "on" | "off";
export interface CreateResponseActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. It can accelerate loading of image-heavy websites on very slow mobile connections and HTTP/1. */
    id?: CreateResponseActionsItemMirageId | null;
    /** The status of Mirage. */
    value?: CreateResponseActionsItemMirageValue | null;
}
export type CreateResponseActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export type CreateResponseActionsItemOpportunisticEncryptionValue = "on" | "off";
export interface CreateResponseActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. It's not a substitute for HTTPS, but provides additional security for otherwise vulnerable requests. */
    id?: CreateResponseActionsItemOpportunisticEncryptionId | null;
    /** The status of Opportunistic Encryption. */
    value?: CreateResponseActionsItemOpportunisticEncryptionValue | null;
}
export type CreateResponseActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export type CreateResponseActionsItemOriginErrorPagePassThruValue = "on" | "off";
export interface CreateResponseActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: CreateResponseActionsItemOriginErrorPagePassThruId | null;
    /** The status of Origin Error Page Passthru. */
    value?: CreateResponseActionsItemOriginErrorPagePassThruValue | null;
}
export type CreateResponseActionsItemPolishId = "polish";
export type CreateResponseActionsItemPolishValue = "off" | "lossless" | "lossy";
export interface CreateResponseActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: CreateResponseActionsItemPolishId | null;
    /** The level of Polish you want applied to your origin. */
    value?: CreateResponseActionsItemPolishValue | null;
}
export type CreateResponseActionsItemResolveOverrideId = "resolve_override";
export interface CreateResponseActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: CreateResponseActionsItemResolveOverrideId | null;
    /** The origin address you want to override with. */
    value?: string | null;
}
export type CreateResponseActionsItemRespectStrongEtagId = "respect_strong_etag";
export type CreateResponseActionsItemRespectStrongEtagValue = "on" | "off";
export interface CreateResponseActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the Cloudflare cache and the origin server. */
    id?: CreateResponseActionsItemRespectStrongEtagId | null;
    /** The status of Respect Strong ETags */
    value?: CreateResponseActionsItemRespectStrongEtagValue | null;
}
export type CreateResponseActionsItemResponseBufferingId = "response_buffering";
export type CreateResponseActionsItemResponseBufferingValue = "on" | "off";
export interface CreateResponseActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file from the origin server before forwarding it to the site visitor. By default, Cloudflare sends packets to the client as they arrive from the origin server. */
    id?: CreateResponseActionsItemResponseBufferingId | null;
    /** The status of Response Buffering */
    value?: CreateResponseActionsItemResponseBufferingValue | null;
}
export type CreateResponseActionsItemRocketLoaderId = "rocket_loader";
export type CreateResponseActionsItemRocketLoaderValue = "on" | "off";
export interface CreateResponseActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: CreateResponseActionsItemRocketLoaderId | null;
    /** The status of Rocket Loader */
    value?: CreateResponseActionsItemRocketLoaderValue | null;
}
export type CreateResponseActionsItemSecurityLevelId = "security_level";
export type CreateResponseActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface CreateResponseActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: CreateResponseActionsItemSecurityLevelId | null;
    value?: CreateResponseActionsItemSecurityLevelValue | null;
}
export type CreateResponseActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export type CreateResponseActionsItemSortQueryStringForCacheValue = "on" | "off";
export interface CreateResponseActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: CreateResponseActionsItemSortQueryStringForCacheId | null;
    /** The status of Query String Sort */
    value?: CreateResponseActionsItemSortQueryStringForCacheValue | null;
}
export type CreateResponseActionsItemSSLId = "ssl";
export type CreateResponseActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export interface CreateResponseActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: CreateResponseActionsItemSSLId | null;
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: CreateResponseActionsItemSSLValue | null;
}
export type CreateResponseActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export type CreateResponseActionsItemTrueClientIPHeaderValue = "on" | "off";
export interface CreateResponseActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: CreateResponseActionsItemTrueClientIPHeaderId | null;
    /** The status of True Client IP Header. */
    value?: CreateResponseActionsItemTrueClientIPHeaderValue | null;
}
export type CreateResponseActionsItemWAFId = "waf";
export type CreateResponseActionsItemWAFValue = "on" | "off";
export interface CreateResponseActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). You cannot enable or disable individual WAF managed rules via Page Rules. */
    id?: CreateResponseActionsItemWAFId | null;
    /** The status of WAF managed rules (previous version). */
    value?: CreateResponseActionsItemWAFValue | null;
}
export type CreateResponseActionsItem = CreateResponseActionsItemAlwaysUseHTTPS | CreateResponseActionsItemAutomaticHTTPSRewrites | CreateResponseActionsItemBrowserCacheTTL | CreateResponseActionsItemBrowserCheck | CreateResponseActionsItemBypassCacheOnCookie | CreateResponseActionsItemCacheByDeviceType | CreateResponseActionsItemCacheDeceptionArmor | CreateResponseActionsItemCacheKeyFields | CreateResponseActionsItemCacheLevel | CreateResponseActionsItemCacheOnCookie | CreateResponseActionsItemCacheTTLByStatus | CreateResponseActionsItemDisableApps | CreateResponseActionsItemDisablePerformance | CreateResponseActionsItemDisableSecurity | CreateResponseActionsItemDisableZaraz | CreateResponseActionsItemEdgeCacheTTL | CreateResponseActionsItemEmailObfuscation | CreateResponseActionsItemExplicitCacheControl | CreateResponseActionsItemForwardingURL | CreateResponseActionsItemHostHeaderOverride | CreateResponseActionsItemIPGeolocation | CreateResponseActionsItemMirage | CreateResponseActionsItemOpportunisticEncryption | CreateResponseActionsItemOriginErrorPagePassThru | CreateResponseActionsItemPolish | CreateResponseActionsItemResolveOverride | CreateResponseActionsItemRespectStrongEtag | CreateResponseActionsItemResponseBuffering | CreateResponseActionsItemRocketLoader | CreateResponseActionsItemSecurityLevel | CreateResponseActionsItemSortQueryStringForCache | CreateResponseActionsItemSSL | CreateResponseActionsItemTrueClientIPHeader | CreateResponseActionsItemWAF;
export type CreateResponseActionsList = Array<CreateResponseActionsItem>;
export type CreateResponseStatus = "active" | "disabled";
export type CreateResponseTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export interface CreateResponseTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: CreateResponseTargetsItemConstraintOperator;
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export type CreateResponseTargetsItemTarget = "url";
export interface CreateResponseTargetsItem {
    /** String constraint. */
    constraint?: CreateResponseTargetsItemConstraint | null;
    /** A target based on the URL of the request. */
    target?: CreateResponseTargetsItemTarget | null;
}
export type CreateResponseTargetsList = Array<CreateResponseTargetsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePageRuleResponse {
    /** Identifier. */
    id: string;
    /** The set of actions to perform if the targets of this rule match the request. Actions can redirect to another URL or override settings, but not both. */
    actions: CreateResponseActionsList;
    /** The timestamp of when the Page Rule was created. */
    createdOn: string;
    /** The timestamp of when the Page Rule was last modified. */
    modifiedOn: string;
    /** The priority of the rule, used to define which Page Rule is processed over another. A higher number indicates a higher priority. For example, if you have a catch-all Page Rule (rule A: `/images/*`) but want a more specific Page Rule to take precedence (rule B: `/images/special/*`), specify a higher priority for rule B so it overrides rule A. */
    priority: number;
    /** The status of the Page Rule. */
    status: CreateResponseStatus;
    /** The rule targets to evaluate on each request. */
    targets: CreateResponseTargetsList;
}
export interface DeletePageRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    pageruleId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeletePageRuleResponse {
    /** Identifier. */
    id: string;
}
export interface GetPageRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    pageruleId: string;
}
export type GetResponseActionsItemAlwaysUseHTTPSId = "always_use_https";
export interface GetResponseActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to` https://` through a 301 redirect. */
    id?: GetResponseActionsItemAlwaysUseHTTPSId | null;
}
export type GetResponseActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export type GetResponseActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export interface GetResponseActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: GetResponseActionsItemAutomaticHTTPSRewritesId | null;
    /** The status of Automatic HTTPS Rewrites. */
    value?: GetResponseActionsItemAutomaticHTTPSRewritesValue | null;
}
export type GetResponseActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export interface GetResponseActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: GetResponseActionsItemBrowserCacheTTLId | null;
    /** The number of seconds to cache resources for. Setting this to 0 enables "Respect Existing Headers". */
    value?: number | null;
}
export type GetResponseActionsItemBrowserCheckId = "browser_check";
export type GetResponseActionsItemBrowserCheckValue = "on" | "off";
export interface GetResponseActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with spammers and certain bots. */
    id?: GetResponseActionsItemBrowserCheckId | null;
    /** The status of Browser Integrity Check. */
    value?: GetResponseActionsItemBrowserCheckValue | null;
}
export type GetResponseActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export interface GetResponseActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular expression matches against a cookie name present in the request. */
    id?: GetResponseActionsItemBypassCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the request. Refer to [Bypass Cache on Cookie setting](https://developers.cloudflare.com/rules/page-rules/reference/additional-reference/#bypass-cache-on-cookie-setting) to learn about limited regular expression support. */
    value?: string | null;
}
export type GetResponseActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export type GetResponseActionsItemCacheByDeviceTypeValue = "on" | "off";
export interface GetResponseActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: GetResponseActionsItemCacheByDeviceTypeId | null;
    /** The status of Cache By Device Type. */
    value?: GetResponseActionsItemCacheByDeviceTypeValue | null;
}
export type GetResponseActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export type GetResponseActionsItemCacheDeceptionArmorValue = "on" | "off";
export interface GetResponseActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static assets to be cached. This setting verifies that the URL's extension matches the returned `Content-Type`. */
    id?: GetResponseActionsItemCacheDeceptionArmorId | null;
    /** The status of Cache Deception Armor. */
    value?: GetResponseActionsItemCacheDeceptionArmorValue | null;
}
export type GetResponseActionsItemCacheKeyFieldsId = "cache_key_fields";
export type GetResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export type GetResponseActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export interface GetResponseActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without including their actual values. */
    checkPresence?: GetResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList | null;
    /** A list of cookies to include. */
    include?: GetResponseActionsItemCacheKeyFieldsValueCookieIncludeList | null;
}
export type GetResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export type GetResponseActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export type GetResponseActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export interface GetResponseActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without including their actual values. */
    checkPresence?: GetResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList | null;
    /** A list of headers to ignore. */
    exclude?: GetResponseActionsItemCacheKeyFieldsValueHeaderExcludeList | null;
    /** A list of headers to include. */
    include?: GetResponseActionsItemCacheKeyFieldsValueHeaderIncludeList | null;
}
export type GetResponseActionsItemCacheKeyFieldsValueHost = CreateResponseActionsItemCacheKeyFieldsValueHost;
export type GetResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export type GetResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export type GetResponseActionsItemCacheKeyFieldsValueQueryStringExclude = GetResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | GetResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export type GetResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export type GetResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export type GetResponseActionsItemCacheKeyFieldsValueQueryStringInclude = GetResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | GetResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export interface GetResponseActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: GetResponseActionsItemCacheKeyFieldsValueQueryStringExclude | null;
    /** Include all query string parameters. */
    include?: GetResponseActionsItemCacheKeyFieldsValueQueryStringInclude | null;
}
export type GetResponseActionsItemCacheKeyFieldsValueUser = CreateResponseActionsItemCacheKeyFieldsValueUser;
export interface GetResponseActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: GetResponseActionsItemCacheKeyFieldsValueCookie | null;
    /** Controls which headers go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    header?: GetResponseActionsItemCacheKeyFieldsValueHeader | null;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateResponseActionsItemCacheKeyFieldsValueHost | null;
    /** Controls which URL query string parameters go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    queryString?: GetResponseActionsItemCacheKeyFieldsValueQueryString | null;
    /** Feature fields to add features about the end-user (client) into the Cache Key. */
    user?: CreateResponseActionsItemCacheKeyFieldsValueUser | null;
}
export interface GetResponseActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which resources to cache. This allows customers to determine what to cache based on something other than just the URL. */
    id?: GetResponseActionsItemCacheKeyFieldsId | null;
    value?: GetResponseActionsItemCacheKeyFieldsValue | null;
}
export type GetResponseActionsItemCacheLevelId = "cache_level";
export type GetResponseActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export interface GetResponseActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: GetResponseActionsItemCacheLevelId | null;
    /** - `bypass`: Cloudflare does not cache. - `basic`: Delivers resources from cache when there is no query string. - `simplified`: Delivers the same resource to everyone independent of the query string. - `aggressive`: Caches all static content that has a query string. - `cache_everything`: Treats all content as static and caches all file types beyond the [Cloudflare default cached content](https://developers.cloudflare.com/cache/concepts/default-cache-behavior/#default-cached-file-extensions). */
    value?: GetResponseActionsItemCacheLevelValue | null;
}
export type GetResponseActionsItemCacheOnCookieId = "cache_on_cookie";
export interface GetResponseActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a regular expression match against a cookie name. */
    id?: GetResponseActionsItemCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the request. */
    value?: string | null;
}
export type GetResponseActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export type GetResponseActionsItemCacheTTLByStatusValueValueCase0 = "no-cache" | "no-store";
export type GetResponseActionsItemCacheTTLByStatusValueValue = number | GetResponseActionsItemCacheTTLByStatusValueValueCase0;
export type GetResponseActionsItemCacheTTLByStatusValueMap = {
    [key: string]: GetResponseActionsItemCacheTTLByStatusValueValue | undefined;
};
export interface GetResponseActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the response status from the origin web server. Cache TTL refers to the duration of a resource in the Cloudflare network before being marked as stale or discarded from cache. Status codes are returned by a resource's origin. Setting cache TTL based on response status overrides the default cache behavior (standard caching) for static files and overrides cache instructions sent by the origin web server. To cache non-static assets, set a Cache Level of Cache Everything using a Page Rule. Setting no-store Cache-Control or a low TTL (using `max-age`/`s-maxage`) increases requests to origin web servers and decreases performance. */
    id?: GetResponseActionsItemCacheTTLByStatusId | null;
    /** A JSON object containing status codes and their corresponding TTLs. Each key-value pair in the cache TTL by status cache rule has the following syntax */
    value?: GetResponseActionsItemCacheTTLByStatusValueMap | null;
}
export type GetResponseActionsItemDisableAppsId = "disable_apps";
export interface GetResponseActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) (deprecated). */
    id?: GetResponseActionsItemDisableAppsId | null;
}
export type GetResponseActionsItemDisablePerformanceId = "disable_performance";
export interface GetResponseActionsItemDisablePerformance {
    /** Turn off [Rocket Loader](https://developers.cloudflare.com/speed/optimization/content/rocket-loader/), and [Polish](https://developers.cloudflare.com/images/polish/). */
    id?: GetResponseActionsItemDisablePerformanceId | null;
}
export type GetResponseActionsItemDisableSecurityId = "disable_security";
export interface GetResponseActionsItemDisableSecurity {
    /** Turn off [Email Obfuscation](https://developers.cloudflare.com/waf/tools/scrape-shield/email-address-obfuscation/), [Rate Limiting (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-rate-limiting/), [Scrape Shield](https://developers.cloudflare.com/waf/tools/scrape-shield/), [URL (Zone) Lockdown](https://developers.cloudflare.com/waf/tools/zone-lockdown/), and [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: GetResponseActionsItemDisableSecurityId | null;
}
export type GetResponseActionsItemDisableZarazId = "disable_zaraz";
export interface GetResponseActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: GetResponseActionsItemDisableZarazId | null;
}
export type GetResponseActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export interface GetResponseActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global network. *Edge Cache TTL* is not visible in response headers. */
    id?: GetResponseActionsItemEdgeCacheTTLId | null;
    value?: number | null;
}
export type GetResponseActionsItemEmailObfuscationId = "email_obfuscation";
export type GetResponseActionsItemEmailObfuscationValue = "on" | "off";
export interface GetResponseActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: GetResponseActionsItemEmailObfuscationId | null;
    /** The status of Email Obfuscation. */
    value?: GetResponseActionsItemEmailObfuscationValue | null;
}
export type GetResponseActionsItemExplicitCacheControlId = "explicit_cache_control";
export type GetResponseActionsItemExplicitCacheControlValue = "on" | "off";
export interface GetResponseActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and Business domains and disabled by default for Enterprise domains. */
    id?: GetResponseActionsItemExplicitCacheControlId | null;
    /** The status of Origin Cache Control. */
    value?: GetResponseActionsItemExplicitCacheControlValue | null;
}
export type GetResponseActionsItemForwardingURLId = "forwarding_url";
export type GetResponseActionsItemForwardingURLValueStatusCode = 301 | 302;
export interface GetResponseActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent redirect. 302 is a temporary redirect. */
    statusCode?: GetResponseActionsItemForwardingURLValueStatusCode | null;
    /** The URL to redirect the request to. Notes: ${num} refers to the position of '*' in the constraint value. */
    url?: string | null;
}
export interface GetResponseActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer to [Wildcard matching and referencing](https://developers.cloudflare.com/rules/page-rules/reference/wildcard-matching/). */
    id?: GetResponseActionsItemForwardingURLId | null;
    value?: GetResponseActionsItemForwardingURLValue | null;
}
export type GetResponseActionsItemHostHeaderOverrideId = "host_header_override";
export interface GetResponseActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: GetResponseActionsItemHostHeaderOverrideId | null;
    /** The hostname to use in the `Host` header */
    value?: string | null;
}
export type GetResponseActionsItemIPGeolocationId = "ip_geolocation";
export type GetResponseActionsItemIPGeolocationValue = "on" | "off";
export interface GetResponseActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: GetResponseActionsItemIPGeolocationId | null;
    /** The status of adding the IP Geolocation Header. */
    value?: GetResponseActionsItemIPGeolocationValue | null;
}
export type GetResponseActionsItemMirageId = "mirage";
export type GetResponseActionsItemMirageValue = "on" | "off";
export interface GetResponseActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. It can accelerate loading of image-heavy websites on very slow mobile connections and HTTP/1. */
    id?: GetResponseActionsItemMirageId | null;
    /** The status of Mirage. */
    value?: GetResponseActionsItemMirageValue | null;
}
export type GetResponseActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export type GetResponseActionsItemOpportunisticEncryptionValue = "on" | "off";
export interface GetResponseActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. It's not a substitute for HTTPS, but provides additional security for otherwise vulnerable requests. */
    id?: GetResponseActionsItemOpportunisticEncryptionId | null;
    /** The status of Opportunistic Encryption. */
    value?: GetResponseActionsItemOpportunisticEncryptionValue | null;
}
export type GetResponseActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export type GetResponseActionsItemOriginErrorPagePassThruValue = "on" | "off";
export interface GetResponseActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: GetResponseActionsItemOriginErrorPagePassThruId | null;
    /** The status of Origin Error Page Passthru. */
    value?: GetResponseActionsItemOriginErrorPagePassThruValue | null;
}
export type GetResponseActionsItemPolishId = "polish";
export type GetResponseActionsItemPolishValue = "off" | "lossless" | "lossy";
export interface GetResponseActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: GetResponseActionsItemPolishId | null;
    /** The level of Polish you want applied to your origin. */
    value?: GetResponseActionsItemPolishValue | null;
}
export type GetResponseActionsItemResolveOverrideId = "resolve_override";
export interface GetResponseActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: GetResponseActionsItemResolveOverrideId | null;
    /** The origin address you want to override with. */
    value?: string | null;
}
export type GetResponseActionsItemRespectStrongEtagId = "respect_strong_etag";
export type GetResponseActionsItemRespectStrongEtagValue = "on" | "off";
export interface GetResponseActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the Cloudflare cache and the origin server. */
    id?: GetResponseActionsItemRespectStrongEtagId | null;
    /** The status of Respect Strong ETags */
    value?: GetResponseActionsItemRespectStrongEtagValue | null;
}
export type GetResponseActionsItemResponseBufferingId = "response_buffering";
export type GetResponseActionsItemResponseBufferingValue = "on" | "off";
export interface GetResponseActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file from the origin server before forwarding it to the site visitor. By default, Cloudflare sends packets to the client as they arrive from the origin server. */
    id?: GetResponseActionsItemResponseBufferingId | null;
    /** The status of Response Buffering */
    value?: GetResponseActionsItemResponseBufferingValue | null;
}
export type GetResponseActionsItemRocketLoaderId = "rocket_loader";
export type GetResponseActionsItemRocketLoaderValue = "on" | "off";
export interface GetResponseActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: GetResponseActionsItemRocketLoaderId | null;
    /** The status of Rocket Loader */
    value?: GetResponseActionsItemRocketLoaderValue | null;
}
export type GetResponseActionsItemSecurityLevelId = "security_level";
export type GetResponseActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface GetResponseActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: GetResponseActionsItemSecurityLevelId | null;
    value?: GetResponseActionsItemSecurityLevelValue | null;
}
export type GetResponseActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export type GetResponseActionsItemSortQueryStringForCacheValue = "on" | "off";
export interface GetResponseActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: GetResponseActionsItemSortQueryStringForCacheId | null;
    /** The status of Query String Sort */
    value?: GetResponseActionsItemSortQueryStringForCacheValue | null;
}
export type GetResponseActionsItemSSLId = "ssl";
export type GetResponseActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export interface GetResponseActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: GetResponseActionsItemSSLId | null;
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: GetResponseActionsItemSSLValue | null;
}
export type GetResponseActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export type GetResponseActionsItemTrueClientIPHeaderValue = "on" | "off";
export interface GetResponseActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: GetResponseActionsItemTrueClientIPHeaderId | null;
    /** The status of True Client IP Header. */
    value?: GetResponseActionsItemTrueClientIPHeaderValue | null;
}
export type GetResponseActionsItemWAFId = "waf";
export type GetResponseActionsItemWAFValue = "on" | "off";
export interface GetResponseActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). You cannot enable or disable individual WAF managed rules via Page Rules. */
    id?: GetResponseActionsItemWAFId | null;
    /** The status of WAF managed rules (previous version). */
    value?: GetResponseActionsItemWAFValue | null;
}
export type GetResponseActionsItem = GetResponseActionsItemAlwaysUseHTTPS | GetResponseActionsItemAutomaticHTTPSRewrites | GetResponseActionsItemBrowserCacheTTL | GetResponseActionsItemBrowserCheck | GetResponseActionsItemBypassCacheOnCookie | GetResponseActionsItemCacheByDeviceType | GetResponseActionsItemCacheDeceptionArmor | GetResponseActionsItemCacheKeyFields | GetResponseActionsItemCacheLevel | GetResponseActionsItemCacheOnCookie | GetResponseActionsItemCacheTTLByStatus | GetResponseActionsItemDisableApps | GetResponseActionsItemDisablePerformance | GetResponseActionsItemDisableSecurity | GetResponseActionsItemDisableZaraz | GetResponseActionsItemEdgeCacheTTL | GetResponseActionsItemEmailObfuscation | GetResponseActionsItemExplicitCacheControl | GetResponseActionsItemForwardingURL | GetResponseActionsItemHostHeaderOverride | GetResponseActionsItemIPGeolocation | GetResponseActionsItemMirage | GetResponseActionsItemOpportunisticEncryption | GetResponseActionsItemOriginErrorPagePassThru | GetResponseActionsItemPolish | GetResponseActionsItemResolveOverride | GetResponseActionsItemRespectStrongEtag | GetResponseActionsItemResponseBuffering | GetResponseActionsItemRocketLoader | GetResponseActionsItemSecurityLevel | GetResponseActionsItemSortQueryStringForCache | GetResponseActionsItemSSL | GetResponseActionsItemTrueClientIPHeader | GetResponseActionsItemWAF;
export type GetResponseActionsList = Array<GetResponseActionsItem>;
export type GetResponseStatus = "active" | "disabled";
export type GetResponseTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export interface GetResponseTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: GetResponseTargetsItemConstraintOperator;
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export type GetResponseTargetsItemTarget = "url";
export interface GetResponseTargetsItem {
    /** String constraint. */
    constraint?: GetResponseTargetsItemConstraint | null;
    /** A target based on the URL of the request. */
    target?: GetResponseTargetsItemTarget | null;
}
export type GetResponseTargetsList = Array<GetResponseTargetsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPageRuleResponse {
    /** Identifier. */
    id: string;
    /** The set of actions to perform if the targets of this rule match the request. Actions can redirect to another URL or override settings, but not both. */
    actions: GetResponseActionsList;
    /** The timestamp of when the Page Rule was created. */
    createdOn: string;
    /** The timestamp of when the Page Rule was last modified. */
    modifiedOn: string;
    /** The priority of the rule, used to define which Page Rule is processed over another. A higher number indicates a higher priority. For example, if you have a catch-all Page Rule (rule A: `/images/*`) but want a more specific Page Rule to take precedence (rule B: `/images/special/*`), specify a higher priority for rule B so it overrides rule A. */
    priority: number;
    /** The status of the Page Rule. */
    status: GetResponseStatus;
    /** The rule targets to evaluate on each request. */
    targets: GetResponseTargetsList;
}
export type ListRequestDirection = "asc" | "desc";
export type ListRequestMatch = "any" | "all";
export type ListRequestOrder = "status" | "priority";
export type ListRequestStatus = "active" | "disabled";
export interface ListPageRulesRequest {
    /** Identifier. */
    zoneId: string;
    /** The direction used to sort returned Page Rules. */
    direction?: ListRequestDirection | (string & {});
    /** When set to `all`, all the search requirements must match. When set to `any`, only one of the search requirements has to match. */
    match?: ListRequestMatch | (string & {});
    /** The field used to sort returned Page Rules. */
    order?: ListRequestOrder | (string & {});
    /** The status of the Page Rule. */
    status?: ListRequestStatus | (string & {});
}
export type ListResultItemActionsItemAlwaysUseHTTPSId = "always_use_https";
export interface ListResultItemActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to` https://` through a 301 redirect. */
    id?: ListResultItemActionsItemAlwaysUseHTTPSId | null;
}
export type ListResultItemActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export type ListResultItemActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export interface ListResultItemActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: ListResultItemActionsItemAutomaticHTTPSRewritesId | null;
    /** The status of Automatic HTTPS Rewrites. */
    value?: ListResultItemActionsItemAutomaticHTTPSRewritesValue | null;
}
export type ListResultItemActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export interface ListResultItemActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: ListResultItemActionsItemBrowserCacheTTLId | null;
    /** The number of seconds to cache resources for. Setting this to 0 enables "Respect Existing Headers". */
    value?: number | null;
}
export type ListResultItemActionsItemBrowserCheckId = "browser_check";
export type ListResultItemActionsItemBrowserCheckValue = "on" | "off";
export interface ListResultItemActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with spammers and certain bots. */
    id?: ListResultItemActionsItemBrowserCheckId | null;
    /** The status of Browser Integrity Check. */
    value?: ListResultItemActionsItemBrowserCheckValue | null;
}
export type ListResultItemActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export interface ListResultItemActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular expression matches against a cookie name present in the request. */
    id?: ListResultItemActionsItemBypassCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the request. Refer to [Bypass Cache on Cookie setting](https://developers.cloudflare.com/rules/page-rules/reference/additional-reference/#bypass-cache-on-cookie-setting) to learn about limited regular expression support. */
    value?: string | null;
}
export type ListResultItemActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export type ListResultItemActionsItemCacheByDeviceTypeValue = "on" | "off";
export interface ListResultItemActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: ListResultItemActionsItemCacheByDeviceTypeId | null;
    /** The status of Cache By Device Type. */
    value?: ListResultItemActionsItemCacheByDeviceTypeValue | null;
}
export type ListResultItemActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export type ListResultItemActionsItemCacheDeceptionArmorValue = "on" | "off";
export interface ListResultItemActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static assets to be cached. This setting verifies that the URL's extension matches the returned `Content-Type`. */
    id?: ListResultItemActionsItemCacheDeceptionArmorId | null;
    /** The status of Cache Deception Armor. */
    value?: ListResultItemActionsItemCacheDeceptionArmorValue | null;
}
export type ListResultItemActionsItemCacheKeyFieldsId = "cache_key_fields";
export type ListResultItemActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export type ListResultItemActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export interface ListResultItemActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without including their actual values. */
    checkPresence?: ListResultItemActionsItemCacheKeyFieldsValueCookieCheckPresenceList | null;
    /** A list of cookies to include. */
    include?: ListResultItemActionsItemCacheKeyFieldsValueCookieIncludeList | null;
}
export type ListResultItemActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export type ListResultItemActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export type ListResultItemActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export interface ListResultItemActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without including their actual values. */
    checkPresence?: ListResultItemActionsItemCacheKeyFieldsValueHeaderCheckPresenceList | null;
    /** A list of headers to ignore. */
    exclude?: ListResultItemActionsItemCacheKeyFieldsValueHeaderExcludeList | null;
    /** A list of headers to include. */
    include?: ListResultItemActionsItemCacheKeyFieldsValueHeaderIncludeList | null;
}
export type ListResultItemActionsItemCacheKeyFieldsValueHost = CreateResponseActionsItemCacheKeyFieldsValueHost;
export type ListResultItemActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export type ListResultItemActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export type ListResultItemActionsItemCacheKeyFieldsValueQueryStringExclude = ListResultItemActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | ListResultItemActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export type ListResultItemActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export type ListResultItemActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export type ListResultItemActionsItemCacheKeyFieldsValueQueryStringInclude = ListResultItemActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | ListResultItemActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export interface ListResultItemActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: ListResultItemActionsItemCacheKeyFieldsValueQueryStringExclude | null;
    /** Include all query string parameters. */
    include?: ListResultItemActionsItemCacheKeyFieldsValueQueryStringInclude | null;
}
export type ListResultItemActionsItemCacheKeyFieldsValueUser = CreateResponseActionsItemCacheKeyFieldsValueUser;
export interface ListResultItemActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: ListResultItemActionsItemCacheKeyFieldsValueCookie | null;
    /** Controls which headers go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    header?: ListResultItemActionsItemCacheKeyFieldsValueHeader | null;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateResponseActionsItemCacheKeyFieldsValueHost | null;
    /** Controls which URL query string parameters go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    queryString?: ListResultItemActionsItemCacheKeyFieldsValueQueryString | null;
    /** Feature fields to add features about the end-user (client) into the Cache Key. */
    user?: CreateResponseActionsItemCacheKeyFieldsValueUser | null;
}
export interface ListResultItemActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which resources to cache. This allows customers to determine what to cache based on something other than just the URL. */
    id?: ListResultItemActionsItemCacheKeyFieldsId | null;
    value?: ListResultItemActionsItemCacheKeyFieldsValue | null;
}
export type ListResultItemActionsItemCacheLevelId = "cache_level";
export type ListResultItemActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export interface ListResultItemActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: ListResultItemActionsItemCacheLevelId | null;
    /** - `bypass`: Cloudflare does not cache. - `basic`: Delivers resources from cache when there is no query string. - `simplified`: Delivers the same resource to everyone independent of the query string. - `aggressive`: Caches all static content that has a query string. - `cache_everything`: Treats all content as static and caches all file types beyond the [Cloudflare default cached content](https://developers.cloudflare.com/cache/concepts/default-cache-behavior/#default-cached-file-extensions). */
    value?: ListResultItemActionsItemCacheLevelValue | null;
}
export type ListResultItemActionsItemCacheOnCookieId = "cache_on_cookie";
export interface ListResultItemActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a regular expression match against a cookie name. */
    id?: ListResultItemActionsItemCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the request. */
    value?: string | null;
}
export type ListResultItemActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export type ListResultItemActionsItemCacheTTLByStatusValueValueCase0 = "no-cache" | "no-store";
export type ListResultItemActionsItemCacheTTLByStatusValueValue = number | ListResultItemActionsItemCacheTTLByStatusValueValueCase0;
export type ListResultItemActionsItemCacheTTLByStatusValueMap = {
    [key: string]: ListResultItemActionsItemCacheTTLByStatusValueValue | undefined;
};
export interface ListResultItemActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the response status from the origin web server. Cache TTL refers to the duration of a resource in the Cloudflare network before being marked as stale or discarded from cache. Status codes are returned by a resource's origin. Setting cache TTL based on response status overrides the default cache behavior (standard caching) for static files and overrides cache instructions sent by the origin web server. To cache non-static assets, set a Cache Level of Cache Everything using a Page Rule. Setting no-store Cache-Control or a low TTL (using `max-age`/`s-maxage`) increases requests to origin web servers and decreases performance. */
    id?: ListResultItemActionsItemCacheTTLByStatusId | null;
    /** A JSON object containing status codes and their corresponding TTLs. Each key-value pair in the cache TTL by status cache rule has the following syntax */
    value?: ListResultItemActionsItemCacheTTLByStatusValueMap | null;
}
export type ListResultItemActionsItemDisableAppsId = "disable_apps";
export interface ListResultItemActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) (deprecated). */
    id?: ListResultItemActionsItemDisableAppsId | null;
}
export type ListResultItemActionsItemDisablePerformanceId = "disable_performance";
export interface ListResultItemActionsItemDisablePerformance {
    /** Turn off [Rocket Loader](https://developers.cloudflare.com/speed/optimization/content/rocket-loader/), and [Polish](https://developers.cloudflare.com/images/polish/). */
    id?: ListResultItemActionsItemDisablePerformanceId | null;
}
export type ListResultItemActionsItemDisableSecurityId = "disable_security";
export interface ListResultItemActionsItemDisableSecurity {
    /** Turn off [Email Obfuscation](https://developers.cloudflare.com/waf/tools/scrape-shield/email-address-obfuscation/), [Rate Limiting (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-rate-limiting/), [Scrape Shield](https://developers.cloudflare.com/waf/tools/scrape-shield/), [URL (Zone) Lockdown](https://developers.cloudflare.com/waf/tools/zone-lockdown/), and [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: ListResultItemActionsItemDisableSecurityId | null;
}
export type ListResultItemActionsItemDisableZarazId = "disable_zaraz";
export interface ListResultItemActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: ListResultItemActionsItemDisableZarazId | null;
}
export type ListResultItemActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export interface ListResultItemActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global network. *Edge Cache TTL* is not visible in response headers. */
    id?: ListResultItemActionsItemEdgeCacheTTLId | null;
    value?: number | null;
}
export type ListResultItemActionsItemEmailObfuscationId = "email_obfuscation";
export type ListResultItemActionsItemEmailObfuscationValue = "on" | "off";
export interface ListResultItemActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: ListResultItemActionsItemEmailObfuscationId | null;
    /** The status of Email Obfuscation. */
    value?: ListResultItemActionsItemEmailObfuscationValue | null;
}
export type ListResultItemActionsItemExplicitCacheControlId = "explicit_cache_control";
export type ListResultItemActionsItemExplicitCacheControlValue = "on" | "off";
export interface ListResultItemActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and Business domains and disabled by default for Enterprise domains. */
    id?: ListResultItemActionsItemExplicitCacheControlId | null;
    /** The status of Origin Cache Control. */
    value?: ListResultItemActionsItemExplicitCacheControlValue | null;
}
export type ListResultItemActionsItemForwardingURLId = "forwarding_url";
export type ListResultItemActionsItemForwardingURLValueStatusCode = 301 | 302;
export interface ListResultItemActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent redirect. 302 is a temporary redirect. */
    statusCode?: ListResultItemActionsItemForwardingURLValueStatusCode | null;
    /** The URL to redirect the request to. Notes: ${num} refers to the position of '*' in the constraint value. */
    url?: string | null;
}
export interface ListResultItemActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer to [Wildcard matching and referencing](https://developers.cloudflare.com/rules/page-rules/reference/wildcard-matching/). */
    id?: ListResultItemActionsItemForwardingURLId | null;
    value?: ListResultItemActionsItemForwardingURLValue | null;
}
export type ListResultItemActionsItemHostHeaderOverrideId = "host_header_override";
export interface ListResultItemActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: ListResultItemActionsItemHostHeaderOverrideId | null;
    /** The hostname to use in the `Host` header */
    value?: string | null;
}
export type ListResultItemActionsItemIPGeolocationId = "ip_geolocation";
export type ListResultItemActionsItemIPGeolocationValue = "on" | "off";
export interface ListResultItemActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: ListResultItemActionsItemIPGeolocationId | null;
    /** The status of adding the IP Geolocation Header. */
    value?: ListResultItemActionsItemIPGeolocationValue | null;
}
export type ListResultItemActionsItemMirageId = "mirage";
export type ListResultItemActionsItemMirageValue = "on" | "off";
export interface ListResultItemActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. It can accelerate loading of image-heavy websites on very slow mobile connections and HTTP/1. */
    id?: ListResultItemActionsItemMirageId | null;
    /** The status of Mirage. */
    value?: ListResultItemActionsItemMirageValue | null;
}
export type ListResultItemActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export type ListResultItemActionsItemOpportunisticEncryptionValue = "on" | "off";
export interface ListResultItemActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. It's not a substitute for HTTPS, but provides additional security for otherwise vulnerable requests. */
    id?: ListResultItemActionsItemOpportunisticEncryptionId | null;
    /** The status of Opportunistic Encryption. */
    value?: ListResultItemActionsItemOpportunisticEncryptionValue | null;
}
export type ListResultItemActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export type ListResultItemActionsItemOriginErrorPagePassThruValue = "on" | "off";
export interface ListResultItemActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: ListResultItemActionsItemOriginErrorPagePassThruId | null;
    /** The status of Origin Error Page Passthru. */
    value?: ListResultItemActionsItemOriginErrorPagePassThruValue | null;
}
export type ListResultItemActionsItemPolishId = "polish";
export type ListResultItemActionsItemPolishValue = "off" | "lossless" | "lossy";
export interface ListResultItemActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: ListResultItemActionsItemPolishId | null;
    /** The level of Polish you want applied to your origin. */
    value?: ListResultItemActionsItemPolishValue | null;
}
export type ListResultItemActionsItemResolveOverrideId = "resolve_override";
export interface ListResultItemActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: ListResultItemActionsItemResolveOverrideId | null;
    /** The origin address you want to override with. */
    value?: string | null;
}
export type ListResultItemActionsItemRespectStrongEtagId = "respect_strong_etag";
export type ListResultItemActionsItemRespectStrongEtagValue = "on" | "off";
export interface ListResultItemActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the Cloudflare cache and the origin server. */
    id?: ListResultItemActionsItemRespectStrongEtagId | null;
    /** The status of Respect Strong ETags */
    value?: ListResultItemActionsItemRespectStrongEtagValue | null;
}
export type ListResultItemActionsItemResponseBufferingId = "response_buffering";
export type ListResultItemActionsItemResponseBufferingValue = "on" | "off";
export interface ListResultItemActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file from the origin server before forwarding it to the site visitor. By default, Cloudflare sends packets to the client as they arrive from the origin server. */
    id?: ListResultItemActionsItemResponseBufferingId | null;
    /** The status of Response Buffering */
    value?: ListResultItemActionsItemResponseBufferingValue | null;
}
export type ListResultItemActionsItemRocketLoaderId = "rocket_loader";
export type ListResultItemActionsItemRocketLoaderValue = "on" | "off";
export interface ListResultItemActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: ListResultItemActionsItemRocketLoaderId | null;
    /** The status of Rocket Loader */
    value?: ListResultItemActionsItemRocketLoaderValue | null;
}
export type ListResultItemActionsItemSecurityLevelId = "security_level";
export type ListResultItemActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface ListResultItemActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: ListResultItemActionsItemSecurityLevelId | null;
    value?: ListResultItemActionsItemSecurityLevelValue | null;
}
export type ListResultItemActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export type ListResultItemActionsItemSortQueryStringForCacheValue = "on" | "off";
export interface ListResultItemActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: ListResultItemActionsItemSortQueryStringForCacheId | null;
    /** The status of Query String Sort */
    value?: ListResultItemActionsItemSortQueryStringForCacheValue | null;
}
export type ListResultItemActionsItemSSLId = "ssl";
export type ListResultItemActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export interface ListResultItemActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: ListResultItemActionsItemSSLId | null;
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: ListResultItemActionsItemSSLValue | null;
}
export type ListResultItemActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export type ListResultItemActionsItemTrueClientIPHeaderValue = "on" | "off";
export interface ListResultItemActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: ListResultItemActionsItemTrueClientIPHeaderId | null;
    /** The status of True Client IP Header. */
    value?: ListResultItemActionsItemTrueClientIPHeaderValue | null;
}
export type ListResultItemActionsItemWAFId = "waf";
export type ListResultItemActionsItemWAFValue = "on" | "off";
export interface ListResultItemActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). You cannot enable or disable individual WAF managed rules via Page Rules. */
    id?: ListResultItemActionsItemWAFId | null;
    /** The status of WAF managed rules (previous version). */
    value?: ListResultItemActionsItemWAFValue | null;
}
export type ListResultItemActionsItem = ListResultItemActionsItemAlwaysUseHTTPS | ListResultItemActionsItemAutomaticHTTPSRewrites | ListResultItemActionsItemBrowserCacheTTL | ListResultItemActionsItemBrowserCheck | ListResultItemActionsItemBypassCacheOnCookie | ListResultItemActionsItemCacheByDeviceType | ListResultItemActionsItemCacheDeceptionArmor | ListResultItemActionsItemCacheKeyFields | ListResultItemActionsItemCacheLevel | ListResultItemActionsItemCacheOnCookie | ListResultItemActionsItemCacheTTLByStatus | ListResultItemActionsItemDisableApps | ListResultItemActionsItemDisablePerformance | ListResultItemActionsItemDisableSecurity | ListResultItemActionsItemDisableZaraz | ListResultItemActionsItemEdgeCacheTTL | ListResultItemActionsItemEmailObfuscation | ListResultItemActionsItemExplicitCacheControl | ListResultItemActionsItemForwardingURL | ListResultItemActionsItemHostHeaderOverride | ListResultItemActionsItemIPGeolocation | ListResultItemActionsItemMirage | ListResultItemActionsItemOpportunisticEncryption | ListResultItemActionsItemOriginErrorPagePassThru | ListResultItemActionsItemPolish | ListResultItemActionsItemResolveOverride | ListResultItemActionsItemRespectStrongEtag | ListResultItemActionsItemResponseBuffering | ListResultItemActionsItemRocketLoader | ListResultItemActionsItemSecurityLevel | ListResultItemActionsItemSortQueryStringForCache | ListResultItemActionsItemSSL | ListResultItemActionsItemTrueClientIPHeader | ListResultItemActionsItemWAF;
export type ListResultItemActionsList = Array<ListResultItemActionsItem>;
export type ListResultItemStatus = "active" | "disabled";
export type ListResultItemTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export interface ListResultItemTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: ListResultItemTargetsItemConstraintOperator;
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export type ListResultItemTargetsItemTarget = "url";
export interface ListResultItemTargetsItem {
    /** String constraint. */
    constraint?: ListResultItemTargetsItemConstraint | null;
    /** A target based on the URL of the request. */
    target?: ListResultItemTargetsItemTarget | null;
}
export type ListResultItemTargetsList = Array<ListResultItemTargetsItem>;
export interface ListResultItem {
    /** Identifier. */
    id: string;
    /** The set of actions to perform if the targets of this rule match the request. Actions can redirect to another URL or override settings, but not both. */
    actions: ListResultItemActionsList;
    /** The timestamp of when the Page Rule was created. */
    createdOn: string;
    /** The timestamp of when the Page Rule was last modified. */
    modifiedOn: string;
    /** The priority of the rule, used to define which Page Rule is processed over another. A higher number indicates a higher priority. For example, if you have a catch-all Page Rule (rule A: `/images/*`) but want a more specific Page Rule to take precedence (rule B: `/images/special/*`), specify a higher priority for rule B so it overrides rule A. */
    priority: number;
    /** The status of the Page Rule. */
    status: ListResultItemStatus;
    /** The rule targets to evaluate on each request. */
    targets: ListResultItemTargetsList;
}
export type ListResultList = Array<ListResultItem>;
export type ListPageRulesResponse = ListResultList;
export type EditRequestActionsItemAlwaysUseHTTPSId = "always_use_https";
export interface EditRequestActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to` https://` through a 301 redirect. */
    id?: EditRequestActionsItemAlwaysUseHTTPSId | (string & {});
}
export type EditRequestActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export type EditRequestActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export interface EditRequestActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: EditRequestActionsItemAutomaticHTTPSRewritesId | (string & {});
    /** The status of Automatic HTTPS Rewrites. */
    value?: EditRequestActionsItemAutomaticHTTPSRewritesValue | (string & {});
}
export type EditRequestActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export interface EditRequestActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: EditRequestActionsItemBrowserCacheTTLId | (string & {});
    /** The number of seconds to cache resources for. Setting this to 0 enables "Respect Existing Headers". */
    value?: number;
}
export type EditRequestActionsItemBrowserCheckId = "browser_check";
export type EditRequestActionsItemBrowserCheckValue = "on" | "off";
export interface EditRequestActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with spammers and certain bots. */
    id?: EditRequestActionsItemBrowserCheckId | (string & {});
    /** The status of Browser Integrity Check. */
    value?: EditRequestActionsItemBrowserCheckValue | (string & {});
}
export type EditRequestActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export interface EditRequestActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular expression matches against a cookie name present in the request. */
    id?: EditRequestActionsItemBypassCacheOnCookieId | (string & {});
    /** The regular expression to use for matching cookie names in the request. Refer to [Bypass Cache on Cookie setting](https://developers.cloudflare.com/rules/page-rules/reference/additional-reference/#bypass-cache-on-cookie-setting) to learn about limited regular expression support. */
    value?: string;
}
export type EditRequestActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export type EditRequestActionsItemCacheByDeviceTypeValue = "on" | "off";
export interface EditRequestActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: EditRequestActionsItemCacheByDeviceTypeId | (string & {});
    /** The status of Cache By Device Type. */
    value?: EditRequestActionsItemCacheByDeviceTypeValue | (string & {});
}
export type EditRequestActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export type EditRequestActionsItemCacheDeceptionArmorValue = "on" | "off";
export interface EditRequestActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static assets to be cached. This setting verifies that the URL's extension matches the returned `Content-Type`. */
    id?: EditRequestActionsItemCacheDeceptionArmorId | (string & {});
    /** The status of Cache Deception Armor. */
    value?: EditRequestActionsItemCacheDeceptionArmorValue | (string & {});
}
export type EditRequestActionsItemCacheKeyFieldsId = "cache_key_fields";
export type EditRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export type EditRequestActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export interface EditRequestActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without including their actual values. */
    checkPresence?: EditRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList;
    /** A list of cookies to include. */
    include?: EditRequestActionsItemCacheKeyFieldsValueCookieIncludeList;
}
export type EditRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export type EditRequestActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export type EditRequestActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export interface EditRequestActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without including their actual values. */
    checkPresence?: EditRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList;
    /** A list of headers to ignore. */
    exclude?: EditRequestActionsItemCacheKeyFieldsValueHeaderExcludeList;
    /** A list of headers to include. */
    include?: EditRequestActionsItemCacheKeyFieldsValueHeaderIncludeList;
}
export type EditRequestActionsItemCacheKeyFieldsValueHost = CreateRequestActionsItemCacheKeyFieldsValueHost;
export type EditRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export type EditRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export type EditRequestActionsItemCacheKeyFieldsValueQueryStringExclude = EditRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | (string & {}) | EditRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export type EditRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export type EditRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export type EditRequestActionsItemCacheKeyFieldsValueQueryStringInclude = EditRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | (string & {}) | EditRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export interface EditRequestActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: EditRequestActionsItemCacheKeyFieldsValueQueryStringExclude;
    /** Include all query string parameters. */
    include?: EditRequestActionsItemCacheKeyFieldsValueQueryStringInclude;
}
export type EditRequestActionsItemCacheKeyFieldsValueUser = CreateRequestActionsItemCacheKeyFieldsValueUser;
export interface EditRequestActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: EditRequestActionsItemCacheKeyFieldsValueCookie;
    /** Controls which headers go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    header?: EditRequestActionsItemCacheKeyFieldsValueHeader;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateRequestActionsItemCacheKeyFieldsValueHost;
    /** Controls which URL query string parameters go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    queryString?: EditRequestActionsItemCacheKeyFieldsValueQueryString;
    /** Feature fields to add features about the end-user (client) into the Cache Key. */
    user?: CreateRequestActionsItemCacheKeyFieldsValueUser;
}
export interface EditRequestActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which resources to cache. This allows customers to determine what to cache based on something other than just the URL. */
    id?: EditRequestActionsItemCacheKeyFieldsId | (string & {});
    value?: EditRequestActionsItemCacheKeyFieldsValue;
}
export type EditRequestActionsItemCacheLevelId = "cache_level";
export type EditRequestActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export interface EditRequestActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: EditRequestActionsItemCacheLevelId | (string & {});
    /** - `bypass`: Cloudflare does not cache. - `basic`: Delivers resources from cache when there is no query string. - `simplified`: Delivers the same resource to everyone independent of the query string. - `aggressive`: Caches all static content that has a query string. - `cache_everything`: Treats all content as static and caches all file types beyond the [Cloudflare default cached content](https://developers.cloudflare.com/cache/concepts/default-cache-behavior/#default-cached-file-extensions). */
    value?: EditRequestActionsItemCacheLevelValue | (string & {});
}
export type EditRequestActionsItemCacheOnCookieId = "cache_on_cookie";
export interface EditRequestActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a regular expression match against a cookie name. */
    id?: EditRequestActionsItemCacheOnCookieId | (string & {});
    /** The regular expression to use for matching cookie names in the request. */
    value?: string;
}
export type EditRequestActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export type EditRequestActionsItemCacheTTLByStatusValueValueCase0 = "no-cache" | "no-store";
export type EditRequestActionsItemCacheTTLByStatusValueValue = number | EditRequestActionsItemCacheTTLByStatusValueValueCase0 | (string & {});
export type EditRequestActionsItemCacheTTLByStatusValueMap = {
    [key: string]: EditRequestActionsItemCacheTTLByStatusValueValue | undefined;
};
export interface EditRequestActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the response status from the origin web server. Cache TTL refers to the duration of a resource in the Cloudflare network before being marked as stale or discarded from cache. Status codes are returned by a resource's origin. Setting cache TTL based on response status overrides the default cache behavior (standard caching) for static files and overrides cache instructions sent by the origin web server. To cache non-static assets, set a Cache Level of Cache Everything using a Page Rule. Setting no-store Cache-Control or a low TTL (using `max-age`/`s-maxage`) increases requests to origin web servers and decreases performance. */
    id?: EditRequestActionsItemCacheTTLByStatusId | (string & {});
    /** A JSON object containing status codes and their corresponding TTLs. Each key-value pair in the cache TTL by status cache rule has the following syntax */
    value?: EditRequestActionsItemCacheTTLByStatusValueMap;
}
export type EditRequestActionsItemDisableAppsId = "disable_apps";
export interface EditRequestActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) (deprecated). */
    id?: EditRequestActionsItemDisableAppsId | (string & {});
}
export type EditRequestActionsItemDisablePerformanceId = "disable_performance";
export interface EditRequestActionsItemDisablePerformance {
    /** Turn off [Rocket Loader](https://developers.cloudflare.com/speed/optimization/content/rocket-loader/), and [Polish](https://developers.cloudflare.com/images/polish/). */
    id?: EditRequestActionsItemDisablePerformanceId | (string & {});
}
export type EditRequestActionsItemDisableSecurityId = "disable_security";
export interface EditRequestActionsItemDisableSecurity {
    /** Turn off [Email Obfuscation](https://developers.cloudflare.com/waf/tools/scrape-shield/email-address-obfuscation/), [Rate Limiting (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-rate-limiting/), [Scrape Shield](https://developers.cloudflare.com/waf/tools/scrape-shield/), [URL (Zone) Lockdown](https://developers.cloudflare.com/waf/tools/zone-lockdown/), and [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: EditRequestActionsItemDisableSecurityId | (string & {});
}
export type EditRequestActionsItemDisableZarazId = "disable_zaraz";
export interface EditRequestActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: EditRequestActionsItemDisableZarazId | (string & {});
}
export type EditRequestActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export interface EditRequestActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global network. *Edge Cache TTL* is not visible in response headers. */
    id?: EditRequestActionsItemEdgeCacheTTLId | (string & {});
    value?: number;
}
export type EditRequestActionsItemEmailObfuscationId = "email_obfuscation";
export type EditRequestActionsItemEmailObfuscationValue = "on" | "off";
export interface EditRequestActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: EditRequestActionsItemEmailObfuscationId | (string & {});
    /** The status of Email Obfuscation. */
    value?: EditRequestActionsItemEmailObfuscationValue | (string & {});
}
export type EditRequestActionsItemExplicitCacheControlId = "explicit_cache_control";
export type EditRequestActionsItemExplicitCacheControlValue = "on" | "off";
export interface EditRequestActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and Business domains and disabled by default for Enterprise domains. */
    id?: EditRequestActionsItemExplicitCacheControlId | (string & {});
    /** The status of Origin Cache Control. */
    value?: EditRequestActionsItemExplicitCacheControlValue | (string & {});
}
export type EditRequestActionsItemForwardingURLId = "forwarding_url";
export type EditRequestActionsItemForwardingURLValueStatusCode = 301 | 302;
export interface EditRequestActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent redirect. 302 is a temporary redirect. */
    statusCode?: EditRequestActionsItemForwardingURLValueStatusCode | (number & {});
    /** The URL to redirect the request to. Notes: ${num} refers to the position of '*' in the constraint value. */
    url?: string;
}
export interface EditRequestActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer to [Wildcard matching and referencing](https://developers.cloudflare.com/rules/page-rules/reference/wildcard-matching/). */
    id?: EditRequestActionsItemForwardingURLId | (string & {});
    value?: EditRequestActionsItemForwardingURLValue;
}
export type EditRequestActionsItemHostHeaderOverrideId = "host_header_override";
export interface EditRequestActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: EditRequestActionsItemHostHeaderOverrideId | (string & {});
    /** The hostname to use in the `Host` header */
    value?: string;
}
export type EditRequestActionsItemIPGeolocationId = "ip_geolocation";
export type EditRequestActionsItemIPGeolocationValue = "on" | "off";
export interface EditRequestActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: EditRequestActionsItemIPGeolocationId | (string & {});
    /** The status of adding the IP Geolocation Header. */
    value?: EditRequestActionsItemIPGeolocationValue | (string & {});
}
export type EditRequestActionsItemMirageId = "mirage";
export type EditRequestActionsItemMirageValue = "on" | "off";
export interface EditRequestActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. It can accelerate loading of image-heavy websites on very slow mobile connections and HTTP/1. */
    id?: EditRequestActionsItemMirageId | (string & {});
    /** The status of Mirage. */
    value?: EditRequestActionsItemMirageValue | (string & {});
}
export type EditRequestActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export type EditRequestActionsItemOpportunisticEncryptionValue = "on" | "off";
export interface EditRequestActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. It's not a substitute for HTTPS, but provides additional security for otherwise vulnerable requests. */
    id?: EditRequestActionsItemOpportunisticEncryptionId | (string & {});
    /** The status of Opportunistic Encryption. */
    value?: EditRequestActionsItemOpportunisticEncryptionValue | (string & {});
}
export type EditRequestActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export type EditRequestActionsItemOriginErrorPagePassThruValue = "on" | "off";
export interface EditRequestActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: EditRequestActionsItemOriginErrorPagePassThruId | (string & {});
    /** The status of Origin Error Page Passthru. */
    value?: EditRequestActionsItemOriginErrorPagePassThruValue | (string & {});
}
export type EditRequestActionsItemPolishId = "polish";
export type EditRequestActionsItemPolishValue = "off" | "lossless" | "lossy";
export interface EditRequestActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: EditRequestActionsItemPolishId | (string & {});
    /** The level of Polish you want applied to your origin. */
    value?: EditRequestActionsItemPolishValue | (string & {});
}
export type EditRequestActionsItemResolveOverrideId = "resolve_override";
export interface EditRequestActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: EditRequestActionsItemResolveOverrideId | (string & {});
    /** The origin address you want to override with. */
    value?: string;
}
export type EditRequestActionsItemRespectStrongEtagId = "respect_strong_etag";
export type EditRequestActionsItemRespectStrongEtagValue = "on" | "off";
export interface EditRequestActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the Cloudflare cache and the origin server. */
    id?: EditRequestActionsItemRespectStrongEtagId | (string & {});
    /** The status of Respect Strong ETags */
    value?: EditRequestActionsItemRespectStrongEtagValue | (string & {});
}
export type EditRequestActionsItemResponseBufferingId = "response_buffering";
export type EditRequestActionsItemResponseBufferingValue = "on" | "off";
export interface EditRequestActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file from the origin server before forwarding it to the site visitor. By default, Cloudflare sends packets to the client as they arrive from the origin server. */
    id?: EditRequestActionsItemResponseBufferingId | (string & {});
    /** The status of Response Buffering */
    value?: EditRequestActionsItemResponseBufferingValue | (string & {});
}
export type EditRequestActionsItemRocketLoaderId = "rocket_loader";
export type EditRequestActionsItemRocketLoaderValue = "on" | "off";
export interface EditRequestActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: EditRequestActionsItemRocketLoaderId | (string & {});
    /** The status of Rocket Loader */
    value?: EditRequestActionsItemRocketLoaderValue | (string & {});
}
export type EditRequestActionsItemSecurityLevelId = "security_level";
export type EditRequestActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface EditRequestActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: EditRequestActionsItemSecurityLevelId | (string & {});
    value?: EditRequestActionsItemSecurityLevelValue | (string & {});
}
export type EditRequestActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export type EditRequestActionsItemSortQueryStringForCacheValue = "on" | "off";
export interface EditRequestActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: EditRequestActionsItemSortQueryStringForCacheId | (string & {});
    /** The status of Query String Sort */
    value?: EditRequestActionsItemSortQueryStringForCacheValue | (string & {});
}
export type EditRequestActionsItemSSLId = "ssl";
export type EditRequestActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export interface EditRequestActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: EditRequestActionsItemSSLId | (string & {});
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: EditRequestActionsItemSSLValue | (string & {});
}
export type EditRequestActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export type EditRequestActionsItemTrueClientIPHeaderValue = "on" | "off";
export interface EditRequestActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: EditRequestActionsItemTrueClientIPHeaderId | (string & {});
    /** The status of True Client IP Header. */
    value?: EditRequestActionsItemTrueClientIPHeaderValue | (string & {});
}
export type EditRequestActionsItemWAFId = "waf";
export type EditRequestActionsItemWAFValue = "on" | "off";
export interface EditRequestActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). You cannot enable or disable individual WAF managed rules via Page Rules. */
    id?: EditRequestActionsItemWAFId | (string & {});
    /** The status of WAF managed rules (previous version). */
    value?: EditRequestActionsItemWAFValue | (string & {});
}
export type EditRequestActionsItem = EditRequestActionsItemAlwaysUseHTTPS | EditRequestActionsItemAutomaticHTTPSRewrites | EditRequestActionsItemBrowserCacheTTL | EditRequestActionsItemBrowserCheck | EditRequestActionsItemBypassCacheOnCookie | EditRequestActionsItemCacheByDeviceType | EditRequestActionsItemCacheDeceptionArmor | EditRequestActionsItemCacheKeyFields | EditRequestActionsItemCacheLevel | EditRequestActionsItemCacheOnCookie | EditRequestActionsItemCacheTTLByStatus | EditRequestActionsItemDisableApps | EditRequestActionsItemDisablePerformance | EditRequestActionsItemDisableSecurity | EditRequestActionsItemDisableZaraz | EditRequestActionsItemEdgeCacheTTL | EditRequestActionsItemEmailObfuscation | EditRequestActionsItemExplicitCacheControl | EditRequestActionsItemForwardingURL | EditRequestActionsItemHostHeaderOverride | EditRequestActionsItemIPGeolocation | EditRequestActionsItemMirage | EditRequestActionsItemOpportunisticEncryption | EditRequestActionsItemOriginErrorPagePassThru | EditRequestActionsItemPolish | EditRequestActionsItemResolveOverride | EditRequestActionsItemRespectStrongEtag | EditRequestActionsItemResponseBuffering | EditRequestActionsItemRocketLoader | EditRequestActionsItemSecurityLevel | EditRequestActionsItemSortQueryStringForCache | EditRequestActionsItemSSL | EditRequestActionsItemTrueClientIPHeader | EditRequestActionsItemWAF;
export type EditRequestActionsList = Array<EditRequestActionsItem>;
export type EditRequestStatus = "active" | "disabled";
export type EditRequestTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export interface EditRequestTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: EditRequestTargetsItemConstraintOperator | (string & {});
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export type EditRequestTargetsItemTarget = "url";
export interface EditRequestTargetsItem {
    /** String constraint. */
    constraint?: EditRequestTargetsItemConstraint;
    /** A target based on the URL of the request. */
    target?: EditRequestTargetsItemTarget | (string & {});
}
export type EditRequestTargetsList = Array<EditRequestTargetsItem>;
export interface PatchPageRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    pageruleId: string;
    /** The set of actions to perform if the targets of this rule match the request. Actions can redirect to another URL or override settings, but not both. */
    actions?: EditRequestActionsList;
    /** The priority of the rule, used to define which Page Rule is processed over another. A higher number indicates a higher priority. For example, if you have a catch-all Page Rule (rule A: `/images/*`) but want a more specific Page Rule to take precedence (rule B: `/images/special/*`), specify a higher priority for rule B so it overrides rule A. */
    priority?: number;
    /** The status of the Page Rule. */
    status?: EditRequestStatus | (string & {});
    /** The rule targets to evaluate on each request. */
    targets?: EditRequestTargetsList;
}
export type EditResponseActionsItemAlwaysUseHTTPSId = "always_use_https";
export interface EditResponseActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to` https://` through a 301 redirect. */
    id?: EditResponseActionsItemAlwaysUseHTTPSId | null;
}
export type EditResponseActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export type EditResponseActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export interface EditResponseActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: EditResponseActionsItemAutomaticHTTPSRewritesId | null;
    /** The status of Automatic HTTPS Rewrites. */
    value?: EditResponseActionsItemAutomaticHTTPSRewritesValue | null;
}
export type EditResponseActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export interface EditResponseActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: EditResponseActionsItemBrowserCacheTTLId | null;
    /** The number of seconds to cache resources for. Setting this to 0 enables "Respect Existing Headers". */
    value?: number | null;
}
export type EditResponseActionsItemBrowserCheckId = "browser_check";
export type EditResponseActionsItemBrowserCheckValue = "on" | "off";
export interface EditResponseActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with spammers and certain bots. */
    id?: EditResponseActionsItemBrowserCheckId | null;
    /** The status of Browser Integrity Check. */
    value?: EditResponseActionsItemBrowserCheckValue | null;
}
export type EditResponseActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export interface EditResponseActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular expression matches against a cookie name present in the request. */
    id?: EditResponseActionsItemBypassCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the request. Refer to [Bypass Cache on Cookie setting](https://developers.cloudflare.com/rules/page-rules/reference/additional-reference/#bypass-cache-on-cookie-setting) to learn about limited regular expression support. */
    value?: string | null;
}
export type EditResponseActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export type EditResponseActionsItemCacheByDeviceTypeValue = "on" | "off";
export interface EditResponseActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: EditResponseActionsItemCacheByDeviceTypeId | null;
    /** The status of Cache By Device Type. */
    value?: EditResponseActionsItemCacheByDeviceTypeValue | null;
}
export type EditResponseActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export type EditResponseActionsItemCacheDeceptionArmorValue = "on" | "off";
export interface EditResponseActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static assets to be cached. This setting verifies that the URL's extension matches the returned `Content-Type`. */
    id?: EditResponseActionsItemCacheDeceptionArmorId | null;
    /** The status of Cache Deception Armor. */
    value?: EditResponseActionsItemCacheDeceptionArmorValue | null;
}
export type EditResponseActionsItemCacheKeyFieldsId = "cache_key_fields";
export type EditResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export type EditResponseActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export interface EditResponseActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without including their actual values. */
    checkPresence?: EditResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList | null;
    /** A list of cookies to include. */
    include?: EditResponseActionsItemCacheKeyFieldsValueCookieIncludeList | null;
}
export type EditResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export type EditResponseActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export type EditResponseActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export interface EditResponseActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without including their actual values. */
    checkPresence?: EditResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList | null;
    /** A list of headers to ignore. */
    exclude?: EditResponseActionsItemCacheKeyFieldsValueHeaderExcludeList | null;
    /** A list of headers to include. */
    include?: EditResponseActionsItemCacheKeyFieldsValueHeaderIncludeList | null;
}
export type EditResponseActionsItemCacheKeyFieldsValueHost = CreateResponseActionsItemCacheKeyFieldsValueHost;
export type EditResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export type EditResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export type EditResponseActionsItemCacheKeyFieldsValueQueryStringExclude = EditResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | EditResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export type EditResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export type EditResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export type EditResponseActionsItemCacheKeyFieldsValueQueryStringInclude = EditResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | EditResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export interface EditResponseActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: EditResponseActionsItemCacheKeyFieldsValueQueryStringExclude | null;
    /** Include all query string parameters. */
    include?: EditResponseActionsItemCacheKeyFieldsValueQueryStringInclude | null;
}
export type EditResponseActionsItemCacheKeyFieldsValueUser = CreateResponseActionsItemCacheKeyFieldsValueUser;
export interface EditResponseActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: EditResponseActionsItemCacheKeyFieldsValueCookie | null;
    /** Controls which headers go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    header?: EditResponseActionsItemCacheKeyFieldsValueHeader | null;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateResponseActionsItemCacheKeyFieldsValueHost | null;
    /** Controls which URL query string parameters go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    queryString?: EditResponseActionsItemCacheKeyFieldsValueQueryString | null;
    /** Feature fields to add features about the end-user (client) into the Cache Key. */
    user?: CreateResponseActionsItemCacheKeyFieldsValueUser | null;
}
export interface EditResponseActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which resources to cache. This allows customers to determine what to cache based on something other than just the URL. */
    id?: EditResponseActionsItemCacheKeyFieldsId | null;
    value?: EditResponseActionsItemCacheKeyFieldsValue | null;
}
export type EditResponseActionsItemCacheLevelId = "cache_level";
export type EditResponseActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export interface EditResponseActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: EditResponseActionsItemCacheLevelId | null;
    /** - `bypass`: Cloudflare does not cache. - `basic`: Delivers resources from cache when there is no query string. - `simplified`: Delivers the same resource to everyone independent of the query string. - `aggressive`: Caches all static content that has a query string. - `cache_everything`: Treats all content as static and caches all file types beyond the [Cloudflare default cached content](https://developers.cloudflare.com/cache/concepts/default-cache-behavior/#default-cached-file-extensions). */
    value?: EditResponseActionsItemCacheLevelValue | null;
}
export type EditResponseActionsItemCacheOnCookieId = "cache_on_cookie";
export interface EditResponseActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a regular expression match against a cookie name. */
    id?: EditResponseActionsItemCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the request. */
    value?: string | null;
}
export type EditResponseActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export type EditResponseActionsItemCacheTTLByStatusValueValueCase0 = "no-cache" | "no-store";
export type EditResponseActionsItemCacheTTLByStatusValueValue = number | EditResponseActionsItemCacheTTLByStatusValueValueCase0;
export type EditResponseActionsItemCacheTTLByStatusValueMap = {
    [key: string]: EditResponseActionsItemCacheTTLByStatusValueValue | undefined;
};
export interface EditResponseActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the response status from the origin web server. Cache TTL refers to the duration of a resource in the Cloudflare network before being marked as stale or discarded from cache. Status codes are returned by a resource's origin. Setting cache TTL based on response status overrides the default cache behavior (standard caching) for static files and overrides cache instructions sent by the origin web server. To cache non-static assets, set a Cache Level of Cache Everything using a Page Rule. Setting no-store Cache-Control or a low TTL (using `max-age`/`s-maxage`) increases requests to origin web servers and decreases performance. */
    id?: EditResponseActionsItemCacheTTLByStatusId | null;
    /** A JSON object containing status codes and their corresponding TTLs. Each key-value pair in the cache TTL by status cache rule has the following syntax */
    value?: EditResponseActionsItemCacheTTLByStatusValueMap | null;
}
export type EditResponseActionsItemDisableAppsId = "disable_apps";
export interface EditResponseActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) (deprecated). */
    id?: EditResponseActionsItemDisableAppsId | null;
}
export type EditResponseActionsItemDisablePerformanceId = "disable_performance";
export interface EditResponseActionsItemDisablePerformance {
    /** Turn off [Rocket Loader](https://developers.cloudflare.com/speed/optimization/content/rocket-loader/), and [Polish](https://developers.cloudflare.com/images/polish/). */
    id?: EditResponseActionsItemDisablePerformanceId | null;
}
export type EditResponseActionsItemDisableSecurityId = "disable_security";
export interface EditResponseActionsItemDisableSecurity {
    /** Turn off [Email Obfuscation](https://developers.cloudflare.com/waf/tools/scrape-shield/email-address-obfuscation/), [Rate Limiting (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-rate-limiting/), [Scrape Shield](https://developers.cloudflare.com/waf/tools/scrape-shield/), [URL (Zone) Lockdown](https://developers.cloudflare.com/waf/tools/zone-lockdown/), and [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: EditResponseActionsItemDisableSecurityId | null;
}
export type EditResponseActionsItemDisableZarazId = "disable_zaraz";
export interface EditResponseActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: EditResponseActionsItemDisableZarazId | null;
}
export type EditResponseActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export interface EditResponseActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global network. *Edge Cache TTL* is not visible in response headers. */
    id?: EditResponseActionsItemEdgeCacheTTLId | null;
    value?: number | null;
}
export type EditResponseActionsItemEmailObfuscationId = "email_obfuscation";
export type EditResponseActionsItemEmailObfuscationValue = "on" | "off";
export interface EditResponseActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: EditResponseActionsItemEmailObfuscationId | null;
    /** The status of Email Obfuscation. */
    value?: EditResponseActionsItemEmailObfuscationValue | null;
}
export type EditResponseActionsItemExplicitCacheControlId = "explicit_cache_control";
export type EditResponseActionsItemExplicitCacheControlValue = "on" | "off";
export interface EditResponseActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and Business domains and disabled by default for Enterprise domains. */
    id?: EditResponseActionsItemExplicitCacheControlId | null;
    /** The status of Origin Cache Control. */
    value?: EditResponseActionsItemExplicitCacheControlValue | null;
}
export type EditResponseActionsItemForwardingURLId = "forwarding_url";
export type EditResponseActionsItemForwardingURLValueStatusCode = 301 | 302;
export interface EditResponseActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent redirect. 302 is a temporary redirect. */
    statusCode?: EditResponseActionsItemForwardingURLValueStatusCode | null;
    /** The URL to redirect the request to. Notes: ${num} refers to the position of '*' in the constraint value. */
    url?: string | null;
}
export interface EditResponseActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer to [Wildcard matching and referencing](https://developers.cloudflare.com/rules/page-rules/reference/wildcard-matching/). */
    id?: EditResponseActionsItemForwardingURLId | null;
    value?: EditResponseActionsItemForwardingURLValue | null;
}
export type EditResponseActionsItemHostHeaderOverrideId = "host_header_override";
export interface EditResponseActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: EditResponseActionsItemHostHeaderOverrideId | null;
    /** The hostname to use in the `Host` header */
    value?: string | null;
}
export type EditResponseActionsItemIPGeolocationId = "ip_geolocation";
export type EditResponseActionsItemIPGeolocationValue = "on" | "off";
export interface EditResponseActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: EditResponseActionsItemIPGeolocationId | null;
    /** The status of adding the IP Geolocation Header. */
    value?: EditResponseActionsItemIPGeolocationValue | null;
}
export type EditResponseActionsItemMirageId = "mirage";
export type EditResponseActionsItemMirageValue = "on" | "off";
export interface EditResponseActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. It can accelerate loading of image-heavy websites on very slow mobile connections and HTTP/1. */
    id?: EditResponseActionsItemMirageId | null;
    /** The status of Mirage. */
    value?: EditResponseActionsItemMirageValue | null;
}
export type EditResponseActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export type EditResponseActionsItemOpportunisticEncryptionValue = "on" | "off";
export interface EditResponseActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. It's not a substitute for HTTPS, but provides additional security for otherwise vulnerable requests. */
    id?: EditResponseActionsItemOpportunisticEncryptionId | null;
    /** The status of Opportunistic Encryption. */
    value?: EditResponseActionsItemOpportunisticEncryptionValue | null;
}
export type EditResponseActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export type EditResponseActionsItemOriginErrorPagePassThruValue = "on" | "off";
export interface EditResponseActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: EditResponseActionsItemOriginErrorPagePassThruId | null;
    /** The status of Origin Error Page Passthru. */
    value?: EditResponseActionsItemOriginErrorPagePassThruValue | null;
}
export type EditResponseActionsItemPolishId = "polish";
export type EditResponseActionsItemPolishValue = "off" | "lossless" | "lossy";
export interface EditResponseActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: EditResponseActionsItemPolishId | null;
    /** The level of Polish you want applied to your origin. */
    value?: EditResponseActionsItemPolishValue | null;
}
export type EditResponseActionsItemResolveOverrideId = "resolve_override";
export interface EditResponseActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: EditResponseActionsItemResolveOverrideId | null;
    /** The origin address you want to override with. */
    value?: string | null;
}
export type EditResponseActionsItemRespectStrongEtagId = "respect_strong_etag";
export type EditResponseActionsItemRespectStrongEtagValue = "on" | "off";
export interface EditResponseActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the Cloudflare cache and the origin server. */
    id?: EditResponseActionsItemRespectStrongEtagId | null;
    /** The status of Respect Strong ETags */
    value?: EditResponseActionsItemRespectStrongEtagValue | null;
}
export type EditResponseActionsItemResponseBufferingId = "response_buffering";
export type EditResponseActionsItemResponseBufferingValue = "on" | "off";
export interface EditResponseActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file from the origin server before forwarding it to the site visitor. By default, Cloudflare sends packets to the client as they arrive from the origin server. */
    id?: EditResponseActionsItemResponseBufferingId | null;
    /** The status of Response Buffering */
    value?: EditResponseActionsItemResponseBufferingValue | null;
}
export type EditResponseActionsItemRocketLoaderId = "rocket_loader";
export type EditResponseActionsItemRocketLoaderValue = "on" | "off";
export interface EditResponseActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: EditResponseActionsItemRocketLoaderId | null;
    /** The status of Rocket Loader */
    value?: EditResponseActionsItemRocketLoaderValue | null;
}
export type EditResponseActionsItemSecurityLevelId = "security_level";
export type EditResponseActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface EditResponseActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: EditResponseActionsItemSecurityLevelId | null;
    value?: EditResponseActionsItemSecurityLevelValue | null;
}
export type EditResponseActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export type EditResponseActionsItemSortQueryStringForCacheValue = "on" | "off";
export interface EditResponseActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: EditResponseActionsItemSortQueryStringForCacheId | null;
    /** The status of Query String Sort */
    value?: EditResponseActionsItemSortQueryStringForCacheValue | null;
}
export type EditResponseActionsItemSSLId = "ssl";
export type EditResponseActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export interface EditResponseActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: EditResponseActionsItemSSLId | null;
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: EditResponseActionsItemSSLValue | null;
}
export type EditResponseActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export type EditResponseActionsItemTrueClientIPHeaderValue = "on" | "off";
export interface EditResponseActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: EditResponseActionsItemTrueClientIPHeaderId | null;
    /** The status of True Client IP Header. */
    value?: EditResponseActionsItemTrueClientIPHeaderValue | null;
}
export type EditResponseActionsItemWAFId = "waf";
export type EditResponseActionsItemWAFValue = "on" | "off";
export interface EditResponseActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). You cannot enable or disable individual WAF managed rules via Page Rules. */
    id?: EditResponseActionsItemWAFId | null;
    /** The status of WAF managed rules (previous version). */
    value?: EditResponseActionsItemWAFValue | null;
}
export type EditResponseActionsItem = EditResponseActionsItemAlwaysUseHTTPS | EditResponseActionsItemAutomaticHTTPSRewrites | EditResponseActionsItemBrowserCacheTTL | EditResponseActionsItemBrowserCheck | EditResponseActionsItemBypassCacheOnCookie | EditResponseActionsItemCacheByDeviceType | EditResponseActionsItemCacheDeceptionArmor | EditResponseActionsItemCacheKeyFields | EditResponseActionsItemCacheLevel | EditResponseActionsItemCacheOnCookie | EditResponseActionsItemCacheTTLByStatus | EditResponseActionsItemDisableApps | EditResponseActionsItemDisablePerformance | EditResponseActionsItemDisableSecurity | EditResponseActionsItemDisableZaraz | EditResponseActionsItemEdgeCacheTTL | EditResponseActionsItemEmailObfuscation | EditResponseActionsItemExplicitCacheControl | EditResponseActionsItemForwardingURL | EditResponseActionsItemHostHeaderOverride | EditResponseActionsItemIPGeolocation | EditResponseActionsItemMirage | EditResponseActionsItemOpportunisticEncryption | EditResponseActionsItemOriginErrorPagePassThru | EditResponseActionsItemPolish | EditResponseActionsItemResolveOverride | EditResponseActionsItemRespectStrongEtag | EditResponseActionsItemResponseBuffering | EditResponseActionsItemRocketLoader | EditResponseActionsItemSecurityLevel | EditResponseActionsItemSortQueryStringForCache | EditResponseActionsItemSSL | EditResponseActionsItemTrueClientIPHeader | EditResponseActionsItemWAF;
export type EditResponseActionsList = Array<EditResponseActionsItem>;
export type EditResponseStatus = "active" | "disabled";
export type EditResponseTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export interface EditResponseTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: EditResponseTargetsItemConstraintOperator;
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export type EditResponseTargetsItemTarget = "url";
export interface EditResponseTargetsItem {
    /** String constraint. */
    constraint?: EditResponseTargetsItemConstraint | null;
    /** A target based on the URL of the request. */
    target?: EditResponseTargetsItemTarget | null;
}
export type EditResponseTargetsList = Array<EditResponseTargetsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchPageRuleResponse {
    /** Identifier. */
    id: string;
    /** The set of actions to perform if the targets of this rule match the request. Actions can redirect to another URL or override settings, but not both. */
    actions: EditResponseActionsList;
    /** The timestamp of when the Page Rule was created. */
    createdOn: string;
    /** The timestamp of when the Page Rule was last modified. */
    modifiedOn: string;
    /** The priority of the rule, used to define which Page Rule is processed over another. A higher number indicates a higher priority. For example, if you have a catch-all Page Rule (rule A: `/images/*`) but want a more specific Page Rule to take precedence (rule B: `/images/special/*`), specify a higher priority for rule B so it overrides rule A. */
    priority: number;
    /** The status of the Page Rule. */
    status: EditResponseStatus;
    /** The rule targets to evaluate on each request. */
    targets: EditResponseTargetsList;
}
export type UpdateRequestActionsItemAlwaysUseHTTPSId = "always_use_https";
export interface UpdateRequestActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to` https://` through a 301 redirect. */
    id?: UpdateRequestActionsItemAlwaysUseHTTPSId | (string & {});
}
export type UpdateRequestActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export type UpdateRequestActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export interface UpdateRequestActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: UpdateRequestActionsItemAutomaticHTTPSRewritesId | (string & {});
    /** The status of Automatic HTTPS Rewrites. */
    value?: UpdateRequestActionsItemAutomaticHTTPSRewritesValue | (string & {});
}
export type UpdateRequestActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export interface UpdateRequestActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: UpdateRequestActionsItemBrowserCacheTTLId | (string & {});
    /** The number of seconds to cache resources for. Setting this to 0 enables "Respect Existing Headers". */
    value?: number;
}
export type UpdateRequestActionsItemBrowserCheckId = "browser_check";
export type UpdateRequestActionsItemBrowserCheckValue = "on" | "off";
export interface UpdateRequestActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with spammers and certain bots. */
    id?: UpdateRequestActionsItemBrowserCheckId | (string & {});
    /** The status of Browser Integrity Check. */
    value?: UpdateRequestActionsItemBrowserCheckValue | (string & {});
}
export type UpdateRequestActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export interface UpdateRequestActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular expression matches against a cookie name present in the request. */
    id?: UpdateRequestActionsItemBypassCacheOnCookieId | (string & {});
    /** The regular expression to use for matching cookie names in the request. Refer to [Bypass Cache on Cookie setting](https://developers.cloudflare.com/rules/page-rules/reference/additional-reference/#bypass-cache-on-cookie-setting) to learn about limited regular expression support. */
    value?: string;
}
export type UpdateRequestActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export type UpdateRequestActionsItemCacheByDeviceTypeValue = "on" | "off";
export interface UpdateRequestActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: UpdateRequestActionsItemCacheByDeviceTypeId | (string & {});
    /** The status of Cache By Device Type. */
    value?: UpdateRequestActionsItemCacheByDeviceTypeValue | (string & {});
}
export type UpdateRequestActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export type UpdateRequestActionsItemCacheDeceptionArmorValue = "on" | "off";
export interface UpdateRequestActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static assets to be cached. This setting verifies that the URL's extension matches the returned `Content-Type`. */
    id?: UpdateRequestActionsItemCacheDeceptionArmorId | (string & {});
    /** The status of Cache Deception Armor. */
    value?: UpdateRequestActionsItemCacheDeceptionArmorValue | (string & {});
}
export type UpdateRequestActionsItemCacheKeyFieldsId = "cache_key_fields";
export type UpdateRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export type UpdateRequestActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export interface UpdateRequestActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without including their actual values. */
    checkPresence?: UpdateRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList;
    /** A list of cookies to include. */
    include?: UpdateRequestActionsItemCacheKeyFieldsValueCookieIncludeList;
}
export type UpdateRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export type UpdateRequestActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export type UpdateRequestActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export interface UpdateRequestActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without including their actual values. */
    checkPresence?: UpdateRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList;
    /** A list of headers to ignore. */
    exclude?: UpdateRequestActionsItemCacheKeyFieldsValueHeaderExcludeList;
    /** A list of headers to include. */
    include?: UpdateRequestActionsItemCacheKeyFieldsValueHeaderIncludeList;
}
export type UpdateRequestActionsItemCacheKeyFieldsValueHost = CreateRequestActionsItemCacheKeyFieldsValueHost;
export type UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export type UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export type UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExclude = UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | (string & {}) | UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export type UpdateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export type UpdateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export type UpdateRequestActionsItemCacheKeyFieldsValueQueryStringInclude = UpdateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | (string & {}) | UpdateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export interface UpdateRequestActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExclude;
    /** Include all query string parameters. */
    include?: UpdateRequestActionsItemCacheKeyFieldsValueQueryStringInclude;
}
export type UpdateRequestActionsItemCacheKeyFieldsValueUser = CreateRequestActionsItemCacheKeyFieldsValueUser;
export interface UpdateRequestActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: UpdateRequestActionsItemCacheKeyFieldsValueCookie;
    /** Controls which headers go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    header?: UpdateRequestActionsItemCacheKeyFieldsValueHeader;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateRequestActionsItemCacheKeyFieldsValueHost;
    /** Controls which URL query string parameters go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    queryString?: UpdateRequestActionsItemCacheKeyFieldsValueQueryString;
    /** Feature fields to add features about the end-user (client) into the Cache Key. */
    user?: CreateRequestActionsItemCacheKeyFieldsValueUser;
}
export interface UpdateRequestActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which resources to cache. This allows customers to determine what to cache based on something other than just the URL. */
    id?: UpdateRequestActionsItemCacheKeyFieldsId | (string & {});
    value?: UpdateRequestActionsItemCacheKeyFieldsValue;
}
export type UpdateRequestActionsItemCacheLevelId = "cache_level";
export type UpdateRequestActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export interface UpdateRequestActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: UpdateRequestActionsItemCacheLevelId | (string & {});
    /** - `bypass`: Cloudflare does not cache. - `basic`: Delivers resources from cache when there is no query string. - `simplified`: Delivers the same resource to everyone independent of the query string. - `aggressive`: Caches all static content that has a query string. - `cache_everything`: Treats all content as static and caches all file types beyond the [Cloudflare default cached content](https://developers.cloudflare.com/cache/concepts/default-cache-behavior/#default-cached-file-extensions). */
    value?: UpdateRequestActionsItemCacheLevelValue | (string & {});
}
export type UpdateRequestActionsItemCacheOnCookieId = "cache_on_cookie";
export interface UpdateRequestActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a regular expression match against a cookie name. */
    id?: UpdateRequestActionsItemCacheOnCookieId | (string & {});
    /** The regular expression to use for matching cookie names in the request. */
    value?: string;
}
export type UpdateRequestActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export type UpdateRequestActionsItemCacheTTLByStatusValueValueCase0 = "no-cache" | "no-store";
export type UpdateRequestActionsItemCacheTTLByStatusValueValue = number | UpdateRequestActionsItemCacheTTLByStatusValueValueCase0 | (string & {});
export type UpdateRequestActionsItemCacheTTLByStatusValueMap = {
    [key: string]: UpdateRequestActionsItemCacheTTLByStatusValueValue | undefined;
};
export interface UpdateRequestActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the response status from the origin web server. Cache TTL refers to the duration of a resource in the Cloudflare network before being marked as stale or discarded from cache. Status codes are returned by a resource's origin. Setting cache TTL based on response status overrides the default cache behavior (standard caching) for static files and overrides cache instructions sent by the origin web server. To cache non-static assets, set a Cache Level of Cache Everything using a Page Rule. Setting no-store Cache-Control or a low TTL (using `max-age`/`s-maxage`) increases requests to origin web servers and decreases performance. */
    id?: UpdateRequestActionsItemCacheTTLByStatusId | (string & {});
    /** A JSON object containing status codes and their corresponding TTLs. Each key-value pair in the cache TTL by status cache rule has the following syntax */
    value?: UpdateRequestActionsItemCacheTTLByStatusValueMap;
}
export type UpdateRequestActionsItemDisableAppsId = "disable_apps";
export interface UpdateRequestActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) (deprecated). */
    id?: UpdateRequestActionsItemDisableAppsId | (string & {});
}
export type UpdateRequestActionsItemDisablePerformanceId = "disable_performance";
export interface UpdateRequestActionsItemDisablePerformance {
    /** Turn off [Rocket Loader](https://developers.cloudflare.com/speed/optimization/content/rocket-loader/), and [Polish](https://developers.cloudflare.com/images/polish/). */
    id?: UpdateRequestActionsItemDisablePerformanceId | (string & {});
}
export type UpdateRequestActionsItemDisableSecurityId = "disable_security";
export interface UpdateRequestActionsItemDisableSecurity {
    /** Turn off [Email Obfuscation](https://developers.cloudflare.com/waf/tools/scrape-shield/email-address-obfuscation/), [Rate Limiting (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-rate-limiting/), [Scrape Shield](https://developers.cloudflare.com/waf/tools/scrape-shield/), [URL (Zone) Lockdown](https://developers.cloudflare.com/waf/tools/zone-lockdown/), and [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: UpdateRequestActionsItemDisableSecurityId | (string & {});
}
export type UpdateRequestActionsItemDisableZarazId = "disable_zaraz";
export interface UpdateRequestActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: UpdateRequestActionsItemDisableZarazId | (string & {});
}
export type UpdateRequestActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export interface UpdateRequestActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global network. *Edge Cache TTL* is not visible in response headers. */
    id?: UpdateRequestActionsItemEdgeCacheTTLId | (string & {});
    value?: number;
}
export type UpdateRequestActionsItemEmailObfuscationId = "email_obfuscation";
export type UpdateRequestActionsItemEmailObfuscationValue = "on" | "off";
export interface UpdateRequestActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: UpdateRequestActionsItemEmailObfuscationId | (string & {});
    /** The status of Email Obfuscation. */
    value?: UpdateRequestActionsItemEmailObfuscationValue | (string & {});
}
export type UpdateRequestActionsItemExplicitCacheControlId = "explicit_cache_control";
export type UpdateRequestActionsItemExplicitCacheControlValue = "on" | "off";
export interface UpdateRequestActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and Business domains and disabled by default for Enterprise domains. */
    id?: UpdateRequestActionsItemExplicitCacheControlId | (string & {});
    /** The status of Origin Cache Control. */
    value?: UpdateRequestActionsItemExplicitCacheControlValue | (string & {});
}
export type UpdateRequestActionsItemForwardingURLId = "forwarding_url";
export type UpdateRequestActionsItemForwardingURLValueStatusCode = 301 | 302;
export interface UpdateRequestActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent redirect. 302 is a temporary redirect. */
    statusCode?: UpdateRequestActionsItemForwardingURLValueStatusCode | (number & {});
    /** The URL to redirect the request to. Notes: ${num} refers to the position of '*' in the constraint value. */
    url?: string;
}
export interface UpdateRequestActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer to [Wildcard matching and referencing](https://developers.cloudflare.com/rules/page-rules/reference/wildcard-matching/). */
    id?: UpdateRequestActionsItemForwardingURLId | (string & {});
    value?: UpdateRequestActionsItemForwardingURLValue;
}
export type UpdateRequestActionsItemHostHeaderOverrideId = "host_header_override";
export interface UpdateRequestActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: UpdateRequestActionsItemHostHeaderOverrideId | (string & {});
    /** The hostname to use in the `Host` header */
    value?: string;
}
export type UpdateRequestActionsItemIPGeolocationId = "ip_geolocation";
export type UpdateRequestActionsItemIPGeolocationValue = "on" | "off";
export interface UpdateRequestActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: UpdateRequestActionsItemIPGeolocationId | (string & {});
    /** The status of adding the IP Geolocation Header. */
    value?: UpdateRequestActionsItemIPGeolocationValue | (string & {});
}
export type UpdateRequestActionsItemMirageId = "mirage";
export type UpdateRequestActionsItemMirageValue = "on" | "off";
export interface UpdateRequestActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. It can accelerate loading of image-heavy websites on very slow mobile connections and HTTP/1. */
    id?: UpdateRequestActionsItemMirageId | (string & {});
    /** The status of Mirage. */
    value?: UpdateRequestActionsItemMirageValue | (string & {});
}
export type UpdateRequestActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export type UpdateRequestActionsItemOpportunisticEncryptionValue = "on" | "off";
export interface UpdateRequestActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. It's not a substitute for HTTPS, but provides additional security for otherwise vulnerable requests. */
    id?: UpdateRequestActionsItemOpportunisticEncryptionId | (string & {});
    /** The status of Opportunistic Encryption. */
    value?: UpdateRequestActionsItemOpportunisticEncryptionValue | (string & {});
}
export type UpdateRequestActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export type UpdateRequestActionsItemOriginErrorPagePassThruValue = "on" | "off";
export interface UpdateRequestActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: UpdateRequestActionsItemOriginErrorPagePassThruId | (string & {});
    /** The status of Origin Error Page Passthru. */
    value?: UpdateRequestActionsItemOriginErrorPagePassThruValue | (string & {});
}
export type UpdateRequestActionsItemPolishId = "polish";
export type UpdateRequestActionsItemPolishValue = "off" | "lossless" | "lossy";
export interface UpdateRequestActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: UpdateRequestActionsItemPolishId | (string & {});
    /** The level of Polish you want applied to your origin. */
    value?: UpdateRequestActionsItemPolishValue | (string & {});
}
export type UpdateRequestActionsItemResolveOverrideId = "resolve_override";
export interface UpdateRequestActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: UpdateRequestActionsItemResolveOverrideId | (string & {});
    /** The origin address you want to override with. */
    value?: string;
}
export type UpdateRequestActionsItemRespectStrongEtagId = "respect_strong_etag";
export type UpdateRequestActionsItemRespectStrongEtagValue = "on" | "off";
export interface UpdateRequestActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the Cloudflare cache and the origin server. */
    id?: UpdateRequestActionsItemRespectStrongEtagId | (string & {});
    /** The status of Respect Strong ETags */
    value?: UpdateRequestActionsItemRespectStrongEtagValue | (string & {});
}
export type UpdateRequestActionsItemResponseBufferingId = "response_buffering";
export type UpdateRequestActionsItemResponseBufferingValue = "on" | "off";
export interface UpdateRequestActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file from the origin server before forwarding it to the site visitor. By default, Cloudflare sends packets to the client as they arrive from the origin server. */
    id?: UpdateRequestActionsItemResponseBufferingId | (string & {});
    /** The status of Response Buffering */
    value?: UpdateRequestActionsItemResponseBufferingValue | (string & {});
}
export type UpdateRequestActionsItemRocketLoaderId = "rocket_loader";
export type UpdateRequestActionsItemRocketLoaderValue = "on" | "off";
export interface UpdateRequestActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: UpdateRequestActionsItemRocketLoaderId | (string & {});
    /** The status of Rocket Loader */
    value?: UpdateRequestActionsItemRocketLoaderValue | (string & {});
}
export type UpdateRequestActionsItemSecurityLevelId = "security_level";
export type UpdateRequestActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface UpdateRequestActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: UpdateRequestActionsItemSecurityLevelId | (string & {});
    value?: UpdateRequestActionsItemSecurityLevelValue | (string & {});
}
export type UpdateRequestActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export type UpdateRequestActionsItemSortQueryStringForCacheValue = "on" | "off";
export interface UpdateRequestActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: UpdateRequestActionsItemSortQueryStringForCacheId | (string & {});
    /** The status of Query String Sort */
    value?: UpdateRequestActionsItemSortQueryStringForCacheValue | (string & {});
}
export type UpdateRequestActionsItemSSLId = "ssl";
export type UpdateRequestActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export interface UpdateRequestActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: UpdateRequestActionsItemSSLId | (string & {});
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: UpdateRequestActionsItemSSLValue | (string & {});
}
export type UpdateRequestActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export type UpdateRequestActionsItemTrueClientIPHeaderValue = "on" | "off";
export interface UpdateRequestActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: UpdateRequestActionsItemTrueClientIPHeaderId | (string & {});
    /** The status of True Client IP Header. */
    value?: UpdateRequestActionsItemTrueClientIPHeaderValue | (string & {});
}
export type UpdateRequestActionsItemWAFId = "waf";
export type UpdateRequestActionsItemWAFValue = "on" | "off";
export interface UpdateRequestActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). You cannot enable or disable individual WAF managed rules via Page Rules. */
    id?: UpdateRequestActionsItemWAFId | (string & {});
    /** The status of WAF managed rules (previous version). */
    value?: UpdateRequestActionsItemWAFValue | (string & {});
}
export type UpdateRequestActionsItem = UpdateRequestActionsItemAlwaysUseHTTPS | UpdateRequestActionsItemAutomaticHTTPSRewrites | UpdateRequestActionsItemBrowserCacheTTL | UpdateRequestActionsItemBrowserCheck | UpdateRequestActionsItemBypassCacheOnCookie | UpdateRequestActionsItemCacheByDeviceType | UpdateRequestActionsItemCacheDeceptionArmor | UpdateRequestActionsItemCacheKeyFields | UpdateRequestActionsItemCacheLevel | UpdateRequestActionsItemCacheOnCookie | UpdateRequestActionsItemCacheTTLByStatus | UpdateRequestActionsItemDisableApps | UpdateRequestActionsItemDisablePerformance | UpdateRequestActionsItemDisableSecurity | UpdateRequestActionsItemDisableZaraz | UpdateRequestActionsItemEdgeCacheTTL | UpdateRequestActionsItemEmailObfuscation | UpdateRequestActionsItemExplicitCacheControl | UpdateRequestActionsItemForwardingURL | UpdateRequestActionsItemHostHeaderOverride | UpdateRequestActionsItemIPGeolocation | UpdateRequestActionsItemMirage | UpdateRequestActionsItemOpportunisticEncryption | UpdateRequestActionsItemOriginErrorPagePassThru | UpdateRequestActionsItemPolish | UpdateRequestActionsItemResolveOverride | UpdateRequestActionsItemRespectStrongEtag | UpdateRequestActionsItemResponseBuffering | UpdateRequestActionsItemRocketLoader | UpdateRequestActionsItemSecurityLevel | UpdateRequestActionsItemSortQueryStringForCache | UpdateRequestActionsItemSSL | UpdateRequestActionsItemTrueClientIPHeader | UpdateRequestActionsItemWAF;
export type UpdateRequestActionsList = Array<UpdateRequestActionsItem>;
export type UpdateRequestTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export interface UpdateRequestTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: UpdateRequestTargetsItemConstraintOperator | (string & {});
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export type UpdateRequestTargetsItemTarget = "url";
export interface UpdateRequestTargetsItem {
    /** String constraint. */
    constraint?: UpdateRequestTargetsItemConstraint;
    /** A target based on the URL of the request. */
    target?: UpdateRequestTargetsItemTarget | (string & {});
}
export type UpdateRequestTargetsList = Array<UpdateRequestTargetsItem>;
export type UpdateRequestStatus = "active" | "disabled";
export interface UpdatePageRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    pageruleId: string;
    /** The set of actions to perform if the targets of this rule match the request. Actions can redirect to another URL or override settings, but not both. */
    actions: UpdateRequestActionsList;
    /** The rule targets to evaluate on each request. */
    targets: UpdateRequestTargetsList;
    /** The priority of the rule, used to define which Page Rule is processed over another. A higher number indicates a higher priority. For example, if you have a catch-all Page Rule (rule A: `/images/*`) but want a more specific Page Rule to take precedence (rule B: `/images/special/*`), specify a higher priority for rule B so it overrides rule A. */
    priority?: number;
    /** The status of the Page Rule. */
    status?: UpdateRequestStatus | (string & {});
}
export type UpdateResponseActionsItemAlwaysUseHTTPSId = "always_use_https";
export interface UpdateResponseActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to` https://` through a 301 redirect. */
    id?: UpdateResponseActionsItemAlwaysUseHTTPSId | null;
}
export type UpdateResponseActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export type UpdateResponseActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export interface UpdateResponseActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: UpdateResponseActionsItemAutomaticHTTPSRewritesId | null;
    /** The status of Automatic HTTPS Rewrites. */
    value?: UpdateResponseActionsItemAutomaticHTTPSRewritesValue | null;
}
export type UpdateResponseActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export interface UpdateResponseActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: UpdateResponseActionsItemBrowserCacheTTLId | null;
    /** The number of seconds to cache resources for. Setting this to 0 enables "Respect Existing Headers". */
    value?: number | null;
}
export type UpdateResponseActionsItemBrowserCheckId = "browser_check";
export type UpdateResponseActionsItemBrowserCheckValue = "on" | "off";
export interface UpdateResponseActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with spammers and certain bots. */
    id?: UpdateResponseActionsItemBrowserCheckId | null;
    /** The status of Browser Integrity Check. */
    value?: UpdateResponseActionsItemBrowserCheckValue | null;
}
export type UpdateResponseActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export interface UpdateResponseActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular expression matches against a cookie name present in the request. */
    id?: UpdateResponseActionsItemBypassCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the request. Refer to [Bypass Cache on Cookie setting](https://developers.cloudflare.com/rules/page-rules/reference/additional-reference/#bypass-cache-on-cookie-setting) to learn about limited regular expression support. */
    value?: string | null;
}
export type UpdateResponseActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export type UpdateResponseActionsItemCacheByDeviceTypeValue = "on" | "off";
export interface UpdateResponseActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: UpdateResponseActionsItemCacheByDeviceTypeId | null;
    /** The status of Cache By Device Type. */
    value?: UpdateResponseActionsItemCacheByDeviceTypeValue | null;
}
export type UpdateResponseActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export type UpdateResponseActionsItemCacheDeceptionArmorValue = "on" | "off";
export interface UpdateResponseActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static assets to be cached. This setting verifies that the URL's extension matches the returned `Content-Type`. */
    id?: UpdateResponseActionsItemCacheDeceptionArmorId | null;
    /** The status of Cache Deception Armor. */
    value?: UpdateResponseActionsItemCacheDeceptionArmorValue | null;
}
export type UpdateResponseActionsItemCacheKeyFieldsId = "cache_key_fields";
export type UpdateResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export type UpdateResponseActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export interface UpdateResponseActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without including their actual values. */
    checkPresence?: UpdateResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList | null;
    /** A list of cookies to include. */
    include?: UpdateResponseActionsItemCacheKeyFieldsValueCookieIncludeList | null;
}
export type UpdateResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export type UpdateResponseActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export type UpdateResponseActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export interface UpdateResponseActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without including their actual values. */
    checkPresence?: UpdateResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList | null;
    /** A list of headers to ignore. */
    exclude?: UpdateResponseActionsItemCacheKeyFieldsValueHeaderExcludeList | null;
    /** A list of headers to include. */
    include?: UpdateResponseActionsItemCacheKeyFieldsValueHeaderIncludeList | null;
}
export type UpdateResponseActionsItemCacheKeyFieldsValueHost = CreateResponseActionsItemCacheKeyFieldsValueHost;
export type UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export type UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export type UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExclude = UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export type UpdateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export type UpdateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export type UpdateResponseActionsItemCacheKeyFieldsValueQueryStringInclude = UpdateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | UpdateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export interface UpdateResponseActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExclude | null;
    /** Include all query string parameters. */
    include?: UpdateResponseActionsItemCacheKeyFieldsValueQueryStringInclude | null;
}
export type UpdateResponseActionsItemCacheKeyFieldsValueUser = CreateResponseActionsItemCacheKeyFieldsValueUser;
export interface UpdateResponseActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: UpdateResponseActionsItemCacheKeyFieldsValueCookie | null;
    /** Controls which headers go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    header?: UpdateResponseActionsItemCacheKeyFieldsValueHeader | null;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateResponseActionsItemCacheKeyFieldsValueHost | null;
    /** Controls which URL query string parameters go into the Cache Key. Exactly one of `include` or `exclude` is expected. */
    queryString?: UpdateResponseActionsItemCacheKeyFieldsValueQueryString | null;
    /** Feature fields to add features about the end-user (client) into the Cache Key. */
    user?: CreateResponseActionsItemCacheKeyFieldsValueUser | null;
}
export interface UpdateResponseActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which resources to cache. This allows customers to determine what to cache based on something other than just the URL. */
    id?: UpdateResponseActionsItemCacheKeyFieldsId | null;
    value?: UpdateResponseActionsItemCacheKeyFieldsValue | null;
}
export type UpdateResponseActionsItemCacheLevelId = "cache_level";
export type UpdateResponseActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export interface UpdateResponseActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: UpdateResponseActionsItemCacheLevelId | null;
    /** - `bypass`: Cloudflare does not cache. - `basic`: Delivers resources from cache when there is no query string. - `simplified`: Delivers the same resource to everyone independent of the query string. - `aggressive`: Caches all static content that has a query string. - `cache_everything`: Treats all content as static and caches all file types beyond the [Cloudflare default cached content](https://developers.cloudflare.com/cache/concepts/default-cache-behavior/#default-cached-file-extensions). */
    value?: UpdateResponseActionsItemCacheLevelValue | null;
}
export type UpdateResponseActionsItemCacheOnCookieId = "cache_on_cookie";
export interface UpdateResponseActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a regular expression match against a cookie name. */
    id?: UpdateResponseActionsItemCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the request. */
    value?: string | null;
}
export type UpdateResponseActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export type UpdateResponseActionsItemCacheTTLByStatusValueValueCase0 = "no-cache" | "no-store";
export type UpdateResponseActionsItemCacheTTLByStatusValueValue = number | UpdateResponseActionsItemCacheTTLByStatusValueValueCase0;
export type UpdateResponseActionsItemCacheTTLByStatusValueMap = {
    [key: string]: UpdateResponseActionsItemCacheTTLByStatusValueValue | undefined;
};
export interface UpdateResponseActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the response status from the origin web server. Cache TTL refers to the duration of a resource in the Cloudflare network before being marked as stale or discarded from cache. Status codes are returned by a resource's origin. Setting cache TTL based on response status overrides the default cache behavior (standard caching) for static files and overrides cache instructions sent by the origin web server. To cache non-static assets, set a Cache Level of Cache Everything using a Page Rule. Setting no-store Cache-Control or a low TTL (using `max-age`/`s-maxage`) increases requests to origin web servers and decreases performance. */
    id?: UpdateResponseActionsItemCacheTTLByStatusId | null;
    /** A JSON object containing status codes and their corresponding TTLs. Each key-value pair in the cache TTL by status cache rule has the following syntax */
    value?: UpdateResponseActionsItemCacheTTLByStatusValueMap | null;
}
export type UpdateResponseActionsItemDisableAppsId = "disable_apps";
export interface UpdateResponseActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) (deprecated). */
    id?: UpdateResponseActionsItemDisableAppsId | null;
}
export type UpdateResponseActionsItemDisablePerformanceId = "disable_performance";
export interface UpdateResponseActionsItemDisablePerformance {
    /** Turn off [Rocket Loader](https://developers.cloudflare.com/speed/optimization/content/rocket-loader/), and [Polish](https://developers.cloudflare.com/images/polish/). */
    id?: UpdateResponseActionsItemDisablePerformanceId | null;
}
export type UpdateResponseActionsItemDisableSecurityId = "disable_security";
export interface UpdateResponseActionsItemDisableSecurity {
    /** Turn off [Email Obfuscation](https://developers.cloudflare.com/waf/tools/scrape-shield/email-address-obfuscation/), [Rate Limiting (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-rate-limiting/), [Scrape Shield](https://developers.cloudflare.com/waf/tools/scrape-shield/), [URL (Zone) Lockdown](https://developers.cloudflare.com/waf/tools/zone-lockdown/), and [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: UpdateResponseActionsItemDisableSecurityId | null;
}
export type UpdateResponseActionsItemDisableZarazId = "disable_zaraz";
export interface UpdateResponseActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: UpdateResponseActionsItemDisableZarazId | null;
}
export type UpdateResponseActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export interface UpdateResponseActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global network. *Edge Cache TTL* is not visible in response headers. */
    id?: UpdateResponseActionsItemEdgeCacheTTLId | null;
    value?: number | null;
}
export type UpdateResponseActionsItemEmailObfuscationId = "email_obfuscation";
export type UpdateResponseActionsItemEmailObfuscationValue = "on" | "off";
export interface UpdateResponseActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: UpdateResponseActionsItemEmailObfuscationId | null;
    /** The status of Email Obfuscation. */
    value?: UpdateResponseActionsItemEmailObfuscationValue | null;
}
export type UpdateResponseActionsItemExplicitCacheControlId = "explicit_cache_control";
export type UpdateResponseActionsItemExplicitCacheControlValue = "on" | "off";
export interface UpdateResponseActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and Business domains and disabled by default for Enterprise domains. */
    id?: UpdateResponseActionsItemExplicitCacheControlId | null;
    /** The status of Origin Cache Control. */
    value?: UpdateResponseActionsItemExplicitCacheControlValue | null;
}
export type UpdateResponseActionsItemForwardingURLId = "forwarding_url";
export type UpdateResponseActionsItemForwardingURLValueStatusCode = 301 | 302;
export interface UpdateResponseActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent redirect. 302 is a temporary redirect. */
    statusCode?: UpdateResponseActionsItemForwardingURLValueStatusCode | null;
    /** The URL to redirect the request to. Notes: ${num} refers to the position of '*' in the constraint value. */
    url?: string | null;
}
export interface UpdateResponseActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer to [Wildcard matching and referencing](https://developers.cloudflare.com/rules/page-rules/reference/wildcard-matching/). */
    id?: UpdateResponseActionsItemForwardingURLId | null;
    value?: UpdateResponseActionsItemForwardingURLValue | null;
}
export type UpdateResponseActionsItemHostHeaderOverrideId = "host_header_override";
export interface UpdateResponseActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: UpdateResponseActionsItemHostHeaderOverrideId | null;
    /** The hostname to use in the `Host` header */
    value?: string | null;
}
export type UpdateResponseActionsItemIPGeolocationId = "ip_geolocation";
export type UpdateResponseActionsItemIPGeolocationValue = "on" | "off";
export interface UpdateResponseActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: UpdateResponseActionsItemIPGeolocationId | null;
    /** The status of adding the IP Geolocation Header. */
    value?: UpdateResponseActionsItemIPGeolocationValue | null;
}
export type UpdateResponseActionsItemMirageId = "mirage";
export type UpdateResponseActionsItemMirageValue = "on" | "off";
export interface UpdateResponseActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. It can accelerate loading of image-heavy websites on very slow mobile connections and HTTP/1. */
    id?: UpdateResponseActionsItemMirageId | null;
    /** The status of Mirage. */
    value?: UpdateResponseActionsItemMirageValue | null;
}
export type UpdateResponseActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export type UpdateResponseActionsItemOpportunisticEncryptionValue = "on" | "off";
export interface UpdateResponseActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. It's not a substitute for HTTPS, but provides additional security for otherwise vulnerable requests. */
    id?: UpdateResponseActionsItemOpportunisticEncryptionId | null;
    /** The status of Opportunistic Encryption. */
    value?: UpdateResponseActionsItemOpportunisticEncryptionValue | null;
}
export type UpdateResponseActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export type UpdateResponseActionsItemOriginErrorPagePassThruValue = "on" | "off";
export interface UpdateResponseActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: UpdateResponseActionsItemOriginErrorPagePassThruId | null;
    /** The status of Origin Error Page Passthru. */
    value?: UpdateResponseActionsItemOriginErrorPagePassThruValue | null;
}
export type UpdateResponseActionsItemPolishId = "polish";
export type UpdateResponseActionsItemPolishValue = "off" | "lossless" | "lossy";
export interface UpdateResponseActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: UpdateResponseActionsItemPolishId | null;
    /** The level of Polish you want applied to your origin. */
    value?: UpdateResponseActionsItemPolishValue | null;
}
export type UpdateResponseActionsItemResolveOverrideId = "resolve_override";
export interface UpdateResponseActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: UpdateResponseActionsItemResolveOverrideId | null;
    /** The origin address you want to override with. */
    value?: string | null;
}
export type UpdateResponseActionsItemRespectStrongEtagId = "respect_strong_etag";
export type UpdateResponseActionsItemRespectStrongEtagValue = "on" | "off";
export interface UpdateResponseActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the Cloudflare cache and the origin server. */
    id?: UpdateResponseActionsItemRespectStrongEtagId | null;
    /** The status of Respect Strong ETags */
    value?: UpdateResponseActionsItemRespectStrongEtagValue | null;
}
export type UpdateResponseActionsItemResponseBufferingId = "response_buffering";
export type UpdateResponseActionsItemResponseBufferingValue = "on" | "off";
export interface UpdateResponseActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file from the origin server before forwarding it to the site visitor. By default, Cloudflare sends packets to the client as they arrive from the origin server. */
    id?: UpdateResponseActionsItemResponseBufferingId | null;
    /** The status of Response Buffering */
    value?: UpdateResponseActionsItemResponseBufferingValue | null;
}
export type UpdateResponseActionsItemRocketLoaderId = "rocket_loader";
export type UpdateResponseActionsItemRocketLoaderValue = "on" | "off";
export interface UpdateResponseActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: UpdateResponseActionsItemRocketLoaderId | null;
    /** The status of Rocket Loader */
    value?: UpdateResponseActionsItemRocketLoaderValue | null;
}
export type UpdateResponseActionsItemSecurityLevelId = "security_level";
export type UpdateResponseActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface UpdateResponseActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: UpdateResponseActionsItemSecurityLevelId | null;
    value?: UpdateResponseActionsItemSecurityLevelValue | null;
}
export type UpdateResponseActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export type UpdateResponseActionsItemSortQueryStringForCacheValue = "on" | "off";
export interface UpdateResponseActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: UpdateResponseActionsItemSortQueryStringForCacheId | null;
    /** The status of Query String Sort */
    value?: UpdateResponseActionsItemSortQueryStringForCacheValue | null;
}
export type UpdateResponseActionsItemSSLId = "ssl";
export type UpdateResponseActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export interface UpdateResponseActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: UpdateResponseActionsItemSSLId | null;
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: UpdateResponseActionsItemSSLValue | null;
}
export type UpdateResponseActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export type UpdateResponseActionsItemTrueClientIPHeaderValue = "on" | "off";
export interface UpdateResponseActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: UpdateResponseActionsItemTrueClientIPHeaderId | null;
    /** The status of True Client IP Header. */
    value?: UpdateResponseActionsItemTrueClientIPHeaderValue | null;
}
export type UpdateResponseActionsItemWAFId = "waf";
export type UpdateResponseActionsItemWAFValue = "on" | "off";
export interface UpdateResponseActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). You cannot enable or disable individual WAF managed rules via Page Rules. */
    id?: UpdateResponseActionsItemWAFId | null;
    /** The status of WAF managed rules (previous version). */
    value?: UpdateResponseActionsItemWAFValue | null;
}
export type UpdateResponseActionsItem = UpdateResponseActionsItemAlwaysUseHTTPS | UpdateResponseActionsItemAutomaticHTTPSRewrites | UpdateResponseActionsItemBrowserCacheTTL | UpdateResponseActionsItemBrowserCheck | UpdateResponseActionsItemBypassCacheOnCookie | UpdateResponseActionsItemCacheByDeviceType | UpdateResponseActionsItemCacheDeceptionArmor | UpdateResponseActionsItemCacheKeyFields | UpdateResponseActionsItemCacheLevel | UpdateResponseActionsItemCacheOnCookie | UpdateResponseActionsItemCacheTTLByStatus | UpdateResponseActionsItemDisableApps | UpdateResponseActionsItemDisablePerformance | UpdateResponseActionsItemDisableSecurity | UpdateResponseActionsItemDisableZaraz | UpdateResponseActionsItemEdgeCacheTTL | UpdateResponseActionsItemEmailObfuscation | UpdateResponseActionsItemExplicitCacheControl | UpdateResponseActionsItemForwardingURL | UpdateResponseActionsItemHostHeaderOverride | UpdateResponseActionsItemIPGeolocation | UpdateResponseActionsItemMirage | UpdateResponseActionsItemOpportunisticEncryption | UpdateResponseActionsItemOriginErrorPagePassThru | UpdateResponseActionsItemPolish | UpdateResponseActionsItemResolveOverride | UpdateResponseActionsItemRespectStrongEtag | UpdateResponseActionsItemResponseBuffering | UpdateResponseActionsItemRocketLoader | UpdateResponseActionsItemSecurityLevel | UpdateResponseActionsItemSortQueryStringForCache | UpdateResponseActionsItemSSL | UpdateResponseActionsItemTrueClientIPHeader | UpdateResponseActionsItemWAF;
export type UpdateResponseActionsList = Array<UpdateResponseActionsItem>;
export type UpdateResponseStatus = "active" | "disabled";
export type UpdateResponseTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export interface UpdateResponseTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: UpdateResponseTargetsItemConstraintOperator;
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export type UpdateResponseTargetsItemTarget = "url";
export interface UpdateResponseTargetsItem {
    /** String constraint. */
    constraint?: UpdateResponseTargetsItemConstraint | null;
    /** A target based on the URL of the request. */
    target?: UpdateResponseTargetsItemTarget | null;
}
export type UpdateResponseTargetsList = Array<UpdateResponseTargetsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdatePageRuleResponse {
    /** Identifier. */
    id: string;
    /** The set of actions to perform if the targets of this rule match the request. Actions can redirect to another URL or override settings, but not both. */
    actions: UpdateResponseActionsList;
    /** The timestamp of when the Page Rule was created. */
    createdOn: string;
    /** The timestamp of when the Page Rule was last modified. */
    modifiedOn: string;
    /** The priority of the rule, used to define which Page Rule is processed over another. A higher number indicates a higher priority. For example, if you have a catch-all Page Rule (rule A: `/images/*`) but want a more specific Page Rule to take precedence (rule B: `/images/special/*`), specify a higher priority for rule B so it overrides rule A. */
    priority: number;
    /** The status of the Page Rule. */
    status: UpdateResponseStatus;
    /** The rule targets to evaluate on each request. */
    targets: UpdateResponseTargetsList;
}
export type CreatePageRuleError = Forbidden | CloudflareOpError;
/** Creates a new Page Rule. */
export declare const createPageRule: API.OperationMethod<CreatePageRuleRequest, CreatePageRuleResponse, CreatePageRuleError, CloudflareOpContext>;
export type DeletePageRuleError = PageRuleNotFound | Forbidden | CloudflareOpError;
/** Deletes an existing Page Rule. */
export declare const deletePageRule: API.OperationMethod<DeletePageRuleRequest, DeletePageRuleResponse, DeletePageRuleError, CloudflareOpContext>;
export type GetPageRuleError = PageRuleNotFound | Forbidden | CloudflareOpError;
/** Fetches the details of a Page Rule. */
export declare const getPageRule: API.OperationMethod<GetPageRuleRequest, GetPageRuleResponse, GetPageRuleError, CloudflareOpContext>;
export type ListPageRulesError = Forbidden | InvalidZoneIdentifier | CloudflareOpError;
/** Fetches Page Rules in a zone. */
export declare const listPageRules: API.OperationMethod<ListPageRulesRequest, ListPageRulesResponse, ListPageRulesError, CloudflareOpContext>;
export type PatchPageRuleError = PageRuleNotFound | Forbidden | CloudflareOpError;
/** Updates one or more fields of an existing Page Rule. */
export declare const patchPageRule: API.OperationMethod<PatchPageRuleRequest, PatchPageRuleResponse, PatchPageRuleError, CloudflareOpContext>;
export type UpdatePageRuleError = PageRuleNotFound | Forbidden | CloudflareOpError;
/** Replaces the configuration of an existing Page Rule. The configuration of the updated Page Rule will exactly match the data passed in the API request. */
export declare const updatePageRule: API.OperationMethod<UpdatePageRuleRequest, UpdatePageRuleResponse, UpdatePageRuleError, CloudflareOpContext>;
//# sourceMappingURL=page_rules.d.ts.map