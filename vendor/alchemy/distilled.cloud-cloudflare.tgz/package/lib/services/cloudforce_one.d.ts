import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ScanConfigNotFound_base: S.TaggedErrorClass<"ScanConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ScanConfigNotFound extends /*@__PURE__*/ ScanConfigNotFound_base {
}
export type ThreatEventsBulkCreateRequestDataItemRawDataMap = {
    [key: string]: unknown | undefined;
};
export interface ThreatEventsBulkCreateRequestDataItemRaw {
    data: ThreatEventsBulkCreateRequestDataItemRawDataMap;
    source?: string;
    tlp?: string;
}
export interface ThreatEventsBulkCreateRequestDataItemIndicatorsItem {
    /** The type of indicator (e.g., DOMAIN, IP, JA3, HASH) */
    indicatorType: string;
    /** The indicator value (e.g., domain name, IP address, hash) */
    value: string;
}
export type ThreatEventsBulkCreateRequestDataItemIndicatorsList = Array<ThreatEventsBulkCreateRequestDataItemIndicatorsItem>;
export type ThreatEventsBulkCreateRequestDataItemTagsList = Array<string>;
export interface ThreatEventsBulkCreateRequestDataItem {
    category: string;
    date: string;
    event: string;
    raw: ThreatEventsBulkCreateRequestDataItemRaw;
    tlp: string;
    accountId?: number;
    attacker?: string;
    attackerCountry?: string;
    datasetId?: string;
    indicator?: string;
    /** Array of indicators for this event. Supports multiple indicators per event for complex scenarios. */
    indicators?: ThreatEventsBulkCreateRequestDataItemIndicatorsList;
    indicatorType?: string;
    insight?: string;
    tags?: ThreatEventsBulkCreateRequestDataItemTagsList;
    targetCountry?: string;
    targetIndustry?: string;
}
export type ThreatEventsBulkCreateRequestDataList = Array<ThreatEventsBulkCreateRequestDataItem>;
export interface BulkCreateThreatEventsRequest {
    /** Account ID. */
    accountId: string;
    data: ThreatEventsBulkCreateRequestDataList;
    datasetId: string;
    /** When true, response includes array of created event UUIDs and shard IDs. Useful for tracking which events were created and where. */
    includeCreatedEvents?: boolean;
}
export interface ThreatEventsBulkCreateResponseCreatedEventsItem {
    /** Original index in the input data array */
    eventIndex: number;
    /** Dataset ID of the shard where the event was created */
    shardId: string;
    /** UUID of the created event */
    uuid: string;
}
export type ThreatEventsBulkCreateResponseCreatedEventsList = Array<ThreatEventsBulkCreateResponseCreatedEventsItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface BulkCreateThreatEventsResponse {
    /** Number of events created */
    createdEventsCount: number;
    /** Number of new tags created in SoT */
    createdTagsCount: number;
    /** Number of errors encountered */
    errorCount: number;
    /** Number of indicators queued for async processing */
    queuedIndicatorsCount: number;
    /** Correlation ID for async indicator processing */
    createBulkEventsRequestId?: string | null;
    /** Array of created events with UUIDs and shard locations. Only present when includeCreatedEvents=true */
    createdEvents?: ThreatEventsBulkCreateResponseCreatedEventsList | null;
}
export interface CreateBinaryStorageRequest {
    /** Account ID. */
    accountId: string;
    /** The binary file content to upload. */
    file: unknown;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateBinaryStorageResponse {
    contentType: string;
    md5: string;
    sha1: string;
    sha256: string;
}
export type RequestsCreateRequestTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export interface CreateRequestRequest {
    /** Identifier. */
    accountId: string;
    /** Request content. */
    content?: string;
    /** Priority for analyzing the request. */
    priority?: string;
    /** Requested information from request. */
    requestType?: string;
    /** Brief description of the request. */
    summary?: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp?: RequestsCreateRequestTlp | (string & {});
}
export type RequestsCreateResponseTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export type RequestsCreateResponseStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRequestResponse {
    /** UUID. */
    id: string;
    /** Request content. */
    content: string;
    created: string;
    priority: string;
    /** Requested information from request. */
    request: string;
    /** Brief description of the request. */
    summary: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsCreateResponseTlp;
    updated: string;
    completed?: string | null;
    /** Tokens for the request messages. */
    messageTokens?: number | null;
    /** Readable Request ID. */
    readableId?: string | null;
    /** Request Status. */
    status?: RequestsCreateResponseStatus | null;
    /** Tokens for the request. */
    tokens?: number | null;
}
export interface CreateRequestAssetRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** Page number of results. */
    page: number;
    /** Number of results per page. */
    perPage: number;
}
export interface RequestsAssetsCreateResultItem {
    /** Asset ID. */
    id: number;
    /** Asset name. */
    name: string;
    /** Defines the asset creation time. */
    created?: string | null;
    /** Asset description. */
    description?: string | null;
    /** Asset file type. */
    fileType?: string | null;
}
export type RequestsAssetsCreateResultList = Array<RequestsAssetsCreateResultItem>;
export interface CreateRequestAssetResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RequestsAssetsCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface CreateRequestMessageRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** Content of message. */
    content?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRequestMessageResponse {
    /** Message ID. */
    id: number;
    /** Author of message. */
    author: string;
    /** Content of message. */
    content: string;
    /** Whether the message is a follow-on request. */
    isFollowOnRequest: boolean;
    /** Defines the message last updated time. */
    updated: string;
    /** Defines the message creation time. */
    created?: string | null;
}
export type RequestsPriorityCreateRequestLabelsList = Array<string>;
export type RequestsPriorityCreateRequestTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export interface CreateRequestPriorityRequest {
    /** Identifier. */
    accountId: string;
    /** List of labels. */
    labels: RequestsPriorityCreateRequestLabelsList;
    /** Priority. */
    priority: number;
    /** Requirement. */
    requirement: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsPriorityCreateRequestTlp | (string & {});
}
export type RequestsPriorityCreateResponseLabelsList = Array<string>;
export type RequestsPriorityCreateResponseTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRequestPriorityResponse {
    /** UUID. */
    id: string;
    /** Priority creation time. */
    created: string;
    /** List of labels. */
    labels: RequestsPriorityCreateResponseLabelsList;
    /** Priority. */
    priority: number;
    /** Requirement. */
    requirement: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsPriorityCreateResponseTlp;
    /** Priority last updated time. */
    updated: string;
}
export type ScansConfigCreateRequestIpsList = Array<string>;
export type ScansConfigCreateRequestPortsList = Array<string>;
export interface CreateScanConfigRequest {
    /** Defines the Account ID. */
    accountId: string;
    /** Defines a list of IP addresses or CIDR blocks to scan. The maximum number of total IP addresses allowed is 5000. */
    ips: ScansConfigCreateRequestIpsList;
    /** Defines the number of days between each scan (0 = One-off scan). */
    frequency?: number;
    /** Defines a list of ports to scan. Valid values are:"default", "all", or a comma-separated list of ports or range of ports (e.g. ["1-80", "443"]). "default" scans the 100 most commonly open ports. */
    ports?: ScansConfigCreateRequestPortsList;
}
export type ScansConfigCreateResponseIpsList = Array<string>;
export type ScansConfigCreateResponsePortsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScanConfigResponse {
    /** Defines the Config ID. */
    id: string;
    accountId: string;
    /** Defines the number of days between each scan (0 = One-off scan). */
    frequency: number;
    /** Defines a list of IP addresses or CIDR blocks to scan. The maximum number of total IP addresses allowed is 5000. */
    ips: ScansConfigCreateResponseIpsList;
    /** Defines a list of ports to scan. Valid values are:"default", "all", or a comma-separated list of ports or range of ports (e.g. ["1-80", "443"]). "default" scans the 100 most commonly open ports. */
    ports: ScansConfigCreateResponsePortsList;
}
export type ThreatEventsCreateRequestRawDataMap = {
    [key: string]: unknown | undefined;
};
export interface ThreatEventsCreateRequestRaw {
    data: ThreatEventsCreateRequestRawDataMap;
    source?: string;
    tlp?: string;
}
export type ThreatEventsCreateRequestIndicatorsItem = ThreatEventsBulkCreateRequestDataItemIndicatorsItem;
export type ThreatEventsCreateRequestIndicatorsList = Array<ThreatEventsBulkCreateRequestDataItemIndicatorsItem>;
export type ThreatEventsCreateRequestSourceResourceType = "article";
export type ThreatEventsCreateRequestSourceSystem = "threat-signals";
export interface ThreatEventsCreateRequestSource {
    resourceId: string;
    resourceType: ThreatEventsCreateRequestSourceResourceType | (string & {});
    system: ThreatEventsCreateRequestSourceSystem | (string & {});
    /** Threat Signals article title; null for historical provenance without a stored title. */
    title?: string;
}
export type ThreatEventsCreateRequestTagsList = Array<string>;
export interface CreateThreatEventRequest {
    /** Account ID. */
    accountId: string;
    category: string;
    date: string;
    event: string;
    raw: ThreatEventsCreateRequestRaw;
    tlp: string;
    attacker?: string;
    attackerCountry?: string;
    datasetId?: string;
    indicator?: string;
    /** Array of indicators for this event. Supports multiple indicators per event for complex scenarios. */
    indicators?: ThreatEventsCreateRequestIndicatorsList;
    indicatorType?: string;
    insight?: string;
    /** Controlled provenance for an event and its indicators derived from a Threat Signals article. */
    source?: ThreatEventsCreateRequestSource;
    tags?: ThreatEventsCreateRequestTagsList;
    targetCountry?: string;
    targetIndustry?: string;
}
export type ThreatEventsCreateResponseMitreAttackList = Array<string>;
export type ThreatEventsCreateResponseMitreCapecList = Array<string>;
export type ThreatEventsCreateResponseReferencedList = Array<string>;
export type ThreatEventsCreateResponseReferencedIdsList = Array<number>;
export type ThreatEventsCreateResponseReferencesList = Array<string>;
export type ThreatEventsCreateResponseReferencesIdsList = Array<number>;
export type ThreatEventsCreateResponseTagsList = Array<string>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateThreatEventResponse {
    attacker: string;
    attackerCountry: string;
    attackerCountryAlpha3: string;
    category: string;
    datasetId: string;
    date: string;
    event: string;
    hasChildren: boolean;
    indicator: string;
    indicatorType: string;
    indicatorTypeId: number;
    killChain: number;
    mitreAttack: ThreatEventsCreateResponseMitreAttackList;
    mitreCapec: ThreatEventsCreateResponseMitreCapecList;
    numReferenced: number;
    numReferences: number;
    rawId: string;
    referenced: ThreatEventsCreateResponseReferencedList;
    referencedIds: ThreatEventsCreateResponseReferencedIdsList;
    references: ThreatEventsCreateResponseReferencesList;
    referencesIds: ThreatEventsCreateResponseReferencesIdsList;
    tags: ThreatEventsCreateResponseTagsList;
    targetCountry: string;
    targetCountryAlpha3: string;
    targetIndustry: string;
    tlp: string;
    uuid: string;
    insight?: string | null;
    releasabilityId?: string | null;
}
export type ThreatEventsCategoriesCreateRequestMitreAttackList = Array<string>;
export type ThreatEventsCategoriesCreateRequestMitreCapecList = Array<string>;
export interface CreateThreatEventCategoryRequest {
    /** Account ID. */
    accountId: string;
    killChain: number;
    name: string;
    mitreAttack?: ThreatEventsCategoriesCreateRequestMitreAttackList;
    mitreCapec?: ThreatEventsCategoriesCreateRequestMitreCapecList;
    shortname?: string;
}
export type ThreatEventsCategoriesCreateResponseMitreAttackList = Array<string>;
export type ThreatEventsCategoriesCreateResponseMitreCapecList = Array<string>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateThreatEventCategoryResponse {
    killChain: number;
    name: string;
    uuid: string;
    mitreAttack?: ThreatEventsCategoriesCreateResponseMitreAttackList | null;
    mitreCapec?: ThreatEventsCategoriesCreateResponseMitreCapecList | null;
    shortname?: string | null;
}
export interface CreateThreatEventDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** If true, then anyone can search the dataset. If false, then its limited to the account. */
    isPublic: boolean;
    /** Used to describe the dataset within the account context. */
    name: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateThreatEventDatasetResponse {
    isAnalytics: boolean;
    isPublic: boolean;
    name: string;
    uuid: string;
}
export type ThreatEventsEventTagsCreateRequestTagsList = Array<string>;
export interface CreateThreatEventEventTagRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
    tags: ThreatEventsEventTagsCreateRequestTagsList;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateThreatEventEventTagResponse {
    success: boolean;
}
export interface CreateThreatEventsGraphqlRequest {
    /** Account ID. */
    accountId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateThreatEventsGraphqlResponse {
    data?: unknown | null;
}
export interface CreateThreatEventsQueryRequest {
    /** Account ID. */
    accountId: string;
    /** Unique name for the saved query */
    name: string;
    /** JSON string containing the query parameters */
    queryJson: string;
    /** Deprecated and ignored: saved-query alerting and rules were removed. */
    alertEnabled?: boolean;
    /** Deprecated and ignored: saved-query alerting and rules were removed. */
    alertRollupEnabled?: boolean;
    /** Deprecated and ignored: saved-query alerting and rules were removed. */
    ruleEnabled?: boolean;
    /** Deprecated and ignored: saved-query alerting and rules were removed. */
    ruleScope?: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateThreatEventsQueryResponse {
    /** Unique identifier for the saved query */
    id: number;
    /** Account ID */
    accountId: number;
    /** Deprecated: saved-query alerting and rules were removed. Always false. */
    alertEnabled: boolean;
    /** Deprecated: saved-query alerting and rules were removed. Always false. */
    alertRollupEnabled: boolean;
    /** Creation timestamp */
    createdAt: string;
    /** Name of the saved query */
    name: string;
    /** JSON string containing the query parameters */
    queryJson: string;
    /** Deprecated: saved-query alerting and rules were removed. Always false. */
    ruleEnabled: boolean;
    /** Last update timestamp */
    updatedAt: string;
    /** Email of the user who created the query */
    userEmail: string;
    /** Deprecated: saved-query alerting and rules were removed. Always null. */
    customThreatFeedId?: number | null;
    /** Deprecated: saved-query alerting and rules were removed. Always null. */
    ruleListId?: string | null;
    /** Deprecated: saved-query alerting and rules were removed. Always null. */
    ruleScope?: string | null;
}
export type CreateThreatEventsTagsCategoryRequestSchemaItemKind = "string" | "number" | "enum" | "date" | "array" | "object";
export type CreateThreatEventsTagsCategoryRequestSchemaItemAllowedValuesList = Array<string>;
export interface CreateThreatEventsTagsCategoryRequestSchemaItemAnnotations {
    confidence?: boolean;
    tlp?: boolean;
}
export type CreateThreatEventsTagsCategoryRequestSchemaItemDeprecatedValuesList = Array<string>;
export type CreateThreatEventsTagsCategoryRequestSchemaItemEnforcement = "error" | "warn" | "off";
export type CreateThreatEventsTagsCategoryRequestSchemaItemFormat = "date" | "url" | "duration" | "country";
export interface CreateThreatEventsTagsCategoryRequestSchemaItemNumberConstraint {
    integer?: boolean;
    max?: number;
    min?: number;
}
export type CreateThreatEventsTagsCategoryRequestSchemaItemPropertiesMap = {
    [key: string]: unknown | undefined;
};
export interface CreateThreatEventsTagsCategoryRequestSchemaItem {
    key: string;
    kind: CreateThreatEventsTagsCategoryRequestSchemaItemKind | (string & {});
    allowedValues?: CreateThreatEventsTagsCategoryRequestSchemaItemAllowedValuesList;
    annotations?: CreateThreatEventsTagsCategoryRequestSchemaItemAnnotations;
    /** Marks a field as unavailable for new values while retaining its definition for historical values. */
    deprecated?: boolean;
    /** Enum values unavailable for new writes but retained in allowedValues for historical display. */
    deprecatedValues?: CreateThreatEventsTagsCategoryRequestSchemaItemDeprecatedValuesList;
    element?: unknown;
    enforcement?: CreateThreatEventsTagsCategoryRequestSchemaItemEnforcement | (string & {});
    format?: CreateThreatEventsTagsCategoryRequestSchemaItemFormat | (string & {});
    label?: string;
    /** exclusiveMinimum */
    maxLength?: number;
    numberConstraint?: CreateThreatEventsTagsCategoryRequestSchemaItemNumberConstraint;
    /** Map of property key to FieldDefinition for object fields. Required when kind is 'object'. See FieldDefinition (recursive). */
    properties?: CreateThreatEventsTagsCategoryRequestSchemaItemPropertiesMap;
    required?: boolean;
}
export type CreateThreatEventsTagsCategoryRequestSchemaList = Array<CreateThreatEventsTagsCategoryRequestSchemaItem>;
export interface CreateThreatEventsTagsCategoryRequest {
    /** Account ID. */
    accountId: string;
    name: string;
    description?: string;
    /** Optional array of FieldDefinition objects defining custom fields for tags in this category. Persisted as JSON; returned as a parsed array. */
    schema?: CreateThreatEventsTagsCategoryRequestSchemaList;
}
export type CreateThreatEventsTagsCategoryResponseSchemaItemKind = "string" | "number" | "enum" | "date" | "array" | "object";
export type CreateThreatEventsTagsCategoryResponseSchemaItemAllowedValuesList = Array<string>;
export interface CreateThreatEventsTagsCategoryResponseSchemaItemAnnotations {
    confidence?: boolean | null;
    tlp?: boolean | null;
}
export type CreateThreatEventsTagsCategoryResponseSchemaItemDeprecatedValuesList = Array<string>;
export type CreateThreatEventsTagsCategoryResponseSchemaItemEnforcement = "error" | "warn" | "off";
export type CreateThreatEventsTagsCategoryResponseSchemaItemFormat = "date" | "url" | "duration" | "country";
export interface CreateThreatEventsTagsCategoryResponseSchemaItemNumberConstraint {
    integer?: boolean | null;
    max?: number | null;
    min?: number | null;
}
export type CreateThreatEventsTagsCategoryResponseSchemaItemPropertiesMap = {
    [key: string]: unknown | undefined;
};
export interface CreateThreatEventsTagsCategoryResponseSchemaItem {
    key: string;
    kind: CreateThreatEventsTagsCategoryResponseSchemaItemKind;
    allowedValues?: CreateThreatEventsTagsCategoryResponseSchemaItemAllowedValuesList | null;
    annotations?: CreateThreatEventsTagsCategoryResponseSchemaItemAnnotations | null;
    /** Marks a field as unavailable for new values while retaining its definition for historical values. */
    deprecated?: boolean | null;
    /** Enum values unavailable for new writes but retained in allowedValues for historical display. */
    deprecatedValues?: CreateThreatEventsTagsCategoryResponseSchemaItemDeprecatedValuesList | null;
    element?: unknown | null;
    enforcement?: CreateThreatEventsTagsCategoryResponseSchemaItemEnforcement | null;
    format?: CreateThreatEventsTagsCategoryResponseSchemaItemFormat | null;
    label?: string | null;
    /** exclusiveMinimum */
    maxLength?: number | null;
    numberConstraint?: CreateThreatEventsTagsCategoryResponseSchemaItemNumberConstraint | null;
    /** Map of property key to FieldDefinition for object fields. Required when kind is 'object'. See FieldDefinition (recursive). */
    properties?: CreateThreatEventsTagsCategoryResponseSchemaItemPropertiesMap | null;
    required?: boolean | null;
}
export type CreateThreatEventsTagsCategoryResponseSchemaList = Array<CreateThreatEventsTagsCategoryResponseSchemaItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateThreatEventsTagsCategoryResponse {
    name: string;
    uuid: string;
    createdAt?: string | null;
    description?: string | null;
    /** Parsed FieldDefinition[] defining custom fields for this category, or null if none. */
    schema?: CreateThreatEventsTagsCategoryResponseSchemaList | null;
    updatedAt?: string | null;
}
export type ThreatEventsTagsCreateRequestActiveDurationCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateRequestActiveDurationCase1 {
    value: string;
    confidence?: number;
    tlp?: ThreatEventsTagsCreateRequestActiveDurationCase1Tlp | (string & {});
}
export type ThreatEventsTagsCreateRequestActiveDuration = string | ThreatEventsTagsCreateRequestActiveDurationCase1;
export type ThreatEventsTagsCreateRequestActorCategoryCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateRequestActorCategoryCase1 {
    value: string;
    confidence?: number;
    tlp?: ThreatEventsTagsCreateRequestActorCategoryCase1Tlp | (string & {});
}
export type ThreatEventsTagsCreateRequestActorCategory = string | ThreatEventsTagsCreateRequestActorCategoryCase1;
export type ThreatEventsTagsCreateRequestAliasesItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateRequestAliasesItem {
    value: string;
    confidence?: number;
    tlp?: ThreatEventsTagsCreateRequestAliasesItemTlp | (string & {});
}
export type ThreatEventsTagsCreateRequestAliasesList = Array<ThreatEventsTagsCreateRequestAliasesItem>;
export type ThreatEventsTagsCreateRequestAliasGroupNamesList = Array<string>;
export type ThreatEventsTagsCreateRequestAliasGroupNamesInternalList = Array<string>;
export type ThreatEventsTagsCreateRequestAttributionOrganizationCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateRequestAttributionOrganizationCase1 {
    value: string;
    confidence?: number;
    tlp?: ThreatEventsTagsCreateRequestAttributionOrganizationCase1Tlp | (string & {});
}
export type ThreatEventsTagsCreateRequestAttributionOrganization = string | ThreatEventsTagsCreateRequestAttributionOrganizationCase1;
export type ThreatEventsTagsCreateRequestExternalReferenceLinksList = Array<string>;
export interface ThreatEventsTagsCreateRequestExternalReferencesItem {
    url: string;
    description?: string;
}
export type ThreatEventsTagsCreateRequestExternalReferencesList = Array<ThreatEventsTagsCreateRequestExternalReferencesItem>;
export type ThreatEventsTagsCreateRequestInternalAliasesItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateRequestInternalAliasesItem {
    value: string;
    confidence?: number;
    tlp?: ThreatEventsTagsCreateRequestInternalAliasesItemTlp | (string & {});
}
export type ThreatEventsTagsCreateRequestInternalAliasesList = Array<ThreatEventsTagsCreateRequestInternalAliasesItem>;
export type ThreatEventsTagsCreateRequestMotiveCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateRequestMotiveCase1 {
    value: string;
    confidence?: number;
    tlp?: ThreatEventsTagsCreateRequestMotiveCase1Tlp | (string & {});
}
export type ThreatEventsTagsCreateRequestMotive = string | ThreatEventsTagsCreateRequestMotiveCase1;
export type ThreatEventsTagsCreateRequestOpsecLevelCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateRequestOpsecLevelCase1 {
    value: string;
    confidence?: number;
    tlp?: ThreatEventsTagsCreateRequestOpsecLevelCase1Tlp | (string & {});
}
export type ThreatEventsTagsCreateRequestOpsecLevel = string | ThreatEventsTagsCreateRequestOpsecLevelCase1;
export type ThreatEventsTagsCreateRequestOriginCountryISOCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateRequestOriginCountryISOCase1 {
    value: string;
    confidence?: number;
    tlp?: ThreatEventsTagsCreateRequestOriginCountryISOCase1Tlp | (string & {});
}
export type ThreatEventsTagsCreateRequestOriginCountryISO = string | ThreatEventsTagsCreateRequestOriginCountryISOCase1;
export type ThreatEventsTagsCreateRequestPriorityCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateRequestPriorityCase1 {
    value: number;
    confidence?: number;
    tlp?: ThreatEventsTagsCreateRequestPriorityCase1Tlp | (string & {});
}
export type ThreatEventsTagsCreateRequestPriority = number | ThreatEventsTagsCreateRequestPriorityCase1;
export type ThreatEventsTagsCreateRequestPropertiesMap = {
    [key: string]: unknown | undefined;
};
export type ThreatEventsTagsCreateRequestSophisticationLevelCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateRequestSophisticationLevelCase1 {
    value: string;
    confidence?: number;
    tlp?: ThreatEventsTagsCreateRequestSophisticationLevelCase1Tlp | (string & {});
}
export type ThreatEventsTagsCreateRequestSophisticationLevel = string | ThreatEventsTagsCreateRequestSophisticationLevelCase1;
export type ThreatEventsTagsCreateRequestTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface CreateThreatEventTagRequest {
    /** Account ID. */
    accountId: string;
    value: string;
    activeDuration?: ThreatEventsTagsCreateRequestActiveDuration;
    actorCategory?: ThreatEventsTagsCreateRequestActorCategory;
    /** Structured aliases ({ value, confidence 1-10, tlp }). Public: returned to all accounts with per-entry TLP filtering (entries with tlp: purple are removed for non-CFONE accounts). */
    aliases?: ThreatEventsTagsCreateRequestAliasesList;
    aliasGroupNames?: ThreatEventsTagsCreateRequestAliasGroupNamesList;
    aliasGroupNamesInternal?: ThreatEventsTagsCreateRequestAliasGroupNamesInternalList;
    attributionOrganization?: ThreatEventsTagsCreateRequestAttributionOrganization;
    /** Tag type (category) UUID. Optional -- when present, `properties` is validated against this category's schema. When absent, the tag is typeless and properties are accepted free-form. */
    categoryUuid?: string;
    /** Overall tag confidence (1-10). Optional. */
    confidence?: number;
    /** Date of discovery (ISO YYYY-MM-DD). Optional. */
    dateOfDiscovery?: string;
    description?: string;
    externalReferenceLinks?: ThreatEventsTagsCreateRequestExternalReferenceLinksList;
    /** Structured external references ({ url, description }). Public: returned to all accounts. */
    externalReferences?: ThreatEventsTagsCreateRequestExternalReferencesList;
    /** Owner-private structured aliases ({ value, confidence 1-10, tlp }). Returned to the owning account and omitted from shared-catalog non-owner responses. */
    internalAliases?: ThreatEventsTagsCreateRequestInternalAliasesList;
    internalDescription?: string;
    lastSeen?: string;
    motive?: ThreatEventsTagsCreateRequestMotive;
    opsecLevel?: ThreatEventsTagsCreateRequestOpsecLevel;
    originCountryISO?: ThreatEventsTagsCreateRequestOriginCountryISO;
    priority?: ThreatEventsTagsCreateRequestPriority;
    /** Structured metadata blob. Optional. When `categoryUuid` is given, validated against this category's schema on write. When typeless, accepted free-form. Use `{}` for a tag with no custom data. */
    properties?: ThreatEventsTagsCreateRequestPropertiesMap;
    sophisticationLevel?: ThreatEventsTagsCreateRequestSophisticationLevel;
    /** Tag-level TLP handling marking. Optional. Allowed values: red, amber, amber-strict, green, clear, purple, amber+strict. */
    tlp?: ThreatEventsTagsCreateRequestTlp | (string & {});
}
export type ThreatEventsTagsCreateResponseActiveDurationAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateResponseActiveDurationAnnotated {
    value: string;
    tlp?: ThreatEventsTagsCreateResponseActiveDurationAnnotatedTlp | null;
}
export type ThreatEventsTagsCreateResponseActorCategoryAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateResponseActorCategoryAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: ThreatEventsTagsCreateResponseActorCategoryAnnotatedTlp | null;
}
export type ThreatEventsTagsCreateResponseAliasesItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateResponseAliasesItem {
    value: string;
    confidence?: number | null;
    tlp?: ThreatEventsTagsCreateResponseAliasesItemTlp | null;
}
export type ThreatEventsTagsCreateResponseAliasesList = Array<ThreatEventsTagsCreateResponseAliasesItem>;
export type ThreatEventsTagsCreateResponseAliasGroupNamesList = Array<string>;
export type ThreatEventsTagsCreateResponseAliasGroupNamesInternalList = Array<string>;
export type ThreatEventsTagsCreateResponseAttributionOrganizationAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateResponseAttributionOrganizationAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: ThreatEventsTagsCreateResponseAttributionOrganizationAnnotatedTlp | null;
}
export type ThreatEventsTagsCreateResponseExternalReferenceLinksList = Array<string>;
export interface ThreatEventsTagsCreateResponseExternalReferencesItem {
    url: string;
    description?: string | null;
}
export type ThreatEventsTagsCreateResponseExternalReferencesList = Array<ThreatEventsTagsCreateResponseExternalReferencesItem>;
export type ThreatEventsTagsCreateResponseExternalReferencesAnnotatedItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateResponseExternalReferencesAnnotatedItem {
    value: string;
    tlp?: ThreatEventsTagsCreateResponseExternalReferencesAnnotatedItemTlp | null;
}
export type ThreatEventsTagsCreateResponseExternalReferencesAnnotatedList = Array<ThreatEventsTagsCreateResponseExternalReferencesAnnotatedItem>;
export type ThreatEventsTagsCreateResponseInternalAliasesItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateResponseInternalAliasesItem {
    value: string;
    confidence?: number | null;
    tlp?: ThreatEventsTagsCreateResponseInternalAliasesItemTlp | null;
}
export type ThreatEventsTagsCreateResponseInternalAliasesList = Array<ThreatEventsTagsCreateResponseInternalAliasesItem>;
export type ThreatEventsTagsCreateResponseMotiveAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateResponseMotiveAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: ThreatEventsTagsCreateResponseMotiveAnnotatedTlp | null;
}
export type ThreatEventsTagsCreateResponseOpsecLevelAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateResponseOpsecLevelAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: ThreatEventsTagsCreateResponseOpsecLevelAnnotatedTlp | null;
}
export type ThreatEventsTagsCreateResponseOriginCountryISOAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateResponseOriginCountryISOAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: ThreatEventsTagsCreateResponseOriginCountryISOAnnotatedTlp | null;
}
export type ThreatEventsTagsCreateResponsePriorityAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateResponsePriorityAnnotated {
    value: number;
    tlp?: ThreatEventsTagsCreateResponsePriorityAnnotatedTlp | null;
}
export type ThreatEventsTagsCreateResponsePropertiesMap = {
    [key: string]: unknown | undefined;
};
export type ThreatEventsTagsCreateResponseSophisticationLevelAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ThreatEventsTagsCreateResponseSophisticationLevelAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: ThreatEventsTagsCreateResponseSophisticationLevelAnnotatedTlp | null;
}
export type ThreatEventsTagsCreateResponseTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateThreatEventTagResponse {
    uuid: string;
    value: string;
    activeDuration?: string | null;
    activeDurationAnnotated?: ThreatEventsTagsCreateResponseActiveDurationAnnotated | null;
    actorCategory?: string | null;
    actorCategoryAnnotated?: ThreatEventsTagsCreateResponseActorCategoryAnnotated | null;
    /** Structured aliases ({ value, confidence 1-10, tlp }). Public: returned to all accounts with per-entry TLP filtering (entries with tlp: purple are removed for non-CFONE accounts). */
    aliases?: ThreatEventsTagsCreateResponseAliasesList | null;
    aliasGroupNames?: ThreatEventsTagsCreateResponseAliasGroupNamesList | null;
    aliasGroupNamesInternal?: ThreatEventsTagsCreateResponseAliasGroupNamesInternalList | null;
    attributionOrganization?: string | null;
    attributionOrganizationAnnotated?: ThreatEventsTagsCreateResponseAttributionOrganizationAnnotated | null;
    categoryName?: string | null;
    categoryUuid?: string | null;
    /** Overall tag confidence (1-10). */
    confidence?: number | null;
    createdAt?: string | null;
    dateOfDiscovery?: string | null;
    description?: string | null;
    externalReferenceLinks?: ThreatEventsTagsCreateResponseExternalReferenceLinksList | null;
    /** Structured external references ({ url, description }). Public: returned to all accounts. */
    externalReferences?: ThreatEventsTagsCreateResponseExternalReferencesList | null;
    externalReferencesAnnotated?: ThreatEventsTagsCreateResponseExternalReferencesAnnotatedList | null;
    /** Owner-private structured aliases ({ value, confidence 1-10, tlp }). Returned to the owning account and omitted from shared-catalog non-owner responses. */
    internalAliases?: ThreatEventsTagsCreateResponseInternalAliasesList | null;
    internalDescription?: string | null;
    lastSeen?: string | null;
    motive?: string | null;
    motiveAnnotated?: ThreatEventsTagsCreateResponseMotiveAnnotated | null;
    opsecLevel?: string | null;
    opsecLevelAnnotated?: ThreatEventsTagsCreateResponseOpsecLevelAnnotated | null;
    /** ISO country code (alpha-2 or alpha-3). Normalized to uppercase on read. Null when stored value is blank/whitespace. */
    originCountryISO?: string | null;
    originCountryISOAnnotated?: ThreatEventsTagsCreateResponseOriginCountryISOAnnotated | null;
    priority?: number | null;
    priorityAnnotated?: ThreatEventsTagsCreateResponsePriorityAnnotated | null;
    /** Parsed custom field values. Null when the tag has no custom fields. */
    properties?: ThreatEventsTagsCreateResponsePropertiesMap | null;
    sophisticationLevel?: string | null;
    sophisticationLevelAnnotated?: ThreatEventsTagsCreateResponseSophisticationLevelAnnotated | null;
    /** Tag-level TLP handling marking. */
    tlp?: ThreatEventsTagsCreateResponseTlp | null;
    updatedAt?: string | null;
    version?: number | null;
}
export interface CreateThreatSignalsArticlesTagRequest {
    accountId: string;
    /** Threat Signals article UUID */
    articleId: string;
    /** UUID of a tag from the account's catalog to apply to the article. */
    tagId: string;
}
export type CreateThreatSignalsArticlesTagResponseAppliedBy = "ai" | "analyst" | "system";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateThreatSignalsArticlesTagResponse {
    appliedBy: CreateThreatSignalsArticlesTagResponseAppliedBy;
    categoryId: string;
    uuid: string;
    value: string;
}
export type CreateThreatSignalsFeedRequestCategoryId = "b12a0fd6-f7b9-5393-9ef3-f888d506c550" | "d5b70eaa-626f-5761-b55b-6d9590df49fb" | "3b572d2b-890d-5286-9433-f18c85079030" | "17f90d3b-37d3-5241-8ad4-7d6abbc2006c" | "c68f28e9-7e8f-5d4b-853b-f3076893a9ee" | "bb0e4a94-38ab-5c14-80a7-28cee9f4b139" | "b1ef66d9-a73c-58dc-b269-22d34dfd11f4" | "ab02a976-0a20-5c76-a553-7f6325afacfe";
export interface CreateThreatSignalsFeedRequest {
    accountId: string;
    /** One of the predefined Threat Signals feed categories; see GET /:account_id/v2/threat-signals/categories. */
    categoryId?: CreateThreatSignalsFeedRequestCategoryId | (string & {});
    /** UUID of a curated feed to subscribe to. Provide exactly one of url or curated_feed_id. The account must have feed creation entitlement and not exceed feed allowance. */
    curatedFeedId?: string;
    /** Override the feed's display name. Null clears it; omit to keep existing or derived value. */
    displayName?: string;
    /** Whether to actively poll the feed. Default true. */
    enabled?: boolean;
    /** Polling interval in seconds (60-86400). Default 300s (5 minutes). */
    pollIntervalS?: number;
    /** Override the feed's title. Null clears it; omit to keep existing or derived value. */
    title?: string;
    /** HTTPS RSS feed URL. Provide exactly one of url or curated_feed_id. The account must have feed creation entitlement and not exceed feed allowance. */
    url?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateThreatSignalsFeedResponse {
    id: string;
    /** Feed category identifier. Null when unset. */
    categoryId: string;
    /** Display name of the feed category. Null when unset or unresolvable. */
    categoryName: string;
    createdAt: string;
    /** Curated catalog feed this subscription was created from. Null for custom feeds. */
    curatedFeedId: string;
    displayName: string;
    enabled: boolean;
    lastPolledAt: string;
    pollIntervalS: number;
    /** `custom` for a feed added by URL, `curated` for a curated catalog feed. */
    sourceType: string;
    /** Polling health: `active`, or `error` after a failed poll. */
    status: string;
    subscribedAt: string;
    title: string;
    updatedAt: string;
    url: string;
}
export type CreateThreatSignalsSkillRequestType = "summary" | "tags";
export interface CreateThreatSignalsSkillRequest {
    accountId: string;
    /** Custom Skill name (1-100 characters). */
    name: string;
    /** JSON Schema serialized as a string (max 4096 characters). */
    outputSchema: string;
    /** AI prompt (1-4000 characters) defining the skill's instructions. */
    prompt: string;
    /** Optional label; does not affect execution. Defaults to "summary". */
    type?: CreateThreatSignalsSkillRequestType | (string & {});
}
export type CreateThreatSignalsSkillResponseSource = "default" | "custom";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateThreatSignalsSkillResponse {
    id: string;
    /** JSON-encoded skill configuration. Always null for default skills. */
    config: string;
    createdAt: string;
    /** 1 when active, 0 when inactive. */
    isActive: number;
    name: string;
    /** JSON-encoded JSON Schema the skill output must satisfy. */
    outputSchema: string;
    prompt: string;
    /** `default` for Cloudforce One managed skills (read-only), `custom` for account skills. */
    source: CreateThreatSignalsSkillResponseSource;
    type: string;
    updatedAt: string;
}
export interface DeleteRequestRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
}
export interface DeleteRequestResponse {
}
export interface DeleteRequestAssetRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** UUID. */
    assetId: string;
}
export interface DeleteRequestAssetResponse {
}
export interface DeleteRequestMessageRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    messageId: number;
}
export interface DeleteRequestMessageResponse {
}
export interface DeleteRequestPriorityRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    priorityId: string;
}
export interface DeleteRequestPriorityResponse {
}
export interface DeleteScanConfigRequest {
    /** Defines the Account ID. */
    accountId: string;
    /** Defines the Config ID. */
    configId: string;
}
export type DeleteScanConfigResponse = unknown;
export interface DeleteThreatEventCategoryRequest {
    /** Account ID. */
    accountId: string;
    /** Category UUID. */
    categoryId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteThreatEventCategoryResponse {
    uuid: string;
}
export interface DeleteThreatEventEventTagRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteThreatEventEventTagResponse {
    success: boolean;
}
export interface DeleteThreatEventRelateRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteThreatEventRelateResponse {
    success: boolean;
}
export interface DeleteThreatEventsDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset ID to delete */
    datasetId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteThreatEventsDatasetResponse {
    name: string;
    uuid: string;
}
export interface DeleteThreatEventsQueryRequest {
    /** Account ID. */
    accountId: string;
    /** Event query ID */
    queryId: number;
}
export interface DeleteThreatEventsQueryResponse {
}
export interface DeleteThreatEventsTagRequest {
    /** Account ID. */
    accountId: string;
    /** Tag UUID. */
    tagUuid: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteThreatEventsTagResponse {
    uuid: string;
}
export interface DeleteThreatEventsTagsCategoryRequest {
    /** Account ID. */
    accountId: string;
    /** Tag Category UUID. */
    categoryUuid: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteThreatEventsTagsCategoryResponse {
    uuid: string;
}
export interface DeleteThreatSignalsArticlesTagRequest {
    accountId: string;
    /** Threat Signals article UUID */
    articleId: string;
    /** UUID of a tag from the account's catalog */
    tagId: string;
}
export type DeleteThreatSignalsArticlesTagResponseAppliedBy = "ai" | "analyst" | "system";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteThreatSignalsArticlesTagResponse {
    appliedBy: DeleteThreatSignalsArticlesTagResponseAppliedBy;
    categoryId: string;
    uuid: string;
    value: string;
}
export interface DeleteThreatSignalsFeedRequest {
    accountId: string;
    /** UUID of the Threat Signals feed */
    feedId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteThreatSignalsFeedResponse {
    id: string;
    /** Feed category identifier. Null when unset. */
    categoryId: string;
    /** Display name of the feed category. Null when unset or unresolvable. */
    categoryName: string;
    createdAt: string;
    /** Curated catalog feed this subscription was created from. Null for custom feeds. */
    curatedFeedId: string;
    displayName: string;
    enabled: boolean;
    lastPolledAt: string;
    pollIntervalS: number;
    /** `custom` for a feed added by URL, `curated` for a curated catalog feed. */
    sourceType: string;
    /** Polling health: `active`, or `error` after a failed poll. */
    status: string;
    subscribedAt: string;
    title: string;
    updatedAt: string;
    url: string;
}
export interface DeleteThreatSignalsSkillRequest {
    accountId: string;
    /** Custom Skill UUID or a Managed Default Skill ID */
    skillId: string;
}
export type DeleteThreatSignalsSkillResponseSource = "default" | "custom";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteThreatSignalsSkillResponse {
    id: string;
    /** JSON-encoded skill configuration. Always null for default skills. */
    config: string;
    createdAt: string;
    /** 1 when active, 0 when inactive. */
    isActive: number;
    name: string;
    /** JSON-encoded JSON Schema the skill output must satisfy. */
    outputSchema: string;
    prompt: string;
    /** `default` for Cloudforce One managed skills (read-only), `custom` for account skills. */
    source: DeleteThreatSignalsSkillResponseSource;
    type: string;
    updatedAt: string;
}
export interface EditThreatEventsQueryRequest {
    /** Account ID. */
    accountId: string;
    /** Event query ID */
    queryId: number;
    /** Deprecated and ignored: saved-query alerting and rules were removed. */
    alertEnabled?: boolean;
    /** Deprecated and ignored: saved-query alerting and rules were removed. */
    alertRollupEnabled?: boolean;
    /** Unique name for the saved query */
    name?: string;
    /** JSON string containing the query parameters */
    queryJson?: string;
    /** Deprecated and ignored: saved-query alerting and rules were removed. */
    ruleEnabled?: boolean;
    /** Deprecated and ignored: saved-query alerting and rules were removed. */
    ruleScope?: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface EditThreatEventsQueryResponse {
    /** Unique identifier for the saved query */
    id: number;
    /** Account ID */
    accountId: number;
    /** Deprecated: saved-query alerting and rules were removed. Always false. */
    alertEnabled: boolean;
    /** Deprecated: saved-query alerting and rules were removed. Always false. */
    alertRollupEnabled: boolean;
    /** Creation timestamp */
    createdAt: string;
    /** Name of the saved query */
    name: string;
    /** JSON string containing the query parameters */
    queryJson: string;
    /** Deprecated: saved-query alerting and rules were removed. Always false. */
    ruleEnabled: boolean;
    /** Last update timestamp */
    updatedAt: string;
    /** Email of the user who created the query */
    userEmail: string;
    /** Deprecated: saved-query alerting and rules were removed. Always null. */
    customThreatFeedId?: number | null;
    /** Deprecated: saved-query alerting and rules were removed. Always null. */
    ruleListId?: string | null;
    /** Deprecated: saved-query alerting and rules were removed. Always null. */
    ruleScope?: string | null;
}
export type EditThreatEventsTagRequestActiveDurationCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagRequestActiveDurationCase1 {
    value: string;
    confidence?: number;
    tlp?: EditThreatEventsTagRequestActiveDurationCase1Tlp | (string & {});
}
export type EditThreatEventsTagRequestActiveDuration = string | EditThreatEventsTagRequestActiveDurationCase1;
export type EditThreatEventsTagRequestActorCategoryCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagRequestActorCategoryCase1 {
    value: string;
    confidence?: number;
    tlp?: EditThreatEventsTagRequestActorCategoryCase1Tlp | (string & {});
}
export type EditThreatEventsTagRequestActorCategory = string | EditThreatEventsTagRequestActorCategoryCase1;
export type EditThreatEventsTagRequestAliasesItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagRequestAliasesItem {
    value: string;
    confidence?: number;
    tlp?: EditThreatEventsTagRequestAliasesItemTlp | (string & {});
}
export type EditThreatEventsTagRequestAliasesList = Array<EditThreatEventsTagRequestAliasesItem>;
export type EditThreatEventsTagRequestAliasGroupNamesList = Array<string>;
export type EditThreatEventsTagRequestAliasGroupNamesInternalList = Array<string>;
export type EditThreatEventsTagRequestAttributionOrganizationCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagRequestAttributionOrganizationCase1 {
    value: string;
    confidence?: number;
    tlp?: EditThreatEventsTagRequestAttributionOrganizationCase1Tlp | (string & {});
}
export type EditThreatEventsTagRequestAttributionOrganization = string | EditThreatEventsTagRequestAttributionOrganizationCase1;
export type EditThreatEventsTagRequestExternalReferenceLinksList = Array<string>;
export type EditThreatEventsTagRequestExternalReferencesItem = ThreatEventsTagsCreateRequestExternalReferencesItem;
export type EditThreatEventsTagRequestExternalReferencesList = Array<ThreatEventsTagsCreateRequestExternalReferencesItem>;
export type EditThreatEventsTagRequestInternalAliasesItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagRequestInternalAliasesItem {
    value: string;
    confidence?: number;
    tlp?: EditThreatEventsTagRequestInternalAliasesItemTlp | (string & {});
}
export type EditThreatEventsTagRequestInternalAliasesList = Array<EditThreatEventsTagRequestInternalAliasesItem>;
export type EditThreatEventsTagRequestMotiveCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagRequestMotiveCase1 {
    value: string;
    confidence?: number;
    tlp?: EditThreatEventsTagRequestMotiveCase1Tlp | (string & {});
}
export type EditThreatEventsTagRequestMotive = string | EditThreatEventsTagRequestMotiveCase1;
export type EditThreatEventsTagRequestOpsecLevelCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagRequestOpsecLevelCase1 {
    value: string;
    confidence?: number;
    tlp?: EditThreatEventsTagRequestOpsecLevelCase1Tlp | (string & {});
}
export type EditThreatEventsTagRequestOpsecLevel = string | EditThreatEventsTagRequestOpsecLevelCase1;
export type EditThreatEventsTagRequestOriginCountryISOCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagRequestOriginCountryISOCase1 {
    value: string;
    confidence?: number;
    tlp?: EditThreatEventsTagRequestOriginCountryISOCase1Tlp | (string & {});
}
export type EditThreatEventsTagRequestOriginCountryISO = string | EditThreatEventsTagRequestOriginCountryISOCase1;
export type EditThreatEventsTagRequestPriorityCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagRequestPriorityCase1 {
    value: number;
    confidence?: number;
    tlp?: EditThreatEventsTagRequestPriorityCase1Tlp | (string & {});
}
export type EditThreatEventsTagRequestPriority = number | EditThreatEventsTagRequestPriorityCase1;
export type EditThreatEventsTagRequestPropertiesMap = {
    [key: string]: unknown | undefined;
};
export type EditThreatEventsTagRequestSophisticationLevelCase1Tlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagRequestSophisticationLevelCase1 {
    value: string;
    confidence?: number;
    tlp?: EditThreatEventsTagRequestSophisticationLevelCase1Tlp | (string & {});
}
export type EditThreatEventsTagRequestSophisticationLevel = string | EditThreatEventsTagRequestSophisticationLevelCase1;
export type EditThreatEventsTagRequestTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagRequest {
    /** Account ID. */
    accountId: string;
    /** Tag UUID. */
    tagUuid: string;
    activeDuration?: EditThreatEventsTagRequestActiveDuration;
    actorCategory?: EditThreatEventsTagRequestActorCategory;
    /** Structured aliases ({ value, confidence 1-10, tlp }). Public: returned to all accounts with per-entry TLP filtering (entries with tlp: purple are removed for non-CFONE accounts). */
    aliases?: EditThreatEventsTagRequestAliasesList;
    aliasGroupNames?: EditThreatEventsTagRequestAliasGroupNamesList;
    aliasGroupNamesInternal?: EditThreatEventsTagRequestAliasGroupNamesInternalList;
    attributionOrganization?: EditThreatEventsTagRequestAttributionOrganization;
    /** Tag type (category) UUID. When changed, existing `properties` are re-validated against the new category's schema (400 on mismatch). Set to null to unlink (typeless; properties stop being validated). */
    categoryUuid?: string;
    /** Overall tag confidence (1-10). Omit to preserve existing. */
    confidence?: number;
    /** Date of discovery (ISO YYYY-MM-DD). Omit to preserve existing. */
    dateOfDiscovery?: string;
    description?: string;
    externalReferenceLinks?: EditThreatEventsTagRequestExternalReferenceLinksList;
    /** Structured external references ({ url, description }). Public: returned to all accounts. */
    externalReferences?: EditThreatEventsTagRequestExternalReferencesList;
    /** Owner-private structured aliases ({ value, confidence 1-10, tlp }). Returned to the owning account and omitted from shared-catalog non-owner responses. */
    internalAliases?: EditThreatEventsTagRequestInternalAliasesList;
    internalDescription?: string;
    lastSeen?: string;
    motive?: EditThreatEventsTagRequestMotive;
    opsecLevel?: EditThreatEventsTagRequestOpsecLevel;
    originCountryISO?: EditThreatEventsTagRequestOriginCountryISO;
    priority?: EditThreatEventsTagRequestPriority;
    /** Custom field values blob. When omitted, the existing value is preserved. When provided, performs a shallow per-key merge over the stored value (unmentioned keys are retained). Setting an individual key to null deletes that key. Validation runs against the merged result, so a partial update may omit a schema-required key if the stored value supplies it. */
    properties?: EditThreatEventsTagRequestPropertiesMap;
    sophisticationLevel?: EditThreatEventsTagRequestSophisticationLevel;
    /** Tag-level TLP marking. Omit to preserve existing. Cannot be cleared to null. */
    tlp?: EditThreatEventsTagRequestTlp | (string & {});
    value?: string;
}
export type EditThreatEventsTagResponseActiveDurationAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagResponseActiveDurationAnnotated {
    value: string;
    tlp?: EditThreatEventsTagResponseActiveDurationAnnotatedTlp | null;
}
export type EditThreatEventsTagResponseActorCategoryAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagResponseActorCategoryAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: EditThreatEventsTagResponseActorCategoryAnnotatedTlp | null;
}
export type EditThreatEventsTagResponseAliasesItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagResponseAliasesItem {
    value: string;
    confidence?: number | null;
    tlp?: EditThreatEventsTagResponseAliasesItemTlp | null;
}
export type EditThreatEventsTagResponseAliasesList = Array<EditThreatEventsTagResponseAliasesItem>;
export type EditThreatEventsTagResponseAliasGroupNamesList = Array<string>;
export type EditThreatEventsTagResponseAliasGroupNamesInternalList = Array<string>;
export type EditThreatEventsTagResponseAttributionOrganizationAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagResponseAttributionOrganizationAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: EditThreatEventsTagResponseAttributionOrganizationAnnotatedTlp | null;
}
export type EditThreatEventsTagResponseExternalReferenceLinksList = Array<string>;
export type EditThreatEventsTagResponseExternalReferencesItem = ThreatEventsTagsCreateResponseExternalReferencesItem;
export type EditThreatEventsTagResponseExternalReferencesList = Array<ThreatEventsTagsCreateResponseExternalReferencesItem>;
export type EditThreatEventsTagResponseExternalReferencesAnnotatedItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagResponseExternalReferencesAnnotatedItem {
    value: string;
    tlp?: EditThreatEventsTagResponseExternalReferencesAnnotatedItemTlp | null;
}
export type EditThreatEventsTagResponseExternalReferencesAnnotatedList = Array<EditThreatEventsTagResponseExternalReferencesAnnotatedItem>;
export type EditThreatEventsTagResponseInternalAliasesItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagResponseInternalAliasesItem {
    value: string;
    confidence?: number | null;
    tlp?: EditThreatEventsTagResponseInternalAliasesItemTlp | null;
}
export type EditThreatEventsTagResponseInternalAliasesList = Array<EditThreatEventsTagResponseInternalAliasesItem>;
export type EditThreatEventsTagResponseMotiveAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagResponseMotiveAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: EditThreatEventsTagResponseMotiveAnnotatedTlp | null;
}
export type EditThreatEventsTagResponseOpsecLevelAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagResponseOpsecLevelAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: EditThreatEventsTagResponseOpsecLevelAnnotatedTlp | null;
}
export type EditThreatEventsTagResponseOriginCountryISOAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagResponseOriginCountryISOAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: EditThreatEventsTagResponseOriginCountryISOAnnotatedTlp | null;
}
export type EditThreatEventsTagResponsePriorityAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagResponsePriorityAnnotated {
    value: number;
    tlp?: EditThreatEventsTagResponsePriorityAnnotatedTlp | null;
}
export type EditThreatEventsTagResponsePropertiesMap = {
    [key: string]: unknown | undefined;
};
export type EditThreatEventsTagResponseSophisticationLevelAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface EditThreatEventsTagResponseSophisticationLevelAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: EditThreatEventsTagResponseSophisticationLevelAnnotatedTlp | null;
}
export type EditThreatEventsTagResponseTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface EditThreatEventsTagResponse {
    uuid: string;
    value: string;
    activeDuration?: string | null;
    activeDurationAnnotated?: EditThreatEventsTagResponseActiveDurationAnnotated | null;
    actorCategory?: string | null;
    actorCategoryAnnotated?: EditThreatEventsTagResponseActorCategoryAnnotated | null;
    /** Structured aliases ({ value, confidence 1-10, tlp }). Public: returned to all accounts with per-entry TLP filtering (entries with tlp: purple are removed for non-CFONE accounts). */
    aliases?: EditThreatEventsTagResponseAliasesList | null;
    aliasGroupNames?: EditThreatEventsTagResponseAliasGroupNamesList | null;
    aliasGroupNamesInternal?: EditThreatEventsTagResponseAliasGroupNamesInternalList | null;
    attributionOrganization?: string | null;
    attributionOrganizationAnnotated?: EditThreatEventsTagResponseAttributionOrganizationAnnotated | null;
    categoryName?: string | null;
    categoryUuid?: string | null;
    /** Overall tag confidence (1-10). */
    confidence?: number | null;
    createdAt?: string | null;
    dateOfDiscovery?: string | null;
    description?: string | null;
    externalReferenceLinks?: EditThreatEventsTagResponseExternalReferenceLinksList | null;
    /** Structured external references ({ url, description }). Public: returned to all accounts. */
    externalReferences?: EditThreatEventsTagResponseExternalReferencesList | null;
    externalReferencesAnnotated?: EditThreatEventsTagResponseExternalReferencesAnnotatedList | null;
    /** Owner-private structured aliases ({ value, confidence 1-10, tlp }). Returned to the owning account and omitted from shared-catalog non-owner responses. */
    internalAliases?: EditThreatEventsTagResponseInternalAliasesList | null;
    internalDescription?: string | null;
    lastSeen?: string | null;
    motive?: string | null;
    motiveAnnotated?: EditThreatEventsTagResponseMotiveAnnotated | null;
    opsecLevel?: string | null;
    opsecLevelAnnotated?: EditThreatEventsTagResponseOpsecLevelAnnotated | null;
    /** ISO country code (alpha-2 or alpha-3). Normalized to uppercase on read. Null when stored value is blank/whitespace. */
    originCountryISO?: string | null;
    originCountryISOAnnotated?: EditThreatEventsTagResponseOriginCountryISOAnnotated | null;
    priority?: number | null;
    priorityAnnotated?: EditThreatEventsTagResponsePriorityAnnotated | null;
    /** Parsed custom field values. Null when the tag has no custom fields. */
    properties?: EditThreatEventsTagResponsePropertiesMap | null;
    sophisticationLevel?: string | null;
    sophisticationLevelAnnotated?: EditThreatEventsTagResponseSophisticationLevelAnnotated | null;
    /** Tag-level TLP handling marking. */
    tlp?: EditThreatEventsTagResponseTlp | null;
    updatedAt?: string | null;
    version?: number | null;
}
export type EditThreatEventsTagsCategoryRequestSchemaItemKind = "string" | "number" | "enum" | "date" | "array" | "object";
export type EditThreatEventsTagsCategoryRequestSchemaItemAllowedValuesList = Array<string>;
export type EditThreatEventsTagsCategoryRequestSchemaItemAnnotations = CreateThreatEventsTagsCategoryRequestSchemaItemAnnotations;
export type EditThreatEventsTagsCategoryRequestSchemaItemDeprecatedValuesList = Array<string>;
export type EditThreatEventsTagsCategoryRequestSchemaItemEnforcement = "error" | "warn" | "off";
export type EditThreatEventsTagsCategoryRequestSchemaItemFormat = "date" | "url" | "duration" | "country";
export type EditThreatEventsTagsCategoryRequestSchemaItemNumberConstraint = CreateThreatEventsTagsCategoryRequestSchemaItemNumberConstraint;
export type EditThreatEventsTagsCategoryRequestSchemaItemPropertiesMap = {
    [key: string]: unknown | undefined;
};
export interface EditThreatEventsTagsCategoryRequestSchemaItem {
    key: string;
    kind: EditThreatEventsTagsCategoryRequestSchemaItemKind | (string & {});
    allowedValues?: EditThreatEventsTagsCategoryRequestSchemaItemAllowedValuesList;
    annotations?: CreateThreatEventsTagsCategoryRequestSchemaItemAnnotations;
    /** Marks a field as unavailable for new values while retaining its definition for historical values. */
    deprecated?: boolean;
    /** Enum values unavailable for new writes but retained in allowedValues for historical display. */
    deprecatedValues?: EditThreatEventsTagsCategoryRequestSchemaItemDeprecatedValuesList;
    element?: unknown;
    enforcement?: EditThreatEventsTagsCategoryRequestSchemaItemEnforcement | (string & {});
    format?: EditThreatEventsTagsCategoryRequestSchemaItemFormat | (string & {});
    label?: string;
    /** exclusiveMinimum */
    maxLength?: number;
    numberConstraint?: CreateThreatEventsTagsCategoryRequestSchemaItemNumberConstraint;
    /** Map of property key to FieldDefinition for object fields. Required when kind is 'object'. See FieldDefinition (recursive). */
    properties?: EditThreatEventsTagsCategoryRequestSchemaItemPropertiesMap;
    required?: boolean;
}
export type EditThreatEventsTagsCategoryRequestSchemaList = Array<EditThreatEventsTagsCategoryRequestSchemaItem>;
export interface EditThreatEventsTagsCategoryRequest {
    /** Account ID. */
    accountId: string;
    /** Tag Category UUID. */
    categoryUuid: string;
    description?: string;
    name?: string;
    /** Optional array of FieldDefinition objects. When provided, replaces the existing field schema. When omitted, the existing schema is preserved. */
    schema?: EditThreatEventsTagsCategoryRequestSchemaList;
}
export type EditThreatEventsTagsCategoryResponseSchemaItemKind = "string" | "number" | "enum" | "date" | "array" | "object";
export type EditThreatEventsTagsCategoryResponseSchemaItemAllowedValuesList = Array<string>;
export type EditThreatEventsTagsCategoryResponseSchemaItemAnnotations = CreateThreatEventsTagsCategoryResponseSchemaItemAnnotations;
export type EditThreatEventsTagsCategoryResponseSchemaItemDeprecatedValuesList = Array<string>;
export type EditThreatEventsTagsCategoryResponseSchemaItemEnforcement = "error" | "warn" | "off";
export type EditThreatEventsTagsCategoryResponseSchemaItemFormat = "date" | "url" | "duration" | "country";
export type EditThreatEventsTagsCategoryResponseSchemaItemNumberConstraint = CreateThreatEventsTagsCategoryResponseSchemaItemNumberConstraint;
export type EditThreatEventsTagsCategoryResponseSchemaItemPropertiesMap = {
    [key: string]: unknown | undefined;
};
export interface EditThreatEventsTagsCategoryResponseSchemaItem {
    key: string;
    kind: EditThreatEventsTagsCategoryResponseSchemaItemKind;
    allowedValues?: EditThreatEventsTagsCategoryResponseSchemaItemAllowedValuesList | null;
    annotations?: CreateThreatEventsTagsCategoryResponseSchemaItemAnnotations | null;
    /** Marks a field as unavailable for new values while retaining its definition for historical values. */
    deprecated?: boolean | null;
    /** Enum values unavailable for new writes but retained in allowedValues for historical display. */
    deprecatedValues?: EditThreatEventsTagsCategoryResponseSchemaItemDeprecatedValuesList | null;
    element?: unknown | null;
    enforcement?: EditThreatEventsTagsCategoryResponseSchemaItemEnforcement | null;
    format?: EditThreatEventsTagsCategoryResponseSchemaItemFormat | null;
    label?: string | null;
    /** exclusiveMinimum */
    maxLength?: number | null;
    numberConstraint?: CreateThreatEventsTagsCategoryResponseSchemaItemNumberConstraint | null;
    /** Map of property key to FieldDefinition for object fields. Required when kind is 'object'. See FieldDefinition (recursive). */
    properties?: EditThreatEventsTagsCategoryResponseSchemaItemPropertiesMap | null;
    required?: boolean | null;
}
export type EditThreatEventsTagsCategoryResponseSchemaList = Array<EditThreatEventsTagsCategoryResponseSchemaItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface EditThreatEventsTagsCategoryResponse {
    name: string;
    uuid: string;
    createdAt?: string | null;
    description?: string | null;
    /** Parsed FieldDefinition[] defining custom fields for this category, or null if none. */
    schema?: EditThreatEventsTagsCategoryResponseSchemaList | null;
    updatedAt?: string | null;
}
export interface EditThreatSignalsArticleRequest {
    accountId: string;
    /** Threat Signals article UUID */
    articleId: string;
    /** True to mark the article read, false to mark unread. */
    read: boolean;
}
export interface EditThreatSignalsArticleResponseBulletPoints {
    impact: string;
    whatHappened: string;
    whoAffected: string;
}
export type EditThreatSignalsArticleResponseIndicatorExtractionStatus = "in_progress" | "complete" | "failed" | "unknown";
export type EditThreatSignalsArticleResponseMetadataMap = {
    [key: string]: unknown | undefined;
};
export type EditThreatSignalsArticleResponseTagsItemAppliedBy = "ai" | "analyst" | "system";
export interface EditThreatSignalsArticleResponseTagsItem {
    appliedBy: EditThreatSignalsArticleResponseTagsItemAppliedBy;
    categoryId: string;
    uuid: string;
    value: string;
}
export type EditThreatSignalsArticleResponseTagsList = Array<EditThreatSignalsArticleResponseTagsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditThreatSignalsArticleResponse {
    id: string;
    bulletPoints: EditThreatSignalsArticleResponseBulletPoints;
    contentR2Key: string;
    feedDisplayName: string;
    feedId: string;
    fetchedAt: string;
    /** Progress of the article's indicator extraction and IOC contextualization run. complete and failed are terminal; unknown means no run has been recorded. */
    indicatorExtractionStatus: EditThreatSignalsArticleResponseIndicatorExtractionStatus;
    link: string;
    metadata: EditThreatSignalsArticleResponseMetadataMap;
    publishedAt: string;
    read: boolean;
    readAt: string;
    sourceCount: number;
    /** Persisted enrichment summary. Null until enrichment produces a summary. */
    summary: string;
    summaryR2Key: string;
    tags: EditThreatSignalsArticleResponseTagsList;
    title: string;
    skillVersion?: string | null;
    tagSkillVersion?: string | null;
}
export type EditThreatSignalsFeedRequestCategoryId = "b12a0fd6-f7b9-5393-9ef3-f888d506c550" | "d5b70eaa-626f-5761-b55b-6d9590df49fb" | "3b572d2b-890d-5286-9433-f18c85079030" | "17f90d3b-37d3-5241-8ad4-7d6abbc2006c" | "c68f28e9-7e8f-5d4b-853b-f3076893a9ee" | "bb0e4a94-38ab-5c14-80a7-28cee9f4b139" | "b1ef66d9-a73c-58dc-b269-22d34dfd11f4" | "ab02a976-0a20-5c76-a553-7f6325afacfe";
export interface EditThreatSignalsFeedRequest {
    accountId: string;
    /** UUID of the Threat Signals feed */
    feedId: string;
    /** One of the predefined Threat Signals feed categories; see GET /:account_id/v2/threat-signals/categories. */
    categoryId?: EditThreatSignalsFeedRequestCategoryId | (string & {});
    /** Override the feed's display name. Null clears it; omit to keep existing or derived value. */
    displayName?: string;
    /** Whether to actively poll the feed. Omit to keep current value. */
    enabled?: boolean;
    /** New polling interval in seconds (60-86400). Omit to keep current value. */
    pollIntervalS?: number;
    /** Override the feed's title. Null clears it; omit to keep existing or derived value. */
    title?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditThreatSignalsFeedResponse {
    id: string;
    /** Feed category identifier. Null when unset. */
    categoryId: string;
    /** Display name of the feed category. Null when unset or unresolvable. */
    categoryName: string;
    createdAt: string;
    /** Curated catalog feed this subscription was created from. Null for custom feeds. */
    curatedFeedId: string;
    displayName: string;
    enabled: boolean;
    lastPolledAt: string;
    pollIntervalS: number;
    /** `custom` for a feed added by URL, `curated` for a curated catalog feed. */
    sourceType: string;
    /** Polling health: `active`, or `error` after a failed poll. */
    status: string;
    subscribedAt: string;
    title: string;
    updatedAt: string;
    url: string;
}
export interface EditThreatSignalsSkillRequest {
    accountId: string;
    /** Custom Skill UUID or a Managed Default Skill ID */
    skillId: string;
    /** Optional skill configuration (stored but not currently interpreted). */
    config?: string;
    /** Whether the skill is active and eligible for feed assignment. */
    isActive?: boolean;
    /** Custom Skill name (1-100 characters). */
    name?: string;
    /** JSON Schema serialized as a string (max 4096 characters). */
    outputSchema?: string;
    /** AI prompt (1-4000 characters) defining the skill's instructions. */
    prompt?: string;
}
export type EditThreatSignalsSkillResponseSource = "default" | "custom";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditThreatSignalsSkillResponse {
    id: string;
    /** JSON-encoded skill configuration. Always null for default skills. */
    config: string;
    createdAt: string;
    /** 1 when active, 0 when inactive. */
    isActive: number;
    name: string;
    /** JSON-encoded JSON Schema the skill output must satisfy. */
    outputSchema: string;
    prompt: string;
    /** `default` for Cloudforce One managed skills (read-only), `custom` for account skills. */
    source: EditThreatSignalsSkillResponseSource;
    type: string;
    updatedAt: string;
}
export interface GenerateThreatSignalsArticlesTagRequest {
    accountId: string;
    /** Threat Signals article UUID */
    articleId: string;
}
export type GenerateThreatSignalsArticlesTagResponseTagsItemAppliedBy = "ai" | "analyst" | "system";
export interface GenerateThreatSignalsArticlesTagResponseTagsItem {
    appliedBy: GenerateThreatSignalsArticlesTagResponseTagsItemAppliedBy;
    categoryId: string;
    uuid: string;
    value: string;
}
export type GenerateThreatSignalsArticlesTagResponseTagsList = Array<GenerateThreatSignalsArticlesTagResponseTagsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GenerateThreatSignalsArticlesTagResponse {
    tagSkillVersion: string;
    /** Final hydrated assignment set; may be empty when no applicable tags are selected. */
    tags: GenerateThreatSignalsArticlesTagResponseTagsList;
}
export interface GetBinaryStorageRequest {
    /** Account ID. */
    accountId: string;
    /** hash of the binary */
    hash: string;
}
export interface GetBinaryStorageResponse {
}
export interface GetRequestRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
}
export type RequestsGetResponseTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export type RequestsGetResponseStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRequestResponse {
    /** UUID. */
    id: string;
    /** Request content. */
    content: string;
    created: string;
    priority: string;
    /** Requested information from request. */
    request: string;
    /** Brief description of the request. */
    summary: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsGetResponseTlp;
    updated: string;
    completed?: string | null;
    /** Tokens for the request messages. */
    messageTokens?: number | null;
    /** Readable Request ID. */
    readableId?: string | null;
    /** Request Status. */
    status?: RequestsGetResponseStatus | null;
    /** Tokens for the request. */
    tokens?: number | null;
}
export type RequestsMessageGetRequestSortOrder = "asc" | "desc";
export interface GetRequestMessageRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** Page number of results. */
    page: number;
    /** Number of results per page. */
    perPage: number;
    /** Retrieve mes ges created after this time. */
    after?: string;
    /** Retrieve messages created before this time. */
    before?: string;
    /** Field to sort results by. */
    sortBy?: string;
    /** Sort order (asc or desc). */
    sortOrder?: RequestsMessageGetRequestSortOrder | (string & {});
}
export interface RequestsMessageGetResultItem {
    /** Message ID. */
    id: number;
    /** Author of message. */
    author: string;
    /** Content of message. */
    content: string;
    /** Whether the message is a follow-on request. */
    isFollowOnRequest: boolean;
    /** Defines the message last updated time. */
    updated: string;
    /** Defines the message creation time. */
    created?: string | null;
}
export type RequestsMessageGetResultList = Array<RequestsMessageGetResultItem>;
export interface GetRequestMessageResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RequestsMessageGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetRequestPriorityRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    priorityId: string;
}
export type RequestsPriorityGetResponseTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export type RequestsPriorityGetResponseStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRequestPriorityResponse {
    /** UUID. */
    id: string;
    /** Request content. */
    content: string;
    created: string;
    priority: string;
    /** Requested information from request. */
    request: string;
    /** Brief description of the request. */
    summary: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsPriorityGetResponseTlp;
    updated: string;
    completed?: string | null;
    /** Tokens for the request messages. */
    messageTokens?: number | null;
    /** Readable Request ID. */
    readableId?: string | null;
    /** Request Status. */
    status?: RequestsPriorityGetResponseStatus | null;
    /** Tokens for the request. */
    tokens?: number | null;
}
export interface GetRequestsAssetRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** UUID. */
    assetId: string;
}
export type GetRequestsAssetResultItem = RequestsAssetsCreateResultItem;
export type GetRequestsAssetResultList = Array<RequestsAssetsCreateResultItem>;
export type GetRequestsAssetResponse = GetRequestsAssetResultList;
export interface GetScanResultRequest {
    /** Defines the Account ID. */
    accountId: string;
    /** Defines the Config ID. */
    configId: string;
}
export interface ScansResultsGetResponse1111Item {
    number?: number | null;
    proto?: string | null;
    status?: string | null;
}
export type ScansResultsGetResponse1111List = Array<ScansResultsGetResponse1111Item>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScanResultResponse {
    "1_1_1_1": ScansResultsGetResponse1111List;
}
export interface GetThreatEventRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
}
export type ThreatEventsGetResponseMitreAttackList = Array<string>;
export type ThreatEventsGetResponseMitreCapecList = Array<string>;
export type ThreatEventsGetResponseReferencedList = Array<string>;
export type ThreatEventsGetResponseReferencedIdsList = Array<number>;
export type ThreatEventsGetResponseReferencesList = Array<string>;
export type ThreatEventsGetResponseReferencesIdsList = Array<number>;
export type ThreatEventsGetResponseTagsList = Array<string>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetThreatEventResponse {
    attacker: string;
    attackerCountry: string;
    attackerCountryAlpha3: string;
    category: string;
    datasetId: string;
    date: string;
    event: string;
    hasChildren: boolean;
    indicator: string;
    indicatorType: string;
    indicatorTypeId: number;
    killChain: number;
    mitreAttack: ThreatEventsGetResponseMitreAttackList;
    mitreCapec: ThreatEventsGetResponseMitreCapecList;
    numReferenced: number;
    numReferences: number;
    rawId: string;
    referenced: ThreatEventsGetResponseReferencedList;
    referencedIds: ThreatEventsGetResponseReferencedIdsList;
    references: ThreatEventsGetResponseReferencesList;
    referencesIds: ThreatEventsGetResponseReferencesIdsList;
    tags: ThreatEventsGetResponseTagsList;
    targetCountry: string;
    targetCountryAlpha3: string;
    targetIndustry: string;
    tlp: string;
    uuid: string;
    insight?: string | null;
    releasabilityId?: string | null;
}
export interface GetThreatEventCategoryRequest {
    /** Account ID. */
    accountId: string;
    /** Category UUID. */
    categoryId: string;
}
export type ThreatEventsCategoriesGetResponseMitreAttackList = Array<string>;
export type ThreatEventsCategoriesGetResponseMitreCapecList = Array<string>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetThreatEventCategoryResponse {
    killChain: number;
    name: string;
    uuid: string;
    mitreAttack?: ThreatEventsCategoriesGetResponseMitreAttackList | null;
    mitreCapec?: ThreatEventsCategoriesGetResponseMitreCapecList | null;
    shortname?: string | null;
}
export interface GetThreatEventDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset ID. */
    datasetId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetThreatEventDatasetResponse {
    isAnalytics: boolean;
    isPublic: boolean;
    name: string;
    uuid: string;
}
export interface GetThreatEventRawRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
    /** Raw Event UUID. */
    rawId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetThreatEventRawResponse {
    id: string;
    accountId: number;
    created: string;
    data: unknown;
    source: string;
    tlp: string;
}
export interface GetThreatEventsDatasetsEventRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset ID. */
    datasetId: string;
    /** Event UUID. */
    eventId: string;
}
export type GetThreatEventsDatasetsEventResponseMitreAttackList = Array<string>;
export type GetThreatEventsDatasetsEventResponseMitreCapecList = Array<string>;
export type GetThreatEventsDatasetsEventResponseReferencedList = Array<string>;
export type GetThreatEventsDatasetsEventResponseReferencedIdsList = Array<number>;
export type GetThreatEventsDatasetsEventResponseReferencesList = Array<string>;
export type GetThreatEventsDatasetsEventResponseReferencesIdsList = Array<number>;
export type GetThreatEventsDatasetsEventResponseTagsList = Array<string>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetThreatEventsDatasetsEventResponse {
    attacker: string;
    attackerCountry: string;
    attackerCountryAlpha3: string;
    category: string;
    datasetId: string;
    date: string;
    event: string;
    hasChildren: boolean;
    indicator: string;
    indicatorType: string;
    indicatorTypeId: number;
    killChain: number;
    mitreAttack: GetThreatEventsDatasetsEventResponseMitreAttackList;
    mitreCapec: GetThreatEventsDatasetsEventResponseMitreCapecList;
    numReferenced: number;
    numReferences: number;
    rawId: string;
    referenced: GetThreatEventsDatasetsEventResponseReferencedList;
    referencedIds: GetThreatEventsDatasetsEventResponseReferencedIdsList;
    references: GetThreatEventsDatasetsEventResponseReferencesList;
    referencesIds: GetThreatEventsDatasetsEventResponseReferencesIdsList;
    tags: GetThreatEventsDatasetsEventResponseTagsList;
    targetCountry: string;
    targetCountryAlpha3: string;
    targetIndustry: string;
    tlp: string;
    uuid: string;
    insight?: string | null;
    releasabilityId?: string | null;
}
export interface GetThreatEventsIndicatorsByDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset ID. */
    datasetId: string;
    /** Indicator UUID. */
    indicatorId: string;
}
export interface GetThreatEventsIndicatorsByDatasetResponseRelatedEventsItem {
    datasetId: string;
    eventId: string;
    /** ISO 8601 date of the related event. Null for legacy relationships created before event-date tracking was added. */
    eventDate?: string | null;
}
export type GetThreatEventsIndicatorsByDatasetResponseRelatedEventsList = Array<GetThreatEventsIndicatorsByDatasetResponseRelatedEventsItem>;
export interface GetThreatEventsIndicatorsByDatasetResponseTagsItem {
    /** The UUID of the tag category, or null when the tag is uncategorized. */
    categoryId?: string | null;
    categoryName?: string | null;
    uuid?: string | null;
    value?: string | null;
}
export type GetThreatEventsIndicatorsByDatasetResponseTagsList = Array<GetThreatEventsIndicatorsByDatasetResponseTagsItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetThreatEventsIndicatorsByDatasetResponse {
    createdAt: string;
    indicatorType: string;
    updatedAt: string;
    uuid: string;
    value: string;
    /** The dataset ID this indicator belongs to. Included in list responses. */
    datasetId?: string | null;
    /** Related events, capped by `relatedEventsLimit` (default 2). Check `relatedEventsHasMore` to detect a capped list; pass `relatedEventsLimit=-1` to retrieve all of them. */
    relatedEvents?: GetThreatEventsIndicatorsByDatasetResponseRelatedEventsList | null;
    /** True when this indicator appears in more events than `relatedEvents` contains because `relatedEventsLimit` capped the list. Pass `relatedEventsLimit=-1` to retrieve every related event. */
    relatedEventsHasMore?: boolean | null;
    tags?: GetThreatEventsIndicatorsByDatasetResponseTagsList | null;
    /** Traffic Light Protocol designation. UPPERCASE. Possible values: CLEAR, GREEN, AMBER, AMBER-STRICT, RED, PURPLE. Null when not set. */
    tlp?: string | null;
}
export interface GetThreatEventsQueryRequest {
    /** Account ID. */
    accountId: string;
    /** Event query ID */
    queryId: number;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetThreatEventsQueryResponse {
    /** Unique identifier for the saved query */
    id: number;
    /** Account ID */
    accountId: number;
    /** Deprecated: saved-query alerting and rules were removed. Always false. */
    alertEnabled: boolean;
    /** Deprecated: saved-query alerting and rules were removed. Always false. */
    alertRollupEnabled: boolean;
    /** Creation timestamp */
    createdAt: string;
    /** Name of the saved query */
    name: string;
    /** JSON string containing the query parameters */
    queryJson: string;
    /** Deprecated: saved-query alerting and rules were removed. Always false. */
    ruleEnabled: boolean;
    /** Last update timestamp */
    updatedAt: string;
    /** Email of the user who created the query */
    userEmail: string;
    /** Deprecated: saved-query alerting and rules were removed. Always null. */
    customThreatFeedId?: number | null;
    /** Deprecated: saved-query alerting and rules were removed. Always null. */
    ruleListId?: string | null;
    /** Deprecated: saved-query alerting and rules were removed. Always null. */
    ruleScope?: string | null;
}
export interface GetThreatSignalsArticleRequest {
    accountId: string;
    /** Threat Signals article UUID */
    articleId: string;
}
export type GetThreatSignalsArticleResponseBulletPoints = EditThreatSignalsArticleResponseBulletPoints;
export type GetThreatSignalsArticleResponseIndicatorExtractionStatus = "in_progress" | "complete" | "failed" | "unknown";
export type GetThreatSignalsArticleResponseMetadataMap = {
    [key: string]: unknown | undefined;
};
export type GetThreatSignalsArticleResponseTagsItemAppliedBy = "ai" | "analyst" | "system";
export interface GetThreatSignalsArticleResponseTagsItem {
    appliedBy: GetThreatSignalsArticleResponseTagsItemAppliedBy;
    categoryId: string;
    uuid: string;
    value: string;
}
export type GetThreatSignalsArticleResponseTagsList = Array<GetThreatSignalsArticleResponseTagsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetThreatSignalsArticleResponse {
    id: string;
    bulletPoints: EditThreatSignalsArticleResponseBulletPoints;
    contentR2Key: string;
    feedDisplayName: string;
    feedId: string;
    fetchedAt: string;
    /** Progress of the article's indicator extraction and IOC contextualization run. complete and failed are terminal; unknown means no run has been recorded. */
    indicatorExtractionStatus: GetThreatSignalsArticleResponseIndicatorExtractionStatus;
    link: string;
    metadata: GetThreatSignalsArticleResponseMetadataMap;
    publishedAt: string;
    read: boolean;
    readAt: string;
    sourceCount: number;
    /** Persisted enrichment summary. Null until enrichment produces a summary. */
    summary: string;
    summaryR2Key: string;
    tags: GetThreatSignalsArticleResponseTagsList;
    title: string;
    skillVersion?: string | null;
    tagSkillVersion?: string | null;
}
export type GetThreatSignalsArticlesContentRequestFormat = "text" | "html";
export interface GetThreatSignalsArticlesContentRequest {
    accountId: string;
    /** Threat Signals article UUID */
    articleId: string;
    /** Response Content-Type: text (the default) for text/plain or html for text/html. Neither value converts the content. html is deprecated; use text. */
    format?: GetThreatSignalsArticlesContentRequestFormat | (string & {});
}
export interface GetThreatSignalsArticlesContentResponse {
}
export interface GetThreatSignalsArticlesSkillOutputRequest {
    accountId: string;
    /** Threat Signals article UUID */
    articleId: string;
    /** Custom Skill UUID or a Managed Default Skill ID (IOC-context: default-ioc-context-skill) */
    skillId: string;
}
export type GetThreatSignalsArticlesSkillOutputResponseCustomOutputCase3Map = {
    [key: string]: unknown | undefined;
};
export type GetThreatSignalsArticlesSkillOutputResponseCustomOutputCase4ItemCase3Map = {
    [key: string]: unknown | undefined;
};
export type GetThreatSignalsArticlesSkillOutputResponseCustomOutputCase4Item = string | number | boolean | GetThreatSignalsArticlesSkillOutputResponseCustomOutputCase4ItemCase3Map;
export type GetThreatSignalsArticlesSkillOutputResponseCustomOutputCase4List = Array<GetThreatSignalsArticlesSkillOutputResponseCustomOutputCase4Item>;
export type GetThreatSignalsArticlesSkillOutputResponseCustomOutput = string | number | boolean | GetThreatSignalsArticlesSkillOutputResponseCustomOutputCase3Map | GetThreatSignalsArticlesSkillOutputResponseCustomOutputCase4List;
export type GetThreatSignalsArticlesSkillOutputResponseCustomOutputParseStatus = "parsed" | "invalid_json";
export type GetThreatSignalsArticlesSkillOutputResponseCustomOutputValidationStatus = "valid" | "invalid_json" | "schema_invalid" | "unknown";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetThreatSignalsArticlesSkillOutputResponse {
    /** Article UUID that received the skill output. */
    articleId: string;
    /** Untrusted model output: parsed JSON when the stored completion text is valid JSON, otherwise raw text. Consumers must safely render or escape it. */
    customOutput: GetThreatSignalsArticlesSkillOutputResponseCustomOutput;
    /** Whether custom_output was parsed from the stored completion text. */
    customOutputParseStatus: GetThreatSignalsArticlesSkillOutputResponseCustomOutputParseStatus;
    /** Non-blocking validation classification for untrusted model output. `unknown` is retained only for historical rows. */
    customOutputValidationStatus: GetThreatSignalsArticlesSkillOutputResponseCustomOutputValidationStatus;
    /** Custom Skill version that produced the output. Null when historical metadata is unavailable. */
    customSkillVersion: string;
    /** JSON-encoded output schema. Null when historical skill metadata is unavailable. */
    outputSchema: string;
    /** Custom Skill UUID that produced the output. */
    skillId: string;
}
export type GetThreatSignalsFeedsRawRequestFormat = "xml";
export interface GetThreatSignalsFeedsRawRequest {
    accountId: string;
    /** UUID of the Threat Signals feed */
    feedId: string;
    /** Response format. Use xml for application/xml; omit it for the default text/plain response. */
    format?: GetThreatSignalsFeedsRawRequestFormat | (string & {});
}
export interface GetThreatSignalsFeedsRawResponse {
}
export interface GetThreatSignalsFeedsSkillRequest {
    accountId: string;
    /** UUID of the Threat Signals feed */
    feedId: string;
}
export type GetThreatSignalsFeedsSkillResponseSkillsItemSource = "default" | "custom";
export interface GetThreatSignalsFeedsSkillResponseSkillsItem {
    id: string;
    /** JSON-encoded skill configuration. Always null for default skills. */
    config: string;
    createdAt: string;
    /** 1 when active, 0 when inactive. */
    isActive: number;
    name: string;
    /** JSON-encoded JSON Schema the skill output must satisfy. */
    outputSchema: string;
    prompt: string;
    /** `default` for Cloudforce One managed skills (read-only), `custom` for account skills. */
    source: GetThreatSignalsFeedsSkillResponseSkillsItemSource;
    type: string;
    updatedAt: string;
}
export type GetThreatSignalsFeedsSkillResponseSkillsList = Array<GetThreatSignalsFeedsSkillResponseSkillsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetThreatSignalsFeedsSkillResponse {
    feedId: string;
    skills: GetThreatSignalsFeedsSkillResponseSkillsList;
}
export interface GetThreatSignalsSkillRequest {
    accountId: string;
    /** Custom Skill UUID or a Managed Default Skill ID */
    skillId: string;
}
export type GetThreatSignalsSkillResponseSource = "default" | "custom";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetThreatSignalsSkillResponse {
    id: string;
    /** JSON-encoded skill configuration. Always null for default skills. */
    config: string;
    createdAt: string;
    /** 1 when active, 0 when inactive. */
    isActive: number;
    name: string;
    /** JSON-encoded JSON Schema the skill output must satisfy. */
    outputSchema: string;
    prompt: string;
    /** `default` for Cloudforce One managed skills (read-only), `custom` for account skills. */
    source: GetThreatSignalsSkillResponseSource;
    type: string;
    updatedAt: string;
}
export type GetThreatSignalsSkillsTagCategoryRequestSkillId = "default-tagging-skill";
export interface GetThreatSignalsSkillsTagCategoryRequest {
    accountId: string;
    /** Must be default-tagging-skill; configures the managed default tagging skill */
    skillId: GetThreatSignalsSkillsTagCategoryRequestSkillId | (string & {});
}
export type GetThreatSignalsSkillsTagCategoryResponseCategoryUuidsList = Array<string>;
export type GetThreatSignalsSkillsTagCategoryResponseSkillId = "default-tagging-skill";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetThreatSignalsSkillsTagCategoryResponse {
    categoryUuids: GetThreatSignalsSkillsTagCategoryResponseCategoryUuidsList;
    skillId: GetThreatSignalsSkillsTagCategoryResponseSkillId;
}
export type ListRequestsRequestSortOrder = "asc" | "desc";
export type ListRequestsRequestStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
export interface ListRequestsRequest {
    /** Identifier. */
    accountId: string;
    /** Page number of results. */
    page: number;
    /** Number of results per page. */
    perPage: number;
    /** Retrieve requests completed after this time. */
    completedAfter?: string;
    /** Retrieve requests completed before this time. */
    completedBefore?: string;
    /** Retrieve requests created after this time. */
    createdAfter?: string;
    /** Retrieve requests created before this time. */
    createdBefore?: string;
    /** Requested information from request. */
    requestType?: string;
    /** Field to sort results by. */
    sortBy?: string;
    /** Sort order (asc or desc). */
    sortOrder?: ListRequestsRequestSortOrder | (string & {});
    /** Request Status. */
    status?: ListRequestsRequestStatus | (string & {});
}
export type ListRequestsResultItemPriority = "routine" | "high" | "urgent";
export type ListRequestsResultItemTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export type ListRequestsResultItemStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
export interface ListRequestsResultItem {
    /** UUID. */
    id: string;
    /** Request creation time. */
    created: string;
    priority: ListRequestsResultItemPriority;
    /** Requested information from request. */
    request: string;
    /** Brief description of the request. */
    summary: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: ListRequestsResultItemTlp;
    /** Request last updated time. */
    updated: string;
    /** Request completion time. */
    completed?: string | null;
    /** Tokens for the request messages. */
    messageTokens?: number | null;
    /** Readable Request ID. */
    readableId?: string | null;
    /** Request Status. */
    status?: ListRequestsResultItemStatus | null;
    /** Tokens for the request. */
    tokens?: number | null;
}
export type ListRequestsResultList = Array<ListRequestsResultItem>;
export type ListRequestsResponse = ListRequestsResultList;
export interface ListScanConfigsRequest {
    /** Defines the Account ID. */
    accountId: string;
}
export type ScansConfigListResultItemIpsList = Array<string>;
export type ScansConfigListResultItemPortsList = Array<string>;
export interface ScansConfigListResultItem {
    /** Defines the Config ID. */
    id: string;
    accountId: string;
    /** Defines the number of days between each scan (0 = One-off scan). */
    frequency: number;
    /** Defines a list of IP addresses or CIDR blocks to scan. The maximum number of total IP addresses allowed is 5000. */
    ips: ScansConfigListResultItemIpsList;
    /** Defines a list of ports to scan. Valid values are:"default", "all", or a comma-separated list of ports or range of ports (e.g. ["1-80", "443"]). "default" scans the 100 most commonly open ports. */
    ports: ScansConfigListResultItemPortsList;
}
export type ScansConfigListResultList = Array<ScansConfigListResultItem>;
export interface ListScanConfigsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ScansConfigListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ThreatEventsAttackersListRequestDatasetIdsList = Array<string>;
export interface ListThreatEventAttackersRequest {
    /** Account ID. */
    accountId: string;
    /** Array of dataset IDs to query attackers from. If not provided, uses the default dataset. */
    datasetIds?: ThreatEventsAttackersListRequestDatasetIdsList;
}
export interface ThreatEventsAttackersListResponseItems {
    type: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventAttackersResponse {
    items: ThreatEventsAttackersListResponseItems;
    type: string;
}
export type ThreatEventsCategoriesListRequestDatasetIdsList = Array<string>;
export interface ListThreatEventCategoriesRequest {
    /** Account ID. */
    accountId: string;
    /** Array of dataset IDs to query categories from. If not provided, uses the default dataset. */
    datasetIds?: ThreatEventsCategoriesListRequestDatasetIdsList;
}
export type ThreatEventsCategoriesListResponseMitreAttackList = Array<string>;
export type ThreatEventsCategoriesListResponseMitreCapecList = Array<string>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventCategoriesResponse {
    killChain: number;
    name: string;
    uuid: string;
    mitreAttack?: ThreatEventsCategoriesListResponseMitreAttackList | null;
    mitreCapec?: ThreatEventsCategoriesListResponseMitreCapecList | null;
    shortname?: string | null;
}
export interface ListThreatEventCountriesRequest {
    /** Account ID. */
    accountId: string;
}
export interface ThreatEventsCountriesListResultItem {
    alpha2: string;
    alpha3: string;
    name: string;
}
export type ThreatEventsCountriesListResultList = Array<ThreatEventsCountriesListResultItem>;
export type ListThreatEventCountriesResponse = ThreatEventsCountriesListResultList;
export interface ListThreatEventDatasetsRequest {
    /** Account ID. */
    accountId: string;
    /** When true, include soft-deleted datasets in the response. Each item includes a `deletedAt` field (ISO 8601 or null). Default: false. */
    includeDeleted?: boolean;
}
export type ThreatEventsDatasetsListResponseIndicatorWriteMode = "read_only" | "create_only" | "full";
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventDatasetsResponse {
    /** Effective indicator mutation capability after account/dataset authorization and dataset storage capability are applied. API Gateway method permissions are separate and must also allow the requested operation. */
    indicatorWriteMode: ThreatEventsDatasetsListResponseIndicatorWriteMode;
    isAnalytics: boolean;
    isPublic: boolean;
    name: string;
    uuid: string;
    deletedAt?: string | null;
}
export interface ListThreatEventIndicatorTypesRequest {
    /** Account ID. */
    accountId: string;
}
export type ThreatEventsIndicatorTypesListResponseItems = ThreatEventsAttackersListResponseItems;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventIndicatorTypesResponse {
    items: ThreatEventsAttackersListResponseItems;
    type: string;
}
export type ThreatEventsListRequestCache = "from-graph";
export type ThreatEventsListRequestDatasetIdList = Array<string>;
export type ThreatEventsListRequestFormat = "json" | "stix2" | "taxii";
export type ThreatEventsListRequestOrder = "asc" | "desc";
export type ThreatEventsListRequestSearchList = Array<string>;
export type ThreatEventsListRequestSearchBranchesList = Array<string>;
export interface ListThreatEventsRequest {
    /** Account ID. */
    accountId: string;
    /** Cache strategy. 'from-graph' serves results from the graph-node KV cache when all requested UUIDs are cached; falls back to normal path on partial/zero hit. */
    cache?: ThreatEventsListRequestCache | (string & {});
    /** Cursor for pagination. When provided, filters are embedded in the cursor so you only need to pass cursor and pageSize. Returned in the previous response's result_info.cursor field. Use cursor-based pagination for deep pagination (beyond 100,000 records) or for optimal performance. */
    cursor?: string;
    /** Dataset UUIDs to query, or one standalone scope value: 'all'/'*' or 'operational' for readable intelligence datasets (isAnalytics=false), or 'analytics' for readable analytics datasets (isAnalytics=true). Scope values query at most 50 datasets. If not provided, uses the default dataset. */
    datasetId?: ThreatEventsListRequestDatasetIdList;
    forceRefresh?: boolean;
    format?: ThreatEventsListRequestFormat | (string & {});
    order?: ThreatEventsListRequestOrder | (string & {});
    orderBy?: string;
    /** Page number (1-indexed) for offset-based pagination. Limited to offset of 100,000 records. For deep pagination, use cursor-based pagination instead. */
    page?: number;
    /** Number of results per page. Maximum 25,000. */
    pageSize?: number;
    search?: ThreatEventsListRequestSearchList;
    /** JSON-encoded. OR branches of structured search filters. Filters within a branch are AND'd, branches are OR'd, and the result is AND'd with `search`: `AND(search) AND OR(AND(branch 1), ...)`. Max 8 branches of 1-10 conditions each. Not supported for analytics datasets, and `indicator` filters are not yet supported inside branches. Cursor pages carry the original branches, so do not resend them with `cursor`. */
    searchBranches?: ThreatEventsListRequestSearchBranchesList;
}
export type ThreatEventsListResponseMitreAttackList = Array<string>;
export type ThreatEventsListResponseMitreCapecList = Array<string>;
export type ThreatEventsListResponseReferencedList = Array<string>;
export type ThreatEventsListResponseReferencedIdsList = Array<number>;
export type ThreatEventsListResponseReferencesList = Array<string>;
export type ThreatEventsListResponseReferencesIdsList = Array<number>;
export type ThreatEventsListResponseTagsList = Array<string>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsResponse {
    attacker: string;
    attackerCountry: string;
    attackerCountryAlpha3: string;
    category: string;
    datasetId: string;
    date: string;
    event: string;
    hasChildren: boolean;
    indicator: string;
    indicatorType: string;
    indicatorTypeId: number;
    killChain: number;
    mitreAttack: ThreatEventsListResponseMitreAttackList;
    mitreCapec: ThreatEventsListResponseMitreCapecList;
    numReferenced: number;
    numReferences: number;
    rawId: string;
    referenced: ThreatEventsListResponseReferencedList;
    referencedIds: ThreatEventsListResponseReferencedIdsList;
    references: ThreatEventsListResponseReferencesList;
    referencesIds: ThreatEventsListResponseReferencesIdsList;
    tags: ThreatEventsListResponseTagsList;
    targetCountry: string;
    targetCountryAlpha3: string;
    targetIndustry: string;
    tlp: string;
    uuid: string;
    insight?: string | null;
    releasabilityId?: string | null;
}
export type ListThreatEventsAggregateRequestDatasetIdList = Array<string>;
export interface ListThreatEventsAggregateRequest {
    /** Account ID. */
    accountId: string;
    /** Column(s) to aggregate by - single column or comma-separated list (e.g., 'attacker', 'targetIndustry', 'attacker,targetIndustry') */
    aggregateBy: string;
    /** Dataset UUIDs to filter by, or one standalone scope value: 'all'/'*' or 'operational' for readable intelligence datasets (isAnalytics=false), or 'analytics' for readable analytics datasets (isAnalytics=true). Scope values query at most 50 datasets. If not provided, uses the default dataset. */
    datasetId?: ListThreatEventsAggregateRequestDatasetIdList;
    /** End date for filtering (ISO 8601 format, e.g., '2024-12-31') */
    endDate?: string;
    /** Whether to group results by date (daily aggregation) */
    groupByDate?: boolean;
    /** Maximum number of results to return */
    limit?: number;
    /** Start date for filtering (ISO 8601 format, e.g., '2024-01-01') */
    startDate?: string;
}
export interface ListThreatEventsAggregateResponseAggregationsItem {
    /** Number of events for this aggregation */
    count: number;
    /** Date (if groupByDate is true) */
    date?: string | null;
}
export type ListThreatEventsAggregateResponseAggregationsList = Array<ListThreatEventsAggregateResponseAggregationsItem>;
export interface ListThreatEventsAggregateResponseDateRange {
    endDate?: string | null;
    startDate?: string | null;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsAggregateResponse {
    /** Column(s) that were aggregated by */
    aggregateBy: string;
    /** Array of aggregation results with dynamic fields based on aggregateBy columns */
    aggregations: ListThreatEventsAggregateResponseAggregationsList;
    /** Total number of events in the aggregation */
    total: number;
    /** Date range used for filtering */
    dateRange?: ListThreatEventsAggregateResponseDateRange | null;
}
export interface ListThreatEventsCategoriesCatalogRequest {
    /** Account ID. */
    accountId: string;
}
export type ListThreatEventsCategoriesCatalogResponseMitreAttackList = Array<string>;
export type ListThreatEventsCategoriesCatalogResponseMitreCapecList = Array<string>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsCategoriesCatalogResponse {
    killChain: number;
    name: string;
    uuid: string;
    mitreAttack?: ListThreatEventsCategoriesCatalogResponseMitreAttackList | null;
    mitreCapec?: ListThreatEventsCategoriesCatalogResponseMitreCapecList | null;
    shortname?: string | null;
}
export type ListThreatEventsGraphRequestDatasetIdsList = Array<string>;
export type ListThreatEventsGraphRequestExpandList = Array<string>;
export type ListThreatEventsGraphRequestRelationshipTypesList = Array<string>;
export type ListThreatEventsGraphRequestSeedsList = Array<string>;
export interface ListThreatEventsGraphRequest {
    /** Account ID. */
    accountId: string;
    /** Opaque pagination token. Only valid when seeds has exactly 1 entry; 400 otherwise. */
    cursor?: string;
    /** Comma-separated dataset UUIDs to restrict neighbor scope, or one standalone scope value: 'operational' for readable intelligence datasets (isAnalytics=false), 'analytics' for readable analytics datasets (isAnalytics=true), or 'all'/'*' for every readable dataset including analytics datasets (the graph reads analytics relationships from R2). Intersected with access grants. */
    datasetIds?: ListThreatEventsGraphRequestDatasetIdsList;
    /** Edge direction relative to each seed: out (seed->neighbors), in (neighbors->seed), both (default). */
    direction?: string;
    /** Comma-separated list of response sections to expand (hydrate). Allowed: `nodes`. Omitting `expand` returns identifier-only nodes. */
    expand?: ListThreatEventsGraphRequestExpandList;
    /** Hydration strategy for neighbor nodes when expand=nodes is set. r2_join (default): use R2 JOIN query + DO fallback. do_only: use plain R2 query + hydrate all neighbors via Durable Objects. */
    hydration?: string;
    /** Max neighbors per seed (default: 100, max: 1000). Values above 1000 return 400. */
    limit?: number;
    /** Total accumulated node cap across all seeds (default: 500, max: 1000). Values above 1000 return 400. */
    maxNodes?: number;
    /** Comma-separated relationship types to filter by. Allowed: tagged_with, appears_in, related_to, caused_by, attributed_to. */
    relationshipTypes?: ListThreatEventsGraphRequestRelationshipTypesList;
    /** Comma-separated compact seed ids (type:uuid). Example: seeds=event:550e8400-...,indicator:661fa920-... Provide 1-50 entries; omitting seeds returns 400. */
    seeds?: ListThreatEventsGraphRequestSeedsList;
}
export interface ListThreatEventsGraphResponseEdgesItem {
    /** Deterministic composite edge id (source->target:relationshipType) */
    id: string;
    relationshipType: string;
    /** Compact id of the source node (type:uuid) */
    source: string;
    sourceId: string;
    sourceType: string;
    /** Compact id of the target node (type:uuid) */
    target: string;
    targetId: string;
    targetType: string;
}
export type ListThreatEventsGraphResponseEdgesList = Array<ListThreatEventsGraphResponseEdgesItem>;
export type ListThreatEventsGraphResponseNodeMap = {
    [key: string]: unknown | undefined;
};
export type ListThreatEventsGraphResponseNodesItemMap = {
    [key: string]: unknown | undefined;
};
export type ListThreatEventsGraphResponseNodesList = Array<ListThreatEventsGraphResponseNodesItemMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListThreatEventsGraphResponse {
    edges: ListThreatEventsGraphResponseEdgesList;
    /** Focal node object (legacy single-seed). Null when unavailable. */
    node: ListThreatEventsGraphResponseNodeMap;
    nodes: ListThreatEventsGraphResponseNodesList;
}
export type ListThreatEventsIndicatorsRequestCache = "from-graph";
export type ListThreatEventsIndicatorsRequestDatasetIdsList = Array<string>;
export type ListThreatEventsIndicatorsRequestFormat = "json" | "stix2" | "taxii";
export type ListThreatEventsIndicatorsRequestRelatedEventsList = Array<string>;
export type ListThreatEventsIndicatorsRequestSearchList = Array<string>;
export type ListThreatEventsIndicatorsRequestTagsList = Array<string>;
export type ListThreatEventsIndicatorsRequestTagSearchList = Array<string>;
export interface ListThreatEventsIndicatorsRequest {
    /** Account ID. */
    accountId: string;
    /** Cache strategy. 'from-graph' serves results from the graph-node KV cache when all requested UUIDs are cached; falls back to normal path on partial/zero hit. Cannot be combined with `cursor`. */
    cache?: ListThreatEventsIndicatorsRequestCache | (string & {});
    /** Filter indicators created on or after this date. Must use ISO 8601 format (e.g., '2024-01-15T00:00:00Z'). */
    createdAfter?: string;
    /** Filter indicators created on or before this date. Must use ISO 8601 format (e.g., '2024-12-31T23:59:59Z'). */
    createdBefore?: string;
    /** Opaque cursor from a previous response's `pagination.cursor`. When provided, all filters, datasetIds, page, `pageSize`, `includeTags` and `relatedEventsLimit` come from the cursor -- do not resend them. Sending any filter, `page`, `pageSize`, `includeTags`, `relatedEventsLimit`, `includeTotalCount=true`, or `cache=from-graph` alongside a cursor yields a 400 `CursorFilterConflictError`. A cursor issued for a different entity, an unsupported version, or a dataset that has since been reconfigured as analytics-only yields a 400 `InvalidCursorError`. */
    cursor?: string;
    /** Dataset UUIDs to query, or one standalone scope value: 'all'/'*' or 'operational' for readable intelligence datasets (isAnalytics=false), or 'analytics' for readable analytics datasets (isAnalytics=true). If not provided, uses the default dataset. */
    datasetIds?: ListThreatEventsIndicatorsRequestDatasetIdsList;
    /** Output format for indicator data. 'json' returns the default format, 'stix2' returns STIX 2.1 Indicator SDOs, 'taxii' returns a TAXII 2.1 Envelope with Content-Type application/taxii+json;version=2.1. */
    format?: ListThreatEventsIndicatorsRequestFormat | (string & {});
    /** Whether to include full tag details for each indicator. Defaults to true. */
    includeTags?: boolean;
    /** Whether to compute total count via COUNT(*). Defaults to false for performance. total_count is null unless this is true and the complete fan-out succeeds. */
    includeTotalCount?: boolean;
    indicatorType?: string;
    /** Filter indicators by value using substring match (LIKE). Legacy alternative to structured search. */
    name?: string;
    page?: number;
    pageSize?: number;
    /** Filter by related event IDs */
    relatedEvents?: ListThreatEventsIndicatorsRequestRelatedEventsList;
    /** Limit the number of related events returned per indicator. Default: 2. Set to 0 for none, -1 for all events. For JSON responses, when the limit hides events, the indicator carries `relatedEventsHasMore: true` and the response includes an advisory message -- the cap is never applied silently. STIX and TAXII representations do not include related-event data. */
    relatedEventsLimit?: number;
    /** Structured search as a JSON array of {field, op, value} objects. Searchable fields: value, indicatorType, uuid. Supports operators: equals, not, contains, startsWith, endsWith, gt, lt, gte, lte, like, in, find. Use the 'in' operator with an array value to bulk-check up to 100 indicators in a single request, e.g. search=[{"field":"value","op":"in","value":["evil.com","bad.org"]}]. Multiple conditions are AND'd together. Max 10 conditions per request. */
    search?: ListThreatEventsIndicatorsRequestSearchList;
    /** Filter by tag values or UUIDs. Indicators must have at least one of the specified tags (OR logic). Supports both tag UUID and tag value. */
    tags?: ListThreatEventsIndicatorsRequestTagsList;
    /** Structured tag-metadata filter as a JSON array of {field, op, value} objects. Operates against the per-dataset IndicatorTag mirror so you can find indicators by tag attributes (origin country, motive, sophistication, priority, etc.) without a separate Tags lookup. Common dashboard usage: drill from a country into indicators, e.g. tagSearch=[{"field":"originCountryISO","op":"in","value":["IR","CN"]}]. Country values may be passed as alpha-2, alpha-3, name, or alias (e.g. "iran"). Operators: equals, not, gt/gte/lt/lte (numeric only), contains/like/find/startsWith/endsWith (string only), in. AND-joined across entries; combined with `tags`, a matching tag must satisfy both. Max 10 entries per request, max 100 values per 'in'. Performance notes: `originCountryISO` uses its B-tree index for equals/not/in. `priority` uses its B-tree index for numeric comparisons. Other string columns (`actorCategory`, `motive`, etc.) are case-insensitive and unindexed; current catalog size makes this a non-issue. `endsWith` and `aliasGroupNames` contains/like are leading-wildcard scans and slow on large result sets. `aliasGroupNames` matches on the JSON-encoded text, so substrings can cross alias boundaries ("apt28" also matches "apt280" when both appear in the same tag's alias list). */
    tagSearch?: ListThreatEventsIndicatorsRequestTagSearchList;
}
export type ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesComplete = ThreatEventsAttackersListResponseItems;
export type ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedDatasetsItems = ThreatEventsAttackersListResponseItems;
export interface ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedDatasets {
    items: ThreatEventsAttackersListResponseItems;
    type: string;
}
export type ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedShardsItemsPropertiesDatasetId = ThreatEventsAttackersListResponseItems;
export type ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedShardsItemsPropertiesShardId = ThreatEventsAttackersListResponseItems;
export interface ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedShardsItemsProperties {
    datasetId: ThreatEventsAttackersListResponseItems;
    shardId: ThreatEventsAttackersListResponseItems;
}
export interface ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedShardsItems {
    properties: ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedShardsItemsProperties;
    type: string;
}
export interface ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedShards {
    items: ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedShardsItems;
    type: string;
}
export type ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesWarningsItems = ThreatEventsAttackersListResponseItems;
export type ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesWarnings = ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedDatasets;
export interface ListThreatEventsIndicatorsResponsePropertiesCompletenessProperties {
    complete: ThreatEventsAttackersListResponseItems;
    failedDatasets: ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedDatasets;
    failedShards: ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedShards;
    warnings: ListThreatEventsIndicatorsResponsePropertiesCompletenessPropertiesFailedDatasets;
}
export interface ListThreatEventsIndicatorsResponsePropertiesCompleteness {
    properties: ListThreatEventsIndicatorsResponsePropertiesCompletenessProperties;
    type: string;
}
export type ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsSourcesItemResourceType = "article";
export type ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsSourcesItemSystem = "threat-signals";
export interface ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsSourcesItem {
    resourceId: string;
    resourceType: ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsSourcesItemResourceType;
    system: ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsSourcesItemSystem;
    /** Threat Signals article title; null for historical provenance without a stored title. */
    title: string;
}
export type ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsSourcesList = Array<ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsSourcesItem>;
export type ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsRelatedEventsItem = GetThreatEventsIndicatorsByDatasetResponseRelatedEventsItem;
export type ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsRelatedEventsList = Array<GetThreatEventsIndicatorsByDatasetResponseRelatedEventsItem>;
export type ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsTagsItem = GetThreatEventsIndicatorsByDatasetResponseTagsItem;
export type ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsTagsList = Array<GetThreatEventsIndicatorsByDatasetResponseTagsItem>;
export interface ListThreatEventsIndicatorsResponsePropertiesIndicatorsItems {
    createdAt: string;
    indicatorType: string;
    /** RSS article sources from which this indicator was extracted. */
    sources: ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsSourcesList;
    updatedAt: string;
    uuid: string;
    value: string;
    /** The dataset ID this indicator belongs to. Included in list responses. */
    datasetId?: string | null;
    /** Related events, capped by `relatedEventsLimit` (default 2). Check `relatedEventsHasMore` to detect a capped list; pass `relatedEventsLimit=-1` to retrieve all of them. */
    relatedEvents?: ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsRelatedEventsList | null;
    /** True when this indicator appears in more events than `relatedEvents` contains because `relatedEventsLimit` capped the list. Pass `relatedEventsLimit=-1` to retrieve every related event. */
    relatedEventsHasMore?: boolean | null;
    tags?: ListThreatEventsIndicatorsResponsePropertiesIndicatorsItemsTagsList | null;
    /** Traffic Light Protocol designation. UPPERCASE. Possible values: CLEAR, GREEN, AMBER, AMBER-STRICT, RED, PURPLE. Null when not set. */
    tlp?: string | null;
}
export interface ListThreatEventsIndicatorsResponsePropertiesIndicators {
    items: ListThreatEventsIndicatorsResponsePropertiesIndicatorsItems;
    type: string;
}
export type ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesCount = ThreatEventsAttackersListResponseItems;
export interface ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesCursor {
    description: string;
    nullable: boolean;
    type: string;
}
export interface ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesHasMore {
    description: string;
    type: string;
}
export type ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesPage = ThreatEventsAttackersListResponseItems;
export type ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesPerPage = ThreatEventsAttackersListResponseItems;
export type ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesTotalCount = ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesCursor;
export type ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesTotalCountIsExact = ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesHasMore;
export interface ListThreatEventsIndicatorsResponsePropertiesPaginationProperties {
    count: ThreatEventsAttackersListResponseItems;
    cursor: ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesCursor;
    hasMore: ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesHasMore;
    page: ThreatEventsAttackersListResponseItems;
    perPage: ThreatEventsAttackersListResponseItems;
    totalCount: ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesCursor;
    totalCountIsExact: ListThreatEventsIndicatorsResponsePropertiesPaginationPropertiesHasMore;
}
export interface ListThreatEventsIndicatorsResponsePropertiesPagination {
    properties: ListThreatEventsIndicatorsResponsePropertiesPaginationProperties;
    type: string;
}
export interface ListThreatEventsIndicatorsResponseProperties {
    completeness: ListThreatEventsIndicatorsResponsePropertiesCompleteness;
    indicators: ListThreatEventsIndicatorsResponsePropertiesIndicators;
    pagination: ListThreatEventsIndicatorsResponsePropertiesPagination;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsIndicatorsResponse {
    properties: ListThreatEventsIndicatorsResponseProperties;
    type: string;
}
export type ListThreatEventsIndicatorsAggregateRequestDatasetIdsList = Array<string>;
export type ListThreatEventsIndicatorsAggregateRequestMeasure = "indicators" | "relationships";
export interface ListThreatEventsIndicatorsAggregateRequest {
    /** Account ID. */
    accountId: string;
    /** Column(s) to aggregate by - single column or comma-separated list (e.g., 'indicatorType', 'value', 'indicatorType,value') */
    aggregateBy: string;
    /** Filter indicators created after this date/datetime (ISO 8601, e.g., '2024-01-01' or '2024-01-01T00:00:00Z') */
    createdAfter?: string;
    /** Filter indicators created before this date/datetime (ISO 8601, e.g., '2024-12-31' or '2024-12-31T23:59:59Z') */
    createdBefore?: string;
    /** Dataset UUIDs to filter by, or one standalone scope value: 'operational' for readable intelligence datasets (isAnalytics=false), 'analytics' for readable analytics datasets (isAnalytics=true), or 'all'/'*' for every readable dataset including analytics datasets. If not provided, aggregates across all accessible datasets, including analytics datasets. */
    datasetIds?: ListThreatEventsIndicatorsAggregateRequestDatasetIdsList;
    /** For measure=relationships: only count indicator->event links whose relationship was created/observed on or after this date (ISO 8601). Bounds the activity view to recently-observed links. Note: this filters by the relationship's createdAt (link-observation time), not the underlying event's business date. */
    eventDateAfter?: string;
    /** For measure=relationships: only count indicator->event links whose relationship was created/observed on or before this date (ISO 8601). Bounds the activity view by the relationship's createdAt (link-observation time), not the underlying event's business date. */
    eventDateBefore?: string;
    /** Maximum number of aggregation results to return (1-100) */
    limit?: number;
    /** What to count per group: 'indicators' (catalog rows, default) or 'relationships' (linked events per indicator). Use 'relationships' for 'top indicator by event activity'. */
    measure?: ListThreatEventsIndicatorsAggregateRequestMeasure | (string & {});
    /** Scope to indicators associated with this tag/actor UUID. Combine with measure=relationships for 'top indicator for an actor'. */
    tagUuid?: string;
}
export interface ListThreatEventsIndicatorsAggregateResponseAggregationsItem {
    /** Number of indicators for this aggregation */
    count: number;
}
export type ListThreatEventsIndicatorsAggregateResponseAggregationsList = Array<ListThreatEventsIndicatorsAggregateResponseAggregationsItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsIndicatorsAggregateResponse {
    /** Column(s) that were aggregated by */
    aggregateBy: string;
    /** Array of aggregation results with dynamic fields based on aggregateBy columns */
    aggregations: ListThreatEventsIndicatorsAggregateResponseAggregationsList;
    /** Number of datasets whose aggregation failed and were excluded from the result */
    failedDatasets: number;
    /** Total count in the aggregation: indicator rows when measure=indicators, or linked-event rows when measure=relationships */
    total: number;
}
export type ListThreatEventsIndicatorsByDatasetRequestRelatedEventList = Array<string>;
export interface ListThreatEventsIndicatorsByDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset UUID. */
    datasetId: string;
    indicatorType?: string;
    /** Filter by indicator value (substring match) */
    name?: string;
    page?: number;
    pageSize?: number;
    /** Filter indicators by related event UUID(s). Multiple UUIDs can be provided by repeating the parameter. */
    relatedEvent?: ListThreatEventsIndicatorsByDatasetRequestRelatedEventList;
}
export type ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemSourcesItemResourceType = "article";
export type ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemSourcesItemSystem = "threat-signals";
export interface ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemSourcesItem {
    resourceId: string;
    resourceType: ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemSourcesItemResourceType;
    system: ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemSourcesItemSystem;
    /** Threat Signals article title; null for historical provenance without a stored title. */
    title: string;
}
export type ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemSourcesList = Array<ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemSourcesItem>;
export type ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemRelatedEventsItem = GetThreatEventsIndicatorsByDatasetResponseRelatedEventsItem;
export type ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemRelatedEventsList = Array<GetThreatEventsIndicatorsByDatasetResponseRelatedEventsItem>;
export type ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemTagsItem = GetThreatEventsIndicatorsByDatasetResponseTagsItem;
export type ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemTagsList = Array<GetThreatEventsIndicatorsByDatasetResponseTagsItem>;
export interface ListThreatEventsIndicatorsByDatasetResponseIndicatorsItem {
    createdAt: string;
    indicatorType: string;
    /** RSS article sources from which this indicator was extracted. */
    sources: ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemSourcesList;
    updatedAt: string;
    uuid: string;
    value: string;
    /** The dataset ID this indicator belongs to. Included in list responses. */
    datasetId?: string | null;
    /** Related events, capped by `relatedEventsLimit` (default 2). Check `relatedEventsHasMore` to detect a capped list; pass `relatedEventsLimit=-1` to retrieve all of them. */
    relatedEvents?: ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemRelatedEventsList | null;
    /** True when this indicator appears in more events than `relatedEvents` contains because `relatedEventsLimit` capped the list. Pass `relatedEventsLimit=-1` to retrieve every related event. */
    relatedEventsHasMore?: boolean | null;
    tags?: ListThreatEventsIndicatorsByDatasetResponseIndicatorsItemTagsList | null;
    /** Traffic Light Protocol designation. UPPERCASE. Possible values: CLEAR, GREEN, AMBER, AMBER-STRICT, RED, PURPLE. Null when not set. */
    tlp?: string | null;
}
export type ListThreatEventsIndicatorsByDatasetResponseIndicatorsList = Array<ListThreatEventsIndicatorsByDatasetResponseIndicatorsItem>;
export interface ListThreatEventsIndicatorsByDatasetResponsePagination {
    page: number;
    pageSize: number;
    totalCount: number;
    totalPages: number;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsIndicatorsByDatasetResponse {
    indicators: ListThreatEventsIndicatorsByDatasetResponseIndicatorsList;
    pagination: ListThreatEventsIndicatorsByDatasetResponsePagination;
}
export interface ListThreatEventsIndicatorsByDatasetTagsRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset ID. */
    datasetId: string;
}
export interface ListThreatEventsIndicatorsByDatasetTagsResponse {
}
export type ListThreatEventsIndicatorsTypesRequestDatasetIdsList = Array<string>;
export interface ListThreatEventsIndicatorsTypesRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset UUIDs to query, or one standalone scope value: 'operational' for readable intelligence datasets (isAnalytics=false), 'analytics' for readable analytics datasets (isAnalytics=true), or 'all'/'*' for every readable dataset including analytics datasets. If not provided, queries all accessible datasets, including analytics datasets. */
    datasetIds?: ListThreatEventsIndicatorsTypesRequestDatasetIdsList;
}
export type ListThreatEventsIndicatorsTypesResponseItems = ThreatEventsAttackersListResponseItems;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsIndicatorsTypesResponse {
    items: ThreatEventsAttackersListResponseItems;
    type: string;
}
export interface ListThreatEventsQueriesRequest {
    /** Account ID. */
    accountId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsQueriesResponse {
    /** Unique identifier for the saved query */
    id: number;
    /** Account ID */
    accountId: number;
    /** Deprecated: saved-query alerting and rules were removed. Always false. */
    alertEnabled: boolean;
    /** Deprecated: saved-query alerting and rules were removed. Always false. */
    alertRollupEnabled: boolean;
    /** Creation timestamp */
    createdAt: string;
    /** Name of the saved query */
    name: string;
    /** JSON string containing the query parameters */
    queryJson: string;
    /** Deprecated: saved-query alerting and rules were removed. Always false. */
    ruleEnabled: boolean;
    /** Last update timestamp */
    updatedAt: string;
    /** Email of the user who created the query */
    userEmail: string;
    /** Deprecated: saved-query alerting and rules were removed. Always null. */
    customThreatFeedId?: number | null;
    /** Deprecated: saved-query alerting and rules were removed. Always null. */
    ruleListId?: string | null;
    /** Deprecated: saved-query alerting and rules were removed. Always null. */
    ruleScope?: string | null;
}
export type ListThreatEventsRelationshipsRequestDirection = "ancestors" | "descendants" | "both";
export type ListThreatEventsRelationshipsRequestIndicatorTypeIdsList = Array<string>;
export interface ListThreatEventsRelationshipsRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
    /** The dataset ID to search within. */
    datasetId: string;
    /** The direction to traverse the graph. Defaults to 'both' to search all. */
    direction?: ListThreatEventsRelationshipsRequestDirection | (string & {});
    /** Whether to include the starting event in the results. Defaults to true. */
    includeParent?: boolean;
    /** An optional array of indicator type IDs to filter the results by. */
    indicatorTypeIds?: ListThreatEventsRelationshipsRequestIndicatorTypeIdsList;
    /** The maximum depth to traverse. Defaults to 5. */
    maxDepth?: number;
    page?: number;
    pageSize?: number;
    /** An optional array of relationship types to filter by. */
    relationshipTypes?: string;
}
export type ListThreatEventsRelationshipsResponseMitreAttackList = Array<string>;
export type ListThreatEventsRelationshipsResponseMitreCapecList = Array<string>;
export type ListThreatEventsRelationshipsResponseReferencedList = Array<string>;
export type ListThreatEventsRelationshipsResponseReferencedIdsList = Array<number>;
export type ListThreatEventsRelationshipsResponseReferencesList = Array<string>;
export type ListThreatEventsRelationshipsResponseReferencesIdsList = Array<number>;
export type ListThreatEventsRelationshipsResponseTagsList = Array<string>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsRelationshipsResponse {
    attacker: string;
    attackerCountry: string;
    attackerCountryAlpha3: string;
    category: string;
    datasetId: string;
    date: string;
    event: string;
    hasChildren: boolean;
    indicator: string;
    indicatorType: string;
    indicatorTypeId: number;
    killChain: number;
    mitreAttack: ListThreatEventsRelationshipsResponseMitreAttackList;
    mitreCapec: ListThreatEventsRelationshipsResponseMitreCapecList;
    numReferenced: number;
    numReferences: number;
    rawId: string;
    referenced: ListThreatEventsRelationshipsResponseReferencedList;
    referencedIds: ListThreatEventsRelationshipsResponseReferencedIdsList;
    references: ListThreatEventsRelationshipsResponseReferencesList;
    referencesIds: ListThreatEventsRelationshipsResponseReferencesIdsList;
    tags: ListThreatEventsRelationshipsResponseTagsList;
    targetCountry: string;
    targetCountryAlpha3: string;
    targetIndustry: string;
    tlp: string;
    uuid: string;
    insight?: string | null;
    releasabilityId?: string | null;
}
export type ListThreatEventsTagsRequestCache = "from-graph";
export type ListThreatEventsTagsRequestFiltersList = Array<string>;
export interface ListThreatEventsTagsRequest {
    /** Account ID. */
    accountId: string;
    /** Cache strategy. 'from-graph' serves results from the graph-node KV cache when all requested UUIDs are cached; falls back to normal path on partial/zero hit. */
    cache?: ListThreatEventsTagsRequestCache | (string & {});
    categoryUuid?: string;
    /** Structured filters as a JSON array of {field, op, value} objects. Searchable fields: uuid, value, categoryName, description, dateOfDiscovery, tlp, confidence, actorCategory, motive, attributionOrganization, originCountryISO, aliases, externalReferences, opsecLevel, sophisticationLevel, activeDuration, priority, lastSeen, aliasGroupNames. Operators: equals, not, contains, startsWith, endsWith, gt, lt, gte, lte, like, in, find. Use 'in' for bulk OR within a single field, e.g. filters=[{"field":"originCountryISO","op":"in","value":["IR","CN"]}]. Multiple entries are AND-joined. Max 10 entries per request, max 100 values per 'in'. Per-field notes: `uuid` accepts only 'equals' and 'in' (other operators throw ValidationError) -- matched against the canonical lowercase storage but callers may pass either case (the server lowercases before comparison); index-backed by the column's UNIQUE constraint and intended for batched UUID -> tag resolution. `originCountryISO` uses its B-tree index for equals/not/in. `priority` uses its B-tree index for numeric comparisons. Other string columns (`actorCategory`, `motive`, etc.) are case-insensitive and unindexed; current catalog size makes this a non-issue. `endsWith` and `aliasGroupNames` contains/like are leading-wildcard scans and slow on large result sets. `aliasGroupNames` matches on the JSON-encoded text, so substrings can cross alias boundaries (a search for "apt28" will also match "apt280" if both appear in the same tag's alias list). */
    filters?: ListThreatEventsTagsRequestFiltersList;
    page?: number;
    pageSize?: number;
    /** Free-text substring match on tag value AND custom-field properties. Searches case-insensitively inside both `Tag.value` and the serialized `Tag.properties` JSON blob (keys, values, and annotation metadata like confidence/tlp are all searchable). Same serialized-text tradeoff as `aliasGroupNames` -- substrings can cross JSON boundaries. */
    search?: string;
}
export type ListThreatEventsTagsResponsePagination = ListThreatEventsIndicatorsByDatasetResponsePagination;
export type ListThreatEventsTagsResponseTagsItemActiveDurationAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ListThreatEventsTagsResponseTagsItemActiveDurationAnnotated {
    value: string;
    tlp?: ListThreatEventsTagsResponseTagsItemActiveDurationAnnotatedTlp | null;
}
export type ListThreatEventsTagsResponseTagsItemActorCategoryAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ListThreatEventsTagsResponseTagsItemActorCategoryAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: ListThreatEventsTagsResponseTagsItemActorCategoryAnnotatedTlp | null;
}
export type ListThreatEventsTagsResponseTagsItemAliasesItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ListThreatEventsTagsResponseTagsItemAliasesItem {
    value: string;
    confidence?: number | null;
    tlp?: ListThreatEventsTagsResponseTagsItemAliasesItemTlp | null;
}
export type ListThreatEventsTagsResponseTagsItemAliasesList = Array<ListThreatEventsTagsResponseTagsItemAliasesItem>;
export type ListThreatEventsTagsResponseTagsItemAliasGroupNamesList = Array<string>;
export type ListThreatEventsTagsResponseTagsItemAliasGroupNamesInternalList = Array<string>;
export type ListThreatEventsTagsResponseTagsItemAttributionOrganizationAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ListThreatEventsTagsResponseTagsItemAttributionOrganizationAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: ListThreatEventsTagsResponseTagsItemAttributionOrganizationAnnotatedTlp | null;
}
export type ListThreatEventsTagsResponseTagsItemExternalReferenceLinksList = Array<string>;
export type ListThreatEventsTagsResponseTagsItemExternalReferencesItem = ThreatEventsTagsCreateResponseExternalReferencesItem;
export type ListThreatEventsTagsResponseTagsItemExternalReferencesList = Array<ThreatEventsTagsCreateResponseExternalReferencesItem>;
export type ListThreatEventsTagsResponseTagsItemExternalReferencesAnnotatedItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ListThreatEventsTagsResponseTagsItemExternalReferencesAnnotatedItem {
    value: string;
    tlp?: ListThreatEventsTagsResponseTagsItemExternalReferencesAnnotatedItemTlp | null;
}
export type ListThreatEventsTagsResponseTagsItemExternalReferencesAnnotatedList = Array<ListThreatEventsTagsResponseTagsItemExternalReferencesAnnotatedItem>;
export type ListThreatEventsTagsResponseTagsItemInternalAliasesItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ListThreatEventsTagsResponseTagsItemInternalAliasesItem {
    value: string;
    confidence?: number | null;
    tlp?: ListThreatEventsTagsResponseTagsItemInternalAliasesItemTlp | null;
}
export type ListThreatEventsTagsResponseTagsItemInternalAliasesList = Array<ListThreatEventsTagsResponseTagsItemInternalAliasesItem>;
export type ListThreatEventsTagsResponseTagsItemMotiveAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ListThreatEventsTagsResponseTagsItemMotiveAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: ListThreatEventsTagsResponseTagsItemMotiveAnnotatedTlp | null;
}
export type ListThreatEventsTagsResponseTagsItemOpsecLevelAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ListThreatEventsTagsResponseTagsItemOpsecLevelAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: ListThreatEventsTagsResponseTagsItemOpsecLevelAnnotatedTlp | null;
}
export type ListThreatEventsTagsResponseTagsItemOriginCountryISOAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ListThreatEventsTagsResponseTagsItemOriginCountryISOAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: ListThreatEventsTagsResponseTagsItemOriginCountryISOAnnotatedTlp | null;
}
export type ListThreatEventsTagsResponseTagsItemPriorityAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ListThreatEventsTagsResponseTagsItemPriorityAnnotated {
    value: number;
    tlp?: ListThreatEventsTagsResponseTagsItemPriorityAnnotatedTlp | null;
}
export type ListThreatEventsTagsResponseTagsItemPropertiesMap = {
    [key: string]: unknown | undefined;
};
export type ListThreatEventsTagsResponseTagsItemSophisticationLevelAnnotatedTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ListThreatEventsTagsResponseTagsItemSophisticationLevelAnnotated {
    value: string;
    confidence?: number | null;
    tlp?: ListThreatEventsTagsResponseTagsItemSophisticationLevelAnnotatedTlp | null;
}
export type ListThreatEventsTagsResponseTagsItemTlp = "red" | "amber" | "amber-strict" | "green" | "clear" | "purple" | "amber+strict";
export interface ListThreatEventsTagsResponseTagsItem {
    uuid: string;
    value: string;
    activeDuration?: string | null;
    activeDurationAnnotated?: ListThreatEventsTagsResponseTagsItemActiveDurationAnnotated | null;
    actorCategory?: string | null;
    actorCategoryAnnotated?: ListThreatEventsTagsResponseTagsItemActorCategoryAnnotated | null;
    /** Structured aliases ({ value, confidence 1-10, tlp }). Public: returned to all accounts with per-entry TLP filtering (entries with tlp: purple are removed for non-CFONE accounts). */
    aliases?: ListThreatEventsTagsResponseTagsItemAliasesList | null;
    aliasGroupNames?: ListThreatEventsTagsResponseTagsItemAliasGroupNamesList | null;
    aliasGroupNamesInternal?: ListThreatEventsTagsResponseTagsItemAliasGroupNamesInternalList | null;
    attributionOrganization?: string | null;
    attributionOrganizationAnnotated?: ListThreatEventsTagsResponseTagsItemAttributionOrganizationAnnotated | null;
    categoryName?: string | null;
    categoryUuid?: string | null;
    /** Overall tag confidence (1-10). */
    confidence?: number | null;
    createdAt?: string | null;
    dateOfDiscovery?: string | null;
    description?: string | null;
    externalReferenceLinks?: ListThreatEventsTagsResponseTagsItemExternalReferenceLinksList | null;
    /** Structured external references ({ url, description }). Public: returned to all accounts. */
    externalReferences?: ListThreatEventsTagsResponseTagsItemExternalReferencesList | null;
    externalReferencesAnnotated?: ListThreatEventsTagsResponseTagsItemExternalReferencesAnnotatedList | null;
    /** Owner-private structured aliases ({ value, confidence 1-10, tlp }). Returned to the owning account and omitted from shared-catalog non-owner responses. */
    internalAliases?: ListThreatEventsTagsResponseTagsItemInternalAliasesList | null;
    internalDescription?: string | null;
    lastSeen?: string | null;
    motive?: string | null;
    motiveAnnotated?: ListThreatEventsTagsResponseTagsItemMotiveAnnotated | null;
    opsecLevel?: string | null;
    opsecLevelAnnotated?: ListThreatEventsTagsResponseTagsItemOpsecLevelAnnotated | null;
    /** ISO country code (alpha-2 or alpha-3). Normalized to uppercase on read. Null when stored value is blank/whitespace. */
    originCountryISO?: string | null;
    originCountryISOAnnotated?: ListThreatEventsTagsResponseTagsItemOriginCountryISOAnnotated | null;
    priority?: number | null;
    priorityAnnotated?: ListThreatEventsTagsResponseTagsItemPriorityAnnotated | null;
    /** Parsed custom field values. Null when the tag has no custom fields. */
    properties?: ListThreatEventsTagsResponseTagsItemPropertiesMap | null;
    sophisticationLevel?: string | null;
    sophisticationLevelAnnotated?: ListThreatEventsTagsResponseTagsItemSophisticationLevelAnnotated | null;
    /** Tag-level TLP handling marking. */
    tlp?: ListThreatEventsTagsResponseTagsItemTlp | null;
    updatedAt?: string | null;
    version?: number | null;
}
export type ListThreatEventsTagsResponseTagsList = Array<ListThreatEventsTagsResponseTagsItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsTagsResponse {
    pagination: ListThreatEventsIndicatorsByDatasetResponsePagination;
    tags: ListThreatEventsTagsResponseTagsList;
}
export interface ListThreatEventsTagsCategoriesRequest {
    /** Account ID. */
    accountId: string;
    search?: string;
}
export type ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemKind = "string" | "number" | "enum" | "date" | "array" | "object";
export type ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemAllowedValuesList = Array<string>;
export type ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemAnnotations = CreateThreatEventsTagsCategoryResponseSchemaItemAnnotations;
export type ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemDeprecatedValuesList = Array<string>;
export type ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemEnforcement = "error" | "warn" | "off";
export type ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemFormat = "date" | "url" | "duration" | "country";
export type ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemNumberConstraint = CreateThreatEventsTagsCategoryResponseSchemaItemNumberConstraint;
export type ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemPropertiesMap = {
    [key: string]: unknown | undefined;
};
export interface ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItem {
    key: string;
    kind: ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemKind;
    allowedValues?: ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemAllowedValuesList | null;
    annotations?: CreateThreatEventsTagsCategoryResponseSchemaItemAnnotations | null;
    /** Marks a field as unavailable for new values while retaining its definition for historical values. */
    deprecated?: boolean | null;
    /** Enum values unavailable for new writes but retained in allowedValues for historical display. */
    deprecatedValues?: ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemDeprecatedValuesList | null;
    element?: unknown | null;
    enforcement?: ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemEnforcement | null;
    format?: ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemFormat | null;
    label?: string | null;
    /** exclusiveMinimum */
    maxLength?: number | null;
    numberConstraint?: CreateThreatEventsTagsCategoryResponseSchemaItemNumberConstraint | null;
    /** Map of property key to FieldDefinition for object fields. Required when kind is 'object'. See FieldDefinition (recursive). */
    properties?: ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItemPropertiesMap | null;
    required?: boolean | null;
}
export type ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaList = Array<ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaItem>;
export interface ListThreatEventsTagsCategoriesResponseCategoriesItem {
    name: string;
    uuid: string;
    createdAt?: string | null;
    description?: string | null;
    /** Parsed FieldDefinition[] defining custom fields for this category, or null if none. */
    schema?: ListThreatEventsTagsCategoriesResponseCategoriesItemSchemaList | null;
    updatedAt?: string | null;
}
export type ListThreatEventsTagsCategoriesResponseCategoriesList = Array<ListThreatEventsTagsCategoriesResponseCategoriesItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsTagsCategoriesResponse {
    categories: ListThreatEventsTagsCategoriesResponseCategoriesList;
}
export type ListThreatEventsTagsIndicatorsRequestDatasetIdsList = Array<string>;
export type ListThreatEventsTagsIndicatorsRequestRelatedEventList = Array<string>;
export type ListThreatEventsTagsIndicatorsRequestSearchList = Array<string>;
export interface ListThreatEventsTagsIndicatorsRequest {
    /** Account ID. */
    accountId: string;
    /** Tag UUID. */
    tagUuid: string;
    /** Dataset UUIDs to scope to (repeat the param for multiple), or one standalone scope value: 'all'/'*' or 'operational' for readable intelligence datasets (isAnalytics=false), or 'analytics' for readable analytics datasets (isAnalytics=true). Analytics datasets do not expose tag associations, so 'analytics' returns an empty result. Omit for 'all'. */
    datasetIds?: ListThreatEventsTagsIndicatorsRequestDatasetIdsList;
    indicatorType?: string;
    page?: number;
    pageSize?: number;
    /** Filter indicators by related event UUID(s). Multiple UUIDs can be provided by repeating the parameter. */
    relatedEvent?: ListThreatEventsTagsIndicatorsRequestRelatedEventList;
    /** Structured search as a JSON array of {field, op, value} objects. Searchable fields: value, indicatorType. Multiple conditions are AND'd together. Max 10 conditions per request. */
    search?: ListThreatEventsTagsIndicatorsRequestSearchList;
}
export type ListThreatEventsTagsIndicatorsResponseIndicatorsItemRelatedEventsItem = GetThreatEventsIndicatorsByDatasetResponseRelatedEventsItem;
export type ListThreatEventsTagsIndicatorsResponseIndicatorsItemRelatedEventsList = Array<GetThreatEventsIndicatorsByDatasetResponseRelatedEventsItem>;
export type ListThreatEventsTagsIndicatorsResponseIndicatorsItemTagsItem = GetThreatEventsIndicatorsByDatasetResponseTagsItem;
export type ListThreatEventsTagsIndicatorsResponseIndicatorsItemTagsList = Array<GetThreatEventsIndicatorsByDatasetResponseTagsItem>;
export interface ListThreatEventsTagsIndicatorsResponseIndicatorsItem {
    createdAt: string;
    indicatorType: string;
    updatedAt: string;
    uuid: string;
    value: string;
    /** The dataset ID this indicator belongs to. Included in list responses. */
    datasetId?: string | null;
    /** Related events, capped by `relatedEventsLimit` (default 2). Check `relatedEventsHasMore` to detect a capped list; pass `relatedEventsLimit=-1` to retrieve all of them. */
    relatedEvents?: ListThreatEventsTagsIndicatorsResponseIndicatorsItemRelatedEventsList | null;
    /** True when this indicator appears in more events than `relatedEvents` contains because `relatedEventsLimit` capped the list. Pass `relatedEventsLimit=-1` to retrieve every related event. */
    relatedEventsHasMore?: boolean | null;
    tags?: ListThreatEventsTagsIndicatorsResponseIndicatorsItemTagsList | null;
    /** Traffic Light Protocol designation. UPPERCASE. Possible values: CLEAR, GREEN, AMBER, AMBER-STRICT, RED, PURPLE. Null when not set. */
    tlp?: string | null;
}
export type ListThreatEventsTagsIndicatorsResponseIndicatorsList = Array<ListThreatEventsTagsIndicatorsResponseIndicatorsItem>;
export type ListThreatEventsTagsIndicatorsResponsePagination = ListThreatEventsIndicatorsByDatasetResponsePagination;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsTagsIndicatorsResponse {
    indicators: ListThreatEventsTagsIndicatorsResponseIndicatorsList;
    pagination: ListThreatEventsIndicatorsByDatasetResponsePagination;
}
export type ListThreatEventsTagsIndicatorsByDatasetRequestRelatedEventList = Array<string>;
export type ListThreatEventsTagsIndicatorsByDatasetRequestSearchList = Array<string>;
export interface ListThreatEventsTagsIndicatorsByDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset UUID. */
    datasetId: string;
    /** Tag UUID. */
    tagUuid: string;
    indicatorType?: string;
    page?: number;
    pageSize?: number;
    /** Filter indicators by related event UUID(s). Multiple UUIDs can be provided by repeating the parameter. */
    relatedEvent?: ListThreatEventsTagsIndicatorsByDatasetRequestRelatedEventList;
    /** Structured search as a JSON array of {field, op, value} objects. Searchable fields: value, indicatorType. Multiple conditions are AND'd together. Max 10 conditions per request. */
    search?: ListThreatEventsTagsIndicatorsByDatasetRequestSearchList;
}
export type ListThreatEventsTagsIndicatorsByDatasetResponseIndicatorsItemRelatedEventsItem = GetThreatEventsIndicatorsByDatasetResponseRelatedEventsItem;
export type ListThreatEventsTagsIndicatorsByDatasetResponseIndicatorsItemRelatedEventsList = Array<GetThreatEventsIndicatorsByDatasetResponseRelatedEventsItem>;
export type ListThreatEventsTagsIndicatorsByDatasetResponseIndicatorsItemTagsItem = GetThreatEventsIndicatorsByDatasetResponseTagsItem;
export type ListThreatEventsTagsIndicatorsByDatasetResponseIndicatorsItemTagsList = Array<GetThreatEventsIndicatorsByDatasetResponseTagsItem>;
export interface ListThreatEventsTagsIndicatorsByDatasetResponseIndicatorsItem {
    createdAt: string;
    indicatorType: string;
    updatedAt: string;
    uuid: string;
    value: string;
    /** The dataset ID this indicator belongs to. Included in list responses. */
    datasetId?: string | null;
    /** Related events, capped by `relatedEventsLimit` (default 2). Check `relatedEventsHasMore` to detect a capped list; pass `relatedEventsLimit=-1` to retrieve all of them. */
    relatedEvents?: ListThreatEventsTagsIndicatorsByDatasetResponseIndicatorsItemRelatedEventsList | null;
    /** True when this indicator appears in more events than `relatedEvents` contains because `relatedEventsLimit` capped the list. Pass `relatedEventsLimit=-1` to retrieve every related event. */
    relatedEventsHasMore?: boolean | null;
    tags?: ListThreatEventsTagsIndicatorsByDatasetResponseIndicatorsItemTagsList | null;
    /** Traffic Light Protocol designation. UPPERCASE. Possible values: CLEAR, GREEN, AMBER, AMBER-STRICT, RED, PURPLE. Null when not set. */
    tlp?: string | null;
}
export type ListThreatEventsTagsIndicatorsByDatasetResponseIndicatorsList = Array<ListThreatEventsTagsIndicatorsByDatasetResponseIndicatorsItem>;
export type ListThreatEventsTagsIndicatorsByDatasetResponsePagination = ListThreatEventsIndicatorsByDatasetResponsePagination;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsTagsIndicatorsByDatasetResponse {
    indicators: ListThreatEventsTagsIndicatorsByDatasetResponseIndicatorsList;
    pagination: ListThreatEventsIndicatorsByDatasetResponsePagination;
}
export interface ListThreatEventsTargetIndustriesByDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset UUID. */
    datasetId: string;
}
export type ListThreatEventsTargetIndustriesByDatasetResponseItems = ThreatEventsAttackersListResponseItems;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsTargetIndustriesByDatasetResponse {
    items: ThreatEventsAttackersListResponseItems;
    type: string;
}
export interface ListThreatEventsTargetIndustriesCatalogRequest {
    /** Account ID. */
    accountId: string;
}
export type ListThreatEventsTargetIndustriesCatalogResponseItems = ThreatEventsAttackersListResponseItems;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsTargetIndustriesCatalogResponse {
    items: ThreatEventsAttackersListResponseItems;
    type: string;
}
export type ThreatEventsTargetIndustriesListRequestDatasetIdsList = Array<string>;
export interface ListThreatEventTargetIndustriesRequest {
    /** Account ID. */
    accountId: string;
    /** Array of dataset IDs to query target industries from. If not provided, uses the default dataset. */
    datasetIds?: ThreatEventsTargetIndustriesListRequestDatasetIdsList;
}
export type ThreatEventsTargetIndustriesListResponseItems = ThreatEventsAttackersListResponseItems;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventTargetIndustriesResponse {
    items: ThreatEventsAttackersListResponseItems;
    type: string;
}
export type ListThreatSignalsArticlesRequestArticleIdList = Array<string>;
export type ListThreatSignalsArticlesRequestSourceType = "curated" | "custom";
export type ListThreatSignalsArticlesRequestTagAppliedBy = "ai" | "analyst" | "system";
export type ListThreatSignalsArticlesRequestTagCategoryIdList = Array<string>;
export type ListThreatSignalsArticlesRequestTagIdList = Array<string>;
export interface ListThreatSignalsArticlesRequest {
    accountId: string;
    /** Repeatable article UUID filter. Returns the union of matching account-owned articles; use this to list every Threat Signals article referenced by an indicator's sources. */
    articleId?: ListThreatSignalsArticlesRequestArticleIdList;
    /** Opaque cursor from a previous response's `next_cursor`. When provided, pagination, ordering, totals, and article filters come from the cursor. Sending `per_page`, `sort`, `include_total`, or any article filter alongside it returns a 400 `CursorFilterConflictError`. */
    cursor?: string;
    /** Exact feed-category filter after trimming. Omit to include every category. */
    feedCategory?: string;
    /** Feed UUID filter. Omit to include articles from every account feed. */
    feedId?: string;
    /** Include articles fetched at or after this ISO 8601 date-time with Z or a numeric UTC offset; normalized to UTC. */
    fetchedAfter?: string;
    /** Include articles fetched at or before this ISO 8601 date-time with Z or a numeric UTC offset; normalized to UTC. */
    fetchedBefore?: string;
    /** When true on the first page, count matching articles and return an exact total. Defaults to false; cursor pages do not recalculate totals. */
    includeTotal?: boolean;
    /** Number of articles per cursor page, from 1 to 100. Defaults to 20. */
    perPage?: number;
    /** Include articles published at or after this ISO 8601 date-time with Z or a numeric UTC offset; normalized to UTC. */
    publishedAfter?: string;
    /** Include articles published at or before this ISO 8601 date-time with Z or a numeric UTC offset; normalized to UTC. */
    publishedBefore?: string;
    /** Filter by read state. Accepts true, false, 1, or 0; omit to include read and unread articles. */
    read?: boolean;
    /** NFC-normalized, trimmed literal substring filter on article titles; ASCII case-insensitive, from 1 to 500 characters. */
    search?: string;
    /** Sort by fetched_at, published_at, or title. Prefix the field with - for descending order; defaults to -fetched_at. */
    sort?: string;
    /** Filter by curated or custom feed source. Omit to include both source types. */
    sourceType?: ListThreatSignalsArticlesRequestSourceType | (string & {});
    /** Legacy human-readable tag-value filter. Ignored when tag_id is supplied; prefer tag_id. */
    tag?: string;
    /** Assignment provenance filter. When combined with tag_id or tag_category_id, the matching assignment must have this provenance. */
    tagAppliedBy?: ListThreatSignalsArticlesRequestTagAppliedBy | (string & {});
    /** Legacy category-name disambiguator for tag. It has no effect without tag; prefer tag_category_id. */
    tagCategory?: string;
    /** Repeatable tag-category UUID filter. An article matches any selected category; when tag_id is also present, the tag and category groups are ANDed. */
    tagCategoryId?: ListThreatSignalsArticlesRequestTagCategoryIdList;
    /** Repeatable tag UUID filter. An article matches any selected tag. */
    tagId?: ListThreatSignalsArticlesRequestTagIdList;
}
export type ListThreatSignalsArticlesResponseArticlesItemTagsItemAppliedBy = "ai" | "analyst" | "system";
export interface ListThreatSignalsArticlesResponseArticlesItemTagsItem {
    appliedBy: ListThreatSignalsArticlesResponseArticlesItemTagsItemAppliedBy;
    categoryId: string;
    uuid: string;
    value: string;
}
export type ListThreatSignalsArticlesResponseArticlesItemTagsList = Array<ListThreatSignalsArticlesResponseArticlesItemTagsItem>;
export interface ListThreatSignalsArticlesResponseArticlesItem {
    id: string;
    /** Threat Events dataset identifier for the article redirect. Null when the account feeds dataset mapping is unavailable. */
    datasetId: string;
    /** Threat Events event identifier associated with this article for a UI redirect. Null when no event has been linked. */
    eventId: string;
    feedDisplayName: string;
    feedId: string;
    fetchedAt: string;
    link: string;
    publishedAt: string;
    read: boolean;
    readAt: string;
    /** Persisted enrichment summary. Null until enrichment produces a summary. */
    summary: string;
    tags: ListThreatSignalsArticlesResponseArticlesItemTagsList;
    title: string;
}
export type ListThreatSignalsArticlesResponseArticlesList = Array<ListThreatSignalsArticlesResponseArticlesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListThreatSignalsArticlesResponse {
    articles: ListThreatSignalsArticlesResponseArticlesList;
    hasMore: boolean;
    nextCursor: string;
    totalCount: number;
    totalCountIsExact: boolean;
}
export interface ListThreatSignalsCategoriesRequest {
    accountId: string;
}
export interface ListThreatSignalsCategoriesResponseCategoriesItem {
    /** Wire value accepted by the feed `category_id` field. */
    id: string;
    /** Plain-language description of the category. */
    description: string;
    /** Human-readable display label. */
    name: string;
}
export type ListThreatSignalsCategoriesResponseCategoriesList = Array<ListThreatSignalsCategoriesResponseCategoriesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListThreatSignalsCategoriesResponse {
    categories: ListThreatSignalsCategoriesResponseCategoriesList;
}
export type ListThreatSignalsFeedsRequestSourceType = "curated" | "custom";
export interface ListThreatSignalsFeedsRequest {
    accountId: string;
    /** Exact feed-category filter, up to 100 characters. Omit to include all categories. */
    category?: string;
    /** Filter by enabled state. Accepts true, false, 1, or 0; omit to include enabled and disabled feeds. */
    enabled?: boolean;
    /** Optional 1-100 alias for per_page. When provided, limit takes precedence. */
    limit?: number;
    /** 1-based page number. Minimum 1; defaults to 1. */
    page?: number;
    /** Number of feeds per page, from 1 to 100. Defaults to 20. */
    perPage?: number;
    /** Sort by created_at, title, category, or url. Prefix the field with - for descending order; defaults to -created_at. */
    sort?: string;
    /** Filter by curated or custom feed source. Omit to include both source types. */
    sourceType?: ListThreatSignalsFeedsRequestSourceType | (string & {});
    /** Exact stored polling-status filter, such as active or error. Omit to include every status. */
    status?: string;
}
export interface ListThreatSignalsFeedsResponseFeedsItem {
    id: string;
    /** Feed category identifier. Null when unset. */
    categoryId: string;
    /** Display name of the feed category. Null when unset or unresolvable. */
    categoryName: string;
    createdAt: string;
    /** Curated catalog feed this subscription was created from. Null for custom feeds. */
    curatedFeedId: string;
    displayName: string;
    enabled: boolean;
    lastPolledAt: string;
    pollIntervalS: number;
    /** `custom` for a feed added by URL, `curated` for a curated catalog feed. */
    sourceType: string;
    /** Polling health: `active`, or `error` after a failed poll. */
    status: string;
    subscribedAt: string;
    title: string;
    updatedAt: string;
    url: string;
}
export type ListThreatSignalsFeedsResponseFeedsList = Array<ListThreatSignalsFeedsResponseFeedsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListThreatSignalsFeedsResponse {
    /** Number of feeds on this page. */
    count: number;
    /** The current count of custom feeds for the account. */
    customFeedCount: number;
    /** The resolved custom feed limit for the account. */
    customFeedLimit: number;
    feeds: ListThreatSignalsFeedsResponseFeedsList;
    page: number;
    perPage: number;
    totalCount: number;
}
export interface ListThreatSignalsIndicatorsRequest {
    accountId: string;
    /** Article UUID filter. Omit to include indicators from every article. */
    articleId?: string;
    /** Opaque cursor from the previous response's `pagination.cursor`. When provided, page size, ordering, and filters come from the cursor. Sending `per_page`, `sort`, `include_total`, `feed_id`, `article_id`, or `search` alongside it returns a 400 `CursorFilterConflictError`. */
    cursor?: string;
    /** Feed UUID filter. Omit to include indicators from every account feed. */
    feedId?: string;
    /** When true on the first page, count matching indicators and return an exact total. Defaults to false; cursor pages do not recalculate totals. */
    includeTotal?: boolean;
    /** Number of indicators per cursor page, from 1 to 100. Defaults to 20. */
    perPage?: number;
    /** NFC-normalized and trimmed, case-insensitive literal substring search of indicator values. Requires 3-500 Unicode code points; the upper code-point bound is described here because OpenAPI string length cannot precisely express it without imposing UTF-16 semantics. */
    search?: string;
    /** Sort by id. Use id for ascending or -id for descending order; defaults to id. */
    sort?: string;
}
export interface ListThreatSignalsIndicatorsResponseIndicatorsItem {
    id: string;
    articleId: string;
    articleTitle: string;
    /** Threat Events dataset identifier for navigating from this indicator. Null when the account feeds dataset mapping is unavailable. */
    datasetId: string;
    feedDisplayName: string;
    feedId: string;
    type: string;
    value: string;
}
export type ListThreatSignalsIndicatorsResponseIndicatorsList = Array<ListThreatSignalsIndicatorsResponseIndicatorsItem>;
export interface ListThreatSignalsIndicatorsResponsePagination {
    count: number;
    cursor: string;
    hasMore: boolean;
    /** Ordinal of this cursor page; not a total-results offset. */
    page: number;
    perPage: number;
    totalCount: number;
    totalCountIsExact: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListThreatSignalsIndicatorsResponse {
    indicators: ListThreatSignalsIndicatorsResponseIndicatorsList;
    pagination: ListThreatSignalsIndicatorsResponsePagination;
}
export interface ListThreatSignalsSkillsRequest {
    accountId: string;
    /** Page number (>= 1, default 1). */
    page?: number;
    /** Results per page (1-100, default 20). */
    perPage?: number;
}
export type ListThreatSignalsSkillsResponseSkillsItemSource = "default" | "custom";
export interface ListThreatSignalsSkillsResponseSkillsItem {
    id: string;
    /** JSON-encoded skill configuration. Always null for default skills. */
    config: string;
    createdAt: string;
    /** 1 when active, 0 when inactive. */
    isActive: number;
    name: string;
    /** JSON-encoded JSON Schema the skill output must satisfy. */
    outputSchema: string;
    prompt: string;
    /** `default` for Cloudforce One managed skills (read-only), `custom` for account skills. */
    source: ListThreatSignalsSkillsResponseSkillsItemSource;
    type: string;
    updatedAt: string;
}
export type ListThreatSignalsSkillsResponseSkillsList = Array<ListThreatSignalsSkillsResponseSkillsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListThreatSignalsSkillsResponse {
    /** Number of skills on this page. */
    count: number;
    /** Whether Custom Skills are available to the account. False for Free Threat Signals accounts, which receive managed default skills only. */
    customSkillsAvailable: boolean;
    page: number;
    perPage: number;
    skills: ListThreatSignalsSkillsResponseSkillsList;
    totalCount: number;
}
export type ScansConfigEditRequestIpsList = Array<string>;
export type ScansConfigEditRequestPortsList = Array<string>;
export interface PatchScanConfigRequest {
    /** Defines the Account ID. */
    accountId: string;
    /** Defines the Config ID. */
    configId: string;
    /** Defines the number of days between each scan (0 = One-off scan). */
    frequency?: number;
    /** Defines a list of IP addresses or CIDR blocks to scan. The maximum number of total IP addresses allowed is 5000. */
    ips?: ScansConfigEditRequestIpsList;
    /** Defines a list of ports to scan. Valid values are:"default", "all", or a comma-separated list of ports or range of ports (e.g. ["1-80", "443"]). "default" scans the 100 most commonly open ports. */
    ports?: ScansConfigEditRequestPortsList;
}
export type ScansConfigEditResponseIpsList = Array<string>;
export type ScansConfigEditResponsePortsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchScanConfigResponse {
    /** Defines the Config ID. */
    id: string;
    accountId: string;
    /** Defines the number of days between each scan (0 = One-off scan). */
    frequency: number;
    /** Defines a list of IP addresses or CIDR blocks to scan. The maximum number of total IP addresses allowed is 5000. */
    ips: ScansConfigEditResponseIpsList;
    /** Defines a list of ports to scan. Valid values are:"default", "all", or a comma-separated list of ports or range of ports (e.g. ["1-80", "443"]). "default" scans the 100 most commonly open ports. */
    ports: ScansConfigEditResponsePortsList;
}
export type ThreatEventsEditRequestRawDataMap = {
    [key: string]: unknown | undefined;
};
export interface ThreatEventsEditRequestRaw {
    data?: ThreatEventsEditRequestRawDataMap;
    source?: string;
    tlp?: string;
}
export interface PatchThreatEventRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
    /** Dataset ID containing the event to update. */
    datasetId: string;
    attacker?: string;
    attackerCountry?: string;
    category?: string;
    createdAt?: string;
    date?: string;
    event?: string;
    indicator?: string;
    indicatorType?: string;
    insight?: string;
    raw?: ThreatEventsEditRequestRaw;
    targetCountry?: string;
    targetIndustry?: string;
    tlp?: string;
}
export type ThreatEventsEditResponseMitreAttackList = Array<string>;
export type ThreatEventsEditResponseMitreCapecList = Array<string>;
export type ThreatEventsEditResponseReferencedList = Array<string>;
export type ThreatEventsEditResponseReferencedIdsList = Array<number>;
export type ThreatEventsEditResponseReferencesList = Array<string>;
export type ThreatEventsEditResponseReferencesIdsList = Array<number>;
export type ThreatEventsEditResponseTagsList = Array<string>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchThreatEventResponse {
    attacker: string;
    attackerCountry: string;
    attackerCountryAlpha3: string;
    category: string;
    datasetId: string;
    date: string;
    event: string;
    hasChildren: boolean;
    indicator: string;
    indicatorType: string;
    indicatorTypeId: number;
    killChain: number;
    mitreAttack: ThreatEventsEditResponseMitreAttackList;
    mitreCapec: ThreatEventsEditResponseMitreCapecList;
    numReferenced: number;
    numReferences: number;
    rawId: string;
    referenced: ThreatEventsEditResponseReferencedList;
    referencedIds: ThreatEventsEditResponseReferencedIdsList;
    references: ThreatEventsEditResponseReferencesList;
    referencesIds: ThreatEventsEditResponseReferencesIdsList;
    tags: ThreatEventsEditResponseTagsList;
    targetCountry: string;
    targetCountryAlpha3: string;
    targetIndustry: string;
    tlp: string;
    uuid: string;
    insight?: string | null;
    releasabilityId?: string | null;
}
export type ThreatEventsCategoriesEditRequestMitreAttackList = Array<string>;
export type ThreatEventsCategoriesEditRequestMitreCapecList = Array<string>;
export interface PatchThreatEventCategoryRequest {
    /** Account ID. */
    accountId: string;
    /** Category UUID. */
    categoryId: string;
    killChain?: number;
    mitreAttack?: ThreatEventsCategoriesEditRequestMitreAttackList;
    mitreCapec?: ThreatEventsCategoriesEditRequestMitreCapecList;
    name?: string;
    shortname?: string;
}
export type ThreatEventsCategoriesEditResponseMitreAttackList = Array<string>;
export type ThreatEventsCategoriesEditResponseMitreCapecList = Array<string>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchThreatEventCategoryResponse {
    killChain: number;
    name: string;
    uuid: string;
    mitreAttack?: ThreatEventsCategoriesEditResponseMitreAttackList | null;
    mitreCapec?: ThreatEventsCategoriesEditResponseMitreCapecList | null;
    shortname?: string | null;
}
export interface PatchThreatEventDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset ID. */
    datasetId: string;
    /** If true, then anyone can search the dataset. If false, then its limited to the account. */
    isPublic: boolean;
    /** Used to describe the dataset within the account context. */
    name: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchThreatEventDatasetResponse {
    isAnalytics: boolean;
    isPublic: boolean;
    name: string;
    uuid: string;
}
export interface PatchThreatEventRawRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
    /** Raw Event UUID. */
    rawId: string;
    data?: unknown;
    source?: string;
    tlp?: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchThreatEventRawResponse {
    id: string;
    data: unknown;
}
export interface PollThreatSignalsFeedRequest {
    accountId: string;
    /** UUID of a specific feed to poll, or "all" to poll all feeds. Omit or pass "all" for all feeds. */
    feedId?: string;
}
export type PollThreatSignalsFeedResponseFeedsItemStatus = "workflow_created" | "error";
export interface PollThreatSignalsFeedResponseFeedsItem {
    feedId: string;
    status: PollThreatSignalsFeedResponseFeedsItemStatus;
    workflowId: string;
    feedEnabled?: boolean | null;
}
export type PollThreatSignalsFeedResponseFeedsList = Array<PollThreatSignalsFeedResponseFeedsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PollThreatSignalsFeedResponse {
    errors: number;
    feeds: PollThreatSignalsFeedResponseFeedsList;
    triggered: number;
}
export interface QuotaRequestPriorityRequest {
    /** Identifier. */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface QuotaRequestPriorityResponse {
    /** Anniversary date is when annual quota limit is refreshed. */
    anniversaryDate?: string | null;
    /** Quarter anniversary date is when quota limit is refreshed each quarter. */
    quarterAnniversaryDate?: string | null;
    /** Tokens for the quarter. */
    quota?: number | null;
    /** Tokens remaining for the quarter. */
    remaining?: number | null;
}
export interface RawThreatEventDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset ID. */
    datasetId: string;
    /** Event ID. */
    eventId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface RawThreatEventDatasetResponse {
    id: number;
    accountId: number;
    created: string;
    data: string;
    source: string;
    tlp: string;
}
export interface RequestsConstantsRequest {
    /** Identifier. */
    accountId: string;
}
export type RequestsConstantsResponsePriorityItem = "routine" | "high" | "urgent";
export type RequestsConstantsResponsePriorityList = Array<RequestsConstantsResponsePriorityItem>;
export type RequestsConstantsResponseStatusItem = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
export type RequestsConstantsResponseStatusList = Array<RequestsConstantsResponseStatusItem>;
export type RequestsConstantsResponseTlpItem = "clear" | "amber" | "amber-strict" | "green" | "red";
export type RequestsConstantsResponseTlpList = Array<RequestsConstantsResponseTlpItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RequestsConstantsResponse {
    priority?: RequestsConstantsResponsePriorityList | null;
    status?: RequestsConstantsResponseStatusList | null;
    tlp?: RequestsConstantsResponseTlpList | null;
}
export interface RequestsQuotaRequest {
    /** Identifier. */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RequestsQuotaResponse {
    /** Anniversary date is when annual quota limit is refreshed. */
    anniversaryDate?: string | null;
    /** Quarter anniversary date is when quota limit is refreshed each quarter. */
    quarterAnniversaryDate?: string | null;
    /** Tokens for the quarter. */
    quota?: number | null;
    /** Tokens remaining for the quarter. */
    remaining?: number | null;
}
export interface RequestsTypesRequest {
    /** Identifier. */
    accountId: string;
}
export type RequestsTypesResultList = Array<string>;
export type RequestsTypesResponse = RequestsTypesResultList;
export interface SearchThreatSignalRequest {
    accountId: string;
    query: string;
    feedId?: string;
    maxResults?: string;
}
export interface SearchThreatSignalResponseResultsItem {
    articleId: string;
    datasetId: string;
    eventId: string;
    feedId: string;
    score: number;
    text: string;
}
export type SearchThreatSignalResponseResultsList = Array<SearchThreatSignalResponseResultsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchThreatSignalResponse {
    /** Number of unique article candidates returned in this response. Equal to results.length. */
    count: number;
    results: SearchThreatSignalResponseResultsList;
}
export type ThreatEventsBulkCreateRelationshipsRequestDataItemRawDataMap = {
    [key: string]: unknown | undefined;
};
export interface ThreatEventsBulkCreateRelationshipsRequestDataItemRaw {
    data: ThreatEventsBulkCreateRelationshipsRequestDataItemRawDataMap;
    source?: string;
    tlp?: string;
}
export type ThreatEventsBulkCreateRelationshipsRequestDataItemIndicatorsItem = ThreatEventsBulkCreateRequestDataItemIndicatorsItem;
export type ThreatEventsBulkCreateRelationshipsRequestDataItemIndicatorsList = Array<ThreatEventsBulkCreateRequestDataItemIndicatorsItem>;
export type ThreatEventsBulkCreateRelationshipsRequestDataItemTagsList = Array<string>;
export interface ThreatEventsBulkCreateRelationshipsRequestDataItem {
    category: string;
    date: string;
    event: string;
    raw: ThreatEventsBulkCreateRelationshipsRequestDataItemRaw;
    tlp: string;
    accountId?: number;
    attacker?: string;
    attackerCountry?: string;
    datasetId?: string;
    indicator?: string;
    /** Array of indicators for this event. Supports multiple indicators per event for complex scenarios. */
    indicators?: ThreatEventsBulkCreateRelationshipsRequestDataItemIndicatorsList;
    indicatorType?: string;
    insight?: string;
    tags?: ThreatEventsBulkCreateRelationshipsRequestDataItemTagsList;
    targetCountry?: string;
    targetIndustry?: string;
}
export type ThreatEventsBulkCreateRelationshipsRequestDataList = Array<ThreatEventsBulkCreateRelationshipsRequestDataItem>;
export interface ThreatEventsBulkCreateRelationshipsRequest {
    /** Account ID. */
    accountId: string;
    data: ThreatEventsBulkCreateRelationshipsRequestDataList;
    datasetId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ThreatEventsBulkCreateRelationshipsResponse {
    /** Number of events created */
    createdEventsCount: number;
    /** Number of indicators created */
    createdIndicatorsCount: number;
    /** Number of relationships created */
    createdRelationshipsCount: number;
    /** Number of errors encountered */
    errorCount: number;
}
export type ThreatSignalsArticlesBulkEditRequestArticleIdsList = Array<string>;
export interface ThreatSignalsArticlesBulkEditRequest {
    accountId: string;
    /** Array of article UUIDs to mark (1-50). */
    articleIds: ThreatSignalsArticlesBulkEditRequestArticleIdsList;
    /** True to mark read, false to mark unread. */
    read: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ThreatSignalsArticlesBulkEditResponse {
    updatedCount: number;
}
export interface ThreatSignalsHealthRequest {
    accountId: string;
}
export type ThreatSignalsHealthResponseStatus = "ok";
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ThreatSignalsHealthResponse {
    status: ThreatSignalsHealthResponseStatus;
}
export interface ThreatSignalsSearchSearchRequest {
    accountId: string;
    /** Keyword and semantic article-search text, from 1 to 1000 characters. */
    query: string;
    /** Optional feed UUID that restricts results to articles from that feed. */
    feedId?: string;
    /** Maximum search matches to request, an integer from 1 to 50. Defaults to 20 when omitted or empty; multiple matches from one article can produce fewer returned articles. */
    maxResults?: string;
}
export type ThreatSignalsSearchSearchResponseResultsItem = SearchThreatSignalResponseResultsItem;
export type ThreatSignalsSearchSearchResponseResultsList = Array<SearchThreatSignalResponseResultsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ThreatSignalsSearchSearchResponse {
    /** Number of unique article candidates returned in this response. Equal to results.length. */
    count: number;
    results: ThreatSignalsSearchSearchResponseResultsList;
}
export type UpdateRequestRequestTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export interface UpdateRequestRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** Request content. */
    content?: string;
    /** Priority for analyzing the request. */
    priority?: string;
    /** Requested information from request. */
    requestType?: string;
    /** Brief description of the request. */
    summary?: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp?: UpdateRequestRequestTlp | (string & {});
}
export type UpdateRequestResponseTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export type UpdateRequestResponseStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRequestResponse {
    /** UUID. */
    id: string;
    /** Request content. */
    content: string;
    created: string;
    priority: string;
    /** Requested information from request. */
    request: string;
    /** Brief description of the request. */
    summary: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: UpdateRequestResponseTlp;
    updated: string;
    completed?: string | null;
    /** Tokens for the request messages. */
    messageTokens?: number | null;
    /** Readable Request ID. */
    readableId?: string | null;
    /** Request Status. */
    status?: UpdateRequestResponseStatus | null;
    /** Tokens for the request. */
    tokens?: number | null;
}
export interface UpdateRequestAssetRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** UUID. */
    assetId: string;
    /** Asset file to upload. */
    source?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRequestAssetResponse {
    /** Asset ID. */
    id: number;
    /** Asset name. */
    name: string;
    /** Defines the asset creation time. */
    created?: string | null;
    /** Asset description. */
    description?: string | null;
    /** Asset file type. */
    fileType?: string | null;
}
export interface UpdateRequestMessageRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    messageId: number;
    /** Content of message. */
    content?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRequestMessageResponse {
    /** Message ID. */
    id: number;
    /** Author of message. */
    author: string;
    /** Content of message. */
    content: string;
    /** Whether the message is a follow-on request. */
    isFollowOnRequest: boolean;
    /** Defines the message last updated time. */
    updated: string;
    /** Defines the message creation time. */
    created?: string | null;
}
export type RequestsPriorityUpdateRequestLabelsList = Array<string>;
export type RequestsPriorityUpdateRequestTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export interface UpdateRequestPriorityRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    priorityId: string;
    /** List of labels. */
    labels: RequestsPriorityUpdateRequestLabelsList;
    /** Priority. */
    priority: number;
    /** Requirement. */
    requirement: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsPriorityUpdateRequestTlp | (string & {});
}
export type RequestsPriorityUpdateResponseTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export type RequestsPriorityUpdateResponseStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRequestPriorityResponse {
    /** UUID. */
    id: string;
    /** Request content. */
    content: string;
    created: string;
    priority: string;
    /** Requested information from request. */
    request: string;
    /** Brief description of the request. */
    summary: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsPriorityUpdateResponseTlp;
    updated: string;
    completed?: string | null;
    /** Tokens for the request messages. */
    messageTokens?: number | null;
    /** Readable Request ID. */
    readableId?: string | null;
    /** Request Status. */
    status?: RequestsPriorityUpdateResponseStatus | null;
    /** Tokens for the request. */
    tokens?: number | null;
}
export type UpdateThreatSignalsFeedsSkillRequestSkillIdsList = Array<string>;
export interface UpdateThreatSignalsFeedsSkillRequest {
    accountId: string;
    /** UUID of the Threat Signals feed */
    feedId: string;
    /** Ordered array of Custom Skill UUIDs (max 20). Replaces the feed's custom skill assignments. Free accounts cannot assign custom skills. Managed default skills are unaffected. */
    skillIds: UpdateThreatSignalsFeedsSkillRequestSkillIdsList;
}
export interface UpdateThreatSignalsFeedsSkillResponseSkillsItem {
    /** Zero-based pipeline position. */
    position: number;
    skillId: string;
}
export type UpdateThreatSignalsFeedsSkillResponseSkillsList = Array<UpdateThreatSignalsFeedsSkillResponseSkillsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateThreatSignalsFeedsSkillResponse {
    feedId: string;
    skills: UpdateThreatSignalsFeedsSkillResponseSkillsList;
}
export type UpdateThreatSignalsSkillsTagCategoryRequestSkillId = "default-tagging-skill";
export type UpdateThreatSignalsSkillsTagCategoryRequestCategoryUuidsList = Array<string>;
export interface UpdateThreatSignalsSkillsTagCategoryRequest {
    accountId: string;
    /** Must be default-tagging-skill; configures the managed default tagging skill */
    skillId: UpdateThreatSignalsSkillsTagCategoryRequestSkillId | (string & {});
    /** Up to 100 unique tag category UUIDs that the managed default tagging skill may select tags from. */
    categoryUuids: UpdateThreatSignalsSkillsTagCategoryRequestCategoryUuidsList;
}
export type UpdateThreatSignalsSkillsTagCategoryResponseCategoryUuidsList = Array<string>;
export type UpdateThreatSignalsSkillsTagCategoryResponseSkillId = "default-tagging-skill";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateThreatSignalsSkillsTagCategoryResponse {
    categoryUuids: UpdateThreatSignalsSkillsTagCategoryResponseCategoryUuidsList;
    skillId: UpdateThreatSignalsSkillsTagCategoryResponseSkillId;
}
export type BulkCreateThreatEventsError = CloudflareOpError;
/** The `datasetId` parameter must be defined. To list existing datasets (and their IDs) in your account, use the [`List Datasets`](https://developers.cloudflare.com/api/resources/cloudforce_one/subresources/threat_events/subresources/datasets/methods/list/) endpoint. */
export declare const bulkCreateThreatEvents: API.OperationMethod<BulkCreateThreatEventsRequest, BulkCreateThreatEventsResponse, BulkCreateThreatEventsError, CloudflareOpContext>;
export type CreateBinaryStorageError = CloudflareOpError;
/** Uploads a binary file to Cloudforce One's binary database for malware analysis and threat intelligence correlation. */
export declare const createBinaryStorage: API.OperationMethod<CreateBinaryStorageRequest, CreateBinaryStorageResponse, CreateBinaryStorageError, CloudflareOpContext>;
export type CreateRequestError = CloudflareOpError;
/** Creating a request adds the request into the Cloudforce One queue for analysis. In addition to the content, a short title, type, priority, and releasability should be provided. If one is not provided, a default will be assigned. */
export declare const createRequest: API.OperationMethod<CreateRequestRequest, CreateRequestResponse, CreateRequestError, CloudflareOpContext>;
export type CreateRequestAssetError = CloudflareOpError;
/** Lists assets attached to a Cloudforce One intelligence request. */
export declare const createRequestAsset: API.PaginatedOperationMethod<CreateRequestAssetRequest, CreateRequestAssetResponse, CreateRequestAssetError, CloudflareOpContext, RequestsAssetsCreateResultItem>;
export type CreateRequestMessageError = CloudflareOpError;
/** Adds a message to a Cloudforce One intelligence request conversation. */
export declare const createRequestMessage: API.OperationMethod<CreateRequestMessageRequest, CreateRequestMessageResponse, CreateRequestMessageError, CloudflareOpContext>;
export type CreateRequestPriorityError = CloudflareOpError;
/** Creates a new priority intelligence request in Cloudforce One. */
export declare const createRequestPriority: API.OperationMethod<CreateRequestPriorityRequest, CreateRequestPriorityResponse, CreateRequestPriorityError, CloudflareOpContext>;
export type CreateScanConfigError = CloudflareOpError;
/** Creates a new scan configuration for Cloudforce One's network scanning service. */
export declare const createScanConfig: API.OperationMethod<CreateScanConfigRequest, CreateScanConfigResponse, CreateScanConfigError, CloudflareOpContext>;
export type CreateThreatEventError = CloudflareOpError;
/** To create a dataset, see the [`Create Dataset`](https://developers.cloudflare.com/api/resources/cloudforce_one/subresources/threat_events/subresources/datasets/methods/create/) endpoint. When `datasetId` parameter is unspecified, it will be created in a default dataset named `Cloudforce One Threat Events`. */
export declare const createThreatEvent: API.OperationMethod<CreateThreatEventRequest, CreateThreatEventResponse, CreateThreatEventError, CloudflareOpContext>;
export type CreateThreatEventCategoryError = CloudflareOpError;
/** Creates a new threat event category in Cloudforce One for organizing and classifying threat events. */
export declare const createThreatEventCategory: API.OperationMethod<CreateThreatEventCategoryRequest, CreateThreatEventCategoryResponse, CreateThreatEventCategoryError, CloudflareOpContext>;
export type CreateThreatEventDatasetError = CloudflareOpError;
/** Creates a new threat event dataset in Cloudforce One for organizing related threat events. */
export declare const createThreatEventDataset: API.OperationMethod<CreateThreatEventDatasetRequest, CreateThreatEventDatasetResponse, CreateThreatEventDatasetError, CloudflareOpContext>;
export type CreateThreatEventEventTagError = CloudflareOpError;
/** Adds a tag to a threat event in Cloudforce One for classification and filtering. */
export declare const createThreatEventEventTag: API.OperationMethod<CreateThreatEventEventTagRequest, CreateThreatEventEventTagResponse, CreateThreatEventEventTagError, CloudflareOpContext>;
export type CreateThreatEventsGraphqlError = CloudflareOpError;
/** Execute GraphQL aggregations over threat events. Supports multi-dimensional group-bys, optional date range filtering, and multi-dataset aggregation. */
export declare const createThreatEventsGraphql: API.OperationMethod<CreateThreatEventsGraphqlRequest, CreateThreatEventsGraphqlResponse, CreateThreatEventsGraphqlError, CloudflareOpContext>;
export type CreateThreatEventsQueryError = CloudflareOpError;
/** Create a new saved event query for the account */
export declare const createThreatEventsQuery: API.OperationMethod<CreateThreatEventsQueryRequest, CreateThreatEventsQueryResponse, CreateThreatEventsQueryError, CloudflareOpContext>;
export type CreateThreatEventsTagsCategoryError = CloudflareOpError;
/** Creates a new Source-of-Truth tag category for an account. */
export declare const createThreatEventsTagsCategory: API.OperationMethod<CreateThreatEventsTagsCategoryRequest, CreateThreatEventsTagsCategoryResponse, CreateThreatEventsTagsCategoryError, CloudflareOpContext>;
export type CreateThreatEventTagError = CloudflareOpError;
/** Creates an account-owned tag for threat events and returns its complete owner projection. */
export declare const createThreatEventTag: API.OperationMethod<CreateThreatEventTagRequest, CreateThreatEventTagResponse, CreateThreatEventTagError, CloudflareOpContext>;
export type CreateThreatSignalsArticlesTagError = CloudflareOpError;
/** Applies a tag from the account's tag catalog to a Threat Signals article. */
export declare const createThreatSignalsArticlesTag: API.OperationMethod<CreateThreatSignalsArticlesTagRequest, CreateThreatSignalsArticlesTagResponse, CreateThreatSignalsArticlesTagError, CloudflareOpContext>;
export type CreateThreatSignalsFeedError = CloudflareOpError;
/** Subscribes the account to a custom or curated Threat Signals feed. Adding a custom feed when the account is at its custom-feed limit returns 403 with `errors[0].reason` `threat_signals_feed_limit`, and `errors[0].custom_feed_limit` and `errors[0].custom_feed_count` give the limit and current count. Curated feeds are not subject to this limit. */
export declare const createThreatSignalsFeed: API.OperationMethod<CreateThreatSignalsFeedRequest, CreateThreatSignalsFeedResponse, CreateThreatSignalsFeedError, CloudflareOpContext>;
export type CreateThreatSignalsSkillError = CloudflareOpError;
/** Creates a Custom Skill for the account. Free Threat Signals accounts cannot create Custom Skills. */
export declare const createThreatSignalsSkill: API.OperationMethod<CreateThreatSignalsSkillRequest, CreateThreatSignalsSkillResponse, CreateThreatSignalsSkillError, CloudflareOpContext>;
export type DeleteRequestError = CloudflareOpError;
/** Deletes a Cloudforce One intelligence request and all associated data. */
export declare const deleteRequest: API.OperationMethod<DeleteRequestRequest, DeleteRequestResponse, DeleteRequestError, CloudflareOpContext>;
export type DeleteRequestAssetError = CloudflareOpError;
/** Removes an asset from a Cloudforce One intelligence request. */
export declare const deleteRequestAsset: API.OperationMethod<DeleteRequestAssetRequest, DeleteRequestAssetResponse, DeleteRequestAssetError, CloudflareOpContext>;
export type DeleteRequestMessageError = CloudflareOpError;
/** Removes a message from a Cloudforce One intelligence request thread. */
export declare const deleteRequestMessage: API.OperationMethod<DeleteRequestMessageRequest, DeleteRequestMessageResponse, DeleteRequestMessageError, CloudflareOpContext>;
export type DeleteRequestPriorityError = CloudflareOpError;
/** Deletes a priority intelligence request from Cloudforce One. */
export declare const deleteRequestPriority: API.OperationMethod<DeleteRequestPriorityRequest, DeleteRequestPriorityResponse, DeleteRequestPriorityError, CloudflareOpContext>;
export type DeleteScanConfigError = ScanConfigNotFound | CloudflareOpError;
/** Deletes a scan configuration from Cloudforce One's network scanning service. */
export declare const deleteScanConfig: API.OperationMethod<DeleteScanConfigRequest, DeleteScanConfigResponse, DeleteScanConfigError, CloudflareOpContext>;
export type DeleteThreatEventCategoryError = CloudflareOpError;
/** Deprecated; use DELETE /events/event-categories/by-id/{category_id}. Available through 2026-11-28. */
export declare const deleteThreatEventCategory: API.OperationMethod<DeleteThreatEventCategoryRequest, DeleteThreatEventCategoryResponse, DeleteThreatEventCategoryError, CloudflareOpContext>;
export type DeleteThreatEventEventTagError = CloudflareOpError;
/** Removes a tag from a threat event in Cloudforce One. */
export declare const deleteThreatEventEventTag: API.OperationMethod<DeleteThreatEventEventTagRequest, DeleteThreatEventEventTagResponse, DeleteThreatEventEventTagError, CloudflareOpContext>;
export type DeleteThreatEventRelateError = CloudflareOpError;
/** Removes a reference link between related threat events in Cloudforce One. */
export declare const deleteThreatEventRelate: API.OperationMethod<DeleteThreatEventRelateRequest, DeleteThreatEventRelateResponse, DeleteThreatEventRelateError, CloudflareOpContext>;
export type DeleteThreatEventsDatasetError = CloudflareOpError;
/** Soft-deletes a dataset given a datasetId. */
export declare const deleteThreatEventsDataset: API.OperationMethod<DeleteThreatEventsDatasetRequest, DeleteThreatEventsDatasetResponse, DeleteThreatEventsDatasetError, CloudflareOpContext>;
export type DeleteThreatEventsQueryError = CloudflareOpError;
/** Delete a saved event query by its ID */
export declare const deleteThreatEventsQuery: API.OperationMethod<DeleteThreatEventsQueryRequest, DeleteThreatEventsQueryResponse, DeleteThreatEventsQueryError, CloudflareOpContext>;
export type DeleteThreatEventsTagError = CloudflareOpError;
/** Deletes a Source-of-Truth tag by UUID. */
export declare const deleteThreatEventsTag: API.OperationMethod<DeleteThreatEventsTagRequest, DeleteThreatEventsTagResponse, DeleteThreatEventsTagError, CloudflareOpContext>;
export type DeleteThreatEventsTagsCategoryError = CloudflareOpError;
/** Deprecated; use DELETE /events/tag-categories/{category_uuid}. Available through 2026-11-28. */
export declare const deleteThreatEventsTagsCategory: API.OperationMethod<DeleteThreatEventsTagsCategoryRequest, DeleteThreatEventsTagsCategoryResponse, DeleteThreatEventsTagsCategoryError, CloudflareOpContext>;
export type DeleteThreatSignalsArticlesTagError = CloudflareOpError;
/** Removes a tag from a Threat Signals article. */
export declare const deleteThreatSignalsArticlesTag: API.OperationMethod<DeleteThreatSignalsArticlesTagRequest, DeleteThreatSignalsArticlesTagResponse, DeleteThreatSignalsArticlesTagError, CloudflareOpContext>;
export type DeleteThreatSignalsFeedError = CloudflareOpError;
/** Unsubscribes the account from a Threat Signals feed and deletes its articles. */
export declare const deleteThreatSignalsFeed: API.OperationMethod<DeleteThreatSignalsFeedRequest, DeleteThreatSignalsFeedResponse, DeleteThreatSignalsFeedError, CloudflareOpContext>;
export type DeleteThreatSignalsSkillError = CloudflareOpError;
/** Deletes a Custom Skill. The skill's stored outputs on articles are deleted with it. Managed Default Skills cannot be deleted. Free Threat Signals accounts cannot delete Custom Skills. */
export declare const deleteThreatSignalsSkill: API.OperationMethod<DeleteThreatSignalsSkillRequest, DeleteThreatSignalsSkillResponse, DeleteThreatSignalsSkillError, CloudflareOpContext>;
export type EditThreatEventsQueryError = CloudflareOpError;
/** Update an existing saved event query by its ID */
export declare const editThreatEventsQuery: API.OperationMethod<EditThreatEventsQueryRequest, EditThreatEventsQueryResponse, EditThreatEventsQueryError, CloudflareOpContext>;
export type EditThreatEventsTagError = CloudflareOpError;
/** Updates an account-owned Source-of-Truth tag by UUID and returns its complete owner projection. */
export declare const editThreatEventsTag: API.OperationMethod<EditThreatEventsTagRequest, EditThreatEventsTagResponse, EditThreatEventsTagError, CloudflareOpContext>;
export type EditThreatEventsTagsCategoryError = CloudflareOpError;
/** Deprecated; use PATCH /events/tag-categories/{category_uuid}. Available through 2026-11-28. */
export declare const editThreatEventsTagsCategory: API.OperationMethod<EditThreatEventsTagsCategoryRequest, EditThreatEventsTagsCategoryResponse, EditThreatEventsTagsCategoryError, CloudflareOpContext>;
export type EditThreatSignalsArticleError = CloudflareOpError;
/** Marks a Threat Signals article as read or unread. */
export declare const editThreatSignalsArticle: API.OperationMethod<EditThreatSignalsArticleRequest, EditThreatSignalsArticleResponse, EditThreatSignalsArticleError, CloudflareOpContext>;
export type EditThreatSignalsFeedError = CloudflareOpError;
/** Updates a Threat Signals feed subscription. */
export declare const editThreatSignalsFeed: API.OperationMethod<EditThreatSignalsFeedRequest, EditThreatSignalsFeedResponse, EditThreatSignalsFeedError, CloudflareOpContext>;
export type EditThreatSignalsSkillError = CloudflareOpError;
/** Updates a Custom Skill. Managed Default Skills cannot be updated. Free Threat Signals accounts cannot update Custom Skills. */
export declare const editThreatSignalsSkill: API.OperationMethod<EditThreatSignalsSkillRequest, EditThreatSignalsSkillResponse, EditThreatSignalsSkillError, CloudflareOpContext>;
export type GenerateThreatSignalsArticlesTagError = CloudflareOpError;
/** Runs the default AI tagging skill on an article and replaces its AI-applied tags. */
export declare const generateThreatSignalsArticlesTag: API.OperationMethod<GenerateThreatSignalsArticlesTagRequest, GenerateThreatSignalsArticlesTagResponse, GenerateThreatSignalsArticlesTagError, CloudflareOpContext>;
export type GetBinaryStorageError = CloudflareOpError;
/** Retrieves a binary file from the Cloudforce One binary storage for analysis. */
export declare const getBinaryStorage: API.OperationMethod<GetBinaryStorageRequest, GetBinaryStorageResponse, GetBinaryStorageError, CloudflareOpContext>;
export type GetRequestError = CloudflareOpError;
/** Retrieves details for a specific Cloudforce One intelligence request. */
export declare const getRequest: API.OperationMethod<GetRequestRequest, GetRequestResponse, GetRequestError, CloudflareOpContext>;
export type GetRequestMessageError = CloudflareOpError;
/** Lists messages in a Cloudforce One intelligence request conversation. */
export declare const getRequestMessage: API.PaginatedOperationMethod<GetRequestMessageRequest, GetRequestMessageResponse, GetRequestMessageError, CloudflareOpContext, RequestsMessageGetResultItem>;
export type GetRequestPriorityError = CloudflareOpError;
/** Retrieves a specific priority intelligence request from Cloudforce One. */
export declare const getRequestPriority: API.OperationMethod<GetRequestPriorityRequest, GetRequestPriorityResponse, GetRequestPriorityError, CloudflareOpContext>;
export type GetRequestsAssetError = CloudflareOpError;
/** Retrieves an asset attached to a Cloudforce One intelligence request. */
export declare const getRequestsAsset: API.OperationMethod<GetRequestsAssetRequest, GetRequestsAssetResponse, GetRequestsAssetError, CloudflareOpContext>;
export type GetScanResultError = CloudflareOpError;
/** Retrieves the latest scan results for a Cloudforce One scan configuration, including discovered open ports. */
export declare const getScanResult: API.OperationMethod<GetScanResultRequest, GetScanResultResponse, GetScanResultError, CloudflareOpContext>;
export type GetThreatEventError = CloudflareOpError;
/** This Method is deprecated. Please use /events/dataset/:dataset_id/events/:event_id instead. */
export declare const getThreatEvent: API.OperationMethod<GetThreatEventRequest, GetThreatEventResponse, GetThreatEventError, CloudflareOpContext>;
export type GetThreatEventCategoryError = CloudflareOpError;
/** Deprecated; use GET /events/event-categories/by-id/{category_id}. Available through 2026-11-28. */
export declare const getThreatEventCategory: API.OperationMethod<GetThreatEventCategoryRequest, GetThreatEventCategoryResponse, GetThreatEventCategoryError, CloudflareOpContext>;
export type GetThreatEventDatasetError = CloudflareOpError;
/** Retrieves details for a specific threat event dataset. */
export declare const getThreatEventDataset: API.OperationMethod<GetThreatEventDatasetRequest, GetThreatEventDatasetResponse, GetThreatEventDatasetError, CloudflareOpContext>;
export type GetThreatEventRawError = CloudflareOpError;
/** Retrieves raw threat event data for a specific event in Cloudforce One. */
export declare const getThreatEventRaw: API.OperationMethod<GetThreatEventRawRequest, GetThreatEventRawResponse, GetThreatEventRawError, CloudflareOpContext>;
export type GetThreatEventsDatasetsEventError = CloudflareOpError;
/** Retrieves a specific event by its UUID. */
export declare const getThreatEventsDatasetsEvent: API.OperationMethod<GetThreatEventsDatasetsEventRequest, GetThreatEventsDatasetsEventResponse, GetThreatEventsDatasetsEventError, CloudflareOpContext>;
export type GetThreatEventsIndicatorsByDatasetError = CloudflareOpError;
/** Retrieves a specific indicator by its UUID. */
export declare const getThreatEventsIndicatorsByDataset: API.OperationMethod<GetThreatEventsIndicatorsByDatasetRequest, GetThreatEventsIndicatorsByDatasetResponse, GetThreatEventsIndicatorsByDatasetError, CloudflareOpContext>;
export type GetThreatEventsQueryError = CloudflareOpError;
/** Retrieve a saved event query by its ID */
export declare const getThreatEventsQuery: API.OperationMethod<GetThreatEventsQueryRequest, GetThreatEventsQueryResponse, GetThreatEventsQueryError, CloudflareOpContext>;
export type GetThreatSignalsArticleError = CloudflareOpError;
/** Retrieves a Threat Signals article with its summary, tags and indicator status. */
export declare const getThreatSignalsArticle: API.OperationMethod<GetThreatSignalsArticleRequest, GetThreatSignalsArticleResponse, GetThreatSignalsArticleError, CloudflareOpContext>;
export type GetThreatSignalsArticlesContentError = CloudflareOpError;
/** Retrieves the stored content of a Threat Signals article, unchanged. Depending on how the article was captured from its source, the content is HTML, Markdown, or plain text. The format parameter sets only the response Content-Type; it does not convert the content. */
export declare const getThreatSignalsArticlesContent: API.OperationMethod<GetThreatSignalsArticlesContentRequest, GetThreatSignalsArticlesContentResponse, GetThreatSignalsArticlesContentError, CloudflareOpContext>;
export type GetThreatSignalsArticlesSkillOutputError = CloudflareOpError;
/** Retrieves the stored output of a skill for a Threat Signals article. The custom_output field is parsed JSON when the stored output is valid JSON, otherwise the raw string. */
export declare const getThreatSignalsArticlesSkillOutput: API.OperationMethod<GetThreatSignalsArticlesSkillOutputRequest, GetThreatSignalsArticlesSkillOutputResponse, GetThreatSignalsArticlesSkillOutputError, CloudflareOpContext>;
export type GetThreatSignalsFeedsRawError = CloudflareOpError;
/** Retrieves the feed document fetched by the most recent poll as text/plain by default or application/xml when format is xml. */
export declare const getThreatSignalsFeedsRaw: API.OperationMethod<GetThreatSignalsFeedsRawRequest, GetThreatSignalsFeedsRawResponse, GetThreatSignalsFeedsRawError, CloudflareOpContext>;
export type GetThreatSignalsFeedsSkillError = CloudflareOpError;
/** Retrieves active non-IOC-context Managed Default Skills followed by active Custom Skills assigned to the feed, with each entry's source. Free Threat Signals accounts receive only those Managed Default Skills. */
export declare const getThreatSignalsFeedsSkill: API.OperationMethod<GetThreatSignalsFeedsSkillRequest, GetThreatSignalsFeedsSkillResponse, GetThreatSignalsFeedsSkillError, CloudflareOpContext>;
export type GetThreatSignalsSkillError = CloudflareOpError;
/** Retrieves a Managed Default Skill or Custom Skill. Managed catalog definitions are readable. Free Threat Signals accounts cannot read Custom Skills. */
export declare const getThreatSignalsSkill: API.OperationMethod<GetThreatSignalsSkillRequest, GetThreatSignalsSkillResponse, GetThreatSignalsSkillError, CloudflareOpContext>;
export type GetThreatSignalsSkillsTagCategoryError = CloudflareOpError;
/** Retrieves the Tag Categories the managed default tagging skill may select tags from. This configures the managed default tagging skill, not Custom Skills. */
export declare const getThreatSignalsSkillsTagCategory: API.OperationMethod<GetThreatSignalsSkillsTagCategoryRequest, GetThreatSignalsSkillsTagCategoryResponse, GetThreatSignalsSkillsTagCategoryError, CloudflareOpContext>;
export type ListRequestsError = CloudflareOpError;
/** Lists Cloudforce One intelligence requests with filtering and pagination. */
export declare const listRequests: API.OperationMethod<ListRequestsRequest, ListRequestsResponse, ListRequestsError, CloudflareOpContext>;
export type ListScanConfigsError = CloudflareOpError;
/** Lists scan configurations for Cloudforce One's network scanning service. */
export declare const listScanConfigs: API.PaginatedOperationMethod<ListScanConfigsRequest, ListScanConfigsResponse, ListScanConfigsError, CloudflareOpContext, ScansConfigListResultItem>;
export type ListThreatEventAttackersError = CloudflareOpError;
/** Lists known threat attackers tracked in Cloudforce One threat intelligence. */
export declare const listThreatEventAttackers: API.OperationMethod<ListThreatEventAttackersRequest, ListThreatEventAttackersResponse, ListThreatEventAttackersError, CloudflareOpContext>;
export type ListThreatEventCategoriesError = CloudflareOpError;
/** Lists all threat event categories configured for classifying and organizing threat events. */
export declare const listThreatEventCategories: API.OperationMethod<ListThreatEventCategoriesRequest, ListThreatEventCategoriesResponse, ListThreatEventCategoriesError, CloudflareOpContext>;
export type ListThreatEventCountriesError = CloudflareOpError;
/** Lists countries referenced in Cloudforce One threat intelligence data. */
export declare const listThreatEventCountries: API.OperationMethod<ListThreatEventCountriesRequest, ListThreatEventCountriesResponse, ListThreatEventCountriesError, CloudflareOpContext>;
export type ListThreatEventDatasetsError = CloudflareOpError;
/** Lists all threat event datasets configured in Cloudforce One. */
export declare const listThreatEventDatasets: API.OperationMethod<ListThreatEventDatasetsRequest, ListThreatEventDatasetsResponse, ListThreatEventDatasetsError, CloudflareOpContext>;
export type ListThreatEventIndicatorTypesError = CloudflareOpError;
/** This Method is deprecated. Please use /events/dataset/:dataset_id/indicatorTypes instead. */
export declare const listThreatEventIndicatorTypes: API.OperationMethod<ListThreatEventIndicatorTypesRequest, ListThreatEventIndicatorTypesResponse, ListThreatEventIndicatorTypesError, CloudflareOpContext>;
export type ListThreatEventsError = CloudflareOpError;
/** Use one standalone `datasetId` scope value: 'all'/'*' or 'operational' for readable intelligence datasets (isAnalytics=false), or 'analytics' for readable analytics datasets (isAnalytics=true). Scope values query at most 50 datasets and must be used alone. When `datasetId` is unspecified, events are listed from the default Cloudforce One Threat Events dataset. To list existing datasets, use the [`List Datasets`](https://developers.cloudflare.com/api/resources/cloudforce_one/subresources/threat_events/subresources/datasets/methods/list/) endpoint. */
export declare const listThreatEvents: API.OperationMethod<ListThreatEventsRequest, ListThreatEventsResponse, ListThreatEventsError, CloudflareOpContext>;
export type ListThreatEventsAggregateError = CloudflareOpError;
/** Aggregate threat events by one or more columns (e.g., attacker, targetIndustry) with optional date filtering and daily grouping. Supports multi-dimensional aggregation for cross-analysis. */
export declare const listThreatEventsAggregate: API.OperationMethod<ListThreatEventsAggregateRequest, ListThreatEventsAggregateResponse, ListThreatEventsAggregateError, CloudflareOpContext>;
export type ListThreatEventsCategoriesCatalogError = CloudflareOpError;
/** Lists categories */
export declare const listThreatEventsCategoriesCatalog: API.OperationMethod<ListThreatEventsCategoriesCatalogRequest, ListThreatEventsCategoriesCatalogResponse, ListThreatEventsCategoriesCatalogError, CloudflareOpContext>;
export type ListThreatEventsGraphError = CloudflareOpError;
/** Expands the single-level relationship neighborhood of one or more seed nodes (event, indicator, or tag) from R2 Data Catalog. Seeds use compact id format (type:uuid), e.g. "event:550e8400-...". Multi-seed requests merge and deduplicate results server-side. Hydrates neighbor entities with summary data from Durable Objects. Supports filtering by relationship type and dataset scope. */
export declare const listThreatEventsGraph: API.OperationMethod<ListThreatEventsGraphRequest, ListThreatEventsGraphResponse, ListThreatEventsGraphError, CloudflareOpContext>;
export type ListThreatEventsIndicatorsError = CloudflareOpError;
/** Retrieves indicators across specified datasets, ordered by createdAt descending then UUID, dataset ID, and shard ID ascending. Use one standalone datasetIds scope value: 'all'/'*' or 'operational' for readable intelligence datasets (isAnalytics=false), or 'analytics' for readable analytics datasets (isAnalytics=true). If no datasetIds are provided, uses the default dataset. */
export declare const listThreatEventsIndicators: API.OperationMethod<ListThreatEventsIndicatorsRequest, ListThreatEventsIndicatorsResponse, ListThreatEventsIndicatorsError, CloudflareOpContext>;
export type ListThreatEventsIndicatorsAggregateError = CloudflareOpError;
/** Aggregate threat indicators by one or more columns (e.g., indicatorType, value) across datasets. Returns top-N groups ordered by count. */
export declare const listThreatEventsIndicatorsAggregate: API.OperationMethod<ListThreatEventsIndicatorsAggregateRequest, ListThreatEventsIndicatorsAggregateResponse, ListThreatEventsIndicatorsAggregateError, CloudflareOpContext>;
export type ListThreatEventsIndicatorsByDatasetError = CloudflareOpError;
/** This method is deprecated. Please use /events/indicators to retrieve a paginated list of indicators. */
export declare const listThreatEventsIndicatorsByDataset: API.OperationMethod<ListThreatEventsIndicatorsByDatasetRequest, ListThreatEventsIndicatorsByDatasetResponse, ListThreatEventsIndicatorsByDatasetError, CloudflareOpContext>;
export type ListThreatEventsIndicatorsByDatasetTagsError = CloudflareOpError;
/** Returns all mirrored tags from the indicator dataset (DO mirror table). No pagination. */
export declare const listThreatEventsIndicatorsByDatasetTags: API.OperationMethod<ListThreatEventsIndicatorsByDatasetTagsRequest, ListThreatEventsIndicatorsByDatasetTagsResponse, ListThreatEventsIndicatorsByDatasetTagsError, CloudflareOpContext>;
export type ListThreatEventsIndicatorsTypesError = CloudflareOpError;
/** Lists indicator types across multiple datasets */
export declare const listThreatEventsIndicatorsTypes: API.OperationMethod<ListThreatEventsIndicatorsTypesRequest, ListThreatEventsIndicatorsTypesResponse, ListThreatEventsIndicatorsTypesError, CloudflareOpContext>;
export type ListThreatEventsQueriesError = CloudflareOpError;
/** Retrieve all saved event queries for the account */
export declare const listThreatEventsQueries: API.OperationMethod<ListThreatEventsQueriesRequest, ListThreatEventsQueriesResponse, ListThreatEventsQueriesError, CloudflareOpContext>;
export type ListThreatEventsRelationshipsError = CloudflareOpError;
/** Deprecated; use GET /events/by-id/{event_id}/relationships. Available through 2026-11-28. */
export declare const listThreatEventsRelationships: API.OperationMethod<ListThreatEventsRelationshipsRequest, ListThreatEventsRelationshipsResponse, ListThreatEventsRelationshipsError, CloudflareOpContext>;
export type ListThreatEventsTagsError = CloudflareOpError;
/** Returns all Source-of-Truth tags for an account. Supports legacy free-text `search` on tag value and `categoryUuid` exact match, plus a structured `filters` JSON array for filtering by metadata fields (originCountryISO, actorCategory, motive, priority, etc.). The authenticated account owns these account-scoped tags and receives their complete owner projection. Country values may be passed as alpha-2, alpha-3, name, or common alias. Purple TLP remains CFONE-only. */
export declare const listThreatEventsTags: API.OperationMethod<ListThreatEventsTagsRequest, ListThreatEventsTagsResponse, ListThreatEventsTagsError, CloudflareOpContext>;
export type ListThreatEventsTagsCategoriesError = CloudflareOpError;
/** Returns all Source-of-Truth tag categories for an account. */
export declare const listThreatEventsTagsCategories: API.OperationMethod<ListThreatEventsTagsCategoriesRequest, ListThreatEventsTagsCategoriesResponse, ListThreatEventsTagsCategoriesError, CloudflareOpContext>;
export type ListThreatEventsTagsIndicatorsError = CloudflareOpError;
/** Returns indicators associated with the provided tag UUID, with pagination. By default fans out across every intelligence (isAnalytics=false) indicator dataset the account can read; pass datasetIds to scope to dataset UUIDs or a scope value. Analytics datasets do not expose tag associations, so the analytics scope returns an empty result. */
export declare const listThreatEventsTagsIndicators: API.OperationMethod<ListThreatEventsTagsIndicatorsRequest, ListThreatEventsTagsIndicatorsResponse, ListThreatEventsTagsIndicatorsError, CloudflareOpContext>;
export type ListThreatEventsTagsIndicatorsByDatasetError = CloudflareOpError;
/** This endpoint is deprecated. Use GET /:account_id/events/tags/:tag_uuid/indicators with the optional datasetIds query parameter instead. Returns indicators associated with the provided tag UUID within a single dataset's indicator shards, with pagination. */
export declare const listThreatEventsTagsIndicatorsByDataset: API.OperationMethod<ListThreatEventsTagsIndicatorsByDatasetRequest, ListThreatEventsTagsIndicatorsByDatasetResponse, ListThreatEventsTagsIndicatorsByDatasetError, CloudflareOpContext>;
export type ListThreatEventsTargetIndustriesByDatasetError = CloudflareOpError;
/** Lists all target industries for a specific dataset */
export declare const listThreatEventsTargetIndustriesByDataset: API.OperationMethod<ListThreatEventsTargetIndustriesByDatasetRequest, ListThreatEventsTargetIndustriesByDatasetResponse, ListThreatEventsTargetIndustriesByDatasetError, CloudflareOpContext>;
export type ListThreatEventsTargetIndustriesCatalogError = CloudflareOpError;
/** Lists all target industries from industry map catalog */
export declare const listThreatEventsTargetIndustriesCatalog: API.OperationMethod<ListThreatEventsTargetIndustriesCatalogRequest, ListThreatEventsTargetIndustriesCatalogResponse, ListThreatEventsTargetIndustriesCatalogError, CloudflareOpContext>;
export type ListThreatEventTargetIndustriesError = CloudflareOpError;
/** Retrieves the catalog of industry classifications used in Cloudforce One threat intelligence. */
export declare const listThreatEventTargetIndustries: API.OperationMethod<ListThreatEventTargetIndustriesRequest, ListThreatEventTargetIndustriesResponse, ListThreatEventTargetIndustriesError, CloudflareOpContext>;
export type ListThreatSignalsArticlesError = CloudflareOpError;
/** Lists articles from the account's Threat Signals feeds. */
export declare const listThreatSignalsArticles: API.OperationMethod<ListThreatSignalsArticlesRequest, ListThreatSignalsArticlesResponse, ListThreatSignalsArticlesError, CloudflareOpContext>;
export type ListThreatSignalsCategoriesError = CloudflareOpError;
/** Lists the predefined categories that can be assigned to feeds. */
export declare const listThreatSignalsCategories: API.OperationMethod<ListThreatSignalsCategoriesRequest, ListThreatSignalsCategoriesResponse, ListThreatSignalsCategoriesError, CloudflareOpContext>;
export type ListThreatSignalsFeedsError = CloudflareOpError;
/** Lists the account's Threat Signals feed subscriptions. */
export declare const listThreatSignalsFeeds: API.OperationMethod<ListThreatSignalsFeedsRequest, ListThreatSignalsFeedsResponse, ListThreatSignalsFeedsError, CloudflareOpContext>;
export type ListThreatSignalsIndicatorsError = CloudflareOpError;
/** Lists indicators of compromise extracted from the account's Threat Signals articles. */
export declare const listThreatSignalsIndicators: API.OperationMethod<ListThreatSignalsIndicatorsRequest, ListThreatSignalsIndicatorsResponse, ListThreatSignalsIndicatorsError, CloudflareOpContext>;
export type ListThreatSignalsSkillsError = CloudflareOpError;
/** Lists active Managed Default Skills and Custom Skills. Free Threat Signals accounts see active managed defaults only, with custom_skills_available: false. */
export declare const listThreatSignalsSkills: API.OperationMethod<ListThreatSignalsSkillsRequest, ListThreatSignalsSkillsResponse, ListThreatSignalsSkillsError, CloudflareOpContext>;
export type PatchScanConfigError = ScanConfigNotFound | CloudflareOpError;
/** Updates an existing scan configuration in Cloudforce One's network scanning service. */
export declare const patchScanConfig: API.OperationMethod<PatchScanConfigRequest, PatchScanConfigResponse, PatchScanConfigError, CloudflareOpContext>;
export type PatchThreatEventError = CloudflareOpError;
/** Partially updates a threat event in Cloudforce One, modifying specific fields without replacing the entire event. */
export declare const patchThreatEvent: API.OperationMethod<PatchThreatEventRequest, PatchThreatEventResponse, PatchThreatEventError, CloudflareOpContext>;
export type PatchThreatEventCategoryError = CloudflareOpError;
/** Deprecated; use PATCH /events/event-categories/by-id/{category_id}. Available through 2026-11-28. */
export declare const patchThreatEventCategory: API.OperationMethod<PatchThreatEventCategoryRequest, PatchThreatEventCategoryResponse, PatchThreatEventCategoryError, CloudflareOpContext>;
export type PatchThreatEventDatasetError = CloudflareOpError;
/** Partially updates a threat event dataset in Cloudforce One, modifying specific fields without replacing the entire dataset configuration. */
export declare const patchThreatEventDataset: API.OperationMethod<PatchThreatEventDatasetRequest, PatchThreatEventDatasetResponse, PatchThreatEventDatasetError, CloudflareOpContext>;
export type PatchThreatEventRawError = CloudflareOpError;
/** Partially updates raw threat event data in Cloudforce One, modifying specific fields of the event. */
export declare const patchThreatEventRaw: API.OperationMethod<PatchThreatEventRawRequest, PatchThreatEventRawResponse, PatchThreatEventRawError, CloudflareOpContext>;
export type PollThreatSignalsFeedError = CloudflareOpError;
/** Starts an immediate poll of one or all Threat Signals feeds. */
export declare const pollThreatSignalsFeed: API.OperationMethod<PollThreatSignalsFeedRequest, PollThreatSignalsFeedResponse, PollThreatSignalsFeedError, CloudflareOpContext>;
export type QuotaRequestPriorityError = CloudflareOpError;
/** Retrieves quota usage for Cloudforce One priority requests. */
export declare const quotaRequestPriority: API.OperationMethod<QuotaRequestPriorityRequest, QuotaRequestPriorityResponse, QuotaRequestPriorityError, CloudflareOpContext>;
export type RawThreatEventDatasetError = CloudflareOpError;
/** Deprecated; use GET /events/datasets/{dataset_id}/events/{event_id}/raw. Available through 2026-11-28. */
export declare const rawThreatEventDataset: API.OperationMethod<RawThreatEventDatasetRequest, RawThreatEventDatasetResponse, RawThreatEventDatasetError, CloudflareOpContext>;
export type RequestsConstantsError = CloudflareOpError;
/** Retrieves constant values used in Cloudforce One requests, including valid statuses and types. */
export declare const requestsConstants: API.OperationMethod<RequestsConstantsRequest, RequestsConstantsResponse, RequestsConstantsError, CloudflareOpContext>;
export type RequestsQuotaError = CloudflareOpError;
/** Retrieves quota usage for Cloudforce One standard requests. */
export declare const requestsQuota: API.OperationMethod<RequestsQuotaRequest, RequestsQuotaResponse, RequestsQuotaError, CloudflareOpContext>;
export type RequestsTypesError = CloudflareOpError;
/** Lists available request types for Cloudforce One intelligence requests. */
export declare const requestsTypes: API.OperationMethod<RequestsTypesRequest, RequestsTypesResponse, RequestsTypesError, CloudflareOpContext>;
export type SearchThreatSignalError = CloudflareOpError;
/** Searches the account's Threat Signals articles using keyword and semantic retrieval. */
export declare const searchThreatSignal: API.OperationMethod<SearchThreatSignalRequest, SearchThreatSignalResponse, SearchThreatSignalError, CloudflareOpContext>;
export type ThreatEventsBulkCreateRelationshipsError = CloudflareOpError;
/** This method is deprecated. Please use `event_create_bulk` instead */
export declare const threatEventsBulkCreateRelationships: API.OperationMethod<ThreatEventsBulkCreateRelationshipsRequest, ThreatEventsBulkCreateRelationshipsResponse, ThreatEventsBulkCreateRelationshipsError, CloudflareOpContext>;
export type ThreatSignalsArticlesBulkEditError = CloudflareOpError;
/** Marks up to 50 Threat Signals articles as read or unread. */
export declare const threatSignalsArticlesBulkEdit: API.OperationMethod<ThreatSignalsArticlesBulkEditRequest, ThreatSignalsArticlesBulkEditResponse, ThreatSignalsArticlesBulkEditError, CloudflareOpContext>;
export type ThreatSignalsHealthError = CloudflareOpError;
/** Checks that the Threat Signals API is reachable. */
export declare const threatSignalsHealth: API.OperationMethod<ThreatSignalsHealthRequest, ThreatSignalsHealthResponse, ThreatSignalsHealthError, CloudflareOpContext>;
export type ThreatSignalsSearchSearchError = CloudflareOpError;
/** Searches the account's Threat Signals articles using keyword and semantic retrieval. */
export declare const threatSignalsSearchSearch: API.OperationMethod<ThreatSignalsSearchSearchRequest, ThreatSignalsSearchSearchResponse, ThreatSignalsSearchSearchError, CloudflareOpContext>;
export type UpdateRequestError = CloudflareOpError;
/** Updating a request alters the request in the Cloudforce One queue. This API may be used to update any attributes of the request after the initial submission. Only fields that you choose to update need to be add to the request body. */
export declare const updateRequest: API.OperationMethod<UpdateRequestRequest, UpdateRequestResponse, UpdateRequestError, CloudflareOpContext>;
export type UpdateRequestAssetError = CloudflareOpError;
/** Updates an asset in a Cloudforce One intelligence request. */
export declare const updateRequestAsset: API.OperationMethod<UpdateRequestAssetRequest, UpdateRequestAssetResponse, UpdateRequestAssetError, CloudflareOpContext>;
export type UpdateRequestMessageError = CloudflareOpError;
/** Updates a message in a Cloudforce One intelligence request thread. */
export declare const updateRequestMessage: API.OperationMethod<UpdateRequestMessageRequest, UpdateRequestMessageResponse, UpdateRequestMessageError, CloudflareOpContext>;
export type UpdateRequestPriorityError = CloudflareOpError;
/** Updates a priority intelligence request in Cloudforce One. */
export declare const updateRequestPriority: API.OperationMethod<UpdateRequestPriorityRequest, UpdateRequestPriorityResponse, UpdateRequestPriorityError, CloudflareOpContext>;
export type UpdateThreatSignalsFeedsSkillError = CloudflareOpError;
/** Replaces the ordered custom skills assigned to a Threat Signals feed. Requires a paid Threat Signals subscription. */
export declare const updateThreatSignalsFeedsSkill: API.OperationMethod<UpdateThreatSignalsFeedsSkillRequest, UpdateThreatSignalsFeedsSkillResponse, UpdateThreatSignalsFeedsSkillError, CloudflareOpContext>;
export type UpdateThreatSignalsSkillsTagCategoryError = CloudflareOpError;
/** Replaces the Tag Categories the managed default tagging skill may select tags from. This configures the managed default tagging skill, not Custom Skills. */
export declare const updateThreatSignalsSkillsTagCategory: API.OperationMethod<UpdateThreatSignalsSkillsTagCategoryRequest, UpdateThreatSignalsSkillsTagCategoryResponse, UpdateThreatSignalsSkillsTagCategoryError, CloudflareOpContext>;
//# sourceMappingURL=cloudforce_one.d.ts.map