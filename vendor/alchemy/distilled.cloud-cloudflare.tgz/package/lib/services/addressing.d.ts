import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AddressMapNotFound_base: S.TaggedErrorClass<"AddressMapNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class AddressMapNotFound extends /*@__PURE__*/ AddressMapNotFound_base {
}
declare const BgpPrefixNotFound_base: S.TaggedErrorClass<"BgpPrefixNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class BgpPrefixNotFound extends /*@__PURE__*/ BgpPrefixNotFound_base {
}
declare const BindingNotFound_base: S.TaggedErrorClass<"BindingNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class BindingNotFound extends /*@__PURE__*/ BindingNotFound_base {
}
declare const DelegationNotFound_base: S.TaggedErrorClass<"DelegationNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DelegationNotFound extends /*@__PURE__*/ DelegationNotFound_base {
}
declare const FeatureNotEnabled_base: S.TaggedErrorClass<"FeatureNotEnabled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class FeatureNotEnabled extends /*@__PURE__*/ FeatureNotEnabled_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidAccountId_base: S.TaggedErrorClass<"InvalidAccountId", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidAccountId extends /*@__PURE__*/ InvalidAccountId_base {
}
declare const InvalidHostname_base: S.TaggedErrorClass<"InvalidHostname", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidHostname extends /*@__PURE__*/ InvalidHostname_base {
}
declare const InvalidLoaForm_base: S.TaggedErrorClass<"InvalidLoaForm", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidLoaForm extends /*@__PURE__*/ InvalidLoaForm_base {
}
declare const InvalidNetworkCidr_base: S.TaggedErrorClass<"InvalidNetworkCidr", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidNetworkCidr extends /*@__PURE__*/ InvalidNetworkCidr_base {
}
declare const InvalidZoneId_base: S.TaggedErrorClass<"InvalidZoneId", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidZoneId extends /*@__PURE__*/ InvalidZoneId_base {
}
declare const IrrEntryNotFound_base: S.TaggedErrorClass<"IrrEntryNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class IrrEntryNotFound extends /*@__PURE__*/ IrrEntryNotFound_base {
}
declare const LoaDocumentNotFound_base: S.TaggedErrorClass<"LoaDocumentNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class LoaDocumentNotFound extends /*@__PURE__*/ LoaDocumentNotFound_base {
}
declare const MethodNotAllowed_base: S.TaggedErrorClass<"MethodNotAllowed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MethodNotAllowed extends /*@__PURE__*/ MethodNotAllowed_base {
}
declare const MissingAccountId_base: S.TaggedErrorClass<"MissingAccountId", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MissingAccountId extends /*@__PURE__*/ MissingAccountId_base {
}
declare const NonexistentAccountPrefix_base: S.TaggedErrorClass<"NonexistentAccountPrefix", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NonexistentAccountPrefix extends /*@__PURE__*/ NonexistentAccountPrefix_base {
}
declare const PrefixNotFound_base: S.TaggedErrorClass<"PrefixNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PrefixNotFound extends /*@__PURE__*/ PrefixNotFound_base {
}
declare const RegionalHostnameEmpty_base: S.TaggedErrorClass<"RegionalHostnameEmpty", {
    readonly code: any;
    readonly message: any;
}>;
export declare class RegionalHostnameEmpty extends /*@__PURE__*/ RegionalHostnameEmpty_base {
}
declare const RegionalHostnameNotFound_base: S.TaggedErrorClass<"RegionalHostnameNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class RegionalHostnameNotFound extends /*@__PURE__*/ RegionalHostnameNotFound_base {
}
declare const UnsupportedBindingConfiguration_base: S.TaggedErrorClass<"UnsupportedBindingConfiguration", {
    readonly code: any;
    readonly message: any;
}>;
export declare class UnsupportedBindingConfiguration extends /*@__PURE__*/ UnsupportedBindingConfiguration_base {
}
export type AddressMapsCreateRequestIpsList = Array<string>;
export type AddressMapsCreateRequestMembershipsItemKind = "zone" | "account";
export interface AddressMapsCreateRequestMembershipsItem {
    /** The identifier for the membership (eg. a zone or account tag). */
    identifier?: string;
    /** The type of the membership. */
    kind?: AddressMapsCreateRequestMembershipsItemKind | (string & {});
}
export type AddressMapsCreateRequestMembershipsList = Array<AddressMapsCreateRequestMembershipsItem>;
export interface CreateAddressMapRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** An optional description field which may be used to describe the types of IPs or zones on the map. */
    description?: string;
    /** Whether the Address Map is enabled or not. Cloudflare's DNS will not respond with IP addresses on an Address Map until the map is enabled. */
    enabled?: boolean;
    ips?: AddressMapsCreateRequestIpsList;
    /** Zones and Accounts which will be assigned IPs on this Address Map. A zone membership will take priority over an account membership. */
    memberships?: AddressMapsCreateRequestMembershipsList;
}
export interface AddressMapsCreateResponseIps {
    createdAt?: string | null;
    /** An IPv4 or IPv6 address. */
    ip?: string | null;
}
export type AddressMapsCreateResponseIpsList = Array<AddressMapsCreateResponseIps>;
export type AddressMapsCreateResponseMembershipsItemKind = "zone" | "account";
export interface AddressMapsCreateResponseMembershipsItem {
    /** Controls whether the membership can be deleted via the API or not. */
    canDelete?: boolean | null;
    createdAt?: string | null;
    /** The identifier for the membership (eg. a zone or account tag). */
    identifier?: string | null;
    /** The type of the membership. */
    kind?: AddressMapsCreateResponseMembershipsItemKind | null;
}
export type AddressMapsCreateResponseMembershipsList = Array<AddressMapsCreateResponseMembershipsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAddressMapResponse {
    /** Identifier of an Address Map. */
    id?: string | null;
    /** If set to false, then the Address Map cannot be deleted via API. This is true for Cloudflare-managed maps. */
    canDelete?: boolean | null;
    /** If set to false, then the IPs on the Address Map cannot be modified via the API. This is true for Cloudflare-managed maps. */
    canModifyIps?: boolean | null;
    createdAt?: string | null;
    /** If you have legacy TLS clients which do not send the TLS server name indicator, then you can specify one default SNI on the map. If Cloudflare receives a TLS handshake from a client without an SNI, it will respond with the default SNI on those IPs. The default SNI can be any valid zone or subdomain owned by the account. */
    defaultSni?: string | null;
    /** An optional description field which may be used to describe the types of IPs or zones on the map. */
    description?: string | null;
    /** Whether the Address Map is enabled or not. Cloudflare's DNS will not respond with IP addresses on an Address Map until the map is enabled. */
    enabled?: boolean | null;
    /** The set of IPs on the Address Map. */
    ips?: AddressMapsCreateResponseIpsList | null;
    /** Zones and Accounts which will be assigned IPs on this Address Map. A zone membership will take priority over an account membership. */
    memberships?: AddressMapsCreateResponseMembershipsList | null;
    modifiedAt?: string | null;
}
export interface CreateLoaDocumentRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** LOA document to upload. */
    loaDocument: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLoaDocumentResponse {
    /** Identifier for the uploaded LOA document. */
    id?: string | null;
    /** Identifier of a Cloudflare account. */
    accountId?: string | null;
    /** Whether the LOA has been auto-generated for the prefix owner by Cloudflare. */
    autoGenerated?: boolean | null;
    created?: string | null;
    /** Name of LOA document. Max file size 10MB, and supported filetype is pdf. */
    filename?: string | null;
    /** File size of the uploaded LOA document. */
    sizeBytes?: number | null;
    /** Whether the LOA has been verified by Cloudflare staff. */
    verified?: boolean | null;
    /** Timestamp of the moment the LOA was marked as validated. */
    verifiedAt?: string | null;
}
export interface CreatePrefixRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Autonomous System Number (ASN) the prefix will be advertised under. */
    asn: number;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr: string;
    /** Whether Cloudflare is allowed to generate the LOA document on behalf of the prefix owner. */
    delegateLoaCreation?: boolean;
    /** Description of the prefix. */
    description?: string;
    /** Identifier for the uploaded LOA document. */
    loaDocumentId?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePrefixResponse {
    /** Identifier of an IP Prefix. */
    id?: string | null;
    /** Identifier of a Cloudflare account. */
    accountId?: string | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    advertised?: boolean | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    advertisedModifiedAt?: string | null;
    /** Approval state of the prefix (P = pending, V = active). */
    approved?: string | null;
    /** Autonomous System Number (ASN) the prefix will be advertised under. */
    asn?: number | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    createdAt?: string | null;
    /** Whether Cloudflare is allowed to generate the LOA document on behalf of the prefix owner. */
    delegateLoaCreation?: boolean | null;
    /** Description of the prefix. */
    description?: string | null;
    /** State of one kind of validation for an IP prefix. */
    irrValidationState?: string | null;
    /** Identifier for the uploaded LOA document. */
    loaDocumentId?: string | null;
    modifiedAt?: string | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    onDemandEnabled?: boolean | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    onDemandLocked?: boolean | null;
    /** State of one kind of validation for an IP prefix. */
    ownershipValidationState?: string | null;
    /** Token provided to demonstrate ownership of the prefix. */
    ownershipValidationToken?: string | null;
    /** State of one kind of validation for an IP prefix. */
    rpkiValidationState?: string | null;
}
export interface CreatePrefixBgpPrefixRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr: string;
}
export interface PrefixesBgpPrefixesCreateResponseBgpSignalOpts {
    /** Whether control of advertisement of the prefix to the Internet is enabled to be performed via BGP signal */
    enabled?: boolean | null;
    /** Last time BGP signaling control was toggled. This field is null if BGP signaling has never been enabled. */
    modifiedAt?: string | null;
}
export interface PrefixesBgpPrefixesCreateResponseOnDemand {
    /** Prefix advertisement status to the Internet. This field is only not 'null' if on demand is enabled. */
    advertised?: boolean | null;
    /** Last time the advertisement status was changed. This field is only not 'null' if on demand is enabled. */
    advertisedModifiedAt?: string | null;
    /** Whether advertisement of the prefix to the Internet may be dynamically enabled or disabled. */
    onDemandEnabled?: boolean | null;
    /** Whether the advertisement status of the prefix is locked, meaning it cannot be changed. */
    onDemandLocked?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePrefixBgpPrefixResponse {
    /** Identifier of BGP Prefix. */
    id?: string | null;
    /** Autonomous System Number (ASN) the prefix will be advertised under. */
    asn?: number | null;
    /** Number of times to prepend the Cloudflare ASN to the BGP AS-Path attribute */
    asnPrependCount?: number | null;
    /** Determines if Cloudflare advertises a BYOIP BGP prefix even when there is no matching BGP prefix in the Magic routing table. When true, Cloudflare will automatically withdraw the BGP prefix when there are no matching BGP routes, and will resume advertising when there is at least one matching BGP route. */
    autoAdvertiseWithdraw?: boolean | null;
    bgpSignalOpts?: PrefixesBgpPrefixesCreateResponseBgpSignalOpts | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    createdAt?: string | null;
    modifiedAt?: string | null;
    onDemand?: PrefixesBgpPrefixesCreateResponseOnDemand | null;
}
export interface CreatePrefixDelegationRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr: string;
    /** Account identifier for the account to which prefix is being delegated. */
    delegatedAccountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePrefixDelegationResponse {
    /** Identifier of a Delegation. */
    id?: string | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    createdAt?: string | null;
    /** Account identifier for the account to which prefix is being delegated. */
    delegatedAccountId?: string | null;
    modifiedAt?: string | null;
    /** Identifier of an IP Prefix. */
    parentPrefixId?: string | null;
}
export interface CreatePrefixServiceBindingRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr: string;
    /** Identifier of a Service on the Cloudflare network. Available services and their IDs may be found in the **List Services** endpoint. */
    serviceId: string;
}
export type PrefixesServiceBindingsCreateResponseProvisioningState = "provisioning" | "active" | "magic_transit_route_missing";
export interface PrefixesServiceBindingsCreateResponseProvisioning {
    /** When a binding has been deployed to a majority of Cloudflare datacenters, the binding will become active and can be used with its associated service. */
    state?: PrefixesServiceBindingsCreateResponseProvisioningState | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePrefixServiceBindingResponse {
    /** Identifier of a Service Binding. */
    id?: string | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    /** Status of a Service Binding's deployment to the Cloudflare network */
    provisioning?: PrefixesServiceBindingsCreateResponseProvisioning | null;
    /** Identifier of a Service on the Cloudflare network. Available services and their IDs may be found in the **List Services** endpoint. */
    serviceId?: string | null;
    /** Name of a service running on the Cloudflare network */
    serviceName?: string | null;
}
export interface CreateRegionalHostnameRequest {
    /** Identifier. */
    zoneId: string;
    /** DNS hostname to be regionalized, must be a subdomain of the zone. Wildcards are supported for one level, e.g `*.example.com` */
    hostname: string;
    /** Identifying key for the region */
    regionKey: string;
    /** Configure which routing method to use for the regional hostname */
    routing?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRegionalHostnameResponse {
    /** When the regional hostname was created */
    createdOn: string;
    /** DNS hostname to be regionalized, must be a subdomain of the zone. Wildcards are supported for one level, e.g `*.example.com` */
    hostname: string;
    /** Identifying key for the region */
    regionKey: string;
    /** Configure which routing method to use for the regional hostname */
    routing: string;
}
export interface DeleteAddressMapRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an Address Map. */
    addressMapId: string;
}
export interface DeleteAddressMapResponse {
}
export interface DeleteAddressMapAccountRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an Address Map. */
    addressMapId: string;
    /** Identifier of a Cloudflare account. */
    memberAccountId: string;
}
export interface DeleteAddressMapAccountResponse {
}
export interface DeleteAddressMapIpRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an Address Map. */
    addressMapId: string;
    /** An IPv4 or IPv6 address. */
    ipAddress: string;
}
export interface DeleteAddressMapIpResponse {
}
export interface DeleteAddressMapZoneRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an Address Map. */
    addressMapId: string;
    /** Identifier of a zone. */
    zoneId: string;
}
export interface DeleteAddressMapZoneResponse {
}
export interface DeletePrefixRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
}
export interface DeletePrefixResponse {
}
export interface DeletePrefixDelegationRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
    /** Identifier of a Delegation. */
    delegationId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeletePrefixDelegationResponse {
    /** Identifier of a Delegation. */
    id?: string | null;
}
export interface DeletePrefixesBgpPrefixRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
    /** Identifier of BGP Prefix. */
    bgpPrefixId: string;
}
export interface DeletePrefixesBgpPrefixResponse {
}
export interface DeletePrefixServiceBindingRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
    /** Identifier of a Service Binding. */
    bindingId: string;
}
export interface DeletePrefixServiceBindingResponse {
}
export interface DeleteRegionalHostnameRequest {
    /** Identifier. */
    zoneId: string;
    /** DNS hostname to be regionalized, must be a subdomain of the zone. Wildcards are supported for one level, e.g `*.example.com` */
    hostname: string;
}
export interface DeleteRegionalHostnameResponse {
}
export interface GetAddressMapRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an Address Map. */
    addressMapId: string;
}
export type AddressMapsGetResponseIps = AddressMapsCreateResponseIps;
export type AddressMapsGetResponseIpsList = Array<AddressMapsCreateResponseIps>;
export type AddressMapsGetResponseMembershipsItemKind = "zone" | "account";
export interface AddressMapsGetResponseMembershipsItem {
    /** Controls whether the membership can be deleted via the API or not. */
    canDelete?: boolean | null;
    createdAt?: string | null;
    /** The identifier for the membership (eg. a zone or account tag). */
    identifier?: string | null;
    /** The type of the membership. */
    kind?: AddressMapsGetResponseMembershipsItemKind | null;
}
export type AddressMapsGetResponseMembershipsList = Array<AddressMapsGetResponseMembershipsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAddressMapResponse {
    /** Identifier of an Address Map. */
    id?: string | null;
    /** If set to false, then the Address Map cannot be deleted via API. This is true for Cloudflare-managed maps. */
    canDelete?: boolean | null;
    /** If set to false, then the IPs on the Address Map cannot be modified via the API. This is true for Cloudflare-managed maps. */
    canModifyIps?: boolean | null;
    createdAt?: string | null;
    /** If you have legacy TLS clients which do not send the TLS server name indicator, then you can specify one default SNI on the map. If Cloudflare receives a TLS handshake from a client without an SNI, it will respond with the default SNI on those IPs. The default SNI can be any valid zone or subdomain owned by the account. */
    defaultSni?: string | null;
    /** An optional description field which may be used to describe the types of IPs or zones on the map. */
    description?: string | null;
    /** Whether the Address Map is enabled or not. Cloudflare's DNS will not respond with IP addresses on an Address Map until the map is enabled. */
    enabled?: boolean | null;
    /** The set of IPs on the Address Map. */
    ips?: AddressMapsGetResponseIpsList | null;
    /** Zones and Accounts which will be assigned IPs on this Address Map. A zone membership will take priority over an account membership. */
    memberships?: AddressMapsGetResponseMembershipsList | null;
    modifiedAt?: string | null;
}
export interface GetLoaDocumentRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier for the uploaded LOA document. */
    loaDocumentId: string;
}
export interface GetLoaDocumentResponse {
}
export interface GetPrefixRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPrefixResponse {
    /** Identifier of an IP Prefix. */
    id?: string | null;
    /** Identifier of a Cloudflare account. */
    accountId?: string | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    advertised?: boolean | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    advertisedModifiedAt?: string | null;
    /** Approval state of the prefix (P = pending, V = active). */
    approved?: string | null;
    /** Autonomous System Number (ASN) the prefix will be advertised under. */
    asn?: number | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    createdAt?: string | null;
    /** Whether Cloudflare is allowed to generate the LOA document on behalf of the prefix owner. */
    delegateLoaCreation?: boolean | null;
    /** Description of the prefix. */
    description?: string | null;
    /** State of one kind of validation for an IP prefix. */
    irrValidationState?: string | null;
    /** Identifier for the uploaded LOA document. */
    loaDocumentId?: string | null;
    modifiedAt?: string | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    onDemandEnabled?: boolean | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    onDemandLocked?: boolean | null;
    /** State of one kind of validation for an IP prefix. */
    ownershipValidationState?: string | null;
    /** Token provided to demonstrate ownership of the prefix. */
    ownershipValidationToken?: string | null;
    /** State of one kind of validation for an IP prefix. */
    rpkiValidationState?: string | null;
}
export interface GetPrefixAdvertisementStatusRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPrefixAdvertisementStatusResponse {
    /** Advertisement status of the prefix. If `true`, the BGP route for the prefix is advertised to the Internet. If `false`, the BGP route is withdrawn. */
    advertised?: boolean | null;
    /** Last time the advertisement status was changed. This field is only not 'null' if on demand is enabled. */
    advertisedModifiedAt?: string | null;
}
export interface GetPrefixBgpPrefixRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
    /** Identifier of BGP Prefix. */
    bgpPrefixId: string;
}
export type PrefixesBgpPrefixesGetResponseBgpSignalOpts = PrefixesBgpPrefixesCreateResponseBgpSignalOpts;
export type PrefixesBgpPrefixesGetResponseOnDemand = PrefixesBgpPrefixesCreateResponseOnDemand;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPrefixBgpPrefixResponse {
    /** Identifier of BGP Prefix. */
    id?: string | null;
    /** Autonomous System Number (ASN) the prefix will be advertised under. */
    asn?: number | null;
    /** Number of times to prepend the Cloudflare ASN to the BGP AS-Path attribute */
    asnPrependCount?: number | null;
    /** Determines if Cloudflare advertises a BYOIP BGP prefix even when there is no matching BGP prefix in the Magic routing table. When true, Cloudflare will automatically withdraw the BGP prefix when there are no matching BGP routes, and will resume advertising when there is at least one matching BGP route. */
    autoAdvertiseWithdraw?: boolean | null;
    bgpSignalOpts?: PrefixesBgpPrefixesCreateResponseBgpSignalOpts | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    createdAt?: string | null;
    modifiedAt?: string | null;
    onDemand?: PrefixesBgpPrefixesCreateResponseOnDemand | null;
}
export interface GetPrefixServiceBindingRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
    /** Identifier of a Service Binding. */
    bindingId: string;
}
export type PrefixesServiceBindingsGetResponseProvisioningState = "provisioning" | "active" | "magic_transit_route_missing";
export interface PrefixesServiceBindingsGetResponseProvisioning {
    /** When a binding has been deployed to a majority of Cloudflare datacenters, the binding will become active and can be used with its associated service. */
    state?: PrefixesServiceBindingsGetResponseProvisioningState | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPrefixServiceBindingResponse {
    /** Identifier of a Service Binding. */
    id?: string | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    /** Status of a Service Binding's deployment to the Cloudflare network */
    provisioning?: PrefixesServiceBindingsGetResponseProvisioning | null;
    /** Identifier of a Service on the Cloudflare network. Available services and their IDs may be found in the **List Services** endpoint. */
    serviceId?: string | null;
    /** Name of a service running on the Cloudflare network */
    serviceName?: string | null;
}
export interface GetRegionalHostnameRequest {
    /** Identifier. */
    zoneId: string;
    /** DNS hostname to be regionalized, must be a subdomain of the zone. Wildcards are supported for one level, e.g `*.example.com` */
    hostname: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRegionalHostnameResponse {
    /** When the regional hostname was created */
    createdOn: string;
    /** DNS hostname to be regionalized, must be a subdomain of the zone. Wildcards are supported for one level, e.g `*.example.com` */
    hostname: string;
    /** Identifying key for the region */
    regionKey: string;
    /** Configure which routing method to use for the regional hostname */
    routing: string;
}
export interface ListAddressMapsRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
}
export interface AddressMapsListResultItem {
    /** Identifier of an Address Map. */
    id?: string | null;
    /** If set to false, then the Address Map cannot be deleted via API. This is true for Cloudflare-managed maps. */
    canDelete?: boolean | null;
    /** If set to false, then the IPs on the Address Map cannot be modified via the API. This is true for Cloudflare-managed maps. */
    canModifyIps?: boolean | null;
    createdAt?: string | null;
    /** If you have legacy TLS clients which do not send the TLS server name indicator, then you can specify one default SNI on the map. If Cloudflare receives a TLS handshake from a client without an SNI, it will respond with the default SNI on those IPs. The default SNI can be any valid zone or subdomain owned by the account. */
    defaultSni?: string | null;
    /** An optional description field which may be used to describe the types of IPs or zones on the map. */
    description?: string | null;
    /** Whether the Address Map is enabled or not. Cloudflare's DNS will not respond with IP addresses on an Address Map until the map is enabled. */
    enabled?: boolean | null;
    modifiedAt?: string | null;
}
export type AddressMapsListResultList = Array<AddressMapsListResultItem>;
export interface ListAddressMapsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AddressMapsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListPrefixBgpPrefixesRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
}
export type PrefixesBgpPrefixesListResultItemBgpSignalOpts = PrefixesBgpPrefixesCreateResponseBgpSignalOpts;
export type PrefixesBgpPrefixesListResultItemOnDemand = PrefixesBgpPrefixesCreateResponseOnDemand;
export interface PrefixesBgpPrefixesListResultItem {
    /** Identifier of BGP Prefix. */
    id?: string | null;
    /** Autonomous System Number (ASN) the prefix will be advertised under. */
    asn?: number | null;
    /** Number of times to prepend the Cloudflare ASN to the BGP AS-Path attribute */
    asnPrependCount?: number | null;
    /** Determines if Cloudflare advertises a BYOIP BGP prefix even when there is no matching BGP prefix in the Magic routing table. When true, Cloudflare will automatically withdraw the BGP prefix when there are no matching BGP routes, and will resume advertising when there is at least one matching BGP route. */
    autoAdvertiseWithdraw?: boolean | null;
    bgpSignalOpts?: PrefixesBgpPrefixesCreateResponseBgpSignalOpts | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    createdAt?: string | null;
    modifiedAt?: string | null;
    onDemand?: PrefixesBgpPrefixesCreateResponseOnDemand | null;
}
export type PrefixesBgpPrefixesListResultList = Array<PrefixesBgpPrefixesListResultItem>;
export interface ListPrefixBgpPrefixesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PrefixesBgpPrefixesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListPrefixDelegationsRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
}
export interface PrefixesDelegationsListResultItem {
    /** Identifier of a Delegation. */
    id?: string | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    createdAt?: string | null;
    /** Account identifier for the account to which prefix is being delegated. */
    delegatedAccountId?: string | null;
    modifiedAt?: string | null;
    /** Identifier of an IP Prefix. */
    parentPrefixId?: string | null;
}
export type PrefixesDelegationsListResultList = Array<PrefixesDelegationsListResultItem>;
export interface ListPrefixDelegationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PrefixesDelegationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListPrefixesRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
}
export interface PrefixesListResultItem {
    /** Identifier of an IP Prefix. */
    id?: string | null;
    /** Identifier of a Cloudflare account. */
    accountId?: string | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    advertised?: boolean | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    advertisedModifiedAt?: string | null;
    /** Approval state of the prefix (P = pending, V = active). */
    approved?: string | null;
    /** Autonomous System Number (ASN) the prefix will be advertised under. */
    asn?: number | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    createdAt?: string | null;
    /** Whether Cloudflare is allowed to generate the LOA document on behalf of the prefix owner. */
    delegateLoaCreation?: boolean | null;
    /** Description of the prefix. */
    description?: string | null;
    /** State of one kind of validation for an IP prefix. */
    irrValidationState?: string | null;
    /** Identifier for the uploaded LOA document. */
    loaDocumentId?: string | null;
    modifiedAt?: string | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    onDemandEnabled?: boolean | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    onDemandLocked?: boolean | null;
    /** State of one kind of validation for an IP prefix. */
    ownershipValidationState?: string | null;
    /** Token provided to demonstrate ownership of the prefix. */
    ownershipValidationToken?: string | null;
    /** State of one kind of validation for an IP prefix. */
    rpkiValidationState?: string | null;
}
export type PrefixesListResultList = Array<PrefixesListResultItem>;
export interface ListPrefixesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PrefixesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListPrefixServiceBindingsRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
}
export type PrefixesServiceBindingsListResultItemProvisioningState = "provisioning" | "active" | "magic_transit_route_missing";
export interface PrefixesServiceBindingsListResultItemProvisioning {
    /** When a binding has been deployed to a majority of Cloudflare datacenters, the binding will become active and can be used with its associated service. */
    state?: PrefixesServiceBindingsListResultItemProvisioningState | null;
}
export interface PrefixesServiceBindingsListResultItem {
    /** Identifier of a Service Binding. */
    id?: string | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    /** Status of a Service Binding's deployment to the Cloudflare network */
    provisioning?: PrefixesServiceBindingsListResultItemProvisioning | null;
    /** Identifier of a Service on the Cloudflare network. Available services and their IDs may be found in the **List Services** endpoint. */
    serviceId?: string | null;
    /** Name of a service running on the Cloudflare network */
    serviceName?: string | null;
}
export type PrefixesServiceBindingsListResultList = Array<PrefixesServiceBindingsListResultItem>;
export interface ListPrefixServiceBindingsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PrefixesServiceBindingsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListRegionalHostnameRegionsRequest {
    /** Identifier. */
    accountId: string;
}
export interface RegionalHostnamesRegionsListResultItem {
    /** Identifying key for the region */
    key?: string | null;
    /** Human-readable text label for the region */
    label?: string | null;
}
export type RegionalHostnamesRegionsListResultList = Array<RegionalHostnamesRegionsListResultItem>;
export interface ListRegionalHostnameRegionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RegionalHostnamesRegionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListRegionalHostnamesRequest {
    /** Identifier. */
    zoneId: string;
}
export interface RegionalHostnamesListResultItem {
    /** When the regional hostname was created */
    createdOn: string;
    /** DNS hostname to be regionalized, must be a subdomain of the zone. Wildcards are supported for one level, e.g `*.example.com` */
    hostname: string;
    /** Identifying key for the region */
    regionKey: string;
    /** Configure which routing method to use for the regional hostname */
    routing: string;
}
export type RegionalHostnamesListResultList = Array<RegionalHostnamesListResultItem>;
export interface ListRegionalHostnamesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RegionalHostnamesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListServicesRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
}
export interface ServicesListResultItem {
    /** Identifier of a Service on the Cloudflare network. Available services and their IDs may be found in the **List Services** endpoint. */
    id?: string | null;
    /** Name of a service running on the Cloudflare network */
    name?: string | null;
}
export type ServicesListResultList = Array<ServicesListResultItem>;
export interface ListServicesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ServicesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface PatchAddressMapRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an Address Map. */
    addressMapId: string;
    /** If you have legacy TLS clients which do not send the TLS server name indicator, then you can specify one default SNI on the map. If Cloudflare receives a TLS handshake from a client without an SNI, it will respond with the default SNI on those IPs. The default SNI can be any valid zone or subdomain owned by the account. */
    defaultSni?: string;
    /** An optional description field which may be used to describe the types of IPs or zones on the map. */
    description?: string;
    /** Whether the Address Map is enabled or not. Cloudflare's DNS will not respond with IP addresses on an Address Map until the map is enabled. */
    enabled?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAddressMapResponse {
    /** Identifier of an Address Map. */
    id?: string | null;
    /** If set to false, then the Address Map cannot be deleted via API. This is true for Cloudflare-managed maps. */
    canDelete?: boolean | null;
    /** If set to false, then the IPs on the Address Map cannot be modified via the API. This is true for Cloudflare-managed maps. */
    canModifyIps?: boolean | null;
    createdAt?: string | null;
    /** If you have legacy TLS clients which do not send the TLS server name indicator, then you can specify one default SNI on the map. If Cloudflare receives a TLS handshake from a client without an SNI, it will respond with the default SNI on those IPs. The default SNI can be any valid zone or subdomain owned by the account. */
    defaultSni?: string | null;
    /** An optional description field which may be used to describe the types of IPs or zones on the map. */
    description?: string | null;
    /** Whether the Address Map is enabled or not. Cloudflare's DNS will not respond with IP addresses on an Address Map until the map is enabled. */
    enabled?: boolean | null;
    modifiedAt?: string | null;
}
export interface PatchPrefixRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
    /** Description of the prefix. */
    description: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchPrefixResponse {
    /** Identifier of an IP Prefix. */
    id?: string | null;
    /** Identifier of a Cloudflare account. */
    accountId?: string | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    advertised?: boolean | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    advertisedModifiedAt?: string | null;
    /** Approval state of the prefix (P = pending, V = active). */
    approved?: string | null;
    /** Autonomous System Number (ASN) the prefix will be advertised under. */
    asn?: number | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    createdAt?: string | null;
    /** Whether Cloudflare is allowed to generate the LOA document on behalf of the prefix owner. */
    delegateLoaCreation?: boolean | null;
    /** Description of the prefix. */
    description?: string | null;
    /** State of one kind of validation for an IP prefix. */
    irrValidationState?: string | null;
    /** Identifier for the uploaded LOA document. */
    loaDocumentId?: string | null;
    modifiedAt?: string | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    onDemandEnabled?: boolean | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    onDemandLocked?: boolean | null;
    /** State of one kind of validation for an IP prefix. */
    ownershipValidationState?: string | null;
    /** Token provided to demonstrate ownership of the prefix. */
    ownershipValidationToken?: string | null;
    /** State of one kind of validation for an IP prefix. */
    rpkiValidationState?: string | null;
}
export interface PatchPrefixAdvertisementStatusRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
    /** Advertisement status of the prefix. If `true`, the BGP route for the prefix is advertised to the Internet. If `false`, the BGP route is withdrawn. */
    advertised: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchPrefixAdvertisementStatusResponse {
    /** Advertisement status of the prefix. If `true`, the BGP route for the prefix is advertised to the Internet. If `false`, the BGP route is withdrawn. */
    advertised?: boolean | null;
    /** Last time the advertisement status was changed. This field is only not 'null' if on demand is enabled. */
    advertisedModifiedAt?: string | null;
}
export interface PrefixesBgpPrefixesEditRequestOnDemand {
    advertised?: boolean;
}
export interface PatchPrefixBgpPrefixRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
    /** Identifier of BGP Prefix. */
    bgpPrefixId: string;
    /** Number of times to prepend the Cloudflare ASN to the BGP AS-Path attribute */
    asnPrependCount?: number;
    /** Determines if Cloudflare advertises a BYOIP BGP prefix even when there is no matching BGP prefix in the Magic routing table. When true, Cloudflare will automatically withdraw the BGP prefix when there are no matching BGP routes, and will resume advertising when there is at least one matching BGP route. */
    autoAdvertiseWithdraw?: boolean;
    onDemand?: PrefixesBgpPrefixesEditRequestOnDemand;
}
export type PrefixesBgpPrefixesEditResponseBgpSignalOpts = PrefixesBgpPrefixesCreateResponseBgpSignalOpts;
export type PrefixesBgpPrefixesEditResponseOnDemand = PrefixesBgpPrefixesCreateResponseOnDemand;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchPrefixBgpPrefixResponse {
    /** Identifier of BGP Prefix. */
    id?: string | null;
    /** Autonomous System Number (ASN) the prefix will be advertised under. */
    asn?: number | null;
    /** Number of times to prepend the Cloudflare ASN to the BGP AS-Path attribute */
    asnPrependCount?: number | null;
    /** Determines if Cloudflare advertises a BYOIP BGP prefix even when there is no matching BGP prefix in the Magic routing table. When true, Cloudflare will automatically withdraw the BGP prefix when there are no matching BGP routes, and will resume advertising when there is at least one matching BGP route. */
    autoAdvertiseWithdraw?: boolean | null;
    bgpSignalOpts?: PrefixesBgpPrefixesCreateResponseBgpSignalOpts | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    createdAt?: string | null;
    modifiedAt?: string | null;
    onDemand?: PrefixesBgpPrefixesCreateResponseOnDemand | null;
}
export interface PatchRegionalHostnameRequest {
    /** Identifier. */
    zoneId: string;
    /** DNS hostname to be regionalized, must be a subdomain of the zone. Wildcards are supported for one level, e.g `*.example.com` */
    hostname: string;
    /** Identifying key for the region */
    regionKey: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchRegionalHostnameResponse {
    /** When the regional hostname was created */
    createdOn: string;
    /** DNS hostname to be regionalized, must be a subdomain of the zone. Wildcards are supported for one level, e.g `*.example.com` */
    hostname: string;
    /** Identifying key for the region */
    regionKey: string;
    /** Configure which routing method to use for the regional hostname */
    routing: string;
}
export interface PutAddressMapAccountRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an Address Map. */
    addressMapId: string;
    /** Identifier of a Cloudflare account. */
    memberAccountId: string;
}
export interface PutAddressMapAccountResponse {
}
export interface PutAddressMapIpRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an Address Map. */
    addressMapId: string;
    /** An IPv4 or IPv6 address. */
    ipAddress: string;
}
export interface PutAddressMapIpResponse {
}
export interface PutAddressMapZoneRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an Address Map. */
    addressMapId: string;
    /** Identifier of a zone. */
    zoneId: string;
}
export interface PutAddressMapZoneResponse {
}
export interface ValidatePrefixRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Identifier of an IP Prefix. */
    prefixId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ValidatePrefixResponse {
    /** Identifier of an IP Prefix. */
    id?: string | null;
    /** Identifier of a Cloudflare account. */
    accountId?: string | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    advertised?: boolean | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    advertisedModifiedAt?: string | null;
    /** Approval state of the prefix (P = pending, V = active). */
    approved?: string | null;
    /** Autonomous System Number (ASN) the prefix will be advertised under. */
    asn?: number | null;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    cidr?: string | null;
    createdAt?: string | null;
    /** Whether Cloudflare is allowed to generate the LOA document on behalf of the prefix owner. */
    delegateLoaCreation?: boolean | null;
    /** Description of the prefix. */
    description?: string | null;
    /** State of one kind of validation for an IP prefix. */
    irrValidationState?: string | null;
    /** Identifier for the uploaded LOA document. */
    loaDocumentId?: string | null;
    modifiedAt?: string | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    onDemandEnabled?: boolean | null;
    /** Prefer the [BGP Prefixes API](https://developers.cloudflare.com/api/resources/addressing/subresources/prefixes/subresources/bgp_prefixes/) instead, which allows for advertising multiple BGP routes within a single IP Prefix. */
    onDemandLocked?: boolean | null;
    /** State of one kind of validation for an IP prefix. */
    ownershipValidationState?: string | null;
    /** Token provided to demonstrate ownership of the prefix. */
    ownershipValidationToken?: string | null;
    /** State of one kind of validation for an IP prefix. */
    rpkiValidationState?: string | null;
}
export type CreateAddressMapError = FeatureNotEnabled | InvalidAccountId | Forbidden | CloudflareOpError;
/** Create a new address map under the account. */
export declare const createAddressMap: API.OperationMethod<CreateAddressMapRequest, CreateAddressMapResponse, CreateAddressMapError, CloudflareOpContext>;
export type CreateLoaDocumentError = InvalidAccountId | InvalidLoaForm | CloudflareOpError;
/** Submit LOA document (pdf format) under the account. */
export declare const createLoaDocument: API.OperationMethod<CreateLoaDocumentRequest, CreateLoaDocumentResponse, CreateLoaDocumentError, CloudflareOpContext>;
export type CreatePrefixError = InvalidAccountId | InvalidNetworkCidr | IrrEntryNotFound | CloudflareOpError;
/** Add a new prefix under the account. */
export declare const createPrefix: API.OperationMethod<CreatePrefixRequest, CreatePrefixResponse, CreatePrefixError, CloudflareOpContext>;
export type CreatePrefixBgpPrefixError = NonexistentAccountPrefix | InvalidAccountId | InvalidNetworkCidr | CloudflareOpError;
/** Create a BGP prefix, controlling the BGP advertisement status of a specific subnet. When created, BGP prefixes are initially withdrawn, and can be advertised with the Update BGP Prefix API. */
export declare const createPrefixBgpPrefix: API.OperationMethod<CreatePrefixBgpPrefixRequest, CreatePrefixBgpPrefixResponse, CreatePrefixBgpPrefixError, CloudflareOpContext>;
export type CreatePrefixDelegationError = PrefixNotFound | MissingAccountId | InvalidAccountId | CloudflareOpError;
/** Create a new account delegation for a given IP prefix. */
export declare const createPrefixDelegation: API.OperationMethod<CreatePrefixDelegationRequest, CreatePrefixDelegationResponse, CreatePrefixDelegationError, CloudflareOpContext>;
export type CreatePrefixServiceBindingError = UnsupportedBindingConfiguration | InvalidAccountId | CloudflareOpError;
/** Creates a new Service Binding, routing traffic to IPs within the given CIDR to a service running on Cloudflare's network. **NOTE:** The first Service Binding created for an IP Prefix must exactly match the IP Prefix's CIDR. Subsequent Service Bindings may be created with a more-specific CIDR. Refer to the [Service Bindings Documentation](https://developers.cloudflare.com/byoip/service-bindings/) for compatibility details. */
export declare const createPrefixServiceBinding: API.OperationMethod<CreatePrefixServiceBindingRequest, CreatePrefixServiceBindingResponse, CreatePrefixServiceBindingError, CloudflareOpContext>;
export type CreateRegionalHostnameError = InvalidZoneId | InvalidHostname | RegionalHostnameEmpty | CloudflareOpError;
/** Create a new Regional Hostname entry. Cloudflare will only use data centers that are physically located within the chosen region to decrypt and service HTTPS traffic. Learn more about [Regional Services](https://developers.cloudflare.com/data-localization/regional-services/get-started/). */
export declare const createRegionalHostname: API.OperationMethod<CreateRegionalHostnameRequest, CreateRegionalHostnameResponse, CreateRegionalHostnameError, CloudflareOpContext>;
export type DeleteAddressMapError = MethodNotAllowed | FeatureNotEnabled | InvalidAccountId | AddressMapNotFound | CloudflareOpError;
/** Delete a particular address map owned by the account. An Address Map must be disabled before it can be deleted. */
export declare const deleteAddressMap: API.OperationMethod<DeleteAddressMapRequest, DeleteAddressMapResponse, DeleteAddressMapError, CloudflareOpContext>;
export type DeleteAddressMapAccountError = MethodNotAllowed | FeatureNotEnabled | InvalidAccountId | CloudflareOpError;
/** Remove an account as a member of a particular address map. */
export declare const deleteAddressMapAccount: API.OperationMethod<DeleteAddressMapAccountRequest, DeleteAddressMapAccountResponse, DeleteAddressMapAccountError, CloudflareOpContext>;
export type DeleteAddressMapIpError = MethodNotAllowed | FeatureNotEnabled | InvalidAccountId | AddressMapNotFound | CloudflareOpError;
/** Remove an IP from a particular address map. */
export declare const deleteAddressMapIp: API.OperationMethod<DeleteAddressMapIpRequest, DeleteAddressMapIpResponse, DeleteAddressMapIpError, CloudflareOpContext>;
export type DeleteAddressMapZoneError = MethodNotAllowed | FeatureNotEnabled | InvalidAccountId | CloudflareOpError;
/** Remove a zone as a member of a particular address map. */
export declare const deleteAddressMapZone: API.OperationMethod<DeleteAddressMapZoneRequest, DeleteAddressMapZoneResponse, DeleteAddressMapZoneError, CloudflareOpContext>;
export type DeletePrefixError = MethodNotAllowed | PrefixNotFound | InvalidAccountId | CloudflareOpError;
/** Delete an unapproved prefix owned by the account. */
export declare const deletePrefix: API.OperationMethod<DeletePrefixRequest, DeletePrefixResponse, DeletePrefixError, CloudflareOpContext>;
export type DeletePrefixDelegationError = DelegationNotFound | InvalidAccountId | CloudflareOpError;
/** Delete an account delegation for a given IP prefix. */
export declare const deletePrefixDelegation: API.OperationMethod<DeletePrefixDelegationRequest, DeletePrefixDelegationResponse, DeletePrefixDelegationError, CloudflareOpContext>;
export type DeletePrefixesBgpPrefixError = CloudflareOpError;
/** Delete a BGP Prefix associated with the specified IP Prefix. A BGP Prefix must be withdrawn before it can be deleted. */
export declare const deletePrefixesBgpPrefix: API.OperationMethod<DeletePrefixesBgpPrefixRequest, DeletePrefixesBgpPrefixResponse, DeletePrefixesBgpPrefixError, CloudflareOpContext>;
export type DeletePrefixServiceBindingError = BindingNotFound | InvalidAccountId | PrefixNotFound | CloudflareOpError;
/** Delete a Service Binding */
export declare const deletePrefixServiceBinding: API.OperationMethod<DeletePrefixServiceBindingRequest, DeletePrefixServiceBindingResponse, DeletePrefixServiceBindingError, CloudflareOpContext>;
export type DeleteRegionalHostnameError = MethodNotAllowed | InvalidZoneId | RegionalHostnameNotFound | RegionalHostnameEmpty | CloudflareOpError;
/** Delete the region configuration for a specific Regional Hostname. */
export declare const deleteRegionalHostname: API.OperationMethod<DeleteRegionalHostnameRequest, DeleteRegionalHostnameResponse, DeleteRegionalHostnameError, CloudflareOpContext>;
export type GetAddressMapError = AddressMapNotFound | InvalidAccountId | Forbidden | CloudflareOpError;
/** Show a particular address map owned by the account. */
export declare const getAddressMap: API.OperationMethod<GetAddressMapRequest, GetAddressMapResponse, GetAddressMapError, CloudflareOpContext>;
export type GetLoaDocumentError = LoaDocumentNotFound | InvalidAccountId | CloudflareOpError;
/** Download specified LOA document under the account. */
export declare const getLoaDocument: API.OperationMethod<GetLoaDocumentRequest, GetLoaDocumentResponse, GetLoaDocumentError, CloudflareOpContext>;
export type GetPrefixError = PrefixNotFound | InvalidAccountId | CloudflareOpError;
/** List a particular prefix owned by the account. */
export declare const getPrefix: API.OperationMethod<GetPrefixRequest, GetPrefixResponse, GetPrefixError, CloudflareOpContext>;
export type GetPrefixAdvertisementStatusError = PrefixNotFound | InvalidAccountId | CloudflareOpError;
/** View the current advertisement state for a prefix. **Deprecated:** Prefer the BGP Prefixes endpoints, which additionally allow for advertising and withdrawing subnets of an IP prefix. */
export declare const getPrefixAdvertisementStatus: API.OperationMethod<GetPrefixAdvertisementStatusRequest, GetPrefixAdvertisementStatusResponse, GetPrefixAdvertisementStatusError, CloudflareOpContext>;
export type GetPrefixBgpPrefixError = BgpPrefixNotFound | InvalidAccountId | PrefixNotFound | CloudflareOpError;
/** Retrieve a single BGP Prefix according to its identifier */
export declare const getPrefixBgpPrefix: API.OperationMethod<GetPrefixBgpPrefixRequest, GetPrefixBgpPrefixResponse, GetPrefixBgpPrefixError, CloudflareOpContext>;
export type GetPrefixServiceBindingError = BindingNotFound | InvalidAccountId | PrefixNotFound | CloudflareOpError;
/** Fetch a single Service Binding */
export declare const getPrefixServiceBinding: API.OperationMethod<GetPrefixServiceBindingRequest, GetPrefixServiceBindingResponse, GetPrefixServiceBindingError, CloudflareOpContext>;
export type GetRegionalHostnameError = InvalidZoneId | RegionalHostnameNotFound | RegionalHostnameEmpty | CloudflareOpError;
/** Fetch the configuration for a specific Regional Hostname, within a zone. */
export declare const getRegionalHostname: API.OperationMethod<GetRegionalHostnameRequest, GetRegionalHostnameResponse, GetRegionalHostnameError, CloudflareOpContext>;
export type ListAddressMapsError = CloudflareOpError;
/** List all address maps owned by the account. */
export declare const listAddressMaps: API.PaginatedOperationMethod<ListAddressMapsRequest, ListAddressMapsResponse, ListAddressMapsError, CloudflareOpContext, AddressMapsListResultItem>;
export type ListPrefixBgpPrefixesError = PrefixNotFound | InvalidAccountId | CloudflareOpError;
/** List all BGP Prefixes within the specified IP Prefix. BGP Prefixes are used to control which specific subnets are advertised to the Internet. It is possible to advertise subnets more specific than an IP Prefix by creating more specific BGP Prefixes. */
export declare const listPrefixBgpPrefixes: API.PaginatedOperationMethod<ListPrefixBgpPrefixesRequest, ListPrefixBgpPrefixesResponse, ListPrefixBgpPrefixesError, CloudflareOpContext, PrefixesBgpPrefixesListResultItem>;
export type ListPrefixDelegationsError = PrefixNotFound | InvalidAccountId | CloudflareOpError;
/** List all delegations for a given account IP prefix. */
export declare const listPrefixDelegations: API.PaginatedOperationMethod<ListPrefixDelegationsRequest, ListPrefixDelegationsResponse, ListPrefixDelegationsError, CloudflareOpContext, PrefixesDelegationsListResultItem>;
export type ListPrefixesError = CloudflareOpError;
/** List all prefixes owned by the account. */
export declare const listPrefixes: API.PaginatedOperationMethod<ListPrefixesRequest, ListPrefixesResponse, ListPrefixesError, CloudflareOpContext, PrefixesListResultItem>;
export type ListPrefixServiceBindingsError = PrefixNotFound | InvalidAccountId | CloudflareOpError;
/** List the Cloudflare services this prefix is currently bound to. Traffic sent to an address within an IP prefix will be routed to the Cloudflare service of the most-specific Service Binding matching the address. **Example:** binding `192.0.2.0/24` to Cloudflare Magic Transit and `192.0.2.1/32` to the Cloudflare CDN would route traffic for `192.0.2.1` to the CDN, and traffic for all other IPs in the prefix to Cloudflare Magic Transit. */
export declare const listPrefixServiceBindings: API.PaginatedOperationMethod<ListPrefixServiceBindingsRequest, ListPrefixServiceBindingsResponse, ListPrefixServiceBindingsError, CloudflareOpContext, PrefixesServiceBindingsListResultItem>;
export type ListRegionalHostnameRegionsError = CloudflareOpError;
/** List all Regional Services regions available for use by this account. */
export declare const listRegionalHostnameRegions: API.PaginatedOperationMethod<ListRegionalHostnameRegionsRequest, ListRegionalHostnameRegionsResponse, ListRegionalHostnameRegionsError, CloudflareOpContext, RegionalHostnamesRegionsListResultItem>;
export type ListRegionalHostnamesError = Forbidden | CloudflareOpError;
/** List all Regional Hostnames within a zone. */
export declare const listRegionalHostnames: API.PaginatedOperationMethod<ListRegionalHostnamesRequest, ListRegionalHostnamesResponse, ListRegionalHostnamesError, CloudflareOpContext, RegionalHostnamesListResultItem>;
export type ListServicesError = CloudflareOpError;
/** Bring-Your-Own IP (BYOIP) prefixes onboarded to Cloudflare must be bound to a service running on the Cloudflare network to enable a Cloudflare product on the IP addresses. This endpoint can be used as a reference of available services on the Cloudflare network, and their service IDs. */
export declare const listServices: API.PaginatedOperationMethod<ListServicesRequest, ListServicesResponse, ListServicesError, CloudflareOpContext, ServicesListResultItem>;
export type PatchAddressMapError = MethodNotAllowed | FeatureNotEnabled | InvalidAccountId | CloudflareOpError;
/** Modify properties of an address map owned by the account. */
export declare const patchAddressMap: API.OperationMethod<PatchAddressMapRequest, PatchAddressMapResponse, PatchAddressMapError, CloudflareOpContext>;
export type PatchPrefixError = MethodNotAllowed | PrefixNotFound | InvalidAccountId | CloudflareOpError;
/** Modify the description for a prefix owned by the account. */
export declare const patchPrefix: API.OperationMethod<PatchPrefixRequest, PatchPrefixResponse, PatchPrefixError, CloudflareOpContext>;
export type PatchPrefixAdvertisementStatusError = PrefixNotFound | InvalidAccountId | CloudflareOpError;
/** Advertise or withdraw the BGP route for a prefix. **Deprecated:** Prefer the BGP Prefixes endpoints, which additionally allow for advertising and withdrawing subnets of an IP prefix. */
export declare const patchPrefixAdvertisementStatus: API.OperationMethod<PatchPrefixAdvertisementStatusRequest, PatchPrefixAdvertisementStatusResponse, PatchPrefixAdvertisementStatusError, CloudflareOpContext>;
export type PatchPrefixBgpPrefixError = BgpPrefixNotFound | PrefixNotFound | InvalidAccountId | CloudflareOpError;
/** Update the properties of a BGP Prefix, such as the on demand advertisement status (advertised or withdrawn). */
export declare const patchPrefixBgpPrefix: API.OperationMethod<PatchPrefixBgpPrefixRequest, PatchPrefixBgpPrefixResponse, PatchPrefixBgpPrefixError, CloudflareOpContext>;
export type PatchRegionalHostnameError = InvalidZoneId | RegionalHostnameNotFound | RegionalHostnameEmpty | CloudflareOpError;
/** Update the configuration for a specific Regional Hostname. Only the region_key of a hostname is mutable. */
export declare const patchRegionalHostname: API.OperationMethod<PatchRegionalHostnameRequest, PatchRegionalHostnameResponse, PatchRegionalHostnameError, CloudflareOpContext>;
export type PutAddressMapAccountError = MethodNotAllowed | FeatureNotEnabled | InvalidAccountId | CloudflareOpError;
/** Add an account as a member of a particular address map. */
export declare const putAddressMapAccount: API.OperationMethod<PutAddressMapAccountRequest, PutAddressMapAccountResponse, PutAddressMapAccountError, CloudflareOpContext>;
export type PutAddressMapIpError = MethodNotAllowed | FeatureNotEnabled | InvalidAccountId | AddressMapNotFound | CloudflareOpError;
/** Add an IP from a prefix owned by the account to a particular address map. */
export declare const putAddressMapIp: API.OperationMethod<PutAddressMapIpRequest, PutAddressMapIpResponse, PutAddressMapIpError, CloudflareOpContext>;
export type PutAddressMapZoneError = MethodNotAllowed | FeatureNotEnabled | InvalidAccountId | CloudflareOpError;
/** Add a zone as a member of a particular address map. */
export declare const putAddressMapZone: API.OperationMethod<PutAddressMapZoneRequest, PutAddressMapZoneResponse, PutAddressMapZoneError, CloudflareOpContext>;
export type ValidatePrefixError = CloudflareOpError;
/** Triggers a new prefix validation. The checks are run asynchronously and include IRR, RPKI, and prefix ownership. */
export declare const validatePrefix: API.OperationMethod<ValidatePrefixRequest, ValidatePrefixResponse, ValidatePrefixError, CloudflareOpContext>;
//# sourceMappingURL=addressing.d.ts.map