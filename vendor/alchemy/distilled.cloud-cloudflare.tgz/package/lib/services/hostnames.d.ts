import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AdvancedCertificateManagerRequired_base: S.TaggedErrorClass<"AdvancedCertificateManagerRequired", {
    readonly code: any;
    readonly message: any;
}>;
export declare class AdvancedCertificateManagerRequired extends /*@__PURE__*/ AdvancedCertificateManagerRequired_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HostnameTlsSettingNotFound_base: S.TaggedErrorClass<"HostnameTlsSettingNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HostnameTlsSettingNotFound extends /*@__PURE__*/ HostnameTlsSettingNotFound_base {
}
export type SettingsTlsDeleteRequestSettingId = "ciphers" | "min_tls_version" | "http2";
export interface DeleteSettingTlsRequest {
    /** Identifier. */
    zoneId: string;
    /** The TLS Setting name. The value type depends on the setting: */
    settingId: SettingsTlsDeleteRequestSettingId | (string & {});
    /** The hostname for which the tls settings are set. */
    hostname: string;
}
export type SettingsTlsDeleteResponseValueCase0 = "1.0" | "1.1" | "1.2" | "1.3" | "on" | "off";
export type SettingsTlsDeleteResponseValueCase1List = Array<string>;
export type SettingsTlsDeleteResponseValue = SettingsTlsDeleteResponseValueCase0 | SettingsTlsDeleteResponseValueCase1List;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingTlsResponse {
    /** This is the time the tls setting was originally created for this hostname. */
    createdAt?: string | null;
    /** The hostname for which the tls settings are set. */
    hostname?: string | null;
    /** Deployment status for the given tls setting. */
    status?: string | null;
    /** This is the time the tls setting was updated. */
    updatedAt?: string | null;
    /** The TLS setting value. The type depends on the `setting_id` used in the request path: */
    value?: SettingsTlsDeleteResponseValue | null;
}
export type SettingsTlsGetRequestSettingId = "ciphers" | "min_tls_version" | "http2";
export interface GetSettingTlsRequest {
    /** Identifier. */
    zoneId: string;
    /** The TLS Setting name. The value type depends on the setting: */
    settingId: SettingsTlsGetRequestSettingId | (string & {});
    /** The hostname for which the tls settings are set. */
    hostname: string;
}
export type SettingsTlsGetResponseValueCase0 = "1.0" | "1.1" | "1.2" | "1.3" | "on" | "off";
export type SettingsTlsGetResponseValueCase1List = Array<string>;
export type SettingsTlsGetResponseValue = SettingsTlsGetResponseValueCase0 | SettingsTlsGetResponseValueCase1List;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingTlsResponse {
    /** This is the time the tls setting was originally created for this hostname. */
    createdAt?: string | null;
    /** The hostname for which the tls settings are set. */
    hostname?: string | null;
    /** Deployment status for the given tls setting. */
    status?: string | null;
    /** This is the time the tls setting was updated. */
    updatedAt?: string | null;
    /** The TLS setting value. The type depends on the `setting_id` used in the request path: */
    value?: SettingsTlsGetResponseValue | null;
}
export type ListSettingsTlsRequestSettingId = "ciphers" | "min_tls_version" | "http2";
export interface ListSettingsTlsRequest {
    /** Identifier. */
    zoneId: string;
    /** The TLS Setting name. The value type depends on the setting: */
    settingId: ListSettingsTlsRequestSettingId | (string & {});
}
export type ListSettingsTlsResultItemValueCase0 = "1.0" | "1.1" | "1.2" | "1.3" | "on" | "off";
export type ListSettingsTlsResultItemValueCase1List = Array<string>;
export type ListSettingsTlsResultItemValue = ListSettingsTlsResultItemValueCase0 | ListSettingsTlsResultItemValueCase1List;
export interface ListSettingsTlsResultItem {
    /** This is the time the tls setting was originally created for this hostname. */
    createdAt?: string | null;
    /** The hostname for which the tls settings are set. */
    hostname?: string | null;
    /** Deployment status for the given tls setting. */
    status?: string | null;
    /** This is the time the tls setting was updated. */
    updatedAt?: string | null;
    /** The TLS setting value. The type depends on the `setting_id` used in the request path: */
    value?: ListSettingsTlsResultItemValue | null;
}
export type ListSettingsTlsResultList = Array<ListSettingsTlsResultItem>;
export type ListSettingsTlsResponse = ListSettingsTlsResultList;
export type SettingsTlsUpdateRequestSettingId = "ciphers" | "min_tls_version" | "http2";
export type SettingsTlsUpdateRequestValueCase0 = "1.0" | "1.1" | "1.2" | "1.3" | "on" | "off";
export type SettingsTlsUpdateRequestValueCase1List = Array<string>;
export type SettingsTlsUpdateRequestValue = SettingsTlsUpdateRequestValueCase0 | (string & {}) | SettingsTlsUpdateRequestValueCase1List;
export interface PutSettingTlsRequest {
    /** Identifier. */
    zoneId: string;
    /** The TLS Setting name. The value type depends on the setting: */
    settingId: SettingsTlsUpdateRequestSettingId | (string & {});
    /** The hostname for which the tls settings are set. */
    hostname: string;
    /** The TLS setting value. The type depends on the `setting_id` used in the request path: */
    value: SettingsTlsUpdateRequestValue;
}
export type SettingsTlsUpdateResponseValueCase0 = "1.0" | "1.1" | "1.2" | "1.3" | "on" | "off";
export type SettingsTlsUpdateResponseValueCase1List = Array<string>;
export type SettingsTlsUpdateResponseValue = SettingsTlsUpdateResponseValueCase0 | SettingsTlsUpdateResponseValueCase1List;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSettingTlsResponse {
    /** This is the time the tls setting was originally created for this hostname. */
    createdAt?: string | null;
    /** The hostname for which the tls settings are set. */
    hostname?: string | null;
    /** Deployment status for the given tls setting. */
    status?: string | null;
    /** This is the time the tls setting was updated. */
    updatedAt?: string | null;
    /** The TLS setting value. The type depends on the `setting_id` used in the request path: */
    value?: SettingsTlsUpdateResponseValue | null;
}
export type DeleteSettingTlsError = AdvancedCertificateManagerRequired | HostnameTlsSettingNotFound | Forbidden | CloudflareOpError;
/** Delete the tls setting value for the hostname. */
export declare const deleteSettingTls: API.OperationMethod<DeleteSettingTlsRequest, DeleteSettingTlsResponse, DeleteSettingTlsError, CloudflareOpContext>;
export type GetSettingTlsError = AdvancedCertificateManagerRequired | Forbidden | CloudflareOpError;
/** Get the requested TLS setting for the hostname. */
export declare const getSettingTls: API.OperationMethod<GetSettingTlsRequest, GetSettingTlsResponse, GetSettingTlsError, CloudflareOpContext>;
export type ListSettingsTlsError = CloudflareOpError;
/** List the requested TLS setting for the hostnames under this zone. */
export declare const listSettingsTls: API.OperationMethod<ListSettingsTlsRequest, ListSettingsTlsResponse, ListSettingsTlsError, CloudflareOpContext>;
export type PutSettingTlsError = AdvancedCertificateManagerRequired | Forbidden | CloudflareOpError;
/** Update the tls setting value for the hostname. */
export declare const putSettingTls: API.OperationMethod<PutSettingTlsRequest, PutSettingTlsResponse, PutSettingTlsError, CloudflareOpContext>;
//# sourceMappingURL=hostnames.d.ts.map