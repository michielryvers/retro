import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ContentScanningNotEnabled_base: S.TaggedErrorClass<"ContentScanningNotEnabled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ContentScanningNotEnabled extends /*@__PURE__*/ ContentScanningNotEnabled_base {
}
declare const ContentScanningNotEntitled_base: S.TaggedErrorClass<"ContentScanningNotEntitled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ContentScanningNotEntitled extends /*@__PURE__*/ ContentScanningNotEntitled_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export type CreateRequestValue = "enabled" | "disabled";
export interface CreateContentScanningRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The status value for Content Scanning. */
    value: CreateRequestValue | (string & {});
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateContentScanningResponse {
    /** Defines the last modification date (ISO 8601) of the Content Scanning status. */
    modified?: string | null;
    /** Defines the status of Content Scanning. */
    value?: string | null;
}
export interface PayloadsCreateRequestBodyItem {
    /** Defines the custom content extraction expression used to reach content objects in the request. */
    payload: string;
}
export type PayloadsCreateRequestBodyList = Array<PayloadsCreateRequestBodyItem>;
export interface CreatePayloadRequest {
    /** Defines an identifier. */
    zoneId: string;
    body: PayloadsCreateRequestBodyList;
}
export interface PayloadsCreateResultItem {
    /** Defines the unique ID for this Content Scanning custom expression. */
    id?: string | null;
    /** Defines the custom content extraction expression used to reach content objects in the request. */
    payload?: string | null;
}
export type PayloadsCreateResultList = Array<PayloadsCreateResultItem>;
export interface CreatePayloadResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PayloadsCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface DeletePayloadRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique ID for this Content Scanning custom expression. */
    expressionId: string;
}
export type PayloadsDeleteResultItem = PayloadsCreateResultItem;
export type PayloadsDeleteResultList = Array<PayloadsCreateResultItem>;
export interface DeletePayloadResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PayloadsDeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface DisableContentScanningRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export type DisableContentScanningResponse = unknown;
export interface EnableContentScanningRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export type EnableContentScanningResponse = unknown;
export interface GetContentScanningRequest {
    /** Defines an identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetContentScanningResponse {
    /** Defines the last modification date (ISO 8601) of the Content Scanning status. */
    modified?: string | null;
    /** Defines the status of Content Scanning. */
    value?: string | null;
}
export interface GetSettingsRequest {
    /** Defines an identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingsResponse {
    /** Defines the last modification date (ISO 8601) of the Content Scanning status. */
    modified?: string | null;
    /** Defines the status of Content Scanning. */
    value?: string | null;
}
export interface ListPayloadsRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export type PayloadsListResultItem = PayloadsCreateResultItem;
export type PayloadsListResultList = Array<PayloadsCreateResultItem>;
export interface ListPayloadsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PayloadsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type UpdateRequestValue = "enabled" | "disabled";
export interface UpdateRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The status value for Content Scanning. */
    value: UpdateRequestValue | (string & {});
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResponse {
    /** Defines the last modification date (ISO 8601) of the Content Scanning status. */
    modified?: string | null;
    /** Defines the status of Content Scanning. */
    value?: string | null;
}
export interface UpdatePayloadRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique ID for this Content Scanning custom expression. */
    expressionId: string;
    /** Defines the custom content extraction expression used to reach content objects in the request. */
    payload: string;
}
export type UpdatePayloadResultItem = PayloadsCreateResultItem;
export type UpdatePayloadResultList = Array<PayloadsCreateResultItem>;
export type UpdatePayloadResponse = UpdatePayloadResultList;
export type CreateContentScanningError = ContentScanningNotEntitled | Forbidden | CloudflareOpError;
/** Update the Content Scanning status by setting the status value to `enabled` or `disabled`. This is equivalent to calling the dedicated enable and disable endpoints. */
export declare const createContentScanning: API.OperationMethod<CreateContentScanningRequest, CreateContentScanningResponse, CreateContentScanningError, CloudflareOpContext>;
export type CreatePayloadError = ContentScanningNotEnabled | ContentScanningNotEntitled | Forbidden | CloudflareOpError;
/** Create one or more Content Scanning custom expressions, appending them to the existing list of the zone, and return the updated list. Each expression reaches content objects the scanner cannot find automatically, for example `lookup_json_string(http.request.body.raw, "file")`. */
export declare const createPayload: API.PaginatedOperationMethod<CreatePayloadRequest, CreatePayloadResponse, CreatePayloadError, CloudflareOpContext, PayloadsCreateResultItem>;
export type DeletePayloadError = ContentScanningNotEnabled | Forbidden | CloudflareOpError;
/** Delete the Content Scanning custom expression with the given identifier and return the expressions that remain. Content objects reached only by the deleted expression are no longer scanned. */
export declare const deletePayload: API.PaginatedOperationMethod<DeletePayloadRequest, DeletePayloadResponse, DeletePayloadError, CloudflareOpContext, PayloadsCreateResultItem>;
export type DisableContentScanningError = CloudflareOpError;
/** Disable Content Scanning for a zone. The `cf.waf.content_scan.*` fields are no longer populated, so rules that reference them stop matching. */
export declare const disableContentScanning: API.OperationMethod<DisableContentScanningRequest, DisableContentScanningResponse, DisableContentScanningError, CloudflareOpContext>;
export type EnableContentScanningError = CloudflareOpError;
/** Enable Content Scanning for a zone, so that Cloudflare inspects content objects uploaded to the zone and checks them for malware. Scan results populate the `cf.waf.content_scan.*` fields, which you can reference in custom rules and rate limiting rules. */
export declare const enableContentScanning: API.OperationMethod<EnableContentScanningRequest, EnableContentScanningResponse, EnableContentScanningError, CloudflareOpContext>;
export type GetContentScanningError = Forbidden | CloudflareOpError;
/** Get the current Content Scanning status for the zone, together with the date the status was last modified. */
export declare const getContentScanning: API.OperationMethod<GetContentScanningRequest, GetContentScanningResponse, GetContentScanningError, CloudflareOpContext>;
export type GetSettingsError = Forbidden | CloudflareOpError;
/** Get the current Content Scanning status for the zone, together with the date the status was last modified. */
export declare const getSettings: API.OperationMethod<GetSettingsRequest, GetSettingsResponse, GetSettingsError, CloudflareOpContext>;
export type ListPayloadsError = ContentScanningNotEnabled | Forbidden | CloudflareOpError;
/** List the Content Scanning custom expressions configured for the zone, each with its own identifier. A custom expression tells the scanner how to reach content objects in a request it cannot parse on its own, such as files Base64-encoded inside a JSON body. */
export declare const listPayloads: API.PaginatedOperationMethod<ListPayloadsRequest, ListPayloadsResponse, ListPayloadsError, CloudflareOpContext, PayloadsCreateResultItem>;
export type UpdateError = ContentScanningNotEntitled | Forbidden | CloudflareOpError;
/** Update the Content Scanning status by setting the status value to `enabled` or `disabled`. This is equivalent to calling the dedicated enable and disable endpoints. */
export declare const update: API.OperationMethod<UpdateRequest, UpdateResponse, UpdateError, CloudflareOpContext>;
export type UpdatePayloadError = CloudflareOpError;
/** Update the Content Scanning custom expression with the given identifier and return the updated list of expressions. */
export declare const updatePayload: API.OperationMethod<UpdatePayloadRequest, UpdatePayloadResponse, UpdatePayloadError, CloudflareOpContext>;
export declare const getSetting: API.OperationMethod<GetContentScanningRequest, GetContentScanningResponse, GetContentScanningError, CloudflareOpContext>;
export type GetSettingRequest = GetContentScanningRequest;
export type GetSettingResponse = GetContentScanningResponse;
export type GetSettingError = GetContentScanningError;
export declare const putContentScanning: API.OperationMethod<CreateContentScanningRequest, CreateContentScanningResponse, CreateContentScanningError, CloudflareOpContext>;
export type PutContentScanningRequest = CreateContentScanningRequest;
export type PutContentScanningResponse = CreateContentScanningResponse;
export type PutContentScanningError = CreateContentScanningError;
//# sourceMappingURL=content_scanning.d.ts.map