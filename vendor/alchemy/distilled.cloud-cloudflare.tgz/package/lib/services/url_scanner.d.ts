import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type ScansBulkCreateRequestBodyItemCustomHeadersMap = {
    [key: string]: string | undefined;
};
export type ScansBulkCreateRequestBodyItemScreenshotsResolutionsItem = "desktop" | "mobile" | "tablet";
export type ScansBulkCreateRequestBodyItemScreenshotsResolutionsList = Array<ScansBulkCreateRequestBodyItemScreenshotsResolutionsItem | (string & {})>;
export type ScansBulkCreateRequestBodyItemVisibility = "Public" | "Unlisted";
export interface ScansBulkCreateRequestBodyItem {
    url: string;
    /** Enable agent readiness checks. */
    agentReadiness?: boolean;
    customagent?: string;
    /** Set custom headers. */
    customHeaders?: ScansBulkCreateRequestBodyItemCustomHeadersMap;
    referer?: string;
    /** Take multiple screenshots targeting different device types. */
    screenshotsResolutions?: ScansBulkCreateRequestBodyItemScreenshotsResolutionsList;
    /** The option `Public` means it will be included in listings like recent scans and search results. `Unlisted` means it will not be included in the aforementioned listings, users will need to have the scan's ID to access it. A a scan will be automatically marked as unlisted if it fails, if it contains potential PII or other sensitive material. */
    visibility?: ScansBulkCreateRequestBodyItemVisibility | (string & {});
}
export type ScansBulkCreateRequestBodyList = Array<ScansBulkCreateRequestBodyItem>;
export interface BulkCreateScansRequest {
    /** Account ID. */
    accountId: string;
    /** List of urls to scan (up to a 100). */
    body?: ScansBulkCreateRequestBodyList;
}
export type BulkCreateScansResponse = string;
export type ScansCreateRequestCountry = "AF" | "AL" | "DZ" | "AD" | "AO" | "AG" | "AR" | "AM" | "AU" | "AT" | "AZ" | "BH" | "BD" | "BB" | "BY" | "BE" | "BZ" | "BJ" | "BM" | "BT" | "BO" | "BA" | "BW" | "BR" | "BN" | "BG" | "BF" | "BI" | "KH" | "CM" | "CA" | "CV" | "KY" | "CF" | "TD" | "CL" | "CN" | "CO" | "KM" | "CG" | "CR" | "CI" | "HR" | "CU" | "CY" | "CZ" | "CD" | "DK" | "DJ" | "DM" | "DO" | "EC" | "EG" | "SV" | "GQ" | "ER" | "EE" | "SZ" | "ET" | "FJ" | "FI" | "FR" | "GA" | "GE" | "DE" | "GH" | "GR" | "GL" | "GD" | "GT" | "GN" | "GW" | "GY" | "HT" | "HN" | "HU" | "IS" | "IN" | "ID" | "IR" | "IQ" | "IE" | "IL" | "IT" | "JM" | "JP" | "JO" | "KZ" | "KE" | "KI" | "KW" | "KG" | "LA" | "LV" | "LB" | "LS" | "LR" | "LY" | "LI" | "LT" | "LU" | "MO" | "MG" | "MW" | "MY" | "MV" | "ML" | "MR" | "MU" | "MX" | "FM" | "MD" | "MC" | "MN" | "MS" | "MA" | "MZ" | "MM" | "NA" | "NR" | "NP" | "NL" | "NZ" | "NI" | "NE" | "NG" | "KP" | "MK" | "NO" | "OM" | "PK" | "PS" | "PA" | "PG" | "PY" | "PE" | "PH" | "PL" | "PT" | "QA" | "RO" | "RU" | "RW" | "SH" | "KN" | "LC" | "VC" | "WS" | "SM" | "ST" | "SA" | "SN" | "RS" | "SC" | "SL" | "SK" | "SI" | "SB" | "SO" | "ZA" | "KR" | "SS" | "ES" | "LK" | "SD" | "SR" | "SE" | "CH" | "SY" | "TW" | "TJ" | "TZ" | "TH" | "BS" | "GM" | "TL" | "TG" | "TO" | "TT" | "TN" | "TR" | "TM" | "UG" | "UA" | "AE" | "GB" | "US" | "UY" | "UZ" | "VU" | "VE" | "VN" | "YE" | "ZM" | "ZW";
export type ScansCreateRequestCustomHeadersMap = {
    [key: string]: string | undefined;
};
export type ScansCreateRequestScreenshotsResolutionsItem = "desktop" | "mobile" | "tablet";
export type ScansCreateRequestScreenshotsResolutionsList = Array<ScansCreateRequestScreenshotsResolutionsItem | (string & {})>;
export type ScansCreateRequestVisibility = "Public" | "Unlisted";
export interface CreateScanRequest {
    /** Account ID. */
    accountId: string;
    url: string;
    /** Enable agent readiness checks. */
    agentReadiness?: boolean;
    /** Country to geo egress from */
    country?: ScansCreateRequestCountry | (string & {});
    customagent?: string;
    /** Set custom headers. */
    customHeaders?: ScansCreateRequestCustomHeadersMap;
    referer?: string;
    /** Take multiple screenshots targeting different device types. */
    screenshotsResolutions?: ScansCreateRequestScreenshotsResolutionsList;
    /** The option `Public` means it will be included in listings like recent scans and search results. `Unlisted` means it will not be included in the aforementioned listings, users will need to have the scan's ID to access it. A a scan will be automatically marked as unlisted if it fails, if it contains potential PII or other sensitive material. */
    visibility?: ScansCreateRequestVisibility | (string & {});
}
export type CreateScanResponse = string;
export interface DomScanRequest {
    /** Account ID. */
    accountId: string;
    /** Scan UUID. */
    scanId: string;
}
export interface DomScanResponse {
}
export interface GetResponsRequest {
    /** Account ID. */
    accountId: string;
    /** Response hash. */
    responseId: string;
}
export interface GetResponsResponse {
}
export interface GetScanRequest {
    /** Account ID. */
    accountId: string;
    /** Scan UUID. */
    scanId: string;
}
export interface ScansGetResponseDataConsoleItemMessage {
    level: string;
    source: string;
    text: string;
    url: string;
}
export interface ScansGetResponseDataConsoleItem {
    message: ScansGetResponseDataConsoleItemMessage;
}
export type ScansGetResponseDataConsoleList = Array<ScansGetResponseDataConsoleItem>;
export interface ScansGetResponseDataCookiesItem {
    domain: string;
    expires: number;
    httpOnly: boolean;
    name: string;
    path: string;
    priority: string;
    sameParty: boolean;
    secure: boolean;
    session: boolean;
    size: number;
    sourcePort: number;
    sourceScheme: string;
    value: string;
}
export type ScansGetResponseDataCookiesList = Array<ScansGetResponseDataCookiesItem>;
export interface ScansGetResponseDataGlobalsItem {
    prop: string;
    type: string;
}
export type ScansGetResponseDataGlobalsList = Array<ScansGetResponseDataGlobalsItem>;
export interface ScansGetResponseDataLinksItem {
    href: string;
    text: string;
}
export type ScansGetResponseDataLinksList = Array<ScansGetResponseDataLinksItem>;
export interface ScansGetResponseDataPerformanceItem {
    duration: number;
    entryType: string;
    name: string;
    startTime: number;
}
export type ScansGetResponseDataPerformanceList = Array<ScansGetResponseDataPerformanceItem>;
export interface ScansGetResponseDataRequestsItemRequestInitiator {
    host: string;
    type: string;
    url: string;
}
export interface ScansGetResponseDataRequestsItemRequestRequest {
    initialPriority: string;
    isSameSite: boolean;
    method: string;
    mixedContentType: string;
    referrerPolicy: string;
    url: string;
    headers?: unknown | null;
}
export interface ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem {
    name: string;
    value: string;
}
export type ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersList = Array<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export interface ScansGetResponseDataRequestsItemRequestRedirectResponse {
    charset: string;
    mimeType: string;
    protocol: string;
    remoteIPAddress: string;
    remotePort: number;
    securityHeaders: ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersList;
    securityState: string;
    status: number;
    statusText: string;
    url: string;
    headers?: unknown | null;
}
export interface ScansGetResponseDataRequestsItemRequest {
    documentURL: string;
    hasUserGesture: boolean;
    initiator: ScansGetResponseDataRequestsItemRequestInitiator;
    redirectHasExtraInfo: boolean;
    request: ScansGetResponseDataRequestsItemRequestRequest;
    requestId: string;
    type: string;
    wallTime: number;
    frameId?: string | null;
    loaderId?: string | null;
    primaryRequest?: boolean | null;
    redirectResponse?: ScansGetResponseDataRequestsItemRequestRedirectResponse | null;
}
export interface ScansGetResponseDataRequestsItemResponseAsn {
    asn: string;
    country: string;
    description: string;
    ip: string;
    name: string;
    org: string;
}
export type ScansGetResponseDataRequestsItemResponseGeoipLlList = Array<number>;
export interface ScansGetResponseDataRequestsItemResponseGeoip {
    city: string;
    country: string;
    countryName: string;
    geonameId: string;
    ll: ScansGetResponseDataRequestsItemResponseGeoipLlList;
    region: string;
}
export type ScansGetResponseDataRequestsItemResponseResponseSecurityDetailsSanListList = Array<string>;
export interface ScansGetResponseDataRequestsItemResponseResponseSecurityDetails {
    certificateId: number;
    certificateTransparencyCompliance: string;
    cipher: string;
    encryptedClientHello: boolean;
    issuer: string;
    keyExchange: string;
    keyExchangeGroup: string;
    protocol: string;
    sanList: ScansGetResponseDataRequestsItemResponseResponseSecurityDetailsSanListList;
    serverSignatureAlgorithm: number;
    subjectName: string;
    validFrom: number;
    validTo: number;
}
export type ScansGetResponseDataRequestsItemResponseResponseSecurityHeadersItem = ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem;
export type ScansGetResponseDataRequestsItemResponseResponseSecurityHeadersList = Array<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export interface ScansGetResponseDataRequestsItemResponseResponse {
    charset: string;
    mimeType: string;
    protocol: string;
    remoteIPAddress: string;
    remotePort: number;
    securityDetails: ScansGetResponseDataRequestsItemResponseResponseSecurityDetails;
    securityHeaders: ScansGetResponseDataRequestsItemResponseResponseSecurityHeadersList;
    securityState: string;
    status: number;
    statusText: string;
    url: string;
    headers?: unknown | null;
}
export interface ScansGetResponseDataRequestsItemResponse {
    asn: ScansGetResponseDataRequestsItemResponseAsn;
    dataLength: number;
    encodedDataLength: number;
    geoip: ScansGetResponseDataRequestsItemResponseGeoip;
    hasExtraInfo: boolean;
    requestId: string;
    response: ScansGetResponseDataRequestsItemResponseResponse;
    size: number;
    type: string;
    contentAvailable?: boolean | null;
    hash?: string | null;
}
export interface ScansGetResponseDataRequestsItemRequestsItemInitiator {
    type: string;
}
export interface ScansGetResponseDataRequestsItemRequestsItemRequestHeaders {
    name: string;
}
export interface ScansGetResponseDataRequestsItemRequestsItemRequest {
    headers: ScansGetResponseDataRequestsItemRequestsItemRequestHeaders;
    initialPriority: string;
    isSameSite: boolean;
    method: string;
    mixedContentType: string;
    referrerPolicy: string;
    url: string;
}
export interface ScansGetResponseDataRequestsItemRequestsItem {
    documentURL: string;
    frameId: string;
    hasUserGesture: boolean;
    initiator: ScansGetResponseDataRequestsItemRequestsItemInitiator;
    loaderId: string;
    redirectHasExtraInfo: boolean;
    request: ScansGetResponseDataRequestsItemRequestsItemRequest;
    requestId: string;
    type: string;
    wallTime: number;
}
export type ScansGetResponseDataRequestsItemRequestsList = Array<ScansGetResponseDataRequestsItemRequestsItem>;
export interface ScansGetResponseDataRequestsItem {
    request: ScansGetResponseDataRequestsItemRequest;
    response: ScansGetResponseDataRequestsItemResponse;
    requests?: ScansGetResponseDataRequestsItemRequestsList | null;
}
export type ScansGetResponseDataRequestsList = Array<ScansGetResponseDataRequestsItem>;
export interface ScansGetResponseData {
    console: ScansGetResponseDataConsoleList;
    cookies: ScansGetResponseDataCookiesList;
    globals: ScansGetResponseDataGlobalsList;
    links: ScansGetResponseDataLinksList;
    performance: ScansGetResponseDataPerformanceList;
    requests: ScansGetResponseDataRequestsList;
}
export type ScansGetResponseListsAsnsList = Array<string>;
export interface ScansGetResponseListsCertificatesItem {
    issuer: string;
    subjectName: string;
    validFrom: number;
    validTo: number;
}
export type ScansGetResponseListsCertificatesList = Array<ScansGetResponseListsCertificatesItem>;
export type ScansGetResponseListsContinentsList = Array<string>;
export type ScansGetResponseListsCountriesList = Array<string>;
export type ScansGetResponseListsDomainsList = Array<string>;
export type ScansGetResponseListsHashesList = Array<string>;
export type ScansGetResponseListsIpsList = Array<string>;
export type ScansGetResponseListsLinkDomainsList = Array<string>;
export type ScansGetResponseListsServersList = Array<string>;
export type ScansGetResponseListsUrlsList = Array<string>;
export interface ScansGetResponseLists {
    asns: ScansGetResponseListsAsnsList;
    certificates: ScansGetResponseListsCertificatesList;
    continents: ScansGetResponseListsContinentsList;
    countries: ScansGetResponseListsCountriesList;
    domains: ScansGetResponseListsDomainsList;
    hashes: ScansGetResponseListsHashesList;
    ips: ScansGetResponseListsIpsList;
    linkDomains: ScansGetResponseListsLinkDomainsList;
    servers: ScansGetResponseListsServersList;
    urls: ScansGetResponseListsUrlsList;
}
export interface ScansGetResponseMetaProcessorsAsnDataItem {
    asn: string;
    country: string;
    description: string;
    ip: string;
    name: string;
}
export type ScansGetResponseMetaProcessorsAsnDataList = Array<ScansGetResponseMetaProcessorsAsnDataItem>;
export interface ScansGetResponseMetaProcessorsAsn {
    data: ScansGetResponseMetaProcessorsAsnDataList;
}
export interface ScansGetResponseMetaProcessorsDnsDataItem {
    address: string;
    dnssecValid: boolean;
    name: string;
    type: string;
}
export type ScansGetResponseMetaProcessorsDnsDataList = Array<ScansGetResponseMetaProcessorsDnsDataItem>;
export interface ScansGetResponseMetaProcessorsDns {
    data: ScansGetResponseMetaProcessorsDnsDataList;
}
export interface ScansGetResponseMetaProcessorsDomainCategoriesDataItem {
    inherited: unknown;
    isPrimary: boolean;
    name: string;
}
export type ScansGetResponseMetaProcessorsDomainCategoriesDataList = Array<ScansGetResponseMetaProcessorsDomainCategoriesDataItem>;
export interface ScansGetResponseMetaProcessorsDomainCategories {
    data: ScansGetResponseMetaProcessorsDomainCategoriesDataList;
}
export type ScansGetResponseMetaProcessorsGeoipDataItemGeoipLlList = Array<number>;
export interface ScansGetResponseMetaProcessorsGeoipDataItemGeoip {
    city: string;
    country: string;
    countryName: string;
    ll: ScansGetResponseMetaProcessorsGeoipDataItemGeoipLlList;
    region: string;
}
export interface ScansGetResponseMetaProcessorsGeoipDataItem {
    geoip: ScansGetResponseMetaProcessorsGeoipDataItemGeoip;
    ip: string;
}
export type ScansGetResponseMetaProcessorsGeoipDataList = Array<ScansGetResponseMetaProcessorsGeoipDataItem>;
export interface ScansGetResponseMetaProcessorsGeoip {
    data: ScansGetResponseMetaProcessorsGeoipDataList;
}
export type ScansGetResponseMetaProcessorsPhishingDataList = Array<string>;
export interface ScansGetResponseMetaProcessorsPhishing {
    data: ScansGetResponseMetaProcessorsPhishingDataList;
}
export interface ScansGetResponseMetaProcessorsRadarRankDataItem {
    bucket: string;
    hostname: string;
    rank?: number | null;
}
export type ScansGetResponseMetaProcessorsRadarRankDataList = Array<ScansGetResponseMetaProcessorsRadarRankDataItem>;
export interface ScansGetResponseMetaProcessorsRadarRank {
    data: ScansGetResponseMetaProcessorsRadarRankDataList;
}
export interface ScansGetResponseMetaProcessorsWappaDataItemCategoriesItem {
    name: string;
    priority: number;
}
export type ScansGetResponseMetaProcessorsWappaDataItemCategoriesList = Array<ScansGetResponseMetaProcessorsWappaDataItemCategoriesItem>;
export interface ScansGetResponseMetaProcessorsWappaDataItemConfidenceItem {
    confidence: number;
    name: string;
    pattern: string;
    patternType: string;
}
export type ScansGetResponseMetaProcessorsWappaDataItemConfidenceList = Array<ScansGetResponseMetaProcessorsWappaDataItemConfidenceItem>;
export interface ScansGetResponseMetaProcessorsWappaDataItem {
    app: string;
    categories: ScansGetResponseMetaProcessorsWappaDataItemCategoriesList;
    confidence: ScansGetResponseMetaProcessorsWappaDataItemConfidenceList;
    confidenceTotal: number;
    icon: string;
    website: string;
}
export type ScansGetResponseMetaProcessorsWappaDataList = Array<ScansGetResponseMetaProcessorsWappaDataItem>;
export interface ScansGetResponseMetaProcessorsWappa {
    data: ScansGetResponseMetaProcessorsWappaDataList;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding {
    outcome: string;
    summary: string;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest {
    method: string;
    url: string;
    headers?: unknown | null;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse {
    status: number;
    statusText: string;
    bodyPreview?: string | null;
    bodySize?: number | null;
    headers?: unknown | null;
    redirectedTo?: string | null;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem {
    action: string;
    label: string;
    finding?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding | null;
    request?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest | null;
    response?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef {
    /** Stable, translatable message code. */
    code: string;
    params?: unknown | null;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignals {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRules {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuth {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControl {
    contentSignals: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignals;
    robotsTxtAiRules: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRules;
    webBotAuth: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuth;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcp {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2MessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2 {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMpp {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcp {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402MessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402 {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerce {
    acp: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcp;
    ap2: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2;
    mpp: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMpp;
    ucp: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcp;
    x402: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiation {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibility {
    markdownNegotiation: ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiation;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAid {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeaders {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxt {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemap {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverability {
    dnsAid: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAid;
    linkHeaders: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeaders;
    robotsTxt: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxt;
    sitemap: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemap;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCard {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkills {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalog {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArd {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMd {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCard {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscovery {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResource {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcp {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceList | null;
    message?: string | null;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscovery {
    a2aAgentCard: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCard;
    agentSkills: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkills;
    apiCatalog: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalog;
    ard: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArd;
    authMd: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMd;
    mcpServerCard: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCard;
    oauthDiscovery: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscovery;
    oauthProtectedResource: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResource;
    webMcp: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcp;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecks {
    botAccessControl: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControl;
    commerce: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerce;
    contentAccessibility: ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibility;
    discoverability: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverability;
    discovery: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscovery;
}
export type ScansGetResponseMetaProcessorsAgentReadinessCommerceSignalsList = Array<string>;
export type ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItemSpecUrlsList = Array<string>;
export interface ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItem {
    check: string;
    description: string;
    prompt: string;
    skillUrl: string;
    specUrls: ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItemSpecUrlsList;
}
export type ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsList = Array<ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItem>;
export interface ScansGetResponseMetaProcessorsAgentReadinessNextLevel {
    name: string;
    requirements: ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsList;
    target: number;
}
export interface ScansGetResponseMetaProcessorsAgentReadiness {
    checks: ScansGetResponseMetaProcessorsAgentReadinessChecks;
    level: number;
    levelName: string;
    commerceSignals?: ScansGetResponseMetaProcessorsAgentReadinessCommerceSignalsList | null;
    isCommerce?: boolean | null;
    nextLevel?: ScansGetResponseMetaProcessorsAgentReadinessNextLevel | null;
}
export type ScansGetResponseMetaProcessorsPhishingV2DataList = Array<string>;
export interface ScansGetResponseMetaProcessorsPhishingV2 {
    data: ScansGetResponseMetaProcessorsPhishingV2DataList;
}
export type ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValueAllowList = Array<string>;
export type ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValueDisallowList = Array<string>;
export interface ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValueContentSignal {
    aiInput?: string | null;
    aiTrain?: string | null;
    search?: string | null;
}
export interface ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValue {
    allow: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValueAllowList;
    disallow: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValueDisallowList;
    contentSignal?: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValueContentSignal | null;
    crawlDelay?: number | null;
}
export type ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesMap = {
    [key: string]: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValue | undefined;
};
export type ScansGetResponseMetaProcessorsRobotsTxtDataItemSitemapsList = Array<string>;
export interface ScansGetResponseMetaProcessorsRobotsTxtDataItem {
    rules: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesMap;
    sitemaps: ScansGetResponseMetaProcessorsRobotsTxtDataItemSitemapsList;
    hash?: string | null;
}
export type ScansGetResponseMetaProcessorsRobotsTxtDataList = Array<ScansGetResponseMetaProcessorsRobotsTxtDataItem>;
export interface ScansGetResponseMetaProcessorsRobotsTxt {
    data: ScansGetResponseMetaProcessorsRobotsTxtDataList;
}
export interface ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem {
    id: number;
    name: string;
    superCategoryId: number;
}
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedContentItem = ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedContentList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedRisksItem = ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedRisksList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export interface ScansGetResponseMetaProcessorsUrlCategoriesDataItemInherited {
    content: ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedContentList;
    from: string;
    risks: ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedRisksList;
}
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemRisksItem = ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemRisksList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export interface ScansGetResponseMetaProcessorsUrlCategoriesDataItem {
    content: ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentList;
    inherited: ScansGetResponseMetaProcessorsUrlCategoriesDataItemInherited;
    name: string;
    risks: ScansGetResponseMetaProcessorsUrlCategoriesDataItemRisksList;
}
export type ScansGetResponseMetaProcessorsUrlCategoriesDataList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItem>;
export interface ScansGetResponseMetaProcessorsUrlCategories {
    data: ScansGetResponseMetaProcessorsUrlCategoriesDataList;
}
export interface ScansGetResponseMetaProcessors {
    asn: ScansGetResponseMetaProcessorsAsn;
    dns: ScansGetResponseMetaProcessorsDns;
    domainCategories: ScansGetResponseMetaProcessorsDomainCategories;
    geoip: ScansGetResponseMetaProcessorsGeoip;
    phishing: ScansGetResponseMetaProcessorsPhishing;
    radarRank: ScansGetResponseMetaProcessorsRadarRank;
    wappa: ScansGetResponseMetaProcessorsWappa;
    agentReadiness?: ScansGetResponseMetaProcessorsAgentReadiness | null;
    phishingV2?: ScansGetResponseMetaProcessorsPhishingV2 | null;
    robotsTxt?: ScansGetResponseMetaProcessorsRobotsTxt | null;
    urlCategories?: ScansGetResponseMetaProcessorsUrlCategories | null;
}
export interface ScansGetResponseMeta {
    processors: ScansGetResponseMetaProcessors;
}
export interface ScansGetResponsePageScreenshot {
    dhash: string;
    mm3Hash: number;
    name: string;
    phash: string;
}
export interface ScansGetResponsePage {
    apexDomain: string;
    asn: string;
    asnname: string;
    city: string;
    country: string;
    domain: string;
    ip: string;
    mimeType: string;
    server: string;
    status: string;
    title: string;
    tlsAgeDays: number;
    tlsIssuer: string;
    tlsValidDays: number;
    tlsValidFrom: string;
    url: string;
    screenshot?: ScansGetResponsePageScreenshot | null;
}
export interface ScansGetResponseScanner {
    colo: string;
    country: string;
}
export type ScansGetResponseStatsDomainStatsItemCountriesList = Array<string>;
export type ScansGetResponseStatsDomainStatsItemInitiatorsList = Array<string>;
export type ScansGetResponseStatsDomainStatsItemIpsList = Array<string>;
export interface ScansGetResponseStatsDomainStatsItem {
    count: number;
    countries: ScansGetResponseStatsDomainStatsItemCountriesList;
    domain: string;
    encodedSize: number;
    index: number;
    initiators: ScansGetResponseStatsDomainStatsItemInitiatorsList;
    ips: ScansGetResponseStatsDomainStatsItemIpsList;
    redirects: number;
    size: number;
}
export type ScansGetResponseStatsDomainStatsList = Array<ScansGetResponseStatsDomainStatsItem>;
export type ScansGetResponseStatsIpStatsItemAsn = ScansGetResponseDataRequestsItemResponseAsn;
export type ScansGetResponseStatsIpStatsItemCountriesList = Array<string>;
export type ScansGetResponseStatsIpStatsItemDomainsList = Array<string>;
export type ScansGetResponseStatsIpStatsItemGeoipLlList = Array<number>;
export interface ScansGetResponseStatsIpStatsItemGeoip {
    city: string;
    country: string;
    countryName: string;
    ll: ScansGetResponseStatsIpStatsItemGeoipLlList;
    region: string;
}
export interface ScansGetResponseStatsIpStatsItem {
    asn: ScansGetResponseDataRequestsItemResponseAsn;
    countries: ScansGetResponseStatsIpStatsItemCountriesList;
    domains: ScansGetResponseStatsIpStatsItemDomainsList;
    encodedSize: number;
    geoip: ScansGetResponseStatsIpStatsItemGeoip;
    index: number;
    ip: string;
    ipv6: boolean;
    redirects: number;
    requests: number;
    size: number;
    count?: number | null;
}
export type ScansGetResponseStatsIpStatsList = Array<ScansGetResponseStatsIpStatsItem>;
export type ScansGetResponseStatsProtocolStatsItemCountriesList = Array<string>;
export type ScansGetResponseStatsProtocolStatsItemIpsList = Array<string>;
export interface ScansGetResponseStatsProtocolStatsItem {
    count: number;
    countries: ScansGetResponseStatsProtocolStatsItemCountriesList;
    encodedSize: number;
    ips: ScansGetResponseStatsProtocolStatsItemIpsList;
    protocol: string;
    size: number;
}
export type ScansGetResponseStatsProtocolStatsList = Array<ScansGetResponseStatsProtocolStatsItem>;
export type ScansGetResponseStatsResourceStatsItemCountriesList = Array<string>;
export type ScansGetResponseStatsResourceStatsItemIpsList = Array<string>;
export interface ScansGetResponseStatsResourceStatsItem {
    compression: number;
    count: number;
    countries: ScansGetResponseStatsResourceStatsItemCountriesList;
    encodedSize: number;
    ips: ScansGetResponseStatsResourceStatsItemIpsList;
    percentage: number;
    size: number;
    type: string;
}
export type ScansGetResponseStatsResourceStatsList = Array<ScansGetResponseStatsResourceStatsItem>;
export type ScansGetResponseStatsServerStatsItemCountriesList = Array<string>;
export type ScansGetResponseStatsServerStatsItemIpsList = Array<string>;
export interface ScansGetResponseStatsServerStatsItem {
    count: number;
    countries: ScansGetResponseStatsServerStatsItemCountriesList;
    encodedSize: number;
    ips: ScansGetResponseStatsServerStatsItemIpsList;
    server: string;
    size: number;
}
export type ScansGetResponseStatsServerStatsList = Array<ScansGetResponseStatsServerStatsItem>;
export type ScansGetResponseStatsTlsStatsItemCountriesList = Array<string>;
export type ScansGetResponseStatsTlsStatsItemIpsList = Array<string>;
export interface ScansGetResponseStatsTlsStatsItemProtocols {
    TLS_1_3___AES_128_GCM: number;
}
export interface ScansGetResponseStatsTlsStatsItem {
    count: number;
    countries: ScansGetResponseStatsTlsStatsItemCountriesList;
    encodedSize: number;
    ips: ScansGetResponseStatsTlsStatsItemIpsList;
    protocols: ScansGetResponseStatsTlsStatsItemProtocols;
    securityState: string;
    size: number;
}
export type ScansGetResponseStatsTlsStatsList = Array<ScansGetResponseStatsTlsStatsItem>;
export interface ScansGetResponseStats {
    domainStats: ScansGetResponseStatsDomainStatsList;
    ipStats: ScansGetResponseStatsIpStatsList;
    iPv6Percentage: number;
    malicious: number;
    protocolStats: ScansGetResponseStatsProtocolStatsList;
    resourceStats: ScansGetResponseStatsResourceStatsList;
    securePercentage: number;
    secureRequests: number;
    serverStats: ScansGetResponseStatsServerStatsList;
    tlsStats: ScansGetResponseStatsTlsStatsList;
    totalLinks: number;
    uniqASNs: number;
    uniqCountries: number;
}
export type ScansGetResponseTaskOptionsScreenshotsResolutionsList = Array<string>;
export interface ScansGetResponseTaskOptions {
    /** Custom headers set. */
    customHeaders?: unknown | null;
    screenshotsResolutions?: ScansGetResponseTaskOptionsScreenshotsResolutionsList | null;
}
export interface ScansGetResponseTask {
    apexDomain: string;
    domain: string;
    domURL: string;
    method: string;
    options: ScansGetResponseTaskOptions;
    reportURL: string;
    screenshotURL: string;
    source: string;
    success: boolean;
    time: string;
    url: string;
    uuid: string;
    visibility: string;
}
export type ScansGetResponseVerdictsOverallCategoriesList = Array<string>;
export type ScansGetResponseVerdictsOverallTagsList = Array<string>;
export interface ScansGetResponseVerdictsOverall {
    categories: ScansGetResponseVerdictsOverallCategoriesList;
    hasVerdicts: boolean;
    malicious: boolean;
    tags: ScansGetResponseVerdictsOverallTagsList;
}
export interface ScansGetResponseVerdicts {
    overall: ScansGetResponseVerdictsOverall;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetScanResponse {
    data: ScansGetResponseData;
    lists: ScansGetResponseLists;
    meta: ScansGetResponseMeta;
    page: ScansGetResponsePage;
    scanner: ScansGetResponseScanner;
    stats: ScansGetResponseStats;
    task: ScansGetResponseTask;
    verdicts: ScansGetResponseVerdicts;
}
export interface HarScanRequest {
    /** Account ID. */
    accountId: string;
    /** Scan UUID. */
    scanId: string;
}
export interface ScansHarResponseLogCreator {
    comment: string;
    name: string;
    version: string;
}
export type ScansHarResponseLogEntriesItemRequestHeadersItem = ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem;
export type ScansHarResponseLogEntriesItemRequestHeadersList = Array<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export interface ScansHarResponseLogEntriesItemRequest {
    bodySize: number;
    headers: ScansHarResponseLogEntriesItemRequestHeadersList;
    headersSize: number;
    httpVersion: string;
    method: string;
    url: string;
}
export interface ScansHarResponseLogEntriesItemResponseContent {
    mimeType: string;
    size: number;
    compression?: number | null;
}
export type ScansHarResponseLogEntriesItemResponseHeadersItem = ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem;
export type ScansHarResponseLogEntriesItemResponseHeadersList = Array<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export interface ScansHarResponseLogEntriesItemResponse {
    transferSize: number;
    bodySize: number;
    content: ScansHarResponseLogEntriesItemResponseContent;
    headers: ScansHarResponseLogEntriesItemResponseHeadersList;
    headersSize: number;
    httpVersion: string;
    redirectURL: string;
    status: number;
    statusText: string;
}
export interface ScansHarResponseLogEntriesItem {
    initialPriority: string;
    initiatorType: string;
    priority: string;
    requestId: string;
    requestTime: number;
    resourceType: string;
    cache: unknown;
    connection: string;
    pageref: string;
    request: ScansHarResponseLogEntriesItemRequest;
    response: ScansHarResponseLogEntriesItemResponse;
    serverIPAddress: string;
    startedDateTime: string;
    time: number;
}
export type ScansHarResponseLogEntriesList = Array<ScansHarResponseLogEntriesItem>;
export interface ScansHarResponseLogPagesItemPageTimings {
    onContentLoad: number;
    onLoad: number;
}
export interface ScansHarResponseLogPagesItem {
    id: string;
    pageTimings: ScansHarResponseLogPagesItemPageTimings;
    startedDateTime: string;
    title: string;
}
export type ScansHarResponseLogPagesList = Array<ScansHarResponseLogPagesItem>;
export interface ScansHarResponseLog {
    creator: ScansHarResponseLogCreator;
    entries: ScansHarResponseLogEntriesList;
    pages: ScansHarResponseLogPagesList;
    version: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface HarScanResponse {
    log: ScansHarResponseLog;
}
export interface ListScansRequest {
    /** Account ID. */
    accountId: string;
    /** Filter scans */
    q?: string;
    /** Limit the number of objects in the response. */
    size?: number;
}
export interface ScansListResponseResultsItemPage {
    asn: string;
    country: string;
    ip: string;
    url: string;
}
export interface ScansListResponseResultsItemStats {
    dataLength: number;
    requests: number;
    uniqCountries: number;
    uniqIPs: number;
}
export interface ScansListResponseResultsItemTask {
    time: string;
    url: string;
    uuid: string;
    visibility: string;
}
export interface ScansListResponseResultsItemVerdicts {
    malicious: boolean;
}
export interface ScansListResponseResultsItem {
    id: string;
    page: ScansListResponseResultsItemPage;
    result: string;
    stats: ScansListResponseResultsItemStats;
    task: ScansListResponseResultsItemTask;
    verdicts: ScansListResponseResultsItemVerdicts;
}
export type ScansListResponseResultsList = Array<ScansListResponseResultsItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListScansResponse {
    results: ScansListResponseResultsList;
}
export type ScansScreenshotRequestResolution = "desktop" | "mobile" | "tablet";
export interface ScreenshotScanRequest {
    /** Account ID. */
    accountId: string;
    /** Scan UUID. */
    scanId: string;
    /** Target device type. */
    resolution?: ScansScreenshotRequestResolution | (string & {});
}
export interface ScreenshotScanResponse {
}
export type BulkCreateScansError = CloudflareOpError;
/** Submit URLs to scan. Check limits at https://developers.cloudflare.com/security-center/investigate/scan-limits/ and take into account scans submitted in bulk have lower priority and may take longer to finish. */
export declare const bulkCreateScans: API.OperationMethod<BulkCreateScansRequest, BulkCreateScansResponse, BulkCreateScansError, CloudflareOpContext>;
export type CreateScanError = CloudflareOpError;
/** Submit a URL to scan. Check limits at https://developers.cloudflare.com/security-center/investigate/scan-limits/. */
export declare const createScan: API.OperationMethod<CreateScanRequest, CreateScanResponse, CreateScanError, CloudflareOpContext>;
export type DomScanError = CloudflareOpError;
/** Returns a plain text response, with the scan's DOM content as rendered by Chrome. */
export declare const domScan: API.OperationMethod<DomScanRequest, DomScanResponse, DomScanError, CloudflareOpContext>;
export type GetResponsError = CloudflareOpError;
/** Returns the raw response of the network request. Find the `response_id` in the `data.requests.response.hash`. */
export declare const getRespons: API.OperationMethod<GetResponsRequest, GetResponsResponse, GetResponsError, CloudflareOpContext>;
export type GetScanError = CloudflareOpError;
/** Get URL scan by uuid */
export declare const getScan: API.OperationMethod<GetScanRequest, GetScanResponse, GetScanError, CloudflareOpContext>;
export type HarScanError = CloudflareOpError;
/** Get a URL scan's HAR file. See HAR spec at http://www.softwareishard.com/blog/har-12-spec/. */
export declare const harScan: API.OperationMethod<HarScanRequest, HarScanResponse, HarScanError, CloudflareOpContext>;
export type ListScansError = CloudflareOpError;
/** Use a subset of ElasticSearch Query syntax to filter scans. Some example queries: - 'path:"/bundles/jquery.js"': Searches for scans who requested resources with the given path. - 'page.asn:AS24940 AND hash:xxx': Websites hosted in AS24940 where a resource with the given hash was downloaded. - 'page.domain:microsoft* AND verdicts.malicious:true AND NOT page.domain:microsoft.com': malicious scans whose hostname starts with "microsoft". - 'apikey:me AND date:[2025-01 TO 2025-02]': my scans from 2025 January to 2025 February. */
export declare const listScans: API.OperationMethod<ListScansRequest, ListScansResponse, ListScansError, CloudflareOpContext>;
export type ScreenshotScanError = CloudflareOpError;
/** Get scan's screenshot by resolution (desktop/mobile/tablet). */
export declare const screenshotScan: API.OperationMethod<ScreenshotScanRequest, ScreenshotScanResponse, ScreenshotScanError, CloudflareOpContext>;
//# sourceMappingURL=url_scanner.d.ts.map