import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const TagPreconditionFailed_base: S.TaggedErrorClass<"TagPreconditionFailed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TagPreconditionFailed extends /*@__PURE__*/ TagPreconditionFailed_base {
}
declare const ZoneTagResourceNotFound_base: S.TaggedErrorClass<"ZoneTagResourceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ZoneTagResourceNotFound extends /*@__PURE__*/ ZoneTagResourceNotFound_base {
}
export interface DeleteAccountTagRequest {
    /** Identifier. */
    accountId: string;
    ifMatch?: string;
    /** Identifier of the resource to remove tags from. */
    resourceId?: string;
    /** Type of the resource to remove tags from. */
    resourceType?: string;
    /** Identifier of the Worker to remove tags from. */
    workerId?: string;
}
export interface DeleteAccountTagResponse {
}
export interface DeleteZoneTagRequest {
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    ifMatch?: string;
    /** Identifier of the resource to remove tags from. */
    resourceId?: string;
    /** Type of the resource to remove tags from. */
    resourceType?: string;
    /** Identifier of the Access application to remove tags from. */
    accessApplicationId?: string;
}
export interface DeleteZoneTagResponse {
}
export type AccountTagsGetRequestResourceType = "access_application" | "access_group" | "access_service_token" | "account" | "account_ruleset" | "ai_gateway" | "ai_search_instance" | "alerting_policy" | "alerting_webhook" | "cloudflared_tunnel" | "cws_deployment" | "cws_policy" | "cws_policy_set" | "cws_workload" | "d1_database" | "device" | "durable_object_namespace" | "gateway_list" | "gateway_rule" | "image" | "infrastructure_target" | "kv_namespace" | "load_balancer_monitor" | "load_balancer_pool" | "namespace_worker" | "pages_project" | "queue" | "r2_bucket" | "resource_share" | "stream_live_input" | "stream_video" | "vectorize_index" | "worker" | "worker_version";
export interface GetAccountTagRequest {
    /** Identifier. */
    accountId: string;
    /** The ID of the resource to retrieve tags for. */
    resourceId: string;
    /** The type of the resource. */
    resourceType: AccountTagsGetRequestResourceType | (string & {});
    /** Worker identifier. Required for worker_version resources. */
    workerId?: string;
}
export type AccountTagsGetResultAccessApplicationTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultAccessApplicationType = "access_application";
export interface AccountTagsGetResultAccessApplication {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultAccessApplicationTagsMap;
    type: AccountTagsGetResultAccessApplicationType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultAccessApplicationPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultAccessApplicationPolicyType = "access_application_policy";
export interface AccountTagsGetResultAccessApplicationPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** Access application ID is required only for access_application_policy resources */
    accessApplicationId: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultAccessApplicationPolicyTagsMap;
    type: AccountTagsGetResultAccessApplicationPolicyType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultAccessGroupTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultAccessGroupType = "access_group";
export interface AccountTagsGetResultAccessGroup {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultAccessGroupTagsMap;
    type: AccountTagsGetResultAccessGroupType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultAccessServiceTokenTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultAccessServiceTokenType = "access_service_token";
export interface AccountTagsGetResultAccessServiceToken {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultAccessServiceTokenTagsMap;
    type: AccountTagsGetResultAccessServiceTokenType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultAccountTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultAccountType = "account";
export interface AccountTagsGetResultAccount {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultAccountTagsMap;
    type: AccountTagsGetResultAccountType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultAccountRulesetTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultAccountRulesetType = "account_ruleset";
export interface AccountTagsGetResultAccountRuleset {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultAccountRulesetTagsMap;
    type: AccountTagsGetResultAccountRulesetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultAIGatewayTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultAIGatewayType = "ai_gateway";
export interface AccountTagsGetResultAIGateway {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultAIGatewayTagsMap;
    type: AccountTagsGetResultAIGatewayType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultAISearchInstanceTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultAISearchInstanceType = "ai_search_instance";
export interface AccountTagsGetResultAISearchInstance {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultAISearchInstanceTagsMap;
    type: AccountTagsGetResultAISearchInstanceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultAlertingPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultAlertingPolicyType = "alerting_policy";
export interface AccountTagsGetResultAlertingPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultAlertingPolicyTagsMap;
    type: AccountTagsGetResultAlertingPolicyType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultAlertingWebhookTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultAlertingWebhookType = "alerting_webhook";
export interface AccountTagsGetResultAlertingWebhook {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultAlertingWebhookTagsMap;
    type: AccountTagsGetResultAlertingWebhookType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultAPIGatewayOperationTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultAPIGatewayOperationType = "api_gateway_operation";
export interface AccountTagsGetResultAPIGatewayOperation {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultAPIGatewayOperationTagsMap;
    type: AccountTagsGetResultAPIGatewayOperationType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultCloudflaredTunnelTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultCloudflaredTunnelType = "cloudflared_tunnel";
export interface AccountTagsGetResultCloudflaredTunnel {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultCloudflaredTunnelTagsMap;
    type: AccountTagsGetResultCloudflaredTunnelType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultCustomCertificateTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultCustomCertificateType = "custom_certificate";
export interface AccountTagsGetResultCustomCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultCustomCertificateTagsMap;
    type: AccountTagsGetResultCustomCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultCustomHostnameTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultCustomHostnameType = "custom_hostname";
export interface AccountTagsGetResultCustomHostname {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultCustomHostnameTagsMap;
    type: AccountTagsGetResultCustomHostnameType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultCWSDeploymentTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultCWSDeploymentType = "cws_deployment";
export interface AccountTagsGetResultCWSDeployment {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultCWSDeploymentTagsMap;
    type: AccountTagsGetResultCWSDeploymentType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultCWSPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultCWSPolicyType = "cws_policy";
export interface AccountTagsGetResultCWSPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultCWSPolicyTagsMap;
    type: AccountTagsGetResultCWSPolicyType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultCWSPolicySetTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultCWSPolicySetType = "cws_policy_set";
export interface AccountTagsGetResultCWSPolicySet {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultCWSPolicySetTagsMap;
    type: AccountTagsGetResultCWSPolicySetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultCWSWorkloadTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultCWSWorkloadType = "cws_workload";
export interface AccountTagsGetResultCWSWorkload {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultCWSWorkloadTagsMap;
    type: AccountTagsGetResultCWSWorkloadType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultD1DatabaseTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultD1DatabaseType = "d1_database";
export interface AccountTagsGetResultD1Database {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultD1DatabaseTagsMap;
    type: AccountTagsGetResultD1DatabaseType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultDeviceTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultDeviceType = "device";
export interface AccountTagsGetResultDevice {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultDeviceTagsMap;
    type: AccountTagsGetResultDeviceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultDNSRecordTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultDNSRecordType = "dns_record";
export interface AccountTagsGetResultDNSRecord {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultDNSRecordTagsMap;
    type: AccountTagsGetResultDNSRecordType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultDurableObjectNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultDurableObjectNamespaceType = "durable_object_namespace";
export interface AccountTagsGetResultDurableObjectNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultDurableObjectNamespaceTagsMap;
    type: AccountTagsGetResultDurableObjectNamespaceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultGatewayListTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultGatewayListType = "gateway_list";
export interface AccountTagsGetResultGatewayList {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultGatewayListTagsMap;
    type: AccountTagsGetResultGatewayListType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultGatewayRuleTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultGatewayRuleType = "gateway_rule";
export interface AccountTagsGetResultGatewayRule {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultGatewayRuleTagsMap;
    type: AccountTagsGetResultGatewayRuleType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultHealthcheckTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultHealthcheckType = "healthcheck";
export interface AccountTagsGetResultHealthcheck {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultHealthcheckTagsMap;
    type: AccountTagsGetResultHealthcheckType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultImageTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultImageType = "image";
export interface AccountTagsGetResultImage {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultImageTagsMap;
    type: AccountTagsGetResultImageType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultInfrastructureTargetTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultInfrastructureTargetType = "infrastructure_target";
export interface AccountTagsGetResultInfrastructureTarget {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultInfrastructureTargetTagsMap;
    type: AccountTagsGetResultInfrastructureTargetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultKVNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultKVNamespaceType = "kv_namespace";
export interface AccountTagsGetResultKVNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultKVNamespaceTagsMap;
    type: AccountTagsGetResultKVNamespaceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultLoadBalancerTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultLoadBalancerType = "load_balancer";
export interface AccountTagsGetResultLoadBalancer {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultLoadBalancerTagsMap;
    type: AccountTagsGetResultLoadBalancerType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultLoadBalancerMonitorTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultLoadBalancerMonitorType = "load_balancer_monitor";
export interface AccountTagsGetResultLoadBalancerMonitor {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultLoadBalancerMonitorTagsMap;
    type: AccountTagsGetResultLoadBalancerMonitorType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultLoadBalancerPoolTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultLoadBalancerPoolType = "load_balancer_pool";
export interface AccountTagsGetResultLoadBalancerPool {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultLoadBalancerPoolTagsMap;
    type: AccountTagsGetResultLoadBalancerPoolType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultManagedClientCertificateTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultManagedClientCertificateType = "managed_client_certificate";
export interface AccountTagsGetResultManagedClientCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultManagedClientCertificateTagsMap;
    type: AccountTagsGetResultManagedClientCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultNamespaceWorkerTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultNamespaceWorkerType = "namespace_worker";
export interface AccountTagsGetResultNamespaceWorkerNavigation {
    namespaceId: string;
    namespaceName: string;
    scriptName: string;
}
export interface AccountTagsGetResultNamespaceWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultNamespaceWorkerTagsMap;
    type: AccountTagsGetResultNamespaceWorkerType;
    /** Read-only routing metadata resolved from EWC using the account and immutable namespace Worker ID. Returned only by tagged-resource lists requested with include_navigation=true. Omitted when lookup is unavailable or the child has been deleted. Never supplied on tag writes or stored as extra_data. */
    navigation?: AccountTagsGetResultNamespaceWorkerNavigation | null;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultPagesProjectTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultPagesProjectType = "pages_project";
export interface AccountTagsGetResultPagesProject {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultPagesProjectTagsMap;
    type: AccountTagsGetResultPagesProjectType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultQueueTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultQueueType = "queue";
export interface AccountTagsGetResultQueue {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultQueueTagsMap;
    type: AccountTagsGetResultQueueType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultR2BucketTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultR2BucketType = "r2_bucket";
export interface AccountTagsGetResultR2Bucket {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultR2BucketTagsMap;
    type: AccountTagsGetResultR2BucketType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultResourceShareTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultResourceShareType = "resource_share";
export interface AccountTagsGetResultResourceShare {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultResourceShareTagsMap;
    type: AccountTagsGetResultResourceShareType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultStreamLiveInputTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultStreamLiveInputType = "stream_live_input";
export interface AccountTagsGetResultStreamLiveInput {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultStreamLiveInputTagsMap;
    type: AccountTagsGetResultStreamLiveInputType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultStreamVideoTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultStreamVideoType = "stream_video";
export interface AccountTagsGetResultStreamVideo {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultStreamVideoTagsMap;
    type: AccountTagsGetResultStreamVideoType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultVectorizeIndexTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultVectorizeIndexType = "vectorize_index";
export interface AccountTagsGetResultVectorizeIndex {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultVectorizeIndexTagsMap;
    type: AccountTagsGetResultVectorizeIndexType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultWorkerTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultWorkerType = "worker";
export interface AccountTagsGetResultWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultWorkerTagsMap;
    type: AccountTagsGetResultWorkerType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultWorkerRouteTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultWorkerRouteType = "worker_route";
export interface AccountTagsGetResultWorkerRoute {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultWorkerRouteTagsMap;
    type: AccountTagsGetResultWorkerRouteType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultWorkerVersionTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultWorkerVersionType = "worker_version";
export interface AccountTagsGetResultWorkerVersion {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultWorkerVersionTagsMap;
    type: AccountTagsGetResultWorkerVersionType;
    /** Worker ID is required only for worker_version resources */
    workerId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultZoneTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultZoneType = "zone";
export interface AccountTagsGetResultZone {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultZoneTagsMap;
    type: AccountTagsGetResultZoneType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResultZoneRulesetTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsGetResultZoneRulesetType = "zone_ruleset";
export interface AccountTagsGetResultZoneRuleset {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsGetResultZoneRulesetTagsMap;
    type: AccountTagsGetResultZoneRulesetType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsGetResult = AccountTagsGetResultAccessApplication | AccountTagsGetResultAccessApplicationPolicy | AccountTagsGetResultAccessGroup | AccountTagsGetResultAccessServiceToken | AccountTagsGetResultAccount | AccountTagsGetResultAccountRuleset | AccountTagsGetResultAIGateway | AccountTagsGetResultAISearchInstance | AccountTagsGetResultAlertingPolicy | AccountTagsGetResultAlertingWebhook | AccountTagsGetResultAPIGatewayOperation | AccountTagsGetResultCloudflaredTunnel | AccountTagsGetResultCustomCertificate | AccountTagsGetResultCustomHostname | AccountTagsGetResultCWSDeployment | AccountTagsGetResultCWSPolicy | AccountTagsGetResultCWSPolicySet | AccountTagsGetResultCWSWorkload | AccountTagsGetResultD1Database | AccountTagsGetResultDevice | AccountTagsGetResultDNSRecord | AccountTagsGetResultDurableObjectNamespace | AccountTagsGetResultGatewayList | AccountTagsGetResultGatewayRule | AccountTagsGetResultHealthcheck | AccountTagsGetResultImage | AccountTagsGetResultInfrastructureTarget | AccountTagsGetResultKVNamespace | AccountTagsGetResultLoadBalancer | AccountTagsGetResultLoadBalancerMonitor | AccountTagsGetResultLoadBalancerPool | AccountTagsGetResultManagedClientCertificate | AccountTagsGetResultNamespaceWorker | AccountTagsGetResultPagesProject | AccountTagsGetResultQueue | AccountTagsGetResultR2Bucket | AccountTagsGetResultResourceShare | AccountTagsGetResultStreamLiveInput | AccountTagsGetResultStreamVideo | AccountTagsGetResultVectorizeIndex | AccountTagsGetResultWorker | AccountTagsGetResultWorkerRoute | AccountTagsGetResultWorkerVersion | AccountTagsGetResultZone | AccountTagsGetResultZoneRuleset;
export type GetAccountTagResponse = AccountTagsGetResult;
export interface GetSummaryRequest {
    /** Identifier. */
    accountId: string;
    /** Cursor for pagination. */
    cursor?: string;
}
export type GetSummaryResultItemValuesList = Array<string>;
export interface GetSummaryResultItem {
    /** A tag key. */
    key: string;
    /** All distinct values for this tag key. */
    values: GetSummaryResultItemValuesList;
}
export type GetSummaryResultList = Array<GetSummaryResultItem>;
export type GetSummaryResponse = GetSummaryResultList;
export type ZoneTagsGetRequestResourceType = "access_application_policy" | "api_gateway_operation" | "custom_certificate" | "custom_hostname" | "dns_record" | "healthcheck" | "load_balancer" | "managed_client_certificate" | "worker_route" | "zone" | "zone_ruleset";
export interface GetZoneTagRequest {
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** The ID of the resource to retrieve tags for. */
    resourceId: string;
    /** The type of the resource. */
    resourceType: ZoneTagsGetRequestResourceType | (string & {});
    /** Access application ID identifier. Required for access_application_policy resources. */
    accessApplicationId?: string;
}
export type ZoneTagsGetResultAccessApplicationTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultAccessApplicationType = "access_application";
export interface ZoneTagsGetResultAccessApplication {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultAccessApplicationTagsMap;
    type: ZoneTagsGetResultAccessApplicationType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultAccessApplicationPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultAccessApplicationPolicyType = "access_application_policy";
export interface ZoneTagsGetResultAccessApplicationPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** Access application ID is required only for access_application_policy resources */
    accessApplicationId: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultAccessApplicationPolicyTagsMap;
    type: ZoneTagsGetResultAccessApplicationPolicyType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultAccessGroupTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultAccessGroupType = "access_group";
export interface ZoneTagsGetResultAccessGroup {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultAccessGroupTagsMap;
    type: ZoneTagsGetResultAccessGroupType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultAccessServiceTokenTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultAccessServiceTokenType = "access_service_token";
export interface ZoneTagsGetResultAccessServiceToken {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultAccessServiceTokenTagsMap;
    type: ZoneTagsGetResultAccessServiceTokenType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultAccountTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultAccountType = "account";
export interface ZoneTagsGetResultAccount {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultAccountTagsMap;
    type: ZoneTagsGetResultAccountType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultAccountRulesetTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultAccountRulesetType = "account_ruleset";
export interface ZoneTagsGetResultAccountRuleset {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultAccountRulesetTagsMap;
    type: ZoneTagsGetResultAccountRulesetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultAIGatewayTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultAIGatewayType = "ai_gateway";
export interface ZoneTagsGetResultAIGateway {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultAIGatewayTagsMap;
    type: ZoneTagsGetResultAIGatewayType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultAISearchInstanceTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultAISearchInstanceType = "ai_search_instance";
export interface ZoneTagsGetResultAISearchInstance {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultAISearchInstanceTagsMap;
    type: ZoneTagsGetResultAISearchInstanceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultAlertingPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultAlertingPolicyType = "alerting_policy";
export interface ZoneTagsGetResultAlertingPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultAlertingPolicyTagsMap;
    type: ZoneTagsGetResultAlertingPolicyType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultAlertingWebhookTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultAlertingWebhookType = "alerting_webhook";
export interface ZoneTagsGetResultAlertingWebhook {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultAlertingWebhookTagsMap;
    type: ZoneTagsGetResultAlertingWebhookType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultAPIGatewayOperationTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultAPIGatewayOperationType = "api_gateway_operation";
export interface ZoneTagsGetResultAPIGatewayOperation {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultAPIGatewayOperationTagsMap;
    type: ZoneTagsGetResultAPIGatewayOperationType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultCloudflaredTunnelTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultCloudflaredTunnelType = "cloudflared_tunnel";
export interface ZoneTagsGetResultCloudflaredTunnel {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultCloudflaredTunnelTagsMap;
    type: ZoneTagsGetResultCloudflaredTunnelType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultCustomCertificateTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultCustomCertificateType = "custom_certificate";
export interface ZoneTagsGetResultCustomCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultCustomCertificateTagsMap;
    type: ZoneTagsGetResultCustomCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultCustomHostnameTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultCustomHostnameType = "custom_hostname";
export interface ZoneTagsGetResultCustomHostname {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultCustomHostnameTagsMap;
    type: ZoneTagsGetResultCustomHostnameType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultCWSDeploymentTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultCWSDeploymentType = "cws_deployment";
export interface ZoneTagsGetResultCWSDeployment {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultCWSDeploymentTagsMap;
    type: ZoneTagsGetResultCWSDeploymentType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultCWSPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultCWSPolicyType = "cws_policy";
export interface ZoneTagsGetResultCWSPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultCWSPolicyTagsMap;
    type: ZoneTagsGetResultCWSPolicyType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultCWSPolicySetTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultCWSPolicySetType = "cws_policy_set";
export interface ZoneTagsGetResultCWSPolicySet {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultCWSPolicySetTagsMap;
    type: ZoneTagsGetResultCWSPolicySetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultCWSWorkloadTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultCWSWorkloadType = "cws_workload";
export interface ZoneTagsGetResultCWSWorkload {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultCWSWorkloadTagsMap;
    type: ZoneTagsGetResultCWSWorkloadType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultD1DatabaseTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultD1DatabaseType = "d1_database";
export interface ZoneTagsGetResultD1Database {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultD1DatabaseTagsMap;
    type: ZoneTagsGetResultD1DatabaseType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultDeviceTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultDeviceType = "device";
export interface ZoneTagsGetResultDevice {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultDeviceTagsMap;
    type: ZoneTagsGetResultDeviceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultDNSRecordTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultDNSRecordType = "dns_record";
export interface ZoneTagsGetResultDNSRecord {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultDNSRecordTagsMap;
    type: ZoneTagsGetResultDNSRecordType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultDurableObjectNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultDurableObjectNamespaceType = "durable_object_namespace";
export interface ZoneTagsGetResultDurableObjectNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultDurableObjectNamespaceTagsMap;
    type: ZoneTagsGetResultDurableObjectNamespaceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultGatewayListTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultGatewayListType = "gateway_list";
export interface ZoneTagsGetResultGatewayList {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultGatewayListTagsMap;
    type: ZoneTagsGetResultGatewayListType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultGatewayRuleTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultGatewayRuleType = "gateway_rule";
export interface ZoneTagsGetResultGatewayRule {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultGatewayRuleTagsMap;
    type: ZoneTagsGetResultGatewayRuleType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultHealthcheckTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultHealthcheckType = "healthcheck";
export interface ZoneTagsGetResultHealthcheck {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultHealthcheckTagsMap;
    type: ZoneTagsGetResultHealthcheckType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultImageTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultImageType = "image";
export interface ZoneTagsGetResultImage {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultImageTagsMap;
    type: ZoneTagsGetResultImageType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultInfrastructureTargetTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultInfrastructureTargetType = "infrastructure_target";
export interface ZoneTagsGetResultInfrastructureTarget {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultInfrastructureTargetTagsMap;
    type: ZoneTagsGetResultInfrastructureTargetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultKVNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultKVNamespaceType = "kv_namespace";
export interface ZoneTagsGetResultKVNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultKVNamespaceTagsMap;
    type: ZoneTagsGetResultKVNamespaceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultLoadBalancerTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultLoadBalancerType = "load_balancer";
export interface ZoneTagsGetResultLoadBalancer {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultLoadBalancerTagsMap;
    type: ZoneTagsGetResultLoadBalancerType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultLoadBalancerMonitorTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultLoadBalancerMonitorType = "load_balancer_monitor";
export interface ZoneTagsGetResultLoadBalancerMonitor {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultLoadBalancerMonitorTagsMap;
    type: ZoneTagsGetResultLoadBalancerMonitorType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultLoadBalancerPoolTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultLoadBalancerPoolType = "load_balancer_pool";
export interface ZoneTagsGetResultLoadBalancerPool {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultLoadBalancerPoolTagsMap;
    type: ZoneTagsGetResultLoadBalancerPoolType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultManagedClientCertificateTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultManagedClientCertificateType = "managed_client_certificate";
export interface ZoneTagsGetResultManagedClientCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultManagedClientCertificateTagsMap;
    type: ZoneTagsGetResultManagedClientCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultNamespaceWorkerTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultNamespaceWorkerType = "namespace_worker";
export type ZoneTagsGetResultNamespaceWorkerNavigation = AccountTagsGetResultNamespaceWorkerNavigation;
export interface ZoneTagsGetResultNamespaceWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultNamespaceWorkerTagsMap;
    type: ZoneTagsGetResultNamespaceWorkerType;
    /** Read-only routing metadata resolved from EWC using the account and immutable namespace Worker ID. Returned only by tagged-resource lists requested with include_navigation=true. Omitted when lookup is unavailable or the child has been deleted. Never supplied on tag writes or stored as extra_data. */
    navigation?: AccountTagsGetResultNamespaceWorkerNavigation | null;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultPagesProjectTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultPagesProjectType = "pages_project";
export interface ZoneTagsGetResultPagesProject {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultPagesProjectTagsMap;
    type: ZoneTagsGetResultPagesProjectType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultQueueTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultQueueType = "queue";
export interface ZoneTagsGetResultQueue {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultQueueTagsMap;
    type: ZoneTagsGetResultQueueType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultR2BucketTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultR2BucketType = "r2_bucket";
export interface ZoneTagsGetResultR2Bucket {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultR2BucketTagsMap;
    type: ZoneTagsGetResultR2BucketType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultResourceShareTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultResourceShareType = "resource_share";
export interface ZoneTagsGetResultResourceShare {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultResourceShareTagsMap;
    type: ZoneTagsGetResultResourceShareType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultStreamLiveInputTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultStreamLiveInputType = "stream_live_input";
export interface ZoneTagsGetResultStreamLiveInput {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultStreamLiveInputTagsMap;
    type: ZoneTagsGetResultStreamLiveInputType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultStreamVideoTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultStreamVideoType = "stream_video";
export interface ZoneTagsGetResultStreamVideo {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultStreamVideoTagsMap;
    type: ZoneTagsGetResultStreamVideoType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultVectorizeIndexTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultVectorizeIndexType = "vectorize_index";
export interface ZoneTagsGetResultVectorizeIndex {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultVectorizeIndexTagsMap;
    type: ZoneTagsGetResultVectorizeIndexType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultWorkerTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultWorkerType = "worker";
export interface ZoneTagsGetResultWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultWorkerTagsMap;
    type: ZoneTagsGetResultWorkerType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultWorkerRouteTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultWorkerRouteType = "worker_route";
export interface ZoneTagsGetResultWorkerRoute {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultWorkerRouteTagsMap;
    type: ZoneTagsGetResultWorkerRouteType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultWorkerVersionTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultWorkerVersionType = "worker_version";
export interface ZoneTagsGetResultWorkerVersion {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultWorkerVersionTagsMap;
    type: ZoneTagsGetResultWorkerVersionType;
    /** Worker ID is required only for worker_version resources */
    workerId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultZoneTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultZoneType = "zone";
export interface ZoneTagsGetResultZone {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultZoneTagsMap;
    type: ZoneTagsGetResultZoneType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResultZoneRulesetTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsGetResultZoneRulesetType = "zone_ruleset";
export interface ZoneTagsGetResultZoneRuleset {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsGetResultZoneRulesetTagsMap;
    type: ZoneTagsGetResultZoneRulesetType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsGetResult = ZoneTagsGetResultAccessApplication | ZoneTagsGetResultAccessApplicationPolicy | ZoneTagsGetResultAccessGroup | ZoneTagsGetResultAccessServiceToken | ZoneTagsGetResultAccount | ZoneTagsGetResultAccountRuleset | ZoneTagsGetResultAIGateway | ZoneTagsGetResultAISearchInstance | ZoneTagsGetResultAlertingPolicy | ZoneTagsGetResultAlertingWebhook | ZoneTagsGetResultAPIGatewayOperation | ZoneTagsGetResultCloudflaredTunnel | ZoneTagsGetResultCustomCertificate | ZoneTagsGetResultCustomHostname | ZoneTagsGetResultCWSDeployment | ZoneTagsGetResultCWSPolicy | ZoneTagsGetResultCWSPolicySet | ZoneTagsGetResultCWSWorkload | ZoneTagsGetResultD1Database | ZoneTagsGetResultDevice | ZoneTagsGetResultDNSRecord | ZoneTagsGetResultDurableObjectNamespace | ZoneTagsGetResultGatewayList | ZoneTagsGetResultGatewayRule | ZoneTagsGetResultHealthcheck | ZoneTagsGetResultImage | ZoneTagsGetResultInfrastructureTarget | ZoneTagsGetResultKVNamespace | ZoneTagsGetResultLoadBalancer | ZoneTagsGetResultLoadBalancerMonitor | ZoneTagsGetResultLoadBalancerPool | ZoneTagsGetResultManagedClientCertificate | ZoneTagsGetResultNamespaceWorker | ZoneTagsGetResultPagesProject | ZoneTagsGetResultQueue | ZoneTagsGetResultR2Bucket | ZoneTagsGetResultResourceShare | ZoneTagsGetResultStreamLiveInput | ZoneTagsGetResultStreamVideo | ZoneTagsGetResultVectorizeIndex | ZoneTagsGetResultWorker | ZoneTagsGetResultWorkerRoute | ZoneTagsGetResultWorkerVersion | ZoneTagsGetResultZone | ZoneTagsGetResultZoneRuleset;
export type GetZoneTagResponse = ZoneTagsGetResult;
export interface ListKeysRequest {
    /** Identifier. */
    accountId: string;
    /** Cursor for pagination. */
    cursor?: string;
}
export type KeysListResultList = Array<string>;
export interface ListKeysResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: KeysListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ListRequestIdList = Array<string>;
export type ListRequestTagList = Array<string>;
export type ListRequestType = "access_application" | "access_application_policy" | "access_group" | "access_service_token" | "account" | "account_ruleset" | "ai_gateway" | "ai_search_instance" | "alerting_policy" | "alerting_webhook" | "api_gateway_operation" | "cloudflared_tunnel" | "custom_certificate" | "custom_hostname" | "cws_deployment" | "cws_policy" | "cws_policy_set" | "cws_workload" | "d1_database" | "device" | "dns_record" | "durable_object_namespace" | "gateway_list" | "gateway_rule" | "healthcheck" | "image" | "infrastructure_target" | "kv_namespace" | "load_balancer" | "load_balancer_monitor" | "load_balancer_pool" | "managed_client_certificate" | "namespace_worker" | "pages_project" | "queue" | "r2_bucket" | "resource_share" | "stream_live_input" | "stream_video" | "vectorize_index" | "worker" | "worker_route" | "worker_version" | "zone" | "zone_ruleset";
export type ListRequestTypeList = Array<ListRequestType | (string & {})>;
export interface ListResourceTaggingsRequest {
    /** Identifier. */
    accountId: string;
    /** Filter by resource ID. Can be repeated up to 50 times to filter by multiple IDs. Example: ?id=abc&id=def */
    id?: ListRequestIdList;
    /** Match `tag` keys and values case-insensitively. Stored casing is unchanged. Example: ?tag=environment=production&case_insensitive=true */
    caseInsensitive?: boolean;
    /** Cursor for pagination. */
    cursor?: string;
    /** Resolve current namespace Worker navigation by immutable child tag. Optional read-only navigation is omitted for deleted or unresolved children. Lookups are limited to this page, at most five concurrently, with a shared two-second budget. Tag identity, ETag, filters and pagination are unchanged; name filtering still uses the stored resource name. Defaults to false. */
    includeNavigation?: boolean;
    /** Filter by resource name. Performs a case-insensitive substring match. Example: ?name=my-zone */
    name?: string;
    /** Filter resources by tag criteria. This parameter can be repeated multiple times, with AND logic between parameters. */
    tag?: ListRequestTagList;
    /** Filter by resource type. Can be repeated to filter by multiple types (OR logic). Example: ?type=zone&amp;type=worker */
    type?: ListRequestTypeList;
}
export type ListResultItemAccessApplicationTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemAccessApplicationType = "access_application";
export interface ListResultItemAccessApplication {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemAccessApplicationTagsMap;
    type: ListResultItemAccessApplicationType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemAccessApplicationPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemAccessApplicationPolicyType = "access_application_policy";
export interface ListResultItemAccessApplicationPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** Access application ID is required only for access_application_policy resources */
    accessApplicationId: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemAccessApplicationPolicyTagsMap;
    type: ListResultItemAccessApplicationPolicyType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemAccessGroupTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemAccessGroupType = "access_group";
export interface ListResultItemAccessGroup {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemAccessGroupTagsMap;
    type: ListResultItemAccessGroupType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemAccessServiceTokenTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemAccessServiceTokenType = "access_service_token";
export interface ListResultItemAccessServiceToken {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemAccessServiceTokenTagsMap;
    type: ListResultItemAccessServiceTokenType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemAccountTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemAccountType = "account";
export interface ListResultItemAccount {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemAccountTagsMap;
    type: ListResultItemAccountType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemAccountRulesetTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemAccountRulesetType = "account_ruleset";
export interface ListResultItemAccountRuleset {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemAccountRulesetTagsMap;
    type: ListResultItemAccountRulesetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemAIGatewayTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemAIGatewayType = "ai_gateway";
export interface ListResultItemAIGateway {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemAIGatewayTagsMap;
    type: ListResultItemAIGatewayType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemAISearchInstanceTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemAISearchInstanceType = "ai_search_instance";
export interface ListResultItemAISearchInstance {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemAISearchInstanceTagsMap;
    type: ListResultItemAISearchInstanceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemAlertingPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemAlertingPolicyType = "alerting_policy";
export interface ListResultItemAlertingPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemAlertingPolicyTagsMap;
    type: ListResultItemAlertingPolicyType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemAlertingWebhookTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemAlertingWebhookType = "alerting_webhook";
export interface ListResultItemAlertingWebhook {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemAlertingWebhookTagsMap;
    type: ListResultItemAlertingWebhookType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemAPIGatewayOperationTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemAPIGatewayOperationType = "api_gateway_operation";
export interface ListResultItemAPIGatewayOperation {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemAPIGatewayOperationTagsMap;
    type: ListResultItemAPIGatewayOperationType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemCloudflaredTunnelTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemCloudflaredTunnelType = "cloudflared_tunnel";
export interface ListResultItemCloudflaredTunnel {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemCloudflaredTunnelTagsMap;
    type: ListResultItemCloudflaredTunnelType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemCustomCertificateTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemCustomCertificateType = "custom_certificate";
export interface ListResultItemCustomCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemCustomCertificateTagsMap;
    type: ListResultItemCustomCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemCustomHostnameTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemCustomHostnameType = "custom_hostname";
export interface ListResultItemCustomHostname {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemCustomHostnameTagsMap;
    type: ListResultItemCustomHostnameType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemCWSDeploymentTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemCWSDeploymentType = "cws_deployment";
export interface ListResultItemCWSDeployment {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemCWSDeploymentTagsMap;
    type: ListResultItemCWSDeploymentType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemCWSPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemCWSPolicyType = "cws_policy";
export interface ListResultItemCWSPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemCWSPolicyTagsMap;
    type: ListResultItemCWSPolicyType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemCWSPolicySetTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemCWSPolicySetType = "cws_policy_set";
export interface ListResultItemCWSPolicySet {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemCWSPolicySetTagsMap;
    type: ListResultItemCWSPolicySetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemCWSWorkloadTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemCWSWorkloadType = "cws_workload";
export interface ListResultItemCWSWorkload {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemCWSWorkloadTagsMap;
    type: ListResultItemCWSWorkloadType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemD1DatabaseTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemD1DatabaseType = "d1_database";
export interface ListResultItemD1Database {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemD1DatabaseTagsMap;
    type: ListResultItemD1DatabaseType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemDeviceTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemDeviceType = "device";
export interface ListResultItemDevice {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemDeviceTagsMap;
    type: ListResultItemDeviceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemDNSRecordTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemDNSRecordType = "dns_record";
export interface ListResultItemDNSRecord {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemDNSRecordTagsMap;
    type: ListResultItemDNSRecordType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemDurableObjectNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemDurableObjectNamespaceType = "durable_object_namespace";
export interface ListResultItemDurableObjectNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemDurableObjectNamespaceTagsMap;
    type: ListResultItemDurableObjectNamespaceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemGatewayListTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemGatewayListType = "gateway_list";
export interface ListResultItemGatewayList {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemGatewayListTagsMap;
    type: ListResultItemGatewayListType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemGatewayRuleTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemGatewayRuleType = "gateway_rule";
export interface ListResultItemGatewayRule {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemGatewayRuleTagsMap;
    type: ListResultItemGatewayRuleType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemHealthcheckTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemHealthcheckType = "healthcheck";
export interface ListResultItemHealthcheck {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemHealthcheckTagsMap;
    type: ListResultItemHealthcheckType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemImageTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemImageType = "image";
export interface ListResultItemImage {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemImageTagsMap;
    type: ListResultItemImageType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemInfrastructureTargetTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemInfrastructureTargetType = "infrastructure_target";
export interface ListResultItemInfrastructureTarget {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemInfrastructureTargetTagsMap;
    type: ListResultItemInfrastructureTargetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemKVNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemKVNamespaceType = "kv_namespace";
export interface ListResultItemKVNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemKVNamespaceTagsMap;
    type: ListResultItemKVNamespaceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemLoadBalancerTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemLoadBalancerType = "load_balancer";
export interface ListResultItemLoadBalancer {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemLoadBalancerTagsMap;
    type: ListResultItemLoadBalancerType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemLoadBalancerMonitorTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemLoadBalancerMonitorType = "load_balancer_monitor";
export interface ListResultItemLoadBalancerMonitor {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemLoadBalancerMonitorTagsMap;
    type: ListResultItemLoadBalancerMonitorType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemLoadBalancerPoolTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemLoadBalancerPoolType = "load_balancer_pool";
export interface ListResultItemLoadBalancerPool {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemLoadBalancerPoolTagsMap;
    type: ListResultItemLoadBalancerPoolType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemManagedClientCertificateTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemManagedClientCertificateType = "managed_client_certificate";
export interface ListResultItemManagedClientCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemManagedClientCertificateTagsMap;
    type: ListResultItemManagedClientCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemNamespaceWorkerTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemNamespaceWorkerType = "namespace_worker";
export type ListResultItemNamespaceWorkerNavigation = AccountTagsGetResultNamespaceWorkerNavigation;
export interface ListResultItemNamespaceWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemNamespaceWorkerTagsMap;
    type: ListResultItemNamespaceWorkerType;
    /** Read-only routing metadata resolved from EWC using the account and immutable namespace Worker ID. Returned only by tagged-resource lists requested with include_navigation=true. Omitted when lookup is unavailable or the child has been deleted. Never supplied on tag writes or stored as extra_data. */
    navigation?: AccountTagsGetResultNamespaceWorkerNavigation | null;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemPagesProjectTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemPagesProjectType = "pages_project";
export interface ListResultItemPagesProject {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemPagesProjectTagsMap;
    type: ListResultItemPagesProjectType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemQueueTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemQueueType = "queue";
export interface ListResultItemQueue {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemQueueTagsMap;
    type: ListResultItemQueueType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemR2BucketTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemR2BucketType = "r2_bucket";
export interface ListResultItemR2Bucket {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemR2BucketTagsMap;
    type: ListResultItemR2BucketType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemResourceShareTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemResourceShareType = "resource_share";
export interface ListResultItemResourceShare {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemResourceShareTagsMap;
    type: ListResultItemResourceShareType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemStreamLiveInputTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemStreamLiveInputType = "stream_live_input";
export interface ListResultItemStreamLiveInput {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemStreamLiveInputTagsMap;
    type: ListResultItemStreamLiveInputType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemStreamVideoTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemStreamVideoType = "stream_video";
export interface ListResultItemStreamVideo {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemStreamVideoTagsMap;
    type: ListResultItemStreamVideoType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemVectorizeIndexTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemVectorizeIndexType = "vectorize_index";
export interface ListResultItemVectorizeIndex {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemVectorizeIndexTagsMap;
    type: ListResultItemVectorizeIndexType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemWorkerTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemWorkerType = "worker";
export interface ListResultItemWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemWorkerTagsMap;
    type: ListResultItemWorkerType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemWorkerRouteTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemWorkerRouteType = "worker_route";
export interface ListResultItemWorkerRoute {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemWorkerRouteTagsMap;
    type: ListResultItemWorkerRouteType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemWorkerVersionTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemWorkerVersionType = "worker_version";
export interface ListResultItemWorkerVersion {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemWorkerVersionTagsMap;
    type: ListResultItemWorkerVersionType;
    /** Worker ID is required only for worker_version resources */
    workerId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemZoneTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemZoneType = "zone";
export interface ListResultItemZone {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemZoneTagsMap;
    type: ListResultItemZoneType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItemZoneRulesetTagsMap = {
    [key: string]: string | undefined;
};
export type ListResultItemZoneRulesetType = "zone_ruleset";
export interface ListResultItemZoneRuleset {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ListResultItemZoneRulesetTagsMap;
    type: ListResultItemZoneRulesetType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ListResultItem = ListResultItemAccessApplication | ListResultItemAccessApplicationPolicy | ListResultItemAccessGroup | ListResultItemAccessServiceToken | ListResultItemAccount | ListResultItemAccountRuleset | ListResultItemAIGateway | ListResultItemAISearchInstance | ListResultItemAlertingPolicy | ListResultItemAlertingWebhook | ListResultItemAPIGatewayOperation | ListResultItemCloudflaredTunnel | ListResultItemCustomCertificate | ListResultItemCustomHostname | ListResultItemCWSDeployment | ListResultItemCWSPolicy | ListResultItemCWSPolicySet | ListResultItemCWSWorkload | ListResultItemD1Database | ListResultItemDevice | ListResultItemDNSRecord | ListResultItemDurableObjectNamespace | ListResultItemGatewayList | ListResultItemGatewayRule | ListResultItemHealthcheck | ListResultItemImage | ListResultItemInfrastructureTarget | ListResultItemKVNamespace | ListResultItemLoadBalancer | ListResultItemLoadBalancerMonitor | ListResultItemLoadBalancerPool | ListResultItemManagedClientCertificate | ListResultItemNamespaceWorker | ListResultItemPagesProject | ListResultItemQueue | ListResultItemR2Bucket | ListResultItemResourceShare | ListResultItemStreamLiveInput | ListResultItemStreamVideo | ListResultItemVectorizeIndex | ListResultItemWorker | ListResultItemWorkerRoute | ListResultItemWorkerVersion | ListResultItemZone | ListResultItemZoneRuleset;
export type ListResultList = Array<ListResultItem>;
export interface ListResourceTaggingsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ValuesListRequestType = "access_application" | "access_application_policy" | "access_group" | "access_service_token" | "account" | "account_ruleset" | "ai_gateway" | "ai_search_instance" | "alerting_policy" | "alerting_webhook" | "api_gateway_operation" | "cloudflared_tunnel" | "custom_certificate" | "custom_hostname" | "cws_deployment" | "cws_policy" | "cws_policy_set" | "cws_workload" | "d1_database" | "device" | "dns_record" | "durable_object_namespace" | "gateway_list" | "gateway_rule" | "healthcheck" | "image" | "infrastructure_target" | "kv_namespace" | "load_balancer" | "load_balancer_monitor" | "load_balancer_pool" | "managed_client_certificate" | "namespace_worker" | "pages_project" | "queue" | "r2_bucket" | "resource_share" | "stream_live_input" | "stream_video" | "vectorize_index" | "worker" | "worker_route" | "worker_version" | "zone" | "zone_ruleset";
export interface ListValuesRequest {
    /** Identifier. */
    accountId: string;
    tagKey: string;
    /** Cursor for pagination. */
    cursor?: string;
    /** Filter by resource type. */
    type?: ValuesListRequestType | (string & {});
}
export type ValuesListResultList = Array<string>;
export interface ListValuesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ValuesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type AccountTagsUpdateRequestResourceType = "worker_version" | "access_application" | "access_group" | "access_service_token" | "account" | "account_ruleset" | "ai_gateway" | "ai_search_instance" | "alerting_policy" | "alerting_webhook" | "cloudflared_tunnel" | "cws_deployment" | "cws_policy" | "cws_policy_set" | "cws_workload" | "d1_database" | "device" | "durable_object_namespace" | "gateway_list" | "gateway_rule" | "image" | "infrastructure_target" | "kv_namespace" | "load_balancer_monitor" | "load_balancer_pool" | "namespace_worker" | "pages_project" | "queue" | "r2_bucket" | "resource_share" | "stream_live_input" | "stream_video" | "vectorize_index" | "worker";
export type AccountTagsUpdateRequestTagsMap = {
    [key: string]: string | undefined;
};
export interface PutAccountTagRequest {
    /** Identifier. */
    accountId: string;
    /** Identifies the unique resource. */
    resourceId: string;
    /** Enum for worker_version resource type. */
    resourceType: AccountTagsUpdateRequestResourceType | (string & {});
    /** Worker ID is required only for worker_version resources */
    workerId?: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags?: AccountTagsUpdateRequestTagsMap;
    ifMatch?: string;
}
export type AccountTagsUpdateResultAccessApplicationTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultAccessApplicationType = "access_application";
export interface AccountTagsUpdateResultAccessApplication {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultAccessApplicationTagsMap;
    type: AccountTagsUpdateResultAccessApplicationType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultAccessApplicationPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultAccessApplicationPolicyType = "access_application_policy";
export interface AccountTagsUpdateResultAccessApplicationPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** Access application ID is required only for access_application_policy resources */
    accessApplicationId: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultAccessApplicationPolicyTagsMap;
    type: AccountTagsUpdateResultAccessApplicationPolicyType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultAccessGroupTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultAccessGroupType = "access_group";
export interface AccountTagsUpdateResultAccessGroup {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultAccessGroupTagsMap;
    type: AccountTagsUpdateResultAccessGroupType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultAccessServiceTokenTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultAccessServiceTokenType = "access_service_token";
export interface AccountTagsUpdateResultAccessServiceToken {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultAccessServiceTokenTagsMap;
    type: AccountTagsUpdateResultAccessServiceTokenType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultAccountTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultAccountType = "account";
export interface AccountTagsUpdateResultAccount {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultAccountTagsMap;
    type: AccountTagsUpdateResultAccountType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultAccountRulesetTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultAccountRulesetType = "account_ruleset";
export interface AccountTagsUpdateResultAccountRuleset {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultAccountRulesetTagsMap;
    type: AccountTagsUpdateResultAccountRulesetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultAIGatewayTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultAIGatewayType = "ai_gateway";
export interface AccountTagsUpdateResultAIGateway {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultAIGatewayTagsMap;
    type: AccountTagsUpdateResultAIGatewayType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultAISearchInstanceTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultAISearchInstanceType = "ai_search_instance";
export interface AccountTagsUpdateResultAISearchInstance {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultAISearchInstanceTagsMap;
    type: AccountTagsUpdateResultAISearchInstanceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultAlertingPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultAlertingPolicyType = "alerting_policy";
export interface AccountTagsUpdateResultAlertingPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultAlertingPolicyTagsMap;
    type: AccountTagsUpdateResultAlertingPolicyType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultAlertingWebhookTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultAlertingWebhookType = "alerting_webhook";
export interface AccountTagsUpdateResultAlertingWebhook {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultAlertingWebhookTagsMap;
    type: AccountTagsUpdateResultAlertingWebhookType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultAPIGatewayOperationTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultAPIGatewayOperationType = "api_gateway_operation";
export interface AccountTagsUpdateResultAPIGatewayOperation {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultAPIGatewayOperationTagsMap;
    type: AccountTagsUpdateResultAPIGatewayOperationType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultCloudflaredTunnelTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultCloudflaredTunnelType = "cloudflared_tunnel";
export interface AccountTagsUpdateResultCloudflaredTunnel {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultCloudflaredTunnelTagsMap;
    type: AccountTagsUpdateResultCloudflaredTunnelType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultCustomCertificateTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultCustomCertificateType = "custom_certificate";
export interface AccountTagsUpdateResultCustomCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultCustomCertificateTagsMap;
    type: AccountTagsUpdateResultCustomCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultCustomHostnameTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultCustomHostnameType = "custom_hostname";
export interface AccountTagsUpdateResultCustomHostname {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultCustomHostnameTagsMap;
    type: AccountTagsUpdateResultCustomHostnameType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultCWSDeploymentTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultCWSDeploymentType = "cws_deployment";
export interface AccountTagsUpdateResultCWSDeployment {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultCWSDeploymentTagsMap;
    type: AccountTagsUpdateResultCWSDeploymentType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultCWSPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultCWSPolicyType = "cws_policy";
export interface AccountTagsUpdateResultCWSPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultCWSPolicyTagsMap;
    type: AccountTagsUpdateResultCWSPolicyType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultCWSPolicySetTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultCWSPolicySetType = "cws_policy_set";
export interface AccountTagsUpdateResultCWSPolicySet {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultCWSPolicySetTagsMap;
    type: AccountTagsUpdateResultCWSPolicySetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultCWSWorkloadTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultCWSWorkloadType = "cws_workload";
export interface AccountTagsUpdateResultCWSWorkload {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultCWSWorkloadTagsMap;
    type: AccountTagsUpdateResultCWSWorkloadType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultD1DatabaseTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultD1DatabaseType = "d1_database";
export interface AccountTagsUpdateResultD1Database {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultD1DatabaseTagsMap;
    type: AccountTagsUpdateResultD1DatabaseType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultDeviceTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultDeviceType = "device";
export interface AccountTagsUpdateResultDevice {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultDeviceTagsMap;
    type: AccountTagsUpdateResultDeviceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultDNSRecordTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultDNSRecordType = "dns_record";
export interface AccountTagsUpdateResultDNSRecord {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultDNSRecordTagsMap;
    type: AccountTagsUpdateResultDNSRecordType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultDurableObjectNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultDurableObjectNamespaceType = "durable_object_namespace";
export interface AccountTagsUpdateResultDurableObjectNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultDurableObjectNamespaceTagsMap;
    type: AccountTagsUpdateResultDurableObjectNamespaceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultGatewayListTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultGatewayListType = "gateway_list";
export interface AccountTagsUpdateResultGatewayList {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultGatewayListTagsMap;
    type: AccountTagsUpdateResultGatewayListType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultGatewayRuleTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultGatewayRuleType = "gateway_rule";
export interface AccountTagsUpdateResultGatewayRule {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultGatewayRuleTagsMap;
    type: AccountTagsUpdateResultGatewayRuleType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultHealthcheckTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultHealthcheckType = "healthcheck";
export interface AccountTagsUpdateResultHealthcheck {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultHealthcheckTagsMap;
    type: AccountTagsUpdateResultHealthcheckType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultImageTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultImageType = "image";
export interface AccountTagsUpdateResultImage {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultImageTagsMap;
    type: AccountTagsUpdateResultImageType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultInfrastructureTargetTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultInfrastructureTargetType = "infrastructure_target";
export interface AccountTagsUpdateResultInfrastructureTarget {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultInfrastructureTargetTagsMap;
    type: AccountTagsUpdateResultInfrastructureTargetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultKVNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultKVNamespaceType = "kv_namespace";
export interface AccountTagsUpdateResultKVNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultKVNamespaceTagsMap;
    type: AccountTagsUpdateResultKVNamespaceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultLoadBalancerTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultLoadBalancerType = "load_balancer";
export interface AccountTagsUpdateResultLoadBalancer {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultLoadBalancerTagsMap;
    type: AccountTagsUpdateResultLoadBalancerType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultLoadBalancerMonitorTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultLoadBalancerMonitorType = "load_balancer_monitor";
export interface AccountTagsUpdateResultLoadBalancerMonitor {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultLoadBalancerMonitorTagsMap;
    type: AccountTagsUpdateResultLoadBalancerMonitorType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultLoadBalancerPoolTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultLoadBalancerPoolType = "load_balancer_pool";
export interface AccountTagsUpdateResultLoadBalancerPool {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultLoadBalancerPoolTagsMap;
    type: AccountTagsUpdateResultLoadBalancerPoolType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultManagedClientCertificateTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultManagedClientCertificateType = "managed_client_certificate";
export interface AccountTagsUpdateResultManagedClientCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultManagedClientCertificateTagsMap;
    type: AccountTagsUpdateResultManagedClientCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultNamespaceWorkerTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultNamespaceWorkerType = "namespace_worker";
export type AccountTagsUpdateResultNamespaceWorkerNavigation = AccountTagsGetResultNamespaceWorkerNavigation;
export interface AccountTagsUpdateResultNamespaceWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultNamespaceWorkerTagsMap;
    type: AccountTagsUpdateResultNamespaceWorkerType;
    /** Read-only routing metadata resolved from EWC using the account and immutable namespace Worker ID. Returned only by tagged-resource lists requested with include_navigation=true. Omitted when lookup is unavailable or the child has been deleted. Never supplied on tag writes or stored as extra_data. */
    navigation?: AccountTagsGetResultNamespaceWorkerNavigation | null;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultPagesProjectTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultPagesProjectType = "pages_project";
export interface AccountTagsUpdateResultPagesProject {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultPagesProjectTagsMap;
    type: AccountTagsUpdateResultPagesProjectType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultQueueTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultQueueType = "queue";
export interface AccountTagsUpdateResultQueue {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultQueueTagsMap;
    type: AccountTagsUpdateResultQueueType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultR2BucketTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultR2BucketType = "r2_bucket";
export interface AccountTagsUpdateResultR2Bucket {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultR2BucketTagsMap;
    type: AccountTagsUpdateResultR2BucketType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultResourceShareTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultResourceShareType = "resource_share";
export interface AccountTagsUpdateResultResourceShare {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultResourceShareTagsMap;
    type: AccountTagsUpdateResultResourceShareType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultStreamLiveInputTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultStreamLiveInputType = "stream_live_input";
export interface AccountTagsUpdateResultStreamLiveInput {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultStreamLiveInputTagsMap;
    type: AccountTagsUpdateResultStreamLiveInputType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultStreamVideoTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultStreamVideoType = "stream_video";
export interface AccountTagsUpdateResultStreamVideo {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultStreamVideoTagsMap;
    type: AccountTagsUpdateResultStreamVideoType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultVectorizeIndexTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultVectorizeIndexType = "vectorize_index";
export interface AccountTagsUpdateResultVectorizeIndex {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultVectorizeIndexTagsMap;
    type: AccountTagsUpdateResultVectorizeIndexType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultWorkerTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultWorkerType = "worker";
export interface AccountTagsUpdateResultWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultWorkerTagsMap;
    type: AccountTagsUpdateResultWorkerType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultWorkerRouteTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultWorkerRouteType = "worker_route";
export interface AccountTagsUpdateResultWorkerRoute {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultWorkerRouteTagsMap;
    type: AccountTagsUpdateResultWorkerRouteType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultWorkerVersionTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultWorkerVersionType = "worker_version";
export interface AccountTagsUpdateResultWorkerVersion {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultWorkerVersionTagsMap;
    type: AccountTagsUpdateResultWorkerVersionType;
    /** Worker ID is required only for worker_version resources */
    workerId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultZoneTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultZoneType = "zone";
export interface AccountTagsUpdateResultZone {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultZoneTagsMap;
    type: AccountTagsUpdateResultZoneType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResultZoneRulesetTagsMap = {
    [key: string]: string | undefined;
};
export type AccountTagsUpdateResultZoneRulesetType = "zone_ruleset";
export interface AccountTagsUpdateResultZoneRuleset {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: AccountTagsUpdateResultZoneRulesetTagsMap;
    type: AccountTagsUpdateResultZoneRulesetType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type AccountTagsUpdateResult = AccountTagsUpdateResultAccessApplication | AccountTagsUpdateResultAccessApplicationPolicy | AccountTagsUpdateResultAccessGroup | AccountTagsUpdateResultAccessServiceToken | AccountTagsUpdateResultAccount | AccountTagsUpdateResultAccountRuleset | AccountTagsUpdateResultAIGateway | AccountTagsUpdateResultAISearchInstance | AccountTagsUpdateResultAlertingPolicy | AccountTagsUpdateResultAlertingWebhook | AccountTagsUpdateResultAPIGatewayOperation | AccountTagsUpdateResultCloudflaredTunnel | AccountTagsUpdateResultCustomCertificate | AccountTagsUpdateResultCustomHostname | AccountTagsUpdateResultCWSDeployment | AccountTagsUpdateResultCWSPolicy | AccountTagsUpdateResultCWSPolicySet | AccountTagsUpdateResultCWSWorkload | AccountTagsUpdateResultD1Database | AccountTagsUpdateResultDevice | AccountTagsUpdateResultDNSRecord | AccountTagsUpdateResultDurableObjectNamespace | AccountTagsUpdateResultGatewayList | AccountTagsUpdateResultGatewayRule | AccountTagsUpdateResultHealthcheck | AccountTagsUpdateResultImage | AccountTagsUpdateResultInfrastructureTarget | AccountTagsUpdateResultKVNamespace | AccountTagsUpdateResultLoadBalancer | AccountTagsUpdateResultLoadBalancerMonitor | AccountTagsUpdateResultLoadBalancerPool | AccountTagsUpdateResultManagedClientCertificate | AccountTagsUpdateResultNamespaceWorker | AccountTagsUpdateResultPagesProject | AccountTagsUpdateResultQueue | AccountTagsUpdateResultR2Bucket | AccountTagsUpdateResultResourceShare | AccountTagsUpdateResultStreamLiveInput | AccountTagsUpdateResultStreamVideo | AccountTagsUpdateResultVectorizeIndex | AccountTagsUpdateResultWorker | AccountTagsUpdateResultWorkerRoute | AccountTagsUpdateResultWorkerVersion | AccountTagsUpdateResultZone | AccountTagsUpdateResultZoneRuleset;
export type PutAccountTagResponse = AccountTagsUpdateResult;
export type ZoneTagsUpdateRequestResourceType = "access_application_policy" | "api_gateway_operation" | "custom_certificate" | "custom_hostname" | "dns_record" | "healthcheck" | "load_balancer" | "managed_client_certificate" | "worker_route" | "zone" | "zone_ruleset";
export type ZoneTagsUpdateRequestTagsMap = {
    [key: string]: string | undefined;
};
export interface PutZoneTagRequest {
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Identifies the unique resource. */
    resourceId: string;
    /** Enum for base zone-level resource types (those with no extra required fields). */
    resourceType: ZoneTagsUpdateRequestResourceType | (string & {});
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags?: ZoneTagsUpdateRequestTagsMap;
    /** Access application ID is required only for access_application_policy resources */
    accessApplicationId?: string;
    ifMatch?: string;
}
export type ZoneTagsUpdateResultAccessApplicationTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultAccessApplicationType = "access_application";
export interface ZoneTagsUpdateResultAccessApplication {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultAccessApplicationTagsMap;
    type: ZoneTagsUpdateResultAccessApplicationType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultAccessApplicationPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultAccessApplicationPolicyType = "access_application_policy";
export interface ZoneTagsUpdateResultAccessApplicationPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** Access application ID is required only for access_application_policy resources */
    accessApplicationId: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultAccessApplicationPolicyTagsMap;
    type: ZoneTagsUpdateResultAccessApplicationPolicyType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultAccessGroupTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultAccessGroupType = "access_group";
export interface ZoneTagsUpdateResultAccessGroup {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultAccessGroupTagsMap;
    type: ZoneTagsUpdateResultAccessGroupType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultAccessServiceTokenTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultAccessServiceTokenType = "access_service_token";
export interface ZoneTagsUpdateResultAccessServiceToken {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultAccessServiceTokenTagsMap;
    type: ZoneTagsUpdateResultAccessServiceTokenType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultAccountTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultAccountType = "account";
export interface ZoneTagsUpdateResultAccount {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultAccountTagsMap;
    type: ZoneTagsUpdateResultAccountType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultAccountRulesetTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultAccountRulesetType = "account_ruleset";
export interface ZoneTagsUpdateResultAccountRuleset {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultAccountRulesetTagsMap;
    type: ZoneTagsUpdateResultAccountRulesetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultAIGatewayTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultAIGatewayType = "ai_gateway";
export interface ZoneTagsUpdateResultAIGateway {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultAIGatewayTagsMap;
    type: ZoneTagsUpdateResultAIGatewayType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultAISearchInstanceTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultAISearchInstanceType = "ai_search_instance";
export interface ZoneTagsUpdateResultAISearchInstance {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultAISearchInstanceTagsMap;
    type: ZoneTagsUpdateResultAISearchInstanceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultAlertingPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultAlertingPolicyType = "alerting_policy";
export interface ZoneTagsUpdateResultAlertingPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultAlertingPolicyTagsMap;
    type: ZoneTagsUpdateResultAlertingPolicyType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultAlertingWebhookTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultAlertingWebhookType = "alerting_webhook";
export interface ZoneTagsUpdateResultAlertingWebhook {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultAlertingWebhookTagsMap;
    type: ZoneTagsUpdateResultAlertingWebhookType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultAPIGatewayOperationTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultAPIGatewayOperationType = "api_gateway_operation";
export interface ZoneTagsUpdateResultAPIGatewayOperation {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultAPIGatewayOperationTagsMap;
    type: ZoneTagsUpdateResultAPIGatewayOperationType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultCloudflaredTunnelTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultCloudflaredTunnelType = "cloudflared_tunnel";
export interface ZoneTagsUpdateResultCloudflaredTunnel {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultCloudflaredTunnelTagsMap;
    type: ZoneTagsUpdateResultCloudflaredTunnelType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultCustomCertificateTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultCustomCertificateType = "custom_certificate";
export interface ZoneTagsUpdateResultCustomCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultCustomCertificateTagsMap;
    type: ZoneTagsUpdateResultCustomCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultCustomHostnameTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultCustomHostnameType = "custom_hostname";
export interface ZoneTagsUpdateResultCustomHostname {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultCustomHostnameTagsMap;
    type: ZoneTagsUpdateResultCustomHostnameType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultCWSDeploymentTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultCWSDeploymentType = "cws_deployment";
export interface ZoneTagsUpdateResultCWSDeployment {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultCWSDeploymentTagsMap;
    type: ZoneTagsUpdateResultCWSDeploymentType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultCWSPolicyTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultCWSPolicyType = "cws_policy";
export interface ZoneTagsUpdateResultCWSPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultCWSPolicyTagsMap;
    type: ZoneTagsUpdateResultCWSPolicyType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultCWSPolicySetTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultCWSPolicySetType = "cws_policy_set";
export interface ZoneTagsUpdateResultCWSPolicySet {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultCWSPolicySetTagsMap;
    type: ZoneTagsUpdateResultCWSPolicySetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultCWSWorkloadTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultCWSWorkloadType = "cws_workload";
export interface ZoneTagsUpdateResultCWSWorkload {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultCWSWorkloadTagsMap;
    type: ZoneTagsUpdateResultCWSWorkloadType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultD1DatabaseTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultD1DatabaseType = "d1_database";
export interface ZoneTagsUpdateResultD1Database {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultD1DatabaseTagsMap;
    type: ZoneTagsUpdateResultD1DatabaseType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultDeviceTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultDeviceType = "device";
export interface ZoneTagsUpdateResultDevice {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultDeviceTagsMap;
    type: ZoneTagsUpdateResultDeviceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultDNSRecordTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultDNSRecordType = "dns_record";
export interface ZoneTagsUpdateResultDNSRecord {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultDNSRecordTagsMap;
    type: ZoneTagsUpdateResultDNSRecordType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultDurableObjectNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultDurableObjectNamespaceType = "durable_object_namespace";
export interface ZoneTagsUpdateResultDurableObjectNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultDurableObjectNamespaceTagsMap;
    type: ZoneTagsUpdateResultDurableObjectNamespaceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultGatewayListTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultGatewayListType = "gateway_list";
export interface ZoneTagsUpdateResultGatewayList {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultGatewayListTagsMap;
    type: ZoneTagsUpdateResultGatewayListType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultGatewayRuleTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultGatewayRuleType = "gateway_rule";
export interface ZoneTagsUpdateResultGatewayRule {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultGatewayRuleTagsMap;
    type: ZoneTagsUpdateResultGatewayRuleType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultHealthcheckTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultHealthcheckType = "healthcheck";
export interface ZoneTagsUpdateResultHealthcheck {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultHealthcheckTagsMap;
    type: ZoneTagsUpdateResultHealthcheckType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultImageTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultImageType = "image";
export interface ZoneTagsUpdateResultImage {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultImageTagsMap;
    type: ZoneTagsUpdateResultImageType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultInfrastructureTargetTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultInfrastructureTargetType = "infrastructure_target";
export interface ZoneTagsUpdateResultInfrastructureTarget {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultInfrastructureTargetTagsMap;
    type: ZoneTagsUpdateResultInfrastructureTargetType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultKVNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultKVNamespaceType = "kv_namespace";
export interface ZoneTagsUpdateResultKVNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultKVNamespaceTagsMap;
    type: ZoneTagsUpdateResultKVNamespaceType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultLoadBalancerTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultLoadBalancerType = "load_balancer";
export interface ZoneTagsUpdateResultLoadBalancer {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultLoadBalancerTagsMap;
    type: ZoneTagsUpdateResultLoadBalancerType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultLoadBalancerMonitorTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultLoadBalancerMonitorType = "load_balancer_monitor";
export interface ZoneTagsUpdateResultLoadBalancerMonitor {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultLoadBalancerMonitorTagsMap;
    type: ZoneTagsUpdateResultLoadBalancerMonitorType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultLoadBalancerPoolTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultLoadBalancerPoolType = "load_balancer_pool";
export interface ZoneTagsUpdateResultLoadBalancerPool {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultLoadBalancerPoolTagsMap;
    type: ZoneTagsUpdateResultLoadBalancerPoolType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultManagedClientCertificateTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultManagedClientCertificateType = "managed_client_certificate";
export interface ZoneTagsUpdateResultManagedClientCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultManagedClientCertificateTagsMap;
    type: ZoneTagsUpdateResultManagedClientCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultNamespaceWorkerTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultNamespaceWorkerType = "namespace_worker";
export type ZoneTagsUpdateResultNamespaceWorkerNavigation = AccountTagsGetResultNamespaceWorkerNavigation;
export interface ZoneTagsUpdateResultNamespaceWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultNamespaceWorkerTagsMap;
    type: ZoneTagsUpdateResultNamespaceWorkerType;
    /** Read-only routing metadata resolved from EWC using the account and immutable namespace Worker ID. Returned only by tagged-resource lists requested with include_navigation=true. Omitted when lookup is unavailable or the child has been deleted. Never supplied on tag writes or stored as extra_data. */
    navigation?: AccountTagsGetResultNamespaceWorkerNavigation | null;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultPagesProjectTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultPagesProjectType = "pages_project";
export interface ZoneTagsUpdateResultPagesProject {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultPagesProjectTagsMap;
    type: ZoneTagsUpdateResultPagesProjectType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultQueueTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultQueueType = "queue";
export interface ZoneTagsUpdateResultQueue {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultQueueTagsMap;
    type: ZoneTagsUpdateResultQueueType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultR2BucketTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultR2BucketType = "r2_bucket";
export interface ZoneTagsUpdateResultR2Bucket {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultR2BucketTagsMap;
    type: ZoneTagsUpdateResultR2BucketType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultResourceShareTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultResourceShareType = "resource_share";
export interface ZoneTagsUpdateResultResourceShare {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultResourceShareTagsMap;
    type: ZoneTagsUpdateResultResourceShareType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultStreamLiveInputTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultStreamLiveInputType = "stream_live_input";
export interface ZoneTagsUpdateResultStreamLiveInput {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultStreamLiveInputTagsMap;
    type: ZoneTagsUpdateResultStreamLiveInputType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultStreamVideoTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultStreamVideoType = "stream_video";
export interface ZoneTagsUpdateResultStreamVideo {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultStreamVideoTagsMap;
    type: ZoneTagsUpdateResultStreamVideoType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultVectorizeIndexTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultVectorizeIndexType = "vectorize_index";
export interface ZoneTagsUpdateResultVectorizeIndex {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultVectorizeIndexTagsMap;
    type: ZoneTagsUpdateResultVectorizeIndexType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultWorkerTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultWorkerType = "worker";
export interface ZoneTagsUpdateResultWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultWorkerTagsMap;
    type: ZoneTagsUpdateResultWorkerType;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultWorkerRouteTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultWorkerRouteType = "worker_route";
export interface ZoneTagsUpdateResultWorkerRoute {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultWorkerRouteTagsMap;
    type: ZoneTagsUpdateResultWorkerRouteType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultWorkerVersionTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultWorkerVersionType = "worker_version";
export interface ZoneTagsUpdateResultWorkerVersion {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultWorkerVersionTagsMap;
    type: ZoneTagsUpdateResultWorkerVersionType;
    /** Worker ID is required only for worker_version resources */
    workerId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultZoneTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultZoneType = "zone";
export interface ZoneTagsUpdateResultZone {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultZoneTagsMap;
    type: ZoneTagsUpdateResultZoneType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResultZoneRulesetTagsMap = {
    [key: string]: string | undefined;
};
export type ZoneTagsUpdateResultZoneRulesetType = "zone_ruleset";
export interface ZoneTagsUpdateResultZoneRuleset {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:" where the hash is the base64url-encoded SHA-256 (truncated to 128 bits) of the tags map canonicalized using RFC 8785 (JSON Canonicalization Scheme). Clients should treat ETags as opaque strings and pass them back via the If-Match header on write operations. */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. Keys may contain at most 256 characters. Values may contain at most 1024 characters and may be empty for key-only tags. */
    tags: ZoneTagsUpdateResultZoneRulesetTagsMap;
    type: ZoneTagsUpdateResultZoneRulesetType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Monotonic version of the resource's tags: the timestamp assigned when the tags were last written. Returned by read endpoints, by 2PC prepare (the version that will be assigned on commit, unless a concurrent write lands first, in which case a newer version is assigned), and by 2PC commit (the authoritative committed version). Omitted for untagged resources and delete commits: a deleted resource has no current version, and deletions are ordered by event order rather than by version. */
    tagsUpdatedAt?: string | null;
}
export type ZoneTagsUpdateResult = ZoneTagsUpdateResultAccessApplication | ZoneTagsUpdateResultAccessApplicationPolicy | ZoneTagsUpdateResultAccessGroup | ZoneTagsUpdateResultAccessServiceToken | ZoneTagsUpdateResultAccount | ZoneTagsUpdateResultAccountRuleset | ZoneTagsUpdateResultAIGateway | ZoneTagsUpdateResultAISearchInstance | ZoneTagsUpdateResultAlertingPolicy | ZoneTagsUpdateResultAlertingWebhook | ZoneTagsUpdateResultAPIGatewayOperation | ZoneTagsUpdateResultCloudflaredTunnel | ZoneTagsUpdateResultCustomCertificate | ZoneTagsUpdateResultCustomHostname | ZoneTagsUpdateResultCWSDeployment | ZoneTagsUpdateResultCWSPolicy | ZoneTagsUpdateResultCWSPolicySet | ZoneTagsUpdateResultCWSWorkload | ZoneTagsUpdateResultD1Database | ZoneTagsUpdateResultDevice | ZoneTagsUpdateResultDNSRecord | ZoneTagsUpdateResultDurableObjectNamespace | ZoneTagsUpdateResultGatewayList | ZoneTagsUpdateResultGatewayRule | ZoneTagsUpdateResultHealthcheck | ZoneTagsUpdateResultImage | ZoneTagsUpdateResultInfrastructureTarget | ZoneTagsUpdateResultKVNamespace | ZoneTagsUpdateResultLoadBalancer | ZoneTagsUpdateResultLoadBalancerMonitor | ZoneTagsUpdateResultLoadBalancerPool | ZoneTagsUpdateResultManagedClientCertificate | ZoneTagsUpdateResultNamespaceWorker | ZoneTagsUpdateResultPagesProject | ZoneTagsUpdateResultQueue | ZoneTagsUpdateResultR2Bucket | ZoneTagsUpdateResultResourceShare | ZoneTagsUpdateResultStreamLiveInput | ZoneTagsUpdateResultStreamVideo | ZoneTagsUpdateResultVectorizeIndex | ZoneTagsUpdateResultWorker | ZoneTagsUpdateResultWorkerRoute | ZoneTagsUpdateResultWorkerVersion | ZoneTagsUpdateResultZone | ZoneTagsUpdateResultZoneRuleset;
export type PutZoneTagResponse = ZoneTagsUpdateResult;
export type DeleteAccountTagError = Forbidden | CloudflareOpError;
/** Removes all tags from a specific account-level resource. */
export declare const deleteAccountTag: API.OperationMethod<DeleteAccountTagRequest, DeleteAccountTagResponse, DeleteAccountTagError, CloudflareOpContext>;
export type DeleteZoneTagError = Forbidden | CloudflareOpError;
/** Removes all tags from a specific zone-level resource. */
export declare const deleteZoneTag: API.OperationMethod<DeleteZoneTagRequest, DeleteZoneTagResponse, DeleteZoneTagError, CloudflareOpContext>;
export type GetAccountTagError = Forbidden | CloudflareOpError;
/** Retrieves tags for a specific account-level resource. */
export declare const getAccountTag: API.OperationMethod<GetAccountTagRequest, GetAccountTagResponse, GetAccountTagError, CloudflareOpContext>;
export type GetSummaryError = CloudflareOpError;
/** Lists all distinct tag keys and their distinct values across resources in an account. */
export declare const getSummary: API.OperationMethod<GetSummaryRequest, GetSummaryResponse, GetSummaryError, CloudflareOpContext>;
export type GetZoneTagError = ZoneTagResourceNotFound | Forbidden | CloudflareOpError;
/** Retrieves tags for a specific zone-level resource. */
export declare const getZoneTag: API.OperationMethod<GetZoneTagRequest, GetZoneTagResponse, GetZoneTagError, CloudflareOpContext>;
export type ListKeysError = CloudflareOpError;
/** Lists all distinct tag keys used across resources in an account. */
export declare const listKeys: API.PaginatedOperationMethod<ListKeysRequest, ListKeysResponse, ListKeysError, CloudflareOpContext, string>;
export type ListResourceTaggingsError = CloudflareOpError;
/** Lists all tagged resources for an account. */
export declare const listResourceTaggings: API.PaginatedOperationMethod<ListResourceTaggingsRequest, ListResourceTaggingsResponse, ListResourceTaggingsError, CloudflareOpContext, ListResultItem>;
export type ListValuesError = CloudflareOpError;
/** Lists all distinct values for a given tag key, optionally filtered by resource type. */
export declare const listValues: API.PaginatedOperationMethod<ListValuesRequest, ListValuesResponse, ListValuesError, CloudflareOpContext, string>;
export type PutAccountTagError = Forbidden | TagPreconditionFailed | CloudflareOpError;
/** Creates or updates tags for a specific account-level resource. Replaces all existing tags for the resource. */
export declare const putAccountTag: API.OperationMethod<PutAccountTagRequest, PutAccountTagResponse, PutAccountTagError, CloudflareOpContext>;
export type PutZoneTagError = ZoneTagResourceNotFound | Forbidden | TagPreconditionFailed | CloudflareOpError;
/** Creates or updates tags for a specific zone-level resource. Replaces all existing tags for the resource. */
export declare const putZoneTag: API.OperationMethod<PutZoneTagRequest, PutZoneTagResponse, PutZoneTagError, CloudflareOpContext>;
//# sourceMappingURL=resource_tagging.d.ts.map