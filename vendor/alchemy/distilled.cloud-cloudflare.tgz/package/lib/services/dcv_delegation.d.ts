import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface GetDcvDelegationRequest {
    /** Identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDcvDelegationResponse {
    /** The DCV Delegation unique identifier. */
    uuid?: string | null;
}
export type GetDcvDelegationError = CloudflareOpError;
/** Retrieve the account and zone specific unique identifier used as part of the CNAME target for DCV Delegation. */
export declare const getDcvDelegation: API.OperationMethod<GetDcvDelegationRequest, GetDcvDelegationResponse, GetDcvDelegationError, CloudflareOpContext>;
//# sourceMappingURL=dcv_delegation.d.ts.map