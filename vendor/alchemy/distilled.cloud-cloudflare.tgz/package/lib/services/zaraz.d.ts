import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const NotFound_base: S.TaggedErrorClass<"NotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
export interface CreatePublishRequest {
    /** Identifier. */
    zoneId: string;
    /** Zaraz configuration description. */
    body?: string;
}
export type CreatePublishResponse = string;
export interface GetConfigRequest {
    /** Identifier. */
    zoneId: string;
}
export interface ConfigGetResponseSettingsContextEnricher {
    escapedWorkerName: string;
    workerTag: string;
}
export interface ConfigGetResponseSettings {
    /** Automatic injection of Zaraz scripts enabled. */
    autoInjectScript: boolean;
    /** Details of the worker that receives and edits Zaraz Context object. */
    contextEnricher?: ConfigGetResponseSettingsContextEnricher | null;
    /** The domain Zaraz will use for writing and reading its cookies. */
    cookieDomain?: string | null;
    /** Ecommerce API enabled. */
    ecommerce?: boolean | null;
    /** Custom endpoint for server-side track events. */
    eventsApiPath?: string | null;
    /** Hiding external referrer URL enabled. */
    hideExternalReferer?: boolean | null;
    /** Trimming IP address enabled. */
    hideIPAddress?: boolean | null;
    /** Removing URL query params enabled. */
    hideQueryParams?: boolean | null;
    /** Removing sensitive data from User Agent string enabled. */
    hideUserAgent?: boolean | null;
    /** Custom endpoint for Zaraz init script. */
    initPath?: string | null;
    /** Injection of Zaraz scripts into iframes enabled. */
    injectIframes?: boolean | null;
    /** Custom path for Managed Components server functionalities. */
    mcRootPath?: string | null;
    /** Custom endpoint for Zaraz main script. */
    scriptPath?: string | null;
    /** Custom endpoint for Zaraz tracking requests. */
    trackPath?: string | null;
}
export type UntypedConfigMap = {
    [key: string]: unknown | undefined;
};
export interface ConfigGetResponseAnalytics {
    /** Consent purpose assigned to Monitoring. */
    defaultPurpose?: string | null;
    /** Whether Advanced Monitoring reports are enabled. */
    enabled?: boolean | null;
    /** Session expiration time (seconds). */
    sessionExpTime?: number | null;
}
export type ConfigGetResponseConsentButtonTextTranslationsAcceptAllMap = {
    [key: string]: string | undefined;
};
export type ConfigGetResponseConsentButtonTextTranslationsConfirmMyChoicesMap = {
    [key: string]: string | undefined;
};
export type ConfigGetResponseConsentButtonTextTranslationsRejectAllMap = {
    [key: string]: string | undefined;
};
export interface ConfigGetResponseConsentButtonTextTranslations {
    /** Object where keys are language codes. */
    acceptAll: ConfigGetResponseConsentButtonTextTranslationsAcceptAllMap;
    /** Object where keys are language codes. */
    confirmMyChoices: ConfigGetResponseConsentButtonTextTranslationsConfirmMyChoicesMap;
    /** Object where keys are language codes. */
    rejectAll: ConfigGetResponseConsentButtonTextTranslationsRejectAllMap;
}
export type ConfigGetResponseConsentConsentModalIntroHTMLWithTranslationsMap = {
    [key: string]: string | undefined;
};
export interface ConfigGetResponseConsentPurposesValue {
    description: string;
    name: string;
}
export type ConfigGetResponseConsentPurposesMap = {
    [key: string]: ConfigGetResponseConsentPurposesValue | undefined;
};
export type ConfigGetResponseConsentPurposesWithTranslationsValueDescriptionMap = {
    [key: string]: string | undefined;
};
export type ConfigGetResponseConsentPurposesWithTranslationsValueNameMap = {
    [key: string]: string | undefined;
};
export interface ConfigGetResponseConsentPurposesWithTranslationsValue {
    /** Object where keys are language codes. */
    description: ConfigGetResponseConsentPurposesWithTranslationsValueDescriptionMap;
    /** Object where keys are language codes. */
    name: ConfigGetResponseConsentPurposesWithTranslationsValueNameMap;
    order: number;
}
export type ConfigGetResponseConsentPurposesWithTranslationsMap = {
    [key: string]: ConfigGetResponseConsentPurposesWithTranslationsValue | undefined;
};
export interface ConfigGetResponseConsent {
    enabled: boolean;
    buttonTextTranslations?: ConfigGetResponseConsentButtonTextTranslations | null;
    companyEmail?: string | null;
    companyName?: string | null;
    companyStreetAddress?: string | null;
    consentModalIntroHTML?: string | null;
    /** Object where keys are language codes. */
    consentModalIntroHTMLWithTranslations?: ConfigGetResponseConsentConsentModalIntroHTMLWithTranslationsMap | null;
    cookieName?: string | null;
    customCSS?: string | null;
    customIntroDisclaimerDismissed?: boolean | null;
    defaultLanguage?: string | null;
    hideModal?: boolean | null;
    /** Object where keys are purpose alpha-numeric IDs. */
    purposes?: ConfigGetResponseConsentPurposesMap | null;
    /** Object where keys are purpose alpha-numeric IDs. */
    purposesWithTranslations?: ConfigGetResponseConsentPurposesWithTranslationsMap | null;
    tcfCompliant?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigResponse {
    /** Data layer compatibility mode enabled. */
    dataLayer: boolean;
    /** The key for Zaraz debug mode. */
    debugKey: string;
    /** General Zaraz settings. */
    settings: ConfigGetResponseSettings;
    /** Tools set up under Zaraz configuration, where key is the alpha-numeric tool ID and value is the tool configuration object. */
    tools: UntypedConfigMap;
    /** Triggers set up under Zaraz configuration, where key is the trigger alpha-numeric ID and value is the trigger configuration. */
    triggers: UntypedConfigMap;
    /** Variables set up under Zaraz configuration, where key is the variable alpha-numeric ID and value is the variable configuration. Values of variables of type secret are not included. */
    variables: UntypedConfigMap;
    /** Zaraz internal version of the config. */
    zarazVersion: number;
    /** Cloudflare Monitoring settings. */
    analytics?: ConfigGetResponseAnalytics | null;
    /** Consent management configuration. */
    consent?: ConfigGetResponseConsent | null;
    /** Single Page Application support enabled. */
    historyChange?: boolean | null;
}
export interface GetDefaultRequest {
    /** Identifier. */
    zoneId: string;
}
export type DefaultGetResponseSettingsContextEnricher = ConfigGetResponseSettingsContextEnricher;
export type DefaultGetResponseSettings = ConfigGetResponseSettings;
export type DefaultGetResponseAnalytics = ConfigGetResponseAnalytics;
export type DefaultGetResponseConsentButtonTextTranslationsAcceptAllMap = {
    [key: string]: string | undefined;
};
export type DefaultGetResponseConsentButtonTextTranslationsConfirmMyChoicesMap = {
    [key: string]: string | undefined;
};
export type DefaultGetResponseConsentButtonTextTranslationsRejectAllMap = {
    [key: string]: string | undefined;
};
export interface DefaultGetResponseConsentButtonTextTranslations {
    /** Object where keys are language codes. */
    acceptAll: DefaultGetResponseConsentButtonTextTranslationsAcceptAllMap;
    /** Object where keys are language codes. */
    confirmMyChoices: DefaultGetResponseConsentButtonTextTranslationsConfirmMyChoicesMap;
    /** Object where keys are language codes. */
    rejectAll: DefaultGetResponseConsentButtonTextTranslationsRejectAllMap;
}
export type DefaultGetResponseConsentConsentModalIntroHTMLWithTranslationsMap = {
    [key: string]: string | undefined;
};
export type DefaultGetResponseConsentPurposesValue = ConfigGetResponseConsentPurposesValue;
export type DefaultGetResponseConsentPurposesMap = {
    [key: string]: ConfigGetResponseConsentPurposesValue | undefined;
};
export type DefaultGetResponseConsentPurposesWithTranslationsValueDescriptionMap = {
    [key: string]: string | undefined;
};
export type DefaultGetResponseConsentPurposesWithTranslationsValueNameMap = {
    [key: string]: string | undefined;
};
export interface DefaultGetResponseConsentPurposesWithTranslationsValue {
    /** Object where keys are language codes. */
    description: DefaultGetResponseConsentPurposesWithTranslationsValueDescriptionMap;
    /** Object where keys are language codes. */
    name: DefaultGetResponseConsentPurposesWithTranslationsValueNameMap;
    order: number;
}
export type DefaultGetResponseConsentPurposesWithTranslationsMap = {
    [key: string]: DefaultGetResponseConsentPurposesWithTranslationsValue | undefined;
};
export interface DefaultGetResponseConsent {
    enabled: boolean;
    buttonTextTranslations?: DefaultGetResponseConsentButtonTextTranslations | null;
    companyEmail?: string | null;
    companyName?: string | null;
    companyStreetAddress?: string | null;
    consentModalIntroHTML?: string | null;
    /** Object where keys are language codes. */
    consentModalIntroHTMLWithTranslations?: DefaultGetResponseConsentConsentModalIntroHTMLWithTranslationsMap | null;
    cookieName?: string | null;
    customCSS?: string | null;
    customIntroDisclaimerDismissed?: boolean | null;
    defaultLanguage?: string | null;
    hideModal?: boolean | null;
    /** Object where keys are purpose alpha-numeric IDs. */
    purposes?: DefaultGetResponseConsentPurposesMap | null;
    /** Object where keys are purpose alpha-numeric IDs. */
    purposesWithTranslations?: DefaultGetResponseConsentPurposesWithTranslationsMap | null;
    tcfCompliant?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDefaultResponse {
    /** Data layer compatibility mode enabled. */
    dataLayer: boolean;
    /** The key for Zaraz debug mode. */
    debugKey: string;
    /** General Zaraz settings. */
    settings: ConfigGetResponseSettings;
    /** Tools set up under Zaraz configuration, where key is the alpha-numeric tool ID and value is the tool configuration object. */
    tools: UntypedConfigMap;
    /** Triggers set up under Zaraz configuration, where key is the trigger alpha-numeric ID and value is the trigger configuration. */
    triggers: UntypedConfigMap;
    /** Variables set up under Zaraz configuration, where key is the variable alpha-numeric ID and value is the variable configuration. Values of variables of type secret are not included. */
    variables: UntypedConfigMap;
    /** Zaraz internal version of the config. */
    zarazVersion: number;
    /** Cloudflare Monitoring settings. */
    analytics?: ConfigGetResponseAnalytics | null;
    /** Consent management configuration. */
    consent?: DefaultGetResponseConsent | null;
    /** Single Page Application support enabled. */
    historyChange?: boolean | null;
}
export interface GetExportRequest {
    /** Identifier. */
    zoneId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetExportResponse {
}
export type HistoryConfigsGetRequestIdsList = Array<number>;
export interface GetHistoryConfigRequest {
    /** Identifier. */
    zoneId: string;
    /** Comma separated list of Zaraz configuration IDs. */
    ids: HistoryConfigsGetRequestIdsList;
}
export type HistoryConfigsGetResultValueConfigSettingsContextEnricher = ConfigGetResponseSettingsContextEnricher;
export type HistoryConfigsGetResultValueConfigSettings = ConfigGetResponseSettings;
export type HistoryConfigsGetResultValueConfigAnalytics = ConfigGetResponseAnalytics;
export type HistoryConfigsGetResultValueConfigConsentButtonTextTranslationsAcceptAllMap = {
    [key: string]: string | undefined;
};
export type HistoryConfigsGetResultValueConfigConsentButtonTextTranslationsConfirmMyChoicesMap = {
    [key: string]: string | undefined;
};
export type HistoryConfigsGetResultValueConfigConsentButtonTextTranslationsRejectAllMap = {
    [key: string]: string | undefined;
};
export interface HistoryConfigsGetResultValueConfigConsentButtonTextTranslations {
    /** Object where keys are language codes. */
    acceptAll: HistoryConfigsGetResultValueConfigConsentButtonTextTranslationsAcceptAllMap;
    /** Object where keys are language codes. */
    confirmMyChoices: HistoryConfigsGetResultValueConfigConsentButtonTextTranslationsConfirmMyChoicesMap;
    /** Object where keys are language codes. */
    rejectAll: HistoryConfigsGetResultValueConfigConsentButtonTextTranslationsRejectAllMap;
}
export type HistoryConfigsGetResultValueConfigConsentConsentModalIntroHTMLWithTranslationsMap = {
    [key: string]: string | undefined;
};
export type HistoryConfigsGetResultValueConfigConsentPurposesValue = ConfigGetResponseConsentPurposesValue;
export type HistoryConfigsGetResultValueConfigConsentPurposesMap = {
    [key: string]: ConfigGetResponseConsentPurposesValue | undefined;
};
export type HistoryConfigsGetResultValueConfigConsentPurposesWithTranslationsValueDescriptionMap = {
    [key: string]: string | undefined;
};
export type HistoryConfigsGetResultValueConfigConsentPurposesWithTranslationsValueNameMap = {
    [key: string]: string | undefined;
};
export interface HistoryConfigsGetResultValueConfigConsentPurposesWithTranslationsValue {
    /** Object where keys are language codes. */
    description: HistoryConfigsGetResultValueConfigConsentPurposesWithTranslationsValueDescriptionMap;
    /** Object where keys are language codes. */
    name: HistoryConfigsGetResultValueConfigConsentPurposesWithTranslationsValueNameMap;
    order: number;
}
export type HistoryConfigsGetResultValueConfigConsentPurposesWithTranslationsMap = {
    [key: string]: HistoryConfigsGetResultValueConfigConsentPurposesWithTranslationsValue | undefined;
};
export interface HistoryConfigsGetResultValueConfigConsent {
    enabled: boolean;
    buttonTextTranslations?: HistoryConfigsGetResultValueConfigConsentButtonTextTranslations | null;
    companyEmail?: string | null;
    companyName?: string | null;
    companyStreetAddress?: string | null;
    consentModalIntroHTML?: string | null;
    /** Object where keys are language codes. */
    consentModalIntroHTMLWithTranslations?: HistoryConfigsGetResultValueConfigConsentConsentModalIntroHTMLWithTranslationsMap | null;
    cookieName?: string | null;
    customCSS?: string | null;
    customIntroDisclaimerDismissed?: boolean | null;
    defaultLanguage?: string | null;
    hideModal?: boolean | null;
    /** Object where keys are purpose alpha-numeric IDs. */
    purposes?: HistoryConfigsGetResultValueConfigConsentPurposesMap | null;
    /** Object where keys are purpose alpha-numeric IDs. */
    purposesWithTranslations?: HistoryConfigsGetResultValueConfigConsentPurposesWithTranslationsMap | null;
    tcfCompliant?: boolean | null;
}
export interface HistoryConfigsGetResultValueConfig {
    /** Data layer compatibility mode enabled. */
    dataLayer: boolean;
    /** The key for Zaraz debug mode. */
    debugKey: string;
    /** General Zaraz settings. */
    settings: ConfigGetResponseSettings;
    /** Tools set up under Zaraz configuration, where key is the alpha-numeric tool ID and value is the tool configuration object. */
    tools: UntypedConfigMap;
    /** Triggers set up under Zaraz configuration, where key is the trigger alpha-numeric ID and value is the trigger configuration. */
    triggers: UntypedConfigMap;
    /** Variables set up under Zaraz configuration, where key is the variable alpha-numeric ID and value is the variable configuration. Values of variables of type secret are not included. */
    variables: UntypedConfigMap;
    /** Zaraz internal version of the config. */
    zarazVersion: number;
    /** Cloudflare Monitoring settings. */
    analytics?: ConfigGetResponseAnalytics | null;
    /** Consent management configuration. */
    consent?: HistoryConfigsGetResultValueConfigConsent | null;
    /** Single Page Application support enabled. */
    historyChange?: boolean | null;
}
export interface HistoryConfigsGetResultValue {
    /** ID of the configuration. */
    id: number;
    /** Zaraz configuration. */
    config: HistoryConfigsGetResultValueConfig;
    /** Date and time the configuration was created. */
    createdAt: string;
    /** Date and time the configuration was last updated. */
    updatedAt: string;
    /** Alpha-numeric ID of the account user who published the configuration. */
    userId: string;
}
export type HistoryConfigsGetResultMap = {
    [key: string]: HistoryConfigsGetResultValue | undefined;
};
export type GetHistoryConfigResponse = HistoryConfigsGetResultMap;
export interface GetWorkflowRequest {
    /** Identifier. */
    zoneId: string;
}
export type WorkflowGetResult = "realtime" | "preview";
export type GetWorkflowResponse = WorkflowGetResult;
export type HistoryListRequestSortField = "id" | "user_id" | "description" | "created_at" | "updated_at";
export type HistoryListRequestSortOrder = "DESC" | "ASC";
export interface ListHistoriesRequest {
    /** Identifier. */
    zoneId: string;
    /** Maximum amount of results to list. Default value is 10. */
    limit?: number;
    /** Ordinal number to start listing the results with. Default value is 0. */
    offset?: number;
    /** The field to sort by. Default is updated_at. */
    sortField?: HistoryListRequestSortField | (string & {});
    /** Sorting order. Default is DESC. */
    sortOrder?: HistoryListRequestSortOrder | (string & {});
}
export interface HistoryListResultItem {
    /** ID of the configuration. */
    id: number;
    /** Date and time the configuration was created. */
    createdAt: string;
    /** Configuration description provided by the user who published this configuration. */
    description: string;
    /** Date and time the configuration was last updated. */
    updatedAt: string;
    /** Alpha-numeric ID of the account user who published the configuration. */
    userId: string;
}
export type HistoryListResultList = Array<HistoryListResultItem>;
export interface ListHistoriesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: HistoryListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ConfigUpdateRequestSettingsContextEnricher = ConfigGetResponseSettingsContextEnricher;
export interface ConfigUpdateRequestSettings {
    /** Automatic injection of Zaraz scripts enabled. */
    autoInjectScript: boolean;
    /** Details of the worker that receives and edits Zaraz Context object. */
    contextEnricher?: ConfigGetResponseSettingsContextEnricher;
    /** The domain Zaraz will use for writing and reading its cookies. */
    cookieDomain?: string;
    /** Ecommerce API enabled. */
    ecommerce?: boolean;
    /** Custom endpoint for server-side track events. */
    eventsApiPath?: string;
    /** Hiding external referrer URL enabled. */
    hideExternalReferer?: boolean;
    /** Trimming IP address enabled. */
    hideIPAddress?: boolean;
    /** Removing URL query params enabled. */
    hideQueryParams?: boolean;
    /** Removing sensitive data from User Agent string enabled. */
    hideUserAgent?: boolean;
    /** Custom endpoint for Zaraz init script. */
    initPath?: string;
    /** Injection of Zaraz scripts into iframes enabled. */
    injectIframes?: boolean;
    /** Custom path for Managed Components server functionalities. */
    mcRootPath?: string;
    /** Custom endpoint for Zaraz main script. */
    scriptPath?: string;
    /** Custom endpoint for Zaraz tracking requests. */
    trackPath?: string;
}
export interface ConfigUpdateRequestAnalytics {
    /** Consent purpose assigned to Monitoring. */
    defaultPurpose?: string;
    /** Whether Advanced Monitoring reports are enabled. */
    enabled?: boolean;
    /** Session expiration time (seconds). */
    sessionExpTime?: number;
}
export type ConfigUpdateRequestConsentButtonTextTranslationsAcceptAllMap = {
    [key: string]: string | undefined;
};
export type ConfigUpdateRequestConsentButtonTextTranslationsConfirmMyChoicesMap = {
    [key: string]: string | undefined;
};
export type ConfigUpdateRequestConsentButtonTextTranslationsRejectAllMap = {
    [key: string]: string | undefined;
};
export interface ConfigUpdateRequestConsentButtonTextTranslations {
    /** Object where keys are language codes. */
    acceptAll: ConfigUpdateRequestConsentButtonTextTranslationsAcceptAllMap;
    /** Object where keys are language codes. */
    confirmMyChoices: ConfigUpdateRequestConsentButtonTextTranslationsConfirmMyChoicesMap;
    /** Object where keys are language codes. */
    rejectAll: ConfigUpdateRequestConsentButtonTextTranslationsRejectAllMap;
}
export type ConfigUpdateRequestConsentConsentModalIntroHTMLWithTranslationsMap = {
    [key: string]: string | undefined;
};
export type ConfigUpdateRequestConsentPurposesValue = ConfigGetResponseConsentPurposesValue;
export type ConfigUpdateRequestConsentPurposesMap = {
    [key: string]: ConfigGetResponseConsentPurposesValue | undefined;
};
export type ConfigUpdateRequestConsentPurposesWithTranslationsValueDescriptionMap = {
    [key: string]: string | undefined;
};
export type ConfigUpdateRequestConsentPurposesWithTranslationsValueNameMap = {
    [key: string]: string | undefined;
};
export interface ConfigUpdateRequestConsentPurposesWithTranslationsValue {
    /** Object where keys are language codes. */
    description: ConfigUpdateRequestConsentPurposesWithTranslationsValueDescriptionMap;
    /** Object where keys are language codes. */
    name: ConfigUpdateRequestConsentPurposesWithTranslationsValueNameMap;
    order: number;
}
export type ConfigUpdateRequestConsentPurposesWithTranslationsMap = {
    [key: string]: ConfigUpdateRequestConsentPurposesWithTranslationsValue | undefined;
};
export interface ConfigUpdateRequestConsent {
    enabled: boolean;
    buttonTextTranslations?: ConfigUpdateRequestConsentButtonTextTranslations;
    companyEmail?: string;
    companyName?: string;
    companyStreetAddress?: string;
    consentModalIntroHTML?: string;
    /** Object where keys are language codes. */
    consentModalIntroHTMLWithTranslations?: ConfigUpdateRequestConsentConsentModalIntroHTMLWithTranslationsMap;
    cookieName?: string;
    customCSS?: string;
    customIntroDisclaimerDismissed?: boolean;
    defaultLanguage?: string;
    hideModal?: boolean;
    /** Object where keys are purpose alpha-numeric IDs. */
    purposes?: ConfigUpdateRequestConsentPurposesMap;
    /** Object where keys are purpose alpha-numeric IDs. */
    purposesWithTranslations?: ConfigUpdateRequestConsentPurposesWithTranslationsMap;
    tcfCompliant?: boolean;
}
export interface PutConfigRequest {
    /** Identifier. */
    zoneId: string;
    /** Data layer compatibility mode enabled. */
    dataLayer: boolean;
    /** The key for Zaraz debug mode. */
    debugKey: string;
    /** General Zaraz settings. */
    settings: ConfigUpdateRequestSettings;
    /** Tools set up under Zaraz configuration, where key is the alpha-numeric tool ID and value is the tool configuration object. */
    tools: UntypedConfigMap;
    /** Triggers set up under Zaraz configuration, where key is the trigger alpha-numeric ID and value is the trigger configuration. */
    triggers: UntypedConfigMap;
    /** Variables set up under Zaraz configuration, where key is the variable alpha-numeric ID and value is the variable configuration. Values of variables of type secret are not included. */
    variables: UntypedConfigMap;
    /** Zaraz internal version of the config. */
    zarazVersion: number;
    /** Cloudflare Monitoring settings. */
    analytics?: ConfigUpdateRequestAnalytics;
    /** Consent management configuration. */
    consent?: ConfigUpdateRequestConsent;
    /** Single Page Application support enabled. */
    historyChange?: boolean;
}
export type ConfigUpdateResponseSettingsContextEnricher = ConfigGetResponseSettingsContextEnricher;
export type ConfigUpdateResponseSettings = ConfigGetResponseSettings;
export type ConfigUpdateResponseAnalytics = ConfigGetResponseAnalytics;
export type ConfigUpdateResponseConsentButtonTextTranslationsAcceptAllMap = {
    [key: string]: string | undefined;
};
export type ConfigUpdateResponseConsentButtonTextTranslationsConfirmMyChoicesMap = {
    [key: string]: string | undefined;
};
export type ConfigUpdateResponseConsentButtonTextTranslationsRejectAllMap = {
    [key: string]: string | undefined;
};
export interface ConfigUpdateResponseConsentButtonTextTranslations {
    /** Object where keys are language codes. */
    acceptAll: ConfigUpdateResponseConsentButtonTextTranslationsAcceptAllMap;
    /** Object where keys are language codes. */
    confirmMyChoices: ConfigUpdateResponseConsentButtonTextTranslationsConfirmMyChoicesMap;
    /** Object where keys are language codes. */
    rejectAll: ConfigUpdateResponseConsentButtonTextTranslationsRejectAllMap;
}
export type ConfigUpdateResponseConsentConsentModalIntroHTMLWithTranslationsMap = {
    [key: string]: string | undefined;
};
export type ConfigUpdateResponseConsentPurposesValue = ConfigGetResponseConsentPurposesValue;
export type ConfigUpdateResponseConsentPurposesMap = {
    [key: string]: ConfigGetResponseConsentPurposesValue | undefined;
};
export type ConfigUpdateResponseConsentPurposesWithTranslationsValueDescriptionMap = {
    [key: string]: string | undefined;
};
export type ConfigUpdateResponseConsentPurposesWithTranslationsValueNameMap = {
    [key: string]: string | undefined;
};
export interface ConfigUpdateResponseConsentPurposesWithTranslationsValue {
    /** Object where keys are language codes. */
    description: ConfigUpdateResponseConsentPurposesWithTranslationsValueDescriptionMap;
    /** Object where keys are language codes. */
    name: ConfigUpdateResponseConsentPurposesWithTranslationsValueNameMap;
    order: number;
}
export type ConfigUpdateResponseConsentPurposesWithTranslationsMap = {
    [key: string]: ConfigUpdateResponseConsentPurposesWithTranslationsValue | undefined;
};
export interface ConfigUpdateResponseConsent {
    enabled: boolean;
    buttonTextTranslations?: ConfigUpdateResponseConsentButtonTextTranslations | null;
    companyEmail?: string | null;
    companyName?: string | null;
    companyStreetAddress?: string | null;
    consentModalIntroHTML?: string | null;
    /** Object where keys are language codes. */
    consentModalIntroHTMLWithTranslations?: ConfigUpdateResponseConsentConsentModalIntroHTMLWithTranslationsMap | null;
    cookieName?: string | null;
    customCSS?: string | null;
    customIntroDisclaimerDismissed?: boolean | null;
    defaultLanguage?: string | null;
    hideModal?: boolean | null;
    /** Object where keys are purpose alpha-numeric IDs. */
    purposes?: ConfigUpdateResponseConsentPurposesMap | null;
    /** Object where keys are purpose alpha-numeric IDs. */
    purposesWithTranslations?: ConfigUpdateResponseConsentPurposesWithTranslationsMap | null;
    tcfCompliant?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutConfigResponse {
    /** Data layer compatibility mode enabled. */
    dataLayer: boolean;
    /** The key for Zaraz debug mode. */
    debugKey: string;
    /** General Zaraz settings. */
    settings: ConfigGetResponseSettings;
    /** Tools set up under Zaraz configuration, where key is the alpha-numeric tool ID and value is the tool configuration object. */
    tools: UntypedConfigMap;
    /** Triggers set up under Zaraz configuration, where key is the trigger alpha-numeric ID and value is the trigger configuration. */
    triggers: UntypedConfigMap;
    /** Variables set up under Zaraz configuration, where key is the variable alpha-numeric ID and value is the variable configuration. Values of variables of type secret are not included. */
    variables: UntypedConfigMap;
    /** Zaraz internal version of the config. */
    zarazVersion: number;
    /** Cloudflare Monitoring settings. */
    analytics?: ConfigGetResponseAnalytics | null;
    /** Consent management configuration. */
    consent?: ConfigUpdateResponseConsent | null;
    /** Single Page Application support enabled. */
    historyChange?: boolean | null;
}
export interface PutHistoryRequest {
    /** Identifier. */
    zoneId: string;
    /** ID of the Zaraz configuration to restore. */
    body: number;
}
export type HistoryUpdateResponseSettingsContextEnricher = ConfigGetResponseSettingsContextEnricher;
export type HistoryUpdateResponseSettings = ConfigGetResponseSettings;
export type HistoryUpdateResponseAnalytics = ConfigGetResponseAnalytics;
export type HistoryUpdateResponseConsentButtonTextTranslationsAcceptAllMap = {
    [key: string]: string | undefined;
};
export type HistoryUpdateResponseConsentButtonTextTranslationsConfirmMyChoicesMap = {
    [key: string]: string | undefined;
};
export type HistoryUpdateResponseConsentButtonTextTranslationsRejectAllMap = {
    [key: string]: string | undefined;
};
export interface HistoryUpdateResponseConsentButtonTextTranslations {
    /** Object where keys are language codes. */
    acceptAll: HistoryUpdateResponseConsentButtonTextTranslationsAcceptAllMap;
    /** Object where keys are language codes. */
    confirmMyChoices: HistoryUpdateResponseConsentButtonTextTranslationsConfirmMyChoicesMap;
    /** Object where keys are language codes. */
    rejectAll: HistoryUpdateResponseConsentButtonTextTranslationsRejectAllMap;
}
export type HistoryUpdateResponseConsentConsentModalIntroHTMLWithTranslationsMap = {
    [key: string]: string | undefined;
};
export type HistoryUpdateResponseConsentPurposesValue = ConfigGetResponseConsentPurposesValue;
export type HistoryUpdateResponseConsentPurposesMap = {
    [key: string]: ConfigGetResponseConsentPurposesValue | undefined;
};
export type HistoryUpdateResponseConsentPurposesWithTranslationsValueDescriptionMap = {
    [key: string]: string | undefined;
};
export type HistoryUpdateResponseConsentPurposesWithTranslationsValueNameMap = {
    [key: string]: string | undefined;
};
export interface HistoryUpdateResponseConsentPurposesWithTranslationsValue {
    /** Object where keys are language codes. */
    description: HistoryUpdateResponseConsentPurposesWithTranslationsValueDescriptionMap;
    /** Object where keys are language codes. */
    name: HistoryUpdateResponseConsentPurposesWithTranslationsValueNameMap;
    order: number;
}
export type HistoryUpdateResponseConsentPurposesWithTranslationsMap = {
    [key: string]: HistoryUpdateResponseConsentPurposesWithTranslationsValue | undefined;
};
export interface HistoryUpdateResponseConsent {
    enabled: boolean;
    buttonTextTranslations?: HistoryUpdateResponseConsentButtonTextTranslations | null;
    companyEmail?: string | null;
    companyName?: string | null;
    companyStreetAddress?: string | null;
    consentModalIntroHTML?: string | null;
    /** Object where keys are language codes. */
    consentModalIntroHTMLWithTranslations?: HistoryUpdateResponseConsentConsentModalIntroHTMLWithTranslationsMap | null;
    cookieName?: string | null;
    customCSS?: string | null;
    customIntroDisclaimerDismissed?: boolean | null;
    defaultLanguage?: string | null;
    hideModal?: boolean | null;
    /** Object where keys are purpose alpha-numeric IDs. */
    purposes?: HistoryUpdateResponseConsentPurposesMap | null;
    /** Object where keys are purpose alpha-numeric IDs. */
    purposesWithTranslations?: HistoryUpdateResponseConsentPurposesWithTranslationsMap | null;
    tcfCompliant?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutHistoryResponse {
    /** Data layer compatibility mode enabled. */
    dataLayer: boolean;
    /** The key for Zaraz debug mode. */
    debugKey: string;
    /** General Zaraz settings. */
    settings: ConfigGetResponseSettings;
    /** Tools set up under Zaraz configuration, where key is the alpha-numeric tool ID and value is the tool configuration object. */
    tools: UntypedConfigMap;
    /** Triggers set up under Zaraz configuration, where key is the trigger alpha-numeric ID and value is the trigger configuration. */
    triggers: UntypedConfigMap;
    /** Variables set up under Zaraz configuration, where key is the variable alpha-numeric ID and value is the variable configuration. Values of variables of type secret are not included. */
    variables: UntypedConfigMap;
    /** Zaraz internal version of the config. */
    zarazVersion: number;
    /** Cloudflare Monitoring settings. */
    analytics?: ConfigGetResponseAnalytics | null;
    /** Consent management configuration. */
    consent?: HistoryUpdateResponseConsent | null;
    /** Single Page Application support enabled. */
    historyChange?: boolean | null;
}
export type UpdateRequestWorkflow = "realtime" | "preview";
export interface PutZarazRequest {
    /** Identifier. */
    zoneId: string;
    /** Zaraz workflow. */
    workflow: UpdateRequestWorkflow | (string & {});
}
export type UpdateResult = "realtime" | "preview";
export type PutZarazResponse = UpdateResult;
export type CreatePublishError = CloudflareOpError;
/** Publish current Zaraz preview configuration for a zone. */
export declare const createPublish: API.OperationMethod<CreatePublishRequest, CreatePublishResponse, CreatePublishError, CloudflareOpContext>;
export type GetConfigError = Forbidden | NotFound | CloudflareOpError;
/** Gets latest Zaraz configuration for a zone. It can be preview or published configuration, whichever was the last updated. Secret variables values will not be included. */
export declare const getConfig: API.OperationMethod<GetConfigRequest, GetConfigResponse, GetConfigError, CloudflareOpContext>;
export type GetDefaultError = CloudflareOpError;
/** Gets default Zaraz configuration for a zone. */
export declare const getDefault: API.OperationMethod<GetDefaultRequest, GetDefaultResponse, GetDefaultError, CloudflareOpContext>;
export type GetExportError = CloudflareOpError;
/** Exports full current published Zaraz configuration for a zone, secret variables included. */
export declare const getExport: API.OperationMethod<GetExportRequest, GetExportResponse, GetExportError, CloudflareOpContext>;
export type GetHistoryConfigError = CloudflareOpError;
/** Gets a history of published Zaraz configurations by ID(s) for a zone. */
export declare const getHistoryConfig: API.OperationMethod<GetHistoryConfigRequest, GetHistoryConfigResponse, GetHistoryConfigError, CloudflareOpContext>;
export type GetWorkflowError = Forbidden | NotFound | CloudflareOpError;
/** Gets Zaraz workflow for a zone. */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest, GetWorkflowResponse, GetWorkflowError, CloudflareOpContext>;
export type ListHistoriesError = CloudflareOpError;
/** Lists a history of published Zaraz configuration records for a zone. */
export declare const listHistories: API.PaginatedOperationMethod<ListHistoriesRequest, ListHistoriesResponse, ListHistoriesError, CloudflareOpContext, HistoryListResultItem>;
export type PutConfigError = CloudflareOpError;
/** Updates Zaraz configuration for a zone. */
export declare const putConfig: API.OperationMethod<PutConfigRequest, PutConfigResponse, PutConfigError, CloudflareOpContext>;
export type PutHistoryError = CloudflareOpError;
/** Restores a historical published Zaraz configuration by ID for a zone. */
export declare const putHistory: API.OperationMethod<PutHistoryRequest, PutHistoryResponse, PutHistoryError, CloudflareOpContext>;
export type PutZarazError = CloudflareOpError;
/** Updates Zaraz workflow for a zone. */
export declare const putZaraz: API.OperationMethod<PutZarazRequest, PutZarazResponse, PutZarazError, CloudflareOpContext>;
//# sourceMappingURL=zaraz.d.ts.map