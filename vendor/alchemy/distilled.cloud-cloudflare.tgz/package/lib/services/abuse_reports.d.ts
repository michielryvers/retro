import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const InvalidAccountId_base: S.TaggedErrorClass<"InvalidAccountId", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidAccountId extends /*@__PURE__*/ InvalidAccountId_base {
}
declare const InvalidRequest_base: S.TaggedErrorClass<"InvalidRequest", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequest extends /*@__PURE__*/ InvalidRequest_base {
}
export type CreateRequestAct = "abuse_dmca" | "abuse_trademark" | "abuse_general" | "abuse_phishing" | "abuse_children" | "abuse_threat" | "abuse_registrar_whois" | "abuse_ncsei";
export type CreateRequestAgree = 1;
export type CreateRequestHostNotification = "send" | "send-anon";
export type CreateRequestOwnerNotification = "send" | "send-anon" | "none";
export type CreateRequestNcmecNotification = "send" | "send-anon";
export type CreateRequestRegWhoRequestRegWhoRequestType = "disclosure" | "invalid_whois";
export type CreateRequestRegWhoRequestRegWhoRequestedDataElementsItem = "registrant_name" | "registrant_organization" | "registrant_email" | "registrant_phone" | "registrant_address" | "registrant_address_country" | "registrant_address_postal_code" | "admin_name" | "admin_organization" | "admin_email" | "admin_phone" | "admin_address" | "tech_name" | "tech_organization" | "tech_email" | "tech_phone" | "tech_address";
export type CreateRequestRegWhoRequestRegWhoRequestedDataElementsList = Array<CreateRequestRegWhoRequestRegWhoRequestedDataElementsItem | (string & {})>;
export type CreateRequestRegWhoRequestRegWhoRequestorType = "government" | "corporation" | "individual";
export interface CreateRequestRegWhoRequest {
    /** Affirmation that the request is made in good faith per RDP 10.2.4. Must be true. */
    regWhoGoodFaithAffirmation: boolean;
    /** Agreement to process data lawfully per RDP 10.2.5. Must be true. */
    regWhoLawfulProcessingAgreement: boolean;
    /** Legal rights and rationale for the request per RDP 10.2.3. Required for all WHOIS requests. */
    regWhoLegalBasis: string;
    /** The type of WHOIS data request per RDP procedure. */
    regWhoRequestType: CreateRequestRegWhoRequestRegWhoRequestType | (string & {});
    /** The specific WHOIS data elements being requested per RDP 10.2.2. Required for all WHOIS requests. */
    regWhoRequestedDataElements: CreateRequestRegWhoRequestRegWhoRequestedDataElementsList;
    /** Optional authorization statement or power of attorney per RDP 10.2.1.3. */
    regWhoAuthorizationStatement?: string;
    /** The nature of the requestor per RDP 10.2.1.2. */
    regWhoRequestorType?: CreateRequestRegWhoRequestRegWhoRequestorType | (string & {});
}
export interface CreateAbuseReportRequest {
    accountId: string;
    /** The report type for submitted reports. */
    reportParam: string;
    /** The report type for submitted reports. */
    act: CreateRequestAct | (string & {});
    /** Text not exceeding 100 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    address1?: string;
    /** The name of the copyright holder. Text not exceeding 60 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    agentName?: string;
    /** Can be `0` for false or `1` for true. Must be value: 1 for DMCA reports */
    agree?: CreateRequestAgree | (number & {});
    /** Text not exceeding 255 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    city?: string;
    /** Text not exceeding 255 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    country?: string;
    /** A valid email of the abuse reporter. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    email: string;
    /** Should match the value provided in `email` */
    email2: string;
    /** Notification type based on the abuse type. For delegated reports, the report--including contact information and comments--will be forwarded to the customer in full regardless of this value. NOTE: Copyright (DMCA) and Trademark reports cannot be anonymous. */
    hostNotification?: CreateRequestHostNotification | (string & {});
    /** Text not exceeding 255 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    name: string;
    /** Text not exceeding 255 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    originalWork?: string;
    /** Notification type based on the abuse type. For delegated reports, the report--including contact information and comments--will be forwarded to the customer in full regardless of this value. NOTE: Copyright (DMCA) and Trademark reports cannot be anonymous. */
    ownerNotification: CreateRequestOwnerNotification | (string & {});
    /** Required for DMCA reports, should be same as Name. An affirmation that all information in the report is true and accurate while agreeing to the policies of Cloudflare's abuse reports */
    signature?: string;
    /** Text not exceeding 255 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    state?: string;
    /** A list of valid URLs separated by '\n' (new line character). The list of the URLs should not exceed 250 URLs. All URLs should have the same hostname. Each URL should be unique. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    urls: string;
    /** Any additional comments about the infringement not exceeding 2000 characters. Comments are kept internal to Cloudflare and not shared with the host or customer as part of regular processing. For delegated reports, comments may be shared in full. */
    comments?: string;
    /** Text not exceeding 100 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    company?: string;
    /** Text containing 2 characters */
    reportedCountry?: string;
    /** Text not exceeding 255 characters */
    reportedUserAgent?: string;
    /** Text not exceeding 20 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    tele?: string;
    /** Text not exceeding 255 characters */
    title?: string;
    /** A detailed description of the infringement, including any necessary access details and the exact steps needed to view the content, not exceeding 5000 characters. */
    justification?: string;
    /** Text not exceeding 1000 characters */
    trademarkNumber?: string;
    /** Text not exceeding 1000 characters */
    trademarkOffice?: string;
    /** Text not exceeding 1000 characters */
    trademarkSymbol?: string;
    /** A list of IP addresses separated by '\n' (new line character). The list of destination IPs should not exceed 30 IP addresses. Each one of the IP addresses ought to be unique. */
    destinationIps?: string;
    /** A comma separated list of ports and protocols e.g. 80/TCP, 22/UDP. The total size of the field should not exceed 2000 characters. Each individual port/protocol should not exceed 100 characters. The list should not have more than 30 unique ports and protocols. */
    portsProtocols?: string;
    /** A list of IP addresses separated by '\n' (new line character). The list of source IPs should not exceed 30 IP addresses. Each one of the IP addresses ought to be unique. */
    sourceIps?: string;
    /** Notification type based on the abuse type. NOTE: Copyright (DMCA) and Trademark reports cannot be anonymous. */
    ncmecNotification?: CreateRequestNcmecNotification | (string & {});
    /** RDP-mandated fields for registrar WHOIS data disclosure requests. */
    regWhoRequest?: CreateRequestRegWhoRequest;
    /** If the submitter is the target of NCSEI in the URLs of the abuse report. */
    ncseiSubjectRepresentation?: boolean;
}
export type CreateAbuseReportResponse = string;
export interface GetRequest {
    accountId: string;
    reportParam: string;
}
export interface GetResponseMitigationSummary {
    /** How many of the reported URLs were confirmed as abusive. */
    acceptedUrlCount: number;
    /** How many mitigations are active. */
    activeCount: number;
    /** Whether the report has been forwarded to an external hosting provider. */
    externalHostNotified: boolean;
    /** How many mitigations are under review. */
    inReviewCount: number;
    /** How many mitigations are pending their effective date. */
    pendingCount: number;
}
export type GetResponseStatus = "accepted" | "in_review";
export type GetResponseType = "PHISH" | "GEN" | "THREAT" | "DMCA" | "EMER" | "TM" | "REG_WHO" | "NCSEI" | "NETWORK";
export interface GetResponseSubmitter {
    company?: string | null;
    email?: string | null;
    name?: string | null;
    telephone?: string | null;
}
export type GetResponseUrlsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResponse {
    /** Public facing ID of abuse report, aka abuse_rand. */
    id: string;
    /** Creation date of report. Time in RFC 3339 format (https://www.rfc-editor.org/rfc/rfc3339.html) */
    cdate: string;
    /** Domain that relates to the report. */
    domain: string;
    /** A summary of the mitigations related to this report. */
    mitigationSummary: GetResponseMitigationSummary;
    /** An enum value that represents the status of an abuse record */
    status: GetResponseStatus;
    /** The abuse report type */
    type: GetResponseType;
    /** Justification for the report. */
    justification?: string | null;
    /** Original work / Targeted brand in the alleged abuse. */
    originalWork?: string | null;
    /** Information about the submitter of the report. */
    submitter?: GetResponseSubmitter | null;
    urls?: GetResponseUrlsList | null;
}
export interface GetSubmittedRequest {
    accountId: string;
    reportId: string;
}
export type GetSubmittedResponseDenialReason = "unable_to_confirm" | "incomplete_report" | "not_on_cloudflare" | "duplicate_report" | "content_removed" | "report_details_mismatch" | "no_abuse_found" | "missing_original_work" | "direct_url_required" | "wrong_report_category" | "content_unavailable" | "law_enforcement_referral_required" | "domain_dispute_process_required";
export type GetSubmittedResponseStatus = "submitted" | "accepted" | "denied";
export type GetSubmittedResponseType = "PHISH" | "GEN" | "THREAT" | "DMCA" | "EMER" | "TM" | "REG_WHO" | "NCSEI" | "NETWORK";
export type GetSubmittedResponseUrlsList = Array<string>;
export type GetSubmittedResponseDestinationIpsList = Array<string>;
export type GetSubmittedResponsePortsProtocolsList = Array<string>;
export type GetSubmittedResponseRegWhoRequestRegWhoRequestType = "disclosure" | "invalid_whois";
export type GetSubmittedResponseRegWhoRequestRegWhoRequestedDataElementsItem = "registrant_name" | "registrant_organization" | "registrant_email" | "registrant_phone" | "registrant_address" | "registrant_address_country" | "registrant_address_postal_code" | "admin_name" | "admin_organization" | "admin_email" | "admin_phone" | "admin_address" | "tech_name" | "tech_organization" | "tech_email" | "tech_phone" | "tech_address";
export type GetSubmittedResponseRegWhoRequestRegWhoRequestedDataElementsList = Array<GetSubmittedResponseRegWhoRequestRegWhoRequestedDataElementsItem>;
export type GetSubmittedResponseRegWhoRequestRegWhoRequestorType = "government" | "corporation" | "individual";
export interface GetSubmittedResponseRegWhoRequest {
    /** Affirmation that the request is made in good faith per RDP 10.2.4. Must be true. */
    regWhoGoodFaithAffirmation: boolean;
    /** Agreement to process data lawfully per RDP 10.2.5. Must be true. */
    regWhoLawfulProcessingAgreement: boolean;
    /** Legal rights and rationale for the request per RDP 10.2.3. Required for all WHOIS requests. */
    regWhoLegalBasis: string;
    /** The type of WHOIS data request per RDP procedure. */
    regWhoRequestType: GetSubmittedResponseRegWhoRequestRegWhoRequestType;
    /** The specific WHOIS data elements being requested per RDP 10.2.2. Required for all WHOIS requests. */
    regWhoRequestedDataElements: GetSubmittedResponseRegWhoRequestRegWhoRequestedDataElementsList;
    /** Optional authorization statement or power of attorney per RDP 10.2.1.3. */
    regWhoAuthorizationStatement?: string | null;
    /** The nature of the requestor per RDP 10.2.1.2. */
    regWhoRequestorType?: GetSubmittedResponseRegWhoRequestRegWhoRequestorType | null;
}
export type GetSubmittedResponseSourceIpsList = Array<string>;
export type GetSubmittedResponseSubmitter = GetResponseSubmitter;
export type GetSubmittedResponseSubtypesList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSubmittedResponse {
    /** Public report code. */
    id: string;
    /** Time the report was submitted. */
    cdate: string;
    /** Submitter-safe reason for a denied report. Null when unavailable. */
    denialReason: GetSubmittedResponseDenialReason;
    /** Domain identified in the report. */
    domain: string;
    /** Whether the submitter provided the Digital Services Act attestation. */
    dsaAttestation: boolean;
    /** Status visible to the account that submitted the report. */
    status: GetSubmittedResponseStatus;
    /** The abuse report type */
    type: GetSubmittedResponseType;
    /** URLs supplied with the report. */
    urls: GetSubmittedResponseUrlsList;
    /** Authorized agent name supplied with the report. */
    agentName?: string | null;
    /** Additional comments supplied with the report. */
    comments?: string | null;
    /** The string "on" when a court proceeding applies to the report; otherwise omitted. */
    court?: string | null;
    /** Destination IP addresses supplied with a network abuse report. */
    destinationIps?: GetSubmittedResponseDestinationIpsList | null;
    /** Submitter preference for notifying the hosting provider. */
    hostNotification?: string | null;
    /** Evidence supplied with the report. */
    justification?: string | null;
    /** Submitter preference for notifying NCMEC. */
    ncmecNotification?: string | null;
    /** Representation supplied for an NCSEI report. */
    ncseiSubjectRepresentation?: boolean | null;
    /** Original work or targeted brand supplied with the report. */
    originalWork?: string | null;
    /** Submitter preference for notifying the content owner. */
    ownerNotification?: string | null;
    /** Ports and protocols supplied with a network abuse report. */
    portsProtocols?: GetSubmittedResponsePortsProtocolsList | null;
    /** RDP-mandated fields for registrar WHOIS data disclosure requests. */
    regWhoRequest?: GetSubmittedResponseRegWhoRequest | null;
    /** Country associated with the reported activity. */
    reportedCountry?: string | null;
    /** User agent associated with the reported activity. */
    reportedUserAgent?: string | null;
    /** Source IP addresses supplied with a network abuse report. */
    sourceIps?: GetSubmittedResponseSourceIpsList | null;
    /** Information about the submitter of the report. */
    submitter?: GetResponseSubmitter | null;
    /** Additional abuse classifications supplied with the report. */
    subtypes?: GetSubmittedResponseSubtypesList | null;
    /** Title supplied with the report. */
    title?: string | null;
    /** The string "on" when a UDRP proceeding applies to the report; otherwise omitted. */
    udrp?: string | null;
    /** The string "on" when a URS proceeding applies to the report; otherwise omitted. */
    urs?: string | null;
}
export type ListRequestMitigationStatus = "pending" | "active" | "in_review" | "cancelled" | "removed";
export type ListRequestStatus = "accepted" | "in_review";
export type ListRequestType = "PHISH" | "GEN" | "THREAT" | "DMCA" | "EMER" | "TM" | "REG_WHO" | "NCSEI" | "NETWORK";
export interface ListAbuseReportsRequest {
    accountId: string;
    /** Returns reports created after the specified date */
    createdAfter?: string;
    /** Returns reports created before the specified date */
    createdBefore?: string;
    /** Filter by domain name related to the abuse report */
    domain?: string;
    /** Filter reports that have any mitigations in the given status. */
    mitigationStatus?: ListRequestMitigationStatus | (string & {});
    /** Where in pagination to start listing abuse reports */
    page?: number;
    /** How many abuse reports per page to list */
    perPage?: number;
    /** Free-text search. Returns reports whose report ID starts with the term or whose domain contains the term, both case-insensitively. Surrounding whitespace is ignored, and an empty value is treated as absent. Combined with the other filters using AND. */
    search?: string;
    /** A property to sort by, followed by the order (id, cdate, domain, type, status) */
    sort?: string;
    /** Filter by the status of the report. */
    status?: ListRequestStatus | (string & {});
    /** Filter by the type of the report. */
    type?: ListRequestType | (string & {});
}
export type ListResponseReportsItemMitigationSummary = GetResponseMitigationSummary;
export type ListResponseReportsItemStatus = "accepted" | "in_review";
export type ListResponseReportsItemType = "PHISH" | "GEN" | "THREAT" | "DMCA" | "EMER" | "TM" | "REG_WHO" | "NCSEI" | "NETWORK";
export type ListResponseReportsItemSubmitter = GetResponseSubmitter;
export type ListResponseReportsItemUrlsList = Array<string>;
export interface ListResponseReportsItem {
    /** Public facing ID of abuse report, aka abuse_rand. */
    id: string;
    /** Creation date of report. Time in RFC 3339 format (https://www.rfc-editor.org/rfc/rfc3339.html) */
    cdate: string;
    /** Domain that relates to the report. */
    domain: string;
    /** A summary of the mitigations related to this report. */
    mitigationSummary: GetResponseMitigationSummary;
    /** An enum value that represents the status of an abuse record */
    status: ListResponseReportsItemStatus;
    /** The abuse report type */
    type: ListResponseReportsItemType;
    /** Justification for the report. */
    justification?: string | null;
    /** Original work / Targeted brand in the alleged abuse. */
    originalWork?: string | null;
    /** Information about the submitter of the report. */
    submitter?: GetResponseSubmitter | null;
    urls?: ListResponseReportsItemUrlsList | null;
}
export type ListResponseReportsList = Array<ListResponseReportsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListAbuseReportsResponse {
    reports: ListResponseReportsList;
}
export type MitigationsListRequestEntityType = "url_pattern" | "account" | "zone" | "custom_expression";
export type MitigationsListRequestSort = "type,asc" | "type,desc" | "effective_date,asc" | "effective_date,desc" | "status,asc" | "status,desc" | "entity_type,asc" | "entity_type,desc";
export type MitigationsListRequestStatus = "pending" | "active" | "in_review" | "cancelled" | "removed";
export interface ListMitigationsRequest {
    accountId: string;
    reportId: string;
    /** Returns mitigation that were dispatched after the given date */
    effectiveAfter?: string;
    /** Returns mitigations that were dispatched before the given date */
    effectiveBefore?: string;
    /** Filter by the type of entity the mitigation impacts. */
    entityType?: MitigationsListRequestEntityType | (string & {});
    /** Where in pagination to start listing abuse reports */
    page?: number;
    /** How many abuse reports per page to list */
    perPage?: number;
    /** A property to sort by, followed by the order */
    sort?: MitigationsListRequestSort | (string & {});
    /** Filter by the status of the mitigation. */
    status?: MitigationsListRequestStatus | (string & {});
    /** Filter by the type of mitigation. This filter parameter can be specified multiple times to include multiple types of mitigations in the result set. */
    type?: string;
}
export type MitigationsListResponseMitigationsItemEntityType = "url_pattern" | "account" | "zone" | "custom_expression";
export type MitigationsListResponseMitigationsItemStatus = "pending" | "active" | "in_review" | "cancelled" | "removed";
export interface MitigationsListResponseMitigationsItem {
    /** ID of remediation. */
    id: string;
    /** Date when the mitigation will become active. Time in RFC 3339 format (https://www.rfc-editor.org/rfc/rfc3339.html) */
    effectiveDate: string;
    entityId: string;
    /** The type of entity targeted by a mitigation. */
    entityType: MitigationsListResponseMitigationsItemEntityType;
    /** The status of a mitigation */
    status: MitigationsListResponseMitigationsItemStatus;
    /** The type of mitigation applied to a reported entity. */
    type: string;
}
export type MitigationsListResponseMitigationsList = Array<MitigationsListResponseMitigationsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListMitigationsResponse {
    mitigations: MitigationsListResponseMitigationsList;
}
export type ListSubmittedRequestDomainList = Array<string>;
export type ListSubmittedRequestStatus = "submitted" | "accepted" | "denied";
export type ListSubmittedRequestStatusList = Array<ListSubmittedRequestStatus | (string & {})>;
export type ListSubmittedRequestType = "PHISH" | "GEN" | "THREAT" | "DMCA" | "EMER" | "TM" | "REG_WHO" | "NCSEI" | "NETWORK";
export type ListSubmittedRequestTypeList = Array<ListSubmittedRequestType | (string & {})>;
export interface ListSubmittedRequest {
    accountId: string;
    /** Filter by report code. */
    id?: string;
    /** Return reports submitted after this time. */
    createdAfter?: string;
    /** Return reports submitted before this time. */
    createdBefore?: string;
    /** Filter by reported domain. This parameter can be specified multiple times. */
    domain?: ListSubmittedRequestDomainList;
    /** Page of submitted reports to return. */
    page?: number;
    /** Number of submitted reports per page. */
    perPage?: number;
    /** A property and direction to sort by (id, cdate, domain, type, status). */
    sort?: string;
    /** Filter by submitter-facing status. This parameter can be specified multiple times. */
    status?: ListSubmittedRequestStatusList;
    /** Filter by report type. This parameter can be specified multiple times. */
    type?: ListSubmittedRequestTypeList;
}
export type ListSubmittedResponseReportsItemDenialReason = "unable_to_confirm" | "incomplete_report" | "not_on_cloudflare" | "duplicate_report" | "content_removed" | "report_details_mismatch" | "no_abuse_found" | "missing_original_work" | "direct_url_required" | "wrong_report_category" | "content_unavailable" | "law_enforcement_referral_required" | "domain_dispute_process_required";
export type ListSubmittedResponseReportsItemStatus = "submitted" | "accepted" | "denied";
export type ListSubmittedResponseReportsItemType = "PHISH" | "GEN" | "THREAT" | "DMCA" | "EMER" | "TM" | "REG_WHO" | "NCSEI" | "NETWORK";
export type ListSubmittedResponseReportsItemSubmitter = GetResponseSubmitter;
export interface ListSubmittedResponseReportsItem {
    /** Public report code. */
    id: string;
    /** Time the report was submitted. */
    cdate: string;
    /** Submitter-safe reason for a denied report. Null when unavailable. */
    denialReason: ListSubmittedResponseReportsItemDenialReason;
    /** Domain identified in the report. */
    domain: string;
    /** Status visible to the account that submitted the report. */
    status: ListSubmittedResponseReportsItemStatus;
    /** The abuse report type */
    type: ListSubmittedResponseReportsItemType;
    /** Information about the submitter of the report. */
    submitter?: GetResponseSubmitter | null;
}
export type ListSubmittedResponseReportsList = Array<ListSubmittedResponseReportsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListSubmittedResponse {
    reports: ListSubmittedResponseReportsList;
}
export interface ListSubmittedEmailsRequest {
    accountId: string;
    reportId: string;
    /** Page number to retrieve (default 1). */
    page?: number;
    /** Number of emails per page (default 20, max 100). */
    perPage?: number;
}
export interface ListSubmittedEmailsResponseEmailsItem {
    /** Unique identifier of the email. */
    id: string;
    /** Body content of the email. */
    body: string;
    /** Email address of the recipient. */
    recipient: string;
    /** When the email was sent. Time in RFC 3339 format (https://www.rfc-editor.org/rfc/rfc3339.html) */
    sentAt: string;
    /** Subject line of the email. */
    subject: string;
}
export type ListSubmittedEmailsResponseEmailsList = Array<ListSubmittedEmailsResponseEmailsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListSubmittedEmailsResponse {
    emails: ListSubmittedEmailsResponseEmailsList;
}
export type MitigationsReviewRequestAppealsItemReason = "removed" | "misclassified";
export interface MitigationsReviewRequestAppealsItem {
    /** ID of the mitigation to appeal. */
    id: string;
    /** Reason why the customer is appealing. */
    reason: MitigationsReviewRequestAppealsItemReason | (string & {});
}
export type MitigationsReviewRequestAppealsList = Array<MitigationsReviewRequestAppealsItem>;
export type MitigationsReviewRequestDataUrlsList = Array<string>;
export interface MitigationsReviewRequestData {
    city: string;
    country: string;
    email: string;
    fullName: string;
    jurisdictionConsent: boolean;
    perjuryAttestation: boolean;
    phoneNumber: string;
    signature: string;
    state: string;
    streetAddress: string;
    urls: MitigationsReviewRequestDataUrlsList;
    zipCode: string;
    company?: string;
    counterNoticeResponse?: string;
}
export type MitigationsReviewRequestType = "counter_notice" | "content_removed";
export interface ReviewMitigationRequest {
    accountId: string;
    reportId: string;
    /** List of mitigations to appeal. */
    appeals?: MitigationsReviewRequestAppealsList;
    /** Counter-notice details supporting an appeal. */
    data?: MitigationsReviewRequestData;
    /** The type of appeal being submitted. */
    type?: MitigationsReviewRequestType | (string & {});
}
export type MitigationsReviewResultItemEntityType = "url_pattern" | "account" | "zone" | "custom_expression";
export type MitigationsReviewResultItemStatus = "pending" | "active" | "in_review" | "cancelled" | "removed";
export interface MitigationsReviewResultItem {
    /** ID of remediation. */
    id: string;
    /** Date when the mitigation will become active. Time in RFC 3339 format (https://www.rfc-editor.org/rfc/rfc3339.html) */
    effectiveDate: string;
    entityId: string;
    /** The type of entity targeted by a mitigation. */
    entityType: MitigationsReviewResultItemEntityType;
    /** The status of a mitigation */
    status: MitigationsReviewResultItemStatus;
    /** The type of mitigation applied to a reported entity. */
    type: string;
}
export type MitigationsReviewResultList = Array<MitigationsReviewResultItem>;
export interface ReviewMitigationResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MitigationsReviewResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type CreateAbuseReportError = InvalidRequest | CloudflareOpError;
/** Submit an abuse report of a particular type. Requires the abuse-reports entitlement on the account (Enterprise accounts have it by default; other accounts must request access) and an API token with the `Trust and Safety Write` permission. If the account is not entitled, the request is rejected with an HTTP `401` response (see below). Delegated reports: In limited circumstances, Cloudflare works with select customers who have established abuse-handling programs. For these customers, Cloudflare may forward abuse reports directly and in full--including reporter contact information, comments, and supporting evidence--without redaction or preprocessing by Cloudflare. This allows the customer to investigate and respond using their own policies and processes. For delegated reports, the report--including contact information and comments--will be forwarded to the customer in full regardless of the `host_notification` and `owner_notification` values. */
export declare const createAbuseReport: API.OperationMethod<CreateAbuseReportRequest, CreateAbuseReportResponse, CreateAbuseReportError, CloudflareOpContext>;
export type GetError = CloudflareOpError;
/** Retrieve the details of an abuse report made against a domain or other content associated with the account. To retrieve a report that the account submitted, use the submitted abuse report endpoint instead. */
export declare const get: API.OperationMethod<GetRequest, GetResponse, GetError, CloudflareOpContext>;
export type GetSubmittedError = CloudflareOpError;
/** Retrieve a report submitted by the account. */
export declare const getSubmitted: API.OperationMethod<GetSubmittedRequest, GetSubmittedResponse, GetSubmittedError, CloudflareOpContext>;
export type ListAbuseReportsError = InvalidAccountId | CloudflareOpError;
/** List abuse reports made against domains or other content associated with the account. To list reports that the account submitted, use the submitted abuse reports endpoint instead. */
export declare const listAbuseReports: API.OperationMethod<ListAbuseReportsRequest, ListAbuseReportsResponse, ListAbuseReportsError, CloudflareOpContext>;
export type ListMitigationsError = CloudflareOpError;
/** List mitigations done to remediate the abuse report. */
export declare const listMitigations: API.OperationMethod<ListMitigationsRequest, ListMitigationsResponse, ListMitigationsError, CloudflareOpContext>;
export type ListSubmittedError = CloudflareOpError;
/** List abuse reports submitted by the account. */
export declare const listSubmitted: API.OperationMethod<ListSubmittedRequest, ListSubmittedResponse, ListSubmittedError, CloudflareOpContext>;
export type ListSubmittedEmailsError = CloudflareOpError;
/** List successful emails sent to the submitter of a report submitted by the account. Does not include emails sent to customers or hosts. */
export declare const listSubmittedEmails: API.OperationMethod<ListSubmittedEmailsRequest, ListSubmittedEmailsResponse, ListSubmittedEmailsError, CloudflareOpContext>;
export type ReviewMitigationError = CloudflareOpError;
/** Request a review of mitigations applied because of an abuse report, or submit a report-level appeal. - To request a review of specific mitigations, send `appeals` with the mitigation IDs and reasons. Repeating a request for a mitigation with an unresolved appeal is idempotent and returns that mitigation in the in-review state. - To submit a report-level appeal, send `type` and, for a `counter_notice`, the counter-notice details in `data`. Report-level appeals are currently available only for DMCA (copyright) reports. */
export declare const reviewMitigation: API.PaginatedOperationMethod<ReviewMitigationRequest, ReviewMitigationResponse, ReviewMitigationError, CloudflareOpContext, MitigationsReviewResultItem>;
//# sourceMappingURL=abuse_reports.d.ts.map