import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type GetRequestCloudflareVersion = "1.0";
export interface GetRequest {
    /** Identifier. */
    zoneId: string;
    cloudflareVersion: GetRequestCloudflareVersion | (string & {});
}
export type GetResponseMode = "off" | "monitor" | "arm";
export interface GetResponseRulesItem {
    /** The filter expression that determines which requests the rule matches. */
    expression: string;
    /** Whether Precursor shows an interstitial when it takes action on a request. */
    showInterstitial: boolean;
    /** The read-only identifier that Cloudflare assigns to the rule. */
    id?: string | null;
    /** An informative description of the rule. */
    description?: string | null;
    /** Whether the rule is active. */
    enabled?: boolean | null;
}
export type GetResponseRulesList = Array<GetResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResponse {
    /** Controls Precursor detection for the zone. `off` disables detection, `monitor` records detections without affecting bot scores, and `arm` allows detections to affect bot scores. */
    mode?: GetResponseMode | null;
    /** The ordered list of Precursor rules for the zone. */
    rules?: GetResponseRulesList | null;
    /** Whether Precursor shows an interstitial when it takes action on a request. */
    showInterstitial?: boolean | null;
}
export type UpdateRequestCloudflareVersion = "1.0";
export type UpdateRequestMode = "off" | "monitor" | "arm";
export interface UpdateRequestRulesItem {
    /** The filter expression that determines which requests the rule matches. */
    expression: string;
    /** Whether Precursor shows an interstitial when it takes action on a request. */
    showInterstitial: boolean;
    /** The read-only identifier that Cloudflare assigns to the rule. */
    id?: string;
    /** An informative description of the rule. */
    description?: string;
    /** Whether the rule is active. */
    enabled?: boolean;
}
export type UpdateRequestRulesList = Array<UpdateRequestRulesItem>;
export interface UpdateRequest {
    /** Identifier. */
    zoneId: string;
    cloudflareVersion: UpdateRequestCloudflareVersion | (string & {});
    /** Controls Precursor detection for the zone. `off` disables detection, `monitor` records detections without affecting bot scores, and `arm` allows detections to affect bot scores. */
    mode?: UpdateRequestMode | (string & {});
    /** The ordered list of Precursor rules for the zone. */
    rules?: UpdateRequestRulesList;
    /** Whether Precursor shows an interstitial when it takes action on a request. */
    showInterstitial?: boolean;
}
export type UpdateResponseMode = "off" | "monitor" | "arm";
export type UpdateResponseRulesItem = GetResponseRulesItem;
export type UpdateResponseRulesList = Array<GetResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResponse {
    /** Controls Precursor detection for the zone. `off` disables detection, `monitor` records detections without affecting bot scores, and `arm` allows detections to affect bot scores. */
    mode?: UpdateResponseMode | null;
    /** The ordered list of Precursor rules for the zone. */
    rules?: UpdateResponseRulesList | null;
    /** Whether Precursor shows an interstitial when it takes action on a request. */
    showInterstitial?: boolean | null;
}
export type GetError = CloudflareOpError;
/** Retrieve a zone's Precursor configuration: the detection `mode`, whether to `show_interstitial`, and the ordered list of `rules`. */
export declare const get: API.OperationMethod<GetRequest, GetResponse, GetError, CloudflareOpContext>;
export type UpdateError = CloudflareOpError;
/** Updates the Precursor configuration for a zone. `mode` controls whether Precursor detection is off, monitoring, or armed. `show_interstitial` controls the zone-level response when armed. `rules` is the ordered list of overrides for matching requests. This is a partial update: only the fields present in the request body are changed. - Sending an empty array ( `[]`) clears all rules. - At least one of `mode`, `show_interstitial`, or `rules` must be present; an empty body ( `{}`) is rejected with `400`. - Rule `id` is read-only (assigned by Cloudflare) and ignored on input. - Rule `show_interstitial` is required and controls the response for requests that match that rule. - Rule `expression` is limited to 4000 characters. The limit applies to each rule individually, not to the combined size of all rules. */
export declare const update: API.OperationMethod<UpdateRequest, UpdateResponse, UpdateError, CloudflareOpContext>;
//# sourceMappingURL=precursor.d.ts.map