import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type DataSecurityContentFindingsTopNRequestFiltersItemValuesItem = string | number | boolean;
export type DataSecurityContentFindingsTopNRequestFiltersItemValuesList = Array<DataSecurityContentFindingsTopNRequestFiltersItemValuesItem>;
export interface DataSecurityContentFindingsTopNRequestFiltersItem {
    /** Specifies the column name to filter on. Requires a valid column for the target dataset (e.g. `country`, `allowed`, `appId`). */
    name: string;
    /** Filter operator. Common values: `eq`, `neq`, `in`, `not_in`, `gt`, `lt`, `gte`, `lte`. */
    op: string;
    /** Values to match against. Type depends on the column. */
    values: DataSecurityContentFindingsTopNRequestFiltersItemValuesList;
}
export type DataSecurityContentFindingsTopNRequestFiltersList = Array<DataSecurityContentFindingsTopNRequestFiltersItem>;
export interface DataSecurityContentFindingsTopNRequest {
    accountId: string;
    /** Filters to apply. `findingType = content` is applied automatically for CASB data. */
    filters: DataSecurityContentFindingsTopNRequestFiltersList;
    /** Start of the query time range (inclusive). RFC3339. */
    from: string;
    /** Maximum number of integrations to return. */
    n: number;
    /** End of the query time range (exclusive). RFC3339. */
    to: string;
}
export type DataSecurityContentFindingsTopNResultItemMap = {
    [key: string]: unknown | undefined;
};
export type DataSecurityContentFindingsTopNResultList = Array<DataSecurityContentFindingsTopNResultItemMap>;
export type DataSecurityContentFindingsTopNResponse = DataSecurityContentFindingsTopNResultList;
export type DataSecurityFindingsSummaryRequestFiltersItemValuesItem = string | number | boolean;
export type DataSecurityFindingsSummaryRequestFiltersItemValuesList = Array<DataSecurityFindingsSummaryRequestFiltersItemValuesItem>;
export interface DataSecurityFindingsSummaryRequestFiltersItem {
    /** Specifies the column name to filter on. Requires a valid column for the target dataset (e.g. `country`, `allowed`, `appId`). */
    name: string;
    /** Filter operator. Common values: `eq`, `neq`, `in`, `not_in`, `gt`, `lt`, `gte`, `lte`. */
    op: string;
    /** Values to match against. Type depends on the column. */
    values: DataSecurityFindingsSummaryRequestFiltersItemValuesList;
}
export type DataSecurityFindingsSummaryRequestFiltersList = Array<DataSecurityFindingsSummaryRequestFiltersItem>;
export interface DataSecurityFindingsSummaryRequest {
    accountId: string;
    /** Filters to apply. */
    filters: DataSecurityFindingsSummaryRequestFiltersList;
    /** Start of the query time range (inclusive). RFC3339. */
    from: string;
    /** End of the query time range (exclusive). RFC3339. */
    to: string;
}
export type DataSecurityFindingsSummaryResponseCurrentTotalItemMap = {
    [key: string]: unknown | undefined;
};
export type DataSecurityFindingsSummaryResponseCurrentTotalList = Array<DataSecurityFindingsSummaryResponseCurrentTotalItemMap>;
export type DataSecurityFindingsSummaryResponsePreviousTotalItemMap = {
    [key: string]: unknown | undefined;
};
export type DataSecurityFindingsSummaryResponsePreviousTotalList = Array<DataSecurityFindingsSummaryResponsePreviousTotalItemMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DataSecurityFindingsSummaryResponse {
    /** Aggregated stats for the requested time range. */
    currentTotal: DataSecurityFindingsSummaryResponseCurrentTotalList;
    /** Aggregated stats for the equivalent preceding time range, for trend comparison. */
    previousTotal: DataSecurityFindingsSummaryResponsePreviousTotalList;
}
export type DataSecurityFindingsTimeseriesRequestFiltersItemValuesItem = string | number | boolean;
export type DataSecurityFindingsTimeseriesRequestFiltersItemValuesList = Array<DataSecurityFindingsTimeseriesRequestFiltersItemValuesItem>;
export interface DataSecurityFindingsTimeseriesRequestFiltersItem {
    /** Specifies the column name to filter on. Requires a valid column for the target dataset (e.g. `country`, `allowed`, `appId`). */
    name: string;
    /** Filter operator. Common values: `eq`, `neq`, `in`, `not_in`, `gt`, `lt`, `gte`, `lte`. */
    op: string;
    /** Values to match against. Type depends on the column. */
    values: DataSecurityFindingsTimeseriesRequestFiltersItemValuesList;
}
export type DataSecurityFindingsTimeseriesRequestFiltersList = Array<DataSecurityFindingsTimeseriesRequestFiltersItem>;
export interface DataSecurityFindingsTimeseriesRequest {
    accountId: string;
    /** Filters to apply. */
    filters: DataSecurityFindingsTimeseriesRequestFiltersList;
    /** Start of the query time range (inclusive). RFC3339. */
    from: string;
    /** End of the query time range (exclusive). RFC3339. */
    to: string;
}
export type DataSecurityFindingsTimeseriesResponseSlotsItemMap = {
    [key: string]: unknown | undefined;
};
export type DataSecurityFindingsTimeseriesResponseSlotsList = Array<DataSecurityFindingsTimeseriesResponseSlotsItemMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DataSecurityFindingsTimeseriesResponse {
    /** Contains time-bucketed result rows. Each slot includes a `timestamp` plus `content` and `posture` maps with `cloud` and `saas` keys. */
    slots: DataSecurityFindingsTimeseriesResponseSlotsList;
    /** Always null for this endpoint. */
    resolution?: string | null;
}
export type SummaryRequestFiltersItemValuesItem = string | number | boolean;
export type SummaryRequestFiltersItemValuesList = Array<SummaryRequestFiltersItemValuesItem>;
export interface SummaryRequestFiltersItem {
    /** Specifies the column name to filter on. Requires a valid column for the target dataset (e.g. `country`, `allowed`, `appId`). */
    name: string;
    /** Filter operator. Common values: `eq`, `neq`, `in`, `not_in`, `gt`, `lt`, `gte`, `lte`. */
    op: string;
    /** Values to match against. Type depends on the column. */
    values: SummaryRequestFiltersItemValuesList;
}
export type SummaryRequestFiltersList = Array<SummaryRequestFiltersItem>;
export type SummaryRequestGroupByList = Array<string>;
export type SummaryRequestStatsList = Array<string>;
export interface SummaryRequest {
    accountId: string;
    dataset: string;
    /** Filters to apply before aggregating results. */
    filters: SummaryRequestFiltersList;
    /** The start of the query time range (inclusive). RFC3339 format with timezone is required (e.g. `2024-11-05T00:00:00Z`). */
    from: string;
    /** Specifies the column names to group results by. Requires valid columns for the target dataset. */
    groupBy: SummaryRequestGroupByList;
    /** Specifies the stat names to include in results. Requires valid stats for the target dataset (e.g. `attemptsTotal`, `bytesTotal`). */
    stats: SummaryRequestStatsList;
    /** Specifies the end of the query time range (exclusive). Requires RFC3339 format with timezone. */
    to: string;
}
export type SummaryResponseCurrentTotalItemMap = {
    [key: string]: unknown | undefined;
};
export type SummaryResponseCurrentTotalList = Array<SummaryResponseCurrentTotalItemMap>;
export type SummaryResponsePreviousTotalItemMap = {
    [key: string]: unknown | undefined;
};
export type SummaryResponsePreviousTotalList = Array<SummaryResponsePreviousTotalItemMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SummaryResponse {
    /** Aggregated stats for the requested time range. */
    currentTotal: SummaryResponseCurrentTotalList;
    /** Aggregated stats for the equivalent preceding time range, for trend comparison. */
    previousTotal: SummaryResponsePreviousTotalList;
}
export type TimeseriesRequestFiltersItemValuesItem = string | number | boolean;
export type TimeseriesRequestFiltersItemValuesList = Array<TimeseriesRequestFiltersItemValuesItem>;
export interface TimeseriesRequestFiltersItem {
    /** Specifies the column name to filter on. Requires a valid column for the target dataset (e.g. `country`, `allowed`, `appId`). */
    name: string;
    /** Filter operator. Common values: `eq`, `neq`, `in`, `not_in`, `gt`, `lt`, `gte`, `lte`. */
    op: string;
    /** Values to match against. Type depends on the column. */
    values: TimeseriesRequestFiltersItemValuesList;
}
export type TimeseriesRequestFiltersList = Array<TimeseriesRequestFiltersItem>;
export type TimeseriesRequestGroupByList = Array<string>;
export type TimeseriesRequestStatsList = Array<string>;
export interface TimeseriesRequest {
    accountId: string;
    dataset: string;
    /** Filters to apply before aggregating results. */
    filters: TimeseriesRequestFiltersList;
    /** The start of the query time range (inclusive). RFC3339 format with timezone is required (e.g. `2024-11-05T00:00:00Z`). */
    from: string;
    /** Specifies the column names to group results by. Requires valid columns for the target dataset. */
    groupBy: TimeseriesRequestGroupByList;
    /** Time bucket size for grouping results. Controls the granularity of the returned time slots. */
    resolution: string;
    /** Specifies the stat names to include in results. Requires valid stats for the target dataset (e.g. `attemptsTotal`, `bytesTotal`). */
    stats: TimeseriesRequestStatsList;
    /** Specifies the end of the query time range (exclusive). Requires RFC3339 format with timezone. */
    to: string;
}
export type TimeseriesResponseSlotsItemMap = {
    [key: string]: unknown | undefined;
};
export type TimeseriesResponseSlotsList = Array<TimeseriesResponseSlotsItemMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface TimeseriesResponse {
    /** The resolution used for time bucketing. */
    resolution: string;
    /** Time-bucketed result rows. Each slot contains a `time_bucket` field plus the requested stats and group-by dimensions. */
    slots: TimeseriesResponseSlotsList;
}
export type TopNRequestFiltersItemValuesItem = string | number | boolean;
export type TopNRequestFiltersItemValuesList = Array<TopNRequestFiltersItemValuesItem>;
export interface TopNRequestFiltersItem {
    /** Specifies the column name to filter on. Requires a valid column for the target dataset (e.g. `country`, `allowed`, `appId`). */
    name: string;
    /** Filter operator. Common values: `eq`, `neq`, `in`, `not_in`, `gt`, `lt`, `gte`, `lte`. */
    op: string;
    /** Values to match against. Type depends on the column. */
    values: TopNRequestFiltersItemValuesList;
}
export type TopNRequestFiltersList = Array<TopNRequestFiltersItem>;
export type TopNRequestGroupByList = Array<string>;
export type TopNRequestStatsList = Array<string>;
export interface TopNRequest {
    accountId: string;
    dataset: string;
    /** Filters to apply before aggregating results. */
    filters: TopNRequestFiltersList;
    /** The start of the query time range (inclusive). RFC3339 format with timezone is required (e.g. `2024-11-05T00:00:00Z`). */
    from: string;
    /** Specifies the column names to group results by. Requires valid columns for the target dataset. */
    groupBy: TopNRequestGroupByList;
    /** Maximum number of results to return. */
    n: number;
    /** Specifies the stat name for sorting results in descending order. Requires a valid stat for the target dataset. */
    orderBy: string;
    /** Specifies the stat names to include in results. Requires valid stats for the target dataset (e.g. `attemptsTotal`, `bytesTotal`). */
    stats: TopNRequestStatsList;
    /** Specifies the end of the query time range (exclusive). Requires RFC3339 format with timezone. */
    to: string;
}
export type TopNResultItemMap = {
    [key: string]: unknown | undefined;
};
export type TopNResultList = Array<TopNResultItemMap>;
export type TopNResponse = TopNResultList;
export type DataSecurityContentFindingsTopNError = CloudflareOpError;
/** Returns the top N integrations ranked by total content findings. */
export declare const dataSecurityContentFindingsTopN: API.OperationMethod<DataSecurityContentFindingsTopNRequest, DataSecurityContentFindingsTopNResponse, DataSecurityContentFindingsTopNError, CloudflareOpContext>;
export type DataSecurityFindingsSummaryError = CloudflareOpError;
/** Returns aggregate current-period and previous-period totals for CASB findings. */
export declare const dataSecurityFindingsSummary: API.OperationMethod<DataSecurityFindingsSummaryRequest, DataSecurityFindingsSummaryResponse, DataSecurityFindingsSummaryError, CloudflareOpContext>;
export type DataSecurityFindingsTimeseriesError = CloudflareOpError;
/** Returns merged time-bucketed CASB findings. */
export declare const dataSecurityFindingsTimeseries: API.OperationMethod<DataSecurityFindingsTimeseriesRequest, DataSecurityFindingsTimeseriesResponse, DataSecurityFindingsTimeseriesError, CloudflareOpContext>;
export type SummaryError = CloudflareOpError;
/** Returns aggregate summary stats for a dataset. Includes current-period and previous-period totals for trend comparison. */
export declare const summary: API.OperationMethod<SummaryRequest, SummaryResponse, SummaryError, CloudflareOpContext>;
export type TimeseriesError = CloudflareOpError;
/** Returns time-bucketed analytics data for a dataset. Includes time slots, each containing the requested stats, group-by dimensions, and resolution-controlled bucket size (e.g. `hour`, `day`). */
export declare const timeseries: API.OperationMethod<TimeseriesRequest, TimeseriesResponse, TimeseriesError, CloudflareOpContext>;
export type TopNError = CloudflareOpError;
/** Returns the top N results for a dataset by a specified stat. Includes an array of result rows, each containing the requested stats and group-by dimensions. */
export declare const topN: API.OperationMethod<TopNRequest, TopNResponse, TopNError, CloudflareOpContext>;
//# sourceMappingURL=analytics_query.d.ts.map