import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CustomNameserverAlreadyExists_base: S.TaggedErrorClass<"CustomNameserverAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CustomNameserverAlreadyExists extends /*@__PURE__*/ CustomNameserverAlreadyExists_base {
}
declare const CustomNameserverNotFound_base: S.TaggedErrorClass<"CustomNameserverNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CustomNameserverNotFound extends /*@__PURE__*/ CustomNameserverNotFound_base {
}
declare const CustomNameserversNotEnabled_base: S.TaggedErrorClass<"CustomNameserversNotEnabled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CustomNameserversNotEnabled extends /*@__PURE__*/ CustomNameserversNotEnabled_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface CreateCustomNameserverRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The FQDN of the name server. */
    nsName: string;
    /** The number of the set that this name server belongs to. */
    nsSet?: number;
}
export type CreateResponseDnsRecordsItemType = "A" | "AAAA";
export interface CreateResponseDnsRecordsItem {
    /** DNS record type. */
    type?: CreateResponseDnsRecordsItemType | null;
    /** DNS record contents (an IPv4 or IPv6 address). */
    value?: string | null;
}
export type CreateResponseDnsRecordsList = Array<CreateResponseDnsRecordsItem>;
export type CreateResponseStatus = "moved" | "pending" | "verified";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCustomNameserverResponse {
    /** A and AAAA records associated with the nameserver. */
    dnsRecords: CreateResponseDnsRecordsList;
    /** The FQDN of the name server. */
    nsName: string;
    /** Verification status of the nameserver. */
    status: CreateResponseStatus;
    /** Identifier. */
    zoneTag: string;
    /** The number of the set that this name server belongs to. */
    nsSet?: number | null;
}
export interface DeleteCustomNameserverRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The FQDN of the name server. */
    customNsId: string;
}
export type DeleteResultList = Array<string>;
export interface DeleteCustomNameserverResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetCustomNameserverRequest {
    /** Account identifier tag. */
    accountId: string;
}
export type GetResultItemDnsRecordsItemType = "A" | "AAAA";
export interface GetResultItemDnsRecordsItem {
    /** DNS record type. */
    type?: GetResultItemDnsRecordsItemType | null;
    /** DNS record contents (an IPv4 or IPv6 address). */
    value?: string | null;
}
export type GetResultItemDnsRecordsList = Array<GetResultItemDnsRecordsItem>;
export type GetResultItemStatus = "moved" | "pending" | "verified";
export interface GetResultItem {
    /** A and AAAA records associated with the nameserver. */
    dnsRecords: GetResultItemDnsRecordsList;
    /** The FQDN of the name server. */
    nsName: string;
    /** Verification status of the nameserver. */
    status: GetResultItemStatus;
    /** Identifier. */
    zoneTag: string;
    /** The number of the set that this name server belongs to. */
    nsSet?: number | null;
}
export type GetResultList = Array<GetResultItem>;
export interface GetCustomNameserverResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: GetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type CreateCustomNameserverError = CustomNameserversNotEnabled | CustomNameserverAlreadyExists | Forbidden | CloudflareOpError;
/** Adds a custom nameserver to the account for use as a vanity nameserver on zones. */
export declare const createCustomNameserver: API.OperationMethod<CreateCustomNameserverRequest, CreateCustomNameserverResponse, CreateCustomNameserverError, CloudflareOpContext>;
export type DeleteCustomNameserverError = CustomNameserversNotEnabled | CustomNameserverNotFound | Forbidden | CloudflareOpError;
/** Removes a custom nameserver from the account. */
export declare const deleteCustomNameserver: API.PaginatedOperationMethod<DeleteCustomNameserverRequest, DeleteCustomNameserverResponse, DeleteCustomNameserverError, CloudflareOpContext, string>;
export type GetCustomNameserverError = CustomNameserversNotEnabled | Forbidden | CloudflareOpError;
/** List an account's custom nameservers. */
export declare const getCustomNameserver: API.PaginatedOperationMethod<GetCustomNameserverRequest, GetCustomNameserverResponse, GetCustomNameserverError, CloudflareOpContext, GetResultItem>;
//# sourceMappingURL=custom_nameservers.d.ts.map