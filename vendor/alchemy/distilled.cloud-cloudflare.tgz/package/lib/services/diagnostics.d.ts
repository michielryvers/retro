import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const EndpointHealthcheckNotFound_base: S.TaggedErrorClass<"EndpointHealthcheckNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class EndpointHealthcheckNotFound extends /*@__PURE__*/ EndpointHealthcheckNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidHealthcheckEndpoint_base: S.TaggedErrorClass<"InvalidHealthcheckEndpoint", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidHealthcheckEndpoint extends /*@__PURE__*/ InvalidHealthcheckEndpoint_base {
}
export type EndpointHealthchecksCreateRequestCheckType = "icmp";
export interface CreateEndpointHealthcheckRequest {
    /** Identifier */
    accountId: string;
    /** type of check to perform */
    checkType: EndpointHealthchecksCreateRequestCheckType | (string & {});
    /** the IP address of the host to perform checks against */
    endpoint: string;
    /** Optional name associated with this check */
    name?: string;
}
export type EndpointHealthchecksCreateResponseCheckType = "icmp";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateEndpointHealthcheckResponse {
    /** type of check to perform */
    checkType: EndpointHealthchecksCreateResponseCheckType;
    /** the IP address of the host to perform checks against */
    endpoint: string;
    /** UUID. */
    id?: string | null;
    /** Optional name associated with this check */
    name?: string | null;
}
export type TraceroutesCreateRequestTargetsList = Array<string>;
export type TraceroutesCreateRequestColosList = Array<string>;
export type TraceroutesCreateRequestOptionsPacketType = "icmp" | "tcp" | "udp" | "gre" | "gre+icmp";
export interface TraceroutesCreateRequestOptions {
    /** Max TTL. */
    maxTtl?: number;
    /** Type of packet sent. */
    packetType?: TraceroutesCreateRequestOptionsPacketType | (string & {});
    /** Number of packets sent at each TTL. */
    packetsPerTtl?: number;
    /** For UDP and TCP, specifies the destination port. For ICMP, specifies the initial ICMP sequence value. Default value 0 will choose the best value to use for each protocol. */
    port?: number;
    /** Set the time (in seconds) to wait for a response to a probe. */
    waitTime?: number;
}
export interface CreateTracerouteRequest {
    /** Identifier */
    accountId: string;
    targets: TraceroutesCreateRequestTargetsList;
    /** If no source colo names specified, all colos will be used. China colos are unavailable for traceroutes. */
    colos?: TraceroutesCreateRequestColosList;
    options?: TraceroutesCreateRequestOptions;
}
export interface TraceroutesCreateResultItemColosItemColo {
    /** Source colo city. */
    city?: string | null;
    /** Source colo name. */
    name?: string | null;
}
export type TraceroutesCreateResultItemColosItemError = "" | "Could not gather traceroute data: Code 1" | "Could not gather traceroute data: Code 2" | "Could not gather traceroute data: Code 3" | "Could not gather traceroute data: Code 4";
export type TraceroutesCreateResultItemColosItemHopsItemNodesItemLabelsList = Array<string>;
export interface TraceroutesCreateResultItemColosItemHopsItemNodesItem {
    /** AS number associated with the node object. */
    asn?: string | null;
    /** IP address of the node. */
    ip?: string | null;
    /** Field appears if there is an additional annotation printed when the probe returns. Field also appears when running a GRE+ICMP traceroute to denote which traceroute a node comes from. */
    labels?: TraceroutesCreateResultItemColosItemHopsItemNodesItemLabelsList | null;
    /** Maximum RTT in ms. */
    maxRttMs?: number | null;
    /** Mean RTT in ms. */
    meanRttMs?: number | null;
    /** Minimum RTT in ms. */
    minRttMs?: number | null;
    /** Host name of the address, this may be the same as the IP address. */
    name?: string | null;
    /** Number of packets with a response from this node. */
    packetCount?: number | null;
    /** Standard deviation of the RTTs in ms. */
    stdDevRttMs?: number | null;
}
export type TraceroutesCreateResultItemColosItemHopsItemNodesList = Array<TraceroutesCreateResultItemColosItemHopsItemNodesItem>;
export interface TraceroutesCreateResultItemColosItemHopsItem {
    /** An array of node objects. */
    nodes?: TraceroutesCreateResultItemColosItemHopsItemNodesList | null;
    /** Number of packets where no response was received. */
    packetsLost?: number | null;
    /** Number of packets sent with specified TTL. */
    packetsSent?: number | null;
    /** The time to live (TTL). */
    packetsTtl?: number | null;
}
export type TraceroutesCreateResultItemColosItemHopsList = Array<TraceroutesCreateResultItemColosItemHopsItem>;
export interface TraceroutesCreateResultItemColosItem {
    colo?: TraceroutesCreateResultItemColosItemColo | null;
    /** Errors resulting from collecting traceroute from colo to target. */
    error?: TraceroutesCreateResultItemColosItemError | null;
    hops?: TraceroutesCreateResultItemColosItemHopsList | null;
    /** Aggregated statistics from all hops about the target. */
    targetSummary?: unknown | null;
    /** Total time of traceroute in ms. */
    tracerouteTimeMs?: number | null;
}
export type TraceroutesCreateResultItemColosList = Array<TraceroutesCreateResultItemColosItem>;
export interface TraceroutesCreateResultItem {
    colos?: TraceroutesCreateResultItemColosList | null;
    /** The target hostname, IPv6, or IPv6 address. */
    target?: string | null;
}
export type TraceroutesCreateResultList = Array<TraceroutesCreateResultItem>;
export interface CreateTracerouteResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TraceroutesCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface DeleteEndpointHealthcheckRequest {
    /** Identifier */
    accountId: string;
    /** UUID. */
    id: string;
}
export interface DeleteEndpointHealthcheckResponse {
}
export interface GetEndpointHealthcheckRequest {
    /** Identifier */
    accountId: string;
    /** UUID. */
    id: string;
}
export type EndpointHealthchecksGetResponseCheckType = "icmp";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetEndpointHealthcheckResponse {
    /** type of check to perform */
    checkType: EndpointHealthchecksGetResponseCheckType;
    /** the IP address of the host to perform checks against */
    endpoint: string;
    /** UUID. */
    id?: string | null;
    /** Optional name associated with this check */
    name?: string | null;
}
export interface ListEndpointHealthchecksRequest {
    /** Identifier */
    accountId: string;
}
export type EndpointHealthchecksListResultItemCheckType = "icmp";
export interface EndpointHealthchecksListResultItem {
    /** type of check to perform */
    checkType: EndpointHealthchecksListResultItemCheckType;
    /** the IP address of the host to perform checks against */
    endpoint: string;
    /** UUID. */
    id?: string | null;
    /** Optional name associated with this check */
    name?: string | null;
}
export type EndpointHealthchecksListResultList = Array<EndpointHealthchecksListResultItem>;
export type ListEndpointHealthchecksResponse = EndpointHealthchecksListResultList;
export type EndpointHealthchecksUpdateRequestCheckType = "icmp";
export interface UpdateEndpointHealthcheckRequest {
    /** Identifier */
    accountId: string;
    /** UUID. */
    id: string;
    /** type of check to perform */
    checkType: EndpointHealthchecksUpdateRequestCheckType | (string & {});
    /** the IP address of the host to perform checks against */
    endpoint: string;
    /** Optional name associated with this check */
    name?: string;
}
export type EndpointHealthchecksUpdateResponseCheckType = "icmp";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateEndpointHealthcheckResponse {
    /** type of check to perform */
    checkType: EndpointHealthchecksUpdateResponseCheckType;
    /** the IP address of the host to perform checks against */
    endpoint: string;
    /** UUID. */
    id?: string | null;
    /** Optional name associated with this check */
    name?: string | null;
}
export type CreateEndpointHealthcheckError = InvalidHealthcheckEndpoint | Forbidden | CloudflareOpError;
/** Create Endpoint Health Check. */
export declare const createEndpointHealthcheck: API.OperationMethod<CreateEndpointHealthcheckRequest, CreateEndpointHealthcheckResponse, CreateEndpointHealthcheckError, CloudflareOpContext>;
export type CreateTracerouteError = CloudflareOpError;
/** Run traceroutes from Cloudflare colos. */
export declare const createTraceroute: API.PaginatedOperationMethod<CreateTracerouteRequest, CreateTracerouteResponse, CreateTracerouteError, CloudflareOpContext, TraceroutesCreateResultItem>;
export type DeleteEndpointHealthcheckError = EndpointHealthcheckNotFound | Forbidden | CloudflareOpError;
/** Delete Endpoint Health Check. */
export declare const deleteEndpointHealthcheck: API.OperationMethod<DeleteEndpointHealthcheckRequest, DeleteEndpointHealthcheckResponse, DeleteEndpointHealthcheckError, CloudflareOpContext>;
export type GetEndpointHealthcheckError = EndpointHealthcheckNotFound | Forbidden | CloudflareOpError;
/** Get a single Endpoint Health Check. */
export declare const getEndpointHealthcheck: API.OperationMethod<GetEndpointHealthcheckRequest, GetEndpointHealthcheckResponse, GetEndpointHealthcheckError, CloudflareOpContext>;
export type ListEndpointHealthchecksError = Forbidden | CloudflareOpError;
/** List Endpoint Health Checks. */
export declare const listEndpointHealthchecks: API.OperationMethod<ListEndpointHealthchecksRequest, ListEndpointHealthchecksResponse, ListEndpointHealthchecksError, CloudflareOpContext>;
export type UpdateEndpointHealthcheckError = EndpointHealthcheckNotFound | InvalidHealthcheckEndpoint | Forbidden | CloudflareOpError;
/** Update an Endpoint Health Check. */
export declare const updateEndpointHealthcheck: API.OperationMethod<UpdateEndpointHealthcheckRequest, UpdateEndpointHealthcheckResponse, UpdateEndpointHealthcheckError, CloudflareOpContext>;
//# sourceMappingURL=diagnostics.d.ts.map