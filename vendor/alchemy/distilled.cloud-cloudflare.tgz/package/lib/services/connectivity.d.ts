import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const VpcServiceNameAlreadyExists_base: S.TaggedErrorClass<"VpcServiceNameAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class VpcServiceNameAlreadyExists extends /*@__PURE__*/ VpcServiceNameAlreadyExists_base {
}
declare const VpcServiceNotFound_base: S.TaggedErrorClass<"VpcServiceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class VpcServiceNotFound extends /*@__PURE__*/ VpcServiceNotFound_base {
}
declare const VpcTunnelNotFound_base: S.TaggedErrorClass<"VpcTunnelNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class VpcTunnelNotFound extends /*@__PURE__*/ VpcTunnelNotFound_base {
}
export interface DirectoryServicesCreateRequestHostInfraIPv4HostNetwork {
    tunnelId: string;
}
export interface DirectoryServicesCreateRequestHostInfraIPv4Host {
    ipv4: string;
    network: DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
}
export type DirectoryServicesCreateRequestHostInfraIPv6HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export interface DirectoryServicesCreateRequestHostInfraIPv6Host {
    ipv6: string;
    network: DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
}
export type DirectoryServicesCreateRequestHostInfraDualStackHostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export interface DirectoryServicesCreateRequestHostInfraDualStackHost {
    ipv4: string;
    ipv6: string;
    network: DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
}
export type DirectoryServicesCreateRequestHostInfraHostnameHostResolverNetworkResolverIpsList = Array<string>;
export interface DirectoryServicesCreateRequestHostInfraHostnameHostResolverNetwork {
    tunnelId: string;
    resolverIps?: DirectoryServicesCreateRequestHostInfraHostnameHostResolverNetworkResolverIpsList;
}
export interface DirectoryServicesCreateRequestHostInfraHostnameHost {
    hostname: string;
    resolverNetwork: DirectoryServicesCreateRequestHostInfraHostnameHostResolverNetwork;
}
export type DirectoryServicesCreateRequestHost = DirectoryServicesCreateRequestHostInfraIPv4Host | DirectoryServicesCreateRequestHostInfraIPv6Host | DirectoryServicesCreateRequestHostInfraDualStackHost | DirectoryServicesCreateRequestHostInfraHostnameHost;
export type DirectoryServicesCreateRequestType = "tcp" | "http";
export interface DirectoryServicesCreateRequestTlsSettings {
    /** TLS certificate verification mode for the connection to the origin. */
    certVerificationMode: string;
}
export type DirectoryServicesCreateRequestAppProtocol = "postgresql" | "mysql";
export interface CreateDirectoryServiceRequest {
    /** Account identifier */
    accountId: string;
    host: DirectoryServicesCreateRequestHost;
    name: string;
    type: DirectoryServicesCreateRequestType | (string & {});
    createdAt?: string;
    httpPort?: number;
    httpsPort?: number;
    serviceId?: string;
    /** TLS settings for a connectivity service. */
    tlsSettings?: DirectoryServicesCreateRequestTlsSettings;
    updatedAt?: string;
    appProtocol?: DirectoryServicesCreateRequestAppProtocol | (string & {});
    tcpPort?: number;
}
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraIPv4HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraIPv4Host = DirectoryServicesCreateRequestHostInfraIPv4Host;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraIPv6HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraIPv6Host = DirectoryServicesCreateRequestHostInfraIPv6Host;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraDualStackHostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraDualStackHost = DirectoryServicesCreateRequestHostInfraDualStackHost;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList = Array<string>;
export interface DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork {
    tunnelId: string;
    resolverIps?: DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList | null;
}
export interface DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHost {
    hostname: string;
    resolverNetwork: DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork;
}
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHost = DirectoryServicesCreateRequestHostInfraIPv4Host | DirectoryServicesCreateRequestHostInfraIPv6Host | DirectoryServicesCreateRequestHostInfraDualStackHost | DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHost;
export type DirectoryServicesCreateResultType = "tcp" | "http";
export type DirectoryServicesCreateResultInfraHTTPServiceConfigTlsSettings = DirectoryServicesCreateRequestTlsSettings;
export type DirectoryServicesCreateResultInfraTCPServiceConfigAppProtocol = "postgresql" | "mysql";
export interface DirectoryServicesCreateResult {
    host: DirectoryServicesCreateResultInfraHTTPServiceConfigHost;
    name: string;
    type: DirectoryServicesCreateResultType;
    createdAt?: string | null;
    httpPort?: number | null;
    httpsPort?: number | null;
    serviceId?: string | null;
    /** TLS settings for a connectivity service. */
    tlsSettings?: DirectoryServicesCreateRequestTlsSettings | null;
    updatedAt?: string | null;
    appProtocol?: DirectoryServicesCreateResultInfraTCPServiceConfigAppProtocol | null;
    tcpPort?: number | null;
}
export type CreateDirectoryServiceResponse = DirectoryServicesCreateResult;
export interface DeleteDirectoryServiceRequest {
    accountId: string;
    serviceId: string;
}
export interface DeleteDirectoryServiceResponse {
}
export interface GetDirectoryServiceRequest {
    accountId: string;
    serviceId: string;
}
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraIPv4HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraIPv4Host = DirectoryServicesCreateRequestHostInfraIPv4Host;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraIPv6HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraIPv6Host = DirectoryServicesCreateRequestHostInfraIPv6Host;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraDualStackHostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraDualStackHost = DirectoryServicesCreateRequestHostInfraDualStackHost;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList = Array<string>;
export interface DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork {
    tunnelId: string;
    resolverIps?: DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList | null;
}
export interface DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHost {
    hostname: string;
    resolverNetwork: DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork;
}
export type DirectoryServicesGetResultInfraHTTPServiceConfigHost = DirectoryServicesCreateRequestHostInfraIPv4Host | DirectoryServicesCreateRequestHostInfraIPv6Host | DirectoryServicesCreateRequestHostInfraDualStackHost | DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHost;
export type DirectoryServicesGetResultType = "tcp" | "http";
export type DirectoryServicesGetResultInfraHTTPServiceConfigTlsSettings = DirectoryServicesCreateRequestTlsSettings;
export type DirectoryServicesGetResultInfraTCPServiceConfigAppProtocol = "postgresql" | "mysql";
export interface DirectoryServicesGetResult {
    host: DirectoryServicesGetResultInfraHTTPServiceConfigHost;
    name: string;
    type: DirectoryServicesGetResultType;
    createdAt?: string | null;
    httpPort?: number | null;
    httpsPort?: number | null;
    serviceId?: string | null;
    /** TLS settings for a connectivity service. */
    tlsSettings?: DirectoryServicesCreateRequestTlsSettings | null;
    updatedAt?: string | null;
    appProtocol?: DirectoryServicesGetResultInfraTCPServiceConfigAppProtocol | null;
    tcpPort?: number | null;
}
export type GetDirectoryServiceResponse = DirectoryServicesGetResult;
export type DirectoryServicesListRequestType = "tcp" | "http";
export interface ListDirectoryServicesRequest {
    /** Account identifier */
    accountId: string;
    /** Current page in the response */
    page?: number;
    /** Max amount of entries returned per page */
    perPage?: number;
    type?: DirectoryServicesListRequestType | (string & {});
}
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraIPv4HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraIPv4Host = DirectoryServicesCreateRequestHostInfraIPv4Host;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraIPv6HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraIPv6Host = DirectoryServicesCreateRequestHostInfraIPv6Host;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraDualStackHostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraDualStackHost = DirectoryServicesCreateRequestHostInfraDualStackHost;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList = Array<string>;
export interface DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork {
    tunnelId: string;
    resolverIps?: DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList | null;
}
export interface DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHost {
    hostname: string;
    resolverNetwork: DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork;
}
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHost = DirectoryServicesCreateRequestHostInfraIPv4Host | DirectoryServicesCreateRequestHostInfraIPv6Host | DirectoryServicesCreateRequestHostInfraDualStackHost | DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHost;
export type DirectoryServicesListResultItemType = "tcp" | "http";
export type DirectoryServicesListResultItemInfraHTTPServiceConfigTlsSettings = DirectoryServicesCreateRequestTlsSettings;
export type DirectoryServicesListResultItemInfraTCPServiceConfigAppProtocol = "postgresql" | "mysql";
export interface DirectoryServicesListResultItem {
    host: DirectoryServicesListResultItemInfraHTTPServiceConfigHost;
    name: string;
    type: DirectoryServicesListResultItemType;
    createdAt?: string | null;
    httpPort?: number | null;
    httpsPort?: number | null;
    serviceId?: string | null;
    /** TLS settings for a connectivity service. */
    tlsSettings?: DirectoryServicesCreateRequestTlsSettings | null;
    updatedAt?: string | null;
    appProtocol?: DirectoryServicesListResultItemInfraTCPServiceConfigAppProtocol | null;
    tcpPort?: number | null;
}
export type DirectoryServicesListResultList = Array<DirectoryServicesListResultItem>;
export interface ListDirectoryServicesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DirectoryServicesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type DirectoryServicesUpdateRequestHostInfraIPv4HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesUpdateRequestHostInfraIPv4Host = DirectoryServicesCreateRequestHostInfraIPv4Host;
export type DirectoryServicesUpdateRequestHostInfraIPv6HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesUpdateRequestHostInfraIPv6Host = DirectoryServicesCreateRequestHostInfraIPv6Host;
export type DirectoryServicesUpdateRequestHostInfraDualStackHostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesUpdateRequestHostInfraDualStackHost = DirectoryServicesCreateRequestHostInfraDualStackHost;
export type DirectoryServicesUpdateRequestHostInfraHostnameHostResolverNetworkResolverIpsList = Array<string>;
export interface DirectoryServicesUpdateRequestHostInfraHostnameHostResolverNetwork {
    tunnelId: string;
    resolverIps?: DirectoryServicesUpdateRequestHostInfraHostnameHostResolverNetworkResolverIpsList;
}
export interface DirectoryServicesUpdateRequestHostInfraHostnameHost {
    hostname: string;
    resolverNetwork: DirectoryServicesUpdateRequestHostInfraHostnameHostResolverNetwork;
}
export type DirectoryServicesUpdateRequestHost = DirectoryServicesCreateRequestHostInfraIPv4Host | DirectoryServicesCreateRequestHostInfraIPv6Host | DirectoryServicesCreateRequestHostInfraDualStackHost | DirectoryServicesUpdateRequestHostInfraHostnameHost;
export type DirectoryServicesUpdateRequestType = "tcp" | "http";
export type DirectoryServicesUpdateRequestTlsSettings = DirectoryServicesCreateRequestTlsSettings;
export type DirectoryServicesUpdateRequestAppProtocol = "postgresql" | "mysql";
export interface UpdateDirectoryServiceRequest {
    accountId: string;
    serviceId: string;
    host: DirectoryServicesUpdateRequestHost;
    name: string;
    type: DirectoryServicesUpdateRequestType | (string & {});
    createdAt?: string;
    httpPort?: number;
    httpsPort?: number;
    /** TLS settings for a connectivity service. */
    tlsSettings?: DirectoryServicesCreateRequestTlsSettings;
    updatedAt?: string;
    appProtocol?: DirectoryServicesUpdateRequestAppProtocol | (string & {});
    tcpPort?: number;
}
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraIPv4HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraIPv4Host = DirectoryServicesCreateRequestHostInfraIPv4Host;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraIPv6HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraIPv6Host = DirectoryServicesCreateRequestHostInfraIPv6Host;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraDualStackHostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraDualStackHost = DirectoryServicesCreateRequestHostInfraDualStackHost;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList = Array<string>;
export interface DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork {
    tunnelId: string;
    resolverIps?: DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList | null;
}
export interface DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHost {
    hostname: string;
    resolverNetwork: DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork;
}
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHost = DirectoryServicesCreateRequestHostInfraIPv4Host | DirectoryServicesCreateRequestHostInfraIPv6Host | DirectoryServicesCreateRequestHostInfraDualStackHost | DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHost;
export type DirectoryServicesUpdateResultType = "tcp" | "http";
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigTlsSettings = DirectoryServicesCreateRequestTlsSettings;
export type DirectoryServicesUpdateResultInfraTCPServiceConfigAppProtocol = "postgresql" | "mysql";
export interface DirectoryServicesUpdateResult {
    host: DirectoryServicesUpdateResultInfraHTTPServiceConfigHost;
    name: string;
    type: DirectoryServicesUpdateResultType;
    createdAt?: string | null;
    httpPort?: number | null;
    httpsPort?: number | null;
    serviceId?: string | null;
    /** TLS settings for a connectivity service. */
    tlsSettings?: DirectoryServicesCreateRequestTlsSettings | null;
    updatedAt?: string | null;
    appProtocol?: DirectoryServicesUpdateResultInfraTCPServiceConfigAppProtocol | null;
    tcpPort?: number | null;
}
export type UpdateDirectoryServiceResponse = DirectoryServicesUpdateResult;
export type CreateDirectoryServiceError = VpcServiceNameAlreadyExists | VpcTunnelNotFound | Forbidden | CloudflareOpError;
/** Creates a new Workers VPC connectivity service in the account. */
export declare const createDirectoryService: API.OperationMethod<CreateDirectoryServiceRequest, CreateDirectoryServiceResponse, CreateDirectoryServiceError, CloudflareOpContext>;
export type DeleteDirectoryServiceError = VpcServiceNotFound | Forbidden | CloudflareOpError;
/** Removes a single Workers VPC connectivity service by its ID. Any Worker bindings referencing this service will stop working. */
export declare const deleteDirectoryService: API.OperationMethod<DeleteDirectoryServiceRequest, DeleteDirectoryServiceResponse, DeleteDirectoryServiceError, CloudflareOpContext>;
export type GetDirectoryServiceError = VpcServiceNotFound | Forbidden | CloudflareOpError;
/** Fetches a single Workers VPC connectivity service by its ID. */
export declare const getDirectoryService: API.OperationMethod<GetDirectoryServiceRequest, GetDirectoryServiceResponse, GetDirectoryServiceError, CloudflareOpContext>;
export type ListDirectoryServicesError = Forbidden | CloudflareOpError;
/** Lists the Workers VPC connectivity services in the account. */
export declare const listDirectoryServices: API.PaginatedOperationMethod<ListDirectoryServicesRequest, ListDirectoryServicesResponse, ListDirectoryServicesError, CloudflareOpContext, DirectoryServicesListResultItem>;
export type UpdateDirectoryServiceError = VpcServiceNotFound | VpcServiceNameAlreadyExists | VpcTunnelNotFound | Forbidden | CloudflareOpError;
/** Updates an existing Workers VPC connectivity service by its ID. */
export declare const updateDirectoryService: API.OperationMethod<UpdateDirectoryServiceRequest, UpdateDirectoryServiceResponse, UpdateDirectoryServiceError, CloudflareOpContext>;
//# sourceMappingURL=connectivity.d.ts.map