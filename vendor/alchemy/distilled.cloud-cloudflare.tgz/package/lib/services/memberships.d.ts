import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface DeleteMembershipRequest {
    /** Membership identifier tag. */
    membershipId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMembershipResponse {
    /** Membership identifier tag. */
    id?: string | null;
}
export interface GetMembershipRequest {
    /** Membership identifier tag. */
    membershipId: string;
}
export type GetResponseAccountType = "standard" | "enterprise";
export interface GetResponseAccountManagedBy {
    /** ID of the parent Organization, if one exists */
    parentOrgId?: string | null;
    /** Name of the parent Organization, if one exists */
    parentOrgName?: string | null;
}
export interface GetResponseAccountSettings {
    /** Sets an abuse contact email to notify for abuse reports. */
    abuseContactEmail?: string | null;
    /** Indicates whether membership in this account requires that Two-Factor Authentication is enabled */
    enforceTwofactor?: boolean | null;
}
export interface GetResponseAccount {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: GetResponseAccountType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: GetResponseAccountManagedBy | null;
    /** Account settings */
    settings?: GetResponseAccountSettings | null;
}
export interface GetResponsePermissionsAnalytics {
    read?: boolean | null;
    write?: boolean | null;
}
export type GetResponsePermissionsBilling = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsCachePurge = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsDns = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsDnsRecords = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsLb = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsLogs = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsOrganization = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsSsl = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsWaf = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsZoneSettings = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsZones = GetResponsePermissionsAnalytics;
export interface GetResponsePermissions {
    analytics?: GetResponsePermissionsAnalytics | null;
    billing?: GetResponsePermissionsAnalytics | null;
    cachePurge?: GetResponsePermissionsAnalytics | null;
    dns?: GetResponsePermissionsAnalytics | null;
    dnsRecords?: GetResponsePermissionsAnalytics | null;
    lb?: GetResponsePermissionsAnalytics | null;
    logs?: GetResponsePermissionsAnalytics | null;
    organization?: GetResponsePermissionsAnalytics | null;
    ssl?: GetResponsePermissionsAnalytics | null;
    waf?: GetResponsePermissionsAnalytics | null;
    zoneSettings?: GetResponsePermissionsAnalytics | null;
    zones?: GetResponsePermissionsAnalytics | null;
}
export type GetResponsePoliciesItemAccess = "allow" | "deny";
export interface GetResponsePoliciesItemPermissionGroupsItemMeta {
    /** A category used to group permission groups. */
    category?: string | null;
    /** Indicates whether the permission group is deprecated. */
    deprecated?: string | null;
    /** Additional information about the permission group. */
    description?: string | null;
    /** Indicates whether the permission group can be edited. */
    editable?: string | null;
    /** The planned end-of-life date and time, when provided. */
    eolAt?: string | null;
    /** A label identifying the permission group. */
    label?: string | null;
    /** The scope associated with the permission group. */
    scopes?: string | null;
    /** Indicates the permission group's availability or visibility. */
    visibility?: string | null;
}
export interface GetResponsePoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: GetResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the permission group. */
    name?: string | null;
}
export type GetResponsePoliciesItemPermissionGroupsList = Array<GetResponsePoliciesItemPermissionGroupsItem>;
export interface GetResponsePoliciesItemResourceGroupsItemScopeObjectsItem {
    /** This is a combination of pre-defined resource name and identifier (like Zone ID etc.) */
    key: string;
}
export type GetResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<GetResponsePoliciesItemResourceGroupsItemScopeObjectsItem>;
export interface GetResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: GetResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export interface GetResponsePoliciesItemResourceGroupsItemMeta {
    key?: string | null;
    value?: string | null;
}
export interface GetResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: GetResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: GetResponsePoliciesItemResourceGroupsItemMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export type GetResponsePoliciesItemResourceGroupsList = Array<GetResponsePoliciesItemResourceGroupsItem>;
export interface GetResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: GetResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: GetResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: GetResponsePoliciesItemResourceGroupsList | null;
}
export type GetResponsePoliciesList = Array<GetResponsePoliciesItem>;
export type GetResponseRolesList = Array<string>;
export type GetResponseStatus = "accepted" | "pending" | "rejected";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMembershipResponse {
    /** Membership identifier tag. */
    id?: string | null;
    account?: GetResponseAccount | null;
    /** Enterprise only. Indicates whether or not API access is enabled specifically for this user on a given account. */
    apiAccessEnabled?: boolean | null;
    /** All access permissions for the user at the account. */
    permissions?: GetResponsePermissions | null;
    /** Access policy for the membership */
    policies?: GetResponsePoliciesList | null;
    /** List of role names the membership has for this account. */
    roles?: GetResponseRolesList | null;
    /** Status of this membership. */
    status?: GetResponseStatus | null;
}
export interface ListRequestAccount {
    /** Account name */
    name?: string;
}
export type ListRequestDirection = "asc" | "desc";
export type ListRequestOrder = "id" | "account.name" | "status";
export type ListRequestStatus = "accepted" | "pending" | "rejected";
export interface ListMembershipsRequest {
    account?: ListRequestAccount;
    /** Direction to order memberships. */
    direction?: ListRequestDirection | (string & {});
    /** Account name */
    name?: string;
    /** Field to order memberships by. */
    order?: ListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of memberships per page. */
    perPage?: number;
    /** Status of this membership. */
    status?: ListRequestStatus | (string & {});
}
export type ListResultItemAccountType = "standard" | "enterprise";
export type ListResultItemAccountManagedBy = GetResponseAccountManagedBy;
export type ListResultItemAccountSettings = GetResponseAccountSettings;
export interface ListResultItemAccount {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: ListResultItemAccountType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: GetResponseAccountManagedBy | null;
    /** Account settings */
    settings?: GetResponseAccountSettings | null;
}
export type ListResultItemPermissionsAnalytics = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsBilling = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsCachePurge = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsDns = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsDnsRecords = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsLb = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsLogs = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsOrganization = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsSsl = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsWaf = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsZoneSettings = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsZones = GetResponsePermissionsAnalytics;
export type ListResultItemPermissions = GetResponsePermissions;
export type ListResultItemRolesList = Array<string>;
export type ListResultItemStatus = "accepted" | "pending" | "rejected";
export interface ListResultItem {
    /** Membership identifier tag. */
    id?: string | null;
    account?: ListResultItemAccount | null;
    /** Enterprise only. Indicates whether or not API access is enabled specifically for this user on a given account. */
    apiAccessEnabled?: boolean | null;
    /** All access permissions for the user at the account. */
    permissions?: GetResponsePermissions | null;
    /** List of role names the membership has for this account. */
    roles?: ListResultItemRolesList | null;
    /** Status of this membership. */
    status?: ListResultItemStatus | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListMembershipsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type UpdateRequestStatus = "accepted" | "rejected";
export interface PutMembershipRequest {
    /** Membership identifier tag. */
    membershipId: string;
    /** Whether to accept or reject this account invitation. */
    status: UpdateRequestStatus | (string & {});
}
export type UpdateResponseAccountType = "standard" | "enterprise";
export type UpdateResponseAccountManagedBy = GetResponseAccountManagedBy;
export type UpdateResponseAccountSettings = GetResponseAccountSettings;
export interface UpdateResponseAccount {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: UpdateResponseAccountType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: GetResponseAccountManagedBy | null;
    /** Account settings */
    settings?: GetResponseAccountSettings | null;
}
export type UpdateResponsePermissionsAnalytics = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsBilling = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsCachePurge = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsDns = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsDnsRecords = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsLb = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsLogs = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsOrganization = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsSsl = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsWaf = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsZoneSettings = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsZones = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissions = GetResponsePermissions;
export type UpdateResponsePoliciesItemAccess = "allow" | "deny";
export type UpdateResponsePoliciesItemPermissionGroupsItemMeta = GetResponsePoliciesItemPermissionGroupsItemMeta;
export type UpdateResponsePoliciesItemPermissionGroupsItem = GetResponsePoliciesItemPermissionGroupsItem;
export type UpdateResponsePoliciesItemPermissionGroupsList = Array<GetResponsePoliciesItemPermissionGroupsItem>;
export type UpdateResponsePoliciesItemResourceGroupsItemScopeObjectsItem = GetResponsePoliciesItemResourceGroupsItemScopeObjectsItem;
export type UpdateResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<GetResponsePoliciesItemResourceGroupsItemScopeObjectsItem>;
export interface UpdateResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: UpdateResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export type UpdateResponsePoliciesItemResourceGroupsItemMeta = GetResponsePoliciesItemResourceGroupsItemMeta;
export interface UpdateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: UpdateResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: GetResponsePoliciesItemResourceGroupsItemMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export type UpdateResponsePoliciesItemResourceGroupsList = Array<UpdateResponsePoliciesItemResourceGroupsItem>;
export interface UpdateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: UpdateResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: UpdateResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: UpdateResponsePoliciesItemResourceGroupsList | null;
}
export type UpdateResponsePoliciesList = Array<UpdateResponsePoliciesItem>;
export type UpdateResponseRolesList = Array<string>;
export type UpdateResponseStatus = "accepted" | "pending" | "rejected";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutMembershipResponse {
    /** Membership identifier tag. */
    id?: string | null;
    account?: UpdateResponseAccount | null;
    /** Enterprise only. Indicates whether or not API access is enabled specifically for this user on a given account. */
    apiAccessEnabled?: boolean | null;
    /** All access permissions for the user at the account. */
    permissions?: GetResponsePermissions | null;
    /** Access policy for the membership */
    policies?: UpdateResponsePoliciesList | null;
    /** List of role names the membership has for this account. */
    roles?: UpdateResponseRolesList | null;
    /** Status of this membership. */
    status?: UpdateResponseStatus | null;
}
export type DeleteMembershipError = CloudflareOpError;
/** Remove the associated member from an account. */
export declare const deleteMembership: API.OperationMethod<DeleteMembershipRequest, DeleteMembershipResponse, DeleteMembershipError, CloudflareOpContext>;
export type GetMembershipError = CloudflareOpError;
/** Get a specific membership. */
export declare const getMembership: API.OperationMethod<GetMembershipRequest, GetMembershipResponse, GetMembershipError, CloudflareOpContext>;
export type ListMembershipsError = CloudflareOpError;
/** List memberships of accounts the user can access. */
export declare const listMemberships: API.PaginatedOperationMethod<ListMembershipsRequest, ListMembershipsResponse, ListMembershipsError, CloudflareOpContext, ListResultItem>;
export type PutMembershipError = CloudflareOpError;
/** Accept or reject this account invitation. */
export declare const putMembership: API.OperationMethod<PutMembershipRequest, PutMembershipResponse, PutMembershipError, CloudflareOpContext>;
//# sourceMappingURL=memberships.d.ts.map