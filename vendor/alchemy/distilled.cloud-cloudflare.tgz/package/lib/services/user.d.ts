import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidTokenName_base: S.TaggedErrorClass<"InvalidTokenName", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidTokenName extends /*@__PURE__*/ InvalidTokenName_base {
}
declare const MethodNotAllowed_base: S.TaggedErrorClass<"MethodNotAllowed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MethodNotAllowed extends /*@__PURE__*/ MethodNotAllowed_base {
}
declare const PermissionGroupNotFound_base: S.TaggedErrorClass<"PermissionGroupNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PermissionGroupNotFound extends /*@__PURE__*/ PermissionGroupNotFound_base {
}
declare const TokenNotFound_base: S.TaggedErrorClass<"TokenNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TokenNotFound extends /*@__PURE__*/ TokenNotFound_base {
}
export type TokensCreateRequestPoliciesItemEffect = "allow" | "deny";
export interface TokensCreateRequestPoliciesItemPermissionGroupsItemMeta {
    /** A category used to group permission groups. */
    category?: string;
    /** Indicates whether the permission group is deprecated. */
    deprecated?: string;
    /** Additional information about the permission group. */
    description?: string;
    /** Indicates whether the permission group can be edited. */
    editable?: string;
    /** The planned end-of-life date and time, when provided. */
    eolAt?: string;
    /** A label identifying the permission group. */
    label?: string;
    /** The scope associated with the permission group. */
    scopes?: string;
    /** Indicates the permission group's availability or visibility. */
    visibility?: string;
}
export interface TokensCreateRequestPoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: TokensCreateRequestPoliciesItemPermissionGroupsItemMeta;
    /** Name of the permission group. */
    name?: string;
}
export type TokensCreateRequestPoliciesItemPermissionGroupsList = Array<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export type TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensCreateRequestPoliciesItemResourcesValue = string | TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensCreateRequestPoliciesItemResourcesMap = {
    [key: string]: TokensCreateRequestPoliciesItemResourcesValue | undefined;
};
export interface TokensCreateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    effect: TokensCreateRequestPoliciesItemEffect | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensCreateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensCreateRequestPoliciesItemResourcesMap;
}
export type TokensCreateRequestPoliciesList = Array<TokensCreateRequestPoliciesItem>;
export type TokensCreateRequestConditionRequestIpInList = Array<string>;
export type TokensCreateRequestConditionRequestIpNotInList = Array<string>;
export interface TokensCreateRequestConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensCreateRequestConditionRequestIpInList;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensCreateRequestConditionRequestIpNotInList;
}
export interface TokensCreateRequestCondition {
    /** Client IP restrictions. */
    requestIp?: TokensCreateRequestConditionRequestIp;
}
export interface CreateTokenRequest {
    /** Token name. */
    name: string;
    /** List of access policies assigned to the token. */
    policies: TokensCreateRequestPoliciesList;
    condition?: TokensCreateRequestCondition;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string;
}
export type TokensCreateResponseConditionRequestIpInList = Array<string>;
export type TokensCreateResponseConditionRequestIpNotInList = Array<string>;
export interface TokensCreateResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensCreateResponseConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensCreateResponseConditionRequestIpNotInList | null;
}
export interface TokensCreateResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensCreateResponseConditionRequestIp | null;
}
export type TokensCreateResponsePoliciesItemEffect = "allow" | "deny";
export interface TokensCreateResponsePoliciesItemPermissionGroupsItemMeta {
    /** A category used to group permission groups. */
    category?: string | null;
    /** Indicates whether the permission group is deprecated. */
    deprecated?: string | null;
    /** Additional information about the permission group. */
    description?: string | null;
    /** Indicates whether the permission group can be edited. */
    editable?: string | null;
    /** The planned end-of-life date and time, when provided. */
    eolAt?: string | null;
    /** A label identifying the permission group. */
    label?: string | null;
    /** The scope associated with the permission group. */
    scopes?: string | null;
    /** Indicates the permission group's availability or visibility. */
    visibility?: string | null;
}
export interface TokensCreateResponsePoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: TokensCreateResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the permission group. */
    name?: string | null;
}
export type TokensCreateResponsePoliciesItemPermissionGroupsList = Array<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensCreateResponsePoliciesItemResourcesValue = string | TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensCreateResponsePoliciesItemResourcesMap = {
    [key: string]: TokensCreateResponsePoliciesItemResourcesValue | undefined;
};
export interface TokensCreateResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensCreateResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensCreateResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensCreateResponsePoliciesItemResourcesMap;
}
export type TokensCreateResponsePoliciesList = Array<TokensCreateResponsePoliciesItem>;
export type TokensCreateResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensCreateResponseCondition | null;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensCreateResponsePoliciesList | null;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null;
    /** Status of the token. */
    status?: TokensCreateResponseStatus | null;
    /** The token value. */
    value?: string | null;
}
export interface DeleteOrganizationRequest {
    /** Identifier */
    organizationId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteOrganizationResponse {
    /** Identifier */
    id?: string | null;
}
export interface DeleteSubscriptionRequest {
    /** Subscription identifier tag. */
    identifier: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteSubscriptionResponse {
    /** Subscription identifier tag. */
    subscriptionId?: string | null;
}
export interface DeleteTokenRequest {
    /** Token identifier tag. */
    tokenId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteTokenResponse {
    /** Identifier */
    id: string;
}
export interface GetBillingProfileRequest {
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBillingProfileResponse {
    /** Billing item identifier tag. */
    id?: string | null;
    accountType?: string | null;
    address?: string | null;
    address2?: string | null;
    balance?: string | null;
    cardExpiryMonth?: number | null;
    cardExpiryYear?: number | null;
    cardNumber?: string | null;
    city?: string | null;
    company?: string | null;
    country?: string | null;
    createdOn?: string | null;
    deviceData?: string | null;
    editedOn?: string | null;
    enterpriseBillingEmail?: string | null;
    enterprisePrimaryEmail?: string | null;
    firstName?: string | null;
    isPartner?: boolean | null;
    lastName?: string | null;
    nextBillDate?: string | null;
    paymentAddress?: string | null;
    paymentAddress2?: string | null;
    paymentCity?: string | null;
    paymentCountry?: string | null;
    paymentEmail?: string | null;
    paymentFirstName?: string | null;
    paymentGateway?: string | null;
    paymentLastName?: string | null;
    paymentNonce?: string | null;
    paymentState?: string | null;
    paymentZipcode?: string | null;
    primaryEmail?: string | null;
    state?: string | null;
    taxIdType?: string | null;
    telephone?: string | null;
    validationCode?: string | null;
    vat?: string | null;
    zipcode?: string | null;
}
export interface GetInviteRequest {
    /** Invite identifier tag. */
    inviteId: string;
}
export type InvitesGetResponseRolesList = Array<string>;
export type InvitesGetResponseStatus = "pending" | "accepted" | "rejected" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInviteResponse {
    /** ID of the user to add to the organization. */
    invitedMemberId: string;
    /** ID of the organization the user will be added to. */
    organizationId: string;
    /** Invite identifier tag. */
    id?: string | null;
    /** When the invite is no longer active. */
    expiresOn?: string | null;
    /** The email address of the user who created the invite. */
    invitedBy?: string | null;
    /** Email address of the user to add to the organization. */
    invitedMemberEmail?: string | null;
    /** When the invite was sent. */
    invitedOn?: string | null;
    organizationIsEnforcingTwofactor?: boolean | null;
    /** Organization name. */
    organizationName?: string | null;
    /** List of role names the membership has for this account. */
    roles?: InvitesGetResponseRolesList | null;
    /** Current status of the invitation. */
    status?: InvitesGetResponseStatus | null;
}
export interface GetOrganizationRequest {
    /** Identifier */
    organizationId: string;
}
export type GetOrganizationResponse = unknown;
export interface GetSpectrumAnalyticsZonesReportRequest {
    /** Include CDN traffic in the bandwidth aggregation. */
    cdnTraffic?: boolean;
    /** Start of time interval to query, defaults to `until` - 6 hours. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    since?: string;
    /** End of time interval to query, defaults to current time. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    until?: string;
}
export interface GetSpectrumAnalyticsZonesReportResultItemTotalsBandwidth {
    /** Sum of ingress and egress bytes transferred. */
    all: number;
    /** Sum of egress bytes transferred. */
    egress: number;
    /** Sum of ingress bytes transferred. */
    ingress: number;
}
export interface GetSpectrumAnalyticsZonesReportResultItemTotals {
    bandwidth: GetSpectrumAnalyticsZonesReportResultItemTotalsBandwidth;
}
export interface GetSpectrumAnalyticsZonesReportResultItem {
    totals: GetSpectrumAnalyticsZonesReportResultItemTotals;
    /** Identifier. */
    zoneId: string;
}
export type GetSpectrumAnalyticsZonesReportResultList = Array<GetSpectrumAnalyticsZonesReportResultItem>;
export type GetSpectrumAnalyticsZonesReportResponse = GetSpectrumAnalyticsZonesReportResultList;
export interface GetSubscriptionRequest {
}
export type SubscriptionsGetResultItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsGetResultItemRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsGetResultItemRatePlanSetsList = Array<string>;
export interface SubscriptionsGetResultItemRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsGetResultItemRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsGetResultItemRatePlanSetsList | null;
}
export type SubscriptionsGetResultItemState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export interface SubscriptionsGetResultItem {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsGetResultItemFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsGetResultItemRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsGetResultItemState | null;
}
export type SubscriptionsGetResultList = Array<SubscriptionsGetResultItem>;
export interface GetSubscriptionResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubscriptionsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetTokenRequest {
    /** Token identifier tag. */
    tokenId: string;
}
export type TokensGetResponseConditionRequestIpInList = Array<string>;
export type TokensGetResponseConditionRequestIpNotInList = Array<string>;
export interface TokensGetResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensGetResponseConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensGetResponseConditionRequestIpNotInList | null;
}
export interface TokensGetResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensGetResponseConditionRequestIp | null;
}
export type TokensGetResponsePoliciesItemEffect = "allow" | "deny";
export type TokensGetResponsePoliciesItemPermissionGroupsItemMeta = TokensCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensGetResponsePoliciesItemPermissionGroupsItem = TokensCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensGetResponsePoliciesItemPermissionGroupsList = Array<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensGetResponsePoliciesItemResourcesValue = string | TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensGetResponsePoliciesItemResourcesMap = {
    [key: string]: TokensGetResponsePoliciesItemResourcesValue | undefined;
};
export interface TokensGetResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensGetResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensGetResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensGetResponsePoliciesItemResourcesMap;
}
export type TokensGetResponsePoliciesList = Array<TokensGetResponsePoliciesItem>;
export type TokensGetResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTokenResponse {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensGetResponseCondition | null;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensGetResponsePoliciesList | null;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null;
    /** Status of the token. */
    status?: TokensGetResponseStatus | null;
}
export interface GetUserRequest {
}
export type GetResponseBetasList = Array<string>;
export type GetResponseOrganizationsItemPermissionsList = Array<unknown>;
export type GetResponseOrganizationsItemRolesList = Array<string>;
export type GetResponseOrganizationsItemStatus = "member" | "invited";
export interface GetResponseOrganizationsItem {
    /** Identifier */
    id?: string | null;
    /** Organization name. */
    name?: string | null;
    /** Access permissions for this User. */
    permissions?: GetResponseOrganizationsItemPermissionsList | null;
    /** List of roles that a user has within an organization. */
    roles?: GetResponseOrganizationsItemRolesList | null;
    /** Whether the user is a member of the organization or has an invitation pending. */
    status?: GetResponseOrganizationsItemStatus | null;
}
export type GetResponseOrganizationsList = Array<GetResponseOrganizationsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUserResponse {
    /** Identifier of the user. */
    id: string;
    /** Current email address of the user. */
    email: string;
    /** Lists the betas that the user is participating in. */
    betas?: GetResponseBetasList | null;
    /** The country in which the user lives. */
    country?: string | null;
    /** User's first name */
    firstName?: string | null;
    /** Indicates whether user has any business zones */
    hasBusinessZones?: boolean | null;
    /** Indicates whether user has any enterprise zones */
    hasEnterpriseZones?: boolean | null;
    /** Indicates whether user has any pro zones */
    hasProZones?: boolean | null;
    /** User's last name */
    lastName?: string | null;
    organizations?: GetResponseOrganizationsList | null;
    /** Indicates whether user has been suspended */
    suspended?: boolean | null;
    /** User's telephone number */
    telephone?: string | null;
    /** Indicates whether two-factor authentication is enabled for the user account. Does not apply to API authentication. */
    twoFactorAuthenticationEnabled?: boolean | null;
    /** Indicates whether two-factor authentication is required by one of the accounts that the user is a member of. */
    twoFactorAuthenticationLocked?: boolean | null;
    /** The zipcode or postal code where the user lives. */
    zipcode?: string | null;
}
export interface AuditLogsListRequestAction {
    /** Filters by the action type. */
    type?: string;
}
export interface AuditLogsListRequestActor {
    /** Filters by the email address of the actor that made the change. */
    email?: string;
    /** Filters by the IP address of the request that made the change by specific IP address or valid CIDR Range. */
    ip?: string;
}
export type AuditLogsListRequestDirection = "desc" | "asc";
export interface AuditLogsListRequestZone {
    /** Filters by the name of the zone associated to the change. */
    name?: string;
}
export interface ListAuditLogsRequest {
    /** Finds a specific log by its ID. */
    id?: string;
    action?: AuditLogsListRequestAction;
    actor?: AuditLogsListRequestActor;
    /** Limits the returned results to logs older than the specified date. A `full-date` that conforms to RFC3339. */
    before?: string;
    /** Changes the direction of the chronological sorting. */
    direction?: AuditLogsListRequestDirection | (string & {});
    /** Indicates that this request is an export of logs in CSV format. */
    export?: boolean;
    /** Indicates whether or not to hide user level audit logs. */
    hideUserLogs?: boolean;
    /** Defines which page of results to return. */
    page?: number;
    /** Sets the number of results to return per page. */
    perPage?: number;
    /** Limits the returned results to logs newer than the specified date. A `full-date` that conforms to RFC3339. */
    since?: string;
    zone?: AuditLogsListRequestZone;
}
export interface AuditLogsListResultItemAction {
    /** A boolean that indicates if the action attempted was successful. */
    result?: boolean | null;
    /** A short string that describes the action that was performed. */
    type?: string | null;
}
export type AuditLogsListResultItemActorType = "user" | "admin" | "Cloudflare";
export interface AuditLogsListResultItemActor {
    /** The ID of the actor that performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null;
    /** The email of the user that performed the action. */
    email?: string | null;
    /** The IP address of the request that performed the action. */
    ip?: string | null;
    /** The type of actor, whether a User, Cloudflare Admin, or an Automated System. */
    type?: AuditLogsListResultItemActorType | null;
}
export interface AuditLogsListResultItemOwner {
    /** Identifier */
    id?: string | null;
}
export interface AuditLogsListResultItemResource {
    /** An identifier for the resource that was affected by the action. */
    id?: string | null;
    /** A short string that describes the resource that was affected by the action. */
    type?: string | null;
}
export interface AuditLogsListResultItem {
    /** A string that uniquely identifies the audit log. */
    id?: string | null;
    action?: AuditLogsListResultItemAction | null;
    actor?: AuditLogsListResultItemActor | null;
    /** The source of the event. */
    interface?: string | null;
    /** An object which can lend more context to the action being logged. This is a flexible value and varies between different actions. */
    metadata?: unknown | null;
    /** The new value of the resource that was modified. */
    newValue?: string | null;
    /** The value of the resource before it was modified. */
    oldValue?: string | null;
    owner?: AuditLogsListResultItemOwner | null;
    resource?: AuditLogsListResultItemResource | null;
    /** A UTC RFC3339 timestamp that specifies when the action being logged occured. */
    when?: string | null;
}
export type AuditLogsListResultList = Array<AuditLogsListResultItem>;
export interface ListAuditLogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AuditLogsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type BillingHistoryListRequestOrder = "type" | "occurred_at" | "action";
export interface ListBillingHistoriesRequest {
    /** The billing item action. */
    action?: string;
    /** When the billing item was created. */
    occurredAt?: string;
    /** Field to order billing history by. */
    order?: BillingHistoryListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
    /** The billing item type. */
    type?: string;
}
export interface BillingHistoryListResultItemZone {
    name?: string | null;
}
export interface BillingHistoryListResultItem {
    /** Billing item identifier tag. */
    id: string;
    /** The billing item action. */
    action: string;
    /** The amount associated with this billing item. */
    amount: number;
    /** The monetary unit in which pricing information is displayed. */
    currency: string;
    /** The billing item description. */
    description: string;
    /** When the billing item was created. */
    occurredAt: string;
    /** The billing item type. */
    type: string;
    zone: BillingHistoryListResultItemZone;
}
export type BillingHistoryListResultList = Array<BillingHistoryListResultItem>;
export interface ListBillingHistoriesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: BillingHistoryListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListInvitesRequest {
}
export type InvitesListResultItemRolesList = Array<string>;
export type InvitesListResultItemStatus = "pending" | "accepted" | "rejected" | "expired";
export interface InvitesListResultItem {
    /** ID of the user to add to the organization. */
    invitedMemberId: string;
    /** ID of the organization the user will be added to. */
    organizationId: string;
    /** Invite identifier tag. */
    id?: string | null;
    /** When the invite is no longer active. */
    expiresOn?: string | null;
    /** The email address of the user who created the invite. */
    invitedBy?: string | null;
    /** Email address of the user to add to the organization. */
    invitedMemberEmail?: string | null;
    /** When the invite was sent. */
    invitedOn?: string | null;
    organizationIsEnforcingTwofactor?: boolean | null;
    /** Organization name. */
    organizationName?: string | null;
    /** List of role names the membership has for this account. */
    roles?: InvitesListResultItemRolesList | null;
    /** Current status of the invitation. */
    status?: InvitesListResultItemStatus | null;
}
export type InvitesListResultList = Array<InvitesListResultItem>;
export interface ListInvitesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvitesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type OrganizationsListRequestDirection = "asc" | "desc";
export type OrganizationsListRequestMatch = "any" | "all";
export type OrganizationsListRequestOrder = "id" | "name" | "status";
export type OrganizationsListRequestStatus = "member" | "invited";
export interface ListOrganizationsRequest {
    /** Direction to order organizations. */
    direction?: OrganizationsListRequestDirection | (string & {});
    /** Whether to match all search requirements or at least one (any). */
    match?: OrganizationsListRequestMatch | (string & {});
    /** Organization name. */
    name?: string;
    /** Field to order organizations by. */
    order?: OrganizationsListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of organizations per page. */
    perPage?: number;
    /** Whether the user is a member of the organization or has an inivitation pending. */
    status?: OrganizationsListRequestStatus | (string & {});
}
export type OrganizationsListResultItemPermissionsList = Array<unknown>;
export type OrganizationsListResultItemRolesList = Array<string>;
export type OrganizationsListResultItemStatus = "member" | "invited";
export interface OrganizationsListResultItem {
    /** Identifier */
    id?: string | null;
    /** Organization name. */
    name?: string | null;
    /** Access permissions for this User. */
    permissions?: OrganizationsListResultItemPermissionsList | null;
    /** List of roles that a user has within an organization. */
    roles?: OrganizationsListResultItemRolesList | null;
    /** Whether the user is a member of the organization or has an invitation pending. */
    status?: OrganizationsListResultItemStatus | null;
}
export type OrganizationsListResultList = Array<OrganizationsListResultItem>;
export interface ListOrganizationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OrganizationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListTenantsRequest {
}
export type TenantsListResultItemMetaHierarchyTagsList = Array<string>;
export interface TenantsListResultItemMetaTenantFlags {
    accountCreation: string;
    accountCreationAppliesTenantDefaults: string;
    accountDeletion: string;
    accountMigration: string;
    accountMobility: string;
    enterpriseCapability: string;
    memberManagement: string;
    subOrgCreation: string;
}
export interface TenantsListResultItemMeta {
    /** Ordered chain of organization tags from the root organization down to (and including) this organization itself. Root organizations return a single-element array containing their own tag; sub-organizations return `[rootTag, ...intermediateTags, parentTag, selfTag]`. Useful for constructing authorization scopes that need to cover every ancestor in the hierarchy. */
    hierarchyTags?: TenantsListResultItemMetaHierarchyTagsList | null;
    managedBy?: string | null;
    /** Enable features for Organizations. */
    tenantFlags?: TenantsListResultItemMetaTenantFlags | null;
}
export interface TenantsListResultItemParent {
    id: string;
    name: string;
}
export interface TenantsListResultItemProfile {
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export interface TenantsListResultItem {
    id: string;
    createTime: string;
    meta: TenantsListResultItemMeta;
    name: string;
    parent?: TenantsListResultItemParent | null;
    profile?: TenantsListResultItemProfile | null;
}
export type TenantsListResultList = Array<TenantsListResultItem>;
export interface ListTenantsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TenantsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListTokenPermissionGroupsRequest {
    /** Filter by the name of the permission group. The value must be URL-encoded. */
    name?: string;
    /** Filter by the scope of the permission group. The value must be URL-encoded. */
    scope?: string;
}
export type TokensPermissionGroupsListResultItemCategory = "developer_platform" | "ai_and_machine_learning" | "dns_and_zones" | "app_security" | "rules_and_configuration" | "cloudflare_one_and_zero_trust" | "analytics_and_logs" | "network_services" | "media" | "email_and_messaging" | "cache_and_performance" | "account_and_billing" | "other";
export type TokensPermissionGroupsListResultItemScopesItem = "com.cloudflare.api.account" | "com.cloudflare.api.account.zone" | "com.cloudflare.api.user" | "com.cloudflare.edge.r2.bucket";
export type TokensPermissionGroupsListResultItemScopesList = Array<TokensPermissionGroupsListResultItemScopesItem>;
export interface TokensPermissionGroupsListResultItem {
    /** Public ID. */
    id?: string | null;
    /** Product category that this permission group belongs to. */
    category?: TokensPermissionGroupsListResultItemCategory | null;
    /** Whether the caller can select this permission group when creating a token. */
    isSelectable?: boolean | null;
    /** Permission Group Name */
    name?: string | null;
    /** Resources to which the Permission Group is scoped */
    scopes?: TokensPermissionGroupsListResultItemScopesList | null;
}
export type TokensPermissionGroupsListResultList = Array<TokensPermissionGroupsListResultItem>;
export interface ListTokenPermissionGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TokensPermissionGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type TokensListRequestDirection = "asc" | "desc";
export interface ListTokensRequest {
    /** Direction to order results. */
    direction?: TokensListRequestDirection | (string & {});
    /** When true, includes recently-expired tokens in the response. */
    includeExpired?: boolean;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type TokensListResultItemConditionRequestIpInList = Array<string>;
export type TokensListResultItemConditionRequestIpNotInList = Array<string>;
export interface TokensListResultItemConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensListResultItemConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensListResultItemConditionRequestIpNotInList | null;
}
export interface TokensListResultItemCondition {
    /** Client IP restrictions. */
    requestIp?: TokensListResultItemConditionRequestIp | null;
}
export type TokensListResultItemPoliciesItemEffect = "allow" | "deny";
export type TokensListResultItemPoliciesItemPermissionGroupsItemMeta = TokensCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensListResultItemPoliciesItemPermissionGroupsItem = TokensCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensListResultItemPoliciesItemPermissionGroupsList = Array<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensListResultItemPoliciesItemResourcesValue = string | TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensListResultItemPoliciesItemResourcesMap = {
    [key: string]: TokensListResultItemPoliciesItemResourcesValue | undefined;
};
export interface TokensListResultItemPoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensListResultItemPoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensListResultItemPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensListResultItemPoliciesItemResourcesMap;
}
export type TokensListResultItemPoliciesList = Array<TokensListResultItemPoliciesItem>;
export type TokensListResultItemStatus = "active" | "disabled" | "expired";
export interface TokensListResultItem {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensListResultItemCondition | null;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensListResultItemPoliciesList | null;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null;
    /** Status of the token. */
    status?: TokensListResultItemStatus | null;
}
export type TokensListResultList = Array<TokensListResultItem>;
export interface ListTokensResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TokensListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type InvitesEditRequestStatus = "accepted" | "rejected";
export interface PatchInviteRequest {
    /** Invite identifier tag. */
    inviteId: string;
    /** Status of your response to the invitation (rejected or accepted). */
    status: InvitesEditRequestStatus | (string & {});
}
export type InvitesEditResponseRolesList = Array<string>;
export type InvitesEditResponseStatus = "pending" | "accepted" | "rejected" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchInviteResponse {
    /** ID of the user to add to the organization. */
    invitedMemberId: string;
    /** ID of the organization the user will be added to. */
    organizationId: string;
    /** Invite identifier tag. */
    id?: string | null;
    /** When the invite is no longer active. */
    expiresOn?: string | null;
    /** The email address of the user who created the invite. */
    invitedBy?: string | null;
    /** Email address of the user to add to the organization. */
    invitedMemberEmail?: string | null;
    /** When the invite was sent. */
    invitedOn?: string | null;
    organizationIsEnforcingTwofactor?: boolean | null;
    /** Organization name. */
    organizationName?: string | null;
    /** List of role names the membership has for this account. */
    roles?: InvitesEditResponseRolesList | null;
    /** Current status of the invitation. */
    status?: InvitesEditResponseStatus | null;
}
export interface PatchUserRequest {
    /** The country in which the user lives. */
    country?: string;
    /** User's first name */
    firstName?: string;
    /** User's last name */
    lastName?: string;
    /** User's telephone number */
    telephone?: string;
    /** The zipcode or postal code where the user lives. */
    zipcode?: string;
}
export type EditResponseBetasList = Array<string>;
export type EditResponseOrganizationsItemPermissionsList = Array<unknown>;
export type EditResponseOrganizationsItemRolesList = Array<string>;
export type EditResponseOrganizationsItemStatus = "member" | "invited";
export interface EditResponseOrganizationsItem {
    /** Identifier */
    id?: string | null;
    /** Organization name. */
    name?: string | null;
    /** Access permissions for this User. */
    permissions?: EditResponseOrganizationsItemPermissionsList | null;
    /** List of roles that a user has within an organization. */
    roles?: EditResponseOrganizationsItemRolesList | null;
    /** Whether the user is a member of the organization or has an invitation pending. */
    status?: EditResponseOrganizationsItemStatus | null;
}
export type EditResponseOrganizationsList = Array<EditResponseOrganizationsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchUserResponse {
    /** Identifier of the user. */
    id: string;
    /** Current email address of the user. */
    email: string;
    /** Lists the betas that the user is participating in. */
    betas?: EditResponseBetasList | null;
    /** The country in which the user lives. */
    country?: string | null;
    /** User's first name */
    firstName?: string | null;
    /** Indicates whether user has any business zones */
    hasBusinessZones?: boolean | null;
    /** Indicates whether user has any enterprise zones */
    hasEnterpriseZones?: boolean | null;
    /** Indicates whether user has any pro zones */
    hasProZones?: boolean | null;
    /** User's last name */
    lastName?: string | null;
    organizations?: EditResponseOrganizationsList | null;
    /** Indicates whether user has been suspended */
    suspended?: boolean | null;
    /** User's telephone number */
    telephone?: string | null;
    /** Indicates whether two-factor authentication is enabled for the user account. Does not apply to API authentication. */
    twoFactorAuthenticationEnabled?: boolean | null;
    /** Indicates whether two-factor authentication is required by one of the accounts that the user is a member of. */
    twoFactorAuthenticationLocked?: boolean | null;
    /** The zipcode or postal code where the user lives. */
    zipcode?: string | null;
}
export type SubscriptionsUpdateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsUpdateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsUpdateRequestRatePlanSetsList = Array<string>;
export interface SubscriptionsUpdateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateRequestRatePlanId | (string & {});
    /** The currency applied to the rate plan subscription. */
    currency?: string;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean;
    /** The full name of the rate plan. */
    publicName?: string;
    /** The scope that this rate plan applies to. */
    scope?: string;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateRequestRatePlanSetsList;
}
export interface PutSubscriptionRequest {
    /** Subscription identifier tag. */
    identifier: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateRequestFrequency | (string & {});
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateRequestRatePlan;
}
export type PutSubscriptionResponse = unknown;
export interface PutTokenValueRequest {
    /** Token identifier tag. */
    tokenId: string;
}
export type PutTokenValueResponse = unknown;
export type TokensUpdateRequestPoliciesItemEffect = "allow" | "deny";
export type TokensUpdateRequestPoliciesItemPermissionGroupsItemMeta = TokensCreateRequestPoliciesItemPermissionGroupsItemMeta;
export type TokensUpdateRequestPoliciesItemPermissionGroupsItem = TokensCreateRequestPoliciesItemPermissionGroupsItem;
export type TokensUpdateRequestPoliciesItemPermissionGroupsList = Array<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export type TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensUpdateRequestPoliciesItemResourcesValue = string | TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensUpdateRequestPoliciesItemResourcesMap = {
    [key: string]: TokensUpdateRequestPoliciesItemResourcesValue | undefined;
};
export interface TokensUpdateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    effect: TokensUpdateRequestPoliciesItemEffect | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensUpdateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensUpdateRequestPoliciesItemResourcesMap;
}
export type TokensUpdateRequestPoliciesList = Array<TokensUpdateRequestPoliciesItem>;
export type TokensUpdateRequestConditionRequestIpInList = Array<string>;
export type TokensUpdateRequestConditionRequestIpNotInList = Array<string>;
export interface TokensUpdateRequestConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensUpdateRequestConditionRequestIpInList;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensUpdateRequestConditionRequestIpNotInList;
}
export interface TokensUpdateRequestCondition {
    /** Client IP restrictions. */
    requestIp?: TokensUpdateRequestConditionRequestIp;
}
export type TokensUpdateRequestStatus = "active" | "disabled" | "expired";
export interface UpdateTokenRequest {
    /** Token identifier tag. */
    tokenId: string;
    /** Token name. */
    name: string;
    /** List of access policies assigned to the token. */
    policies: TokensUpdateRequestPoliciesList;
    condition?: TokensUpdateRequestCondition;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string;
    /** Status of the token. */
    status?: TokensUpdateRequestStatus | (string & {});
}
export type TokensUpdateResponseConditionRequestIpInList = Array<string>;
export type TokensUpdateResponseConditionRequestIpNotInList = Array<string>;
export interface TokensUpdateResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensUpdateResponseConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensUpdateResponseConditionRequestIpNotInList | null;
}
export interface TokensUpdateResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensUpdateResponseConditionRequestIp | null;
}
export type TokensUpdateResponsePoliciesItemEffect = "allow" | "deny";
export type TokensUpdateResponsePoliciesItemPermissionGroupsItemMeta = TokensCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensUpdateResponsePoliciesItemPermissionGroupsItem = TokensCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensUpdateResponsePoliciesItemPermissionGroupsList = Array<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensUpdateResponsePoliciesItemResourcesValue = string | TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensUpdateResponsePoliciesItemResourcesMap = {
    [key: string]: TokensUpdateResponsePoliciesItemResourcesValue | undefined;
};
export interface TokensUpdateResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensUpdateResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensUpdateResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensUpdateResponsePoliciesItemResourcesMap;
}
export type TokensUpdateResponsePoliciesList = Array<TokensUpdateResponsePoliciesItem>;
export type TokensUpdateResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTokenResponse {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensUpdateResponseCondition | null;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensUpdateResponsePoliciesList | null;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null;
    /** Status of the token. */
    status?: TokensUpdateResponseStatus | null;
}
export interface VerifyTokenRequest {
}
export type TokensVerifyResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface VerifyTokenResponse {
    /** Token identifier tag. */
    id: string;
    /** Status of the token. */
    status: TokensVerifyResponseStatus;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
}
export type CreateTokenError = InvalidRoute | InvalidTokenName | PermissionGroupNotFound | CloudflareOpError;
/** Create a new access token. */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type DeleteOrganizationError = CloudflareOpError;
/** Removes association to an organization. */
export declare const deleteOrganization: API.OperationMethod<DeleteOrganizationRequest, DeleteOrganizationResponse, DeleteOrganizationError, CloudflareOpContext>;
export type DeleteSubscriptionError = CloudflareOpError;
/** Deletes a user's subscription. */
export declare const deleteSubscription: API.OperationMethod<DeleteSubscriptionRequest, DeleteSubscriptionResponse, DeleteSubscriptionError, CloudflareOpContext>;
export type DeleteTokenError = InvalidRoute | MethodNotAllowed | TokenNotFound | CloudflareOpError;
/** Destroy a token. */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, CloudflareOpContext>;
export type GetBillingProfileError = CloudflareOpError;
/** Accesses your billing profile object. */
export declare const getBillingProfile: API.OperationMethod<GetBillingProfileRequest, GetBillingProfileResponse, GetBillingProfileError, CloudflareOpContext>;
export type GetInviteError = CloudflareOpError;
/** Gets the details of an invitation. */
export declare const getInvite: API.OperationMethod<GetInviteRequest, GetInviteResponse, GetInviteError, CloudflareOpContext>;
export type GetOrganizationError = CloudflareOpError;
/** Gets a specific organization the user is associated with. */
export declare const getOrganization: API.OperationMethod<GetOrganizationRequest, GetOrganizationResponse, GetOrganizationError, CloudflareOpContext>;
export type GetSpectrumAnalyticsZonesReportError = CloudflareOpError;
/** Retrieves a list of total bandwidth by zone over a given time period. */
export declare const getSpectrumAnalyticsZonesReport: API.OperationMethod<GetSpectrumAnalyticsZonesReportRequest, GetSpectrumAnalyticsZonesReportResponse, GetSpectrumAnalyticsZonesReportError, CloudflareOpContext>;
export type GetSubscriptionError = CloudflareOpError;
/** Lists all of a user's subscriptions. */
export declare const getSubscription: API.PaginatedOperationMethod<GetSubscriptionRequest, GetSubscriptionResponse, GetSubscriptionError, CloudflareOpContext, SubscriptionsGetResultItem>;
export type GetTokenError = InvalidRoute | TokenNotFound | CloudflareOpError;
/** Get information about a specific token. */
export declare const getToken: API.OperationMethod<GetTokenRequest, GetTokenResponse, GetTokenError, CloudflareOpContext>;
export type GetUserError = CloudflareOpError;
/** Retrieves detailed information about the currently authenticated user, including email, name, and account memberships. */
export declare const getUser: API.OperationMethod<GetUserRequest, GetUserResponse, GetUserError, CloudflareOpContext>;
export type ListAuditLogsError = CloudflareOpError;
/** Gets a list of audit logs for a user account. Can be filtered by who made the change, on which zone, and the timeframe of the change. */
export declare const listAuditLogs: API.PaginatedOperationMethod<ListAuditLogsRequest, ListAuditLogsResponse, ListAuditLogsError, CloudflareOpContext, AuditLogsListResultItem>;
export type ListBillingHistoriesError = CloudflareOpError;
/** Accesses your billing history object. */
export declare const listBillingHistories: API.PaginatedOperationMethod<ListBillingHistoriesRequest, ListBillingHistoriesResponse, ListBillingHistoriesError, CloudflareOpContext, BillingHistoryListResultItem>;
export type ListInvitesError = CloudflareOpError;
/** Lists all invitations associated with my user. */
export declare const listInvites: API.PaginatedOperationMethod<ListInvitesRequest, ListInvitesResponse, ListInvitesError, CloudflareOpContext, InvitesListResultItem>;
export type ListOrganizationsError = CloudflareOpError;
/** Lists organizations the user is associated with. */
export declare const listOrganizations: API.PaginatedOperationMethod<ListOrganizationsRequest, ListOrganizationsResponse, ListOrganizationsError, CloudflareOpContext, OrganizationsListResultItem>;
export type ListTenantsError = CloudflareOpError;
/** Retrieves list of tenants the authenticated user / method has access to. */
export declare const listTenants: API.PaginatedOperationMethod<ListTenantsRequest, ListTenantsResponse, ListTenantsError, CloudflareOpContext, TenantsListResultItem>;
export type ListTokenPermissionGroupsError = CloudflareOpError;
/** Find all available permission groups for API Tokens. */
export declare const listTokenPermissionGroups: API.PaginatedOperationMethod<ListTokenPermissionGroupsRequest, ListTokenPermissionGroupsResponse, ListTokenPermissionGroupsError, CloudflareOpContext, TokensPermissionGroupsListResultItem>;
export type ListTokensError = CloudflareOpError;
/** List all access tokens you created. Results include active, disabled, and recently-expired tokens when include_expired is set to true. */
export declare const listTokens: API.PaginatedOperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, CloudflareOpContext, TokensListResultItem>;
export type PatchInviteError = CloudflareOpError;
/** Responds to an invitation. */
export declare const patchInvite: API.OperationMethod<PatchInviteRequest, PatchInviteResponse, PatchInviteError, CloudflareOpContext>;
export type PatchUserError = CloudflareOpError;
/** Edit part of your user details. */
export declare const patchUser: API.OperationMethod<PatchUserRequest, PatchUserResponse, PatchUserError, CloudflareOpContext>;
export type PutSubscriptionError = CloudflareOpError;
/** Updates a user's subscriptions. */
export declare const putSubscription: API.OperationMethod<PutSubscriptionRequest, PutSubscriptionResponse, PutSubscriptionError, CloudflareOpContext>;
export type PutTokenValueError = InvalidRoute | TokenNotFound | CloudflareOpError;
/** Roll the token secret. */
export declare const putTokenValue: API.OperationMethod<PutTokenValueRequest, PutTokenValueResponse, PutTokenValueError, CloudflareOpContext>;
export type UpdateTokenError = InvalidRoute | MethodNotAllowed | TokenNotFound | PermissionGroupNotFound | CloudflareOpError;
/** Update an existing token. */
export declare const updateToken: API.OperationMethod<UpdateTokenRequest, UpdateTokenResponse, UpdateTokenError, CloudflareOpContext>;
export type VerifyTokenError = Forbidden | CloudflareOpError;
/** Test whether a token works. */
export declare const verifyToken: API.OperationMethod<VerifyTokenRequest, VerifyTokenResponse, VerifyTokenError, CloudflareOpContext>;
//# sourceMappingURL=user.d.ts.map