import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CertificateAlreadyDeleted_base: S.TaggedErrorClass<"CertificateAlreadyDeleted", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CertificateAlreadyDeleted extends /*@__PURE__*/ CertificateAlreadyDeleted_base {
}
declare const CertificateAlreadyExists_base: S.TaggedErrorClass<"CertificateAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CertificateAlreadyExists extends /*@__PURE__*/ CertificateAlreadyExists_base {
}
declare const CertificateInUse_base: S.TaggedErrorClass<"CertificateInUse", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CertificateInUse extends /*@__PURE__*/ CertificateInUse_base {
}
declare const CertificateNotFound_base: S.TaggedErrorClass<"CertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CertificateNotFound extends /*@__PURE__*/ CertificateNotFound_base {
}
export interface CreateMtlsCertificateRequest {
    /** Identifier. */
    accountId: string;
    /** Indicates whether the certificate is a CA or leaf certificate. */
    ca: boolean;
    /** The uploaded root CA certificate. */
    certificates: string;
    /** Optional unique name for the certificate. Only used for human readability. */
    name?: string;
    /** The private key for the certificate. This field is only needed for specific use cases such as using a custom certificate with Zero Trust's block page. */
    privateKey?: string;
}
export type CreateResponseType = "custom" | "gateway_managed" | "access_managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMtlsCertificateResponse {
    /** Certificate identifier tag. */
    id?: string | null;
    /** Indicates whether the certificate is a CA or leaf certificate. */
    ca?: boolean | null;
    /** The uploaded root CA certificate. */
    certificates?: string | null;
    /** When the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** Optional unique name for the certificate. Only used for human readability. */
    name?: string | null;
    /** The certificate serial number. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** The type of the certificate, indicating how it was created and who manages it. */
    type?: CreateResponseType | null;
    /** This is the time the certificate was updated. */
    updatedAt?: string | null;
    /** This is the time the certificate was uploaded. */
    uploadedOn?: string | null;
}
export interface DeleteMtlsCertificateRequest {
    /** Identifier. */
    accountId: string;
    /** Certificate identifier tag. */
    mtlsCertificateId: string;
}
export type DeleteResponseType = "custom" | "gateway_managed" | "access_managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMtlsCertificateResponse {
    /** Certificate identifier tag. */
    id?: string | null;
    /** Indicates whether the certificate is a CA or leaf certificate. */
    ca?: boolean | null;
    /** The uploaded root CA certificate. */
    certificates?: string | null;
    /** When the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** Optional unique name for the certificate. Only used for human readability. */
    name?: string | null;
    /** The certificate serial number. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** The type of the certificate, indicating how it was created and who manages it. */
    type?: DeleteResponseType | null;
    /** This is the time the certificate was uploaded. */
    uploadedOn?: string | null;
}
export interface GetAssociationRequest {
    /** Identifier. */
    accountId: string;
    /** Certificate identifier tag. */
    mtlsCertificateId: string;
}
export interface AssociationsGetResultItem {
    /** The service using the certificate. */
    service?: string | null;
    /** Certificate deployment status for the given service. */
    status?: string | null;
}
export type AssociationsGetResultList = Array<AssociationsGetResultItem>;
export interface GetAssociationResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AssociationsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetMtlsCertificateRequest {
    /** Identifier. */
    accountId: string;
    /** Certificate identifier tag. */
    mtlsCertificateId: string;
}
export type GetResponseType = "custom" | "gateway_managed" | "access_managed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMtlsCertificateResponse {
    /** Certificate identifier tag. */
    id?: string | null;
    /** Indicates whether the certificate is a CA or leaf certificate. */
    ca?: boolean | null;
    /** The uploaded root CA certificate. */
    certificates?: string | null;
    /** When the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** Optional unique name for the certificate. Only used for human readability. */
    name?: string | null;
    /** The certificate serial number. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** The type of the certificate, indicating how it was created and who manages it. */
    type?: GetResponseType | null;
    /** This is the time the certificate was uploaded. */
    uploadedOn?: string | null;
}
export type ListRequestType = "custom" | "gateway_managed" | "access_managed";
export type ListRequestTypeList = Array<ListRequestType | (string & {})>;
export interface ListMtlsCertificatesRequest {
    /** Identifier. */
    accountId: string;
    /** Filters results by certificate type. Multiple types can be comma-separated. */
    type?: ListRequestTypeList;
}
export type ListResultItemType = "custom" | "gateway_managed" | "access_managed";
export interface ListResultItem {
    /** Certificate identifier tag. */
    id?: string | null;
    /** Indicates whether the certificate is a CA or leaf certificate. */
    ca?: boolean | null;
    /** The uploaded root CA certificate. */
    certificates?: string | null;
    /** When the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** Optional unique name for the certificate. Only used for human readability. */
    name?: string | null;
    /** The certificate serial number. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** The type of the certificate, indicating how it was created and who manages it. */
    type?: ListResultItemType | null;
    /** This is the time the certificate was uploaded. */
    uploadedOn?: string | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListMtlsCertificatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type CreateMtlsCertificateError = CertificateAlreadyExists | CloudflareOpError;
/** Upload a certificate that you want to use with mTLS-enabled Cloudflare services, such as Bring Your Own CA (BYO-CA) for mTLS. To create certificates issued by the Cloudflare managed CA, use the [Create Client Certificate endpoint](https://developers.cloudflare.com/api/resources/client_certificates/methods/create/). */
export declare const createMtlsCertificate: API.OperationMethod<CreateMtlsCertificateRequest, CreateMtlsCertificateResponse, CreateMtlsCertificateError, CloudflareOpContext>;
export type DeleteMtlsCertificateError = CertificateNotFound | CertificateAlreadyDeleted | CertificateInUse | CloudflareOpError;
/** Deletes the mTLS certificate unless the certificate is in use by one or more Cloudflare services. */
export declare const deleteMtlsCertificate: API.OperationMethod<DeleteMtlsCertificateRequest, DeleteMtlsCertificateResponse, DeleteMtlsCertificateError, CloudflareOpContext>;
export type GetAssociationError = CloudflareOpError;
/** Lists all active associations between the certificate and Cloudflare services. */
export declare const getAssociation: API.PaginatedOperationMethod<GetAssociationRequest, GetAssociationResponse, GetAssociationError, CloudflareOpContext, AssociationsGetResultItem>;
export type GetMtlsCertificateError = CertificateNotFound | CloudflareOpError;
/** Fetches a single mTLS certificate uploaded to your account. To get a certificate issued by the Cloudflare managed CA, use the [Client Certificate Details endpoint](https://developers.cloudflare.com/api/resources/client_certificates/methods/get/). */
export declare const getMtlsCertificate: API.OperationMethod<GetMtlsCertificateRequest, GetMtlsCertificateResponse, GetMtlsCertificateError, CloudflareOpContext>;
export type ListMtlsCertificatesError = CloudflareOpError;
/** Lists all mTLS certificates uploaded to your account, such as Bring Your Own CA (BYO-CA) for mTLS. To list certificates issued by the Cloudflare managed CA, use the [List Client Certificates endpoint](https://developers.cloudflare.com/api/resources/client_certificates/methods/list/). */
export declare const listMtlsCertificates: API.PaginatedOperationMethod<ListMtlsCertificatesRequest, ListMtlsCertificatesResponse, ListMtlsCertificatesError, CloudflareOpContext, ListResultItem>;
//# sourceMappingURL=mtls_certificates.d.ts.map