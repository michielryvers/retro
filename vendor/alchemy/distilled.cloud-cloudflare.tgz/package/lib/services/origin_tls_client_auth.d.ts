import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CertificateAlreadyDeleted_base: S.TaggedErrorClass<"CertificateAlreadyDeleted", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CertificateAlreadyDeleted extends /*@__PURE__*/ CertificateAlreadyDeleted_base {
}
declare const CertificateAlreadyExists_base: S.TaggedErrorClass<"CertificateAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CertificateAlreadyExists extends /*@__PURE__*/ CertificateAlreadyExists_base {
}
declare const CertificateNotFound_base: S.TaggedErrorClass<"CertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CertificateNotFound extends /*@__PURE__*/ CertificateNotFound_base {
}
declare const CertificatePendingDeletion_base: S.TaggedErrorClass<"CertificatePendingDeletion", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CertificatePendingDeletion extends /*@__PURE__*/ CertificatePendingDeletion_base {
}
declare const CertificatePendingDeployment_base: S.TaggedErrorClass<"CertificatePendingDeployment", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CertificatePendingDeployment extends /*@__PURE__*/ CertificatePendingDeployment_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HostnameAssociationNotFound_base: S.TaggedErrorClass<"HostnameAssociationNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HostnameAssociationNotFound extends /*@__PURE__*/ HostnameAssociationNotFound_base {
}
declare const HostnameCertificateIdRequired_base: S.TaggedErrorClass<"HostnameCertificateIdRequired", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HostnameCertificateIdRequired extends /*@__PURE__*/ HostnameCertificateIdRequired_base {
}
declare const HostnameCertificateInUse_base: S.TaggedErrorClass<"HostnameCertificateInUse", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HostnameCertificateInUse extends /*@__PURE__*/ HostnameCertificateInUse_base {
}
declare const HostnameCertificateNotFound_base: S.TaggedErrorClass<"HostnameCertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HostnameCertificateNotFound extends /*@__PURE__*/ HostnameCertificateNotFound_base {
}
declare const InvalidCertificate_base: S.TaggedErrorClass<"InvalidCertificate", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidCertificate extends /*@__PURE__*/ InvalidCertificate_base {
}
declare const InvalidCertificateId_base: S.TaggedErrorClass<"InvalidCertificateId", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidCertificateId extends /*@__PURE__*/ InvalidCertificateId_base {
}
declare const InvalidHostnameConfig_base: S.TaggedErrorClass<"InvalidHostnameConfig", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidHostnameConfig extends /*@__PURE__*/ InvalidHostnameConfig_base {
}
declare const ZoneClientCertConflict_base: S.TaggedErrorClass<"ZoneClientCertConflict", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ZoneClientCertConflict extends /*@__PURE__*/ ZoneClientCertConflict_base {
}
export interface CreateHostnameCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** The hostname certificate. */
    certificate: string;
    /** The hostname certificate's private key. */
    privateKey: string;
}
export type HostnameCertificatesCreateResponseStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateHostnameCertificateResponse {
    /** Certificate identifier tag. */
    id?: string | null;
    /** The hostname certificate. */
    certificate?: string | null;
    /** The date when the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** The serial number on the uploaded certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the certificate or the association. */
    status?: HostnameCertificatesCreateResponseStatus | null;
    /** The time when the certificate was uploaded. */
    uploadedOn?: string | null;
}
export interface CreateOriginTlsClientAuthRequest {
    /** Identifier. */
    zoneId: string;
    /** The zone's leaf certificate. */
    certificate: string;
    /** The zone's private key. */
    privateKey: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOriginTlsClientAuthResponse {
    /** Certificate identifier tag. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
    expiresOn?: string | null;
    issuer?: string | null;
    signature?: string | null;
    status?: string | null;
    uploadedOn?: string | null;
}
export interface CreateZoneCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** The zone's leaf certificate. */
    certificate: string;
    /** The zone's private key. */
    privateKey: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneCertificateResponse {
    /** Certificate identifier tag. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
}
export interface DeleteHostnameCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Certificate identifier tag. */
    certificateId: string;
}
export type HostnameCertificatesDeleteResponseStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteHostnameCertificateResponse {
    /** Certificate identifier tag. */
    id?: string | null;
    /** The hostname certificate. */
    certificate?: string | null;
    /** The date when the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** The serial number on the uploaded certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the certificate or the association. */
    status?: HostnameCertificatesDeleteResponseStatus | null;
    /** The time when the certificate was uploaded. */
    uploadedOn?: string | null;
}
export interface DeleteOriginTlsClientAuthRequest {
    /** Identifier. */
    zoneId: string;
    /** Certificate identifier tag. */
    certificateId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOriginTlsClientAuthResponse {
    /** Certificate identifier tag. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
}
export interface DeleteZoneCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Certificate identifier tag. */
    certificateId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneCertificateResponse {
    /** Certificate identifier tag. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
}
export interface GetHostnameRequest {
    /** Identifier. */
    zoneId: string;
    /** The hostname on the origin for which the client certificate uploaded will be used. */
    hostname: string;
}
export type HostnamesGetResponseCertStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out";
export type HostnamesGetResponseStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHostnameResponse {
    /** Certificate identifier tag. */
    certId?: string | null;
    /** Status of the certificate or the association. */
    certStatus?: HostnamesGetResponseCertStatus | null;
    /** The time when the certificate was updated. */
    certUpdatedAt?: string | null;
    /** The time when the certificate was uploaded. */
    certUploadedOn?: string | null;
    /** The hostname certificate. */
    certificate?: string | null;
    /** The time when the certificate was created. */
    createdAt?: string | null;
    /** Indicates whether hostname-level authenticated origin pulls is enabled. A null value voids the association. */
    enabled?: boolean | null;
    /** The date when the certificate expires. */
    expiresOn?: string | null;
    /** The hostname on the origin for which the client certificate uploaded will be used. */
    hostname?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** The serial number on the uploaded certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the certificate or the association. */
    status?: HostnamesGetResponseStatus | null;
    /** The time when the certificate was updated. */
    updatedAt?: string | null;
}
export interface GetHostnameCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Certificate identifier tag. */
    certificateId: string;
}
export type HostnameCertificatesGetResponseStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHostnameCertificateResponse {
    /** Certificate identifier tag. */
    id?: string | null;
    /** The hostname certificate. */
    certificate?: string | null;
    /** The date when the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** The serial number on the uploaded certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the certificate or the association. */
    status?: HostnameCertificatesGetResponseStatus | null;
    /** The time when the certificate was uploaded. */
    uploadedOn?: string | null;
}
export interface GetOriginTlsClientAuthRequest {
    /** Identifier. */
    zoneId: string;
    /** Certificate identifier tag. */
    certificateId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOriginTlsClientAuthResponse {
    /** Certificate identifier tag. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
    expiresOn?: string | null;
    issuer?: string | null;
    signature?: string | null;
    status?: string | null;
    uploadedOn?: string | null;
}
export interface GetSettingRequest {
    /** Identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingResponse {
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
}
export interface GetZoneCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Certificate identifier tag. */
    certificateId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneCertificateResponse {
    /** Certificate identifier tag. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
}
export interface ListHostnameCertificatesRequest {
    /** Identifier. */
    zoneId: string;
}
export type HostnameCertificatesListResultItemStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out";
export interface HostnameCertificatesListResultItem {
    /** Certificate identifier tag. */
    id?: string | null;
    /** The hostname certificate. */
    certificate?: string | null;
    /** The date when the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** The serial number on the uploaded certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the certificate or the association. */
    status?: HostnameCertificatesListResultItemStatus | null;
    /** The time when the certificate was uploaded. */
    uploadedOn?: string | null;
}
export type HostnameCertificatesListResultList = Array<HostnameCertificatesListResultItem>;
export interface ListHostnameCertificatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: HostnameCertificatesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListOriginTlsClientAuthsRequest {
    /** Identifier. */
    zoneId: string;
}
export interface ListResultItem {
    /** Certificate identifier tag. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
    expiresOn?: string | null;
    issuer?: string | null;
    signature?: string | null;
    status?: string | null;
    uploadedOn?: string | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListOriginTlsClientAuthsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListZoneCertificatesRequest {
    /** Identifier. */
    zoneId: string;
}
export interface ListZoneCertificatesResultItem {
    /** Certificate identifier tag. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
}
export type ListZoneCertificatesResultList = Array<ListZoneCertificatesResultItem>;
export interface ListZoneCertificatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListZoneCertificatesResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface HostnamesUpdateRequestConfigItem {
    /** Certificate identifier tag. */
    certId?: string;
    /** Indicates whether hostname-level authenticated origin pulls is enabled. A null value voids the association. */
    enabled?: boolean | null;
    /** The hostname on the origin for which the client certificate uploaded will be used. */
    hostname?: string;
}
export type HostnamesUpdateRequestConfigList = Array<HostnamesUpdateRequestConfigItem>;
export interface PutHostnameRequest {
    /** Identifier. */
    zoneId: string;
    config: HostnamesUpdateRequestConfigList;
}
export interface HostnamesUpdateResultItem {
    /** Certificate identifier tag. */
    id?: string | null;
    /** Certificate identifier tag. */
    certId?: string | null;
    /** The hostname certificate. */
    certificate?: string | null;
    /** Indicates whether hostname-level authenticated origin pulls is enabled. A null value voids the association. */
    enabled?: boolean | null;
    /** The hostname on the origin for which the client certificate uploaded will be used. */
    hostname?: string | null;
    /** The hostname certificate's private key. */
    privateKey?: string | null;
}
export type HostnamesUpdateResultList = Array<HostnamesUpdateResultItem>;
export interface PutHostnameResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: HostnamesUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface PutSettingRequest {
    /** Identifier. */
    zoneId: string;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSettingResponse {
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
}
export type CreateHostnameCertificateError = CertificateAlreadyExists | InvalidCertificate | Forbidden | CloudflareOpError;
/** Upload a certificate to be used for client authentication on a hostname. 10 hostname certificates per zone are allowed. */
export declare const createHostnameCertificate: API.OperationMethod<CreateHostnameCertificateRequest, CreateHostnameCertificateResponse, CreateHostnameCertificateError, CloudflareOpContext>;
export type CreateOriginTlsClientAuthError = CertificateAlreadyExists | InvalidCertificate | ZoneClientCertConflict | Forbidden | CloudflareOpError;
/** Upload your own certificate you want Cloudflare to use for edge-to-origin communication to override the shared certificate. Please note that it is important to keep only one certificate active. Also, make sure to enable zone-level authenticated origin pulls by making a PUT call to settings endpoint to see the uploaded certificate in use. */
export declare const createOriginTlsClientAuth: API.OperationMethod<CreateOriginTlsClientAuthRequest, CreateOriginTlsClientAuthResponse, CreateOriginTlsClientAuthError, CloudflareOpContext>;
export type CreateZoneCertificateError = CertificateAlreadyExists | InvalidCertificate | ZoneClientCertConflict | Forbidden | CloudflareOpError;
/** Upload your own certificate you want Cloudflare to use for edge-to-origin communication to override the shared certificate. Please note that it is important to keep only one certificate active. Also, make sure to enable zone-level authenticated origin pulls by making a PUT call to settings endpoint to see the uploaded certificate in use. */
export declare const createZoneCertificate: API.OperationMethod<CreateZoneCertificateRequest, CreateZoneCertificateResponse, CreateZoneCertificateError, CloudflareOpContext>;
export type DeleteHostnameCertificateError = HostnameCertificateNotFound | HostnameCertificateInUse | CertificatePendingDeletion | CertificatePendingDeployment | InvalidCertificateId | Forbidden | CloudflareOpError;
/** Removes a client certificate used for authenticated origin pulls on a specific hostname. Note: Before deleting the certificate, you must first invalidate the hostname for client authentication by sending a PUT request with `enabled` set to null. After invalidating the association, the certificate can be safely deleted. */
export declare const deleteHostnameCertificate: API.OperationMethod<DeleteHostnameCertificateRequest, DeleteHostnameCertificateResponse, DeleteHostnameCertificateError, CloudflareOpContext>;
export type DeleteOriginTlsClientAuthError = CertificateNotFound | Forbidden | CertificateAlreadyDeleted | CertificatePendingDeployment | ZoneClientCertConflict | CloudflareOpError;
/** Removes a client certificate used for zone-level authenticated origin pulls. */
export declare const deleteOriginTlsClientAuth: API.OperationMethod<DeleteOriginTlsClientAuthRequest, DeleteOriginTlsClientAuthResponse, DeleteOriginTlsClientAuthError, CloudflareOpContext>;
export type DeleteZoneCertificateError = CertificateNotFound | Forbidden | CertificateAlreadyDeleted | CertificatePendingDeployment | ZoneClientCertConflict | CloudflareOpError;
/** Removes a client certificate used for zone-level authenticated origin pulls. */
export declare const deleteZoneCertificate: API.OperationMethod<DeleteZoneCertificateRequest, DeleteZoneCertificateResponse, DeleteZoneCertificateError, CloudflareOpContext>;
export type GetHostnameError = HostnameAssociationNotFound | Forbidden | CloudflareOpError;
/** Retrieves the client certificate authentication status for a specific hostname, showing whether authenticated origin pulls are enabled. */
export declare const getHostname: API.OperationMethod<GetHostnameRequest, GetHostnameResponse, GetHostnameError, CloudflareOpContext>;
export type GetHostnameCertificateError = HostnameCertificateNotFound | Forbidden | CloudflareOpError;
/** Get the certificate by ID to be used for client authentication on a hostname. */
export declare const getHostnameCertificate: API.OperationMethod<GetHostnameCertificateRequest, GetHostnameCertificateResponse, GetHostnameCertificateError, CloudflareOpContext>;
export type GetOriginTlsClientAuthError = CertificateNotFound | Forbidden | CloudflareOpError;
/** Retrieves details for a specific client certificate used in zone-level authenticated origin pulls. */
export declare const getOriginTlsClientAuth: API.OperationMethod<GetOriginTlsClientAuthRequest, GetOriginTlsClientAuthResponse, GetOriginTlsClientAuthError, CloudflareOpContext>;
export type GetSettingError = Forbidden | CloudflareOpError;
/** Get whether zone-level authenticated origin pulls is enabled or not. It is false by default. */
export declare const getSetting: API.OperationMethod<GetSettingRequest, GetSettingResponse, GetSettingError, CloudflareOpContext>;
export type GetZoneCertificateError = CertificateNotFound | Forbidden | CloudflareOpError;
/** Retrieves details for a specific client certificate used in zone-level authenticated origin pulls. */
export declare const getZoneCertificate: API.OperationMethod<GetZoneCertificateRequest, GetZoneCertificateResponse, GetZoneCertificateError, CloudflareOpContext>;
export type ListHostnameCertificatesError = Forbidden | CloudflareOpError;
/** Lists all client certificates configured for per-hostname authenticated origin pulls on the zone. */
export declare const listHostnameCertificates: API.PaginatedOperationMethod<ListHostnameCertificatesRequest, ListHostnameCertificatesResponse, ListHostnameCertificatesError, CloudflareOpContext, HostnameCertificatesListResultItem>;
export type ListOriginTlsClientAuthsError = Forbidden | CloudflareOpError;
/** Lists all client certificates configured for zone-level authenticated origin pulls. */
export declare const listOriginTlsClientAuths: API.PaginatedOperationMethod<ListOriginTlsClientAuthsRequest, ListOriginTlsClientAuthsResponse, ListOriginTlsClientAuthsError, CloudflareOpContext, ListResultItem>;
export type ListZoneCertificatesError = Forbidden | CloudflareOpError;
/** Lists all client certificates configured for zone-level authenticated origin pulls. */
export declare const listZoneCertificates: API.PaginatedOperationMethod<ListZoneCertificatesRequest, ListZoneCertificatesResponse, ListZoneCertificatesError, CloudflareOpContext, ListZoneCertificatesResultItem>;
export type PutHostnameError = HostnameCertificateIdRequired | InvalidHostnameConfig | Forbidden | CloudflareOpError;
/** Associate a hostname to a certificate and enable, disable or invalidate the association. If disabled, client certificate will not be sent to the hostname even if activated at the zone level. 100 maximum associations on a single certificate are allowed. Note: Use a null value for parameter *enabled* to invalidate the association. */
export declare const putHostname: API.PaginatedOperationMethod<PutHostnameRequest, PutHostnameResponse, PutHostnameError, CloudflareOpContext, HostnamesUpdateResultItem>;
export type PutSettingError = Forbidden | CloudflareOpError;
/** Enable or disable zone-level authenticated origin pulls. 'enabled' should be set true either before/after the certificate is uploaded to see the certificate in use. */
export declare const putSetting: API.OperationMethod<PutSettingRequest, PutSettingResponse, PutSettingError, CloudflareOpContext>;
//# sourceMappingURL=origin_tls_client_auth.d.ts.map