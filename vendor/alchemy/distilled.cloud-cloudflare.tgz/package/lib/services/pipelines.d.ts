import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const IngestStreamNotFound_base: S.TaggedErrorClass<"IngestStreamNotFound", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** 1000: the stream does not exist (HTTP ingest). */
export declare class IngestStreamNotFound extends /*@__PURE__*/ IngestStreamNotFound_base {
}
declare const InvalidIngestData_base: S.TaggedErrorClass<"InvalidIngestData", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** 1002 / 1003: the body is not a non-empty array of JSON objects, or not valid UTF-8 JSON. */
export declare class InvalidIngestData extends /*@__PURE__*/ InvalidIngestData_base {
}
declare const InvalidSinkConfig_base: S.TaggedErrorClass<"InvalidSinkConfig", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidSinkConfig extends /*@__PURE__*/ InvalidSinkConfig_base {
}
declare const InvalidSinkId_base: S.TaggedErrorClass<"InvalidSinkId", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidSinkId extends /*@__PURE__*/ InvalidSinkId_base {
}
declare const InvalidSql_base: S.TaggedErrorClass<"InvalidSql", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidSql extends /*@__PURE__*/ InvalidSql_base {
}
declare const InvalidStreamId_base: S.TaggedErrorClass<"InvalidStreamId", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidStreamId extends /*@__PURE__*/ InvalidStreamId_base {
}
declare const InvalidStreamName_base: S.TaggedErrorClass<"InvalidStreamName", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidStreamName extends /*@__PURE__*/ InvalidStreamName_base {
}
declare const PipelineAlreadyExists_base: S.TaggedErrorClass<"PipelineAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PipelineAlreadyExists extends /*@__PURE__*/ PipelineAlreadyExists_base {
}
declare const PipelineNotExists_base: S.TaggedErrorClass<"PipelineNotExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PipelineNotExists extends /*@__PURE__*/ PipelineNotExists_base {
}
declare const SinkAlreadyExists_base: S.TaggedErrorClass<"SinkAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SinkAlreadyExists extends /*@__PURE__*/ SinkAlreadyExists_base {
}
declare const SinkAuthFailed_base: S.TaggedErrorClass<"SinkAuthFailed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SinkAuthFailed extends /*@__PURE__*/ SinkAuthFailed_base {
}
declare const SinkInUse_base: S.TaggedErrorClass<"SinkInUse", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SinkInUse extends /*@__PURE__*/ SinkInUse_base {
}
declare const SinkNotFound_base: S.TaggedErrorClass<"SinkNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SinkNotFound extends /*@__PURE__*/ SinkNotFound_base {
}
declare const StreamAlreadyExists_base: S.TaggedErrorClass<"StreamAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class StreamAlreadyExists extends /*@__PURE__*/ StreamAlreadyExists_base {
}
declare const StreamInUse_base: S.TaggedErrorClass<"StreamInUse", {
    readonly code: any;
    readonly message: any;
}>;
export declare class StreamInUse extends /*@__PURE__*/ StreamInUse_base {
}
declare const StreamNotFound_base: S.TaggedErrorClass<"StreamNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class StreamNotFound extends /*@__PURE__*/ StreamNotFound_base {
}
declare const TableNotFound_base: S.TaggedErrorClass<"TableNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TableNotFound extends /*@__PURE__*/ TableNotFound_base {
}
export interface CreateRequestDestinationBatch {
    /** Specifies rough maximum size of files. */
    maxBytes?: number;
    /** Specifies duration to wait to aggregate batches files. */
    maxDurationS?: number;
    /** Specifies rough maximum number of rows per file. */
    maxRows?: number;
}
export type CreateRequestDestinationCompressionType = "none" | "gzip" | "deflate";
export interface CreateRequestDestinationCompression {
    /** Specifies the desired compression algorithm and format. */
    type?: CreateRequestDestinationCompressionType | (string & {});
}
export interface CreateRequestDestinationCredentials {
    /** Specifies the R2 Bucket Access Key Id. */
    accessKeyId: string;
    /** Specifies the R2 Endpoint. */
    endpoint: string;
    /** Specifies the R2 Bucket Secret Access Key. */
    secretAccessKey: string;
}
export type CreateRequestDestinationFormat = "json";
export interface CreateRequestDestinationPath {
    /** Specifies the R2 Bucket to store files. */
    bucket: string;
    /** Specifies the name pattern to for individual data files. */
    filename?: string;
    /** Specifies the name pattern for directory. */
    filepath?: string;
    /** Specifies the base directory within the bucket. */
    prefix?: string;
}
export type CreateRequestDestinationType = "r2";
export interface CreateRequestDestination {
    batch: CreateRequestDestinationBatch;
    compression: CreateRequestDestinationCompression;
    credentials: CreateRequestDestinationCredentials;
    /** Specifies the format of data to deliver. */
    format: CreateRequestDestinationFormat | (string & {});
    path: CreateRequestDestinationPath;
    /** Specifies the type of destination. */
    type: CreateRequestDestinationType | (string & {});
}
export type CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat = "json";
export type CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList = Array<string>;
export interface CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors {
    /** Specifies allowed origins to allow Cross Origin HTTP Requests. */
    origins?: CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList;
}
export interface CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource {
    /** Specifies the format of source data. */
    format: CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat;
    type: string;
    /** Specifies whether authentication is required to send to this pipeline via HTTP. */
    authentication?: boolean;
    cors?: CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors;
}
export type CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat = "json";
export interface CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSource {
    /** Specifies the format of source data. */
    format: CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat;
    type: string;
}
export type CreateRequestSourceItem = CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource | CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSource;
export type CreateRequestSourceList = Array<CreateRequestSourceItem>;
export interface CreatePipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    destination: CreateRequestDestination;
    /** Defines the name of the pipeline. */
    name: string;
    source: CreateRequestSourceList;
}
export interface CreateResponseDestinationBatch {
    /** Specifies rough maximum size of files. */
    maxBytes: number;
    /** Specifies duration to wait to aggregate batches files. */
    maxDurationS: number;
    /** Specifies rough maximum number of rows per file. */
    maxRows: number;
}
export type CreateResponseDestinationCompressionType = "none" | "gzip" | "deflate";
export interface CreateResponseDestinationCompression {
    /** Specifies the desired compression algorithm and format. */
    type: CreateResponseDestinationCompressionType;
}
export type CreateResponseDestinationFormat = "json";
export interface CreateResponseDestinationPath {
    /** Specifies the R2 Bucket to store files. */
    bucket: string;
    /** Specifies the name pattern to for individual data files. */
    filename?: string | null;
    /** Specifies the name pattern for directory. */
    filepath?: string | null;
    /** Specifies the base directory within the bucket. */
    prefix?: string | null;
}
export type CreateResponseDestinationType = "r2";
export interface CreateResponseDestination {
    batch: CreateResponseDestinationBatch;
    compression: CreateResponseDestinationCompression;
    /** Specifies the format of data to deliver. */
    format: CreateResponseDestinationFormat;
    path: CreateResponseDestinationPath;
    /** Specifies the type of destination. */
    type: CreateResponseDestinationType;
}
export type CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat = "json";
export type CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList = Array<string>;
export interface CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors {
    /** Specifies allowed origins to allow Cross Origin HTTP Requests. */
    origins?: CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList | null;
}
export interface CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource {
    /** Specifies the format of source data. */
    format: CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat;
    type: string;
    /** Specifies whether authentication is required to send to this pipeline via HTTP. */
    authentication?: boolean | null;
    cors?: CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors | null;
}
export type CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat = "json";
export interface CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource {
    /** Specifies the format of source data. */
    format: CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat;
    type: string;
}
export type CreateResponseSourceItem = CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource | CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource;
export type CreateResponseSourceList = Array<CreateResponseSourceItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePipelineResponse {
    /** Specifies the pipeline identifier. */
    id: string;
    destination: CreateResponseDestination;
    /** Indicates the endpoint URL to send traffic. */
    endpoint: string;
    /** Defines the name of the pipeline. */
    name: string;
    source: CreateResponseSourceList;
    /** Indicates the version number of last saved configuration. */
    version: number;
}
export type SinksCreateRequestType = "r2" | "r2_data_catalog" | "basin_catalog";
export interface SinksCreateRequestConfigCloudflarePipelinesR2TableCredentials {
    /** Cloudflare Account ID for the bucket */
    accessKeyId: string;
    /** Cloudflare Account ID for the bucket */
    secretAccessKey: string;
}
export type SinksCreateRequestConfigCloudflarePipelinesR2TableFileNamingStrategy = "serial" | "uuid" | "uuid_v7" | "ulid";
export interface SinksCreateRequestConfigCloudflarePipelinesR2TableFileNaming {
    /** The prefix to use in file name. i.e prefix-.parquet */
    prefix?: string;
    /** Filename generation strategy. */
    strategy?: SinksCreateRequestConfigCloudflarePipelinesR2TableFileNamingStrategy | (string & {});
    /** This will overwrite the default file suffix. i.e .parquet, use with caution */
    suffix?: string;
}
export interface SinksCreateRequestConfigCloudflarePipelinesR2TablePartitioning {
    /** The pattern of the date string */
    timePattern?: string;
}
export interface SinksCreateRequestConfigCloudflarePipelinesR2TableRollingPolicy {
    /** Files will be rolled after reaching this number of bytes */
    fileSizeBytes?: number;
    /** Number of seconds of inactivity to wait before rolling over to a new file */
    inactivitySeconds?: number;
    /** Number of seconds to wait before rolling over to a new file */
    intervalSeconds?: number;
}
export interface SinksCreateRequestConfigCloudflarePipelinesR2Table {
    /** Cloudflare Account ID for the bucket */
    accountId: string;
    /** R2 Bucket to write to */
    bucket: string;
    credentials: SinksCreateRequestConfigCloudflarePipelinesR2TableCredentials;
    /** Controls filename prefix/suffix and strategy. */
    fileNaming?: SinksCreateRequestConfigCloudflarePipelinesR2TableFileNaming;
    /** Jurisdiction this bucket is hosted in */
    jurisdiction?: string;
    /** Data-layout partitioning for sinks. */
    partitioning?: SinksCreateRequestConfigCloudflarePipelinesR2TablePartitioning;
    /** Subpath within the bucket to write to */
    path?: string;
    /** Rolling policy for file sinks (when &amp; why to close a file and open a new one). */
    rollingPolicy?: SinksCreateRequestConfigCloudflarePipelinesR2TableRollingPolicy;
}
export type SinksCreateRequestConfigCloudflarePipelinesR2DataCatalogTableRollingPolicy = SinksCreateRequestConfigCloudflarePipelinesR2TableRollingPolicy;
export interface SinksCreateRequestConfigCloudflarePipelinesR2DataCatalogTable {
    /** Authentication token */
    token: string;
    /** Cloudflare Account ID */
    accountId: string;
    /** The R2 Bucket that hosts this catalog */
    bucket: string;
    /** Table name */
    tableName: string;
    /** Table namespace */
    namespace?: string;
    /** Rolling policy for file sinks (when &amp; why to close a file and open a new one). */
    rollingPolicy?: SinksCreateRequestConfigCloudflarePipelinesR2TableRollingPolicy;
}
export type SinksCreateRequestConfig = SinksCreateRequestConfigCloudflarePipelinesR2Table | SinksCreateRequestConfigCloudflarePipelinesR2DataCatalogTable;
export type SinksCreateRequestFormatJsonType = "json";
export type SinksCreateRequestFormatJsonCompression = "uncompressed" | "gzip";
export type SinksCreateRequestFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export type SinksCreateRequestFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export interface SinksCreateRequestFormatJson {
    type: SinksCreateRequestFormatJsonType;
    /** Specifies the compression applied to JSON sink output. */
    compression?: SinksCreateRequestFormatJsonCompression | (string & {});
    decimalEncoding?: SinksCreateRequestFormatJsonDecimalEncoding | (string & {});
    timestampFormat?: SinksCreateRequestFormatJsonTimestampFormat | (string & {});
    unstructured?: boolean;
}
export type SinksCreateRequestFormatParquetType = "parquet";
export type SinksCreateRequestFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export interface SinksCreateRequestFormatParquet {
    type: SinksCreateRequestFormatParquetType;
    compression?: SinksCreateRequestFormatParquetCompression | (string & {});
    rowGroupBytes?: number;
}
export type SinksCreateRequestFormat = SinksCreateRequestFormatJson | SinksCreateRequestFormatParquet;
export type SinksCreateRequestSchemaFieldsItemInt32Type = "int32";
export interface SinksCreateRequestSchemaFieldsItemInt32 {
    type: SinksCreateRequestSchemaFieldsItemInt32Type;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type SinksCreateRequestSchemaFieldsItemInt64Type = "int64";
export interface SinksCreateRequestSchemaFieldsItemInt64 {
    type: SinksCreateRequestSchemaFieldsItemInt64Type;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type SinksCreateRequestSchemaFieldsItemFloat32Type = "float32";
export interface SinksCreateRequestSchemaFieldsItemFloat32 {
    type: SinksCreateRequestSchemaFieldsItemFloat32Type;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type SinksCreateRequestSchemaFieldsItemFloat64Type = "float64";
export interface SinksCreateRequestSchemaFieldsItemFloat64 {
    type: SinksCreateRequestSchemaFieldsItemFloat64Type;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type SinksCreateRequestSchemaFieldsItemBoolType = "bool";
export interface SinksCreateRequestSchemaFieldsItemBool {
    type: SinksCreateRequestSchemaFieldsItemBoolType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type SinksCreateRequestSchemaFieldsItemStringType = "string";
export interface SinksCreateRequestSchemaFieldsItemString {
    type: SinksCreateRequestSchemaFieldsItemStringType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type SinksCreateRequestSchemaFieldsItemBinaryType = "binary";
export interface SinksCreateRequestSchemaFieldsItemBinary {
    type: SinksCreateRequestSchemaFieldsItemBinaryType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type SinksCreateRequestSchemaFieldsItemTimestampType = "timestamp";
export type SinksCreateRequestSchemaFieldsItemTimestampUnit = "second" | "millisecond" | "microsecond" | "nanosecond";
export interface SinksCreateRequestSchemaFieldsItemTimestamp {
    type: SinksCreateRequestSchemaFieldsItemTimestampType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
    unit?: SinksCreateRequestSchemaFieldsItemTimestampUnit | (string & {});
}
export type SinksCreateRequestSchemaFieldsItemJsonType = "json";
export interface SinksCreateRequestSchemaFieldsItemJson {
    type: SinksCreateRequestSchemaFieldsItemJsonType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type SinksCreateRequestSchemaFieldsItemStructType = "struct";
export interface SinksCreateRequestSchemaFieldsItemStruct {
    type: SinksCreateRequestSchemaFieldsItemStructType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type SinksCreateRequestSchemaFieldsItemListType = "list";
export interface SinksCreateRequestSchemaFieldsItemList {
    type: SinksCreateRequestSchemaFieldsItemListType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type SinksCreateRequestSchemaFieldsItem = SinksCreateRequestSchemaFieldsItemInt32 | SinksCreateRequestSchemaFieldsItemInt64 | SinksCreateRequestSchemaFieldsItemFloat32 | SinksCreateRequestSchemaFieldsItemFloat64 | SinksCreateRequestSchemaFieldsItemBool | SinksCreateRequestSchemaFieldsItemString | SinksCreateRequestSchemaFieldsItemBinary | SinksCreateRequestSchemaFieldsItemTimestamp | SinksCreateRequestSchemaFieldsItemJson | SinksCreateRequestSchemaFieldsItemStruct | SinksCreateRequestSchemaFieldsItemList;
export type SinksCreateRequestSchemaFieldsList = Array<SinksCreateRequestSchemaFieldsItem>;
export interface SinksCreateRequestSchema {
    fields?: SinksCreateRequestSchemaFieldsList;
    inferred?: boolean;
}
export interface CreateSinkRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Defines the name of the Sink. */
    name: string;
    /** Specifies the type of sink. */
    type: SinksCreateRequestType | (string & {});
    /** Defines the configuration of the R2 Sink. */
    config?: SinksCreateRequestConfig;
    /** Defines the output data format of a sink. */
    format?: SinksCreateRequestFormat;
    /** Defines the schema of the events in the data stream. */
    schema?: SinksCreateRequestSchema;
}
export type SinksCreateResponseType = "r2" | "r2_data_catalog" | "basin_catalog";
export type SinksCreateResponseConfigCloudflarePipelinesR2TableCredentials = SinksCreateRequestConfigCloudflarePipelinesR2TableCredentials;
export type SinksCreateResponseConfigCloudflarePipelinesR2TableFileNamingStrategy = "serial" | "uuid" | "uuid_v7" | "ulid";
export interface SinksCreateResponseConfigCloudflarePipelinesR2TableFileNaming {
    /** The prefix to use in file name. i.e prefix-.parquet */
    prefix?: string | null;
    /** Filename generation strategy. */
    strategy?: SinksCreateResponseConfigCloudflarePipelinesR2TableFileNamingStrategy | null;
    /** This will overwrite the default file suffix. i.e .parquet, use with caution */
    suffix?: string | null;
}
export interface SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning {
    /** The pattern of the date string */
    timePattern?: string | null;
}
export interface SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy {
    /** Files will be rolled after reaching this number of bytes */
    fileSizeBytes?: number | null;
    /** Number of seconds of inactivity to wait before rolling over to a new file */
    inactivitySeconds?: number | null;
    /** Number of seconds to wait before rolling over to a new file */
    intervalSeconds?: number | null;
}
export interface SinksCreateResponseConfigCloudflarePipelinesR2Table {
    /** Cloudflare Account ID for the bucket */
    accountId: string;
    /** R2 Bucket to write to */
    bucket: string;
    credentials: SinksCreateRequestConfigCloudflarePipelinesR2TableCredentials;
    /** Controls filename prefix/suffix and strategy. */
    fileNaming?: SinksCreateResponseConfigCloudflarePipelinesR2TableFileNaming | null;
    /** Jurisdiction this bucket is hosted in */
    jurisdiction?: string | null;
    /** Data-layout partitioning for sinks. */
    partitioning?: SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning | null;
    /** Subpath within the bucket to write to */
    path?: string | null;
    /** Rolling policy for file sinks (when &amp; why to close a file and open a new one). */
    rollingPolicy?: SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy | null;
}
export type SinksCreateResponseConfigCloudflarePipelinesR2DataCatalogTableRollingPolicy = SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy;
export interface SinksCreateResponseConfigCloudflarePipelinesR2DataCatalogTable {
    /** Authentication token */
    token: string;
    /** Cloudflare Account ID */
    accountId: string;
    /** The R2 Bucket that hosts this catalog */
    bucket: string;
    /** Table name */
    tableName: string;
    /** Table namespace */
    namespace?: string | null;
    /** Rolling policy for file sinks (when &amp; why to close a file and open a new one). */
    rollingPolicy?: SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy | null;
}
export type SinksCreateResponseConfig = SinksCreateResponseConfigCloudflarePipelinesR2Table | SinksCreateResponseConfigCloudflarePipelinesR2DataCatalogTable;
export type SinksCreateResponseFormatJsonType = "json";
export type SinksCreateResponseFormatJsonCompression = "uncompressed" | "gzip";
export type SinksCreateResponseFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export type SinksCreateResponseFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export interface SinksCreateResponseFormatJson {
    type: SinksCreateResponseFormatJsonType;
    /** Specifies the compression applied to JSON sink output. */
    compression?: SinksCreateResponseFormatJsonCompression | null;
    decimalEncoding?: SinksCreateResponseFormatJsonDecimalEncoding | null;
    timestampFormat?: SinksCreateResponseFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export type SinksCreateResponseFormatParquetType = "parquet";
export type SinksCreateResponseFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export interface SinksCreateResponseFormatParquet {
    type: SinksCreateResponseFormatParquetType;
    compression?: SinksCreateResponseFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export type SinksCreateResponseFormat = SinksCreateResponseFormatJson | SinksCreateResponseFormatParquet;
export type SinksCreateResponseSchemaFieldsItemInt32Type = "int32";
export interface SinksCreateResponseSchemaFieldsItemInt32 {
    type: SinksCreateResponseSchemaFieldsItemInt32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksCreateResponseSchemaFieldsItemInt64Type = "int64";
export interface SinksCreateResponseSchemaFieldsItemInt64 {
    type: SinksCreateResponseSchemaFieldsItemInt64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksCreateResponseSchemaFieldsItemFloat32Type = "float32";
export interface SinksCreateResponseSchemaFieldsItemFloat32 {
    type: SinksCreateResponseSchemaFieldsItemFloat32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksCreateResponseSchemaFieldsItemFloat64Type = "float64";
export interface SinksCreateResponseSchemaFieldsItemFloat64 {
    type: SinksCreateResponseSchemaFieldsItemFloat64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksCreateResponseSchemaFieldsItemBoolType = "bool";
export interface SinksCreateResponseSchemaFieldsItemBool {
    type: SinksCreateResponseSchemaFieldsItemBoolType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksCreateResponseSchemaFieldsItemStringType = "string";
export interface SinksCreateResponseSchemaFieldsItemString {
    type: SinksCreateResponseSchemaFieldsItemStringType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksCreateResponseSchemaFieldsItemBinaryType = "binary";
export interface SinksCreateResponseSchemaFieldsItemBinary {
    type: SinksCreateResponseSchemaFieldsItemBinaryType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksCreateResponseSchemaFieldsItemTimestampType = "timestamp";
export type SinksCreateResponseSchemaFieldsItemTimestampUnit = "second" | "millisecond" | "microsecond" | "nanosecond";
export interface SinksCreateResponseSchemaFieldsItemTimestamp {
    type: SinksCreateResponseSchemaFieldsItemTimestampType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
    unit?: SinksCreateResponseSchemaFieldsItemTimestampUnit | null;
}
export type SinksCreateResponseSchemaFieldsItemJsonType = "json";
export interface SinksCreateResponseSchemaFieldsItemJson {
    type: SinksCreateResponseSchemaFieldsItemJsonType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksCreateResponseSchemaFieldsItemStructType = "struct";
export interface SinksCreateResponseSchemaFieldsItemStruct {
    type: SinksCreateResponseSchemaFieldsItemStructType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksCreateResponseSchemaFieldsItemListType = "list";
export interface SinksCreateResponseSchemaFieldsItemList {
    type: SinksCreateResponseSchemaFieldsItemListType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksCreateResponseSchemaFieldsItem = SinksCreateResponseSchemaFieldsItemInt32 | SinksCreateResponseSchemaFieldsItemInt64 | SinksCreateResponseSchemaFieldsItemFloat32 | SinksCreateResponseSchemaFieldsItemFloat64 | SinksCreateResponseSchemaFieldsItemBool | SinksCreateResponseSchemaFieldsItemString | SinksCreateResponseSchemaFieldsItemBinary | SinksCreateResponseSchemaFieldsItemTimestamp | SinksCreateResponseSchemaFieldsItemJson | SinksCreateResponseSchemaFieldsItemStruct | SinksCreateResponseSchemaFieldsItemList;
export type SinksCreateResponseSchemaFieldsList = Array<SinksCreateResponseSchemaFieldsItem>;
export interface SinksCreateResponseSchema {
    fields?: SinksCreateResponseSchemaFieldsList | null;
    inferred?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSinkResponse {
    /** Indicates a unique identifier for this sink. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    /** Defines the name of the Sink. */
    name: string;
    /** Specifies the type of sink. */
    type: SinksCreateResponseType;
    /** R2 Data Catalog Sink */
    config?: SinksCreateResponseConfig | null;
    /** Defines the output data format of a sink. */
    format?: SinksCreateResponseFormat | null;
    /** Defines the schema of the events in the data stream. */
    schema?: SinksCreateResponseSchema | null;
}
export type StreamsCreateRequestFormatJsonType = "json";
export type StreamsCreateRequestFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export type StreamsCreateRequestFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export interface StreamsCreateRequestFormatJson {
    type: StreamsCreateRequestFormatJsonType;
    decimalEncoding?: StreamsCreateRequestFormatJsonDecimalEncoding | (string & {});
    timestampFormat?: StreamsCreateRequestFormatJsonTimestampFormat | (string & {});
    unstructured?: boolean;
}
export type StreamsCreateRequestFormatParquetType = "parquet";
export type StreamsCreateRequestFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export interface StreamsCreateRequestFormatParquet {
    type: StreamsCreateRequestFormatParquetType;
    compression?: StreamsCreateRequestFormatParquetCompression | (string & {});
    rowGroupBytes?: number;
}
export type StreamsCreateRequestFormat = StreamsCreateRequestFormatJson | StreamsCreateRequestFormatParquet;
export type StreamsCreateRequestHttpCorsOriginsList = Array<string>;
export interface StreamsCreateRequestHttpCors {
    origins?: StreamsCreateRequestHttpCorsOriginsList;
}
export interface StreamsCreateRequestHttp {
    /** Indicates that authentication is required for the HTTP endpoint. */
    authentication: boolean;
    /** Indicates that the HTTP endpoint is enabled. */
    enabled: boolean;
    /** Specifies the CORS options for the HTTP endpoint. */
    cors?: StreamsCreateRequestHttpCors;
}
export type StreamsCreateRequestSchemaFieldsItemInt32Type = "int32";
export interface StreamsCreateRequestSchemaFieldsItemInt32 {
    type: StreamsCreateRequestSchemaFieldsItemInt32Type;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type StreamsCreateRequestSchemaFieldsItemInt64Type = "int64";
export interface StreamsCreateRequestSchemaFieldsItemInt64 {
    type: StreamsCreateRequestSchemaFieldsItemInt64Type;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type StreamsCreateRequestSchemaFieldsItemFloat32Type = "float32";
export interface StreamsCreateRequestSchemaFieldsItemFloat32 {
    type: StreamsCreateRequestSchemaFieldsItemFloat32Type;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type StreamsCreateRequestSchemaFieldsItemFloat64Type = "float64";
export interface StreamsCreateRequestSchemaFieldsItemFloat64 {
    type: StreamsCreateRequestSchemaFieldsItemFloat64Type;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type StreamsCreateRequestSchemaFieldsItemBoolType = "bool";
export interface StreamsCreateRequestSchemaFieldsItemBool {
    type: StreamsCreateRequestSchemaFieldsItemBoolType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type StreamsCreateRequestSchemaFieldsItemStringType = "string";
export interface StreamsCreateRequestSchemaFieldsItemString {
    type: StreamsCreateRequestSchemaFieldsItemStringType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type StreamsCreateRequestSchemaFieldsItemBinaryType = "binary";
export interface StreamsCreateRequestSchemaFieldsItemBinary {
    type: StreamsCreateRequestSchemaFieldsItemBinaryType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type StreamsCreateRequestSchemaFieldsItemTimestampType = "timestamp";
export type StreamsCreateRequestSchemaFieldsItemTimestampUnit = "second" | "millisecond" | "microsecond" | "nanosecond";
export interface StreamsCreateRequestSchemaFieldsItemTimestamp {
    type: StreamsCreateRequestSchemaFieldsItemTimestampType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
    unit?: StreamsCreateRequestSchemaFieldsItemTimestampUnit | (string & {});
}
export type StreamsCreateRequestSchemaFieldsItemJsonType = "json";
export interface StreamsCreateRequestSchemaFieldsItemJson {
    type: StreamsCreateRequestSchemaFieldsItemJsonType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type StreamsCreateRequestSchemaFieldsItemStructType = "struct";
export interface StreamsCreateRequestSchemaFieldsItemStruct {
    type: StreamsCreateRequestSchemaFieldsItemStructType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type StreamsCreateRequestSchemaFieldsItemListType = "list";
export interface StreamsCreateRequestSchemaFieldsItemList {
    type: StreamsCreateRequestSchemaFieldsItemListType;
    metadataKey?: string;
    name?: string;
    required?: boolean;
    sqlName?: string;
}
export type StreamsCreateRequestSchemaFieldsItem = StreamsCreateRequestSchemaFieldsItemInt32 | StreamsCreateRequestSchemaFieldsItemInt64 | StreamsCreateRequestSchemaFieldsItemFloat32 | StreamsCreateRequestSchemaFieldsItemFloat64 | StreamsCreateRequestSchemaFieldsItemBool | StreamsCreateRequestSchemaFieldsItemString | StreamsCreateRequestSchemaFieldsItemBinary | StreamsCreateRequestSchemaFieldsItemTimestamp | StreamsCreateRequestSchemaFieldsItemJson | StreamsCreateRequestSchemaFieldsItemStruct | StreamsCreateRequestSchemaFieldsItemList;
export type StreamsCreateRequestSchemaFieldsList = Array<StreamsCreateRequestSchemaFieldsItem>;
export interface StreamsCreateRequestSchema {
    fields?: StreamsCreateRequestSchemaFieldsList;
    inferred?: boolean;
}
export interface StreamsCreateRequestWorkerBinding {
    /** Indicates that the worker binding is enabled. */
    enabled: boolean;
}
export interface CreateStreamRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the name of the Stream. */
    name: string;
    /** Defines the data format of the events. */
    format?: StreamsCreateRequestFormat;
    http?: StreamsCreateRequestHttp;
    /** Defines the schema of the events in the data stream. */
    schema?: StreamsCreateRequestSchema;
    workerBinding?: StreamsCreateRequestWorkerBinding;
}
export type StreamsCreateResponseHttpCorsOriginsList = Array<string>;
export interface StreamsCreateResponseHttpCors {
    origins?: StreamsCreateResponseHttpCorsOriginsList | null;
}
export interface StreamsCreateResponseHttp {
    /** Indicates that authentication is required for the HTTP endpoint. */
    authentication: boolean;
    /** Indicates that the HTTP endpoint is enabled. */
    enabled: boolean;
    /** Specifies the CORS options for the HTTP endpoint. */
    cors?: StreamsCreateResponseHttpCors | null;
}
export type StreamsCreateResponseWorkerBinding = StreamsCreateRequestWorkerBinding;
export type StreamsCreateResponseFormatJsonType = "json";
export type StreamsCreateResponseFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export type StreamsCreateResponseFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export interface StreamsCreateResponseFormatJson {
    type: StreamsCreateResponseFormatJsonType;
    decimalEncoding?: StreamsCreateResponseFormatJsonDecimalEncoding | null;
    timestampFormat?: StreamsCreateResponseFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export type StreamsCreateResponseFormatParquetType = "parquet";
export type StreamsCreateResponseFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export interface StreamsCreateResponseFormatParquet {
    type: StreamsCreateResponseFormatParquetType;
    compression?: StreamsCreateResponseFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export type StreamsCreateResponseFormat = StreamsCreateResponseFormatJson | StreamsCreateResponseFormatParquet;
export type StreamsCreateResponseSchemaFieldsItemInt32Type = "int32";
export interface StreamsCreateResponseSchemaFieldsItemInt32 {
    type: StreamsCreateResponseSchemaFieldsItemInt32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsCreateResponseSchemaFieldsItemInt64Type = "int64";
export interface StreamsCreateResponseSchemaFieldsItemInt64 {
    type: StreamsCreateResponseSchemaFieldsItemInt64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsCreateResponseSchemaFieldsItemFloat32Type = "float32";
export interface StreamsCreateResponseSchemaFieldsItemFloat32 {
    type: StreamsCreateResponseSchemaFieldsItemFloat32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsCreateResponseSchemaFieldsItemFloat64Type = "float64";
export interface StreamsCreateResponseSchemaFieldsItemFloat64 {
    type: StreamsCreateResponseSchemaFieldsItemFloat64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsCreateResponseSchemaFieldsItemBoolType = "bool";
export interface StreamsCreateResponseSchemaFieldsItemBool {
    type: StreamsCreateResponseSchemaFieldsItemBoolType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsCreateResponseSchemaFieldsItemStringType = "string";
export interface StreamsCreateResponseSchemaFieldsItemString {
    type: StreamsCreateResponseSchemaFieldsItemStringType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsCreateResponseSchemaFieldsItemBinaryType = "binary";
export interface StreamsCreateResponseSchemaFieldsItemBinary {
    type: StreamsCreateResponseSchemaFieldsItemBinaryType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsCreateResponseSchemaFieldsItemTimestampType = "timestamp";
export type StreamsCreateResponseSchemaFieldsItemTimestampUnit = "second" | "millisecond" | "microsecond" | "nanosecond";
export interface StreamsCreateResponseSchemaFieldsItemTimestamp {
    type: StreamsCreateResponseSchemaFieldsItemTimestampType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
    unit?: StreamsCreateResponseSchemaFieldsItemTimestampUnit | null;
}
export type StreamsCreateResponseSchemaFieldsItemJsonType = "json";
export interface StreamsCreateResponseSchemaFieldsItemJson {
    type: StreamsCreateResponseSchemaFieldsItemJsonType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsCreateResponseSchemaFieldsItemStructType = "struct";
export interface StreamsCreateResponseSchemaFieldsItemStruct {
    type: StreamsCreateResponseSchemaFieldsItemStructType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsCreateResponseSchemaFieldsItemListType = "list";
export interface StreamsCreateResponseSchemaFieldsItemList {
    type: StreamsCreateResponseSchemaFieldsItemListType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsCreateResponseSchemaFieldsItem = StreamsCreateResponseSchemaFieldsItemInt32 | StreamsCreateResponseSchemaFieldsItemInt64 | StreamsCreateResponseSchemaFieldsItemFloat32 | StreamsCreateResponseSchemaFieldsItemFloat64 | StreamsCreateResponseSchemaFieldsItemBool | StreamsCreateResponseSchemaFieldsItemString | StreamsCreateResponseSchemaFieldsItemBinary | StreamsCreateResponseSchemaFieldsItemTimestamp | StreamsCreateResponseSchemaFieldsItemJson | StreamsCreateResponseSchemaFieldsItemStruct | StreamsCreateResponseSchemaFieldsItemList;
export type StreamsCreateResponseSchemaFieldsList = Array<StreamsCreateResponseSchemaFieldsItem>;
export interface StreamsCreateResponseSchema {
    fields?: StreamsCreateResponseSchemaFieldsList | null;
    inferred?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateStreamResponse {
    /** Indicates a unique identifier for this stream. */
    id: string;
    createdAt: string;
    http: StreamsCreateResponseHttp;
    modifiedAt: string;
    /** Indicates the name of the Stream. */
    name: string;
    /** Indicates the current version of this stream. */
    version: number;
    workerBinding: StreamsCreateRequestWorkerBinding;
    /** Indicates the endpoint URL of this stream. */
    endpoint?: string | null;
    /** Defines the data format of the events. */
    format?: StreamsCreateResponseFormat | null;
    /** Defines the schema of the events in the data stream. */
    schema?: StreamsCreateResponseSchema | null;
}
export interface CreateV1PipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the name of the Pipeline. */
    name: string;
    /** Specifies SQL for the Pipeline processing flow. */
    sql: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateV1PipelineResponse {
    /** Indicates a unique identifier for this pipeline. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    /** Indicates the name of the Pipeline. */
    name: string;
    /** Specifies SQL for the Pipeline processing flow. */
    sql: string;
    /** Indicates the current status of the Pipeline. */
    status: string;
}
export interface DeletePipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Defines the name of the pipeline. */
    pipelineName: string;
}
export interface DeletePipelineResponse {
}
export interface DeleteSinkRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the publid ID of the sink. */
    sinkId: string;
}
export type DeleteSinkResponse = unknown;
export interface DeleteStreamRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the public ID of the stream. */
    streamId: string;
}
export type DeleteStreamResponse = unknown;
export interface DeleteV1PipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the public ID of the pipeline. */
    pipelineId: string;
}
export type DeleteV1PipelineResponse = unknown;
export interface GetPipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Defines the name of the pipeline. */
    pipelineName: string;
}
export type GetResponseDestinationBatch = CreateResponseDestinationBatch;
export type GetResponseDestinationCompressionType = "none" | "gzip" | "deflate";
export interface GetResponseDestinationCompression {
    /** Specifies the desired compression algorithm and format. */
    type: GetResponseDestinationCompressionType;
}
export type GetResponseDestinationFormat = "json";
export type GetResponseDestinationPath = CreateResponseDestinationPath;
export type GetResponseDestinationType = "r2";
export interface GetResponseDestination {
    batch: CreateResponseDestinationBatch;
    compression: GetResponseDestinationCompression;
    /** Specifies the format of data to deliver. */
    format: GetResponseDestinationFormat;
    path: CreateResponseDestinationPath;
    /** Specifies the type of destination. */
    type: GetResponseDestinationType;
}
export type GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat = "json";
export type GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList = Array<string>;
export interface GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors {
    /** Specifies allowed origins to allow Cross Origin HTTP Requests. */
    origins?: GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList | null;
}
export interface GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource {
    /** Specifies the format of source data. */
    format: GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat;
    type: string;
    /** Specifies whether authentication is required to send to this pipeline via HTTP. */
    authentication?: boolean | null;
    cors?: GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors | null;
}
export type GetResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat = "json";
export interface GetResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource {
    /** Specifies the format of source data. */
    format: GetResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat;
    type: string;
}
export type GetResponseSourceItem = GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource | GetResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource;
export type GetResponseSourceList = Array<GetResponseSourceItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPipelineResponse {
    /** Specifies the pipeline identifier. */
    id: string;
    destination: GetResponseDestination;
    /** Indicates the endpoint URL to send traffic. */
    endpoint: string;
    /** Defines the name of the pipeline. */
    name: string;
    source: GetResponseSourceList;
    /** Indicates the version number of last saved configuration. */
    version: number;
}
export interface GetSinkRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the publid ID of the sink. */
    sinkId: string;
}
export type SinksGetResponseType = "r2" | "r2_data_catalog" | "basin_catalog";
export type SinksGetResponseConfigCloudflarePipelinesR2TablePublicFileNamingStrategy = "serial" | "uuid" | "uuid_v7" | "ulid";
export interface SinksGetResponseConfigCloudflarePipelinesR2TablePublicFileNaming {
    /** The prefix to use in file name. i.e prefix-.parquet */
    prefix?: string | null;
    /** Filename generation strategy. */
    strategy?: SinksGetResponseConfigCloudflarePipelinesR2TablePublicFileNamingStrategy | null;
    /** This will overwrite the default file suffix. i.e .parquet, use with caution */
    suffix?: string | null;
}
export type SinksGetResponseConfigCloudflarePipelinesR2TablePublicPartitioning = SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning;
export type SinksGetResponseConfigCloudflarePipelinesR2TablePublicRollingPolicy = SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy;
export interface SinksGetResponseConfigCloudflarePipelinesR2TablePublic {
    /** Cloudflare Account ID for the bucket */
    accountId: string;
    /** R2 Bucket to write to */
    bucket: string;
    /** Controls filename prefix/suffix and strategy. */
    fileNaming?: SinksGetResponseConfigCloudflarePipelinesR2TablePublicFileNaming | null;
    /** Jurisdiction this bucket is hosted in */
    jurisdiction?: string | null;
    /** Data-layout partitioning for sinks. */
    partitioning?: SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning | null;
    /** Subpath within the bucket to write to */
    path?: string | null;
    /** Rolling policy for file sinks (when &amp; why to close a file and open a new one). */
    rollingPolicy?: SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy | null;
}
export type SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublicRollingPolicy = SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy;
export interface SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublic {
    /** Cloudflare Account ID */
    accountId: string;
    /** The R2 Bucket that hosts this catalog */
    bucket: string;
    /** Table name */
    tableName: string;
    /** Table namespace */
    namespace?: string | null;
    /** Rolling policy for file sinks (when &amp; why to close a file and open a new one). */
    rollingPolicy?: SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy | null;
}
export type SinksGetResponseConfig = SinksGetResponseConfigCloudflarePipelinesR2TablePublic | SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublic;
export type SinksGetResponseFormatJsonType = "json";
export type SinksGetResponseFormatJsonCompression = "uncompressed" | "gzip";
export type SinksGetResponseFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export type SinksGetResponseFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export interface SinksGetResponseFormatJson {
    type: SinksGetResponseFormatJsonType;
    /** Specifies the compression applied to JSON sink output. */
    compression?: SinksGetResponseFormatJsonCompression | null;
    decimalEncoding?: SinksGetResponseFormatJsonDecimalEncoding | null;
    timestampFormat?: SinksGetResponseFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export type SinksGetResponseFormatParquetType = "parquet";
export type SinksGetResponseFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export interface SinksGetResponseFormatParquet {
    type: SinksGetResponseFormatParquetType;
    compression?: SinksGetResponseFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export type SinksGetResponseFormat = SinksGetResponseFormatJson | SinksGetResponseFormatParquet;
export type SinksGetResponseSchemaFieldsItemInt32Type = "int32";
export interface SinksGetResponseSchemaFieldsItemInt32 {
    type: SinksGetResponseSchemaFieldsItemInt32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksGetResponseSchemaFieldsItemInt64Type = "int64";
export interface SinksGetResponseSchemaFieldsItemInt64 {
    type: SinksGetResponseSchemaFieldsItemInt64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksGetResponseSchemaFieldsItemFloat32Type = "float32";
export interface SinksGetResponseSchemaFieldsItemFloat32 {
    type: SinksGetResponseSchemaFieldsItemFloat32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksGetResponseSchemaFieldsItemFloat64Type = "float64";
export interface SinksGetResponseSchemaFieldsItemFloat64 {
    type: SinksGetResponseSchemaFieldsItemFloat64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksGetResponseSchemaFieldsItemBoolType = "bool";
export interface SinksGetResponseSchemaFieldsItemBool {
    type: SinksGetResponseSchemaFieldsItemBoolType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksGetResponseSchemaFieldsItemStringType = "string";
export interface SinksGetResponseSchemaFieldsItemString {
    type: SinksGetResponseSchemaFieldsItemStringType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksGetResponseSchemaFieldsItemBinaryType = "binary";
export interface SinksGetResponseSchemaFieldsItemBinary {
    type: SinksGetResponseSchemaFieldsItemBinaryType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksGetResponseSchemaFieldsItemTimestampType = "timestamp";
export type SinksGetResponseSchemaFieldsItemTimestampUnit = "second" | "millisecond" | "microsecond" | "nanosecond";
export interface SinksGetResponseSchemaFieldsItemTimestamp {
    type: SinksGetResponseSchemaFieldsItemTimestampType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
    unit?: SinksGetResponseSchemaFieldsItemTimestampUnit | null;
}
export type SinksGetResponseSchemaFieldsItemJsonType = "json";
export interface SinksGetResponseSchemaFieldsItemJson {
    type: SinksGetResponseSchemaFieldsItemJsonType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksGetResponseSchemaFieldsItemStructType = "struct";
export interface SinksGetResponseSchemaFieldsItemStruct {
    type: SinksGetResponseSchemaFieldsItemStructType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksGetResponseSchemaFieldsItemListType = "list";
export interface SinksGetResponseSchemaFieldsItemList {
    type: SinksGetResponseSchemaFieldsItemListType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksGetResponseSchemaFieldsItem = SinksGetResponseSchemaFieldsItemInt32 | SinksGetResponseSchemaFieldsItemInt64 | SinksGetResponseSchemaFieldsItemFloat32 | SinksGetResponseSchemaFieldsItemFloat64 | SinksGetResponseSchemaFieldsItemBool | SinksGetResponseSchemaFieldsItemString | SinksGetResponseSchemaFieldsItemBinary | SinksGetResponseSchemaFieldsItemTimestamp | SinksGetResponseSchemaFieldsItemJson | SinksGetResponseSchemaFieldsItemStruct | SinksGetResponseSchemaFieldsItemList;
export type SinksGetResponseSchemaFieldsList = Array<SinksGetResponseSchemaFieldsItem>;
export interface SinksGetResponseSchema {
    fields?: SinksGetResponseSchemaFieldsList | null;
    inferred?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSinkResponse {
    /** Indicates a unique identifier for this sink. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    /** Defines the name of the Sink. */
    name: string;
    /** Specifies the type of sink. */
    type: SinksGetResponseType;
    /** Defines the configuration of the R2 Sink. */
    config?: SinksGetResponseConfig | null;
    /** Defines the output data format of a sink. */
    format?: SinksGetResponseFormat | null;
    /** Defines the schema of the events in the data stream. */
    schema?: SinksGetResponseSchema | null;
}
export interface GetStreamRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the public ID of the stream. */
    streamId: string;
}
export type StreamsGetResponseHttpCorsOriginsList = Array<string>;
export interface StreamsGetResponseHttpCors {
    origins?: StreamsGetResponseHttpCorsOriginsList | null;
}
export interface StreamsGetResponseHttp {
    /** Indicates that authentication is required for the HTTP endpoint. */
    authentication: boolean;
    /** Indicates that the HTTP endpoint is enabled. */
    enabled: boolean;
    /** Specifies the CORS options for the HTTP endpoint. */
    cors?: StreamsGetResponseHttpCors | null;
}
export type StreamsGetResponseWorkerBinding = StreamsCreateRequestWorkerBinding;
export type StreamsGetResponseFormatJsonType = "json";
export type StreamsGetResponseFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export type StreamsGetResponseFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export interface StreamsGetResponseFormatJson {
    type: StreamsGetResponseFormatJsonType;
    decimalEncoding?: StreamsGetResponseFormatJsonDecimalEncoding | null;
    timestampFormat?: StreamsGetResponseFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export type StreamsGetResponseFormatParquetType = "parquet";
export type StreamsGetResponseFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export interface StreamsGetResponseFormatParquet {
    type: StreamsGetResponseFormatParquetType;
    compression?: StreamsGetResponseFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export type StreamsGetResponseFormat = StreamsGetResponseFormatJson | StreamsGetResponseFormatParquet;
export type StreamsGetResponseSchemaFieldsItemInt32Type = "int32";
export interface StreamsGetResponseSchemaFieldsItemInt32 {
    type: StreamsGetResponseSchemaFieldsItemInt32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsGetResponseSchemaFieldsItemInt64Type = "int64";
export interface StreamsGetResponseSchemaFieldsItemInt64 {
    type: StreamsGetResponseSchemaFieldsItemInt64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsGetResponseSchemaFieldsItemFloat32Type = "float32";
export interface StreamsGetResponseSchemaFieldsItemFloat32 {
    type: StreamsGetResponseSchemaFieldsItemFloat32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsGetResponseSchemaFieldsItemFloat64Type = "float64";
export interface StreamsGetResponseSchemaFieldsItemFloat64 {
    type: StreamsGetResponseSchemaFieldsItemFloat64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsGetResponseSchemaFieldsItemBoolType = "bool";
export interface StreamsGetResponseSchemaFieldsItemBool {
    type: StreamsGetResponseSchemaFieldsItemBoolType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsGetResponseSchemaFieldsItemStringType = "string";
export interface StreamsGetResponseSchemaFieldsItemString {
    type: StreamsGetResponseSchemaFieldsItemStringType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsGetResponseSchemaFieldsItemBinaryType = "binary";
export interface StreamsGetResponseSchemaFieldsItemBinary {
    type: StreamsGetResponseSchemaFieldsItemBinaryType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsGetResponseSchemaFieldsItemTimestampType = "timestamp";
export type StreamsGetResponseSchemaFieldsItemTimestampUnit = "second" | "millisecond" | "microsecond" | "nanosecond";
export interface StreamsGetResponseSchemaFieldsItemTimestamp {
    type: StreamsGetResponseSchemaFieldsItemTimestampType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
    unit?: StreamsGetResponseSchemaFieldsItemTimestampUnit | null;
}
export type StreamsGetResponseSchemaFieldsItemJsonType = "json";
export interface StreamsGetResponseSchemaFieldsItemJson {
    type: StreamsGetResponseSchemaFieldsItemJsonType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsGetResponseSchemaFieldsItemStructType = "struct";
export interface StreamsGetResponseSchemaFieldsItemStruct {
    type: StreamsGetResponseSchemaFieldsItemStructType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsGetResponseSchemaFieldsItemListType = "list";
export interface StreamsGetResponseSchemaFieldsItemList {
    type: StreamsGetResponseSchemaFieldsItemListType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsGetResponseSchemaFieldsItem = StreamsGetResponseSchemaFieldsItemInt32 | StreamsGetResponseSchemaFieldsItemInt64 | StreamsGetResponseSchemaFieldsItemFloat32 | StreamsGetResponseSchemaFieldsItemFloat64 | StreamsGetResponseSchemaFieldsItemBool | StreamsGetResponseSchemaFieldsItemString | StreamsGetResponseSchemaFieldsItemBinary | StreamsGetResponseSchemaFieldsItemTimestamp | StreamsGetResponseSchemaFieldsItemJson | StreamsGetResponseSchemaFieldsItemStruct | StreamsGetResponseSchemaFieldsItemList;
export type StreamsGetResponseSchemaFieldsList = Array<StreamsGetResponseSchemaFieldsItem>;
export interface StreamsGetResponseSchema {
    fields?: StreamsGetResponseSchemaFieldsList | null;
    inferred?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetStreamResponse {
    /** Indicates a unique identifier for this stream. */
    id: string;
    createdAt: string;
    http: StreamsGetResponseHttp;
    modifiedAt: string;
    /** Indicates the name of the Stream. */
    name: string;
    /** Indicates the current version of this stream. */
    version: number;
    workerBinding: StreamsCreateRequestWorkerBinding;
    /** Indicates the endpoint URL of this stream. */
    endpoint?: string | null;
    /** Defines the data format of the events. */
    format?: StreamsGetResponseFormat | null;
    /** Defines the schema of the events in the data stream. */
    schema?: StreamsGetResponseSchema | null;
}
export interface GetV1PipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the public ID of the pipeline. */
    pipelineId: string;
}
export type GetV1ResponseTablesItemType = "stream" | "sink";
export interface GetV1ResponseTablesItem {
    /** Unique identifier for the connection (stream or sink). */
    id: string;
    /** Latest available version of the connection. */
    latest: number;
    /** Name of the connection. */
    name: string;
    /** Type of the connection. */
    type: GetV1ResponseTablesItemType;
    /** Current version of the connection used by this pipeline. */
    version: number;
}
export type GetV1ResponseTablesList = Array<GetV1ResponseTablesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetV1PipelineResponse {
    /** Indicates a unique identifier for this pipeline. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    /** Indicates the name of the Pipeline. */
    name: string;
    /** Specifies SQL for the Pipeline processing flow. */
    sql: string;
    /** Indicates the current status of the Pipeline. */
    status: string;
    /** List of streams and sinks used by this pipeline. */
    tables: GetV1ResponseTablesList;
    /** Indicates the reason for the failure of the Pipeline. */
    failureReason?: string | null;
}
export interface ListPipelinesRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies which page to retrieve. */
    page?: string;
    /** Specifies the number of pipelines per page. */
    perPage?: string;
    /** Specifies the prefix of pipeline name to search. */
    search?: string;
}
export type ListResponseResultsItemDestinationBatch = CreateResponseDestinationBatch;
export type ListResponseResultsItemDestinationCompressionType = "none" | "gzip" | "deflate";
export interface ListResponseResultsItemDestinationCompression {
    /** Specifies the desired compression algorithm and format. */
    type: ListResponseResultsItemDestinationCompressionType;
}
export type ListResponseResultsItemDestinationFormat = "json";
export type ListResponseResultsItemDestinationPath = CreateResponseDestinationPath;
export type ListResponseResultsItemDestinationType = "r2";
export interface ListResponseResultsItemDestination {
    batch: CreateResponseDestinationBatch;
    compression: ListResponseResultsItemDestinationCompression;
    /** Specifies the format of data to deliver. */
    format: ListResponseResultsItemDestinationFormat;
    path: CreateResponseDestinationPath;
    /** Specifies the type of destination. */
    type: ListResponseResultsItemDestinationType;
}
export type ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat = "json";
export type ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList = Array<string>;
export interface ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors {
    /** Specifies allowed origins to allow Cross Origin HTTP Requests. */
    origins?: ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList | null;
}
export interface ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource {
    /** Specifies the format of source data. */
    format: ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat;
    type: string;
    /** Specifies whether authentication is required to send to this pipeline via HTTP. */
    authentication?: boolean | null;
    cors?: ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors | null;
}
export type ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat = "json";
export interface ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesBindingSource {
    /** Specifies the format of source data. */
    format: ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat;
    type: string;
}
export type ListResponseResultsItemSourceItem = ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource | ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesBindingSource;
export type ListResponseResultsItemSourceList = Array<ListResponseResultsItemSourceItem>;
export interface ListResponseResultsItem {
    /** Specifies the pipeline identifier. */
    id: string;
    destination: ListResponseResultsItemDestination;
    /** Indicates the endpoint URL to send traffic. */
    endpoint: string;
    /** Defines the name of the pipeline. */
    name: string;
    source: ListResponseResultsItemSourceList;
    /** Indicates the version number of last saved configuration. */
    version: number;
}
export type ListResponseResultsList = Array<ListResponseResultsItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListPipelinesResponse {
    results: ListResponseResultsList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type SinksListRequestDirection = "asc" | "desc";
export type SinksListRequestOrderBy = "name" | "created_at";
export interface ListSinksRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Sort direction. */
    direction?: SinksListRequestDirection | (string & {});
    /** Filters sinks by name (case-insensitive substring). */
    name?: string;
    /** Sorts sinks by this field. Defaults to `created_at`. */
    orderBy?: SinksListRequestOrderBy | (string & {});
    page?: number;
    perPage?: number;
    pipelineId?: string;
}
export type SinksListResultItemType = "r2" | "r2_data_catalog" | "basin_catalog";
export type SinksListResultItemConfigCloudflarePipelinesR2TablePublicFileNamingStrategy = "serial" | "uuid" | "uuid_v7" | "ulid";
export interface SinksListResultItemConfigCloudflarePipelinesR2TablePublicFileNaming {
    /** The prefix to use in file name. i.e prefix-.parquet */
    prefix?: string | null;
    /** Filename generation strategy. */
    strategy?: SinksListResultItemConfigCloudflarePipelinesR2TablePublicFileNamingStrategy | null;
    /** This will overwrite the default file suffix. i.e .parquet, use with caution */
    suffix?: string | null;
}
export type SinksListResultItemConfigCloudflarePipelinesR2TablePublicPartitioning = SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning;
export type SinksListResultItemConfigCloudflarePipelinesR2TablePublicRollingPolicy = SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy;
export interface SinksListResultItemConfigCloudflarePipelinesR2TablePublic {
    /** Cloudflare Account ID for the bucket */
    accountId: string;
    /** R2 Bucket to write to */
    bucket: string;
    /** Controls filename prefix/suffix and strategy. */
    fileNaming?: SinksListResultItemConfigCloudflarePipelinesR2TablePublicFileNaming | null;
    /** Jurisdiction this bucket is hosted in */
    jurisdiction?: string | null;
    /** Data-layout partitioning for sinks. */
    partitioning?: SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning | null;
    /** Subpath within the bucket to write to */
    path?: string | null;
    /** Rolling policy for file sinks (when &amp; why to close a file and open a new one). */
    rollingPolicy?: SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy | null;
}
export type SinksListResultItemConfigCloudflarePipelinesR2DataCatalogTablePublicRollingPolicy = SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy;
export type SinksListResultItemConfigCloudflarePipelinesR2DataCatalogTablePublic = SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublic;
export type SinksListResultItemConfig = SinksListResultItemConfigCloudflarePipelinesR2TablePublic | SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublic;
export type SinksListResultItemFormatJsonType = "json";
export type SinksListResultItemFormatJsonCompression = "uncompressed" | "gzip";
export type SinksListResultItemFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export type SinksListResultItemFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export interface SinksListResultItemFormatJson {
    type: SinksListResultItemFormatJsonType;
    /** Specifies the compression applied to JSON sink output. */
    compression?: SinksListResultItemFormatJsonCompression | null;
    decimalEncoding?: SinksListResultItemFormatJsonDecimalEncoding | null;
    timestampFormat?: SinksListResultItemFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export type SinksListResultItemFormatParquetType = "parquet";
export type SinksListResultItemFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export interface SinksListResultItemFormatParquet {
    type: SinksListResultItemFormatParquetType;
    compression?: SinksListResultItemFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export type SinksListResultItemFormat = SinksListResultItemFormatJson | SinksListResultItemFormatParquet;
export type SinksListResultItemSchemaFieldsItemInt32Type = "int32";
export interface SinksListResultItemSchemaFieldsItemInt32 {
    type: SinksListResultItemSchemaFieldsItemInt32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksListResultItemSchemaFieldsItemInt64Type = "int64";
export interface SinksListResultItemSchemaFieldsItemInt64 {
    type: SinksListResultItemSchemaFieldsItemInt64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksListResultItemSchemaFieldsItemFloat32Type = "float32";
export interface SinksListResultItemSchemaFieldsItemFloat32 {
    type: SinksListResultItemSchemaFieldsItemFloat32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksListResultItemSchemaFieldsItemFloat64Type = "float64";
export interface SinksListResultItemSchemaFieldsItemFloat64 {
    type: SinksListResultItemSchemaFieldsItemFloat64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksListResultItemSchemaFieldsItemBoolType = "bool";
export interface SinksListResultItemSchemaFieldsItemBool {
    type: SinksListResultItemSchemaFieldsItemBoolType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksListResultItemSchemaFieldsItemStringType = "string";
export interface SinksListResultItemSchemaFieldsItemString {
    type: SinksListResultItemSchemaFieldsItemStringType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksListResultItemSchemaFieldsItemBinaryType = "binary";
export interface SinksListResultItemSchemaFieldsItemBinary {
    type: SinksListResultItemSchemaFieldsItemBinaryType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksListResultItemSchemaFieldsItemTimestampType = "timestamp";
export type SinksListResultItemSchemaFieldsItemTimestampUnit = "second" | "millisecond" | "microsecond" | "nanosecond";
export interface SinksListResultItemSchemaFieldsItemTimestamp {
    type: SinksListResultItemSchemaFieldsItemTimestampType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
    unit?: SinksListResultItemSchemaFieldsItemTimestampUnit | null;
}
export type SinksListResultItemSchemaFieldsItemJsonType = "json";
export interface SinksListResultItemSchemaFieldsItemJson {
    type: SinksListResultItemSchemaFieldsItemJsonType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksListResultItemSchemaFieldsItemStructType = "struct";
export interface SinksListResultItemSchemaFieldsItemStruct {
    type: SinksListResultItemSchemaFieldsItemStructType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksListResultItemSchemaFieldsItemListType = "list";
export interface SinksListResultItemSchemaFieldsItemList {
    type: SinksListResultItemSchemaFieldsItemListType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type SinksListResultItemSchemaFieldsItem = SinksListResultItemSchemaFieldsItemInt32 | SinksListResultItemSchemaFieldsItemInt64 | SinksListResultItemSchemaFieldsItemFloat32 | SinksListResultItemSchemaFieldsItemFloat64 | SinksListResultItemSchemaFieldsItemBool | SinksListResultItemSchemaFieldsItemString | SinksListResultItemSchemaFieldsItemBinary | SinksListResultItemSchemaFieldsItemTimestamp | SinksListResultItemSchemaFieldsItemJson | SinksListResultItemSchemaFieldsItemStruct | SinksListResultItemSchemaFieldsItemList;
export type SinksListResultItemSchemaFieldsList = Array<SinksListResultItemSchemaFieldsItem>;
export interface SinksListResultItemSchema {
    fields?: SinksListResultItemSchemaFieldsList | null;
    inferred?: boolean | null;
}
export interface SinksListResultItem {
    /** Indicates a unique identifier for this sink. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    /** Defines the name of the Sink. */
    name: string;
    /** Specifies the type of sink. */
    type: SinksListResultItemType;
    /** Defines the configuration of the R2 Sink. */
    config?: SinksListResultItemConfig | null;
    /** Defines the output data format of a sink. */
    format?: SinksListResultItemFormat | null;
    /** Defines the schema of the events in the data stream. */
    schema?: SinksListResultItemSchema | null;
}
export type SinksListResultList = Array<SinksListResultItem>;
export interface ListSinksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SinksListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type StreamsListRequestDirection = "asc" | "desc";
export type StreamsListRequestOrderBy = "name" | "created_at";
export interface ListStreamsRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Sort direction. */
    direction?: StreamsListRequestDirection | (string & {});
    /** Filters streams by name (case-insensitive substring). */
    name?: string;
    /** Sorts streams by this field. Defaults to `created_at`. */
    orderBy?: StreamsListRequestOrderBy | (string & {});
    page?: number;
    perPage?: number;
    /** Specifies the public ID of the pipeline. */
    pipelineId?: string;
}
export type StreamsListResultItemHttpCorsOriginsList = Array<string>;
export interface StreamsListResultItemHttpCors {
    origins?: StreamsListResultItemHttpCorsOriginsList | null;
}
export interface StreamsListResultItemHttp {
    /** Indicates that authentication is required for the HTTP endpoint. */
    authentication: boolean;
    /** Indicates that the HTTP endpoint is enabled. */
    enabled: boolean;
    /** Specifies the CORS options for the HTTP endpoint. */
    cors?: StreamsListResultItemHttpCors | null;
}
export type StreamsListResultItemWorkerBinding = StreamsCreateRequestWorkerBinding;
export type StreamsListResultItemFormatJsonType = "json";
export type StreamsListResultItemFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export type StreamsListResultItemFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export interface StreamsListResultItemFormatJson {
    type: StreamsListResultItemFormatJsonType;
    decimalEncoding?: StreamsListResultItemFormatJsonDecimalEncoding | null;
    timestampFormat?: StreamsListResultItemFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export type StreamsListResultItemFormatParquetType = "parquet";
export type StreamsListResultItemFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export interface StreamsListResultItemFormatParquet {
    type: StreamsListResultItemFormatParquetType;
    compression?: StreamsListResultItemFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export type StreamsListResultItemFormat = StreamsListResultItemFormatJson | StreamsListResultItemFormatParquet;
export type StreamsListResultItemSchemaFieldsItemInt32Type = "int32";
export interface StreamsListResultItemSchemaFieldsItemInt32 {
    type: StreamsListResultItemSchemaFieldsItemInt32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsListResultItemSchemaFieldsItemInt64Type = "int64";
export interface StreamsListResultItemSchemaFieldsItemInt64 {
    type: StreamsListResultItemSchemaFieldsItemInt64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsListResultItemSchemaFieldsItemFloat32Type = "float32";
export interface StreamsListResultItemSchemaFieldsItemFloat32 {
    type: StreamsListResultItemSchemaFieldsItemFloat32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsListResultItemSchemaFieldsItemFloat64Type = "float64";
export interface StreamsListResultItemSchemaFieldsItemFloat64 {
    type: StreamsListResultItemSchemaFieldsItemFloat64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsListResultItemSchemaFieldsItemBoolType = "bool";
export interface StreamsListResultItemSchemaFieldsItemBool {
    type: StreamsListResultItemSchemaFieldsItemBoolType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsListResultItemSchemaFieldsItemStringType = "string";
export interface StreamsListResultItemSchemaFieldsItemString {
    type: StreamsListResultItemSchemaFieldsItemStringType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsListResultItemSchemaFieldsItemBinaryType = "binary";
export interface StreamsListResultItemSchemaFieldsItemBinary {
    type: StreamsListResultItemSchemaFieldsItemBinaryType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsListResultItemSchemaFieldsItemTimestampType = "timestamp";
export type StreamsListResultItemSchemaFieldsItemTimestampUnit = "second" | "millisecond" | "microsecond" | "nanosecond";
export interface StreamsListResultItemSchemaFieldsItemTimestamp {
    type: StreamsListResultItemSchemaFieldsItemTimestampType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
    unit?: StreamsListResultItemSchemaFieldsItemTimestampUnit | null;
}
export type StreamsListResultItemSchemaFieldsItemJsonType = "json";
export interface StreamsListResultItemSchemaFieldsItemJson {
    type: StreamsListResultItemSchemaFieldsItemJsonType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsListResultItemSchemaFieldsItemStructType = "struct";
export interface StreamsListResultItemSchemaFieldsItemStruct {
    type: StreamsListResultItemSchemaFieldsItemStructType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsListResultItemSchemaFieldsItemListType = "list";
export interface StreamsListResultItemSchemaFieldsItemList {
    type: StreamsListResultItemSchemaFieldsItemListType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsListResultItemSchemaFieldsItem = StreamsListResultItemSchemaFieldsItemInt32 | StreamsListResultItemSchemaFieldsItemInt64 | StreamsListResultItemSchemaFieldsItemFloat32 | StreamsListResultItemSchemaFieldsItemFloat64 | StreamsListResultItemSchemaFieldsItemBool | StreamsListResultItemSchemaFieldsItemString | StreamsListResultItemSchemaFieldsItemBinary | StreamsListResultItemSchemaFieldsItemTimestamp | StreamsListResultItemSchemaFieldsItemJson | StreamsListResultItemSchemaFieldsItemStruct | StreamsListResultItemSchemaFieldsItemList;
export type StreamsListResultItemSchemaFieldsList = Array<StreamsListResultItemSchemaFieldsItem>;
export interface StreamsListResultItemSchema {
    fields?: StreamsListResultItemSchemaFieldsList | null;
    inferred?: boolean | null;
}
export interface StreamsListResultItem {
    /** Indicates a unique identifier for this stream. */
    id: string;
    createdAt: string;
    http: StreamsListResultItemHttp;
    modifiedAt: string;
    /** Indicates the name of the Stream. */
    name: string;
    /** Indicates the current version of this stream. */
    version: number;
    workerBinding: StreamsCreateRequestWorkerBinding;
    /** Indicates the endpoint URL of this stream. */
    endpoint?: string | null;
    /** Defines the data format of the events. */
    format?: StreamsListResultItemFormat | null;
    /** Defines the schema of the events in the data stream. */
    schema?: StreamsListResultItemSchema | null;
}
export type StreamsListResultList = Array<StreamsListResultItem>;
export interface ListStreamsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: StreamsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListV1PipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Filters pipelines by name (case-insensitive substring). */
    name?: string;
    page?: number;
    perPage?: number;
}
export interface ListV1ResultItem {
    /** Indicates a unique identifier for this pipeline. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    /** Indicates the name of the Pipeline. */
    name: string;
    /** Specifies SQL for the Pipeline processing flow. */
    sql: string;
    /** Indicates the current status of the Pipeline. */
    status: string;
}
export type ListV1ResultList = Array<ListV1ResultItem>;
export interface ListV1PipelineResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListV1ResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type StreamsUpdateRequestHttpCorsOriginsList = Array<string>;
export interface StreamsUpdateRequestHttpCors {
    origins?: StreamsUpdateRequestHttpCorsOriginsList;
}
export interface StreamsUpdateRequestHttp {
    /** Indicates that authentication is required for the HTTP endpoint. */
    authentication: boolean;
    /** Indicates that the HTTP endpoint is enabled. */
    enabled: boolean;
    /** Specifies the CORS options for the HTTP endpoint. */
    cors?: StreamsUpdateRequestHttpCors;
}
export type StreamsUpdateRequestWorkerBinding = StreamsCreateRequestWorkerBinding;
export interface PatchStreamRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the public ID of the stream. */
    streamId: string;
    http?: StreamsUpdateRequestHttp;
    workerBinding?: StreamsCreateRequestWorkerBinding;
}
export type StreamsUpdateResponseHttpCorsOriginsList = Array<string>;
export interface StreamsUpdateResponseHttpCors {
    origins?: StreamsUpdateResponseHttpCorsOriginsList | null;
}
export interface StreamsUpdateResponseHttp {
    /** Indicates that authentication is required for the HTTP endpoint. */
    authentication: boolean;
    /** Indicates that the HTTP endpoint is enabled. */
    enabled: boolean;
    /** Specifies the CORS options for the HTTP endpoint. */
    cors?: StreamsUpdateResponseHttpCors | null;
}
export type StreamsUpdateResponseWorkerBinding = StreamsCreateRequestWorkerBinding;
export type StreamsUpdateResponseFormatJsonType = "json";
export type StreamsUpdateResponseFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export type StreamsUpdateResponseFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export interface StreamsUpdateResponseFormatJson {
    type: StreamsUpdateResponseFormatJsonType;
    decimalEncoding?: StreamsUpdateResponseFormatJsonDecimalEncoding | null;
    timestampFormat?: StreamsUpdateResponseFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export type StreamsUpdateResponseFormatParquetType = "parquet";
export type StreamsUpdateResponseFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export interface StreamsUpdateResponseFormatParquet {
    type: StreamsUpdateResponseFormatParquetType;
    compression?: StreamsUpdateResponseFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export type StreamsUpdateResponseFormat = StreamsUpdateResponseFormatJson | StreamsUpdateResponseFormatParquet;
export type StreamsUpdateResponseSchemaFieldsItemInt32Type = "int32";
export interface StreamsUpdateResponseSchemaFieldsItemInt32 {
    type: StreamsUpdateResponseSchemaFieldsItemInt32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsUpdateResponseSchemaFieldsItemInt64Type = "int64";
export interface StreamsUpdateResponseSchemaFieldsItemInt64 {
    type: StreamsUpdateResponseSchemaFieldsItemInt64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsUpdateResponseSchemaFieldsItemFloat32Type = "float32";
export interface StreamsUpdateResponseSchemaFieldsItemFloat32 {
    type: StreamsUpdateResponseSchemaFieldsItemFloat32Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsUpdateResponseSchemaFieldsItemFloat64Type = "float64";
export interface StreamsUpdateResponseSchemaFieldsItemFloat64 {
    type: StreamsUpdateResponseSchemaFieldsItemFloat64Type;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsUpdateResponseSchemaFieldsItemBoolType = "bool";
export interface StreamsUpdateResponseSchemaFieldsItemBool {
    type: StreamsUpdateResponseSchemaFieldsItemBoolType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsUpdateResponseSchemaFieldsItemStringType = "string";
export interface StreamsUpdateResponseSchemaFieldsItemString {
    type: StreamsUpdateResponseSchemaFieldsItemStringType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsUpdateResponseSchemaFieldsItemBinaryType = "binary";
export interface StreamsUpdateResponseSchemaFieldsItemBinary {
    type: StreamsUpdateResponseSchemaFieldsItemBinaryType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsUpdateResponseSchemaFieldsItemTimestampType = "timestamp";
export type StreamsUpdateResponseSchemaFieldsItemTimestampUnit = "second" | "millisecond" | "microsecond" | "nanosecond";
export interface StreamsUpdateResponseSchemaFieldsItemTimestamp {
    type: StreamsUpdateResponseSchemaFieldsItemTimestampType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
    unit?: StreamsUpdateResponseSchemaFieldsItemTimestampUnit | null;
}
export type StreamsUpdateResponseSchemaFieldsItemJsonType = "json";
export interface StreamsUpdateResponseSchemaFieldsItemJson {
    type: StreamsUpdateResponseSchemaFieldsItemJsonType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsUpdateResponseSchemaFieldsItemStructType = "struct";
export interface StreamsUpdateResponseSchemaFieldsItemStruct {
    type: StreamsUpdateResponseSchemaFieldsItemStructType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsUpdateResponseSchemaFieldsItemListType = "list";
export interface StreamsUpdateResponseSchemaFieldsItemList {
    type: StreamsUpdateResponseSchemaFieldsItemListType;
    metadataKey?: string | null;
    name?: string | null;
    required?: boolean | null;
    sqlName?: string | null;
}
export type StreamsUpdateResponseSchemaFieldsItem = StreamsUpdateResponseSchemaFieldsItemInt32 | StreamsUpdateResponseSchemaFieldsItemInt64 | StreamsUpdateResponseSchemaFieldsItemFloat32 | StreamsUpdateResponseSchemaFieldsItemFloat64 | StreamsUpdateResponseSchemaFieldsItemBool | StreamsUpdateResponseSchemaFieldsItemString | StreamsUpdateResponseSchemaFieldsItemBinary | StreamsUpdateResponseSchemaFieldsItemTimestamp | StreamsUpdateResponseSchemaFieldsItemJson | StreamsUpdateResponseSchemaFieldsItemStruct | StreamsUpdateResponseSchemaFieldsItemList;
export type StreamsUpdateResponseSchemaFieldsList = Array<StreamsUpdateResponseSchemaFieldsItem>;
export interface StreamsUpdateResponseSchema {
    fields?: StreamsUpdateResponseSchemaFieldsList | null;
    inferred?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchStreamResponse {
    /** Indicates a unique identifier for this stream. */
    id: string;
    createdAt: string;
    http: StreamsUpdateResponseHttp;
    modifiedAt: string;
    /** Indicates the name of the Stream. */
    name: string;
    /** Indicates the current version of this stream. */
    version: number;
    workerBinding: StreamsCreateRequestWorkerBinding;
    /** Indicates the endpoint URL of this stream. */
    endpoint?: string | null;
    /** Defines the data format of the events. */
    format?: StreamsUpdateResponseFormat | null;
    /** Defines the schema of the events in the data stream. */
    schema?: StreamsUpdateResponseSchema | null;
}
export type SendStreamRecordsEventList = Array<unknown>;
export interface SendStreamRecordsRequest {
    /** The stream ID; selects the ingest host. */
    streamId: string;
    /** The events, sent as the bare JSON array body. At most 5 MB per request. */
    records: SendStreamRecordsEventList;
}
export interface SendStreamRecordsResponse {
    /** How many events the stream accepted. */
    committed?: number | null;
}
export type UpdateRequestDestinationBatch = CreateRequestDestinationBatch;
export type UpdateRequestDestinationCompressionType = "none" | "gzip" | "deflate";
export interface UpdateRequestDestinationCompression {
    /** Specifies the desired compression algorithm and format. */
    type?: UpdateRequestDestinationCompressionType | (string & {});
}
export type UpdateRequestDestinationFormat = "json";
export type UpdateRequestDestinationPath = CreateRequestDestinationPath;
export type UpdateRequestDestinationType = "r2";
export type UpdateRequestDestinationCredentials = CreateRequestDestinationCredentials;
export interface UpdateRequestDestination {
    batch: CreateRequestDestinationBatch;
    compression: UpdateRequestDestinationCompression;
    /** Specifies the format of data to deliver. */
    format: UpdateRequestDestinationFormat | (string & {});
    path: CreateRequestDestinationPath;
    /** Specifies the type of destination. */
    type: UpdateRequestDestinationType | (string & {});
    credentials?: CreateRequestDestinationCredentials;
}
export type UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat = "json";
export type UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList = Array<string>;
export interface UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors {
    /** Specifies allowed origins to allow Cross Origin HTTP Requests. */
    origins?: UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList;
}
export interface UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource {
    /** Specifies the format of source data. */
    format: UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat;
    type: string;
    /** Specifies whether authentication is required to send to this pipeline via HTTP. */
    authentication?: boolean;
    cors?: UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors;
}
export type UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat = "json";
export interface UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSource {
    /** Specifies the format of source data. */
    format: UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat;
    type: string;
}
export type UpdateRequestSourceItem = UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource | UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSource;
export type UpdateRequestSourceList = Array<UpdateRequestSourceItem>;
export interface UpdatePipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Defines the name of the pipeline. */
    pipelineName: string;
    destination: UpdateRequestDestination;
    /** Defines the name of the pipeline. */
    name: string;
    source: UpdateRequestSourceList;
}
export type UpdateResponseDestinationBatch = CreateResponseDestinationBatch;
export type UpdateResponseDestinationCompressionType = "none" | "gzip" | "deflate";
export interface UpdateResponseDestinationCompression {
    /** Specifies the desired compression algorithm and format. */
    type: UpdateResponseDestinationCompressionType;
}
export type UpdateResponseDestinationFormat = "json";
export type UpdateResponseDestinationPath = CreateResponseDestinationPath;
export type UpdateResponseDestinationType = "r2";
export interface UpdateResponseDestination {
    batch: CreateResponseDestinationBatch;
    compression: UpdateResponseDestinationCompression;
    /** Specifies the format of data to deliver. */
    format: UpdateResponseDestinationFormat;
    path: CreateResponseDestinationPath;
    /** Specifies the type of destination. */
    type: UpdateResponseDestinationType;
}
export type UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat = "json";
export type UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList = Array<string>;
export interface UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors {
    /** Specifies allowed origins to allow Cross Origin HTTP Requests. */
    origins?: UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList | null;
}
export interface UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource {
    /** Specifies the format of source data. */
    format: UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat;
    type: string;
    /** Specifies whether authentication is required to send to this pipeline via HTTP. */
    authentication?: boolean | null;
    cors?: UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors | null;
}
export type UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat = "json";
export interface UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource {
    /** Specifies the format of source data. */
    format: UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat;
    type: string;
}
export type UpdateResponseSourceItem = UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource | UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource;
export type UpdateResponseSourceList = Array<UpdateResponseSourceItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdatePipelineResponse {
    /** Specifies the pipeline identifier. */
    id: string;
    destination: UpdateResponseDestination;
    /** Indicates the endpoint URL to send traffic. */
    endpoint: string;
    /** Defines the name of the pipeline. */
    name: string;
    source: UpdateResponseSourceList;
    /** Indicates the version number of last saved configuration. */
    version: number;
}
export interface ValidateSqlPipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies SQL to validate. */
    sql: string;
}
export interface ValidateSqlResponseTablesValue {
    id: string;
    name: string;
    type: string;
    version: number;
}
export type ValidateSqlResponseTablesMap = {
    [key: string]: ValidateSqlResponseTablesValue | undefined;
};
export interface ValidateSqlResponseGraphEdgesItem {
    destId: number;
    edgeType: string;
    keyType: string;
    srcId: number;
    valueType: string;
}
export type ValidateSqlResponseGraphEdgesList = Array<ValidateSqlResponseGraphEdgesItem>;
export interface ValidateSqlResponseGraphNodesItem {
    description: string;
    nodeId: number;
    operator: string;
    parallelism: number;
}
export type ValidateSqlResponseGraphNodesList = Array<ValidateSqlResponseGraphNodesItem>;
export interface ValidateSqlResponseGraph {
    edges: ValidateSqlResponseGraphEdgesList;
    nodes: ValidateSqlResponseGraphNodesList;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ValidateSqlPipelineResponse {
    /** Indicates tables involved in the processing. */
    tables: ValidateSqlResponseTablesMap;
    /** Indicates the processing flow to implement the SQL. */
    graph?: ValidateSqlResponseGraph | null;
}
export type CreatePipelineError = CloudflareOpError;
/** [DEPRECATED] Create a new pipeline. Use the new /pipelines/v1/pipelines endpoint instead. */
export declare const createPipeline: API.OperationMethod<CreatePipelineRequest, CreatePipelineResponse, CreatePipelineError, CloudflareOpContext>;
export type CreateSinkError = SinkAuthFailed | InvalidSinkConfig | SinkAlreadyExists | CloudflareOpError;
/** Create a new Sink. */
export declare const createSink: API.OperationMethod<CreateSinkRequest, CreateSinkResponse, CreateSinkError, CloudflareOpContext>;
export type CreateStreamError = InvalidStreamName | StreamAlreadyExists | CloudflareOpError;
/** Create a new Stream. */
export declare const createStream: API.OperationMethod<CreateStreamRequest, CreateStreamResponse, CreateStreamError, CloudflareOpContext>;
export type CreateV1PipelineError = TableNotFound | InvalidSql | PipelineAlreadyExists | CloudflareOpError;
/** Create a new Pipeline. */
export declare const createV1Pipeline: API.OperationMethod<CreateV1PipelineRequest, CreateV1PipelineResponse, CreateV1PipelineError, CloudflareOpContext>;
export type DeletePipelineError = PipelineNotExists | CloudflareOpError;
/** [DEPRECATED] Delete a pipeline. Use the new /pipelines/v1/pipelines endpoint instead. */
export declare const deletePipeline: API.OperationMethod<DeletePipelineRequest, DeletePipelineResponse, DeletePipelineError, CloudflareOpContext>;
export type DeleteSinkError = SinkNotFound | InvalidSinkId | SinkInUse | CloudflareOpError;
/** Delete Sink in Account. */
export declare const deleteSink: API.OperationMethod<DeleteSinkRequest, DeleteSinkResponse, DeleteSinkError, CloudflareOpContext>;
export type DeleteStreamError = PipelineNotExists | StreamNotFound | InvalidStreamId | StreamInUse | CloudflareOpError;
/** Delete Stream in Account. */
export declare const deleteStream: API.OperationMethod<DeleteStreamRequest, DeleteStreamResponse, DeleteStreamError, CloudflareOpContext>;
export type DeleteV1PipelineError = PipelineNotExists | CloudflareOpError;
/** Delete Pipeline in Account. */
export declare const deleteV1Pipeline: API.OperationMethod<DeleteV1PipelineRequest, DeleteV1PipelineResponse, DeleteV1PipelineError, CloudflareOpContext>;
export type GetPipelineError = PipelineNotExists | CloudflareOpError;
/** [DEPRECATED] Get configuration of a pipeline. Use the new /pipelines/v1/pipelines endpoint instead. */
export declare const getPipeline: API.OperationMethod<GetPipelineRequest, GetPipelineResponse, GetPipelineError, CloudflareOpContext>;
export type GetSinkError = SinkNotFound | InvalidSinkId | CloudflareOpError;
/** Get Sink Details. */
export declare const getSink: API.OperationMethod<GetSinkRequest, GetSinkResponse, GetSinkError, CloudflareOpContext>;
export type GetStreamError = StreamNotFound | InvalidStreamId | CloudflareOpError;
/** Get Stream Details. */
export declare const getStream: API.OperationMethod<GetStreamRequest, GetStreamResponse, GetStreamError, CloudflareOpContext>;
export type GetV1PipelineError = PipelineNotExists | CloudflareOpError;
/** Get Pipeline details. */
export declare const getV1Pipeline: API.OperationMethod<GetV1PipelineRequest, GetV1PipelineResponse, GetV1PipelineError, CloudflareOpContext>;
export type ListPipelinesError = CloudflareOpError;
/** [DEPRECATED] List, filter, and paginate pipelines in an account. Use the new /pipelines/v1/pipelines endpoint instead. */
export declare const listPipelines: API.PaginatedOperationMethod<ListPipelinesRequest, ListPipelinesResponse, ListPipelinesError, CloudflareOpContext, ListResponseResultsItem>;
export type ListSinksError = CloudflareOpError;
/** List/Filter Sinks in Account. */
export declare const listSinks: API.PaginatedOperationMethod<ListSinksRequest, ListSinksResponse, ListSinksError, CloudflareOpContext, SinksListResultItem>;
export type ListStreamsError = CloudflareOpError;
/** List/Filter Streams in Account. */
export declare const listStreams: API.PaginatedOperationMethod<ListStreamsRequest, ListStreamsResponse, ListStreamsError, CloudflareOpContext, StreamsListResultItem>;
export type ListV1PipelineError = CloudflareOpError;
/** List/Filter Pipelines in Account. */
export declare const listV1Pipeline: API.PaginatedOperationMethod<ListV1PipelineRequest, ListV1PipelineResponse, ListV1PipelineError, CloudflareOpContext, ListV1ResultItem>;
export type PatchStreamError = StreamNotFound | CloudflareOpError;
/** Update a Stream. */
export declare const patchStream: API.OperationMethod<PatchStreamRequest, PatchStreamResponse, PatchStreamError, CloudflareOpContext>;
export type SendStreamRecordsError = IngestStreamNotFound | InvalidIngestData | CloudflareOpError;
/** Send events to a stream's HTTP ingest endpoint. Needs the stream's HTTP input enabled, and a token with Pipelines Send when it requires authentication. */
export declare const sendStreamRecords: API.OperationMethod<SendStreamRecordsRequest, SendStreamRecordsResponse, SendStreamRecordsError, CloudflareOpContext>;
export type UpdatePipelineError = PipelineNotExists | CloudflareOpError;
/** [DEPRECATED] Update an existing pipeline. Use the new /pipelines/v1/pipelines endpoint instead. */
export declare const updatePipeline: API.OperationMethod<UpdatePipelineRequest, UpdatePipelineResponse, UpdatePipelineError, CloudflareOpContext>;
export type ValidateSqlPipelineError = TableNotFound | InvalidSql | CloudflareOpError;
/** Validates that the Pipelines SQL is correct. */
export declare const validateSqlPipeline: API.OperationMethod<ValidateSqlPipelineRequest, ValidateSqlPipelineResponse, ValidateSqlPipelineError, CloudflareOpContext>;
//# sourceMappingURL=pipelines.d.ts.map