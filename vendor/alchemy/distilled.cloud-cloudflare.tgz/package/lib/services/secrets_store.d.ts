import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const InvalidAccountId_base: S.TaggedErrorClass<"InvalidAccountId", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidAccountId extends /*@__PURE__*/ InvalidAccountId_base {
}
declare const InvalidJsonBody_base: S.TaggedErrorClass<"InvalidJsonBody", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidJsonBody extends /*@__PURE__*/ InvalidJsonBody_base {
}
declare const MaximumStoresExceeded_base: S.TaggedErrorClass<"MaximumStoresExceeded", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MaximumStoresExceeded extends /*@__PURE__*/ MaximumStoresExceeded_base {
}
declare const NotFound_base: S.TaggedErrorClass<"NotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
declare const SecretNameAlreadyExists_base: S.TaggedErrorClass<"SecretNameAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SecretNameAlreadyExists extends /*@__PURE__*/ SecretNameAlreadyExists_base {
}
declare const SecretNameEmpty_base: S.TaggedErrorClass<"SecretNameEmpty", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SecretNameEmpty extends /*@__PURE__*/ SecretNameEmpty_base {
}
declare const SecretNotFound_base: S.TaggedErrorClass<"SecretNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SecretNotFound extends /*@__PURE__*/ SecretNotFound_base {
}
declare const SecretScopeInvalid_base: S.TaggedErrorClass<"SecretScopeInvalid", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SecretScopeInvalid extends /*@__PURE__*/ SecretScopeInvalid_base {
}
declare const SecretScopesEmpty_base: S.TaggedErrorClass<"SecretScopesEmpty", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SecretScopesEmpty extends /*@__PURE__*/ SecretScopesEmpty_base {
}
declare const StoreNotFound_base: S.TaggedErrorClass<"StoreNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class StoreNotFound extends /*@__PURE__*/ StoreNotFound_base {
}
export interface BulkDeleteStoreSecretsRequest {
    accountId: string;
    storeId: string;
}
export type BulkDeleteStoreSecretsResponse = unknown;
export interface CreateStoreRequest {
    accountId: string;
    /** The name of the store. */
    name: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateStoreResponse {
    /** Store Identifier. */
    id: string;
    /** When the secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the store. */
    name: string;
    /** Account Identifier. */
    accountId?: string | null;
}
export type StoresSecretsCreateRequestBodyItemScopesItem = "workers" | "ai_gateway" | "dex" | "access" | "containers" | "websearch";
export type StoresSecretsCreateRequestBodyItemScopesList = Array<StoresSecretsCreateRequestBodyItemScopesItem | (string & {})>;
export interface StoresSecretsCreateRequestBodyItem {
    /** The name of the secret. */
    name: string;
    /** The list of services that can use this secret. */
    scopes: StoresSecretsCreateRequestBodyItemScopesList;
    /** The value of the secret. Maximum 64 KiB (65,536 bytes). Note that this is 'write only' - the API never returns this value; it exists only to create or modify secrets. */
    value: string;
    /** Freeform text describing the secret. */
    comment?: string;
}
export type StoresSecretsCreateRequestBodyList = Array<StoresSecretsCreateRequestBodyItem>;
export interface CreateStoreSecretRequest {
    accountId: string;
    storeId: string;
    body: StoresSecretsCreateRequestBodyList;
}
export type StoresSecretsCreateResultItemStatus = "pending" | "active" | "deleted";
export type StoresSecretsCreateResultItemScopesItem = "workers" | "ai_gateway" | "dex" | "access" | "containers" | "websearch";
export type StoresSecretsCreateResultItemScopesList = Array<StoresSecretsCreateResultItemScopesItem>;
export interface StoresSecretsCreateResultItem {
    /** Secret identifier tag. */
    id: string;
    /** When the secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the secret. */
    name: string;
    status: StoresSecretsCreateResultItemStatus;
    /** Store Identifier. */
    storeId: string;
    /** Freeform text describing the secret. */
    comment?: string | null;
    /** The list of services that can use this secret. */
    scopes?: StoresSecretsCreateResultItemScopesList | null;
}
export type StoresSecretsCreateResultList = Array<StoresSecretsCreateResultItem>;
export interface CreateStoreSecretResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: StoresSecretsCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface DeleteStoreRequest {
    accountId: string;
    storeId: string;
    /** When true, cascade-deletes all secrets in the store before deleting the store itself. Required when deleting a non-empty store. Without this parameter, attempting to delete a non-empty store returns 409. */
    force?: boolean;
}
export type DeleteStoreResponse = unknown;
export interface DeleteStoreSecretRequest {
    accountId: string;
    storeId: string;
    secretId: string;
}
export type DeleteStoreSecretResponse = unknown;
export type StoresSecretsDuplicateRequestScopesItem = "workers" | "ai_gateway" | "dex" | "access" | "containers" | "websearch";
export type StoresSecretsDuplicateRequestScopesList = Array<StoresSecretsDuplicateRequestScopesItem | (string & {})>;
export interface DuplicateStoreSecretRequest {
    accountId: string;
    storeId: string;
    secretId: string;
    /** The name of the secret. */
    name: string;
    /** The list of services that can use this secret. */
    scopes: StoresSecretsDuplicateRequestScopesList;
    /** Freeform text describing the secret. */
    comment?: string;
}
export type StoresSecretsDuplicateResponseStatus = "pending" | "active" | "deleted";
export type StoresSecretsDuplicateResponseScopesItem = "workers" | "ai_gateway" | "dex" | "access" | "containers" | "websearch";
export type StoresSecretsDuplicateResponseScopesList = Array<StoresSecretsDuplicateResponseScopesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DuplicateStoreSecretResponse {
    /** Secret identifier tag. */
    id: string;
    /** When the secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the secret. */
    name: string;
    status: StoresSecretsDuplicateResponseStatus;
    /** Store Identifier. */
    storeId: string;
    /** Freeform text describing the secret. */
    comment?: string | null;
    /** The list of services that can use this secret. */
    scopes?: StoresSecretsDuplicateResponseScopesList | null;
}
export interface GetQuotaRequest {
    accountId: string;
}
export interface QuotaGetResponseSecrets {
    /** The number of secrets the account is entitled to use. */
    quota: number;
    /** The number of secrets the account is currently using. */
    usage: number;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetQuotaResponse {
    secrets: QuotaGetResponseSecrets;
}
export interface GetStoreRequest {
    accountId: string;
    storeId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetStoreResponse {
    /** Store Identifier. */
    id: string;
    /** When the secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the store. */
    name: string;
    /** Account Identifier. */
    accountId?: string | null;
}
export interface GetStoreSecretRequest {
    accountId: string;
    storeId: string;
    secretId: string;
}
export type StoresSecretsGetResponseStatus = "pending" | "active" | "deleted";
export type StoresSecretsGetResponseScopesItem = "workers" | "ai_gateway" | "dex" | "access" | "containers" | "websearch";
export type StoresSecretsGetResponseScopesList = Array<StoresSecretsGetResponseScopesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetStoreSecretResponse {
    /** Secret identifier tag. */
    id: string;
    /** When the secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the secret. */
    name: string;
    status: StoresSecretsGetResponseStatus;
    /** Store Identifier. */
    storeId: string;
    /** Freeform text describing the secret. */
    comment?: string | null;
    /** The list of services that can use this secret. */
    scopes?: StoresSecretsGetResponseScopesList | null;
}
export type StoresListRequestDirection = "asc" | "desc";
export type StoresListRequestOrder = "name" | "created" | "modified";
export interface ListStoresRequest {
    accountId: string;
    /** Direction to sort objects. */
    direction?: StoresListRequestDirection | (string & {});
    /** Order stores by values in the given field. */
    order?: StoresListRequestOrder | (string & {});
    /** Page number. */
    page?: number;
    /** Number of objects to return per page. */
    perPage?: number;
}
export interface StoresListResultItem {
    /** Store Identifier. */
    id: string;
    /** When the secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the store. */
    name: string;
    /** Account Identifier. */
    accountId?: string | null;
}
export type StoresListResultList = Array<StoresListResultItem>;
export interface ListStoresResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: StoresListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type StoresSecretsListRequestDirection = "asc" | "desc";
export type StoresSecretsListRequestOrder = "name" | "comment" | "created" | "modified" | "status";
export type StoresSecretsListRequestScopes = "workers" | "ai_gateway" | "dex" | "access" | "containers" | "websearch";
export type StoresSecretsListRequestScopesList = Array<StoresSecretsListRequestScopes | (string & {})>;
export interface ListStoreSecretsRequest {
    accountId: string;
    storeId: string;
    /** Direction to sort objects. */
    direction?: StoresSecretsListRequestDirection | (string & {});
    /** Order secrets by values in the given field. */
    order?: StoresSecretsListRequestOrder | (string & {});
    /** Page number. */
    page?: number;
    /** Number of objects to return per page. */
    perPage?: number;
    /** Only secrets with the given scopes will be returned. */
    scopes?: StoresSecretsListRequestScopesList;
    /** Search secrets using a filter string, filtering across name and comment. */
    search?: string;
}
export type StoresSecretsListResultItemStatus = "pending" | "active" | "deleted";
export type StoresSecretsListResultItemScopesItem = "workers" | "ai_gateway" | "dex" | "access" | "containers" | "websearch";
export type StoresSecretsListResultItemScopesList = Array<StoresSecretsListResultItemScopesItem>;
export interface StoresSecretsListResultItem {
    /** Secret identifier tag. */
    id: string;
    /** When the secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the secret. */
    name: string;
    status: StoresSecretsListResultItemStatus;
    /** Store Identifier. */
    storeId: string;
    /** Freeform text describing the secret. */
    comment?: string | null;
    /** The list of services that can use this secret. */
    scopes?: StoresSecretsListResultItemScopesList | null;
}
export type StoresSecretsListResultList = Array<StoresSecretsListResultItem>;
export interface ListStoreSecretsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: StoresSecretsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type StoresSecretsEditRequestScopesItem = "workers" | "ai_gateway" | "dex" | "access" | "containers" | "websearch";
export type StoresSecretsEditRequestScopesList = Array<StoresSecretsEditRequestScopesItem | (string & {})>;
export interface PatchStoreSecretRequest {
    accountId: string;
    storeId: string;
    secretId: string;
    /** Freeform text describing the secret. */
    comment?: string;
    /** The list of services that can use this secret. */
    scopes?: StoresSecretsEditRequestScopesList;
    /** The value of the secret. Maximum 64 KiB (65,536 bytes). Note that this is 'write only' - the API never returns this value; it exists only to create or modify secrets. */
    value?: string;
}
export type StoresSecretsEditResponseStatus = "pending" | "active" | "deleted";
export type StoresSecretsEditResponseScopesItem = "workers" | "ai_gateway" | "dex" | "access" | "containers" | "websearch";
export type StoresSecretsEditResponseScopesList = Array<StoresSecretsEditResponseScopesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchStoreSecretResponse {
    /** Secret identifier tag. */
    id: string;
    /** When the secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the secret. */
    name: string;
    status: StoresSecretsEditResponseStatus;
    /** Store Identifier. */
    storeId: string;
    /** Freeform text describing the secret. */
    comment?: string | null;
    /** The list of services that can use this secret. */
    scopes?: StoresSecretsEditResponseScopesList | null;
}
export type BulkDeleteStoreSecretsError = StoreNotFound | InvalidAccountId | InvalidJsonBody | CloudflareOpError;
/** Deletes one or more secrets. */
export declare const bulkDeleteStoreSecrets: API.OperationMethod<BulkDeleteStoreSecretsRequest, BulkDeleteStoreSecretsResponse, BulkDeleteStoreSecretsError, CloudflareOpContext>;
export type CreateStoreError = InvalidAccountId | MaximumStoresExceeded | CloudflareOpError;
/** Creates a store in the account. */
export declare const createStore: API.OperationMethod<CreateStoreRequest, CreateStoreResponse, CreateStoreError, CloudflareOpContext>;
export type CreateStoreSecretError = StoreNotFound | InvalidAccountId | SecretNameEmpty | SecretNameAlreadyExists | SecretScopeInvalid | CloudflareOpError;
/** Creates a secret in the account. */
export declare const createStoreSecret: API.PaginatedOperationMethod<CreateStoreSecretRequest, CreateStoreSecretResponse, CreateStoreSecretError, CloudflareOpContext, StoresSecretsCreateResultItem>;
export type DeleteStoreError = StoreNotFound | InvalidAccountId | NotFound | CloudflareOpError;
/** Deletes a single store. By default, a store that still contains secrets cannot be deleted and returns HTTP 409 (Conflict) with the "store_not_empty" error. Pass `force=true` to cascade-delete all secrets in the store. Empty stores are always deleted regardless of the force parameter. */
export declare const deleteStore: API.OperationMethod<DeleteStoreRequest, DeleteStoreResponse, DeleteStoreError, CloudflareOpContext>;
export type DeleteStoreSecretError = StoreNotFound | SecretNotFound | InvalidAccountId | NotFound | CloudflareOpError;
/** Deletes a single secret. */
export declare const deleteStoreSecret: API.OperationMethod<DeleteStoreSecretRequest, DeleteStoreSecretResponse, DeleteStoreSecretError, CloudflareOpContext>;
export type DuplicateStoreSecretError = StoreNotFound | SecretNotFound | SecretNameEmpty | SecretScopesEmpty | SecretNameAlreadyExists | InvalidAccountId | SecretScopeInvalid | CloudflareOpError;
/** Creates a duplicate of the secret, keeping the value. */
export declare const duplicateStoreSecret: API.OperationMethod<DuplicateStoreSecretRequest, DuplicateStoreSecretResponse, DuplicateStoreSecretError, CloudflareOpContext>;
export type GetQuotaError = InvalidAccountId | CloudflareOpError;
/** Lists the number of secrets used in the account. */
export declare const getQuota: API.OperationMethod<GetQuotaRequest, GetQuotaResponse, GetQuotaError, CloudflareOpContext>;
export type GetStoreError = CloudflareOpError;
/** Returns details of a single store. */
export declare const getStore: API.OperationMethod<GetStoreRequest, GetStoreResponse, GetStoreError, CloudflareOpContext>;
export type GetStoreSecretError = StoreNotFound | SecretNotFound | InvalidAccountId | NotFound | CloudflareOpError;
/** Returns details of a single secret. */
export declare const getStoreSecret: API.OperationMethod<GetStoreSecretRequest, GetStoreSecretResponse, GetStoreSecretError, CloudflareOpContext>;
export type ListStoresError = InvalidAccountId | CloudflareOpError;
/** Lists all the stores in an account. */
export declare const listStores: API.PaginatedOperationMethod<ListStoresRequest, ListStoresResponse, ListStoresError, CloudflareOpContext, StoresListResultItem>;
export type ListStoreSecretsError = StoreNotFound | InvalidAccountId | CloudflareOpError;
/** Lists all store secrets. */
export declare const listStoreSecrets: API.PaginatedOperationMethod<ListStoreSecretsRequest, ListStoreSecretsResponse, ListStoreSecretsError, CloudflareOpContext, StoresSecretsListResultItem>;
export type PatchStoreSecretError = StoreNotFound | SecretNotFound | InvalidAccountId | SecretScopeInvalid | CloudflareOpError;
/** Updates a single secret. */
export declare const patchStoreSecret: API.OperationMethod<PatchStoreSecretRequest, PatchStoreSecretResponse, PatchStoreSecretError, CloudflareOpContext>;
//# sourceMappingURL=secrets_store.d.ts.map