import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CatalogSnapshotExpirationDisabled_base: S.TaggedErrorClass<"CatalogSnapshotExpirationDisabled", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** Per-table snapshot expiration needs snapshot expiration enabled on the catalog first. */
export declare class CatalogSnapshotExpirationDisabled extends /*@__PURE__*/ CatalogSnapshotExpirationDisabled_base {
}
export interface CreateCredentialsRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    /** Provides the Cloudflare API token for accessing R2. */
    token: string;
}
export type CreateCredentialsResponse = unknown;
export interface DeleteRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    /** Remove child metadata before deleting the catalog. */
    force?: boolean;
}
export interface DeleteResponse {
}
export interface DisableRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
}
export interface DisableResponse {
}
export interface EnableRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EnableResponse {
    /** Use this to uniquely identify the activated catalog. */
    id: string;
    /** Specifies the name of the activated catalog. */
    name: string;
}
export interface GetRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
}
export type GetResponseStatus = "active" | "inactive";
export type GetResponseCredentialStatus = "present" | "absent";
export type GetResponseMaintenanceConfigCompactionState = "enabled" | "disabled";
export type GetResponseMaintenanceConfigCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface GetResponseMaintenanceConfigCompaction {
    /** Specifies the state of maintenance operations. */
    state: GetResponseMaintenanceConfigCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: GetResponseMaintenanceConfigCompactionTargetSizeMb;
}
export type GetResponseMaintenanceConfigSnapshotExpirationState = "enabled" | "disabled";
export interface GetResponseMaintenanceConfigSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. Format: where unit is d (days), h (hours), m (minutes), or s (seconds). Examples: "7d" (7 days), "48h" (48 hours), "2880m" (2,880 minutes). Defaults to "7d". */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: GetResponseMaintenanceConfigSnapshotExpirationState;
}
export interface GetResponseMaintenanceConfig {
    /** Configures compaction for catalog maintenance. */
    compaction?: GetResponseMaintenanceConfigCompaction | null;
    /** Scheduling interval between normal table maintenance runs. */
    interval?: string | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: GetResponseMaintenanceConfigSnapshotExpiration | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResponse {
    /** Use this to uniquely identify the catalog. */
    id: string;
    /** Specifies the associated R2 bucket name. */
    bucket: string;
    /** Specifies the catalog name (generated from account and bucket name). */
    name: string;
    /** Indicates the status of the catalog. */
    status: GetResponseStatus;
    /** Shows the credential configuration status. */
    credentialStatus?: GetResponseCredentialStatus | null;
    /** Configures maintenance for the catalog. */
    maintenanceConfig?: GetResponseMaintenanceConfig | null;
}
export interface GetMaintenanceConfigRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
}
export type GetMaintenanceConfigResponseCredentialStatus = "present" | "absent";
export type GetMaintenanceConfigResponseMaintenanceConfigCompactionState = "enabled" | "disabled";
export type GetMaintenanceConfigResponseMaintenanceConfigCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface GetMaintenanceConfigResponseMaintenanceConfigCompaction {
    /** Specifies the state of maintenance operations. */
    state: GetMaintenanceConfigResponseMaintenanceConfigCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: GetMaintenanceConfigResponseMaintenanceConfigCompactionTargetSizeMb;
}
export type GetMaintenanceConfigResponseMaintenanceConfigSnapshotExpirationState = "enabled" | "disabled";
export interface GetMaintenanceConfigResponseMaintenanceConfigSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. Format: where unit is d (days), h (hours), m (minutes), or s (seconds). Examples: "7d" (7 days), "48h" (48 hours), "2880m" (2,880 minutes). Defaults to "7d". */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: GetMaintenanceConfigResponseMaintenanceConfigSnapshotExpirationState;
}
export interface GetMaintenanceConfigResponseMaintenanceConfig {
    /** Configures compaction for catalog maintenance. */
    compaction?: GetMaintenanceConfigResponseMaintenanceConfigCompaction | null;
    /** Scheduling interval between normal table maintenance runs. */
    interval?: string | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: GetMaintenanceConfigResponseMaintenanceConfigSnapshotExpiration | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMaintenanceConfigResponse {
    /** Shows the credential configuration status. */
    credentialStatus: GetMaintenanceConfigResponseCredentialStatus;
    /** Configures maintenance for the catalog. */
    maintenanceConfig: GetMaintenanceConfigResponseMaintenanceConfig;
}
export interface GetNamespacesTablesMaintenanceConfigRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    namespace: string;
    tableName: string;
}
export type GetNamespacesTablesMaintenanceConfigResponseMaintenanceConfigCompactionState = "enabled" | "disabled";
export type GetNamespacesTablesMaintenanceConfigResponseMaintenanceConfigCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface GetNamespacesTablesMaintenanceConfigResponseMaintenanceConfigCompaction {
    /** Specifies the state of maintenance operations. */
    state: GetNamespacesTablesMaintenanceConfigResponseMaintenanceConfigCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: GetNamespacesTablesMaintenanceConfigResponseMaintenanceConfigCompactionTargetSizeMb;
    /** Earliest time when the scheduler can claim this operation. Null when disabled. */
    nextEligibleAt?: string | null;
}
export type GetNamespacesTablesMaintenanceConfigResponseMaintenanceConfigSnapshotExpirationState = "enabled" | "disabled";
export interface GetNamespacesTablesMaintenanceConfigResponseMaintenanceConfigSnapshotExpiration {
    /** Specifies the maximum age for snapshots. */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: GetNamespacesTablesMaintenanceConfigResponseMaintenanceConfigSnapshotExpirationState;
    /** Earliest time when the scheduler can claim this operation. Null when disabled. */
    nextEligibleAt?: string | null;
}
export interface GetNamespacesTablesMaintenanceConfigResponseMaintenanceConfig {
    /** Configures compaction settings for table optimization. */
    compaction?: GetNamespacesTablesMaintenanceConfigResponseMaintenanceConfigCompaction | null;
    /** Scheduling interval between normal table maintenance runs. */
    interval?: string | null;
    snapshotExpiration?: GetNamespacesTablesMaintenanceConfigResponseMaintenanceConfigSnapshotExpiration | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetNamespacesTablesMaintenanceConfigResponse {
    /** Configures maintenance for the table. */
    maintenanceConfig: GetNamespacesTablesMaintenanceConfigResponseMaintenanceConfig;
}
export interface ListRequest {
    /** Use this to identify the account. */
    accountId: string;
}
export type ListResponseWarehousesItemStatus = "active" | "inactive";
export type ListResponseWarehousesItemCredentialStatus = "present" | "absent";
export type ListResponseWarehousesItemMaintenanceConfigCompactionState = "enabled" | "disabled";
export type ListResponseWarehousesItemMaintenanceConfigCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface ListResponseWarehousesItemMaintenanceConfigCompaction {
    /** Specifies the state of maintenance operations. */
    state: ListResponseWarehousesItemMaintenanceConfigCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: ListResponseWarehousesItemMaintenanceConfigCompactionTargetSizeMb;
}
export type ListResponseWarehousesItemMaintenanceConfigSnapshotExpirationState = "enabled" | "disabled";
export interface ListResponseWarehousesItemMaintenanceConfigSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. Format: where unit is d (days), h (hours), m (minutes), or s (seconds). Examples: "7d" (7 days), "48h" (48 hours), "2880m" (2,880 minutes). Defaults to "7d". */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: ListResponseWarehousesItemMaintenanceConfigSnapshotExpirationState;
}
export interface ListResponseWarehousesItemMaintenanceConfig {
    /** Configures compaction for catalog maintenance. */
    compaction?: ListResponseWarehousesItemMaintenanceConfigCompaction | null;
    /** Scheduling interval between normal table maintenance runs. */
    interval?: string | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: ListResponseWarehousesItemMaintenanceConfigSnapshotExpiration | null;
}
export interface ListResponseWarehousesItem {
    /** Use this to uniquely identify the catalog. */
    id: string;
    /** Specifies the associated R2 bucket name. */
    bucket: string;
    /** Specifies the catalog name (generated from account and bucket name). */
    name: string;
    /** Indicates the status of the catalog. */
    status: ListResponseWarehousesItemStatus;
    /** Shows the credential configuration status. */
    credentialStatus?: ListResponseWarehousesItemCredentialStatus | null;
    /** Configures maintenance for the catalog. */
    maintenanceConfig?: ListResponseWarehousesItemMaintenanceConfig | null;
}
export type ListResponseWarehousesList = Array<ListResponseWarehousesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListResponse {
    /** Lists catalogs in the account. */
    warehouses: ListResponseWarehousesList;
}
export interface ListNamespacesRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    /** Maximum number of namespaces to return per page. Defaults to 100, maximum 1000. */
    pageSize?: number;
    /** Opaque pagination token from a previous response. Use this to fetch the next page of results. */
    pageToken?: string;
    /** Parent namespace to filter by. Only returns direct children of this namespace. For nested namespaces, use %1F as separator (e.g., "bronze%1Fanalytics"). Omit this parameter to list top-level namespaces. */
    parent?: string;
    /** Whether to include additional metadata (timestamps). When true, response includes created_at and updated_at arrays. */
    returnDetails?: boolean;
    /** Whether to include namespace UUIDs in the response. Set to true to receive the namespace_uuids array. */
    returnUuids?: boolean;
}
export type ListNamespacesResponseNamespacesItemList = Array<string>;
export type ListNamespacesResponseNamespacesList = Array<ListNamespacesResponseNamespacesItemList>;
export type ListNamespacesResponseDetailsItemNamespaceList = Array<string>;
export interface ListNamespacesResponseDetailsItem {
    /** Specifies the hierarchical namespace parts as an array of strings. For example, ["bronze", "analytics"] represents the namespace "bronze.analytics". */
    namespace: ListNamespacesResponseDetailsItemNamespaceList;
    /** Contains the UUID that persists across renames. */
    namespaceUuid: string;
    /** Indicates the creation timestamp in ISO 8601 format. */
    createdAt?: string | null;
    /** Shows the last update timestamp in ISO 8601 format. Null if never updated. */
    updatedAt?: string | null;
}
export type ListNamespacesResponseDetailsList = Array<ListNamespacesResponseDetailsItem>;
export type ListNamespacesResponseNamespaceUuidsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListNamespacesResponse {
    /** Lists namespaces in the catalog. */
    namespaces: ListNamespacesResponseNamespacesList;
    /** Contains detailed metadata for each namespace when return_details is true. Each object includes the namespace, UUID, and timestamps. */
    details?: ListNamespacesResponseDetailsList | null;
    /** Contains UUIDs for each namespace when return_uuids is true. The order corresponds to the namespaces array. */
    namespaceUuids?: ListNamespacesResponseNamespaceUuidsList | null;
    /** Use this opaque token to fetch the next page of results. A null or absent value indicates the last page. */
    nextPageToken?: string | null;
}
export interface ListNamespacesTablesRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    namespace: string;
    /** Maximum number of tables to return per page. Defaults to 100, maximum 1000. */
    pageSize?: number;
    /** Opaque pagination token from a previous response. Use this to fetch the next page of results. */
    pageToken?: string;
    /** Whether to include additional metadata (timestamps, locations). When true, response includes created_at, updated_at, metadata_locations, and locations arrays. */
    returnDetails?: boolean;
    /** Whether to include table UUIDs in the response. Set to true to receive the table_uuids array. */
    returnUuids?: boolean;
}
export type ListNamespacesTablesResponseIdentifiersItemNamespaceList = Array<string>;
export interface ListNamespacesTablesResponseIdentifiersItem {
    /** Specifies the table name. */
    name: string;
    /** Specifies the hierarchical namespace parts as an array of strings. For example, ["bronze", "analytics"] represents the namespace "bronze.analytics". */
    namespace: ListNamespacesTablesResponseIdentifiersItemNamespaceList;
}
export type ListNamespacesTablesResponseIdentifiersList = Array<ListNamespacesTablesResponseIdentifiersItem>;
export type ListNamespacesTablesResponseDetailsItemIdentifierNamespaceList = Array<string>;
export interface ListNamespacesTablesResponseDetailsItemIdentifier {
    /** Specifies the table name. */
    name: string;
    /** Specifies the hierarchical namespace parts as an array of strings. For example, ["bronze", "analytics"] represents the namespace "bronze.analytics". */
    namespace: ListNamespacesTablesResponseDetailsItemIdentifierNamespaceList;
}
export interface ListNamespacesTablesResponseDetailsItem {
    /** Specifies a unique table identifier within a catalog. */
    identifier: ListNamespacesTablesResponseDetailsItemIdentifier;
    /** Contains the UUID that persists across renames. */
    tableUuid: string;
    /** Indicates the creation timestamp in ISO 8601 format. */
    createdAt?: string | null;
    /** Specifies the base S3 URI for table storage location. */
    location?: string | null;
    /** Contains the S3 URI to table metadata file. Null for staged tables. */
    metadataLocation?: string | null;
    /** Shows the last update timestamp in ISO 8601 format. Null if never updated. */
    updatedAt?: string | null;
}
export type ListNamespacesTablesResponseDetailsList = Array<ListNamespacesTablesResponseDetailsItem>;
export type ListNamespacesTablesResponseTableUuidsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListNamespacesTablesResponse {
    /** Lists tables in the namespace. */
    identifiers: ListNamespacesTablesResponseIdentifiersList;
    /** Contains detailed metadata for each table when return_details is true. Each object includes identifier, UUID, timestamps, and locations. */
    details?: ListNamespacesTablesResponseDetailsList | null;
    /** Use this opaque token to fetch the next page of results. A null or absent value indicates the last page. */
    nextPageToken?: string | null;
    /** Contains UUIDs for each table when return_uuids is true. The order corresponds to the identifiers array. */
    tableUuids?: ListNamespacesTablesResponseTableUuidsList | null;
}
export type UpdateMaintenanceConfigRequestCompactionState = "enabled" | "disabled";
export type UpdateMaintenanceConfigRequestCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface UpdateMaintenanceConfigRequestCompaction {
    /** Specifies the state of maintenance operations. */
    state?: UpdateMaintenanceConfigRequestCompactionState | (string & {});
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb?: UpdateMaintenanceConfigRequestCompactionTargetSizeMb | (string & {});
}
export type UpdateMaintenanceConfigRequestSnapshotExpirationState = "enabled" | "disabled";
export interface UpdateMaintenanceConfigRequestSnapshotExpiration {
    /** Updates the maximum age for snapshots optionally. */
    maxSnapshotAge?: string;
    /** Updates the minimum number of snapshots to retain optionally. */
    minSnapshotsToKeep?: number;
    /** Specifies the state of maintenance operations. */
    state?: UpdateMaintenanceConfigRequestSnapshotExpirationState | (string & {});
}
export interface UpdateMaintenanceConfigRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    /** Updates compaction configuration (all fields optional). */
    compaction?: UpdateMaintenanceConfigRequestCompaction;
    /** Updates snapshot expiration configuration (all fields optional). */
    snapshotExpiration?: UpdateMaintenanceConfigRequestSnapshotExpiration;
}
export type UpdateMaintenanceConfigResponseCompactionState = "enabled" | "disabled";
export type UpdateMaintenanceConfigResponseCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface UpdateMaintenanceConfigResponseCompaction {
    /** Specifies the state of maintenance operations. */
    state: UpdateMaintenanceConfigResponseCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: UpdateMaintenanceConfigResponseCompactionTargetSizeMb;
}
export type UpdateMaintenanceConfigResponseSnapshotExpirationState = "enabled" | "disabled";
export interface UpdateMaintenanceConfigResponseSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. Format: where unit is d (days), h (hours), m (minutes), or s (seconds). Examples: "7d" (7 days), "48h" (48 hours), "2880m" (2,880 minutes). Defaults to "7d". */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: UpdateMaintenanceConfigResponseSnapshotExpirationState;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateMaintenanceConfigResponse {
    /** Configures compaction for catalog maintenance. */
    compaction?: UpdateMaintenanceConfigResponseCompaction | null;
    /** Scheduling interval between normal table maintenance runs. */
    interval?: string | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: UpdateMaintenanceConfigResponseSnapshotExpiration | null;
}
export type UpdateNamespacesTablesMaintenanceConfigRequestCompactionState = "enabled" | "disabled";
export type UpdateNamespacesTablesMaintenanceConfigRequestCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface UpdateNamespacesTablesMaintenanceConfigRequestCompaction {
    /** Specifies the state of maintenance operations. */
    state?: UpdateNamespacesTablesMaintenanceConfigRequestCompactionState | (string & {});
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb?: UpdateNamespacesTablesMaintenanceConfigRequestCompactionTargetSizeMb | (string & {});
}
export type UpdateNamespacesTablesMaintenanceConfigRequestSnapshotExpirationState = "enabled" | "disabled";
export interface UpdateNamespacesTablesMaintenanceConfigRequestSnapshotExpiration {
    /** Updates the maximum age for snapshots optionally. */
    maxSnapshotAge?: string;
    /** Updates the minimum number of snapshots to retain optionally. */
    minSnapshotsToKeep?: number;
    /** Specifies the state of maintenance operations. */
    state?: UpdateNamespacesTablesMaintenanceConfigRequestSnapshotExpirationState | (string & {});
}
export interface UpdateNamespacesTablesMaintenanceConfigRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    namespace: string;
    tableName: string;
    /** Updates table compaction configuration; all fields are optional. */
    compaction?: UpdateNamespacesTablesMaintenanceConfigRequestCompaction;
    /** Updates snapshot expiration configuration (all fields optional). */
    snapshotExpiration?: UpdateNamespacesTablesMaintenanceConfigRequestSnapshotExpiration;
}
export type UpdateNamespacesTablesMaintenanceConfigResponseCompactionState = "enabled" | "disabled";
export type UpdateNamespacesTablesMaintenanceConfigResponseCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface UpdateNamespacesTablesMaintenanceConfigResponseCompaction {
    /** Specifies the state of maintenance operations. */
    state: UpdateNamespacesTablesMaintenanceConfigResponseCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: UpdateNamespacesTablesMaintenanceConfigResponseCompactionTargetSizeMb;
    /** Earliest time when the scheduler can claim this operation. Null when disabled. */
    nextEligibleAt?: string | null;
}
export type UpdateNamespacesTablesMaintenanceConfigResponseSnapshotExpirationState = "enabled" | "disabled";
export interface UpdateNamespacesTablesMaintenanceConfigResponseSnapshotExpiration {
    /** Specifies the maximum age for snapshots. */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: UpdateNamespacesTablesMaintenanceConfigResponseSnapshotExpirationState;
    /** Earliest time when the scheduler can claim this operation. Null when disabled. */
    nextEligibleAt?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateNamespacesTablesMaintenanceConfigResponse {
    /** Configures compaction settings for table optimization. */
    compaction?: UpdateNamespacesTablesMaintenanceConfigResponseCompaction | null;
    /** Scheduling interval between normal table maintenance runs. */
    interval?: string | null;
    snapshotExpiration?: UpdateNamespacesTablesMaintenanceConfigResponseSnapshotExpiration | null;
}
export type CreateCredentialsError = CloudflareOpError;
/** Store authentication credentials for a catalog. These credentials are used to authenticate with R2 storage when performing catalog operations. */
export declare const createCredentials: API.OperationMethod<CreateCredentialsRequest, CreateCredentialsResponse, CreateCredentialsError, CloudflareOpContext>;
export type DeleteError = CloudflareOpError;
/** Removes the catalog from the control plane without deleting R2 bucket objects. Set force=true to remove catalog namespaces, tables, views, and maintenance metadata. Force deletion is limited to a configured catalog object count. */
export declare const Delete: API.OperationMethod<DeleteRequest, DeleteResponse, DeleteError, CloudflareOpContext>;
export type DisableError = CloudflareOpError;
/** Disable an R2 bucket as a catalog. This operation deactivates the catalog but preserves existing metadata and data files. The catalog can be re-enabled later. */
export declare const disable: API.OperationMethod<DisableRequest, DisableResponse, DisableError, CloudflareOpContext>;
export type EnableError = CloudflareOpError;
/** Enable an R2 bucket as an Apache Iceberg catalog. This operation creates the necessary catalog infrastructure and activates the bucket for storing Iceberg metadata and data files. */
export declare const enable: API.OperationMethod<EnableRequest, EnableResponse, EnableError, CloudflareOpContext>;
export type GetError = CloudflareOpError;
/** Retrieve detailed information about a specific Basin Catalog by bucket name. Returns catalog status, maintenance configuration, and credential status. */
export declare const get: API.OperationMethod<GetRequest, GetResponse, GetError, CloudflareOpContext>;
export type GetMaintenanceConfigError = CloudflareOpError;
/** Retrieve the maintenance configuration for a specific catalog, including compaction settings and credential status. */
export declare const getMaintenanceConfig: API.OperationMethod<GetMaintenanceConfigRequest, GetMaintenanceConfigResponse, GetMaintenanceConfigError, CloudflareOpContext>;
export type GetNamespacesTablesMaintenanceConfigError = CloudflareOpError;
/** Retrieve the maintenance configuration for a specific table, including compaction settings. */
export declare const getNamespacesTablesMaintenanceConfig: API.OperationMethod<GetNamespacesTablesMaintenanceConfigRequest, GetNamespacesTablesMaintenanceConfigResponse, GetNamespacesTablesMaintenanceConfigError, CloudflareOpContext>;
export type ListError = CloudflareOpError;
/** Returns a list of R2 buckets that have been enabled as Apache Iceberg catalogs for the specified account. Each catalog represents an R2 bucket configured to store Iceberg metadata and data files. */
export declare const list: API.OperationMethod<ListRequest, ListResponse, ListError, CloudflareOpContext>;
export type ListNamespacesError = CloudflareOpError;
/** Returns a list of namespaces in the specified Basin Catalog. Supports hierarchical filtering and pagination for efficient traversal of large namespace hierarchies. */
export declare const listNamespaces: API.OperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, CloudflareOpContext>;
export type ListNamespacesTablesError = CloudflareOpError;
/** Returns a list of tables in the specified namespace within a Basin Catalog. Supports pagination for efficient traversal of large table collections. */
export declare const listNamespacesTables: API.OperationMethod<ListNamespacesTablesRequest, ListNamespacesTablesResponse, ListNamespacesTablesError, CloudflareOpContext>;
export type UpdateMaintenanceConfigError = CloudflareOpError;
/** Update the maintenance configuration for a catalog. This allows you to enable or disable compaction and adjust target file sizes for optimization. */
export declare const updateMaintenanceConfig: API.OperationMethod<UpdateMaintenanceConfigRequest, UpdateMaintenanceConfigResponse, UpdateMaintenanceConfigError, CloudflareOpContext>;
export type UpdateNamespacesTablesMaintenanceConfigError = CatalogSnapshotExpirationDisabled | CloudflareOpError;
/** Update the maintenance configuration for a specific table. This allows you to enable or disable compaction and adjust target file sizes for optimization. */
export declare const updateNamespacesTablesMaintenanceConfig: API.OperationMethod<UpdateNamespacesTablesMaintenanceConfigRequest, UpdateNamespacesTablesMaintenanceConfigResponse, UpdateNamespacesTablesMaintenanceConfigError, CloudflareOpContext>;
//# sourceMappingURL=basin_catalog.d.ts.map