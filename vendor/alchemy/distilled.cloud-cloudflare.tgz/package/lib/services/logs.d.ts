import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CmbConfigNotFound_base: S.TaggedErrorClass<"CmbConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CmbConfigNotFound extends /*@__PURE__*/ CmbConfigNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const LogsControlNotAuthorized_base: S.TaggedErrorClass<"LogsControlNotAuthorized", {
    readonly code: any;
    readonly message: any;
}>;
export declare class LogsControlNotAuthorized extends /*@__PURE__*/ LogsControlNotAuthorized_base {
}
export interface CreateControlCmbConfigRequest {
    /** Identifier. */
    accountId: string;
    /** Allow out of region access */
    allowOutOfRegionAccess?: boolean;
    /** Name of the region. */
    regions?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateControlCmbConfigResponse {
    /** Allow out of region access */
    allowOutOfRegionAccess?: boolean | null;
    /** Name of the region. */
    regions?: string | null;
}
export interface CreateControlRetentionRequest {
    /** Identifier. */
    zoneId: string;
    /** The log retention flag for Logpull API. */
    flag?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateControlRetentionResponse {
    /** The log retention flag for Logpull API. */
    flag?: boolean | null;
}
export interface LogExplorerDatasetsCreateRequestFieldsItem {
    /** Whether the API includes this field in log ingest. */
    enabled: boolean;
    /** Field name in lowercase. */
    name: string;
}
export type LogExplorerDatasetsCreateRequestFieldsList = Array<LogExplorerDatasetsCreateRequestFieldsItem>;
export interface CreateLogExplorerDatasetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Dataset type name to create (e.g. `http_requests`). */
    dataset: string;
    /** Controls which fields the API ingests. Defaults to all available fields when absent. */
    fields?: LogExplorerDatasetsCreateRequestFieldsList;
    /** Optional Logpush filter predicate to restrict which events are ingested. See [Logpush filters](https://developers.cloudflare.com/logs/reference/filters/) for syntax and examples. */
    filter?: string;
    /** Whether to filter attack traffic from the Logpush job. Defaults to `true` for supported datasets when omitted. Supported datasets are `http_requests`, `firewall_events`, and `network_analytics_logs`. */
    filterAttackTraffic?: boolean;
}
export type LogExplorerDatasetsCreateResponseFieldsItem = LogExplorerDatasetsCreateRequestFieldsItem;
export type LogExplorerDatasetsCreateResponseFieldsList = Array<LogExplorerDatasetsCreateRequestFieldsItem>;
export type LogExplorerDatasetsCreateResponseObjectType = "account" | "zone";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLogExplorerDatasetResponse {
    /** RFC3339 timestamp recording when the API created this dataset. */
    createdAt: string;
    /** Dataset type name (e.g. `http_requests`). */
    dataset: string;
    /** Unique dataset ID. */
    datasetId: string;
    /** Whether deletion is blocked. Set to `false` before deleting the dataset. */
    deletionProtection: boolean;
    /** Whether log ingest is currently active for this dataset. */
    enabled: boolean;
    /** The field configuration for this dataset. */
    fields: LogExplorerDatasetsCreateResponseFieldsList;
    /** Public ID of the account or zone that owns this dataset. */
    objectId: string;
    /** Whether this dataset belongs to an account or a zone. */
    objectType: LogExplorerDatasetsCreateResponseObjectType;
    /** RFC3339 timestamp recording when the API last updated this dataset. */
    updatedAt: string;
    /** The Logpush filter predicate applied to this dataset. Omitted when no filter is set. */
    filter?: string | null;
    /** Whether the Logpush job filters attack traffic. Omitted for datasets that do not support this option. */
    filterAttackTraffic?: boolean | null;
}
export interface CreateLogExplorerDatasetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Dataset type name to create (e.g. `http_requests`). */
    dataset: string;
    /** Controls which fields the API ingests. Defaults to all available fields when absent. */
    fields?: LogExplorerDatasetsCreateRequestFieldsList;
    /** Optional Logpush filter predicate to restrict which events are ingested. See [Logpush filters](https://developers.cloudflare.com/logs/reference/filters/) for syntax and examples. */
    filter?: string;
    /** Whether to filter attack traffic from the Logpush job. Defaults to `true` for supported datasets when omitted. Supported datasets are `http_requests`, `firewall_events`, and `network_analytics_logs`. */
    filterAttackTraffic?: boolean;
}
export interface DeleteControlCmbConfigRequest {
    /** Identifier. */
    accountId: string;
}
export type DeleteControlCmbConfigResponse = unknown;
export interface GetControlCmbConfigRequest {
    /** Identifier. */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetControlCmbConfigResponse {
    /** Allow out of region access */
    allowOutOfRegionAccess?: boolean | null;
    /** Name of the region. */
    regions?: string | null;
}
export interface GetControlRetentionRequest {
    /** Identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetControlRetentionResponse {
    /** The log retention flag for Logpull API. */
    flag?: boolean | null;
}
export interface GetLogExplorerDatasetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    datasetId: string;
}
export type LogExplorerDatasetsGetResponseFieldsItem = LogExplorerDatasetsCreateRequestFieldsItem;
export type LogExplorerDatasetsGetResponseFieldsList = Array<LogExplorerDatasetsCreateRequestFieldsItem>;
export type LogExplorerDatasetsGetResponseObjectType = "account" | "zone";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLogExplorerDatasetResponse {
    /** RFC3339 timestamp recording when the API created this dataset. */
    createdAt: string;
    /** Dataset type name (e.g. `http_requests`). */
    dataset: string;
    /** Unique dataset ID. */
    datasetId: string;
    /** Whether deletion is blocked. Set to `false` before deleting the dataset. */
    deletionProtection: boolean;
    /** Whether log ingest is currently active for this dataset. */
    enabled: boolean;
    /** The field configuration for this dataset. */
    fields: LogExplorerDatasetsGetResponseFieldsList;
    /** Public ID of the account or zone that owns this dataset. */
    objectId: string;
    /** Whether this dataset belongs to an account or a zone. */
    objectType: LogExplorerDatasetsGetResponseObjectType;
    /** RFC3339 timestamp recording when the API last updated this dataset. */
    updatedAt: string;
    /** The Logpush filter predicate applied to this dataset. Omitted when no filter is set. */
    filter?: string | null;
    /** Whether the Logpush job filters attack traffic. Omitted for datasets that do not support this option. */
    filterAttackTraffic?: boolean | null;
}
export interface GetLogExplorerDatasetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    datasetId: string;
}
export type RayidGetRequestTimestamps = "unix" | "unixnano" | "rfc3339";
export interface GetRayidRequest {
    /** Identifier. */
    zoneId: string;
    /** Ray identifier. */
    rayId: string;
    /** The `/received` route by default returns a limited set of fields, and allows customers to override the default field set by specifying individual fields. The reasons for this are: 1. Most customers require only a small subset of fields, but that subset varies from customer to customer; 2. Flat schema is much easier to work with downstream (importing into BigTable etc); 3. Performance (time to process, file size). If `?fields=` is not specified, default field set is returned. This default field set may change at any time. When `?fields=` is provided, each record is returned with the specified fields. `fields` must be specified as a comma separated list without any whitespaces, and all fields must exist. The order in which fields are specified does not matter, and the order of fields in the response is not specified. */
    fields?: string;
    /** By default, timestamps in responses are returned as Unix nanosecond integers. The `?timestamps=` argument can be set to change the format in which response timestamps are returned. Possible values are: `unix`, `unixnano`, `rfc3339`. Note that `unix` and `unixnano` return timestamps as integers; `rfc3339` returns timestamps as strings. */
    timestamps?: RayidGetRequestTimestamps | (string & {});
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetRayidResponse {
}
export type ReceivedGetRequestTimestamps = "unix" | "unixnano" | "rfc3339";
export interface GetReceivedRequest {
    /** Identifier. */
    zoneId: string;
    /** Sets the (exclusive) end of the requested time frame. This can be a unix timestamp (in seconds or nanoseconds), or an absolute timestamp that conforms to RFC 3339. `end` must be at least five minutes earlier than now and must be later than `start`. Difference between `start` and `end` must be not greater than one hour. */
    end: string;
    /** When `?count=` is provided, the response will contain up to `count` results. Since results are not sorted, you are likely to get different data for repeated requests. `count` must be an integer > 0. */
    count?: number;
    /** The `/received` route by default returns a limited set of fields, and allows customers to override the default field set by specifying individual fields. The reasons for this are: 1. Most customers require only a small subset of fields, but that subset varies from customer to customer; 2. Flat schema is much easier to work with downstream (importing into BigTable etc); 3. Performance (time to process, file size). If `?fields=` is not specified, default field set is returned. This default field set may change at any time. When `?fields=` is provided, each record is returned with the specified fields. `fields` must be specified as a comma separated list without any whitespaces, and all fields must exist. The order in which fields are specified does not matter, and the order of fields in the response is not specified. */
    fields?: string;
    /** When `?sample=` is provided, a sample of matching records is returned. If `sample=0.1` then 10% of records will be returned. Sampling is random: repeated calls will not only return different records, but likely will also vary slightly in number of returned records. When `?count=` is also specified, `count` is applied to the number of returned records, not the sampled records. So, with `sample=0.05` and `count=7`, when there is a total of 100 records available, approximately five will be returned. When there are 1000 records, seven will be returned. When there are 10,000 records, seven will be returned. */
    sample?: number;
    /** Sets the (inclusive) beginning of the requested time frame. This can be a unix timestamp (in seconds or nanoseconds), or an absolute timestamp that conforms to RFC 3339. At this point in time, it cannot exceed a time in the past greater than seven days. */
    start?: string;
    /** By default, timestamps in responses are returned as Unix nanosecond integers. The `?timestamps=` argument can be set to change the format in which response timestamps are returned. Possible values are: `unix`, `unixnano`, `rfc3339`. Note that `unix` and `unixnano` return timestamps as integers; `rfc3339` returns timestamps as strings. */
    timestamps?: ReceivedGetRequestTimestamps | (string & {});
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetReceivedResponse {
}
export interface GetReceivedFieldRequest {
    /** Identifier. */
    zoneId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetReceivedFieldResponse {
    key?: string | null;
}
export interface ListLogExplorerDatasetAvailablesForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
}
export type LogExplorerDatasetsAvailableListResultItemObjectType = "account" | "zone";
export type LogExplorerDatasetsAvailableListResultItemSchemaPropertiesMap = {
    [key: string]: unknown | undefined;
};
export type LogExplorerDatasetsAvailableListResultItemSchemaRequiredList = Array<string>;
export type LogExplorerDatasetsAvailableListResultItemSchemaType = "object";
export interface LogExplorerDatasetsAvailableListResultItemSchema {
    properties?: LogExplorerDatasetsAvailableListResultItemSchemaPropertiesMap | null;
    required?: LogExplorerDatasetsAvailableListResultItemSchemaRequiredList | null;
    type?: LogExplorerDatasetsAvailableListResultItemSchemaType | null;
}
export interface LogExplorerDatasetsAvailableListResultItem {
    /** Dataset type name (e.g. `http_requests`). */
    dataset: string;
    /** Whether this dataset type is account-scoped or zone-scoped. */
    objectType: LogExplorerDatasetsAvailableListResultItemObjectType;
    /** JSON Schema that describes the fields this dataset exposes. */
    schema: LogExplorerDatasetsAvailableListResultItemSchema;
    /** The primary timestamp field name for this dataset. */
    timestampField: string;
}
export type LogExplorerDatasetsAvailableListResultList = Array<LogExplorerDatasetsAvailableListResultItem>;
export interface ListLogExplorerDatasetAvailablesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogExplorerDatasetsAvailableListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListLogExplorerDatasetAvailablesForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
}
export interface ListLogExplorerDatasetsForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Set to true to include zone-scoped datasets belonging to this account. */
    includeZones?: boolean;
}
export type LogExplorerDatasetsListResultItemObjectType = "account" | "zone";
export interface LogExplorerDatasetsListResultItem {
    /** RFC3339 timestamp recording when the API created this dataset. */
    createdAt: string;
    /** Dataset type name (e.g. `http_requests`). */
    dataset: string;
    /** Unique dataset ID. */
    datasetId: string;
    /** Whether deletion is blocked. Set to `false` before deleting the dataset. */
    deletionProtection: boolean;
    /** Whether log ingest is currently active for this dataset. */
    enabled: boolean;
    /** Public ID of the account or zone that owns this dataset. */
    objectId: string;
    /** Whether this dataset belongs to an account or a zone. */
    objectType: LogExplorerDatasetsListResultItemObjectType;
    /** RFC3339 timestamp recording when the API last updated this dataset. */
    updatedAt: string;
}
export type LogExplorerDatasetsListResultList = Array<LogExplorerDatasetsListResultItem>;
export interface ListLogExplorerDatasetsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogExplorerDatasetsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListLogExplorerDatasetsForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Set to true to include zone-scoped datasets belonging to this account. */
    includeZones?: boolean;
}
export interface LogExplorerDatasetsDeleteForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    datasetId: string;
}
export type LogExplorerDatasetsDeleteResponseFieldsItem = LogExplorerDatasetsCreateRequestFieldsItem;
export type LogExplorerDatasetsDeleteResponseFieldsList = Array<LogExplorerDatasetsCreateRequestFieldsItem>;
export type LogExplorerDatasetsDeleteResponseObjectType = "account" | "zone";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface LogExplorerDatasetsDeleteResponse {
    /** RFC3339 timestamp recording when the API created this dataset. */
    createdAt: string;
    /** Dataset type name (e.g. `http_requests`). */
    dataset: string;
    /** Unique dataset ID. */
    datasetId: string;
    /** Whether deletion is blocked. Set to `false` before deleting the dataset. */
    deletionProtection: boolean;
    /** Whether log ingest is currently active for this dataset. */
    enabled: boolean;
    /** The field configuration for this dataset. */
    fields: LogExplorerDatasetsDeleteResponseFieldsList;
    /** Public ID of the account or zone that owns this dataset. */
    objectId: string;
    /** Whether this dataset belongs to an account or a zone. */
    objectType: LogExplorerDatasetsDeleteResponseObjectType;
    /** RFC3339 timestamp recording when the API last updated this dataset. */
    updatedAt: string;
    /** The Logpush filter predicate applied to this dataset. Omitted when no filter is set. */
    filter?: string | null;
    /** Whether the Logpush job filters attack traffic. Omitted for datasets that do not support this option. */
    filterAttackTraffic?: boolean | null;
}
export interface LogExplorerDatasetsDeleteForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    datasetId: string;
}
export interface SqlLogExplorerQueryForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
}
export type LogExplorerQuerySqlResultItemMap = {
    [key: string]: unknown | undefined;
};
export type LogExplorerQuerySqlResultList = Array<LogExplorerQuerySqlResultItemMap>;
export interface SqlLogExplorerQueryResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogExplorerQuerySqlResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface SqlLogExplorerQueryForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
}
export type LogExplorerDatasetsUpdateRequestFieldsItem = LogExplorerDatasetsCreateRequestFieldsItem;
export type LogExplorerDatasetsUpdateRequestFieldsList = Array<LogExplorerDatasetsCreateRequestFieldsItem>;
export interface UpdateLogExplorerDatasetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    datasetId: string;
    /** Whether to enable or disable log ingest for this dataset. */
    enabled: boolean;
    /** Set to `false` to allow deletion of this dataset. */
    deletionProtection?: boolean;
    /** Controls which fields the API ingests after the update. Defaults to all available fields when absent. */
    fields?: LogExplorerDatasetsUpdateRequestFieldsList;
    /** Optional Logpush filter predicate to restrict which events are ingested. If omitted, the existing filter is left unchanged. Set to an empty string (`""`) to clear the filter. Otherwise, replaces the dataset's filter entirely. See [Logpush filters](https://developers.cloudflare.com/logs/reference/filters/) for syntax and examples. */
    filter?: string;
    /** Whether to filter attack traffic from the Logpush job. If omitted, the existing setting is left unchanged. Supported datasets are `http_requests`, `firewall_events`, and `network_analytics_logs`. */
    filterAttackTraffic?: boolean;
}
export type LogExplorerDatasetsUpdateResponseFieldsItem = LogExplorerDatasetsCreateRequestFieldsItem;
export type LogExplorerDatasetsUpdateResponseFieldsList = Array<LogExplorerDatasetsCreateRequestFieldsItem>;
export type LogExplorerDatasetsUpdateResponseObjectType = "account" | "zone";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateLogExplorerDatasetResponse {
    /** RFC3339 timestamp recording when the API created this dataset. */
    createdAt: string;
    /** Dataset type name (e.g. `http_requests`). */
    dataset: string;
    /** Unique dataset ID. */
    datasetId: string;
    /** Whether deletion is blocked. Set to `false` before deleting the dataset. */
    deletionProtection: boolean;
    /** Whether log ingest is currently active for this dataset. */
    enabled: boolean;
    /** The field configuration for this dataset. */
    fields: LogExplorerDatasetsUpdateResponseFieldsList;
    /** Public ID of the account or zone that owns this dataset. */
    objectId: string;
    /** Whether this dataset belongs to an account or a zone. */
    objectType: LogExplorerDatasetsUpdateResponseObjectType;
    /** RFC3339 timestamp recording when the API last updated this dataset. */
    updatedAt: string;
    /** The Logpush filter predicate applied to this dataset. Omitted when no filter is set. */
    filter?: string | null;
    /** Whether the Logpush job filters attack traffic. Omitted for datasets that do not support this option. */
    filterAttackTraffic?: boolean | null;
}
export interface UpdateLogExplorerDatasetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    datasetId: string;
    /** Whether to enable or disable log ingest for this dataset. */
    enabled: boolean;
    /** Set to `false` to allow deletion of this dataset. */
    deletionProtection?: boolean;
    /** Controls which fields the API ingests after the update. Defaults to all available fields when absent. */
    fields?: LogExplorerDatasetsUpdateRequestFieldsList;
    /** Optional Logpush filter predicate to restrict which events are ingested. If omitted, the existing filter is left unchanged. Set to an empty string (`""`) to clear the filter. Otherwise, replaces the dataset's filter entirely. See [Logpush filters](https://developers.cloudflare.com/logs/reference/filters/) for syntax and examples. */
    filter?: string;
    /** Whether to filter attack traffic from the Logpush job. If omitted, the existing setting is left unchanged. Supported datasets are `http_requests`, `firewall_events`, and `network_analytics_logs`. */
    filterAttackTraffic?: boolean;
}
export type CreateControlCmbConfigError = LogsControlNotAuthorized | Forbidden | CloudflareOpError;
/** Updates CMB config. */
export declare const createControlCmbConfig: API.OperationMethod<CreateControlCmbConfigRequest, CreateControlCmbConfigResponse, CreateControlCmbConfigError, CloudflareOpContext>;
export type CreateControlRetentionError = LogsControlNotAuthorized | Forbidden | CloudflareOpError;
/** Updates log retention flag for Logpull API. */
export declare const createControlRetention: API.OperationMethod<CreateControlRetentionRequest, CreateControlRetentionResponse, CreateControlRetentionError, CloudflareOpContext>;
export type CreateLogExplorerDatasetForAccountError = CloudflareOpError;
/** Create a new Log Explorer dataset for the account or zone. List available account or zone datasets to see the dataset types and fields you can use. The `fields` property is optional. If not specified, all available fields will be enabled. For dataset field definitions, see: https://developers.cloudflare.com/logs/logpush/logpush-job/datasets/ */
export declare const createLogExplorerDatasetForAccount: API.OperationMethod<CreateLogExplorerDatasetForAccountRequest, CreateLogExplorerDatasetResponse, CreateLogExplorerDatasetForAccountError, CloudflareOpContext>;
export type CreateLogExplorerDatasetForZoneError = CloudflareOpError;
/** Create a new Log Explorer dataset for the account or zone. List available account or zone datasets to see the dataset types and fields you can use. The `fields` property is optional. If not specified, all available fields will be enabled. For dataset field definitions, see: https://developers.cloudflare.com/logs/logpush/logpush-job/datasets/ */
export declare const createLogExplorerDatasetForZone: API.OperationMethod<CreateLogExplorerDatasetForZoneRequest, CreateLogExplorerDatasetResponse, CreateLogExplorerDatasetForZoneError, CloudflareOpContext>;
export type DeleteControlCmbConfigError = LogsControlNotAuthorized | CmbConfigNotFound | Forbidden | CloudflareOpError;
/** Deletes CMB config. */
export declare const deleteControlCmbConfig: API.OperationMethod<DeleteControlCmbConfigRequest, DeleteControlCmbConfigResponse, DeleteControlCmbConfigError, CloudflareOpContext>;
export type GetControlCmbConfigError = LogsControlNotAuthorized | CmbConfigNotFound | Forbidden | CloudflareOpError;
/** Gets CMB config. */
export declare const getControlCmbConfig: API.OperationMethod<GetControlCmbConfigRequest, GetControlCmbConfigResponse, GetControlCmbConfigError, CloudflareOpContext>;
export type GetControlRetentionError = LogsControlNotAuthorized | Forbidden | CloudflareOpError;
/** Gets log retention flag for Logpull API. */
export declare const getControlRetention: API.OperationMethod<GetControlRetentionRequest, GetControlRetentionResponse, GetControlRetentionError, CloudflareOpContext>;
export type GetLogExplorerDatasetForAccountError = CloudflareOpError;
/** Retrieve a single Log Explorer dataset by ID for the account or zone. */
export declare const getLogExplorerDatasetForAccount: API.OperationMethod<GetLogExplorerDatasetForAccountRequest, GetLogExplorerDatasetResponse, GetLogExplorerDatasetForAccountError, CloudflareOpContext>;
export type GetLogExplorerDatasetForZoneError = CloudflareOpError;
/** Retrieve a single Log Explorer dataset by ID for the account or zone. */
export declare const getLogExplorerDatasetForZone: API.OperationMethod<GetLogExplorerDatasetForZoneRequest, GetLogExplorerDatasetResponse, GetLogExplorerDatasetForZoneError, CloudflareOpContext>;
export type GetRayidError = CloudflareOpError;
/** The `/rayids` api route allows lookups by specific rayid. The rayids route will return zero, one, or more records (ray ids are not unique). */
export declare const getRayid: API.OperationMethod<GetRayidRequest, GetRayidResponse, GetRayidError, CloudflareOpContext>;
export type GetReceivedError = CloudflareOpError;
/** The `/received` api route allows customers to retrieve their edge HTTP logs. The basic access pattern is "give me all the logs for zone Z for minute M", where the minute M refers to the time records were received at Cloudflare's central data center. `start` is inclusive, and `end` is exclusive. Because of that, to get all data, at minutely cadence, starting at 10AM, the proper values are: `start=2018-05-20T10:00:00Z&end=2018-05-20T10:01:00Z`, then `start=2018-05-20T10:01:00Z&end=2018-05-20T10:02:00Z` and so on; the overlap will be handled properly. */
export declare const getReceived: API.OperationMethod<GetReceivedRequest, GetReceivedResponse, GetReceivedError, CloudflareOpContext>;
export type GetReceivedFieldError = CloudflareOpError;
/** Lists all fields available. The response is json object with key-value pairs, where keys are field names, and values are descriptions. */
export declare const getReceivedField: API.OperationMethod<GetReceivedFieldRequest, GetReceivedFieldResponse, GetReceivedFieldError, CloudflareOpContext>;
export type ListLogExplorerDatasetAvailablesForAccountError = CloudflareOpError;
/** Returns all dataset types that this account or zone can create. Each entry includes the dataset schema and timestamp field. The schema shows all possible fields for a dataset. However, not all fields may be available for your account or zone. When creating or updating a dataset, only fields available to your account or zone can be enabled. If you request a field that is not available, you will receive an error. */
export declare const listLogExplorerDatasetAvailablesForAccount: API.PaginatedOperationMethod<ListLogExplorerDatasetAvailablesForAccountRequest, ListLogExplorerDatasetAvailablesResponse, ListLogExplorerDatasetAvailablesForAccountError, CloudflareOpContext, LogExplorerDatasetsAvailableListResultItem>;
export type ListLogExplorerDatasetAvailablesForZoneError = CloudflareOpError;
/** Returns all dataset types that this account or zone can create. Each entry includes the dataset schema and timestamp field. The schema shows all possible fields for a dataset. However, not all fields may be available for your account or zone. When creating or updating a dataset, only fields available to your account or zone can be enabled. If you request a field that is not available, you will receive an error. */
export declare const listLogExplorerDatasetAvailablesForZone: API.PaginatedOperationMethod<ListLogExplorerDatasetAvailablesForZoneRequest, ListLogExplorerDatasetAvailablesResponse, ListLogExplorerDatasetAvailablesForZoneError, CloudflareOpContext, LogExplorerDatasetsAvailableListResultItem>;
export type ListLogExplorerDatasetsForAccountError = CloudflareOpError;
/** Returns all Log Explorer datasets configured for the account or zone. Pass `include_zones=true` to also include zone-level datasets that belong to this account or zone. List responses omit the `fields` property; use the single-dataset endpoint to retrieve field configuration. */
export declare const listLogExplorerDatasetsForAccount: API.PaginatedOperationMethod<ListLogExplorerDatasetsForAccountRequest, ListLogExplorerDatasetsResponse, ListLogExplorerDatasetsForAccountError, CloudflareOpContext, LogExplorerDatasetsListResultItem>;
export type ListLogExplorerDatasetsForZoneError = CloudflareOpError;
/** Returns all Log Explorer datasets configured for the account or zone. Pass `include_zones=true` to also include zone-level datasets that belong to this account or zone. List responses omit the `fields` property; use the single-dataset endpoint to retrieve field configuration. */
export declare const listLogExplorerDatasetsForZone: API.PaginatedOperationMethod<ListLogExplorerDatasetsForZoneRequest, ListLogExplorerDatasetsResponse, ListLogExplorerDatasetsForZoneError, CloudflareOpContext, LogExplorerDatasetsListResultItem>;
export type LogExplorerDatasetsDeleteForAccountError = CloudflareOpError;
/** Deletes a Log Explorer dataset for the account or zone. Dataset deletion must not be protected. */
export declare const logExplorerDatasetsDeleteForAccount: API.OperationMethod<LogExplorerDatasetsDeleteForAccountRequest, LogExplorerDatasetsDeleteResponse, LogExplorerDatasetsDeleteForAccountError, CloudflareOpContext>;
export type LogExplorerDatasetsDeleteForZoneError = CloudflareOpError;
/** Deletes a Log Explorer dataset for the account or zone. Dataset deletion must not be protected. */
export declare const logExplorerDatasetsDeleteForZone: API.OperationMethod<LogExplorerDatasetsDeleteForZoneRequest, LogExplorerDatasetsDeleteResponse, LogExplorerDatasetsDeleteForZoneError, CloudflareOpContext>;
export type SqlLogExplorerQueryForAccountError = CloudflareOpError;
/** Run a SQL query against account or zone-level datasets. Timestamp fields are RFC3339 strings. Filter with: WHERE {timestamp_field} >= now() - INTERVAL '30' DAY WHERE {timestamp_field} >= '2026-04-01T00:00:00Z' WHERE {timestamp_field} BETWEEN '2026-04-01T00:00:00Z' AND '2026-04-30T23:59:59Z' List configured account or zone datasets to see enabled account or zone-level datasets. Zone-level datasets will not appear here. List available account or zone datasets to inspect their schemas and timestamp fields. For more information about the datasets, and the meaning of each field, check out https://developers.cloudflare.com/logs/logpush/logpush-job/datasets/ */
export declare const sqlLogExplorerQueryForAccount: API.PaginatedOperationMethod<SqlLogExplorerQueryForAccountRequest, SqlLogExplorerQueryResponse, SqlLogExplorerQueryForAccountError, CloudflareOpContext, LogExplorerQuerySqlResultItemMap>;
export type SqlLogExplorerQueryForZoneError = CloudflareOpError;
/** Run a SQL query against account or zone-level datasets. Timestamp fields are RFC3339 strings. Filter with: WHERE {timestamp_field} >= now() - INTERVAL '30' DAY WHERE {timestamp_field} >= '2026-04-01T00:00:00Z' WHERE {timestamp_field} BETWEEN '2026-04-01T00:00:00Z' AND '2026-04-30T23:59:59Z' List configured account or zone datasets to see enabled account or zone-level datasets. Zone-level datasets will not appear here. List available account or zone datasets to inspect their schemas and timestamp fields. For more information about the datasets, and the meaning of each field, check out https://developers.cloudflare.com/logs/logpush/logpush-job/datasets/ */
export declare const sqlLogExplorerQueryForZone: API.PaginatedOperationMethod<SqlLogExplorerQueryForZoneRequest, SqlLogExplorerQueryResponse, SqlLogExplorerQueryForZoneError, CloudflareOpContext, LogExplorerQuerySqlResultItemMap>;
export type UpdateLogExplorerDatasetForAccountError = CloudflareOpError;
/** Updates the enabled state and/or field configuration of an account or zone dataset. */
export declare const updateLogExplorerDatasetForAccount: API.OperationMethod<UpdateLogExplorerDatasetForAccountRequest, UpdateLogExplorerDatasetResponse, UpdateLogExplorerDatasetForAccountError, CloudflareOpContext>;
export type UpdateLogExplorerDatasetForZoneError = CloudflareOpError;
/** Updates the enabled state and/or field configuration of an account or zone dataset. */
export declare const updateLogExplorerDatasetForZone: API.OperationMethod<UpdateLogExplorerDatasetForZoneRequest, UpdateLogExplorerDatasetResponse, UpdateLogExplorerDatasetForZoneError, CloudflareOpContext>;
//# sourceMappingURL=logs.d.ts.map