import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ConsumerAlreadyExists_base: S.TaggedErrorClass<"ConsumerAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ConsumerAlreadyExists extends /*@__PURE__*/ ConsumerAlreadyExists_base {
}
declare const ConsumerNotFound_base: S.TaggedErrorClass<"ConsumerNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ConsumerNotFound extends /*@__PURE__*/ ConsumerNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidMessageBody_base: S.TaggedErrorClass<"InvalidMessageBody", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidMessageBody extends /*@__PURE__*/ InvalidMessageBody_base {
}
declare const InvalidQueueId_base: S.TaggedErrorClass<"InvalidQueueId", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidQueueId extends /*@__PURE__*/ InvalidQueueId_base {
}
declare const InvalidQueueName_base: S.TaggedErrorClass<"InvalidQueueName", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidQueueName extends /*@__PURE__*/ InvalidQueueName_base {
}
declare const InvalidRequestBody_base: S.TaggedErrorClass<"InvalidRequestBody", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRequestBody extends /*@__PURE__*/ InvalidRequestBody_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const QueueAlreadyExists_base: S.TaggedErrorClass<"QueueAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class QueueAlreadyExists extends /*@__PURE__*/ QueueAlreadyExists_base {
}
declare const QueueHandlerMissing_base: S.TaggedErrorClass<"QueueHandlerMissing", {
    readonly code: any;
    readonly message: any;
}>;
export declare class QueueHandlerMissing extends /*@__PURE__*/ QueueHandlerMissing_base {
}
declare const QueueHttpPullNotEnabled_base: S.TaggedErrorClass<"QueueHttpPullNotEnabled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class QueueHttpPullNotEnabled extends /*@__PURE__*/ QueueHttpPullNotEnabled_base {
}
declare const QueueInUseByEventNotification_base: S.TaggedErrorClass<"QueueInUseByEventNotification", {
    readonly code: any;
    readonly message: any;
}>;
export declare class QueueInUseByEventNotification extends /*@__PURE__*/ QueueInUseByEventNotification_base {
}
declare const QueueInUseByWorkerBinding_base: S.TaggedErrorClass<"QueueInUseByWorkerBinding", {
    readonly code: any;
    readonly message: any;
}>;
export declare class QueueInUseByWorkerBinding extends /*@__PURE__*/ QueueInUseByWorkerBinding_base {
}
declare const QueueNotFound_base: S.TaggedErrorClass<"QueueNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class QueueNotFound extends /*@__PURE__*/ QueueNotFound_base {
}
declare const SubscriptionAlreadyExists_base: S.TaggedErrorClass<"SubscriptionAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SubscriptionAlreadyExists extends /*@__PURE__*/ SubscriptionAlreadyExists_base {
}
declare const SubscriptionNotFound_base: S.TaggedErrorClass<"SubscriptionNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SubscriptionNotFound extends /*@__PURE__*/ SubscriptionNotFound_base {
}
declare const UnrecognizedEventType_base: S.TaggedErrorClass<"UnrecognizedEventType", {
    readonly code: any;
    readonly message: any;
}>;
export declare class UnrecognizedEventType extends /*@__PURE__*/ UnrecognizedEventType_base {
}
declare const WorkerNotFound_base: S.TaggedErrorClass<"WorkerNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WorkerNotFound extends /*@__PURE__*/ WorkerNotFound_base {
}
export interface MessagesAckRequestAcksItem {
    /** An ID that represents an "in-flight" message that has been pulled from a Queue. You must hold on to this ID and use it to acknowledge this message. */
    leaseId?: string;
}
export type MessagesAckRequestAcksList = Array<MessagesAckRequestAcksItem>;
export interface MessagesAckRequestRetriesItem {
    /** The number of seconds to delay before making the message available for another attempt. */
    delaySeconds?: number;
    /** An ID that represents an "in-flight" message that has been pulled from a Queue. You must hold on to this ID and use it to acknowledge this message. */
    leaseId?: string;
}
export type MessagesAckRequestRetriesList = Array<MessagesAckRequestRetriesItem>;
export interface AckMessageRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    acks?: MessagesAckRequestAcksList;
    retries?: MessagesAckRequestRetriesList;
}
export type MessagesAckResponseWarningsMap = {
    [key: string]: string | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface AckMessageResponse {
    /** The number of messages that were succesfully acknowledged. */
    ackCount?: number | null;
    /** The number of messages that were succesfully retried. */
    retryCount?: number | null;
    /** Map of lease IDs to warning messages encountered during acknowledgement. */
    warnings?: MessagesAckResponseWarningsMap | null;
}
export type MessagesBulkPushRequestMessagesItemMqQueueMessageTextContentType = "text";
export interface MessagesBulkPushRequestMessagesItemMqQueueMessageText {
    body?: string;
    contentType?: MessagesBulkPushRequestMessagesItemMqQueueMessageTextContentType | (string & {});
    /** The number of seconds to wait for attempting to deliver this message to consumers */
    delaySeconds?: number;
}
export type MessagesBulkPushRequestMessagesItemMqQueueMessageJsonContentType = "json";
export interface MessagesBulkPushRequestMessagesItemMqQueueMessageJson {
    body?: unknown;
    contentType?: MessagesBulkPushRequestMessagesItemMqQueueMessageJsonContentType | (string & {});
    /** The number of seconds to wait for attempting to deliver this message to consumers */
    delaySeconds?: number;
}
export type MessagesBulkPushRequestMessagesItem = MessagesBulkPushRequestMessagesItemMqQueueMessageText | MessagesBulkPushRequestMessagesItemMqQueueMessageJson;
export type MessagesBulkPushRequestMessagesList = Array<MessagesBulkPushRequestMessagesItem>;
export interface BulkPushMessagesRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** The number of seconds to wait for attempting to deliver this batch to consumers */
    delaySeconds?: number;
    messages?: MessagesBulkPushRequestMessagesList;
}
export interface MessagesBulkPushResponseMetadataMetrics {
    /** The size in bytes of unacknowledged messages in the queue. */
    backlogBytes: number;
    /** The number of unacknowledged messages in the queue. */
    backlogCount: number;
    /** Unix timestamp in milliseconds of the oldest unacknowledged message in the queue. Returns 0 if unknown. */
    oldestMessageTimestampMs: number;
}
export interface MessagesBulkPushResponseMetadata {
    /** Best-effort metrics for the queue. Values may be approximate due to the distributed nature of queues. */
    metrics?: MessagesBulkPushResponseMetadataMetrics | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPushMessagesResponse {
    metadata?: MessagesBulkPushResponseMetadata | null;
}
export type ConsumersCreateRequestType = "worker" | "http_pull";
export interface ConsumersCreateRequestSettingsWorker {
    /** The maximum number of messages to include in a batch. */
    batchSize?: number;
    /** Maximum number of concurrent consumers that may consume from this Queue. Set to `null` to automatically opt in to the platform's maximum (recommended). */
    maxConcurrency?: number;
    /** The maximum number of retries */
    maxRetries?: number;
    /** The number of milliseconds to wait for a batch to fill up before attempting to deliver it */
    maxWaitTimeMs?: number;
    /** The number of seconds to delay before making the message available for another attempt. */
    retryDelay?: number;
}
export interface ConsumersCreateRequestSettingsHTTPPull {
    /** The maximum number of messages to include in a batch. */
    batchSize?: number;
    /** The maximum number of retries */
    maxRetries?: number;
    /** The number of seconds to delay before making the message available for another attempt. */
    retryDelay?: number;
    /** The number of milliseconds that a message is exclusively leased. After the timeout, the message becomes available for another attempt. */
    visibilityTimeoutMs?: number;
}
export type ConsumersCreateRequestSettings = ConsumersCreateRequestSettingsWorker | ConsumersCreateRequestSettingsHTTPPull;
export interface CreateConsumerRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** Name of a Worker */
    scriptName?: string;
    type: ConsumersCreateRequestType | (string & {});
    deadLetterQueue?: string;
    settings?: ConsumersCreateRequestSettings;
}
export interface ConsumersCreateResultWorkerSettings {
    /** The maximum number of messages to include in a batch. */
    batchSize?: number | null;
    /** Maximum number of concurrent consumers that may consume from this Queue. Set to `null` to automatically opt in to the platform's maximum (recommended). */
    maxConcurrency?: number | null;
    /** The maximum number of retries */
    maxRetries?: number | null;
    /** The number of milliseconds to wait for a batch to fill up before attempting to deliver it */
    maxWaitTimeMs?: number | null;
    /** The number of seconds to delay before making the message available for another attempt. */
    retryDelay?: number | null;
}
export type ConsumersCreateResultWorkerType = "worker";
export interface ConsumersCreateResultWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: ConsumersCreateResultWorkerType | null;
}
export interface ConsumersCreateResultHTTPPullSettings {
    /** The maximum number of messages to include in a batch. */
    batchSize?: number | null;
    /** The maximum number of retries */
    maxRetries?: number | null;
    /** The number of seconds to delay before making the message available for another attempt. */
    retryDelay?: number | null;
    /** The number of milliseconds that a message is exclusively leased. After the timeout, the message becomes available for another attempt. */
    visibilityTimeoutMs?: number | null;
}
export type ConsumersCreateResultHTTPPullType = "http_pull";
export interface ConsumersCreateResultHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: ConsumersCreateResultHTTPPullType | null;
}
export type ConsumersCreateResult = ConsumersCreateResultWorker | ConsumersCreateResultHTTPPull;
export type CreateConsumerResponse = ConsumersCreateResult;
export type CreateRequestJurisdiction = "eu" | "us" | "fedramp";
export interface CreateQueueRequest {
    /** A Resource identifier. */
    accountId: string;
    queueName: string;
    jurisdiction?: CreateRequestJurisdiction | (string & {});
}
export type CreateResponseConsumersItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export type CreateResponseConsumersItemWorkerType = "worker";
export interface CreateResponseConsumersItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: CreateResponseConsumersItemWorkerType | null;
}
export type CreateResponseConsumersItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export type CreateResponseConsumersItemHTTPPullType = "http_pull";
export interface CreateResponseConsumersItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: CreateResponseConsumersItemHTTPPullType | null;
}
export type CreateResponseConsumersItem = CreateResponseConsumersItemWorker | CreateResponseConsumersItemHTTPPull;
export type CreateResponseConsumersList = Array<CreateResponseConsumersItem>;
export type CreateResponseJurisdiction = "eu" | "us" | "fedramp";
export type CreateResponseProducersItemMqWorkerProducerType = "worker";
export interface CreateResponseProducersItemMqWorkerProducer {
    type?: CreateResponseProducersItemMqWorkerProducerType | null;
    scriptName?: string | null;
}
export type CreateResponseProducersItemMqR2ProducerType = "r2_bucket";
export interface CreateResponseProducersItemMqR2Producer {
    bucketName?: string | null;
    type?: CreateResponseProducersItemMqR2ProducerType | null;
}
export type CreateResponseProducersItem = CreateResponseProducersItemMqWorkerProducer | CreateResponseProducersItemMqR2Producer;
export type CreateResponseProducersList = Array<CreateResponseProducersItem>;
export interface CreateResponseSettings {
    /** Number of seconds to delay delivery of all messages to consumers. */
    deliveryDelay?: number | null;
    /** Indicates if message delivery to consumers is currently paused. */
    deliveryPaused?: boolean | null;
    /** Number of seconds after which an unconsumed message will be delayed. */
    messageRetentionPeriod?: number | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateQueueResponse {
    consumers?: CreateResponseConsumersList | null;
    consumersTotalCount?: number | null;
    createdOn?: string | null;
    jurisdiction?: CreateResponseJurisdiction | null;
    modifiedOn?: string | null;
    producers?: CreateResponseProducersList | null;
    producersTotalCount?: number | null;
    queueId?: string | null;
    queueName?: string | null;
    settings?: CreateResponseSettings | null;
}
export type SubscriptionsCreateRequestDestinationType = "queues.queue";
export interface SubscriptionsCreateRequestDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsCreateRequestDestinationType | (string & {});
}
export type SubscriptionsCreateRequestEventsList = Array<string>;
export type SubscriptionsCreateRequestSourceMqEventSourceImagesType = "images";
export interface SubscriptionsCreateRequestSourceMqEventSourceImages {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceImagesType | (string & {});
}
export type SubscriptionsCreateRequestSourceMqEventSourceKVType = "kv";
export interface SubscriptionsCreateRequestSourceMqEventSourceKV {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceKVType | (string & {});
}
export type SubscriptionsCreateRequestSourceMqEventSourceR2Type = "r2";
export interface SubscriptionsCreateRequestSourceMqEventSourceR2 {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceR2Type | (string & {});
}
export type SubscriptionsCreateRequestSourceMqEventSourceSuperSlurperType = "superSlurper";
export interface SubscriptionsCreateRequestSourceMqEventSourceSuperSlurper {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceSuperSlurperType | (string & {});
}
export type SubscriptionsCreateRequestSourceMqEventSourceVectorizeType = "vectorize";
export interface SubscriptionsCreateRequestSourceMqEventSourceVectorize {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceVectorizeType | (string & {});
}
export type SubscriptionsCreateRequestSourceMqEventSourceWorkersAIModelType = "workersAi.model";
export interface SubscriptionsCreateRequestSourceMqEventSourceWorkersAIModel {
    /** Name of the Workers AI model */
    modelName?: string;
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceWorkersAIModelType | (string & {});
}
export type SubscriptionsCreateRequestSourceMqEventSourceWorkersBuildsWorkerType = "workersBuilds.worker";
export interface SubscriptionsCreateRequestSourceMqEventSourceWorkersBuildsWorker {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceWorkersBuildsWorkerType | (string & {});
    /** Name of the worker */
    workerName?: string;
}
export type SubscriptionsCreateRequestSourceMqEventSourceWorkersScriptType = "workers.script";
export interface SubscriptionsCreateRequestSourceMqEventSourceWorkersScript {
    /** Tag of the Worker script */
    scriptTag?: string;
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceWorkersScriptType | (string & {});
}
export type SubscriptionsCreateRequestSourceMqEventSourceWorkflowsWorkflowType = "workflows.workflow";
export interface SubscriptionsCreateRequestSourceMqEventSourceWorkflowsWorkflow {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceWorkflowsWorkflowType | (string & {});
    /** Name of the workflow */
    workflowName?: string;
}
export type SubscriptionsCreateRequestSourceMqEventSourceArtifactsType = "artifacts";
export interface SubscriptionsCreateRequestSourceMqEventSourceArtifacts {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceArtifactsType | (string & {});
}
export type SubscriptionsCreateRequestSourceMqEventSourceArtifactsRepoType = "artifacts.repo";
export interface SubscriptionsCreateRequestSourceMqEventSourceArtifactsRepo {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceArtifactsRepoType | (string & {});
    /** Artifacts namespace of the repository */
    namespace: string;
    /** Name of the repository */
    repoName: string;
}
export type SubscriptionsCreateRequestSourceMqEventSourceEmailSendingType = "email.sending";
export interface SubscriptionsCreateRequestSourceMqEventSourceEmailSending {
    /** Sending domain: the zone apex or a verified sending subdomain */
    domain?: string;
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceEmailSendingType | (string & {});
    /** Zone ID of the sending domain */
    zoneId?: string;
}
export type SubscriptionsCreateRequestSource = SubscriptionsCreateRequestSourceMqEventSourceImages | SubscriptionsCreateRequestSourceMqEventSourceKV | SubscriptionsCreateRequestSourceMqEventSourceR2 | SubscriptionsCreateRequestSourceMqEventSourceSuperSlurper | SubscriptionsCreateRequestSourceMqEventSourceVectorize | SubscriptionsCreateRequestSourceMqEventSourceWorkersAIModel | SubscriptionsCreateRequestSourceMqEventSourceWorkersBuildsWorker | SubscriptionsCreateRequestSourceMqEventSourceWorkersScript | SubscriptionsCreateRequestSourceMqEventSourceWorkflowsWorkflow | SubscriptionsCreateRequestSourceMqEventSourceArtifacts | SubscriptionsCreateRequestSourceMqEventSourceArtifactsRepo | SubscriptionsCreateRequestSourceMqEventSourceEmailSending;
export interface CreateSubscriptionRequest {
    /** A Resource identifier. */
    accountId: string;
    /** Destination configuration for the subscription */
    destination?: SubscriptionsCreateRequestDestination;
    /** Whether the subscription is active */
    enabled?: boolean;
    /** List of event types this subscription handles */
    events?: SubscriptionsCreateRequestEventsList;
    /** Name of the subscription */
    name?: string;
    /** Source configuration for the subscription */
    source?: SubscriptionsCreateRequestSource;
}
export type SubscriptionsCreateResponseDestinationType = "queues.queue";
export interface SubscriptionsCreateResponseDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsCreateResponseDestinationType;
}
export type SubscriptionsCreateResponseEventsList = Array<string>;
export type SubscriptionsCreateResponseSourceMqEventSourceImagesType = "images";
export interface SubscriptionsCreateResponseSourceMqEventSourceImages {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceImagesType | null;
}
export type SubscriptionsCreateResponseSourceMqEventSourceKVType = "kv";
export interface SubscriptionsCreateResponseSourceMqEventSourceKV {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceKVType | null;
}
export type SubscriptionsCreateResponseSourceMqEventSourceR2Type = "r2";
export interface SubscriptionsCreateResponseSourceMqEventSourceR2 {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceR2Type | null;
}
export type SubscriptionsCreateResponseSourceMqEventSourceSuperSlurperType = "superSlurper";
export interface SubscriptionsCreateResponseSourceMqEventSourceSuperSlurper {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceSuperSlurperType | null;
}
export type SubscriptionsCreateResponseSourceMqEventSourceVectorizeType = "vectorize";
export interface SubscriptionsCreateResponseSourceMqEventSourceVectorize {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceVectorizeType | null;
}
export type SubscriptionsCreateResponseSourceMqEventSourceWorkersAIModelType = "workersAi.model";
export interface SubscriptionsCreateResponseSourceMqEventSourceWorkersAIModel {
    /** Name of the Workers AI model */
    modelName?: string | null;
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceWorkersAIModelType | null;
}
export type SubscriptionsCreateResponseSourceMqEventSourceWorkersBuildsWorkerType = "workersBuilds.worker";
export interface SubscriptionsCreateResponseSourceMqEventSourceWorkersBuildsWorker {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceWorkersBuildsWorkerType | null;
    /** Name of the worker */
    workerName?: string | null;
}
export type SubscriptionsCreateResponseSourceMqEventSourceWorkersScriptType = "workers.script";
export interface SubscriptionsCreateResponseSourceMqEventSourceWorkersScript {
    /** Tag of the Worker script */
    scriptTag?: string | null;
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceWorkersScriptType | null;
}
export type SubscriptionsCreateResponseSourceMqEventSourceWorkflowsWorkflowType = "workflows.workflow";
export interface SubscriptionsCreateResponseSourceMqEventSourceWorkflowsWorkflow {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceWorkflowsWorkflowType | null;
    /** Name of the workflow */
    workflowName?: string | null;
}
export type SubscriptionsCreateResponseSourceMqEventSourceArtifactsType = "artifacts";
export interface SubscriptionsCreateResponseSourceMqEventSourceArtifacts {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceArtifactsType | null;
}
export type SubscriptionsCreateResponseSourceMqEventSourceArtifactsRepoType = "artifacts.repo";
export interface SubscriptionsCreateResponseSourceMqEventSourceArtifactsRepo {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceArtifactsRepoType | null;
    /** Artifacts namespace of the repository */
    namespace: string;
    /** Name of the repository */
    repoName: string;
}
export type SubscriptionsCreateResponseSourceMqEventSourceEmailSendingType = "email.sending";
export interface SubscriptionsCreateResponseSourceMqEventSourceEmailSending {
    /** Sending domain: the zone apex or a verified sending subdomain */
    domain?: string | null;
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceEmailSendingType | null;
    /** Zone ID of the sending domain */
    zoneId?: string | null;
}
export type SubscriptionsCreateResponseSource = SubscriptionsCreateResponseSourceMqEventSourceImages | SubscriptionsCreateResponseSourceMqEventSourceKV | SubscriptionsCreateResponseSourceMqEventSourceR2 | SubscriptionsCreateResponseSourceMqEventSourceSuperSlurper | SubscriptionsCreateResponseSourceMqEventSourceVectorize | SubscriptionsCreateResponseSourceMqEventSourceWorkersAIModel | SubscriptionsCreateResponseSourceMqEventSourceWorkersBuildsWorker | SubscriptionsCreateResponseSourceMqEventSourceWorkersScript | SubscriptionsCreateResponseSourceMqEventSourceWorkflowsWorkflow | SubscriptionsCreateResponseSourceMqEventSourceArtifacts | SubscriptionsCreateResponseSourceMqEventSourceArtifactsRepo | SubscriptionsCreateResponseSourceMqEventSourceEmailSending;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSubscriptionResponse {
    /** Unique identifier for the subscription */
    id: string;
    /** When the subscription was created */
    createdAt: string;
    /** Destination configuration for the subscription */
    destination: SubscriptionsCreateResponseDestination;
    /** Whether the subscription is active */
    enabled: boolean;
    /** List of event types this subscription handles */
    events: SubscriptionsCreateResponseEventsList;
    /** When the subscription was last modified */
    modifiedAt: string;
    /** Name of the subscription */
    name: string;
    /** Source configuration for the subscription */
    source: SubscriptionsCreateResponseSource;
}
export interface DeleteConsumerRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** A Resource identifier. */
    consumerId: string;
}
export interface DeleteConsumerResponse {
}
export interface DeleteQueueRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
}
export interface DeleteQueueResponse {
}
export interface DeleteSubscriptionRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    subscriptionId: string;
}
export type SubscriptionsDeleteResponseDestinationType = "queues.queue";
export interface SubscriptionsDeleteResponseDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsDeleteResponseDestinationType;
}
export type SubscriptionsDeleteResponseEventsList = Array<string>;
export type SubscriptionsDeleteResponseSourceMqEventSourceImagesType = "images";
export interface SubscriptionsDeleteResponseSourceMqEventSourceImages {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceImagesType | null;
}
export type SubscriptionsDeleteResponseSourceMqEventSourceKVType = "kv";
export interface SubscriptionsDeleteResponseSourceMqEventSourceKV {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceKVType | null;
}
export type SubscriptionsDeleteResponseSourceMqEventSourceR2Type = "r2";
export interface SubscriptionsDeleteResponseSourceMqEventSourceR2 {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceR2Type | null;
}
export type SubscriptionsDeleteResponseSourceMqEventSourceSuperSlurperType = "superSlurper";
export interface SubscriptionsDeleteResponseSourceMqEventSourceSuperSlurper {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceSuperSlurperType | null;
}
export type SubscriptionsDeleteResponseSourceMqEventSourceVectorizeType = "vectorize";
export interface SubscriptionsDeleteResponseSourceMqEventSourceVectorize {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceVectorizeType | null;
}
export type SubscriptionsDeleteResponseSourceMqEventSourceWorkersAIModelType = "workersAi.model";
export interface SubscriptionsDeleteResponseSourceMqEventSourceWorkersAIModel {
    /** Name of the Workers AI model */
    modelName?: string | null;
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceWorkersAIModelType | null;
}
export type SubscriptionsDeleteResponseSourceMqEventSourceWorkersBuildsWorkerType = "workersBuilds.worker";
export interface SubscriptionsDeleteResponseSourceMqEventSourceWorkersBuildsWorker {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceWorkersBuildsWorkerType | null;
    /** Name of the worker */
    workerName?: string | null;
}
export type SubscriptionsDeleteResponseSourceMqEventSourceWorkersScriptType = "workers.script";
export interface SubscriptionsDeleteResponseSourceMqEventSourceWorkersScript {
    /** Tag of the Worker script */
    scriptTag?: string | null;
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceWorkersScriptType | null;
}
export type SubscriptionsDeleteResponseSourceMqEventSourceWorkflowsWorkflowType = "workflows.workflow";
export interface SubscriptionsDeleteResponseSourceMqEventSourceWorkflowsWorkflow {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceWorkflowsWorkflowType | null;
    /** Name of the workflow */
    workflowName?: string | null;
}
export type SubscriptionsDeleteResponseSourceMqEventSourceArtifactsType = "artifacts";
export interface SubscriptionsDeleteResponseSourceMqEventSourceArtifacts {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceArtifactsType | null;
}
export type SubscriptionsDeleteResponseSourceMqEventSourceArtifactsRepoType = "artifacts.repo";
export interface SubscriptionsDeleteResponseSourceMqEventSourceArtifactsRepo {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceArtifactsRepoType | null;
    /** Artifacts namespace of the repository */
    namespace: string;
    /** Name of the repository */
    repoName: string;
}
export type SubscriptionsDeleteResponseSourceMqEventSourceEmailSendingType = "email.sending";
export interface SubscriptionsDeleteResponseSourceMqEventSourceEmailSending {
    /** Sending domain: the zone apex or a verified sending subdomain */
    domain?: string | null;
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceEmailSendingType | null;
    /** Zone ID of the sending domain */
    zoneId?: string | null;
}
export type SubscriptionsDeleteResponseSource = SubscriptionsDeleteResponseSourceMqEventSourceImages | SubscriptionsDeleteResponseSourceMqEventSourceKV | SubscriptionsDeleteResponseSourceMqEventSourceR2 | SubscriptionsDeleteResponseSourceMqEventSourceSuperSlurper | SubscriptionsDeleteResponseSourceMqEventSourceVectorize | SubscriptionsDeleteResponseSourceMqEventSourceWorkersAIModel | SubscriptionsDeleteResponseSourceMqEventSourceWorkersBuildsWorker | SubscriptionsDeleteResponseSourceMqEventSourceWorkersScript | SubscriptionsDeleteResponseSourceMqEventSourceWorkflowsWorkflow | SubscriptionsDeleteResponseSourceMqEventSourceArtifacts | SubscriptionsDeleteResponseSourceMqEventSourceArtifactsRepo | SubscriptionsDeleteResponseSourceMqEventSourceEmailSending;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSubscriptionResponse {
    /** Unique identifier for the subscription */
    id: string;
    /** When the subscription was created */
    createdAt: string;
    /** Destination configuration for the subscription */
    destination: SubscriptionsDeleteResponseDestination;
    /** Whether the subscription is active */
    enabled: boolean;
    /** List of event types this subscription handles */
    events: SubscriptionsDeleteResponseEventsList;
    /** When the subscription was last modified */
    modifiedAt: string;
    /** Name of the subscription */
    name: string;
    /** Source configuration for the subscription */
    source: SubscriptionsDeleteResponseSource;
}
export interface GetConsumerRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** A Resource identifier. */
    consumerId: string;
}
export type ConsumersGetResultWorkerSettings = ConsumersCreateResultWorkerSettings;
export type ConsumersGetResultWorkerType = "worker";
export interface ConsumersGetResultWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: ConsumersGetResultWorkerType | null;
}
export type ConsumersGetResultHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export type ConsumersGetResultHTTPPullType = "http_pull";
export interface ConsumersGetResultHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: ConsumersGetResultHTTPPullType | null;
}
export type ConsumersGetResult = ConsumersGetResultWorker | ConsumersGetResultHTTPPull;
export type GetConsumerResponse = ConsumersGetResult;
export interface GetMetricsQueueRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMetricsQueueResponse {
    /** The size in bytes of unacknowledged messages in the queue. */
    backlogBytes: number;
    /** The number of unacknowledged messages in the queue. */
    backlogCount: number;
    /** Unix timestamp in milliseconds of the oldest unacknowledged message in the queue. Returns 0 if unknown. */
    oldestMessageTimestampMs: number;
}
export interface GetQueueRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
}
export type GetResponseConsumersItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export type GetResponseConsumersItemWorkerType = "worker";
export interface GetResponseConsumersItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: GetResponseConsumersItemWorkerType | null;
}
export type GetResponseConsumersItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export type GetResponseConsumersItemHTTPPullType = "http_pull";
export interface GetResponseConsumersItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: GetResponseConsumersItemHTTPPullType | null;
}
export type GetResponseConsumersItem = GetResponseConsumersItemWorker | GetResponseConsumersItemHTTPPull;
export type GetResponseConsumersList = Array<GetResponseConsumersItem>;
export type GetResponseJurisdiction = "eu" | "us" | "fedramp";
export type GetResponseProducersItemMqWorkerProducerType = "worker";
export interface GetResponseProducersItemMqWorkerProducer {
    type?: GetResponseProducersItemMqWorkerProducerType | null;
    scriptName?: string | null;
}
export type GetResponseProducersItemMqR2ProducerType = "r2_bucket";
export interface GetResponseProducersItemMqR2Producer {
    bucketName?: string | null;
    type?: GetResponseProducersItemMqR2ProducerType | null;
}
export type GetResponseProducersItem = GetResponseProducersItemMqWorkerProducer | GetResponseProducersItemMqR2Producer;
export type GetResponseProducersList = Array<GetResponseProducersItem>;
export type GetResponseSettings = CreateResponseSettings;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetQueueResponse {
    consumers?: GetResponseConsumersList | null;
    consumersTotalCount?: number | null;
    createdOn?: string | null;
    jurisdiction?: GetResponseJurisdiction | null;
    modifiedOn?: string | null;
    producers?: GetResponseProducersList | null;
    producersTotalCount?: number | null;
    queueId?: string | null;
    queueName?: string | null;
    settings?: CreateResponseSettings | null;
}
export interface GetSubscriptionRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    subscriptionId: string;
}
export type SubscriptionsGetResponseDestinationType = "queues.queue";
export interface SubscriptionsGetResponseDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsGetResponseDestinationType;
}
export type SubscriptionsGetResponseEventsList = Array<string>;
export type SubscriptionsGetResponseSourceMqEventSourceImagesType = "images";
export interface SubscriptionsGetResponseSourceMqEventSourceImages {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceImagesType | null;
}
export type SubscriptionsGetResponseSourceMqEventSourceKVType = "kv";
export interface SubscriptionsGetResponseSourceMqEventSourceKV {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceKVType | null;
}
export type SubscriptionsGetResponseSourceMqEventSourceR2Type = "r2";
export interface SubscriptionsGetResponseSourceMqEventSourceR2 {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceR2Type | null;
}
export type SubscriptionsGetResponseSourceMqEventSourceSuperSlurperType = "superSlurper";
export interface SubscriptionsGetResponseSourceMqEventSourceSuperSlurper {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceSuperSlurperType | null;
}
export type SubscriptionsGetResponseSourceMqEventSourceVectorizeType = "vectorize";
export interface SubscriptionsGetResponseSourceMqEventSourceVectorize {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceVectorizeType | null;
}
export type SubscriptionsGetResponseSourceMqEventSourceWorkersAIModelType = "workersAi.model";
export interface SubscriptionsGetResponseSourceMqEventSourceWorkersAIModel {
    /** Name of the Workers AI model */
    modelName?: string | null;
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceWorkersAIModelType | null;
}
export type SubscriptionsGetResponseSourceMqEventSourceWorkersBuildsWorkerType = "workersBuilds.worker";
export interface SubscriptionsGetResponseSourceMqEventSourceWorkersBuildsWorker {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceWorkersBuildsWorkerType | null;
    /** Name of the worker */
    workerName?: string | null;
}
export type SubscriptionsGetResponseSourceMqEventSourceWorkersScriptType = "workers.script";
export interface SubscriptionsGetResponseSourceMqEventSourceWorkersScript {
    /** Tag of the Worker script */
    scriptTag?: string | null;
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceWorkersScriptType | null;
}
export type SubscriptionsGetResponseSourceMqEventSourceWorkflowsWorkflowType = "workflows.workflow";
export interface SubscriptionsGetResponseSourceMqEventSourceWorkflowsWorkflow {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceWorkflowsWorkflowType | null;
    /** Name of the workflow */
    workflowName?: string | null;
}
export type SubscriptionsGetResponseSourceMqEventSourceArtifactsType = "artifacts";
export interface SubscriptionsGetResponseSourceMqEventSourceArtifacts {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceArtifactsType | null;
}
export type SubscriptionsGetResponseSourceMqEventSourceArtifactsRepoType = "artifacts.repo";
export interface SubscriptionsGetResponseSourceMqEventSourceArtifactsRepo {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceArtifactsRepoType | null;
    /** Artifacts namespace of the repository */
    namespace: string;
    /** Name of the repository */
    repoName: string;
}
export type SubscriptionsGetResponseSourceMqEventSourceEmailSendingType = "email.sending";
export interface SubscriptionsGetResponseSourceMqEventSourceEmailSending {
    /** Sending domain: the zone apex or a verified sending subdomain */
    domain?: string | null;
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceEmailSendingType | null;
    /** Zone ID of the sending domain */
    zoneId?: string | null;
}
export type SubscriptionsGetResponseSource = SubscriptionsGetResponseSourceMqEventSourceImages | SubscriptionsGetResponseSourceMqEventSourceKV | SubscriptionsGetResponseSourceMqEventSourceR2 | SubscriptionsGetResponseSourceMqEventSourceSuperSlurper | SubscriptionsGetResponseSourceMqEventSourceVectorize | SubscriptionsGetResponseSourceMqEventSourceWorkersAIModel | SubscriptionsGetResponseSourceMqEventSourceWorkersBuildsWorker | SubscriptionsGetResponseSourceMqEventSourceWorkersScript | SubscriptionsGetResponseSourceMqEventSourceWorkflowsWorkflow | SubscriptionsGetResponseSourceMqEventSourceArtifacts | SubscriptionsGetResponseSourceMqEventSourceArtifactsRepo | SubscriptionsGetResponseSourceMqEventSourceEmailSending;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSubscriptionResponse {
    /** Unique identifier for the subscription */
    id: string;
    /** When the subscription was created */
    createdAt: string;
    /** Destination configuration for the subscription */
    destination: SubscriptionsGetResponseDestination;
    /** Whether the subscription is active */
    enabled: boolean;
    /** List of event types this subscription handles */
    events: SubscriptionsGetResponseEventsList;
    /** When the subscription was last modified */
    modifiedAt: string;
    /** Name of the subscription */
    name: string;
    /** Source configuration for the subscription */
    source: SubscriptionsGetResponseSource;
}
export interface ListConsumersRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
}
export type ConsumersListResultItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export type ConsumersListResultItemWorkerType = "worker";
export interface ConsumersListResultItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: ConsumersListResultItemWorkerType | null;
}
export type ConsumersListResultItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export type ConsumersListResultItemHTTPPullType = "http_pull";
export interface ConsumersListResultItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: ConsumersListResultItemHTTPPullType | null;
}
export type ConsumersListResultItem = ConsumersListResultItemWorker | ConsumersListResultItemHTTPPull;
export type ConsumersListResultList = Array<ConsumersListResultItem>;
export interface ListConsumersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ConsumersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListQueuesRequest {
    /** A Resource identifier. */
    accountId: string;
}
export type ListResultItemConsumersItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export type ListResultItemConsumersItemWorkerType = "worker";
export interface ListResultItemConsumersItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: ListResultItemConsumersItemWorkerType | null;
}
export type ListResultItemConsumersItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export type ListResultItemConsumersItemHTTPPullType = "http_pull";
export interface ListResultItemConsumersItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: ListResultItemConsumersItemHTTPPullType | null;
}
export type ListResultItemConsumersItem = ListResultItemConsumersItemWorker | ListResultItemConsumersItemHTTPPull;
export type ListResultItemConsumersList = Array<ListResultItemConsumersItem>;
export type ListResultItemJurisdiction = "eu" | "us" | "fedramp";
export type ListResultItemProducersItemMqWorkerProducerType = "worker";
export interface ListResultItemProducersItemMqWorkerProducer {
    type?: ListResultItemProducersItemMqWorkerProducerType | null;
    scriptName?: string | null;
}
export type ListResultItemProducersItemMqR2ProducerType = "r2_bucket";
export interface ListResultItemProducersItemMqR2Producer {
    bucketName?: string | null;
    type?: ListResultItemProducersItemMqR2ProducerType | null;
}
export type ListResultItemProducersItem = ListResultItemProducersItemMqWorkerProducer | ListResultItemProducersItemMqR2Producer;
export type ListResultItemProducersList = Array<ListResultItemProducersItem>;
export type ListResultItemSettings = CreateResponseSettings;
export interface ListResultItem {
    consumers?: ListResultItemConsumersList | null;
    consumersTotalCount?: number | null;
    createdOn?: string | null;
    jurisdiction?: ListResultItemJurisdiction | null;
    modifiedOn?: string | null;
    producers?: ListResultItemProducersList | null;
    producersTotalCount?: number | null;
    queueId?: string | null;
    queueName?: string | null;
    settings?: CreateResponseSettings | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListQueuesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type SubscriptionsListRequestDirection = "asc" | "desc";
export type SubscriptionsListRequestOrder = "created_at" | "name" | "enabled" | "source";
export interface ListSubscriptionsRequest {
    /** A Resource identifier. */
    accountId: string;
    /** Sort direction */
    direction?: SubscriptionsListRequestDirection | (string & {});
    /** Field to sort by */
    order?: SubscriptionsListRequestOrder | (string & {});
    /** Page number for pagination */
    page?: number;
    /** Number of items per page */
    perPage?: number;
}
export type SubscriptionsListResultItemDestinationType = "queues.queue";
export interface SubscriptionsListResultItemDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsListResultItemDestinationType;
}
export type SubscriptionsListResultItemEventsList = Array<string>;
export type SubscriptionsListResultItemSourceMqEventSourceImagesType = "images";
export interface SubscriptionsListResultItemSourceMqEventSourceImages {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceImagesType | null;
}
export type SubscriptionsListResultItemSourceMqEventSourceKVType = "kv";
export interface SubscriptionsListResultItemSourceMqEventSourceKV {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceKVType | null;
}
export type SubscriptionsListResultItemSourceMqEventSourceR2Type = "r2";
export interface SubscriptionsListResultItemSourceMqEventSourceR2 {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceR2Type | null;
}
export type SubscriptionsListResultItemSourceMqEventSourceSuperSlurperType = "superSlurper";
export interface SubscriptionsListResultItemSourceMqEventSourceSuperSlurper {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceSuperSlurperType | null;
}
export type SubscriptionsListResultItemSourceMqEventSourceVectorizeType = "vectorize";
export interface SubscriptionsListResultItemSourceMqEventSourceVectorize {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceVectorizeType | null;
}
export type SubscriptionsListResultItemSourceMqEventSourceWorkersAIModelType = "workersAi.model";
export interface SubscriptionsListResultItemSourceMqEventSourceWorkersAIModel {
    /** Name of the Workers AI model */
    modelName?: string | null;
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceWorkersAIModelType | null;
}
export type SubscriptionsListResultItemSourceMqEventSourceWorkersBuildsWorkerType = "workersBuilds.worker";
export interface SubscriptionsListResultItemSourceMqEventSourceWorkersBuildsWorker {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceWorkersBuildsWorkerType | null;
    /** Name of the worker */
    workerName?: string | null;
}
export type SubscriptionsListResultItemSourceMqEventSourceWorkersScriptType = "workers.script";
export interface SubscriptionsListResultItemSourceMqEventSourceWorkersScript {
    /** Tag of the Worker script */
    scriptTag?: string | null;
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceWorkersScriptType | null;
}
export type SubscriptionsListResultItemSourceMqEventSourceWorkflowsWorkflowType = "workflows.workflow";
export interface SubscriptionsListResultItemSourceMqEventSourceWorkflowsWorkflow {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceWorkflowsWorkflowType | null;
    /** Name of the workflow */
    workflowName?: string | null;
}
export type SubscriptionsListResultItemSourceMqEventSourceArtifactsType = "artifacts";
export interface SubscriptionsListResultItemSourceMqEventSourceArtifacts {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceArtifactsType | null;
}
export type SubscriptionsListResultItemSourceMqEventSourceArtifactsRepoType = "artifacts.repo";
export interface SubscriptionsListResultItemSourceMqEventSourceArtifactsRepo {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceArtifactsRepoType | null;
    /** Artifacts namespace of the repository */
    namespace: string;
    /** Name of the repository */
    repoName: string;
}
export type SubscriptionsListResultItemSourceMqEventSourceEmailSendingType = "email.sending";
export interface SubscriptionsListResultItemSourceMqEventSourceEmailSending {
    /** Sending domain: the zone apex or a verified sending subdomain */
    domain?: string | null;
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceEmailSendingType | null;
    /** Zone ID of the sending domain */
    zoneId?: string | null;
}
export type SubscriptionsListResultItemSource = SubscriptionsListResultItemSourceMqEventSourceImages | SubscriptionsListResultItemSourceMqEventSourceKV | SubscriptionsListResultItemSourceMqEventSourceR2 | SubscriptionsListResultItemSourceMqEventSourceSuperSlurper | SubscriptionsListResultItemSourceMqEventSourceVectorize | SubscriptionsListResultItemSourceMqEventSourceWorkersAIModel | SubscriptionsListResultItemSourceMqEventSourceWorkersBuildsWorker | SubscriptionsListResultItemSourceMqEventSourceWorkersScript | SubscriptionsListResultItemSourceMqEventSourceWorkflowsWorkflow | SubscriptionsListResultItemSourceMqEventSourceArtifacts | SubscriptionsListResultItemSourceMqEventSourceArtifactsRepo | SubscriptionsListResultItemSourceMqEventSourceEmailSending;
export interface SubscriptionsListResultItem {
    /** Unique identifier for the subscription */
    id: string;
    /** When the subscription was created */
    createdAt: string;
    /** Destination configuration for the subscription */
    destination: SubscriptionsListResultItemDestination;
    /** Whether the subscription is active */
    enabled: boolean;
    /** List of event types this subscription handles */
    events: SubscriptionsListResultItemEventsList;
    /** When the subscription was last modified */
    modifiedAt: string;
    /** Name of the subscription */
    name: string;
    /** Source configuration for the subscription */
    source: SubscriptionsListResultItemSource;
}
export type SubscriptionsListResultList = Array<SubscriptionsListResultItem>;
export interface ListSubscriptionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubscriptionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface MessagesPeekRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** The maximum number of messages to include in a batch. */
    batchSize?: number;
}
export interface MessagesPeekResponseMessagesItem {
    id?: string | null;
    attempts?: number | null;
    body?: string | null;
    metadata?: unknown | null;
    /** An opaque reference to a peeked message. You must hold on to this value and use it to purge the message. */
    ref?: string | null;
    timestampMs?: number | null;
}
export type MessagesPeekResponseMessagesList = Array<MessagesPeekResponseMessagesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface MessagesPeekResponse {
    messages?: MessagesPeekResponseMessagesList | null;
}
export type EditRequestJurisdiction = "eu" | "us" | "fedramp";
export interface EditRequestSettings {
    /** Number of seconds to delay delivery of all messages to consumers. */
    deliveryDelay?: number;
    /** Indicates if message delivery to consumers is currently paused. */
    deliveryPaused?: boolean;
    /** Number of seconds after which an unconsumed message will be delayed. */
    messageRetentionPeriod?: number;
}
export interface PatchQueueRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    jurisdiction?: EditRequestJurisdiction | (string & {});
    queueName?: string;
    settings?: EditRequestSettings;
}
export type EditResponseConsumersItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export type EditResponseConsumersItemWorkerType = "worker";
export interface EditResponseConsumersItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: EditResponseConsumersItemWorkerType | null;
}
export type EditResponseConsumersItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export type EditResponseConsumersItemHTTPPullType = "http_pull";
export interface EditResponseConsumersItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: EditResponseConsumersItemHTTPPullType | null;
}
export type EditResponseConsumersItem = EditResponseConsumersItemWorker | EditResponseConsumersItemHTTPPull;
export type EditResponseConsumersList = Array<EditResponseConsumersItem>;
export type EditResponseJurisdiction = "eu" | "us" | "fedramp";
export type EditResponseProducersItemMqWorkerProducerType = "worker";
export interface EditResponseProducersItemMqWorkerProducer {
    type?: EditResponseProducersItemMqWorkerProducerType | null;
    scriptName?: string | null;
}
export type EditResponseProducersItemMqR2ProducerType = "r2_bucket";
export interface EditResponseProducersItemMqR2Producer {
    bucketName?: string | null;
    type?: EditResponseProducersItemMqR2ProducerType | null;
}
export type EditResponseProducersItem = EditResponseProducersItemMqWorkerProducer | EditResponseProducersItemMqR2Producer;
export type EditResponseProducersList = Array<EditResponseProducersItem>;
export type EditResponseSettings = CreateResponseSettings;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchQueueResponse {
    consumers?: EditResponseConsumersList | null;
    consumersTotalCount?: number | null;
    createdOn?: string | null;
    jurisdiction?: EditResponseJurisdiction | null;
    modifiedOn?: string | null;
    producers?: EditResponseProducersList | null;
    producersTotalCount?: number | null;
    queueId?: string | null;
    queueName?: string | null;
    settings?: CreateResponseSettings | null;
}
export type SubscriptionsUpdateRequestDestinationType = "queues.queue";
export interface SubscriptionsUpdateRequestDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsUpdateRequestDestinationType | (string & {});
}
export type SubscriptionsUpdateRequestEventsList = Array<string>;
export interface PatchSubscriptionRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    subscriptionId: string;
    /** Destination configuration for the subscription */
    destination?: SubscriptionsUpdateRequestDestination;
    /** Whether the subscription is active */
    enabled?: boolean;
    /** List of event types this subscription handles */
    events?: SubscriptionsUpdateRequestEventsList;
    /** Name of the subscription */
    name?: string;
}
export type SubscriptionsUpdateResponseDestinationType = "queues.queue";
export interface SubscriptionsUpdateResponseDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsUpdateResponseDestinationType;
}
export type SubscriptionsUpdateResponseEventsList = Array<string>;
export type SubscriptionsUpdateResponseSourceMqEventSourceImagesType = "images";
export interface SubscriptionsUpdateResponseSourceMqEventSourceImages {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceImagesType | null;
}
export type SubscriptionsUpdateResponseSourceMqEventSourceKVType = "kv";
export interface SubscriptionsUpdateResponseSourceMqEventSourceKV {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceKVType | null;
}
export type SubscriptionsUpdateResponseSourceMqEventSourceR2Type = "r2";
export interface SubscriptionsUpdateResponseSourceMqEventSourceR2 {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceR2Type | null;
}
export type SubscriptionsUpdateResponseSourceMqEventSourceSuperSlurperType = "superSlurper";
export interface SubscriptionsUpdateResponseSourceMqEventSourceSuperSlurper {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceSuperSlurperType | null;
}
export type SubscriptionsUpdateResponseSourceMqEventSourceVectorizeType = "vectorize";
export interface SubscriptionsUpdateResponseSourceMqEventSourceVectorize {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceVectorizeType | null;
}
export type SubscriptionsUpdateResponseSourceMqEventSourceWorkersAIModelType = "workersAi.model";
export interface SubscriptionsUpdateResponseSourceMqEventSourceWorkersAIModel {
    /** Name of the Workers AI model */
    modelName?: string | null;
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceWorkersAIModelType | null;
}
export type SubscriptionsUpdateResponseSourceMqEventSourceWorkersBuildsWorkerType = "workersBuilds.worker";
export interface SubscriptionsUpdateResponseSourceMqEventSourceWorkersBuildsWorker {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceWorkersBuildsWorkerType | null;
    /** Name of the worker */
    workerName?: string | null;
}
export type SubscriptionsUpdateResponseSourceMqEventSourceWorkersScriptType = "workers.script";
export interface SubscriptionsUpdateResponseSourceMqEventSourceWorkersScript {
    /** Tag of the Worker script */
    scriptTag?: string | null;
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceWorkersScriptType | null;
}
export type SubscriptionsUpdateResponseSourceMqEventSourceWorkflowsWorkflowType = "workflows.workflow";
export interface SubscriptionsUpdateResponseSourceMqEventSourceWorkflowsWorkflow {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceWorkflowsWorkflowType | null;
    /** Name of the workflow */
    workflowName?: string | null;
}
export type SubscriptionsUpdateResponseSourceMqEventSourceArtifactsType = "artifacts";
export interface SubscriptionsUpdateResponseSourceMqEventSourceArtifacts {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceArtifactsType | null;
}
export type SubscriptionsUpdateResponseSourceMqEventSourceArtifactsRepoType = "artifacts.repo";
export interface SubscriptionsUpdateResponseSourceMqEventSourceArtifactsRepo {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceArtifactsRepoType | null;
    /** Artifacts namespace of the repository */
    namespace: string;
    /** Name of the repository */
    repoName: string;
}
export type SubscriptionsUpdateResponseSourceMqEventSourceEmailSendingType = "email.sending";
export interface SubscriptionsUpdateResponseSourceMqEventSourceEmailSending {
    /** Sending domain: the zone apex or a verified sending subdomain */
    domain?: string | null;
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceEmailSendingType | null;
    /** Zone ID of the sending domain */
    zoneId?: string | null;
}
export type SubscriptionsUpdateResponseSource = SubscriptionsUpdateResponseSourceMqEventSourceImages | SubscriptionsUpdateResponseSourceMqEventSourceKV | SubscriptionsUpdateResponseSourceMqEventSourceR2 | SubscriptionsUpdateResponseSourceMqEventSourceSuperSlurper | SubscriptionsUpdateResponseSourceMqEventSourceVectorize | SubscriptionsUpdateResponseSourceMqEventSourceWorkersAIModel | SubscriptionsUpdateResponseSourceMqEventSourceWorkersBuildsWorker | SubscriptionsUpdateResponseSourceMqEventSourceWorkersScript | SubscriptionsUpdateResponseSourceMqEventSourceWorkflowsWorkflow | SubscriptionsUpdateResponseSourceMqEventSourceArtifacts | SubscriptionsUpdateResponseSourceMqEventSourceArtifactsRepo | SubscriptionsUpdateResponseSourceMqEventSourceEmailSending;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSubscriptionResponse {
    /** Unique identifier for the subscription */
    id: string;
    /** When the subscription was created */
    createdAt: string;
    /** Destination configuration for the subscription */
    destination: SubscriptionsUpdateResponseDestination;
    /** Whether the subscription is active */
    enabled: boolean;
    /** List of event types this subscription handles */
    events: SubscriptionsUpdateResponseEventsList;
    /** When the subscription was last modified */
    modifiedAt: string;
    /** Name of the subscription */
    name: string;
    /** Source configuration for the subscription */
    source: SubscriptionsUpdateResponseSource;
}
export interface PullMessageRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** The maximum number of messages to include in a batch. */
    batchSize?: number;
    /** The number of milliseconds that a message is exclusively leased. After the timeout, the message becomes available for another attempt. */
    visibilityTimeoutMs?: number;
}
export interface MessagesPullResponseMessagesItem {
    id?: string | null;
    attempts?: number | null;
    body?: string | null;
    /** An ID that represents an "in-flight" message that has been pulled from a Queue. You must hold on to this ID and use it to acknowledge this message. */
    leaseId?: string | null;
    metadata?: unknown | null;
    timestampMs?: number | null;
}
export type MessagesPullResponseMessagesList = Array<MessagesPullResponseMessagesItem>;
export type MessagesPullResponseMetadataMetrics = MessagesBulkPushResponseMetadataMetrics;
export type MessagesPullResponseMetadata = MessagesBulkPushResponseMetadata;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PullMessageResponse {
    /** The number of unacknowledged messages in the queue. */
    messageBacklogCount?: number | null;
    messages?: MessagesPullResponseMessagesList | null;
    metadata?: MessagesBulkPushResponseMetadata | null;
}
export interface PurgeMessageRequestRefsItem {
    /** An opaque reference to a peeked message. You must hold on to this value and use it to purge the message. */
    ref: string;
}
export type PurgeMessageRequestRefsList = Array<PurgeMessageRequestRefsItem>;
export interface PurgeMessageRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    refs: PurgeMessageRequestRefsList;
}
export interface PurgeMessageResponseErrorsItem {
    message?: string | null;
}
export type PurgeMessageResponseErrorsList = Array<PurgeMessageResponseErrorsItem>;
export type PurgeMessageResponseWarningsMap = {
    [key: string]: string | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PurgeMessageResponse {
    /** Errors encountered while purging messages. */
    errors?: PurgeMessageResponseErrorsList | null;
    /** Map of refs to warning messages encountered during purge. */
    warnings?: PurgeMessageResponseWarningsMap | null;
}
export interface PurgeStatusRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PurgeStatusResponse {
    /** Indicates if the last purge operation completed successfully. */
    completed?: string | null;
    /** Timestamp when the last purge operation started. */
    startedAt?: string | null;
}
export type MessagesPushRequestContentType = "text" | "json";
export interface PushMessageRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    body?: unknown;
    contentType?: MessagesPushRequestContentType | (string & {});
    /** The number of seconds to wait for attempting to deliver this message to consumers */
    delaySeconds?: number;
}
export type MessagesPushResponseMetadataMetrics = MessagesBulkPushResponseMetadataMetrics;
export type MessagesPushResponseMetadata = MessagesBulkPushResponseMetadata;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PushMessageResponse {
    metadata?: MessagesBulkPushResponseMetadata | null;
}
export interface StartPurgeRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** Confirms that all messages will be permanently deleted. */
    deleteMessagesPermanently?: boolean;
}
export type PurgeStartResponseConsumersItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export type PurgeStartResponseConsumersItemWorkerType = "worker";
export interface PurgeStartResponseConsumersItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: PurgeStartResponseConsumersItemWorkerType | null;
}
export type PurgeStartResponseConsumersItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export type PurgeStartResponseConsumersItemHTTPPullType = "http_pull";
export interface PurgeStartResponseConsumersItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: PurgeStartResponseConsumersItemHTTPPullType | null;
}
export type PurgeStartResponseConsumersItem = PurgeStartResponseConsumersItemWorker | PurgeStartResponseConsumersItemHTTPPull;
export type PurgeStartResponseConsumersList = Array<PurgeStartResponseConsumersItem>;
export type PurgeStartResponseJurisdiction = "eu" | "us" | "fedramp";
export type PurgeStartResponseProducersItemMqWorkerProducerType = "worker";
export interface PurgeStartResponseProducersItemMqWorkerProducer {
    type?: PurgeStartResponseProducersItemMqWorkerProducerType | null;
    scriptName?: string | null;
}
export type PurgeStartResponseProducersItemMqR2ProducerType = "r2_bucket";
export interface PurgeStartResponseProducersItemMqR2Producer {
    bucketName?: string | null;
    type?: PurgeStartResponseProducersItemMqR2ProducerType | null;
}
export type PurgeStartResponseProducersItem = PurgeStartResponseProducersItemMqWorkerProducer | PurgeStartResponseProducersItemMqR2Producer;
export type PurgeStartResponseProducersList = Array<PurgeStartResponseProducersItem>;
export type PurgeStartResponseSettings = CreateResponseSettings;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StartPurgeResponse {
    consumers?: PurgeStartResponseConsumersList | null;
    consumersTotalCount?: number | null;
    createdOn?: string | null;
    jurisdiction?: PurgeStartResponseJurisdiction | null;
    modifiedOn?: string | null;
    producers?: PurgeStartResponseProducersList | null;
    producersTotalCount?: number | null;
    queueId?: string | null;
    queueName?: string | null;
    settings?: CreateResponseSettings | null;
}
export type ConsumersUpdateRequestType = "worker" | "http_pull";
export type ConsumersUpdateRequestSettingsWorker = ConsumersCreateRequestSettingsWorker;
export type ConsumersUpdateRequestSettingsHTTPPull = ConsumersCreateRequestSettingsHTTPPull;
export type ConsumersUpdateRequestSettings = ConsumersCreateRequestSettingsWorker | ConsumersCreateRequestSettingsHTTPPull;
export interface UpdateConsumerRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** A Resource identifier. */
    consumerId: string;
    /** Name of a Worker */
    scriptName?: string;
    type: ConsumersUpdateRequestType | (string & {});
    deadLetterQueue?: string;
    settings?: ConsumersUpdateRequestSettings;
}
export type ConsumersUpdateResultWorkerSettings = ConsumersCreateResultWorkerSettings;
export type ConsumersUpdateResultWorkerType = "worker";
export interface ConsumersUpdateResultWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: ConsumersUpdateResultWorkerType | null;
}
export type ConsumersUpdateResultHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export type ConsumersUpdateResultHTTPPullType = "http_pull";
export interface ConsumersUpdateResultHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: ConsumersUpdateResultHTTPPullType | null;
}
export type ConsumersUpdateResult = ConsumersUpdateResultWorker | ConsumersUpdateResultHTTPPull;
export type UpdateConsumerResponse = ConsumersUpdateResult;
export type UpdateRequestJurisdiction = "eu" | "us" | "fedramp";
export type UpdateRequestSettings = EditRequestSettings;
export interface UpdateQueueRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    jurisdiction?: UpdateRequestJurisdiction | (string & {});
    queueName?: string;
    settings?: EditRequestSettings;
}
export type UpdateResponseConsumersItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export type UpdateResponseConsumersItemWorkerType = "worker";
export interface UpdateResponseConsumersItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: UpdateResponseConsumersItemWorkerType | null;
}
export type UpdateResponseConsumersItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export type UpdateResponseConsumersItemHTTPPullType = "http_pull";
export interface UpdateResponseConsumersItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: UpdateResponseConsumersItemHTTPPullType | null;
}
export type UpdateResponseConsumersItem = UpdateResponseConsumersItemWorker | UpdateResponseConsumersItemHTTPPull;
export type UpdateResponseConsumersList = Array<UpdateResponseConsumersItem>;
export type UpdateResponseJurisdiction = "eu" | "us" | "fedramp";
export type UpdateResponseProducersItemMqWorkerProducerType = "worker";
export interface UpdateResponseProducersItemMqWorkerProducer {
    type?: UpdateResponseProducersItemMqWorkerProducerType | null;
    scriptName?: string | null;
}
export type UpdateResponseProducersItemMqR2ProducerType = "r2_bucket";
export interface UpdateResponseProducersItemMqR2Producer {
    bucketName?: string | null;
    type?: UpdateResponseProducersItemMqR2ProducerType | null;
}
export type UpdateResponseProducersItem = UpdateResponseProducersItemMqWorkerProducer | UpdateResponseProducersItemMqR2Producer;
export type UpdateResponseProducersList = Array<UpdateResponseProducersItem>;
export type UpdateResponseSettings = CreateResponseSettings;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateQueueResponse {
    consumers?: UpdateResponseConsumersList | null;
    consumersTotalCount?: number | null;
    createdOn?: string | null;
    jurisdiction?: UpdateResponseJurisdiction | null;
    modifiedOn?: string | null;
    producers?: UpdateResponseProducersList | null;
    producersTotalCount?: number | null;
    queueId?: string | null;
    queueName?: string | null;
    settings?: CreateResponseSettings | null;
}
export type AckMessageError = InvalidRequestBody | InvalidQueueId | QueueNotFound | InvalidRoute | CloudflareOpError;
/** Acknowledges successfully processed Queue messages and retries messages that were not processed successfully. */
export declare const ackMessage: API.OperationMethod<AckMessageRequest, AckMessageResponse, AckMessageError, CloudflareOpContext>;
export type BulkPushMessagesError = InvalidMessageBody | InvalidQueueId | InvalidRoute | CloudflareOpError;
/** Pushes a batch of messages to a Queue. */
export declare const bulkPushMessages: API.OperationMethod<BulkPushMessagesRequest, BulkPushMessagesResponse, BulkPushMessagesError, CloudflareOpContext>;
export type CreateConsumerError = InvalidRequestBody | QueueNotFound | QueueHandlerMissing | ConsumerAlreadyExists | WorkerNotFound | InvalidRoute | CloudflareOpError;
/** Creates a consumer for a Queue. */
export declare const createConsumer: API.OperationMethod<CreateConsumerRequest, CreateConsumerResponse, CreateConsumerError, CloudflareOpContext>;
export type CreateQueueError = QueueAlreadyExists | InvalidQueueName | InvalidRoute | CloudflareOpError;
/** Creates a Queue in the account. */
export declare const createQueue: API.OperationMethod<CreateQueueRequest, CreateQueueResponse, CreateQueueError, CloudflareOpContext>;
export type CreateSubscriptionError = UnrecognizedEventType | SubscriptionAlreadyExists | QueueNotFound | CloudflareOpError;
/** Creates an event subscription for a Queue. */
export declare const createSubscription: API.OperationMethod<CreateSubscriptionRequest, CreateSubscriptionResponse, CreateSubscriptionError, CloudflareOpContext>;
export type DeleteConsumerError = InvalidRequestBody | QueueNotFound | ConsumerNotFound | InvalidRoute | CloudflareOpError;
/** Deletes a consumer from a Queue. */
export declare const deleteConsumer: API.OperationMethod<DeleteConsumerRequest, DeleteConsumerResponse, DeleteConsumerError, CloudflareOpContext>;
export type DeleteQueueError = QueueNotFound | QueueInUseByEventNotification | InvalidRoute | QueueInUseByWorkerBinding | CloudflareOpError;
/** Deletes a Queue. */
export declare const deleteQueue: API.OperationMethod<DeleteQueueRequest, DeleteQueueResponse, DeleteQueueError, CloudflareOpContext>;
export type DeleteSubscriptionError = UnrecognizedEventType | SubscriptionNotFound | CloudflareOpError;
/** Deletes an existing Queue event subscription. */
export declare const deleteSubscription: API.OperationMethod<DeleteSubscriptionRequest, DeleteSubscriptionResponse, DeleteSubscriptionError, CloudflareOpContext>;
export type GetConsumerError = InvalidRequestBody | QueueNotFound | ConsumerNotFound | InvalidRoute | CloudflareOpError;
/** Returns a Queue consumer by identifier. */
export declare const getConsumer: API.OperationMethod<GetConsumerRequest, GetConsumerResponse, GetConsumerError, CloudflareOpContext>;
export type GetMetricsQueueError = CloudflareOpError;
/** Returns best-effort metrics for a Queue. Values may be approximate due to the distributed nature of Queues. */
export declare const getMetricsQueue: API.OperationMethod<GetMetricsQueueRequest, GetMetricsQueueResponse, GetMetricsQueueError, CloudflareOpContext>;
export type GetQueueError = QueueNotFound | InvalidRoute | CloudflareOpError;
/** Returns details about a specific Queue. */
export declare const getQueue: API.OperationMethod<GetQueueRequest, GetQueueResponse, GetQueueError, CloudflareOpContext>;
export type GetSubscriptionError = UnrecognizedEventType | SubscriptionNotFound | Forbidden | CloudflareOpError;
/** Returns an existing Queue event subscription. */
export declare const getSubscription: API.OperationMethod<GetSubscriptionRequest, GetSubscriptionResponse, GetSubscriptionError, CloudflareOpContext>;
export type ListConsumersError = InvalidRequestBody | QueueNotFound | InvalidRoute | CloudflareOpError;
/** Returns the consumers configured for a Queue. */
export declare const listConsumers: API.PaginatedOperationMethod<ListConsumersRequest, ListConsumersResponse, ListConsumersError, CloudflareOpContext, ConsumersListResultItem>;
export type ListQueuesError = InvalidRoute | CloudflareOpError;
/** Returns the queues owned by an account. */
export declare const listQueues: API.PaginatedOperationMethod<ListQueuesRequest, ListQueuesResponse, ListQueuesError, CloudflareOpContext, ListResultItem>;
export type ListSubscriptionsError = Forbidden | CloudflareOpError;
/** Returns a paginated list of Queue event subscriptions with optional sorting and filtering. */
export declare const listSubscriptions: API.PaginatedOperationMethod<ListSubscriptionsRequest, ListSubscriptionsResponse, ListSubscriptionsError, CloudflareOpContext, SubscriptionsListResultItem>;
export type MessagesPeekError = CloudflareOpError;
/** Peek messages from a Queue without leasing them. Each message includes a ref that can be passed to the purge endpoint, and remains available for subsequent peek or pull operations until it is purged. */
export declare const messagesPeek: API.OperationMethod<MessagesPeekRequest, MessagesPeekResponse, MessagesPeekError, CloudflareOpContext>;
export type PatchQueueError = QueueNotFound | InvalidRoute | CloudflareOpError;
/** Updates part of a Queue's configuration. */
export declare const patchQueue: API.OperationMethod<PatchQueueRequest, PatchQueueResponse, PatchQueueError, CloudflareOpContext>;
export type PatchSubscriptionError = UnrecognizedEventType | SubscriptionNotFound | QueueNotFound | CloudflareOpError;
/** Updates an existing Queue event subscription. */
export declare const patchSubscription: API.OperationMethod<PatchSubscriptionRequest, PatchSubscriptionResponse, PatchSubscriptionError, CloudflareOpContext>;
export type PullMessageError = InvalidRequestBody | InvalidQueueId | QueueNotFound | InvalidRoute | QueueHttpPullNotEnabled | CloudflareOpError;
/** Pulls a batch of messages from a Queue for an HTTP pull consumer. */
export declare const pullMessage: API.OperationMethod<PullMessageRequest, PullMessageResponse, PullMessageError, CloudflareOpContext>;
export type PurgeMessageError = CloudflareOpError;
/** Delete messages from a Queue by using refs returned by the peek endpoint. Purging messages does not count as delivery and does not affect metrics. */
export declare const purgeMessage: API.OperationMethod<PurgeMessageRequest, PurgeMessageResponse, PurgeMessageError, CloudflareOpContext>;
export type PurgeStatusError = InvalidQueueId | InvalidRoute | CloudflareOpError;
/** Returns the status of a Queue purge operation. */
export declare const purgeStatus: API.OperationMethod<PurgeStatusRequest, PurgeStatusResponse, PurgeStatusError, CloudflareOpContext>;
export type PushMessageError = InvalidMessageBody | InvalidQueueId | InvalidRoute | CloudflareOpError;
/** Pushes a message to a Queue. */
export declare const pushMessage: API.OperationMethod<PushMessageRequest, PushMessageResponse, PushMessageError, CloudflareOpContext>;
export type StartPurgeError = InvalidQueueId | InvalidRoute | CloudflareOpError;
/** Starts a purge that deletes all messages from a Queue. */
export declare const startPurge: API.OperationMethod<StartPurgeRequest, StartPurgeResponse, StartPurgeError, CloudflareOpContext>;
export type UpdateConsumerError = InvalidRequestBody | QueueNotFound | QueueHandlerMissing | ConsumerNotFound | WorkerNotFound | InvalidRoute | CloudflareOpError;
/** Replaces a Queue consumer, or creates it if it does not exist. */
export declare const updateConsumer: API.OperationMethod<UpdateConsumerRequest, UpdateConsumerResponse, UpdateConsumerError, CloudflareOpContext>;
export type UpdateQueueError = InvalidQueueName | QueueNotFound | InvalidRoute | CloudflareOpError;
/** Replaces a Queue's configuration with the supplied configuration. This endpoint does not support partial updates. */
export declare const updateQueue: API.OperationMethod<UpdateQueueRequest, UpdateQueueResponse, UpdateQueueError, CloudflareOpContext>;
//# sourceMappingURL=queues.d.ts.map