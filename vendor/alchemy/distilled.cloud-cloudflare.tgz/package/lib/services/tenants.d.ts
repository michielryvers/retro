import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface GetEntitlementRequest {
    tenantId: string;
}
export type EntitlementsGetResponseAllowAddSubdomainType = "bool";
export interface EntitlementsGetResponseAllowAddSubdomain {
    type: EntitlementsGetResponseAllowAddSubdomainType;
    value: boolean;
}
export type EntitlementsGetResponseAllowAutoAcceptInvitesType = "bool";
export interface EntitlementsGetResponseAllowAutoAcceptInvites {
    type: EntitlementsGetResponseAllowAutoAcceptInvitesType;
    value: boolean;
}
export type EntitlementsGetResponseCnameSetupAllowedType = "bool";
export interface EntitlementsGetResponseCnameSetupAllowed {
    type: EntitlementsGetResponseCnameSetupAllowedType;
    value: boolean;
}
export type EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocationType = "max_count";
export interface EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocation {
    type: EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocationType;
    value: number;
}
export type EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocationType = "bool";
export interface EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocation {
    type: EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocationType;
    value: boolean;
}
export type EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocationType = "";
export interface EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocation {
    type: EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocationType;
    value?: unknown | null;
}
export type EntitlementsGetResponseCustomEntitlementsItemAllocation = EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocation | EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocation | EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocation;
export interface EntitlementsGetResponseCustomEntitlementsItemFeature {
    key: string;
}
export interface EntitlementsGetResponseCustomEntitlementsItem {
    allocation: EntitlementsGetResponseCustomEntitlementsItemAllocation;
    feature: EntitlementsGetResponseCustomEntitlementsItemFeature;
}
export type EntitlementsGetResponseCustomEntitlementsList = Array<EntitlementsGetResponseCustomEntitlementsItem>;
export type EntitlementsGetResponseMhsCertificateCountType = "max_count";
export interface EntitlementsGetResponseMhsCertificateCount {
    type: EntitlementsGetResponseMhsCertificateCountType;
    value: number;
}
export type EntitlementsGetResponsePartialSetupAllowedType = "bool";
export interface EntitlementsGetResponsePartialSetupAllowed {
    type: EntitlementsGetResponsePartialSetupAllowedType;
    value: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetEntitlementResponse {
    allowAddSubdomain: EntitlementsGetResponseAllowAddSubdomain;
    allowAutoAcceptInvites: EntitlementsGetResponseAllowAutoAcceptInvites;
    cnameSetupAllowed: EntitlementsGetResponseCnameSetupAllowed;
    customEntitlements: EntitlementsGetResponseCustomEntitlementsList;
    mhsCertificateCount: EntitlementsGetResponseMhsCertificateCount;
    partialSetupAllowed: EntitlementsGetResponsePartialSetupAllowed;
}
export interface GetTenantRequest {
    tenantId: string;
}
export interface GetResponseTenantContacts {
    email?: string | null;
    website?: string | null;
}
export type GetResponseTenantLabelsList = Array<string>;
export interface GetResponseTenantMetadataDnsNsPool {
    primary?: string | null;
    secondary?: string | null;
}
export interface GetResponseTenantMetadataDns {
    nsPool: GetResponseTenantMetadataDnsNsPool;
}
export interface GetResponseTenantMetadata {
    dns?: GetResponseTenantMetadataDns | null;
}
export type GetResponseTenantUnitsItemUnitMembershipsList = Array<unknown>;
export interface GetResponseTenantUnitsItem {
    unitMemberships: GetResponseTenantUnitsItemUnitMembershipsList;
    unitMetadata: unknown;
    unitName: string;
    unitStatus: string;
    unitTag: string;
}
export type GetResponseTenantUnitsList = Array<GetResponseTenantUnitsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTenantResponse {
    cdate: string;
    edate: string;
    tenantContacts: GetResponseTenantContacts;
    tenantLabels: GetResponseTenantLabelsList;
    tenantMetadata: GetResponseTenantMetadata;
    tenantName: string;
    tenantNetwork: unknown;
    tenantStatus: string;
    tenantTag: string;
    tenantType: string;
    tenantUnits: GetResponseTenantUnitsList;
    customerId?: string | null;
}
export interface ListAccountsRequest {
    tenantId: string;
}
export interface AccountsListResultItemSettings {
    abuseContactEmail: string;
    accessApprovalExpiry: string;
    apiAccessEnabled: boolean;
    /** Use [DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-an-account-list-dns-settings) instead. Deprecated. */
    defaultNameservers: string;
    enforceTwofactor: boolean;
    /** Use [DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-an-account-list-dns-settings) instead. Deprecated. */
    useAccountCustomNsByDefault: boolean;
}
export type AccountsListResultItemType = "standard" | "enterprise";
export type AccountsListResultItemTagsMap = {
    [key: string]: string | undefined;
};
export interface AccountsListResultItem {
    id: string;
    createdOn: string;
    name: string;
    settings: AccountsListResultItemSettings;
    type: AccountsListResultItemType;
    /** Account tags, present only when `include_tags=true` is requested. */
    tags?: AccountsListResultItemTagsMap | null;
}
export type AccountsListResultList = Array<AccountsListResultItem>;
export interface ListAccountsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AccountsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListAccountTypesRequest {
    tenantId: string;
}
export type AccountTypesListResultList = Array<string>;
export interface ListAccountTypesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AccountTypesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListMembershipsRequest {
    tenantId: string;
}
export interface MembershipsListResultItem {
    userEmail: string;
    userName: string;
    userTag: string;
}
export type MembershipsListResultList = Array<MembershipsListResultItem>;
export interface ListMembershipsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MembershipsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type GetEntitlementError = CloudflareOpError;
/** Retrieves the innate and custom entitlement allocations available to this tenant. */
export declare const getEntitlement: API.OperationMethod<GetEntitlementRequest, GetEntitlementResponse, GetEntitlementError, CloudflareOpContext>;
export type GetTenantError = CloudflareOpError;
/** Retrieves a tenant's identity, status, metadata, contacts, and organizational units. */
export declare const getTenant: API.OperationMethod<GetTenantRequest, GetTenantResponse, GetTenantError, CloudflareOpContext>;
export type ListAccountsError = CloudflareOpError;
/** Lists the Cloudflare accounts associated with this tenant. */
export declare const listAccounts: API.PaginatedOperationMethod<ListAccountsRequest, ListAccountsResponse, ListAccountsError, CloudflareOpContext, AccountsListResultItem>;
export type ListAccountTypesError = CloudflareOpError;
/** Lists the account types this tenant is allowed to provision. */
export declare const listAccountTypes: API.PaginatedOperationMethod<ListAccountTypesRequest, ListAccountTypesResponse, ListAccountTypesError, CloudflareOpContext, string>;
export type ListMembershipsError = CloudflareOpError;
/** Lists active Cloudflare users with memberships in this tenant. */
export declare const listMemberships: API.PaginatedOperationMethod<ListMembershipsRequest, ListMembershipsResponse, ListMembershipsError, CloudflareOpContext, MembershipsListResultItem>;
//# sourceMappingURL=tenants.d.ts.map