import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CallsAppNotFound_base: S.TaggedErrorClass<"CallsAppNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CallsAppNotFound extends /*@__PURE__*/ CallsAppNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const TurnKeyNotFound_base: S.TaggedErrorClass<"TurnKeyNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TurnKeyNotFound extends /*@__PURE__*/ TurnKeyNotFound_base {
}
export interface CreateSfuRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A short description of a Realtime SFU app, not shown to end users. */
    name?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSfuResponse {
    /** The date and time the item was created. */
    created: string;
    /** The date and time the item was last modified. */
    modified: string;
    /** A short description of a Realtime SFU app, not shown to end users. */
    name: string;
    /** Bearer token */
    secret: string;
    /** A Cloudflare-generated unique identifier for a item. */
    uid: string;
}
export interface CreateTurnRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A short description of a TURN key, not shown to end users. */
    name?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTurnResponse {
    /** The date and time the item was created. */
    created: string;
    /** Bearer token */
    key: string;
    /** The date and time the item was last modified. */
    modified: string;
    /** A short description of a TURN key, not shown to end users. */
    name: string;
    /** A Cloudflare-generated unique identifier for a item. */
    uid: string;
}
export interface DeleteSfuRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a item. */
    appId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSfuResponse {
    /** The date and time the item was created. */
    created: string;
    /** The date and time the item was last modified. */
    modified: string;
    /** A short description of a Realtime SFU app, not shown to end users. */
    name: string;
    /** A Cloudflare-generated unique identifier for a item. */
    uid: string;
}
export interface DeleteTurnRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a item. */
    keyId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteTurnResponse {
    /** The date and time the item was created. */
    created: string;
    /** The date and time the item was last modified. */
    modified: string;
    /** A short description of a Realtime SFU app, not shown to end users. */
    name: string;
    /** A Cloudflare-generated unique identifier for a item. */
    uid: string;
}
export interface GetSfuRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a item. */
    appId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSfuResponse {
    /** The date and time the item was created. */
    created: string;
    /** The date and time the item was last modified. */
    modified: string;
    /** A short description of a Realtime SFU app, not shown to end users. */
    name: string;
    /** A Cloudflare-generated unique identifier for a item. */
    uid: string;
}
export interface GetTurnRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a item. */
    keyId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTurnResponse {
    /** The date and time the item was created. */
    created: string;
    /** The date and time the item was last modified. */
    modified: string;
    /** A short description of a Realtime SFU app, not shown to end users. */
    name: string;
    /** A Cloudflare-generated unique identifier for a item. */
    uid: string;
}
export interface ListSfusRequest {
    /** The account identifier tag. */
    accountId: string;
}
export interface SfuListResultItem {
    /** The date and time the item was created. */
    created: string;
    /** The date and time the item was last modified. */
    modified: string;
    /** A short description of a Realtime SFU app, not shown to end users. */
    name: string;
    /** A Cloudflare-generated unique identifier for a item. */
    uid: string;
}
export type SfuListResultList = Array<SfuListResultItem>;
export interface ListSfusResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SfuListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListTurnsRequest {
    /** The account identifier tag. */
    accountId: string;
}
export type TurnListResultItem = SfuListResultItem;
export type TurnListResultList = Array<SfuListResultItem>;
export interface ListTurnsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TurnListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface UpdateSfuRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a item. */
    appId: string;
    /** A short description of a Realtime SFU app, not shown to end users. */
    name?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSfuResponse {
    /** The date and time the item was created. */
    created: string;
    /** The date and time the item was last modified. */
    modified: string;
    /** A short description of a Realtime SFU app, not shown to end users. */
    name: string;
    /** A Cloudflare-generated unique identifier for a item. */
    uid: string;
}
export interface UpdateTurnRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a item. */
    keyId: string;
    /** A short description of a TURN key, not shown to end users. */
    name?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTurnResponse {
    /** The date and time the item was created. */
    created: string;
    /** The date and time the item was last modified. */
    modified: string;
    /** A short description of a Realtime SFU app, not shown to end users. */
    name: string;
    /** A Cloudflare-generated unique identifier for a item. */
    uid: string;
}
export type CreateSfuError = Forbidden | CloudflareOpError;
/** Creates a Realtime SFU app. An app is an isolated namespace in which sessions can access the app's tracks. */
export declare const createSfu: API.OperationMethod<CreateSfuRequest, CreateSfuResponse, CreateSfuError, CloudflareOpContext>;
export type CreateTurnError = Forbidden | CloudflareOpError;
/** Creates a new Realtime TURN key. */
export declare const createTurn: API.OperationMethod<CreateTurnRequest, CreateTurnResponse, CreateTurnError, CloudflareOpContext>;
export type DeleteSfuError = CallsAppNotFound | Forbidden | CloudflareOpError;
/** Deletes a Realtime SFU app. */
export declare const deleteSfu: API.OperationMethod<DeleteSfuRequest, DeleteSfuResponse, DeleteSfuError, CloudflareOpContext>;
export type DeleteTurnError = TurnKeyNotFound | Forbidden | CloudflareOpError;
/** Deletes a Realtime TURN key. */
export declare const deleteTurn: API.OperationMethod<DeleteTurnRequest, DeleteTurnResponse, DeleteTurnError, CloudflareOpContext>;
export type GetSfuError = CallsAppNotFound | Forbidden | CloudflareOpError;
/** Fetches details for a single Realtime SFU app. */
export declare const getSfu: API.OperationMethod<GetSfuRequest, GetSfuResponse, GetSfuError, CloudflareOpContext>;
export type GetTurnError = TurnKeyNotFound | Forbidden | CloudflareOpError;
/** Fetches details for a single TURN key. */
export declare const getTurn: API.OperationMethod<GetTurnRequest, GetTurnResponse, GetTurnError, CloudflareOpContext>;
export type ListSfusError = CloudflareOpError;
/** Lists all apps in the Cloudflare account */
export declare const listSfus: API.PaginatedOperationMethod<ListSfusRequest, ListSfusResponse, ListSfusError, CloudflareOpContext, SfuListResultItem>;
export type ListTurnsError = CloudflareOpError;
/** Lists all TURN keys in the Cloudflare account. */
export declare const listTurns: API.PaginatedOperationMethod<ListTurnsRequest, ListTurnsResponse, ListTurnsError, CloudflareOpContext, SfuListResultItem>;
export type UpdateSfuError = CallsAppNotFound | Forbidden | CloudflareOpError;
/** Updates details for a single Realtime SFU app. */
export declare const updateSfu: API.OperationMethod<UpdateSfuRequest, UpdateSfuResponse, UpdateSfuError, CloudflareOpContext>;
export type UpdateTurnError = TurnKeyNotFound | Forbidden | CloudflareOpError;
/** Updates details for a single TURN key. */
export declare const updateTurn: API.OperationMethod<UpdateTurnRequest, UpdateTurnResponse, UpdateTurnError, CloudflareOpContext>;
//# sourceMappingURL=calls.d.ts.map