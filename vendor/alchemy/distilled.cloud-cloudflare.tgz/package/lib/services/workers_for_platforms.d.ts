import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const D1DatabaseNotFound_base: S.TaggedErrorClass<"D1DatabaseNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class D1DatabaseNotFound extends /*@__PURE__*/ D1DatabaseNotFound_base {
}
declare const DispatchNamespaceAlreadyExists_base: S.TaggedErrorClass<"DispatchNamespaceAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DispatchNamespaceAlreadyExists extends /*@__PURE__*/ DispatchNamespaceAlreadyExists_base {
}
declare const DispatchNamespaceNotFound_base: S.TaggedErrorClass<"DispatchNamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DispatchNamespaceNotFound extends /*@__PURE__*/ DispatchNamespaceNotFound_base {
}
declare const DispatchNamespaceScriptNotFound_base: S.TaggedErrorClass<"DispatchNamespaceScriptNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DispatchNamespaceScriptNotFound extends /*@__PURE__*/ DispatchNamespaceScriptNotFound_base {
}
declare const DurableObjectClassNotFound_base: S.TaggedErrorClass<"DurableObjectClassNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DurableObjectClassNotFound extends /*@__PURE__*/ DurableObjectClassNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HyperdriveConfigNotFound_base: S.TaggedErrorClass<"HyperdriveConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HyperdriveConfigNotFound extends /*@__PURE__*/ HyperdriveConfigNotFound_base {
}
declare const KVNamespaceNotFound_base: S.TaggedErrorClass<"KVNamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class KVNamespaceNotFound extends /*@__PURE__*/ KVNamespaceNotFound_base {
}
declare const MtlsCertificateNotFound_base: S.TaggedErrorClass<"MtlsCertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MtlsCertificateNotFound extends /*@__PURE__*/ MtlsCertificateNotFound_base {
}
declare const QueueNotFound_base: S.TaggedErrorClass<"QueueNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class QueueNotFound extends /*@__PURE__*/ QueueNotFound_base {
}
declare const R2BucketNotFound_base: S.TaggedErrorClass<"R2BucketNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class R2BucketNotFound extends /*@__PURE__*/ R2BucketNotFound_base {
}
declare const SecretsStoreBindingNotFound_base: S.TaggedErrorClass<"SecretsStoreBindingNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SecretsStoreBindingNotFound extends /*@__PURE__*/ SecretsStoreBindingNotFound_base {
}
declare const ServiceBindingNotFound_base: S.TaggedErrorClass<"ServiceBindingNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ServiceBindingNotFound extends /*@__PURE__*/ ServiceBindingNotFound_base {
}
declare const VectorizeIndexNotFound_base: S.TaggedErrorClass<"VectorizeIndexNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class VectorizeIndexNotFound extends /*@__PURE__*/ VectorizeIndexNotFound_base {
}
declare const WorkerHasNoVersions_base: S.TaggedErrorClass<"WorkerHasNoVersions", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WorkerHasNoVersions extends /*@__PURE__*/ WorkerHasNoVersions_base {
}
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretTextType = "secret_text";
export interface DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretTextType;
}
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyType = "secret_key";
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyUsagesList = Array<DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyUsagesItem | (string & {})>;
export interface DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyFormat | (string & {});
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown;
}
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValue = DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretText | DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValueSecretKey;
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsMap = {
    [key: string]: DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsValue | undefined;
};
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestVersionTagsMap = {
    [key: string]: unknown | undefined;
};
export interface BulkUpdateDispatchNamespaceScriptSecretsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
    /** Map of secret names to secret values: */
    secrets?: DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsMap;
    /** Optional version tags to apply to the new script version. */
    versionTags?: DispatchNamespacesScriptsSecretsBulkUpdateRequestVersionTagsMap;
}
export type DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretTextType = "secret_text";
export interface DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretTextType;
}
export type DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretKeyType = "secret_key";
export type DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretKeyUsagesList = Array<DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretKeyUsagesItem>;
export interface DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type DispatchNamespacesScriptsSecretsBulkUpdateResultValue = DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretText | DispatchNamespacesScriptsSecretsBulkUpdateResultValueSecretKey;
export type DispatchNamespacesScriptsSecretsBulkUpdateResultMap = {
    [key: string]: DispatchNamespacesScriptsSecretsBulkUpdateResultValue | undefined;
};
export type BulkUpdateDispatchNamespaceScriptSecretsResponse = DispatchNamespacesScriptsSecretsBulkUpdateResultMap;
export interface CreateDispatchNamespaceRequest {
    /** Identifier. */
    accountId: string;
    /** The name of the dispatch namespace. */
    name?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDispatchNamespaceResponse {
    /** Identifier. */
    createdBy?: string | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Identifier. */
    modifiedBy?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** API Resource UUID tag. */
    namespaceId?: string | null;
    /** Name of the Workers for Platforms dispatch namespace. */
    namespaceName?: string | null;
    /** The current number of scripts in this Dispatch Namespace. */
    scriptCount?: number | null;
    /** Whether the Workers in the namespace are executed in a "trusted" manner. When a Worker is trusted, it has access to the shared caches for the zone in the Cache API, and has access to the `request.cf` object on incoming Requests. When a Worker is untrusted, caches are not shared across the zone, and `request.cf` is undefined. By default, Workers in a namespace are "untrusted". */
    trustedWorkers?: boolean | null;
}
export interface DispatchNamespacesScriptsAssetUploadCreateRequestManifestValue {
    /** The hash of the file. */
    hash: string;
    /** The size of the file in bytes. */
    size: number;
}
export type DispatchNamespacesScriptsAssetUploadCreateRequestManifestMap = {
    [key: string]: DispatchNamespacesScriptsAssetUploadCreateRequestManifestValue | undefined;
};
export interface CreateDispatchNamespaceScriptAssetUploadRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
    /** A manifest ([path]: {hash, size}) map of files to upload. As an example, `/blog/hello-world.html` would be a valid path key. */
    manifest: DispatchNamespacesScriptsAssetUploadCreateRequestManifestMap;
}
export type DispatchNamespacesScriptsAssetUploadCreateResponseBucketsItemList = Array<string>;
export type DispatchNamespacesScriptsAssetUploadCreateResponseBucketsList = Array<DispatchNamespacesScriptsAssetUploadCreateResponseBucketsItemList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDispatchNamespaceScriptAssetUploadResponse {
    /** The requests to make to upload assets. */
    buckets?: DispatchNamespacesScriptsAssetUploadCreateResponseBucketsList | null;
    /** A JWT to use as authentication for uploading assets. */
    jwt?: string | null;
}
export interface DeleteDispatchNamespaceRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
}
export type DeleteDispatchNamespaceResponse = unknown;
export interface DeleteDispatchNamespaceScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
    /** If true, delete the script even when other Workers still reference it. Service bindings in those Workers may be left broken. Durable Object namespaces implemented by the deleted script are deleted even if other Workers reference them. */
    force?: boolean;
}
export type DeleteDispatchNamespaceScriptResponse = unknown;
export interface DeleteDispatchNamespaceScriptSecretRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
    /** A JavaScript variable name for the secret binding. */
    secretName: string;
    /** Flag that indicates whether the secret name is URL encoded. */
    urlEncoded?: boolean;
}
export type DeleteDispatchNamespaceScriptSecretResponse = unknown;
export interface DeleteDispatchNamespaceScriptTagRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
    /** A typed tag key containing only Unicode letters or numbers, underscores, periods, or hyphens. The complete UTF-8 encoded tag (the key plus `=` and the value when the value is non-empty) must not exceed 1024 bytes. Cloudflare-reserved prefixes are not accepted. */
    tag: string;
    apiVersion?: string;
}
export type DispatchNamespacesScriptsTagsDeleteResultMap = {
    [key: string]: string | undefined;
};
export type DeleteDispatchNamespaceScriptTagResponse = DispatchNamespacesScriptsTagsDeleteResultMap;
export interface GetDispatchNamespaceRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDispatchNamespaceResponse {
    /** Identifier. */
    createdBy?: string | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Identifier. */
    modifiedBy?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** API Resource UUID tag. */
    namespaceId?: string | null;
    /** Name of the Workers for Platforms dispatch namespace. */
    namespaceName?: string | null;
    /** The current number of scripts in this Dispatch Namespace. */
    scriptCount?: number | null;
    /** Whether the Workers in the namespace are executed in a "trusted" manner. When a Worker is trusted, it has access to the shared caches for the zone in the Cache API, and has access to the `request.cf` object on incoming Requests. When a Worker is untrusted, caches are not shared across the zone, and `request.cf` is undefined. By default, Workers in a namespace are "untrusted". */
    trustedWorkers?: boolean | null;
}
export interface GetDispatchNamespaceScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
}
export interface DispatchNamespacesScriptsGetResponseScriptCacheOptions {
    /** Whether caching is enabled for this Worker. */
    enabled: boolean;
    /** Whether cached responses are shared across Worker version uploads. This is independent of `enabled`. It can stay true while caching is off, so the preference survives turning caching off and back on. */
    crossVersionCache?: boolean | null;
}
export type DispatchNamespacesScriptsGetResponseScriptCompatibilityFlagsList = Array<string>;
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerType = "worker";
export interface DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerCache {
    /** Whether caching is enabled for this entrypoint. */
    enabled: boolean;
}
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerState = "created";
export interface DispatchNamespacesScriptsGetResponseScriptExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerState | null;
}
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExportType = "durable-object";
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExportState = "created";
export interface DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExportState | null;
}
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectDeletedExportType;
}
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectRenamedExportType;
}
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectTransferredExportType;
}
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type DispatchNamespacesScriptsGetResponseScriptExportsValue = DispatchNamespacesScriptsGetResponseScriptExportsValueWorker | DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExport | DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectDeletedExport | DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectRenamedExport | DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectTransferredExport | DispatchNamespacesScriptsGetResponseScriptExportsValueWorkersDurableObjectExpectingTransferExport;
export type DispatchNamespacesScriptsGetResponseScriptExportsMap = {
    [key: string]: DispatchNamespacesScriptsGetResponseScriptExportsValue | undefined;
};
export type DispatchNamespacesScriptsGetResponseScriptHandlersList = Array<string>;
export type DispatchNamespacesScriptsGetResponseScriptNamedHandlersItemHandlersList = Array<string>;
export interface DispatchNamespacesScriptsGetResponseScriptNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: DispatchNamespacesScriptsGetResponseScriptNamedHandlersItemHandlersList | null;
    /** The name of the export. */
    name?: string | null;
}
export type DispatchNamespacesScriptsGetResponseScriptNamedHandlersList = Array<DispatchNamespacesScriptsGetResponseScriptNamedHandlersItem>;
export interface DispatchNamespacesScriptsGetResponseScriptObservabilityIssues {
    /** Whether real-time Issues are enabled for the Worker. */
    enabled?: boolean | null;
}
export type DispatchNamespacesScriptsGetResponseScriptObservabilityLogsDestinationsList = Array<string>;
export interface DispatchNamespacesScriptsGetResponseScriptObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: DispatchNamespacesScriptsGetResponseScriptObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type DispatchNamespacesScriptsGetResponseScriptObservabilityTracesDestinationsList = Array<string>;
export type DispatchNamespacesScriptsGetResponseScriptObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface DispatchNamespacesScriptsGetResponseScriptObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: DispatchNamespacesScriptsGetResponseScriptObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: DispatchNamespacesScriptsGetResponseScriptObservabilityTracesPropagationPolicy | null;
}
export interface DispatchNamespacesScriptsGetResponseScriptObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: DispatchNamespacesScriptsGetResponseScriptObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: DispatchNamespacesScriptsGetResponseScriptObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: DispatchNamespacesScriptsGetResponseScriptObservabilityTraces | null;
}
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase0Mode = "smart";
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase0Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase0 {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: DispatchNamespacesScriptsGetResponseScriptPlacementCase0Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase0Status | null;
}
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase1Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase1 {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase1Status | null;
}
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase2Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase2 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase2Status | null;
}
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase3Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase3 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase3Status | null;
}
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase4Mode = "targeted";
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase4Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase4 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsGetResponseScriptPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase4Status | null;
}
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase5Mode = "targeted";
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase5Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsGetResponseScriptPlacementCase5Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase5Status | null;
}
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase6Mode = "targeted";
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase6Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsGetResponseScriptPlacementCase6Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase6Status | null;
}
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase7Mode = "targeted";
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion {
    /** Cloud region in format 'provider:region'. */
    region: string;
}
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname {
    /** HTTP hostname for targeted placement. */
    hostname: string;
}
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost {
    /** TCP host:port for targeted placement. */
    host: string;
}
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItem = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetList = Array<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItem>;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase7Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase7 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsGetResponseScriptPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetList;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase7Status | null;
}
export type DispatchNamespacesScriptsGetResponseScriptPlacement = DispatchNamespacesScriptsGetResponseScriptPlacementCase0 | DispatchNamespacesScriptsGetResponseScriptPlacementCase1 | DispatchNamespacesScriptsGetResponseScriptPlacementCase2 | DispatchNamespacesScriptsGetResponseScriptPlacementCase3 | DispatchNamespacesScriptsGetResponseScriptPlacementCase4 | DispatchNamespacesScriptsGetResponseScriptPlacementCase5 | DispatchNamespacesScriptsGetResponseScriptPlacementCase6 | DispatchNamespacesScriptsGetResponseScriptPlacementCase7;
export type DispatchNamespacesScriptsGetResponseScriptPlacementMode = "smart" | "targeted";
export type DispatchNamespacesScriptsGetResponseScriptPlacementStatus = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export type DispatchNamespacesScriptsGetResponseScriptTagsList = Array<string>;
export interface DispatchNamespacesScriptsGetResponseScriptTailConsumersItem {
    /** Name of Worker that is to be the consumer. */
    service: string;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
    /** Optional dispatch namespace the script belongs to. */
    namespace?: string | null;
}
export type DispatchNamespacesScriptsGetResponseScriptTailConsumersList = Array<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export type DispatchNamespacesScriptsGetResponseScriptUsageModel = "standard" | "bundled" | "unbound";
export interface DispatchNamespacesScriptsGetResponseScript {
    /** The name used to identify the script. */
    id?: string | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: DispatchNamespacesScriptsGetResponseScriptCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: DispatchNamespacesScriptsGetResponseScriptCompatibilityFlagsList | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Hashed script content, can be used in a If-None-Match header when updating. */
    etag?: string | null;
    /** Declarative exports for the Worker's most recent version, including Durable Object classes (with their `storage` backend) and named Worker entrypoints. Tombstoned lifecycle entries are omitted, so only live exports (`created` and `expecting-transfer`) are returned. */
    exports?: DispatchNamespacesScriptsGetResponseScriptExportsMap | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: DispatchNamespacesScriptsGetResponseScriptHandlersList | null;
    /** Whether a Worker contains assets. */
    hasAssets?: boolean | null;
    /** Whether a Worker contains modules. */
    hasModules?: boolean | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: DispatchNamespacesScriptsGetResponseScriptNamedHandlersList | null;
    /** Observability settings for the Worker. */
    observability?: DispatchNamespacesScriptsGetResponseScriptObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: DispatchNamespacesScriptsGetResponseScriptPlacement | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placementMode?: DispatchNamespacesScriptsGetResponseScriptPlacementMode | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    placementStatus?: DispatchNamespacesScriptsGetResponseScriptPlacementStatus | null;
    /** The immutable ID of the script. */
    tag?: string | null;
    /** Tags associated with the Worker. */
    tags?: DispatchNamespacesScriptsGetResponseScriptTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: DispatchNamespacesScriptsGetResponseScriptTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: DispatchNamespacesScriptsGetResponseScriptUsageModel | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDispatchNamespaceScriptResponse {
    /** When the script was created. */
    createdOn?: string | null;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    script?: DispatchNamespacesScriptsGetResponseScript | null;
}
export interface GetDispatchNamespaceScriptBindingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
}
export type DispatchNamespacesScriptsBindingsGetResultItemAIType = "ai";
export interface DispatchNamespacesScriptsBindingsGetResultItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemAIType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemAISearchType = "ai_search";
export interface DispatchNamespacesScriptsBindingsGetResultItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export type DispatchNamespacesScriptsBindingsGetResultItemAISearchNamespaceType = "ai_search_namespace";
export interface DispatchNamespacesScriptsBindingsGetResultItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemAISearchNamespaceType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemMessagingType = "messaging";
export interface DispatchNamespacesScriptsBindingsGetResultItemMessaging {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Messaging namespace to bind to. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemMessagingType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemAnalyticsEngineType = "analytics_engine";
export interface DispatchNamespacesScriptsBindingsGetResultItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemAnalyticsEngineType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemArtifactsType = "artifacts";
export interface DispatchNamespacesScriptsBindingsGetResultItemArtifacts {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Artifacts namespace exposed to the Worker in the Worker's account. Must be 2-63 characters, start with an ASCII alphanumeric character, contain only ASCII alphanumeric characters, dots, underscores, and hyphens, and must not end with a hyphen. The namespace does not need to be created before binding it. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemArtifactsType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemAssetsType = "assets";
export interface DispatchNamespacesScriptsBindingsGetResultItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemAssetsType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemBrowserType = "browser";
export interface DispatchNamespacesScriptsBindingsGetResultItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemBrowserType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemD1Type = "d1";
export interface DispatchNamespacesScriptsBindingsGetResultItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemD1Type;
    /** This property has been renamed to `database_id`. */
    id?: string | null;
}
export type DispatchNamespacesScriptsBindingsGetResultItemDataBlobType = "data_blob";
export interface DispatchNamespacesScriptsBindingsGetResultItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemDataBlobType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceType = "dispatch_namespace";
export interface DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem {
    /** Name of the parameter. */
    name: string;
}
export type DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsList = Array<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem>;
export interface DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker {
    /** Entrypoint to invoke on the outbound worker. */
    entrypoint?: string | null;
    /** Environment of the outbound worker. */
    environment?: string | null;
    /** Name of the outbound worker. */
    service?: string | null;
}
export interface DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker | null;
}
export interface DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutbound | null;
}
export type DispatchNamespacesScriptsBindingsGetResultItemDurableObjectNamespaceType = "durable_object_namespace";
export interface DispatchNamespacesScriptsBindingsGetResultItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export type DispatchNamespacesScriptsBindingsGetResultItemHyperdriveType = "hyperdrive";
export interface DispatchNamespacesScriptsBindingsGetResultItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemHyperdriveType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemInheritType = "inherit";
export interface DispatchNamespacesScriptsBindingsGetResultItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from. This can be a version ID, or the literal "latest" to inherit from the most recently uploaded version, which may not be the deployed version. Defaults to "latest". Only the Workers API version endpoints under `/accounts/{account_id}/workers/workers/{worker_id}/versions` accept a version ID. Other endpoints, including script upload and script version upload, accept only "latest" and reject a version ID with error 10057. */
    versionId?: string | null;
}
export type DispatchNamespacesScriptsBindingsGetResultItemImagesType = "images";
export interface DispatchNamespacesScriptsBindingsGetResultItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemImagesType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemJsonType = "json";
export interface DispatchNamespacesScriptsBindingsGetResultItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemJsonType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemKVNamespaceType = "kv_namespace";
export interface DispatchNamespacesScriptsBindingsGetResultItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemKVNamespaceType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemMediaType = "media";
export interface DispatchNamespacesScriptsBindingsGetResultItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemMediaType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemMTLSCertificateType = "mtls_certificate";
export interface DispatchNamespacesScriptsBindingsGetResultItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemMTLSCertificateType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemPlainTextType = "plain_text";
export interface DispatchNamespacesScriptsBindingsGetResultItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemPlainTextType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemPipelinesType = "pipelines";
export interface DispatchNamespacesScriptsBindingsGetResultItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemPipelinesType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemK2Type = "k2";
export interface DispatchNamespacesScriptsBindingsGetResultItemK2 {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** ID of a K2 stream owned by the account deploying the Worker. */
    stream: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemK2Type;
}
export type DispatchNamespacesScriptsBindingsGetResultItemQueueType = "queue";
export interface DispatchNamespacesScriptsBindingsGetResultItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemQueueType;
}
export interface DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple {
    /** The limit (requests per period). */
    limit: number;
    /** The period in seconds. */
    period: number;
    /** Duration in seconds to apply the mitigation action after the rate limit is exceeded. Valid values are 0 (disabled), 10, or multiples of 60 up to 86400. Must be greater than or equal to the period when non-zero. */
    mitigationTimeout?: number | null;
}
export type DispatchNamespacesScriptsBindingsGetResultItemRatelimitType = "ratelimit";
export interface DispatchNamespacesScriptsBindingsGetResultItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemRatelimitType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemR2BucketType = "r2_bucket";
export type DispatchNamespacesScriptsBindingsGetResultItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high" | "us";
export interface DispatchNamespacesScriptsBindingsGetResultItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: DispatchNamespacesScriptsBindingsGetResultItemR2BucketJurisdiction | null;
}
export type DispatchNamespacesScriptsBindingsGetResultItemSecretTextType = "secret_text";
export interface DispatchNamespacesScriptsBindingsGetResultItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemSecretTextType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemSendEmailType = "send_email";
export type DispatchNamespacesScriptsBindingsGetResultItemSendEmailAllowedDestinationAddressesList = Array<string>;
export type DispatchNamespacesScriptsBindingsGetResultItemSendEmailAllowedSenderAddressesList = Array<string>;
export interface DispatchNamespacesScriptsBindingsGetResultItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: DispatchNamespacesScriptsBindingsGetResultItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: DispatchNamespacesScriptsBindingsGetResultItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export type DispatchNamespacesScriptsBindingsGetResultItemServiceType = "service";
export interface DispatchNamespacesScriptsBindingsGetResultItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export type DispatchNamespacesScriptsBindingsGetResultItemTextBlobType = "text_blob";
export interface DispatchNamespacesScriptsBindingsGetResultItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemTextBlobType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemVectorizeType = "vectorize";
export interface DispatchNamespacesScriptsBindingsGetResultItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemVectorizeType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemVersionMetadataType = "version_metadata";
export interface DispatchNamespacesScriptsBindingsGetResultItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemVersionMetadataType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemSecretsStoreSecretType = "secrets_store_secret";
export interface DispatchNamespacesScriptsBindingsGetResultItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemSecretsStoreSecretType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemFlagshipType = "flagship";
export interface DispatchNamespacesScriptsBindingsGetResultItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemFlagshipType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type DispatchNamespacesScriptsBindingsGetResultItemSecretKeyType = "secret_key";
export type DispatchNamespacesScriptsBindingsGetResultItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type DispatchNamespacesScriptsBindingsGetResultItemSecretKeyUsagesList = Array<DispatchNamespacesScriptsBindingsGetResultItemSecretKeyUsagesItem>;
export interface DispatchNamespacesScriptsBindingsGetResultItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsBindingsGetResultItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsBindingsGetResultItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type DispatchNamespacesScriptsBindingsGetResultItemWorkflowType = "workflow";
export interface DispatchNamespacesScriptsBindingsGetResultItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export type DispatchNamespacesScriptsBindingsGetResultItemWasmModuleType = "wasm_module";
export interface DispatchNamespacesScriptsBindingsGetResultItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemWasmModuleType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemVPCServiceType = "vpc_service";
export interface DispatchNamespacesScriptsBindingsGetResultItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemVPCServiceType;
}
export type DispatchNamespacesScriptsBindingsGetResultItemVPCNetworkType = "vpc_network";
export type DispatchNamespacesScriptsBindingsGetResultItemVPCNetworkIdentity = "runtime-email-alpha";
export interface DispatchNamespacesScriptsBindingsGetResultItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemVPCNetworkType;
    /** Enables Gateway identity for the binding. Requires network_id to be "cf1:network" and cannot be combined with tunnel_id. */
    identity?: DispatchNamespacesScriptsBindingsGetResultItemVPCNetworkIdentity | null;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export type DispatchNamespacesScriptsBindingsGetResultItem = DispatchNamespacesScriptsBindingsGetResultItemAI | DispatchNamespacesScriptsBindingsGetResultItemAISearch | DispatchNamespacesScriptsBindingsGetResultItemAISearchNamespace | DispatchNamespacesScriptsBindingsGetResultItemMessaging | DispatchNamespacesScriptsBindingsGetResultItemAnalyticsEngine | DispatchNamespacesScriptsBindingsGetResultItemArtifacts | DispatchNamespacesScriptsBindingsGetResultItemAssets | DispatchNamespacesScriptsBindingsGetResultItemBrowser | DispatchNamespacesScriptsBindingsGetResultItemD1 | DispatchNamespacesScriptsBindingsGetResultItemDataBlob | DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespace | DispatchNamespacesScriptsBindingsGetResultItemDurableObjectNamespace | DispatchNamespacesScriptsBindingsGetResultItemHyperdrive | DispatchNamespacesScriptsBindingsGetResultItemInherit | DispatchNamespacesScriptsBindingsGetResultItemImages | DispatchNamespacesScriptsBindingsGetResultItemJson | DispatchNamespacesScriptsBindingsGetResultItemKVNamespace | DispatchNamespacesScriptsBindingsGetResultItemMedia | DispatchNamespacesScriptsBindingsGetResultItemMTLSCertificate | DispatchNamespacesScriptsBindingsGetResultItemPlainText | DispatchNamespacesScriptsBindingsGetResultItemPipelines | DispatchNamespacesScriptsBindingsGetResultItemK2 | DispatchNamespacesScriptsBindingsGetResultItemQueue | DispatchNamespacesScriptsBindingsGetResultItemRatelimit | DispatchNamespacesScriptsBindingsGetResultItemR2Bucket | DispatchNamespacesScriptsBindingsGetResultItemSecretText | DispatchNamespacesScriptsBindingsGetResultItemSendEmail | DispatchNamespacesScriptsBindingsGetResultItemService | DispatchNamespacesScriptsBindingsGetResultItemTextBlob | DispatchNamespacesScriptsBindingsGetResultItemVectorize | DispatchNamespacesScriptsBindingsGetResultItemVersionMetadata | DispatchNamespacesScriptsBindingsGetResultItemSecretsStoreSecret | DispatchNamespacesScriptsBindingsGetResultItemFlagship | DispatchNamespacesScriptsBindingsGetResultItemSecretKey | DispatchNamespacesScriptsBindingsGetResultItemWorkflow | DispatchNamespacesScriptsBindingsGetResultItemWasmModule | DispatchNamespacesScriptsBindingsGetResultItemVPCService | DispatchNamespacesScriptsBindingsGetResultItemVPCNetwork;
export type DispatchNamespacesScriptsBindingsGetResultList = Array<DispatchNamespacesScriptsBindingsGetResultItem>;
export interface GetDispatchNamespaceScriptBindingResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DispatchNamespacesScriptsBindingsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetDispatchNamespaceScriptContentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
}
export interface GetDispatchNamespaceScriptContentResponse {
}
export interface GetDispatchNamespaceScriptSecretRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
    /** A JavaScript variable name for the secret binding. */
    secretName: string;
    /** Flag that indicates whether the secret name is URL encoded. */
    urlEncoded?: boolean;
}
export type DispatchNamespacesScriptsSecretsGetResultSecretTextType = "secret_text";
export interface DispatchNamespacesScriptsSecretsGetResultSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsGetResultSecretTextType;
}
export type DispatchNamespacesScriptsSecretsGetResultSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type DispatchNamespacesScriptsSecretsGetResultSecretKeyType = "secret_key";
export type DispatchNamespacesScriptsSecretsGetResultSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type DispatchNamespacesScriptsSecretsGetResultSecretKeyUsagesList = Array<DispatchNamespacesScriptsSecretsGetResultSecretKeyUsagesItem>;
export interface DispatchNamespacesScriptsSecretsGetResultSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSecretsGetResultSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsGetResultSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSecretsGetResultSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type DispatchNamespacesScriptsSecretsGetResult = DispatchNamespacesScriptsSecretsGetResultSecretText | DispatchNamespacesScriptsSecretsGetResultSecretKey;
export type GetDispatchNamespaceScriptSecretResponse = DispatchNamespacesScriptsSecretsGetResult;
export interface GetDispatchNamespaceScriptSettingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemAIType = "ai";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemAIType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchType = "ai_search";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchNamespaceType = "ai_search_namespace";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchNamespaceType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemMessagingType = "messaging";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemMessaging {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Messaging namespace to bind to. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemMessagingType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemAnalyticsEngineType = "analytics_engine";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemAnalyticsEngineType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemArtifactsType = "artifacts";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemArtifacts {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Artifacts namespace exposed to the Worker in the Worker's account. Must be 2-63 characters, start with an ASCII alphanumeric character, contain only ASCII alphanumeric characters, dots, underscores, and hyphens, and must not end with a hyphen. The namespace does not need to be created before binding it. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemArtifactsType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemAssetsType = "assets";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemAssetsType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemBrowserType = "browser";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemBrowserType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemD1Type = "d1";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemD1Type;
    /** This property has been renamed to `database_id`. */
    id?: string | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemDataBlobType = "data_blob";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemDataBlobType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceType = "dispatch_namespace";
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsItem = DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsList = Array<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutboundWorker = DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker | null;
}
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutbound | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemHyperdriveType = "hyperdrive";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemHyperdriveType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemInheritType = "inherit";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from. This can be a version ID, or the literal "latest" to inherit from the most recently uploaded version, which may not be the deployed version. Defaults to "latest". Only the Workers API version endpoints under `/accounts/{account_id}/workers/workers/{worker_id}/versions` accept a version ID. Other endpoints, including script upload and script version upload, accept only "latest" and reject a version ID with error 10057. */
    versionId?: string | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemImagesType = "images";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemImagesType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemJsonType = "json";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemJsonType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemKVNamespaceType = "kv_namespace";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemKVNamespaceType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemMediaType = "media";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemMediaType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemMTLSCertificateType = "mtls_certificate";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemMTLSCertificateType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemPlainTextType = "plain_text";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemPlainTextType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemPipelinesType = "pipelines";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemPipelinesType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemK2Type = "k2";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemK2 {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** ID of a K2 stream owned by the account deploying the Worker. */
    stream: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemK2Type;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemQueueType = "queue";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemQueueType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimitSimple = DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimitType = "ratelimit";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimitType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2BucketType = "r2_bucket";
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high" | "us";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2BucketJurisdiction | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretTextType = "secret_text";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretTextType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailType = "send_email";
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemServiceType = "service";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemTextBlobType = "text_blob";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemTextBlobType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemVectorizeType = "vectorize";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemVectorizeType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemVersionMetadataType = "version_metadata";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemVersionMetadataType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretsStoreSecretType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemFlagshipType = "flagship";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemFlagshipType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyType = "secret_key";
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyUsagesList = Array<DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyUsagesItem>;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemWorkflowType = "workflow";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemWasmModuleType = "wasm_module";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemWasmModuleType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCServiceType = "vpc_service";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCServiceType;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetworkType = "vpc_network";
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetworkIdentity = "runtime-email-alpha";
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetworkType;
    /** Enables Gateway identity for the binding. Requires network_id to be "cf1:network" and cannot be combined with tunnel_id. */
    identity?: DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetworkIdentity | null;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItem = DispatchNamespacesScriptsSettingsGetResponseBindingsItemAI | DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearch | DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchNamespace | DispatchNamespacesScriptsSettingsGetResponseBindingsItemMessaging | DispatchNamespacesScriptsSettingsGetResponseBindingsItemAnalyticsEngine | DispatchNamespacesScriptsSettingsGetResponseBindingsItemArtifacts | DispatchNamespacesScriptsSettingsGetResponseBindingsItemAssets | DispatchNamespacesScriptsSettingsGetResponseBindingsItemBrowser | DispatchNamespacesScriptsSettingsGetResponseBindingsItemD1 | DispatchNamespacesScriptsSettingsGetResponseBindingsItemDataBlob | DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespace | DispatchNamespacesScriptsSettingsGetResponseBindingsItemDurableObjectNamespace | DispatchNamespacesScriptsSettingsGetResponseBindingsItemHyperdrive | DispatchNamespacesScriptsSettingsGetResponseBindingsItemInherit | DispatchNamespacesScriptsSettingsGetResponseBindingsItemImages | DispatchNamespacesScriptsSettingsGetResponseBindingsItemJson | DispatchNamespacesScriptsSettingsGetResponseBindingsItemKVNamespace | DispatchNamespacesScriptsSettingsGetResponseBindingsItemMedia | DispatchNamespacesScriptsSettingsGetResponseBindingsItemMTLSCertificate | DispatchNamespacesScriptsSettingsGetResponseBindingsItemPlainText | DispatchNamespacesScriptsSettingsGetResponseBindingsItemPipelines | DispatchNamespacesScriptsSettingsGetResponseBindingsItemK2 | DispatchNamespacesScriptsSettingsGetResponseBindingsItemQueue | DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimit | DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2Bucket | DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretText | DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmail | DispatchNamespacesScriptsSettingsGetResponseBindingsItemService | DispatchNamespacesScriptsSettingsGetResponseBindingsItemTextBlob | DispatchNamespacesScriptsSettingsGetResponseBindingsItemVectorize | DispatchNamespacesScriptsSettingsGetResponseBindingsItemVersionMetadata | DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretsStoreSecret | DispatchNamespacesScriptsSettingsGetResponseBindingsItemFlagship | DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKey | DispatchNamespacesScriptsSettingsGetResponseBindingsItemWorkflow | DispatchNamespacesScriptsSettingsGetResponseBindingsItemWasmModule | DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCService | DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetwork;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsList = Array<DispatchNamespacesScriptsSettingsGetResponseBindingsItem>;
export type DispatchNamespacesScriptsSettingsGetResponseCacheOptions = DispatchNamespacesScriptsGetResponseScriptCacheOptions;
export type DispatchNamespacesScriptsSettingsGetResponseCompatibilityFlagsList = Array<string>;
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkerType = "worker";
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkerCache = DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerCache;
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkerState = "created";
export interface DispatchNamespacesScriptsSettingsGetResponseExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkerState | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExportType = "durable-object";
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExportState = "created";
export interface DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExportState | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectDeletedExportType;
}
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectRenamedExportType;
}
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectTransferredExportType;
}
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseExportsValue = DispatchNamespacesScriptsSettingsGetResponseExportsValueWorker | DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExport | DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectDeletedExport | DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectRenamedExport | DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectTransferredExport | DispatchNamespacesScriptsSettingsGetResponseExportsValueWorkersDurableObjectExpectingTransferExport;
export type DispatchNamespacesScriptsSettingsGetResponseExportsMap = {
    [key: string]: DispatchNamespacesScriptsSettingsGetResponseExportsValue | undefined;
};
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationCreatedList = Array<string>;
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationDeletedList = Array<string>;
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationInfoItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationInfoItemReferencingScriptsList = Array<string>;
export interface DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationInfoItem {
    /** The class name the info entry is about. */
    class: string;
    /** Human-readable explanation. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationInfoItemScenario;
    /** The provisioned namespace the entry relates to, when applicable. */
    namespaceId?: string | null;
    /** Other Workers in the account that still bind to the affected class. Advisory: while non-empty the tombstone is not yet safe to remove -- redeploy these Workers with bindings re-pointed first. */
    referencingScripts?: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationInfoItemReferencingScriptsList | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationInfoList = Array<DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationInfoItem>;
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationRemovableEntriesList = Array<string>;
export interface DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationRenamedItem {
    /** The original (source) class name. */
    from: string;
    /** The new class name (`renamed_to`). */
    to: string;
}
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationRenamedList = Array<DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationRenamedItem>;
export interface DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferPendingItem {
    /** The target-side class name awaiting transfer. */
    class: string;
    /** The source script the namespace will be transferred from. */
    from: string;
}
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferPendingList = Array<DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferPendingItem>;
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferredItemPhase = "committed";
export interface DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferredItem {
    /** The source class name that was transferred. */
    class: string;
    /** The transfer phase. Currently always `committed`. */
    phase: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferredItemPhase;
    /** The destination script that now owns the namespace. */
    to: string;
}
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferredList = Array<DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferredItem>;
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationUpdatedList = Array<string>;
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationWarningsItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export interface DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationWarningsItem {
    /** The class name the warning is about. */
    class: string;
    /** Human-readable explanation of the warning. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationWarningsItemScenario;
    /** The provisioned namespace the warning relates to, when applicable. */
    namespaceId?: string | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationWarningsList = Array<DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationWarningsItem>;
export interface DispatchNamespacesScriptsSettingsGetResponseExportsReconciliation {
    /** Class names for which a new namespace was provisioned. */
    created: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationCreatedList;
    /** Class names whose namespace was deleted by a `deleted` tombstone. */
    deleted: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationDeletedList;
    /** Non-blocking info entries (stale tombstones, tombstone applied with class still in code). See `exports_reconciliation_info`. */
    info: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationInfoList;
    /** Source class names whose tombstone entry is now stale and safe to delete from `exports` (no remaining referencing scripts). */
    removableEntries: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationRemovableEntriesList;
    /** Applied `renamed` tombstones. */
    renamed: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationRenamedList;
    /** Phase-1 transfer hints recorded on the target side. */
    transferPending: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferPendingList;
    /** Committed `transferred` tombstones (phase-2). */
    transferred: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferredList;
    /** Class names whose provisioned namespace was mutated in place. */
    updated: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationUpdatedList;
    /** Non-blocking warnings. See `exports_reconciliation_warning`. */
    warnings: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationWarningsList;
}
export interface DispatchNamespacesScriptsSettingsGetResponseLimits {
    /** The amount of CPU time this Worker can use in milliseconds. */
    cpuMs?: number | null;
    /** The number of subrequests this Worker can make per request. */
    subrequests?: number | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationNewClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export interface DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem {
    from?: string | null;
    to?: string | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export interface DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem {
    from?: string | null;
    fromScript?: string | null;
    to?: string | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesList | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export interface DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseMigrations = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigration | DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrations;
export type DispatchNamespacesScriptsSettingsGetResponseObservabilityIssues = DispatchNamespacesScriptsGetResponseScriptObservabilityIssues;
export type DispatchNamespacesScriptsSettingsGetResponseObservabilityLogsDestinationsList = Array<string>;
export interface DispatchNamespacesScriptsSettingsGetResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: DispatchNamespacesScriptsSettingsGetResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type DispatchNamespacesScriptsSettingsGetResponseObservabilityTracesDestinationsList = Array<string>;
export type DispatchNamespacesScriptsSettingsGetResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface DispatchNamespacesScriptsSettingsGetResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: DispatchNamespacesScriptsSettingsGetResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: DispatchNamespacesScriptsSettingsGetResponseObservabilityTracesPropagationPolicy | null;
}
export interface DispatchNamespacesScriptsSettingsGetResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: DispatchNamespacesScriptsGetResponseScriptObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: DispatchNamespacesScriptsSettingsGetResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: DispatchNamespacesScriptsSettingsGetResponseObservabilityTraces | null;
}
export type DispatchNamespacesScriptsSettingsGetResponsePlacementModeMode = "smart";
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: DispatchNamespacesScriptsSettingsGetResponsePlacementModeMode;
}
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementRegion {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type DispatchNamespacesScriptsSettingsGetResponsePlacementHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementHost {
    /** TCP host and port for targeted placement. */
    host: string;
}
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase4Mode = "targeted";
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsGetResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase5Mode = "targeted";
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsGetResponsePlacementCase5Mode;
}
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase6Mode = "targeted";
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsGetResponsePlacementCase6Mode;
}
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase7Mode = "targeted";
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItemRegion = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItemHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItemHost = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItem = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetList = Array<DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItem>;
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsGetResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetList;
}
export type DispatchNamespacesScriptsSettingsGetResponsePlacement = DispatchNamespacesScriptsSettingsGetResponsePlacementMode | DispatchNamespacesScriptsSettingsGetResponsePlacementRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsSettingsGetResponsePlacementHost | DispatchNamespacesScriptsSettingsGetResponsePlacementCase4 | DispatchNamespacesScriptsSettingsGetResponsePlacementCase5 | DispatchNamespacesScriptsSettingsGetResponsePlacementCase6 | DispatchNamespacesScriptsSettingsGetResponsePlacementCase7;
export type DispatchNamespacesScriptsSettingsGetResponseTagsList = Array<string>;
export type DispatchNamespacesScriptsSettingsGetResponseTailConsumersItem = DispatchNamespacesScriptsGetResponseScriptTailConsumersItem;
export type DispatchNamespacesScriptsSettingsGetResponseTailConsumersList = Array<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export type DispatchNamespacesScriptsSettingsGetResponseUsageModel = "standard" | "bundled" | "unbound";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDispatchNamespaceScriptSettingResponse {
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: DispatchNamespacesScriptsSettingsGetResponseBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: DispatchNamespacesScriptsGetResponseScriptCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: DispatchNamespacesScriptsSettingsGetResponseCompatibilityFlagsList | null;
    /** Declarative exports for the Worker. Worker entrypoint entries (`type: worker`) carry cache configuration for that entrypoint. */
    exports?: DispatchNamespacesScriptsSettingsGetResponseExportsMap | null;
    /** Summary of the declarative exports reconciliation that ran on this upload. Populated only when the uploaded metadata included an `exports` block. Durable Object entries drive reconciliation; `type: worker` entries do not contribute to this summary. */
    exportsReconciliation?: DispatchNamespacesScriptsSettingsGetResponseExportsReconciliation | null;
    /** Limits to apply for this Worker. */
    limits?: DispatchNamespacesScriptsSettingsGetResponseLimits | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** Migrations to apply for Durable Objects associated with this Worker. */
    migrations?: DispatchNamespacesScriptsSettingsGetResponseMigrations | null;
    /** Observability settings for the Worker. */
    observability?: DispatchNamespacesScriptsSettingsGetResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: DispatchNamespacesScriptsSettingsGetResponsePlacement | null;
    /** Tags associated with the Worker. */
    tags?: DispatchNamespacesScriptsSettingsGetResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: DispatchNamespacesScriptsSettingsGetResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: DispatchNamespacesScriptsSettingsGetResponseUsageModel | null;
}
export interface ListDispatchNamespacesRequest {
    /** Identifier. */
    accountId: string;
}
export interface DispatchNamespacesListResultItem {
    /** Identifier. */
    createdBy?: string | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Identifier. */
    modifiedBy?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** API Resource UUID tag. */
    namespaceId?: string | null;
    /** Name of the Workers for Platforms dispatch namespace. */
    namespaceName?: string | null;
    /** The current number of scripts in this Dispatch Namespace. */
    scriptCount?: number | null;
    /** Whether the Workers in the namespace are executed in a "trusted" manner. When a Worker is trusted, it has access to the shared caches for the zone in the Cache API, and has access to the `request.cf` object on incoming Requests. When a Worker is untrusted, caches are not shared across the zone, and `request.cf` is undefined. By default, Workers in a namespace are "untrusted". */
    trustedWorkers?: boolean | null;
}
export type DispatchNamespacesListResultList = Array<DispatchNamespacesListResultItem>;
export interface ListDispatchNamespacesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DispatchNamespacesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListDispatchNamespaceScriptSecretsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
}
export type DispatchNamespacesScriptsSecretsListResultItemSecretTextType = "secret_text";
export interface DispatchNamespacesScriptsSecretsListResultItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsListResultItemSecretTextType;
}
export type DispatchNamespacesScriptsSecretsListResultItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type DispatchNamespacesScriptsSecretsListResultItemSecretKeyType = "secret_key";
export type DispatchNamespacesScriptsSecretsListResultItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type DispatchNamespacesScriptsSecretsListResultItemSecretKeyUsagesList = Array<DispatchNamespacesScriptsSecretsListResultItemSecretKeyUsagesItem>;
export interface DispatchNamespacesScriptsSecretsListResultItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSecretsListResultItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsListResultItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSecretsListResultItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type DispatchNamespacesScriptsSecretsListResultItem = DispatchNamespacesScriptsSecretsListResultItemSecretText | DispatchNamespacesScriptsSecretsListResultItemSecretKey;
export type DispatchNamespacesScriptsSecretsListResultList = Array<DispatchNamespacesScriptsSecretsListResultItem>;
export interface ListDispatchNamespaceScriptSecretsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DispatchNamespacesScriptsSecretsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListDispatchNamespaceScriptTagsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
}
export type DispatchNamespacesScriptsTagsListResultList = Array<string>;
export interface ListDispatchNamespaceScriptTagsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DispatchNamespacesScriptsTagsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAIType = "ai";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAIType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAISearchType = "ai_search";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAISearchNamespaceType = "ai_search_namespace";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAISearchNamespaceType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemMessagingType = "messaging";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemMessaging {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Messaging namespace to bind to. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemMessagingType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAnalyticsEngineType = "analytics_engine";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAnalyticsEngineType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemArtifactsType = "artifacts";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemArtifacts {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Artifacts namespace exposed to the Worker in the Worker's account. Must be 2-63 characters, start with an ASCII alphanumeric character, contain only ASCII alphanumeric characters, dots, underscores, and hyphens, and must not end with a hyphen. The namespace does not need to be created before binding it. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemArtifactsType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAssetsType = "assets";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAssetsType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemBrowserType = "browser";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemBrowserType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemD1Type = "d1";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemD1Type;
    /** This property has been renamed to `database_id`. */
    id?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDataBlobType = "data_blob";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDataBlobType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDispatchNamespaceType = "dispatch_namespace";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDispatchNamespaceOutboundParamsItem = DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDispatchNamespaceOutboundParamsList = Array<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDispatchNamespaceOutboundWorker {
    /** Entrypoint to invoke on the outbound worker. */
    entrypoint?: string;
    /** Environment of the outbound worker. */
    environment?: string;
    /** Name of the outbound worker. */
    service?: string;
}
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDispatchNamespaceOutboundParamsList;
    /** Outbound worker. */
    worker?: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDispatchNamespaceOutboundWorker;
}
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDispatchNamespaceOutbound;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string;
    /** The environment of the script_name to bind to. */
    environment?: string;
    /** Namespace identifier tag. */
    namespaceId?: string;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemHyperdriveType = "hyperdrive";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemHyperdriveType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemInheritType = "inherit";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string;
    /** Identifier for the version to inherit the binding from. This can be a version ID, or the literal "latest" to inherit from the most recently uploaded version, which may not be the deployed version. Defaults to "latest". Only the Workers API version endpoints under `/accounts/{account_id}/workers/workers/{worker_id}/versions` accept a version ID. Other endpoints, including script upload and script version upload, accept only "latest" and reject a version ID with error 10057. */
    versionId?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemImagesType = "images";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemImagesType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemJsonType = "json";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemJsonType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemKVNamespaceType = "kv_namespace";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemKVNamespaceType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemMediaType = "media";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemMediaType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemMTLSCertificateType = "mtls_certificate";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemMTLSCertificateType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemPlainTextType = "plain_text";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemPlainTextType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemPipelinesType = "pipelines";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemPipelinesType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemK2Type = "k2";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemK2 {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** ID of a K2 stream owned by the account deploying the Worker. */
    stream: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemK2Type;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemQueueType = "queue";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemQueueType;
}
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemRatelimitSimple {
    /** The limit (requests per period). */
    limit: number;
    /** The period in seconds. */
    period: number;
    /** Duration in seconds to apply the mitigation action after the rate limit is exceeded. Valid values are 0 (disabled), 10, or multiples of 60 up to 86400. Must be greater than or equal to the period when non-zero. */
    mitigationTimeout?: number;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemRatelimitType = "ratelimit";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemRatelimitType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemR2BucketType = "r2_bucket";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high" | "us";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemR2BucketJurisdiction | (string & {});
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretTextType = "secret_text";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretTextType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSendEmailType = "send_email";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSendEmailAllowedDestinationAddressesList;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSendEmailAllowedSenderAddressesList;
    /** Destination address for the email. */
    destinationAddress?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemServiceType = "service";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string;
    /** Optional environment if the Worker utilizes one. */
    environment?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemTextBlobType = "text_blob";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemTextBlobType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVectorizeType = "vectorize";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVectorizeType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVersionMetadataType = "version_metadata";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVersionMetadataType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretsStoreSecretType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemFlagshipType = "flagship";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemFlagshipType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretKeyType = "secret_key";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretKeyUsagesList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretKeyUsagesItem | (string & {})>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretKeyFormat | (string & {});
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemWorkflowType = "workflow";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemWasmModuleType = "wasm_module";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemWasmModuleType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVPCServiceType = "vpc_service";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVPCServiceType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVPCNetworkType = "vpc_network";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVPCNetworkIdentity = "runtime-email-alpha";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVPCNetworkType;
    /** Enables Gateway identity for the binding. Requires network_id to be "cf1:network" and cannot be combined with tunnel_id. */
    identity?: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVPCNetworkIdentity | (string & {});
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItem = DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAI | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAISearch | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAISearchNamespace | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemMessaging | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAnalyticsEngine | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemArtifacts | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemAssets | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemBrowser | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemD1 | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDataBlob | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDispatchNamespace | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemDurableObjectNamespace | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemHyperdrive | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemInherit | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemImages | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemJson | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemKVNamespace | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemMedia | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemMTLSCertificate | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemPlainText | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemPipelines | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemK2 | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemQueue | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemRatelimit | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemR2Bucket | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretText | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSendEmail | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemService | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemTextBlob | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVectorize | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVersionMetadata | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretsStoreSecret | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemFlagship | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemSecretKey | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemWorkflow | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemWasmModule | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVPCService | DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItemVPCNetwork;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsItem>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsCacheOptions {
    /** Whether caching is enabled for this Worker. */
    enabled: boolean;
    /** Whether cached responses are shared across Worker version uploads. This is independent of `enabled`. It can stay true while caching is off, so the preference survives turning caching off and back on. */
    crossVersionCache?: boolean;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsCompatibilityFlagsList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkerType = "worker";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkerCache = DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerCache;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkerState = "created";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerCache;
    /** Live export. May be omitted; defaults to `created`. */
    state?: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkerState | (string & {});
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExportType = "durable-object";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExportState = "created";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExportStorage | (string & {});
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string;
    /** Live export. May be omitted; defaults to `created`. */
    state?: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExportState | (string & {});
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectDeletedExportType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectRenamedExportType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectTransferredExportType;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExpectingTransferExportStorage | (string & {});
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValue = DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorker | DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExport | DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectDeletedExport | DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectRenamedExport | DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectTransferredExport | DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValueWorkersDurableObjectExpectingTransferExport;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsMap = {
    [key: string]: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsValue | undefined;
};
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationCreatedList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationDeletedList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationInfoItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationInfoItemReferencingScriptsList = Array<string>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationInfoItem {
    /** The class name the info entry is about. */
    class: string;
    /** Human-readable explanation. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationInfoItemScenario | (string & {});
    /** The provisioned namespace the entry relates to, when applicable. */
    namespaceId?: string;
    /** Other Workers in the account that still bind to the affected class. Advisory: while non-empty the tombstone is not yet safe to remove -- redeploy these Workers with bindings re-pointed first. */
    referencingScripts?: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationInfoItemReferencingScriptsList;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationInfoList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationInfoItem>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationRemovableEntriesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationRenamedItem = DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationRenamedItem;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationRenamedList = Array<DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationRenamedItem>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationTransferPendingItem = DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferPendingItem;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationTransferPendingList = Array<DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferPendingItem>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationTransferredItemPhase = "committed";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationTransferredItem {
    /** The source class name that was transferred. */
    class: string;
    /** The transfer phase. Currently always `committed`. */
    phase: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationTransferredItemPhase | (string & {});
    /** The destination script that now owns the namespace. */
    to: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationTransferredList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationTransferredItem>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationUpdatedList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationWarningsItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationWarningsItem {
    /** The class name the warning is about. */
    class: string;
    /** Human-readable explanation of the warning. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationWarningsItemScenario | (string & {});
    /** The provisioned namespace the warning relates to, when applicable. */
    namespaceId?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationWarningsList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationWarningsItem>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliation {
    /** Class names for which a new namespace was provisioned. */
    created: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationCreatedList;
    /** Class names whose namespace was deleted by a `deleted` tombstone. */
    deleted: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationDeletedList;
    /** Non-blocking info entries (stale tombstones, tombstone applied with class still in code). See `exports_reconciliation_info`. */
    info: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationInfoList;
    /** Source class names whose tombstone entry is now stale and safe to delete from `exports` (no remaining referencing scripts). */
    removableEntries: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationRemovableEntriesList;
    /** Applied `renamed` tombstones. */
    renamed: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationRenamedList;
    /** Phase-1 transfer hints recorded on the target side. */
    transferPending: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationTransferPendingList;
    /** Committed `transferred` tombstones (phase-2). */
    transferred: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationTransferredList;
    /** Class names whose provisioned namespace was mutated in place. */
    updated: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationUpdatedList;
    /** Non-blocking warnings. See `exports_reconciliation_warning`. */
    warnings: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliationWarningsList;
}
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsLimits {
    /** The amount of CPU time this Worker can use in milliseconds. */
    cpuMs?: number;
    /** The number of subrequests this Worker can make per request. */
    subrequests?: number;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationNewClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationRenamedClassesItem {
    from?: string;
    to?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationRenamedClassesList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationRenamedClassesItem>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationTransferredClassesItem {
    from?: string;
    fromScript?: string;
    to?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationTransferredClassesList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationTransferredClassesItem>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationDeletedClassesList;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationNewClassesList;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationNewSqliteClassesList;
    /** Tag to set as the latest migration tag. */
    newTag?: string;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationRenamedClassesList;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationTransferredClassesList;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationRenamedClassesItem;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationRenamedClassesItem>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationTransferredClassesItem;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationTransferredClassesItem>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsItem>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string;
    /** Migrations to apply in order. */
    steps?: DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrationsStepsList;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsMigrations = DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigration | DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsWorkersMultipleStepMigrations;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsObservabilityIssues {
    /** Whether real-time Issues are enabled for the Worker. */
    enabled?: boolean;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsObservabilityLogsDestinationsList = Array<string>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: DispatchNamespacesScriptsSettingsEditRequestSettingsObservabilityLogsDestinationsList;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsObservabilityTracesDestinationsList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: DispatchNamespacesScriptsSettingsEditRequestSettingsObservabilityTracesDestinationsList;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: DispatchNamespacesScriptsSettingsEditRequestSettingsObservabilityTracesPropagationPolicy | (string & {});
}
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number;
    /** Real-time Issues settings for the Worker. */
    issues?: DispatchNamespacesScriptsSettingsEditRequestSettingsObservabilityIssues;
    /** Log settings for the Worker. */
    logs?: DispatchNamespacesScriptsSettingsEditRequestSettingsObservabilityLogs;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean;
    /** Trace settings for the Worker. */
    traces?: DispatchNamespacesScriptsSettingsEditRequestSettingsObservabilityTraces;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementModeMode = "smart";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementModeMode;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementRegion = DispatchNamespacesScriptsSettingsGetResponsePlacementRegion;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementHost = DispatchNamespacesScriptsSettingsGetResponsePlacementHost;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase4Mode = "targeted";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase4 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase5Mode = "targeted";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase5Mode;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase6Mode = "targeted";
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase6Mode;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase7Mode = "targeted";
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase7TargetItemRegion = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase7TargetItemHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase7TargetItemHost = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase7TargetItem = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase7TargetList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase7TargetItem>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase7 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase7TargetList;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsPlacement = DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementMode | DispatchNamespacesScriptsSettingsGetResponsePlacementRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsSettingsGetResponsePlacementHost | DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase4 | DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase5 | DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase6 | DispatchNamespacesScriptsSettingsEditRequestSettingsPlacementCase7;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsTagsList = Array<string>;
export interface DispatchNamespacesScriptsSettingsEditRequestSettingsTailConsumersItem {
    /** Name of Worker that is to be the consumer. */
    service: string;
    /** Optional environment if the Worker utilizes one. */
    environment?: string;
    /** Optional dispatch namespace the script belongs to. */
    namespace?: string;
}
export type DispatchNamespacesScriptsSettingsEditRequestSettingsTailConsumersList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsTailConsumersItem>;
export type DispatchNamespacesScriptsSettingsEditRequestSettingsUsageModel = "standard" | "bundled" | "unbound";
export interface DispatchNamespacesScriptsSettingsEditRequestSettings {
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: DispatchNamespacesScriptsSettingsEditRequestSettingsBindingsList;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: DispatchNamespacesScriptsSettingsEditRequestSettingsCacheOptions;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: DispatchNamespacesScriptsSettingsEditRequestSettingsCompatibilityFlagsList;
    /** Declarative exports for the Worker. Worker entrypoint entries (`type: worker`) carry cache configuration for that entrypoint. */
    exports?: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsMap;
    /** Summary of the declarative exports reconciliation that ran on this upload. Populated only when the uploaded metadata included an `exports` block. Durable Object entries drive reconciliation; `type: worker` entries do not contribute to this summary. */
    exportsReconciliation?: DispatchNamespacesScriptsSettingsEditRequestSettingsExportsReconciliation;
    /** Limits to apply for this Worker. */
    limits?: DispatchNamespacesScriptsSettingsEditRequestSettingsLimits;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean;
    /** Migrations to apply for Durable Objects associated with this Worker. */
    migrations?: DispatchNamespacesScriptsSettingsEditRequestSettingsMigrations;
    /** Observability settings for the Worker. */
    observability?: DispatchNamespacesScriptsSettingsEditRequestSettingsObservability;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: DispatchNamespacesScriptsSettingsEditRequestSettingsPlacement;
    /** Tags associated with the Worker. */
    tags?: DispatchNamespacesScriptsSettingsEditRequestSettingsTagsList;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: DispatchNamespacesScriptsSettingsEditRequestSettingsTailConsumersList;
    /** Usage model for the Worker invocations. */
    usageModel?: DispatchNamespacesScriptsSettingsEditRequestSettingsUsageModel | (string & {});
}
export interface PatchDispatchNamespaceScriptSettingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
    /** Script and version settings for Workers for Platforms namespace scripts. Same as script-and-version-settings-item but without annotations, which are not supported for namespace scripts. */
    settings?: DispatchNamespacesScriptsSettingsEditRequestSettings;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemAIType = "ai";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemAIType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchType = "ai_search";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchNamespaceType = "ai_search_namespace";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchNamespaceType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemMessagingType = "messaging";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemMessaging {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Messaging namespace to bind to. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemMessagingType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemAnalyticsEngineType = "analytics_engine";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemAnalyticsEngineType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemArtifactsType = "artifacts";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemArtifacts {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The Artifacts namespace exposed to the Worker in the Worker's account. Must be 2-63 characters, start with an ASCII alphanumeric character, contain only ASCII alphanumeric characters, dots, underscores, and hyphens, and must not end with a hyphen. The namespace does not need to be created before binding it. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemArtifactsType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemAssetsType = "assets";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemAssetsType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemBrowserType = "browser";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemBrowserType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemD1Type = "d1";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemD1Type;
    /** This property has been renamed to `database_id`. */
    id?: string | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemDataBlobType = "data_blob";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemDataBlobType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceType = "dispatch_namespace";
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsItem = DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsList = Array<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutboundWorker = DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker | null;
}
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutbound | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemHyperdriveType = "hyperdrive";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemHyperdriveType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemInheritType = "inherit";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from. This can be a version ID, or the literal "latest" to inherit from the most recently uploaded version, which may not be the deployed version. Defaults to "latest". Only the Workers API version endpoints under `/accounts/{account_id}/workers/workers/{worker_id}/versions` accept a version ID. Other endpoints, including script upload and script version upload, accept only "latest" and reject a version ID with error 10057. */
    versionId?: string | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemImagesType = "images";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemImagesType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemJsonType = "json";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemJsonType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemKVNamespaceType = "kv_namespace";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemKVNamespaceType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemMediaType = "media";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemMediaType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemMTLSCertificateType = "mtls_certificate";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemMTLSCertificateType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemPlainTextType = "plain_text";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemPlainTextType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemPipelinesType = "pipelines";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemPipelinesType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemK2Type = "k2";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemK2 {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** ID of a K2 stream owned by the account deploying the Worker. */
    stream: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemK2Type;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemQueueType = "queue";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemQueueType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimitSimple = DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimitType = "ratelimit";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimitType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2BucketType = "r2_bucket";
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high" | "us";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2BucketJurisdiction | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretTextType = "secret_text";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretTextType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailType = "send_email";
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemServiceType = "service";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemTextBlobType = "text_blob";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemTextBlobType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemVectorizeType = "vectorize";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemVectorizeType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemVersionMetadataType = "version_metadata";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemVersionMetadataType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretsStoreSecretType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemFlagshipType = "flagship";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemFlagshipType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyType = "secret_key";
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyUsagesList = Array<DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyUsagesItem>;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemWorkflowType = "workflow";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemWasmModuleType = "wasm_module";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemWasmModuleType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCServiceType = "vpc_service";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCServiceType;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetworkType = "vpc_network";
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetworkIdentity = "runtime-email-alpha";
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetworkType;
    /** Enables Gateway identity for the binding. Requires network_id to be "cf1:network" and cannot be combined with tunnel_id. */
    identity?: DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetworkIdentity | null;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItem = DispatchNamespacesScriptsSettingsEditResponseBindingsItemAI | DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearch | DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchNamespace | DispatchNamespacesScriptsSettingsEditResponseBindingsItemMessaging | DispatchNamespacesScriptsSettingsEditResponseBindingsItemAnalyticsEngine | DispatchNamespacesScriptsSettingsEditResponseBindingsItemArtifacts | DispatchNamespacesScriptsSettingsEditResponseBindingsItemAssets | DispatchNamespacesScriptsSettingsEditResponseBindingsItemBrowser | DispatchNamespacesScriptsSettingsEditResponseBindingsItemD1 | DispatchNamespacesScriptsSettingsEditResponseBindingsItemDataBlob | DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespace | DispatchNamespacesScriptsSettingsEditResponseBindingsItemDurableObjectNamespace | DispatchNamespacesScriptsSettingsEditResponseBindingsItemHyperdrive | DispatchNamespacesScriptsSettingsEditResponseBindingsItemInherit | DispatchNamespacesScriptsSettingsEditResponseBindingsItemImages | DispatchNamespacesScriptsSettingsEditResponseBindingsItemJson | DispatchNamespacesScriptsSettingsEditResponseBindingsItemKVNamespace | DispatchNamespacesScriptsSettingsEditResponseBindingsItemMedia | DispatchNamespacesScriptsSettingsEditResponseBindingsItemMTLSCertificate | DispatchNamespacesScriptsSettingsEditResponseBindingsItemPlainText | DispatchNamespacesScriptsSettingsEditResponseBindingsItemPipelines | DispatchNamespacesScriptsSettingsEditResponseBindingsItemK2 | DispatchNamespacesScriptsSettingsEditResponseBindingsItemQueue | DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimit | DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2Bucket | DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretText | DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmail | DispatchNamespacesScriptsSettingsEditResponseBindingsItemService | DispatchNamespacesScriptsSettingsEditResponseBindingsItemTextBlob | DispatchNamespacesScriptsSettingsEditResponseBindingsItemVectorize | DispatchNamespacesScriptsSettingsEditResponseBindingsItemVersionMetadata | DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretsStoreSecret | DispatchNamespacesScriptsSettingsEditResponseBindingsItemFlagship | DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKey | DispatchNamespacesScriptsSettingsEditResponseBindingsItemWorkflow | DispatchNamespacesScriptsSettingsEditResponseBindingsItemWasmModule | DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCService | DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetwork;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsList = Array<DispatchNamespacesScriptsSettingsEditResponseBindingsItem>;
export type DispatchNamespacesScriptsSettingsEditResponseCacheOptions = DispatchNamespacesScriptsGetResponseScriptCacheOptions;
export type DispatchNamespacesScriptsSettingsEditResponseCompatibilityFlagsList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkerType = "worker";
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkerCache = DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerCache;
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkerState = "created";
export interface DispatchNamespacesScriptsSettingsEditResponseExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkerState | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExportType = "durable-object";
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExportState = "created";
export interface DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExportState | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectDeletedExportType;
}
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectRenamedExportType;
}
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectTransferredExportType;
}
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseExportsValue = DispatchNamespacesScriptsSettingsEditResponseExportsValueWorker | DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExport | DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectDeletedExport | DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectRenamedExport | DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectTransferredExport | DispatchNamespacesScriptsSettingsEditResponseExportsValueWorkersDurableObjectExpectingTransferExport;
export type DispatchNamespacesScriptsSettingsEditResponseExportsMap = {
    [key: string]: DispatchNamespacesScriptsSettingsEditResponseExportsValue | undefined;
};
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationCreatedList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationDeletedList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationInfoItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationInfoItemReferencingScriptsList = Array<string>;
export interface DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationInfoItem {
    /** The class name the info entry is about. */
    class: string;
    /** Human-readable explanation. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationInfoItemScenario;
    /** The provisioned namespace the entry relates to, when applicable. */
    namespaceId?: string | null;
    /** Other Workers in the account that still bind to the affected class. Advisory: while non-empty the tombstone is not yet safe to remove -- redeploy these Workers with bindings re-pointed first. */
    referencingScripts?: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationInfoItemReferencingScriptsList | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationInfoList = Array<DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationInfoItem>;
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationRemovableEntriesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationRenamedItem = DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationRenamedItem;
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationRenamedList = Array<DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationRenamedItem>;
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationTransferPendingItem = DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferPendingItem;
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationTransferPendingList = Array<DispatchNamespacesScriptsSettingsGetResponseExportsReconciliationTransferPendingItem>;
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationTransferredItemPhase = "committed";
export interface DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationTransferredItem {
    /** The source class name that was transferred. */
    class: string;
    /** The transfer phase. Currently always `committed`. */
    phase: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationTransferredItemPhase;
    /** The destination script that now owns the namespace. */
    to: string;
}
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationTransferredList = Array<DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationTransferredItem>;
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationUpdatedList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationWarningsItemScenario = "code_class_not_in_exports" | "provisioned_class_missing_from_config" | "config_export_not_in_code" | "config_references_nonexistent_class" | "orphaned_provisioned_namespace" | "storage_type_mismatch" | "free_tier_requires_sqlite" | "invalid_export" | "tombstone_delete_class_still_in_code" | "tombstone_delete_blocked_by_external_bindings" | "tombstone_renamed_to_occupied" | "transferred_pending_not_found" | "transferred_target_missing" | "transferred_target_mismatch" | "phase_one_transfer_source_missing" | "phase_one_transfer_source_namespace_missing" | "phase_one_transfer_target_class_provisioned" | "phase_one_transfer_after_commit_mismatch" | "phase_one_transfer_duplicate" | "phase_one_transfer_target_in_dispatch_namespace" | "phase_one_transfer_source_in_dispatch_namespace" | "transferred_source_in_dispatch_namespace" | "transferred_target_in_dispatch_namespace" | "container_undeclared_reference" | "container_class_not_durable_object" | "container_wiring_inconsistent" | "container_multiple_durable_objects" | "transfer_container_parity_mismatch" | "transfer_container_parity_mismatch_on_commit" | "tombstone_class_still_in_code" | "stale_tombstone" | "transfer_receive_already_applied" | "transfer_receive_cleanup_complete";
export interface DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationWarningsItem {
    /** The class name the warning is about. */
    class: string;
    /** Human-readable explanation of the warning. */
    message: string;
    /** Stable, machine-readable tag identifying which reconciliation scenario produced an error, warning, or info entry. Clients may branch on this value instead of parsing `message`. */
    scenario: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationWarningsItemScenario;
    /** The provisioned namespace the warning relates to, when applicable. */
    namespaceId?: string | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationWarningsList = Array<DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationWarningsItem>;
export interface DispatchNamespacesScriptsSettingsEditResponseExportsReconciliation {
    /** Class names for which a new namespace was provisioned. */
    created: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationCreatedList;
    /** Class names whose namespace was deleted by a `deleted` tombstone. */
    deleted: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationDeletedList;
    /** Non-blocking info entries (stale tombstones, tombstone applied with class still in code). See `exports_reconciliation_info`. */
    info: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationInfoList;
    /** Source class names whose tombstone entry is now stale and safe to delete from `exports` (no remaining referencing scripts). */
    removableEntries: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationRemovableEntriesList;
    /** Applied `renamed` tombstones. */
    renamed: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationRenamedList;
    /** Phase-1 transfer hints recorded on the target side. */
    transferPending: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationTransferPendingList;
    /** Committed `transferred` tombstones (phase-2). */
    transferred: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationTransferredList;
    /** Class names whose provisioned namespace was mutated in place. */
    updated: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationUpdatedList;
    /** Non-blocking warnings. See `exports_reconciliation_warning`. */
    warnings: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliationWarningsList;
}
export type DispatchNamespacesScriptsSettingsEditResponseLimits = DispatchNamespacesScriptsSettingsGetResponseLimits;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationNewClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesItem = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesItem = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesList | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export interface DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsList = Array<DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export interface DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseMigrations = DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigration | DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrations;
export type DispatchNamespacesScriptsSettingsEditResponseObservabilityIssues = DispatchNamespacesScriptsGetResponseScriptObservabilityIssues;
export type DispatchNamespacesScriptsSettingsEditResponseObservabilityLogsDestinationsList = Array<string>;
export interface DispatchNamespacesScriptsSettingsEditResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: DispatchNamespacesScriptsSettingsEditResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type DispatchNamespacesScriptsSettingsEditResponseObservabilityTracesDestinationsList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface DispatchNamespacesScriptsSettingsEditResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: DispatchNamespacesScriptsSettingsEditResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: DispatchNamespacesScriptsSettingsEditResponseObservabilityTracesPropagationPolicy | null;
}
export interface DispatchNamespacesScriptsSettingsEditResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: DispatchNamespacesScriptsGetResponseScriptObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: DispatchNamespacesScriptsSettingsEditResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: DispatchNamespacesScriptsSettingsEditResponseObservabilityTraces | null;
}
export type DispatchNamespacesScriptsSettingsEditResponsePlacementModeMode = "smart";
export interface DispatchNamespacesScriptsSettingsEditResponsePlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: DispatchNamespacesScriptsSettingsEditResponsePlacementModeMode;
}
export type DispatchNamespacesScriptsSettingsEditResponsePlacementRegion = DispatchNamespacesScriptsSettingsGetResponsePlacementRegion;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementHost = DispatchNamespacesScriptsSettingsGetResponsePlacementHost;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase4Mode = "targeted";
export interface DispatchNamespacesScriptsSettingsEditResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsEditResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase5Mode = "targeted";
export interface DispatchNamespacesScriptsSettingsEditResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsEditResponsePlacementCase5Mode;
}
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase6Mode = "targeted";
export interface DispatchNamespacesScriptsSettingsEditResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsEditResponsePlacementCase6Mode;
}
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase7Mode = "targeted";
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItemRegion = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItemHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItemHost = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItem = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetList = Array<DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItem>;
export interface DispatchNamespacesScriptsSettingsEditResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsEditResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetList;
}
export type DispatchNamespacesScriptsSettingsEditResponsePlacement = DispatchNamespacesScriptsSettingsEditResponsePlacementMode | DispatchNamespacesScriptsSettingsGetResponsePlacementRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsSettingsGetResponsePlacementHost | DispatchNamespacesScriptsSettingsEditResponsePlacementCase4 | DispatchNamespacesScriptsSettingsEditResponsePlacementCase5 | DispatchNamespacesScriptsSettingsEditResponsePlacementCase6 | DispatchNamespacesScriptsSettingsEditResponsePlacementCase7;
export type DispatchNamespacesScriptsSettingsEditResponseTagsList = Array<string>;
export type DispatchNamespacesScriptsSettingsEditResponseTailConsumersItem = DispatchNamespacesScriptsGetResponseScriptTailConsumersItem;
export type DispatchNamespacesScriptsSettingsEditResponseTailConsumersList = Array<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export type DispatchNamespacesScriptsSettingsEditResponseUsageModel = "standard" | "bundled" | "unbound";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchDispatchNamespaceScriptSettingResponse {
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: DispatchNamespacesScriptsSettingsEditResponseBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: DispatchNamespacesScriptsGetResponseScriptCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: DispatchNamespacesScriptsSettingsEditResponseCompatibilityFlagsList | null;
    /** Declarative exports for the Worker. Worker entrypoint entries (`type: worker`) carry cache configuration for that entrypoint. */
    exports?: DispatchNamespacesScriptsSettingsEditResponseExportsMap | null;
    /** Summary of the declarative exports reconciliation that ran on this upload. Populated only when the uploaded metadata included an `exports` block. Durable Object entries drive reconciliation; `type: worker` entries do not contribute to this summary. */
    exportsReconciliation?: DispatchNamespacesScriptsSettingsEditResponseExportsReconciliation | null;
    /** Limits to apply for this Worker. */
    limits?: DispatchNamespacesScriptsSettingsGetResponseLimits | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** Migrations to apply for Durable Objects associated with this Worker. */
    migrations?: DispatchNamespacesScriptsSettingsEditResponseMigrations | null;
    /** Observability settings for the Worker. */
    observability?: DispatchNamespacesScriptsSettingsEditResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: DispatchNamespacesScriptsSettingsEditResponsePlacement | null;
    /** Tags associated with the Worker. */
    tags?: DispatchNamespacesScriptsSettingsEditResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: DispatchNamespacesScriptsSettingsEditResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: DispatchNamespacesScriptsSettingsEditResponseUsageModel | null;
}
export type DispatchNamespacesScriptsUpdateRequestBindingsInherit = "strict";
export interface PutDispatchNamespaceScriptMetadataAnnotations {
    workersMessage?: string;
    workersTag?: string;
    /** Alias to point at this version (e.g. for gradual deployments). */
    workersAlias?: string;
}
export type PutDispatchNamespaceScriptAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export type PutDispatchNamespaceScriptAssetsConfigNotFoundHandling = "none" | "404-page" | "single-page-application";
export type PutDispatchNamespaceScriptMetadataStringList = Array<string>;
export type PutDispatchNamespaceScriptAssetsConfigRunWorkerFirst = PutDispatchNamespaceScriptMetadataStringList | boolean;
export interface PutDispatchNamespaceScriptAssetsConfig {
    htmlHandling?: PutDispatchNamespaceScriptAssetsConfigHtmlHandling | (string & {});
    notFoundHandling?: PutDispatchNamespaceScriptAssetsConfigNotFoundHandling | (string & {});
    runWorkerFirst?: PutDispatchNamespaceScriptAssetsConfigRunWorkerFirst;
    serveDirectly?: boolean;
    headers?: string;
    redirects?: string;
}
export interface PutDispatchNamespaceScriptMetadataAssets {
    config?: PutDispatchNamespaceScriptAssetsConfig;
    jwt?: string;
}
export type PutDispatchNamespaceScriptBindingAiType = "ai";
export interface PutDispatchNamespaceScriptBindingAi {
    name: string;
    type: PutDispatchNamespaceScriptBindingAiType;
}
export type PutDispatchNamespaceScriptBindingAiSearchType = "ai_search";
export interface PutDispatchNamespaceScriptBindingAiSearch {
    instanceName: string;
    name: string;
    namespace?: string;
    type: PutDispatchNamespaceScriptBindingAiSearchType;
}
export type PutDispatchNamespaceScriptBindingAiSearchNamespaceType = "ai_search_namespace";
export interface PutDispatchNamespaceScriptBindingAiSearchNamespace {
    name: string;
    namespace: string;
    type: PutDispatchNamespaceScriptBindingAiSearchNamespaceType;
}
export type PutDispatchNamespaceScriptBindingAnalyticsEngineType = "analytics_engine";
export interface PutDispatchNamespaceScriptBindingAnalyticsEngine {
    dataset: string;
    name: string;
    type: PutDispatchNamespaceScriptBindingAnalyticsEngineType;
}
export type PutDispatchNamespaceScriptBindingAssetsType = "assets";
export interface PutDispatchNamespaceScriptBindingAssets {
    name: string;
    type: PutDispatchNamespaceScriptBindingAssetsType;
}
export type PutDispatchNamespaceScriptBindingBrowserType = "browser";
export interface PutDispatchNamespaceScriptBindingBrowser {
    name: string;
    type: PutDispatchNamespaceScriptBindingBrowserType;
}
export type PutDispatchNamespaceScriptBindingD1Type = "d1";
export interface PutDispatchNamespaceScriptBindingD1 {
    databaseId: string;
    name: string;
    id?: string;
    type: PutDispatchNamespaceScriptBindingD1Type;
}
export type PutDispatchNamespaceScriptBindingDataBlobType = "data_blob";
export interface PutDispatchNamespaceScriptBindingDataBlob {
    name: string;
    part: string;
    type: PutDispatchNamespaceScriptBindingDataBlobType;
}
export interface PutDispatchNamespaceScriptBindingDispatchNamespaceOutboundParam {
    name: string;
}
export type PutDispatchNamespaceScriptBindingDispatchNamespaceOutboundParamsList = Array<PutDispatchNamespaceScriptBindingDispatchNamespaceOutboundParam>;
export interface PutDispatchNamespaceScriptBindingDispatchNamespaceOutboundWorker {
    entrypoint?: string;
    environment?: string;
    service?: string;
}
export interface PutDispatchNamespaceScriptBindingDispatchNamespaceOutbound {
    params?: PutDispatchNamespaceScriptBindingDispatchNamespaceOutboundParamsList;
    worker?: PutDispatchNamespaceScriptBindingDispatchNamespaceOutboundWorker;
}
export type PutDispatchNamespaceScriptBindingDispatchNamespaceType = "dispatch_namespace";
export interface PutDispatchNamespaceScriptBindingDispatchNamespace {
    name: string;
    namespace: string;
    outbound?: PutDispatchNamespaceScriptBindingDispatchNamespaceOutbound;
    type: PutDispatchNamespaceScriptBindingDispatchNamespaceType;
}
export type PutDispatchNamespaceScriptBindingDurableObjectNamespaceType = "durable_object_namespace";
export interface PutDispatchNamespaceScriptBindingDurableObjectNamespace {
    name: string;
    className: string;
    dispatchNamespace?: string;
    environment?: string;
    namespaceId?: string;
    scriptName?: string;
    type: PutDispatchNamespaceScriptBindingDurableObjectNamespaceType;
}
export type PutDispatchNamespaceScriptBindingHyperdriveType = "hyperdrive";
export interface PutDispatchNamespaceScriptBindingHyperdrive {
    id: string;
    name: string;
    type: PutDispatchNamespaceScriptBindingHyperdriveType;
}
export type PutDispatchNamespaceScriptBindingInheritType = "inherit";
export interface PutDispatchNamespaceScriptBindingInherit {
    name: string;
    oldName?: string;
    versionId?: string;
    type: PutDispatchNamespaceScriptBindingInheritType;
}
export type PutDispatchNamespaceScriptBindingImagesType = "images";
export interface PutDispatchNamespaceScriptBindingImages {
    name: string;
    type: PutDispatchNamespaceScriptBindingImagesType;
}
export type PutDispatchNamespaceScriptBindingJsonType = "json";
export interface PutDispatchNamespaceScriptBindingJson {
    json: unknown;
    name: string;
    type: PutDispatchNamespaceScriptBindingJsonType;
}
export type PutDispatchNamespaceScriptBindingKvNamespaceType = "kv_namespace";
export interface PutDispatchNamespaceScriptBindingKvNamespace {
    name: string;
    namespaceId: string;
    type: PutDispatchNamespaceScriptBindingKvNamespaceType;
}
export type PutDispatchNamespaceScriptBindingMediaType = "media";
export interface PutDispatchNamespaceScriptBindingMedia {
    name: string;
    type: PutDispatchNamespaceScriptBindingMediaType;
}
export type PutDispatchNamespaceScriptBindingMtlsCertificateType = "mtls_certificate";
export interface PutDispatchNamespaceScriptBindingMtlsCertificate {
    certificateId: string;
    name: string;
    type: PutDispatchNamespaceScriptBindingMtlsCertificateType;
}
export type PutDispatchNamespaceScriptBindingPlainTextType = "plain_text";
export interface PutDispatchNamespaceScriptBindingPlainText {
    name: string;
    text: string;
    type: PutDispatchNamespaceScriptBindingPlainTextType;
}
export type PutDispatchNamespaceScriptBindingPipelinesType = "pipelines";
export interface PutDispatchNamespaceScriptBindingPipelines {
    name: string;
    pipeline: string;
    type: PutDispatchNamespaceScriptBindingPipelinesType;
}
export type PutDispatchNamespaceScriptBindingQueueType = "queue";
export interface PutDispatchNamespaceScriptBindingQueue {
    name: string;
    queueName: string;
    type: PutDispatchNamespaceScriptBindingQueueType;
}
export interface PutDispatchNamespaceScriptBindingRatelimitSimple {
    limit: number;
    period: number;
    mitigationTimeout?: number;
}
export type PutDispatchNamespaceScriptBindingRatelimitType = "ratelimit";
export interface PutDispatchNamespaceScriptBindingRatelimit {
    name: string;
    namespaceId: string;
    simple: PutDispatchNamespaceScriptBindingRatelimitSimple;
    type: PutDispatchNamespaceScriptBindingRatelimitType;
}
export type PutDispatchNamespaceScriptBindingR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export type PutDispatchNamespaceScriptBindingR2BucketType = "r2_bucket";
export interface PutDispatchNamespaceScriptBindingR2Bucket {
    bucketName: string;
    name: string;
    jurisdiction?: PutDispatchNamespaceScriptBindingR2BucketJurisdiction | (string & {});
    type: PutDispatchNamespaceScriptBindingR2BucketType;
}
export type PutDispatchNamespaceScriptBindingSecretTextType = "secret_text";
export interface PutDispatchNamespaceScriptBindingSecretText {
    name: string;
    text: string;
    type: PutDispatchNamespaceScriptBindingSecretTextType;
}
export type PutDispatchNamespaceScriptBindingSendEmailType = "send_email";
export interface PutDispatchNamespaceScriptBindingSendEmail {
    name: string;
    allowedDestinationAddresses?: PutDispatchNamespaceScriptMetadataStringList;
    allowedSenderAddresses?: PutDispatchNamespaceScriptMetadataStringList;
    destinationAddress?: string;
    type: PutDispatchNamespaceScriptBindingSendEmailType;
}
export type PutDispatchNamespaceScriptBindingServiceType = "service";
export interface PutDispatchNamespaceScriptBindingService {
    name: string;
    service: string;
    entrypoint?: string;
    environment?: string;
    type: PutDispatchNamespaceScriptBindingServiceType;
}
export type PutDispatchNamespaceScriptBindingTextBlobType = "text_blob";
export interface PutDispatchNamespaceScriptBindingTextBlob {
    name: string;
    part: string;
    type: PutDispatchNamespaceScriptBindingTextBlobType;
}
export type PutDispatchNamespaceScriptBindingVectorizeType = "vectorize";
export interface PutDispatchNamespaceScriptBindingVectorize {
    indexName: string;
    name: string;
    type: PutDispatchNamespaceScriptBindingVectorizeType;
}
export type PutDispatchNamespaceScriptBindingVersionMetadataType = "version_metadata";
export interface PutDispatchNamespaceScriptBindingVersionMetadata {
    name: string;
    type: PutDispatchNamespaceScriptBindingVersionMetadataType;
}
export type PutDispatchNamespaceScriptBindingSecretsStoreSecretType = "secrets_store_secret";
export interface PutDispatchNamespaceScriptBindingSecretsStoreSecret {
    name: string;
    secretName: string;
    storeId: string;
    type: PutDispatchNamespaceScriptBindingSecretsStoreSecretType;
}
export type PutDispatchNamespaceScriptBindingFlagshipType = "flagship";
export interface PutDispatchNamespaceScriptBindingFlagship {
    appId: string;
    name: string;
    type: PutDispatchNamespaceScriptBindingFlagshipType;
}
export type PutDispatchNamespaceScriptBindingSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type PutDispatchNamespaceScriptBindingSecretKeyUsage = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type PutDispatchNamespaceScriptBindingSecretKeyUsagesList = Array<PutDispatchNamespaceScriptBindingSecretKeyUsage | (string & {})>;
export type PutDispatchNamespaceScriptBindingSecretKeyType = "secret_key";
export interface PutDispatchNamespaceScriptBindingSecretKey {
    algorithm: unknown;
    format: PutDispatchNamespaceScriptBindingSecretKeyFormat | (string & {});
    name: string;
    usages: PutDispatchNamespaceScriptBindingSecretKeyUsagesList;
    keyBase64?: string;
    keyJwk?: unknown;
    type: PutDispatchNamespaceScriptBindingSecretKeyType;
}
export type PutDispatchNamespaceScriptBindingWorkflowType = "workflow";
export interface PutDispatchNamespaceScriptBindingWorkflow {
    name: string;
    workflowName: string;
    className: string;
    scriptName?: string;
    type: PutDispatchNamespaceScriptBindingWorkflowType;
}
export type PutDispatchNamespaceScriptBindingWasmModuleType = "wasm_module";
export interface PutDispatchNamespaceScriptBindingWasmModule {
    name: string;
    part: string;
    type: PutDispatchNamespaceScriptBindingWasmModuleType;
}
export type PutDispatchNamespaceScriptBindingVpcServiceType = "vpc_service";
export interface PutDispatchNamespaceScriptBindingVpcService {
    name: string;
    serviceId: string;
    type: PutDispatchNamespaceScriptBindingVpcServiceType;
}
export type PutDispatchNamespaceScriptBindingVpcNetworkType = "vpc_network";
export interface PutDispatchNamespaceScriptBindingVpcNetwork {
    name: string;
    networkId?: string;
    tunnelId?: string;
    type: PutDispatchNamespaceScriptBindingVpcNetworkType;
}
export type PutDispatchNamespaceScriptBindingWorkerLoaderType = "worker_loader";
export interface PutDispatchNamespaceScriptBindingWorkerLoader {
    name: string;
    type: PutDispatchNamespaceScriptBindingWorkerLoaderType;
}
export type PutDispatchNamespaceScriptBindingArtifactsType = "artifacts";
export interface PutDispatchNamespaceScriptBindingArtifacts {
    name: string;
    namespace: string;
    type: PutDispatchNamespaceScriptBindingArtifactsType;
}
export type PutDispatchNamespaceScriptBindingStreamType = "stream";
export interface PutDispatchNamespaceScriptBindingStream {
    name: string;
    type: PutDispatchNamespaceScriptBindingStreamType;
}
export type PutDispatchNamespaceScriptBindingK2Type = "k2";
export interface PutDispatchNamespaceScriptBindingK2 {
    name: string;
    /** ID of a K2 stream owned by the account deploying the Worker (32 lowercase hex characters). */
    stream: string;
    type: PutDispatchNamespaceScriptBindingK2Type;
}
export type PutDispatchNamespaceScriptBinding = PutDispatchNamespaceScriptBindingAi | PutDispatchNamespaceScriptBindingAiSearch | PutDispatchNamespaceScriptBindingAiSearchNamespace | PutDispatchNamespaceScriptBindingAnalyticsEngine | PutDispatchNamespaceScriptBindingAssets | PutDispatchNamespaceScriptBindingBrowser | PutDispatchNamespaceScriptBindingD1 | PutDispatchNamespaceScriptBindingDataBlob | PutDispatchNamespaceScriptBindingDispatchNamespace | PutDispatchNamespaceScriptBindingDurableObjectNamespace | PutDispatchNamespaceScriptBindingHyperdrive | PutDispatchNamespaceScriptBindingInherit | PutDispatchNamespaceScriptBindingImages | PutDispatchNamespaceScriptBindingJson | PutDispatchNamespaceScriptBindingKvNamespace | PutDispatchNamespaceScriptBindingMedia | PutDispatchNamespaceScriptBindingMtlsCertificate | PutDispatchNamespaceScriptBindingPlainText | PutDispatchNamespaceScriptBindingPipelines | PutDispatchNamespaceScriptBindingQueue | PutDispatchNamespaceScriptBindingRatelimit | PutDispatchNamespaceScriptBindingR2Bucket | PutDispatchNamespaceScriptBindingSecretText | PutDispatchNamespaceScriptBindingSendEmail | PutDispatchNamespaceScriptBindingService | PutDispatchNamespaceScriptBindingTextBlob | PutDispatchNamespaceScriptBindingVectorize | PutDispatchNamespaceScriptBindingVersionMetadata | PutDispatchNamespaceScriptBindingSecretsStoreSecret | PutDispatchNamespaceScriptBindingFlagship | PutDispatchNamespaceScriptBindingSecretKey | PutDispatchNamespaceScriptBindingWorkflow | PutDispatchNamespaceScriptBindingWasmModule | PutDispatchNamespaceScriptBindingVpcService | PutDispatchNamespaceScriptBindingVpcNetwork | PutDispatchNamespaceScriptBindingWorkerLoader | PutDispatchNamespaceScriptBindingArtifacts | PutDispatchNamespaceScriptBindingStream | PutDispatchNamespaceScriptBindingK2;
export type PutDispatchNamespaceScriptMetadataBindingsList = Array<PutDispatchNamespaceScriptBinding>;
export type ContainerImageMap = {
    [key: string]: string | undefined;
};
export interface PutDispatchNamespaceScriptContainer {
    className: string;
    name?: string;
    images?: ContainerImageMap;
}
export type PutDispatchNamespaceScriptMetadataContainersList = Array<PutDispatchNamespaceScriptContainer>;
export interface PutDispatchNamespaceScriptMetadataLimits {
    cpuMs?: number;
    subrequests?: number;
}
export type PutDispatchNamespaceScriptMigrationRenamedClass = DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationRenamedClassesItem;
export type PutDispatchNamespaceScriptMigrationRenamedClassesList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationRenamedClassesItem>;
export type PutDispatchNamespaceScriptMigrationTransferredClass = DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationTransferredClassesItem;
export type PutDispatchNamespaceScriptMigrationTransferredClassesList = Array<DispatchNamespacesScriptsSettingsEditRequestSettingsMigrationsSingleStepMigrationTransferredClassesItem>;
export interface PutDispatchNamespaceScriptSingleStepMigration {
    deletedClasses?: PutDispatchNamespaceScriptMetadataStringList;
    newClasses?: PutDispatchNamespaceScriptMetadataStringList;
    newSqliteClasses?: PutDispatchNamespaceScriptMetadataStringList;
    newTag?: string;
    oldTag?: string;
    renamedClasses?: PutDispatchNamespaceScriptMigrationRenamedClassesList;
    transferredClasses?: PutDispatchNamespaceScriptMigrationTransferredClassesList;
}
export interface PutDispatchNamespaceScriptMigrationStep {
    deletedClasses?: PutDispatchNamespaceScriptMetadataStringList;
    newClasses?: PutDispatchNamespaceScriptMetadataStringList;
    newSqliteClasses?: PutDispatchNamespaceScriptMetadataStringList;
    renamedClasses?: PutDispatchNamespaceScriptMigrationRenamedClassesList;
    transferredClasses?: PutDispatchNamespaceScriptMigrationTransferredClassesList;
}
export type PutDispatchNamespaceScriptMigrationStepsList = Array<PutDispatchNamespaceScriptMigrationStep>;
export interface PutDispatchNamespaceScriptMultipleStepMigrations {
    newTag?: string;
    oldTag?: string;
    steps?: PutDispatchNamespaceScriptMigrationStepsList;
}
export type PutDispatchNamespaceScriptMetadataMigrations = PutDispatchNamespaceScriptSingleStepMigration | PutDispatchNamespaceScriptMultipleStepMigrations;
export interface PutDispatchNamespaceScriptObservabilityLogs {
    enabled: boolean;
    invocationLogs: boolean;
    destinations?: PutDispatchNamespaceScriptMetadataStringList;
    headSamplingRate?: number | null;
    persist?: boolean;
}
export type PutDispatchNamespaceScriptObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface PutDispatchNamespaceScriptObservabilityTraces {
    destinations?: PutDispatchNamespaceScriptMetadataStringList;
    enabled?: boolean;
    headSamplingRate?: number | null;
    persist?: boolean;
    propagationPolicy?: PutDispatchNamespaceScriptObservabilityTracesPropagationPolicy | (string & {});
}
export interface PutDispatchNamespaceScriptObservabilityIssues {
    /** Whether Workers Issues error monitoring is enabled. */
    enabled: boolean;
}
export interface PutDispatchNamespaceScriptMetadataObservability {
    enabled?: boolean;
    headSamplingRate?: number | null;
    logs?: PutDispatchNamespaceScriptObservabilityLogs | null;
    traces?: PutDispatchNamespaceScriptObservabilityTraces | null;
    issues?: PutDispatchNamespaceScriptObservabilityIssues;
}
export type PutDispatchNamespaceScriptPlacementSmartMode = "smart";
export interface PutDispatchNamespaceScriptPlacementSmart {
    mode: PutDispatchNamespaceScriptPlacementSmartMode;
}
export interface PutDispatchNamespaceScriptPlacementRegion {
    region: string;
}
export interface PutDispatchNamespaceScriptPlacementHostname {
    hostname: string;
}
export interface PutDispatchNamespaceScriptPlacementHost {
    host: string;
}
export type PutDispatchNamespaceScriptPlacementTargetedMode = "targeted";
export interface PutDispatchNamespaceScriptPlacementTargetedRegion {
    mode: PutDispatchNamespaceScriptPlacementTargetedMode;
    region: string;
}
export interface PutDispatchNamespaceScriptPlacementTargetedHostname {
    hostname: string;
    mode: PutDispatchNamespaceScriptPlacementTargetedMode;
}
export interface PutDispatchNamespaceScriptPlacementTargetedHost {
    host: string;
    mode: PutDispatchNamespaceScriptPlacementTargetedMode;
}
export type PutDispatchNamespaceScriptPlacementTargetRegion = PutDispatchNamespaceScriptPlacementRegion;
export type PutDispatchNamespaceScriptPlacementTargetHostname = PutDispatchNamespaceScriptPlacementHostname;
export type PutDispatchNamespaceScriptPlacementTargetHost = PutDispatchNamespaceScriptPlacementHost;
export type PutDispatchNamespaceScriptPlacementTarget = PutDispatchNamespaceScriptPlacementRegion | PutDispatchNamespaceScriptPlacementHostname | PutDispatchNamespaceScriptPlacementHost;
export type PutDispatchNamespaceScriptPlacementTargetsList = Array<PutDispatchNamespaceScriptPlacementTarget>;
export interface PutDispatchNamespaceScriptPlacementTargetedList {
    mode: PutDispatchNamespaceScriptPlacementTargetedMode;
    target: PutDispatchNamespaceScriptPlacementTargetsList;
}
export type PutDispatchNamespaceScriptMetadataPlacement = PutDispatchNamespaceScriptPlacementSmart | PutDispatchNamespaceScriptPlacementRegion | PutDispatchNamespaceScriptPlacementHostname | PutDispatchNamespaceScriptPlacementHost | PutDispatchNamespaceScriptPlacementTargetedRegion | PutDispatchNamespaceScriptPlacementTargetedHostname | PutDispatchNamespaceScriptPlacementTargetedHost | PutDispatchNamespaceScriptPlacementTargetedList;
export interface PutDispatchNamespaceScriptTailConsumer {
    service: string;
    environment?: string;
    namespace?: string;
}
export type PutDispatchNamespaceScriptMetadataTailConsumersList = Array<PutDispatchNamespaceScriptTailConsumer>;
export type PutDispatchNamespaceScriptMetadataUsageModel = "standard" | "bundled" | "unbound";
export interface PutDispatchNamespaceScriptMetadataCache {
    enabled?: boolean;
    crossVersionCache?: boolean;
}
export type PutDispatchNamespaceScriptMetadataStreamingTailConsumersList = Array<PutDispatchNamespaceScriptTailConsumer>;
export type PutDispatchNamespaceScriptMetadataExportType = "worker" | "durable-object";
export type PutDispatchNamespaceScriptMetadataExportState = "created" | "deleted" | "renamed" | "transferred" | "expecting-transfer";
export interface PutDispatchNamespaceScriptMetadataExport {
    type?: PutDispatchNamespaceScriptMetadataExportType | (string & {});
    cache?: PutDispatchNamespaceScriptMetadataCache;
    storage?: string;
    container?: string;
    state?: PutDispatchNamespaceScriptMetadataExportState | (string & {});
    renamedTo?: string;
    transferredTo?: string;
    transferFrom?: string;
}
export type PutDispatchNamespaceScriptMetadataExports = {
    [key: string]: PutDispatchNamespaceScriptMetadataExport | undefined;
};
export interface PutDispatchNamespaceScriptMetadata {
    annotations?: PutDispatchNamespaceScriptMetadataAnnotations;
    assets?: PutDispatchNamespaceScriptMetadataAssets;
    bindings?: PutDispatchNamespaceScriptMetadataBindingsList;
    bodyPart?: string;
    compatibilityDate?: string;
    compatibilityFlags?: PutDispatchNamespaceScriptMetadataStringList;
    containers?: PutDispatchNamespaceScriptMetadataContainersList;
    keepAssets?: boolean;
    keepBindings?: PutDispatchNamespaceScriptMetadataStringList;
    limits?: PutDispatchNamespaceScriptMetadataLimits;
    logpush?: boolean;
    mainModule?: string;
    migrations?: PutDispatchNamespaceScriptMetadataMigrations;
    observability?: PutDispatchNamespaceScriptMetadataObservability;
    placement?: PutDispatchNamespaceScriptMetadataPlacement;
    tags?: PutDispatchNamespaceScriptMetadataStringList;
    tailConsumers?: PutDispatchNamespaceScriptMetadataTailConsumersList | null;
    usageModel?: PutDispatchNamespaceScriptMetadataUsageModel | (string & {});
    cacheOptions?: PutDispatchNamespaceScriptMetadataCache;
    streamingTailConsumers?: PutDispatchNamespaceScriptMetadataStreamingTailConsumersList | null;
    /** Per-export settings keyed by the verbatim export name (default for the default export). */
    exports?: PutDispatchNamespaceScriptMetadataExports;
}
export interface PutDispatchNamespaceScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
    /** When set to "strict", the upload will fail with error 10057 if any `inherit` type bindings cannot be resolved against the latest uploaded version of the script, which may not be the deployed version. Without this, unresolvable inherit bindings are silently dropped. */
    bindingsInherit?: DispatchNamespacesScriptsUpdateRequestBindingsInherit | (string & {});
    metadata: PutDispatchNamespaceScriptMetadata;
    /** Module / asset file parts, appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
}
export type DispatchNamespacesScriptsUpdateResponseCacheOptions = DispatchNamespacesScriptsGetResponseScriptCacheOptions;
export type DispatchNamespacesScriptsUpdateResponseCompatibilityFlagsList = Array<string>;
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkerType = "worker";
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkerCache = DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerCache;
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkerState = "created";
export interface DispatchNamespacesScriptsUpdateResponseExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: DispatchNamespacesScriptsUpdateResponseExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: DispatchNamespacesScriptsUpdateResponseExportsValueWorkerState | null;
}
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExportType = "durable-object";
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExportState = "created";
export interface DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExportState | null;
}
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectDeletedExportType;
}
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectRenamedExportType;
}
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectTransferredExportType;
}
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type DispatchNamespacesScriptsUpdateResponseExportsValue = DispatchNamespacesScriptsUpdateResponseExportsValueWorker | DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExport | DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectDeletedExport | DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectRenamedExport | DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectTransferredExport | DispatchNamespacesScriptsUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExport;
export type DispatchNamespacesScriptsUpdateResponseExportsMap = {
    [key: string]: DispatchNamespacesScriptsUpdateResponseExportsValue | undefined;
};
export type DispatchNamespacesScriptsUpdateResponseHandlersList = Array<string>;
export type DispatchNamespacesScriptsUpdateResponseNamedHandlersItemHandlersList = Array<string>;
export interface DispatchNamespacesScriptsUpdateResponseNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: DispatchNamespacesScriptsUpdateResponseNamedHandlersItemHandlersList | null;
    /** The name of the export. */
    name?: string | null;
}
export type DispatchNamespacesScriptsUpdateResponseNamedHandlersList = Array<DispatchNamespacesScriptsUpdateResponseNamedHandlersItem>;
export type DispatchNamespacesScriptsUpdateResponseObservabilityIssues = DispatchNamespacesScriptsGetResponseScriptObservabilityIssues;
export type DispatchNamespacesScriptsUpdateResponseObservabilityLogsDestinationsList = Array<string>;
export interface DispatchNamespacesScriptsUpdateResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: DispatchNamespacesScriptsUpdateResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type DispatchNamespacesScriptsUpdateResponseObservabilityTracesDestinationsList = Array<string>;
export type DispatchNamespacesScriptsUpdateResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface DispatchNamespacesScriptsUpdateResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: DispatchNamespacesScriptsUpdateResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: DispatchNamespacesScriptsUpdateResponseObservabilityTracesPropagationPolicy | null;
}
export interface DispatchNamespacesScriptsUpdateResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: DispatchNamespacesScriptsGetResponseScriptObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: DispatchNamespacesScriptsUpdateResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: DispatchNamespacesScriptsUpdateResponseObservabilityTraces | null;
}
export type DispatchNamespacesScriptsUpdateResponsePlacementCase0Mode = "smart";
export type DispatchNamespacesScriptsUpdateResponsePlacementCase0Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase0 {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: DispatchNamespacesScriptsUpdateResponsePlacementCase0Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase0Status | null;
}
export type DispatchNamespacesScriptsUpdateResponsePlacementCase1Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase1 {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase1Status | null;
}
export type DispatchNamespacesScriptsUpdateResponsePlacementCase2Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase2 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase2Status | null;
}
export type DispatchNamespacesScriptsUpdateResponsePlacementCase3Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase3 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase3Status | null;
}
export type DispatchNamespacesScriptsUpdateResponsePlacementCase4Mode = "targeted";
export type DispatchNamespacesScriptsUpdateResponsePlacementCase4Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsUpdateResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase4Status | null;
}
export type DispatchNamespacesScriptsUpdateResponsePlacementCase5Mode = "targeted";
export type DispatchNamespacesScriptsUpdateResponsePlacementCase5Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsUpdateResponsePlacementCase5Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase5Status | null;
}
export type DispatchNamespacesScriptsUpdateResponsePlacementCase6Mode = "targeted";
export type DispatchNamespacesScriptsUpdateResponsePlacementCase6Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsUpdateResponsePlacementCase6Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase6Status | null;
}
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7Mode = "targeted";
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItemRegion = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItemHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItemHost = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItem = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetList = Array<DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItem>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsUpdateResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetList;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase7Status | null;
}
export type DispatchNamespacesScriptsUpdateResponsePlacement = DispatchNamespacesScriptsUpdateResponsePlacementCase0 | DispatchNamespacesScriptsUpdateResponsePlacementCase1 | DispatchNamespacesScriptsUpdateResponsePlacementCase2 | DispatchNamespacesScriptsUpdateResponsePlacementCase3 | DispatchNamespacesScriptsUpdateResponsePlacementCase4 | DispatchNamespacesScriptsUpdateResponsePlacementCase5 | DispatchNamespacesScriptsUpdateResponsePlacementCase6 | DispatchNamespacesScriptsUpdateResponsePlacementCase7;
export type DispatchNamespacesScriptsUpdateResponsePlacementMode = "smart" | "targeted";
export type DispatchNamespacesScriptsUpdateResponsePlacementStatus = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export type DispatchNamespacesScriptsUpdateResponseTagsList = Array<string>;
export type DispatchNamespacesScriptsUpdateResponseTailConsumersItem = DispatchNamespacesScriptsGetResponseScriptTailConsumersItem;
export type DispatchNamespacesScriptsUpdateResponseTailConsumersList = Array<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export type DispatchNamespacesScriptsUpdateResponseUsageModel = "standard" | "bundled" | "unbound";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutDispatchNamespaceScriptResponse {
    startupTimeMs: number;
    /** The name used to identify the script. */
    id?: string | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: DispatchNamespacesScriptsGetResponseScriptCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: DispatchNamespacesScriptsUpdateResponseCompatibilityFlagsList | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** The entry point for the script. */
    entryPoint?: string | null;
    /** Hashed script content, can be used in a If-None-Match header when updating. */
    etag?: string | null;
    /** Declarative exports for the Worker's most recent version, including Durable Object classes (with their `storage` backend) and named Worker entrypoints. Tombstoned lifecycle entries are omitted, so only live exports (`created` and `expecting-transfer`) are returned. */
    exports?: DispatchNamespacesScriptsUpdateResponseExportsMap | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: DispatchNamespacesScriptsUpdateResponseHandlersList | null;
    /** Whether a Worker contains assets. */
    hasAssets?: boolean | null;
    /** Whether a Worker contains modules. */
    hasModules?: boolean | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: DispatchNamespacesScriptsUpdateResponseNamedHandlersList | null;
    /** Observability settings for the Worker. */
    observability?: DispatchNamespacesScriptsUpdateResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: DispatchNamespacesScriptsUpdateResponsePlacement | null;
    placementMode?: DispatchNamespacesScriptsUpdateResponsePlacementMode | null;
    placementStatus?: DispatchNamespacesScriptsUpdateResponsePlacementStatus | null;
    /** The immutable ID of the script. */
    tag?: string | null;
    /** Tags associated with the Worker. */
    tags?: DispatchNamespacesScriptsUpdateResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: DispatchNamespacesScriptsUpdateResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: DispatchNamespacesScriptsUpdateResponseUsageModel | null;
}
export interface DispatchNamespacesScriptsContentUpdateRequestMetadata {
    /** Name of the part in the multipart request that contains the script (e.g. the file adding a listener to the `fetch` event). Indicates a `service worker syntax` Worker. */
    bodyPart?: string;
    /** Name of the part in the multipart request that contains the main module (e.g. the file exporting a `fetch` handler). Indicates a `module syntax` Worker. */
    mainModule?: string;
}
export type DispatchNamespacesScriptsContentUpdateRequestFilesList = Array<string>;
export interface PutDispatchNamespaceScriptContentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
    /** JSON-encoded metadata about the uploaded parts and Worker configuration. */
    metadata: DispatchNamespacesScriptsContentUpdateRequestMetadata;
    /** An array of modules (often JavaScript files) comprising a Worker script. At least one module must be present and referenced in the metadata as `main_module` or `body_part` by filename. Possible Content-Type(s) are: `application/javascript+module`, `text/javascript+module`, `application/javascript`, `text/javascript`, `text/x-python`, `text/x-python-requirement`, `application/wasm`, `text/plain`, `application/octet-stream`, `application/source-map`. */
    files?: DispatchNamespacesScriptsContentUpdateRequestFilesList;
    cfworkerbodypart?: string;
    cfworkermainmodulepart?: string;
}
export type DispatchNamespacesScriptsContentUpdateResponseCacheOptions = DispatchNamespacesScriptsGetResponseScriptCacheOptions;
export type DispatchNamespacesScriptsContentUpdateResponseCompatibilityFlagsList = Array<string>;
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkerType = "worker";
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkerCache = DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerCache;
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkerState = "created";
export interface DispatchNamespacesScriptsContentUpdateResponseExportsValueWorker {
    /** Marks this entry as a Worker entrypoint export. */
    type: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkerType;
    /** Cache override for this entrypoint. Overrides the Worker's global `cache_options.enabled` for this entrypoint only. */
    cache?: DispatchNamespacesScriptsGetResponseScriptExportsValueWorkerCache | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkerState | null;
}
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExportStorage = "sqlite" | "legacy-kv";
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExportType = "durable-object";
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExportState = "created";
export interface DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExport {
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExportStorage;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object. When set, the namespace is container-enabled. Valid only on live entries. */
    container?: string | null;
    /** Live export. May be omitted; defaults to `created`. */
    state?: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExportState | null;
}
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectDeletedExportState = "deleted";
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectDeletedExportType = "durable-object";
export interface DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectDeletedExport {
    /** Tombstone that deletes the namespace. */
    state: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectDeletedExportState;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectDeletedExportType;
}
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectRenamedExportState = "renamed";
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectRenamedExportType = "durable-object";
export interface DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectRenamedExport {
    /** The destination class name. Must differ from the source class (the map key) and must be declared as a live (`created`) entry in the same `exports` map. Write-only: never present in GET responses. */
    renamedTo: string;
    /** Tombstone that renames the namespace's class. */
    state: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectRenamedExportState;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectRenamedExportType;
}
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectTransferredExportState = "transferred";
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectTransferredExportType = "durable-object";
export interface DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectTransferredExport {
    /** Tombstone that transfers the namespace to another script. */
    state: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectTransferredExportState;
    /** The destination script name. Must be in the same account and the same dispatch-namespace context (or both non-dispatch). Cross-dispatch-namespace transfers are rejected. Write-only: never present in GET responses. */
    transferredTo: string;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectTransferredExportType;
}
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportState = "expecting-transfer";
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage = "sqlite" | "legacy-kv";
export type DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportType = "durable-object";
export interface DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExport {
    /** Target side of a two-phase transfer. */
    state: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportState;
    /** Durable Object storage backend. `sqlite` is the recommended (and only) backend for new namespaces. `legacy-kv` is accepted only for a class whose namespace already exists as KV-backed; the `exports` flow never provisions a new `legacy-kv` namespace. */
    storage: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportStorage;
    /** The source script name to receive the namespace from. Must be in the same account and dispatch-namespace context. Present on reads for `expecting-transfer` entries. */
    transferFrom: string;
    /** Marks this entry as a Durable Object export. */
    type: DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExportType;
    /** Name of the container (declared in the upload's `metadata.containers`) that backs this Durable Object once the transfer settles. Valid only on live entries. */
    container?: string | null;
}
export type DispatchNamespacesScriptsContentUpdateResponseExportsValue = DispatchNamespacesScriptsContentUpdateResponseExportsValueWorker | DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExport | DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectDeletedExport | DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectRenamedExport | DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectTransferredExport | DispatchNamespacesScriptsContentUpdateResponseExportsValueWorkersDurableObjectExpectingTransferExport;
export type DispatchNamespacesScriptsContentUpdateResponseExportsMap = {
    [key: string]: DispatchNamespacesScriptsContentUpdateResponseExportsValue | undefined;
};
export type DispatchNamespacesScriptsContentUpdateResponseHandlersList = Array<string>;
export type DispatchNamespacesScriptsContentUpdateResponseNamedHandlersItemHandlersList = Array<string>;
export interface DispatchNamespacesScriptsContentUpdateResponseNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: DispatchNamespacesScriptsContentUpdateResponseNamedHandlersItemHandlersList | null;
    /** The name of the export. */
    name?: string | null;
}
export type DispatchNamespacesScriptsContentUpdateResponseNamedHandlersList = Array<DispatchNamespacesScriptsContentUpdateResponseNamedHandlersItem>;
export type DispatchNamespacesScriptsContentUpdateResponseObservabilityIssues = DispatchNamespacesScriptsGetResponseScriptObservabilityIssues;
export type DispatchNamespacesScriptsContentUpdateResponseObservabilityLogsDestinationsList = Array<string>;
export interface DispatchNamespacesScriptsContentUpdateResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: DispatchNamespacesScriptsContentUpdateResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export type DispatchNamespacesScriptsContentUpdateResponseObservabilityTracesDestinationsList = Array<string>;
export type DispatchNamespacesScriptsContentUpdateResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export interface DispatchNamespacesScriptsContentUpdateResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: DispatchNamespacesScriptsContentUpdateResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. Returns null when the trace propagation feature is not enabled for the account. */
    propagationPolicy?: DispatchNamespacesScriptsContentUpdateResponseObservabilityTracesPropagationPolicy | null;
}
export interface DispatchNamespacesScriptsContentUpdateResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Real-time Issues settings for the Worker. */
    issues?: DispatchNamespacesScriptsGetResponseScriptObservabilityIssues | null;
    /** Log settings for the Worker. */
    logs?: DispatchNamespacesScriptsContentUpdateResponseObservabilityLogs | null;
    /** Whether query strings are removed from request URLs in logs and traces. */
    redactQueryString?: boolean | null;
    /** Trace settings for the Worker. */
    traces?: DispatchNamespacesScriptsContentUpdateResponseObservabilityTraces | null;
}
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase0Mode = "smart";
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase0Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase0 {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: DispatchNamespacesScriptsContentUpdateResponsePlacementCase0Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase0Status | null;
}
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase1Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase1 {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase1Status | null;
}
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase2Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase2 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase2Status | null;
}
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase3Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase3 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase3Status | null;
}
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase4Mode = "targeted";
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase4Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsContentUpdateResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase4Status | null;
}
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase5Mode = "targeted";
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase5Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsContentUpdateResponsePlacementCase5Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase5Status | null;
}
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase6Mode = "targeted";
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase6Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsContentUpdateResponsePlacementCase6Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase6Status | null;
}
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7Mode = "targeted";
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItemRegion = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItemHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItemHost = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItem = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetList = Array<DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItem>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsContentUpdateResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetList;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase7Status | null;
}
export type DispatchNamespacesScriptsContentUpdateResponsePlacement = DispatchNamespacesScriptsContentUpdateResponsePlacementCase0 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase1 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase2 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase3 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase4 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase5 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase6 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase7;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementMode = "smart" | "targeted";
export type DispatchNamespacesScriptsContentUpdateResponsePlacementStatus = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export type DispatchNamespacesScriptsContentUpdateResponseTagsList = Array<string>;
export type DispatchNamespacesScriptsContentUpdateResponseTailConsumersItem = DispatchNamespacesScriptsGetResponseScriptTailConsumersItem;
export type DispatchNamespacesScriptsContentUpdateResponseTailConsumersList = Array<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export type DispatchNamespacesScriptsContentUpdateResponseUsageModel = "standard" | "bundled" | "unbound";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutDispatchNamespaceScriptContentResponse {
    /** The name used to identify the script. */
    id?: string | null;
    /** Global CacheW configuration for the Worker. When caching is on, the platform provisions a `cloudflare.app` zone for the Worker. A `type: worker` entry in the `exports` map can override this value for a single entrypoint. */
    cacheOptions?: DispatchNamespacesScriptsGetResponseScriptCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: DispatchNamespacesScriptsContentUpdateResponseCompatibilityFlagsList | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Hashed script content, can be used in a If-None-Match header when updating. */
    etag?: string | null;
    /** Declarative exports for the Worker's most recent version, including Durable Object classes (with their `storage` backend) and named Worker entrypoints. Tombstoned lifecycle entries are omitted, so only live exports (`created` and `expecting-transfer`) are returned. */
    exports?: DispatchNamespacesScriptsContentUpdateResponseExportsMap | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: DispatchNamespacesScriptsContentUpdateResponseHandlersList | null;
    /** Whether a Worker contains assets. */
    hasAssets?: boolean | null;
    /** Whether a Worker contains modules. */
    hasModules?: boolean | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: DispatchNamespacesScriptsContentUpdateResponseNamedHandlersList | null;
    /** Observability settings for the Worker. */
    observability?: DispatchNamespacesScriptsContentUpdateResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: DispatchNamespacesScriptsContentUpdateResponsePlacement | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placementMode?: DispatchNamespacesScriptsContentUpdateResponsePlacementMode | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    placementStatus?: DispatchNamespacesScriptsContentUpdateResponsePlacementStatus | null;
    /** The immutable ID of the script. */
    tag?: string | null;
    /** Tags associated with the Worker. */
    tags?: DispatchNamespacesScriptsContentUpdateResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: DispatchNamespacesScriptsContentUpdateResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: DispatchNamespacesScriptsContentUpdateResponseUsageModel | null;
}
export type DispatchNamespacesScriptsSecretsUpdateRequestType = "secret_text" | "secret_key";
export type DispatchNamespacesScriptsSecretsUpdateRequestFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type DispatchNamespacesScriptsSecretsUpdateRequestUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type DispatchNamespacesScriptsSecretsUpdateRequestUsagesList = Array<DispatchNamespacesScriptsSecretsUpdateRequestUsagesItem | (string & {})>;
export interface PutDispatchNamespaceScriptSecretRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text?: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsUpdateRequestType | (string & {});
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm?: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format?: DispatchNamespacesScriptsSecretsUpdateRequestFormat | (string & {});
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages?: DispatchNamespacesScriptsSecretsUpdateRequestUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown;
}
export type DispatchNamespacesScriptsSecretsUpdateResultSecretTextType = "secret_text";
export interface DispatchNamespacesScriptsSecretsUpdateResultSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsUpdateResultSecretTextType;
}
export type DispatchNamespacesScriptsSecretsUpdateResultSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export type DispatchNamespacesScriptsSecretsUpdateResultSecretKeyType = "secret_key";
export type DispatchNamespacesScriptsSecretsUpdateResultSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export type DispatchNamespacesScriptsSecretsUpdateResultSecretKeyUsagesList = Array<DispatchNamespacesScriptsSecretsUpdateResultSecretKeyUsagesItem>;
export interface DispatchNamespacesScriptsSecretsUpdateResultSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSecretsUpdateResultSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsUpdateResultSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSecretsUpdateResultSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export type DispatchNamespacesScriptsSecretsUpdateResult = DispatchNamespacesScriptsSecretsUpdateResultSecretText | DispatchNamespacesScriptsSecretsUpdateResultSecretKey;
export type PutDispatchNamespaceScriptSecretResponse = DispatchNamespacesScriptsSecretsUpdateResult;
export type DispatchNamespacesScriptsTagsUpdateRequestBodyList = Array<string>;
export interface PutDispatchNamespaceScriptTagRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script. */
    scriptName: string;
    /** Tags associated with the Worker. */
    body: DispatchNamespacesScriptsTagsUpdateRequestBodyList;
}
export type DispatchNamespacesScriptsTagsUpdateResultList = Array<string>;
export interface PutDispatchNamespaceScriptTagResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DispatchNamespacesScriptsTagsUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type BulkUpdateDispatchNamespaceScriptSecretsError = CloudflareOpError;
/** Create, update, or delete multiple secrets on a Workers for Platforms script in a single operation using JSON Merge Patch (RFC 7396). This operation creates a single version with all changes included. Prefer this API instead of changing many secrets individually. Usage: - To create or update a secret, set its value to a secret object. - To delete a secret, set its value to `null`. - Secrets not included in the request are left unchanged. */
export declare const bulkUpdateDispatchNamespaceScriptSecrets: API.OperationMethod<BulkUpdateDispatchNamespaceScriptSecretsRequest, BulkUpdateDispatchNamespaceScriptSecretsResponse, BulkUpdateDispatchNamespaceScriptSecretsError, CloudflareOpContext>;
export type CreateDispatchNamespaceError = DispatchNamespaceAlreadyExists | Forbidden | CloudflareOpError;
/** Create a new Workers for Platforms dispatch namespace. */
export declare const createDispatchNamespace: API.OperationMethod<CreateDispatchNamespaceRequest, CreateDispatchNamespaceResponse, CreateDispatchNamespaceError, CloudflareOpContext>;
export type CreateDispatchNamespaceScriptAssetUploadError = CloudflareOpError;
/** Start uploading a collection of assets for use in a Workers for Platforms script version. To learn more about the direct uploads of assets, see https://developers.cloudflare.com/workers/static-assets/direct-upload/. */
export declare const createDispatchNamespaceScriptAssetUpload: API.OperationMethod<CreateDispatchNamespaceScriptAssetUploadRequest, CreateDispatchNamespaceScriptAssetUploadResponse, CreateDispatchNamespaceScriptAssetUploadError, CloudflareOpContext>;
export type DeleteDispatchNamespaceError = DispatchNamespaceNotFound | Forbidden | CloudflareOpError;
/** Delete a Workers for Platforms dispatch namespace. */
export declare const deleteDispatchNamespace: API.OperationMethod<DeleteDispatchNamespaceRequest, DeleteDispatchNamespaceResponse, DeleteDispatchNamespaceError, CloudflareOpContext>;
export type DeleteDispatchNamespaceScriptError = DispatchNamespaceScriptNotFound | DispatchNamespaceNotFound | Forbidden | CloudflareOpError;
/** Delete a script from a Workers for Platforms dispatch namespace. This call has no response body on a successful delete. */
export declare const deleteDispatchNamespaceScript: API.OperationMethod<DeleteDispatchNamespaceScriptRequest, DeleteDispatchNamespaceScriptResponse, DeleteDispatchNamespaceScriptError, CloudflareOpContext>;
export type DeleteDispatchNamespaceScriptSecretError = CloudflareOpError;
/** Remove a secret from a Workers for Platforms script by creating a new version without that secret. When changing more than one secret at a time, prefer the "Patch multiple script secrets" API instead of changing many secrets individually. */
export declare const deleteDispatchNamespaceScriptSecret: API.OperationMethod<DeleteDispatchNamespaceScriptSecretRequest, DeleteDispatchNamespaceScriptSecretResponse, DeleteDispatchNamespaceScriptSecretError, CloudflareOpContext>;
export type DeleteDispatchNamespaceScriptTagError = CloudflareOpError;
/** Delete a tag from a script uploaded to a Workers for Platforms dispatch namespace. On `api-version` dates on or after `2026-10-01`, `tag` identifies a key and the operation returns the complete updated tag map. Deleting a missing key succeeds. Earlier versions retain the legacy string-tag behavior and return a null result. */
export declare const deleteDispatchNamespaceScriptTag: API.OperationMethod<DeleteDispatchNamespaceScriptTagRequest, DeleteDispatchNamespaceScriptTagResponse, DeleteDispatchNamespaceScriptTagError, CloudflareOpContext>;
export type GetDispatchNamespaceError = DispatchNamespaceNotFound | Forbidden | CloudflareOpError;
/** Get a Workers for Platforms dispatch namespace. */
export declare const getDispatchNamespace: API.OperationMethod<GetDispatchNamespaceRequest, GetDispatchNamespaceResponse, GetDispatchNamespaceError, CloudflareOpContext>;
export type GetDispatchNamespaceScriptError = DispatchNamespaceNotFound | DispatchNamespaceScriptNotFound | Forbidden | CloudflareOpError;
/** Fetch information about a script uploaded to a Workers for Platforms dispatch namespace. */
export declare const getDispatchNamespaceScript: API.OperationMethod<GetDispatchNamespaceScriptRequest, GetDispatchNamespaceScriptResponse, GetDispatchNamespaceScriptError, CloudflareOpContext>;
export type GetDispatchNamespaceScriptBindingError = CloudflareOpError;
/** Fetch bindings from a script uploaded to a Workers for Platforms dispatch namespace. */
export declare const getDispatchNamespaceScriptBinding: API.PaginatedOperationMethod<GetDispatchNamespaceScriptBindingRequest, GetDispatchNamespaceScriptBindingResponse, GetDispatchNamespaceScriptBindingError, CloudflareOpContext, DispatchNamespacesScriptsBindingsGetResultItem>;
export type GetDispatchNamespaceScriptContentError = CloudflareOpError;
/** Fetch content from a script uploaded to a Workers for Platforms dispatch namespace. */
export declare const getDispatchNamespaceScriptContent: API.OperationMethod<GetDispatchNamespaceScriptContentRequest, GetDispatchNamespaceScriptContentResponse, GetDispatchNamespaceScriptContentError, CloudflareOpContext>;
export type GetDispatchNamespaceScriptSecretError = CloudflareOpError;
/** Get a given secret binding (value omitted) on a script uploaded to a Workers for Platforms dispatch namespace. */
export declare const getDispatchNamespaceScriptSecret: API.OperationMethod<GetDispatchNamespaceScriptSecretRequest, GetDispatchNamespaceScriptSecretResponse, GetDispatchNamespaceScriptSecretError, CloudflareOpContext>;
export type GetDispatchNamespaceScriptSettingError = DispatchNamespaceNotFound | DispatchNamespaceScriptNotFound | Forbidden | WorkerHasNoVersions | CloudflareOpError;
/** Get settings for a script uploaded to a Workers for Platforms dispatch namespace. */
export declare const getDispatchNamespaceScriptSetting: API.OperationMethod<GetDispatchNamespaceScriptSettingRequest, GetDispatchNamespaceScriptSettingResponse, GetDispatchNamespaceScriptSettingError, CloudflareOpContext>;
export type ListDispatchNamespacesError = CloudflareOpError;
/** Fetch a list of Workers for Platforms dispatch namespaces. */
export declare const listDispatchNamespaces: API.PaginatedOperationMethod<ListDispatchNamespacesRequest, ListDispatchNamespacesResponse, ListDispatchNamespacesError, CloudflareOpContext, DispatchNamespacesListResultItem>;
export type ListDispatchNamespaceScriptSecretsError = CloudflareOpError;
/** List secrets bound to a script uploaded to a Workers for Platforms dispatch namespace. */
export declare const listDispatchNamespaceScriptSecrets: API.PaginatedOperationMethod<ListDispatchNamespaceScriptSecretsRequest, ListDispatchNamespaceScriptSecretsResponse, ListDispatchNamespaceScriptSecretsError, CloudflareOpContext, DispatchNamespacesScriptsSecretsListResultItem>;
export type ListDispatchNamespaceScriptTagsError = CloudflareOpError;
/** Fetch tags from a script uploaded to a Workers for Platforms dispatch namespace. */
export declare const listDispatchNamespaceScriptTags: API.PaginatedOperationMethod<ListDispatchNamespaceScriptTagsRequest, ListDispatchNamespaceScriptTagsResponse, ListDispatchNamespaceScriptTagsError, CloudflareOpContext, string>;
export type PatchDispatchNamespaceScriptSettingError = CloudflareOpError;
/** Patch metadata for a script uploaded to a Workers for Platforms dispatch namespace, such as bindings. */
export declare const patchDispatchNamespaceScriptSetting: API.OperationMethod<PatchDispatchNamespaceScriptSettingRequest, PatchDispatchNamespaceScriptSettingResponse, PatchDispatchNamespaceScriptSettingError, CloudflareOpContext>;
export type PutDispatchNamespaceScriptError = DispatchNamespaceNotFound | Forbidden | SecretsStoreBindingNotFound | KVNamespaceNotFound | R2BucketNotFound | D1DatabaseNotFound | QueueNotFound | ServiceBindingNotFound | DurableObjectClassNotFound | HyperdriveConfigNotFound | VectorizeIndexNotFound | MtlsCertificateNotFound | CloudflareOpError;
/** Upload a Workers for Platforms script module to a dispatch namespace. You can find more about the multipart metadata on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/. */
export declare const putDispatchNamespaceScript: API.OperationMethod<PutDispatchNamespaceScriptRequest, PutDispatchNamespaceScriptResponse, PutDispatchNamespaceScriptError, CloudflareOpContext>;
export type PutDispatchNamespaceScriptContentError = CloudflareOpError;
/** Replace content for a script uploaded to a Workers for Platforms dispatch namespace. */
export declare const putDispatchNamespaceScriptContent: API.OperationMethod<PutDispatchNamespaceScriptContentRequest, PutDispatchNamespaceScriptContentResponse, PutDispatchNamespaceScriptContentError, CloudflareOpContext>;
export type PutDispatchNamespaceScriptSecretError = CloudflareOpError;
/** Add a secret to a Workers for Platforms script by creating a new version with that secret. When changing more than one secret at a time, prefer the "Patch multiple script secrets" API instead of changing many secrets individually. */
export declare const putDispatchNamespaceScriptSecret: API.OperationMethod<PutDispatchNamespaceScriptSecretRequest, PutDispatchNamespaceScriptSecretResponse, PutDispatchNamespaceScriptSecretError, CloudflareOpContext>;
export type PutDispatchNamespaceScriptTagError = CloudflareOpError;
/** Replace tags for a script uploaded to a Workers for Platforms dispatch namespace. */
export declare const putDispatchNamespaceScriptTag: API.PaginatedOperationMethod<PutDispatchNamespaceScriptTagRequest, PutDispatchNamespaceScriptTagResponse, PutDispatchNamespaceScriptTagError, CloudflareOpContext, string>;
//# sourceMappingURL=workers_for_platforms.d.ts.map