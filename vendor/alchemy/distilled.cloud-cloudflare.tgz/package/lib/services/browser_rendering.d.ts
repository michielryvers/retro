import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface ActivateDevtoolBrowserTargetRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
    /** Target ID to activate. */
    targetId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ActivateDevtoolBrowserTargetResponse {
    /** Target activated. */
    message: string;
}
export interface CloseDevtoolBrowserTargetRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
    /** Target ID to close. */
    targetId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CloseDevtoolBrowserTargetResponse {
    /** Target is closing. */
    message: string;
}
export interface ConnectDevtoolBrowserRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID to connect to. */
    sessionId: string;
    /** Keep-alive time in ms (only valid when acquiring new session). */
    keepAlive?: number;
    /** Use experimental browser. */
    lab?: boolean;
    recording?: boolean;
    /** Optional base64url-encoded JSON connection guardrails (mode) */
    cfBrapiGuardrails?: string;
}
export interface ConnectDevtoolBrowserResponse {
}
export type CreateAccessibilityTreeRequestBrowser = "kitesurf";
export interface CreateAccessibilityTreeRequestAddScriptTagItem {
    id?: string;
    content?: string;
    type?: string;
    url?: string;
}
export type CreateAccessibilityTreeRequestAddScriptTagList = Array<CreateAccessibilityTreeRequestAddScriptTagItem>;
export interface CreateAccessibilityTreeRequestAddStyleTagItem {
    content?: string;
    url?: string;
}
export type CreateAccessibilityTreeRequestAddStyleTagList = Array<CreateAccessibilityTreeRequestAddStyleTagItem>;
export type CreateAccessibilityTreeRequestAllowRequestPatternList = Array<string>;
export type CreateAccessibilityTreeRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type CreateAccessibilityTreeRequestAllowResourceTypesList = Array<CreateAccessibilityTreeRequestAllowResourceTypesItem | (string & {})>;
export interface CreateAccessibilityTreeRequestAuthenticate {
    password: string;
    username: string;
}
export type CreateAccessibilityTreeRequestCookiesItemPriority = "Low" | "Medium" | "High";
export type CreateAccessibilityTreeRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export type CreateAccessibilityTreeRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export interface CreateAccessibilityTreeRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: CreateAccessibilityTreeRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: CreateAccessibilityTreeRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: CreateAccessibilityTreeRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export type CreateAccessibilityTreeRequestCookiesList = Array<CreateAccessibilityTreeRequestCookiesItem>;
export type CreateAccessibilityTreeRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type CreateAccessibilityTreeRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type CreateAccessibilityTreeRequestGotoOptionsWaitUntilCase1List = Array<CreateAccessibilityTreeRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export type CreateAccessibilityTreeRequestGotoOptionsWaitUntil = CreateAccessibilityTreeRequestGotoOptionsWaitUntilCase0 | (string & {}) | CreateAccessibilityTreeRequestGotoOptionsWaitUntilCase1List;
export interface CreateAccessibilityTreeRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: CreateAccessibilityTreeRequestGotoOptionsWaitUntil;
}
export type CreateAccessibilityTreeRequestRejectRequestPatternList = Array<string>;
export type CreateAccessibilityTreeRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type CreateAccessibilityTreeRequestRejectResourceTypesList = Array<CreateAccessibilityTreeRequestRejectResourceTypesItem | (string & {})>;
export type CreateAccessibilityTreeRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export interface CreateAccessibilityTreeRequestViewport {
    height: number;
    width: number;
    deviceScaleFactor?: number;
    hasTouch?: boolean;
    isLandscape?: boolean;
    isMobile?: boolean;
}
export interface CreateAccessibilityTreeRequestWaitForSelector {
    selector: string;
    hidden?: boolean;
    timeout?: number;
    visible?: boolean;
}
export interface CreateAccessibilityTreeRequest {
    /** Account ID. */
    accountId: string;
    /** Rendering backend. Set to `kitesurf` to use Kitesurf (beta). */
    browser?: CreateAccessibilityTreeRequestBrowser | (string & {});
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    url?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a script element into the page with the desired URL or content. */
    addScriptTag?: CreateAccessibilityTreeRequestAddScriptTagList;
    /** Adds a `&lt;link rel="stylesheet"&gt;` tag into the page with the desired URL or a `&lt;style type="text/css"&gt;` tag with the content. */
    addStyleTag?: CreateAccessibilityTreeRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. Reject rules are applied first. */
    allowRequestPattern?: CreateAccessibilityTreeRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. Reject rules are applied first. */
    allowResourceTypes?: CreateAccessibilityTreeRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: CreateAccessibilityTreeRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: CreateAccessibilityTreeRequestCookiesList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: CreateAccessibilityTreeRequestGotoOptions;
    html?: string;
    interestingOnly?: boolean;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: CreateAccessibilityTreeRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: CreateAccessibilityTreeRequestRejectResourceTypesList;
    root?: string;
    setExtraHTTPHeaders?: CreateAccessibilityTreeRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: CreateAccessibilityTreeRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: CreateAccessibilityTreeRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
}
export type CreateAccessibilityTreeResponseAccessibilityTreeChecked = "mixed";
export type CreateAccessibilityTreeResponseAccessibilityTreeChecked2 = CreateAccessibilityTreeResponseAccessibilityTreeChecked | boolean;
export type CreateAccessibilityTreeResponseAccessibilityTreeChildrenList = Array<unknown>;
export type CreateAccessibilityTreeResponseAccessibilityTreePressed = "mixed";
export type CreateAccessibilityTreeResponseAccessibilityTreePressed2 = CreateAccessibilityTreeResponseAccessibilityTreePressed | boolean;
export type CreateAccessibilityTreeResponseAccessibilityTreeValue = string | number;
export interface CreateAccessibilityTreeResponseAccessibilityTree {
    role: string;
    autocomplete?: string | null;
    checked?: CreateAccessibilityTreeResponseAccessibilityTreeChecked2 | null;
    children?: CreateAccessibilityTreeResponseAccessibilityTreeChildrenList | null;
    description?: string | null;
    disabled?: boolean | null;
    expanded?: boolean | null;
    focused?: boolean | null;
    haspopup?: string | null;
    invalid?: string | null;
    keyshortcuts?: string | null;
    level?: number | null;
    modal?: boolean | null;
    multiline?: boolean | null;
    multiselectable?: boolean | null;
    name?: string | null;
    orientation?: string | null;
    pressed?: CreateAccessibilityTreeResponseAccessibilityTreePressed2 | null;
    readonly?: boolean | null;
    required?: boolean | null;
    roledescription?: string | null;
    selected?: boolean | null;
    value?: CreateAccessibilityTreeResponseAccessibilityTreeValue | null;
    valuemax?: number | null;
    valuemin?: number | null;
    valuetext?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAccessibilityTreeResponse {
    /** Accessibility tree node */
    accessibilityTree: CreateAccessibilityTreeResponseAccessibilityTree;
}
export type ContentCreateRequestBrowser = "kitesurf";
export type ContentCreateRequestAddScriptTagItem = CreateAccessibilityTreeRequestAddScriptTagItem;
export type ContentCreateRequestAddScriptTagList = Array<CreateAccessibilityTreeRequestAddScriptTagItem>;
export type ContentCreateRequestAddStyleTagItem = CreateAccessibilityTreeRequestAddStyleTagItem;
export type ContentCreateRequestAddStyleTagList = Array<CreateAccessibilityTreeRequestAddStyleTagItem>;
export type ContentCreateRequestAllowRequestPatternList = Array<string>;
export type ContentCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type ContentCreateRequestAllowResourceTypesList = Array<ContentCreateRequestAllowResourceTypesItem | (string & {})>;
export type ContentCreateRequestAuthenticate = CreateAccessibilityTreeRequestAuthenticate;
export type ContentCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export type ContentCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export type ContentCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export interface ContentCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: ContentCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: ContentCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: ContentCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export type ContentCreateRequestCookiesList = Array<ContentCreateRequestCookiesItem>;
export type ContentCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type ContentCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type ContentCreateRequestGotoOptionsWaitUntilCase1List = Array<ContentCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export type ContentCreateRequestGotoOptionsWaitUntil = ContentCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | ContentCreateRequestGotoOptionsWaitUntilCase1List;
export interface ContentCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: ContentCreateRequestGotoOptionsWaitUntil;
}
export type ContentCreateRequestRejectRequestPatternList = Array<string>;
export type ContentCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type ContentCreateRequestRejectResourceTypesList = Array<ContentCreateRequestRejectResourceTypesItem | (string & {})>;
export type ContentCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export type ContentCreateRequestViewport = CreateAccessibilityTreeRequestViewport;
export type ContentCreateRequestWaitForSelector = CreateAccessibilityTreeRequestWaitForSelector;
export interface CreateContentRequest {
    /** Account ID. */
    accountId: string;
    /** Rendering backend. Set to `kitesurf` to use Kitesurf (beta). */
    browser?: ContentCreateRequestBrowser | (string & {});
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    url?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a script element into the page with the desired URL or content. */
    addScriptTag?: ContentCreateRequestAddScriptTagList;
    /** Adds a `&lt;link rel="stylesheet"&gt;` tag into the page with the desired URL or a `&lt;style type="text/css"&gt;` tag with the content. */
    addStyleTag?: ContentCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. Reject rules are applied first. */
    allowRequestPattern?: ContentCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. Reject rules are applied first. */
    allowResourceTypes?: ContentCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: CreateAccessibilityTreeRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: ContentCreateRequestCookiesList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: ContentCreateRequestGotoOptions;
    html?: string;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: ContentCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: ContentCreateRequestRejectResourceTypesList;
    setExtraHTTPHeaders?: ContentCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: CreateAccessibilityTreeRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: CreateAccessibilityTreeRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
}
export type CreateContentResponse = string;
export type CrawlCreateRequestAddScriptTagItem = CreateAccessibilityTreeRequestAddScriptTagItem;
export type CrawlCreateRequestAddScriptTagList = Array<CreateAccessibilityTreeRequestAddScriptTagItem>;
export type CrawlCreateRequestAddStyleTagItem = CreateAccessibilityTreeRequestAddStyleTagItem;
export type CrawlCreateRequestAddStyleTagList = Array<CreateAccessibilityTreeRequestAddStyleTagItem>;
export type CrawlCreateRequestAllowRequestPatternList = Array<string>;
export type CrawlCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type CrawlCreateRequestAllowResourceTypesList = Array<CrawlCreateRequestAllowResourceTypesItem | (string & {})>;
export type CrawlCreateRequestAuthenticate = CreateAccessibilityTreeRequestAuthenticate;
export type CrawlCreateRequestBrowser = "kitesurf";
export type CrawlCreateRequestContentUse = "reference" | "full";
export type CrawlCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export type CrawlCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export type CrawlCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export interface CrawlCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: CrawlCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: CrawlCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: CrawlCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export type CrawlCreateRequestCookiesList = Array<CrawlCreateRequestCookiesItem>;
export type CrawlCreateRequestCrawlPurposesItem = "search" | "ai-input" | "ai-train";
export type CrawlCreateRequestCrawlPurposesList = Array<CrawlCreateRequestCrawlPurposesItem | (string & {})>;
export type CrawlCreateRequestFormatsItem = "html" | "markdown" | "json";
export type CrawlCreateRequestFormatsList = Array<CrawlCreateRequestFormatsItem | (string & {})>;
export type CrawlCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type CrawlCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type CrawlCreateRequestGotoOptionsWaitUntilCase1List = Array<CrawlCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export type CrawlCreateRequestGotoOptionsWaitUntil = CrawlCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | CrawlCreateRequestGotoOptionsWaitUntilCase1List;
export interface CrawlCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: CrawlCreateRequestGotoOptionsWaitUntil;
}
export interface CrawlCreateRequestJsonOptionsCustomAiItem {
    /** AI model to use for the request. Must be formed as `&lt;provider&gt;/&lt;model_name&gt;`, e.g. `workers-ai/@cf/meta/llama-3.3-70b-instruct-fp8-fast`. */
    model: string;
    /** Authorization token for the AI model: `Bearer &lt;token&gt;`. Not needed for workers-ai models. */
    authorization?: string;
}
export type CrawlCreateRequestJsonOptionsCustomAiList = Array<CrawlCreateRequestJsonOptionsCustomAiItem>;
export type CrawlCreateRequestJsonOptionsResponseFormatJsonSchemaMap = {
    [key: string]: unknown | undefined;
};
export interface CrawlCreateRequestJsonOptionsResponseFormat {
    type: string;
    /** Schema for the response format. More information here: https://developers.cloudflare.com/workers-ai/json-mode/ */
    jsonSchema?: CrawlCreateRequestJsonOptionsResponseFormatJsonSchemaMap;
}
export interface CrawlCreateRequestJsonOptions {
    /** Optional list of custom AI models to use for the request. The models will be tried in the order provided, and in case a model returns an error, the next one will be used as fallback. */
    customAi?: CrawlCreateRequestJsonOptionsCustomAiList;
    prompt?: string;
    responseFormat?: CrawlCreateRequestJsonOptionsResponseFormat;
}
export type CrawlCreateRequestOptionsExcludePatternsList = Array<string>;
export type CrawlCreateRequestOptionsIncludePatternsList = Array<string>;
export interface CrawlCreateRequestOptions {
    /** Exclude links matching the provided wildcard patterns in the crawl job. Example: 'https://example.com/privacy/**'. */
    excludePatterns?: CrawlCreateRequestOptionsExcludePatternsList;
    /** Include external links in the crawl job. If set to true, includeSubdomains is ignored. */
    includeExternalLinks?: boolean;
    /** Include only links matching the provided wildcard patterns in the crawl job. Include patterns are evaluated before exclude patterns. URLs that match any of the specified include patterns will be included in the crawl job. Example: 'https://example.com/blog/**'. */
    includePatterns?: CrawlCreateRequestOptionsIncludePatternsList;
    /** Include links to subdomains in the crawl job. This option is ignored if includeExternalLinks is true. */
    includeSubdomains?: boolean;
}
export type CrawlCreateRequestRejectRequestPatternList = Array<string>;
export type CrawlCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type CrawlCreateRequestRejectResourceTypesList = Array<CrawlCreateRequestRejectResourceTypesItem | (string & {})>;
export type CrawlCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export type CrawlCreateRequestSource = "sitemaps" | "links" | "all";
export type CrawlCreateRequestViewport = CreateAccessibilityTreeRequestViewport;
export type CrawlCreateRequestWaitForSelector = CreateAccessibilityTreeRequestWaitForSelector;
export interface CreateCrawlRequest {
    /** Account ID. */
    accountId: string;
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    /** URL to navigate to, eg. `https://example.com`. */
    url: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a script element into the page with the desired URL or content. */
    addScriptTag?: CrawlCreateRequestAddScriptTagList;
    /** Adds a `&lt;link rel="stylesheet"&gt;` tag into the page with the desired URL or a `&lt;style type="text/css"&gt;` tag with the content. */
    addStyleTag?: CrawlCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. Reject rules are applied first. */
    allowRequestPattern?: CrawlCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. Reject rules are applied first. */
    allowResourceTypes?: CrawlCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: CreateAccessibilityTreeRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Rendering backend for this crawl. Set to `kitesurf` to render pages with Kitesurf (beta). Only valid when `render` is `true`. */
    browser?: CrawlCreateRequestBrowser | (string & {});
    /** Intended content use level to respect the `use` Content-Signal directive in robots.txt. Levels (least to most permissive): 'reference', 'full'. A URL is disallowed when the publisher's declared `use` level is lower than this intent. Learn more: https://contentsignals.org/. Default: 'full'. */
    contentUse?: CrawlCreateRequestContentUse | (string & {});
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: CrawlCreateRequestCookiesList;
    /** List of crawl purposes to respect Content-Signal directives in robots.txt. Allowed values: 'search', 'ai-input', 'ai-train'. Learn more: https://contentsignals.org/. Default: ['search', 'ai-input', 'ai-train']. */
    crawlPurposes?: CrawlCreateRequestCrawlPurposesList;
    /** Maximum number of levels deep the crawler will traverse from the starting URL. */
    depth?: number;
    emulateMediaType?: string;
    /** Formats to return. Default is `html`. */
    formats?: CrawlCreateRequestFormatsList;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: CrawlCreateRequestGotoOptions;
    /** Options for JSON extraction. */
    jsonOptions?: CrawlCreateRequestJsonOptions;
    /** Maximum number of URLs to crawl. */
    limit?: number;
    /** Maximum age of a resource that can be returned from cache in seconds. Default is 1 day. */
    maxAge?: number;
    /** Unix timestamp (seconds since epoch) indicating to only crawl pages that were modified since this time. For sitemap URLs with a lastmod field, this is compared directly. For other URLs, the crawler will use If-Modified-Since header when fetching. URLs without modification information (no lastmod in sitemap and no Last-Modified header support) will be crawled. Note: This works in conjunction with maxAge - both filters must pass for a cached resource to be used. Must be within the last year and not in the future. */
    modifiedSince?: number;
    /** Additional options for the crawler. */
    options?: CrawlCreateRequestOptions;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: CrawlCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: CrawlCreateRequestRejectResourceTypesList;
    /** Whether to render the page or fetch static content. True by default. */
    render?: boolean;
    setExtraHTTPHeaders?: CrawlCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    /** Source of links to crawl. 'sitemaps' - only crawl URLs from sitemaps, 'links' - only crawl URLs scraped from pages, 'all' - crawl both sitemap and scraped links (default). */
    source?: CrawlCreateRequestSource | (string & {});
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: CreateAccessibilityTreeRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: CreateAccessibilityTreeRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
}
export type CreateCrawlResponse = string;
export type DevtoolsBrowserCreateRequestGuardrailsAllowedDomainsList = Array<string>;
export type DevtoolsBrowserCreateRequestGuardrailsAllowedDomainSetsList = Array<string>;
export interface DevtoolsBrowserCreateRequestGuardrails {
    /** Hostname patterns, max 50. Supports exact hosts (example.com) or a single * wildcard anywhere. Prefer *.example.com (subdomain wildcard) over *example.com (prefix wildcard) to avoid matching overbroad lookalikes like evilexample.com. */
    allowedDomains?: DevtoolsBrowserCreateRequestGuardrailsAllowedDomainsList;
    /** Max 4 entries: curated preset names (common-cdns) and/or https URLs of newline-separated hostname lists. */
    allowedDomainSets?: DevtoolsBrowserCreateRequestGuardrailsAllowedDomainSetsList;
}
export interface CreateDevtoolBrowserRequest {
    /** Account ID. */
    accountId: string;
    /** Keep-alive time in milliseconds. */
    keepAlive?: number;
    /** Use experimental browser. */
    lab?: boolean;
    /** How long the live view URL remains valid, in milliseconds (max 60 minutes). Only used when targets is true. */
    liveViewUrlExpiresInMs?: number;
    recording?: boolean;
    /** Include browser targets in response. */
    targets?: boolean;
    guardrails?: DevtoolsBrowserCreateRequestGuardrails;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateDevtoolBrowserResponse {
    /** Browser session ID. */
    sessionId: string;
    /** WebSocket URL for the session. */
    webSocketDebuggerUrl?: string | null;
}
export interface CreateDevtoolBrowserTargetRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
    /** How long the live view URL remains valid, in milliseconds (max 60 minutes) */
    liveViewUrlExpiresInMs?: number;
    url?: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateDevtoolBrowserTargetResponse {
    /** Target ID. */
    id: string;
    /** Target type (page, background_page, worker, etc.). */
    type: string;
    /** URL of the target. */
    url: string;
    /** Target description. */
    description?: string | null;
    /** DevTools frontend URL. */
    devtoolsFrontendUrl?: string | null;
    /** Title of the target. */
    title?: string | null;
    /** WebSocket URL for debugging this target. */
    webSocketDebuggerUrl?: string | null;
}
export type CreateDevtoolsBrowserLiveViewRequestGuardrailsMode = "readonly";
export interface CreateDevtoolsBrowserLiveViewRequestGuardrails {
    mode: CreateDevtoolsBrowserLiveViewRequestGuardrailsMode | (string & {});
}
export type CreateDevtoolsBrowserLiveViewRequestMode = "devtools" | "tab" | "full";
export interface CreateDevtoolsBrowserLiveViewRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID */
    sessionId: string;
    /** How long the live view URLs remain valid, in milliseconds. Default: 5 minutes. Max: 60 minutes. */
    expiresInMs?: number;
    /** Connection guardrails. Use `{ mode: 'readonly' }` to generate a view-only link. */
    guardrails?: CreateDevtoolsBrowserLiveViewRequestGuardrails;
    /** UI mode: 'devtools' (Chrome DevTools), 'tab' (single tab view), 'full' (multi-tab browser) */
    mode?: CreateDevtoolsBrowserLiveViewRequestMode | (string & {});
    /** Target ID (page) to connect to. If omitted, auto-resolves to the first active page. */
    targetId?: string;
}
export type CreateDevtoolsBrowserLiveViewResponseOptionsMode = "devtools" | "tab" | "full";
export type CreateDevtoolsBrowserLiveViewResponseOptionsGuardrailsMode = "readonly";
export interface CreateDevtoolsBrowserLiveViewResponseOptionsGuardrails {
    mode: CreateDevtoolsBrowserLiveViewResponseOptionsGuardrailsMode;
}
export interface CreateDevtoolsBrowserLiveViewResponseOptions {
    /** UI mode for the live view */
    mode: CreateDevtoolsBrowserLiveViewResponseOptionsMode;
    /** Connection guardrails applied to this link */
    guardrails?: CreateDevtoolsBrowserLiveViewResponseOptionsGuardrails | null;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateDevtoolsBrowserLiveViewResponse {
    /** Target ID */
    id: string;
    /** URL to open the live view in a browser */
    devtoolsFrontendUrl: string;
    options: CreateDevtoolsBrowserLiveViewResponseOptions;
    /** WebSocket URL for CDP connection */
    webSocketDebuggerUrl: string;
}
export type JsonCreateRequestBrowser = "kitesurf";
export type JsonCreateRequestAddScriptTagItem = CreateAccessibilityTreeRequestAddScriptTagItem;
export type JsonCreateRequestAddScriptTagList = Array<CreateAccessibilityTreeRequestAddScriptTagItem>;
export type JsonCreateRequestAddStyleTagItem = CreateAccessibilityTreeRequestAddStyleTagItem;
export type JsonCreateRequestAddStyleTagList = Array<CreateAccessibilityTreeRequestAddStyleTagItem>;
export type JsonCreateRequestAllowRequestPatternList = Array<string>;
export type JsonCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type JsonCreateRequestAllowResourceTypesList = Array<JsonCreateRequestAllowResourceTypesItem | (string & {})>;
export type JsonCreateRequestAuthenticate = CreateAccessibilityTreeRequestAuthenticate;
export type JsonCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export type JsonCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export type JsonCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export interface JsonCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: JsonCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: JsonCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: JsonCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export type JsonCreateRequestCookiesList = Array<JsonCreateRequestCookiesItem>;
export type JsonCreateRequestCustomAiItem = CrawlCreateRequestJsonOptionsCustomAiItem;
export type JsonCreateRequestCustomAiList = Array<CrawlCreateRequestJsonOptionsCustomAiItem>;
export type JsonCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type JsonCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type JsonCreateRequestGotoOptionsWaitUntilCase1List = Array<JsonCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export type JsonCreateRequestGotoOptionsWaitUntil = JsonCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | JsonCreateRequestGotoOptionsWaitUntilCase1List;
export interface JsonCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: JsonCreateRequestGotoOptionsWaitUntil;
}
export type JsonCreateRequestRejectRequestPatternList = Array<string>;
export type JsonCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type JsonCreateRequestRejectResourceTypesList = Array<JsonCreateRequestRejectResourceTypesItem | (string & {})>;
export type JsonCreateRequestResponseFormatJsonSchemaMap = {
    [key: string]: unknown | undefined;
};
export interface JsonCreateRequestResponseFormat {
    type: string;
    /** Schema for the response format. More information here: https://developers.cloudflare.com/workers-ai/json-mode/ */
    jsonSchema?: JsonCreateRequestResponseFormatJsonSchemaMap;
}
export type JsonCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export type JsonCreateRequestViewport = CreateAccessibilityTreeRequestViewport;
export type JsonCreateRequestWaitForSelector = CreateAccessibilityTreeRequestWaitForSelector;
export interface CreateJsonRequest {
    /** Account ID. */
    accountId: string;
    /** Rendering backend. Set to `kitesurf` to use Kitesurf (beta). */
    browser?: JsonCreateRequestBrowser | (string & {});
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    url?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a script element into the page with the desired URL or content. */
    addScriptTag?: JsonCreateRequestAddScriptTagList;
    /** Adds a `&lt;link rel="stylesheet"&gt;` tag into the page with the desired URL or a `&lt;style type="text/css"&gt;` tag with the content. */
    addStyleTag?: JsonCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. Reject rules are applied first. */
    allowRequestPattern?: JsonCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. Reject rules are applied first. */
    allowResourceTypes?: JsonCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: CreateAccessibilityTreeRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: JsonCreateRequestCookiesList;
    /** Optional list of custom AI models to use for the request. The models will be tried in the order provided, and in case a model returns an error, the next one will be used as fallback. */
    customAi?: JsonCreateRequestCustomAiList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: JsonCreateRequestGotoOptions;
    html?: string;
    prompt?: string;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: JsonCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: JsonCreateRequestRejectResourceTypesList;
    responseFormat?: JsonCreateRequestResponseFormat;
    setExtraHTTPHeaders?: JsonCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: CreateAccessibilityTreeRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: CreateAccessibilityTreeRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
}
export type JsonCreateResultMap = {
    [key: string]: unknown | undefined;
};
export type CreateJsonResponse = JsonCreateResultMap;
export type LinksCreateRequestBrowser = "kitesurf";
export type LinksCreateRequestAddScriptTagItem = CreateAccessibilityTreeRequestAddScriptTagItem;
export type LinksCreateRequestAddScriptTagList = Array<CreateAccessibilityTreeRequestAddScriptTagItem>;
export type LinksCreateRequestAddStyleTagItem = CreateAccessibilityTreeRequestAddStyleTagItem;
export type LinksCreateRequestAddStyleTagList = Array<CreateAccessibilityTreeRequestAddStyleTagItem>;
export type LinksCreateRequestAllowRequestPatternList = Array<string>;
export type LinksCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type LinksCreateRequestAllowResourceTypesList = Array<LinksCreateRequestAllowResourceTypesItem | (string & {})>;
export type LinksCreateRequestAuthenticate = CreateAccessibilityTreeRequestAuthenticate;
export type LinksCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export type LinksCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export type LinksCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export interface LinksCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: LinksCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: LinksCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: LinksCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export type LinksCreateRequestCookiesList = Array<LinksCreateRequestCookiesItem>;
export type LinksCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type LinksCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type LinksCreateRequestGotoOptionsWaitUntilCase1List = Array<LinksCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export type LinksCreateRequestGotoOptionsWaitUntil = LinksCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | LinksCreateRequestGotoOptionsWaitUntilCase1List;
export interface LinksCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: LinksCreateRequestGotoOptionsWaitUntil;
}
export type LinksCreateRequestRejectRequestPatternList = Array<string>;
export type LinksCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type LinksCreateRequestRejectResourceTypesList = Array<LinksCreateRequestRejectResourceTypesItem | (string & {})>;
export type LinksCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export type LinksCreateRequestViewport = CreateAccessibilityTreeRequestViewport;
export type LinksCreateRequestWaitForSelector = CreateAccessibilityTreeRequestWaitForSelector;
export interface CreateLinkRequest {
    /** Account ID. */
    accountId: string;
    /** Rendering backend. Set to `kitesurf` to use Kitesurf (beta). */
    browser?: LinksCreateRequestBrowser | (string & {});
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    url?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a script element into the page with the desired URL or content. */
    addScriptTag?: LinksCreateRequestAddScriptTagList;
    /** Adds a `&lt;link rel="stylesheet"&gt;` tag into the page with the desired URL or a `&lt;style type="text/css"&gt;` tag with the content. */
    addStyleTag?: LinksCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. Reject rules are applied first. */
    allowRequestPattern?: LinksCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. Reject rules are applied first. */
    allowResourceTypes?: LinksCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: CreateAccessibilityTreeRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: LinksCreateRequestCookiesList;
    emulateMediaType?: string;
    excludeExternalLinks?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: LinksCreateRequestGotoOptions;
    html?: string;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: LinksCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: LinksCreateRequestRejectResourceTypesList;
    setExtraHTTPHeaders?: LinksCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: CreateAccessibilityTreeRequestViewport;
    visibleLinksOnly?: boolean;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: CreateAccessibilityTreeRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
}
export type LinksCreateResultList = Array<string>;
export type CreateLinkResponse = LinksCreateResultList;
export type MarkdownCreateRequestBrowser = "kitesurf";
export type MarkdownCreateRequestAddScriptTagItem = CreateAccessibilityTreeRequestAddScriptTagItem;
export type MarkdownCreateRequestAddScriptTagList = Array<CreateAccessibilityTreeRequestAddScriptTagItem>;
export type MarkdownCreateRequestAddStyleTagItem = CreateAccessibilityTreeRequestAddStyleTagItem;
export type MarkdownCreateRequestAddStyleTagList = Array<CreateAccessibilityTreeRequestAddStyleTagItem>;
export type MarkdownCreateRequestAllowRequestPatternList = Array<string>;
export type MarkdownCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type MarkdownCreateRequestAllowResourceTypesList = Array<MarkdownCreateRequestAllowResourceTypesItem | (string & {})>;
export type MarkdownCreateRequestAuthenticate = CreateAccessibilityTreeRequestAuthenticate;
export type MarkdownCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export type MarkdownCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export type MarkdownCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export interface MarkdownCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: MarkdownCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: MarkdownCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: MarkdownCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export type MarkdownCreateRequestCookiesList = Array<MarkdownCreateRequestCookiesItem>;
export type MarkdownCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type MarkdownCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type MarkdownCreateRequestGotoOptionsWaitUntilCase1List = Array<MarkdownCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export type MarkdownCreateRequestGotoOptionsWaitUntil = MarkdownCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | MarkdownCreateRequestGotoOptionsWaitUntilCase1List;
export interface MarkdownCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: MarkdownCreateRequestGotoOptionsWaitUntil;
}
export type MarkdownCreateRequestRejectRequestPatternList = Array<string>;
export type MarkdownCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type MarkdownCreateRequestRejectResourceTypesList = Array<MarkdownCreateRequestRejectResourceTypesItem | (string & {})>;
export type MarkdownCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export type MarkdownCreateRequestViewport = CreateAccessibilityTreeRequestViewport;
export type MarkdownCreateRequestWaitForSelector = CreateAccessibilityTreeRequestWaitForSelector;
export interface CreateMarkdownRequest {
    /** Account ID. */
    accountId: string;
    /** Rendering backend. Set to `kitesurf` to use Kitesurf (beta). */
    browser?: MarkdownCreateRequestBrowser | (string & {});
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    url?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a script element into the page with the desired URL or content. */
    addScriptTag?: MarkdownCreateRequestAddScriptTagList;
    /** Adds a `&lt;link rel="stylesheet"&gt;` tag into the page with the desired URL or a `&lt;style type="text/css"&gt;` tag with the content. */
    addStyleTag?: MarkdownCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. Reject rules are applied first. */
    allowRequestPattern?: MarkdownCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. Reject rules are applied first. */
    allowResourceTypes?: MarkdownCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: CreateAccessibilityTreeRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: MarkdownCreateRequestCookiesList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: MarkdownCreateRequestGotoOptions;
    html?: string;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: MarkdownCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: MarkdownCreateRequestRejectResourceTypesList;
    setExtraHTTPHeaders?: MarkdownCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: CreateAccessibilityTreeRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: CreateAccessibilityTreeRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
}
export type CreateMarkdownResponse = string;
export type PdfCreateRequestBrowser = "kitesurf";
export type PdfCreateRequestAddScriptTagItem = CreateAccessibilityTreeRequestAddScriptTagItem;
export type PdfCreateRequestAddScriptTagList = Array<CreateAccessibilityTreeRequestAddScriptTagItem>;
export type PdfCreateRequestAddStyleTagItem = CreateAccessibilityTreeRequestAddStyleTagItem;
export type PdfCreateRequestAddStyleTagList = Array<CreateAccessibilityTreeRequestAddStyleTagItem>;
export type PdfCreateRequestAllowRequestPatternList = Array<string>;
export type PdfCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type PdfCreateRequestAllowResourceTypesList = Array<PdfCreateRequestAllowResourceTypesItem | (string & {})>;
export type PdfCreateRequestAuthenticate = CreateAccessibilityTreeRequestAuthenticate;
export type PdfCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export type PdfCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export type PdfCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export interface PdfCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: PdfCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: PdfCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: PdfCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export type PdfCreateRequestCookiesList = Array<PdfCreateRequestCookiesItem>;
export type PdfCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type PdfCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type PdfCreateRequestGotoOptionsWaitUntilCase1List = Array<PdfCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export type PdfCreateRequestGotoOptionsWaitUntil = PdfCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | PdfCreateRequestGotoOptionsWaitUntilCase1List;
export interface PdfCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: PdfCreateRequestGotoOptionsWaitUntil;
}
export type PdfCreateRequestPdfOptionsFormat = "letter" | "legal" | "tabloid" | "ledger" | "a0" | "a1" | "a2" | "a3" | "a4" | "a5" | "a6";
export type PdfCreateRequestPdfOptionsHeight = string | number;
export type PdfCreateRequestPdfOptionsMarginBottom = string | number;
export type PdfCreateRequestPdfOptionsMarginLeft = string | number;
export type PdfCreateRequestPdfOptionsMarginRight = string | number;
export type PdfCreateRequestPdfOptionsMarginTop = string | number;
export interface PdfCreateRequestPdfOptionsMargin {
    bottom?: PdfCreateRequestPdfOptionsMarginBottom;
    left?: PdfCreateRequestPdfOptionsMarginLeft;
    right?: PdfCreateRequestPdfOptionsMarginRight;
    top?: PdfCreateRequestPdfOptionsMarginTop;
}
export type PdfCreateRequestPdfOptionsWidth = string | number;
export interface PdfCreateRequestPdfOptions {
    /** Whether to show the header and footer. */
    displayHeaderFooter?: boolean;
    /** HTML template for the print footer. */
    footerTemplate?: string;
    /** Paper format. Takes priority over width and height if set. */
    format?: PdfCreateRequestPdfOptionsFormat | (string & {});
    /** HTML template for the print header. */
    headerTemplate?: string;
    /** Sets the height of paper. Can be a number or string with unit. */
    height?: PdfCreateRequestPdfOptionsHeight;
    /** Whether to print in landscape orientation. */
    landscape?: boolean;
    /** Set the PDF margins. Useful when setting header and footer. */
    margin?: PdfCreateRequestPdfOptionsMargin;
    /** Hides default white background and allows generating pdfs with transparency. */
    omitBackground?: boolean;
    /** Generate document outline. */
    outline?: boolean;
    /** Paper ranges to print, e.g. '1-5, 8, 11-13'. */
    pageRanges?: string;
    /** Give CSS @page size priority over other size declarations. */
    preferCSSPageSize?: boolean;
    /** Set to true to print background graphics. */
    printBackground?: boolean;
    /** Scales the rendering of the web page. Amount must be between 0.1 and 2. */
    scale?: number;
    /** Generate tagged (accessible) PDF. */
    tagged?: boolean;
    /** Timeout in milliseconds. */
    timeout?: number;
    /** Sets the width of paper. Can be a number or string with unit. */
    width?: PdfCreateRequestPdfOptionsWidth;
}
export type PdfCreateRequestRejectRequestPatternList = Array<string>;
export type PdfCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type PdfCreateRequestRejectResourceTypesList = Array<PdfCreateRequestRejectResourceTypesItem | (string & {})>;
export type PdfCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export type PdfCreateRequestViewport = CreateAccessibilityTreeRequestViewport;
export type PdfCreateRequestWaitForSelector = CreateAccessibilityTreeRequestWaitForSelector;
export interface CreatePdfRequest {
    /** Account ID. */
    accountId: string;
    /** Rendering backend. Set to `kitesurf` to use Kitesurf (beta). */
    browser?: PdfCreateRequestBrowser | (string & {});
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    url?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a script element into the page with the desired URL or content. */
    addScriptTag?: PdfCreateRequestAddScriptTagList;
    /** Adds a `&lt;link rel="stylesheet"&gt;` tag into the page with the desired URL or a `&lt;style type="text/css"&gt;` tag with the content. */
    addStyleTag?: PdfCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. Reject rules are applied first. */
    allowRequestPattern?: PdfCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. Reject rules are applied first. */
    allowResourceTypes?: PdfCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: CreateAccessibilityTreeRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: PdfCreateRequestCookiesList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: PdfCreateRequestGotoOptions;
    html?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.pdfoptions). */
    pdfOptions?: PdfCreateRequestPdfOptions;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: PdfCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: PdfCreateRequestRejectResourceTypesList;
    setExtraHTTPHeaders?: PdfCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: CreateAccessibilityTreeRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: CreateAccessibilityTreeRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
}
export interface CreatePdfResponse {
}
export type ScrapeCreateRequestBrowser = "kitesurf";
export type ScrapeCreateRequestAddScriptTagItem = CreateAccessibilityTreeRequestAddScriptTagItem;
export type ScrapeCreateRequestAddScriptTagList = Array<CreateAccessibilityTreeRequestAddScriptTagItem>;
export type ScrapeCreateRequestAddStyleTagItem = CreateAccessibilityTreeRequestAddStyleTagItem;
export type ScrapeCreateRequestAddStyleTagList = Array<CreateAccessibilityTreeRequestAddStyleTagItem>;
export type ScrapeCreateRequestAllowRequestPatternList = Array<string>;
export type ScrapeCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type ScrapeCreateRequestAllowResourceTypesList = Array<ScrapeCreateRequestAllowResourceTypesItem | (string & {})>;
export type ScrapeCreateRequestAuthenticate = CreateAccessibilityTreeRequestAuthenticate;
export type ScrapeCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export type ScrapeCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export type ScrapeCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export interface ScrapeCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: ScrapeCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: ScrapeCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: ScrapeCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export type ScrapeCreateRequestCookiesList = Array<ScrapeCreateRequestCookiesItem>;
export interface ScrapeCreateRequestElementsItem {
    selector: string;
}
export type ScrapeCreateRequestElementsList = Array<ScrapeCreateRequestElementsItem>;
export type ScrapeCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type ScrapeCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type ScrapeCreateRequestGotoOptionsWaitUntilCase1List = Array<ScrapeCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export type ScrapeCreateRequestGotoOptionsWaitUntil = ScrapeCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | ScrapeCreateRequestGotoOptionsWaitUntilCase1List;
export interface ScrapeCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: ScrapeCreateRequestGotoOptionsWaitUntil;
}
export type ScrapeCreateRequestRejectRequestPatternList = Array<string>;
export type ScrapeCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type ScrapeCreateRequestRejectResourceTypesList = Array<ScrapeCreateRequestRejectResourceTypesItem | (string & {})>;
export type ScrapeCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export type ScrapeCreateRequestViewport = CreateAccessibilityTreeRequestViewport;
export type ScrapeCreateRequestWaitForSelector = CreateAccessibilityTreeRequestWaitForSelector;
export interface CreateScrapeRequest {
    /** Account ID. */
    accountId: string;
    /** Rendering backend. Set to `kitesurf` to use Kitesurf (beta). */
    browser?: ScrapeCreateRequestBrowser | (string & {});
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    url?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a script element into the page with the desired URL or content. */
    addScriptTag?: ScrapeCreateRequestAddScriptTagList;
    /** Adds a `&lt;link rel="stylesheet"&gt;` tag into the page with the desired URL or a `&lt;style type="text/css"&gt;` tag with the content. */
    addStyleTag?: ScrapeCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. Reject rules are applied first. */
    allowRequestPattern?: ScrapeCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. Reject rules are applied first. */
    allowResourceTypes?: ScrapeCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: CreateAccessibilityTreeRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: ScrapeCreateRequestCookiesList;
    elements?: ScrapeCreateRequestElementsList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: ScrapeCreateRequestGotoOptions;
    html?: string;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: ScrapeCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: ScrapeCreateRequestRejectResourceTypesList;
    setExtraHTTPHeaders?: ScrapeCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: CreateAccessibilityTreeRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: CreateAccessibilityTreeRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
}
export interface ScrapeCreateResultItemResultsAttributesItem {
    /** Attribute name. */
    name: string;
    /** Attribute value. */
    value: string;
}
export type ScrapeCreateResultItemResultsAttributesList = Array<ScrapeCreateResultItemResultsAttributesItem>;
export interface ScrapeCreateResultItemResults {
    attributes: ScrapeCreateResultItemResultsAttributesList;
    /** Element height. */
    height: number;
    /** HTML content. */
    html: string;
    /** Element left. */
    left: number;
    /** Text content. */
    text: string;
    /** Element top. */
    top: number;
    /** Element width. */
    width: number;
}
export interface ScrapeCreateResultItem {
    results: ScrapeCreateResultItemResults;
    /** Selector. */
    selector: string;
}
export type ScrapeCreateResultList = Array<ScrapeCreateResultItem>;
export type CreateScrapeResponse = ScrapeCreateResultList;
export type ScreenshotCreateRequestBrowser = "kitesurf";
export type ScreenshotCreateRequestAddScriptTagItem = CreateAccessibilityTreeRequestAddScriptTagItem;
export type ScreenshotCreateRequestAddScriptTagList = Array<CreateAccessibilityTreeRequestAddScriptTagItem>;
export type ScreenshotCreateRequestAddStyleTagItem = CreateAccessibilityTreeRequestAddStyleTagItem;
export type ScreenshotCreateRequestAddStyleTagList = Array<CreateAccessibilityTreeRequestAddStyleTagItem>;
export type ScreenshotCreateRequestAllowRequestPatternList = Array<string>;
export type ScreenshotCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type ScreenshotCreateRequestAllowResourceTypesList = Array<ScreenshotCreateRequestAllowResourceTypesItem | (string & {})>;
export type ScreenshotCreateRequestAuthenticate = CreateAccessibilityTreeRequestAuthenticate;
export type ScreenshotCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export type ScreenshotCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export type ScreenshotCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export interface ScreenshotCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: ScreenshotCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: ScreenshotCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: ScreenshotCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export type ScreenshotCreateRequestCookiesList = Array<ScreenshotCreateRequestCookiesItem>;
export type ScreenshotCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type ScreenshotCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type ScreenshotCreateRequestGotoOptionsWaitUntilCase1List = Array<ScreenshotCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export type ScreenshotCreateRequestGotoOptionsWaitUntil = ScreenshotCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | ScreenshotCreateRequestGotoOptionsWaitUntilCase1List;
export interface ScreenshotCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: ScreenshotCreateRequestGotoOptionsWaitUntil;
}
export type ScreenshotCreateRequestRejectRequestPatternList = Array<string>;
export type ScreenshotCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type ScreenshotCreateRequestRejectResourceTypesList = Array<ScreenshotCreateRequestRejectResourceTypesItem | (string & {})>;
export interface ScreenshotCreateRequestScreenshotOptionsClip {
    height: number;
    width: number;
    x: number;
    y: number;
    scale?: number;
}
export type ScreenshotCreateRequestScreenshotOptionsEncoding = "binary" | "base64";
export type ScreenshotCreateRequestScreenshotOptionsType = "png" | "jpeg" | "webp";
export interface ScreenshotCreateRequestScreenshotOptions {
    captureBeyondViewport?: boolean;
    clip?: ScreenshotCreateRequestScreenshotOptionsClip;
    encoding?: ScreenshotCreateRequestScreenshotOptionsEncoding | (string & {});
    fromSurface?: boolean;
    fullPage?: boolean;
    omitBackground?: boolean;
    optimizeForSpeed?: boolean;
    quality?: number;
    type?: ScreenshotCreateRequestScreenshotOptionsType | (string & {});
}
export type ScreenshotCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export type ScreenshotCreateRequestViewport = CreateAccessibilityTreeRequestViewport;
export type ScreenshotCreateRequestWaitForSelector = CreateAccessibilityTreeRequestWaitForSelector;
export interface CreateScreenshotRequest {
    /** Account ID. */
    accountId: string;
    /** Rendering backend. Set to `kitesurf` to use Kitesurf (beta). */
    browser?: ScreenshotCreateRequestBrowser | (string & {});
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    url?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a script element into the page with the desired URL or content. */
    addScriptTag?: ScreenshotCreateRequestAddScriptTagList;
    /** Adds a `&lt;link rel="stylesheet"&gt;` tag into the page with the desired URL or a `&lt;style type="text/css"&gt;` tag with the content. */
    addStyleTag?: ScreenshotCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. Reject rules are applied first. */
    allowRequestPattern?: ScreenshotCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. Reject rules are applied first. */
    allowResourceTypes?: ScreenshotCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: CreateAccessibilityTreeRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: ScreenshotCreateRequestCookiesList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: ScreenshotCreateRequestGotoOptions;
    html?: string;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: ScreenshotCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: ScreenshotCreateRequestRejectResourceTypesList;
    /** Check [options](https://pptr.dev/api/puppeteer.screenshotoptions). */
    screenshotOptions?: ScreenshotCreateRequestScreenshotOptions;
    scrollPage?: boolean;
    selector?: string;
    setExtraHTTPHeaders?: ScreenshotCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: CreateAccessibilityTreeRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: CreateAccessibilityTreeRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
}
export interface CreateScreenshotResponse {
}
export type SnapshotCreateRequestBrowser = "kitesurf";
export type SnapshotCreateRequestAddScriptTagItem = CreateAccessibilityTreeRequestAddScriptTagItem;
export type SnapshotCreateRequestAddScriptTagList = Array<CreateAccessibilityTreeRequestAddScriptTagItem>;
export type SnapshotCreateRequestAddStyleTagItem = CreateAccessibilityTreeRequestAddStyleTagItem;
export type SnapshotCreateRequestAddStyleTagList = Array<CreateAccessibilityTreeRequestAddStyleTagItem>;
export type SnapshotCreateRequestAllowRequestPatternList = Array<string>;
export type SnapshotCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type SnapshotCreateRequestAllowResourceTypesList = Array<SnapshotCreateRequestAllowResourceTypesItem | (string & {})>;
export type SnapshotCreateRequestAuthenticate = CreateAccessibilityTreeRequestAuthenticate;
export type SnapshotCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export type SnapshotCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export type SnapshotCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export interface SnapshotCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: SnapshotCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: SnapshotCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: SnapshotCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export type SnapshotCreateRequestCookiesList = Array<SnapshotCreateRequestCookiesItem>;
export type SnapshotCreateRequestFormatsItem = "content" | "screenshot" | "markdown" | "accessibilityTree";
export type SnapshotCreateRequestFormatsList = Array<SnapshotCreateRequestFormatsItem | (string & {})>;
export type SnapshotCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type SnapshotCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export type SnapshotCreateRequestGotoOptionsWaitUntilCase1List = Array<SnapshotCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export type SnapshotCreateRequestGotoOptionsWaitUntil = SnapshotCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | SnapshotCreateRequestGotoOptionsWaitUntilCase1List;
export interface SnapshotCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: SnapshotCreateRequestGotoOptionsWaitUntil;
}
export type SnapshotCreateRequestRejectRequestPatternList = Array<string>;
export type SnapshotCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export type SnapshotCreateRequestRejectResourceTypesList = Array<SnapshotCreateRequestRejectResourceTypesItem | (string & {})>;
export type SnapshotCreateRequestScreenshotOptionsClip = ScreenshotCreateRequestScreenshotOptionsClip;
export type SnapshotCreateRequestScreenshotOptionsType = "png" | "jpeg" | "webp";
export interface SnapshotCreateRequestScreenshotOptions {
    captureBeyondViewport?: boolean;
    clip?: ScreenshotCreateRequestScreenshotOptionsClip;
    fromSurface?: boolean;
    fullPage?: boolean;
    omitBackground?: boolean;
    optimizeForSpeed?: boolean;
    quality?: number;
    type?: SnapshotCreateRequestScreenshotOptionsType | (string & {});
}
export type SnapshotCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export type SnapshotCreateRequestViewport = CreateAccessibilityTreeRequestViewport;
export type SnapshotCreateRequestWaitForSelector = CreateAccessibilityTreeRequestWaitForSelector;
export interface CreateSnapshotRequest {
    /** Account ID. */
    accountId: string;
    /** Rendering backend. Set to `kitesurf` to use Kitesurf (beta). */
    browser?: SnapshotCreateRequestBrowser | (string & {});
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    url?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a script element into the page with the desired URL or content. */
    addScriptTag?: SnapshotCreateRequestAddScriptTagList;
    /** Adds a `&lt;link rel="stylesheet"&gt;` tag into the page with the desired URL or a `&lt;style type="text/css"&gt;` tag with the content. */
    addStyleTag?: SnapshotCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. Reject rules are applied first. */
    allowRequestPattern?: SnapshotCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. Reject rules are applied first. */
    allowResourceTypes?: SnapshotCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: CreateAccessibilityTreeRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: SnapshotCreateRequestCookiesList;
    emulateMediaType?: string;
    formats?: SnapshotCreateRequestFormatsList;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: SnapshotCreateRequestGotoOptions;
    html?: string;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: SnapshotCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: SnapshotCreateRequestRejectResourceTypesList;
    screenshotOptions?: SnapshotCreateRequestScreenshotOptions;
    setExtraHTTPHeaders?: SnapshotCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: CreateAccessibilityTreeRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: CreateAccessibilityTreeRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
}
export type SnapshotCreateResponseAccessibilityTreeChecked = "mixed";
export type SnapshotCreateResponseAccessibilityTreeChecked2 = SnapshotCreateResponseAccessibilityTreeChecked | boolean;
export type SnapshotCreateResponseAccessibilityTreeChildrenList = Array<unknown>;
export type SnapshotCreateResponseAccessibilityTreePressed = "mixed";
export type SnapshotCreateResponseAccessibilityTreePressed2 = SnapshotCreateResponseAccessibilityTreePressed | boolean;
export type SnapshotCreateResponseAccessibilityTreeValue = string | number;
export interface SnapshotCreateResponseAccessibilityTree {
    role: string;
    autocomplete?: string | null;
    checked?: SnapshotCreateResponseAccessibilityTreeChecked2 | null;
    children?: SnapshotCreateResponseAccessibilityTreeChildrenList | null;
    description?: string | null;
    disabled?: boolean | null;
    expanded?: boolean | null;
    focused?: boolean | null;
    haspopup?: string | null;
    invalid?: string | null;
    keyshortcuts?: string | null;
    level?: number | null;
    modal?: boolean | null;
    multiline?: boolean | null;
    multiselectable?: boolean | null;
    name?: string | null;
    orientation?: string | null;
    pressed?: SnapshotCreateResponseAccessibilityTreePressed2 | null;
    readonly?: boolean | null;
    required?: boolean | null;
    roledescription?: string | null;
    selected?: boolean | null;
    value?: SnapshotCreateResponseAccessibilityTreeValue | null;
    valuemax?: number | null;
    valuemin?: number | null;
    valuetext?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSnapshotResponse {
    /** Accessibility tree node */
    accessibilityTree?: SnapshotCreateResponseAccessibilityTree | null;
    /** HTML content. */
    content?: string | null;
    /** Markdown content. Prefixed with YAML frontmatter (e.g. `title`) when the page provides that metadata. */
    markdown?: string | null;
    /** Base64 encoded image. */
    screenshot?: string | null;
}
export interface DeleteCrawlRequest {
    /** Account ID. */
    accountId: string;
    /** The ID of the crawl job to cancel. */
    jobId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCrawlResponse {
    /** The ID of the cancelled job. */
    jobId: string;
    /** Cancellation confirmation message. */
    message: string;
}
export interface DeleteDevtoolBrowserRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID to close. */
    sessionId: string;
}
export type DevtoolsBrowserDeleteResponseStatus = "closing" | "closed";
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteDevtoolBrowserResponse {
    status: DevtoolsBrowserDeleteResponseStatus;
}
export type CrawlGetRequestStatus = "queued" | "errored" | "completed" | "disallowed" | "skipped" | "cancelled";
export interface GetCrawlRequest {
    /** Account ID. */
    accountId: string;
    /** Crawl job ID. */
    jobId: string;
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    /** Cursor for pagination. */
    cursor?: number;
    /** Limit for pagination. */
    limit?: number;
    /** Filter by URL status. */
    status?: CrawlGetRequestStatus | (string & {});
}
export type CrawlGetResponseRecordsItemStatus = "queued" | "errored" | "completed" | "disallowed" | "skipped" | "cancelled";
export type CrawlGetResponseRecordsItemJsonMap = {
    [key: string]: unknown | undefined;
};
export interface CrawlGetResponseRecordsItemMetadata {
    /** HTTP status code of the crawled page. */
    status: number;
    /** Final URL of the crawled page. */
    url: string;
    /** Value of the Last-Modified response header, when provided by the origin. */
    lastModified?: string | null;
    /** Open Graph description of the crawled page. */
    ogDescription?: string | null;
    /** Open Graph image of the crawled page. */
    ogImage?: string | null;
    /** Open Graph site name of the crawled page. */
    ogSiteName?: string | null;
    /** Open Graph title of the crawled page. */
    ogTitle?: string | null;
    /** Open Graph type of the crawled page. */
    ogType?: string | null;
    /** Title of the crawled page. */
    title?: string | null;
}
export type CrawlGetResponseRecordsItemOutcome = "success" | "robots_disallowed" | "crawl_purpose_disallowed" | "content_use_disallowed" | "connection_error" | "timeout" | "browser_unavailable" | "format_generation_error" | "unsupported_content_type" | "unclassified_error" | "page_error" | "too_large";
export interface CrawlGetResponseRecordsItem {
    /** Current status of the crawled URL. */
    status: CrawlGetResponseRecordsItemStatus;
    /** Crawled URL. */
    url: string;
    /** HTML content of the crawled URL. */
    html?: string | null;
    /** JSON of the content of the crawled URL. */
    json?: CrawlGetResponseRecordsItemJsonMap | null;
    /** Markdown of the content of the crawled URL. */
    markdown?: string | null;
    /** Absent for urls that never reached a fetch. */
    metadata?: CrawlGetResponseRecordsItemMetadata | null;
    /** Result of processing the URL. Absent for older records. */
    outcome?: CrawlGetResponseRecordsItemOutcome | null;
}
export type CrawlGetResponseRecordsList = Array<CrawlGetResponseRecordsItem>;
export type CrawlGetResponseRobotsItemState = "available" | "absent" | "fetch_failed";
export interface CrawlGetResponseRobotsItem {
    /** Origin whose robots.txt was checked. */
    origin: string;
    /** Whether usable robots.txt rules were available. */
    state: CrawlGetResponseRobotsItemState;
    /** HTTP status that established the current robots.txt state. Absent when no HTTP response was received. */
    status?: number | null;
}
export type CrawlGetResponseRobotsList = Array<CrawlGetResponseRobotsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCrawlResponse {
    /** Crawl job ID. */
    id: string;
    /** Total seconds spent in browser so far. */
    browserSecondsUsed: number;
    /** Total number of URLs that have been crawled so far. */
    finished: number;
    /** List of crawl job records. */
    records: CrawlGetResponseRecordsList;
    /** Robots.txt state for the first 50 origins encountered by the crawl. */
    robots: CrawlGetResponseRobotsList;
    /** Total number of URLs that were skipped due to include/exclude/subdomain filters. Skipped URLs are included in records but are not counted toward total/finished. */
    skipped: number;
    /** Current crawl job status. */
    status: string;
    /** Total current number of URLs in the crawl job. */
    total: number;
    /** Cursor for pagination. */
    cursor?: number | null;
}
export interface GetDevtoolBrowserPageRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
    /** Target ID, e.g. page ID. */
    targetId: string;
    /** Optional base64url-encoded JSON connection guardrails (mode) */
    cfBrapiGuardrails?: string;
}
export interface GetDevtoolBrowserPageResponse {
}
export interface GetDevtoolBrowserTargetRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
    /** Target ID. */
    targetId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetDevtoolBrowserTargetResponse {
    /** Target ID. */
    id: string;
    /** Target type (page, background_page, worker, etc.). */
    type: string;
    /** URL of the target. */
    url: string;
    /** Target description. */
    description?: string | null;
    /** DevTools frontend URL. */
    devtoolsFrontendUrl?: string | null;
    /** Title of the target. */
    title?: string | null;
    /** WebSocket URL for debugging this target. */
    webSocketDebuggerUrl?: string | null;
}
export interface GetDevtoolSessionRequest {
    /** Account ID. */
    accountId: string;
    /** Session ID. */
    sessionId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetDevtoolSessionResponse {
    /** Session ID. */
    sessionId: string;
    /** Reason code for session closure. */
    closeReason?: number | null;
    /** Human-readable close reason. */
    closeReasonText?: string | null;
    /** Connection end time. */
    connectionEndTime?: number | null;
    /** Connection ID. */
    connectionId?: string | null;
    /** Connection start time. */
    connectionStartTime?: number | null;
    /** DevTools frontend URL. */
    devtoolsFrontendUrl?: string | null;
    /** Session end time. */
    endTime?: number | null;
    /** Last updated timestamp. */
    lastUpdated?: number | null;
    /** Session start time. */
    startTime?: number | null;
    /** WebSocket URL for debugging this target. */
    webSocketDebuggerUrl?: string | null;
}
export interface LaunchDevtoolBrowserRequest {
    /** Account ID. */
    accountId: string;
    /** Keep-alive time in ms (only valid when acquiring new session). */
    keepAlive?: number;
    /** Use experimental browser. */
    lab?: boolean;
    recording?: boolean;
    /** Optional base64url-encoded JSON session guardrails (allowedDomains and allowedDomainSets) */
    cfBrapiGuardrails?: string;
}
export interface LaunchDevtoolBrowserResponse {
}
export interface ListDevtoolBrowserTargetsRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
    /** How long the live view URLs remain valid, in milliseconds (max 60 minutes) */
    liveViewUrlExpiresInMs?: number;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListDevtoolBrowserTargetsResponse {
    /** Target ID. */
    id: string;
    /** Target type (page, background_page, worker, etc.). */
    type: string;
    /** URL of the target. */
    url: string;
    /** Target description. */
    description?: string | null;
    /** DevTools frontend URL. */
    devtoolsFrontendUrl?: string | null;
    /** Title of the target. */
    title?: string | null;
    /** WebSocket URL for debugging this target. */
    webSocketDebuggerUrl?: string | null;
}
export interface ListDevtoolSessionsRequest {
    /** Account ID. */
    accountId: string;
    limit?: number;
    offset?: number;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListDevtoolSessionsResponse {
    /** Session ID. */
    sessionId: string;
    /** Reason code for session closure. */
    closeReason?: number | null;
    /** Human-readable close reason. */
    closeReasonText?: string | null;
    /** Connection end time. */
    connectionEndTime?: number | null;
    /** Connection ID. */
    connectionId?: string | null;
    /** Connection start time. */
    connectionStartTime?: number | null;
    /** DevTools frontend URL. */
    devtoolsFrontendUrl?: string | null;
    /** Session end time. */
    endTime?: number | null;
    /** Last updated timestamp. */
    lastUpdated?: number | null;
    /** Session start time. */
    startTime?: number | null;
    /** WebSocket URL for debugging this target. */
    webSocketDebuggerUrl?: string | null;
}
export interface ProtocolDevtoolBrowserRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
}
export type DevtoolsBrowserProtocolResponseDomainsItemCommandsItemMap = {
    [key: string]: unknown | undefined;
};
export type DevtoolsBrowserProtocolResponseDomainsItemCommandsList = Array<DevtoolsBrowserProtocolResponseDomainsItemCommandsItemMap>;
export type DevtoolsBrowserProtocolResponseDomainsItemDependenciesList = Array<string>;
export type DevtoolsBrowserProtocolResponseDomainsItemEventsItemMap = {
    [key: string]: unknown | undefined;
};
export type DevtoolsBrowserProtocolResponseDomainsItemEventsList = Array<DevtoolsBrowserProtocolResponseDomainsItemEventsItemMap>;
export type DevtoolsBrowserProtocolResponseDomainsItemTypesItemMap = {
    [key: string]: unknown | undefined;
};
export type DevtoolsBrowserProtocolResponseDomainsItemTypesList = Array<DevtoolsBrowserProtocolResponseDomainsItemTypesItemMap>;
export interface DevtoolsBrowserProtocolResponseDomainsItem {
    /** Domain name. */
    domain: string;
    /** Available commands. */
    commands?: DevtoolsBrowserProtocolResponseDomainsItemCommandsList | null;
    /** Domain dependencies. */
    dependencies?: DevtoolsBrowserProtocolResponseDomainsItemDependenciesList | null;
    /** Available events. */
    events?: DevtoolsBrowserProtocolResponseDomainsItemEventsList | null;
    /** Whether this domain is experimental. */
    experimental?: boolean | null;
    /** Type definitions. */
    types?: DevtoolsBrowserProtocolResponseDomainsItemTypesList | null;
}
export type DevtoolsBrowserProtocolResponseDomainsList = Array<DevtoolsBrowserProtocolResponseDomainsItem>;
export interface DevtoolsBrowserProtocolResponseVersion {
    /** Major version. */
    major: string;
    /** Minor version. */
    minor: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ProtocolDevtoolBrowserResponse {
    /** List of protocol domains. */
    domains: DevtoolsBrowserProtocolResponseDomainsList;
    /** Protocol version. */
    version?: DevtoolsBrowserProtocolResponseVersion | null;
}
export interface VersionDevtoolBrowserRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface VersionDevtoolBrowserResponse {
    /** Browser name and version. */
    browser: string;
    /** Chrome DevTools Protocol version. */
    protocolVersion: string;
    /** User agent string. */
    userAgent: string;
    /** V8 JavaScript engine version. */
    v8Version: string;
    /** WebKit version. */
    webKitVersion: string;
    /** WebSocket URL for debugging the browser. */
    webSocketDebuggerUrl: string;
}
export type ActivateDevtoolBrowserTargetError = CloudflareOpError;
/** Activates (brings to front) a specific browser target by its ID. */
export declare const activateDevtoolBrowserTarget: API.OperationMethod<ActivateDevtoolBrowserTargetRequest, ActivateDevtoolBrowserTargetResponse, ActivateDevtoolBrowserTargetError, CloudflareOpContext>;
export type CloseDevtoolBrowserTargetError = CloudflareOpError;
/** Closes a specific browser target (tab, page, etc.) by its ID. Returns 'Target is closing' on success or an error if the target is not found. */
export declare const closeDevtoolBrowserTarget: API.OperationMethod<CloseDevtoolBrowserTargetRequest, CloseDevtoolBrowserTargetResponse, CloseDevtoolBrowserTargetError, CloudflareOpContext>;
export type ConnectDevtoolBrowserError = CloudflareOpError;
/** Establishes a WebSocket connection to an existing browser session. */
export declare const connectDevtoolBrowser: API.OperationMethod<ConnectDevtoolBrowserRequest, ConnectDevtoolBrowserResponse, ConnectDevtoolBrowserError, CloudflareOpContext>;
export type CreateAccessibilityTreeError = CloudflareOpError;
/** Returns the page's accessibility tree. Use `interestingOnly` to only return semantically meaningful nodes; use `root` to scope the tree to a CSS-selector-anchored subtree. Control page loading with `gotoOptions` and `waitFor*` options. */
export declare const createAccessibilityTree: API.OperationMethod<CreateAccessibilityTreeRequest, CreateAccessibilityTreeResponse, CreateAccessibilityTreeError, CloudflareOpContext>;
export type CreateContentError = CloudflareOpError;
/** Fetches rendered HTML content from provided URL or HTML. Check available options like `gotoOptions` and `waitFor*` to control page load behaviour. */
export declare const createContent: API.OperationMethod<CreateContentRequest, CreateContentResponse, CreateContentError, CloudflareOpContext>;
export type CreateCrawlError = CloudflareOpError;
/** Starts a crawl job for the provided URL and its children. Check available options like `gotoOptions` and `waitFor*` to control page load behaviour. */
export declare const createCrawl: API.OperationMethod<CreateCrawlRequest, CreateCrawlResponse, CreateCrawlError, CloudflareOpContext>;
export type CreateDevtoolBrowserError = CloudflareOpError;
/** Acquires a browser and returns its session ID and websocket URL. Optionally accepts a JSON body with session guardrails to restrict outbound HTTP/S traffic. */
export declare const createDevtoolBrowser: API.OperationMethod<CreateDevtoolBrowserRequest, CreateDevtoolBrowserResponse, CreateDevtoolBrowserError, CloudflareOpContext>;
export type CreateDevtoolBrowserTargetError = CloudflareOpError;
/** Opens a new tab in the browser. Optionally specify a URL to navigate to. */
export declare const createDevtoolBrowserTarget: API.OperationMethod<CreateDevtoolBrowserTargetRequest, CreateDevtoolBrowserTargetResponse, CreateDevtoolBrowserTargetError, CloudflareOpContext>;
export type CreateDevtoolsBrowserLiveViewError = CloudflareOpError;
/** Generates time-limited URLs to view a remote browser session. Set `guardrails: { mode: 'readonly' }` to create a view-only link. */
export declare const createDevtoolsBrowserLiveView: API.OperationMethod<CreateDevtoolsBrowserLiveViewRequest, CreateDevtoolsBrowserLiveViewResponse, CreateDevtoolsBrowserLiveViewError, CloudflareOpContext>;
export type CreateJsonError = CloudflareOpError;
/** Gets json from a webpage from a provided URL or HTML. Pass `prompt` or `schema` in the body. Control page loading with `gotoOptions` and `waitFor*` options. */
export declare const createJson: API.OperationMethod<CreateJsonRequest, CreateJsonResponse, CreateJsonError, CloudflareOpContext>;
export type CreateLinkError = CloudflareOpError;
/** Get links from a web page. */
export declare const createLink: API.OperationMethod<CreateLinkRequest, CreateLinkResponse, CreateLinkError, CloudflareOpContext>;
export type CreateMarkdownError = CloudflareOpError;
/** Gets markdown of a webpage from provided URL or HTML. Control page loading with `gotoOptions` and `waitFor*` options. */
export declare const createMarkdown: API.OperationMethod<CreateMarkdownRequest, CreateMarkdownResponse, CreateMarkdownError, CloudflareOpContext>;
export type CreatePdfError = CloudflareOpError;
/** Fetches rendered PDF from provided URL or HTML. Check available options like `gotoOptions` and `waitFor*` to control page load behaviour. */
export declare const createPdf: API.OperationMethod<CreatePdfRequest, CreatePdfResponse, CreatePdfError, CloudflareOpContext>;
export type CreateScrapeError = CloudflareOpError;
/** Get meta attributes like height, width, text and others of selected elements. */
export declare const createScrape: API.OperationMethod<CreateScrapeRequest, CreateScrapeResponse, CreateScrapeError, CloudflareOpContext>;
export type CreateScreenshotError = CloudflareOpError;
/** Takes a screenshot of a webpage from provided URL or HTML. Control page loading with `gotoOptions` and `waitFor*` options. Customize screenshots with `viewport`, `fullPage`, `clip` and others. */
export declare const createScreenshot: API.OperationMethod<CreateScreenshotRequest, CreateScreenshotResponse, CreateScreenshotError, CloudflareOpContext>;
export type CreateSnapshotError = CloudflareOpError;
/** Returns the page's HTML content and screenshot. Control page loading with `gotoOptions` and `waitFor*` options. Customize screenshots with `viewport`, `fullPage`, `clip` and others. */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotRequest, CreateSnapshotResponse, CreateSnapshotError, CloudflareOpContext>;
export type DeleteCrawlError = CloudflareOpError;
/** Cancels an ongoing crawl job by setting its status to cancelled and stopping all queued URLs. */
export declare const deleteCrawl: API.OperationMethod<DeleteCrawlRequest, DeleteCrawlResponse, DeleteCrawlError, CloudflareOpContext>;
export type DeleteDevtoolBrowserError = CloudflareOpError;
/** Closes an existing browser session. */
export declare const deleteDevtoolBrowser: API.OperationMethod<DeleteDevtoolBrowserRequest, DeleteDevtoolBrowserResponse, DeleteDevtoolBrowserError, CloudflareOpContext>;
export type GetCrawlError = CloudflareOpError;
/** Returns the result of a crawl job. */
export declare const getCrawl: API.OperationMethod<GetCrawlRequest, GetCrawlResponse, GetCrawlError, CloudflareOpContext>;
export type GetDevtoolBrowserPageError = CloudflareOpError;
/** Establishes a WebSocket connection to a specific Chrome DevTools target or page. */
export declare const getDevtoolBrowserPage: API.OperationMethod<GetDevtoolBrowserPageRequest, GetDevtoolBrowserPageResponse, GetDevtoolBrowserPageError, CloudflareOpContext>;
export type GetDevtoolBrowserTargetError = CloudflareOpError;
/** Returns the debuggable target with the given ID. */
export declare const getDevtoolBrowserTarget: API.OperationMethod<GetDevtoolBrowserTargetRequest, GetDevtoolBrowserTargetResponse, GetDevtoolBrowserTargetError, CloudflareOpContext>;
export type GetDevtoolSessionError = CloudflareOpError;
/** Get details for a specific browser session. */
export declare const getDevtoolSession: API.OperationMethod<GetDevtoolSessionRequest, GetDevtoolSessionResponse, GetDevtoolSessionError, CloudflareOpContext>;
export type LaunchDevtoolBrowserError = CloudflareOpError;
/** Acquires and establishes a WebSocket connection to a browser session. Session guardrails may be supplied in the `cf-brapi-guardrails` header as base64url-encoded JSON of the same `guardrails` object the POST body accepts (for example `{"allowedDomains":["*.example.com"]}`). */
export declare const launchDevtoolBrowser: API.OperationMethod<LaunchDevtoolBrowserRequest, LaunchDevtoolBrowserResponse, LaunchDevtoolBrowserError, CloudflareOpContext>;
export type ListDevtoolBrowserTargetsError = CloudflareOpError;
/** Returns a list of all debuggable targets including tabs, pages, service workers, and other browser contexts. */
export declare const listDevtoolBrowserTargets: API.OperationMethod<ListDevtoolBrowserTargetsRequest, ListDevtoolBrowserTargetsResponse, ListDevtoolBrowserTargetsError, CloudflareOpContext>;
export type ListDevtoolSessionsError = CloudflareOpError;
/** List active browser sessions. */
export declare const listDevtoolSessions: API.OperationMethod<ListDevtoolSessionsRequest, ListDevtoolSessionsResponse, ListDevtoolSessionsError, CloudflareOpContext>;
export type ProtocolDevtoolBrowserError = CloudflareOpError;
/** Returns the complete Chrome DevTools Protocol schema including all domains, commands, events, and types. This schema describes the entire CDP API surface. */
export declare const protocolDevtoolBrowser: API.OperationMethod<ProtocolDevtoolBrowserRequest, ProtocolDevtoolBrowserResponse, ProtocolDevtoolBrowserError, CloudflareOpContext>;
export type VersionDevtoolBrowserError = CloudflareOpError;
/** Get browser version metadata. */
export declare const versionDevtoolBrowser: API.OperationMethod<VersionDevtoolBrowserRequest, VersionDevtoolBrowserResponse, VersionDevtoolBrowserError, CloudflareOpContext>;
//# sourceMappingURL=browser_rendering.d.ts.map