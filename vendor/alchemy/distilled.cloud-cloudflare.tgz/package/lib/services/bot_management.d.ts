import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface CreateFeedbackRequestRequestsByAttribute {
    metric: string;
    requests: number;
}
export type CreateFeedbackRequestRequestsByScoreMap = {
    [key: string]: number | undefined;
};
export type CreateFeedbackRequestRequestsByScoreSrcMap = {
    [key: string]: number | undefined;
};
export type CreateFeedbackRequestType = "false_positive" | "false_negative";
export interface CreateFeedbackRequest {
    /** Identifier. */
    zoneId: string;
    description: string;
    /** Wirefilter expression describing the traffic being reported. */
    expression: string;
    firstRequestSeenAt: string;
    lastRequestSeenAt: string;
    requests: number;
    /** Top attributes contributing to the feedback sample. Keys include topASNs, topCountries, topHosts, topIPs, topJA3Hashes, topJA4s, topPaths, topUserAgents. */
    requestsByAttribute: CreateFeedbackRequestRequestsByAttribute;
    /** Map of bot scores (1-99) to request counts. Sum must equal `requests`. */
    requestsByScore: CreateFeedbackRequestRequestsByScoreMap;
    /** Map of score source to request counts. Sum must equal `requests`. */
    requestsByScoreSrc: CreateFeedbackRequestRequestsByScoreSrcMap;
    /** Type of feedback report. */
    type: CreateFeedbackRequestType | (string & {});
    subtype?: string;
}
export interface CreateFeedbackResponse {
}
export interface GetBotManagementRequest {
    /** Identifier. */
    zoneId: string;
}
export type GetResultBotFightModeConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type GetResultBotFightModeConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type GetResultBotFightModeConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type GetResultBotFightModeConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type GetResultBotFightModeConfigurationCfRobotsVariant = "off" | "policy_only";
export type GetResultBotFightModeConfigurationContentBotsProtection = "block" | "disabled";
export type GetResultBotFightModeConfigurationCrawlerProtection = "enabled" | "disabled";
export interface GetResultBotFightModeConfigurationStaleZoneConfiguration {
    /** Indicates that the zone's wordpress optimization for SBFM is turned on. */
    optimizeWordpress?: boolean | null;
    /** Indicates that the zone's definitely automated requests are being blocked or challenged. */
    sbfmDefinitelyAutomated?: string | null;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string | null;
    /** Indicates that the zone's static resource protection is turned on. */
    sbfmStaticResourceProtection?: string | null;
    /** Indicates that the zone's verified bot requests are being blocked. */
    sbfmVerifiedBots?: string | null;
    /** Indicates that the zone's session score tracking is disabled. */
    suppressSessionScore?: boolean | null;
}
export interface GetResultBotFightModeConfiguration {
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: GetResultBotFightModeConfigurationAiBotsProtection | null;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: GetResultBotFightModeConfigurationAiSearch | null;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: GetResultBotFightModeConfigurationAiTraining | null;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: GetResultBotFightModeConfigurationAiUser | null;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: GetResultBotFightModeConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: GetResultBotFightModeConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: GetResultBotFightModeConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Whether to enable Bot Fight Mode. */
    fightMode?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultBotFightModeConfigurationStaleZoneConfiguration | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export type GetResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type GetResultSuperBotFightModeDefinitelyConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeDefinitelyConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeDefinitelyConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant = "off" | "policy_only";
export type GetResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection = "block" | "disabled";
export type GetResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection = "enabled" | "disabled";
export type GetResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export type GetResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots = "allow" | "block";
export interface GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean | null;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string | null;
}
export interface GetResultSuperBotFightModeDefinitelyConfiguration {
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: GetResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection | null;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: GetResultSuperBotFightModeDefinitelyConfigurationAiSearch | null;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: GetResultSuperBotFightModeDefinitelyConfigurationAiTraining | null;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: GetResultSuperBotFightModeDefinitelyConfigurationAiUser | null;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: GetResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: GetResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: GetResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: GetResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated | null;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. Enable if static resources on your application need bot protection. Note: Static resource protection can also result in legitimate traffic being blocked. */
    sbfmStaticResourceProtection?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: GetResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export type GetResultSuperBotFightModeLikelyConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type GetResultSuperBotFightModeLikelyConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeLikelyConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeLikelyConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeLikelyConfigurationCfRobotsVariant = "off" | "policy_only";
export type GetResultSuperBotFightModeLikelyConfigurationContentBotsProtection = "block" | "disabled";
export type GetResultSuperBotFightModeLikelyConfigurationCrawlerProtection = "enabled" | "disabled";
export type GetResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export type GetResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated = "allow" | "block" | "managed_challenge";
export type GetResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots = "allow" | "block";
export interface GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean | null;
}
export interface GetResultSuperBotFightModeLikelyConfiguration {
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: GetResultSuperBotFightModeLikelyConfigurationAiBotsProtection | null;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: GetResultSuperBotFightModeLikelyConfigurationAiSearch | null;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: GetResultSuperBotFightModeLikelyConfigurationAiTraining | null;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: GetResultSuperBotFightModeLikelyConfigurationAiUser | null;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: GetResultSuperBotFightModeLikelyConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: GetResultSuperBotFightModeLikelyConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: GetResultSuperBotFightModeLikelyConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: GetResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated | null;
    /** Super Bot Fight Mode (SBFM) action to take on likely automated requests. */
    sbfmLikelyAutomated?: GetResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated | null;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. Enable if static resources on your application need bot protection. Note: Static resource protection can also result in legitimate traffic being blocked. */
    sbfmStaticResourceProtection?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: GetResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export type GetResultSubscriptionConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type GetResultSubscriptionConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSubscriptionConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type GetResultSubscriptionConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSubscriptionConfigurationCfRobotsVariant = "off" | "policy_only";
export type GetResultSubscriptionConfigurationContentBotsProtection = "block" | "disabled";
export type GetResultSubscriptionConfigurationCrawlerProtection = "enabled" | "disabled";
export interface GetResultSubscriptionConfigurationStaleZoneConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean | null;
    /** Indicates that the zone's wordpress optimization for SBFM is turned on. */
    optimizeWordpress?: boolean | null;
    /** Indicates that the zone's definitely automated requests are being blocked or challenged. */
    sbfmDefinitelyAutomated?: string | null;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string | null;
    /** Indicates that the zone's static resource protection is turned on. */
    sbfmStaticResourceProtection?: string | null;
    /** Indicates that the zone's verified bot requests are being blocked. */
    sbfmVerifiedBots?: string | null;
}
export interface GetResultSubscriptionConfiguration {
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: GetResultSubscriptionConfigurationAiBotsProtection | null;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: GetResultSubscriptionConfigurationAiSearch | null;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: GetResultSubscriptionConfigurationAiTraining | null;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: GetResultSubscriptionConfigurationAiUser | null;
    /** Automatically update to the newest bot detection models created by Cloudflare as they are released. [Learn more.](https://developers.cloudflare.com/bots/reference/machine-learning-models#model-versions-and-release-notes) */
    autoUpdateModel?: boolean | null;
    /** Indicates that the bot management cookie can be placed on end user devices accessing the site. Defaults to true */
    bmCookieEnabled?: boolean | null;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: GetResultSubscriptionConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: GetResultSubscriptionConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: GetResultSubscriptionConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSubscriptionConfigurationStaleZoneConfiguration | null;
    /** Whether to disable tracking the highest bot score for a session in the Bot Management cookie. */
    suppressSessionScore?: boolean | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export type GetResult = GetResultBotFightModeConfiguration | GetResultSuperBotFightModeDefinitelyConfiguration | GetResultSuperBotFightModeLikelyConfiguration | GetResultSubscriptionConfiguration;
export type GetBotManagementResponse = GetResult;
export interface ListFeedbackRequest {
    /** Identifier. */
    zoneId: string;
}
export type ListFeedbackResponseRequestsByAttribute = CreateFeedbackRequestRequestsByAttribute;
export type ListFeedbackResponseRequestsByScoreMap = {
    [key: string]: number | undefined;
};
export type ListFeedbackResponseRequestsByScoreSrcMap = {
    [key: string]: number | undefined;
};
export type ListFeedbackResponseType = "false_positive" | "false_negative";
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListFeedbackResponse {
    description: string;
    /** Wirefilter expression describing the traffic being reported. */
    expression: string;
    firstRequestSeenAt: string;
    lastRequestSeenAt: string;
    requests: number;
    /** Top attributes contributing to the feedback sample. Keys include topASNs, topCountries, topHosts, topIPs, topJA3Hashes, topJA4s, topPaths, topUserAgents. */
    requestsByAttribute: CreateFeedbackRequestRequestsByAttribute;
    /** Map of bot scores (1-99) to request counts. Sum must equal `requests`. */
    requestsByScore: ListFeedbackResponseRequestsByScoreMap;
    /** Map of score source to request counts. Sum must equal `requests`. */
    requestsByScoreSrc: ListFeedbackResponseRequestsByScoreSrcMap;
    /** Type of feedback report. */
    type: ListFeedbackResponseType;
    createdAt?: string | null;
    subtype?: string | null;
}
export type UpdateRequestAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type UpdateRequestAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type UpdateRequestAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type UpdateRequestAiUser = "disabled" | "block" | "only_on_ad_pages";
export type UpdateRequestCfRobotsVariant = "off" | "policy_only";
export type UpdateRequestContentBotsProtection = "block" | "disabled";
export type UpdateRequestCrawlerProtection = "enabled" | "disabled";
export interface UpdateRequestStaleZoneConfigurationBotFightModeConfiguration {
    /** Indicates that the zone's wordpress optimization for SBFM is turned on. */
    optimizeWordpress?: boolean;
    /** Indicates that the zone's definitely automated requests are being blocked or challenged. */
    sbfmDefinitelyAutomated?: string;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string;
    /** Indicates that the zone's static resource protection is turned on. */
    sbfmStaticResourceProtection?: string;
    /** Indicates that the zone's verified bot requests are being blocked. */
    sbfmVerifiedBots?: string;
    /** Indicates that the zone's session score tracking is disabled. */
    suppressSessionScore?: boolean;
}
export interface UpdateRequestStaleZoneConfigurationSuperBotFightModeDefinitelyConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string;
}
export interface UpdateRequestStaleZoneConfigurationSuperBotFightModeLikelyConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean;
}
export interface UpdateRequestStaleZoneConfigurationSubscriptionConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean;
    /** Indicates that the zone's wordpress optimization for SBFM is turned on. */
    optimizeWordpress?: boolean;
    /** Indicates that the zone's definitely automated requests are being blocked or challenged. */
    sbfmDefinitelyAutomated?: string;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string;
    /** Indicates that the zone's static resource protection is turned on. */
    sbfmStaticResourceProtection?: string;
    /** Indicates that the zone's verified bot requests are being blocked. */
    sbfmVerifiedBots?: string;
}
export type UpdateRequestStaleZoneConfiguration = UpdateRequestStaleZoneConfigurationBotFightModeConfiguration | UpdateRequestStaleZoneConfigurationSuperBotFightModeDefinitelyConfiguration | UpdateRequestStaleZoneConfigurationSuperBotFightModeLikelyConfiguration | UpdateRequestStaleZoneConfigurationSubscriptionConfiguration;
export type UpdateRequestSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export type UpdateRequestSbfmVerifiedBots = "allow" | "block";
export type UpdateRequestSbfmLikelyAutomated = "allow" | "block" | "managed_challenge";
export interface PutBotManagementRequest {
    /** Identifier. */
    zoneId: string;
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateRequestAiBotsProtection | (string & {});
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: UpdateRequestAiSearch | (string & {});
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: UpdateRequestAiTraining | (string & {});
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: UpdateRequestAiUser | (string & {});
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateRequestCfRobotsVariant | (string & {});
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateRequestContentBotsProtection | (string & {});
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateRequestCrawlerProtection | (string & {});
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean;
    /** Whether to enable Bot Fight Mode. */
    fightMode?: boolean;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: UpdateRequestStaleZoneConfiguration;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: UpdateRequestSbfmDefinitelyAutomated | (string & {});
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. Enable if static resources on your application need bot protection. Note: Static resource protection can also result in legitimate traffic being blocked. */
    sbfmStaticResourceProtection?: boolean;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: UpdateRequestSbfmVerifiedBots | (string & {});
    /** Super Bot Fight Mode (SBFM) action to take on likely automated requests. */
    sbfmLikelyAutomated?: UpdateRequestSbfmLikelyAutomated | (string & {});
    /** Automatically update to the newest bot detection models created by Cloudflare as they are released. [Learn more.](https://developers.cloudflare.com/bots/reference/machine-learning-models#model-versions-and-release-notes) */
    autoUpdateModel?: boolean;
    /** Indicates that the bot management cookie can be placed on end user devices accessing the site. Defaults to true */
    bmCookieEnabled?: boolean;
    /** Whether to disable tracking the highest bot score for a session in the Bot Management cookie. */
    suppressSessionScore?: boolean;
}
export type UpdateResultBotFightModeConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type UpdateResultBotFightModeConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultBotFightModeConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type UpdateResultBotFightModeConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultBotFightModeConfigurationCfRobotsVariant = "off" | "policy_only";
export type UpdateResultBotFightModeConfigurationContentBotsProtection = "block" | "disabled";
export type UpdateResultBotFightModeConfigurationCrawlerProtection = "enabled" | "disabled";
export type UpdateResultBotFightModeConfigurationStaleZoneConfiguration = GetResultBotFightModeConfigurationStaleZoneConfiguration;
export interface UpdateResultBotFightModeConfiguration {
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateResultBotFightModeConfigurationAiBotsProtection | null;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: UpdateResultBotFightModeConfigurationAiSearch | null;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: UpdateResultBotFightModeConfigurationAiTraining | null;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: UpdateResultBotFightModeConfigurationAiUser | null;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateResultBotFightModeConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateResultBotFightModeConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateResultBotFightModeConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Whether to enable Bot Fight Mode. */
    fightMode?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultBotFightModeConfigurationStaleZoneConfiguration | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant = "off" | "policy_only";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection = "block" | "disabled";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection = "enabled" | "disabled";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots = "allow" | "block";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration = GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration;
export interface UpdateResultSuperBotFightModeDefinitelyConfiguration {
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection | null;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiSearch | null;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiTraining | null;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiUser | null;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated | null;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. Enable if static resources on your application need bot protection. Note: Static resource protection can also result in legitimate traffic being blocked. */
    sbfmStaticResourceProtection?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export type UpdateResultSuperBotFightModeLikelyConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeLikelyConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeLikelyConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeLikelyConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeLikelyConfigurationCfRobotsVariant = "off" | "policy_only";
export type UpdateResultSuperBotFightModeLikelyConfigurationContentBotsProtection = "block" | "disabled";
export type UpdateResultSuperBotFightModeLikelyConfigurationCrawlerProtection = "enabled" | "disabled";
export type UpdateResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export type UpdateResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated = "allow" | "block" | "managed_challenge";
export type UpdateResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots = "allow" | "block";
export type UpdateResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration = GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration;
export interface UpdateResultSuperBotFightModeLikelyConfiguration {
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateResultSuperBotFightModeLikelyConfigurationAiBotsProtection | null;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: UpdateResultSuperBotFightModeLikelyConfigurationAiSearch | null;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: UpdateResultSuperBotFightModeLikelyConfigurationAiTraining | null;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: UpdateResultSuperBotFightModeLikelyConfigurationAiUser | null;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateResultSuperBotFightModeLikelyConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateResultSuperBotFightModeLikelyConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateResultSuperBotFightModeLikelyConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: UpdateResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated | null;
    /** Super Bot Fight Mode (SBFM) action to take on likely automated requests. */
    sbfmLikelyAutomated?: UpdateResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated | null;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. Enable if static resources on your application need bot protection. Note: Static resource protection can also result in legitimate traffic being blocked. */
    sbfmStaticResourceProtection?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: UpdateResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export type UpdateResultSubscriptionConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type UpdateResultSubscriptionConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSubscriptionConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type UpdateResultSubscriptionConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSubscriptionConfigurationCfRobotsVariant = "off" | "policy_only";
export type UpdateResultSubscriptionConfigurationContentBotsProtection = "block" | "disabled";
export type UpdateResultSubscriptionConfigurationCrawlerProtection = "enabled" | "disabled";
export type UpdateResultSubscriptionConfigurationStaleZoneConfiguration = GetResultSubscriptionConfigurationStaleZoneConfiguration;
export interface UpdateResultSubscriptionConfiguration {
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateResultSubscriptionConfigurationAiBotsProtection | null;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: UpdateResultSubscriptionConfigurationAiSearch | null;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: UpdateResultSubscriptionConfigurationAiTraining | null;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: UpdateResultSubscriptionConfigurationAiUser | null;
    /** Automatically update to the newest bot detection models created by Cloudflare as they are released. [Learn more.](https://developers.cloudflare.com/bots/reference/machine-learning-models#model-versions-and-release-notes) */
    autoUpdateModel?: boolean | null;
    /** Indicates that the bot management cookie can be placed on end user devices accessing the site. Defaults to true */
    bmCookieEnabled?: boolean | null;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateResultSubscriptionConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateResultSubscriptionConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateResultSubscriptionConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSubscriptionConfigurationStaleZoneConfiguration | null;
    /** Whether to disable tracking the highest bot score for a session in the Bot Management cookie. */
    suppressSessionScore?: boolean | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export type UpdateResult = UpdateResultBotFightModeConfiguration | UpdateResultSuperBotFightModeDefinitelyConfiguration | UpdateResultSuperBotFightModeLikelyConfiguration | UpdateResultSubscriptionConfiguration;
export type PutBotManagementResponse = UpdateResult;
export type CreateFeedbackError = CloudflareOpError;
/** Submit a feedback report for the specified zone. Use `type` to indicate whether the report is a false positive (good traffic flagged as bot) or a false negative (bot traffic missed). Furthermore, you can also use `expression` as a wirefilter to identify the affected traffic sample. See more accepted API fields and expression types at https://developers.cloudflare.com/bots/concepts/feedback-loop/#api-fields and https://developers.cloudflare.com/bots/concepts/feedback-loop/#expression-fields, respectively. */
export declare const createFeedback: API.OperationMethod<CreateFeedbackRequest, CreateFeedbackResponse, CreateFeedbackError, CloudflareOpContext>;
export type GetBotManagementError = Forbidden | CloudflareOpError;
/** Retrieve a zone's Bot Management Config */
export declare const getBotManagement: API.OperationMethod<GetBotManagementRequest, GetBotManagementResponse, GetBotManagementError, CloudflareOpContext>;
export type ListFeedbackError = CloudflareOpError;
/** Returns all feedback reports previously submitted for the specified zone. Feedback reports help improve detection by sharing samples of traffic that were misclassified as bots or humans. */
export declare const listFeedback: API.OperationMethod<ListFeedbackRequest, ListFeedbackResponse, ListFeedbackError, CloudflareOpContext>;
export type PutBotManagementError = Forbidden | CloudflareOpError;
/** Updates the Bot Management configuration for a zone. This API is used to update: - **Bot Fight Mode** - **Super Bot Fight Mode** - **Bot Management for Enterprise** See [Bot Plans](https://developers.cloudflare.com/bots/plans/) for more information on the different plans If you recently upgraded or downgraded your plan, refer to the following examples to clean up old configurations. Copy and paste the example body to remove old zone configurations based on your current plan. */
export declare const putBotManagement: API.OperationMethod<PutBotManagementRequest, PutBotManagementResponse, PutBotManagementError, CloudflareOpContext>;
//# sourceMappingURL=bot_management.d.ts.map