import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type BulkDeleteRequestIdList = Array<string>;
export interface BulkDeleteFiltersRequest {
    /** Defines an identifier. */
    zoneId: string;
    id: BulkDeleteRequestIdList;
}
export interface BulkDeleteResultItem {
    /** The unique identifier of the filter. */
    id?: string | null;
}
export type BulkDeleteResultList = Array<BulkDeleteResultItem>;
export type BulkDeleteFiltersResponse = BulkDeleteResultList;
export interface BulkUpdateRequestBodyItem {
    /** The unique identifier of the filter. */
    id?: string;
    /** An informative summary of the filter. */
    description?: string;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string;
}
export type BulkUpdateRequestBodyList = Array<BulkUpdateRequestBodyItem>;
export interface BulkPutFiltersRequest {
    /** Defines an identifier. */
    zoneId: string;
    body: BulkUpdateRequestBodyList;
}
export interface BulkUpdateResultItem {
    /** The unique identifier of the filter. */
    id?: string | null;
    /** An informative summary of the filter. */
    description?: string | null;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string | null;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean | null;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string | null;
}
export type BulkUpdateResultList = Array<BulkUpdateResultItem>;
export interface BulkPutFiltersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: BulkUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type CreateRequestBodyItem = BulkUpdateRequestBodyItem;
export type CreateRequestBodyList = Array<BulkUpdateRequestBodyItem>;
export interface CreateFilterRequest {
    /** Defines an identifier. */
    zoneId: string;
    body: CreateRequestBodyList;
}
export type CreateResultItem = BulkUpdateResultItem;
export type CreateResultList = Array<BulkUpdateResultItem>;
export interface CreateFilterResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface DeleteFilterRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the filter. */
    filterId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteFilterResponse {
    /** The unique identifier of the filter. */
    id: string;
}
export interface GetFilterRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the filter. */
    filterId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetFilterResponse {
    /** The unique identifier of the filter. */
    id?: string | null;
    /** An informative summary of the filter. */
    description?: string | null;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string | null;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean | null;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string | null;
}
export interface ListFiltersRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the filter. */
    id?: string;
    /** A case-insensitive string to find in the description. */
    description?: string;
    /** A case-insensitive string to find in the expression. */
    expression?: string;
    /** Page number of paginated results. */
    page?: number;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean;
    /** Number of filters per page. */
    perPage?: number;
    /** The filter ref (a short reference tag) to search for. Must be an exact match. */
    ref?: string;
}
export type ListResultItem = BulkUpdateResultItem;
export type ListResultList = Array<BulkUpdateResultItem>;
export interface ListFiltersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface UpdateFilterRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the filter. */
    filterId: string;
    /** An informative summary of the filter. */
    description?: string;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateFilterResponse {
    /** The unique identifier of the filter. */
    id?: string | null;
    /** An informative summary of the filter. */
    description?: string | null;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string | null;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean | null;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string | null;
}
export type BulkDeleteFiltersError = CloudflareOpError;
/** Deletes one or more existing filters. */
export declare const bulkDeleteFilters: API.OperationMethod<BulkDeleteFiltersRequest, BulkDeleteFiltersResponse, BulkDeleteFiltersError, CloudflareOpContext>;
export type BulkPutFiltersError = CloudflareOpError;
/** Updates one or more existing filters. */
export declare const bulkPutFilters: API.PaginatedOperationMethod<BulkPutFiltersRequest, BulkPutFiltersResponse, BulkPutFiltersError, CloudflareOpContext, BulkUpdateResultItem>;
export type CreateFilterError = CloudflareOpError;
/** Creates one or more filters. */
export declare const createFilter: API.PaginatedOperationMethod<CreateFilterRequest, CreateFilterResponse, CreateFilterError, CloudflareOpContext, BulkUpdateResultItem>;
export type DeleteFilterError = CloudflareOpError;
/** Deletes an existing filter. */
export declare const deleteFilter: API.OperationMethod<DeleteFilterRequest, DeleteFilterResponse, DeleteFilterError, CloudflareOpContext>;
export type GetFilterError = CloudflareOpError;
/** Fetches the details of a filter. */
export declare const getFilter: API.OperationMethod<GetFilterRequest, GetFilterResponse, GetFilterError, CloudflareOpContext>;
export type ListFiltersError = CloudflareOpError;
/** Fetches filters in a zone. You can filter the results using several optional parameters. */
export declare const listFilters: API.PaginatedOperationMethod<ListFiltersRequest, ListFiltersResponse, ListFiltersError, CloudflareOpContext, BulkUpdateResultItem>;
export type UpdateFilterError = CloudflareOpError;
/** Updates an existing filter. */
export declare const updateFilter: API.OperationMethod<UpdateFilterRequest, UpdateFilterResponse, UpdateFilterError, CloudflareOpContext>;
//# sourceMappingURL=filters.d.ts.map