import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const OriginCloudRegionNotFound_base: S.TaggedErrorClass<"OriginCloudRegionNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class OriginCloudRegionNotFound extends /*@__PURE__*/ OriginCloudRegionNotFound_base {
}
declare const SettingUnavailableForPlan_base: S.TaggedErrorClass<"SettingUnavailableForPlan", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SettingUnavailableForPlan extends /*@__PURE__*/ SettingUnavailableForPlan_base {
}
declare const Unauthorized_base: S.TaggedErrorClass<"Unauthorized", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Unauthorized extends /*@__PURE__*/ Unauthorized_base {
}
declare const VariantsNotConfigured_base: S.TaggedErrorClass<"VariantsNotConfigured", {
    readonly code: any;
    readonly message: any;
}>;
export declare class VariantsNotConfigured extends /*@__PURE__*/ VariantsNotConfigured_base {
}
export interface BulkDeleteOriginCloudRegionsRequest {
    /** Identifier. */
    zoneId: string;
}
export interface OriginCloudRegionsBulkDeleteResponseFailedItem {
    /** The origin IP address for this item. */
    originIp: string;
    /** Error message explaining why the item failed. Present only on failed items. */
    error?: string | null;
    /** Cloud vendor region identifier. Present on succeeded items (the new value for upsert, the deleted value for delete). */
    region?: string | null;
    /** Cloud vendor identifier. Present on succeeded items (the new value for upsert, the deleted value for delete). */
    vendor?: string | null;
}
export type OriginCloudRegionsBulkDeleteResponseFailedList = Array<OriginCloudRegionsBulkDeleteResponseFailedItem>;
export type OriginCloudRegionsBulkDeleteResponseSucceededItem = OriginCloudRegionsBulkDeleteResponseFailedItem;
export type OriginCloudRegionsBulkDeleteResponseSucceededList = Array<OriginCloudRegionsBulkDeleteResponseFailedItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkDeleteOriginCloudRegionsResponse {
    /** Items that could not be applied, with error details. */
    failed: OriginCloudRegionsBulkDeleteResponseFailedList;
    /** Items that were successfully applied. */
    succeeded: OriginCloudRegionsBulkDeleteResponseSucceededList;
}
export type OriginCloudRegionsBulkUpdateRequestBodyItemVendor = "aws" | "azure" | "gcp" | "oci";
export interface OriginCloudRegionsBulkUpdateRequestBodyItem {
    /** Origin IP address (IPv4 or IPv6). For the single PUT endpoint (`PUT /origin/cloud_regions/{origin_ip}`), this field must match the path parameter or the request will be rejected with a 400 error. For the batch PUT endpoint, this field identifies which mapping to upsert. */
    originIp: string;
    /** Cloud vendor region identifier. Must be a valid region for the specified vendor as returned by the supported_regions endpoint. */
    region: string;
    /** Cloud vendor hosting the origin. Must be one of the supported vendors. */
    vendor: OriginCloudRegionsBulkUpdateRequestBodyItemVendor | (string & {});
}
export type OriginCloudRegionsBulkUpdateRequestBodyList = Array<OriginCloudRegionsBulkUpdateRequestBodyItem>;
export interface BulkPutOriginCloudRegionsRequest {
    /** Identifier. */
    zoneId: string;
    body: OriginCloudRegionsBulkUpdateRequestBodyList;
}
export type OriginCloudRegionsBulkUpdateResponseFailedItem = OriginCloudRegionsBulkDeleteResponseFailedItem;
export type OriginCloudRegionsBulkUpdateResponseFailedList = Array<OriginCloudRegionsBulkDeleteResponseFailedItem>;
export type OriginCloudRegionsBulkUpdateResponseSucceededItem = OriginCloudRegionsBulkDeleteResponseFailedItem;
export type OriginCloudRegionsBulkUpdateResponseSucceededList = Array<OriginCloudRegionsBulkDeleteResponseFailedItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPutOriginCloudRegionsResponse {
    /** Items that could not be applied, with error details. */
    failed: OriginCloudRegionsBulkUpdateResponseFailedList;
    /** Items that were successfully applied. */
    succeeded: OriginCloudRegionsBulkUpdateResponseSucceededList;
}
export interface ClearCacheReserveRequest {
    /** Identifier. */
    zoneId: string;
}
export type CacheReserveClearResponseId = "cache_reserve_clear";
export type CacheReserveClearResponseState = "In-progress" | "Completed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ClearCacheReserveResponse {
    /** ID of the zone setting. */
    id: CacheReserveClearResponseId;
    /** The time that the latest Cache Reserve Clear operation started. */
    startTs: string;
    /** The current state of the Cache Reserve Clear operation. */
    state: CacheReserveClearResponseState;
    /** The time that the latest Cache Reserve Clear operation completed. */
    endTs?: string | null;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SmartTieredCacheCreateRequestValue = "on" | "off";
export interface CreateSmartTieredCacheRequest {
    /** Identifier. */
    zoneId: string;
    /** Enable or disable the Smart Tiered Cache. */
    value: SmartTieredCacheCreateRequestValue | (string & {});
}
export type SmartTieredCacheCreateResponseId = "tiered_cache_smart_topology_enable";
export type SmartTieredCacheCreateResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSmartTieredCacheResponse {
    /** The identifier of the caching setting. */
    id: SmartTieredCacheCreateResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Smart Tiered Cache zone setting. */
    value: SmartTieredCacheCreateResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export interface DeleteOriginCloudRegionRequest {
    /** Identifier. */
    zoneId: string;
    originIP: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOriginCloudRegionResponse {
    /** The origin IP address whose mapping was deleted. */
    originIp: string;
}
export interface DeleteSmartTieredCacheRequest {
    /** Identifier. */
    zoneId: string;
}
export type SmartTieredCacheDeleteResponseId = "tiered_cache_smart_topology_enable";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSmartTieredCacheResponse {
    /** The identifier of the caching setting. */
    id: SmartTieredCacheDeleteResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export interface DeleteVariantRequest {
    /** Identifier. */
    zoneId: string;
}
export type VariantsDeleteResponseId = "variants";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteVariantResponse {
    /** The identifier of the caching setting. */
    id: VariantsDeleteResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export interface GetCacheReserveRequest {
    /** Identifier. */
    zoneId: string;
}
export type CacheReserveGetResponseId = "cache_reserve";
export type CacheReserveGetResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCacheReserveResponse {
    /** The identifier of the caching setting. */
    id: CacheReserveGetResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Cache Reserve zone setting. */
    value: CacheReserveGetResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export interface GetOriginCloudRegionRequest {
    /** Identifier. */
    zoneId: string;
    originIP: string;
}
export type OriginCloudRegionsGetResponseVendor = "aws" | "azure" | "gcp" | "oci";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOriginCloudRegionResponse {
    /** The origin IP address (IPv4 or IPv6). Normalized to canonical form (RFC 5952 for IPv6). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsGetResponseVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export interface GetRegionalTieredCacheRequest {
    /** Identifier. */
    zoneId: string;
}
export type RegionalTieredCacheGetResponseId = "tc_regional";
export type RegionalTieredCacheGetResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRegionalTieredCacheResponse {
    /** The identifier of the caching setting. */
    id: RegionalTieredCacheGetResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Regional Tiered Cache zone setting. */
    value: RegionalTieredCacheGetResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export interface GetSmartTieredCacheRequest {
    /** Identifier. */
    zoneId: string;
}
export type SmartTieredCacheGetResponseId = "tiered_cache_smart_topology_enable";
export type SmartTieredCacheGetResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSmartTieredCacheResponse {
    /** The identifier of the caching setting. */
    id: SmartTieredCacheGetResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Smart Tiered Cache zone setting. */
    value: SmartTieredCacheGetResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export interface GetVariantRequest {
    /** Identifier. */
    zoneId: string;
}
export type VariantsGetResponseId = "variants";
export type VariantsGetResponseValueAvifList = Array<string>;
export type VariantsGetResponseValueBmpList = Array<string>;
export type VariantsGetResponseValueGifList = Array<string>;
export type VariantsGetResponseValueJp2List = Array<string>;
export type VariantsGetResponseValueJpegList = Array<string>;
export type VariantsGetResponseValueJpgList = Array<string>;
export type VariantsGetResponseValueJpg2List = Array<string>;
export type VariantsGetResponseValuePngList = Array<string>;
export type VariantsGetResponseValueTifList = Array<string>;
export type VariantsGetResponseValueTiffList = Array<string>;
export type VariantsGetResponseValueWebpList = Array<string>;
export interface VariantsGetResponseValue {
    /** List of strings with the MIME types of all the variants that should be served for avif. */
    avif?: VariantsGetResponseValueAvifList | null;
    /** List of strings with the MIME types of all the variants that should be served for bmp. */
    bmp?: VariantsGetResponseValueBmpList | null;
    /** List of strings with the MIME types of all the variants that should be served for gif. */
    gif?: VariantsGetResponseValueGifList | null;
    /** List of strings with the MIME types of all the variants that should be served for jp2. */
    jp2?: VariantsGetResponseValueJp2List | null;
    /** List of strings with the MIME types of all the variants that should be served for jpeg. */
    jpeg?: VariantsGetResponseValueJpegList | null;
    /** List of strings with the MIME types of all the variants that should be served for jpg. */
    jpg?: VariantsGetResponseValueJpgList | null;
    /** List of strings with the MIME types of all the variants that should be served for jpg2. */
    jpg2?: VariantsGetResponseValueJpg2List | null;
    /** List of strings with the MIME types of all the variants that should be served for png. */
    png?: VariantsGetResponseValuePngList | null;
    /** List of strings with the MIME types of all the variants that should be served for tif. */
    tif?: VariantsGetResponseValueTifList | null;
    /** List of strings with the MIME types of all the variants that should be served for tiff. */
    tiff?: VariantsGetResponseValueTiffList | null;
    /** List of strings with the MIME types of all the variants that should be served for webp. */
    webp?: VariantsGetResponseValueWebpList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetVariantResponse {
    /** The identifier of the caching setting. */
    id: VariantsGetResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the zone setting. */
    value: VariantsGetResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export type InvalidateRequestTagsList = Array<string>;
export type InvalidateRequestHostsList = Array<string>;
export type InvalidateRequestPrefixesList = Array<string>;
export type InvalidateRequestFilesCachePurgeSingleFileList = Array<string>;
export type InvalidateRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap = {
    [key: string]: string | undefined;
};
export interface InvalidateRequestFilesCachePurgeSingleFileWithURLAndHeadersItem {
    /** Request headers and the values the content was cached with. */
    headers?: InvalidateRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap;
    /** Full URL of the content. */
    url?: string;
}
export type InvalidateRequestFilesCachePurgeSingleFileWithURLAndHeadersList = Array<InvalidateRequestFilesCachePurgeSingleFileWithURLAndHeadersItem>;
export type InvalidateRequestFiles = InvalidateRequestFilesCachePurgeSingleFileList | InvalidateRequestFilesCachePurgeSingleFileWithURLAndHeadersList;
export interface InvalidateRequest {
    zoneId: string;
    /** Cache tags. Targets all content whose `Cache-Tag` response header contains at least one of these tags. See [Purge cache by cache-tags](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-tags/). */
    tags?: InvalidateRequestTagsList;
    /** Hostnames, such as `www.example.com`. Targets all content cached for these hostnames. See [Purge cache by hostname](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-hostname/). */
    hosts?: InvalidateRequestHostsList;
    /** URL prefixes, each a hostname followed by a path, such as `www.example.com/blog/`. Targets all content whose URL starts with one of these prefixes. Do not include a scheme, query string, or fragment. See [Purge cache by prefix](https://developers.cloudflare.com/cache/how-to/purge-cache/purge_by_prefix/). */
    prefixes?: InvalidateRequestPrefixesList;
    /** Set to `true` to target all cached content in the zone, or in the environment for the environment endpoints. Must be the only field in the request. See [Purge everything](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-everything/). */
    purgeEverything?: boolean;
    /** Full URLs, such as `https://www.example.com/css/styles.css`. Targets the content cached for each URL. If your cache key includes request headers, send objects with `url` and `headers` instead. See [Purge by single-file](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-single-file/). */
    files?: InvalidateRequestFiles;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface InvalidateResponse {
    id: string;
}
export type InvalidateEnvironmentRequestTagsList = Array<string>;
export type InvalidateEnvironmentRequestHostsList = Array<string>;
export type InvalidateEnvironmentRequestPrefixesList = Array<string>;
export type InvalidateEnvironmentRequestFilesCachePurgeSingleFileList = Array<string>;
export type InvalidateEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap = {
    [key: string]: string | undefined;
};
export interface InvalidateEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItem {
    /** Request headers and the values the content was cached with. */
    headers?: InvalidateEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap;
    /** Full URL of the content. */
    url?: string;
}
export type InvalidateEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersList = Array<InvalidateEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItem>;
export type InvalidateEnvironmentRequestFiles = InvalidateEnvironmentRequestFilesCachePurgeSingleFileList | InvalidateEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersList;
export interface InvalidateEnvironmentRequest {
    zoneId: string;
    environmentId: string;
    /** Cache tags. Targets all content whose `Cache-Tag` response header contains at least one of these tags. See [Purge cache by cache-tags](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-tags/). */
    tags?: InvalidateEnvironmentRequestTagsList;
    /** Hostnames, such as `www.example.com`. Targets all content cached for these hostnames. See [Purge cache by hostname](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-hostname/). */
    hosts?: InvalidateEnvironmentRequestHostsList;
    /** URL prefixes, each a hostname followed by a path, such as `www.example.com/blog/`. Targets all content whose URL starts with one of these prefixes. Do not include a scheme, query string, or fragment. See [Purge cache by prefix](https://developers.cloudflare.com/cache/how-to/purge-cache/purge_by_prefix/). */
    prefixes?: InvalidateEnvironmentRequestPrefixesList;
    /** Set to `true` to target all cached content in the zone, or in the environment for the environment endpoints. Must be the only field in the request. See [Purge everything](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-everything/). */
    purgeEverything?: boolean;
    /** Full URLs, such as `https://www.example.com/css/styles.css`. Targets the content cached for each URL. If your cache key includes request headers, send objects with `url` and `headers` instead. See [Purge by single-file](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-single-file/). */
    files?: InvalidateEnvironmentRequestFiles;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface InvalidateEnvironmentResponse {
    id: string;
}
export interface ListOriginCloudRegionsRequest {
    /** Identifier. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
}
export type OriginCloudRegionsListResultItemVendor = "aws" | "azure" | "gcp" | "oci";
export interface OriginCloudRegionsListResultItem {
    /** The origin IP address (IPv4 or IPv6). Normalized to canonical form (RFC 5952 for IPv6). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsListResultItemVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export type OriginCloudRegionsListResultList = Array<OriginCloudRegionsListResultItem>;
export interface ListOriginCloudRegionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OriginCloudRegionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface OriginCloudRegionsBulkDeleteV1Request {
    /** Identifier. */
    zoneId: string;
}
export type OriginCloudRegionsBulkDeleteV1ResponseId = "origin_public_cloud_region";
export interface OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem {
    /** The origin IP address for this item. */
    originIp: string;
    /** Error message explaining why the item failed. Present only on failed items. */
    error?: string | null;
    /** Cloud vendor region identifier. Present on succeeded items for patch operations. */
    region?: string | null;
    /** Cloud vendor identifier. Present on succeeded items for patch operations. */
    vendor?: string | null;
}
export type OriginCloudRegionsBulkDeleteV1ResponseValueFailedList = Array<OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem>;
export type OriginCloudRegionsBulkDeleteV1ResponseValueSucceededItem = OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem;
export type OriginCloudRegionsBulkDeleteV1ResponseValueSucceededList = Array<OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem>;
export interface OriginCloudRegionsBulkDeleteV1ResponseValue {
    /** Items that could not be applied, with error details. */
    failed: OriginCloudRegionsBulkDeleteV1ResponseValueFailedList;
    /** Items that were successfully applied. */
    succeeded: OriginCloudRegionsBulkDeleteV1ResponseValueSucceededList;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsBulkDeleteV1Response {
    id: OriginCloudRegionsBulkDeleteV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    value: OriginCloudRegionsBulkDeleteV1ResponseValue;
    /** Time the mapping set was last modified. Null when no items were successfully applied. */
    modifiedOn?: string | null;
}
export type OriginCloudRegionsBulkEditV1RequestBodyItemVendor = "aws" | "azure" | "gcp" | "oci";
export interface OriginCloudRegionsBulkEditV1RequestBodyItem {
    /** Origin IP address (IPv4 or IPv6). Normalized to canonical form before storage (RFC 5952 for IPv6). */
    ip: string;
    /** Cloud vendor region identifier. Must be a valid region for the specified vendor as returned by the supported_regions endpoint. */
    region: string;
    /** Cloud vendor hosting the origin. Must be one of the supported vendors. */
    vendor: OriginCloudRegionsBulkEditV1RequestBodyItemVendor | (string & {});
}
export type OriginCloudRegionsBulkEditV1RequestBodyList = Array<OriginCloudRegionsBulkEditV1RequestBodyItem>;
export interface OriginCloudRegionsBulkEditV1Request {
    /** Identifier. */
    zoneId: string;
    body: OriginCloudRegionsBulkEditV1RequestBodyList;
}
export type OriginCloudRegionsBulkEditV1ResponseId = "origin_public_cloud_region";
export type OriginCloudRegionsBulkEditV1ResponseValueFailedItem = OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem;
export type OriginCloudRegionsBulkEditV1ResponseValueFailedList = Array<OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem>;
export type OriginCloudRegionsBulkEditV1ResponseValueSucceededItem = OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem;
export type OriginCloudRegionsBulkEditV1ResponseValueSucceededList = Array<OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem>;
export interface OriginCloudRegionsBulkEditV1ResponseValue {
    /** Items that could not be applied, with error details. */
    failed: OriginCloudRegionsBulkEditV1ResponseValueFailedList;
    /** Items that were successfully applied. */
    succeeded: OriginCloudRegionsBulkEditV1ResponseValueSucceededList;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsBulkEditV1Response {
    id: OriginCloudRegionsBulkEditV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    value: OriginCloudRegionsBulkEditV1ResponseValue;
    /** Time the mapping set was last modified. Null when no items were successfully applied. */
    modifiedOn?: string | null;
}
export type OriginCloudRegionsCreateV1RequestVendor = "aws" | "azure" | "gcp" | "oci";
export interface OriginCloudRegionsCreateV1Request {
    /** Identifier. */
    zoneId: string;
    /** Origin IP address (IPv4 or IPv6). Normalized to canonical form before storage (RFC 5952 for IPv6). */
    ip: string;
    /** Cloud vendor region identifier. Must be a valid region for the specified vendor as returned by the supported_regions endpoint. */
    region: string;
    /** Cloud vendor hosting the origin. Must be one of the supported vendors. */
    vendor: OriginCloudRegionsCreateV1RequestVendor | (string & {});
}
export type OriginCloudRegionsCreateV1ResponseId = "origin_public_cloud_region";
export type OriginCloudRegionsCreateV1ResponseValueVendor = "aws" | "azure" | "gcp" | "oci";
export interface OriginCloudRegionsCreateV1ResponseValue {
    /** The origin IP address (IPv4 or IPv6, canonicalized). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsCreateV1ResponseValueVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsCreateV1Response {
    id: OriginCloudRegionsCreateV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    /** A single origin IP-to-cloud-region mapping. */
    value: OriginCloudRegionsCreateV1ResponseValue;
    /** Time the mapping was last modified. */
    modifiedOn?: string | null;
}
export interface OriginCloudRegionsDeleteV1Request {
    /** Identifier. */
    zoneId: string;
    originIp: string;
}
export type OriginCloudRegionsDeleteV1ResponseId = "origin_public_cloud_region";
export type OriginCloudRegionsDeleteV1ResponseValueVendor = "aws" | "azure" | "gcp" | "oci";
export interface OriginCloudRegionsDeleteV1ResponseValue {
    /** The origin IP address (IPv4 or IPv6, canonicalized). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsDeleteV1ResponseValueVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsDeleteV1Response {
    id: OriginCloudRegionsDeleteV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    /** A single origin IP-to-cloud-region mapping. */
    value: OriginCloudRegionsDeleteV1ResponseValue;
    /** Time the mapping was last modified. */
    modifiedOn?: string | null;
}
export type OriginCloudRegionsEditV1RequestVendor = "aws" | "azure" | "gcp" | "oci";
export interface OriginCloudRegionsEditV1Request {
    /** Identifier. */
    zoneId: string;
    /** Origin IP address (IPv4 or IPv6). Normalized to canonical form before storage (RFC 5952 for IPv6). */
    ip: string;
    /** Cloud vendor region identifier. Must be a valid region for the specified vendor as returned by the supported_regions endpoint. */
    region: string;
    /** Cloud vendor hosting the origin. Must be one of the supported vendors. */
    vendor: OriginCloudRegionsEditV1RequestVendor | (string & {});
}
export type OriginCloudRegionsEditV1ResponseId = "origin_public_cloud_region";
export type OriginCloudRegionsEditV1ResponseValueItemVendor = "aws" | "azure" | "gcp" | "oci";
export interface OriginCloudRegionsEditV1ResponseValueItem {
    /** The origin IP address (IPv4 or IPv6, canonicalized). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsEditV1ResponseValueItemVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export type OriginCloudRegionsEditV1ResponseValueList = Array<OriginCloudRegionsEditV1ResponseValueItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsEditV1Response {
    id: OriginCloudRegionsEditV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    value: OriginCloudRegionsEditV1ResponseValueList;
    /** Time the mapping set was last modified. Null when no mappings exist. */
    modifiedOn?: string | null;
}
export interface OriginCloudRegionsGetV1Request {
    /** Identifier. */
    zoneId: string;
    originIp: string;
}
export type OriginCloudRegionsGetV1ResponseId = "origin_public_cloud_region";
export type OriginCloudRegionsGetV1ResponseValueVendor = "aws" | "azure" | "gcp" | "oci";
export interface OriginCloudRegionsGetV1ResponseValue {
    /** The origin IP address (IPv4 or IPv6, canonicalized). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsGetV1ResponseValueVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsGetV1Response {
    id: OriginCloudRegionsGetV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    /** A single origin IP-to-cloud-region mapping. */
    value: OriginCloudRegionsGetV1ResponseValue;
    /** Time the mapping was last modified. */
    modifiedOn?: string | null;
}
export interface OriginCloudRegionsListV1Request {
    /** Identifier. */
    zoneId: string;
}
export type OriginCloudRegionsListV1ResponseId = "origin_public_cloud_region";
export type OriginCloudRegionsListV1ResponseValueItemVendor = "aws" | "azure" | "gcp" | "oci";
export interface OriginCloudRegionsListV1ResponseValueItem {
    /** The origin IP address (IPv4 or IPv6, canonicalized). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsListV1ResponseValueItemVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export type OriginCloudRegionsListV1ResponseValueList = Array<OriginCloudRegionsListV1ResponseValueItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsListV1Response {
    id: OriginCloudRegionsListV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    value: OriginCloudRegionsListV1ResponseValueList;
    /** Time the mapping set was last modified. Null when no mappings exist. */
    modifiedOn?: string | null;
}
export interface OriginCloudRegionsSupportedRegionsV1Request {
    /** Identifier. */
    zoneId: string;
}
export type OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueItemUpperTierColosList = Array<string>;
export interface OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueItem {
    /** Cloud vendor region identifier. */
    name: string;
    /** Cloudflare Tiered Cache upper-tier colocation codes co-located with this cloud region. Requests from zones with a matching origin mapping will be routed through these colos. */
    upperTierColos: OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueItemUpperTierColosList;
}
export type OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueList = Array<OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueItem>;
export type OriginCloudRegionsSupportedRegionsV1ResponseVendorsMap = {
    [key: string]: OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueList | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsSupportedRegionsV1Response {
    /** Whether Cloudflare airport codes (IATA colo identifiers) were successfully resolved for the `upper_tier_colos` field on each region. When `false`, the `upper_tier_colos` arrays may be empty or incomplete. */
    obtainedCodes: boolean;
    /** Map of vendor name to list of supported regions. */
    vendors: OriginCloudRegionsSupportedRegionsV1ResponseVendorsMap;
}
export type CacheReserveEditRequestValue = "on" | "off";
export interface PatchCacheReserveRequest {
    /** Identifier. */
    zoneId: string;
    /** Value of the Cache Reserve zone setting. */
    value: CacheReserveEditRequestValue | (string & {});
}
export type CacheReserveEditResponseId = "cache_reserve";
export type CacheReserveEditResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCacheReserveResponse {
    /** The identifier of the caching setting. */
    id: CacheReserveEditResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Cache Reserve zone setting. */
    value: CacheReserveEditResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export type RegionalTieredCacheEditRequestValue = "on" | "off";
export interface PatchRegionalTieredCacheRequest {
    /** Identifier. */
    zoneId: string;
    /** Value of the Regional Tiered Cache zone setting. */
    value: RegionalTieredCacheEditRequestValue | (string & {});
}
export type RegionalTieredCacheEditResponseId = "tc_regional";
export type RegionalTieredCacheEditResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchRegionalTieredCacheResponse {
    /** The identifier of the caching setting. */
    id: RegionalTieredCacheEditResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Regional Tiered Cache zone setting. */
    value: RegionalTieredCacheEditResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SmartTieredCacheEditRequestValue = "on" | "off";
export interface PatchSmartTieredCacheRequest {
    /** Identifier. */
    zoneId: string;
    /** Enable or disable the Smart Tiered Cache. */
    value: SmartTieredCacheEditRequestValue | (string & {});
}
export type SmartTieredCacheEditResponseId = "tiered_cache_smart_topology_enable";
export type SmartTieredCacheEditResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSmartTieredCacheResponse {
    /** The identifier of the caching setting. */
    id: SmartTieredCacheEditResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Smart Tiered Cache zone setting. */
    value: SmartTieredCacheEditResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export type VariantsEditRequestValueAvifList = Array<string>;
export type VariantsEditRequestValueBmpList = Array<string>;
export type VariantsEditRequestValueGifList = Array<string>;
export type VariantsEditRequestValueJp2List = Array<string>;
export type VariantsEditRequestValueJpegList = Array<string>;
export type VariantsEditRequestValueJpgList = Array<string>;
export type VariantsEditRequestValueJpg2List = Array<string>;
export type VariantsEditRequestValuePngList = Array<string>;
export type VariantsEditRequestValueTifList = Array<string>;
export type VariantsEditRequestValueTiffList = Array<string>;
export type VariantsEditRequestValueWebpList = Array<string>;
export interface VariantsEditRequestValue {
    /** List of strings with the MIME types of all the variants that should be served for avif. */
    avif?: VariantsEditRequestValueAvifList;
    /** List of strings with the MIME types of all the variants that should be served for bmp. */
    bmp?: VariantsEditRequestValueBmpList;
    /** List of strings with the MIME types of all the variants that should be served for gif. */
    gif?: VariantsEditRequestValueGifList;
    /** List of strings with the MIME types of all the variants that should be served for jp2. */
    jp2?: VariantsEditRequestValueJp2List;
    /** List of strings with the MIME types of all the variants that should be served for jpeg. */
    jpeg?: VariantsEditRequestValueJpegList;
    /** List of strings with the MIME types of all the variants that should be served for jpg. */
    jpg?: VariantsEditRequestValueJpgList;
    /** List of strings with the MIME types of all the variants that should be served for jpg2. */
    jpg2?: VariantsEditRequestValueJpg2List;
    /** List of strings with the MIME types of all the variants that should be served for png. */
    png?: VariantsEditRequestValuePngList;
    /** List of strings with the MIME types of all the variants that should be served for tif. */
    tif?: VariantsEditRequestValueTifList;
    /** List of strings with the MIME types of all the variants that should be served for tiff. */
    tiff?: VariantsEditRequestValueTiffList;
    /** List of strings with the MIME types of all the variants that should be served for webp. */
    webp?: VariantsEditRequestValueWebpList;
}
export interface PatchVariantRequest {
    /** Identifier. */
    zoneId: string;
    /** Value of the zone setting. */
    value: VariantsEditRequestValue;
}
export type VariantsEditResponseId = "variants";
export type VariantsEditResponseValueAvifList = Array<string>;
export type VariantsEditResponseValueBmpList = Array<string>;
export type VariantsEditResponseValueGifList = Array<string>;
export type VariantsEditResponseValueJp2List = Array<string>;
export type VariantsEditResponseValueJpegList = Array<string>;
export type VariantsEditResponseValueJpgList = Array<string>;
export type VariantsEditResponseValueJpg2List = Array<string>;
export type VariantsEditResponseValuePngList = Array<string>;
export type VariantsEditResponseValueTifList = Array<string>;
export type VariantsEditResponseValueTiffList = Array<string>;
export type VariantsEditResponseValueWebpList = Array<string>;
export interface VariantsEditResponseValue {
    /** List of strings with the MIME types of all the variants that should be served for avif. */
    avif?: VariantsEditResponseValueAvifList | null;
    /** List of strings with the MIME types of all the variants that should be served for bmp. */
    bmp?: VariantsEditResponseValueBmpList | null;
    /** List of strings with the MIME types of all the variants that should be served for gif. */
    gif?: VariantsEditResponseValueGifList | null;
    /** List of strings with the MIME types of all the variants that should be served for jp2. */
    jp2?: VariantsEditResponseValueJp2List | null;
    /** List of strings with the MIME types of all the variants that should be served for jpeg. */
    jpeg?: VariantsEditResponseValueJpegList | null;
    /** List of strings with the MIME types of all the variants that should be served for jpg. */
    jpg?: VariantsEditResponseValueJpgList | null;
    /** List of strings with the MIME types of all the variants that should be served for jpg2. */
    jpg2?: VariantsEditResponseValueJpg2List | null;
    /** List of strings with the MIME types of all the variants that should be served for png. */
    png?: VariantsEditResponseValuePngList | null;
    /** List of strings with the MIME types of all the variants that should be served for tif. */
    tif?: VariantsEditResponseValueTifList | null;
    /** List of strings with the MIME types of all the variants that should be served for tiff. */
    tiff?: VariantsEditResponseValueTiffList | null;
    /** List of strings with the MIME types of all the variants that should be served for webp. */
    webp?: VariantsEditResponseValueWebpList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchVariantResponse {
    /** The identifier of the caching setting. */
    id: VariantsEditResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the zone setting. */
    value: VariantsEditResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export type PurgeRequestTagsList = Array<string>;
export type PurgeRequestHostsList = Array<string>;
export type PurgeRequestPrefixesList = Array<string>;
export type PurgeRequestFilesCachePurgeSingleFileList = Array<string>;
export type PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap = {
    [key: string]: string | undefined;
};
export interface PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersItem {
    /** Request headers and the values the content was cached with. */
    headers?: PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap;
    /** Full URL of the content. */
    url?: string;
}
export type PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersList = Array<PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersItem>;
export type PurgeRequestFiles = PurgeRequestFilesCachePurgeSingleFileList | PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersList;
export interface PurgeCacheRequest {
    zoneId: string;
    /** Cache tags. Targets all content whose `Cache-Tag` response header contains at least one of these tags. See [Purge cache by cache-tags](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-tags/). */
    tags?: PurgeRequestTagsList;
    /** Hostnames, such as `www.example.com`. Targets all content cached for these hostnames. See [Purge cache by hostname](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-hostname/). */
    hosts?: PurgeRequestHostsList;
    /** URL prefixes, each a hostname followed by a path, such as `www.example.com/blog/`. Targets all content whose URL starts with one of these prefixes. Do not include a scheme, query string, or fragment. See [Purge cache by prefix](https://developers.cloudflare.com/cache/how-to/purge-cache/purge_by_prefix/). */
    prefixes?: PurgeRequestPrefixesList;
    /** Set to `true` to target all cached content in the zone, or in the environment for the environment endpoints. Must be the only field in the request. See [Purge everything](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-everything/). */
    purgeEverything?: boolean;
    /** Full URLs, such as `https://www.example.com/css/styles.css`. Targets the content cached for each URL. If your cache key includes request headers, send objects with `url` and `headers` instead. See [Purge by single-file](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-single-file/). */
    files?: PurgeRequestFiles;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PurgeCacheResponse {
    id: string;
}
export type PurgeEnvironmentRequestTagsList = Array<string>;
export type PurgeEnvironmentRequestHostsList = Array<string>;
export type PurgeEnvironmentRequestPrefixesList = Array<string>;
export type PurgeEnvironmentRequestFilesCachePurgeSingleFileList = Array<string>;
export type PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap = {
    [key: string]: string | undefined;
};
export interface PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItem {
    /** Request headers and the values the content was cached with. */
    headers?: PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap;
    /** Full URL of the content. */
    url?: string;
}
export type PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersList = Array<PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItem>;
export type PurgeEnvironmentRequestFiles = PurgeEnvironmentRequestFilesCachePurgeSingleFileList | PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersList;
export interface PurgeEnvironmentCacheRequest {
    zoneId: string;
    environmentId: string;
    /** Cache tags. Targets all content whose `Cache-Tag` response header contains at least one of these tags. See [Purge cache by cache-tags](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-tags/). */
    tags?: PurgeEnvironmentRequestTagsList;
    /** Hostnames, such as `www.example.com`. Targets all content cached for these hostnames. See [Purge cache by hostname](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-hostname/). */
    hosts?: PurgeEnvironmentRequestHostsList;
    /** URL prefixes, each a hostname followed by a path, such as `www.example.com/blog/`. Targets all content whose URL starts with one of these prefixes. Do not include a scheme, query string, or fragment. See [Purge cache by prefix](https://developers.cloudflare.com/cache/how-to/purge-cache/purge_by_prefix/). */
    prefixes?: PurgeEnvironmentRequestPrefixesList;
    /** Set to `true` to target all cached content in the zone, or in the environment for the environment endpoints. Must be the only field in the request. See [Purge everything](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-everything/). */
    purgeEverything?: boolean;
    /** Full URLs, such as `https://www.example.com/css/styles.css`. Targets the content cached for each URL. If your cache key includes request headers, send objects with `url` and `headers` instead. See [Purge by single-file](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-single-file/). */
    files?: PurgeEnvironmentRequestFiles;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PurgeEnvironmentCacheResponse {
    id: string;
}
export type OriginCloudRegionsUpdateRequestVendor = "aws" | "azure" | "gcp" | "oci";
export interface PutOriginCloudRegionRequest {
    /** Identifier. */
    zoneId: string;
    /** Cloud vendor region identifier. Must be a valid region for the specified vendor as returned by the supported_regions endpoint. */
    region: string;
    /** Cloud vendor hosting the origin. Must be one of the supported vendors. */
    vendor: OriginCloudRegionsUpdateRequestVendor | (string & {});
    originIP: string;
    /** Origin IP address (IPv4 or IPv6). For the single PUT endpoint (`PUT /origin/cloud_regions/{origin_ip}`), this field must match the path parameter or the request will be rejected with a 400 error. For the batch PUT endpoint, this field identifies which mapping to upsert. */
    originIp: string;
}
export type OriginCloudRegionsUpdateResponseVendor = "aws" | "azure" | "gcp" | "oci";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutOriginCloudRegionResponse {
    /** The origin IP address (IPv4 or IPv6). Normalized to canonical form (RFC 5952 for IPv6). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsUpdateResponseVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export interface StatusCacheReserveRequest {
    /** Identifier. */
    zoneId: string;
}
export type CacheReserveStatusResponseId = "cache_reserve_clear";
export type CacheReserveStatusResponseState = "In-progress" | "Completed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StatusCacheReserveResponse {
    /** ID of the zone setting. */
    id: CacheReserveStatusResponseId;
    /** The time that the latest Cache Reserve Clear operation started. */
    startTs: string;
    /** The current state of the Cache Reserve Clear operation. */
    state: CacheReserveStatusResponseState;
    /** The time that the latest Cache Reserve Clear operation completed. */
    endTs?: string | null;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export interface SupportedRegionsOriginCloudRegionRequest {
    /** Identifier. */
    zoneId: string;
}
export type OriginCloudRegionsSupportedRegionsResponseVendorsValueItemUpperTierColosList = Array<string>;
export interface OriginCloudRegionsSupportedRegionsResponseVendorsValueItem {
    /** Cloud vendor region identifier. */
    name: string;
    /** Cloudflare Tiered Cache upper-tier colocation codes co-located with this cloud region. Requests from zones with a matching origin mapping will be routed through these colos. */
    upperTierColos: OriginCloudRegionsSupportedRegionsResponseVendorsValueItemUpperTierColosList;
}
export type OriginCloudRegionsSupportedRegionsResponseVendorsValueList = Array<OriginCloudRegionsSupportedRegionsResponseVendorsValueItem>;
export type OriginCloudRegionsSupportedRegionsResponseVendorsMap = {
    [key: string]: OriginCloudRegionsSupportedRegionsResponseVendorsValueList | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SupportedRegionsOriginCloudRegionResponse {
    /** Whether Cloudflare airport codes (IATA colo identifiers) were successfully resolved for the `upper_tier_colos` field on each region. When `false`, the `upper_tier_colos` arrays may be empty or incomplete. */
    obtainedCodes: boolean;
    /** Map of vendor name to list of supported regions. */
    vendors: OriginCloudRegionsSupportedRegionsResponseVendorsMap;
}
export type BulkDeleteOriginCloudRegionsError = CloudflareOpError;
/** Removes up to 100 IP-to-cloud-region mappings in a single request. Each IP is validated independently -- successfully deleted items are returned in the `succeeded` array and IPs that could not be found or are invalid are returned in the `failed` array. */
export declare const bulkDeleteOriginCloudRegions: API.OperationMethod<BulkDeleteOriginCloudRegionsRequest, BulkDeleteOriginCloudRegionsResponse, BulkDeleteOriginCloudRegionsError, CloudflareOpContext>;
export type BulkPutOriginCloudRegionsError = CloudflareOpError;
/** Upserts up to 100 IP-to-cloud-region mappings in a single request. Items in the request body are created or replaced; mappings not included in the request body are preserved unchanged (this is a merge operation, not a full collection replacement). Each item is validated independently -- valid items are applied and invalid items are returned in the `failed` array. The vendor and region for every item are validated against the list from `GET /zones/{zone_id}/origin/cloud_regions/supported_regions`. */
export declare const bulkPutOriginCloudRegions: API.OperationMethod<BulkPutOriginCloudRegionsRequest, BulkPutOriginCloudRegionsResponse, BulkPutOriginCloudRegionsError, CloudflareOpContext>;
export type ClearCacheReserveError = CloudflareOpError;
/** You can use Cache Reserve Clear to clear your Cache Reserve, but you must first disable Cache Reserve. In most cases, this will be accomplished within 24 hours. You cannot re-enable Cache Reserve while this process is ongoing. Keep in mind that you cannot undo or cancel this operation. */
export declare const clearCacheReserve: API.OperationMethod<ClearCacheReserveRequest, ClearCacheReserveResponse, ClearCacheReserveError, CloudflareOpContext>;
export type CreateSmartTieredCacheError = CloudflareOpError;
/** Smart Tiered Cache dynamically selects the single closest upper tier for each of your website's origins with no configuration required, using our in-house performance and routing data. Cloudflare collects latency data for each request to an origin, and uses the latency data to determine how well any upper-tier data center is connected with an origin. As a result, Cloudflare can select the data center with the lowest latency to be the upper-tier for an origin. */
export declare const createSmartTieredCache: API.OperationMethod<CreateSmartTieredCacheRequest, CreateSmartTieredCacheResponse, CreateSmartTieredCacheError, CloudflareOpContext>;
export type DeleteOriginCloudRegionError = OriginCloudRegionNotFound | Forbidden | CloudflareOpError;
/** Removes the cloud region mapping for a single origin IP address. The IP path parameter is normalized before lookup. Returns the deleted IP on success. Returns 404 if no mapping exists for the specified IP. When the last mapping for the zone is removed the underlying rule record is also deleted. */
export declare const deleteOriginCloudRegion: API.OperationMethod<DeleteOriginCloudRegionRequest, DeleteOriginCloudRegionResponse, DeleteOriginCloudRegionError, CloudflareOpContext>;
export type DeleteSmartTieredCacheError = CloudflareOpError;
/** Smart Tiered Cache dynamically selects the single closest upper tier for each of your website's origins with no configuration required, using our in-house performance and routing data. Cloudflare collects latency data for each request to an origin, and uses the latency data to determine how well any upper-tier data center is connected with an origin. As a result, Cloudflare can select the data center with the lowest latency to be the upper-tier for an origin. */
export declare const deleteSmartTieredCache: API.OperationMethod<DeleteSmartTieredCacheRequest, DeleteSmartTieredCacheResponse, DeleteSmartTieredCacheError, CloudflareOpContext>;
export type DeleteVariantError = VariantsNotConfigured | Forbidden | CloudflareOpError;
/** Variant support enables caching variants of images with certain file extensions in addition to the original. This only applies when the origin server sends the 'Vary: Accept' response header. If the origin server sends 'Vary: Accept' but does not serve the variant requested, the response will not be cached. This will be indicated with BYPASS cache status in the response headers. */
export declare const deleteVariant: API.OperationMethod<DeleteVariantRequest, DeleteVariantResponse, DeleteVariantError, CloudflareOpContext>;
export type GetCacheReserveError = SettingUnavailableForPlan | Forbidden | CloudflareOpError;
/** Increase cache lifetimes by automatically storing all cacheable files into Cloudflare's persistent object storage buckets. Requires Cache Reserve subscription. Note: using Tiered Cache with Cache Reserve is highly recommended to reduce Reserve operations costs. See the [developer docs](https://developers.cloudflare.com/cache/about/cache-reserve) for more information. */
export declare const getCacheReserve: API.OperationMethod<GetCacheReserveRequest, GetCacheReserveResponse, GetCacheReserveError, CloudflareOpContext>;
export type GetOriginCloudRegionError = OriginCloudRegionNotFound | Forbidden | CloudflareOpError;
/** Returns the cloud region mapping for a single origin IP address. The IP path parameter is normalized before lookup (RFC 5952 for IPv6). Returns 404 if the zone has no mappings or if the specified IP has no mapping. */
export declare const getOriginCloudRegion: API.OperationMethod<GetOriginCloudRegionRequest, GetOriginCloudRegionResponse, GetOriginCloudRegionError, CloudflareOpContext>;
export type GetRegionalTieredCacheError = SettingUnavailableForPlan | Forbidden | Unauthorized | CloudflareOpError;
/** Instructs Cloudflare to check a regional hub data center on the way to your upper tier. This can help improve performance for smart and custom tiered cache topologies. */
export declare const getRegionalTieredCache: API.OperationMethod<GetRegionalTieredCacheRequest, GetRegionalTieredCacheResponse, GetRegionalTieredCacheError, CloudflareOpContext>;
export type GetSmartTieredCacheError = Forbidden | CloudflareOpError;
/** Smart Tiered Cache dynamically selects the single closest upper tier for each of your website's origins with no configuration required, using our in-house performance and routing data. Cloudflare collects latency data for each request to an origin, and uses the latency data to determine how well any upper-tier data center is connected with an origin. As a result, Cloudflare can select the data center with the lowest latency to be the upper-tier for an origin. */
export declare const getSmartTieredCache: API.OperationMethod<GetSmartTieredCacheRequest, GetSmartTieredCacheResponse, GetSmartTieredCacheError, CloudflareOpContext>;
export type GetVariantError = VariantsNotConfigured | Forbidden | CloudflareOpError;
/** Variant support enables caching variants of images with certain file extensions in addition to the original. This only applies when the origin server sends the 'Vary: Accept' response header. If the origin server sends 'Vary: Accept' but does not serve the variant requested, the response will not be cached. This will be indicated with BYPASS cache status in the response headers. */
export declare const getVariant: API.OperationMethod<GetVariantRequest, GetVariantResponse, GetVariantError, CloudflareOpContext>;
export type InvalidateError = CloudflareOpError;
/** Marks cached content as stale in every Cloudflare data center and cache tier, including Cache Reserve. The content stays in cache. The next request for it makes Cloudflare revalidate it with your origin, using the `ETag` and `Last-Modified` values it was cached with: - If your origin answers `304 Not Modified`, Cloudflare serves the cached copy without downloading it again, and `CF-Cache-Status` is `REVALIDATED`. - If your origin sends a full response, Cloudflare serves and caches the new content, and `CF-Cache-Status` is `EXPIRED`. With Tiered Cache, each tier revalidates with the tier above it, so a visitor can see `EXPIRED` even when your origin answered `304`. Until content is revalidated, your `stale-while-revalidate` and `stale-if-error` directives still apply, counted from the time you invalidated it. For example, if your origin fails during revalidation, Cloudflare can keep serving the stale copy for the `stale-if-error` window. */
export declare const invalidate: API.OperationMethod<InvalidateRequest, InvalidateResponse, InvalidateError, CloudflareOpContext>;
export type InvalidateEnvironmentError = CloudflareOpError;
/** Marks cached content as stale for one environment of the zone. Content cached for the zone's other environments, including production, is not affected. Otherwise this works like `POST /zones/{zone_id}/invalidate_cache`: the next request for invalidated content makes Cloudflare revalidate it with your origin, and the request body takes the same fields. Environments are part of [Version Management](https://developers.cloudflare.com/version-management/). To delete the content instead, use `POST /zones/{zone_id}/environments/{environment_id}/purge_cache`. Invalidating by URL (`files`) does not work for environments that select requests by IP address, country, ASN, or threat score, and fails with error `1136`. Use `tags`, `hosts`, `prefixes`, or `purge_everything` for those environments. */
export declare const invalidateEnvironment: API.OperationMethod<InvalidateEnvironmentRequest, InvalidateEnvironmentResponse, InvalidateEnvironmentError, CloudflareOpContext>;
export type ListOriginCloudRegionsError = Forbidden | CloudflareOpError;
/** Returns all IP-to-cloud-region mappings configured for the zone with pagination support. Each mapping tells Cloudflare which cloud vendor and region hosts the origin at that IP, enabling the edge to route via the nearest Tiered Cache upper-tier co-located with that cloud provider. Returns an empty array when no mappings exist. */
export declare const listOriginCloudRegions: API.PaginatedOperationMethod<ListOriginCloudRegionsRequest, ListOriginCloudRegionsResponse, ListOriginCloudRegionsError, CloudflareOpContext, OriginCloudRegionsListResultItem>;
export type OriginCloudRegionsBulkDeleteV1Error = CloudflareOpError;
/** Removes up to 100 IP-to-cloud-region mappings in a single request. Each IP is validated independently -- successfully deleted items are returned in the `succeeded` array and IPs that could not be found or are invalid are returned in the `failed` array. */
export declare const originCloudRegionsBulkDeleteV1: API.OperationMethod<OriginCloudRegionsBulkDeleteV1Request, OriginCloudRegionsBulkDeleteV1Response, OriginCloudRegionsBulkDeleteV1Error, CloudflareOpContext>;
export type OriginCloudRegionsBulkEditV1Error = CloudflareOpError;
/** Adds or updates up to 100 IP-to-cloud-region mappings in a single request. Each item is validated independently -- valid items are applied and invalid items are returned in the `failed` array. The vendor and region for every item are validated against the list from `GET /zones/{zone_id}/cache/origin_cloud_regions/supported_regions`. */
export declare const originCloudRegionsBulkEditV1: API.OperationMethod<OriginCloudRegionsBulkEditV1Request, OriginCloudRegionsBulkEditV1Response, OriginCloudRegionsBulkEditV1Error, CloudflareOpContext>;
export type OriginCloudRegionsCreateV1Error = CloudflareOpError;
/** Adds a single IP-to-cloud-region mapping for the zone. The IP must be a valid IPv4 or IPv6 address and is normalized to canonical form before storage (RFC 5952 for IPv6). Returns 400 (code 1145) if a mapping for that IP already exists -- use PATCH to update an existing entry. The vendor and region are validated against the list from `GET /zones/{zone_id}/cache/origin_cloud_regions/supported_regions`. */
export declare const originCloudRegionsCreateV1: API.OperationMethod<OriginCloudRegionsCreateV1Request, OriginCloudRegionsCreateV1Response, OriginCloudRegionsCreateV1Error, CloudflareOpContext>;
export type OriginCloudRegionsDeleteV1Error = CloudflareOpError;
/** Removes the cloud region mapping for a single origin IP address. The IP path parameter is normalized before lookup. Returns the deleted entry on success. Returns 404 (code 1163) if no mapping exists for the specified IP. When the last mapping for the zone is removed the underlying rule record is also deleted. */
export declare const originCloudRegionsDeleteV1: API.OperationMethod<OriginCloudRegionsDeleteV1Request, OriginCloudRegionsDeleteV1Response, OriginCloudRegionsDeleteV1Error, CloudflareOpContext>;
export type OriginCloudRegionsEditV1Error = CloudflareOpError;
/** Adds or updates a single IP-to-cloud-region mapping for the zone. Unlike POST, this operation is idempotent -- if a mapping for the IP already exists it is overwritten. Returns the complete updated list of all mappings for the zone. Returns 403 (code 1164) when the zone has reached the limit of 3,500 IP mappings. */
export declare const originCloudRegionsEditV1: API.OperationMethod<OriginCloudRegionsEditV1Request, OriginCloudRegionsEditV1Response, OriginCloudRegionsEditV1Error, CloudflareOpContext>;
export type OriginCloudRegionsGetV1Error = CloudflareOpError;
/** Returns the cloud region mapping for a single origin IP address. The IP path parameter is normalized before lookup (RFC 5952 for IPv6). Returns 404 (code 1142) if the zone has no mappings or if the specified IP has no mapping. */
export declare const originCloudRegionsGetV1: API.OperationMethod<OriginCloudRegionsGetV1Request, OriginCloudRegionsGetV1Response, OriginCloudRegionsGetV1Error, CloudflareOpContext>;
export type OriginCloudRegionsListV1Error = CloudflareOpError;
/** Returns all IP-to-cloud-region mappings configured for the zone. Each mapping tells Cloudflare which cloud vendor and region hosts the origin at that IP, enabling the edge to route via the nearest Tiered Cache upper-tier co-located with that cloud provider. Returns an empty array when no mappings exist. */
export declare const originCloudRegionsListV1: API.OperationMethod<OriginCloudRegionsListV1Request, OriginCloudRegionsListV1Response, OriginCloudRegionsListV1Error, CloudflareOpContext>;
export type OriginCloudRegionsSupportedRegionsV1Error = CloudflareOpError;
/** Returns the cloud vendors and regions that are valid values for origin cloud region mappings. Each region includes the Tiered Cache upper-tier colocation codes that will be used for cache routing when a mapping targeting that region is active. Requires the zone to have Tiered Cache enabled. */
export declare const originCloudRegionsSupportedRegionsV1: API.OperationMethod<OriginCloudRegionsSupportedRegionsV1Request, OriginCloudRegionsSupportedRegionsV1Response, OriginCloudRegionsSupportedRegionsV1Error, CloudflareOpContext>;
export type PatchCacheReserveError = SettingUnavailableForPlan | Forbidden | CloudflareOpError;
/** Increase cache lifetimes by automatically storing all cacheable files into Cloudflare's persistent object storage buckets. Requires Cache Reserve subscription. Note: using Tiered Cache with Cache Reserve is highly recommended to reduce Reserve operations costs. See the [developer docs](https://developers.cloudflare.com/cache/about/cache-reserve) for more information. */
export declare const patchCacheReserve: API.OperationMethod<PatchCacheReserveRequest, PatchCacheReserveResponse, PatchCacheReserveError, CloudflareOpContext>;
export type PatchRegionalTieredCacheError = SettingUnavailableForPlan | Forbidden | CloudflareOpError;
/** Instructs Cloudflare to check a regional hub data center on the way to your upper tier. This can help improve performance for smart and custom tiered cache topologies. */
export declare const patchRegionalTieredCache: API.OperationMethod<PatchRegionalTieredCacheRequest, PatchRegionalTieredCacheResponse, PatchRegionalTieredCacheError, CloudflareOpContext>;
export type PatchSmartTieredCacheError = Forbidden | CloudflareOpError;
/** Smart Tiered Cache dynamically selects the single closest upper tier for each of your website's origins with no configuration required, using our in-house performance and routing data. Cloudflare collects latency data for each request to an origin, and uses the latency data to determine how well any upper-tier data center is connected with an origin. As a result, Cloudflare can select the data center with the lowest latency to be the upper-tier for an origin. */
export declare const patchSmartTieredCache: API.OperationMethod<PatchSmartTieredCacheRequest, PatchSmartTieredCacheResponse, PatchSmartTieredCacheError, CloudflareOpContext>;
export type PatchVariantError = Forbidden | CloudflareOpError;
/** Variant support enables caching variants of images with certain file extensions in addition to the original. This only applies when the origin server sends the 'Vary: Accept' response header. If the origin server sends 'Vary: Accept' but does not serve the variant requested, the response will not be cached. This will be indicated with BYPASS cache status in the response headers. */
export declare const patchVariant: API.OperationMethod<PatchVariantRequest, PatchVariantResponse, PatchVariantError, CloudflareOpContext>;
export type PurgeCacheError = CloudflareOpError;
/** Deletes cached content in every Cloudflare data center and cache tier, including Cache Reserve. The next request for purged content is a cache `MISS`: Cloudflare fetches the full response from your origin and caches it again. Cloudflare does not serve purged content from cache again, even if your origin is unavailable. To keep content cached and have Cloudflare revalidate it with your origin instead, use `POST /zones/{zone_id}/invalidate_cache`. */
export declare const purgeCache: API.OperationMethod<PurgeCacheRequest, PurgeCacheResponse, PurgeCacheError, CloudflareOpContext>;
export type PurgeEnvironmentCacheError = CloudflareOpError;
/** Deletes cached content for one environment of the zone. Content cached for the zone's other environments, including production, is not affected. Otherwise this works like `POST /zones/{zone_id}/purge_cache`: the next request for purged content is a cache `MISS`, and the request body takes the same fields. Environments are part of [Version Management](https://developers.cloudflare.com/version-management/). To keep content cached and have Cloudflare revalidate it instead, use `POST /zones/{zone_id}/environments/{environment_id}/invalidate_cache`. Purging by URL (`files`) does not work for environments that select requests by IP address, country, ASN, or threat score, and fails with error `1136`. Use `tags`, `hosts`, `prefixes`, or `purge_everything` for those environments. */
export declare const purgeEnvironmentCache: API.OperationMethod<PurgeEnvironmentCacheRequest, PurgeEnvironmentCacheResponse, PurgeEnvironmentCacheError, CloudflareOpContext>;
export type PutOriginCloudRegionError = Forbidden | CloudflareOpError;
/** Creates a new IP-to-cloud-region mapping or replaces the existing mapping for the specified IP. PUT is idempotent -- calling it repeatedly with the same body produces the same result. The IP path parameter is normalized to canonical form (RFC 5952 for IPv6) before storage. The vendor and region are validated against the list from `GET /zones/{zone_id}/origin/cloud_regions/supported_regions`. Returns 400 if the `origin_ip` in the body does not match the URL path parameter. Returns 403 (code 1164) when the zone has reached the limit of 3,500 IP mappings. */
export declare const putOriginCloudRegion: API.OperationMethod<PutOriginCloudRegionRequest, PutOriginCloudRegionResponse, PutOriginCloudRegionError, CloudflareOpContext>;
export type StatusCacheReserveError = CloudflareOpError;
/** You can use Cache Reserve Clear to clear your Cache Reserve, but you must first disable Cache Reserve. In most cases, this will be accomplished within 24 hours. You cannot re-enable Cache Reserve while this process is ongoing. Keep in mind that you cannot undo or cancel this operation. */
export declare const statusCacheReserve: API.OperationMethod<StatusCacheReserveRequest, StatusCacheReserveResponse, StatusCacheReserveError, CloudflareOpContext>;
export type SupportedRegionsOriginCloudRegionError = CloudflareOpError;
/** Returns the cloud vendors and regions that are valid values for origin cloud region mappings. Each region includes the Tiered Cache upper-tier colocation codes that will be used for cache routing when a mapping targeting that region is active. Requires the zone to have Tiered Cache enabled. */
export declare const supportedRegionsOriginCloudRegion: API.OperationMethod<SupportedRegionsOriginCloudRegionRequest, SupportedRegionsOriginCloudRegionResponse, SupportedRegionsOriginCloudRegionError, CloudflareOpContext>;
//# sourceMappingURL=cache.d.ts.map