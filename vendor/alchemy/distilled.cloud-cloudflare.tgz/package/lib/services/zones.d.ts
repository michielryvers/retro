import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CustomNameserverSetNotFound_base: S.TaggedErrorClass<"CustomNameserverSetNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CustomNameserverSetNotFound extends /*@__PURE__*/ CustomNameserverSetNotFound_base {
}
declare const DomainNotRegistered_base: S.TaggedErrorClass<"DomainNotRegistered", {
    readonly code: any;
    readonly message: any;
}>;
export declare class DomainNotRegistered extends /*@__PURE__*/ DomainNotRegistered_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidDomain_base: S.TaggedErrorClass<"InvalidDomain", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidDomain extends /*@__PURE__*/ InvalidDomain_base {
}
declare const InvalidZoneIdentifier_base: S.TaggedErrorClass<"InvalidZoneIdentifier", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidZoneIdentifier extends /*@__PURE__*/ InvalidZoneIdentifier_base {
}
declare const SubdomainNotAllowed_base: S.TaggedErrorClass<"SubdomainNotAllowed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SubdomainNotAllowed extends /*@__PURE__*/ SubdomainNotAllowed_base {
}
declare const ZoneAlreadyExists_base: S.TaggedErrorClass<"ZoneAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ZoneAlreadyExists extends /*@__PURE__*/ ZoneAlreadyExists_base {
}
declare const ZoneCreationBlocked_base: S.TaggedErrorClass<"ZoneCreationBlocked", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ZoneCreationBlocked extends /*@__PURE__*/ ZoneCreationBlocked_base {
}
declare const ZoneHoldNotFound_base: S.TaggedErrorClass<"ZoneHoldNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ZoneHoldNotFound extends /*@__PURE__*/ ZoneHoldNotFound_base {
}
declare const ZoneHoldsRequireEnterprise_base: S.TaggedErrorClass<"ZoneHoldsRequireEnterprise", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ZoneHoldsRequireEnterprise extends /*@__PURE__*/ ZoneHoldsRequireEnterprise_base {
}
export interface EnvironmentsCreateRequestEnvironmentsItemPosition {
    after?: string;
    before?: string;
}
export interface EnvironmentsCreateRequestEnvironmentsItem {
    expression: string;
    lockedOnDeployment: boolean;
    name: string;
    position: EnvironmentsCreateRequestEnvironmentsItemPosition;
    ref: string;
    version: number;
    httpApplicationId?: string;
}
export type EnvironmentsCreateRequestEnvironmentsList = Array<EnvironmentsCreateRequestEnvironmentsItem>;
export interface CreateEnvironmentRequest {
    zoneId: string;
    environments: EnvironmentsCreateRequestEnvironmentsList;
}
export interface EnvironmentsCreateResponseEnvironmentsItemPosition {
    after?: string | null;
    before?: string | null;
}
export interface EnvironmentsCreateResponseEnvironmentsItem {
    expression: string;
    lockedOnDeployment: boolean;
    name: string;
    position: EnvironmentsCreateResponseEnvironmentsItemPosition;
    ref: string;
    version: number;
    httpApplicationId?: string | null;
}
export type EnvironmentsCreateResponseEnvironmentsList = Array<EnvironmentsCreateResponseEnvironmentsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateEnvironmentResponse {
    environments: EnvironmentsCreateResponseEnvironmentsList;
}
export interface CreateHoldRequest {
    /** Identifier. */
    zoneId: string;
    /** If provided, the zone hold will extend to block any subdomain of the given zone, as well as SSL4SaaS Custom Hostnames. For example, a zone hold on a zone with the hostname 'example.com' and include_subdomains=true will block 'example.com', 'staging.example.com', 'api.staging.example.com', etc. */
    includeSubdomains?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateHoldResponse {
    hold?: boolean | null;
    holdAfter?: string | null;
    includeSubdomains?: unknown | null;
}
export type SubscriptionsCreateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsCreateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsCreateRequestRatePlanSetsList = Array<string>;
export interface SubscriptionsCreateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsCreateRequestRatePlanId | (string & {});
    /** The currency applied to the rate plan subscription. */
    currency?: string;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean;
    /** The full name of the rate plan. */
    publicName?: string;
    /** The scope that this rate plan applies to. */
    scope?: string;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsCreateRequestRatePlanSetsList;
}
export interface CreateSubscriptionRequest {
    /** Identifier */
    zoneId: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsCreateRequestFrequency | (string & {});
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsCreateRequestRatePlan;
}
export type SubscriptionsCreateResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly" | "not-applicable";
export type SubscriptionsCreateResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsCreateResponseRatePlanSetsList = Array<string>;
export interface SubscriptionsCreateResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsCreateResponseRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsCreateResponseRatePlanSetsList | null;
}
export type SubscriptionsCreateResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSubscriptionResponse {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsCreateResponseFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsCreateResponseRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsCreateResponseState | null;
}
export interface CreateRequestAccount {
    /** Identifier */
    id?: string;
}
export type CreateRequestType = "full" | "partial" | "secondary" | "internal";
export interface CreateZoneRequest {
    account: CreateRequestAccount;
    /** The domain name. Per [RFC 1035](https://datatracker.ietf.org/doc/html/rfc1035#section-2.3.4) the overall zone name can be up to 253 characters, with each segment ("label") not exceeding 63 characters. */
    name: string;
    /** A full zone implies that DNS is hosted with Cloudflare. A partial zone is typically a partner-hosted zone or a CNAME setup. */
    type?: CreateRequestType | (string & {});
}
export interface CreateResponseAccount {
    /** Identifier */
    id?: string | null;
    /** The name of the account. */
    name?: string | null;
}
export interface CreateResponseMeta {
    /** The zone is only configured for CDN. */
    cdnOnly?: boolean | null;
    /** Number of Custom Certificates the zone can have. */
    customCertificateQuota?: number | null;
    /** The zone is only configured for DNS. */
    dnsOnly?: boolean | null;
    /** The zone is setup with Foundation DNS. */
    foundationDns?: boolean | null;
    /** Number of Page Rules a zone can have. */
    pageRuleQuota?: number | null;
    /** The zone has been flagged for phishing. */
    phishingDetected?: boolean | null;
    step?: number | null;
}
export type CreateResponseNameServersList = Array<string>;
export type CreateResponseOriginalNameServersList = Array<string>;
export interface CreateResponseOwner {
    /** Identifier */
    id?: string | null;
    /** Name of the owner. */
    name?: string | null;
    /** The type of owner. */
    type?: string | null;
}
export interface CreateResponsePlan {
    /** Identifier */
    id?: string | null;
    /** States if the subscription can be activated. */
    canSubscribe?: boolean | null;
    /** The denomination of the customer. */
    currency?: string | null;
    /** If this Zone is managed by another company. */
    externallyManaged?: boolean | null;
    /** How often the customer is billed. */
    frequency?: string | null;
    /** States if the subscription active. */
    isSubscribed?: boolean | null;
    /** If the legacy discount applies to this Zone. */
    legacyDiscount?: boolean | null;
    /** The legacy name of the plan. */
    legacyId?: string | null;
    /** Name of the owner. */
    name?: string | null;
    /** How much the customer is paying. */
    price?: number | null;
}
export type CreateResponsePermissionsList = Array<string>;
export type CreateResponseStatus = "initializing" | "pending" | "active" | "moved";
export interface CreateResponseTenant {
    /** Identifier */
    id?: string | null;
    /** The name of the Tenant account. */
    name?: string | null;
}
export interface CreateResponseTenantUnit {
    /** Identifier */
    id?: string | null;
}
export type CreateResponseType = "full" | "partial" | "secondary" | "internal";
export type CreateResponseVanityNameServersList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneResponse {
    /** Identifier */
    id: string;
    /** The account the zone belongs to. */
    account: CreateResponseAccount;
    /** The last time proof of ownership was detected and the zone was made active. */
    activatedOn: string;
    /** When the zone was created. */
    createdOn: string;
    /** The interval (in seconds) from when development mode expires (positive integer) or last expired (negative integer) for the domain. If development mode has never been enabled, this value is 0. */
    developmentMode: number;
    /** Metadata about the zone. */
    meta: CreateResponseMeta;
    /** When the zone was last modified. */
    modifiedOn: string;
    /** The domain name. Per [RFC 1035](https://datatracker.ietf.org/doc/html/rfc1035#section-2.3.4) the overall zone name can be up to 253 characters, with each segment ("label") not exceeding 63 characters. */
    name: string;
    /** The name servers Cloudflare assigns to a zone. */
    nameServers: CreateResponseNameServersList;
    /** DNS host at the time of switching to Cloudflare. */
    originalDnshost: string;
    /** Original name servers before moving to Cloudflare. */
    originalNameServers: CreateResponseOriginalNameServersList;
    /** Registrar for the domain at the time of switching to Cloudflare. */
    originalRegistrar: string;
    /** The owner of the zone. */
    owner: CreateResponseOwner;
    /** Please use the `/zones/{zone_id}/subscription` API to update a zone's plan. Changing this value will create/cancel associated subscriptions. To view available plans for this zone, see [Zone Plans](https://developers.cloudflare.com/api/resources/zones/subresources/plans/). */
    plan: CreateResponsePlan;
    /** Allows the customer to use a custom apex. *Tenants Only Configuration*. */
    cnameSuffix?: string | null;
    /** Indicates whether the zone is only using Cloudflare DNS services. A true value means the zone will not receive security or performance benefits. */
    paused?: boolean | null;
    /** This has been replaced by Account memberships. */
    permissions?: CreateResponsePermissionsList | null;
    /** The zone status on Cloudflare. */
    status?: CreateResponseStatus | null;
    /** The root organizational unit that this zone belongs to (such as a tenant or organization). */
    tenant?: CreateResponseTenant | null;
    /** The immediate parent organizational unit that this zone belongs to (such as under a tenant or sub-organization). */
    tenantUnit?: CreateResponseTenantUnit | null;
    /** A full zone implies that DNS is hosted with Cloudflare. A partial zone is typically a partner-hosted zone or a CNAME setup. */
    type?: CreateResponseType | null;
    /** An array of domains used for custom name servers. This is only available for Business and Enterprise plans. */
    vanityNameServers?: CreateResponseVanityNameServersList | null;
    /** Verification key for partial zone setup. */
    verificationKey?: string | null;
}
export interface DeleteEnvironmentRequest {
    zoneId: string;
    environmentId: string;
}
export type EnvironmentsDeleteResponseEnvironmentsItemPosition = EnvironmentsCreateResponseEnvironmentsItemPosition;
export type EnvironmentsDeleteResponseEnvironmentsItem = EnvironmentsCreateResponseEnvironmentsItem;
export type EnvironmentsDeleteResponseEnvironmentsList = Array<EnvironmentsCreateResponseEnvironmentsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteEnvironmentResponse {
    environments: EnvironmentsDeleteResponseEnvironmentsList;
}
export interface DeleteHoldRequest {
    /** Identifier. */
    zoneId: string;
    /** If `hold_after` is provided, the hold will be temporarily disabled, then automatically re-enabled by the system at the time specified in this RFC3339-formatted timestamp. Otherwise, the hold will be disabled indefinitely. `hold_after` cannot be provided for CDN-only zones. */
    holdAfter?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteHoldResponse {
    hold?: boolean | null;
    holdAfter?: string | null;
    includeSubdomains?: unknown | null;
}
export interface DeleteObservabilityTracingRuleRequest {
    /** Specify the zone ID. */
    zoneId: string;
}
export type DeleteObservabilityTracingRuleResponseRulesItemAction = "set_trace_settings";
export interface DeleteObservabilityTracingRuleResponseRulesItemActionParameters {
    /** The ratio of requests sampled for tracing, from 0 to 1. */
    samplingRatio: number;
}
export interface DeleteObservabilityTracingRuleResponseRulesItem {
    action: DeleteObservabilityTracingRuleResponseRulesItemAction;
    actionParameters: DeleteObservabilityTracingRuleResponseRulesItemActionParameters;
    description: string;
    enabled: boolean;
    /** A Rules language expression that selects requests. */
    expression: string;
}
export type DeleteObservabilityTracingRuleResponseRulesList = Array<DeleteObservabilityTracingRuleResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteObservabilityTracingRuleResponse {
    /** Trace rules in evaluation order. */
    rules: DeleteObservabilityTracingRuleResponseRulesList;
}
export interface DeleteObservabilityTracingSettingsRequest {
    /** Specify the zone ID. */
    zoneId: string;
}
export type DeleteObservabilityTracingSettingsResponseDestinationsList = Array<string>;
export type DeleteObservabilityTracingSettingsResponsePropagationPolicy = "accept" | "authenticated" | "reject";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteObservabilityTracingSettingsResponse {
    /** Up to 100 OpenTelemetry destination identifiers that receive traces. */
    destinations: DeleteObservabilityTracingSettingsResponseDestinationsList;
    /** Whether Cloudflare Traces is enabled for the zone. */
    enabled: boolean;
    /** Whether trace context is sent externally or across a zone boundary. */
    forwardContext: boolean;
    /** Whether traces are persisted in Cloudflare. */
    persist: boolean;
    /** When inbound trace context may be continued. Authenticated propagation is not supported yet. */
    propagationPolicy: DeleteObservabilityTracingSettingsResponsePropagationPolicy;
    /** The ratio of requests sampled for tracing, from 0 to 1. */
    samplingRatio: number;
}
export interface DeleteZoneRequest {
    /** Identifier */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneResponse {
    /** Identifier */
    id: string;
}
export interface EditNelRequestValue {
    /** Whether Network Error Logging is enabled for the zone. When enabled, browsers report network errors to Cloudflare's NEL endpoint. */
    enabled: boolean;
}
export interface EditNelRequest {
    /** Identifier of the zone. */
    zoneId: string;
    /** The NEL configuration value. */
    value: EditNelRequestValue;
}
export type EditNelResponseId = "nel";
export type EditNelResponseValue = EditNelRequestValue;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditNelResponse {
    /** Zone setting identifier. */
    id: EditNelResponseId;
    /** Whether the setting is editable. This is false when the zone's plan does not include NEL or the NEL product feature is not enabled. */
    editable: boolean;
    /** When the setting was last modified. A zero value (0001-01-01T00:00:00Z) indicates the setting has never been explicitly set and is using the default value. */
    modifiedOn: string;
    /** The NEL configuration value. */
    value: EditNelRequestValue;
}
export interface EditTransformationsAllowedOriginRequest {
    /** Identifier. */
    zoneId: string;
    /** Comma-separated list of allowed origin domains for image and video transformations. Use "*" to allow all origins (default). */
    value: string;
}
export type EditTransformationsAllowedOriginResponseId = "image_resizing_allowed_origins";
export type EditTransformationsAllowedOriginResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditTransformationsAllowedOriginResponse {
    /** ID of the zone setting. */
    id?: EditTransformationsAllowedOriginResponseId | null;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
    /** Comma-separated list of allowed origin domains for image and video transformations. Use "*" to allow all origins (default). */
    value?: EditTransformationsAllowedOriginResponseValue | null;
}
export type EditTransformationsC2paRequestValue = "off" | "on";
export interface EditTransformationsC2paRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether C2PA signing is enabled for image transformations. */
    value: EditTransformationsC2paRequestValue | (string & {});
}
export type EditTransformationsC2paResponseId = "image_resizing_c2pa";
export type EditTransformationsC2paResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditTransformationsC2paResponse {
    /** ID of the zone setting. */
    id?: EditTransformationsC2paResponseId | null;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
    /** Current value of the zone setting. */
    value?: EditTransformationsC2paResponseValue | null;
}
export interface GetCtAlertingRequest {
    /** Identifier. */
    zoneId: string;
}
export type CtAlertingGetResponseEmailsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCtAlertingResponse {
    /** Whether CT alerting is enabled for the zone. */
    enabled: boolean;
    /** Email addresses that receive CT alert notifications for the zone. A maximum of 100 addresses may be configured. Each address must be a valid RFC 5322 email address and must not contain a comma. */
    emails?: CtAlertingGetResponseEmailsList | null;
}
export interface GetCustomNameserverRequest {
    /** Identifier. */
    zoneId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetCustomNameserverResponse {
    /** Whether zone uses account-level custom nameservers. */
    enabled?: boolean | null;
    /** The number of the name server set to assign to the zone. */
    nsSet?: number | null;
}
export interface GetHoldRequest {
    /** Identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHoldResponse {
    hold?: boolean | null;
    holdAfter?: string | null;
    includeSubdomains?: unknown | null;
}
export interface GetNelRequest {
    /** Identifier of the zone. */
    zoneId: string;
}
export type GetNelResponseId = "nel";
export type GetNelResponseValue = EditNelRequestValue;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetNelResponse {
    /** Zone setting identifier. */
    id: GetNelResponseId;
    /** Whether the setting is editable. This is false when the zone's plan does not include NEL or the NEL product feature is not enabled. */
    editable: boolean;
    /** When the setting was last modified. A zero value (0001-01-01T00:00:00Z) indicates the setting has never been explicitly set and is using the default value. */
    modifiedOn: string;
    /** The NEL configuration value. */
    value: EditNelRequestValue;
}
export interface GetObservabilityTracingRuleRequest {
    /** Specify the zone ID. */
    zoneId: string;
}
export type GetObservabilityTracingRuleResponseRulesItemAction = "set_trace_settings";
export type GetObservabilityTracingRuleResponseRulesItemActionParameters = DeleteObservabilityTracingRuleResponseRulesItemActionParameters;
export interface GetObservabilityTracingRuleResponseRulesItem {
    action: GetObservabilityTracingRuleResponseRulesItemAction;
    actionParameters: DeleteObservabilityTracingRuleResponseRulesItemActionParameters;
    description: string;
    enabled: boolean;
    /** A Rules language expression that selects requests. */
    expression: string;
}
export type GetObservabilityTracingRuleResponseRulesList = Array<GetObservabilityTracingRuleResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetObservabilityTracingRuleResponse {
    /** Trace rules in evaluation order. */
    rules: GetObservabilityTracingRuleResponseRulesList;
}
export interface GetObservabilityTracingSettingsRequest {
    /** Specify the zone ID. */
    zoneId: string;
}
export type GetObservabilityTracingSettingsResponseDestinationsList = Array<string>;
export type GetObservabilityTracingSettingsResponsePropagationPolicy = "accept" | "authenticated" | "reject";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetObservabilityTracingSettingsResponse {
    /** Up to 100 OpenTelemetry destination identifiers that receive traces. */
    destinations: GetObservabilityTracingSettingsResponseDestinationsList;
    /** Whether Cloudflare Traces is enabled for the zone. */
    enabled: boolean;
    /** Whether trace context is sent externally or across a zone boundary. */
    forwardContext: boolean;
    /** Whether traces are persisted in Cloudflare. */
    persist: boolean;
    /** When inbound trace context may be continued. Authenticated propagation is not supported yet. */
    propagationPolicy: GetObservabilityTracingSettingsResponsePropagationPolicy;
    /** The ratio of requests sampled for tracing, from 0 to 1. */
    samplingRatio: number;
}
export interface GetPlanRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    planIdentifier: string;
}
export type PlansGetResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPlanResponse {
    /** Identifier */
    id?: string | null;
    /** Indicates whether you can subscribe to this plan. */
    canSubscribe?: boolean | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** Indicates whether this plan is managed externally. */
    externallyManaged?: boolean | null;
    /** The frequency at which you will be billed for this plan. */
    frequency?: PlansGetResponseFrequency | null;
    /** Indicates whether you are currently subscribed to this plan. */
    isSubscribed?: boolean | null;
    /** The legacy identifier for this rate plan, if any. */
    legacyId?: string | null;
    /** The plan name. */
    name?: string | null;
    /** The amount you will be billed for this plan. */
    price?: number | null;
}
export interface GetRatePlanRequest {
    /** Identifier */
    zoneId: string;
}
export type RatePlansGetResultItemComponentsItemName = "zones" | "page_rules" | "dedicated_certificates" | "dedicated_certificates_custom";
export interface RatePlansGetResultItemComponentsItem {
    /** The default amount allocated. */
    default?: number | null;
    /** The unique component. */
    name?: RatePlansGetResultItemComponentsItemName | null;
    /** The unit price of the component. */
    unitPrice?: number | null;
}
export type RatePlansGetResultItemComponentsList = Array<RatePlansGetResultItemComponentsItem>;
export type RatePlansGetResultItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export interface RatePlansGetResultItem {
    /** Plan identifier tag. */
    id?: string | null;
    /** Array of available components values for the plan. */
    components?: RatePlansGetResultItemComponentsList | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The duration of the plan subscription. */
    duration?: number | null;
    /** The frequency at which you will be billed for this plan. */
    frequency?: RatePlansGetResultItemFrequency | null;
    /** The plan name. */
    name?: string | null;
}
export type RatePlansGetResultList = Array<RatePlansGetResultItem>;
export interface GetRatePlanResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RatePlansGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetSettingRequest {
    /** Identifier */
    zoneId: string;
    /** Setting name */
    settingId: string;
}
export type SettingsGetResultZeroRTTId = "0rtt";
export type SettingsGetResultZeroRTTValue = "on" | "off";
export interface SettingsGetResultZeroRTT {
    /** ID of the zone setting. */
    id: SettingsGetResultZeroRTTId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZeroRTTValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultAdvancedDDoSId = "advanced_ddos";
export type SettingsGetResultAdvancedDDoSValue = "on" | "off";
export interface SettingsGetResultAdvancedDDoS {
    /** ID of the zone setting. */
    id: SettingsGetResultAdvancedDDoSId;
    /** Current value of the zone setting. */
    value: SettingsGetResultAdvancedDDoSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesCacheRulesAegisId = "aegis";
export interface SettingsGetResultZonesCacheRulesAegisValue {
    /** Whether the feature is enabled or not. */
    enabled?: boolean | null;
    /** Egress pool id which refers to a grouping of dedicated egress IPs through which Cloudflare will connect to origin. */
    poolId?: string | null;
}
export interface SettingsGetResultZonesCacheRulesAegis {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesCacheRulesAegisId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. */
    value?: SettingsGetResultZonesCacheRulesAegisValue | null;
}
export type SettingsGetResultAlwaysOnlineId = "always_online";
export type SettingsGetResultAlwaysOnlineValue = "on" | "off";
export interface SettingsGetResultAlwaysOnline {
    /** ID of the zone setting. */
    id: SettingsGetResultAlwaysOnlineId;
    /** Current value of the zone setting. */
    value: SettingsGetResultAlwaysOnlineValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesAlwaysUseHTTPS2Id = "always_use_https";
export type SettingsGetResultZonesAlwaysUseHTTPS2Value = "on" | "off";
export interface SettingsGetResultZonesAlwaysUseHTTPS2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesAlwaysUseHTTPS2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesAlwaysUseHTTPS2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesAutomaticHTTPSRewrites2Id = "automatic_https_rewrites";
export type SettingsGetResultZonesAutomaticHTTPSRewrites2Value = "on" | "off";
export interface SettingsGetResultZonesAutomaticHTTPSRewrites2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesAutomaticHTTPSRewrites2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesAutomaticHTTPSRewrites2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultBrotliId = "brotli";
export type SettingsGetResultBrotliValue = "off" | "on";
export interface SettingsGetResultBrotli {
    /** ID of the zone setting. */
    id: SettingsGetResultBrotliId;
    /** Current value of the zone setting. */
    value: SettingsGetResultBrotliValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesBrowserCacheTTL2Id = "browser_cache_ttl";
export interface SettingsGetResultZonesBrowserCacheTTL2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesBrowserCacheTTL2Id;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesBrowserCheck2Id = "browser_check";
export type SettingsGetResultZonesBrowserCheck2Value = "on" | "off";
export interface SettingsGetResultZonesBrowserCheck2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesBrowserCheck2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesBrowserCheck2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesCacheLevel2Id = "cache_level";
export type SettingsGetResultZonesCacheLevel2Value = "aggressive" | "basic" | "simplified";
export interface SettingsGetResultZonesCacheLevel2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesCacheLevel2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesCacheLevel2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultChallengeTTLId = "challenge_ttl";
export type SettingsGetResultChallengeTTLValue = 300 | 900 | 1800 | 2700 | 3600 | 7200 | 10800 | 14400 | 28800 | 57600 | 86400 | 604800 | 2592000 | 31536000;
export interface SettingsGetResultChallengeTTL {
    /** ID of the zone setting. */
    id: SettingsGetResultChallengeTTLId;
    /** Current value of the zone setting. */
    value: SettingsGetResultChallengeTTLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesChinaNetworkEnabledId = "china_network_enabled";
export type SettingsGetResultZonesChinaNetworkEnabledValue = "on" | "off";
export interface SettingsGetResultZonesChinaNetworkEnabled {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesChinaNetworkEnabledId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesChinaNetworkEnabledValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesContentConverterId = "content_converter";
export type SettingsGetResultZonesContentConverterValue = "off" | "on";
export interface SettingsGetResultZonesContentConverter {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesContentConverterId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesContentConverterValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultCiphersId = "ciphers";
export type SettingsGetResultCiphersValueList = Array<string>;
export interface SettingsGetResultCiphers {
    /** ID of the zone setting. */
    id: SettingsGetResultCiphersId;
    /** Current value of the zone setting. */
    value: SettingsGetResultCiphersValueList;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesCNAMEFlatteningId = "cname_flattening";
export type SettingsGetResultZonesCNAMEFlatteningValue = "flatten_at_root" | "flatten_all";
export interface SettingsGetResultZonesCNAMEFlattening {
    /** How to flatten the cname destination. */
    id: SettingsGetResultZonesCNAMEFlatteningId;
    /** This zone setting is deprecated; please use the DNS Settings route instead. More information at https://developers.cloudflare.com/fundamentals/api/reference/deprecations/#2025-03-21 */
    value: SettingsGetResultZonesCNAMEFlatteningValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultDevelopmentModeId = "development_mode";
export type SettingsGetResultDevelopmentModeValue = "on" | "off";
export interface SettingsGetResultDevelopmentMode {
    /** ID of the zone setting. */
    id: SettingsGetResultDevelopmentModeId;
    /** Current value of the zone setting. */
    value: SettingsGetResultDevelopmentModeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. Notes: The interval (in seconds) from when development mode expires (positive integer) or last expired (negative integer) for the domain. If development mode has never been enabled, this value is false. */
    timeRemaining?: number | null;
}
export type SettingsGetResultEarlyHintsId = "early_hints";
export type SettingsGetResultEarlyHintsValue = "on" | "off";
export interface SettingsGetResultEarlyHints {
    /** ID of the zone setting. */
    id: SettingsGetResultEarlyHintsId;
    /** Current value of the zone setting. */
    value: SettingsGetResultEarlyHintsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesEdgeCacheTTL2Id = "edge_cache_ttl";
export type SettingsGetResultZonesEdgeCacheTTL2Value = 30 | 60 | 300 | 1200 | 1800 | 3600 | 7200 | 10800 | 14400 | 18000 | 28800 | 43200 | 57600 | 72000 | 86400 | 172800 | 259200 | 345600 | 432000 | 518400 | 604800;
export interface SettingsGetResultZonesEdgeCacheTTL2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesEdgeCacheTTL2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesEdgeCacheTTL2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesEmailObfuscation2Id = "email_obfuscation";
export type SettingsGetResultZonesEmailObfuscation2Value = "on" | "off";
export interface SettingsGetResultZonesEmailObfuscation2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesEmailObfuscation2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesEmailObfuscation2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultH2PrioritizationId = "h2_prioritization";
export type SettingsGetResultH2PrioritizationValue = "on" | "off" | "custom";
export interface SettingsGetResultH2Prioritization {
    /** ID of the zone setting. */
    id: SettingsGetResultH2PrioritizationId;
    /** Current value of the zone setting. */
    value: SettingsGetResultH2PrioritizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultHotlinkProtectionId = "hotlink_protection";
export type SettingsGetResultHotlinkProtectionValue = "on" | "off";
export interface SettingsGetResultHotlinkProtection {
    /** ID of the zone setting. */
    id: SettingsGetResultHotlinkProtectionId;
    /** Current value of the zone setting. */
    value: SettingsGetResultHotlinkProtectionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultHTTP2Id = "http2";
export type SettingsGetResultHTTP2Value = "on" | "off";
export interface SettingsGetResultHTTP2 {
    /** ID of the zone setting. */
    id: SettingsGetResultHTTP2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultHTTP2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultHTTP3Id = "http3";
export type SettingsGetResultHTTP3Value = "on" | "off";
export interface SettingsGetResultHTTP3 {
    /** ID of the zone setting. */
    id: SettingsGetResultHTTP3Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultHTTP3Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultImageResizingId = "image_resizing";
export type SettingsGetResultImageResizingValue = "on" | "off" | "open";
export interface SettingsGetResultImageResizing {
    /** ID of the zone setting. */
    id: SettingsGetResultImageResizingId;
    /** Current value of the zone setting. */
    value: SettingsGetResultImageResizingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesIPGeolocation2Id = "ip_geolocation";
export type SettingsGetResultZonesIPGeolocation2Value = "on" | "off";
export interface SettingsGetResultZonesIPGeolocation2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesIPGeolocation2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesIPGeolocation2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultIPV6Id = "ipv6";
export type SettingsGetResultIPV6Value = "off" | "on";
export interface SettingsGetResultIPV6 {
    /** ID of the zone setting. */
    id: SettingsGetResultIPV6Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultIPV6Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesMaxUploadId = "max_upload";
export type SettingsGetResultZonesMaxUploadValue = 100 | 125 | 150 | 175 | 200 | 225 | 250 | 275 | 300 | 325 | 350 | 375 | 400 | 425 | 450 | 475 | 500 | 1000 | 1500 | 2000 | 2500 | 3000 | 3500 | 4000 | 4500 | 5000;
export interface SettingsGetResultZonesMaxUpload {
    /** identifier of the zone setting. */
    id: SettingsGetResultZonesMaxUploadId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesMaxUploadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultMinTLSVersionId = "min_tls_version";
export type SettingsGetResultMinTLSVersionValue = "1.0" | "1.1" | "1.2" | "1.3";
export interface SettingsGetResultMinTLSVersion {
    /** ID of the zone setting. */
    id: SettingsGetResultMinTLSVersionId;
    /** Current value of the zone setting. */
    value: SettingsGetResultMinTLSVersionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesMirage2Id = "mirage";
export type SettingsGetResultZonesMirage2Value = "on" | "off";
export interface SettingsGetResultZonesMirage2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesMirage2Id;
    /** Mirage is being deprecated. More information at https://developers.cloudflare.com/speed/optimization/images/mirage/ */
    value: SettingsGetResultZonesMirage2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultNELId = "nel";
export interface SettingsGetResultNELValue {
    enabled?: boolean | null;
}
export interface SettingsGetResultNEL {
    /** Zone setting identifier. */
    id: SettingsGetResultNELId;
    /** Current value of the zone setting. */
    value: SettingsGetResultNELValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesOpportunisticEncryption2Id = "opportunistic_encryption";
export type SettingsGetResultZonesOpportunisticEncryption2Value = "on" | "off";
export interface SettingsGetResultZonesOpportunisticEncryption2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesOpportunisticEncryption2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesOpportunisticEncryption2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultOpportunisticOnionId = "opportunistic_onion";
export type SettingsGetResultOpportunisticOnionValue = "on" | "off";
export interface SettingsGetResultOpportunisticOnion {
    /** ID of the zone setting. */
    id: SettingsGetResultOpportunisticOnionId;
    /** Current value of the zone setting. */
    value: SettingsGetResultOpportunisticOnionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultOrangeToOrangeId = "orange_to_orange";
export type SettingsGetResultOrangeToOrangeValue = "on" | "off";
export interface SettingsGetResultOrangeToOrange {
    /** ID of the zone setting. */
    id: SettingsGetResultOrangeToOrangeId;
    /** This setting is deprecated. Orange to Orange (O2O) is applied automatically for eligible zones and no longer requires configuration; this setting only controlled the legacy O2O v1 (Managed CNAME) path. More information at https://developers.cloudflare.com/fundamentals/api/reference/deprecations/ */
    value: SettingsGetResultOrangeToOrangeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesOriginErrorPagePassThru2Id = "origin_error_page_pass_thru";
export type SettingsGetResultZonesOriginErrorPagePassThru2Value = "on" | "off";
export interface SettingsGetResultZonesOriginErrorPagePassThru2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesOriginErrorPagePassThru2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesOriginErrorPagePassThru2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesCacheRulesOriginH2MaxStreamsId = "origin_h2_max_streams";
export interface SettingsGetResultZonesCacheRulesOriginH2MaxStreams {
    /** Value of the zone setting. */
    id: SettingsGetResultZonesCacheRulesOriginH2MaxStreamsId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin H2 Max Streams Setting. */
    value?: number | null;
}
export type SettingsGetResultZonesCacheRulesOriginMaxHTTPVersionId = "origin_max_http_version";
export type SettingsGetResultZonesCacheRulesOriginMaxHTTPVersionValue = "2" | "1";
export interface SettingsGetResultZonesCacheRulesOriginMaxHTTPVersion {
    /** Value of the zone setting. */
    id: SettingsGetResultZonesCacheRulesOriginMaxHTTPVersionId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin Max HTTP Version Setting. */
    value?: SettingsGetResultZonesCacheRulesOriginMaxHTTPVersionValue | null;
}
export type SettingsGetResultZonesPolish2Id = "polish";
export type SettingsGetResultZonesPolish2Value = "off" | "lossless" | "lossy";
export interface SettingsGetResultZonesPolish2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesPolish2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesPolish2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultPrefetchPreloadId = "prefetch_preload";
export type SettingsGetResultPrefetchPreloadValue = "on" | "off";
export interface SettingsGetResultPrefetchPreload {
    /** ID of the zone setting. */
    id: SettingsGetResultPrefetchPreloadId;
    /** Current value of the zone setting. */
    value: SettingsGetResultPrefetchPreloadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesPreRenderId = "pre_render";
export type SettingsGetResultZonesPreRenderValue = "off" | "on";
export interface SettingsGetResultZonesPreRender {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesPreRenderId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesPreRenderValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesPrivacyPassId = "privacy_pass";
export type SettingsGetResultZonesPrivacyPassValue = "on" | "off";
export interface SettingsGetResultZonesPrivacyPass {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesPrivacyPassId;
    /** Privacy Pass v1 was deprecated in 2023. (Announcement - https://blog.cloudflare.com/privacy-pass-standard/) and (API deprecation details - https://developers.cloudflare.com/fundamentals/api/reference/deprecations/#2024-03-31) */
    value: SettingsGetResultZonesPrivacyPassValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultProxyReadTimeoutId = "proxy_read_timeout";
export interface SettingsGetResultProxyReadTimeout {
    /** ID of the zone setting. */
    id: SettingsGetResultProxyReadTimeoutId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultPseudoIPV4Id = "pseudo_ipv4";
export type SettingsGetResultPseudoIPV4Value = "off" | "add_header" | "overwrite_header";
export interface SettingsGetResultPseudoIPV4 {
    /** Value of the Pseudo IPv4 setting. */
    id: SettingsGetResultPseudoIPV4Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultPseudoIPV4Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesRedirectsForAITrainingId = "redirects_for_ai_training";
export type SettingsGetResultZonesRedirectsForAITrainingValue = "off" | "on";
export interface SettingsGetResultZonesRedirectsForAITraining {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesRedirectsForAITrainingId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesRedirectsForAITrainingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesReplaceInsecureJSId = "replace_insecure_js";
export type SettingsGetResultZonesReplaceInsecureJSValue = "on" | "off";
export interface SettingsGetResultZonesReplaceInsecureJS {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesReplaceInsecureJSId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesReplaceInsecureJSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesResponseBuffering2Id = "response_buffering";
export type SettingsGetResultZonesResponseBuffering2Value = "on" | "off";
export interface SettingsGetResultZonesResponseBuffering2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesResponseBuffering2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesResponseBuffering2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesRocketLoader2Id = "rocket_loader";
export type SettingsGetResultZonesRocketLoader2Value = "on" | "off";
export interface SettingsGetResultZonesRocketLoader2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesRocketLoader2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesRocketLoader2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesSchemasAutomaticPlatformOptimizationId = "automatic_platform_optimization";
export type SettingsGetResultZonesSchemasAutomaticPlatformOptimizationValueHostnamesList = Array<string>;
export interface SettingsGetResultZonesSchemasAutomaticPlatformOptimizationValue {
    /** Indicates whether or not [cache by device type](https://developers.cloudflare.com/automatic-platform-optimization/reference/cache-device-type/) is enabled. */
    cacheByDeviceType: boolean;
    /** Indicates whether or not Cloudflare proxy is enabled. */
    cf: boolean;
    /** Indicates whether or not Automatic Platform Optimization is enabled. */
    enabled: boolean;
    /** An array of hostnames where Automatic Platform Optimization for WordPress is activated. */
    hostnames: SettingsGetResultZonesSchemasAutomaticPlatformOptimizationValueHostnamesList;
    /** Indicates whether or not site is powered by WordPress. */
    wordpress: boolean;
    /** Indicates whether or not [Cloudflare for WordPress plugin](https://wordpress.org/plugins/cloudflare/) is installed. */
    wpPlugin: boolean;
}
export interface SettingsGetResultZonesSchemasAutomaticPlatformOptimization {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasAutomaticPlatformOptimizationId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasAutomaticPlatformOptimizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesSearchForAgentsId = "search_for_agents";
export type SettingsGetResultZonesSearchForAgentsValue = "off" | "on";
export interface SettingsGetResultZonesSearchForAgents {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSearchForAgentsId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSearchForAgentsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultSecurityHeadersId = "security_header";
export interface SettingsGetResultSecurityHeadersValueStrictTransportSecurity {
    /** Whether or not strict transport security is enabled. */
    enabled?: boolean | null;
    /** Include all subdomains for strict transport security. */
    includeSubdomains?: boolean | null;
    /** Max age in seconds of the strict transport security. */
    maxAge?: number | null;
    /** Whether or not to include 'X-Content-Type-Options: nosniff' header. */
    nosniff?: boolean | null;
    /** Enable automatic preload of the HSTS configuration. */
    preload?: boolean | null;
}
export interface SettingsGetResultSecurityHeadersValue {
    /** Strict Transport Security. */
    strictTransportSecurity?: SettingsGetResultSecurityHeadersValueStrictTransportSecurity | null;
}
export interface SettingsGetResultSecurityHeaders {
    /** ID of the zone's security header. */
    id: SettingsGetResultSecurityHeadersId;
    /** Current value of the zone setting. */
    value: SettingsGetResultSecurityHeadersValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesSecurityLevel2Id = "security_level";
export type SettingsGetResultZonesSecurityLevel2Value = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface SettingsGetResultZonesSecurityLevel2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSecurityLevel2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSecurityLevel2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultServerSideExcludesId = "server_side_exclude";
export type SettingsGetResultServerSideExcludesValue = "on" | "off";
export interface SettingsGetResultServerSideExcludes {
    /** ID of the zone setting. */
    id: SettingsGetResultServerSideExcludesId;
    /** Current value of the zone setting. */
    value: SettingsGetResultServerSideExcludesValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesSha1SupportId = "sha1_support";
export type SettingsGetResultZonesSha1SupportValue = "off" | "on";
export interface SettingsGetResultZonesSha1Support {
    /** Zone setting identifier. */
    id: SettingsGetResultZonesSha1SupportId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSha1SupportValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesSortQueryStringForCache2Id = "sort_query_string_for_cache";
export type SettingsGetResultZonesSortQueryStringForCache2Value = "on" | "off";
export interface SettingsGetResultZonesSortQueryStringForCache2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSortQueryStringForCache2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSortQueryStringForCache2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesSSL2Id = "ssl";
export type SettingsGetResultZonesSSL2Value = "off" | "flexible" | "full" | "strict";
export interface SettingsGetResultZonesSSL2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSSL2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSSL2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultSSLRecommenderId = "ssl_recommender";
export interface SettingsGetResultSSLRecommender {
    /** Enrollment value for SSL/TLS Recommender. */
    id?: SettingsGetResultSSLRecommenderId | null;
    /** ssl-recommender enrollment setting. */
    enabled?: boolean | null;
}
export type SettingsGetResultZonesTLS12OnlyId = "tls_1_2_only";
export type SettingsGetResultZonesTLS12OnlyValue = "off" | "on";
export interface SettingsGetResultZonesTLS12Only {
    /** Zone setting identifier. */
    id: SettingsGetResultZonesTLS12OnlyId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesTLS12OnlyValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultTLS13Id = "tls_1_3";
export type SettingsGetResultTLS13Value = "on" | "off" | "zrt";
export interface SettingsGetResultTLS13 {
    /** ID of the zone setting. */
    id: SettingsGetResultTLS13Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultTLS13Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultTLSClientAuthId = "tls_client_auth";
export type SettingsGetResultTLSClientAuthValue = "on" | "off";
export interface SettingsGetResultTLSClientAuth {
    /** ID of the zone setting. */
    id: SettingsGetResultTLSClientAuthId;
    /** Current value of the zone setting. */
    value: SettingsGetResultTLSClientAuthValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesTransformationsId = "transformations";
export type SettingsGetResultZonesTransformationsValue = "on" | "off" | "open";
export interface SettingsGetResultZonesTransformations {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: SettingsGetResultZonesTransformationsId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesTransformationsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesTransformationsAllowedOriginsId = "transformations_allowed_origins";
export interface SettingsGetResultZonesTransformationsAllowedOrigins {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: SettingsGetResultZonesTransformationsAllowedOriginsId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesTrueClientIPHeader2Id = "true_client_ip_header";
export type SettingsGetResultZonesTrueClientIPHeader2Value = "on" | "off";
export interface SettingsGetResultZonesTrueClientIPHeader2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesTrueClientIPHeader2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesTrueClientIPHeader2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesWAF2Id = "waf";
export type SettingsGetResultZonesWAF2Value = "on" | "off";
export interface SettingsGetResultZonesWAF2 {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesWAF2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesWAF2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesWebmcpEnabledId = "webmcp_enabled";
export type SettingsGetResultZonesWebmcpEnabledValue = "off" | "on";
export interface SettingsGetResultZonesWebmcpEnabled {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesWebmcpEnabledId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesWebmcpEnabledValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesWebmcpMcpURLId = "webmcp_mcp_url";
export interface SettingsGetResultZonesWebmcpMcpURL {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesWebmcpMcpURLId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultZonesWebmcpPacksId = "webmcp_packs";
export interface SettingsGetResultZonesWebmcpPacks {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesWebmcpPacksId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultWebPId = "webp";
export type SettingsGetResultWebPValue = "off" | "on";
export interface SettingsGetResultWebP {
    /** ID of the zone setting. */
    id: SettingsGetResultWebPId;
    /** Current value of the zone setting. */
    value: SettingsGetResultWebPValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResultWebsocketId = "websockets";
export type SettingsGetResultWebsocketValue = "off" | "on";
export interface SettingsGetResultWebsocket {
    /** ID of the zone setting. */
    id: SettingsGetResultWebsocketId;
    /** Current value of the zone setting. */
    value: SettingsGetResultWebsocketValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsGetResult = SettingsGetResultZeroRTT | SettingsGetResultAdvancedDDoS | SettingsGetResultZonesCacheRulesAegis | SettingsGetResultAlwaysOnline | SettingsGetResultZonesAlwaysUseHTTPS2 | SettingsGetResultZonesAutomaticHTTPSRewrites2 | SettingsGetResultBrotli | SettingsGetResultZonesBrowserCacheTTL2 | SettingsGetResultZonesBrowserCheck2 | SettingsGetResultZonesCacheLevel2 | SettingsGetResultChallengeTTL | SettingsGetResultZonesChinaNetworkEnabled | SettingsGetResultZonesContentConverter | SettingsGetResultCiphers | SettingsGetResultZonesCNAMEFlattening | SettingsGetResultDevelopmentMode | SettingsGetResultEarlyHints | SettingsGetResultZonesEdgeCacheTTL2 | SettingsGetResultZonesEmailObfuscation2 | SettingsGetResultH2Prioritization | SettingsGetResultHotlinkProtection | SettingsGetResultHTTP2 | SettingsGetResultHTTP3 | SettingsGetResultImageResizing | SettingsGetResultZonesIPGeolocation2 | SettingsGetResultIPV6 | SettingsGetResultZonesMaxUpload | SettingsGetResultMinTLSVersion | SettingsGetResultZonesMirage2 | SettingsGetResultNEL | SettingsGetResultZonesOpportunisticEncryption2 | SettingsGetResultOpportunisticOnion | SettingsGetResultOrangeToOrange | SettingsGetResultZonesOriginErrorPagePassThru2 | SettingsGetResultZonesCacheRulesOriginH2MaxStreams | SettingsGetResultZonesCacheRulesOriginMaxHTTPVersion | SettingsGetResultZonesPolish2 | SettingsGetResultPrefetchPreload | SettingsGetResultZonesPreRender | SettingsGetResultZonesPrivacyPass | SettingsGetResultProxyReadTimeout | SettingsGetResultPseudoIPV4 | SettingsGetResultZonesRedirectsForAITraining | SettingsGetResultZonesReplaceInsecureJS | SettingsGetResultZonesResponseBuffering2 | SettingsGetResultZonesRocketLoader2 | SettingsGetResultZonesSchemasAutomaticPlatformOptimization | SettingsGetResultZonesSearchForAgents | SettingsGetResultSecurityHeaders | SettingsGetResultZonesSecurityLevel2 | SettingsGetResultServerSideExcludes | SettingsGetResultZonesSha1Support | SettingsGetResultZonesSortQueryStringForCache2 | SettingsGetResultZonesSSL2 | SettingsGetResultSSLRecommender | SettingsGetResultZonesTLS12Only | SettingsGetResultTLS13 | SettingsGetResultTLSClientAuth | SettingsGetResultZonesTransformations | SettingsGetResultZonesTransformationsAllowedOrigins | SettingsGetResultZonesTrueClientIPHeader2 | SettingsGetResultZonesWAF2 | SettingsGetResultZonesWebmcpEnabled | SettingsGetResultZonesWebmcpMcpURL | SettingsGetResultZonesWebmcpPacks | SettingsGetResultWebP | SettingsGetResultWebsocket;
export type GetSettingResponse = SettingsGetResult;
export interface GetSubscriptionRequest {
    /** Identifier */
    zoneId: string;
}
export type SubscriptionsGetResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly" | "not-applicable";
export type SubscriptionsGetResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsGetResponseRatePlanSetsList = Array<string>;
export interface SubscriptionsGetResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsGetResponseRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsGetResponseRatePlanSetsList | null;
}
export type SubscriptionsGetResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSubscriptionResponse {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsGetResponseFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsGetResponseRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsGetResponseState | null;
}
export interface GetTransformationsAllowedOriginRequest {
    /** Identifier. */
    zoneId: string;
}
export type GetTransformationsAllowedOriginResponseId = "image_resizing_allowed_origins";
export type GetTransformationsAllowedOriginResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTransformationsAllowedOriginResponse {
    /** ID of the zone setting. */
    id?: GetTransformationsAllowedOriginResponseId | null;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
    /** Comma-separated list of allowed origin domains for image and video transformations. Use "*" to allow all origins (default). */
    value?: GetTransformationsAllowedOriginResponseValue | null;
}
export interface GetTransformationsC2paRequest {
    /** Identifier. */
    zoneId: string;
}
export type GetTransformationsC2paResponseId = "image_resizing_c2pa";
export type GetTransformationsC2paResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTransformationsC2paResponse {
    /** ID of the zone setting. */
    id?: GetTransformationsC2paResponseId | null;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
    /** Current value of the zone setting. */
    value?: GetTransformationsC2paResponseValue | null;
}
export interface GetZoneRequest {
    /** Identifier */
    zoneId: string;
}
export type GetResponseAccount = CreateResponseAccount;
export type GetResponseMeta = CreateResponseMeta;
export type GetResponseNameServersList = Array<string>;
export type GetResponseOriginalNameServersList = Array<string>;
export type GetResponseOwner = CreateResponseOwner;
export type GetResponsePlan = CreateResponsePlan;
export type GetResponsePermissionsList = Array<string>;
export type GetResponseStatus = "initializing" | "pending" | "active" | "moved";
export type GetResponseTenant = CreateResponseTenant;
export type GetResponseTenantUnit = CreateResponseTenantUnit;
export type GetResponseType = "full" | "partial" | "secondary" | "internal";
export type GetResponseVanityNameServersList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneResponse {
    /** Identifier */
    id: string;
    /** The account the zone belongs to. */
    account: CreateResponseAccount;
    /** The last time proof of ownership was detected and the zone was made active. */
    activatedOn: string;
    /** When the zone was created. */
    createdOn: string;
    /** The interval (in seconds) from when development mode expires (positive integer) or last expired (negative integer) for the domain. If development mode has never been enabled, this value is 0. */
    developmentMode: number;
    /** Metadata about the zone. */
    meta: CreateResponseMeta;
    /** When the zone was last modified. */
    modifiedOn: string;
    /** The domain name. Per [RFC 1035](https://datatracker.ietf.org/doc/html/rfc1035#section-2.3.4) the overall zone name can be up to 253 characters, with each segment ("label") not exceeding 63 characters. */
    name: string;
    /** The name servers Cloudflare assigns to a zone. */
    nameServers: GetResponseNameServersList;
    /** DNS host at the time of switching to Cloudflare. */
    originalDnshost: string;
    /** Original name servers before moving to Cloudflare. */
    originalNameServers: GetResponseOriginalNameServersList;
    /** Registrar for the domain at the time of switching to Cloudflare. */
    originalRegistrar: string;
    /** The owner of the zone. */
    owner: CreateResponseOwner;
    /** Please use the `/zones/{zone_id}/subscription` API to update a zone's plan. Changing this value will create/cancel associated subscriptions. To view available plans for this zone, see [Zone Plans](https://developers.cloudflare.com/api/resources/zones/subresources/plans/). */
    plan: CreateResponsePlan;
    /** Allows the customer to use a custom apex. *Tenants Only Configuration*. */
    cnameSuffix?: string | null;
    /** Indicates whether the zone is only using Cloudflare DNS services. A true value means the zone will not receive security or performance benefits. */
    paused?: boolean | null;
    /** This has been replaced by Account memberships. */
    permissions?: GetResponsePermissionsList | null;
    /** The zone status on Cloudflare. */
    status?: GetResponseStatus | null;
    /** The root organizational unit that this zone belongs to (such as a tenant or organization). */
    tenant?: CreateResponseTenant | null;
    /** The immediate parent organizational unit that this zone belongs to (such as under a tenant or sub-organization). */
    tenantUnit?: CreateResponseTenantUnit | null;
    /** A full zone implies that DNS is hosted with Cloudflare. A partial zone is typically a partner-hosted zone or a CNAME setup. */
    type?: GetResponseType | null;
    /** An array of domains used for custom name servers. This is only available for Business and Enterprise plans. */
    vanityNameServers?: GetResponseVanityNameServersList | null;
    /** Verification key for partial zone setup. */
    verificationKey?: string | null;
}
export interface ListEntitlementsRequest {
    /** Identifier tag. */
    zoneId: string;
}
export type ListEntitlementsResultItemAllocationType = "bool" | "max_count" | "enum_number" | "range" | "string";
export type ListEntitlementsResultItemAllocationValueCase3List = Array<number>;
export interface ListEntitlementsResultItemAllocationValueCase4 {
    max: number;
    min: number;
}
export type ListEntitlementsResultItemAllocationValue = string | number | boolean | ListEntitlementsResultItemAllocationValueCase3List | ListEntitlementsResultItemAllocationValueCase4;
export interface ListEntitlementsResultItemAllocation {
    /** Allocation type discriminator. */
    type: ListEntitlementsResultItemAllocationType;
    /** Contains the allocation value whose concrete type the `type` field determines: bool yields a boolean, max_count yields an integer, enum_number yields an array of numbers, range yields an object with `min` and `max`, and string yields a string. */
    value: ListEntitlementsResultItemAllocationValue;
}
export interface ListEntitlementsResultItemFeature {
    /** Numeric identifier of the feature. */
    id: number;
    /** The logical grouping (set) this feature belongs to. */
    featureSet: string;
    /** Unique string key for the feature. */
    key: string;
    /** Human-readable name of the feature. */
    name: string;
}
export interface ListEntitlementsResultItem {
    /** Entitlement identifier -- equal to the feature key. */
    id: string;
    /** Represents the allocation value for an entitlement. The shape of `value` depends on `type`: `bool` uses a boolean, `max_count` uses an integer, `enum_number` uses an array of numbers, `range` uses an object with `min` and `max` integer fields, and `string` uses a string. */
    allocation: ListEntitlementsResultItemAllocation;
    /** ISO 8601 timestamp (microsecond precision, no timezone offset) when the entitlement was created. Format: `YYYY-MM-DDTHH:MM:SS.ffffff`. */
    createdDate: string;
    /** ISO 8601 timestamp when the entitlement was deleted, or empty string if not deleted. */
    deletedDate: string;
    /** ISO 8601 timestamp (microsecond precision, no timezone offset) when the entitlement was last edited. */
    editedDate: string;
    /** Describes a product feature associated with an entitlement. */
    feature: ListEntitlementsResultItemFeature;
}
export type ListEntitlementsResultList = Array<ListEntitlementsResultItem>;
export type ListEntitlementsResponse = ListEntitlementsResultList;
export interface ListEnvironmentsRequest {
    zoneId: string;
}
export type EnvironmentsListResponseEnvironmentsItemPosition = EnvironmentsCreateResponseEnvironmentsItemPosition;
export type EnvironmentsListResponseEnvironmentsItem = EnvironmentsCreateResponseEnvironmentsItem;
export type EnvironmentsListResponseEnvironmentsList = Array<EnvironmentsCreateResponseEnvironmentsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListEnvironmentsResponse {
    environments: EnvironmentsListResponseEnvironmentsList;
}
export interface ListPlansRequest {
    /** Identifier */
    zoneId: string;
}
export type PlansListResultItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export interface PlansListResultItem {
    /** Identifier */
    id?: string | null;
    /** Indicates whether you can subscribe to this plan. */
    canSubscribe?: boolean | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** Indicates whether this plan is managed externally. */
    externallyManaged?: boolean | null;
    /** The frequency at which you will be billed for this plan. */
    frequency?: PlansListResultItemFrequency | null;
    /** Indicates whether you are currently subscribed to this plan. */
    isSubscribed?: boolean | null;
    /** The legacy identifier for this rate plan, if any. */
    legacyId?: string | null;
    /** The plan name. */
    name?: string | null;
    /** The amount you will be billed for this plan. */
    price?: number | null;
}
export type PlansListResultList = Array<PlansListResultItem>;
export interface ListPlansResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PlansListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListSettingsRequest {
    /** Identifier */
    zoneId: string;
}
export type ListSettingsResultItemZeroRTTId = "0rtt";
export type ListSettingsResultItemZeroRTTValue = "on" | "off";
export interface ListSettingsResultItemZeroRTT {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZeroRTTId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZeroRTTValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemAdvancedDDoSId = "advanced_ddos";
export type ListSettingsResultItemAdvancedDDoSValue = "on" | "off";
export interface ListSettingsResultItemAdvancedDDoS {
    /** ID of the zone setting. */
    id: ListSettingsResultItemAdvancedDDoSId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemAdvancedDDoSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesCacheRulesAegisId = "aegis";
export type ListSettingsResultItemZonesCacheRulesAegisValue = SettingsGetResultZonesCacheRulesAegisValue;
export interface ListSettingsResultItemZonesCacheRulesAegis {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesCacheRulesAegisId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. */
    value?: SettingsGetResultZonesCacheRulesAegisValue | null;
}
export type ListSettingsResultItemAlwaysOnlineId = "always_online";
export type ListSettingsResultItemAlwaysOnlineValue = "on" | "off";
export interface ListSettingsResultItemAlwaysOnline {
    /** ID of the zone setting. */
    id: ListSettingsResultItemAlwaysOnlineId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemAlwaysOnlineValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesAlwaysUseHTTPS2Id = "always_use_https";
export type ListSettingsResultItemZonesAlwaysUseHTTPS2Value = "on" | "off";
export interface ListSettingsResultItemZonesAlwaysUseHTTPS2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesAlwaysUseHTTPS2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesAlwaysUseHTTPS2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesAutomaticHTTPSRewrites2Id = "automatic_https_rewrites";
export type ListSettingsResultItemZonesAutomaticHTTPSRewrites2Value = "on" | "off";
export interface ListSettingsResultItemZonesAutomaticHTTPSRewrites2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesAutomaticHTTPSRewrites2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesAutomaticHTTPSRewrites2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemBrotliId = "brotli";
export type ListSettingsResultItemBrotliValue = "off" | "on";
export interface ListSettingsResultItemBrotli {
    /** ID of the zone setting. */
    id: ListSettingsResultItemBrotliId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemBrotliValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesBrowserCacheTTL2Id = "browser_cache_ttl";
export interface ListSettingsResultItemZonesBrowserCacheTTL2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesBrowserCacheTTL2Id;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesBrowserCheck2Id = "browser_check";
export type ListSettingsResultItemZonesBrowserCheck2Value = "on" | "off";
export interface ListSettingsResultItemZonesBrowserCheck2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesBrowserCheck2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesBrowserCheck2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesCacheLevel2Id = "cache_level";
export type ListSettingsResultItemZonesCacheLevel2Value = "aggressive" | "basic" | "simplified";
export interface ListSettingsResultItemZonesCacheLevel2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesCacheLevel2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesCacheLevel2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemChallengeTTLId = "challenge_ttl";
export type ListSettingsResultItemChallengeTTLValue = 300 | 900 | 1800 | 2700 | 3600 | 7200 | 10800 | 14400 | 28800 | 57600 | 86400 | 604800 | 2592000 | 31536000;
export interface ListSettingsResultItemChallengeTTL {
    /** ID of the zone setting. */
    id: ListSettingsResultItemChallengeTTLId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemChallengeTTLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemCiphersId = "ciphers";
export type ListSettingsResultItemCiphersValueList = Array<string>;
export interface ListSettingsResultItemCiphers {
    /** ID of the zone setting. */
    id: ListSettingsResultItemCiphersId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemCiphersValueList;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesContentConverterId = "content_converter";
export type ListSettingsResultItemZonesContentConverterValue = "off" | "on";
export interface ListSettingsResultItemZonesContentConverter {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesContentConverterId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesContentConverterValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesCNAMEFlatteningId = "cname_flattening";
export type ListSettingsResultItemZonesCNAMEFlatteningValue = "flatten_at_root" | "flatten_all";
export interface ListSettingsResultItemZonesCNAMEFlattening {
    /** How to flatten the cname destination. */
    id: ListSettingsResultItemZonesCNAMEFlatteningId;
    /** This zone setting is deprecated; please use the DNS Settings route instead. More information at https://developers.cloudflare.com/fundamentals/api/reference/deprecations/#2025-03-21 */
    value: ListSettingsResultItemZonesCNAMEFlatteningValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemDevelopmentModeId = "development_mode";
export type ListSettingsResultItemDevelopmentModeValue = "on" | "off";
export interface ListSettingsResultItemDevelopmentMode {
    /** ID of the zone setting. */
    id: ListSettingsResultItemDevelopmentModeId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemDevelopmentModeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. Notes: The interval (in seconds) from when development mode expires (positive integer) or last expired (negative integer) for the domain. If development mode has never been enabled, this value is false. */
    timeRemaining?: number | null;
}
export type ListSettingsResultItemEarlyHintsId = "early_hints";
export type ListSettingsResultItemEarlyHintsValue = "on" | "off";
export interface ListSettingsResultItemEarlyHints {
    /** ID of the zone setting. */
    id: ListSettingsResultItemEarlyHintsId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemEarlyHintsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesEdgeCacheTTL2Id = "edge_cache_ttl";
export type ListSettingsResultItemZonesEdgeCacheTTL2Value = 30 | 60 | 300 | 1200 | 1800 | 3600 | 7200 | 10800 | 14400 | 18000 | 28800 | 43200 | 57600 | 72000 | 86400 | 172800 | 259200 | 345600 | 432000 | 518400 | 604800;
export interface ListSettingsResultItemZonesEdgeCacheTTL2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesEdgeCacheTTL2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesEdgeCacheTTL2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesEmailObfuscation2Id = "email_obfuscation";
export type ListSettingsResultItemZonesEmailObfuscation2Value = "on" | "off";
export interface ListSettingsResultItemZonesEmailObfuscation2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesEmailObfuscation2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesEmailObfuscation2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemH2PrioritizationId = "h2_prioritization";
export type ListSettingsResultItemH2PrioritizationValue = "on" | "off" | "custom";
export interface ListSettingsResultItemH2Prioritization {
    /** ID of the zone setting. */
    id: ListSettingsResultItemH2PrioritizationId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemH2PrioritizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemHotlinkProtectionId = "hotlink_protection";
export type ListSettingsResultItemHotlinkProtectionValue = "on" | "off";
export interface ListSettingsResultItemHotlinkProtection {
    /** ID of the zone setting. */
    id: ListSettingsResultItemHotlinkProtectionId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemHotlinkProtectionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemHTTP2Id = "http2";
export type ListSettingsResultItemHTTP2Value = "on" | "off";
export interface ListSettingsResultItemHTTP2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemHTTP2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemHTTP2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemHTTP3Id = "http3";
export type ListSettingsResultItemHTTP3Value = "on" | "off";
export interface ListSettingsResultItemHTTP3 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemHTTP3Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemHTTP3Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemImageResizingId = "image_resizing";
export type ListSettingsResultItemImageResizingValue = "on" | "off" | "open";
export interface ListSettingsResultItemImageResizing {
    /** ID of the zone setting. */
    id: ListSettingsResultItemImageResizingId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemImageResizingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesIPGeolocation2Id = "ip_geolocation";
export type ListSettingsResultItemZonesIPGeolocation2Value = "on" | "off";
export interface ListSettingsResultItemZonesIPGeolocation2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesIPGeolocation2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesIPGeolocation2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemIPV6Id = "ipv6";
export type ListSettingsResultItemIPV6Value = "off" | "on";
export interface ListSettingsResultItemIPV6 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemIPV6Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemIPV6Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesMaxUploadId = "max_upload";
export type ListSettingsResultItemZonesMaxUploadValue = 100 | 125 | 150 | 175 | 200 | 225 | 250 | 275 | 300 | 325 | 350 | 375 | 400 | 425 | 450 | 475 | 500 | 1000 | 1500 | 2000 | 2500 | 3000 | 3500 | 4000 | 4500 | 5000;
export interface ListSettingsResultItemZonesMaxUpload {
    /** identifier of the zone setting. */
    id: ListSettingsResultItemZonesMaxUploadId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesMaxUploadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemMinTLSVersionId = "min_tls_version";
export type ListSettingsResultItemMinTLSVersionValue = "1.0" | "1.1" | "1.2" | "1.3";
export interface ListSettingsResultItemMinTLSVersion {
    /** ID of the zone setting. */
    id: ListSettingsResultItemMinTLSVersionId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemMinTLSVersionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesMirage2Id = "mirage";
export type ListSettingsResultItemZonesMirage2Value = "on" | "off";
export interface ListSettingsResultItemZonesMirage2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesMirage2Id;
    /** Mirage is being deprecated. More information at https://developers.cloudflare.com/speed/optimization/images/mirage/ */
    value: ListSettingsResultItemZonesMirage2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemNELId = "nel";
export type ListSettingsResultItemNELValue = SettingsGetResultNELValue;
export interface ListSettingsResultItemNEL {
    /** Zone setting identifier. */
    id: ListSettingsResultItemNELId;
    /** Current value of the zone setting. */
    value: SettingsGetResultNELValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesOpportunisticEncryption2Id = "opportunistic_encryption";
export type ListSettingsResultItemZonesOpportunisticEncryption2Value = "on" | "off";
export interface ListSettingsResultItemZonesOpportunisticEncryption2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesOpportunisticEncryption2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesOpportunisticEncryption2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemOpportunisticOnionId = "opportunistic_onion";
export type ListSettingsResultItemOpportunisticOnionValue = "on" | "off";
export interface ListSettingsResultItemOpportunisticOnion {
    /** ID of the zone setting. */
    id: ListSettingsResultItemOpportunisticOnionId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemOpportunisticOnionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemOrangeToOrangeId = "orange_to_orange";
export type ListSettingsResultItemOrangeToOrangeValue = "on" | "off";
export interface ListSettingsResultItemOrangeToOrange {
    /** ID of the zone setting. */
    id: ListSettingsResultItemOrangeToOrangeId;
    /** This setting is deprecated. Orange to Orange (O2O) is applied automatically for eligible zones and no longer requires configuration; this setting only controlled the legacy O2O v1 (Managed CNAME) path. More information at https://developers.cloudflare.com/fundamentals/api/reference/deprecations/ */
    value: ListSettingsResultItemOrangeToOrangeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesOriginErrorPagePassThru2Id = "origin_error_page_pass_thru";
export type ListSettingsResultItemZonesOriginErrorPagePassThru2Value = "on" | "off";
export interface ListSettingsResultItemZonesOriginErrorPagePassThru2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesOriginErrorPagePassThru2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesOriginErrorPagePassThru2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesCacheRulesOriginH2MaxStreamsId = "origin_h2_max_streams";
export interface ListSettingsResultItemZonesCacheRulesOriginH2MaxStreams {
    /** Value of the zone setting. */
    id: ListSettingsResultItemZonesCacheRulesOriginH2MaxStreamsId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin H2 Max Streams Setting. */
    value?: number | null;
}
export type ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersionId = "origin_max_http_version";
export type ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersionValue = "2" | "1";
export interface ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersion {
    /** Value of the zone setting. */
    id: ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersionId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin Max HTTP Version Setting. */
    value?: ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersionValue | null;
}
export type ListSettingsResultItemZonesPolish2Id = "polish";
export type ListSettingsResultItemZonesPolish2Value = "off" | "lossless" | "lossy";
export interface ListSettingsResultItemZonesPolish2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesPolish2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesPolish2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemPrefetchPreloadId = "prefetch_preload";
export type ListSettingsResultItemPrefetchPreloadValue = "on" | "off";
export interface ListSettingsResultItemPrefetchPreload {
    /** ID of the zone setting. */
    id: ListSettingsResultItemPrefetchPreloadId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemPrefetchPreloadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesPreRenderId = "pre_render";
export type ListSettingsResultItemZonesPreRenderValue = "off" | "on";
export interface ListSettingsResultItemZonesPreRender {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesPreRenderId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesPreRenderValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesPrivacyPassId = "privacy_pass";
export type ListSettingsResultItemZonesPrivacyPassValue = "on" | "off";
export interface ListSettingsResultItemZonesPrivacyPass {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesPrivacyPassId;
    /** Privacy Pass v1 was deprecated in 2023. (Announcement - https://blog.cloudflare.com/privacy-pass-standard/) and (API deprecation details - https://developers.cloudflare.com/fundamentals/api/reference/deprecations/#2024-03-31) */
    value: ListSettingsResultItemZonesPrivacyPassValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemProxyReadTimeoutId = "proxy_read_timeout";
export interface ListSettingsResultItemProxyReadTimeout {
    /** ID of the zone setting. */
    id: ListSettingsResultItemProxyReadTimeoutId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemPseudoIPV4Id = "pseudo_ipv4";
export type ListSettingsResultItemPseudoIPV4Value = "off" | "add_header" | "overwrite_header";
export interface ListSettingsResultItemPseudoIPV4 {
    /** Value of the Pseudo IPv4 setting. */
    id: ListSettingsResultItemPseudoIPV4Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemPseudoIPV4Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesRedirectsForAITrainingId = "redirects_for_ai_training";
export type ListSettingsResultItemZonesRedirectsForAITrainingValue = "off" | "on";
export interface ListSettingsResultItemZonesRedirectsForAITraining {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesRedirectsForAITrainingId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesRedirectsForAITrainingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesReplaceInsecureJSId = "replace_insecure_js";
export type ListSettingsResultItemZonesReplaceInsecureJSValue = "on" | "off";
export interface ListSettingsResultItemZonesReplaceInsecureJS {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesReplaceInsecureJSId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesReplaceInsecureJSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesResponseBuffering2Id = "response_buffering";
export type ListSettingsResultItemZonesResponseBuffering2Value = "on" | "off";
export interface ListSettingsResultItemZonesResponseBuffering2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesResponseBuffering2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesResponseBuffering2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesRocketLoader2Id = "rocket_loader";
export type ListSettingsResultItemZonesRocketLoader2Value = "on" | "off";
export interface ListSettingsResultItemZonesRocketLoader2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesRocketLoader2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesRocketLoader2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationId = "automatic_platform_optimization";
export type ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList = Array<string>;
export interface ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationValue {
    /** Indicates whether or not [cache by device type](https://developers.cloudflare.com/automatic-platform-optimization/reference/cache-device-type/) is enabled. */
    cacheByDeviceType: boolean;
    /** Indicates whether or not Cloudflare proxy is enabled. */
    cf: boolean;
    /** Indicates whether or not Automatic Platform Optimization is enabled. */
    enabled: boolean;
    /** An array of hostnames where Automatic Platform Optimization for WordPress is activated. */
    hostnames: ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList;
    /** Indicates whether or not site is powered by WordPress. */
    wordpress: boolean;
    /** Indicates whether or not [Cloudflare for WordPress plugin](https://wordpress.org/plugins/cloudflare/) is installed. */
    wpPlugin: boolean;
}
export interface ListSettingsResultItemZonesSchemasAutomaticPlatformOptimization {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesSearchForAgentsId = "search_for_agents";
export type ListSettingsResultItemZonesSearchForAgentsValue = "off" | "on";
export interface ListSettingsResultItemZonesSearchForAgents {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSearchForAgentsId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSearchForAgentsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemSecurityHeadersId = "security_header";
export type ListSettingsResultItemSecurityHeadersValueStrictTransportSecurity = SettingsGetResultSecurityHeadersValueStrictTransportSecurity;
export type ListSettingsResultItemSecurityHeadersValue = SettingsGetResultSecurityHeadersValue;
export interface ListSettingsResultItemSecurityHeaders {
    /** ID of the zone's security header. */
    id: ListSettingsResultItemSecurityHeadersId;
    /** Current value of the zone setting. */
    value: SettingsGetResultSecurityHeadersValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesSecurityLevel2Id = "security_level";
export type ListSettingsResultItemZonesSecurityLevel2Value = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface ListSettingsResultItemZonesSecurityLevel2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSecurityLevel2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSecurityLevel2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemServerSideExcludesId = "server_side_exclude";
export type ListSettingsResultItemServerSideExcludesValue = "on" | "off";
export interface ListSettingsResultItemServerSideExcludes {
    /** ID of the zone setting. */
    id: ListSettingsResultItemServerSideExcludesId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemServerSideExcludesValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesSha1SupportId = "sha1_support";
export type ListSettingsResultItemZonesSha1SupportValue = "off" | "on";
export interface ListSettingsResultItemZonesSha1Support {
    /** Zone setting identifier. */
    id: ListSettingsResultItemZonesSha1SupportId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSha1SupportValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesSortQueryStringForCache2Id = "sort_query_string_for_cache";
export type ListSettingsResultItemZonesSortQueryStringForCache2Value = "on" | "off";
export interface ListSettingsResultItemZonesSortQueryStringForCache2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSortQueryStringForCache2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSortQueryStringForCache2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesSSL2Id = "ssl";
export type ListSettingsResultItemZonesSSL2Value = "off" | "flexible" | "full" | "strict";
export interface ListSettingsResultItemZonesSSL2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSSL2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSSL2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemSSLRecommenderId = "ssl_recommender";
export interface ListSettingsResultItemSSLRecommender {
    /** Enrollment value for SSL/TLS Recommender. */
    id?: ListSettingsResultItemSSLRecommenderId | null;
    /** ssl-recommender enrollment setting. */
    enabled?: boolean | null;
}
export type ListSettingsResultItemZonesTLS12OnlyId = "tls_1_2_only";
export type ListSettingsResultItemZonesTLS12OnlyValue = "off" | "on";
export interface ListSettingsResultItemZonesTLS12Only {
    /** Zone setting identifier. */
    id: ListSettingsResultItemZonesTLS12OnlyId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesTLS12OnlyValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemTLS13Id = "tls_1_3";
export type ListSettingsResultItemTLS13Value = "on" | "off" | "zrt";
export interface ListSettingsResultItemTLS13 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemTLS13Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemTLS13Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemTLSClientAuthId = "tls_client_auth";
export type ListSettingsResultItemTLSClientAuthValue = "on" | "off";
export interface ListSettingsResultItemTLSClientAuth {
    /** ID of the zone setting. */
    id: ListSettingsResultItemTLSClientAuthId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemTLSClientAuthValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesTransformationsId = "transformations";
export type ListSettingsResultItemZonesTransformationsValue = "on" | "off" | "open";
export interface ListSettingsResultItemZonesTransformations {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: ListSettingsResultItemZonesTransformationsId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesTransformationsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesTransformationsAllowedOriginsId = "transformations_allowed_origins";
export interface ListSettingsResultItemZonesTransformationsAllowedOrigins {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: ListSettingsResultItemZonesTransformationsAllowedOriginsId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesTrueClientIPHeader2Id = "true_client_ip_header";
export type ListSettingsResultItemZonesTrueClientIPHeader2Value = "on" | "off";
export interface ListSettingsResultItemZonesTrueClientIPHeader2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesTrueClientIPHeader2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesTrueClientIPHeader2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesWAF2Id = "waf";
export type ListSettingsResultItemZonesWAF2Value = "on" | "off";
export interface ListSettingsResultItemZonesWAF2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesWAF2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesWAF2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesWebmcpEnabledId = "webmcp_enabled";
export type ListSettingsResultItemZonesWebmcpEnabledValue = "off" | "on";
export interface ListSettingsResultItemZonesWebmcpEnabled {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesWebmcpEnabledId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesWebmcpEnabledValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesWebmcpMcpURLId = "webmcp_mcp_url";
export interface ListSettingsResultItemZonesWebmcpMcpURL {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesWebmcpMcpURLId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemZonesWebmcpPacksId = "webmcp_packs";
export interface ListSettingsResultItemZonesWebmcpPacks {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesWebmcpPacksId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemWebPId = "webp";
export type ListSettingsResultItemWebPValue = "off" | "on";
export interface ListSettingsResultItemWebP {
    /** ID of the zone setting. */
    id: ListSettingsResultItemWebPId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemWebPValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItemWebsocketId = "websockets";
export type ListSettingsResultItemWebsocketValue = "off" | "on";
export interface ListSettingsResultItemWebsocket {
    /** ID of the zone setting. */
    id: ListSettingsResultItemWebsocketId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemWebsocketValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type ListSettingsResultItem = ListSettingsResultItemZeroRTT | ListSettingsResultItemAdvancedDDoS | ListSettingsResultItemZonesCacheRulesAegis | ListSettingsResultItemAlwaysOnline | ListSettingsResultItemZonesAlwaysUseHTTPS2 | ListSettingsResultItemZonesAutomaticHTTPSRewrites2 | ListSettingsResultItemBrotli | ListSettingsResultItemZonesBrowserCacheTTL2 | ListSettingsResultItemZonesBrowserCheck2 | ListSettingsResultItemZonesCacheLevel2 | ListSettingsResultItemChallengeTTL | ListSettingsResultItemCiphers | ListSettingsResultItemZonesContentConverter | ListSettingsResultItemZonesCNAMEFlattening | ListSettingsResultItemDevelopmentMode | ListSettingsResultItemEarlyHints | ListSettingsResultItemZonesEdgeCacheTTL2 | ListSettingsResultItemZonesEmailObfuscation2 | ListSettingsResultItemH2Prioritization | ListSettingsResultItemHotlinkProtection | ListSettingsResultItemHTTP2 | ListSettingsResultItemHTTP3 | ListSettingsResultItemImageResizing | ListSettingsResultItemZonesIPGeolocation2 | ListSettingsResultItemIPV6 | ListSettingsResultItemZonesMaxUpload | ListSettingsResultItemMinTLSVersion | ListSettingsResultItemZonesMirage2 | ListSettingsResultItemNEL | ListSettingsResultItemZonesOpportunisticEncryption2 | ListSettingsResultItemOpportunisticOnion | ListSettingsResultItemOrangeToOrange | ListSettingsResultItemZonesOriginErrorPagePassThru2 | ListSettingsResultItemZonesCacheRulesOriginH2MaxStreams | ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersion | ListSettingsResultItemZonesPolish2 | ListSettingsResultItemPrefetchPreload | ListSettingsResultItemZonesPreRender | ListSettingsResultItemZonesPrivacyPass | ListSettingsResultItemProxyReadTimeout | ListSettingsResultItemPseudoIPV4 | ListSettingsResultItemZonesRedirectsForAITraining | ListSettingsResultItemZonesReplaceInsecureJS | ListSettingsResultItemZonesResponseBuffering2 | ListSettingsResultItemZonesRocketLoader2 | ListSettingsResultItemZonesSchemasAutomaticPlatformOptimization | ListSettingsResultItemZonesSearchForAgents | ListSettingsResultItemSecurityHeaders | ListSettingsResultItemZonesSecurityLevel2 | ListSettingsResultItemServerSideExcludes | ListSettingsResultItemZonesSha1Support | ListSettingsResultItemZonesSortQueryStringForCache2 | ListSettingsResultItemZonesSSL2 | ListSettingsResultItemSSLRecommender | ListSettingsResultItemZonesTLS12Only | ListSettingsResultItemTLS13 | ListSettingsResultItemTLSClientAuth | ListSettingsResultItemZonesTransformations | ListSettingsResultItemZonesTransformationsAllowedOrigins | ListSettingsResultItemZonesTrueClientIPHeader2 | ListSettingsResultItemZonesWAF2 | ListSettingsResultItemZonesWebmcpEnabled | ListSettingsResultItemZonesWebmcpMcpURL | ListSettingsResultItemZonesWebmcpPacks | ListSettingsResultItemWebP | ListSettingsResultItemWebsocket;
export type ListSettingsResultList = Array<ListSettingsResultItem>;
export type ListSettingsResponse = ListSettingsResultList;
export interface ListRequestAccount {
    /** Filter by an account ID. */
    id?: string;
    /** An account Name. Optional filter operators can be provided to extend refine the search: */
    name?: string;
}
export type ListRequestDirection = "asc" | "desc";
export type ListRequestMatch = "any" | "all";
export type ListRequestOrder = "name" | "status" | "account.id" | "account.name" | "plan.id";
export type ListRequestStatus = "initializing" | "pending" | "active" | "moved";
export type ListRequestType = "full" | "partial" | "secondary" | "internal";
export type ListRequestTypeList = Array<ListRequestType | (string & {})>;
export interface ListZonesRequest {
    account?: ListRequestAccount;
    /** Direction to order zones. */
    direction?: ListRequestDirection | (string & {});
    /** Whether to match all search requirements or at least one (any). */
    match?: ListRequestMatch | (string & {});
    /** A domain name. Optional filter operators can be provided to extend refine the search: */
    name?: string;
    /** Field to order zones by. */
    order?: ListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of zones per page. */
    perPage?: number;
    /** Specify a zone status to filter by. */
    status?: ListRequestStatus | (string & {});
    /** Zone types to filter by. Multiple types can be specified as a comma-separated list (e.g., ?type=full,partial,secondary). When this parameter is not provided, zones with type "internal" are excluded from the results. */
    type?: ListRequestTypeList;
}
export type ListResultItemAccount = CreateResponseAccount;
export type ListResultItemMeta = CreateResponseMeta;
export type ListResultItemNameServersList = Array<string>;
export type ListResultItemOriginalNameServersList = Array<string>;
export type ListResultItemOwner = CreateResponseOwner;
export type ListResultItemPlan = CreateResponsePlan;
export type ListResultItemPermissionsList = Array<string>;
export type ListResultItemStatus = "initializing" | "pending" | "active" | "moved";
export type ListResultItemTenant = CreateResponseTenant;
export type ListResultItemTenantUnit = CreateResponseTenantUnit;
export type ListResultItemType = "full" | "partial" | "secondary" | "internal";
export type ListResultItemVanityNameServersList = Array<string>;
export interface ListResultItem {
    /** Identifier */
    id: string;
    /** The account the zone belongs to. */
    account: CreateResponseAccount;
    /** The last time proof of ownership was detected and the zone was made active. */
    activatedOn: string;
    /** When the zone was created. */
    createdOn: string;
    /** The interval (in seconds) from when development mode expires (positive integer) or last expired (negative integer) for the domain. If development mode has never been enabled, this value is 0. */
    developmentMode: number;
    /** Metadata about the zone. */
    meta: CreateResponseMeta;
    /** When the zone was last modified. */
    modifiedOn: string;
    /** The domain name. Per [RFC 1035](https://datatracker.ietf.org/doc/html/rfc1035#section-2.3.4) the overall zone name can be up to 253 characters, with each segment ("label") not exceeding 63 characters. */
    name: string;
    /** The name servers Cloudflare assigns to a zone. */
    nameServers: ListResultItemNameServersList;
    /** DNS host at the time of switching to Cloudflare. */
    originalDnshost: string;
    /** Original name servers before moving to Cloudflare. */
    originalNameServers: ListResultItemOriginalNameServersList;
    /** Registrar for the domain at the time of switching to Cloudflare. */
    originalRegistrar: string;
    /** The owner of the zone. */
    owner: CreateResponseOwner;
    /** Please use the `/zones/{zone_id}/subscription` API to update a zone's plan. Changing this value will create/cancel associated subscriptions. To view available plans for this zone, see [Zone Plans](https://developers.cloudflare.com/api/resources/zones/subresources/plans/). */
    plan: CreateResponsePlan;
    /** Allows the customer to use a custom apex. *Tenants Only Configuration*. */
    cnameSuffix?: string | null;
    /** Indicates whether the zone is only using Cloudflare DNS services. A true value means the zone will not receive security or performance benefits. */
    paused?: boolean | null;
    /** This has been replaced by Account memberships. */
    permissions?: ListResultItemPermissionsList | null;
    /** The zone status on Cloudflare. */
    status?: ListResultItemStatus | null;
    /** The root organizational unit that this zone belongs to (such as a tenant or organization). */
    tenant?: CreateResponseTenant | null;
    /** The immediate parent organizational unit that this zone belongs to (such as under a tenant or sub-organization). */
    tenantUnit?: CreateResponseTenantUnit | null;
    /** A full zone implies that DNS is hosted with Cloudflare. A partial zone is typically a partner-hosted zone or a CNAME setup. */
    type?: ListResultItemType | null;
    /** An array of domains used for custom name servers. This is only available for Business and Enterprise plans. */
    vanityNameServers?: ListResultItemVanityNameServersList | null;
    /** Verification key for partial zone setup. */
    verificationKey?: string | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListZonesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type CtAlertingEditRequestEmailsList = Array<string>;
export interface PatchCtAlertingRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether CT alerting is enabled for the zone. */
    enabled: boolean;
    /** Email addresses that receive CT alert notifications for the zone. A maximum of 100 addresses may be configured. Each address must be a valid RFC 5322 email address and must not contain a comma. */
    emails?: CtAlertingEditRequestEmailsList;
}
export type CtAlertingEditResponseEmailsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCtAlertingResponse {
    /** Whether CT alerting is enabled for the zone. */
    enabled: boolean;
    /** Email addresses that receive CT alert notifications for the zone. A maximum of 100 addresses may be configured. Each address must be a valid RFC 5322 email address and must not contain a comma. */
    emails?: CtAlertingEditResponseEmailsList | null;
}
export type EnvironmentsEditRequestEnvironmentsItemPosition = EnvironmentsCreateRequestEnvironmentsItemPosition;
export type EnvironmentsEditRequestEnvironmentsItem = EnvironmentsCreateRequestEnvironmentsItem;
export type EnvironmentsEditRequestEnvironmentsList = Array<EnvironmentsCreateRequestEnvironmentsItem>;
export interface PatchEnvironmentRequest {
    zoneId: string;
    environments: EnvironmentsEditRequestEnvironmentsList;
}
export type EnvironmentsEditResponseEnvironmentsItemPosition = EnvironmentsCreateResponseEnvironmentsItemPosition;
export type EnvironmentsEditResponseEnvironmentsItem = EnvironmentsCreateResponseEnvironmentsItem;
export type EnvironmentsEditResponseEnvironmentsList = Array<EnvironmentsCreateResponseEnvironmentsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchEnvironmentResponse {
    environments: EnvironmentsEditResponseEnvironmentsList;
}
export interface PatchHoldRequest {
    /** Identifier. */
    zoneId: string;
    /** If `hold_after` is provided and future-dated, the hold will be temporarily disabled, then automatically re-enabled by the system at the time specified in this RFC3339-formatted timestamp. A past-dated `hold_after` value will have no effect on an existing, enabled hold. Providing an empty string will set its value to the current time. Providing `null` will disable the hold indefinitely. */
    holdAfter?: string;
    /** If `true`, the zone hold will extend to block any subdomain of the given zone, as well as SSL4SaaS Custom Hostnames. For example, a zone hold on a zone with the hostname 'example.com' and include_subdomains=true will block 'example.com', 'staging.example.com', 'api.staging.example.com', etc. */
    includeSubdomains?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchHoldResponse {
    hold?: boolean | null;
    holdAfter?: string | null;
    includeSubdomains?: unknown | null;
}
export interface PatchSettingRequest {
    /** Identifier */
    zoneId: string;
    /** Setting name */
    settingId: string;
    /** ssl-recommender enrollment setting. */
    enabled?: boolean;
    /** Value of the zone setting. */
    value?: unknown;
}
export type SettingsEditResultZeroRTTId = "0rtt";
export type SettingsEditResultZeroRTTValue = "on" | "off";
export interface SettingsEditResultZeroRTT {
    /** ID of the zone setting. */
    id: SettingsEditResultZeroRTTId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZeroRTTValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultAdvancedDDoSId = "advanced_ddos";
export type SettingsEditResultAdvancedDDoSValue = "on" | "off";
export interface SettingsEditResultAdvancedDDoS {
    /** ID of the zone setting. */
    id: SettingsEditResultAdvancedDDoSId;
    /** Current value of the zone setting. */
    value: SettingsEditResultAdvancedDDoSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesCacheRulesAegisId = "aegis";
export type SettingsEditResultZonesCacheRulesAegisValue = SettingsGetResultZonesCacheRulesAegisValue;
export interface SettingsEditResultZonesCacheRulesAegis {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesCacheRulesAegisId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. */
    value?: SettingsGetResultZonesCacheRulesAegisValue | null;
}
export type SettingsEditResultAlwaysOnlineId = "always_online";
export type SettingsEditResultAlwaysOnlineValue = "on" | "off";
export interface SettingsEditResultAlwaysOnline {
    /** ID of the zone setting. */
    id: SettingsEditResultAlwaysOnlineId;
    /** Current value of the zone setting. */
    value: SettingsEditResultAlwaysOnlineValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesAlwaysUseHTTPS2Id = "always_use_https";
export type SettingsEditResultZonesAlwaysUseHTTPS2Value = "on" | "off";
export interface SettingsEditResultZonesAlwaysUseHTTPS2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesAlwaysUseHTTPS2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesAlwaysUseHTTPS2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesAutomaticHTTPSRewrites2Id = "automatic_https_rewrites";
export type SettingsEditResultZonesAutomaticHTTPSRewrites2Value = "on" | "off";
export interface SettingsEditResultZonesAutomaticHTTPSRewrites2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesAutomaticHTTPSRewrites2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesAutomaticHTTPSRewrites2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultBrotliId = "brotli";
export type SettingsEditResultBrotliValue = "off" | "on";
export interface SettingsEditResultBrotli {
    /** ID of the zone setting. */
    id: SettingsEditResultBrotliId;
    /** Current value of the zone setting. */
    value: SettingsEditResultBrotliValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesBrowserCacheTTL2Id = "browser_cache_ttl";
export interface SettingsEditResultZonesBrowserCacheTTL2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesBrowserCacheTTL2Id;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesBrowserCheck2Id = "browser_check";
export type SettingsEditResultZonesBrowserCheck2Value = "on" | "off";
export interface SettingsEditResultZonesBrowserCheck2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesBrowserCheck2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesBrowserCheck2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesCacheLevel2Id = "cache_level";
export type SettingsEditResultZonesCacheLevel2Value = "aggressive" | "basic" | "simplified";
export interface SettingsEditResultZonesCacheLevel2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesCacheLevel2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesCacheLevel2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultChallengeTTLId = "challenge_ttl";
export type SettingsEditResultChallengeTTLValue = 300 | 900 | 1800 | 2700 | 3600 | 7200 | 10800 | 14400 | 28800 | 57600 | 86400 | 604800 | 2592000 | 31536000;
export interface SettingsEditResultChallengeTTL {
    /** ID of the zone setting. */
    id: SettingsEditResultChallengeTTLId;
    /** Current value of the zone setting. */
    value: SettingsEditResultChallengeTTLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesChinaNetworkEnabledId = "china_network_enabled";
export type SettingsEditResultZonesChinaNetworkEnabledValue = "on" | "off";
export interface SettingsEditResultZonesChinaNetworkEnabled {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesChinaNetworkEnabledId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesChinaNetworkEnabledValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesContentConverterId = "content_converter";
export type SettingsEditResultZonesContentConverterValue = "off" | "on";
export interface SettingsEditResultZonesContentConverter {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesContentConverterId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesContentConverterValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultCiphersId = "ciphers";
export type SettingsEditResultCiphersValueList = Array<string>;
export interface SettingsEditResultCiphers {
    /** ID of the zone setting. */
    id: SettingsEditResultCiphersId;
    /** Current value of the zone setting. */
    value: SettingsEditResultCiphersValueList;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesCNAMEFlatteningId = "cname_flattening";
export type SettingsEditResultZonesCNAMEFlatteningValue = "flatten_at_root" | "flatten_all";
export interface SettingsEditResultZonesCNAMEFlattening {
    /** How to flatten the cname destination. */
    id: SettingsEditResultZonesCNAMEFlatteningId;
    /** This zone setting is deprecated; please use the DNS Settings route instead. More information at https://developers.cloudflare.com/fundamentals/api/reference/deprecations/#2025-03-21 */
    value: SettingsEditResultZonesCNAMEFlatteningValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultDevelopmentModeId = "development_mode";
export type SettingsEditResultDevelopmentModeValue = "on" | "off";
export interface SettingsEditResultDevelopmentMode {
    /** ID of the zone setting. */
    id: SettingsEditResultDevelopmentModeId;
    /** Current value of the zone setting. */
    value: SettingsEditResultDevelopmentModeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. Notes: The interval (in seconds) from when development mode expires (positive integer) or last expired (negative integer) for the domain. If development mode has never been enabled, this value is false. */
    timeRemaining?: number | null;
}
export type SettingsEditResultEarlyHintsId = "early_hints";
export type SettingsEditResultEarlyHintsValue = "on" | "off";
export interface SettingsEditResultEarlyHints {
    /** ID of the zone setting. */
    id: SettingsEditResultEarlyHintsId;
    /** Current value of the zone setting. */
    value: SettingsEditResultEarlyHintsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesEdgeCacheTTL2Id = "edge_cache_ttl";
export type SettingsEditResultZonesEdgeCacheTTL2Value = 30 | 60 | 300 | 1200 | 1800 | 3600 | 7200 | 10800 | 14400 | 18000 | 28800 | 43200 | 57600 | 72000 | 86400 | 172800 | 259200 | 345600 | 432000 | 518400 | 604800;
export interface SettingsEditResultZonesEdgeCacheTTL2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesEdgeCacheTTL2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesEdgeCacheTTL2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesEmailObfuscation2Id = "email_obfuscation";
export type SettingsEditResultZonesEmailObfuscation2Value = "on" | "off";
export interface SettingsEditResultZonesEmailObfuscation2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesEmailObfuscation2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesEmailObfuscation2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultH2PrioritizationId = "h2_prioritization";
export type SettingsEditResultH2PrioritizationValue = "on" | "off" | "custom";
export interface SettingsEditResultH2Prioritization {
    /** ID of the zone setting. */
    id: SettingsEditResultH2PrioritizationId;
    /** Current value of the zone setting. */
    value: SettingsEditResultH2PrioritizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultHotlinkProtectionId = "hotlink_protection";
export type SettingsEditResultHotlinkProtectionValue = "on" | "off";
export interface SettingsEditResultHotlinkProtection {
    /** ID of the zone setting. */
    id: SettingsEditResultHotlinkProtectionId;
    /** Current value of the zone setting. */
    value: SettingsEditResultHotlinkProtectionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultHTTP2Id = "http2";
export type SettingsEditResultHTTP2Value = "on" | "off";
export interface SettingsEditResultHTTP2 {
    /** ID of the zone setting. */
    id: SettingsEditResultHTTP2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultHTTP2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultHTTP3Id = "http3";
export type SettingsEditResultHTTP3Value = "on" | "off";
export interface SettingsEditResultHTTP3 {
    /** ID of the zone setting. */
    id: SettingsEditResultHTTP3Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultHTTP3Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultImageResizingId = "image_resizing";
export type SettingsEditResultImageResizingValue = "on" | "off" | "open";
export interface SettingsEditResultImageResizing {
    /** ID of the zone setting. */
    id: SettingsEditResultImageResizingId;
    /** Current value of the zone setting. */
    value: SettingsEditResultImageResizingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesIPGeolocation2Id = "ip_geolocation";
export type SettingsEditResultZonesIPGeolocation2Value = "on" | "off";
export interface SettingsEditResultZonesIPGeolocation2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesIPGeolocation2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesIPGeolocation2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultIPV6Id = "ipv6";
export type SettingsEditResultIPV6Value = "off" | "on";
export interface SettingsEditResultIPV6 {
    /** ID of the zone setting. */
    id: SettingsEditResultIPV6Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultIPV6Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesMaxUploadId = "max_upload";
export type SettingsEditResultZonesMaxUploadValue = 100 | 125 | 150 | 175 | 200 | 225 | 250 | 275 | 300 | 325 | 350 | 375 | 400 | 425 | 450 | 475 | 500 | 1000 | 1500 | 2000 | 2500 | 3000 | 3500 | 4000 | 4500 | 5000;
export interface SettingsEditResultZonesMaxUpload {
    /** identifier of the zone setting. */
    id: SettingsEditResultZonesMaxUploadId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesMaxUploadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultMinTLSVersionId = "min_tls_version";
export type SettingsEditResultMinTLSVersionValue = "1.0" | "1.1" | "1.2" | "1.3";
export interface SettingsEditResultMinTLSVersion {
    /** ID of the zone setting. */
    id: SettingsEditResultMinTLSVersionId;
    /** Current value of the zone setting. */
    value: SettingsEditResultMinTLSVersionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesMirage2Id = "mirage";
export type SettingsEditResultZonesMirage2Value = "on" | "off";
export interface SettingsEditResultZonesMirage2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesMirage2Id;
    /** Mirage is being deprecated. More information at https://developers.cloudflare.com/speed/optimization/images/mirage/ */
    value: SettingsEditResultZonesMirage2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultNELId = "nel";
export type SettingsEditResultNELValue = SettingsGetResultNELValue;
export interface SettingsEditResultNEL {
    /** Zone setting identifier. */
    id: SettingsEditResultNELId;
    /** Current value of the zone setting. */
    value: SettingsGetResultNELValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesOpportunisticEncryption2Id = "opportunistic_encryption";
export type SettingsEditResultZonesOpportunisticEncryption2Value = "on" | "off";
export interface SettingsEditResultZonesOpportunisticEncryption2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesOpportunisticEncryption2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesOpportunisticEncryption2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultOpportunisticOnionId = "opportunistic_onion";
export type SettingsEditResultOpportunisticOnionValue = "on" | "off";
export interface SettingsEditResultOpportunisticOnion {
    /** ID of the zone setting. */
    id: SettingsEditResultOpportunisticOnionId;
    /** Current value of the zone setting. */
    value: SettingsEditResultOpportunisticOnionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultOrangeToOrangeId = "orange_to_orange";
export type SettingsEditResultOrangeToOrangeValue = "on" | "off";
export interface SettingsEditResultOrangeToOrange {
    /** ID of the zone setting. */
    id: SettingsEditResultOrangeToOrangeId;
    /** This setting is deprecated. Orange to Orange (O2O) is applied automatically for eligible zones and no longer requires configuration; this setting only controlled the legacy O2O v1 (Managed CNAME) path. More information at https://developers.cloudflare.com/fundamentals/api/reference/deprecations/ */
    value: SettingsEditResultOrangeToOrangeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesOriginErrorPagePassThru2Id = "origin_error_page_pass_thru";
export type SettingsEditResultZonesOriginErrorPagePassThru2Value = "on" | "off";
export interface SettingsEditResultZonesOriginErrorPagePassThru2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesOriginErrorPagePassThru2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesOriginErrorPagePassThru2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesCacheRulesOriginH2MaxStreamsId = "origin_h2_max_streams";
export interface SettingsEditResultZonesCacheRulesOriginH2MaxStreams {
    /** Value of the zone setting. */
    id: SettingsEditResultZonesCacheRulesOriginH2MaxStreamsId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin H2 Max Streams Setting. */
    value?: number | null;
}
export type SettingsEditResultZonesCacheRulesOriginMaxHTTPVersionId = "origin_max_http_version";
export type SettingsEditResultZonesCacheRulesOriginMaxHTTPVersionValue = "2" | "1";
export interface SettingsEditResultZonesCacheRulesOriginMaxHTTPVersion {
    /** Value of the zone setting. */
    id: SettingsEditResultZonesCacheRulesOriginMaxHTTPVersionId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin Max HTTP Version Setting. */
    value?: SettingsEditResultZonesCacheRulesOriginMaxHTTPVersionValue | null;
}
export type SettingsEditResultZonesPolish2Id = "polish";
export type SettingsEditResultZonesPolish2Value = "off" | "lossless" | "lossy";
export interface SettingsEditResultZonesPolish2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesPolish2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesPolish2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultPrefetchPreloadId = "prefetch_preload";
export type SettingsEditResultPrefetchPreloadValue = "on" | "off";
export interface SettingsEditResultPrefetchPreload {
    /** ID of the zone setting. */
    id: SettingsEditResultPrefetchPreloadId;
    /** Current value of the zone setting. */
    value: SettingsEditResultPrefetchPreloadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesPreRenderId = "pre_render";
export type SettingsEditResultZonesPreRenderValue = "off" | "on";
export interface SettingsEditResultZonesPreRender {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesPreRenderId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesPreRenderValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesPrivacyPassId = "privacy_pass";
export type SettingsEditResultZonesPrivacyPassValue = "on" | "off";
export interface SettingsEditResultZonesPrivacyPass {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesPrivacyPassId;
    /** Privacy Pass v1 was deprecated in 2023. (Announcement - https://blog.cloudflare.com/privacy-pass-standard/) and (API deprecation details - https://developers.cloudflare.com/fundamentals/api/reference/deprecations/#2024-03-31) */
    value: SettingsEditResultZonesPrivacyPassValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultProxyReadTimeoutId = "proxy_read_timeout";
export interface SettingsEditResultProxyReadTimeout {
    /** ID of the zone setting. */
    id: SettingsEditResultProxyReadTimeoutId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultPseudoIPV4Id = "pseudo_ipv4";
export type SettingsEditResultPseudoIPV4Value = "off" | "add_header" | "overwrite_header";
export interface SettingsEditResultPseudoIPV4 {
    /** Value of the Pseudo IPv4 setting. */
    id: SettingsEditResultPseudoIPV4Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultPseudoIPV4Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesRedirectsForAITrainingId = "redirects_for_ai_training";
export type SettingsEditResultZonesRedirectsForAITrainingValue = "off" | "on";
export interface SettingsEditResultZonesRedirectsForAITraining {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesRedirectsForAITrainingId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesRedirectsForAITrainingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesReplaceInsecureJSId = "replace_insecure_js";
export type SettingsEditResultZonesReplaceInsecureJSValue = "on" | "off";
export interface SettingsEditResultZonesReplaceInsecureJS {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesReplaceInsecureJSId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesReplaceInsecureJSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesResponseBuffering2Id = "response_buffering";
export type SettingsEditResultZonesResponseBuffering2Value = "on" | "off";
export interface SettingsEditResultZonesResponseBuffering2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesResponseBuffering2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesResponseBuffering2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesRocketLoader2Id = "rocket_loader";
export type SettingsEditResultZonesRocketLoader2Value = "on" | "off";
export interface SettingsEditResultZonesRocketLoader2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesRocketLoader2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesRocketLoader2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesSchemasAutomaticPlatformOptimizationId = "automatic_platform_optimization";
export type SettingsEditResultZonesSchemasAutomaticPlatformOptimizationValueHostnamesList = Array<string>;
export interface SettingsEditResultZonesSchemasAutomaticPlatformOptimizationValue {
    /** Indicates whether or not [cache by device type](https://developers.cloudflare.com/automatic-platform-optimization/reference/cache-device-type/) is enabled. */
    cacheByDeviceType: boolean;
    /** Indicates whether or not Cloudflare proxy is enabled. */
    cf: boolean;
    /** Indicates whether or not Automatic Platform Optimization is enabled. */
    enabled: boolean;
    /** An array of hostnames where Automatic Platform Optimization for WordPress is activated. */
    hostnames: SettingsEditResultZonesSchemasAutomaticPlatformOptimizationValueHostnamesList;
    /** Indicates whether or not site is powered by WordPress. */
    wordpress: boolean;
    /** Indicates whether or not [Cloudflare for WordPress plugin](https://wordpress.org/plugins/cloudflare/) is installed. */
    wpPlugin: boolean;
}
export interface SettingsEditResultZonesSchemasAutomaticPlatformOptimization {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasAutomaticPlatformOptimizationId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasAutomaticPlatformOptimizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesSearchForAgentsId = "search_for_agents";
export type SettingsEditResultZonesSearchForAgentsValue = "off" | "on";
export interface SettingsEditResultZonesSearchForAgents {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSearchForAgentsId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSearchForAgentsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultSecurityHeadersId = "security_header";
export type SettingsEditResultSecurityHeadersValueStrictTransportSecurity = SettingsGetResultSecurityHeadersValueStrictTransportSecurity;
export type SettingsEditResultSecurityHeadersValue = SettingsGetResultSecurityHeadersValue;
export interface SettingsEditResultSecurityHeaders {
    /** ID of the zone's security header. */
    id: SettingsEditResultSecurityHeadersId;
    /** Current value of the zone setting. */
    value: SettingsGetResultSecurityHeadersValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesSecurityLevel2Id = "security_level";
export type SettingsEditResultZonesSecurityLevel2Value = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface SettingsEditResultZonesSecurityLevel2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSecurityLevel2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSecurityLevel2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultServerSideExcludesId = "server_side_exclude";
export type SettingsEditResultServerSideExcludesValue = "on" | "off";
export interface SettingsEditResultServerSideExcludes {
    /** ID of the zone setting. */
    id: SettingsEditResultServerSideExcludesId;
    /** Current value of the zone setting. */
    value: SettingsEditResultServerSideExcludesValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesSha1SupportId = "sha1_support";
export type SettingsEditResultZonesSha1SupportValue = "off" | "on";
export interface SettingsEditResultZonesSha1Support {
    /** Zone setting identifier. */
    id: SettingsEditResultZonesSha1SupportId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSha1SupportValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesSortQueryStringForCache2Id = "sort_query_string_for_cache";
export type SettingsEditResultZonesSortQueryStringForCache2Value = "on" | "off";
export interface SettingsEditResultZonesSortQueryStringForCache2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSortQueryStringForCache2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSortQueryStringForCache2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesSSL2Id = "ssl";
export type SettingsEditResultZonesSSL2Value = "off" | "flexible" | "full" | "strict";
export interface SettingsEditResultZonesSSL2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSSL2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSSL2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultSSLRecommenderId = "ssl_recommender";
export interface SettingsEditResultSSLRecommender {
    /** Enrollment value for SSL/TLS Recommender. */
    id?: SettingsEditResultSSLRecommenderId | null;
    /** ssl-recommender enrollment setting. */
    enabled?: boolean | null;
}
export type SettingsEditResultZonesTLS12OnlyId = "tls_1_2_only";
export type SettingsEditResultZonesTLS12OnlyValue = "off" | "on";
export interface SettingsEditResultZonesTLS12Only {
    /** Zone setting identifier. */
    id: SettingsEditResultZonesTLS12OnlyId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesTLS12OnlyValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultTLS13Id = "tls_1_3";
export type SettingsEditResultTLS13Value = "on" | "off" | "zrt";
export interface SettingsEditResultTLS13 {
    /** ID of the zone setting. */
    id: SettingsEditResultTLS13Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultTLS13Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultTLSClientAuthId = "tls_client_auth";
export type SettingsEditResultTLSClientAuthValue = "on" | "off";
export interface SettingsEditResultTLSClientAuth {
    /** ID of the zone setting. */
    id: SettingsEditResultTLSClientAuthId;
    /** Current value of the zone setting. */
    value: SettingsEditResultTLSClientAuthValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesTransformationsId = "transformations";
export type SettingsEditResultZonesTransformationsValue = "on" | "off" | "open";
export interface SettingsEditResultZonesTransformations {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: SettingsEditResultZonesTransformationsId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesTransformationsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesTransformationsAllowedOriginsId = "transformations_allowed_origins";
export interface SettingsEditResultZonesTransformationsAllowedOrigins {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: SettingsEditResultZonesTransformationsAllowedOriginsId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesTrueClientIPHeader2Id = "true_client_ip_header";
export type SettingsEditResultZonesTrueClientIPHeader2Value = "on" | "off";
export interface SettingsEditResultZonesTrueClientIPHeader2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesTrueClientIPHeader2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesTrueClientIPHeader2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesWAF2Id = "waf";
export type SettingsEditResultZonesWAF2Value = "on" | "off";
export interface SettingsEditResultZonesWAF2 {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesWAF2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesWAF2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesWebmcpEnabledId = "webmcp_enabled";
export type SettingsEditResultZonesWebmcpEnabledValue = "off" | "on";
export interface SettingsEditResultZonesWebmcpEnabled {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesWebmcpEnabledId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesWebmcpEnabledValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesWebmcpMcpURLId = "webmcp_mcp_url";
export interface SettingsEditResultZonesWebmcpMcpURL {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesWebmcpMcpURLId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultZonesWebmcpPacksId = "webmcp_packs";
export interface SettingsEditResultZonesWebmcpPacks {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesWebmcpPacksId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultWebPId = "webp";
export type SettingsEditResultWebPValue = "off" | "on";
export interface SettingsEditResultWebP {
    /** ID of the zone setting. */
    id: SettingsEditResultWebPId;
    /** Current value of the zone setting. */
    value: SettingsEditResultWebPValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResultWebsocketId = "websockets";
export type SettingsEditResultWebsocketValue = "off" | "on";
export interface SettingsEditResultWebsocket {
    /** ID of the zone setting. */
    id: SettingsEditResultWebsocketId;
    /** Current value of the zone setting. */
    value: SettingsEditResultWebsocketValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsEditResult = SettingsEditResultZeroRTT | SettingsEditResultAdvancedDDoS | SettingsEditResultZonesCacheRulesAegis | SettingsEditResultAlwaysOnline | SettingsEditResultZonesAlwaysUseHTTPS2 | SettingsEditResultZonesAutomaticHTTPSRewrites2 | SettingsEditResultBrotli | SettingsEditResultZonesBrowserCacheTTL2 | SettingsEditResultZonesBrowserCheck2 | SettingsEditResultZonesCacheLevel2 | SettingsEditResultChallengeTTL | SettingsEditResultZonesChinaNetworkEnabled | SettingsEditResultZonesContentConverter | SettingsEditResultCiphers | SettingsEditResultZonesCNAMEFlattening | SettingsEditResultDevelopmentMode | SettingsEditResultEarlyHints | SettingsEditResultZonesEdgeCacheTTL2 | SettingsEditResultZonesEmailObfuscation2 | SettingsEditResultH2Prioritization | SettingsEditResultHotlinkProtection | SettingsEditResultHTTP2 | SettingsEditResultHTTP3 | SettingsEditResultImageResizing | SettingsEditResultZonesIPGeolocation2 | SettingsEditResultIPV6 | SettingsEditResultZonesMaxUpload | SettingsEditResultMinTLSVersion | SettingsEditResultZonesMirage2 | SettingsEditResultNEL | SettingsEditResultZonesOpportunisticEncryption2 | SettingsEditResultOpportunisticOnion | SettingsEditResultOrangeToOrange | SettingsEditResultZonesOriginErrorPagePassThru2 | SettingsEditResultZonesCacheRulesOriginH2MaxStreams | SettingsEditResultZonesCacheRulesOriginMaxHTTPVersion | SettingsEditResultZonesPolish2 | SettingsEditResultPrefetchPreload | SettingsEditResultZonesPreRender | SettingsEditResultZonesPrivacyPass | SettingsEditResultProxyReadTimeout | SettingsEditResultPseudoIPV4 | SettingsEditResultZonesRedirectsForAITraining | SettingsEditResultZonesReplaceInsecureJS | SettingsEditResultZonesResponseBuffering2 | SettingsEditResultZonesRocketLoader2 | SettingsEditResultZonesSchemasAutomaticPlatformOptimization | SettingsEditResultZonesSearchForAgents | SettingsEditResultSecurityHeaders | SettingsEditResultZonesSecurityLevel2 | SettingsEditResultServerSideExcludes | SettingsEditResultZonesSha1Support | SettingsEditResultZonesSortQueryStringForCache2 | SettingsEditResultZonesSSL2 | SettingsEditResultSSLRecommender | SettingsEditResultZonesTLS12Only | SettingsEditResultTLS13 | SettingsEditResultTLSClientAuth | SettingsEditResultZonesTransformations | SettingsEditResultZonesTransformationsAllowedOrigins | SettingsEditResultZonesTrueClientIPHeader2 | SettingsEditResultZonesWAF2 | SettingsEditResultZonesWebmcpEnabled | SettingsEditResultZonesWebmcpMcpURL | SettingsEditResultZonesWebmcpPacks | SettingsEditResultWebP | SettingsEditResultWebsocket;
export type PatchSettingResponse = SettingsEditResult;
export type EditRequestType = "full" | "partial" | "secondary" | "internal";
export type EditRequestVanityNameServersList = Array<string>;
export interface PatchZoneRequest {
    /** Identifier */
    zoneId: string;
    /** Indicates whether the zone is only using Cloudflare DNS services. A true value means the zone will not receive security or performance benefits. */
    paused?: boolean;
    /** A full zone implies that DNS is hosted with Cloudflare. A partial zone is typically a partner-hosted zone or a CNAME setup. This parameter is only available to Enterprise customers or if it has been explicitly enabled on a zone. */
    type?: EditRequestType | (string & {});
    /** An array of domains used for custom name servers. This is only available for Business and Enterprise plans. */
    vanityNameServers?: EditRequestVanityNameServersList;
}
export type EditResponseAccount = CreateResponseAccount;
export type EditResponseMeta = CreateResponseMeta;
export type EditResponseNameServersList = Array<string>;
export type EditResponseOriginalNameServersList = Array<string>;
export type EditResponseOwner = CreateResponseOwner;
export type EditResponsePlan = CreateResponsePlan;
export type EditResponsePermissionsList = Array<string>;
export type EditResponseStatus = "initializing" | "pending" | "active" | "moved";
export type EditResponseTenant = CreateResponseTenant;
export type EditResponseTenantUnit = CreateResponseTenantUnit;
export type EditResponseType = "full" | "partial" | "secondary" | "internal";
export type EditResponseVanityNameServersList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchZoneResponse {
    /** Identifier */
    id: string;
    /** The account the zone belongs to. */
    account: CreateResponseAccount;
    /** The last time proof of ownership was detected and the zone was made active. */
    activatedOn: string;
    /** When the zone was created. */
    createdOn: string;
    /** The interval (in seconds) from when development mode expires (positive integer) or last expired (negative integer) for the domain. If development mode has never been enabled, this value is 0. */
    developmentMode: number;
    /** Metadata about the zone. */
    meta: CreateResponseMeta;
    /** When the zone was last modified. */
    modifiedOn: string;
    /** The domain name. Per [RFC 1035](https://datatracker.ietf.org/doc/html/rfc1035#section-2.3.4) the overall zone name can be up to 253 characters, with each segment ("label") not exceeding 63 characters. */
    name: string;
    /** The name servers Cloudflare assigns to a zone. */
    nameServers: EditResponseNameServersList;
    /** DNS host at the time of switching to Cloudflare. */
    originalDnshost: string;
    /** Original name servers before moving to Cloudflare. */
    originalNameServers: EditResponseOriginalNameServersList;
    /** Registrar for the domain at the time of switching to Cloudflare. */
    originalRegistrar: string;
    /** The owner of the zone. */
    owner: CreateResponseOwner;
    /** Please use the `/zones/{zone_id}/subscription` API to update a zone's plan. Changing this value will create/cancel associated subscriptions. To view available plans for this zone, see [Zone Plans](https://developers.cloudflare.com/api/resources/zones/subresources/plans/). */
    plan: CreateResponsePlan;
    /** Allows the customer to use a custom apex. *Tenants Only Configuration*. */
    cnameSuffix?: string | null;
    /** Indicates whether the zone is only using Cloudflare DNS services. A true value means the zone will not receive security or performance benefits. */
    paused?: boolean | null;
    /** This has been replaced by Account memberships. */
    permissions?: EditResponsePermissionsList | null;
    /** The zone status on Cloudflare. */
    status?: EditResponseStatus | null;
    /** The root organizational unit that this zone belongs to (such as a tenant or organization). */
    tenant?: CreateResponseTenant | null;
    /** The immediate parent organizational unit that this zone belongs to (such as under a tenant or sub-organization). */
    tenantUnit?: CreateResponseTenantUnit | null;
    /** A full zone implies that DNS is hosted with Cloudflare. A partial zone is typically a partner-hosted zone or a CNAME setup. */
    type?: EditResponseType | null;
    /** An array of domains used for custom name servers. This is only available for Business and Enterprise plans. */
    vanityNameServers?: EditResponseVanityNameServersList | null;
    /** Verification key for partial zone setup. */
    verificationKey?: string | null;
}
export interface PutCustomNameserverRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether zone uses account-level custom nameservers. */
    enabled?: boolean;
    /** The number of the name server set to assign to the zone. */
    nsSet?: number;
}
export type CustomNameserversUpdateResultList = Array<string>;
export interface PutCustomNameserverResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CustomNameserversUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface RollbackEnvironmentRequest {
    zoneId: string;
    environmentId: string;
}
export type EnvironmentsRollbackResponseEnvironmentsItemPosition = EnvironmentsCreateResponseEnvironmentsItemPosition;
export type EnvironmentsRollbackResponseEnvironmentsItem = EnvironmentsCreateResponseEnvironmentsItem;
export type EnvironmentsRollbackResponseEnvironmentsList = Array<EnvironmentsCreateResponseEnvironmentsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RollbackEnvironmentResponse {
    environments: EnvironmentsRollbackResponseEnvironmentsList;
}
export type SettingsBulkEditRequestBodyItemZeroRTTId = "0rtt";
export type SettingsBulkEditRequestBodyItemZeroRTTValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZeroRTT {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZeroRTTId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZeroRTTValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemAdvancedDDoSId = "advanced_ddos";
export type SettingsBulkEditRequestBodyItemAdvancedDDoSValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemAdvancedDDoS {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemAdvancedDDoSId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemAdvancedDDoSValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesCacheRulesAegisId = "aegis";
export interface SettingsBulkEditRequestBodyItemZonesCacheRulesAegisValue {
    /** Whether the feature is enabled or not. */
    enabled?: boolean;
    /** Egress pool id which refers to a grouping of dedicated egress IPs through which Cloudflare will connect to origin. */
    poolId?: string;
}
export interface SettingsBulkEditRequestBodyItemZonesCacheRulesAegis {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesCacheRulesAegisId;
    /** Last time this setting was modified. */
    modifiedOn?: string;
    /** Value of the zone setting. */
    value?: SettingsBulkEditRequestBodyItemZonesCacheRulesAegisValue;
}
export type SettingsBulkEditRequestBodyItemAlwaysOnlineId = "always_online";
export type SettingsBulkEditRequestBodyItemAlwaysOnlineValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemAlwaysOnline {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemAlwaysOnlineId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemAlwaysOnlineValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesAlwaysUseHTTPS2Id = "always_use_https";
export type SettingsBulkEditRequestBodyItemZonesAlwaysUseHTTPS2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesAlwaysUseHTTPS2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesAlwaysUseHTTPS2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesAlwaysUseHTTPS2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesAutomaticHTTPSRewrites2Id = "automatic_https_rewrites";
export type SettingsBulkEditRequestBodyItemZonesAutomaticHTTPSRewrites2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesAutomaticHTTPSRewrites2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesAutomaticHTTPSRewrites2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesAutomaticHTTPSRewrites2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemBrotliId = "brotli";
export type SettingsBulkEditRequestBodyItemBrotliValue = "off" | "on";
export interface SettingsBulkEditRequestBodyItemBrotli {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemBrotliId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemBrotliValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesBrowserCacheTTL2Id = "browser_cache_ttl";
export interface SettingsBulkEditRequestBodyItemZonesBrowserCacheTTL2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesBrowserCacheTTL2Id;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesBrowserCheck2Id = "browser_check";
export type SettingsBulkEditRequestBodyItemZonesBrowserCheck2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesBrowserCheck2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesBrowserCheck2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesBrowserCheck2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesCacheLevel2Id = "cache_level";
export type SettingsBulkEditRequestBodyItemZonesCacheLevel2Value = "aggressive" | "basic" | "simplified";
export interface SettingsBulkEditRequestBodyItemZonesCacheLevel2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesCacheLevel2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesCacheLevel2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemChallengeTTLId = "challenge_ttl";
export type SettingsBulkEditRequestBodyItemChallengeTTLValue = 300 | 900 | 1800 | 2700 | 3600 | 7200 | 10800 | 14400 | 28800 | 57600 | 86400 | 604800 | 2592000 | 31536000;
export interface SettingsBulkEditRequestBodyItemChallengeTTL {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemChallengeTTLId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemChallengeTTLValue | (number & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabledId = "china_network_enabled";
export type SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabledValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabled {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabledId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabledValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesContentConverterId = "content_converter";
export type SettingsBulkEditRequestBodyItemZonesContentConverterValue = "off" | "on";
export interface SettingsBulkEditRequestBodyItemZonesContentConverter {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesContentConverterId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesContentConverterValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemCiphersId = "ciphers";
export type SettingsBulkEditRequestBodyItemCiphersValueList = Array<string>;
export interface SettingsBulkEditRequestBodyItemCiphers {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemCiphersId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemCiphersValueList;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesCNAMEFlatteningId = "cname_flattening";
export type SettingsBulkEditRequestBodyItemZonesCNAMEFlatteningValue = "flatten_at_root" | "flatten_all";
export interface SettingsBulkEditRequestBodyItemZonesCNAMEFlattening {
    /** How to flatten the cname destination. */
    id: SettingsBulkEditRequestBodyItemZonesCNAMEFlatteningId;
    /** This zone setting is deprecated; please use the DNS Settings route instead. More information at https://developers.cloudflare.com/fundamentals/api/reference/deprecations/#2025-03-21 */
    value: SettingsBulkEditRequestBodyItemZonesCNAMEFlatteningValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemDevelopmentModeId = "development_mode";
export type SettingsBulkEditRequestBodyItemDevelopmentModeValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemDevelopmentMode {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemDevelopmentModeId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemDevelopmentModeValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
    /** Value of the zone setting. Notes: The interval (in seconds) from when development mode expires (positive integer) or last expired (negative integer) for the domain. If development mode has never been enabled, this value is false. */
    timeRemaining?: number;
}
export type SettingsBulkEditRequestBodyItemEarlyHintsId = "early_hints";
export type SettingsBulkEditRequestBodyItemEarlyHintsValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemEarlyHints {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemEarlyHintsId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemEarlyHintsValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesEdgeCacheTTL2Id = "edge_cache_ttl";
export type SettingsBulkEditRequestBodyItemZonesEdgeCacheTTL2Value = 30 | 60 | 300 | 1200 | 1800 | 3600 | 7200 | 10800 | 14400 | 18000 | 28800 | 43200 | 57600 | 72000 | 86400 | 172800 | 259200 | 345600 | 432000 | 518400 | 604800;
export interface SettingsBulkEditRequestBodyItemZonesEdgeCacheTTL2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesEdgeCacheTTL2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesEdgeCacheTTL2Value | (number & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesEmailObfuscation2Id = "email_obfuscation";
export type SettingsBulkEditRequestBodyItemZonesEmailObfuscation2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesEmailObfuscation2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesEmailObfuscation2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesEmailObfuscation2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemH2PrioritizationId = "h2_prioritization";
export type SettingsBulkEditRequestBodyItemH2PrioritizationValue = "on" | "off" | "custom";
export interface SettingsBulkEditRequestBodyItemH2Prioritization {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemH2PrioritizationId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemH2PrioritizationValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemHotlinkProtectionId = "hotlink_protection";
export type SettingsBulkEditRequestBodyItemHotlinkProtectionValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemHotlinkProtection {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemHotlinkProtectionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemHotlinkProtectionValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemHTTP2Id = "http2";
export type SettingsBulkEditRequestBodyItemHTTP2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemHTTP2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemHTTP2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemHTTP2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemHTTP3Id = "http3";
export type SettingsBulkEditRequestBodyItemHTTP3Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemHTTP3 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemHTTP3Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemHTTP3Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesIPGeolocation2Id = "ip_geolocation";
export type SettingsBulkEditRequestBodyItemZonesIPGeolocation2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesIPGeolocation2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesIPGeolocation2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesIPGeolocation2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemIPV6Id = "ipv6";
export type SettingsBulkEditRequestBodyItemIPV6Value = "off" | "on";
export interface SettingsBulkEditRequestBodyItemIPV6 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemIPV6Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemIPV6Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesMaxUploadId = "max_upload";
export type SettingsBulkEditRequestBodyItemZonesMaxUploadValue = 100 | 125 | 150 | 175 | 200 | 225 | 250 | 275 | 300 | 325 | 350 | 375 | 400 | 425 | 450 | 475 | 500 | 1000 | 1500 | 2000 | 2500 | 3000 | 3500 | 4000 | 4500 | 5000;
export interface SettingsBulkEditRequestBodyItemZonesMaxUpload {
    /** identifier of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesMaxUploadId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesMaxUploadValue | (number & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemMinTLSVersionId = "min_tls_version";
export type SettingsBulkEditRequestBodyItemMinTLSVersionValue = "1.0" | "1.1" | "1.2" | "1.3";
export interface SettingsBulkEditRequestBodyItemMinTLSVersion {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemMinTLSVersionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemMinTLSVersionValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesMirage2Id = "mirage";
export type SettingsBulkEditRequestBodyItemZonesMirage2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesMirage2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesMirage2Id;
    /** Mirage is being deprecated. More information at https://developers.cloudflare.com/speed/optimization/images/mirage/ */
    value: SettingsBulkEditRequestBodyItemZonesMirage2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemNELId = "nel";
export interface SettingsBulkEditRequestBodyItemNELValue {
    enabled?: boolean;
}
export interface SettingsBulkEditRequestBodyItemNEL {
    /** Zone setting identifier. */
    id: SettingsBulkEditRequestBodyItemNELId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemNELValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesOpportunisticEncryption2Id = "opportunistic_encryption";
export type SettingsBulkEditRequestBodyItemZonesOpportunisticEncryption2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesOpportunisticEncryption2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesOpportunisticEncryption2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesOpportunisticEncryption2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemOpportunisticOnionId = "opportunistic_onion";
export type SettingsBulkEditRequestBodyItemOpportunisticOnionValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemOpportunisticOnion {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemOpportunisticOnionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemOpportunisticOnionValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemOrangeToOrangeId = "orange_to_orange";
export type SettingsBulkEditRequestBodyItemOrangeToOrangeValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemOrangeToOrange {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemOrangeToOrangeId;
    /** This setting is deprecated. Orange to Orange (O2O) is applied automatically for eligible zones and no longer requires configuration; this setting only controlled the legacy O2O v1 (Managed CNAME) path. More information at https://developers.cloudflare.com/fundamentals/api/reference/deprecations/ */
    value: SettingsBulkEditRequestBodyItemOrangeToOrangeValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesOriginErrorPagePassThru2Id = "origin_error_page_pass_thru";
export type SettingsBulkEditRequestBodyItemZonesOriginErrorPagePassThru2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesOriginErrorPagePassThru2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesOriginErrorPagePassThru2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesOriginErrorPagePassThru2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesCacheRulesOriginH2MaxStreamsId = "origin_h2_max_streams";
export interface SettingsBulkEditRequestBodyItemZonesCacheRulesOriginH2MaxStreams {
    /** Value of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesCacheRulesOriginH2MaxStreamsId;
    /** Last time this setting was modified. */
    modifiedOn?: string;
    /** Value of the Origin H2 Max Streams Setting. */
    value?: number;
}
export type SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersionId = "origin_max_http_version";
export type SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersionValue = "2" | "1";
export interface SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersion {
    /** Value of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersionId;
    /** Last time this setting was modified. */
    modifiedOn?: string;
    /** Value of the Origin Max HTTP Version Setting. */
    value?: SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersionValue | (string & {});
}
export type SettingsBulkEditRequestBodyItemZonesPolish2Id = "polish";
export type SettingsBulkEditRequestBodyItemZonesPolish2Value = "off" | "lossless" | "lossy";
export interface SettingsBulkEditRequestBodyItemZonesPolish2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesPolish2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesPolish2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemPrefetchPreloadId = "prefetch_preload";
export type SettingsBulkEditRequestBodyItemPrefetchPreloadValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemPrefetchPreload {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemPrefetchPreloadId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemPrefetchPreloadValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesPreRenderId = "pre_render";
export type SettingsBulkEditRequestBodyItemZonesPreRenderValue = "off" | "on";
export interface SettingsBulkEditRequestBodyItemZonesPreRender {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesPreRenderId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesPreRenderValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesPrivacyPassId = "privacy_pass";
export type SettingsBulkEditRequestBodyItemZonesPrivacyPassValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesPrivacyPass {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesPrivacyPassId;
    /** Privacy Pass v1 was deprecated in 2023. (Announcement - https://blog.cloudflare.com/privacy-pass-standard/) and (API deprecation details - https://developers.cloudflare.com/fundamentals/api/reference/deprecations/#2024-03-31) */
    value: SettingsBulkEditRequestBodyItemZonesPrivacyPassValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemProxyReadTimeoutId = "proxy_read_timeout";
export interface SettingsBulkEditRequestBodyItemProxyReadTimeout {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemProxyReadTimeoutId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemPseudoIPV4Id = "pseudo_ipv4";
export type SettingsBulkEditRequestBodyItemPseudoIPV4Value = "off" | "add_header" | "overwrite_header";
export interface SettingsBulkEditRequestBodyItemPseudoIPV4 {
    /** Value of the Pseudo IPv4 setting. */
    id: SettingsBulkEditRequestBodyItemPseudoIPV4Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemPseudoIPV4Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesRedirectsForAITrainingId = "redirects_for_ai_training";
export type SettingsBulkEditRequestBodyItemZonesRedirectsForAITrainingValue = "off" | "on";
export interface SettingsBulkEditRequestBodyItemZonesRedirectsForAITraining {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesRedirectsForAITrainingId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesRedirectsForAITrainingValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesReplaceInsecureJSId = "replace_insecure_js";
export type SettingsBulkEditRequestBodyItemZonesReplaceInsecureJSValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesReplaceInsecureJS {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesReplaceInsecureJSId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesReplaceInsecureJSValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesResponseBuffering2Id = "response_buffering";
export type SettingsBulkEditRequestBodyItemZonesResponseBuffering2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesResponseBuffering2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesResponseBuffering2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesResponseBuffering2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesRocketLoader2Id = "rocket_loader";
export type SettingsBulkEditRequestBodyItemZonesRocketLoader2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesRocketLoader2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesRocketLoader2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesRocketLoader2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationId = "automatic_platform_optimization";
export type SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList = Array<string>;
export interface SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationValue {
    /** Indicates whether or not [cache by device type](https://developers.cloudflare.com/automatic-platform-optimization/reference/cache-device-type/) is enabled. */
    cacheByDeviceType: boolean;
    /** Indicates whether or not Cloudflare proxy is enabled. */
    cf: boolean;
    /** Indicates whether or not Automatic Platform Optimization is enabled. */
    enabled: boolean;
    /** An array of hostnames where Automatic Platform Optimization for WordPress is activated. */
    hostnames: SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList;
    /** Indicates whether or not site is powered by WordPress. */
    wordpress: boolean;
    /** Indicates whether or not [Cloudflare for WordPress plugin](https://wordpress.org/plugins/cloudflare/) is installed. */
    wpPlugin: boolean;
}
export interface SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimization {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesSearchForAgentsId = "search_for_agents";
export type SettingsBulkEditRequestBodyItemZonesSearchForAgentsValue = "off" | "on";
export interface SettingsBulkEditRequestBodyItemZonesSearchForAgents {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSearchForAgentsId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSearchForAgentsValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemSecurityHeadersId = "security_header";
export interface SettingsBulkEditRequestBodyItemSecurityHeadersValueStrictTransportSecurity {
    /** Whether or not strict transport security is enabled. */
    enabled?: boolean;
    /** Include all subdomains for strict transport security. */
    includeSubdomains?: boolean;
    /** Max age in seconds of the strict transport security. */
    maxAge?: number;
    /** Whether or not to include 'X-Content-Type-Options: nosniff' header. */
    nosniff?: boolean;
    /** Enable automatic preload of the HSTS configuration. */
    preload?: boolean;
}
export interface SettingsBulkEditRequestBodyItemSecurityHeadersValue {
    /** Strict Transport Security. */
    strictTransportSecurity?: SettingsBulkEditRequestBodyItemSecurityHeadersValueStrictTransportSecurity;
}
export interface SettingsBulkEditRequestBodyItemSecurityHeaders {
    /** ID of the zone's security header. */
    id: SettingsBulkEditRequestBodyItemSecurityHeadersId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemSecurityHeadersValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesSecurityLevel2Id = "security_level";
export type SettingsBulkEditRequestBodyItemZonesSecurityLevel2Value = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface SettingsBulkEditRequestBodyItemZonesSecurityLevel2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSecurityLevel2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSecurityLevel2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemServerSideExcludesId = "server_side_exclude";
export type SettingsBulkEditRequestBodyItemServerSideExcludesValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemServerSideExcludes {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemServerSideExcludesId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemServerSideExcludesValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesSha1SupportId = "sha1_support";
export type SettingsBulkEditRequestBodyItemZonesSha1SupportValue = "off" | "on";
export interface SettingsBulkEditRequestBodyItemZonesSha1Support {
    /** Zone setting identifier. */
    id: SettingsBulkEditRequestBodyItemZonesSha1SupportId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSha1SupportValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesSortQueryStringForCache2Id = "sort_query_string_for_cache";
export type SettingsBulkEditRequestBodyItemZonesSortQueryStringForCache2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesSortQueryStringForCache2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSortQueryStringForCache2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSortQueryStringForCache2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesSSL2Id = "ssl";
export type SettingsBulkEditRequestBodyItemZonesSSL2Value = "off" | "flexible" | "full" | "strict";
export interface SettingsBulkEditRequestBodyItemZonesSSL2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSSL2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSSL2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemSSLRecommenderId = "ssl_recommender";
export interface SettingsBulkEditRequestBodyItemSSLRecommender {
    /** Enrollment value for SSL/TLS Recommender. */
    id?: SettingsBulkEditRequestBodyItemSSLRecommenderId | (string & {});
    /** ssl-recommender enrollment setting. */
    enabled?: boolean;
}
export type SettingsBulkEditRequestBodyItemZonesTLS12OnlyId = "tls_1_2_only";
export type SettingsBulkEditRequestBodyItemZonesTLS12OnlyValue = "off" | "on";
export interface SettingsBulkEditRequestBodyItemZonesTLS12Only {
    /** Zone setting identifier. */
    id: SettingsBulkEditRequestBodyItemZonesTLS12OnlyId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesTLS12OnlyValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemTLS13Id = "tls_1_3";
export type SettingsBulkEditRequestBodyItemTLS13Value = "on" | "off" | "zrt";
export interface SettingsBulkEditRequestBodyItemTLS13 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemTLS13Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemTLS13Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemTLSClientAuthId = "tls_client_auth";
export type SettingsBulkEditRequestBodyItemTLSClientAuthValue = "on" | "off";
export interface SettingsBulkEditRequestBodyItemTLSClientAuth {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemTLSClientAuthId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemTLSClientAuthValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesTrueClientIPHeader2Id = "true_client_ip_header";
export type SettingsBulkEditRequestBodyItemZonesTrueClientIPHeader2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesTrueClientIPHeader2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesTrueClientIPHeader2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesTrueClientIPHeader2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesWAF2Id = "waf";
export type SettingsBulkEditRequestBodyItemZonesWAF2Value = "on" | "off";
export interface SettingsBulkEditRequestBodyItemZonesWAF2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesWAF2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesWAF2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesWebmcpEnabledId = "webmcp_enabled";
export type SettingsBulkEditRequestBodyItemZonesWebmcpEnabledValue = "off" | "on";
export interface SettingsBulkEditRequestBodyItemZonesWebmcpEnabled {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesWebmcpEnabledId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesWebmcpEnabledValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesWebmcpMcpURLId = "webmcp_mcp_url";
export interface SettingsBulkEditRequestBodyItemZonesWebmcpMcpURL {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesWebmcpMcpURLId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemZonesWebmcpPacksId = "webmcp_packs";
export interface SettingsBulkEditRequestBodyItemZonesWebmcpPacks {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesWebmcpPacksId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemWebPId = "webp";
export type SettingsBulkEditRequestBodyItemWebPValue = "off" | "on";
export interface SettingsBulkEditRequestBodyItemWebP {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemWebPId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemWebPValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItemWebsocketId = "websockets";
export type SettingsBulkEditRequestBodyItemWebsocketValue = "off" | "on";
export interface SettingsBulkEditRequestBodyItemWebsocket {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemWebsocketId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemWebsocketValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export type SettingsBulkEditRequestBodyItem = SettingsBulkEditRequestBodyItemZeroRTT | SettingsBulkEditRequestBodyItemAdvancedDDoS | SettingsBulkEditRequestBodyItemZonesCacheRulesAegis | SettingsBulkEditRequestBodyItemAlwaysOnline | SettingsBulkEditRequestBodyItemZonesAlwaysUseHTTPS2 | SettingsBulkEditRequestBodyItemZonesAutomaticHTTPSRewrites2 | SettingsBulkEditRequestBodyItemBrotli | SettingsBulkEditRequestBodyItemZonesBrowserCacheTTL2 | SettingsBulkEditRequestBodyItemZonesBrowserCheck2 | SettingsBulkEditRequestBodyItemZonesCacheLevel2 | SettingsBulkEditRequestBodyItemChallengeTTL | SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabled | SettingsBulkEditRequestBodyItemZonesContentConverter | SettingsBulkEditRequestBodyItemCiphers | SettingsBulkEditRequestBodyItemZonesCNAMEFlattening | SettingsBulkEditRequestBodyItemDevelopmentMode | SettingsBulkEditRequestBodyItemEarlyHints | SettingsBulkEditRequestBodyItemZonesEdgeCacheTTL2 | SettingsBulkEditRequestBodyItemZonesEmailObfuscation2 | SettingsBulkEditRequestBodyItemH2Prioritization | SettingsBulkEditRequestBodyItemHotlinkProtection | SettingsBulkEditRequestBodyItemHTTP2 | SettingsBulkEditRequestBodyItemHTTP3 | SettingsBulkEditRequestBodyItemZonesIPGeolocation2 | SettingsBulkEditRequestBodyItemIPV6 | SettingsBulkEditRequestBodyItemZonesMaxUpload | SettingsBulkEditRequestBodyItemMinTLSVersion | SettingsBulkEditRequestBodyItemZonesMirage2 | SettingsBulkEditRequestBodyItemNEL | SettingsBulkEditRequestBodyItemZonesOpportunisticEncryption2 | SettingsBulkEditRequestBodyItemOpportunisticOnion | SettingsBulkEditRequestBodyItemOrangeToOrange | SettingsBulkEditRequestBodyItemZonesOriginErrorPagePassThru2 | SettingsBulkEditRequestBodyItemZonesCacheRulesOriginH2MaxStreams | SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersion | SettingsBulkEditRequestBodyItemZonesPolish2 | SettingsBulkEditRequestBodyItemPrefetchPreload | SettingsBulkEditRequestBodyItemZonesPreRender | SettingsBulkEditRequestBodyItemZonesPrivacyPass | SettingsBulkEditRequestBodyItemProxyReadTimeout | SettingsBulkEditRequestBodyItemPseudoIPV4 | SettingsBulkEditRequestBodyItemZonesRedirectsForAITraining | SettingsBulkEditRequestBodyItemZonesReplaceInsecureJS | SettingsBulkEditRequestBodyItemZonesResponseBuffering2 | SettingsBulkEditRequestBodyItemZonesRocketLoader2 | SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimization | SettingsBulkEditRequestBodyItemZonesSearchForAgents | SettingsBulkEditRequestBodyItemSecurityHeaders | SettingsBulkEditRequestBodyItemZonesSecurityLevel2 | SettingsBulkEditRequestBodyItemServerSideExcludes | SettingsBulkEditRequestBodyItemZonesSha1Support | SettingsBulkEditRequestBodyItemZonesSortQueryStringForCache2 | SettingsBulkEditRequestBodyItemZonesSSL2 | SettingsBulkEditRequestBodyItemSSLRecommender | SettingsBulkEditRequestBodyItemZonesTLS12Only | SettingsBulkEditRequestBodyItemTLS13 | SettingsBulkEditRequestBodyItemTLSClientAuth | SettingsBulkEditRequestBodyItemZonesTrueClientIPHeader2 | SettingsBulkEditRequestBodyItemZonesWAF2 | SettingsBulkEditRequestBodyItemZonesWebmcpEnabled | SettingsBulkEditRequestBodyItemZonesWebmcpMcpURL | SettingsBulkEditRequestBodyItemZonesWebmcpPacks | SettingsBulkEditRequestBodyItemWebP | SettingsBulkEditRequestBodyItemWebsocket;
export type SettingsBulkEditRequestBodyList = Array<SettingsBulkEditRequestBodyItem>;
export interface SettingsBulkEditRequest {
    /** Identifier */
    zoneId: string;
    body: SettingsBulkEditRequestBodyList;
}
export type SettingsBulkEditResultItemZeroRTTId = "0rtt";
export type SettingsBulkEditResultItemZeroRTTValue = "on" | "off";
export interface SettingsBulkEditResultItemZeroRTT {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZeroRTTId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZeroRTTValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemAdvancedDDoSId = "advanced_ddos";
export type SettingsBulkEditResultItemAdvancedDDoSValue = "on" | "off";
export interface SettingsBulkEditResultItemAdvancedDDoS {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemAdvancedDDoSId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemAdvancedDDoSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesCacheRulesAegisId = "aegis";
export type SettingsBulkEditResultItemZonesCacheRulesAegisValue = SettingsGetResultZonesCacheRulesAegisValue;
export interface SettingsBulkEditResultItemZonesCacheRulesAegis {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesCacheRulesAegisId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. */
    value?: SettingsGetResultZonesCacheRulesAegisValue | null;
}
export type SettingsBulkEditResultItemAlwaysOnlineId = "always_online";
export type SettingsBulkEditResultItemAlwaysOnlineValue = "on" | "off";
export interface SettingsBulkEditResultItemAlwaysOnline {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemAlwaysOnlineId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemAlwaysOnlineValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesAlwaysUseHTTPS2Id = "always_use_https";
export type SettingsBulkEditResultItemZonesAlwaysUseHTTPS2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesAlwaysUseHTTPS2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesAlwaysUseHTTPS2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesAlwaysUseHTTPS2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesAutomaticHTTPSRewrites2Id = "automatic_https_rewrites";
export type SettingsBulkEditResultItemZonesAutomaticHTTPSRewrites2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesAutomaticHTTPSRewrites2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesAutomaticHTTPSRewrites2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesAutomaticHTTPSRewrites2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemBrotliId = "brotli";
export type SettingsBulkEditResultItemBrotliValue = "off" | "on";
export interface SettingsBulkEditResultItemBrotli {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemBrotliId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemBrotliValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesBrowserCacheTTL2Id = "browser_cache_ttl";
export interface SettingsBulkEditResultItemZonesBrowserCacheTTL2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesBrowserCacheTTL2Id;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesBrowserCheck2Id = "browser_check";
export type SettingsBulkEditResultItemZonesBrowserCheck2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesBrowserCheck2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesBrowserCheck2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesBrowserCheck2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesCacheLevel2Id = "cache_level";
export type SettingsBulkEditResultItemZonesCacheLevel2Value = "aggressive" | "basic" | "simplified";
export interface SettingsBulkEditResultItemZonesCacheLevel2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesCacheLevel2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesCacheLevel2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemChallengeTTLId = "challenge_ttl";
export type SettingsBulkEditResultItemChallengeTTLValue = 300 | 900 | 1800 | 2700 | 3600 | 7200 | 10800 | 14400 | 28800 | 57600 | 86400 | 604800 | 2592000 | 31536000;
export interface SettingsBulkEditResultItemChallengeTTL {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemChallengeTTLId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemChallengeTTLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemCiphersId = "ciphers";
export type SettingsBulkEditResultItemCiphersValueList = Array<string>;
export interface SettingsBulkEditResultItemCiphers {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemCiphersId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemCiphersValueList;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesContentConverterId = "content_converter";
export type SettingsBulkEditResultItemZonesContentConverterValue = "off" | "on";
export interface SettingsBulkEditResultItemZonesContentConverter {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesContentConverterId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesContentConverterValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesCNAMEFlatteningId = "cname_flattening";
export type SettingsBulkEditResultItemZonesCNAMEFlatteningValue = "flatten_at_root" | "flatten_all";
export interface SettingsBulkEditResultItemZonesCNAMEFlattening {
    /** How to flatten the cname destination. */
    id: SettingsBulkEditResultItemZonesCNAMEFlatteningId;
    /** This zone setting is deprecated; please use the DNS Settings route instead. More information at https://developers.cloudflare.com/fundamentals/api/reference/deprecations/#2025-03-21 */
    value: SettingsBulkEditResultItemZonesCNAMEFlatteningValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemDevelopmentModeId = "development_mode";
export type SettingsBulkEditResultItemDevelopmentModeValue = "on" | "off";
export interface SettingsBulkEditResultItemDevelopmentMode {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemDevelopmentModeId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemDevelopmentModeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. Notes: The interval (in seconds) from when development mode expires (positive integer) or last expired (negative integer) for the domain. If development mode has never been enabled, this value is false. */
    timeRemaining?: number | null;
}
export type SettingsBulkEditResultItemEarlyHintsId = "early_hints";
export type SettingsBulkEditResultItemEarlyHintsValue = "on" | "off";
export interface SettingsBulkEditResultItemEarlyHints {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemEarlyHintsId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemEarlyHintsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesEdgeCacheTTL2Id = "edge_cache_ttl";
export type SettingsBulkEditResultItemZonesEdgeCacheTTL2Value = 30 | 60 | 300 | 1200 | 1800 | 3600 | 7200 | 10800 | 14400 | 18000 | 28800 | 43200 | 57600 | 72000 | 86400 | 172800 | 259200 | 345600 | 432000 | 518400 | 604800;
export interface SettingsBulkEditResultItemZonesEdgeCacheTTL2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesEdgeCacheTTL2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesEdgeCacheTTL2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesEmailObfuscation2Id = "email_obfuscation";
export type SettingsBulkEditResultItemZonesEmailObfuscation2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesEmailObfuscation2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesEmailObfuscation2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesEmailObfuscation2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemH2PrioritizationId = "h2_prioritization";
export type SettingsBulkEditResultItemH2PrioritizationValue = "on" | "off" | "custom";
export interface SettingsBulkEditResultItemH2Prioritization {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemH2PrioritizationId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemH2PrioritizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemHotlinkProtectionId = "hotlink_protection";
export type SettingsBulkEditResultItemHotlinkProtectionValue = "on" | "off";
export interface SettingsBulkEditResultItemHotlinkProtection {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemHotlinkProtectionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemHotlinkProtectionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemHTTP2Id = "http2";
export type SettingsBulkEditResultItemHTTP2Value = "on" | "off";
export interface SettingsBulkEditResultItemHTTP2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemHTTP2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemHTTP2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemHTTP3Id = "http3";
export type SettingsBulkEditResultItemHTTP3Value = "on" | "off";
export interface SettingsBulkEditResultItemHTTP3 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemHTTP3Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemHTTP3Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemImageResizingId = "image_resizing";
export type SettingsBulkEditResultItemImageResizingValue = "on" | "off" | "open";
export interface SettingsBulkEditResultItemImageResizing {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemImageResizingId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemImageResizingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesIPGeolocation2Id = "ip_geolocation";
export type SettingsBulkEditResultItemZonesIPGeolocation2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesIPGeolocation2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesIPGeolocation2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesIPGeolocation2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemIPV6Id = "ipv6";
export type SettingsBulkEditResultItemIPV6Value = "off" | "on";
export interface SettingsBulkEditResultItemIPV6 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemIPV6Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemIPV6Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesMaxUploadId = "max_upload";
export type SettingsBulkEditResultItemZonesMaxUploadValue = 100 | 125 | 150 | 175 | 200 | 225 | 250 | 275 | 300 | 325 | 350 | 375 | 400 | 425 | 450 | 475 | 500 | 1000 | 1500 | 2000 | 2500 | 3000 | 3500 | 4000 | 4500 | 5000;
export interface SettingsBulkEditResultItemZonesMaxUpload {
    /** identifier of the zone setting. */
    id: SettingsBulkEditResultItemZonesMaxUploadId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesMaxUploadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemMinTLSVersionId = "min_tls_version";
export type SettingsBulkEditResultItemMinTLSVersionValue = "1.0" | "1.1" | "1.2" | "1.3";
export interface SettingsBulkEditResultItemMinTLSVersion {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemMinTLSVersionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemMinTLSVersionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesMirage2Id = "mirage";
export type SettingsBulkEditResultItemZonesMirage2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesMirage2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesMirage2Id;
    /** Mirage is being deprecated. More information at https://developers.cloudflare.com/speed/optimization/images/mirage/ */
    value: SettingsBulkEditResultItemZonesMirage2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemNELId = "nel";
export type SettingsBulkEditResultItemNELValue = SettingsGetResultNELValue;
export interface SettingsBulkEditResultItemNEL {
    /** Zone setting identifier. */
    id: SettingsBulkEditResultItemNELId;
    /** Current value of the zone setting. */
    value: SettingsGetResultNELValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesOpportunisticEncryption2Id = "opportunistic_encryption";
export type SettingsBulkEditResultItemZonesOpportunisticEncryption2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesOpportunisticEncryption2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesOpportunisticEncryption2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesOpportunisticEncryption2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemOpportunisticOnionId = "opportunistic_onion";
export type SettingsBulkEditResultItemOpportunisticOnionValue = "on" | "off";
export interface SettingsBulkEditResultItemOpportunisticOnion {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemOpportunisticOnionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemOpportunisticOnionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemOrangeToOrangeId = "orange_to_orange";
export type SettingsBulkEditResultItemOrangeToOrangeValue = "on" | "off";
export interface SettingsBulkEditResultItemOrangeToOrange {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemOrangeToOrangeId;
    /** This setting is deprecated. Orange to Orange (O2O) is applied automatically for eligible zones and no longer requires configuration; this setting only controlled the legacy O2O v1 (Managed CNAME) path. More information at https://developers.cloudflare.com/fundamentals/api/reference/deprecations/ */
    value: SettingsBulkEditResultItemOrangeToOrangeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesOriginErrorPagePassThru2Id = "origin_error_page_pass_thru";
export type SettingsBulkEditResultItemZonesOriginErrorPagePassThru2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesOriginErrorPagePassThru2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesOriginErrorPagePassThru2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesOriginErrorPagePassThru2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesCacheRulesOriginH2MaxStreamsId = "origin_h2_max_streams";
export interface SettingsBulkEditResultItemZonesCacheRulesOriginH2MaxStreams {
    /** Value of the zone setting. */
    id: SettingsBulkEditResultItemZonesCacheRulesOriginH2MaxStreamsId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin H2 Max Streams Setting. */
    value?: number | null;
}
export type SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersionId = "origin_max_http_version";
export type SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersionValue = "2" | "1";
export interface SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersion {
    /** Value of the zone setting. */
    id: SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersionId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin Max HTTP Version Setting. */
    value?: SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersionValue | null;
}
export type SettingsBulkEditResultItemZonesPolish2Id = "polish";
export type SettingsBulkEditResultItemZonesPolish2Value = "off" | "lossless" | "lossy";
export interface SettingsBulkEditResultItemZonesPolish2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesPolish2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesPolish2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemPrefetchPreloadId = "prefetch_preload";
export type SettingsBulkEditResultItemPrefetchPreloadValue = "on" | "off";
export interface SettingsBulkEditResultItemPrefetchPreload {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemPrefetchPreloadId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemPrefetchPreloadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesPreRenderId = "pre_render";
export type SettingsBulkEditResultItemZonesPreRenderValue = "off" | "on";
export interface SettingsBulkEditResultItemZonesPreRender {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesPreRenderId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesPreRenderValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesPrivacyPassId = "privacy_pass";
export type SettingsBulkEditResultItemZonesPrivacyPassValue = "on" | "off";
export interface SettingsBulkEditResultItemZonesPrivacyPass {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesPrivacyPassId;
    /** Privacy Pass v1 was deprecated in 2023. (Announcement - https://blog.cloudflare.com/privacy-pass-standard/) and (API deprecation details - https://developers.cloudflare.com/fundamentals/api/reference/deprecations/#2024-03-31) */
    value: SettingsBulkEditResultItemZonesPrivacyPassValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemProxyReadTimeoutId = "proxy_read_timeout";
export interface SettingsBulkEditResultItemProxyReadTimeout {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemProxyReadTimeoutId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemPseudoIPV4Id = "pseudo_ipv4";
export type SettingsBulkEditResultItemPseudoIPV4Value = "off" | "add_header" | "overwrite_header";
export interface SettingsBulkEditResultItemPseudoIPV4 {
    /** Value of the Pseudo IPv4 setting. */
    id: SettingsBulkEditResultItemPseudoIPV4Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemPseudoIPV4Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesRedirectsForAITrainingId = "redirects_for_ai_training";
export type SettingsBulkEditResultItemZonesRedirectsForAITrainingValue = "off" | "on";
export interface SettingsBulkEditResultItemZonesRedirectsForAITraining {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesRedirectsForAITrainingId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesRedirectsForAITrainingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesReplaceInsecureJSId = "replace_insecure_js";
export type SettingsBulkEditResultItemZonesReplaceInsecureJSValue = "on" | "off";
export interface SettingsBulkEditResultItemZonesReplaceInsecureJS {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesReplaceInsecureJSId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesReplaceInsecureJSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesResponseBuffering2Id = "response_buffering";
export type SettingsBulkEditResultItemZonesResponseBuffering2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesResponseBuffering2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesResponseBuffering2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesResponseBuffering2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesRocketLoader2Id = "rocket_loader";
export type SettingsBulkEditResultItemZonesRocketLoader2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesRocketLoader2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesRocketLoader2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesRocketLoader2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationId = "automatic_platform_optimization";
export type SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList = Array<string>;
export interface SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationValue {
    /** Indicates whether or not [cache by device type](https://developers.cloudflare.com/automatic-platform-optimization/reference/cache-device-type/) is enabled. */
    cacheByDeviceType: boolean;
    /** Indicates whether or not Cloudflare proxy is enabled. */
    cf: boolean;
    /** Indicates whether or not Automatic Platform Optimization is enabled. */
    enabled: boolean;
    /** An array of hostnames where Automatic Platform Optimization for WordPress is activated. */
    hostnames: SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList;
    /** Indicates whether or not site is powered by WordPress. */
    wordpress: boolean;
    /** Indicates whether or not [Cloudflare for WordPress plugin](https://wordpress.org/plugins/cloudflare/) is installed. */
    wpPlugin: boolean;
}
export interface SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimization {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesSearchForAgentsId = "search_for_agents";
export type SettingsBulkEditResultItemZonesSearchForAgentsValue = "off" | "on";
export interface SettingsBulkEditResultItemZonesSearchForAgents {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSearchForAgentsId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSearchForAgentsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemSecurityHeadersId = "security_header";
export type SettingsBulkEditResultItemSecurityHeadersValueStrictTransportSecurity = SettingsGetResultSecurityHeadersValueStrictTransportSecurity;
export type SettingsBulkEditResultItemSecurityHeadersValue = SettingsGetResultSecurityHeadersValue;
export interface SettingsBulkEditResultItemSecurityHeaders {
    /** ID of the zone's security header. */
    id: SettingsBulkEditResultItemSecurityHeadersId;
    /** Current value of the zone setting. */
    value: SettingsGetResultSecurityHeadersValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesSecurityLevel2Id = "security_level";
export type SettingsBulkEditResultItemZonesSecurityLevel2Value = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export interface SettingsBulkEditResultItemZonesSecurityLevel2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSecurityLevel2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSecurityLevel2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemServerSideExcludesId = "server_side_exclude";
export type SettingsBulkEditResultItemServerSideExcludesValue = "on" | "off";
export interface SettingsBulkEditResultItemServerSideExcludes {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemServerSideExcludesId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemServerSideExcludesValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesSha1SupportId = "sha1_support";
export type SettingsBulkEditResultItemZonesSha1SupportValue = "off" | "on";
export interface SettingsBulkEditResultItemZonesSha1Support {
    /** Zone setting identifier. */
    id: SettingsBulkEditResultItemZonesSha1SupportId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSha1SupportValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesSortQueryStringForCache2Id = "sort_query_string_for_cache";
export type SettingsBulkEditResultItemZonesSortQueryStringForCache2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesSortQueryStringForCache2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSortQueryStringForCache2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSortQueryStringForCache2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesSSL2Id = "ssl";
export type SettingsBulkEditResultItemZonesSSL2Value = "off" | "flexible" | "full" | "strict";
export interface SettingsBulkEditResultItemZonesSSL2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSSL2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSSL2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemSSLRecommenderId = "ssl_recommender";
export interface SettingsBulkEditResultItemSSLRecommender {
    /** Enrollment value for SSL/TLS Recommender. */
    id?: SettingsBulkEditResultItemSSLRecommenderId | null;
    /** ssl-recommender enrollment setting. */
    enabled?: boolean | null;
}
export type SettingsBulkEditResultItemZonesTLS12OnlyId = "tls_1_2_only";
export type SettingsBulkEditResultItemZonesTLS12OnlyValue = "off" | "on";
export interface SettingsBulkEditResultItemZonesTLS12Only {
    /** Zone setting identifier. */
    id: SettingsBulkEditResultItemZonesTLS12OnlyId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesTLS12OnlyValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemTLS13Id = "tls_1_3";
export type SettingsBulkEditResultItemTLS13Value = "on" | "off" | "zrt";
export interface SettingsBulkEditResultItemTLS13 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemTLS13Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemTLS13Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemTLSClientAuthId = "tls_client_auth";
export type SettingsBulkEditResultItemTLSClientAuthValue = "on" | "off";
export interface SettingsBulkEditResultItemTLSClientAuth {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemTLSClientAuthId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemTLSClientAuthValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesTransformationsId = "transformations";
export type SettingsBulkEditResultItemZonesTransformationsValue = "on" | "off" | "open";
export interface SettingsBulkEditResultItemZonesTransformations {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: SettingsBulkEditResultItemZonesTransformationsId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesTransformationsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesTransformationsAllowedOriginsId = "transformations_allowed_origins";
export interface SettingsBulkEditResultItemZonesTransformationsAllowedOrigins {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: SettingsBulkEditResultItemZonesTransformationsAllowedOriginsId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesTrueClientIPHeader2Id = "true_client_ip_header";
export type SettingsBulkEditResultItemZonesTrueClientIPHeader2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesTrueClientIPHeader2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesTrueClientIPHeader2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesTrueClientIPHeader2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesWAF2Id = "waf";
export type SettingsBulkEditResultItemZonesWAF2Value = "on" | "off";
export interface SettingsBulkEditResultItemZonesWAF2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesWAF2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesWAF2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesWebmcpEnabledId = "webmcp_enabled";
export type SettingsBulkEditResultItemZonesWebmcpEnabledValue = "off" | "on";
export interface SettingsBulkEditResultItemZonesWebmcpEnabled {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesWebmcpEnabledId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesWebmcpEnabledValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesWebmcpMcpURLId = "webmcp_mcp_url";
export interface SettingsBulkEditResultItemZonesWebmcpMcpURL {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesWebmcpMcpURLId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemZonesWebmcpPacksId = "webmcp_packs";
export interface SettingsBulkEditResultItemZonesWebmcpPacks {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesWebmcpPacksId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemWebPId = "webp";
export type SettingsBulkEditResultItemWebPValue = "off" | "on";
export interface SettingsBulkEditResultItemWebP {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemWebPId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemWebPValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItemWebsocketId = "websockets";
export type SettingsBulkEditResultItemWebsocketValue = "off" | "on";
export interface SettingsBulkEditResultItemWebsocket {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemWebsocketId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemWebsocketValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export type SettingsBulkEditResultItem = SettingsBulkEditResultItemZeroRTT | SettingsBulkEditResultItemAdvancedDDoS | SettingsBulkEditResultItemZonesCacheRulesAegis | SettingsBulkEditResultItemAlwaysOnline | SettingsBulkEditResultItemZonesAlwaysUseHTTPS2 | SettingsBulkEditResultItemZonesAutomaticHTTPSRewrites2 | SettingsBulkEditResultItemBrotli | SettingsBulkEditResultItemZonesBrowserCacheTTL2 | SettingsBulkEditResultItemZonesBrowserCheck2 | SettingsBulkEditResultItemZonesCacheLevel2 | SettingsBulkEditResultItemChallengeTTL | SettingsBulkEditResultItemCiphers | SettingsBulkEditResultItemZonesContentConverter | SettingsBulkEditResultItemZonesCNAMEFlattening | SettingsBulkEditResultItemDevelopmentMode | SettingsBulkEditResultItemEarlyHints | SettingsBulkEditResultItemZonesEdgeCacheTTL2 | SettingsBulkEditResultItemZonesEmailObfuscation2 | SettingsBulkEditResultItemH2Prioritization | SettingsBulkEditResultItemHotlinkProtection | SettingsBulkEditResultItemHTTP2 | SettingsBulkEditResultItemHTTP3 | SettingsBulkEditResultItemImageResizing | SettingsBulkEditResultItemZonesIPGeolocation2 | SettingsBulkEditResultItemIPV6 | SettingsBulkEditResultItemZonesMaxUpload | SettingsBulkEditResultItemMinTLSVersion | SettingsBulkEditResultItemZonesMirage2 | SettingsBulkEditResultItemNEL | SettingsBulkEditResultItemZonesOpportunisticEncryption2 | SettingsBulkEditResultItemOpportunisticOnion | SettingsBulkEditResultItemOrangeToOrange | SettingsBulkEditResultItemZonesOriginErrorPagePassThru2 | SettingsBulkEditResultItemZonesCacheRulesOriginH2MaxStreams | SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersion | SettingsBulkEditResultItemZonesPolish2 | SettingsBulkEditResultItemPrefetchPreload | SettingsBulkEditResultItemZonesPreRender | SettingsBulkEditResultItemZonesPrivacyPass | SettingsBulkEditResultItemProxyReadTimeout | SettingsBulkEditResultItemPseudoIPV4 | SettingsBulkEditResultItemZonesRedirectsForAITraining | SettingsBulkEditResultItemZonesReplaceInsecureJS | SettingsBulkEditResultItemZonesResponseBuffering2 | SettingsBulkEditResultItemZonesRocketLoader2 | SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimization | SettingsBulkEditResultItemZonesSearchForAgents | SettingsBulkEditResultItemSecurityHeaders | SettingsBulkEditResultItemZonesSecurityLevel2 | SettingsBulkEditResultItemServerSideExcludes | SettingsBulkEditResultItemZonesSha1Support | SettingsBulkEditResultItemZonesSortQueryStringForCache2 | SettingsBulkEditResultItemZonesSSL2 | SettingsBulkEditResultItemSSLRecommender | SettingsBulkEditResultItemZonesTLS12Only | SettingsBulkEditResultItemTLS13 | SettingsBulkEditResultItemTLSClientAuth | SettingsBulkEditResultItemZonesTransformations | SettingsBulkEditResultItemZonesTransformationsAllowedOrigins | SettingsBulkEditResultItemZonesTrueClientIPHeader2 | SettingsBulkEditResultItemZonesWAF2 | SettingsBulkEditResultItemZonesWebmcpEnabled | SettingsBulkEditResultItemZonesWebmcpMcpURL | SettingsBulkEditResultItemZonesWebmcpPacks | SettingsBulkEditResultItemWebP | SettingsBulkEditResultItemWebsocket;
export type SettingsBulkEditResultList = Array<SettingsBulkEditResultItem>;
export type SettingsBulkEditResponse = SettingsBulkEditResultList;
export interface TriggerActivationCheckRequest {
    /** Identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface TriggerActivationCheckResponse {
    /** Identifier. */
    id?: string | null;
}
export type EnvironmentsUpdateRequestEnvironmentsItemPosition = EnvironmentsCreateRequestEnvironmentsItemPosition;
export type EnvironmentsUpdateRequestEnvironmentsItem = EnvironmentsCreateRequestEnvironmentsItem;
export type EnvironmentsUpdateRequestEnvironmentsList = Array<EnvironmentsCreateRequestEnvironmentsItem>;
export interface UpdateEnvironmentRequest {
    zoneId: string;
    environments: EnvironmentsUpdateRequestEnvironmentsList;
}
export type EnvironmentsUpdateResponseEnvironmentsItemPosition = EnvironmentsCreateResponseEnvironmentsItemPosition;
export type EnvironmentsUpdateResponseEnvironmentsItem = EnvironmentsCreateResponseEnvironmentsItem;
export type EnvironmentsUpdateResponseEnvironmentsList = Array<EnvironmentsCreateResponseEnvironmentsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateEnvironmentResponse {
    environments: EnvironmentsUpdateResponseEnvironmentsList;
}
export type UpdateObservabilityTracingRuleRequestRulesItemAction = "set_trace_settings";
export type UpdateObservabilityTracingRuleRequestRulesItemActionParameters = DeleteObservabilityTracingRuleResponseRulesItemActionParameters;
export interface UpdateObservabilityTracingRuleRequestRulesItem {
    action: UpdateObservabilityTracingRuleRequestRulesItemAction | (string & {});
    actionParameters: DeleteObservabilityTracingRuleResponseRulesItemActionParameters;
    description: string;
    enabled: boolean;
    /** A Rules language expression that selects requests. */
    expression: string;
}
export type UpdateObservabilityTracingRuleRequestRulesList = Array<UpdateObservabilityTracingRuleRequestRulesItem>;
export interface UpdateObservabilityTracingRuleRequest {
    /** Specify the zone ID. */
    zoneId: string;
    /** Trace rules in evaluation order. */
    rules: UpdateObservabilityTracingRuleRequestRulesList;
}
export type UpdateObservabilityTracingRuleResponseRulesItemAction = "set_trace_settings";
export type UpdateObservabilityTracingRuleResponseRulesItemActionParameters = DeleteObservabilityTracingRuleResponseRulesItemActionParameters;
export interface UpdateObservabilityTracingRuleResponseRulesItem {
    action: UpdateObservabilityTracingRuleResponseRulesItemAction;
    actionParameters: DeleteObservabilityTracingRuleResponseRulesItemActionParameters;
    description: string;
    enabled: boolean;
    /** A Rules language expression that selects requests. */
    expression: string;
}
export type UpdateObservabilityTracingRuleResponseRulesList = Array<UpdateObservabilityTracingRuleResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateObservabilityTracingRuleResponse {
    /** Trace rules in evaluation order. */
    rules: UpdateObservabilityTracingRuleResponseRulesList;
}
export type UpdateObservabilityTracingSettingsRequestDestinationsList = Array<string>;
export type UpdateObservabilityTracingSettingsRequestPropagationPolicy = "accept" | "authenticated" | "reject";
export interface UpdateObservabilityTracingSettingsRequest {
    /** Specify the zone ID. */
    zoneId: string;
    /** Up to 100 OpenTelemetry destination identifiers that receive traces. */
    destinations?: UpdateObservabilityTracingSettingsRequestDestinationsList;
    /** Whether Cloudflare Traces is enabled for the zone. */
    enabled?: boolean;
    /** Whether trace context is sent externally or across a zone boundary. */
    forwardContext?: boolean;
    /** Whether traces are persisted in Cloudflare. */
    persist?: boolean;
    /** When inbound trace context may be continued. Authenticated propagation is not supported yet. */
    propagationPolicy?: UpdateObservabilityTracingSettingsRequestPropagationPolicy | (string & {});
    /** The ratio of requests sampled for tracing, from 0 to 1. */
    samplingRatio?: number;
}
export type UpdateObservabilityTracingSettingsResponseDestinationsList = Array<string>;
export type UpdateObservabilityTracingSettingsResponsePropagationPolicy = "accept" | "authenticated" | "reject";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateObservabilityTracingSettingsResponse {
    /** Up to 100 OpenTelemetry destination identifiers that receive traces. */
    destinations: UpdateObservabilityTracingSettingsResponseDestinationsList;
    /** Whether Cloudflare Traces is enabled for the zone. */
    enabled: boolean;
    /** Whether trace context is sent externally or across a zone boundary. */
    forwardContext: boolean;
    /** Whether traces are persisted in Cloudflare. */
    persist: boolean;
    /** When inbound trace context may be continued. Authenticated propagation is not supported yet. */
    propagationPolicy: UpdateObservabilityTracingSettingsResponsePropagationPolicy;
    /** The ratio of requests sampled for tracing, from 0 to 1. */
    samplingRatio: number;
}
export type SubscriptionsUpdateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsUpdateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsUpdateRequestRatePlanSetsList = Array<string>;
export interface SubscriptionsUpdateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateRequestRatePlanId | (string & {});
    /** The currency applied to the rate plan subscription. */
    currency?: string;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean;
    /** The full name of the rate plan. */
    publicName?: string;
    /** The scope that this rate plan applies to. */
    scope?: string;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateRequestRatePlanSetsList;
}
export interface UpdateSubscriptionRequest {
    /** Identifier */
    zoneId: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateRequestFrequency | (string & {});
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateRequestRatePlan;
}
export type SubscriptionsUpdateResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly" | "not-applicable";
export type SubscriptionsUpdateResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsUpdateResponseRatePlanSetsList = Array<string>;
export interface SubscriptionsUpdateResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateResponseRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateResponseRatePlanSetsList | null;
}
export type SubscriptionsUpdateResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSubscriptionResponse {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateResponseFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateResponseRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsUpdateResponseState | null;
}
export type CreateEnvironmentError = CloudflareOpError;
/** Creates environments for a zone. */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentRequest, CreateEnvironmentResponse, CreateEnvironmentError, CloudflareOpContext>;
export type CreateHoldError = ZoneHoldsRequireEnterprise | InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Enforce a zone hold on the zone, blocking the creation and activation of zones with this zone's hostname. Zone holds cannot be enabled on CDN-only zones. */
export declare const createHold: API.OperationMethod<CreateHoldRequest, CreateHoldResponse, CreateHoldError, CloudflareOpContext>;
export type CreateSubscriptionError = CloudflareOpError;
/** Create a zone subscription, either plan or add-ons. */
export declare const createSubscription: API.OperationMethod<CreateSubscriptionRequest, CreateSubscriptionResponse, CreateSubscriptionError, CloudflareOpContext>;
export type CreateZoneError = ZoneAlreadyExists | ZoneCreationBlocked | InvalidDomain | DomainNotRegistered | SubdomainNotAllowed | CloudflareOpError;
/** Creates a new zone (domain) in your Cloudflare account. The zone is created in a pending state and must be activated by updating your domain's nameservers to point to Cloudflare, or by completing the verification process for partial (CNAME) setups. */
export declare const createZone: API.OperationMethod<CreateZoneRequest, CreateZoneResponse, CreateZoneError, CloudflareOpContext>;
export type DeleteEnvironmentError = CloudflareOpError;
/** Deletes a zone environment by reference identifier. */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest, DeleteEnvironmentResponse, DeleteEnvironmentError, CloudflareOpContext>;
export type DeleteHoldError = InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Stop enforcement of a zone hold on the zone, permanently or temporarily, allowing the creation and activation of zones with this zone's hostname. Existing zone holds can be removed from CDN-only zones when `hold_after` is not provided. Active holds are automatically disabled when a zone transitions to CDN-only mode. */
export declare const deleteHold: API.OperationMethod<DeleteHoldRequest, DeleteHoldResponse, DeleteHoldError, CloudflareOpContext>;
export type DeleteObservabilityTracingRuleError = CloudflareOpError;
/** Delete every sampling override from a zone's managed Cloudflare Traces ruleset. */
export declare const deleteObservabilityTracingRule: API.OperationMethod<DeleteObservabilityTracingRuleRequest, DeleteObservabilityTracingRuleResponse, DeleteObservabilityTracingRuleError, CloudflareOpContext>;
export type DeleteObservabilityTracingSettingsError = CloudflareOpError;
/** Reset the zone-level Cloudflare Traces settings to their defaults while preserving the sampling rules. */
export declare const deleteObservabilityTracingSettings: API.OperationMethod<DeleteObservabilityTracingSettingsRequest, DeleteObservabilityTracingSettingsResponse, DeleteObservabilityTracingSettingsError, CloudflareOpContext>;
export type DeleteZoneError = InvalidZoneIdentifier | CloudflareOpError;
/** Deletes an existing zone. */
export declare const deleteZone: API.OperationMethod<DeleteZoneRequest, DeleteZoneResponse, DeleteZoneError, CloudflareOpContext>;
export type EditNelError = CloudflareOpError;
/** Updates the Network Error Logging (NEL) setting for a zone. Requires the NEL product feature to be enabled for the zone. The setting controls whether browsers report network errors to Cloudflare's NEL endpoint. */
export declare const editNel: API.OperationMethod<EditNelRequest, EditNelResponse, EditNelError, CloudflareOpContext>;
export type EditTransformationsAllowedOriginError = CloudflareOpError;
/** Media Transformations Allowed Origins restricts transformations for images and video served through Cloudflare's network to requests originating from specified domains. Refer to the Image Transformations and Video Transformations documentation for more information. */
export declare const editTransformationsAllowedOrigin: API.OperationMethod<EditTransformationsAllowedOriginRequest, EditTransformationsAllowedOriginResponse, EditTransformationsAllowedOriginError, CloudflareOpContext>;
export type EditTransformationsC2paError = CloudflareOpError;
/** C2PA (Coalition for Content Provenance and Authenticity) signing adds cryptographic metadata to images processed through Cloudflare Image Transformations, enabling verification of image authenticity and provenance. */
export declare const editTransformationsC2pa: API.OperationMethod<EditTransformationsC2paRequest, EditTransformationsC2paResponse, EditTransformationsC2paError, CloudflareOpContext>;
export type GetCtAlertingError = CloudflareOpError;
/** Retrieve the Certificate Transparency alerting subscription settings for a zone. Returns whether CT monitoring is enabled and the list of email addresses that receive alerts, if any have been configured. */
export declare const getCtAlerting: API.OperationMethod<GetCtAlertingRequest, GetCtAlertingResponse, GetCtAlertingError, CloudflareOpContext>;
export type GetCustomNameserverError = InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Get metadata for account-level custom nameservers on a zone. Deprecated in favor of [Show DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-a-zone-list-dns-settings). */
export declare const getCustomNameserver: API.OperationMethod<GetCustomNameserverRequest, GetCustomNameserverResponse, GetCustomNameserverError, CloudflareOpContext>;
export type GetHoldError = InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Retrieve whether the zone is subject to a zone hold, and metadata about the hold. */
export declare const getHold: API.OperationMethod<GetHoldRequest, GetHoldResponse, GetHoldError, CloudflareOpContext>;
export type GetNelError = CloudflareOpError;
/** Fetches the Network Error Logging (NEL) setting for a zone. NEL allows browsers to report network errors to a configured endpoint. The setting is enabled by default for free and pro zones, and disabled by default for business and enterprise zones unless the NEL product feature is enabled. */
export declare const getNel: API.OperationMethod<GetNelRequest, GetNelResponse, GetNelError, CloudflareOpContext>;
export type GetObservabilityTracingRuleError = CloudflareOpError;
/** Retrieve the ordered sampling overrides for a zone's managed Cloudflare Traces ruleset. */
export declare const getObservabilityTracingRule: API.OperationMethod<GetObservabilityTracingRuleRequest, GetObservabilityTracingRuleResponse, GetObservabilityTracingRuleError, CloudflareOpContext>;
export type GetObservabilityTracingSettingsError = CloudflareOpError;
/** Retrieve the zone-level Cloudflare Traces settings. */
export declare const getObservabilityTracingSettings: API.OperationMethod<GetObservabilityTracingSettingsRequest, GetObservabilityTracingSettingsResponse, GetObservabilityTracingSettingsError, CloudflareOpContext>;
export type GetPlanError = CloudflareOpError;
/** Details of the available plan that the zone can subscribe to. */
export declare const getPlan: API.OperationMethod<GetPlanRequest, GetPlanResponse, GetPlanError, CloudflareOpContext>;
export type GetRatePlanError = CloudflareOpError;
/** Lists all rate plans the zone can subscribe to. */
export declare const getRatePlan: API.PaginatedOperationMethod<GetRatePlanRequest, GetRatePlanResponse, GetRatePlanError, CloudflareOpContext, RatePlansGetResultItem>;
export type GetSettingError = InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Fetch a single zone setting by name */
export declare const getSetting: API.OperationMethod<GetSettingRequest, GetSettingResponse, GetSettingError, CloudflareOpContext>;
export type GetSubscriptionError = CloudflareOpError;
/** Lists zone subscription details. */
export declare const getSubscription: API.OperationMethod<GetSubscriptionRequest, GetSubscriptionResponse, GetSubscriptionError, CloudflareOpContext>;
export type GetTransformationsAllowedOriginError = CloudflareOpError;
/** Media Transformations Allowed Origins restricts transformations for images and video served through Cloudflare's network to requests originating from specified domains. Refer to the Image Transformations and Video Transformations documentation for more information. */
export declare const getTransformationsAllowedOrigin: API.OperationMethod<GetTransformationsAllowedOriginRequest, GetTransformationsAllowedOriginResponse, GetTransformationsAllowedOriginError, CloudflareOpContext>;
export type GetTransformationsC2paError = CloudflareOpError;
/** C2PA (Coalition for Content Provenance and Authenticity) signing adds cryptographic metadata to images processed through Cloudflare Image Transformations, enabling verification of image authenticity and provenance. */
export declare const getTransformationsC2pa: API.OperationMethod<GetTransformationsC2paRequest, GetTransformationsC2paResponse, GetTransformationsC2paError, CloudflareOpContext>;
export type GetZoneError = InvalidZoneIdentifier | CloudflareOpError;
/** Retrieves detailed information about a specific zone identified by its zone ID. Returns zone configuration, status, nameservers, and associated metadata. */
export declare const getZone: API.OperationMethod<GetZoneRequest, GetZoneResponse, GetZoneError, CloudflareOpContext>;
export type ListEntitlementsError = CloudflareOpError;
/** Returns the list of entitlements (features and their allocations) for a given zone. Each entitlement describes a product feature the zone is permitted to use and the allocation value (boolean, count, range, enum, or string) that governs its behaviour. */
export declare const listEntitlements: API.OperationMethod<ListEntitlementsRequest, ListEntitlementsResponse, ListEntitlementsError, CloudflareOpContext>;
export type ListEnvironmentsError = CloudflareOpError;
/** Lists configured environments for a zone. */
export declare const listEnvironments: API.OperationMethod<ListEnvironmentsRequest, ListEnvironmentsResponse, ListEnvironmentsError, CloudflareOpContext>;
export type ListPlansError = CloudflareOpError;
/** Lists available plans the zone can subscribe to. */
export declare const listPlans: API.PaginatedOperationMethod<ListPlansRequest, ListPlansResponse, ListPlansError, CloudflareOpContext, PlansListResultItem>;
export type ListSettingsError = CloudflareOpError;
/** Available settings for your user in relation to a zone. */
export declare const listSettings: API.OperationMethod<ListSettingsRequest, ListSettingsResponse, ListSettingsError, CloudflareOpContext>;
export type ListZonesError = CloudflareOpError;
/** Lists, searches, sorts, and filters your zones. Listing zones across more than 500 accounts is currently not allowed. */
export declare const listZones: API.PaginatedOperationMethod<ListZonesRequest, ListZonesResponse, ListZonesError, CloudflareOpContext, ListResultItem>;
export type PatchCtAlertingError = CloudflareOpError;
/** Create or update the Certificate Transparency alerting subscription for a zone. Enables or disables email notifications when certificates are issued for the zone's domains. The `enabled` field is required on every request and controls whether the subscription is active. The `emails` field is optional and, when provided, replaces the stored recipient list for the zone. When `emails` is omitted, the stored recipient list is preserved and only the enabled state is toggled. A maximum of 100 email addresses may be configured per zone. Requests that omit `enabled` are rejected with error code 1008. Subscribe and unsubscribe notification emails are only sent for recipients whose effective subscription state changes. Idempotent requests (no state change) send no notification email. */
export declare const patchCtAlerting: API.OperationMethod<PatchCtAlertingRequest, PatchCtAlertingResponse, PatchCtAlertingError, CloudflareOpContext>;
export type PatchEnvironmentError = CloudflareOpError;
/** Applies partial updates to zone environments. */
export declare const patchEnvironment: API.OperationMethod<PatchEnvironmentRequest, PatchEnvironmentResponse, PatchEnvironmentError, CloudflareOpContext>;
export type PatchHoldError = ZoneHoldNotFound | ZoneHoldsRequireEnterprise | InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Update the `hold_after` and/or `include_subdomains` values on an existing zone hold. The hold is enabled if the `hold_after` date-time value is in the past. Existing zone holds can be removed from CDN-only zones by setting `hold_after` to `null`. Other zone hold updates cannot be made on CDN-only zones. Active holds are automatically disabled when a zone transitions to CDN-only mode. */
export declare const patchHold: API.OperationMethod<PatchHoldRequest, PatchHoldResponse, PatchHoldError, CloudflareOpContext>;
export type PatchSettingError = InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Updates a single zone setting by the identifier */
export declare const patchSetting: API.OperationMethod<PatchSettingRequest, PatchSettingResponse, PatchSettingError, CloudflareOpContext>;
export type PatchZoneError = InvalidZoneIdentifier | CloudflareOpError;
/** Edits a zone. Only one zone property can be changed at a time. */
export declare const patchZone: API.OperationMethod<PatchZoneRequest, PatchZoneResponse, PatchZoneError, CloudflareOpContext>;
export type PutCustomNameserverError = InvalidZoneIdentifier | CustomNameserverSetNotFound | Forbidden | CloudflareOpError;
/** Set metadata for account-level custom nameservers on a zone. If you would like new zones in the account to use account custom nameservers by default, use PUT /accounts/:identifier to set the account setting use_account_custom_ns_by_default to true. Deprecated in favor of [Update DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-a-zone-update-dns-settings). */
export declare const putCustomNameserver: API.PaginatedOperationMethod<PutCustomNameserverRequest, PutCustomNameserverResponse, PutCustomNameserverError, CloudflareOpContext, string>;
export type RollbackEnvironmentError = CloudflareOpError;
/** Rolls a zone environment back to its previous version. */
export declare const rollbackEnvironment: API.OperationMethod<RollbackEnvironmentRequest, RollbackEnvironmentResponse, RollbackEnvironmentError, CloudflareOpContext>;
export type SettingsBulkEditError = CloudflareOpError;
/** Edit settings for a zone. */
export declare const settingsBulkEdit: API.OperationMethod<SettingsBulkEditRequest, SettingsBulkEditResponse, SettingsBulkEditError, CloudflareOpContext>;
export type TriggerActivationCheckError = CloudflareOpError;
/** Triggeres a new activation check for a PENDING Zone. This can be triggered every 5 min for paygo/ent customers, every hour for FREE Zones. */
export declare const triggerActivationCheck: API.OperationMethod<TriggerActivationCheckRequest, TriggerActivationCheckResponse, TriggerActivationCheckError, CloudflareOpContext>;
export type UpdateEnvironmentError = CloudflareOpError;
/** Replaces the full environment configuration for a zone. */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentRequest, UpdateEnvironmentResponse, UpdateEnvironmentError, CloudflareOpContext>;
export type UpdateObservabilityTracingRuleError = CloudflareOpError;
/** Replace all sampling overrides in a zone's managed Cloudflare Traces ruleset. Rules are evaluated in the supplied order. */
export declare const updateObservabilityTracingRule: API.OperationMethod<UpdateObservabilityTracingRuleRequest, UpdateObservabilityTracingRuleResponse, UpdateObservabilityTracingRuleError, CloudflareOpContext>;
export type UpdateObservabilityTracingSettingsError = CloudflareOpError;
/** Update the zone-level Cloudflare Traces settings. */
export declare const updateObservabilityTracingSettings: API.OperationMethod<UpdateObservabilityTracingSettingsRequest, UpdateObservabilityTracingSettingsResponse, UpdateObservabilityTracingSettingsError, CloudflareOpContext>;
export type UpdateSubscriptionError = CloudflareOpError;
/** Updates zone subscriptions, either plan or add-ons. */
export declare const updateSubscription: API.OperationMethod<UpdateSubscriptionRequest, UpdateSubscriptionResponse, UpdateSubscriptionError, CloudflareOpContext>;
//# sourceMappingURL=zones.d.ts.map