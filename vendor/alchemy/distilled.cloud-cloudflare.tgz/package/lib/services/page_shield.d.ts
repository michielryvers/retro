import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const NotEntitled_base: S.TaggedErrorClass<"NotEntitled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NotEntitled extends /*@__PURE__*/ NotEntitled_base {
}
declare const PolicyNotFound_base: S.TaggedErrorClass<"PolicyNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PolicyNotFound extends /*@__PURE__*/ PolicyNotFound_base {
}
declare const PolicyQuotaExceeded_base: S.TaggedErrorClass<"PolicyQuotaExceeded", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PolicyQuotaExceeded extends /*@__PURE__*/ PolicyQuotaExceeded_base {
}
export type PoliciesCreateRequestAction = "allow" | "log" | "add_reporting_directives";
export interface CreatePolicyRequest {
    /** Identifier */
    zoneId: string;
    /** The action to take if the expression matches */
    action: PoliciesCreateRequestAction | (string & {});
    /** A description for the policy */
    description: string;
    /** Whether the policy is enabled */
    enabled: boolean;
    /** The expression which must match for the policy to be applied, using the Cloudflare Firewall rule expression syntax */
    expression: string;
    /** The policy which will be applied */
    value: string;
}
export type PoliciesCreateResponseAction = "allow" | "log" | "add_reporting_directives";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePolicyResponse {
    /** Identifier */
    id: string;
    /** The action to take if the expression matches */
    action: PoliciesCreateResponseAction;
    /** A description for the policy */
    description: string;
    /** Whether the policy is enabled */
    enabled: boolean;
    /** The expression which must match for the policy to be applied, using the Cloudflare Firewall rule expression syntax */
    expression: string;
    /** The policy which will be applied */
    value: string;
}
export interface DeletePolicyRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    policyId: string;
}
export interface DeletePolicyResponse {
}
export interface GetConnectionRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    connectionId: string;
}
export type ConnectionsGetResponseMaliciousDomainCategoriesList = Array<string>;
export type ConnectionsGetResponseMaliciousUrlCategoriesList = Array<string>;
export type ConnectionsGetResponsePageUrlsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConnectionResponse {
    /** Identifier */
    id: string;
    addedAt: string;
    firstSeenAt: string;
    host: string;
    lastSeenAt: string;
    url: string;
    urlContainsCdnCgiPath: boolean;
    domainReportedMalicious?: boolean | null;
    firstPageUrl?: string | null;
    maliciousDomainCategories?: ConnectionsGetResponseMaliciousDomainCategoriesList | null;
    maliciousUrlCategories?: ConnectionsGetResponseMaliciousUrlCategoriesList | null;
    pageUrls?: ConnectionsGetResponsePageUrlsList | null;
    urlReportedMalicious?: boolean | null;
}
export interface GetCookyRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    cookieId: string;
}
export type CookiesGetResponseType = "first_party" | "unknown";
export type CookiesGetResponsePageUrlsList = Array<string>;
export type CookiesGetResponseSameSiteAttribute = "lax" | "strict" | "none";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCookyResponse {
    /** Identifier */
    id: string;
    firstSeenAt: string;
    host: string;
    lastSeenAt: string;
    name: string;
    type: CookiesGetResponseType;
    domainAttribute?: string | null;
    expiresAttribute?: string | null;
    httpOnlyAttribute?: boolean | null;
    maxAgeAttribute?: number | null;
    pageUrls?: CookiesGetResponsePageUrlsList | null;
    pathAttribute?: string | null;
    sameSiteAttribute?: CookiesGetResponseSameSiteAttribute | null;
    secureAttribute?: boolean | null;
}
export interface GetPageShieldRequest {
    /** Identifier */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPageShieldResponse {
    /** When true, indicates that Client-Side Security is enabled. */
    enabled: boolean;
    /** The timestamp of when Client-Side Security was last updated. */
    updatedAt: string;
    /** When true, CSP reports will be sent to https://csp-reporting.cloudflare.com/cdn-cgi/script_monitor/report */
    useCloudflareReportingEndpoint: boolean;
    /** When true, the paths associated with connections URLs will also be analyzed. */
    useConnectionUrlPath: boolean;
}
export interface GetPolicyRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    policyId: string;
}
export type PoliciesGetResponseAction = "allow" | "log" | "add_reporting_directives";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPolicyResponse {
    /** Identifier */
    id: string;
    /** The action to take if the expression matches */
    action: PoliciesGetResponseAction;
    /** A description for the policy */
    description: string;
    /** Whether the policy is enabled */
    enabled: boolean;
    /** The expression which must match for the policy to be applied, using the Cloudflare Firewall rule expression syntax */
    expression: string;
    /** The policy which will be applied */
    value: string;
}
export interface GetScriptRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    scriptId: string;
}
export type ScriptsGetResponseMaliciousDomainCategoriesList = Array<string>;
export type ScriptsGetResponseMaliciousUrlCategoriesList = Array<string>;
export type ScriptsGetResponsePageUrlsList = Array<string>;
export interface ScriptsGetResponseVersionsItem {
    /** The cryptomining score of the JavaScript content. */
    cryptominingScore?: number | null;
    /** The dataflow score of the JavaScript content. This field has been deprecated in favour of js_integrity_score. */
    dataflowScore?: number | null;
    /** The timestamp of when the script was last fetched. */
    fetchedAt?: string | null;
    /** The computed hash of the analyzed script. */
    hash?: string | null;
    /** The integrity score of the JavaScript content. */
    jsIntegrityScore?: number | null;
    /** The magecart score of the JavaScript content. */
    magecartScore?: number | null;
    /** The malware score of the JavaScript content. */
    malwareScore?: number | null;
    /** The obfuscation score of the JavaScript content. This field has been deprecated in favour of js_integrity_score. */
    obfuscationScore?: number | null;
}
export type ScriptsGetResponseVersionsList = Array<ScriptsGetResponseVersionsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptResponse {
    /** Identifier */
    id: string;
    addedAt: string;
    firstSeenAt: string;
    host: string;
    lastSeenAt: string;
    url: string;
    urlContainsCdnCgiPath: boolean;
    /** The cryptomining score of the JavaScript content. */
    cryptominingScore?: number | null;
    /** The dataflow score of the JavaScript content. This field has been deprecated in favour of js_integrity_score. */
    dataflowScore?: number | null;
    domainReportedMalicious?: boolean | null;
    /** The timestamp of when the script was last fetched. */
    fetchedAt?: string | null;
    firstPageUrl?: string | null;
    /** The computed hash of the analyzed script. */
    hash?: string | null;
    /** The integrity score of the JavaScript content. */
    jsIntegrityScore?: number | null;
    /** The magecart score of the JavaScript content. */
    magecartScore?: number | null;
    maliciousDomainCategories?: ScriptsGetResponseMaliciousDomainCategoriesList | null;
    maliciousUrlCategories?: ScriptsGetResponseMaliciousUrlCategoriesList | null;
    /** The malware score of the JavaScript content. */
    malwareScore?: number | null;
    /** The obfuscation score of the JavaScript content. This field has been deprecated in favour of js_integrity_score. */
    obfuscationScore?: number | null;
    pageUrls?: ScriptsGetResponsePageUrlsList | null;
    urlReportedMalicious?: boolean | null;
    versions?: ScriptsGetResponseVersionsList | null;
}
export type ConnectionsListRequestDirection = "asc" | "desc";
export type ConnectionsListRequestExport = "csv";
export type ConnectionsListRequestOrderBy = "first_seen_at" | "last_seen_at";
export interface ListConnectionsRequest {
    /** Identifier */
    zoneId: string;
    /** The direction used to sort returned connections. */
    direction?: ConnectionsListRequestDirection | (string & {});
    /** When true, excludes connections seen in a `/cdn-cgi` path from the returned connections. The default value is true. */
    excludeCdnCgi?: boolean;
    /** Excludes connections whose URL contains one of the URL-encoded URLs separated by commas. */
    excludeUrls?: string;
    /** Export the list of connections as a file, limited to 50000 entries. */
    export?: ConnectionsListRequestExport | (string & {});
    /** Includes connections that match one or more URL-encoded hostnames separated by commas. */
    hosts?: string;
    /** The field used to sort returned connections. */
    orderBy?: ConnectionsListRequestOrderBy | (string & {});
    /** The current page number of the paginated results. */
    page?: string;
    /** Includes connections that match one or more page URLs (separated by commas) where they were last seen */
    pageUrl?: string;
    /** The number of results per page. */
    perPage?: number;
    /** When true, malicious connections appear first in the returned connections. */
    prioritizeMalicious?: boolean;
    /** Filters the returned connections using a comma-separated list of connection statuses. Accepted values: `active`, `infrequent`, and `inactive`. The default value is `active`. */
    status?: string;
    /** Includes connections whose URL contain one or more URL-encoded URLs separated by commas. */
    urls?: string;
}
export type ConnectionsListResultItemMaliciousDomainCategoriesList = Array<string>;
export type ConnectionsListResultItemMaliciousUrlCategoriesList = Array<string>;
export type ConnectionsListResultItemPageUrlsList = Array<string>;
export interface ConnectionsListResultItem {
    /** Identifier */
    id: string;
    addedAt: string;
    firstSeenAt: string;
    host: string;
    lastSeenAt: string;
    url: string;
    urlContainsCdnCgiPath: boolean;
    domainReportedMalicious?: boolean | null;
    firstPageUrl?: string | null;
    maliciousDomainCategories?: ConnectionsListResultItemMaliciousDomainCategoriesList | null;
    maliciousUrlCategories?: ConnectionsListResultItemMaliciousUrlCategoriesList | null;
    pageUrls?: ConnectionsListResultItemPageUrlsList | null;
    urlReportedMalicious?: boolean | null;
}
export type ConnectionsListResultList = Array<ConnectionsListResultItem>;
export interface ListConnectionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ConnectionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type CookiesListRequestDirection = "asc" | "desc";
export type CookiesListRequestExport = "csv";
export type CookiesListRequestOrderBy = "first_seen_at" | "last_seen_at";
export type CookiesListRequestSameSite = "lax" | "strict" | "none";
export type CookiesListRequestType = "first_party" | "unknown";
export interface ListCookiesRequest {
    /** Identifier */
    zoneId: string;
    /** The direction used to sort returned cookies.' */
    direction?: CookiesListRequestDirection | (string & {});
    /** Filters the returned cookies that match the specified domain attribute */
    domain?: string;
    /** Export the list of cookies as a file, limited to 50000 entries. */
    export?: CookiesListRequestExport | (string & {});
    /** Includes cookies that match one or more URL-encoded hostnames separated by commas. */
    hosts?: string;
    /** Filters the returned cookies that are set with HttpOnly */
    httpOnly?: boolean;
    /** Filters the returned cookies that match the specified name. Wildcards are supported at the start and end to support starts with, ends with and contains. e.g. session* */
    name?: string;
    /** The field used to sort returned cookies. */
    orderBy?: CookiesListRequestOrderBy | (string & {});
    /** The current page number of the paginated results. */
    page?: string;
    /** Includes connections that match one or more page URLs (separated by commas) where they were last seen */
    pageUrl?: string;
    /** Filters the returned cookies that match the specified path attribute */
    path?: string;
    /** The number of results per page. */
    perPage?: number;
    /** Filters the returned cookies that match the specified same_site attribute */
    sameSite?: CookiesListRequestSameSite | (string & {});
    /** Filters the returned cookies that are set with Secure */
    secure?: boolean;
    /** Filters the returned cookies that match the specified type attribute */
    type?: CookiesListRequestType | (string & {});
}
export type CookiesListResultItemType = "first_party" | "unknown";
export type CookiesListResultItemPageUrlsList = Array<string>;
export type CookiesListResultItemSameSiteAttribute = "lax" | "strict" | "none";
export interface CookiesListResultItem {
    /** Identifier */
    id: string;
    firstSeenAt: string;
    host: string;
    lastSeenAt: string;
    name: string;
    type: CookiesListResultItemType;
    domainAttribute?: string | null;
    expiresAttribute?: string | null;
    httpOnlyAttribute?: boolean | null;
    maxAgeAttribute?: number | null;
    pageUrls?: CookiesListResultItemPageUrlsList | null;
    pathAttribute?: string | null;
    sameSiteAttribute?: CookiesListResultItemSameSiteAttribute | null;
    secureAttribute?: boolean | null;
}
export type CookiesListResultList = Array<CookiesListResultItem>;
export interface ListCookiesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CookiesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListPoliciesRequest {
    /** Identifier */
    zoneId: string;
}
export type PoliciesListResultItemAction = "allow" | "log" | "add_reporting_directives";
export interface PoliciesListResultItem {
    /** Identifier */
    id: string;
    /** The action to take if the expression matches */
    action: PoliciesListResultItemAction;
    /** A description for the policy */
    description: string;
    /** Whether the policy is enabled */
    enabled: boolean;
    /** The expression which must match for the policy to be applied, using the Cloudflare Firewall rule expression syntax */
    expression: string;
    /** The policy which will be applied */
    value: string;
}
export type PoliciesListResultList = Array<PoliciesListResultItem>;
export interface ListPoliciesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PoliciesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ScriptsListRequestDirection = "asc" | "desc";
export type ScriptsListRequestExport = "csv";
export type ScriptsListRequestOrderBy = "first_seen_at" | "last_seen_at";
export interface ListScriptsRequest {
    /** Identifier */
    zoneId: string;
    /** The direction used to sort returned scripts. */
    direction?: ScriptsListRequestDirection | (string & {});
    /** When true, excludes scripts seen in a `/cdn-cgi` path from the returned scripts. The default value is true. */
    excludeCdnCgi?: boolean;
    /** When true, excludes duplicate scripts. We consider a script duplicate of another if their javascript content matches and they share the same url host and zone hostname. In such case, we return the most recent script for the URL host and zone hostname combination. */
    excludeDuplicates?: boolean;
    /** Excludes scripts whose URL contains one of the URL-encoded URLs separated by commas. */
    excludeUrls?: string;
    /** Export the list of scripts as a file, limited to 50000 entries. */
    export?: ScriptsListRequestExport | (string & {});
    /** Includes scripts that match one or more URL-encoded hostnames separated by commas. */
    hosts?: string;
    /** The field used to sort returned scripts. */
    orderBy?: ScriptsListRequestOrderBy | (string & {});
    /** The current page number of the paginated results. */
    page?: string;
    /** Includes scripts that match one or more page URLs (separated by commas) where they were last seen */
    pageUrl?: string;
    /** The number of results per page. */
    perPage?: number;
    /** When true, malicious scripts appear first in the returned scripts. */
    prioritizeMalicious?: boolean;
    /** Filters the returned scripts using a comma-separated list of scripts statuses. Accepted values: `active`, `infrequent`, and `inactive`. The default value is `active`. */
    status?: string;
    /** Includes scripts whose URL contain one or more URL-encoded URLs separated by commas. */
    urls?: string;
}
export type ScriptsListResultItemMaliciousDomainCategoriesList = Array<string>;
export type ScriptsListResultItemMaliciousUrlCategoriesList = Array<string>;
export type ScriptsListResultItemPageUrlsList = Array<string>;
export interface ScriptsListResultItem {
    /** Identifier */
    id: string;
    addedAt: string;
    firstSeenAt: string;
    host: string;
    lastSeenAt: string;
    url: string;
    urlContainsCdnCgiPath: boolean;
    /** The cryptomining score of the JavaScript content. */
    cryptominingScore?: number | null;
    /** The dataflow score of the JavaScript content. This field has been deprecated in favour of js_integrity_score. */
    dataflowScore?: number | null;
    domainReportedMalicious?: boolean | null;
    /** The timestamp of when the script was last fetched. */
    fetchedAt?: string | null;
    firstPageUrl?: string | null;
    /** The computed hash of the analyzed script. */
    hash?: string | null;
    /** The integrity score of the JavaScript content. */
    jsIntegrityScore?: number | null;
    /** The magecart score of the JavaScript content. */
    magecartScore?: number | null;
    maliciousDomainCategories?: ScriptsListResultItemMaliciousDomainCategoriesList | null;
    maliciousUrlCategories?: ScriptsListResultItemMaliciousUrlCategoriesList | null;
    /** The malware score of the JavaScript content. */
    malwareScore?: number | null;
    /** The obfuscation score of the JavaScript content. This field has been deprecated in favour of js_integrity_score. */
    obfuscationScore?: number | null;
    pageUrls?: ScriptsListResultItemPageUrlsList | null;
    urlReportedMalicious?: boolean | null;
}
export type ScriptsListResultList = Array<ScriptsListResultItem>;
export interface ListScriptsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ScriptsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface PutPageShieldRequest {
    /** Identifier */
    zoneId: string;
    /** When true, indicates that Client-Side Security is enabled. */
    enabled?: boolean;
    /** When true, CSP reports will be sent to https://csp-reporting.cloudflare.com/cdn-cgi/script_monitor/report */
    useCloudflareReportingEndpoint?: boolean;
    /** When true, the paths associated with connections URLs will also be analyzed. */
    useConnectionUrlPath?: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutPageShieldResponse {
    /** When true, indicates that Client-Side Security is enabled. */
    enabled: boolean;
    /** The timestamp of when Client-Side Security was last updated. */
    updatedAt: string;
    /** When true, CSP reports will be sent to https://csp-reporting.cloudflare.com/cdn-cgi/script_monitor/report */
    useCloudflareReportingEndpoint: boolean;
    /** When true, the paths associated with connections URLs will also be analyzed. */
    useConnectionUrlPath: boolean;
}
export type PoliciesUpdateRequestAction = "allow" | "log" | "add_reporting_directives";
export interface UpdatePolicyRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    policyId: string;
    /** The action to take if the expression matches */
    action?: PoliciesUpdateRequestAction | (string & {});
    /** A description for the policy */
    description?: string;
    /** Whether the policy is enabled */
    enabled?: boolean;
    /** The expression which must match for the policy to be applied, using the Cloudflare Firewall rule expression syntax */
    expression?: string;
    /** The policy which will be applied */
    value?: string;
}
export type PoliciesUpdateResponseAction = "allow" | "log" | "add_reporting_directives";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdatePolicyResponse {
    /** Identifier */
    id: string;
    /** The action to take if the expression matches */
    action: PoliciesUpdateResponseAction;
    /** A description for the policy */
    description: string;
    /** Whether the policy is enabled */
    enabled: boolean;
    /** The expression which must match for the policy to be applied, using the Cloudflare Firewall rule expression syntax */
    expression: string;
    /** The policy which will be applied */
    value: string;
}
export type CreatePolicyError = PolicyQuotaExceeded | Forbidden | CloudflareOpError;
/** Creates a rule that applies a client-side security action when its filter expression matches. */
export declare const createPolicy: API.OperationMethod<CreatePolicyRequest, CreatePolicyResponse, CreatePolicyError, CloudflareOpContext>;
export type DeletePolicyError = PolicyNotFound | Forbidden | CloudflareOpError;
/** Permanently deletes a content security rule by ID. */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest, DeletePolicyResponse, DeletePolicyError, CloudflareOpContext>;
export type GetConnectionError = CloudflareOpError;
/** Returns a webpage connection detected on the zone by connection ID. */
export declare const getConnection: API.OperationMethod<GetConnectionRequest, GetConnectionResponse, GetConnectionError, CloudflareOpContext>;
export type GetCookyError = CloudflareOpError;
/** Returns a cookie detected on the zone by cookie ID. */
export declare const getCooky: API.OperationMethod<GetCookyRequest, GetCookyResponse, GetCookyError, CloudflareOpContext>;
export type GetPageShieldError = Forbidden | CloudflareOpError;
/** Returns the client-side security product enablement status and reporting behaviors. */
export declare const getPageShield: API.OperationMethod<GetPageShieldRequest, GetPageShieldResponse, GetPageShieldError, CloudflareOpContext>;
export type GetPolicyError = PolicyNotFound | Forbidden | CloudflareOpError;
/** Returns a content security rule by ID. */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest, GetPolicyResponse, GetPolicyError, CloudflareOpContext>;
export type GetScriptError = CloudflareOpError;
/** Returns a script detected on the zone by script ID. */
export declare const getScript: API.OperationMethod<GetScriptRequest, GetScriptResponse, GetScriptError, CloudflareOpContext>;
export type ListConnectionsError = CloudflareOpError;
/** Lists outbound connections made by webpages in the zone. */
export declare const listConnections: API.PaginatedOperationMethod<ListConnectionsRequest, ListConnectionsResponse, ListConnectionsError, CloudflareOpContext, ConnectionsListResultItem>;
export type ListCookiesError = CloudflareOpError;
/** Lists cookies detected on the zone. */
export declare const listCookies: API.PaginatedOperationMethod<ListCookiesRequest, ListCookiesResponse, ListCookiesError, CloudflareOpContext, CookiesListResultItem>;
export type ListPoliciesError = Forbidden | CloudflareOpError;
/** Lists content security rules configured for the zone. */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesRequest, ListPoliciesResponse, ListPoliciesError, CloudflareOpContext, PoliciesListResultItem>;
export type ListScriptsError = CloudflareOpError;
/** Lists scripts detected on webpages in the zone, with filtering and pagination. */
export declare const listScripts: API.PaginatedOperationMethod<ListScriptsRequest, ListScriptsResponse, ListScriptsError, CloudflareOpContext, ScriptsListResultItem>;
export type PutPageShieldError = NotEntitled | Forbidden | CloudflareOpError;
/** Updates client-side security enablement and reporting behaviors for the zone. */
export declare const putPageShield: API.OperationMethod<PutPageShieldRequest, PutPageShieldResponse, PutPageShieldError, CloudflareOpContext>;
export type UpdatePolicyError = PolicyNotFound | Forbidden | CloudflareOpError;
/** Updates the description, action, expression, enabled state, and policy value for a content security rule. */
export declare const updatePolicy: API.OperationMethod<UpdatePolicyRequest, UpdatePolicyResponse, UpdatePolicyError, CloudflareOpContext>;
//# sourceMappingURL=page_shield.d.ts.map