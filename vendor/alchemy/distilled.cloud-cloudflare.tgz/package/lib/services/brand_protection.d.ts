import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type QueriesBulkRequestQueriesItemMap = {
    [key: string]: unknown | undefined;
};
export type QueriesBulkRequestQueriesList = Array<QueriesBulkRequestQueriesItemMap>;
export interface BulkQueryRequest {
    accountId: string;
    queries?: QueriesBulkRequestQueriesList;
}
export interface BulkQueryResponse {
}
export interface CreateLogoRequest {
    accountId: string;
    matchType?: string;
    tag?: string;
    threshold?: number;
    image?: unknown;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateLogoResponse {
    id?: number | null;
    tag?: string | null;
    uploadPath?: string | null;
}
export interface CreateQueryRequest {
    accountId: string;
    id?: string;
    scan?: boolean;
    tag?: string;
    maxTime?: string;
    minTime?: string;
    stringMatches?: unknown;
    bodyScan?: boolean;
    bodyTag?: string;
}
export interface CreateQueryResponse {
}
export interface CreateV2LogoRequest {
    accountId: string;
    /** Base64 encoded image data. Can include data URI prefix (e.g., 'data:image/png;base64,...') or just the base64 string. */
    imageData: string;
    /** Minimum similarity score (0-1) required for visual matches */
    similarityThreshold: number;
    /** Unique identifier for the logo query */
    tag: string;
    /** If true, search historic scanned images for matches above the similarity threshold */
    searchLookback?: boolean;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateV2LogoResponse {
    message: string;
    queryId?: number | null;
}
export interface DeleteLogoRequest {
    accountId: string;
    logoId: string;
}
export interface DeleteLogoResponse {
}
export interface DeleteQueryRequest {
    accountId: string;
    id?: string;
    scan?: boolean;
    tag?: string;
}
export interface DeleteQueryResponse {
}
export interface DeleteV2LogoRequest {
    accountId: string;
    queryId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteV2LogoResponse {
    message: string;
}
export type LogoMatchesDownloadRequestLogoIdList = Array<string>;
export interface DownloadLogoMatchRequest {
    accountId: string;
    limit?: string;
    logoId?: LogoMatchesDownloadRequestLogoIdList;
    offset?: string;
}
export type LogoMatchesDownloadResponseMatchesItemMap = {
    [key: string]: unknown | undefined;
};
export type LogoMatchesDownloadResponseMatchesList = Array<LogoMatchesDownloadResponseMatchesItemMap>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DownloadLogoMatchResponse {
    matches?: LogoMatchesDownloadResponseMatchesList | null;
    total?: number | null;
}
export interface DownloadMatchRequest {
    accountId: string;
    id?: string;
    includeDismissed?: boolean;
    includeDomainId?: boolean;
    limit?: number;
    offset?: number;
}
export type MatchesDownloadResponseMatchesItemMap = {
    [key: string]: unknown | undefined;
};
export type MatchesDownloadResponseMatchesList = Array<MatchesDownloadResponseMatchesItemMap>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DownloadMatchResponse {
    matches?: MatchesDownloadResponseMatchesList | null;
    total?: number | null;
}
export type LogoMatchesGetRequestLogoIdList = Array<string>;
export interface GetLogoMatchRequest {
    accountId: string;
    limit?: string;
    logoId?: LogoMatchesGetRequestLogoIdList;
    offset?: string;
}
export type LogoMatchesGetResponseMatchesItemMap = {
    [key: string]: unknown | undefined;
};
export type LogoMatchesGetResponseMatchesList = Array<LogoMatchesGetResponseMatchesItemMap>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetLogoMatchResponse {
    matches?: LogoMatchesGetResponseMatchesList | null;
    total?: number | null;
}
export interface GetMatchRequest {
    accountId: string;
    id?: string;
    includeDismissed?: boolean;
    includeDomainId?: boolean;
    limit?: number;
    offset?: number;
}
export type MatchesGetResponseMatchesItemMap = {
    [key: string]: unknown | undefined;
};
export type MatchesGetResponseMatchesList = Array<MatchesGetResponseMatchesItemMap>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetMatchResponse {
    matches?: MatchesGetResponseMatchesList | null;
    total?: number | null;
}
export interface GetV2LogoRequest {
    accountId: string;
    /** Optional query ID to retrieve a specific logo query */
    id?: string;
    /** If true, include base64-encoded image data in the response */
    download?: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetV2LogoResponse {
    id: number;
    r2Path: string;
    similarityThreshold: number;
    tag: string;
    uploadedAt: string;
    /** MIME type of the image (only present when download=true) */
    contentType?: string | null;
    /** Base64-encoded image data (only present when download=true) */
    imageData?: string | null;
}
export type V2LogoMatchesGetRequestOrder = "asc" | "desc";
export type V2LogoMatchesGetRequestOrderBy = "matchedAt" | "domain" | "similarityScore" | "registrar";
export interface GetV2LogoMatchRequest {
    accountId: string;
    queryId: string;
    download?: string;
    limit?: string;
    offset?: string;
    /** Sort order. Options: 'asc' (ascending) or 'desc' (descending) */
    order?: V2LogoMatchesGetRequestOrder | (string & {});
    /** Column to sort by. Options: 'matchedAt', 'domain', 'similarityScore', or 'registrar' */
    orderBy?: V2LogoMatchesGetRequestOrderBy | (string & {});
}
export interface V2LogoMatchesGetResponseMatchesItem {
    id: number;
    domain: string;
    matchedAt: string;
    queryId: number;
    registrar: string;
    similarityScore: number;
    urlScanId: string;
    contentType?: string | null;
    imageData?: string | null;
}
export type V2LogoMatchesGetResponseMatchesList = Array<V2LogoMatchesGetResponseMatchesItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetV2LogoMatchResponse {
    matches: V2LogoMatchesGetResponseMatchesList;
    total: number;
}
export type V2MatchesGetRequestQueryIdList = Array<string>;
export type V2MatchesGetRequestOrder = "asc" | "desc";
export type V2MatchesGetRequestOrderBy = "domain" | "first_seen" | "registrar";
export interface GetV2MatchRequest {
    accountId: string;
    /** Query ID or comma-separated list of Query IDs. When multiple IDs are provided, matches are deduplicated across queries and each match includes a match_details array with per-match query metadata and dismissed state. */
    queryId: V2MatchesGetRequestQueryIdList;
    /** Filter matches by domain name (substring match) */
    domainSearch?: string;
    includeDismissed?: string;
    includeDomainId?: string;
    limit?: string;
    offset?: string;
    /** Sort order. Options: 'asc' (ascending) or 'desc' (descending) */
    order?: V2MatchesGetRequestOrder | (string & {});
    /** Column to sort by. Options: 'domain', 'first_seen', or 'registrar' */
    orderBy?: V2MatchesGetRequestOrderBy | (string & {});
}
export interface V2MatchesGetResponseMatchesItemPublicScans {
    submissionId: string;
}
export interface V2MatchesGetResponseMatchesItemMatchDetailsItem {
    /** Individual dismissed state for this specific match. */
    dismissed: boolean;
    matchId: number;
    queryId: number;
    /** Tag associated with the query, if one exists. */
    queryTag: string;
}
export type V2MatchesGetResponseMatchesItemMatchDetailsList = Array<V2MatchesGetResponseMatchesItemMatchDetailsItem>;
export interface V2MatchesGetResponseMatchesItem {
    domain: string;
    firstSeen: string;
    publicScans: V2MatchesGetResponseMatchesItemPublicScans;
    registrar: string;
    scanStatus: string;
    scanSubmissionId: number;
    source: string;
    /** Whether the match is dismissed. Only present for single-query requests. For multi-query requests, use the dismissed field in each match_details entry. */
    dismissed?: boolean | null;
    /** Per-match detail objects with query metadata and individual dismissed state. Only present when multiple query_ids are requested. */
    matchDetails?: V2MatchesGetResponseMatchesItemMatchDetailsList | null;
}
export type V2MatchesGetResponseMatchesList = Array<V2MatchesGetResponseMatchesItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetV2MatchResponse {
    matches: V2MatchesGetResponseMatchesList;
    total: number;
}
export interface GetV2QueryRequest {
    accountId: string;
    id?: string;
    /** Optional page number for paginated list requests. Defaults to 1 when only per_page is supplied. Omit page and per_page to preserve the legacy full-list response. */
    page?: number;
    /** Optional number of queries per page for paginated list requests. Defaults to 100 when only page is supplied. Maximum 100. Omit page and per_page to preserve the legacy full-list response. */
    perPage?: number;
}
export interface V2QueriesGetResultCase0ItemParametersStringMatchesItem {
    pattern: string;
}
export type V2QueriesGetResultCase0ItemParametersStringMatchesList = Array<V2QueriesGetResultCase0ItemParametersStringMatchesItem>;
export interface V2QueriesGetResultCase0ItemParameters {
    stringMatches: V2QueriesGetResultCase0ItemParametersStringMatchesList;
    maxTime?: string | null;
    minTime?: string | null;
}
export interface V2QueriesGetResultCase0Item {
    created: string;
    parameters: V2QueriesGetResultCase0ItemParameters;
    queryId: number;
    queryTag: string;
    scan: boolean;
    updated: string;
}
export type V2QueriesGetResultCase0List = Array<V2QueriesGetResultCase0Item>;
export type V2QueriesGetResultCase1ParametersStringMatchesItem = V2QueriesGetResultCase0ItemParametersStringMatchesItem;
export type V2QueriesGetResultCase1ParametersStringMatchesList = Array<V2QueriesGetResultCase0ItemParametersStringMatchesItem>;
export interface V2QueriesGetResultCase1Parameters {
    stringMatches: V2QueriesGetResultCase1ParametersStringMatchesList;
    maxTime?: string | null;
    minTime?: string | null;
}
export interface V2QueriesGetResultCase1 {
    created: string;
    parameters: V2QueriesGetResultCase1Parameters;
    queryId: number;
    queryTag: string;
    scan: boolean;
    updated: string;
}
export type V2QueriesGetResult = V2QueriesGetResultCase0List | V2QueriesGetResultCase1;
export type GetV2QueryResponse = V2QueriesGetResult;
export interface SubmitBrandProtectionRequest {
    accountId: string;
}
export type SubmitResponseSkippedUrlsItemMap = {
    [key: string]: unknown | undefined;
};
export type SubmitResponseSkippedUrlsList = Array<SubmitResponseSkippedUrlsItemMap>;
export type SubmitResponseSubmittedUrlsItemMap = {
    [key: string]: unknown | undefined;
};
export type SubmitResponseSubmittedUrlsList = Array<SubmitResponseSubmittedUrlsItemMap>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface SubmitBrandProtectionResponse {
    skippedUrls?: SubmitResponseSkippedUrlsList | null;
    submittedUrls?: SubmitResponseSubmittedUrlsList | null;
}
export interface UrlInfoBrandProtectionRequest {
    accountId: string;
}
export type UrlInfoResultItemMap = {
    [key: string]: unknown | undefined;
};
export type UrlInfoResultList = Array<UrlInfoResultItemMap>;
export interface UrlInfoBrandProtectionResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UrlInfoResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type BulkQueryError = CloudflareOpError;
/** Return a success message after creating new saved string queries in bulk */
export declare const bulkQuery: API.OperationMethod<BulkQueryRequest, BulkQueryResponse, BulkQueryError, CloudflareOpContext>;
export type CreateLogoError = CloudflareOpError;
/** Return new saved logo queries created from image files */
export declare const createLogo: API.OperationMethod<CreateLogoRequest, CreateLogoResponse, CreateLogoError, CloudflareOpContext>;
export type CreateQueryError = CloudflareOpError;
/** Return a success message after creating new saved string queries */
export declare const createQuery: API.OperationMethod<CreateQueryRequest, CreateQueryResponse, CreateQueryError, CloudflareOpContext>;
export type CreateV2LogoError = CloudflareOpError;
/** Create a new saved brand protection logo query for visual similarity matching */
export declare const createV2Logo: API.OperationMethod<CreateV2LogoRequest, CreateV2LogoResponse, CreateV2LogoError, CloudflareOpContext>;
export type DeleteLogoError = CloudflareOpError;
/** Return a success message after deleting saved logo queries by ID */
export declare const deleteLogo: API.OperationMethod<DeleteLogoRequest, DeleteLogoResponse, DeleteLogoError, CloudflareOpContext>;
export type DeleteQueryError = CloudflareOpError;
/** Return a success message after deleting saved string queries by ID */
export declare const deleteQuery: API.OperationMethod<DeleteQueryRequest, DeleteQueryResponse, DeleteQueryError, CloudflareOpContext>;
export type DeleteV2LogoError = CloudflareOpError;
/** Delete a saved brand protection logo query. Returns 404 if the query ID doesn't exist. */
export declare const deleteV2Logo: API.OperationMethod<DeleteV2LogoRequest, DeleteV2LogoResponse, DeleteV2LogoError, CloudflareOpContext>;
export type DownloadLogoMatchError = CloudflareOpError;
/** Return matches as CSV for logo queries based on ID */
export declare const downloadLogoMatch: API.OperationMethod<DownloadLogoMatchRequest, DownloadLogoMatchResponse, DownloadLogoMatchError, CloudflareOpContext>;
export type DownloadMatchError = CloudflareOpError;
/** Return matches as CSV for string queries based on ID */
export declare const downloadMatch: API.OperationMethod<DownloadMatchRequest, DownloadMatchResponse, DownloadMatchError, CloudflareOpContext>;
export type GetLogoMatchError = CloudflareOpError;
/** Return matches for logo queries based on ID */
export declare const getLogoMatch: API.OperationMethod<GetLogoMatchRequest, GetLogoMatchResponse, GetLogoMatchError, CloudflareOpContext>;
export type GetMatchError = CloudflareOpError;
/** Return matches for string queries based on ID */
export declare const getMatch: API.OperationMethod<GetMatchRequest, GetMatchResponse, GetMatchError, CloudflareOpContext>;
export type GetV2LogoError = CloudflareOpError;
/** Get all saved brand protection logo queries for an account. Optionally specify id to get a single query. Set download=true to include base64-encoded image data. */
export declare const getV2Logo: API.OperationMethod<GetV2LogoRequest, GetV2LogoResponse, GetV2LogoError, CloudflareOpContext>;
export type GetV2LogoMatchError = CloudflareOpError;
/** Get paginated list of logo matches for a specific brand protection logo query */
export declare const getV2LogoMatch: API.OperationMethod<GetV2LogoMatchRequest, GetV2LogoMatchResponse, GetV2LogoMatchError, CloudflareOpContext>;
export type GetV2MatchError = CloudflareOpError;
/** Get paginated list of domain matches for one or more brand protection queries. When multiple query_ids are provided (comma-separated), matches are deduplicated across queries and each match includes a match_details array with per-match query metadata and individual dismissed state. */
export declare const getV2Match: API.OperationMethod<GetV2MatchRequest, GetV2MatchResponse, GetV2MatchError, CloudflareOpContext>;
export type GetV2QueryError = CloudflareOpError;
/** Get all saved brand protection queries for an account */
export declare const getV2Query: API.OperationMethod<GetV2QueryRequest, GetV2QueryResponse, GetV2QueryError, CloudflareOpContext>;
export type SubmitBrandProtectionError = CloudflareOpError;
/** Return new URL submissions */
export declare const submitBrandProtection: API.OperationMethod<SubmitBrandProtectionRequest, SubmitBrandProtectionResponse, SubmitBrandProtectionError, CloudflareOpContext>;
export type UrlInfoBrandProtectionError = CloudflareOpError;
/** Return submitted URLs based on ID */
export declare const urlInfoBrandProtection: API.PaginatedOperationMethod<UrlInfoBrandProtectionRequest, UrlInfoBrandProtectionResponse, UrlInfoBrandProtectionError, CloudflareOpContext, UrlInfoResultItemMap>;
//# sourceMappingURL=brand_protection.d.ts.map