import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const HyperdriveConfigAlreadyExists_base: S.TaggedErrorClass<"HyperdriveConfigAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HyperdriveConfigAlreadyExists extends /*@__PURE__*/ HyperdriveConfigAlreadyExists_base {
}
declare const HyperdriveConfigNotFound_base: S.TaggedErrorClass<"HyperdriveConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HyperdriveConfigNotFound extends /*@__PURE__*/ HyperdriveConfigNotFound_base {
}
declare const HyperdriveOriginUnavailable_base: S.TaggedErrorClass<"HyperdriveOriginUnavailable", {
    readonly code: any;
    readonly message: any;
}>;
export declare class HyperdriveOriginUnavailable extends /*@__PURE__*/ HyperdriveOriginUnavailable_base {
}
declare const InvalidHyperdriveConfig_base: S.TaggedErrorClass<"InvalidHyperdriveConfig", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidHyperdriveConfig extends /*@__PURE__*/ InvalidHyperdriveConfig_base {
}
declare const InvalidObjectIdentifier_base: S.TaggedErrorClass<"InvalidObjectIdentifier", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidObjectIdentifier extends /*@__PURE__*/ InvalidObjectIdentifier_base {
}
declare const MethodNotAllowed_base: S.TaggedErrorClass<"MethodNotAllowed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MethodNotAllowed extends /*@__PURE__*/ MethodNotAllowed_base {
}
declare const PrivateHostNotAllowed_base: S.TaggedErrorClass<"PrivateHostNotAllowed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PrivateHostNotAllowed extends /*@__PURE__*/ PrivateHostNotAllowed_base {
}
export interface ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCreateDisabled {
    disabled: boolean;
    maxAge?: number;
    staleWhileRevalidate?: number;
}
export interface ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCreateEnabled {
    disabled?: boolean;
    /** Specify the maximum duration (in seconds) items should persist in the cache. Defaults to 60 seconds if not specified. */
    maxAge?: number;
    /** Specify the number of seconds the cache may serve a stale response. Defaults to 15 seconds if not specified. */
    staleWhileRevalidate?: number;
}
export type ConfigsCreateRequestCaching = ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCreateDisabled | ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCreateEnabled;
export interface ConfigsCreateRequestMtls {
    /** Define CA certificate ID obtained after uploading CA cert. */
    caCertificateId?: string;
    /** Define mTLS certificate ID obtained after uploading client cert. */
    mtlsCertificateId?: string;
    /** PostgreSQL accepts `require`, `verify-ca`, and `verify-full`. MySQL accepts `REQUIRED`, `VERIFY_CA`, and `VERIFY_IDENTITY`. The verify modes require a CA certificate; the require modes cannot be used with a CA certificate. */
    sslmode?: string;
}
export interface CreateConfigRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    /** Combines database connection fields with exactly one supported network location. */
    origin?: unknown;
    caching?: ConfigsCreateRequestCaching;
    /** Selects a PlanetScale database and provisions credentials managed by Cloudflare when creating a Hyperdrive configuration. The Cloudflare account must already be linked to PlanetScale in the Hyperdrive dashboard. The selection is returned as read-only metadata and cannot be changed with replace or update operations. */
    integration?: unknown;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateRequestMtls;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number;
}
export interface ConfigsCreateResponseCaching {
    /** Defines whether caching is disabled. */
    disabled: boolean;
    /** Defines the maximum duration (in seconds) items persist in the cache. */
    maxAge?: number | null;
    /** Defines the number of seconds the cache may serve a stale response. */
    staleWhileRevalidate?: number | null;
}
export type ConfigsCreateResponseOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsCreateResponseOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the publicly reachable hostname or IP of your origin database. Private, loopback, and link-local IP addresses are not allowed. */
    host: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsCreateResponseOriginPublicDatabaseScheme;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsCreateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsCreateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsCreateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsCreateResponseOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsCreateResponseOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsCreateResponseOriginDatabaseReachableThroughAWorkersVPCScheme;
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsCreateResponseOrigin = ConfigsCreateResponseOriginPublicDatabase | ConfigsCreateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsCreateResponseOriginDatabaseReachableThroughAWorkersVPC;
export type ConfigsCreateResponseIntegrationProvider = "planetscale";
export type ConfigsCreateResponseIntegrationScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsCreateResponseIntegration {
    /** The name of the PlanetScale database branch. */
    databaseBranchName: string;
    /** The name of the PlanetScale database. */
    databaseName: string;
    /** The name of the PlanetScale organization. */
    organizationName: string;
    /** The database integration provider used by this operation. */
    provider: ConfigsCreateResponseIntegrationProvider;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsCreateResponseIntegrationScheme;
    /** The database name to use when connecting. Defaults to `postgres` for PostgreSQL and `mysql` for MySQL. */
    customDatabaseName?: string | null;
}
export interface ConfigsCreateResponseMtls {
    /** Define CA certificate ID obtained after uploading CA cert. */
    caCertificateId?: string | null;
    /** Define mTLS certificate ID obtained after uploading client cert. */
    mtlsCertificateId?: string | null;
    /** PostgreSQL accepts `require`, `verify-ca`, and `verify-full`. MySQL accepts `REQUIRED`, `VERIFY_CA`, and `VERIFY_IDENTITY`. The verify modes require a CA certificate; the require modes cannot be used with a CA certificate. */
    sslmode?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateConfigResponse {
    /** Define configurations using a unique string identifier. */
    id: string;
    caching: ConfigsCreateResponseCaching;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    /** Combines database connection fields with exactly one supported network location. */
    origin: ConfigsCreateResponseOrigin;
    /** Defines the creation time of the Hyperdrive configuration. */
    createdOn?: string | null;
    /** Selects a PlanetScale database and provisions credentials managed by Cloudflare when creating a Hyperdrive configuration. The Cloudflare account must already be linked to PlanetScale in the Hyperdrive dashboard. The selection is returned as read-only metadata and cannot be changed with replace or update operations. */
    integration?: ConfigsCreateResponseIntegration | null;
    /** Defines the last modified time of the Hyperdrive configuration. */
    modifiedOn?: string | null;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateResponseMtls | null;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number | null;
    /** Defines the last time the Hyperdrive connection pool was explicitly restarted via the restart endpoint. Omitted if the pool has never been explicitly restarted. */
    restartedOn?: string | null;
}
export interface DeleteConfigRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
    /** Define configurations using a unique string identifier. */
    hyperdriveId: string;
}
export type DeleteConfigResponse = unknown;
export interface GetConfigRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
    /** Define configurations using a unique string identifier. */
    hyperdriveId: string;
}
export type ConfigsGetResponseCaching = ConfigsCreateResponseCaching;
export type ConfigsGetResponseOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsGetResponseOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the publicly reachable hostname or IP of your origin database. Private, loopback, and link-local IP addresses are not allowed. */
    host: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsGetResponseOriginPublicDatabaseScheme;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsGetResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsGetResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsGetResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsGetResponseOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsGetResponseOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsGetResponseOriginDatabaseReachableThroughAWorkersVPCScheme;
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsGetResponseOrigin = ConfigsGetResponseOriginPublicDatabase | ConfigsGetResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsGetResponseOriginDatabaseReachableThroughAWorkersVPC;
export type ConfigsGetResponseIntegrationProvider = "planetscale";
export type ConfigsGetResponseIntegrationScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsGetResponseIntegration {
    /** The name of the PlanetScale database branch. */
    databaseBranchName: string;
    /** The name of the PlanetScale database. */
    databaseName: string;
    /** The name of the PlanetScale organization. */
    organizationName: string;
    /** The database integration provider used by this operation. */
    provider: ConfigsGetResponseIntegrationProvider;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsGetResponseIntegrationScheme;
    /** The database name to use when connecting. Defaults to `postgres` for PostgreSQL and `mysql` for MySQL. */
    customDatabaseName?: string | null;
}
export type ConfigsGetResponseMtls = ConfigsCreateResponseMtls;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigResponse {
    /** Define configurations using a unique string identifier. */
    id: string;
    caching: ConfigsCreateResponseCaching;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    /** Combines database connection fields with exactly one supported network location. */
    origin: ConfigsGetResponseOrigin;
    /** Defines the creation time of the Hyperdrive configuration. */
    createdOn?: string | null;
    /** Selects a PlanetScale database and provisions credentials managed by Cloudflare when creating a Hyperdrive configuration. The Cloudflare account must already be linked to PlanetScale in the Hyperdrive dashboard. The selection is returned as read-only metadata and cannot be changed with replace or update operations. */
    integration?: ConfigsGetResponseIntegration | null;
    /** Defines the last modified time of the Hyperdrive configuration. */
    modifiedOn?: string | null;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateResponseMtls | null;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number | null;
    /** Defines the last time the Hyperdrive connection pool was explicitly restarted via the restart endpoint. Omitted if the pool has never been explicitly restarted. */
    restartedOn?: string | null;
}
export interface ListConfigsRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type ConfigsListResultItemCaching = ConfigsCreateResponseCaching;
export type ConfigsListResultItemOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsListResultItemOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the publicly reachable hostname or IP of your origin database. Private, loopback, and link-local IP addresses are not allowed. */
    host: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsListResultItemOriginPublicDatabaseScheme;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsListResultItemOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsListResultItemOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsListResultItemOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsListResultItemOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsListResultItemOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsListResultItemOriginDatabaseReachableThroughAWorkersVPCScheme;
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsListResultItemOrigin = ConfigsListResultItemOriginPublicDatabase | ConfigsListResultItemOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsListResultItemOriginDatabaseReachableThroughAWorkersVPC;
export type ConfigsListResultItemIntegrationProvider = "planetscale";
export type ConfigsListResultItemIntegrationScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsListResultItemIntegration {
    /** The name of the PlanetScale database branch. */
    databaseBranchName: string;
    /** The name of the PlanetScale database. */
    databaseName: string;
    /** The name of the PlanetScale organization. */
    organizationName: string;
    /** The database integration provider used by this operation. */
    provider: ConfigsListResultItemIntegrationProvider;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsListResultItemIntegrationScheme;
    /** The database name to use when connecting. Defaults to `postgres` for PostgreSQL and `mysql` for MySQL. */
    customDatabaseName?: string | null;
}
export type ConfigsListResultItemMtls = ConfigsCreateResponseMtls;
export interface ConfigsListResultItem {
    /** Define configurations using a unique string identifier. */
    id: string;
    caching: ConfigsCreateResponseCaching;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    /** Combines database connection fields with exactly one supported network location. */
    origin: ConfigsListResultItemOrigin;
    /** Defines the creation time of the Hyperdrive configuration. */
    createdOn?: string | null;
    /** Selects a PlanetScale database and provisions credentials managed by Cloudflare when creating a Hyperdrive configuration. The Cloudflare account must already be linked to PlanetScale in the Hyperdrive dashboard. The selection is returned as read-only metadata and cannot be changed with replace or update operations. */
    integration?: ConfigsListResultItemIntegration | null;
    /** Defines the last modified time of the Hyperdrive configuration. */
    modifiedOn?: string | null;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateResponseMtls | null;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number | null;
    /** Defines the last time the Hyperdrive connection pool was explicitly restarted via the restart endpoint. Omitted if the pool has never been explicitly restarted. */
    restartedOn?: string | null;
}
export type ConfigsListResultList = Array<ConfigsListResultItem>;
export interface ListConfigsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ConfigsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ConfigsEditRequestCachingHyperdriveHyperdriveCachingCommon {
    /** Set to true to disable caching of SQL responses. Default is false. */
    disabled?: boolean;
}
export interface ConfigsEditRequestCachingHyperdriveHyperdriveCachingEnabled {
    /** Set to true to disable caching of SQL responses. Default is false. */
    disabled?: boolean;
    /** Specify the maximum duration (in seconds) items should persist in the cache. Defaults to 60 seconds if not specified. */
    maxAge?: number;
    /** Specify the number of seconds the cache may serve a stale response. Defaults to 15 seconds if not specified. */
    staleWhileRevalidate?: number;
}
export type ConfigsEditRequestCaching = ConfigsEditRequestCachingHyperdriveHyperdriveCachingCommon | ConfigsEditRequestCachingHyperdriveHyperdriveCachingEnabled;
export type ConfigsEditRequestMtls = ConfigsCreateRequestMtls;
export type ConfigsEditRequestOriginHyperdriveHyperdriveDatabaseScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsEditRequestOriginHyperdriveHyperdriveDatabase {
    /** Set the name of your origin database. */
    database?: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password?: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme?: ConfigsEditRequestOriginHyperdriveHyperdriveDatabaseScheme | (string & {});
    /** Set the user of your origin database. */
    user?: string;
}
export interface ConfigsEditRequestOriginHyperdriveInternetOrigin {
    /** Defines the publicly reachable hostname or IP of your origin database. Private, loopback, and link-local IP addresses are not allowed. */
    host: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
}
export interface ConfigsEditRequestOriginHyperdriveOverAccessOrigin {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
}
export interface ConfigsEditRequestOriginHyperdriveVPCServiceOrigin {
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
}
export type ConfigsEditRequestOrigin = ConfigsEditRequestOriginHyperdriveHyperdriveDatabase | ConfigsEditRequestOriginHyperdriveInternetOrigin | ConfigsEditRequestOriginHyperdriveOverAccessOrigin | ConfigsEditRequestOriginHyperdriveVPCServiceOrigin;
export interface PatchConfigRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
    /** Define configurations using a unique string identifier. */
    hyperdriveId: string;
    caching?: ConfigsEditRequestCaching;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateRequestMtls;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. An empty value leaves the name unchanged. */
    name?: string;
    /** Connect to a database through a Workers VPC Service. TLS settings (mTLS, sslmode) cannot be configured on the Hyperdrive when using a VPC Service origin; TLS must be managed on the VPC Service itself. */
    origin?: ConfigsEditRequestOrigin;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number;
}
export type ConfigsEditResponseCaching = ConfigsCreateResponseCaching;
export type ConfigsEditResponseOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsEditResponseOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the publicly reachable hostname or IP of your origin database. Private, loopback, and link-local IP addresses are not allowed. */
    host: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsEditResponseOriginPublicDatabaseScheme;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsEditResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsEditResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsEditResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsEditResponseOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsEditResponseOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsEditResponseOriginDatabaseReachableThroughAWorkersVPCScheme;
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsEditResponseOrigin = ConfigsEditResponseOriginPublicDatabase | ConfigsEditResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsEditResponseOriginDatabaseReachableThroughAWorkersVPC;
export type ConfigsEditResponseIntegrationProvider = "planetscale";
export type ConfigsEditResponseIntegrationScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsEditResponseIntegration {
    /** The name of the PlanetScale database branch. */
    databaseBranchName: string;
    /** The name of the PlanetScale database. */
    databaseName: string;
    /** The name of the PlanetScale organization. */
    organizationName: string;
    /** The database integration provider used by this operation. */
    provider: ConfigsEditResponseIntegrationProvider;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsEditResponseIntegrationScheme;
    /** The database name to use when connecting. Defaults to `postgres` for PostgreSQL and `mysql` for MySQL. */
    customDatabaseName?: string | null;
}
export type ConfigsEditResponseMtls = ConfigsCreateResponseMtls;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchConfigResponse {
    /** Define configurations using a unique string identifier. */
    id: string;
    caching: ConfigsCreateResponseCaching;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    /** Combines database connection fields with exactly one supported network location. */
    origin: ConfigsEditResponseOrigin;
    /** Defines the creation time of the Hyperdrive configuration. */
    createdOn?: string | null;
    /** Selects a PlanetScale database and provisions credentials managed by Cloudflare when creating a Hyperdrive configuration. The Cloudflare account must already be linked to PlanetScale in the Hyperdrive dashboard. The selection is returned as read-only metadata and cannot be changed with replace or update operations. */
    integration?: ConfigsEditResponseIntegration | null;
    /** Defines the last modified time of the Hyperdrive configuration. */
    modifiedOn?: string | null;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateResponseMtls | null;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number | null;
    /** Defines the last time the Hyperdrive connection pool was explicitly restarted via the restart endpoint. Omitted if the pool has never been explicitly restarted. */
    restartedOn?: string | null;
}
export interface RestartConfigRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
    /** Define configurations using a unique string identifier. */
    hyperdriveId: string;
}
export type RestartConfigResponseCaching = ConfigsCreateResponseCaching;
export type RestartConfigResponseOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export interface RestartConfigResponseOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the publicly reachable hostname or IP of your origin database. Private, loopback, and link-local IP addresses are not allowed. */
    host: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: RestartConfigResponseOriginPublicDatabaseScheme;
    /** Set the user of your origin database. */
    user: string;
}
export type RestartConfigResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export interface RestartConfigResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: RestartConfigResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme;
    /** Set the user of your origin database. */
    user: string;
}
export type RestartConfigResponseOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export interface RestartConfigResponseOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: RestartConfigResponseOriginDatabaseReachableThroughAWorkersVPCScheme;
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export type RestartConfigResponseOrigin = RestartConfigResponseOriginPublicDatabase | RestartConfigResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel | RestartConfigResponseOriginDatabaseReachableThroughAWorkersVPC;
export type RestartConfigResponseIntegrationProvider = "planetscale";
export type RestartConfigResponseIntegrationScheme = "postgres" | "postgresql" | "mysql";
export interface RestartConfigResponseIntegration {
    /** The name of the PlanetScale database branch. */
    databaseBranchName: string;
    /** The name of the PlanetScale database. */
    databaseName: string;
    /** The name of the PlanetScale organization. */
    organizationName: string;
    /** The database integration provider used by this operation. */
    provider: RestartConfigResponseIntegrationProvider;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: RestartConfigResponseIntegrationScheme;
    /** The database name to use when connecting. Defaults to `postgres` for PostgreSQL and `mysql` for MySQL. */
    customDatabaseName?: string | null;
}
export type RestartConfigResponseMtls = ConfigsCreateResponseMtls;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RestartConfigResponse {
    /** Define configurations using a unique string identifier. */
    id: string;
    caching: ConfigsCreateResponseCaching;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    /** Combines database connection fields with exactly one supported network location. */
    origin: RestartConfigResponseOrigin;
    /** Defines the creation time of the Hyperdrive configuration. */
    createdOn?: string | null;
    /** Selects a PlanetScale database and provisions credentials managed by Cloudflare when creating a Hyperdrive configuration. The Cloudflare account must already be linked to PlanetScale in the Hyperdrive dashboard. The selection is returned as read-only metadata and cannot be changed with replace or update operations. */
    integration?: RestartConfigResponseIntegration | null;
    /** Defines the last modified time of the Hyperdrive configuration. */
    modifiedOn?: string | null;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateResponseMtls | null;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number | null;
    /** Defines the last time the Hyperdrive connection pool was explicitly restarted via the restart endpoint. Omitted if the pool has never been explicitly restarted. */
    restartedOn?: string | null;
}
export type ConfigsUpdateRequestOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsUpdateRequestOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the publicly reachable hostname or IP of your origin database. Private, loopback, and link-local IP addresses are not allowed. */
    host: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateRequestOriginPublicDatabaseScheme | (string & {});
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsUpdateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsUpdateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme | (string & {});
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsUpdateRequestOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsUpdateRequestOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateRequestOriginDatabaseReachableThroughAWorkersVPCScheme | (string & {});
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsUpdateRequestOrigin = ConfigsUpdateRequestOriginPublicDatabase | ConfigsUpdateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsUpdateRequestOriginDatabaseReachableThroughAWorkersVPC;
export type ConfigsUpdateRequestCachingHyperdriveHyperdriveCachingCommon = ConfigsEditRequestCachingHyperdriveHyperdriveCachingCommon;
export type ConfigsUpdateRequestCachingHyperdriveHyperdriveCachingEnabled = ConfigsEditRequestCachingHyperdriveHyperdriveCachingEnabled;
export type ConfigsUpdateRequestCaching = ConfigsEditRequestCachingHyperdriveHyperdriveCachingCommon | ConfigsEditRequestCachingHyperdriveHyperdriveCachingEnabled;
export type ConfigsUpdateRequestMtls = ConfigsCreateRequestMtls;
export interface UpdateConfigRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
    /** Define configurations using a unique string identifier. */
    hyperdriveId: string;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    /** Combines database connection fields with exactly one supported network location. */
    origin: ConfigsUpdateRequestOrigin;
    caching?: ConfigsUpdateRequestCaching;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateRequestMtls;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number;
}
export type ConfigsUpdateResponseCaching = ConfigsCreateResponseCaching;
export type ConfigsUpdateResponseOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsUpdateResponseOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the publicly reachable hostname or IP of your origin database. Private, loopback, and link-local IP addresses are not allowed. */
    host: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateResponseOriginPublicDatabaseScheme;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsUpdateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsUpdateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsUpdateResponseOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsUpdateResponseOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateResponseOriginDatabaseReachableThroughAWorkersVPCScheme;
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export type ConfigsUpdateResponseOrigin = ConfigsUpdateResponseOriginPublicDatabase | ConfigsUpdateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsUpdateResponseOriginDatabaseReachableThroughAWorkersVPC;
export type ConfigsUpdateResponseIntegrationProvider = "planetscale";
export type ConfigsUpdateResponseIntegrationScheme = "postgres" | "postgresql" | "mysql";
export interface ConfigsUpdateResponseIntegration {
    /** The name of the PlanetScale database branch. */
    databaseBranchName: string;
    /** The name of the PlanetScale database. */
    databaseName: string;
    /** The name of the PlanetScale organization. */
    organizationName: string;
    /** The database integration provider used by this operation. */
    provider: ConfigsUpdateResponseIntegrationProvider;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateResponseIntegrationScheme;
    /** The database name to use when connecting. Defaults to `postgres` for PostgreSQL and `mysql` for MySQL. */
    customDatabaseName?: string | null;
}
export type ConfigsUpdateResponseMtls = ConfigsCreateResponseMtls;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateConfigResponse {
    /** Define configurations using a unique string identifier. */
    id: string;
    caching: ConfigsCreateResponseCaching;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    /** Combines database connection fields with exactly one supported network location. */
    origin: ConfigsUpdateResponseOrigin;
    /** Defines the creation time of the Hyperdrive configuration. */
    createdOn?: string | null;
    /** Selects a PlanetScale database and provisions credentials managed by Cloudflare when creating a Hyperdrive configuration. The Cloudflare account must already be linked to PlanetScale in the Hyperdrive dashboard. The selection is returned as read-only metadata and cannot be changed with replace or update operations. */
    integration?: ConfigsUpdateResponseIntegration | null;
    /** Defines the last modified time of the Hyperdrive configuration. */
    modifiedOn?: string | null;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateResponseMtls | null;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number | null;
    /** Defines the last time the Hyperdrive connection pool was explicitly restarted via the restart endpoint. Omitted if the pool has never been explicitly restarted. */
    restartedOn?: string | null;
}
export type CreateConfigError = PrivateHostNotAllowed | InvalidHyperdriveConfig | InvalidObjectIdentifier | HyperdriveConfigAlreadyExists | HyperdriveOriginUnavailable | CloudflareOpError;
/** Creates and returns a new Hyperdrive configuration. For a PlanetScale integration, the Cloudflare account must already be linked to PlanetScale in the Hyperdrive dashboard. */
export declare const createConfig: API.OperationMethod<CreateConfigRequest, CreateConfigResponse, CreateConfigError, CloudflareOpContext>;
export type DeleteConfigError = PrivateHostNotAllowed | HyperdriveConfigNotFound | InvalidObjectIdentifier | MethodNotAllowed | CloudflareOpError;
/** Deletes the specified Hyperdrive. */
export declare const deleteConfig: API.OperationMethod<DeleteConfigRequest, DeleteConfigResponse, DeleteConfigError, CloudflareOpContext>;
export type GetConfigError = PrivateHostNotAllowed | HyperdriveConfigNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Returns the specified Hyperdrive configuration. */
export declare const getConfig: API.OperationMethod<GetConfigRequest, GetConfigResponse, GetConfigError, CloudflareOpContext>;
export type ListConfigsError = PrivateHostNotAllowed | InvalidObjectIdentifier | CloudflareOpError;
/** Returns a list of Hyperdrives. */
export declare const listConfigs: API.PaginatedOperationMethod<ListConfigsRequest, ListConfigsResponse, ListConfigsError, CloudflareOpContext, ConfigsListResultItem>;
export type PatchConfigError = PrivateHostNotAllowed | HyperdriveConfigNotFound | InvalidObjectIdentifier | MethodNotAllowed | HyperdriveOriginUnavailable | CloudflareOpError;
/** Updates and returns the specified fields of the Hyperdrive configuration. Custom caching settings are not kept if caching is disabled. For an integration-backed configuration, the integration association is preserved but cannot be changed; omit the integration field. */
export declare const patchConfig: API.OperationMethod<PatchConfigRequest, PatchConfigResponse, PatchConfigError, CloudflareOpContext>;
export type RestartConfigError = CloudflareOpError;
/** Restarts the connection pool for the specified Hyperdrive configuration without changing its configuration. Existing connections are drained and a new pool is established at the edge. */
export declare const restartConfig: API.OperationMethod<RestartConfigRequest, RestartConfigResponse, RestartConfigError, CloudflareOpContext>;
export type UpdateConfigError = PrivateHostNotAllowed | HyperdriveConfigNotFound | InvalidObjectIdentifier | MethodNotAllowed | HyperdriveOriginUnavailable | CloudflareOpError;
/** Replaces and returns the specified Hyperdrive configuration. The request must include the name and complete origin connection details. Omitted caching settings are reset to their defaults, while omitted mTLS settings and origin connection limits are preserved. The integration association is set only during creation and cannot be changed; omit the integration field even when replacing an integration-backed configuration. Use the update operation to modify only selected fields. */
export declare const updateConfig: API.OperationMethod<UpdateConfigRequest, UpdateConfigResponse, UpdateConfigError, CloudflareOpContext>;
//# sourceMappingURL=hyperdrive.d.ts.map