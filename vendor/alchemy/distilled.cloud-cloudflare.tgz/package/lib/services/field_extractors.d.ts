import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface DeleteRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** Extractor type. */
    extractor: string;
}
export type DeleteResponse = unknown;
export interface GetRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** Extractor type. */
    extractor: string;
}
export interface GetResponseRulesItemFieldsItem {
    /** Wirefilter value expression. */
    expression: string;
    /** Field name. */
    name: string;
}
export type GetResponseRulesItemFieldsList = Array<GetResponseRulesItemFieldsItem>;
export interface GetResponseRulesItem {
    fields: GetResponseRulesItemFieldsList;
    /** Stable rule identifier. */
    ref: string;
    /** Human-readable rule description. */
    description?: string | null;
}
export type GetResponseRulesList = Array<GetResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResponse {
    /** Extractor type. */
    extractor: string;
    rules: GetResponseRulesList;
}
export interface UpdateRequestRulesItemFieldsItem {
    expression: string;
    name: string;
}
export type UpdateRequestRulesItemFieldsList = Array<UpdateRequestRulesItemFieldsItem>;
export interface UpdateRequestRulesItem {
    fields: UpdateRequestRulesItemFieldsList;
    ref: string;
    description?: string;
}
export type UpdateRequestRulesList = Array<UpdateRequestRulesItem>;
export interface UpdateRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** Extractor type. */
    extractor: string;
    rules: UpdateRequestRulesList;
}
export type UpdateResponseRulesItemFieldsItem = GetResponseRulesItemFieldsItem;
export type UpdateResponseRulesItemFieldsList = Array<GetResponseRulesItemFieldsItem>;
export interface UpdateResponseRulesItem {
    fields: UpdateResponseRulesItemFieldsList;
    /** Stable rule identifier. */
    ref: string;
    /** Human-readable rule description. */
    description?: string | null;
}
export type UpdateResponseRulesList = Array<UpdateResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResponse {
    /** Extractor type. */
    extractor: string;
    rules: UpdateResponseRulesList;
}
export type DeleteError = CloudflareOpError;
/** Deletes all custom extraction rules for an extractor type. */
export declare const Delete: API.OperationMethod<DeleteRequest, DeleteResponse, DeleteError, CloudflareOpContext>;
export type GetError = CloudflareOpError;
/** Retrieves the custom extraction rules configured for a given extractor type. */
export declare const get: API.OperationMethod<GetRequest, GetResponse, GetError, CloudflareOpContext>;
export type UpdateError = CloudflareOpError;
/** Replaces all custom extraction rules for an extractor type. Omitted rules are deleted. */
export declare const update: API.OperationMethod<UpdateRequest, UpdateResponse, UpdateError, CloudflareOpContext>;
//# sourceMappingURL=field_extractors.d.ts.map