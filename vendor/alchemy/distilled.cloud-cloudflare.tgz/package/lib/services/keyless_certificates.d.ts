import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const KeylessCertificateNotFound_base: S.TaggedErrorClass<"KeylessCertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class KeylessCertificateNotFound extends /*@__PURE__*/ KeylessCertificateNotFound_base {
}
declare const KeylessSslNotAvailable_base: S.TaggedErrorClass<"KeylessSslNotAvailable", {
    readonly code: any;
    readonly message: any;
}>;
export declare class KeylessSslNotAvailable extends /*@__PURE__*/ KeylessSslNotAvailable_base {
}
export type CreateRequestBundleMethod = "ubiquitous" | "optimal" | "force";
export interface CreateRequestTunnel {
    /** Private IP of the Key Server Host. */
    privateIp: string;
    /** Cloudflare Tunnel Virtual Network ID. */
    vnetId: string;
}
export interface CreateKeylessCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** The zone's SSL certificate or SSL certificate and intermediate(s). */
    certificate: string;
    /** The keyless SSL name. */
    host: string;
    /** The keyless SSL port used to communicate between Cloudflare and the client's Keyless SSL server. */
    port: number;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: CreateRequestBundleMethod | (string & {});
    /** The keyless SSL name. */
    name?: string;
    /** Configuration for using Keyless SSL through a Cloudflare Tunnel. */
    tunnel?: CreateRequestTunnel;
}
export type CreateResponsePermissionsList = Array<string>;
export type CreateResponseStatus = "active" | "deleted";
export type CreateResponseTunnel = CreateRequestTunnel;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateKeylessCertificateResponse {
    /** Keyless certificate identifier tag. */
    id: string;
    /** When the Keyless SSL was created. */
    createdOn: string;
    /** Whether or not the Keyless SSL is on or off. */
    enabled: boolean;
    /** The keyless SSL name. */
    host: string;
    /** When the Keyless SSL was last modified. */
    modifiedOn: string;
    /** The keyless SSL name. */
    name: string;
    /** Available permissions for the Keyless SSL for the current user requesting the item. */
    permissions: CreateResponsePermissionsList;
    /** The keyless SSL port used to communicate between Cloudflare and the client's Keyless SSL server. */
    port: number;
    /** Status of the Keyless SSL. */
    status: CreateResponseStatus;
    /** Configuration for using Keyless SSL through a Cloudflare Tunnel. */
    tunnel?: CreateRequestTunnel | null;
}
export interface DeleteKeylessCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Keyless certificate identifier tag. */
    keylessCertificateId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteKeylessCertificateResponse {
    /** Keyless certificate identifier tag. */
    id?: string | null;
}
export interface GetKeylessCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Keyless certificate identifier tag. */
    keylessCertificateId: string;
}
export type GetResponsePermissionsList = Array<string>;
export type GetResponseStatus = "active" | "deleted";
export type GetResponseTunnel = CreateRequestTunnel;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetKeylessCertificateResponse {
    /** Keyless certificate identifier tag. */
    id: string;
    /** When the Keyless SSL was created. */
    createdOn: string;
    /** Whether or not the Keyless SSL is on or off. */
    enabled: boolean;
    /** The keyless SSL name. */
    host: string;
    /** When the Keyless SSL was last modified. */
    modifiedOn: string;
    /** The keyless SSL name. */
    name: string;
    /** Available permissions for the Keyless SSL for the current user requesting the item. */
    permissions: GetResponsePermissionsList;
    /** The keyless SSL port used to communicate between Cloudflare and the client's Keyless SSL server. */
    port: number;
    /** Status of the Keyless SSL. */
    status: GetResponseStatus;
    /** Configuration for using Keyless SSL through a Cloudflare Tunnel. */
    tunnel?: CreateRequestTunnel | null;
}
export interface ListKeylessCertificatesRequest {
    /** Identifier. */
    zoneId: string;
}
export type ListResultItemPermissionsList = Array<string>;
export type ListResultItemStatus = "active" | "deleted";
export type ListResultItemTunnel = CreateRequestTunnel;
export interface ListResultItem {
    /** Keyless certificate identifier tag. */
    id: string;
    /** When the Keyless SSL was created. */
    createdOn: string;
    /** Whether or not the Keyless SSL is on or off. */
    enabled: boolean;
    /** The keyless SSL name. */
    host: string;
    /** When the Keyless SSL was last modified. */
    modifiedOn: string;
    /** The keyless SSL name. */
    name: string;
    /** Available permissions for the Keyless SSL for the current user requesting the item. */
    permissions: ListResultItemPermissionsList;
    /** The keyless SSL port used to communicate between Cloudflare and the client's Keyless SSL server. */
    port: number;
    /** Status of the Keyless SSL. */
    status: ListResultItemStatus;
    /** Configuration for using Keyless SSL through a Cloudflare Tunnel. */
    tunnel?: CreateRequestTunnel | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListKeylessCertificatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type EditRequestTunnel = CreateRequestTunnel;
export interface PatchKeylessCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Keyless certificate identifier tag. */
    keylessCertificateId: string;
    /** Whether or not the Keyless SSL is on or off. */
    enabled?: boolean;
    /** The keyless SSL name. */
    host?: string;
    /** The keyless SSL name. */
    name?: string;
    /** The keyless SSL port used to communicate between Cloudflare and the client's Keyless SSL server. */
    port?: number;
    /** Configuration for using Keyless SSL through a Cloudflare Tunnel. */
    tunnel?: CreateRequestTunnel;
}
export type EditResponsePermissionsList = Array<string>;
export type EditResponseStatus = "active" | "deleted";
export type EditResponseTunnel = CreateRequestTunnel;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchKeylessCertificateResponse {
    /** Keyless certificate identifier tag. */
    id: string;
    /** When the Keyless SSL was created. */
    createdOn: string;
    /** Whether or not the Keyless SSL is on or off. */
    enabled: boolean;
    /** The keyless SSL name. */
    host: string;
    /** When the Keyless SSL was last modified. */
    modifiedOn: string;
    /** The keyless SSL name. */
    name: string;
    /** Available permissions for the Keyless SSL for the current user requesting the item. */
    permissions: EditResponsePermissionsList;
    /** The keyless SSL port used to communicate between Cloudflare and the client's Keyless SSL server. */
    port: number;
    /** Status of the Keyless SSL. */
    status: EditResponseStatus;
    /** Configuration for using Keyless SSL through a Cloudflare Tunnel. */
    tunnel?: CreateRequestTunnel | null;
}
export type CreateKeylessCertificateError = KeylessSslNotAvailable | Forbidden | CloudflareOpError;
/** Creates a Keyless SSL configuration that allows SSL/TLS termination without exposing private keys to Cloudflare. Keys remain on your infrastructure. */
export declare const createKeylessCertificate: API.OperationMethod<CreateKeylessCertificateRequest, CreateKeylessCertificateResponse, CreateKeylessCertificateError, CloudflareOpContext>;
export type DeleteKeylessCertificateError = KeylessCertificateNotFound | Forbidden | CloudflareOpError;
/** Removes a Keyless SSL configuration. SSL connections will no longer use the keyless server for cryptographic operations. */
export declare const deleteKeylessCertificate: API.OperationMethod<DeleteKeylessCertificateRequest, DeleteKeylessCertificateResponse, DeleteKeylessCertificateError, CloudflareOpContext>;
export type GetKeylessCertificateError = KeylessCertificateNotFound | Forbidden | CloudflareOpError;
/** Get details for one Keyless SSL configuration. */
export declare const getKeylessCertificate: API.OperationMethod<GetKeylessCertificateRequest, GetKeylessCertificateResponse, GetKeylessCertificateError, CloudflareOpContext>;
export type ListKeylessCertificatesError = Forbidden | CloudflareOpError;
/** List all Keyless SSL configurations for a given zone. */
export declare const listKeylessCertificates: API.PaginatedOperationMethod<ListKeylessCertificatesRequest, ListKeylessCertificatesResponse, ListKeylessCertificatesError, CloudflareOpContext, ListResultItem>;
export type PatchKeylessCertificateError = KeylessCertificateNotFound | Forbidden | CloudflareOpError;
/** This will update attributes of a Keyless SSL. Consists of one or more of the following: host,name,port. */
export declare const patchKeylessCertificate: API.OperationMethod<PatchKeylessCertificateRequest, PatchKeylessCertificateResponse, PatchKeylessCertificateError, CloudflareOpContext>;
//# sourceMappingURL=keyless_certificates.d.ts.map