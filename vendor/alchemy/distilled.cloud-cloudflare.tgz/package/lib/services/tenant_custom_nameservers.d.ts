import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CreateTenantCustomNameserverRequest {
    /** Tenant identifier tag. */
    tenantTag: string;
    /** The FQDN of the name server. */
    nsName: string;
    /** The number of the set that this name server belongs to. */
    nsSet?: number;
}
export type CreateResponseDnsRecordsItemType = "A" | "AAAA";
export interface CreateResponseDnsRecordsItem {
    /** DNS record type. */
    type?: CreateResponseDnsRecordsItemType | null;
    /** DNS record contents (an IPv4 or IPv6 address). */
    value?: string | null;
}
export type CreateResponseDnsRecordsList = Array<CreateResponseDnsRecordsItem>;
export type CreateResponseStatus = "moved" | "pending" | "verified";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTenantCustomNameserverResponse {
    /** A and AAAA records associated with the nameserver. */
    dnsRecords: CreateResponseDnsRecordsList;
    /** The FQDN of the name server. */
    nsName: string;
    /** Verification status of the nameserver. */
    status: CreateResponseStatus;
    /** Identifier. */
    zoneTag: string;
    /** The number of the set that this name server belongs to. */
    nsSet?: number | null;
}
export interface DeleteTenantCustomNameserverRequest {
    /** Tenant identifier tag. */
    tenantTag: string;
    /** The FQDN of the name server. */
    customNsId: string;
}
export type DeleteResultList = Array<string>;
export interface DeleteTenantCustomNameserverResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetTenantCustomNameserverRequest {
    /** Tenant identifier tag. */
    tenantTag: string;
}
export type GetResultItemDnsRecordsItemType = "A" | "AAAA";
export interface GetResultItemDnsRecordsItem {
    /** DNS record type. */
    type?: GetResultItemDnsRecordsItemType | null;
    /** DNS record contents (an IPv4 or IPv6 address). */
    value?: string | null;
}
export type GetResultItemDnsRecordsList = Array<GetResultItemDnsRecordsItem>;
export type GetResultItemStatus = "moved" | "pending" | "verified";
export interface GetResultItem {
    /** A and AAAA records associated with the nameserver. */
    dnsRecords: GetResultItemDnsRecordsList;
    /** The FQDN of the name server. */
    nsName: string;
    /** Verification status of the nameserver. */
    status: GetResultItemStatus;
    /** Identifier. */
    zoneTag: string;
    /** The number of the set that this name server belongs to. */
    nsSet?: number | null;
}
export type GetResultList = Array<GetResultItem>;
export interface GetTenantCustomNameserverResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: GetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type CreateTenantCustomNameserverError = CloudflareOpError;
/** Adds a custom nameserver for a tenant. */
export declare const createTenantCustomNameserver: API.OperationMethod<CreateTenantCustomNameserverRequest, CreateTenantCustomNameserverResponse, CreateTenantCustomNameserverError, CloudflareOpContext>;
export type DeleteTenantCustomNameserverError = CloudflareOpError;
/** Deletes a tenant's custom nameserver. */
export declare const deleteTenantCustomNameserver: API.PaginatedOperationMethod<DeleteTenantCustomNameserverRequest, DeleteTenantCustomNameserverResponse, DeleteTenantCustomNameserverError, CloudflareOpContext, string>;
export type GetTenantCustomNameserverError = CloudflareOpError;
/** Lists a tenant's custom nameservers. */
export declare const getTenantCustomNameserver: API.PaginatedOperationMethod<GetTenantCustomNameserverRequest, GetTenantCustomNameserverResponse, GetTenantCustomNameserverError, CloudflareOpContext, GetResultItem>;
//# sourceMappingURL=tenant_custom_nameservers.d.ts.map