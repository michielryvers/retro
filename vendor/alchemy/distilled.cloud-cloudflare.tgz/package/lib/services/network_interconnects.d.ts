import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface CnisCreateRequestMagic {
    conduitName: string;
    description: string;
    mtu: number;
}
export type CnisCreateRequestBgpExtraPrefixesList = Array<string>;
export interface CnisCreateRequestBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** Extra set of static prefixes to advertise to the customer's end of the session Prefixes containing host bits will be normalized to contain network bits only. Duplicates are not allowed. */
    extraPrefixes: CnisCreateRequestBgpExtraPrefixesList;
    /** MD5 key to use for session authentication. */
    md5Key?: string;
}
export interface CreateCniRequest {
    /** Customer account tag */
    accountId: string;
    /** Customer account tag */
    account: string;
    interconnect: string;
    magic: CnisCreateRequestMagic;
    bgp?: CnisCreateRequestBgp;
}
export type CnisCreateResponseMagic = CnisCreateRequestMagic;
export type CnisCreateResponseBgpExtraPrefixesList = Array<string>;
export interface CnisCreateResponseBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** Extra set of static prefixes to advertise to the customer's end of the session Prefixes containing host bits will be normalized to contain network bits only. Duplicates are not allowed. */
    extraPrefixes: CnisCreateResponseBgpExtraPrefixesList;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export type CnisCreateResponseBgpMode = "dynamic_route_exchange" | "advertise_only";
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateCniResponse {
    id: string;
    /** Customer account tag */
    account: string;
    /** Customer end of the point-to-point link */
    custIp: string;
    /** Interconnect identifier hosting this CNI */
    interconnect: string;
    magic: CnisCreateRequestMagic;
    /** Cloudflare end of the point-to-point link */
    p2pIp: string;
    bgp?: CnisCreateResponseBgp | null;
    /** The BGP mode for a CNI. One of the following: */
    bgpMode?: CnisCreateResponseBgpMode | null;
}
export type InterconnectsCreateRequestBandwidth = "50M" | "100M" | "200M" | "300M" | "400M" | "500M" | "1G" | "2G" | "5G" | "10G" | "20G" | "50G";
export interface CreateInterconnectRequest {
    /** Customer account tag */
    accountId: string;
    account: string;
    slotId?: string;
    type: string;
    speed?: string;
    /** Bandwidth structure as visible through the customer-facing API. */
    bandwidth?: InterconnectsCreateRequestBandwidth | (string & {});
    /** Pairing key provided by GCP */
    pairingKey?: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateInterconnectResponse {
}
export interface DeleteCniRequest {
    /** Customer account tag */
    accountId: string;
    cni: string;
}
export interface DeleteCniResponse {
}
export interface DeleteInterconnectRequest {
    /** Customer account tag */
    accountId: string;
    icon: string;
}
export interface DeleteInterconnectResponse {
}
export interface GetCniRequest {
    /** Customer account tag */
    accountId: string;
    cni: string;
}
export type CnisGetResponseMagic = CnisCreateRequestMagic;
export type CnisGetResponseBgpExtraPrefixesList = Array<string>;
export interface CnisGetResponseBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** Extra set of static prefixes to advertise to the customer's end of the session Prefixes containing host bits will be normalized to contain network bits only. Duplicates are not allowed. */
    extraPrefixes: CnisGetResponseBgpExtraPrefixesList;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export type CnisGetResponseBgpMode = "dynamic_route_exchange" | "advertise_only";
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetCniResponse {
    id: string;
    /** Customer account tag */
    account: string;
    /** Customer end of the point-to-point link */
    custIp: string;
    /** Interconnect identifier hosting this CNI */
    interconnect: string;
    magic: CnisCreateRequestMagic;
    /** Cloudflare end of the point-to-point link */
    p2pIp: string;
    bgp?: CnisGetResponseBgp | null;
    /** The BGP mode for a CNI. One of the following: */
    bgpMode?: CnisGetResponseBgpMode | null;
}
export interface GetInterconnectRequest {
    /** Customer account tag */
    accountId: string;
    icon: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetInterconnectResponse {
}
export interface GetSettingRequest {
    accountId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSettingResponse {
    defaultAsn: number;
}
export interface GetSlotRequest {
    /** Customer account tag */
    accountId: string;
    slot: string;
}
export type SlotsGetResponseFacilityAddressList = Array<string>;
export interface SlotsGetResponseFacility {
    address: SlotsGetResponseFacilityAddressList;
    name: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSlotResponse {
    /** Slot ID */
    id: string;
    facility: SlotsGetResponseFacility;
    /** Whether the slot is occupied or not */
    occupied: boolean;
    site: string;
    speed: string;
    /** Customer account tag */
    account?: string | null;
    ccrDeviceName?: string | null;
}
export interface ListCnisRequest {
    /** Customer account tag */
    accountId: string;
    cursor?: number;
    limit?: number;
    /** If specified, only show CNIs associated with the specified slot */
    slot?: string;
    /** If specified, only show cnis associated with the specified tunnel id */
    tunnelId?: string;
}
export type CnisListResponseItemsItemMagic = CnisCreateRequestMagic;
export type CnisListResponseItemsItemBgpExtraPrefixesList = Array<string>;
export interface CnisListResponseItemsItemBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** Extra set of static prefixes to advertise to the customer's end of the session Prefixes containing host bits will be normalized to contain network bits only. Duplicates are not allowed. */
    extraPrefixes: CnisListResponseItemsItemBgpExtraPrefixesList;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export type CnisListResponseItemsItemBgpMode = "dynamic_route_exchange" | "advertise_only";
export interface CnisListResponseItemsItem {
    id: string;
    /** Customer account tag */
    account: string;
    /** Customer end of the point-to-point link */
    custIp: string;
    /** Interconnect identifier hosting this CNI */
    interconnect: string;
    magic: CnisCreateRequestMagic;
    /** Cloudflare end of the point-to-point link */
    p2pIp: string;
    bgp?: CnisListResponseItemsItemBgp | null;
    /** The BGP mode for a CNI. One of the following: */
    bgpMode?: CnisListResponseItemsItemBgpMode | null;
}
export type CnisListResponseItemsList = Array<CnisListResponseItemsItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListCnisResponse {
    items: CnisListResponseItemsList;
    next?: number | null;
}
export interface ListInterconnectsRequest {
    /** Customer account tag */
    accountId: string;
    cursor?: number;
    limit?: number;
    /** If specified, only show interconnects located at the given site */
    site?: string;
    /** If specified, only show interconnects of the given type */
    type?: string;
}
export type InterconnectsListResponseItemsItemNscInterconnectPhysicalBodyFacilityAddressList = Array<string>;
export interface InterconnectsListResponseItemsItemNscInterconnectPhysicalBodyFacility {
    address: InterconnectsListResponseItemsItemNscInterconnectPhysicalBodyFacilityAddressList;
    name: string;
}
export interface InterconnectsListResponseItemsItemNscInterconnectPhysicalBody {
    account: string;
    facility: InterconnectsListResponseItemsItemNscInterconnectPhysicalBodyFacility;
    name: string;
    /** A Cloudflare site name. */
    site: string;
    slotId: string;
    speed: string;
    type: string;
    virtualPortReservationId: string;
    ccrDeviceName?: string | null;
    owner?: string | null;
}
export type InterconnectsListResponseItemsItemNscInterconnectGcpPartnerBodySpeed = "50M" | "100M" | "200M" | "300M" | "400M" | "500M" | "1G" | "2G" | "5G" | "10G" | "20G" | "50G";
export interface InterconnectsListResponseItemsItemNscInterconnectGcpPartnerBody {
    account: string;
    name: string;
    region: string;
    type: string;
    virtualPortReservationId: string;
    owner?: string | null;
    /** Bandwidth structure as visible through the customer-facing API. */
    speed?: InterconnectsListResponseItemsItemNscInterconnectGcpPartnerBodySpeed | null;
}
export type InterconnectsListResponseItemsItem = InterconnectsListResponseItemsItemNscInterconnectPhysicalBody | InterconnectsListResponseItemsItemNscInterconnectGcpPartnerBody;
export type InterconnectsListResponseItemsList = Array<InterconnectsListResponseItemsItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListInterconnectsResponse {
    items: InterconnectsListResponseItemsList;
    next?: number | null;
}
export interface ListSlotsRequest {
    /** Customer account tag */
    accountId: string;
    /** If specified, only show slots with the given text in their address field */
    addressContains?: string;
    cursor?: number;
    limit?: number;
    /** If specified, only show slots with a specific occupied/unoccupied state */
    occupied?: boolean;
    /** If specified, only show slots located at the given site */
    site?: string;
    /** If specified, only show slots that support the given speed */
    speed?: string;
}
export type SlotsListResponseItemsItemFacilityAddressList = Array<string>;
export interface SlotsListResponseItemsItemFacility {
    address: SlotsListResponseItemsItemFacilityAddressList;
    name: string;
}
export interface SlotsListResponseItemsItem {
    /** Slot ID */
    id: string;
    facility: SlotsListResponseItemsItemFacility;
    /** Whether the slot is occupied or not */
    occupied: boolean;
    site: string;
    speed: string;
    /** Customer account tag */
    account?: string | null;
    ccrDeviceName?: string | null;
}
export type SlotsListResponseItemsList = Array<SlotsListResponseItemsItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListSlotsResponse {
    items: SlotsListResponseItemsList;
    next?: number | null;
}
export interface LoaInterconnectRequest {
    /** Customer account tag */
    accountId: string;
    icon: string;
    /** Custom name to use in the LOA instead of the account name (200 Character limit) */
    name?: string;
}
export interface LoaInterconnectResponse {
}
export interface PutSettingRequest {
    accountId: string;
    defaultAsn?: number;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PutSettingResponse {
    defaultAsn: number;
}
export interface StatusInterconnectRequest {
    /** Customer account tag */
    accountId: string;
    icon: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface StatusInterconnectResponse {
}
export type CnisUpdateRequestMagic = CnisCreateRequestMagic;
export type CnisUpdateRequestBgpExtraPrefixesList = Array<string>;
export interface CnisUpdateRequestBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** Extra set of static prefixes to advertise to the customer's end of the session Prefixes containing host bits will be normalized to contain network bits only. Duplicates are not allowed. */
    extraPrefixes: CnisUpdateRequestBgpExtraPrefixesList;
    /** MD5 key to use for session authentication. */
    md5Key?: string;
}
export type CnisUpdateRequestBgpMode = "dynamic_route_exchange" | "advertise_only";
export interface UpdateCniRequest {
    /** Customer account tag */
    accountId: string;
    cni: string;
    id: string;
    /** Customer account tag */
    account: string;
    /** Customer end of the point-to-point link */
    custIp: string;
    /** Interconnect identifier hosting this CNI */
    interconnect: string;
    magic: CnisCreateRequestMagic;
    /** Cloudflare end of the point-to-point link */
    p2pIp: string;
    bgp?: CnisUpdateRequestBgp;
    /** The BGP mode for a CNI. One of the following: */
    bgpMode?: CnisUpdateRequestBgpMode | (string & {});
}
export type CnisUpdateResponseMagic = CnisCreateRequestMagic;
export type CnisUpdateResponseBgpExtraPrefixesList = Array<string>;
export interface CnisUpdateResponseBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** Extra set of static prefixes to advertise to the customer's end of the session Prefixes containing host bits will be normalized to contain network bits only. Duplicates are not allowed. */
    extraPrefixes: CnisUpdateResponseBgpExtraPrefixesList;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export type CnisUpdateResponseBgpMode = "dynamic_route_exchange" | "advertise_only";
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface UpdateCniResponse {
    id: string;
    /** Customer account tag */
    account: string;
    /** Customer end of the point-to-point link */
    custIp: string;
    /** Interconnect identifier hosting this CNI */
    interconnect: string;
    magic: CnisCreateRequestMagic;
    /** Cloudflare end of the point-to-point link */
    p2pIp: string;
    bgp?: CnisUpdateResponseBgp | null;
    /** The BGP mode for a CNI. One of the following: */
    bgpMode?: CnisUpdateResponseBgpMode | null;
}
export type CreateCniError = CloudflareOpError;
/** Creates a new Cloud Network Interconnect (CNI) for private network connectivity between Cloudflare and your infrastructure. CNIs enable dedicated, high-performance network links. */
export declare const createCni: API.OperationMethod<CreateCniRequest, CreateCniResponse, CreateCniError, CloudflareOpContext>;
export type CreateInterconnectError = CloudflareOpError;
/** Creates a new network interconnect for connecting Cloudflare's network to external networks. Interconnects provide dedicated bandwidth and reduced latency for traffic exchange. */
export declare const createInterconnect: API.OperationMethod<CreateInterconnectRequest, CreateInterconnectResponse, CreateInterconnectError, CloudflareOpContext>;
export type DeleteCniError = CloudflareOpError;
/** Permanently removes a Cloud Network Interconnect (CNI) configuration. The private network connection will be terminated. */
export declare const deleteCni: API.OperationMethod<DeleteCniRequest, DeleteCniResponse, DeleteCniError, CloudflareOpContext>;
export type DeleteInterconnectError = CloudflareOpError;
/** Permanently removes a network interconnect configuration. The physical or virtual connection will be terminated. */
export declare const deleteInterconnect: API.OperationMethod<DeleteInterconnectRequest, DeleteInterconnectResponse, DeleteInterconnectError, CloudflareOpContext>;
export type GetCniError = CloudflareOpError;
/** Retrieves configuration details for a specific Cloud Network Interconnect (CNI), including connection status and parameters. */
export declare const getCni: API.OperationMethod<GetCniRequest, GetCniResponse, GetCniError, CloudflareOpContext>;
export type GetInterconnectError = CloudflareOpError;
/** Retrieves configuration and status details for a specific network interconnect. */
export declare const getInterconnect: API.OperationMethod<GetInterconnectRequest, GetInterconnectResponse, GetInterconnectError, CloudflareOpContext>;
export type GetSettingError = Forbidden | CloudflareOpError;
/** Retrieves current settings configuration for the specified resource or service. */
export declare const getSetting: API.OperationMethod<GetSettingRequest, GetSettingResponse, GetSettingError, CloudflareOpContext>;
export type GetSlotError = CloudflareOpError;
/** Gets information about a specific infrastructure slot allocation. */
export declare const getSlot: API.OperationMethod<GetSlotRequest, GetSlotResponse, GetSlotError, CloudflareOpContext>;
export type ListCnisError = CloudflareOpError;
/** Lists all Cloud Network Interconnects (CNIs) configured for the account, showing connection status and parameters. */
export declare const listCnis: API.OperationMethod<ListCnisRequest, ListCnisResponse, ListCnisError, CloudflareOpContext>;
export type ListInterconnectsError = CloudflareOpError;
/** Lists all network interconnects configured for the account, including physical and virtual connections. */
export declare const listInterconnects: API.OperationMethod<ListInterconnectsRequest, ListInterconnectsResponse, ListInterconnectsError, CloudflareOpContext>;
export type ListSlotsError = CloudflareOpError;
/** Lists all available infrastructure slots for the account, showing allocation status and capacity. */
export declare const listSlots: API.OperationMethod<ListSlotsRequest, ListSlotsResponse, ListSlotsError, CloudflareOpContext>;
export type LoaInterconnectError = CloudflareOpError;
/** Downloads the Letter of Authorization (LOA) for a network interconnect, required for physical cross-connect provisioning. */
export declare const loaInterconnect: API.OperationMethod<LoaInterconnectRequest, LoaInterconnectResponse, LoaInterconnectError, CloudflareOpContext>;
export type PutSettingError = Forbidden | CloudflareOpError;
/** Updates configuration settings for the specified resource or service. */
export declare const putSetting: API.OperationMethod<PutSettingRequest, PutSettingResponse, PutSettingError, CloudflareOpContext>;
export type StatusInterconnectError = CloudflareOpError;
/** Gets the current operational status of a network interconnect, including link state and traffic metrics. */
export declare const statusInterconnect: API.OperationMethod<StatusInterconnectRequest, StatusInterconnectResponse, StatusInterconnectError, CloudflareOpContext>;
export type UpdateCniError = CloudflareOpError;
/** Updates the configuration of an existing Cloud Network Interconnect (CNI), including connection parameters and routing settings. */
export declare const updateCni: API.OperationMethod<UpdateCniRequest, UpdateCniResponse, UpdateCniError, CloudflareOpContext>;
//# sourceMappingURL=network_interconnects.d.ts.map