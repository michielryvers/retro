import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const FlagshipAppNotFound_base: S.TaggedErrorClass<"FlagshipAppNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class FlagshipAppNotFound extends /*@__PURE__*/ FlagshipAppNotFound_base {
}
declare const FlagshipFlagAlreadyExists_base: S.TaggedErrorClass<"FlagshipFlagAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>;
export declare class FlagshipFlagAlreadyExists extends /*@__PURE__*/ FlagshipFlagAlreadyExists_base {
}
declare const FlagshipFlagNotFound_base: S.TaggedErrorClass<"FlagshipFlagNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class FlagshipFlagNotFound extends /*@__PURE__*/ FlagshipFlagNotFound_base {
}
export interface CreateAppRequest {
    /** Cloudflare account ID that owns the Flagship app. */
    accountId: string;
    /** Name of the Flagship app (1-64 letters, numbers, hyphens, or underscores). */
    name: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAppResponse {
    id: string;
    createdAt: string;
    name: string;
    updatedAt: string;
    /** Email of the actor who last modified the app, or `unknown` when unavailable. */
    updatedBy: string;
}
export type AppsFlagsCreateRequestRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsCreateRequestRulesItemConditionsItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateRequestRulesItemConditionsItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase0Value = string | number | boolean | AppsFlagsCreateRequestRulesItemConditionsItemCase0ValueCase3Map | AppsFlagsCreateRequestRulesItemConditionsItemCase0ValueCase4List;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateRequestRulesItemConditionsItemCase0Operator | (string & {});
    value: AppsFlagsCreateRequestRulesItemConditionsItemCase0Value;
}
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0Operator | (string & {});
    value: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0Value;
}
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    value: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    value: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    value: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    value: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItem = AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItem>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1 {
    clauses: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateRequestRulesItemConditionsItemCase1LogicalOperator | (string & {});
}
export type AppsFlagsCreateRequestRulesItemConditionsItem = AppsFlagsCreateRequestRulesItemConditionsItemCase0 | AppsFlagsCreateRequestRulesItemConditionsItemCase1;
export type AppsFlagsCreateRequestRulesItemConditionsList = Array<AppsFlagsCreateRequestRulesItemConditionsItem>;
export interface AppsFlagsCreateRequestRulesItemRollout {
    /** Percentage of matching traffic (0-100, up to 2 decimal places) served this variation. For multi-way splits, use cumulative upper bounds across rules (e.g. 30, 70, 100). */
    percentage: number;
    /** Context attribute used for sticky bucketing. Defaults to `targetingKey`. If absent at evaluation time, bucketing is random per request. */
    attribute?: string;
}
export interface AppsFlagsCreateRequestRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsCreateRequestRulesItemConditionsList;
    /** Evaluation order: the API evaluates rules with lower numbers first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation the API serves when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateRequestRulesItemRollout;
}
export type AppsFlagsCreateRequestRulesList = Array<AppsFlagsCreateRequestRulesItem>;
export type UntypedVariationsMap = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateRequestType = "boolean" | "string" | "number" | "json";
export interface CreateAppFlagRequest {
    /** Cloudflare account ID that owns the Flagship app. */
    accountId: string;
    /** Flagship app ID returned when the app was created. */
    appId: string;
    /** Variation the API serves when the flag is off, or when it's on but no rule matches the context. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsCreateRequestRulesList;
    /** Map of variation name to value. All values share the same type (boolean, string, number, or JSON object/array), and each serialized value stays within 10KB. */
    variations: UntypedVariationsMap;
    /** Optional operator-facing description. It does not affect flag evaluation. */
    description?: string;
    /** Deprecated compatibility field. Omit it; the API ignores this value and infers the type from the flag's variations. */
    type?: AppsFlagsCreateRequestType | (string & {});
}
export type AppsFlagsCreateResponseRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsCreateResponseRulesItemConditionsItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateResponseRulesItemConditionsItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase0Value = string | number | boolean | AppsFlagsCreateResponseRulesItemConditionsItemCase0ValueCase3Map | AppsFlagsCreateResponseRulesItemConditionsItemCase0ValueCase4List;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateResponseRulesItemConditionsItemCase0Operator;
    value: AppsFlagsCreateResponseRulesItemConditionsItemCase0Value;
}
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0Operator;
    value: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0Value;
}
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItem = AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItem>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1 {
    clauses: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateResponseRulesItemConditionsItemCase1LogicalOperator;
}
export type AppsFlagsCreateResponseRulesItemConditionsItem = AppsFlagsCreateResponseRulesItemConditionsItemCase0 | AppsFlagsCreateResponseRulesItemConditionsItemCase1;
export type AppsFlagsCreateResponseRulesItemConditionsList = Array<AppsFlagsCreateResponseRulesItemConditionsItem>;
export interface AppsFlagsCreateResponseRulesItemRollout {
    /** Percentage of matching traffic (0-100, up to 2 decimal places) served this variation. For multi-way splits, use cumulative upper bounds across rules (e.g. 30, 70, 100). */
    percentage: number;
    /** Context attribute used for sticky bucketing. Defaults to `targetingKey`. If absent at evaluation time, bucketing is random per request. */
    attribute?: string | null;
}
export interface AppsFlagsCreateResponseRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsCreateResponseRulesItemConditionsList;
    /** Evaluation order: the API evaluates rules with lower numbers first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation the API serves when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export type AppsFlagsCreateResponseRulesList = Array<AppsFlagsCreateResponseRulesItem>;
export type AppsFlagsCreateResponseType = "boolean" | "string" | "number" | "json";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAppFlagResponse {
    /** Variation the API serves when the flag is off, or when it's on but no rule matches the context. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsCreateResponseRulesList;
    /** Server-inferred value type shared by all of the flag's variations. */
    type: AppsFlagsCreateResponseType;
    /** Map of variation name to value. All values share the same type (boolean, string, number, or JSON object/array), and each serialized value stays within 10KB. */
    variations: UntypedVariationsMap;
    /** Optional operator-facing description. It does not affect flag evaluation. */
    description?: string | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export interface DeleteAppRequest {
    /** Cloudflare account ID that owns the Flagship app. */
    accountId: string;
    /** Flagship app ID returned when the app was created. */
    appId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAppResponse {
    id: string;
}
export interface DeleteAppFlagRequest {
    /** Cloudflare account ID that owns the Flagship app. */
    accountId: string;
    /** Flagship app ID returned when the app was created. */
    appId: string;
    /** Case-sensitive key identifying the flag within the app. */
    flagKey: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAppFlagResponse {
    key: string;
}
export interface GetAppRequest {
    /** Cloudflare account ID that owns the Flagship app. */
    accountId: string;
    /** Flagship app ID returned when the app was created. */
    appId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAppResponse {
    id: string;
    createdAt: string;
    name: string;
    updatedAt: string;
    /** Email of the actor who last modified the app, or `unknown` when unavailable. */
    updatedBy: string;
}
export interface GetAppEvaluateRequest {
    /** Cloudflare account ID that owns the Flagship app. */
    accountId: string;
    /** Flagship app ID returned when the app was created. */
    appId: string;
    /** The flag key to evaluate. */
    flagKey: string;
    /** Context targeting key (per OpenFeature spec); used for percentage rollout bucketing. */
    targetingKey?: string;
}
export type AppsEvaluateGetResponseReason = "STATIC" | "TARGETING_MATCH" | "DEFAULT" | "DISABLED" | "SPLIT";
export type AppsEvaluateGetResponseValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsEvaluateGetResponseValueCase4List = Array<unknown>;
export type AppsEvaluateGetResponseValue = string | number | boolean | AppsEvaluateGetResponseValueCase3Map | AppsEvaluateGetResponseValueCase4List;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetAppEvaluateResponse {
    /** Key of the evaluated flag. */
    flagKey: string;
    /** Reason the evaluator selected this variation. */
    reason: AppsEvaluateGetResponseReason;
    /** Name of the variation that supplied the resolved value. */
    variant: string;
    value?: AppsEvaluateGetResponseValue | null;
}
export interface GetAppFlagRequest {
    /** Cloudflare account ID that owns the Flagship app. */
    accountId: string;
    /** Flagship app ID returned when the app was created. */
    appId: string;
    /** Case-sensitive key identifying the flag within the app. */
    flagKey: string;
}
export type AppsFlagsGetResponseRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsGetResponseRulesItemConditionsItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsGetResponseRulesItemConditionsItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase0Value = string | number | boolean | AppsFlagsGetResponseRulesItemConditionsItemCase0ValueCase3Map | AppsFlagsGetResponseRulesItemConditionsItemCase0ValueCase4List;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsGetResponseRulesItemConditionsItemCase0Operator;
    value: AppsFlagsGetResponseRulesItemConditionsItemCase0Value;
}
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0Operator;
    value: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0Value;
}
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItem = AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItem>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1 {
    clauses: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsGetResponseRulesItemConditionsItemCase1LogicalOperator;
}
export type AppsFlagsGetResponseRulesItemConditionsItem = AppsFlagsGetResponseRulesItemConditionsItemCase0 | AppsFlagsGetResponseRulesItemConditionsItemCase1;
export type AppsFlagsGetResponseRulesItemConditionsList = Array<AppsFlagsGetResponseRulesItemConditionsItem>;
export type AppsFlagsGetResponseRulesItemRollout = AppsFlagsCreateResponseRulesItemRollout;
export interface AppsFlagsGetResponseRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsGetResponseRulesItemConditionsList;
    /** Evaluation order: the API evaluates rules with lower numbers first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation the API serves when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export type AppsFlagsGetResponseRulesList = Array<AppsFlagsGetResponseRulesItem>;
export type AppsFlagsGetResponseType = "boolean" | "string" | "number" | "json";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAppFlagResponse {
    /** Variation the API serves when the flag is off, or when it's on but no rule matches the context. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsGetResponseRulesList;
    /** Server-inferred value type shared by all of the flag's variations. */
    type: AppsFlagsGetResponseType;
    /** Map of variation name to value. All values share the same type (boolean, string, number, or JSON object/array), and each serialized value stays within 10KB. */
    variations: UntypedVariationsMap;
    /** Optional operator-facing description. It does not affect flag evaluation. */
    description?: string | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export interface ListAppFlagChangelogsRequest {
    /** Cloudflare account ID that owns the Flagship app. */
    accountId: string;
    /** Flagship app ID returned when the app was created. */
    appId: string;
    /** Case-sensitive key identifying the flag within the app. */
    flagKey: string;
    /** Pagination cursor from a previous response. */
    cursor?: string;
    /** Max items to return (1-200). */
    limit?: number;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItem = AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0 | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItem>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemRollout = AppsFlagsCreateResponseRulesItemRollout;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsList;
    /** Evaluation order: the API evaluates rules with lower numbers first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation the API serves when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export type AppsFlagsChangelogListResultItemCase0AfterRulesList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItem>;
export type AppsFlagsChangelogListResultItemCase0AfterType = "boolean" | "string" | "number" | "json";
export interface AppsFlagsChangelogListResultItemCase0After {
    /** Variation the API serves when the flag is off, or when it's on but no rule matches the context. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsChangelogListResultItemCase0AfterRulesList;
    /** Server-inferred value type shared by all of the flag's variations. */
    type: AppsFlagsChangelogListResultItemCase0AfterType;
    /** Map of variation name to value. All values share the same type (boolean, string, number, or JSON object/array), and each serialized value stays within 10KB. */
    variations: UntypedVariationsMap;
    /** Optional operator-facing description. It does not affect flag evaluation. */
    description?: string | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export type AppsFlagsChangelogListResultItemCase0Event = "create";
export interface AppsFlagsChangelogListResultItemCase0 {
    after: AppsFlagsChangelogListResultItemCase0After;
    event: AppsFlagsChangelogListResultItemCase0Event;
    flagKey: string;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItem = AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0 | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItem>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemRollout = AppsFlagsCreateResponseRulesItemRollout;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsList;
    /** Evaluation order: the API evaluates rules with lower numbers first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation the API serves when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export type AppsFlagsChangelogListResultItemCase1AfterRulesList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItem>;
export type AppsFlagsChangelogListResultItemCase1AfterType = "boolean" | "string" | "number" | "json";
export interface AppsFlagsChangelogListResultItemCase1After {
    /** Variation the API serves when the flag is off, or when it's on but no rule matches the context. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsChangelogListResultItemCase1AfterRulesList;
    /** Server-inferred value type shared by all of the flag's variations. */
    type: AppsFlagsChangelogListResultItemCase1AfterType;
    /** Map of variation name to value. All values share the same type (boolean, string, number, or JSON object/array), and each serialized value stays within 10KB. */
    variations: UntypedVariationsMap;
    /** Optional operator-facing description. It does not affect flag evaluation. */
    description?: string | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export type AppsFlagsChangelogListResultItemCase1Event = "delete";
export interface AppsFlagsChangelogListResultItemCase1 {
    after: AppsFlagsChangelogListResultItemCase1After;
    event: AppsFlagsChangelogListResultItemCase1Event;
    flagKey: string;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItem>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1LogicalOperator;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItem = AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0 | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItem>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemRollout = AppsFlagsCreateResponseRulesItemRollout;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsList;
    /** Evaluation order: the API evaluates rules with lower numbers first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation the API serves when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export type AppsFlagsChangelogListResultItemCase2AfterRulesList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItem>;
export type AppsFlagsChangelogListResultItemCase2AfterType = "boolean" | "string" | "number" | "json";
export interface AppsFlagsChangelogListResultItemCase2After {
    /** Variation the API serves when the flag is off, or when it's on but no rule matches the context. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsChangelogListResultItemCase2AfterRulesList;
    /** Server-inferred value type shared by all of the flag's variations. */
    type: AppsFlagsChangelogListResultItemCase2AfterType;
    /** Map of variation name to value. All values share the same type (boolean, string, number, or JSON object/array), and each serialized value stays within 10KB. */
    variations: UntypedVariationsMap;
    /** Optional operator-facing description. It does not affect flag evaluation. */
    description?: string | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export type AppsFlagsChangelogListResultItemCase2DiffValueFromCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase2DiffValueFromCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase2DiffValueFrom = string | number | boolean | AppsFlagsChangelogListResultItemCase2DiffValueFromCase3Map | AppsFlagsChangelogListResultItemCase2DiffValueFromCase4List;
export type AppsFlagsChangelogListResultItemCase2DiffValueToCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsChangelogListResultItemCase2DiffValueToCase4List = Array<unknown>;
export type AppsFlagsChangelogListResultItemCase2DiffValueTo = string | number | boolean | AppsFlagsChangelogListResultItemCase2DiffValueToCase3Map | AppsFlagsChangelogListResultItemCase2DiffValueToCase4List;
export interface AppsFlagsChangelogListResultItemCase2DiffValue {
    from?: AppsFlagsChangelogListResultItemCase2DiffValueFrom | null;
    to?: AppsFlagsChangelogListResultItemCase2DiffValueTo | null;
}
export type AppsFlagsChangelogListResultItemCase2DiffMap = {
    [key: string]: AppsFlagsChangelogListResultItemCase2DiffValue | undefined;
};
export type AppsFlagsChangelogListResultItemCase2Event = "update";
export interface AppsFlagsChangelogListResultItemCase2 {
    after: AppsFlagsChangelogListResultItemCase2After;
    diff: AppsFlagsChangelogListResultItemCase2DiffMap;
    event: AppsFlagsChangelogListResultItemCase2Event;
    flagKey: string;
}
export type AppsFlagsChangelogListResultItem = AppsFlagsChangelogListResultItemCase0 | AppsFlagsChangelogListResultItemCase1 | AppsFlagsChangelogListResultItemCase2;
export type AppsFlagsChangelogListResultList = Array<AppsFlagsChangelogListResultItem>;
export interface ListAppFlagChangelogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AppsFlagsChangelogListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListAppFlagsRequest {
    /** Cloudflare account ID that owns the Flagship app. */
    accountId: string;
    /** Flagship app ID returned when the app was created. */
    appId: string;
    /** Pagination cursor from a previous response. */
    cursor?: string;
    /** Max items to return (1-200). */
    limit?: number;
}
export type AppsFlagsListResultItemRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsListResultItemRulesItemConditionsItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsListResultItemRulesItemConditionsItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase0Value = string | number | boolean | AppsFlagsListResultItemRulesItemConditionsItemCase0ValueCase3Map | AppsFlagsListResultItemRulesItemConditionsItemCase0ValueCase4List;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsListResultItemRulesItemConditionsItemCase0Operator;
    value: AppsFlagsListResultItemRulesItemConditionsItemCase0Value;
}
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0Operator;
    value: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0Value;
}
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItem = AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItem>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1 {
    clauses: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsListResultItemRulesItemConditionsItemCase1LogicalOperator;
}
export type AppsFlagsListResultItemRulesItemConditionsItem = AppsFlagsListResultItemRulesItemConditionsItemCase0 | AppsFlagsListResultItemRulesItemConditionsItemCase1;
export type AppsFlagsListResultItemRulesItemConditionsList = Array<AppsFlagsListResultItemRulesItemConditionsItem>;
export type AppsFlagsListResultItemRulesItemRollout = AppsFlagsCreateResponseRulesItemRollout;
export interface AppsFlagsListResultItemRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsListResultItemRulesItemConditionsList;
    /** Evaluation order: the API evaluates rules with lower numbers first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation the API serves when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export type AppsFlagsListResultItemRulesList = Array<AppsFlagsListResultItemRulesItem>;
export type AppsFlagsListResultItemType = "boolean" | "string" | "number" | "json";
export interface AppsFlagsListResultItem {
    /** Variation the API serves when the flag is off, or when it's on but no rule matches the context. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsListResultItemRulesList;
    /** Server-inferred value type shared by all of the flag's variations. */
    type: AppsFlagsListResultItemType;
    /** Map of variation name to value. All values share the same type (boolean, string, number, or JSON object/array), and each serialized value stays within 10KB. */
    variations: UntypedVariationsMap;
    /** Optional operator-facing description. It does not affect flag evaluation. */
    description?: string | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export type AppsFlagsListResultList = Array<AppsFlagsListResultItem>;
export interface ListAppFlagsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AppsFlagsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListAppsRequest {
    /** Cloudflare account ID that owns the Flagship app. */
    accountId: string;
}
export interface AppsListResultItem {
    id: string;
    createdAt: string;
    name: string;
    updatedAt: string;
    /** Email of the actor who last modified the app, or `unknown` when unavailable. */
    updatedBy: string;
}
export type AppsListResultList = Array<AppsListResultItem>;
export interface ListAppsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AppsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface UpdateAppRequest {
    /** Cloudflare account ID that owns the Flagship app. */
    accountId: string;
    /** Flagship app ID returned when the app was created. */
    appId: string;
    /** Name of the Flagship app (1-64 letters, numbers, hyphens, or underscores). */
    name?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAppResponse {
    id: string;
    createdAt: string;
    name: string;
    updatedAt: string;
    /** Email of the actor who last modified the app, or `unknown` when unavailable. */
    updatedBy: string;
}
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase0Value = string | number | boolean | AppsFlagsUpdateRequestRulesItemConditionsItemCase0ValueCase3Map | AppsFlagsUpdateRequestRulesItemConditionsItemCase0ValueCase4List;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateRequestRulesItemConditionsItemCase0Operator | (string & {});
    value: AppsFlagsUpdateRequestRulesItemConditionsItemCase0Value;
}
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0Operator | (string & {});
    value: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0Value;
}
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    value: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    value: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    value: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    value: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItem = AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItem>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1 {
    clauses: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1LogicalOperator | (string & {});
}
export type AppsFlagsUpdateRequestRulesItemConditionsItem = AppsFlagsUpdateRequestRulesItemConditionsItemCase0 | AppsFlagsUpdateRequestRulesItemConditionsItemCase1;
export type AppsFlagsUpdateRequestRulesItemConditionsList = Array<AppsFlagsUpdateRequestRulesItemConditionsItem>;
export type AppsFlagsUpdateRequestRulesItemRollout = AppsFlagsCreateRequestRulesItemRollout;
export interface AppsFlagsUpdateRequestRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsUpdateRequestRulesItemConditionsList;
    /** Evaluation order: the API evaluates rules with lower numbers first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation the API serves when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateRequestRulesItemRollout;
}
export type AppsFlagsUpdateRequestRulesList = Array<AppsFlagsUpdateRequestRulesItem>;
export type AppsFlagsUpdateRequestType = "boolean" | "string" | "number" | "json";
export interface UpdateAppFlagRequest {
    /** Cloudflare account ID that owns the Flagship app. */
    accountId: string;
    /** Flagship app ID returned when the app was created. */
    appId: string;
    /** Case-sensitive key identifying the flag within the app. */
    flagKey: string;
    /** Variation the API serves when the flag is off, or when it's on but no rule matches the context. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsUpdateRequestRulesList;
    /** Map of variation name to value. All values share the same type (boolean, string, number, or JSON object/array), and each serialized value stays within 10KB. */
    variations: UntypedVariationsMap;
    /** Optional operator-facing description. It does not affect flag evaluation. */
    description?: string;
    /** Deprecated compatibility field. Omit it; the API ignores this value and infers the type from the flag's variations. */
    type?: AppsFlagsUpdateRequestType | (string & {});
}
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase0Value = string | number | boolean | AppsFlagsUpdateResponseRulesItemConditionsItemCase0ValueCase3Map | AppsFlagsUpdateResponseRulesItemConditionsItemCase0ValueCase4List;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateResponseRulesItemConditionsItemCase0Operator;
    value: AppsFlagsUpdateResponseRulesItemConditionsItemCase0Value;
}
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0Operator;
    value: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0Value;
}
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in" | "has" | "not_has";
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List = Array<unknown>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value = string | number | boolean | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase3Map | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0ValueCase4List;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    value: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Value;
}
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItem = AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItem>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1 {
    clauses: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1LogicalOperator;
}
export type AppsFlagsUpdateResponseRulesItemConditionsItem = AppsFlagsUpdateResponseRulesItemConditionsItemCase0 | AppsFlagsUpdateResponseRulesItemConditionsItemCase1;
export type AppsFlagsUpdateResponseRulesItemConditionsList = Array<AppsFlagsUpdateResponseRulesItemConditionsItem>;
export type AppsFlagsUpdateResponseRulesItemRollout = AppsFlagsCreateResponseRulesItemRollout;
export interface AppsFlagsUpdateResponseRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsUpdateResponseRulesItemConditionsList;
    /** Evaluation order: the API evaluates rules with lower numbers first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation the API serves when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export type AppsFlagsUpdateResponseRulesList = Array<AppsFlagsUpdateResponseRulesItem>;
export type AppsFlagsUpdateResponseType = "boolean" | "string" | "number" | "json";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAppFlagResponse {
    /** Variation the API serves when the flag is off, or when it's on but no rule matches the context. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsUpdateResponseRulesList;
    /** Server-inferred value type shared by all of the flag's variations. */
    type: AppsFlagsUpdateResponseType;
    /** Map of variation name to value. All values share the same type (boolean, string, number, or JSON object/array), and each serialized value stays within 10KB. */
    variations: UntypedVariationsMap;
    /** Optional operator-facing description. It does not affect flag evaluation. */
    description?: string | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export type CreateAppError = CloudflareOpError;
/** Creates an app. The returned `id` is used in all subsequent flag, changelog, and evaluation requests. */
export declare const createApp: API.OperationMethod<CreateAppRequest, CreateAppResponse, CreateAppError, CloudflareOpContext>;
export type CreateAppFlagError = FlagshipFlagAlreadyExists | FlagshipAppNotFound | CloudflareOpError;
/** Creates a flag. Returns 409 if the key already exists. `type` is always inferred from variation values; legacy request-side values are ignored. */
export declare const createAppFlag: API.OperationMethod<CreateAppFlagRequest, CreateAppFlagResponse, CreateAppFlagError, CloudflareOpContext>;
export type DeleteAppError = FlagshipAppNotFound | CloudflareOpError;
/** Deletes an app and all its flags and changelog history. Returns 409 if any Worker still references this app via a Flagship binding. */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest, DeleteAppResponse, DeleteAppError, CloudflareOpContext>;
export type DeleteAppFlagError = FlagshipFlagNotFound | FlagshipAppNotFound | CloudflareOpError;
/** Deletes a flag permanently. After deletion propagates, direct evaluations return not found; typed binding accessors may return the caller-supplied default. Cannot be undone. */
export declare const deleteAppFlag: API.OperationMethod<DeleteAppFlagRequest, DeleteAppFlagResponse, DeleteAppFlagError, CloudflareOpContext>;
export type GetAppError = FlagshipAppNotFound | CloudflareOpError;
/** Returns an app's name and audit fields. Flag definitions are not included. */
export declare const getApp: API.OperationMethod<GetAppRequest, GetAppResponse, GetAppError, CloudflareOpContext>;
export type GetAppEvaluateError = CloudflareOpError;
/** Evaluates a flag against the provided context. Pass context attributes as query parameters; values are coerced to numbers or booleans where unambiguous. For low-latency in-Worker evaluation, prefer the Flagship binding over this endpoint. */
export declare const getAppEvaluate: API.OperationMethod<GetAppEvaluateRequest, GetAppEvaluateResponse, GetAppEvaluateError, CloudflareOpContext>;
export type GetAppFlagError = FlagshipFlagNotFound | FlagshipAppNotFound | CloudflareOpError;
/** Returns the full flag definition including rules, variations, and audit fields. */
export declare const getAppFlag: API.OperationMethod<GetAppFlagRequest, GetAppFlagResponse, GetAppFlagError, CloudflareOpContext>;
export type ListAppFlagChangelogsError = CloudflareOpError;
/** Returns the audit history for a flag, newest first. Each entry includes the event type and full flag state after the change; `update` entries include a field-level diff. Capped at 200 entries per flag. */
export declare const listAppFlagChangelogs: API.PaginatedOperationMethod<ListAppFlagChangelogsRequest, ListAppFlagChangelogsResponse, ListAppFlagChangelogsError, CloudflareOpContext, AppsFlagsChangelogListResultItem>;
export type ListAppFlagsError = FlagshipAppNotFound | CloudflareOpError;
/** Lists an app's flags ordered by key. Pass `cursor` from `result_info` to page forward; a null cursor indicates the last page. */
export declare const listAppFlags: API.PaginatedOperationMethod<ListAppFlagsRequest, ListAppFlagsResponse, ListAppFlagsError, CloudflareOpContext, AppsFlagsListResultItem>;
export type ListAppsError = CloudflareOpError;
/** Lists all Flagship apps in the account. Returns identity and audit fields only; flag definitions are not included. */
export declare const listApps: API.PaginatedOperationMethod<ListAppsRequest, ListAppsResponse, ListAppsError, CloudflareOpContext, AppsListResultItem>;
export type UpdateAppError = FlagshipAppNotFound | CloudflareOpError;
/** Updates an app. Only `name` is mutable. */
export declare const updateApp: API.OperationMethod<UpdateAppRequest, UpdateAppResponse, UpdateAppError, CloudflareOpContext>;
export type UpdateAppFlagError = FlagshipFlagNotFound | FlagshipAppNotFound | CloudflareOpError;
/** Replaces the entire flag definition. Omitted fields are dropped, not preserved -- read before writing. The path key identifies the flag and cannot be renamed by changing the body `key`. Each update appends a changelog entry. */
export declare const updateAppFlag: API.OperationMethod<UpdateAppFlagRequest, UpdateAppFlagResponse, UpdateAppFlagError, CloudflareOpContext>;
//# sourceMappingURL=flagship.d.ts.map