import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CacheReserveClearStatusRequest {
    /** Identifier. */
    zoneId: string;
}
export type CacheReserveClearStatusResponseState = "In-progress" | "Completed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CacheReserveClearStatusResponse {
    /** ID of the zone setting. */
    id: unknown;
    /** The time that the latest Cache Reserve Clear operation started. */
    startTs: string;
    /** The current state of the Cache Reserve Clear operation. */
    state: CacheReserveClearStatusResponseState;
    /** The time that the latest Cache Reserve Clear operation completed. */
    endTs?: string | null;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export interface ClearCacheReserveClearRequest {
    /** Identifier. */
    zoneId: string;
}
export type ClearCacheReserveClearResponseState = "In-progress" | "Completed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ClearCacheReserveClearResponse {
    /** ID of the zone setting. */
    id: unknown;
    /** The time that the latest Cache Reserve Clear operation started. */
    startTs: string;
    /** The current state of the Cache Reserve Clear operation. */
    state: ClearCacheReserveClearResponseState;
    /** The time that the latest Cache Reserve Clear operation completed. */
    endTs?: string | null;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export type CreateHealthCheckRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type CreateHealthCheckRequestCheckRegionsList = Array<CreateHealthCheckRequestCheckRegionsItem | (string & {})>;
export type CreateHealthCheckRequestHttpConfigExpectedCodesList = Array<string>;
export type CreateHealthCheckRequestHttpConfigHeaderValueList = Array<string>;
export type CreateHealthCheckRequestHttpConfigHeaderMap = {
    [key: string]: CreateHealthCheckRequestHttpConfigHeaderValueList | undefined;
};
export type CreateHealthCheckRequestHttpConfigMethod = "GET" | "HEAD";
export interface CreateHealthCheckRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: CreateHealthCheckRequestHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: CreateHealthCheckRequestHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: CreateHealthCheckRequestHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export type CreateHealthCheckRequestTcpConfigMethod = "connection_established";
export interface CreateHealthCheckRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: CreateHealthCheckRequestTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export interface CreateHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: CreateHealthCheckRequestCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    /** A human-readable description of the health check. */
    description?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: CreateHealthCheckRequestHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: CreateHealthCheckRequestTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export type CreateHealthCheckResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type CreateHealthCheckResponseCheckRegionsList = Array<CreateHealthCheckResponseCheckRegionsItem>;
export type CreateHealthCheckResponseHttpConfigExpectedCodesList = Array<string>;
export type CreateHealthCheckResponseHttpConfigHeaderValueList = Array<string>;
export type CreateHealthCheckResponseHttpConfigHeaderMap = {
    [key: string]: CreateHealthCheckResponseHttpConfigHeaderValueList | undefined;
};
export type CreateHealthCheckResponseHttpConfigMethod = "GET" | "HEAD";
export interface CreateHealthCheckResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: CreateHealthCheckResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: CreateHealthCheckResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: CreateHealthCheckResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export type CreateHealthCheckResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type CreateHealthCheckResponseTcpConfigMethod = "connection_established";
export interface CreateHealthCheckResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: CreateHealthCheckResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateHealthCheckResponse {
    /** Identifier. */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: CreateHealthCheckResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: CreateHealthCheckResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: CreateHealthCheckResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: CreateHealthCheckResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export interface DeleteHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    healthcheckId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteHealthCheckResponse {
    /** Identifier. */
    id?: string | null;
}
export type EditHealthCheckRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type EditHealthCheckRequestCheckRegionsList = Array<EditHealthCheckRequestCheckRegionsItem | (string & {})>;
export type EditHealthCheckRequestHttpConfigExpectedCodesList = Array<string>;
export type EditHealthCheckRequestHttpConfigHeaderValueList = Array<string>;
export type EditHealthCheckRequestHttpConfigHeaderMap = {
    [key: string]: EditHealthCheckRequestHttpConfigHeaderValueList | undefined;
};
export type EditHealthCheckRequestHttpConfigMethod = "GET" | "HEAD";
export interface EditHealthCheckRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: EditHealthCheckRequestHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: EditHealthCheckRequestHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: EditHealthCheckRequestHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export type EditHealthCheckRequestTcpConfigMethod = "connection_established";
export interface EditHealthCheckRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: EditHealthCheckRequestTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export interface EditHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    healthcheckId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: EditHealthCheckRequestCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    /** A human-readable description of the health check. */
    description?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: EditHealthCheckRequestHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: EditHealthCheckRequestTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export type EditHealthCheckResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type EditHealthCheckResponseCheckRegionsList = Array<EditHealthCheckResponseCheckRegionsItem>;
export type EditHealthCheckResponseHttpConfigExpectedCodesList = Array<string>;
export type EditHealthCheckResponseHttpConfigHeaderValueList = Array<string>;
export type EditHealthCheckResponseHttpConfigHeaderMap = {
    [key: string]: EditHealthCheckResponseHttpConfigHeaderValueList | undefined;
};
export type EditHealthCheckResponseHttpConfigMethod = "GET" | "HEAD";
export interface EditHealthCheckResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: EditHealthCheckResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: EditHealthCheckResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: EditHealthCheckResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export type EditHealthCheckResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type EditHealthCheckResponseTcpConfigMethod = "connection_established";
export interface EditHealthCheckResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: EditHealthCheckResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditHealthCheckResponse {
    /** Identifier. */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: EditHealthCheckResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: EditHealthCheckResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: EditHealthCheckResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: EditHealthCheckResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export interface GetRequest {
    /** Identifier. */
    zoneId: string;
}
export type GetResponseCacheReserveValue = "on" | "off";
export interface GetResponseCacheReserve {
    /** The id of the Cache Reserve setting. */
    id?: string | null;
    /** Whether the setting is editable. */
    editable?: boolean | null;
    /** Specifies the enablement value of Cache Reserve. */
    value?: GetResponseCacheReserveValue | null;
}
export type GetResponseRegionalTieredCacheValue = "on" | "off";
export interface GetResponseRegionalTieredCache {
    /** The id of the Regional Tiered Cache setting. */
    id?: string | null;
    /** Whether the setting is editable. */
    editable?: boolean | null;
    /** Specifies the enablement value of Cache Reserve. */
    value?: GetResponseRegionalTieredCacheValue | null;
}
export type GetResponseSmartRoutingValue = "on" | "off";
export interface GetResponseSmartRouting {
    /** The id of the Smart Routing setting. */
    id?: string | null;
    /** Whether the setting is editable. */
    editable?: boolean | null;
    /** Specifies the enablement value of Argo Smart Routing. */
    value?: GetResponseSmartRoutingValue | null;
}
export type GetResponseSmartTieredCacheValue = "on" | "off";
export interface GetResponseSmartTieredCache {
    /** The id of the Smart Tiered Cache setting. */
    id?: string | null;
    /** Whether the setting is editable. */
    editable?: boolean | null;
    /** The last time the setting was modified. */
    modifiedOn?: string | null;
    /** Specifies the enablement value of Tiered Cache. */
    value?: GetResponseSmartTieredCacheValue | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResponse {
    cacheReserve: GetResponseCacheReserve;
    /** The total number of health checks associated with the zone. */
    healthchecksCount: number;
    regionalTieredCache: GetResponseRegionalTieredCache;
    smartRouting: GetResponseSmartRouting;
    smartTieredCache: GetResponseSmartTieredCache;
}
export interface GetHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    healthcheckId: string;
}
export type GetHealthCheckResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type GetHealthCheckResponseCheckRegionsList = Array<GetHealthCheckResponseCheckRegionsItem>;
export type GetHealthCheckResponseHttpConfigExpectedCodesList = Array<string>;
export type GetHealthCheckResponseHttpConfigHeaderValueList = Array<string>;
export type GetHealthCheckResponseHttpConfigHeaderMap = {
    [key: string]: GetHealthCheckResponseHttpConfigHeaderValueList | undefined;
};
export type GetHealthCheckResponseHttpConfigMethod = "GET" | "HEAD";
export interface GetHealthCheckResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: GetHealthCheckResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: GetHealthCheckResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: GetHealthCheckResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export type GetHealthCheckResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type GetHealthCheckResponseTcpConfigMethod = "connection_established";
export interface GetHealthCheckResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: GetHealthCheckResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHealthCheckResponse {
    /** Identifier. */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: GetHealthCheckResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: GetHealthCheckResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: GetHealthCheckResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: GetHealthCheckResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export interface ListHealthChecksRequest {
    /** Identifier. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. Must be a multiple of 5. */
    perPage?: number;
}
export type ListHealthChecksResultItemCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type ListHealthChecksResultItemCheckRegionsList = Array<ListHealthChecksResultItemCheckRegionsItem>;
export type ListHealthChecksResultItemHttpConfigExpectedCodesList = Array<string>;
export type ListHealthChecksResultItemHttpConfigHeaderValueList = Array<string>;
export type ListHealthChecksResultItemHttpConfigHeaderMap = {
    [key: string]: ListHealthChecksResultItemHttpConfigHeaderValueList | undefined;
};
export type ListHealthChecksResultItemHttpConfigMethod = "GET" | "HEAD";
export interface ListHealthChecksResultItemHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: ListHealthChecksResultItemHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: ListHealthChecksResultItemHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: ListHealthChecksResultItemHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export type ListHealthChecksResultItemStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type ListHealthChecksResultItemTcpConfigMethod = "connection_established";
export interface ListHealthChecksResultItemTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: ListHealthChecksResultItemTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export interface ListHealthChecksResultItem {
    /** Identifier. */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: ListHealthChecksResultItemCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: ListHealthChecksResultItemHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: ListHealthChecksResultItemStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: ListHealthChecksResultItemTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export type ListHealthChecksResultList = Array<ListHealthChecksResultItem>;
export type ListHealthChecksResponse = ListHealthChecksResultList;
export type UpdateRequestCacheReserveValue = "on" | "off";
export interface UpdateRequestCacheReserve {
    /** Specifies the enablement value of Cache Reserve. */
    value?: UpdateRequestCacheReserveValue | (string & {});
}
export type UpdateRequestRegionalTieredCacheValue = "on" | "off";
export interface UpdateRequestRegionalTieredCache {
    /** Specifies the enablement value of Regional Tiered Cache. */
    value?: UpdateRequestRegionalTieredCacheValue | (string & {});
}
export type UpdateRequestSmartRoutingValue = "on" | "off";
export interface UpdateRequestSmartRouting {
    /** Specifies the enablement value of Smart Routing. */
    value?: UpdateRequestSmartRoutingValue | (string & {});
}
export type UpdateRequestSmartTieredCacheValue = "on" | "off";
export interface UpdateRequestSmartTieredCache {
    /** Specifies the enablement value of Smart Tiered Cache. */
    value?: UpdateRequestSmartTieredCacheValue | (string & {});
}
export interface UpdateRequest {
    /** Identifier. */
    zoneId: string;
    cacheReserve?: UpdateRequestCacheReserve;
    regionalTieredCache?: UpdateRequestRegionalTieredCache;
    smartRouting?: UpdateRequestSmartRouting;
    smartTieredCache?: UpdateRequestSmartTieredCache;
}
export type UpdateResponseSmartTieredCacheValue = "on" | "off";
export interface UpdateResponseSmartTieredCache {
    /** The id of the Smart Tiered Cache setting. */
    id?: string | null;
    /** Whether the setting is editable. */
    editable?: boolean | null;
    /** The last time the setting was modified. */
    modifiedOn?: string | null;
    /** Specifies the enablement value of Tiered Cache. */
    value?: UpdateResponseSmartTieredCacheValue | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResponse {
    smartTieredCache: UpdateResponseSmartTieredCache;
}
export interface UpdateHealthCheckRequestErrorsItemSource {
    pointer?: string;
}
export interface UpdateHealthCheckRequestErrorsItem {
    code: number;
    message: string;
    documentationUrl?: string;
    source?: UpdateHealthCheckRequestErrorsItemSource;
}
export type UpdateHealthCheckRequestErrorsList = Array<UpdateHealthCheckRequestErrorsItem>;
export type UpdateHealthCheckRequestMessagesItemSource = UpdateHealthCheckRequestErrorsItemSource;
export type UpdateHealthCheckRequestMessagesItem = UpdateHealthCheckRequestErrorsItem;
export type UpdateHealthCheckRequestMessagesList = Array<UpdateHealthCheckRequestErrorsItem>;
export type UpdateHealthCheckRequestResultCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type UpdateHealthCheckRequestResultCheckRegionsList = Array<UpdateHealthCheckRequestResultCheckRegionsItem | (string & {})>;
export type UpdateHealthCheckRequestResultHttpConfigExpectedCodesList = Array<string>;
export type UpdateHealthCheckRequestResultHttpConfigHeaderValueList = Array<string>;
export type UpdateHealthCheckRequestResultHttpConfigHeaderMap = {
    [key: string]: UpdateHealthCheckRequestResultHttpConfigHeaderValueList | undefined;
};
export type UpdateHealthCheckRequestResultHttpConfigMethod = "GET" | "HEAD";
export interface UpdateHealthCheckRequestResultHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: UpdateHealthCheckRequestResultHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: UpdateHealthCheckRequestResultHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: UpdateHealthCheckRequestResultHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export type UpdateHealthCheckRequestResultStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type UpdateHealthCheckRequestResultTcpConfigMethod = "connection_established";
export interface UpdateHealthCheckRequestResultTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: UpdateHealthCheckRequestResultTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export interface UpdateHealthCheckRequestResult {
    /** Identifier. */
    id?: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: UpdateHealthCheckRequestResultCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    createdOn?: string;
    /** A human-readable description of the health check. */
    description?: string;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: UpdateHealthCheckRequestResultHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    modifiedOn?: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** The current status of the origin server according to the health check. */
    status?: UpdateHealthCheckRequestResultStatus | (string & {});
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: UpdateHealthCheckRequestResultTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export interface UpdateHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    healthcheckId: string;
    errors: UpdateHealthCheckRequestErrorsList;
    messages: UpdateHealthCheckRequestMessagesList;
    result: UpdateHealthCheckRequestResult;
    /** Whether the API call was successful. */
    success: boolean;
}
export type UpdateHealthCheckResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type UpdateHealthCheckResponseCheckRegionsList = Array<UpdateHealthCheckResponseCheckRegionsItem>;
export type UpdateHealthCheckResponseHttpConfigExpectedCodesList = Array<string>;
export type UpdateHealthCheckResponseHttpConfigHeaderValueList = Array<string>;
export type UpdateHealthCheckResponseHttpConfigHeaderMap = {
    [key: string]: UpdateHealthCheckResponseHttpConfigHeaderValueList | undefined;
};
export type UpdateHealthCheckResponseHttpConfigMethod = "GET" | "HEAD";
export interface UpdateHealthCheckResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: UpdateHealthCheckResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: UpdateHealthCheckResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: UpdateHealthCheckResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export type UpdateHealthCheckResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type UpdateHealthCheckResponseTcpConfigMethod = "connection_established";
export interface UpdateHealthCheckResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: UpdateHealthCheckResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateHealthCheckResponse {
    /** Identifier. */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: UpdateHealthCheckResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: UpdateHealthCheckResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: UpdateHealthCheckResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: UpdateHealthCheckResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export type CacheReserveClearStatusError = CloudflareOpError;
/** You can use Cache Reserve Clear to clear your Cache Reserve, but you must first disable Cache Reserve. In most cases, this will be accomplished within 24 hours. You cannot re-enable Cache Reserve while this process is ongoing. Keep in mind that you cannot undo or cancel this operation. */
export declare const cacheReserveClearStatus: API.OperationMethod<CacheReserveClearStatusRequest, CacheReserveClearStatusResponse, CacheReserveClearStatusError, CloudflareOpContext>;
export type ClearCacheReserveClearError = CloudflareOpError;
/** You can use Cache Reserve Clear to clear your Cache Reserve, but you must first disable Cache Reserve. In most cases, this will be accomplished within 24 hours. You cannot re-enable Cache Reserve while this process is ongoing. Keep in mind that you cannot undo or cancel this operation. */
export declare const clearCacheReserveClear: API.OperationMethod<ClearCacheReserveClearRequest, ClearCacheReserveClearResponse, ClearCacheReserveClearError, CloudflareOpContext>;
export type CreateHealthCheckError = CloudflareOpError;
/** Create a new health check. */
export declare const createHealthCheck: API.OperationMethod<CreateHealthCheckRequest, CreateHealthCheckResponse, CreateHealthCheckError, CloudflareOpContext>;
export type DeleteHealthCheckError = CloudflareOpError;
/** Delete a health check. */
export declare const deleteHealthCheck: API.OperationMethod<DeleteHealthCheckRequest, DeleteHealthCheckResponse, DeleteHealthCheckError, CloudflareOpContext>;
export type EditHealthCheckError = CloudflareOpError;
/** Patch a configured health check. */
export declare const editHealthCheck: API.OperationMethod<EditHealthCheckRequest, EditHealthCheckResponse, EditHealthCheckError, CloudflareOpContext>;
export type GetError = CloudflareOpError;
/** Retrieve Smart Shield Settings. */
export declare const get: API.OperationMethod<GetRequest, GetResponse, GetError, CloudflareOpContext>;
export type GetHealthCheckError = CloudflareOpError;
/** Fetch a single configured health check. */
export declare const getHealthCheck: API.OperationMethod<GetHealthCheckRequest, GetHealthCheckResponse, GetHealthCheckError, CloudflareOpContext>;
export type ListHealthChecksError = CloudflareOpError;
/** List configured health checks. */
export declare const listHealthChecks: API.OperationMethod<ListHealthChecksRequest, ListHealthChecksResponse, ListHealthChecksError, CloudflareOpContext>;
export type UpdateError = CloudflareOpError;
/** Set Smart Shield Settings. */
export declare const update: API.OperationMethod<UpdateRequest, UpdateResponse, UpdateError, CloudflareOpContext>;
export type UpdateHealthCheckError = CloudflareOpError;
/** Update a configured health check. */
export declare const updateHealthCheck: API.OperationMethod<UpdateHealthCheckRequest, UpdateHealthCheckResponse, UpdateHealthCheckError, CloudflareOpContext>;
//# sourceMappingURL=smart_shield.d.ts.map