import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const TokenConfigurationNotFound_base: S.TaggedErrorClass<"TokenConfigurationNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TokenConfigurationNotFound extends /*@__PURE__*/ TokenConfigurationNotFound_base {
}
declare const TokenValidationNotEntitled_base: S.TaggedErrorClass<"TokenValidationNotEntitled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TokenValidationNotEntitled extends /*@__PURE__*/ TokenValidationNotEntitled_base {
}
declare const TokenValidationRuleNotFound_base: S.TaggedErrorClass<"TokenValidationRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TokenValidationRuleNotFound extends /*@__PURE__*/ TokenValidationRuleNotFound_base {
}
export type RulesBulkCreateRequestBodyItemAction = "log" | "block";
export type RulesBulkCreateRequestBodyItemSelectorExcludeItemOperationIdsList = Array<string>;
export interface RulesBulkCreateRequestBodyItemSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesBulkCreateRequestBodyItemSelectorExcludeItemOperationIdsList;
}
export type RulesBulkCreateRequestBodyItemSelectorExcludeList = Array<RulesBulkCreateRequestBodyItemSelectorExcludeItem>;
export type RulesBulkCreateRequestBodyItemSelectorIncludeItemHostList = Array<string>;
export interface RulesBulkCreateRequestBodyItemSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesBulkCreateRequestBodyItemSelectorIncludeItemHostList;
}
export type RulesBulkCreateRequestBodyItemSelectorIncludeList = Array<RulesBulkCreateRequestBodyItemSelectorIncludeItem>;
export interface RulesBulkCreateRequestBodyItemSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesBulkCreateRequestBodyItemSelectorExcludeList;
    /** Select all matching operations. */
    include?: RulesBulkCreateRequestBodyItemSelectorIncludeList;
}
export interface RulesBulkCreateRequestBodyItem {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesBulkCreateRequestBodyItemAction | (string & {});
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesBulkCreateRequestBodyItemSelector;
    /** A human-readable name for the rule. */
    title: string;
}
export type RulesBulkCreateRequestBodyList = Array<RulesBulkCreateRequestBodyItem>;
export interface BulkCreateRulesRequest {
    /** Identifier. */
    zoneId: string;
    body: RulesBulkCreateRequestBodyList;
}
export type RulesBulkCreateResultItemAction = "log" | "block";
export type RulesBulkCreateResultItemSelectorExcludeItemOperationIdsList = Array<string>;
export interface RulesBulkCreateResultItemSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesBulkCreateResultItemSelectorExcludeItemOperationIdsList | null;
}
export type RulesBulkCreateResultItemSelectorExcludeList = Array<RulesBulkCreateResultItemSelectorExcludeItem>;
export type RulesBulkCreateResultItemSelectorIncludeItemHostList = Array<string>;
export interface RulesBulkCreateResultItemSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesBulkCreateResultItemSelectorIncludeItemHostList | null;
}
export type RulesBulkCreateResultItemSelectorIncludeList = Array<RulesBulkCreateResultItemSelectorIncludeItem>;
export interface RulesBulkCreateResultItemSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesBulkCreateResultItemSelectorExcludeList | null;
    /** Select all matching operations. */
    include?: RulesBulkCreateResultItemSelectorIncludeList | null;
}
export interface RulesBulkCreateResultItem {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesBulkCreateResultItemAction;
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesBulkCreateResultItemSelector;
    /** A human-readable name for the rule. */
    title: string;
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    lastUpdated?: string | null;
}
export type RulesBulkCreateResultList = Array<RulesBulkCreateResultItem>;
export interface BulkCreateRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesBulkCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type RulesBulkEditRequestBodyItemAction = "log" | "block";
export interface RulesBulkEditRequestBodyItemPositionAPIShieldIndex {
    /** Move rule to this position */
    index: number;
}
export interface RulesBulkEditRequestBodyItemPositionAPIShieldBefore {
    /** Move rule to before rule with this ID. */
    before?: string;
}
export interface RulesBulkEditRequestBodyItemPositionAPIShieldAfter {
    /** Move rule to after rule with this ID. */
    after?: string;
}
export type RulesBulkEditRequestBodyItemPosition = RulesBulkEditRequestBodyItemPositionAPIShieldIndex | RulesBulkEditRequestBodyItemPositionAPIShieldBefore | RulesBulkEditRequestBodyItemPositionAPIShieldAfter;
export type RulesBulkEditRequestBodyItemSelectorExcludeItemOperationIdsList = Array<string>;
export interface RulesBulkEditRequestBodyItemSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesBulkEditRequestBodyItemSelectorExcludeItemOperationIdsList;
}
export type RulesBulkEditRequestBodyItemSelectorExcludeList = Array<RulesBulkEditRequestBodyItemSelectorExcludeItem>;
export type RulesBulkEditRequestBodyItemSelectorIncludeItemHostList = Array<string>;
export interface RulesBulkEditRequestBodyItemSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesBulkEditRequestBodyItemSelectorIncludeItemHostList;
}
export type RulesBulkEditRequestBodyItemSelectorIncludeList = Array<RulesBulkEditRequestBodyItemSelectorIncludeItem>;
export interface RulesBulkEditRequestBodyItemSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesBulkEditRequestBodyItemSelectorExcludeList;
    /** Select all matching operations. */
    include?: RulesBulkEditRequestBodyItemSelectorIncludeList;
}
export interface RulesBulkEditRequestBodyItem {
    /** Rule ID this patch applies to */
    id: string;
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action?: RulesBulkEditRequestBodyItemAction | (string & {});
    /** A human-readable description that gives more details than `title`. */
    description?: string;
    /** Toggle rule on or off. */
    enabled?: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression?: string;
    /** Update rule order among zone rules. */
    position?: RulesBulkEditRequestBodyItemPosition;
    /** Select operations covered by this rule. */
    selector?: RulesBulkEditRequestBodyItemSelector;
    /** A human-readable name for the rule. */
    title?: string;
}
export type RulesBulkEditRequestBodyList = Array<RulesBulkEditRequestBodyItem>;
export interface BulkPatchRulesRequest {
    /** Identifier. */
    zoneId: string;
    body: RulesBulkEditRequestBodyList;
}
export type RulesBulkEditResultItemAction = "log" | "block";
export type RulesBulkEditResultItemSelectorExcludeItemOperationIdsList = Array<string>;
export interface RulesBulkEditResultItemSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesBulkEditResultItemSelectorExcludeItemOperationIdsList | null;
}
export type RulesBulkEditResultItemSelectorExcludeList = Array<RulesBulkEditResultItemSelectorExcludeItem>;
export type RulesBulkEditResultItemSelectorIncludeItemHostList = Array<string>;
export interface RulesBulkEditResultItemSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesBulkEditResultItemSelectorIncludeItemHostList | null;
}
export type RulesBulkEditResultItemSelectorIncludeList = Array<RulesBulkEditResultItemSelectorIncludeItem>;
export interface RulesBulkEditResultItemSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesBulkEditResultItemSelectorExcludeList | null;
    /** Select all matching operations. */
    include?: RulesBulkEditResultItemSelectorIncludeList | null;
}
export interface RulesBulkEditResultItem {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesBulkEditResultItemAction;
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesBulkEditResultItemSelector;
    /** A human-readable name for the rule. */
    title: string;
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    lastUpdated?: string | null;
}
export type RulesBulkEditResultList = Array<RulesBulkEditResultItem>;
export interface BulkPatchRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesBulkEditResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export interface ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg | (string & {});
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export interface ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export interface ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyOctRequestAlg = "HS256" | "HS384" | "HS512";
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyOctRequestKty = "oct";
export interface ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyOctRequest {
    /** Algorithm */
    alg: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyOctRequestAlg | (string & {});
    /** Symmetric key material. Required for create and PUT update requests. */
    k: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyOctRequestKty;
}
export type ConfigurationCreateRequestCredentialsKeysItem = ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA | ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 | ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384 | ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyOctRequest;
export type ConfigurationCreateRequestCredentialsKeysList = Array<ConfigurationCreateRequestCredentialsKeysItem>;
export interface ConfigurationCreateRequestCredentials {
    keys: ConfigurationCreateRequestCredentialsKeysList;
}
export type ConfigurationCreateRequestTokenSourcesList = Array<string>;
export type ConfigurationCreateRequestTokenType = "JWT";
export interface CreateConfigurationRequest {
    /** Identifier. */
    zoneId: string;
    /** Request payload for create and PUT credentials operations. Provided keys define the complete stored key set. Key identities (`{alg,kid}`) must be unique. */
    credentials: ConfigurationCreateRequestCredentials;
    description: string;
    title: string;
    tokenSources: ConfigurationCreateRequestTokenSourcesList;
    tokenType: ConfigurationCreateRequestTokenType | (string & {});
}
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export interface ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg;
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export interface ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export interface ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponseAlg = "HS256" | "HS384" | "HS512";
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponseKty = "oct";
export interface ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponse {
    /** Algorithm */
    alg: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponseAlg;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponseKty;
}
export type ConfigurationCreateResponseCredentialsKeysItem = ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA | ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 | ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384 | ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponse;
export type ConfigurationCreateResponseCredentialsKeysList = Array<ConfigurationCreateResponseCredentialsKeysItem>;
export interface ConfigurationCreateResponseCredentials {
    keys: ConfigurationCreateResponseCredentialsKeysList;
}
export type ConfigurationCreateResponseTokenSourcesList = Array<string>;
export type ConfigurationCreateResponseTokenType = "JWT";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateConfigurationResponse {
    /** UUID. */
    id: string;
    createdAt: string;
    credentials: ConfigurationCreateResponseCredentials;
    description: string;
    lastUpdated: string;
    title: string;
    tokenSources: ConfigurationCreateResponseTokenSourcesList;
    tokenType: ConfigurationCreateResponseTokenType;
}
export type RulesCreateRequestAction = "log" | "block";
export type RulesCreateRequestSelectorExcludeItemOperationIdsList = Array<string>;
export interface RulesCreateRequestSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesCreateRequestSelectorExcludeItemOperationIdsList;
}
export type RulesCreateRequestSelectorExcludeList = Array<RulesCreateRequestSelectorExcludeItem>;
export type RulesCreateRequestSelectorIncludeItemHostList = Array<string>;
export interface RulesCreateRequestSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesCreateRequestSelectorIncludeItemHostList;
}
export type RulesCreateRequestSelectorIncludeList = Array<RulesCreateRequestSelectorIncludeItem>;
export interface RulesCreateRequestSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesCreateRequestSelectorExcludeList;
    /** Select all matching operations. */
    include?: RulesCreateRequestSelectorIncludeList;
}
export interface CreateRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesCreateRequestAction | (string & {});
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesCreateRequestSelector;
    /** A human-readable name for the rule. */
    title: string;
}
export type RulesCreateResponseAction = "log" | "block";
export type RulesCreateResponseSelectorExcludeItemOperationIdsList = Array<string>;
export interface RulesCreateResponseSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesCreateResponseSelectorExcludeItemOperationIdsList | null;
}
export type RulesCreateResponseSelectorExcludeList = Array<RulesCreateResponseSelectorExcludeItem>;
export type RulesCreateResponseSelectorIncludeItemHostList = Array<string>;
export interface RulesCreateResponseSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesCreateResponseSelectorIncludeItemHostList | null;
}
export type RulesCreateResponseSelectorIncludeList = Array<RulesCreateResponseSelectorIncludeItem>;
export interface RulesCreateResponseSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesCreateResponseSelectorExcludeList | null;
    /** Select all matching operations. */
    include?: RulesCreateResponseSelectorIncludeList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRuleResponse {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesCreateResponseAction;
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesCreateResponseSelector;
    /** A human-readable name for the rule. */
    title: string;
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    lastUpdated?: string | null;
}
export interface DeleteConfigurationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    configId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteConfigurationResponse {
    /** UUID. */
    id?: string | null;
}
export interface DeleteRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    ruleId: string;
}
export type DeleteRuleResponse = unknown;
export type EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export type EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export interface EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyRSAAlg | (string & {});
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export type EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export type EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export type EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export interface EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export type EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export type EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export interface EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyOctPatchRequestAlg = "HS256" | "HS384" | "HS512";
export type EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyOctPatchRequestKty = "oct";
export interface EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyOctPatchRequest {
    /** Algorithm */
    alg: EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyOctPatchRequestAlg | (string & {});
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyOctPatchRequestKty;
    /** Symmetric key material. Optional for PATCH: omit to preserve existing secret for matching `{alg,kid}`; send a string to rotate. `k: null` is invalid. */
    k?: string;
}
export type EditConfigurationCredentialsRequestKeysItem = EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyRSA | EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256 | EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384 | EditConfigurationCredentialsRequestKeysItemAPIShieldCredentialsJWTKeyOctPatchRequest;
export type EditConfigurationCredentialsRequestKeysList = Array<EditConfigurationCredentialsRequestKeysItem>;
export interface EditConfigurationCredentialsRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    configId: string;
    keys: EditConfigurationCredentialsRequestKeysList;
}
export type EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export type EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export interface EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyRSAAlg;
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export type EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export type EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export type EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export interface EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export type EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export type EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export interface EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyOctResponseAlg = "HS256" | "HS384" | "HS512";
export type EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyOctResponseKty = "oct";
export interface EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyOctResponse {
    /** Algorithm */
    alg: EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyOctResponseAlg;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyOctResponseKty;
}
export type EditConfigurationCredentialsResponseKeysItem = EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyRSA | EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256 | EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384 | EditConfigurationCredentialsResponseKeysItemAPIShieldCredentialsJWTKeyOctResponse;
export type EditConfigurationCredentialsResponseKeysList = Array<EditConfigurationCredentialsResponseKeysItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditConfigurationCredentialsResponse {
    keys: EditConfigurationCredentialsResponseKeysList;
}
export interface GetConfigurationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    configId: string;
}
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export interface ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg;
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export interface ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export interface ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponseAlg = "HS256" | "HS384" | "HS512";
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponseKty = "oct";
export interface ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponse {
    /** Algorithm */
    alg: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponseAlg;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponseKty;
}
export type ConfigurationGetResponseCredentialsKeysItem = ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA | ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 | ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384 | ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponse;
export type ConfigurationGetResponseCredentialsKeysList = Array<ConfigurationGetResponseCredentialsKeysItem>;
export interface ConfigurationGetResponseCredentials {
    keys: ConfigurationGetResponseCredentialsKeysList;
}
export type ConfigurationGetResponseTokenSourcesList = Array<string>;
export type ConfigurationGetResponseTokenType = "JWT";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigurationResponse {
    /** UUID. */
    id: string;
    createdAt: string;
    credentials: ConfigurationGetResponseCredentials;
    description: string;
    lastUpdated: string;
    title: string;
    tokenSources: ConfigurationGetResponseTokenSourcesList;
    tokenType: ConfigurationGetResponseTokenType;
}
export interface GetRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    ruleId: string;
}
export type RulesGetResponseAction = "log" | "block";
export type RulesGetResponseSelectorExcludeItemOperationIdsList = Array<string>;
export interface RulesGetResponseSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesGetResponseSelectorExcludeItemOperationIdsList | null;
}
export type RulesGetResponseSelectorExcludeList = Array<RulesGetResponseSelectorExcludeItem>;
export type RulesGetResponseSelectorIncludeItemHostList = Array<string>;
export interface RulesGetResponseSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesGetResponseSelectorIncludeItemHostList | null;
}
export type RulesGetResponseSelectorIncludeList = Array<RulesGetResponseSelectorIncludeItem>;
export interface RulesGetResponseSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesGetResponseSelectorExcludeList | null;
    /** Select all matching operations. */
    include?: RulesGetResponseSelectorIncludeList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRuleResponse {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesGetResponseAction;
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesGetResponseSelector;
    /** A human-readable name for the rule. */
    title: string;
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    lastUpdated?: string | null;
}
export interface ListConfigurationsRequest {
    /** Identifier. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export interface ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg;
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export interface ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export interface ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponseAlg = "HS256" | "HS384" | "HS512";
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponseKty = "oct";
export interface ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponse {
    /** Algorithm */
    alg: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponseAlg;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponseKty;
}
export type ConfigurationListResultItemCredentialsKeysItem = ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA | ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 | ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384 | ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyOctResponse;
export type ConfigurationListResultItemCredentialsKeysList = Array<ConfigurationListResultItemCredentialsKeysItem>;
export interface ConfigurationListResultItemCredentials {
    keys: ConfigurationListResultItemCredentialsKeysList;
}
export type ConfigurationListResultItemTokenSourcesList = Array<string>;
export type ConfigurationListResultItemTokenType = "JWT";
export interface ConfigurationListResultItem {
    /** UUID. */
    id: string;
    createdAt: string;
    credentials: ConfigurationListResultItemCredentials;
    description: string;
    lastUpdated: string;
    title: string;
    tokenSources: ConfigurationListResultItemTokenSourcesList;
    tokenType: ConfigurationListResultItemTokenType;
}
export type ConfigurationListResultList = Array<ConfigurationListResultItem>;
export interface ListConfigurationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ConfigurationListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type RulesListRequestAction = "log" | "block";
export type RulesListRequestTokenConfigurationList = Array<string>;
export interface ListRulesRequest {
    /** Identifier. */
    zoneId: string;
    /** Select rules with these IDs. */
    id?: string;
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action?: RulesListRequestAction | (string & {});
    /** Toggle rule on or off. */
    enabled?: boolean;
    /** Select rules with this host in `include`. */
    host?: string;
    /** Select rules with this host in `include`. */
    hostname?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** Select rules with these IDs. */
    ruleId?: string;
    /** Select rules using any of these token configurations. */
    tokenConfiguration?: RulesListRequestTokenConfigurationList;
}
export type RulesListResultItemAction = "log" | "block";
export type RulesListResultItemSelectorExcludeItemOperationIdsList = Array<string>;
export interface RulesListResultItemSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesListResultItemSelectorExcludeItemOperationIdsList | null;
}
export type RulesListResultItemSelectorExcludeList = Array<RulesListResultItemSelectorExcludeItem>;
export type RulesListResultItemSelectorIncludeItemHostList = Array<string>;
export interface RulesListResultItemSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesListResultItemSelectorIncludeItemHostList | null;
}
export type RulesListResultItemSelectorIncludeList = Array<RulesListResultItemSelectorIncludeItem>;
export interface RulesListResultItemSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesListResultItemSelectorExcludeList | null;
    /** Select all matching operations. */
    include?: RulesListResultItemSelectorIncludeList | null;
}
export interface RulesListResultItem {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesListResultItemAction;
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesListResultItemSelector;
    /** A human-readable name for the rule. */
    title: string;
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    lastUpdated?: string | null;
}
export type RulesListResultList = Array<RulesListResultItem>;
export interface ListRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ConfigurationEditRequestTokenSourcesList = Array<string>;
export interface PatchConfigurationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    configId: string;
    description?: string;
    title?: string;
    tokenSources?: ConfigurationEditRequestTokenSourcesList;
}
export type ConfigurationEditResponseTokenSourcesList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchConfigurationResponse {
    /** UUID. */
    id?: string | null;
    description?: string | null;
    title?: string | null;
    tokenSources?: ConfigurationEditResponseTokenSourcesList | null;
}
export type RulesEditRequestAction = "log" | "block";
export type RulesEditRequestPositionAPIShieldIndex = RulesBulkEditRequestBodyItemPositionAPIShieldIndex;
export type RulesEditRequestPositionAPIShieldBefore = RulesBulkEditRequestBodyItemPositionAPIShieldBefore;
export type RulesEditRequestPositionAPIShieldAfter = RulesBulkEditRequestBodyItemPositionAPIShieldAfter;
export type RulesEditRequestPosition = RulesBulkEditRequestBodyItemPositionAPIShieldIndex | RulesBulkEditRequestBodyItemPositionAPIShieldBefore | RulesBulkEditRequestBodyItemPositionAPIShieldAfter;
export type RulesEditRequestSelectorExcludeItemOperationIdsList = Array<string>;
export interface RulesEditRequestSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesEditRequestSelectorExcludeItemOperationIdsList;
}
export type RulesEditRequestSelectorExcludeList = Array<RulesEditRequestSelectorExcludeItem>;
export type RulesEditRequestSelectorIncludeItemHostList = Array<string>;
export interface RulesEditRequestSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesEditRequestSelectorIncludeItemHostList;
}
export type RulesEditRequestSelectorIncludeList = Array<RulesEditRequestSelectorIncludeItem>;
export interface RulesEditRequestSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesEditRequestSelectorExcludeList;
    /** Select all matching operations. */
    include?: RulesEditRequestSelectorIncludeList;
}
export interface PatchRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    ruleId: string;
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action?: RulesEditRequestAction | (string & {});
    /** A human-readable description that gives more details than `title`. */
    description?: string;
    /** Toggle rule on or off. */
    enabled?: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression?: string;
    /** Update rule order among zone rules. */
    position?: RulesEditRequestPosition;
    /** Select operations covered by this rule. */
    selector?: RulesEditRequestSelector;
    /** A human-readable name for the rule. */
    title?: string;
}
export type RulesEditResponseAction = "log" | "block";
export type RulesEditResponseSelectorExcludeItemOperationIdsList = Array<string>;
export interface RulesEditResponseSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesEditResponseSelectorExcludeItemOperationIdsList | null;
}
export type RulesEditResponseSelectorExcludeList = Array<RulesEditResponseSelectorExcludeItem>;
export type RulesEditResponseSelectorIncludeItemHostList = Array<string>;
export interface RulesEditResponseSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesEditResponseSelectorIncludeItemHostList | null;
}
export type RulesEditResponseSelectorIncludeList = Array<RulesEditResponseSelectorIncludeItem>;
export interface RulesEditResponseSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesEditResponseSelectorExcludeList | null;
    /** Select all matching operations. */
    include?: RulesEditResponseSelectorIncludeList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchRuleResponse {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesEditResponseAction;
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesEditResponseSelector;
    /** A human-readable name for the rule. */
    title: string;
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    lastUpdated?: string | null;
}
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export interface ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSAAlg | (string & {});
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export interface ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export interface ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyOctRequestAlg = "HS256" | "HS384" | "HS512";
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyOctRequestKty = "oct";
export interface ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyOctRequest {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyOctRequestAlg | (string & {});
    /** Symmetric key material. Required for create and PUT update requests. */
    k: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyOctRequestKty;
}
export type ConfigurationCredentialsUpdateRequestKeysItem = ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSA | ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256 | ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384 | ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyOctRequest;
export type ConfigurationCredentialsUpdateRequestKeysList = Array<ConfigurationCredentialsUpdateRequestKeysItem>;
export interface PutConfigurationCredentialRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    configId: string;
    keys: ConfigurationCredentialsUpdateRequestKeysList;
}
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export interface ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSAAlg;
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export interface ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export interface ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyOctResponseAlg = "HS256" | "HS384" | "HS512";
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyOctResponseKty = "oct";
export interface ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyOctResponse {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyOctResponseAlg;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyOctResponseKty;
}
export type ConfigurationCredentialsUpdateResponseKeysItem = ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSA | ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256 | ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384 | ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyOctResponse;
export type ConfigurationCredentialsUpdateResponseKeysList = Array<ConfigurationCredentialsUpdateResponseKeysItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutConfigurationCredentialResponse {
    keys: ConfigurationCredentialsUpdateResponseKeysList;
}
export type BulkCreateRulesError = CloudflareOpError;
/** Creates multiple token validation rules for the zone in one request. */
export declare const bulkCreateRules: API.PaginatedOperationMethod<BulkCreateRulesRequest, BulkCreateRulesResponse, BulkCreateRulesError, CloudflareOpContext, RulesBulkCreateResultItem>;
export type BulkPatchRulesError = CloudflareOpError;
/** Updates and reorders multiple token validation rules in one request, then returns the updated rules. */
export declare const bulkPatchRules: API.PaginatedOperationMethod<BulkPatchRulesRequest, BulkPatchRulesResponse, BulkPatchRulesError, CloudflareOpContext, RulesBulkEditResultItem>;
export type CreateConfigurationError = TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Creates a JWT validation configuration for the zone. */
export declare const createConfiguration: API.OperationMethod<CreateConfigurationRequest, CreateConfigurationResponse, CreateConfigurationError, CloudflareOpContext>;
export type CreateRuleError = TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Creates a token validation rule for the zone. */
export declare const createRule: API.OperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, CloudflareOpContext>;
export type DeleteConfigurationError = TokenConfigurationNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Deletes a JWT validation configuration from the zone. */
export declare const deleteConfiguration: API.OperationMethod<DeleteConfigurationRequest, DeleteConfigurationResponse, DeleteConfigurationError, CloudflareOpContext>;
export type DeleteRuleError = TokenValidationRuleNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Deletes a token validation rule from the zone. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type EditConfigurationCredentialsError = CloudflareOpError;
/** Updates the configuration's complete key set while allowing omitted fields on existing keys to retain stored values. Omitted key identities are removed. */
export declare const editConfigurationCredentials: API.OperationMethod<EditConfigurationCredentialsRequest, EditConfigurationCredentialsResponse, EditConfigurationCredentialsError, CloudflareOpContext>;
export type GetConfigurationError = TokenConfigurationNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Returns a JWT validation configuration by ID. */
export declare const getConfiguration: API.OperationMethod<GetConfigurationRequest, GetConfigurationResponse, GetConfigurationError, CloudflareOpContext>;
export type GetRuleError = TokenValidationRuleNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Returns a token validation rule by ID. */
export declare const getRule: API.OperationMethod<GetRuleRequest, GetRuleResponse, GetRuleError, CloudflareOpContext>;
export type ListConfigurationsError = TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Lists the JWT validation configurations defined for the zone. */
export declare const listConfigurations: API.PaginatedOperationMethod<ListConfigurationsRequest, ListConfigurationsResponse, ListConfigurationsError, CloudflareOpContext, ConfigurationListResultItem>;
export type ListRulesError = TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Lists token validation rules for the zone, with filters for configuration, action, state, ID, and host. */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext, RulesListResultItem>;
export type PatchConfigurationError = TokenConfigurationNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Updates only the supplied fields on a JWT validation configuration. */
export declare const patchConfiguration: API.OperationMethod<PatchConfigurationRequest, PatchConfigurationResponse, PatchConfigurationError, CloudflareOpContext>;
export type PatchRuleError = TokenValidationRuleNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Updates only the supplied fields on a token validation rule. */
export declare const patchRule: API.OperationMethod<PatchRuleRequest, PatchRuleResponse, PatchRuleError, CloudflareOpContext>;
export type PutConfigurationCredentialError = TokenConfigurationNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Replaces the configuration's complete key set. Symmetric keys must include their key material. */
export declare const putConfigurationCredential: API.OperationMethod<PutConfigurationCredentialRequest, PutConfigurationCredentialResponse, PutConfigurationCredentialError, CloudflareOpContext>;
//# sourceMappingURL=token_validation.d.ts.map