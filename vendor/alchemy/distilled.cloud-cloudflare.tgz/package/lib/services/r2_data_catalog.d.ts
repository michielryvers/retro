import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidCredential_base: S.TaggedErrorClass<"InvalidCredential", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidCredential extends /*@__PURE__*/ InvalidCredential_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const NoSuchBucket_base: S.TaggedErrorClass<"NoSuchBucket", {
    readonly code: any;
    readonly message: any;
}>;
export declare class NoSuchBucket extends /*@__PURE__*/ NoSuchBucket_base {
}
declare const TableNotFound_base: S.TaggedErrorClass<"TableNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TableNotFound extends /*@__PURE__*/ TableNotFound_base {
}
declare const WarehouseInactive_base: S.TaggedErrorClass<"WarehouseInactive", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WarehouseInactive extends /*@__PURE__*/ WarehouseInactive_base {
}
declare const WarehouseNotFound_base: S.TaggedErrorClass<"WarehouseNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class WarehouseNotFound extends /*@__PURE__*/ WarehouseNotFound_base {
}
export interface CreateCredentialRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    /** Provides the Cloudflare API token for accessing R2. */
    token: string;
}
export type CreateCredentialResponse = unknown;
export interface DeleteRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    /** Remove child metadata before deleting the catalog. */
    force?: boolean;
}
export interface DeleteResponse {
}
export interface DisableR2DataCatalogRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
}
export interface DisableR2DataCatalogResponse {
}
export interface EnableR2DataCatalogRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EnableR2DataCatalogResponse {
    /** Use this to uniquely identify the activated catalog. */
    id: string;
    /** Specifies the name of the activated catalog. */
    name: string;
}
export interface GetMaintenanceConfigRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
}
export type MaintenanceConfigsGetResponseCredentialStatus = "present" | "absent";
export type MaintenanceConfigsGetResponseMaintenanceConfigCompactionState = "enabled" | "disabled";
export type MaintenanceConfigsGetResponseMaintenanceConfigCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface MaintenanceConfigsGetResponseMaintenanceConfigCompaction {
    /** Specifies the state of maintenance operations. */
    state: MaintenanceConfigsGetResponseMaintenanceConfigCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: MaintenanceConfigsGetResponseMaintenanceConfigCompactionTargetSizeMb;
}
export type MaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpirationState = "enabled" | "disabled";
export interface MaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. Format: where unit is d (days), h (hours), m (minutes), or s (seconds). Examples: "7d" (7 days), "48h" (48 hours), "2880m" (2,880 minutes). Defaults to "7d". */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: MaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpirationState;
}
export interface MaintenanceConfigsGetResponseMaintenanceConfig {
    /** Configures compaction for catalog maintenance. */
    compaction?: MaintenanceConfigsGetResponseMaintenanceConfigCompaction | null;
    /** Scheduling interval between normal table maintenance runs. */
    interval?: string | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: MaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpiration | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMaintenanceConfigResponse {
    /** Shows the credential configuration status. */
    credentialStatus: MaintenanceConfigsGetResponseCredentialStatus;
    /** Configures maintenance for the catalog. */
    maintenanceConfig: MaintenanceConfigsGetResponseMaintenanceConfig;
}
export interface GetNamespaceTableMaintenanceConfigRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    namespace: string;
    tableName: string;
}
export type NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompactionState = "enabled" | "disabled";
export type NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompaction {
    /** Specifies the state of maintenance operations. */
    state: NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompactionTargetSizeMb;
    /** Earliest time when the scheduler can claim this operation. Null when disabled. */
    nextEligibleAt?: string | null;
}
export type NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpirationState = "enabled" | "disabled";
export interface NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpiration {
    /** Specifies the maximum age for snapshots. */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpirationState;
    /** Earliest time when the scheduler can claim this operation. Null when disabled. */
    nextEligibleAt?: string | null;
}
export interface NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfig {
    /** Configures compaction settings for table optimization. */
    compaction?: NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompaction | null;
    /** Scheduling interval between normal table maintenance runs. */
    interval?: string | null;
    snapshotExpiration?: NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpiration | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetNamespaceTableMaintenanceConfigResponse {
    /** Configures maintenance for the table. */
    maintenanceConfig: NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfig;
}
export interface GetR2DataCatalogRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
}
export type GetResponseStatus = "active" | "inactive";
export type GetResponseCredentialStatus = "present" | "absent";
export type GetResponseMaintenanceConfigCompactionState = "enabled" | "disabled";
export type GetResponseMaintenanceConfigCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface GetResponseMaintenanceConfigCompaction {
    /** Specifies the state of maintenance operations. */
    state: GetResponseMaintenanceConfigCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: GetResponseMaintenanceConfigCompactionTargetSizeMb;
}
export type GetResponseMaintenanceConfigSnapshotExpirationState = "enabled" | "disabled";
export interface GetResponseMaintenanceConfigSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. Format: where unit is d (days), h (hours), m (minutes), or s (seconds). Examples: "7d" (7 days), "48h" (48 hours), "2880m" (2,880 minutes). Defaults to "7d". */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: GetResponseMaintenanceConfigSnapshotExpirationState;
}
export interface GetResponseMaintenanceConfig {
    /** Configures compaction for catalog maintenance. */
    compaction?: GetResponseMaintenanceConfigCompaction | null;
    /** Scheduling interval between normal table maintenance runs. */
    interval?: string | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: GetResponseMaintenanceConfigSnapshotExpiration | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetR2DataCatalogResponse {
    /** Use this to uniquely identify the catalog. */
    id: string;
    /** Specifies the associated R2 bucket name. */
    bucket: string;
    /** Specifies the catalog name (generated from account and bucket name). */
    name: string;
    /** Indicates the status of the catalog. */
    status: GetResponseStatus;
    /** Shows the credential configuration status. */
    credentialStatus?: GetResponseCredentialStatus | null;
    /** Configures maintenance for the catalog. */
    maintenanceConfig?: GetResponseMaintenanceConfig | null;
}
export interface ListNamespacesRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    /** Maximum number of namespaces to return per page. Defaults to 100, maximum 1000. */
    pageSize?: number;
    /** Opaque pagination token from a previous response. Use this to fetch the next page of results. */
    pageToken?: string;
    /** Parent namespace to filter by. Only returns direct children of this namespace. For nested namespaces, use %1F as separator (e.g., "bronze%1Fanalytics"). Omit this parameter to list top-level namespaces. */
    parent?: string;
    /** Whether to include additional metadata (timestamps). When true, response includes created_at and updated_at arrays. */
    returnDetails?: boolean;
    /** Whether to include namespace UUIDs in the response. Set to true to receive the namespace_uuids array. */
    returnUuids?: boolean;
}
export type NamespacesListResponseNamespacesItemList = Array<string>;
export type NamespacesListResponseNamespacesList = Array<NamespacesListResponseNamespacesItemList>;
export type NamespacesListResponseDetailsItemNamespaceList = Array<string>;
export interface NamespacesListResponseDetailsItem {
    /** Specifies the hierarchical namespace parts as an array of strings. For example, ["bronze", "analytics"] represents the namespace "bronze.analytics". */
    namespace: NamespacesListResponseDetailsItemNamespaceList;
    /** Contains the UUID that persists across renames. */
    namespaceUuid: string;
    /** Indicates the creation timestamp in ISO 8601 format. */
    createdAt?: string | null;
    /** Shows the last update timestamp in ISO 8601 format. Null if never updated. */
    updatedAt?: string | null;
}
export type NamespacesListResponseDetailsList = Array<NamespacesListResponseDetailsItem>;
export type NamespacesListResponseNamespaceUuidsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListNamespacesResponse {
    /** Lists namespaces in the catalog. */
    namespaces: NamespacesListResponseNamespacesList;
    /** Contains detailed metadata for each namespace when return_details is true. Each object includes the namespace, UUID, and timestamps. */
    details?: NamespacesListResponseDetailsList | null;
    /** Contains UUIDs for each namespace when return_uuids is true. The order corresponds to the namespaces array. */
    namespaceUuids?: NamespacesListResponseNamespaceUuidsList | null;
    /** Use this opaque token to fetch the next page of results. A null or absent value indicates the last page. */
    nextPageToken?: string | null;
}
export interface ListNamespaceTablesRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    namespace: string;
    /** Maximum number of tables to return per page. Defaults to 100, maximum 1000. */
    pageSize?: number;
    /** Opaque pagination token from a previous response. Use this to fetch the next page of results. */
    pageToken?: string;
    /** Whether to include additional metadata (timestamps, locations). When true, response includes created_at, updated_at, metadata_locations, and locations arrays. */
    returnDetails?: boolean;
    /** Whether to include table UUIDs in the response. Set to true to receive the table_uuids array. */
    returnUuids?: boolean;
}
export type NamespacesTablesListResponseIdentifiersItemNamespaceList = Array<string>;
export interface NamespacesTablesListResponseIdentifiersItem {
    /** Specifies the table name. */
    name: string;
    /** Specifies the hierarchical namespace parts as an array of strings. For example, ["bronze", "analytics"] represents the namespace "bronze.analytics". */
    namespace: NamespacesTablesListResponseIdentifiersItemNamespaceList;
}
export type NamespacesTablesListResponseIdentifiersList = Array<NamespacesTablesListResponseIdentifiersItem>;
export type NamespacesTablesListResponseDetailsItemIdentifierNamespaceList = Array<string>;
export interface NamespacesTablesListResponseDetailsItemIdentifier {
    /** Specifies the table name. */
    name: string;
    /** Specifies the hierarchical namespace parts as an array of strings. For example, ["bronze", "analytics"] represents the namespace "bronze.analytics". */
    namespace: NamespacesTablesListResponseDetailsItemIdentifierNamespaceList;
}
export interface NamespacesTablesListResponseDetailsItem {
    /** Specifies a unique table identifier within a catalog. */
    identifier: NamespacesTablesListResponseDetailsItemIdentifier;
    /** Contains the UUID that persists across renames. */
    tableUuid: string;
    /** Indicates the creation timestamp in ISO 8601 format. */
    createdAt?: string | null;
    /** Specifies the base S3 URI for table storage location. */
    location?: string | null;
    /** Contains the S3 URI to table metadata file. Null for staged tables. */
    metadataLocation?: string | null;
    /** Shows the last update timestamp in ISO 8601 format. Null if never updated. */
    updatedAt?: string | null;
}
export type NamespacesTablesListResponseDetailsList = Array<NamespacesTablesListResponseDetailsItem>;
export type NamespacesTablesListResponseTableUuidsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListNamespaceTablesResponse {
    /** Lists tables in the namespace. */
    identifiers: NamespacesTablesListResponseIdentifiersList;
    /** Contains detailed metadata for each table when return_details is true. Each object includes identifier, UUID, timestamps, and locations. */
    details?: NamespacesTablesListResponseDetailsList | null;
    /** Use this opaque token to fetch the next page of results. A null or absent value indicates the last page. */
    nextPageToken?: string | null;
    /** Contains UUIDs for each table when return_uuids is true. The order corresponds to the identifiers array. */
    tableUuids?: NamespacesTablesListResponseTableUuidsList | null;
}
export interface ListR2DataCatalogsRequest {
    /** Use this to identify the account. */
    accountId: string;
}
export type ListResponseWarehousesItemStatus = "active" | "inactive";
export type ListResponseWarehousesItemCredentialStatus = "present" | "absent";
export type ListResponseWarehousesItemMaintenanceConfigCompactionState = "enabled" | "disabled";
export type ListResponseWarehousesItemMaintenanceConfigCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface ListResponseWarehousesItemMaintenanceConfigCompaction {
    /** Specifies the state of maintenance operations. */
    state: ListResponseWarehousesItemMaintenanceConfigCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: ListResponseWarehousesItemMaintenanceConfigCompactionTargetSizeMb;
}
export type ListResponseWarehousesItemMaintenanceConfigSnapshotExpirationState = "enabled" | "disabled";
export interface ListResponseWarehousesItemMaintenanceConfigSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. Format: where unit is d (days), h (hours), m (minutes), or s (seconds). Examples: "7d" (7 days), "48h" (48 hours), "2880m" (2,880 minutes). Defaults to "7d". */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: ListResponseWarehousesItemMaintenanceConfigSnapshotExpirationState;
}
export interface ListResponseWarehousesItemMaintenanceConfig {
    /** Configures compaction for catalog maintenance. */
    compaction?: ListResponseWarehousesItemMaintenanceConfigCompaction | null;
    /** Scheduling interval between normal table maintenance runs. */
    interval?: string | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: ListResponseWarehousesItemMaintenanceConfigSnapshotExpiration | null;
}
export interface ListResponseWarehousesItem {
    /** Use this to uniquely identify the catalog. */
    id: string;
    /** Specifies the associated R2 bucket name. */
    bucket: string;
    /** Specifies the catalog name (generated from account and bucket name). */
    name: string;
    /** Indicates the status of the catalog. */
    status: ListResponseWarehousesItemStatus;
    /** Shows the credential configuration status. */
    credentialStatus?: ListResponseWarehousesItemCredentialStatus | null;
    /** Configures maintenance for the catalog. */
    maintenanceConfig?: ListResponseWarehousesItemMaintenanceConfig | null;
}
export type ListResponseWarehousesList = Array<ListResponseWarehousesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListR2DataCatalogsResponse {
    /** Lists catalogs in the account. */
    warehouses: ListResponseWarehousesList;
}
export type MaintenanceConfigsUpdateRequestCompactionState = "enabled" | "disabled";
export type MaintenanceConfigsUpdateRequestCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface MaintenanceConfigsUpdateRequestCompaction {
    /** Specifies the state of maintenance operations. */
    state?: MaintenanceConfigsUpdateRequestCompactionState | (string & {});
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb?: MaintenanceConfigsUpdateRequestCompactionTargetSizeMb | (string & {});
}
export type MaintenanceConfigsUpdateRequestSnapshotExpirationState = "enabled" | "disabled";
export interface MaintenanceConfigsUpdateRequestSnapshotExpiration {
    /** Updates the maximum age for snapshots optionally. */
    maxSnapshotAge?: string;
    /** Updates the minimum number of snapshots to retain optionally. */
    minSnapshotsToKeep?: number;
    /** Specifies the state of maintenance operations. */
    state?: MaintenanceConfigsUpdateRequestSnapshotExpirationState | (string & {});
}
export interface UpdateMaintenanceConfigRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    /** Updates compaction configuration (all fields optional). */
    compaction?: MaintenanceConfigsUpdateRequestCompaction;
    /** Updates snapshot expiration configuration (all fields optional). */
    snapshotExpiration?: MaintenanceConfigsUpdateRequestSnapshotExpiration;
}
export type MaintenanceConfigsUpdateResponseCompactionState = "enabled" | "disabled";
export type MaintenanceConfigsUpdateResponseCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface MaintenanceConfigsUpdateResponseCompaction {
    /** Specifies the state of maintenance operations. */
    state: MaintenanceConfigsUpdateResponseCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: MaintenanceConfigsUpdateResponseCompactionTargetSizeMb;
}
export type MaintenanceConfigsUpdateResponseSnapshotExpirationState = "enabled" | "disabled";
export interface MaintenanceConfigsUpdateResponseSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. Format: where unit is d (days), h (hours), m (minutes), or s (seconds). Examples: "7d" (7 days), "48h" (48 hours), "2880m" (2,880 minutes). Defaults to "7d". */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: MaintenanceConfigsUpdateResponseSnapshotExpirationState;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateMaintenanceConfigResponse {
    /** Configures compaction for catalog maintenance. */
    compaction?: MaintenanceConfigsUpdateResponseCompaction | null;
    /** Scheduling interval between normal table maintenance runs. */
    interval?: string | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: MaintenanceConfigsUpdateResponseSnapshotExpiration | null;
}
export type NamespacesTablesMaintenanceConfigsUpdateRequestCompactionState = "enabled" | "disabled";
export type NamespacesTablesMaintenanceConfigsUpdateRequestCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface NamespacesTablesMaintenanceConfigsUpdateRequestCompaction {
    /** Specifies the state of maintenance operations. */
    state?: NamespacesTablesMaintenanceConfigsUpdateRequestCompactionState | (string & {});
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb?: NamespacesTablesMaintenanceConfigsUpdateRequestCompactionTargetSizeMb | (string & {});
}
export type NamespacesTablesMaintenanceConfigsUpdateRequestSnapshotExpirationState = "enabled" | "disabled";
export interface NamespacesTablesMaintenanceConfigsUpdateRequestSnapshotExpiration {
    /** Updates the maximum age for snapshots optionally. */
    maxSnapshotAge?: string;
    /** Updates the minimum number of snapshots to retain optionally. */
    minSnapshotsToKeep?: number;
    /** Specifies the state of maintenance operations. */
    state?: NamespacesTablesMaintenanceConfigsUpdateRequestSnapshotExpirationState | (string & {});
}
export interface UpdateNamespaceTableMaintenanceConfigRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    namespace: string;
    tableName: string;
    /** Updates table compaction configuration; all fields are optional. */
    compaction?: NamespacesTablesMaintenanceConfigsUpdateRequestCompaction;
    /** Updates snapshot expiration configuration (all fields optional). */
    snapshotExpiration?: NamespacesTablesMaintenanceConfigsUpdateRequestSnapshotExpiration;
}
export type NamespacesTablesMaintenanceConfigsUpdateResponseCompactionState = "enabled" | "disabled";
export type NamespacesTablesMaintenanceConfigsUpdateResponseCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export interface NamespacesTablesMaintenanceConfigsUpdateResponseCompaction {
    /** Specifies the state of maintenance operations. */
    state: NamespacesTablesMaintenanceConfigsUpdateResponseCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: NamespacesTablesMaintenanceConfigsUpdateResponseCompactionTargetSizeMb;
    /** Earliest time when the scheduler can claim this operation. Null when disabled. */
    nextEligibleAt?: string | null;
}
export type NamespacesTablesMaintenanceConfigsUpdateResponseSnapshotExpirationState = "enabled" | "disabled";
export interface NamespacesTablesMaintenanceConfigsUpdateResponseSnapshotExpiration {
    /** Specifies the maximum age for snapshots. */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: NamespacesTablesMaintenanceConfigsUpdateResponseSnapshotExpirationState;
    /** Earliest time when the scheduler can claim this operation. Null when disabled. */
    nextEligibleAt?: string | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateNamespaceTableMaintenanceConfigResponse {
    /** Configures compaction settings for table optimization. */
    compaction?: NamespacesTablesMaintenanceConfigsUpdateResponseCompaction | null;
    /** Scheduling interval between normal table maintenance runs. */
    interval?: string | null;
    snapshotExpiration?: NamespacesTablesMaintenanceConfigsUpdateResponseSnapshotExpiration | null;
}
export type CreateCredentialError = InvalidRoute | InvalidCredential | CloudflareOpError;
/** Store authentication credentials for a catalog. These credentials are used to authenticate with R2 storage when performing catalog operations. */
export declare const createCredential: API.OperationMethod<CreateCredentialRequest, CreateCredentialResponse, CreateCredentialError, CloudflareOpContext>;
export type DeleteError = CloudflareOpError;
/** Removes the catalog from the control plane without deleting R2 bucket objects. Set force=true to remove catalog namespaces, tables, views, and maintenance metadata. Force deletion is limited to a configured catalog object count. */
export declare const Delete: API.OperationMethod<DeleteRequest, DeleteResponse, DeleteError, CloudflareOpContext>;
export type DisableR2DataCatalogError = NoSuchBucket | InvalidRoute | WarehouseNotFound | Forbidden | CloudflareOpError;
/** Disable an R2 bucket as a catalog. This operation deactivates the catalog but preserves existing metadata and data files. The catalog can be re-enabled later. */
export declare const disableR2DataCatalog: API.OperationMethod<DisableR2DataCatalogRequest, DisableR2DataCatalogResponse, DisableR2DataCatalogError, CloudflareOpContext>;
export type EnableR2DataCatalogError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Enable an R2 bucket as an Apache Iceberg catalog. This operation creates the necessary catalog infrastructure and activates the bucket for storing Iceberg metadata and data files. */
export declare const enableR2DataCatalog: API.OperationMethod<EnableR2DataCatalogRequest, EnableR2DataCatalogResponse, EnableR2DataCatalogError, CloudflareOpContext>;
export type GetMaintenanceConfigError = InvalidRoute | WarehouseInactive | WarehouseNotFound | CloudflareOpError;
/** Retrieve the maintenance configuration for a specific catalog, including compaction settings and credential status. */
export declare const getMaintenanceConfig: API.OperationMethod<GetMaintenanceConfigRequest, GetMaintenanceConfigResponse, GetMaintenanceConfigError, CloudflareOpContext>;
export type GetNamespaceTableMaintenanceConfigError = TableNotFound | InvalidRoute | WarehouseInactive | CloudflareOpError;
/** Retrieve the maintenance configuration for a specific table, including compaction settings. */
export declare const getNamespaceTableMaintenanceConfig: API.OperationMethod<GetNamespaceTableMaintenanceConfigRequest, GetNamespaceTableMaintenanceConfigResponse, GetNamespaceTableMaintenanceConfigError, CloudflareOpContext>;
export type GetR2DataCatalogError = NoSuchBucket | InvalidRoute | WarehouseNotFound | Forbidden | CloudflareOpError;
/** Retrieve detailed information about a specific R2 catalog by bucket name. Returns catalog status, maintenance configuration, and credential status. */
export declare const getR2DataCatalog: API.OperationMethod<GetR2DataCatalogRequest, GetR2DataCatalogResponse, GetR2DataCatalogError, CloudflareOpContext>;
export type ListNamespacesError = InvalidRoute | WarehouseInactive | WarehouseNotFound | CloudflareOpError;
/** Returns a list of namespaces in the specified R2 catalog. Supports hierarchical filtering and pagination for efficient traversal of large namespace hierarchies. */
export declare const listNamespaces: API.OperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, CloudflareOpContext>;
export type ListNamespaceTablesError = InvalidRoute | WarehouseInactive | CloudflareOpError;
/** Returns a list of tables in the specified namespace within an R2 catalog. Supports pagination for efficient traversal of large table collections. */
export declare const listNamespaceTables: API.OperationMethod<ListNamespaceTablesRequest, ListNamespaceTablesResponse, ListNamespaceTablesError, CloudflareOpContext>;
export type ListR2DataCatalogsError = InvalidRoute | CloudflareOpError;
/** Returns a list of R2 buckets that have been enabled as Apache Iceberg catalogs for the specified account. Each catalog represents an R2 bucket configured to store Iceberg metadata and data files. */
export declare const listR2DataCatalogs: API.OperationMethod<ListR2DataCatalogsRequest, ListR2DataCatalogsResponse, ListR2DataCatalogsError, CloudflareOpContext>;
export type UpdateMaintenanceConfigError = InvalidRoute | WarehouseInactive | CloudflareOpError;
/** Update the maintenance configuration for a catalog. This allows you to enable or disable compaction and adjust target file sizes for optimization. */
export declare const updateMaintenanceConfig: API.OperationMethod<UpdateMaintenanceConfigRequest, UpdateMaintenanceConfigResponse, UpdateMaintenanceConfigError, CloudflareOpContext>;
export type UpdateNamespaceTableMaintenanceConfigError = TableNotFound | InvalidRoute | WarehouseInactive | CloudflareOpError;
/** Update the maintenance configuration for a specific table. This allows you to enable or disable compaction and adjust target file sizes for optimization. */
export declare const updateNamespaceTableMaintenanceConfig: API.OperationMethod<UpdateNamespaceTableMaintenanceConfigRequest, UpdateNamespaceTableMaintenanceConfigResponse, UpdateNamespaceTableMaintenanceConfigError, CloudflareOpContext>;
//# sourceMappingURL=r2_data_catalog.d.ts.map