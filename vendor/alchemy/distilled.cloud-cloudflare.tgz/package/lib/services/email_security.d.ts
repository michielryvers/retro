import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AllowPolicyNotFound_base: S.TaggedErrorClass<"AllowPolicyNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class AllowPolicyNotFound extends /*@__PURE__*/ AllowPolicyNotFound_base {
}
declare const BlockSenderNotFound_base: S.TaggedErrorClass<"BlockSenderNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class BlockSenderNotFound extends /*@__PURE__*/ BlockSenderNotFound_base {
}
declare const EmailSecurityDomainNotFound_base: S.TaggedErrorClass<"EmailSecurityDomainNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class EmailSecurityDomainNotFound extends /*@__PURE__*/ EmailSecurityDomainNotFound_base {
}
declare const EmailSecurityNotEntitled_base: S.TaggedErrorClass<"EmailSecurityNotEntitled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class EmailSecurityNotEntitled extends /*@__PURE__*/ EmailSecurityNotEntitled_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const ImpersonationRegistryEntryNotFound_base: S.TaggedErrorClass<"ImpersonationRegistryEntryNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class ImpersonationRegistryEntryNotFound extends /*@__PURE__*/ ImpersonationRegistryEntryNotFound_base {
}
declare const TrustedDomainNotFound_base: S.TaggedErrorClass<"TrustedDomainNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class TrustedDomainNotFound extends /*@__PURE__*/ TrustedDomainNotFound_base {
}
export type InvestigateMoveBulkRequestDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export type InvestigateMoveBulkRequestIdsList = Array<string>;
export type InvestigateMoveBulkRequestExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type InvestigateMoveBulkRequestPostfixIdsList = Array<string>;
export interface BulkInvestigateMoveRequest {
    /** Identifier. */
    accountId: string;
    /** The mailbox folder to move messages to. */
    destination: InvestigateMoveBulkRequestDestination | (string & {});
    /** List of message IDs to move. */
    ids: InvestigateMoveBulkRequestIdsList;
    /** This field is nonfunctional. */
    expectedDisposition?: InvestigateMoveBulkRequestExpectedDisposition | (string & {});
    /** Use `ids` instead. */
    postfixIds?: InvestigateMoveBulkRequestPostfixIdsList;
}
export interface InvestigateMoveBulkResultItem {
    /** Whether the operation succeeded. */
    success: boolean;
    /** When the move operation completed (UTC). */
    completedAt?: string | null;
    /** Use `completed_at` instead. */
    completedTimestamp?: string | null;
    /** Destination folder for the message. */
    destination?: string | null;
    /** This field is deprecated. */
    itemCount?: number | null;
    /** Message identifier. */
    messageId?: string | null;
    /** Type of operation performed. */
    operation?: string | null;
    /** Recipient email address. */
    recipient?: string | null;
    /** Operation status. */
    status?: string | null;
}
export type InvestigateMoveBulkResultList = Array<InvestigateMoveBulkResultItem>;
export interface BulkInvestigateMoveResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvestigateMoveBulkResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type InvestigateReleaseBulkRequestIdsList = Array<string>;
export interface BulkInvestigateReleaseRequest {
    /** Identifier. */
    accountId: string;
    /** Investigate IDs of the messages to release. */
    ids: InvestigateReleaseBulkRequestIdsList;
}
export type InvestigateReleaseBulkResultItemDeliveredList = Array<string>;
export type InvestigateReleaseBulkResultItemFailedList = Array<string>;
export type InvestigateReleaseBulkResultItemUndeliveredList = Array<string>;
export interface InvestigateReleaseBulkResultItem {
    /** Unique identifier for a message retrieved from investigation. */
    id: string;
    delivered?: InvestigateReleaseBulkResultItemDeliveredList | null;
    failed?: InvestigateReleaseBulkResultItemFailedList | null;
    /** Use `id` instead. */
    postfixId?: string | null;
    undelivered?: InvestigateReleaseBulkResultItemUndeliveredList | null;
}
export type InvestigateReleaseBulkResultList = Array<InvestigateReleaseBulkResultItem>;
export interface BulkInvestigateReleaseResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvestigateReleaseBulkResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type InvestigateBulkCreateRequestAction = "MOVE" | "RELEASE";
export type InvestigateBulkCreateRequestSearchParamsDeliveryStatus = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued" | "move_failed";
export type InvestigateBulkCreateRequestSearchParamsFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type InvestigateBulkCreateRequestSearchParamsMessageAction = "PREVIEW" | "QUARANTINE_RELEASED" | "MOVED";
export interface InvestigateBulkCreateRequestSearchParams {
    /** Use GET /investigate/{investigate_id}/action_log instead. */
    actionLog?: boolean;
    /** Alert ID of the detection to filter by. */
    alertId?: string;
    /** Delivery status to filter by. */
    deliveryStatus?: InvestigateBulkCreateRequestSearchParamsDeliveryStatus | (string & {});
    /** Whether to include only detections in search results. */
    detectionsOnly?: boolean;
    /** Match messages that mention this domain -- sender domain, recipient domain, or a domain in a link. */
    domain?: string;
    /** End of search date range. */
    end?: string;
    /** Match messages whose subject line equals this value exactly. */
    exactSubject?: string;
    /** Dispositions to filter by. */
    finalDisposition?: InvestigateBulkCreateRequestSearchParamsFinalDisposition | (string & {});
    /** Message actions to filter by. */
    messageAction?: InvestigateBulkCreateRequestSearchParamsMessageAction | (string & {});
    /** Message-ID header value to filter by. */
    messageId?: string;
    /** Metric name to filter the search by. */
    metric?: string;
    /** Space-delimited search term. Case-insensitive. */
    query?: string;
    /** Match messages whose recipient is this email address or domain. */
    recipient?: string;
    /** Match messages whose sender is this email address or domain. */
    sender?: string;
    /** Matches messages whose SMTP HELO server IP address equals this value. */
    smtpHeloIp?: string;
    /** Beginning of search date range. */
    start?: string;
    /** Match messages whose subject contains these keywords, in any order. */
    subject?: string;
    /** Whether to search reclassification submissions instead of original messages. */
    submissions?: boolean;
}
export type InvestigateBulkCreateRequestDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export type InvestigateBulkCreateRequestExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export interface CreateInvestigateBulkRequest {
    /** Identifier. */
    accountId: string;
    /** The action the job performs on every message matching the search parameters. */
    action: InvestigateBulkCreateRequestAction | (string & {});
    searchParams: InvestigateBulkCreateRequestSearchParams;
    /** Optional note describing the job. */
    comment?: string;
    /** Required when action is 'MOVE'. */
    destination?: InvestigateBulkCreateRequestDestination | (string & {});
    /** This field is nonfunctional. */
    expectedDisposition?: InvestigateBulkCreateRequestExpectedDisposition | (string & {});
}
export type InvestigateBulkCreateResponseActionParamsMoveDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export type InvestigateBulkCreateResponseActionParamsMoveType = "MOVE";
export type InvestigateBulkCreateResponseActionParamsMoveExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export interface InvestigateBulkCreateResponseActionParamsMove {
    /** The mailbox folder to move messages to. */
    destination: InvestigateBulkCreateResponseActionParamsMoveDestination;
    type: InvestigateBulkCreateResponseActionParamsMoveType;
    /** This field is nonfunctional. */
    expectedDisposition?: InvestigateBulkCreateResponseActionParamsMoveExpectedDisposition | null;
}
export type InvestigateBulkCreateResponseActionParamsReleaseType = "RELEASE";
export interface InvestigateBulkCreateResponseActionParamsRelease {
    type: InvestigateBulkCreateResponseActionParamsReleaseType;
}
export type InvestigateBulkCreateResponseActionParams = InvestigateBulkCreateResponseActionParamsMove | InvestigateBulkCreateResponseActionParamsRelease;
export type InvestigateBulkCreateResponseActionType = "MOVE" | "RELEASE";
export type InvestigateBulkCreateResponseSearchParamsDeliveryStatus = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued" | "move_failed";
export type InvestigateBulkCreateResponseSearchParamsFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type InvestigateBulkCreateResponseSearchParamsMessageAction = "PREVIEW" | "QUARANTINE_RELEASED" | "MOVED";
export interface InvestigateBulkCreateResponseSearchParams {
    /** Use GET /investigate/{investigate_id}/action_log instead. */
    actionLog?: boolean | null;
    /** Alert ID of the detection to filter by. */
    alertId?: string | null;
    /** Delivery status to filter by. */
    deliveryStatus?: InvestigateBulkCreateResponseSearchParamsDeliveryStatus | null;
    /** Whether to include only detections in search results. */
    detectionsOnly?: boolean | null;
    /** Match messages that mention this domain -- sender domain, recipient domain, or a domain in a link. */
    domain?: string | null;
    /** End of search date range. */
    end?: string | null;
    /** Match messages whose subject line equals this value exactly. */
    exactSubject?: string | null;
    /** Dispositions to filter by. */
    finalDisposition?: InvestigateBulkCreateResponseSearchParamsFinalDisposition | null;
    /** Message actions to filter by. */
    messageAction?: InvestigateBulkCreateResponseSearchParamsMessageAction | null;
    /** Message-ID header value to filter by. */
    messageId?: string | null;
    /** Metric name to filter the search by. */
    metric?: string | null;
    /** Space-delimited search term. Case-insensitive. */
    query?: string | null;
    /** Match messages whose recipient is this email address or domain. */
    recipient?: string | null;
    /** Match messages whose sender is this email address or domain. */
    sender?: string | null;
    /** Matches messages whose SMTP HELO server IP address equals this value. */
    smtpHeloIp?: string | null;
    /** Beginning of search date range. */
    start?: string | null;
    /** Match messages whose subject contains these keywords, in any order. */
    subject?: string | null;
    /** Whether to search reclassification submissions instead of original messages. */
    submissions?: boolean | null;
}
export type InvestigateBulkCreateResponseStatus = "PENDING" | "DISCOVERING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInvestigateBulkResponse {
    actionParams: InvestigateBulkCreateResponseActionParams;
    actionType: InvestigateBulkCreateResponseActionType;
    createdAt: string;
    jobId: string;
    /** Messages that were cancelled: rows cancelled via the API before being claimed, and rows whose in-flight attempt ended when the job reached a terminal state. Together the counters satisfy total_messages_discovered = messages_pending + messages_successful + messages_failed + messages_skipped + messages_cancelled. */
    messagesCancelled: number;
    messagesFailed: number;
    messagesPending: number;
    /** Messages that discovery skipped (for example, phish submissions, which the job cannot action). */
    messagesSkipped: number;
    messagesSuccessful: number;
    searchParams: InvestigateBulkCreateResponseSearchParams;
    /** Status of a bulk action job. */
    status: InvestigateBulkCreateResponseStatus;
    totalMessagesDiscovered: number;
    comment?: string | null;
    completedAt?: string | null;
    startedAt?: string | null;
    statusMessage?: string | null;
}
export interface CreateInvestigateBulkCancelRequest {
    /** Identifier. */
    accountId: string;
    /** Bulk action job identifier. */
    jobId: string;
}
export type InvestigateBulkCancelCreateResponseActionParamsMoveDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export type InvestigateBulkCancelCreateResponseActionParamsMoveType = "MOVE";
export type InvestigateBulkCancelCreateResponseActionParamsMoveExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export interface InvestigateBulkCancelCreateResponseActionParamsMove {
    /** The mailbox folder to move messages to. */
    destination: InvestigateBulkCancelCreateResponseActionParamsMoveDestination;
    type: InvestigateBulkCancelCreateResponseActionParamsMoveType;
    /** This field is nonfunctional. */
    expectedDisposition?: InvestigateBulkCancelCreateResponseActionParamsMoveExpectedDisposition | null;
}
export type InvestigateBulkCancelCreateResponseActionParamsReleaseType = "RELEASE";
export interface InvestigateBulkCancelCreateResponseActionParamsRelease {
    type: InvestigateBulkCancelCreateResponseActionParamsReleaseType;
}
export type InvestigateBulkCancelCreateResponseActionParams = InvestigateBulkCancelCreateResponseActionParamsMove | InvestigateBulkCancelCreateResponseActionParamsRelease;
export type InvestigateBulkCancelCreateResponseActionType = "MOVE" | "RELEASE";
export type InvestigateBulkCancelCreateResponseSearchParamsDeliveryStatus = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued" | "move_failed";
export type InvestigateBulkCancelCreateResponseSearchParamsFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type InvestigateBulkCancelCreateResponseSearchParamsMessageAction = "PREVIEW" | "QUARANTINE_RELEASED" | "MOVED";
export interface InvestigateBulkCancelCreateResponseSearchParams {
    /** Use GET /investigate/{investigate_id}/action_log instead. */
    actionLog?: boolean | null;
    /** Alert ID of the detection to filter by. */
    alertId?: string | null;
    /** Delivery status to filter by. */
    deliveryStatus?: InvestigateBulkCancelCreateResponseSearchParamsDeliveryStatus | null;
    /** Whether to include only detections in search results. */
    detectionsOnly?: boolean | null;
    /** Match messages that mention this domain -- sender domain, recipient domain, or a domain in a link. */
    domain?: string | null;
    /** End of search date range. */
    end?: string | null;
    /** Match messages whose subject line equals this value exactly. */
    exactSubject?: string | null;
    /** Dispositions to filter by. */
    finalDisposition?: InvestigateBulkCancelCreateResponseSearchParamsFinalDisposition | null;
    /** Message actions to filter by. */
    messageAction?: InvestigateBulkCancelCreateResponseSearchParamsMessageAction | null;
    /** Message-ID header value to filter by. */
    messageId?: string | null;
    /** Metric name to filter the search by. */
    metric?: string | null;
    /** Space-delimited search term. Case-insensitive. */
    query?: string | null;
    /** Match messages whose recipient is this email address or domain. */
    recipient?: string | null;
    /** Match messages whose sender is this email address or domain. */
    sender?: string | null;
    /** Matches messages whose SMTP HELO server IP address equals this value. */
    smtpHeloIp?: string | null;
    /** Beginning of search date range. */
    start?: string | null;
    /** Match messages whose subject contains these keywords, in any order. */
    subject?: string | null;
    /** Whether to search reclassification submissions instead of original messages. */
    submissions?: boolean | null;
}
export type InvestigateBulkCancelCreateResponseStatus = "PENDING" | "DISCOVERING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInvestigateBulkCancelResponse {
    actionParams: InvestigateBulkCancelCreateResponseActionParams;
    actionType: InvestigateBulkCancelCreateResponseActionType;
    createdAt: string;
    jobId: string;
    /** Messages that were cancelled: rows cancelled via the API before being claimed, and rows whose in-flight attempt ended when the job reached a terminal state. Together the counters satisfy total_messages_discovered = messages_pending + messages_successful + messages_failed + messages_skipped + messages_cancelled. */
    messagesCancelled: number;
    messagesFailed: number;
    messagesPending: number;
    /** Messages that discovery skipped (for example, phish submissions, which the job cannot action). */
    messagesSkipped: number;
    messagesSuccessful: number;
    searchParams: InvestigateBulkCancelCreateResponseSearchParams;
    /** Status of a bulk action job. */
    status: InvestigateBulkCancelCreateResponseStatus;
    totalMessagesDiscovered: number;
    comment?: string | null;
    completedAt?: string | null;
    startedAt?: string | null;
    statusMessage?: string | null;
}
export type InvestigateMoveCreateRequestDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export type InvestigateMoveCreateRequestExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export interface CreateInvestigateMoveRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation. */
    investigateId: string;
    /** The mailbox folder to move messages to. */
    destination: InvestigateMoveCreateRequestDestination | (string & {});
    /** This field is nonfunctional. */
    expectedDisposition?: InvestigateMoveCreateRequestExpectedDisposition | (string & {});
}
export type InvestigateMoveCreateResultItem = InvestigateMoveBulkResultItem;
export type InvestigateMoveCreateResultList = Array<InvestigateMoveBulkResultItem>;
export interface CreateInvestigateMoveResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvestigateMoveCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface CreateInvestigatePreviewRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation. */
    id: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInvestigatePreviewResponse {
    /** A base64 encoded PNG image of the email. */
    screenshot: string;
}
export type InvestigateReclassifyCreateRequestExpectedDisposition = "NONE" | "BULK" | "MALICIOUS" | "SPAM" | "SPOOF" | "SUSPICIOUS";
export interface CreateInvestigateReclassifyRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation. */
    investigateId: string;
    /** The disposition the message should have. */
    expectedDisposition: InvestigateReclassifyCreateRequestExpectedDisposition | (string & {});
    /** Base64 encoded content of the EML file. */
    emlContent?: string;
    /** Submission ID of the original user submission, when reclassifying an escalated user report. */
    escalatedSubmissionId?: string;
}
export type CreateInvestigateReclassifyResponse = unknown;
export type SettingsAllowPoliciesCreateRequestPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface CreateSettingAllowPolicyRequest {
    /** Identifier. */
    accountId: string;
    /** Exempts messages from this sender from Spam, Spoof and Bulk dispositions only; Malicious and Suspicious dispositions still apply. */
    isAcceptableSender: boolean;
    /** Bypasses all detections for messages to this recipient. */
    isExemptRecipient: boolean;
    isRegex: boolean;
    /** Bypasses all detections and link following for messages from this sender. */
    isTrustedSender: boolean;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern: string;
    /** Type of pattern matching. */
    patternType: SettingsAllowPoliciesCreateRequestPatternType | (string & {});
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender: boolean;
    comments?: string;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    /** Use `is_exempt_recipient` instead. */
    isRecipient?: boolean;
    /** Use `is_trusted_sender` instead. */
    isSender?: boolean;
    /** Use `is_acceptable_sender` instead. */
    isSpoof?: boolean;
}
export type SettingsAllowPoliciesCreateResponsePatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingAllowPolicyResponse {
    /** Allow policy identifier. */
    id: string;
    createdAt: string;
    /** Use `modified_at` instead. */
    lastModified: string;
    comments?: string | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Exempts messages from this sender from Spam, Spoof and Bulk dispositions only; Malicious and Suspicious dispositions still apply. */
    isAcceptableSender?: boolean | null;
    /** Bypasses all detections for messages to this recipient. */
    isExemptRecipient?: boolean | null;
    /** Use `is_exempt_recipient` instead. */
    isRecipient?: boolean | null;
    isRegex?: boolean | null;
    /** Use `is_trusted_sender` instead. */
    isSender?: boolean | null;
    /** Use `is_acceptable_sender` instead. */
    isSpoof?: boolean | null;
    /** Bypasses all detections and link following for messages from this sender. */
    isTrustedSender?: boolean | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesCreateResponsePatternType | null;
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean | null;
}
export type SettingsBlockSendersCreateRequestPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface CreateSettingBlockSenderRequest {
    /** Identifier. */
    accountId: string;
    /** Whether `pattern` is a regular expression instead of a literal value. */
    isRegex: boolean;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern: string;
    /** Type of pattern matching. */
    patternType: SettingsBlockSendersCreateRequestPatternType | (string & {});
    comments?: string;
    /** Timestamp at which the pattern expires. After this time, Email Security ignores the pattern. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
}
export type SettingsBlockSendersCreateResponsePatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingBlockSenderResponse {
    /** Blocked sender pattern identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Timestamp at which the pattern expires. After this time, Email Security ignores the pattern. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Whether `pattern` is a regular expression instead of a literal value. */
    isRegex?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersCreateResponsePatternType | null;
}
export type SettingsImpersonationRegistryCreateRequestProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
export interface CreateSettingImpersonationRegistryRequest {
    /** Identifier. */
    accountId: string;
    /** Email address (or pattern) of the protected identity. */
    email: string;
    /** Whether `email` is a regular expression instead of a literal address. */
    isEmailRegex: boolean;
    /** Display name of the protected identity. */
    name: string;
    /** Optional note describing the entry. */
    comments?: string;
    /** Identifier of the directory the entry was synced from, when directory-synced. */
    directoryId?: number;
    /** Identifier of the directory node the entry was synced from, when directory-synced. */
    directoryNodeId?: number;
    /** This field is deprecated. */
    externalDirectoryNodeId?: string;
    /** Source the entry was created from. */
    provenance?: SettingsImpersonationRegistryCreateRequestProvenance | (string & {});
}
export type SettingsImpersonationRegistryCreateResponseProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingImpersonationRegistryResponse {
    /** Impersonation registry entry identifier. */
    id?: string | null;
    /** Optional note describing the entry. */
    comments?: string | null;
    createdAt?: string | null;
    /** Identifier of the directory the entry was synced from, when directory-synced. */
    directoryId?: number | null;
    /** Identifier of the directory node the entry was synced from, when directory-synced. */
    directoryNodeId?: number | null;
    /** Email address (or pattern) of the protected identity. */
    email?: string | null;
    /** This field is deprecated. */
    externalDirectoryNodeId?: string | null;
    /** Whether `email` is a regular expression instead of a literal address. */
    isEmailRegex?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** Display name of the protected identity. */
    name?: string | null;
    /** Source the entry was created from. */
    provenance?: SettingsImpersonationRegistryCreateResponseProvenance | null;
}
export type CreateSettingsContentPolicyRequestTargetsItem = "SUBJECT" | "BODY";
export type CreateSettingsContentPolicyRequestTargetsList = Array<CreateSettingsContentPolicyRequestTargetsItem | (string & {})>;
export interface CreateSettingsContentPolicyRequest {
    /** Identifier. */
    accountId: string;
    /** Whether the policy is active. */
    enabled: boolean;
    /** Human-readable name of the policy. */
    name: string;
    /** Regular expression the policy matches against. */
    pattern: string;
    /** Parts of the email the pattern is matched against. */
    targets: CreateSettingsContentPolicyRequestTargetsList;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    /** Optional note describing the purpose of the policy. */
    notes?: string;
}
export type CreateSettingsContentPolicyResponseTargetsItem = "SUBJECT" | "BODY";
export type CreateSettingsContentPolicyResponseTargetsList = Array<CreateSettingsContentPolicyResponseTargetsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingsContentPolicyResponse {
    /** Content policy identifier. */
    id?: string | null;
    createdAt?: string | null;
    /** Whether the policy is active. */
    enabled?: boolean | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    modifiedAt?: string | null;
    /** Human-readable name of the policy. */
    name?: string | null;
    /** Optional note describing the purpose of the policy. */
    notes?: string | null;
    /** Regular expression the policy matches against. */
    pattern?: string | null;
    /** Parts of the email the pattern is matched against. */
    targets?: CreateSettingsContentPolicyResponseTargetsList | null;
}
export type CreateSettingsDomainRequestAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type CreateSettingsDomainRequestAllowedDeliveryModesList = Array<CreateSettingsDomainRequestAllowedDeliveryModesItem | (string & {})>;
export type CreateSettingsDomainRequestDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type CreateSettingsDomainRequestDropDispositionsList = Array<CreateSettingsDomainRequestDropDispositionsItem | (string & {})>;
export type CreateSettingsDomainRequestIpRestrictionsList = Array<string>;
export type CreateSettingsDomainRequestRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type CreateSettingsDomainRequestRegionsList = Array<CreateSettingsDomainRequestRegionsItem | (string & {})>;
export type CreateSettingsDomainRequestFolder = "AllItems" | "Inbox";
export interface CreateSettingsDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Delivery modes to onboard the domain through. */
    allowedDeliveryModes: CreateSettingsDomainRequestAllowedDeliveryModesList;
    /** The email domain to protect. */
    domain: string;
    /** Dispositions to drop instead of delivering, e.g. `["MALICIOUS", "SPAM"]`. */
    dropDispositions: CreateSettingsDomainRequestDropDispositionsList;
    /** Source IP ranges mail is accepted from. Any other source is rejected. */
    ipRestrictions: CreateSettingsDomainRequestIpRestrictionsList;
    /** Regions that process messages for this domain, e.g. `["GLOBAL"]` or `["US"]`. */
    regions: CreateSettingsDomainRequestRegionsList;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: CreateSettingsDomainRequestFolder | (string & {});
    /** Identifier of the CASB integration that authorizes this domain. The integration also enables API scanning, post-delivery actions, and directory sync. */
    integrationId?: string;
    /** Number of hops to trace back through received headers when reconstructing the original message (1-20). */
    lookbackHops?: number;
    /** Require TLS on inbound connections. */
    requireTlsInbound?: boolean;
    /** Require TLS on outbound connections. */
    requireTlsOutbound?: boolean;
    /** The mail transport hostname for MX/Inline delivery -- the MX record Cloudflare delivers email to (e.g. `mx.example.com`). */
    transport?: string;
}
export type CreateSettingsDomainResponseAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type CreateSettingsDomainResponseAllowedDeliveryModesList = Array<CreateSettingsDomainResponseAllowedDeliveryModesItem>;
export interface CreateSettingsDomainResponseAuthorization {
    authorized: boolean;
    timestamp: string;
    statusMessage?: string | null;
}
export type CreateSettingsDomainResponseDmarcStatus = "none" | "good" | "invalid";
export type CreateSettingsDomainResponseDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type CreateSettingsDomainResponseDropDispositionsList = Array<CreateSettingsDomainResponseDropDispositionsItem>;
export interface CreateSettingsDomainResponseEmailsProcessed {
    timestamp: string;
    totalEmailsProcessed: number;
    totalEmailsProcessedPrevious: number;
}
export type CreateSettingsDomainResponseFolder = "AllItems" | "Inbox";
export type CreateSettingsDomainResponseInboxProvider = "Microsoft" | "Google";
export type CreateSettingsDomainResponseIpRestrictionsList = Array<string>;
export type CreateSettingsDomainResponseRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type CreateSettingsDomainResponseRegionsList = Array<CreateSettingsDomainResponseRegionsItem>;
export type CreateSettingsDomainResponseSpfStatus = "none" | "good" | "neutral" | "open" | "invalid";
export type CreateSettingsDomainResponseStatus = "PENDING" | "ACTIVE" | "FAILED" | "TIMEOUT";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingsDomainResponse {
    /** Domain identifier. */
    id?: string | null;
    allowedDeliveryModes?: CreateSettingsDomainResponseAllowedDeliveryModesList | null;
    authorization?: CreateSettingsDomainResponseAuthorization | null;
    createdAt?: string | null;
    dmarcStatus?: CreateSettingsDomainResponseDmarcStatus | null;
    domain?: string | null;
    dropDispositions?: CreateSettingsDomainResponseDropDispositionsList | null;
    emailsProcessed?: CreateSettingsDomainResponseEmailsProcessed | null;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: CreateSettingsDomainResponseFolder | null;
    inboxProvider?: CreateSettingsDomainResponseInboxProvider | null;
    integrationId?: string | null;
    ipRestrictions?: CreateSettingsDomainResponseIpRestrictionsList | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    lookbackHops?: number | null;
    modifiedAt?: string | null;
    o365TenantId?: string | null;
    regions?: CreateSettingsDomainResponseRegionsList | null;
    requireTlsInbound?: boolean | null;
    requireTlsOutbound?: boolean | null;
    spfStatus?: CreateSettingsDomainResponseSpfStatus | null;
    status?: CreateSettingsDomainResponseStatus | null;
    transport?: string | null;
}
export type SettingsSendingDomainRestrictionsCreateRequestExcludeList = Array<string>;
export interface CreateSettingSendingDomainRestrictionRequest {
    /** Identifier. */
    accountId: string;
    /** Domain that requires TLS enforcement. */
    domain: string;
    /** Subdomains to exempt from TLS requirements. */
    exclude: SettingsSendingDomainRestrictionsCreateRequestExcludeList;
    comments?: string;
}
export type SettingsSendingDomainRestrictionsCreateResponseExcludeList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingSendingDomainRestrictionResponse {
    /** Sending domain restriction identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Domain that requires TLS enforcement. */
    domain?: string | null;
    /** Subdomains to exempt from TLS requirements. */
    exclude?: SettingsSendingDomainRestrictionsCreateResponseExcludeList | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export interface CreateSettingTrustedDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent: boolean;
    /** Whether `pattern` is a regular expression instead of a literal domain. */
    isRegex: boolean;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity: boolean;
    /** The domain pattern to trust, e.g. `example.com`. */
    pattern: string;
    comments?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingTrustedDomainResponse {
    /** Trusted domain identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent?: boolean | null;
    /** Whether `pattern` is a regular expression instead of a literal domain. */
    isRegex?: boolean | null;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** The domain pattern to trust, e.g. `example.com`. */
    pattern?: string | null;
}
export interface CreateSettingUrlIgnorePatternRequest {
    /** Identifier. */
    accountId: string;
    /** Regular expression identifying URLs to exempt from rewriting. */
    pattern: string;
    /** Optional note describing the reason for the ignore pattern. */
    comments?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingUrlIgnorePatternResponse {
    /** URL ignore pattern identifier. */
    id: string;
    createdAt: string;
    /** Regular expression identifying URLs to exempt from rewriting. */
    pattern: string;
    /** Optional note describing the reason for the ignore pattern. */
    comments?: string | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export interface DeleteInvestigateBulkRequest {
    /** Identifier. */
    accountId: string;
    /** Bulk action job identifier. */
    jobId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteInvestigateBulkResponse {
    id: string;
}
export interface DeleteSettingAllowPolicyRequest {
    /** Identifier. */
    accountId: string;
    /** Allow policy identifier. */
    policyId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingAllowPolicyResponse {
    /** Allow policy identifier. */
    id: string;
}
export interface DeleteSettingBlockSenderRequest {
    /** Identifier. */
    accountId: string;
    /** Blocked sender pattern identifier. */
    patternId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingBlockSenderResponse {
    /** Blocked sender pattern identifier. */
    id: string;
}
export interface DeleteSettingDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Domain identifier. */
    domainId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingDomainResponse {
    /** Domain identifier. */
    id: string;
}
export interface DeleteSettingImpersonationRegistryRequest {
    /** Identifier. */
    accountId: string;
    /** Impersonation registry entry identifier. */
    impersonationRegistryId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingImpersonationRegistryResponse {
    /** Impersonation registry entry identifier. */
    id: string;
}
export interface DeleteSettingsContentPolicyRequest {
    /** Identifier. */
    accountId: string;
    /** Content policy identifier. */
    policyId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingsContentPolicyResponse {
    /** Content policy identifier. */
    id: string;
}
export interface DeleteSettingSendingDomainRestrictionRequest {
    /** Identifier. */
    accountId: string;
    /** Sending domain restriction identifier. */
    sendingDomainRestrictionId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingSendingDomainRestrictionResponse {
    /** Sending domain restriction identifier. */
    id: string;
}
export interface DeleteSettingTrustedDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Trusted domain identifier. */
    trustedDomainId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingTrustedDomainResponse {
    /** Trusted domain identifier. */
    id: string;
}
export interface DeleteSettingUrlIgnorePatternRequest {
    /** Identifier. */
    accountId: string;
    /** URL ignore pattern identifier. */
    patternId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingUrlIgnorePatternResponse {
    /** URL ignore pattern identifier. */
    id: string;
}
export type EditSettingsContentPolicyRequestTargetsItem = "SUBJECT" | "BODY";
export type EditSettingsContentPolicyRequestTargetsList = Array<EditSettingsContentPolicyRequestTargetsItem | (string & {})>;
export interface EditSettingsContentPolicyRequest {
    /** Identifier. */
    accountId: string;
    /** Content policy identifier. */
    policyId: string;
    /** Whether the policy is active. */
    enabled?: boolean;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    /** Human-readable name of the policy. */
    name?: string;
    /** Optional note describing the purpose of the policy. */
    notes?: string;
    /** Regular expression the policy matches against. */
    pattern?: string;
    /** Parts of the email the pattern is matched against. */
    targets?: EditSettingsContentPolicyRequestTargetsList;
}
export type EditSettingsContentPolicyResponseTargetsItem = "SUBJECT" | "BODY";
export type EditSettingsContentPolicyResponseTargetsList = Array<EditSettingsContentPolicyResponseTargetsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditSettingsContentPolicyResponse {
    /** Content policy identifier. */
    id?: string | null;
    createdAt?: string | null;
    /** Whether the policy is active. */
    enabled?: boolean | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    modifiedAt?: string | null;
    /** Human-readable name of the policy. */
    name?: string | null;
    /** Optional note describing the purpose of the policy. */
    notes?: string | null;
    /** Regular expression the policy matches against. */
    pattern?: string | null;
    /** Parts of the email the pattern is matched against. */
    targets?: EditSettingsContentPolicyResponseTargetsList | null;
}
export interface GetInvestigateRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation. */
    investigateId: string;
    /** When true, search the submissions datastore only. When false or omitted, search the regular datastore only. */
    submission?: boolean;
}
export type InvestigateGetResponseActionLogItemOperation = "MOVE" | "RELEASE" | "RECLASSIFY" | "SUBMISSION" | "QUARANTINE_RELEASE" | "PREVIEW";
export interface InvestigateGetResponseActionLogItemProperties {
    /** Target folder for move operations. */
    folder?: string | null;
    /** User who requested the action. */
    requestedBy?: string | null;
}
export interface InvestigateGetResponseActionLogItem {
    /** Timestamp when action completed. */
    completedAt: string;
    /** Type of action performed. */
    operation: InvestigateGetResponseActionLogItemOperation;
    /** Use `completed_at` instead. */
    completedTimestamp?: string | null;
    /** Additional properties for the action. */
    properties?: InvestigateGetResponseActionLogItemProperties | null;
    /** Status of the action. */
    status?: string | null;
}
export type InvestigateGetResponseActionLogList = Array<InvestigateGetResponseActionLogItem>;
export type InvestigateGetResponseClientRecipientsList = Array<string>;
export type InvestigateGetResponseDetectionReasonsList = Array<string>;
export type InvestigateGetResponsePropertiesAllowlistedPatternType = "quarantine_release" | "acceptable_sender" | "allowed_sender" | "allowed_recipient" | "domain_similarity" | "domain_recency" | "managed_acceptable_sender" | "outbound_ndr";
export type InvestigateGetResponsePropertiesWhitelistedPatternType = "quarantine_release" | "acceptable_sender" | "allowed_sender" | "allowed_recipient" | "domain_similarity" | "domain_recency" | "managed_acceptable_sender" | "outbound_ndr";
export interface InvestigateGetResponseProperties {
    /** Pattern that allowlisted this message. */
    allowlistedPattern?: string | null;
    /** Type of allowlist pattern. */
    allowlistedPatternType?: InvestigateGetResponsePropertiesAllowlistedPatternType | null;
    /** Whether message was blocklisted. */
    blocklistedMessage?: boolean | null;
    /** Pattern that blocklisted this message. */
    blocklistedPattern?: string | null;
    /** Legacy field for allowlist pattern type. */
    whitelistedPatternType?: InvestigateGetResponsePropertiesWhitelistedPatternType | null;
}
export type InvestigateGetResponseDeliveryMode = "DIRECT" | "BCC" | "JOURNAL" | "REVIEW_SUBMISSION" | "DMARC_UNVERIFIED" | "DMARC_FAILURE_REPORT" | "DMARC_AGGREGATE_REPORT" | "THREAT_INTEL_SUBMISSION" | "SIMULATION_SUBMISSION" | "API" | "RETRO_SCAN";
export type InvestigateGetResponseDeliveryStatusItem = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued" | "move_failed";
export type InvestigateGetResponseDeliveryStatusList = Array<InvestigateGetResponseDeliveryStatusItem>;
export type InvestigateGetResponseEnvelopeToList = Array<string>;
export type InvestigateGetResponseFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type InvestigateGetResponseFindingsItemDetection = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export interface InvestigateGetResponseFindingsItem {
    attachment?: string | null;
    detail?: string | null;
    /** The verdict Email Security assigns to a message. */
    detection?: InvestigateGetResponseFindingsItemDetection | null;
    field?: string | null;
    name?: string | null;
    portion?: string | null;
    reason?: string | null;
    score?: number | null;
    value?: string | null;
}
export type InvestigateGetResponseFindingsList = Array<InvestigateGetResponseFindingsItem>;
export type InvestigateGetResponsePostDeliveryOperationsItem = "PREVIEW" | "QUARANTINE_RELEASE" | "SUBMISSION" | "MOVE";
export type InvestigateGetResponsePostDeliveryOperationsList = Array<InvestigateGetResponsePostDeliveryOperationsItem>;
export type InvestigateGetResponseThreatCategoriesList = Array<string>;
export type InvestigateGetResponseToList = Array<string>;
export type InvestigateGetResponseToNameList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInvestigateResponse {
    /** Unique identifier for a message retrieved from investigation. */
    id: string;
    /** Use GET /investigate/{investigate_id}/action_log instead. */
    actionLog: InvestigateGetResponseActionLogList;
    clientRecipients: InvestigateGetResponseClientRecipientsList;
    detectionReasons: InvestigateGetResponseDetectionReasonsList;
    isPhishSubmission: boolean;
    isQuarantined: boolean;
    /** The identifier of the message. */
    postfixId: string;
    /** Message processing properties. */
    properties: InvestigateGetResponseProperties;
    /** Use `scanned_at` instead. */
    ts: string;
    alertId?: string | null;
    deliveryMode?: InvestigateGetResponseDeliveryMode | null;
    deliveryStatus?: InvestigateGetResponseDeliveryStatusList | null;
    edfHash?: string | null;
    envelopeFrom?: string | null;
    envelopeTo?: InvestigateGetResponseEnvelopeToList | null;
    /** The verdict Email Security assigns to a message. */
    finalDisposition?: InvestigateGetResponseFinalDisposition | null;
    /** Use the `findings` field from GET /investigate/{investigate_id}/detections instead. */
    findings?: InvestigateGetResponseFindingsList | null;
    from?: string | null;
    fromName?: string | null;
    htmltextStructureHash?: string | null;
    messageId?: string | null;
    /** Post-delivery operations performed on this message. */
    postDeliveryOperations?: InvestigateGetResponsePostDeliveryOperationsList | null;
    postfixIdOutbound?: string | null;
    replyto?: string | null;
    /** When the message was scanned (UTC). */
    scannedAt?: string | null;
    /** When the message was sent (UTC). */
    sentAt?: string | null;
    sentDate?: string | null;
    smtpHeloServerIp?: string | null;
    smtpPreviousHopIp?: string | null;
    subject?: string | null;
    threatCategories?: InvestigateGetResponseThreatCategoriesList | null;
    to?: InvestigateGetResponseToList | null;
    toName?: InvestigateGetResponseToNameList | null;
    validation?: unknown | null;
    xOriginatingIp?: string | null;
}
export interface GetInvestigateBulkRequest {
    /** Identifier. */
    accountId: string;
    /** Bulk action job identifier. */
    jobId: string;
}
export type InvestigateBulkGetResponseActionParamsMoveDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export type InvestigateBulkGetResponseActionParamsMoveType = "MOVE";
export type InvestigateBulkGetResponseActionParamsMoveExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export interface InvestigateBulkGetResponseActionParamsMove {
    /** The mailbox folder to move messages to. */
    destination: InvestigateBulkGetResponseActionParamsMoveDestination;
    type: InvestigateBulkGetResponseActionParamsMoveType;
    /** This field is nonfunctional. */
    expectedDisposition?: InvestigateBulkGetResponseActionParamsMoveExpectedDisposition | null;
}
export type InvestigateBulkGetResponseActionParamsReleaseType = "RELEASE";
export interface InvestigateBulkGetResponseActionParamsRelease {
    type: InvestigateBulkGetResponseActionParamsReleaseType;
}
export type InvestigateBulkGetResponseActionParams = InvestigateBulkGetResponseActionParamsMove | InvestigateBulkGetResponseActionParamsRelease;
export type InvestigateBulkGetResponseActionType = "MOVE" | "RELEASE";
export type InvestigateBulkGetResponseSearchParamsDeliveryStatus = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued" | "move_failed";
export type InvestigateBulkGetResponseSearchParamsFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type InvestigateBulkGetResponseSearchParamsMessageAction = "PREVIEW" | "QUARANTINE_RELEASED" | "MOVED";
export interface InvestigateBulkGetResponseSearchParams {
    /** Use GET /investigate/{investigate_id}/action_log instead. */
    actionLog?: boolean | null;
    /** Alert ID of the detection to filter by. */
    alertId?: string | null;
    /** Delivery status to filter by. */
    deliveryStatus?: InvestigateBulkGetResponseSearchParamsDeliveryStatus | null;
    /** Whether to include only detections in search results. */
    detectionsOnly?: boolean | null;
    /** Match messages that mention this domain -- sender domain, recipient domain, or a domain in a link. */
    domain?: string | null;
    /** End of search date range. */
    end?: string | null;
    /** Match messages whose subject line equals this value exactly. */
    exactSubject?: string | null;
    /** Dispositions to filter by. */
    finalDisposition?: InvestigateBulkGetResponseSearchParamsFinalDisposition | null;
    /** Message actions to filter by. */
    messageAction?: InvestigateBulkGetResponseSearchParamsMessageAction | null;
    /** Message-ID header value to filter by. */
    messageId?: string | null;
    /** Metric name to filter the search by. */
    metric?: string | null;
    /** Space-delimited search term. Case-insensitive. */
    query?: string | null;
    /** Match messages whose recipient is this email address or domain. */
    recipient?: string | null;
    /** Match messages whose sender is this email address or domain. */
    sender?: string | null;
    /** Matches messages whose SMTP HELO server IP address equals this value. */
    smtpHeloIp?: string | null;
    /** Beginning of search date range. */
    start?: string | null;
    /** Match messages whose subject contains these keywords, in any order. */
    subject?: string | null;
    /** Whether to search reclassification submissions instead of original messages. */
    submissions?: boolean | null;
}
export type InvestigateBulkGetResponseStatus = "PENDING" | "DISCOVERING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInvestigateBulkResponse {
    actionParams: InvestigateBulkGetResponseActionParams;
    actionType: InvestigateBulkGetResponseActionType;
    createdAt: string;
    jobId: string;
    /** Messages that were cancelled: rows cancelled via the API before being claimed, and rows whose in-flight attempt ended when the job reached a terminal state. Together the counters satisfy total_messages_discovered = messages_pending + messages_successful + messages_failed + messages_skipped + messages_cancelled. */
    messagesCancelled: number;
    messagesFailed: number;
    messagesPending: number;
    /** Messages that discovery skipped (for example, phish submissions, which the job cannot action). */
    messagesSkipped: number;
    messagesSuccessful: number;
    searchParams: InvestigateBulkGetResponseSearchParams;
    /** Status of a bulk action job. */
    status: InvestigateBulkGetResponseStatus;
    totalMessagesDiscovered: number;
    comment?: string | null;
    completedAt?: string | null;
    startedAt?: string | null;
    statusMessage?: string | null;
}
export interface GetInvestigateDetectionRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation. */
    investigateId: string;
}
export type InvestigateDetectionsGetResponseAttachmentsItemDetection = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export interface InvestigateDetectionsGetResponseAttachmentsItem {
    /** Size of the attachment in bytes. */
    size: number;
    /** MIME type of the attachment. */
    contentType?: string | null;
    /** Detection result for this attachment. */
    detection?: InvestigateDetectionsGetResponseAttachmentsItemDetection | null;
    /** Whether the attachment is encrypted. */
    encrypted?: boolean | null;
    /** Name of the attached file. */
    filename?: string | null;
    /** MD5 hash of the attachment. */
    md5?: string | null;
    /** Attachment name (alternative to filename). */
    name?: string | null;
    /** SHA1 hash of the attachment. */
    sha1?: string | null;
    /** SHA256 hash of the attachment. */
    sha256?: string | null;
}
export type InvestigateDetectionsGetResponseAttachmentsList = Array<InvestigateDetectionsGetResponseAttachmentsItem>;
export type InvestigateDetectionsGetResponseFindingsItemDetection = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export interface InvestigateDetectionsGetResponseFindingsItem {
    attachment?: string | null;
    detail?: string | null;
    /** Detection result associated with this finding. */
    detection?: InvestigateDetectionsGetResponseFindingsItemDetection | null;
    field?: string | null;
    name?: string | null;
    portion?: string | null;
    reason?: string | null;
    score?: number | null;
    value?: string | null;
}
export type InvestigateDetectionsGetResponseFindingsList = Array<InvestigateDetectionsGetResponseFindingsItem>;
export interface InvestigateDetectionsGetResponseHeadersItem {
    name: string;
    value: string;
}
export type InvestigateDetectionsGetResponseHeadersList = Array<InvestigateDetectionsGetResponseHeadersItem>;
export interface InvestigateDetectionsGetResponseLinksItem {
    href: string;
    text?: string | null;
}
export type InvestigateDetectionsGetResponseLinksList = Array<InvestigateDetectionsGetResponseLinksItem>;
export interface InvestigateDetectionsGetResponseSenderInfo {
    /** The name of the autonomous system. */
    asName?: string | null;
    /** The number of the autonomous system. */
    asNumber?: number | null;
    geo?: string | null;
    ip?: string | null;
    pld?: string | null;
}
export interface InvestigateDetectionsGetResponseThreatCategoriesItem {
    id?: number | null;
    description?: string | null;
    name?: string | null;
}
export type InvestigateDetectionsGetResponseThreatCategoriesList = Array<InvestigateDetectionsGetResponseThreatCategoriesItem>;
export type InvestigateDetectionsGetResponseValidationDkim = "pass" | "neutral" | "fail" | "error" | "none";
export type InvestigateDetectionsGetResponseValidationDmarc = "pass" | "neutral" | "fail" | "error" | "none";
export type InvestigateDetectionsGetResponseValidationSpf = "pass" | "neutral" | "fail" | "error" | "none";
export interface InvestigateDetectionsGetResponseValidation {
    comment?: string | null;
    dkim?: InvestigateDetectionsGetResponseValidationDkim | null;
    dmarc?: InvestigateDetectionsGetResponseValidationDmarc | null;
    spf?: InvestigateDetectionsGetResponseValidationSpf | null;
}
export type InvestigateDetectionsGetResponseFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInvestigateDetectionResponse {
    action: string;
    attachments: InvestigateDetectionsGetResponseAttachmentsList;
    findings: InvestigateDetectionsGetResponseFindingsList;
    headers: InvestigateDetectionsGetResponseHeadersList;
    links: InvestigateDetectionsGetResponseLinksList;
    senderInfo: InvestigateDetectionsGetResponseSenderInfo;
    threatCategories: InvestigateDetectionsGetResponseThreatCategoriesList;
    validation: InvestigateDetectionsGetResponseValidation;
    /** The verdict Email Security assigns to a message. */
    finalDisposition?: InvestigateDetectionsGetResponseFinalDisposition | null;
}
export interface GetInvestigatePreviewRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation. */
    investigateId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInvestigatePreviewResponse {
    /** A base64 encoded PNG image of the email. */
    screenshot: string;
}
export interface GetInvestigateRawRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation. */
    investigateId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInvestigateRawResponse {
    /** A UTF-8 encoded eml file of the email. */
    raw: string;
}
export interface GetInvestigateTraceRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation. */
    investigateId: string;
}
export interface InvestigateTraceGetResponseInboundLinesItem {
    /** Line number in the trace log. */
    lineno?: number | null;
    loggedAt?: string | null;
    message?: string | null;
    /** Use `logged_at` instead. */
    ts?: string | null;
}
export type InvestigateTraceGetResponseInboundLinesList = Array<InvestigateTraceGetResponseInboundLinesItem>;
export interface InvestigateTraceGetResponseInbound {
    lines?: InvestigateTraceGetResponseInboundLinesList | null;
    pending?: boolean | null;
}
export type InvestigateTraceGetResponseOutboundLinesItem = InvestigateTraceGetResponseInboundLinesItem;
export type InvestigateTraceGetResponseOutboundLinesList = Array<InvestigateTraceGetResponseInboundLinesItem>;
export interface InvestigateTraceGetResponseOutbound {
    lines?: InvestigateTraceGetResponseOutboundLinesList | null;
    pending?: boolean | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInvestigateTraceResponse {
    inbound: InvestigateTraceGetResponseInbound;
    outbound: InvestigateTraceGetResponseOutbound;
}
export interface GetSettingAllowPolicyRequest {
    /** Identifier. */
    accountId: string;
    /** Allow policy identifier. */
    policyId: string;
}
export type SettingsAllowPoliciesGetResponsePatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingAllowPolicyResponse {
    /** Allow policy identifier. */
    id: string;
    createdAt: string;
    /** Use `modified_at` instead. */
    lastModified: string;
    comments?: string | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Exempts messages from this sender from Spam, Spoof and Bulk dispositions only; Malicious and Suspicious dispositions still apply. */
    isAcceptableSender?: boolean | null;
    /** Bypasses all detections for messages to this recipient. */
    isExemptRecipient?: boolean | null;
    /** Use `is_exempt_recipient` instead. */
    isRecipient?: boolean | null;
    isRegex?: boolean | null;
    /** Use `is_trusted_sender` instead. */
    isSender?: boolean | null;
    /** Use `is_acceptable_sender` instead. */
    isSpoof?: boolean | null;
    /** Bypasses all detections and link following for messages from this sender. */
    isTrustedSender?: boolean | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesGetResponsePatternType | null;
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean | null;
}
export interface GetSettingBlockSenderRequest {
    /** Identifier. */
    accountId: string;
    /** Blocked sender pattern identifier. */
    patternId: string;
}
export type SettingsBlockSendersGetResponsePatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingBlockSenderResponse {
    /** Blocked sender pattern identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Timestamp at which the pattern expires. After this time, Email Security ignores the pattern. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Whether `pattern` is a regular expression instead of a literal value. */
    isRegex?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersGetResponsePatternType | null;
}
export interface GetSettingDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Domain identifier. */
    domainId: string;
}
export type SettingsDomainsGetResponseAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type SettingsDomainsGetResponseAllowedDeliveryModesList = Array<SettingsDomainsGetResponseAllowedDeliveryModesItem>;
export type SettingsDomainsGetResponseAuthorization = CreateSettingsDomainResponseAuthorization;
export type SettingsDomainsGetResponseDmarcStatus = "none" | "good" | "invalid";
export type SettingsDomainsGetResponseDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type SettingsDomainsGetResponseDropDispositionsList = Array<SettingsDomainsGetResponseDropDispositionsItem>;
export type SettingsDomainsGetResponseEmailsProcessed = CreateSettingsDomainResponseEmailsProcessed;
export type SettingsDomainsGetResponseFolder = "AllItems" | "Inbox";
export type SettingsDomainsGetResponseInboxProvider = "Microsoft" | "Google";
export type SettingsDomainsGetResponseIpRestrictionsList = Array<string>;
export type SettingsDomainsGetResponseRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type SettingsDomainsGetResponseRegionsList = Array<SettingsDomainsGetResponseRegionsItem>;
export type SettingsDomainsGetResponseSpfStatus = "none" | "good" | "neutral" | "open" | "invalid";
export type SettingsDomainsGetResponseStatus = "PENDING" | "ACTIVE" | "FAILED" | "TIMEOUT";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingDomainResponse {
    /** Domain identifier. */
    id?: string | null;
    allowedDeliveryModes?: SettingsDomainsGetResponseAllowedDeliveryModesList | null;
    authorization?: CreateSettingsDomainResponseAuthorization | null;
    createdAt?: string | null;
    dmarcStatus?: SettingsDomainsGetResponseDmarcStatus | null;
    domain?: string | null;
    dropDispositions?: SettingsDomainsGetResponseDropDispositionsList | null;
    emailsProcessed?: CreateSettingsDomainResponseEmailsProcessed | null;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: SettingsDomainsGetResponseFolder | null;
    inboxProvider?: SettingsDomainsGetResponseInboxProvider | null;
    integrationId?: string | null;
    ipRestrictions?: SettingsDomainsGetResponseIpRestrictionsList | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    lookbackHops?: number | null;
    modifiedAt?: string | null;
    o365TenantId?: string | null;
    regions?: SettingsDomainsGetResponseRegionsList | null;
    requireTlsInbound?: boolean | null;
    requireTlsOutbound?: boolean | null;
    spfStatus?: SettingsDomainsGetResponseSpfStatus | null;
    status?: SettingsDomainsGetResponseStatus | null;
    transport?: string | null;
}
export interface GetSettingImpersonationRegistryRequest {
    /** Identifier. */
    accountId: string;
    /** Impersonation registry entry identifier. */
    impersonationRegistryId: string;
}
export type SettingsImpersonationRegistryGetResponseProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingImpersonationRegistryResponse {
    /** Impersonation registry entry identifier. */
    id?: string | null;
    /** Optional note describing the entry. */
    comments?: string | null;
    createdAt?: string | null;
    /** Identifier of the directory the entry was synced from, when directory-synced. */
    directoryId?: number | null;
    /** Identifier of the directory node the entry was synced from, when directory-synced. */
    directoryNodeId?: number | null;
    /** Email address (or pattern) of the protected identity. */
    email?: string | null;
    /** This field is deprecated. */
    externalDirectoryNodeId?: string | null;
    /** Whether `email` is a regular expression instead of a literal address. */
    isEmailRegex?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** Display name of the protected identity. */
    name?: string | null;
    /** Source the entry was created from. */
    provenance?: SettingsImpersonationRegistryGetResponseProvenance | null;
}
export interface GetSettingsContentPolicyRequest {
    /** Identifier. */
    accountId: string;
    /** Content policy identifier. */
    policyId: string;
}
export type GetSettingsContentPolicyResponseTargetsItem = "SUBJECT" | "BODY";
export type GetSettingsContentPolicyResponseTargetsList = Array<GetSettingsContentPolicyResponseTargetsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingsContentPolicyResponse {
    /** Content policy identifier. */
    id?: string | null;
    createdAt?: string | null;
    /** Whether the policy is active. */
    enabled?: boolean | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    modifiedAt?: string | null;
    /** Human-readable name of the policy. */
    name?: string | null;
    /** Optional note describing the purpose of the policy. */
    notes?: string | null;
    /** Regular expression the policy matches against. */
    pattern?: string | null;
    /** Parts of the email the pattern is matched against. */
    targets?: GetSettingsContentPolicyResponseTargetsList | null;
}
export interface GetSettingSendingDomainRestrictionRequest {
    /** Identifier. */
    accountId: string;
    /** Sending domain restriction identifier. */
    sendingDomainRestrictionId: string;
}
export type SettingsSendingDomainRestrictionsGetResponseExcludeList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingSendingDomainRestrictionResponse {
    /** Sending domain restriction identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Domain that requires TLS enforcement. */
    domain?: string | null;
    /** Subdomains to exempt from TLS requirements. */
    exclude?: SettingsSendingDomainRestrictionsGetResponseExcludeList | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export interface GetSettingTrustedDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Trusted domain identifier. */
    trustedDomainId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingTrustedDomainResponse {
    /** Trusted domain identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent?: boolean | null;
    /** Whether `pattern` is a regular expression instead of a literal domain. */
    isRegex?: boolean | null;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** The domain pattern to trust, e.g. `example.com`. */
    pattern?: string | null;
}
export interface GetSettingUrlIgnorePatternRequest {
    /** Identifier. */
    accountId: string;
    /** URL ignore pattern identifier. */
    patternId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingUrlIgnorePatternResponse {
    /** URL ignore pattern identifier. */
    id: string;
    createdAt: string;
    /** Regular expression identifying URLs to exempt from rewriting. */
    pattern: string;
    /** Optional note describing the reason for the ignore pattern. */
    comments?: string | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export type InvestigateBulkMessagesListRequestStatus = "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED" | "SKIPPED";
export interface ListInvestigateBulkMessagesRequest {
    /** Identifier. */
    accountId: string;
    /** Bulk action job identifier. */
    jobId: string;
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Filter the job's messages by their processing status. */
    status?: InvestigateBulkMessagesListRequestStatus | (string & {});
}
export type InvestigateBulkMessagesListResultItemActionParamsMoveDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export type InvestigateBulkMessagesListResultItemActionParamsMoveType = "MOVE";
export type InvestigateBulkMessagesListResultItemActionParamsMoveExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export interface InvestigateBulkMessagesListResultItemActionParamsMove {
    clientRecipient: string;
    /** The mailbox folder to move messages to. */
    destination: InvestigateBulkMessagesListResultItemActionParamsMoveDestination;
    type: InvestigateBulkMessagesListResultItemActionParamsMoveType;
    /** This field is nonfunctional. */
    expectedDisposition?: InvestigateBulkMessagesListResultItemActionParamsMoveExpectedDisposition | null;
}
export type InvestigateBulkMessagesListResultItemActionParamsReleaseType = "RELEASE";
export interface InvestigateBulkMessagesListResultItemActionParamsRelease {
    clientRecipient: string;
    type: InvestigateBulkMessagesListResultItemActionParamsReleaseType;
}
export type InvestigateBulkMessagesListResultItemActionParams = InvestigateBulkMessagesListResultItemActionParamsMove | InvestigateBulkMessagesListResultItemActionParamsRelease;
export type InvestigateBulkMessagesListResultItemActionType = "MOVE" | "RELEASE";
export type InvestigateBulkMessagesListResultItemStatus = "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED" | "SKIPPED";
export type InvestigateBulkMessagesListResultItemMessageActionLogItemOperation = "MOVE" | "RELEASE" | "RECLASSIFY" | "SUBMISSION" | "QUARANTINE_RELEASE" | "PREVIEW";
export type InvestigateBulkMessagesListResultItemMessageActionLogItemProperties = InvestigateGetResponseActionLogItemProperties;
export interface InvestigateBulkMessagesListResultItemMessageActionLogItem {
    /** Timestamp when action completed. */
    completedAt: string;
    /** Type of action performed. */
    operation: InvestigateBulkMessagesListResultItemMessageActionLogItemOperation;
    /** Use `completed_at` instead. */
    completedTimestamp?: string | null;
    /** Additional properties for the action. */
    properties?: InvestigateGetResponseActionLogItemProperties | null;
    /** Status of the action. */
    status?: string | null;
}
export type InvestigateBulkMessagesListResultItemMessageActionLogList = Array<InvestigateBulkMessagesListResultItemMessageActionLogItem>;
export type InvestigateBulkMessagesListResultItemMessageClientRecipientsList = Array<string>;
export type InvestigateBulkMessagesListResultItemMessageDetectionReasonsList = Array<string>;
export type InvestigateBulkMessagesListResultItemMessagePropertiesAllowlistedPatternType = "quarantine_release" | "acceptable_sender" | "allowed_sender" | "allowed_recipient" | "domain_similarity" | "domain_recency" | "managed_acceptable_sender" | "outbound_ndr";
export type InvestigateBulkMessagesListResultItemMessagePropertiesWhitelistedPatternType = "quarantine_release" | "acceptable_sender" | "allowed_sender" | "allowed_recipient" | "domain_similarity" | "domain_recency" | "managed_acceptable_sender" | "outbound_ndr";
export interface InvestigateBulkMessagesListResultItemMessageProperties {
    /** Pattern that allowlisted this message. */
    allowlistedPattern?: string | null;
    /** Type of allowlist pattern. */
    allowlistedPatternType?: InvestigateBulkMessagesListResultItemMessagePropertiesAllowlistedPatternType | null;
    /** Whether message was blocklisted. */
    blocklistedMessage?: boolean | null;
    /** Pattern that blocklisted this message. */
    blocklistedPattern?: string | null;
    /** Legacy field for allowlist pattern type. */
    whitelistedPatternType?: InvestigateBulkMessagesListResultItemMessagePropertiesWhitelistedPatternType | null;
}
export type InvestigateBulkMessagesListResultItemMessageDeliveryMode = "DIRECT" | "BCC" | "JOURNAL" | "REVIEW_SUBMISSION" | "DMARC_UNVERIFIED" | "DMARC_FAILURE_REPORT" | "DMARC_AGGREGATE_REPORT" | "THREAT_INTEL_SUBMISSION" | "SIMULATION_SUBMISSION" | "API" | "RETRO_SCAN";
export type InvestigateBulkMessagesListResultItemMessageDeliveryStatusItem = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued" | "move_failed";
export type InvestigateBulkMessagesListResultItemMessageDeliveryStatusList = Array<InvestigateBulkMessagesListResultItemMessageDeliveryStatusItem>;
export type InvestigateBulkMessagesListResultItemMessageEnvelopeToList = Array<string>;
export type InvestigateBulkMessagesListResultItemMessageFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type InvestigateBulkMessagesListResultItemMessageFindingsItemDetection = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export interface InvestigateBulkMessagesListResultItemMessageFindingsItem {
    attachment?: string | null;
    detail?: string | null;
    /** The verdict Email Security assigns to a message. */
    detection?: InvestigateBulkMessagesListResultItemMessageFindingsItemDetection | null;
    field?: string | null;
    name?: string | null;
    portion?: string | null;
    reason?: string | null;
    score?: number | null;
    value?: string | null;
}
export type InvestigateBulkMessagesListResultItemMessageFindingsList = Array<InvestigateBulkMessagesListResultItemMessageFindingsItem>;
export type InvestigateBulkMessagesListResultItemMessagePostDeliveryOperationsItem = "PREVIEW" | "QUARANTINE_RELEASE" | "SUBMISSION" | "MOVE";
export type InvestigateBulkMessagesListResultItemMessagePostDeliveryOperationsList = Array<InvestigateBulkMessagesListResultItemMessagePostDeliveryOperationsItem>;
export type InvestigateBulkMessagesListResultItemMessageThreatCategoriesList = Array<string>;
export type InvestigateBulkMessagesListResultItemMessageToList = Array<string>;
export type InvestigateBulkMessagesListResultItemMessageToNameList = Array<string>;
export interface InvestigateBulkMessagesListResultItemMessage {
    /** Unique identifier for a message retrieved from investigation. */
    id: string;
    /** Use GET /investigate/{investigate_id}/action_log instead. */
    actionLog: InvestigateBulkMessagesListResultItemMessageActionLogList;
    clientRecipients: InvestigateBulkMessagesListResultItemMessageClientRecipientsList;
    detectionReasons: InvestigateBulkMessagesListResultItemMessageDetectionReasonsList;
    isPhishSubmission: boolean;
    isQuarantined: boolean;
    /** The identifier of the message. */
    postfixId: string;
    /** Message processing properties. */
    properties: InvestigateBulkMessagesListResultItemMessageProperties;
    /** Use `scanned_at` instead. */
    ts: string;
    alertId?: string | null;
    deliveryMode?: InvestigateBulkMessagesListResultItemMessageDeliveryMode | null;
    deliveryStatus?: InvestigateBulkMessagesListResultItemMessageDeliveryStatusList | null;
    edfHash?: string | null;
    envelopeFrom?: string | null;
    envelopeTo?: InvestigateBulkMessagesListResultItemMessageEnvelopeToList | null;
    /** The verdict Email Security assigns to a message. */
    finalDisposition?: InvestigateBulkMessagesListResultItemMessageFinalDisposition | null;
    /** Use the `findings` field from GET /investigate/{investigate_id}/detections instead. */
    findings?: InvestigateBulkMessagesListResultItemMessageFindingsList | null;
    from?: string | null;
    fromName?: string | null;
    htmltextStructureHash?: string | null;
    messageId?: string | null;
    /** Post-delivery operations performed on this message. */
    postDeliveryOperations?: InvestigateBulkMessagesListResultItemMessagePostDeliveryOperationsList | null;
    postfixIdOutbound?: string | null;
    replyto?: string | null;
    /** When the message was scanned (UTC). */
    scannedAt?: string | null;
    /** When the message was sent (UTC). */
    sentAt?: string | null;
    sentDate?: string | null;
    smtpHeloServerIp?: string | null;
    smtpPreviousHopIp?: string | null;
    subject?: string | null;
    threatCategories?: InvestigateBulkMessagesListResultItemMessageThreatCategoriesList | null;
    to?: InvestigateBulkMessagesListResultItemMessageToList | null;
    toName?: InvestigateBulkMessagesListResultItemMessageToNameList | null;
    validation?: unknown | null;
    xOriginatingIp?: string | null;
}
export interface InvestigateBulkMessagesListResultItem {
    actionParams: InvestigateBulkMessagesListResultItemActionParams;
    actionType: InvestigateBulkMessagesListResultItemActionType;
    createdAt: string;
    messageId: string;
    postfixId: string;
    retryCount: number;
    /** Status of a message within a bulk action job. */
    status: InvestigateBulkMessagesListResultItemStatus;
    alertId?: string | null;
    emailMessageId?: string | null;
    message?: InvestigateBulkMessagesListResultItemMessage | null;
    processedAt?: string | null;
    /** When to retry the action if it failed. */
    retryAfter?: string | null;
    statusMessage?: string | null;
}
export type InvestigateBulkMessagesListResultList = Array<InvestigateBulkMessagesListResultItem>;
export interface ListInvestigateBulkMessagesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvestigateBulkMessagesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type InvestigateBulkListRequestActionType = "MOVE" | "RELEASE";
export type InvestigateBulkListRequestStatus = "PENDING" | "DISCOVERING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED";
export interface ListInvestigateBulksRequest {
    /** Identifier. */
    accountId: string;
    /** Filter jobs by the action they perform. */
    actionType?: InvestigateBulkListRequestActionType | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Filter jobs by their processing status. */
    status?: InvestigateBulkListRequestStatus | (string & {});
}
export type InvestigateBulkListResultItemActionParamsMoveDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export type InvestigateBulkListResultItemActionParamsMoveType = "MOVE";
export type InvestigateBulkListResultItemActionParamsMoveExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export interface InvestigateBulkListResultItemActionParamsMove {
    /** The mailbox folder to move messages to. */
    destination: InvestigateBulkListResultItemActionParamsMoveDestination;
    type: InvestigateBulkListResultItemActionParamsMoveType;
    /** This field is nonfunctional. */
    expectedDisposition?: InvestigateBulkListResultItemActionParamsMoveExpectedDisposition | null;
}
export type InvestigateBulkListResultItemActionParamsReleaseType = "RELEASE";
export interface InvestigateBulkListResultItemActionParamsRelease {
    type: InvestigateBulkListResultItemActionParamsReleaseType;
}
export type InvestigateBulkListResultItemActionParams = InvestigateBulkListResultItemActionParamsMove | InvestigateBulkListResultItemActionParamsRelease;
export type InvestigateBulkListResultItemActionType = "MOVE" | "RELEASE";
export type InvestigateBulkListResultItemSearchParamsDeliveryStatus = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued" | "move_failed";
export type InvestigateBulkListResultItemSearchParamsFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type InvestigateBulkListResultItemSearchParamsMessageAction = "PREVIEW" | "QUARANTINE_RELEASED" | "MOVED";
export interface InvestigateBulkListResultItemSearchParams {
    /** Use GET /investigate/{investigate_id}/action_log instead. */
    actionLog?: boolean | null;
    /** Alert ID of the detection to filter by. */
    alertId?: string | null;
    /** Delivery status to filter by. */
    deliveryStatus?: InvestigateBulkListResultItemSearchParamsDeliveryStatus | null;
    /** Whether to include only detections in search results. */
    detectionsOnly?: boolean | null;
    /** Match messages that mention this domain -- sender domain, recipient domain, or a domain in a link. */
    domain?: string | null;
    /** End of search date range. */
    end?: string | null;
    /** Match messages whose subject line equals this value exactly. */
    exactSubject?: string | null;
    /** Dispositions to filter by. */
    finalDisposition?: InvestigateBulkListResultItemSearchParamsFinalDisposition | null;
    /** Message actions to filter by. */
    messageAction?: InvestigateBulkListResultItemSearchParamsMessageAction | null;
    /** Message-ID header value to filter by. */
    messageId?: string | null;
    /** Metric name to filter the search by. */
    metric?: string | null;
    /** Space-delimited search term. Case-insensitive. */
    query?: string | null;
    /** Match messages whose recipient is this email address or domain. */
    recipient?: string | null;
    /** Match messages whose sender is this email address or domain. */
    sender?: string | null;
    /** Matches messages whose SMTP HELO server IP address equals this value. */
    smtpHeloIp?: string | null;
    /** Beginning of search date range. */
    start?: string | null;
    /** Match messages whose subject contains these keywords, in any order. */
    subject?: string | null;
    /** Whether to search reclassification submissions instead of original messages. */
    submissions?: boolean | null;
}
export type InvestigateBulkListResultItemStatus = "PENDING" | "DISCOVERING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED";
export interface InvestigateBulkListResultItem {
    actionParams: InvestigateBulkListResultItemActionParams;
    actionType: InvestigateBulkListResultItemActionType;
    createdAt: string;
    jobId: string;
    /** Messages that were cancelled: rows cancelled via the API before being claimed, and rows whose in-flight attempt ended when the job reached a terminal state. Together the counters satisfy total_messages_discovered = messages_pending + messages_successful + messages_failed + messages_skipped + messages_cancelled. */
    messagesCancelled: number;
    messagesFailed: number;
    messagesPending: number;
    /** Messages that discovery skipped (for example, phish submissions, which the job cannot action). */
    messagesSkipped: number;
    messagesSuccessful: number;
    searchParams: InvestigateBulkListResultItemSearchParams;
    /** Status of a bulk action job. */
    status: InvestigateBulkListResultItemStatus;
    totalMessagesDiscovered: number;
    comment?: string | null;
    completedAt?: string | null;
    startedAt?: string | null;
    statusMessage?: string | null;
}
export type InvestigateBulkListResultList = Array<InvestigateBulkListResultItem>;
export interface ListInvestigateBulksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvestigateBulkListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type InvestigateListRequestDeliveryStatus = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued" | "move_failed";
export type InvestigateListRequestFinalDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export type InvestigateListRequestMessageAction = "PREVIEW" | "QUARANTINE_RELEASED" | "MOVED";
export interface ListInvestigatesRequest {
    /** Identifier. */
    accountId: string;
    /** Filter by alert ID. */
    alertId?: string;
    /** Pagination cursor from the previous response's `result_info`. */
    cursor?: string;
    /** Delivery status to filter by. */
    deliveryStatus?: InvestigateListRequestDeliveryStatus | (string & {});
    /** Whether to include only detections in search results. */
    detectionsOnly?: boolean;
    /** Filter by a domain found in the email -- sender domain, recipient domain, or a domain in a link. */
    domain?: string;
    /** The end of the search date range. Defaults to `now`. */
    end?: string;
    /** Dispositions to filter by. */
    finalDisposition?: InvestigateListRequestFinalDisposition | (string & {});
    /** Message actions to filter by. */
    messageAction?: InvestigateListRequestMessageAction | (string & {});
    /** Filter by the RFC 5322 Message-ID header. */
    messageId?: string;
    /** Metric to aggregate the results by. */
    metric?: string;
    /** Deprecated: Use cursor pagination instead. End of life: November 1, 2026. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Space-delimited term matched case-insensitively against message metadata -- sender, recipient, subject, attachment names and hashes, and message ID. */
    query?: string;
    /** Filter by recipient. Matches an email address or a domain. */
    recipient?: string;
    /** Filter by sender. Matches an email address or a domain. */
    sender?: string;
    /** Matches messages whose SMTP HELO server IP address equals this value. */
    smtpHeloIp?: string;
    /** The beginning of the search date range. Defaults to `now - 30 days`. Must not be in the future. */
    start?: string;
    /** Search for messages containing individual keywords in any order within the subject. */
    subject?: string;
}
export type InvestigateListResultItemActionLogItemOperation = "MOVE" | "RELEASE" | "RECLASSIFY" | "SUBMISSION" | "QUARANTINE_RELEASE" | "PREVIEW";
export type InvestigateListResultItemActionLogItemProperties = InvestigateGetResponseActionLogItemProperties;
export interface InvestigateListResultItemActionLogItem {
    /** Timestamp when action completed. */
    completedAt: string;
    /** Type of action performed. */
    operation: InvestigateListResultItemActionLogItemOperation;
    /** Use `completed_at` instead. */
    completedTimestamp?: string | null;
    /** Additional properties for the action. */
    properties?: InvestigateGetResponseActionLogItemProperties | null;
    /** Status of the action. */
    status?: string | null;
}
export type InvestigateListResultItemActionLogList = Array<InvestigateListResultItemActionLogItem>;
export type InvestigateListResultItemClientRecipientsList = Array<string>;
export type InvestigateListResultItemDetectionReasonsList = Array<string>;
export type InvestigateListResultItemPropertiesAllowlistedPatternType = "quarantine_release" | "acceptable_sender" | "allowed_sender" | "allowed_recipient" | "domain_similarity" | "domain_recency" | "managed_acceptable_sender" | "outbound_ndr";
export type InvestigateListResultItemPropertiesWhitelistedPatternType = "quarantine_release" | "acceptable_sender" | "allowed_sender" | "allowed_recipient" | "domain_similarity" | "domain_recency" | "managed_acceptable_sender" | "outbound_ndr";
export interface InvestigateListResultItemProperties {
    /** Pattern that allowlisted this message. */
    allowlistedPattern?: string | null;
    /** Type of allowlist pattern. */
    allowlistedPatternType?: InvestigateListResultItemPropertiesAllowlistedPatternType | null;
    /** Whether message was blocklisted. */
    blocklistedMessage?: boolean | null;
    /** Pattern that blocklisted this message. */
    blocklistedPattern?: string | null;
    /** Legacy field for allowlist pattern type. */
    whitelistedPatternType?: InvestigateListResultItemPropertiesWhitelistedPatternType | null;
}
export type InvestigateListResultItemDeliveryMode = "DIRECT" | "BCC" | "JOURNAL" | "REVIEW_SUBMISSION" | "DMARC_UNVERIFIED" | "DMARC_FAILURE_REPORT" | "DMARC_AGGREGATE_REPORT" | "THREAT_INTEL_SUBMISSION" | "SIMULATION_SUBMISSION" | "API" | "RETRO_SCAN";
export type InvestigateListResultItemDeliveryStatusItem = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued" | "move_failed";
export type InvestigateListResultItemDeliveryStatusList = Array<InvestigateListResultItemDeliveryStatusItem>;
export type InvestigateListResultItemEnvelopeToList = Array<string>;
export type InvestigateListResultItemFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type InvestigateListResultItemFindingsItemDetection = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export interface InvestigateListResultItemFindingsItem {
    attachment?: string | null;
    detail?: string | null;
    /** The verdict Email Security assigns to a message. */
    detection?: InvestigateListResultItemFindingsItemDetection | null;
    field?: string | null;
    name?: string | null;
    portion?: string | null;
    reason?: string | null;
    score?: number | null;
    value?: string | null;
}
export type InvestigateListResultItemFindingsList = Array<InvestigateListResultItemFindingsItem>;
export type InvestigateListResultItemPostDeliveryOperationsItem = "PREVIEW" | "QUARANTINE_RELEASE" | "SUBMISSION" | "MOVE";
export type InvestigateListResultItemPostDeliveryOperationsList = Array<InvestigateListResultItemPostDeliveryOperationsItem>;
export type InvestigateListResultItemThreatCategoriesList = Array<string>;
export type InvestigateListResultItemToList = Array<string>;
export type InvestigateListResultItemToNameList = Array<string>;
export interface InvestigateListResultItem {
    /** Unique identifier for a message retrieved from investigation. */
    id: string;
    /** Use GET /investigate/{investigate_id}/action_log instead. */
    actionLog: InvestigateListResultItemActionLogList;
    clientRecipients: InvestigateListResultItemClientRecipientsList;
    detectionReasons: InvestigateListResultItemDetectionReasonsList;
    isPhishSubmission: boolean;
    isQuarantined: boolean;
    /** The identifier of the message. */
    postfixId: string;
    /** Message processing properties. */
    properties: InvestigateListResultItemProperties;
    /** Use `scanned_at` instead. */
    ts: string;
    alertId?: string | null;
    deliveryMode?: InvestigateListResultItemDeliveryMode | null;
    deliveryStatus?: InvestigateListResultItemDeliveryStatusList | null;
    edfHash?: string | null;
    envelopeFrom?: string | null;
    envelopeTo?: InvestigateListResultItemEnvelopeToList | null;
    /** The verdict Email Security assigns to a message. */
    finalDisposition?: InvestigateListResultItemFinalDisposition | null;
    /** Use the `findings` field from GET /investigate/{investigate_id}/detections instead. */
    findings?: InvestigateListResultItemFindingsList | null;
    from?: string | null;
    fromName?: string | null;
    htmltextStructureHash?: string | null;
    messageId?: string | null;
    /** Post-delivery operations performed on this message. */
    postDeliveryOperations?: InvestigateListResultItemPostDeliveryOperationsList | null;
    postfixIdOutbound?: string | null;
    replyto?: string | null;
    /** When the message was scanned (UTC). */
    scannedAt?: string | null;
    /** When the message was sent (UTC). */
    sentAt?: string | null;
    sentDate?: string | null;
    smtpHeloServerIp?: string | null;
    smtpPreviousHopIp?: string | null;
    subject?: string | null;
    threatCategories?: InvestigateListResultItemThreatCategoriesList | null;
    to?: InvestigateListResultItemToList | null;
    toName?: InvestigateListResultItemToNameList | null;
    validation?: unknown | null;
    xOriginatingIp?: string | null;
}
export type InvestigateListResultList = Array<InvestigateListResultItem>;
export interface ListInvestigatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvestigateListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListPhishguardReportsRequest {
    /** Identifier. */
    accountId: string;
    /** End of the time range (RFC3339). Takes precedence over to_date. */
    end?: string;
    /** Deprecated, use `start` instead. Start date in YYYY-MM-DD format. */
    fromDate?: string;
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Start of the time range (RFC3339). Takes precedence over from_date. */
    start?: string;
    /** Deprecated, use `end` instead. End date in YYYY-MM-DD format. */
    toDate?: string;
}
export type PhishguardReportsListResultItemDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type PhishguardReportsListResultItemFieldsToList = Array<string>;
export interface PhishguardReportsListResultItemFields {
    to: PhishguardReportsListResultItemFieldsToList;
    from?: string | null;
    occurredAt?: string | null;
    postfixId?: string | null;
    /** Use `occurred_at` instead. */
    ts?: string | null;
}
export interface PhishguardReportsListResultItemTagsItem {
    category: string;
    value: string;
}
export type PhishguardReportsListResultItemTagsList = Array<PhishguardReportsListResultItemTagsItem>;
export interface PhishguardReportsListResultItem {
    id: number;
    content: string;
    /** The verdict Email Security assigns to a message. */
    disposition: PhishguardReportsListResultItemDisposition;
    fields: PhishguardReportsListResultItemFields;
    priority: string;
    title: string;
    createdAt?: string | null;
    tags?: PhishguardReportsListResultItemTagsList | null;
    /** Use `created_at` instead. */
    ts?: string | null;
    updatedAt?: string | null;
}
export type PhishguardReportsListResultList = Array<PhishguardReportsListResultItem>;
export interface ListPhishguardReportsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PhishguardReportsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type SettingsAllowPoliciesListRequestDirection = "asc" | "desc";
export type SettingsAllowPoliciesListRequestOrder = "pattern" | "created_at";
export type SettingsAllowPoliciesListRequestPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface ListSettingAllowPoliciesRequest {
    /** Identifier. */
    accountId: string;
    /** The sorting direction. */
    direction?: SettingsAllowPoliciesListRequestDirection | (string & {});
    /** Filter to return only expired policies (`true`) or only policies that still apply (`false`). Omit to return both. */
    expired?: boolean;
    /** Filter to show only policies where messages from the sender are exempted from Spam, Spoof, and Bulk dispositions (not Malicious or Suspicious). */
    isAcceptableSender?: boolean;
    /** Filter to show only policies where messages to the recipient bypass all detections. */
    isExemptRecipient?: boolean;
    /** Filter to show only policies where messages from the sender bypass all detections and link following. */
    isTrustedSender?: boolean;
    /** Field to sort by. */
    order?: SettingsAllowPoliciesListRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** Filter by exact pattern value. */
    pattern?: string;
    /** Filter by pattern type. */
    patternType?: SettingsAllowPoliciesListRequestPatternType | (string & {});
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Search term for filtering records. Behavior may change. */
    search?: string;
    /** Filter to show only policies that enforce DMARC, SPF, or DKIM authentication. */
    verifySender?: boolean;
}
export type SettingsAllowPoliciesListResultItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsAllowPoliciesListResultItem {
    /** Allow policy identifier. */
    id: string;
    createdAt: string;
    /** Use `modified_at` instead. */
    lastModified: string;
    comments?: string | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Exempts messages from this sender from Spam, Spoof and Bulk dispositions only; Malicious and Suspicious dispositions still apply. */
    isAcceptableSender?: boolean | null;
    /** Bypasses all detections for messages to this recipient. */
    isExemptRecipient?: boolean | null;
    /** Use `is_exempt_recipient` instead. */
    isRecipient?: boolean | null;
    isRegex?: boolean | null;
    /** Use `is_trusted_sender` instead. */
    isSender?: boolean | null;
    /** Use `is_acceptable_sender` instead. */
    isSpoof?: boolean | null;
    /** Bypasses all detections and link following for messages from this sender. */
    isTrustedSender?: boolean | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesListResultItemPatternType | null;
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean | null;
}
export type SettingsAllowPoliciesListResultList = Array<SettingsAllowPoliciesListResultItem>;
export interface ListSettingAllowPoliciesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsAllowPoliciesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type SettingsBlockSendersListRequestDirection = "asc" | "desc";
export type SettingsBlockSendersListRequestOrder = "pattern" | "created_at";
export type SettingsBlockSendersListRequestPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface ListSettingBlockSendersRequest {
    /** Identifier. */
    accountId: string;
    /** The sorting direction. */
    direction?: SettingsBlockSendersListRequestDirection | (string & {});
    /** Filter to return only expired patterns (`true`) or only patterns that still apply (`false`). Omit to return both. */
    expired?: boolean;
    /** Field to sort by. */
    order?: SettingsBlockSendersListRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** Filter by pattern value. */
    pattern?: string;
    /** Filter by pattern type. */
    patternType?: SettingsBlockSendersListRequestPatternType | (string & {});
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Search term for filtering records. Behavior may change. */
    search?: string;
}
export type SettingsBlockSendersListResultItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsBlockSendersListResultItem {
    /** Blocked sender pattern identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Timestamp at which the pattern expires. After this time, Email Security ignores the pattern. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Whether `pattern` is a regular expression instead of a literal value. */
    isRegex?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersListResultItemPatternType | null;
}
export type SettingsBlockSendersListResultList = Array<SettingsBlockSendersListResultItem>;
export interface ListSettingBlockSendersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsBlockSendersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type SettingsDomainsListRequestActiveDeliveryMode = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type SettingsDomainsListRequestAllowedDeliveryMode = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type SettingsDomainsListRequestDirection = "asc" | "desc";
export type SettingsDomainsListRequestDomainList = Array<string>;
export type SettingsDomainsListRequestOrder = "domain" | "created_at";
export type SettingsDomainsListRequestStatus = "PENDING" | "ACTIVE" | "FAILED" | "TIMEOUT";
export interface ListSettingDomainsRequest {
    /** Identifier. */
    accountId: string;
    /** Currently active delivery mode to filter by. */
    activeDeliveryMode?: SettingsDomainsListRequestActiveDeliveryMode | (string & {});
    /** Delivery mode to filter by. */
    allowedDeliveryMode?: SettingsDomainsListRequestAllowedDeliveryMode | (string & {});
    /** The sorting direction. */
    direction?: SettingsDomainsListRequestDirection | (string & {});
    /** Domain names to filter by. */
    domain?: SettingsDomainsListRequestDomainList;
    /** Integration ID to filter by. */
    integrationId?: string;
    /** Field to sort by. */
    order?: SettingsDomainsListRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Search term for filtering records. Behavior may change. */
    search?: string;
    /** Filters response to domains with the provided status. */
    status?: SettingsDomainsListRequestStatus | (string & {});
}
export type SettingsDomainsListResultItemAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type SettingsDomainsListResultItemAllowedDeliveryModesList = Array<SettingsDomainsListResultItemAllowedDeliveryModesItem>;
export type SettingsDomainsListResultItemAuthorization = CreateSettingsDomainResponseAuthorization;
export type SettingsDomainsListResultItemDmarcStatus = "none" | "good" | "invalid";
export type SettingsDomainsListResultItemDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type SettingsDomainsListResultItemDropDispositionsList = Array<SettingsDomainsListResultItemDropDispositionsItem>;
export type SettingsDomainsListResultItemEmailsProcessed = CreateSettingsDomainResponseEmailsProcessed;
export type SettingsDomainsListResultItemFolder = "AllItems" | "Inbox";
export type SettingsDomainsListResultItemInboxProvider = "Microsoft" | "Google";
export type SettingsDomainsListResultItemIpRestrictionsList = Array<string>;
export type SettingsDomainsListResultItemRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type SettingsDomainsListResultItemRegionsList = Array<SettingsDomainsListResultItemRegionsItem>;
export type SettingsDomainsListResultItemSpfStatus = "none" | "good" | "neutral" | "open" | "invalid";
export type SettingsDomainsListResultItemStatus = "PENDING" | "ACTIVE" | "FAILED" | "TIMEOUT";
export interface SettingsDomainsListResultItem {
    /** Domain identifier. */
    id?: string | null;
    allowedDeliveryModes?: SettingsDomainsListResultItemAllowedDeliveryModesList | null;
    authorization?: CreateSettingsDomainResponseAuthorization | null;
    createdAt?: string | null;
    dmarcStatus?: SettingsDomainsListResultItemDmarcStatus | null;
    domain?: string | null;
    dropDispositions?: SettingsDomainsListResultItemDropDispositionsList | null;
    emailsProcessed?: CreateSettingsDomainResponseEmailsProcessed | null;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: SettingsDomainsListResultItemFolder | null;
    inboxProvider?: SettingsDomainsListResultItemInboxProvider | null;
    integrationId?: string | null;
    ipRestrictions?: SettingsDomainsListResultItemIpRestrictionsList | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    lookbackHops?: number | null;
    modifiedAt?: string | null;
    o365TenantId?: string | null;
    regions?: SettingsDomainsListResultItemRegionsList | null;
    requireTlsInbound?: boolean | null;
    requireTlsOutbound?: boolean | null;
    spfStatus?: SettingsDomainsListResultItemSpfStatus | null;
    status?: SettingsDomainsListResultItemStatus | null;
    transport?: string | null;
}
export type SettingsDomainsListResultList = Array<SettingsDomainsListResultItem>;
export interface ListSettingDomainsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsDomainsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type SettingsImpersonationRegistryListRequestDirection = "asc" | "desc";
export type SettingsImpersonationRegistryListRequestOrder = "name" | "email" | "created_at";
export type SettingsImpersonationRegistryListRequestProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
export interface ListSettingImpersonationRegistriesRequest {
    /** Identifier. */
    accountId: string;
    /** The sorting direction. */
    direction?: SettingsImpersonationRegistryListRequestDirection | (string & {});
    /** Field to sort by. */
    order?: SettingsImpersonationRegistryListRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    provenance?: SettingsImpersonationRegistryListRequestProvenance | (string & {});
    /** Search term for filtering records. Behavior may change. */
    search?: string;
}
export type SettingsImpersonationRegistryListResultItemProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
export interface SettingsImpersonationRegistryListResultItem {
    /** Impersonation registry entry identifier. */
    id?: string | null;
    /** Optional note describing the entry. */
    comments?: string | null;
    createdAt?: string | null;
    /** Identifier of the directory the entry was synced from, when directory-synced. */
    directoryId?: number | null;
    /** Identifier of the directory node the entry was synced from, when directory-synced. */
    directoryNodeId?: number | null;
    /** Email address (or pattern) of the protected identity. */
    email?: string | null;
    /** This field is deprecated. */
    externalDirectoryNodeId?: string | null;
    /** Whether `email` is a regular expression instead of a literal address. */
    isEmailRegex?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** Display name of the protected identity. */
    name?: string | null;
    /** Source the entry was created from. */
    provenance?: SettingsImpersonationRegistryListResultItemProvenance | null;
}
export type SettingsImpersonationRegistryListResultList = Array<SettingsImpersonationRegistryListResultItem>;
export interface ListSettingImpersonationRegistriesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsImpersonationRegistryListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type ListSettingsContentPoliciesRequestDirection = "asc" | "desc";
export type ListSettingsContentPoliciesRequestOrder = "name" | "created_at";
export interface ListSettingsContentPoliciesRequest {
    /** Identifier. */
    accountId: string;
    /** The sorting direction. */
    direction?: ListSettingsContentPoliciesRequestDirection | (string & {});
    /** Filter by enabled status. */
    enabled?: boolean;
    /** Filter to return only expired policies (`true`) or only policies that still apply (`false`). Omit to return both. */
    expired?: boolean;
    /** Filter by exact policy name. */
    name?: string;
    /** Field to sort by. */
    order?: ListSettingsContentPoliciesRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Search term for filtering records. Behavior may change. */
    search?: string;
}
export type ListSettingsContentPoliciesResultItemTargetsItem = "SUBJECT" | "BODY";
export type ListSettingsContentPoliciesResultItemTargetsList = Array<ListSettingsContentPoliciesResultItemTargetsItem>;
export interface ListSettingsContentPoliciesResultItem {
    /** Content policy identifier. */
    id?: string | null;
    createdAt?: string | null;
    /** Whether the policy is active. */
    enabled?: boolean | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    modifiedAt?: string | null;
    /** Human-readable name of the policy. */
    name?: string | null;
    /** Optional note describing the purpose of the policy. */
    notes?: string | null;
    /** Regular expression the policy matches against. */
    pattern?: string | null;
    /** Parts of the email the pattern is matched against. */
    targets?: ListSettingsContentPoliciesResultItemTargetsList | null;
}
export type ListSettingsContentPoliciesResultList = Array<ListSettingsContentPoliciesResultItem>;
export type ListSettingsContentPoliciesResponse = ListSettingsContentPoliciesResultList;
export type SettingsSendingDomainRestrictionsListRequestDirection = "asc" | "desc";
export type SettingsSendingDomainRestrictionsListRequestOrder = "domain" | "created_at";
export interface ListSettingSendingDomainRestrictionsRequest {
    /** Identifier. */
    accountId: string;
    /** The sorting direction. */
    direction?: SettingsSendingDomainRestrictionsListRequestDirection | (string & {});
    /** Field to sort by. */
    order?: SettingsSendingDomainRestrictionsListRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Search term for filtering records. Behavior may change. */
    search?: string;
}
export type SettingsSendingDomainRestrictionsListResultItemExcludeList = Array<string>;
export interface SettingsSendingDomainRestrictionsListResultItem {
    /** Sending domain restriction identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Domain that requires TLS enforcement. */
    domain?: string | null;
    /** Subdomains to exempt from TLS requirements. */
    exclude?: SettingsSendingDomainRestrictionsListResultItemExcludeList | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export type SettingsSendingDomainRestrictionsListResultList = Array<SettingsSendingDomainRestrictionsListResultItem>;
export interface ListSettingSendingDomainRestrictionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsSendingDomainRestrictionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type SettingsTrustedDomainsListRequestDirection = "asc" | "desc";
export type SettingsTrustedDomainsListRequestOrder = "pattern" | "created_at";
export interface ListSettingTrustedDomainsRequest {
    /** Identifier. */
    accountId: string;
    /** The sorting direction. */
    direction?: SettingsTrustedDomainsListRequestDirection | (string & {});
    /** Filter to show only recently registered domains that are trusted to prevent triggering Suspicious or Malicious dispositions. */
    isRecent?: boolean;
    /** Filter to show only proximity domains (partner or approved domains with similar spelling to connected domains) that prevent Spoof dispositions. */
    isSimilarity?: boolean;
    /** Field to sort by. */
    order?: SettingsTrustedDomainsListRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    pattern?: string;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Search term for filtering records. Behavior may change. */
    search?: string;
}
export interface SettingsTrustedDomainsListResultItem {
    /** Trusted domain identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent?: boolean | null;
    /** Whether `pattern` is a regular expression instead of a literal domain. */
    isRegex?: boolean | null;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** The domain pattern to trust, e.g. `example.com`. */
    pattern?: string | null;
}
export type SettingsTrustedDomainsListResultList = Array<SettingsTrustedDomainsListResultItem>;
export interface ListSettingTrustedDomainsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsTrustedDomainsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListSettingUrlIgnorePatternsRequest {
    /** Identifier. */
    accountId: string;
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
}
export interface SettingsUrlIgnorePatternsListResultItem {
    /** URL ignore pattern identifier. */
    id: string;
    createdAt: string;
    /** Regular expression identifying URLs to exempt from rewriting. */
    pattern: string;
    /** Optional note describing the reason for the ignore pattern. */
    comments?: string | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export type SettingsUrlIgnorePatternsListResultList = Array<SettingsUrlIgnorePatternsListResultItem>;
export interface ListSettingUrlIgnorePatternsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsUrlIgnorePatternsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type SubmissionsListRequestDirection = "asc" | "desc";
export type SubmissionsListRequestOrder = "submission_id" | "subject" | "original_disposition" | "requested_disposition" | "outcome_disposition" | "requested_at";
export type SubmissionsListRequestOriginalDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export type SubmissionsListRequestOutcomeDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export type SubmissionsListRequestRequestedDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export type SubmissionsListRequestType = "TEAM" | "USER";
export interface ListSubmissionsRequest {
    /** Identifier. */
    accountId: string;
    /** The sorting direction. */
    direction?: SubmissionsListRequestDirection | (string & {});
    /** The end of the search date range. Defaults to `now`. */
    end?: string;
    /** When true, return only submissions that were escalated by an end user (vs. by the security team). When false, return only submissions that were not escalated by an end user. When omitted, no filter is applied. */
    escalatedFromUser?: boolean;
    /** Field to sort by. */
    order?: SubmissionsListRequestOrder | (string & {});
    /** The disposition a message is submitted to have. */
    originalDisposition?: SubmissionsListRequestOriginalDisposition | (string & {});
    /** The disposition a message is submitted to have. */
    outcomeDisposition?: SubmissionsListRequestOutcomeDisposition | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Search term for filtering submissions. */
    query?: string;
    /** The disposition a message is submitted to have. */
    requestedDisposition?: SubmissionsListRequestRequestedDisposition | (string & {});
    /** The beginning of the search date range. Defaults to `now - 30 days`. */
    start?: string;
    /** Filter by review status -- `escalated`, `reviewed`, or `unreviewed`. */
    status?: string;
    /** Filter by a specific submission ID. */
    submissionId?: string;
    /** Filter by who created the submission -- `TEAM` for security team members or `USER` for end users. */
    type?: SubmissionsListRequestType | (string & {});
}
export type SubmissionsListResultItemCustomerStatus = "escalated" | "reviewed" | "unreviewed";
export type SubmissionsListResultItemEscalatedAs = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export type SubmissionsListResultItemOriginalDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export type SubmissionsListResultItemOutcomeDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export type SubmissionsListResultItemRequestedDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export type SubmissionsListResultItemType = "Team" | "User";
export interface SubmissionsListResultItem {
    /** When the submission was requested (UTC). */
    requestedAt: string;
    submissionId: string;
    customerStatus?: SubmissionsListResultItemCustomerStatus | null;
    /** The disposition a message is submitted to have. */
    escalatedAs?: SubmissionsListResultItemEscalatedAs | null;
    /** When the submission was escalated to the security team. */
    escalatedAt?: string | null;
    /** Email address of the user who escalated the submission. */
    escalatedBy?: string | null;
    /** Submission ID of the escalated team submission, when this user submission was escalated. */
    escalatedSubmissionId?: string | null;
    /** The disposition a message is submitted to have. */
    originalDisposition?: SubmissionsListResultItemOriginalDisposition | null;
    /** EDF hash of the original message. */
    originalEdfHash?: string | null;
    /** The postfix ID of the original message that was submitted. */
    originalPostfixId?: string | null;
    /** Processing outcome of the submission. */
    outcome?: string | null;
    /** The disposition a message is submitted to have. */
    outcomeDisposition?: SubmissionsListResultItemOutcomeDisposition | null;
    /** Email address of the user who requested the submission. */
    requestedBy?: string | null;
    /** The disposition a message is submitted to have. */
    requestedDisposition?: SubmissionsListResultItemRequestedDisposition | null;
    /** Use `requested_at` instead. */
    requestedTs?: string | null;
    /** Processing status of the submission. */
    status?: string | null;
    /** Subject line of the submitted message. */
    subject?: string | null;
    /** Indicates whether a team member or an end user created the submission. */
    type?: SubmissionsListResultItemType | null;
}
export type SubmissionsListResultList = Array<SubmissionsListResultItem>;
export interface ListSubmissionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubmissionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type SettingsAllowPoliciesEditRequestPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface PatchSettingAllowPolicyRequest {
    /** Identifier. */
    accountId: string;
    /** Allow policy identifier. */
    policyId: string;
    comments?: string;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    /** Exempts messages from this sender from Spam, Spoof and Bulk dispositions only; Malicious and Suspicious dispositions still apply. */
    isAcceptableSender?: boolean;
    /** Bypasses all detections for messages to this recipient. */
    isExemptRecipient?: boolean;
    /** Use `is_exempt_recipient` instead. */
    isRecipient?: boolean;
    isRegex?: boolean;
    /** Use `is_trusted_sender` instead. */
    isSender?: boolean;
    /** Use `is_acceptable_sender` instead. */
    isSpoof?: boolean;
    /** Bypasses all detections and link following for messages from this sender. */
    isTrustedSender?: boolean;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesEditRequestPatternType | (string & {});
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean;
}
export type SettingsAllowPoliciesEditResponsePatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingAllowPolicyResponse {
    /** Allow policy identifier. */
    id: string;
    createdAt: string;
    /** Use `modified_at` instead. */
    lastModified: string;
    comments?: string | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Exempts messages from this sender from Spam, Spoof and Bulk dispositions only; Malicious and Suspicious dispositions still apply. */
    isAcceptableSender?: boolean | null;
    /** Bypasses all detections for messages to this recipient. */
    isExemptRecipient?: boolean | null;
    /** Use `is_exempt_recipient` instead. */
    isRecipient?: boolean | null;
    isRegex?: boolean | null;
    /** Use `is_trusted_sender` instead. */
    isSender?: boolean | null;
    /** Use `is_acceptable_sender` instead. */
    isSpoof?: boolean | null;
    /** Bypasses all detections and link following for messages from this sender. */
    isTrustedSender?: boolean | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesEditResponsePatternType | null;
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean | null;
}
export type SettingsBlockSendersEditRequestPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface PatchSettingBlockSenderRequest {
    /** Identifier. */
    accountId: string;
    /** Blocked sender pattern identifier. */
    patternId: string;
    comments?: string;
    /** Timestamp at which the pattern expires. After this time, Email Security ignores the pattern. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    /** Whether `pattern` is a regular expression instead of a literal value. */
    isRegex?: boolean;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersEditRequestPatternType | (string & {});
}
export type SettingsBlockSendersEditResponsePatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingBlockSenderResponse {
    /** Blocked sender pattern identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Timestamp at which the pattern expires. After this time, Email Security ignores the pattern. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Whether `pattern` is a regular expression instead of a literal value. */
    isRegex?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersEditResponsePatternType | null;
}
export type SettingsDomainsEditRequestAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type SettingsDomainsEditRequestAllowedDeliveryModesList = Array<SettingsDomainsEditRequestAllowedDeliveryModesItem | (string & {})>;
export type SettingsDomainsEditRequestDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type SettingsDomainsEditRequestDropDispositionsList = Array<SettingsDomainsEditRequestDropDispositionsItem | (string & {})>;
export type SettingsDomainsEditRequestFolder = "AllItems" | "Inbox";
export type SettingsDomainsEditRequestIpRestrictionsList = Array<string>;
export type SettingsDomainsEditRequestRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type SettingsDomainsEditRequestRegionsList = Array<SettingsDomainsEditRequestRegionsItem | (string & {})>;
export interface PatchSettingDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Domain identifier. */
    domainId: string;
    /** Delivery modes to onboard the domain through. */
    allowedDeliveryModes?: SettingsDomainsEditRequestAllowedDeliveryModesList;
    /** Dispositions to drop instead of delivering, e.g. `["MALICIOUS", "SPAM"]`. */
    dropDispositions?: SettingsDomainsEditRequestDropDispositionsList;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: SettingsDomainsEditRequestFolder | (string & {});
    /** Identifier of the CASB integration that authorizes this domain. The integration also enables API scanning, post-delivery actions, and directory sync. */
    integrationId?: string;
    /** Source IP ranges mail is accepted from. Any other source is rejected. */
    ipRestrictions?: SettingsDomainsEditRequestIpRestrictionsList;
    /** Number of hops to trace back through received headers when reconstructing the original message (1-20). */
    lookbackHops?: number;
    /** Regions that process messages for this domain, e.g. `["GLOBAL"]` or `["US"]`. */
    regions?: SettingsDomainsEditRequestRegionsList;
    /** Require TLS on inbound connections. */
    requireTlsInbound?: boolean;
    /** Require TLS on outbound connections. */
    requireTlsOutbound?: boolean;
    /** The mail transport hostname for MX/Inline delivery -- the MX record Cloudflare delivers email to (e.g. `mx.example.com`). */
    transport?: string;
}
export type SettingsDomainsEditResponseAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type SettingsDomainsEditResponseAllowedDeliveryModesList = Array<SettingsDomainsEditResponseAllowedDeliveryModesItem>;
export type SettingsDomainsEditResponseAuthorization = CreateSettingsDomainResponseAuthorization;
export type SettingsDomainsEditResponseDmarcStatus = "none" | "good" | "invalid";
export type SettingsDomainsEditResponseDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type SettingsDomainsEditResponseDropDispositionsList = Array<SettingsDomainsEditResponseDropDispositionsItem>;
export type SettingsDomainsEditResponseEmailsProcessed = CreateSettingsDomainResponseEmailsProcessed;
export type SettingsDomainsEditResponseFolder = "AllItems" | "Inbox";
export type SettingsDomainsEditResponseInboxProvider = "Microsoft" | "Google";
export type SettingsDomainsEditResponseIpRestrictionsList = Array<string>;
export type SettingsDomainsEditResponseRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type SettingsDomainsEditResponseRegionsList = Array<SettingsDomainsEditResponseRegionsItem>;
export type SettingsDomainsEditResponseSpfStatus = "none" | "good" | "neutral" | "open" | "invalid";
export type SettingsDomainsEditResponseStatus = "PENDING" | "ACTIVE" | "FAILED" | "TIMEOUT";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingDomainResponse {
    /** Domain identifier. */
    id?: string | null;
    allowedDeliveryModes?: SettingsDomainsEditResponseAllowedDeliveryModesList | null;
    authorization?: CreateSettingsDomainResponseAuthorization | null;
    createdAt?: string | null;
    dmarcStatus?: SettingsDomainsEditResponseDmarcStatus | null;
    domain?: string | null;
    dropDispositions?: SettingsDomainsEditResponseDropDispositionsList | null;
    emailsProcessed?: CreateSettingsDomainResponseEmailsProcessed | null;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: SettingsDomainsEditResponseFolder | null;
    inboxProvider?: SettingsDomainsEditResponseInboxProvider | null;
    integrationId?: string | null;
    ipRestrictions?: SettingsDomainsEditResponseIpRestrictionsList | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    lookbackHops?: number | null;
    modifiedAt?: string | null;
    o365TenantId?: string | null;
    regions?: SettingsDomainsEditResponseRegionsList | null;
    requireTlsInbound?: boolean | null;
    requireTlsOutbound?: boolean | null;
    spfStatus?: SettingsDomainsEditResponseSpfStatus | null;
    status?: SettingsDomainsEditResponseStatus | null;
    transport?: string | null;
}
export type SettingsImpersonationRegistryEditRequestProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
export interface PatchSettingImpersonationRegistryRequest {
    /** Identifier. */
    accountId: string;
    /** Impersonation registry entry identifier. */
    impersonationRegistryId: string;
    /** Optional note describing the entry. */
    comments?: string;
    /** Identifier of the directory the entry was synced from, when directory-synced. */
    directoryId?: number;
    /** Identifier of the directory node the entry was synced from, when directory-synced. */
    directoryNodeId?: number;
    /** Email address (or pattern) of the protected identity. */
    email?: string;
    /** This field is deprecated. */
    externalDirectoryNodeId?: string;
    /** Whether `email` is a regular expression instead of a literal address. */
    isEmailRegex?: boolean;
    /** Display name of the protected identity. */
    name?: string;
    /** Source the entry was created from. */
    provenance?: SettingsImpersonationRegistryEditRequestProvenance | (string & {});
}
export type SettingsImpersonationRegistryEditResponseProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingImpersonationRegistryResponse {
    /** Impersonation registry entry identifier. */
    id?: string | null;
    /** Optional note describing the entry. */
    comments?: string | null;
    createdAt?: string | null;
    /** Identifier of the directory the entry was synced from, when directory-synced. */
    directoryId?: number | null;
    /** Identifier of the directory node the entry was synced from, when directory-synced. */
    directoryNodeId?: number | null;
    /** Email address (or pattern) of the protected identity. */
    email?: string | null;
    /** This field is deprecated. */
    externalDirectoryNodeId?: string | null;
    /** Whether `email` is a regular expression instead of a literal address. */
    isEmailRegex?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** Display name of the protected identity. */
    name?: string | null;
    /** Source the entry was created from. */
    provenance?: SettingsImpersonationRegistryEditResponseProvenance | null;
}
export type SettingsSendingDomainRestrictionsEditRequestExcludeList = Array<string>;
export interface PatchSettingSendingDomainRestrictionRequest {
    /** Identifier. */
    accountId: string;
    /** Sending domain restriction identifier. */
    sendingDomainRestrictionId: string;
    comments?: string;
    /** Domain that requires TLS enforcement. */
    domain?: string;
    /** Subdomains to exempt from TLS requirements. */
    exclude?: SettingsSendingDomainRestrictionsEditRequestExcludeList;
}
export type SettingsSendingDomainRestrictionsEditResponseExcludeList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingSendingDomainRestrictionResponse {
    /** Sending domain restriction identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Domain that requires TLS enforcement. */
    domain?: string | null;
    /** Subdomains to exempt from TLS requirements. */
    exclude?: SettingsSendingDomainRestrictionsEditResponseExcludeList | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export interface PatchSettingTrustedDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Trusted domain identifier. */
    trustedDomainId: string;
    comments?: string;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent?: boolean;
    /** Whether `pattern` is a regular expression instead of a literal domain. */
    isRegex?: boolean;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity?: boolean;
    /** The domain pattern to trust, e.g. `example.com`. */
    pattern?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingTrustedDomainResponse {
    /** Trusted domain identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent?: boolean | null;
    /** Whether `pattern` is a regular expression instead of a literal domain. */
    isRegex?: boolean | null;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** The domain pattern to trust, e.g. `example.com`. */
    pattern?: string | null;
}
export interface PatchSettingUrlIgnorePatternRequest {
    /** Identifier. */
    accountId: string;
    /** URL ignore pattern identifier. */
    patternId: string;
    /** Optional note describing the reason for the ignore pattern. */
    comments?: string;
    /** Regular expression identifying URLs to exempt from rewriting. */
    pattern?: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingUrlIgnorePatternResponse {
    /** URL ignore pattern identifier. */
    id: string;
    createdAt: string;
    /** Regular expression identifying URLs to exempt from rewriting. */
    pattern: string;
    /** Optional note describing the reason for the ignore pattern. */
    comments?: string | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export interface SettingsAllowPoliciesBatchRequestDeletesItem {
    /** Allow policy identifier. */
    id: string;
}
export type SettingsAllowPoliciesBatchRequestDeletesList = Array<SettingsAllowPoliciesBatchRequestDeletesItem>;
export type SettingsAllowPoliciesBatchRequestPatchesItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsAllowPoliciesBatchRequestPatchesItem {
    /** Allow policy identifier. */
    id: string;
    createdAt: string;
    /** Use `modified_at` instead. */
    lastModified: string;
    comments?: string;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    /** Exempts messages from this sender from Spam, Spoof and Bulk dispositions only; Malicious and Suspicious dispositions still apply. */
    isAcceptableSender?: boolean;
    /** Bypasses all detections for messages to this recipient. */
    isExemptRecipient?: boolean;
    /** Use `is_exempt_recipient` instead. */
    isRecipient?: boolean;
    isRegex?: boolean;
    /** Use `is_trusted_sender` instead. */
    isSender?: boolean;
    /** Use `is_acceptable_sender` instead. */
    isSpoof?: boolean;
    /** Bypasses all detections and link following for messages from this sender. */
    isTrustedSender?: boolean;
    modifiedAt?: string;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesBatchRequestPatchesItemPatternType | (string & {});
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean;
}
export type SettingsAllowPoliciesBatchRequestPatchesList = Array<SettingsAllowPoliciesBatchRequestPatchesItem>;
export type SettingsAllowPoliciesBatchRequestPostsItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsAllowPoliciesBatchRequestPostsItem {
    /** Exempts messages from this sender from Spam, Spoof and Bulk dispositions only; Malicious and Suspicious dispositions still apply. */
    isAcceptableSender: boolean;
    /** Bypasses all detections for messages to this recipient. */
    isExemptRecipient: boolean;
    isRegex: boolean;
    /** Bypasses all detections and link following for messages from this sender. */
    isTrustedSender: boolean;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern: string;
    /** Type of pattern matching. */
    patternType: SettingsAllowPoliciesBatchRequestPostsItemPatternType | (string & {});
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender: boolean;
    /** Allow policy identifier. */
    id?: string;
    comments?: string;
    createdAt?: string;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    /** Use `is_exempt_recipient` instead. */
    isRecipient?: boolean;
    /** Use `is_trusted_sender` instead. */
    isSender?: boolean;
    /** Use `is_acceptable_sender` instead. */
    isSpoof?: boolean;
    /** Use `modified_at` instead. */
    lastModified?: string;
    modifiedAt?: string;
}
export type SettingsAllowPoliciesBatchRequestPostsList = Array<SettingsAllowPoliciesBatchRequestPostsItem>;
export type SettingsAllowPoliciesBatchRequestPutsItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsAllowPoliciesBatchRequestPutsItem {
    /** Allow policy identifier. */
    id: string;
    createdAt: string;
    /** Use `modified_at` instead. */
    lastModified: string;
    comments?: string;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    /** Exempts messages from this sender from Spam, Spoof and Bulk dispositions only; Malicious and Suspicious dispositions still apply. */
    isAcceptableSender?: boolean;
    /** Bypasses all detections for messages to this recipient. */
    isExemptRecipient?: boolean;
    /** Use `is_exempt_recipient` instead. */
    isRecipient?: boolean;
    isRegex?: boolean;
    /** Use `is_trusted_sender` instead. */
    isSender?: boolean;
    /** Use `is_acceptable_sender` instead. */
    isSpoof?: boolean;
    /** Bypasses all detections and link following for messages from this sender. */
    isTrustedSender?: boolean;
    modifiedAt?: string;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesBatchRequestPutsItemPatternType | (string & {});
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean;
}
export type SettingsAllowPoliciesBatchRequestPutsList = Array<SettingsAllowPoliciesBatchRequestPutsItem>;
export interface SettingsAllowPoliciesBatchRequest {
    /** Identifier. */
    accountId: string;
    /** IDs of the allow policies to delete. */
    deletes: SettingsAllowPoliciesBatchRequestDeletesList;
    /** Partial updates to apply -- each entry carries the policy's ID and only the fields to change. */
    patches: SettingsAllowPoliciesBatchRequestPatchesList;
    /** Allow policies to create. */
    posts: SettingsAllowPoliciesBatchRequestPostsList;
    /** Full replacements to apply -- each entry carries the policy's ID and every field of its new value. */
    puts: SettingsAllowPoliciesBatchRequestPutsList;
}
export type SettingsAllowPoliciesBatchResponseDeletesItem = SettingsAllowPoliciesBatchRequestDeletesItem;
export type SettingsAllowPoliciesBatchResponseDeletesList = Array<SettingsAllowPoliciesBatchRequestDeletesItem>;
export type SettingsAllowPoliciesBatchResponsePatchesItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsAllowPoliciesBatchResponsePatchesItem {
    /** Allow policy identifier. */
    id: string;
    createdAt: string;
    /** Use `modified_at` instead. */
    lastModified: string;
    comments?: string | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Exempts messages from this sender from Spam, Spoof and Bulk dispositions only; Malicious and Suspicious dispositions still apply. */
    isAcceptableSender?: boolean | null;
    /** Bypasses all detections for messages to this recipient. */
    isExemptRecipient?: boolean | null;
    /** Use `is_exempt_recipient` instead. */
    isRecipient?: boolean | null;
    isRegex?: boolean | null;
    /** Use `is_trusted_sender` instead. */
    isSender?: boolean | null;
    /** Use `is_acceptable_sender` instead. */
    isSpoof?: boolean | null;
    /** Bypasses all detections and link following for messages from this sender. */
    isTrustedSender?: boolean | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesBatchResponsePatchesItemPatternType | null;
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean | null;
}
export type SettingsAllowPoliciesBatchResponsePatchesList = Array<SettingsAllowPoliciesBatchResponsePatchesItem>;
export type SettingsAllowPoliciesBatchResponsePostsItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsAllowPoliciesBatchResponsePostsItem {
    /** Allow policy identifier. */
    id: string;
    createdAt: string;
    /** Use `modified_at` instead. */
    lastModified: string;
    comments?: string | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Exempts messages from this sender from Spam, Spoof and Bulk dispositions only; Malicious and Suspicious dispositions still apply. */
    isAcceptableSender?: boolean | null;
    /** Bypasses all detections for messages to this recipient. */
    isExemptRecipient?: boolean | null;
    /** Use `is_exempt_recipient` instead. */
    isRecipient?: boolean | null;
    isRegex?: boolean | null;
    /** Use `is_trusted_sender` instead. */
    isSender?: boolean | null;
    /** Use `is_acceptable_sender` instead. */
    isSpoof?: boolean | null;
    /** Bypasses all detections and link following for messages from this sender. */
    isTrustedSender?: boolean | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesBatchResponsePostsItemPatternType | null;
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean | null;
}
export type SettingsAllowPoliciesBatchResponsePostsList = Array<SettingsAllowPoliciesBatchResponsePostsItem>;
export type SettingsAllowPoliciesBatchResponsePutsItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsAllowPoliciesBatchResponsePutsItem {
    /** Allow policy identifier. */
    id: string;
    createdAt: string;
    /** Use `modified_at` instead. */
    lastModified: string;
    comments?: string | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Exempts messages from this sender from Spam, Spoof and Bulk dispositions only; Malicious and Suspicious dispositions still apply. */
    isAcceptableSender?: boolean | null;
    /** Bypasses all detections for messages to this recipient. */
    isExemptRecipient?: boolean | null;
    /** Use `is_exempt_recipient` instead. */
    isRecipient?: boolean | null;
    isRegex?: boolean | null;
    /** Use `is_trusted_sender` instead. */
    isSender?: boolean | null;
    /** Use `is_acceptable_sender` instead. */
    isSpoof?: boolean | null;
    /** Bypasses all detections and link following for messages from this sender. */
    isTrustedSender?: boolean | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesBatchResponsePutsItemPatternType | null;
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean | null;
}
export type SettingsAllowPoliciesBatchResponsePutsList = Array<SettingsAllowPoliciesBatchResponsePutsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SettingsAllowPoliciesBatchResponse {
    deletes?: SettingsAllowPoliciesBatchResponseDeletesList | null;
    patches?: SettingsAllowPoliciesBatchResponsePatchesList | null;
    posts?: SettingsAllowPoliciesBatchResponsePostsList | null;
    puts?: SettingsAllowPoliciesBatchResponsePutsList | null;
}
export interface SettingsBlockSendersBatchRequestDeletesItem {
    /** Blocked sender pattern identifier. */
    id: string;
}
export type SettingsBlockSendersBatchRequestDeletesList = Array<SettingsBlockSendersBatchRequestDeletesItem>;
export type SettingsBlockSendersBatchRequestPatchesItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsBlockSendersBatchRequestPatchesItem {
    /** Blocked sender pattern identifier. */
    id: string;
    comments?: string;
    createdAt?: string;
    /** Timestamp at which the pattern expires. After this time, Email Security ignores the pattern. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    /** Whether `pattern` is a regular expression instead of a literal value. */
    isRegex?: boolean;
    /** Use `modified_at` instead. */
    lastModified?: string;
    modifiedAt?: string;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersBatchRequestPatchesItemPatternType | (string & {});
}
export type SettingsBlockSendersBatchRequestPatchesList = Array<SettingsBlockSendersBatchRequestPatchesItem>;
export type SettingsBlockSendersBatchRequestPostsItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsBlockSendersBatchRequestPostsItem {
    /** Whether `pattern` is a regular expression instead of a literal value. */
    isRegex: boolean;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern: string;
    /** Type of pattern matching. */
    patternType: SettingsBlockSendersBatchRequestPostsItemPatternType | (string & {});
    /** Blocked sender pattern identifier. */
    id?: string;
    comments?: string;
    createdAt?: string;
    /** Timestamp at which the pattern expires. After this time, Email Security ignores the pattern. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    /** Use `modified_at` instead. */
    lastModified?: string;
    modifiedAt?: string;
}
export type SettingsBlockSendersBatchRequestPostsList = Array<SettingsBlockSendersBatchRequestPostsItem>;
export type SettingsBlockSendersBatchRequestPutsItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsBlockSendersBatchRequestPutsItem {
    /** Blocked sender pattern identifier. */
    id: string;
    /** Whether `pattern` is a regular expression instead of a literal value. */
    isRegex: boolean;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern: string;
    /** Type of pattern matching. */
    patternType: SettingsBlockSendersBatchRequestPutsItemPatternType | (string & {});
    comments?: string;
    createdAt?: string;
    /** Timestamp at which the pattern expires. After this time, Email Security ignores the pattern. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    /** Use `modified_at` instead. */
    lastModified?: string;
    modifiedAt?: string;
}
export type SettingsBlockSendersBatchRequestPutsList = Array<SettingsBlockSendersBatchRequestPutsItem>;
export interface SettingsBlockSendersBatchRequest {
    /** Identifier. */
    accountId: string;
    /** IDs of the blocked sender patterns to delete. */
    deletes: SettingsBlockSendersBatchRequestDeletesList;
    /** Partial updates to apply -- each entry carries the pattern's ID and only the fields to change. */
    patches: SettingsBlockSendersBatchRequestPatchesList;
    /** Blocked sender patterns to create. */
    posts: SettingsBlockSendersBatchRequestPostsList;
    /** Full replacements to apply -- each entry carries the pattern's ID and every field of its new value. */
    puts: SettingsBlockSendersBatchRequestPutsList;
}
export type SettingsBlockSendersBatchResponseDeletesItem = SettingsBlockSendersBatchRequestDeletesItem;
export type SettingsBlockSendersBatchResponseDeletesList = Array<SettingsBlockSendersBatchRequestDeletesItem>;
export type SettingsBlockSendersBatchResponsePatchesItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsBlockSendersBatchResponsePatchesItem {
    /** Blocked sender pattern identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Timestamp at which the pattern expires. After this time, Email Security ignores the pattern. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Whether `pattern` is a regular expression instead of a literal value. */
    isRegex?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersBatchResponsePatchesItemPatternType | null;
}
export type SettingsBlockSendersBatchResponsePatchesList = Array<SettingsBlockSendersBatchResponsePatchesItem>;
export type SettingsBlockSendersBatchResponsePostsItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsBlockSendersBatchResponsePostsItem {
    /** Blocked sender pattern identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Timestamp at which the pattern expires. After this time, Email Security ignores the pattern. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Whether `pattern` is a regular expression instead of a literal value. */
    isRegex?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersBatchResponsePostsItemPatternType | null;
}
export type SettingsBlockSendersBatchResponsePostsList = Array<SettingsBlockSendersBatchResponsePostsItem>;
export type SettingsBlockSendersBatchResponsePutsItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export interface SettingsBlockSendersBatchResponsePutsItem {
    /** Blocked sender pattern identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Timestamp at which the pattern expires. After this time, Email Security ignores the pattern. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    /** Whether `pattern` is a regular expression instead of a literal value. */
    isRegex?: boolean | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    /** The pattern value to match. The format depends on `pattern_type`: a valid email address for EMAIL (e.g. `user@example.com`), a valid domain name for DOMAIN (e.g. `example.com`), or a plain IPv4 or IPv6 address or CIDR block for IP (e.g. `1.2.3.4`, `1.2.3.0/24`, `2606:4700:4700::1111`, or `2606:4700:4700::/48`); the API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents. */
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersBatchResponsePutsItemPatternType | null;
}
export type SettingsBlockSendersBatchResponsePutsList = Array<SettingsBlockSendersBatchResponsePutsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SettingsBlockSendersBatchResponse {
    deletes?: SettingsBlockSendersBatchResponseDeletesList | null;
    patches?: SettingsBlockSendersBatchResponsePatchesList | null;
    posts?: SettingsBlockSendersBatchResponsePostsList | null;
    puts?: SettingsBlockSendersBatchResponsePutsList | null;
}
export interface SettingsContentPoliciesBatchRequestDeletesItem {
    /** Content policy identifier. */
    id: string;
}
export type SettingsContentPoliciesBatchRequestDeletesList = Array<SettingsContentPoliciesBatchRequestDeletesItem>;
export type SettingsContentPoliciesBatchRequestPatchesItemTargetsItem = "SUBJECT" | "BODY";
export type SettingsContentPoliciesBatchRequestPatchesItemTargetsList = Array<SettingsContentPoliciesBatchRequestPatchesItemTargetsItem | (string & {})>;
export interface SettingsContentPoliciesBatchRequestPatchesItem {
    /** Content policy identifier. */
    id: string;
    createdAt?: string;
    /** Whether the policy is active. */
    enabled?: boolean;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    modifiedAt?: string;
    /** Human-readable name of the policy. */
    name?: string;
    /** Optional note describing the purpose of the policy. */
    notes?: string;
    /** Regular expression the policy matches against. */
    pattern?: string;
    /** Parts of the email the pattern is matched against. */
    targets?: SettingsContentPoliciesBatchRequestPatchesItemTargetsList;
}
export type SettingsContentPoliciesBatchRequestPatchesList = Array<SettingsContentPoliciesBatchRequestPatchesItem>;
export type SettingsContentPoliciesBatchRequestPostsItemTargetsItem = "SUBJECT" | "BODY";
export type SettingsContentPoliciesBatchRequestPostsItemTargetsList = Array<SettingsContentPoliciesBatchRequestPostsItemTargetsItem | (string & {})>;
export interface SettingsContentPoliciesBatchRequestPostsItem {
    /** Whether the policy is active. */
    enabled: boolean;
    /** Human-readable name of the policy. */
    name: string;
    /** Regular expression the policy matches against. */
    pattern: string;
    /** Parts of the email the pattern is matched against. */
    targets: SettingsContentPoliciesBatchRequestPostsItemTargetsList;
    /** Content policy identifier. */
    id?: string;
    createdAt?: string;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    modifiedAt?: string;
    /** Optional note describing the purpose of the policy. */
    notes?: string;
}
export type SettingsContentPoliciesBatchRequestPostsList = Array<SettingsContentPoliciesBatchRequestPostsItem>;
export type SettingsContentPoliciesBatchRequestPutsItemTargetsItem = "SUBJECT" | "BODY";
export type SettingsContentPoliciesBatchRequestPutsItemTargetsList = Array<SettingsContentPoliciesBatchRequestPutsItemTargetsItem | (string & {})>;
export interface SettingsContentPoliciesBatchRequestPutsItem {
    /** Content policy identifier. */
    id: string;
    /** Whether the policy is active. */
    enabled: boolean;
    /** Human-readable name of the policy. */
    name: string;
    /** Regular expression the policy matches against. */
    pattern: string;
    /** Parts of the email the pattern is matched against. */
    targets: SettingsContentPoliciesBatchRequestPutsItemTargetsList;
    createdAt?: string;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string;
    modifiedAt?: string;
    /** Optional note describing the purpose of the policy. */
    notes?: string;
}
export type SettingsContentPoliciesBatchRequestPutsList = Array<SettingsContentPoliciesBatchRequestPutsItem>;
export interface SettingsContentPoliciesBatchRequest {
    /** Identifier. */
    accountId: string;
    /** IDs of the content policies to delete. */
    deletes: SettingsContentPoliciesBatchRequestDeletesList;
    /** Partial updates to apply -- each entry carries the policy's ID and only the fields to change. */
    patches: SettingsContentPoliciesBatchRequestPatchesList;
    /** Content policies to create. */
    posts: SettingsContentPoliciesBatchRequestPostsList;
    /** Full replacements to apply -- each entry carries the policy's ID and every field of its new value. */
    puts: SettingsContentPoliciesBatchRequestPutsList;
}
export type SettingsContentPoliciesBatchResponseDeletesItem = SettingsContentPoliciesBatchRequestDeletesItem;
export type SettingsContentPoliciesBatchResponseDeletesList = Array<SettingsContentPoliciesBatchRequestDeletesItem>;
export type SettingsContentPoliciesBatchResponsePatchesItemTargetsItem = "SUBJECT" | "BODY";
export type SettingsContentPoliciesBatchResponsePatchesItemTargetsList = Array<SettingsContentPoliciesBatchResponsePatchesItemTargetsItem>;
export interface SettingsContentPoliciesBatchResponsePatchesItem {
    /** Content policy identifier. */
    id?: string | null;
    createdAt?: string | null;
    /** Whether the policy is active. */
    enabled?: boolean | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    modifiedAt?: string | null;
    /** Human-readable name of the policy. */
    name?: string | null;
    /** Optional note describing the purpose of the policy. */
    notes?: string | null;
    /** Regular expression the policy matches against. */
    pattern?: string | null;
    /** Parts of the email the pattern is matched against. */
    targets?: SettingsContentPoliciesBatchResponsePatchesItemTargetsList | null;
}
export type SettingsContentPoliciesBatchResponsePatchesList = Array<SettingsContentPoliciesBatchResponsePatchesItem>;
export type SettingsContentPoliciesBatchResponsePostsItemTargetsItem = "SUBJECT" | "BODY";
export type SettingsContentPoliciesBatchResponsePostsItemTargetsList = Array<SettingsContentPoliciesBatchResponsePostsItemTargetsItem>;
export interface SettingsContentPoliciesBatchResponsePostsItem {
    /** Content policy identifier. */
    id?: string | null;
    createdAt?: string | null;
    /** Whether the policy is active. */
    enabled?: boolean | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    modifiedAt?: string | null;
    /** Human-readable name of the policy. */
    name?: string | null;
    /** Optional note describing the purpose of the policy. */
    notes?: string | null;
    /** Regular expression the policy matches against. */
    pattern?: string | null;
    /** Parts of the email the pattern is matched against. */
    targets?: SettingsContentPoliciesBatchResponsePostsItemTargetsList | null;
}
export type SettingsContentPoliciesBatchResponsePostsList = Array<SettingsContentPoliciesBatchResponsePostsItem>;
export type SettingsContentPoliciesBatchResponsePutsItemTargetsItem = "SUBJECT" | "BODY";
export type SettingsContentPoliciesBatchResponsePutsItemTargetsList = Array<SettingsContentPoliciesBatchResponsePutsItemTargetsItem>;
export interface SettingsContentPoliciesBatchResponsePutsItem {
    /** Content policy identifier. */
    id?: string | null;
    createdAt?: string | null;
    /** Whether the policy is active. */
    enabled?: boolean | null;
    /** Timestamp at which the policy expires. After this time, Email Security ignores the policy. The value must lie in the future. Send `null` to clear the expiration. */
    expiresAt?: string | null;
    modifiedAt?: string | null;
    /** Human-readable name of the policy. */
    name?: string | null;
    /** Optional note describing the purpose of the policy. */
    notes?: string | null;
    /** Regular expression the policy matches against. */
    pattern?: string | null;
    /** Parts of the email the pattern is matched against. */
    targets?: SettingsContentPoliciesBatchResponsePutsItemTargetsList | null;
}
export type SettingsContentPoliciesBatchResponsePutsList = Array<SettingsContentPoliciesBatchResponsePutsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SettingsContentPoliciesBatchResponse {
    deletes?: SettingsContentPoliciesBatchResponseDeletesList | null;
    patches?: SettingsContentPoliciesBatchResponsePatchesList | null;
    posts?: SettingsContentPoliciesBatchResponsePostsList | null;
    puts?: SettingsContentPoliciesBatchResponsePutsList | null;
}
export interface SettingsDomainsBatchRequestDeletesItem {
    /** Domain identifier. */
    id: string;
}
export type SettingsDomainsBatchRequestDeletesList = Array<SettingsDomainsBatchRequestDeletesItem>;
export type SettingsDomainsBatchRequestPatchesItemAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type SettingsDomainsBatchRequestPatchesItemAllowedDeliveryModesList = Array<SettingsDomainsBatchRequestPatchesItemAllowedDeliveryModesItem | (string & {})>;
export type SettingsDomainsBatchRequestPatchesItemDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type SettingsDomainsBatchRequestPatchesItemDropDispositionsList = Array<SettingsDomainsBatchRequestPatchesItemDropDispositionsItem | (string & {})>;
export type SettingsDomainsBatchRequestPatchesItemFolder = "AllItems" | "Inbox";
export type SettingsDomainsBatchRequestPatchesItemIpRestrictionsList = Array<string>;
export type SettingsDomainsBatchRequestPatchesItemRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type SettingsDomainsBatchRequestPatchesItemRegionsList = Array<SettingsDomainsBatchRequestPatchesItemRegionsItem | (string & {})>;
export interface SettingsDomainsBatchRequestPatchesItem {
    /** Domain identifier. */
    id: string;
    /** Delivery modes to onboard the domain through. */
    allowedDeliveryModes?: SettingsDomainsBatchRequestPatchesItemAllowedDeliveryModesList;
    /** Dispositions to drop instead of delivering, e.g. `["MALICIOUS", "SPAM"]`. */
    dropDispositions?: SettingsDomainsBatchRequestPatchesItemDropDispositionsList;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: SettingsDomainsBatchRequestPatchesItemFolder | (string & {});
    /** Identifier of the CASB integration that authorizes this domain. The integration also enables API scanning, post-delivery actions, and directory sync. */
    integrationId?: string;
    /** Source IP ranges mail is accepted from. Any other source is rejected. */
    ipRestrictions?: SettingsDomainsBatchRequestPatchesItemIpRestrictionsList;
    /** Number of hops to trace back through received headers when reconstructing the original message (1-20). */
    lookbackHops?: number;
    /** Regions that process messages for this domain, e.g. `["GLOBAL"]` or `["US"]`. */
    regions?: SettingsDomainsBatchRequestPatchesItemRegionsList;
    /** Require TLS on inbound connections. */
    requireTlsInbound?: boolean;
    /** Require TLS on outbound connections. */
    requireTlsOutbound?: boolean;
    /** The mail transport hostname for MX/Inline delivery -- the MX record Cloudflare delivers email to (e.g. `mx.example.com`). */
    transport?: string;
}
export type SettingsDomainsBatchRequestPatchesList = Array<SettingsDomainsBatchRequestPatchesItem>;
export type SettingsDomainsBatchRequestPostsItemAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type SettingsDomainsBatchRequestPostsItemAllowedDeliveryModesList = Array<SettingsDomainsBatchRequestPostsItemAllowedDeliveryModesItem | (string & {})>;
export type SettingsDomainsBatchRequestPostsItemDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type SettingsDomainsBatchRequestPostsItemDropDispositionsList = Array<SettingsDomainsBatchRequestPostsItemDropDispositionsItem | (string & {})>;
export type SettingsDomainsBatchRequestPostsItemIpRestrictionsList = Array<string>;
export type SettingsDomainsBatchRequestPostsItemRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type SettingsDomainsBatchRequestPostsItemRegionsList = Array<SettingsDomainsBatchRequestPostsItemRegionsItem | (string & {})>;
export type SettingsDomainsBatchRequestPostsItemFolder = "AllItems" | "Inbox";
export interface SettingsDomainsBatchRequestPostsItem {
    /** Delivery modes to onboard the domain through. */
    allowedDeliveryModes: SettingsDomainsBatchRequestPostsItemAllowedDeliveryModesList;
    /** The email domain to protect. */
    domain: string;
    /** Dispositions to drop instead of delivering, e.g. `["MALICIOUS", "SPAM"]`. */
    dropDispositions: SettingsDomainsBatchRequestPostsItemDropDispositionsList;
    /** Source IP ranges mail is accepted from. Any other source is rejected. */
    ipRestrictions: SettingsDomainsBatchRequestPostsItemIpRestrictionsList;
    /** Regions that process messages for this domain, e.g. `["GLOBAL"]` or `["US"]`. */
    regions: SettingsDomainsBatchRequestPostsItemRegionsList;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: SettingsDomainsBatchRequestPostsItemFolder | (string & {});
    /** Identifier of the CASB integration that authorizes this domain. The integration also enables API scanning, post-delivery actions, and directory sync. */
    integrationId?: string;
    /** Number of hops to trace back through received headers when reconstructing the original message (1-20). */
    lookbackHops?: number;
    /** Require TLS on inbound connections. */
    requireTlsInbound?: boolean;
    /** Require TLS on outbound connections. */
    requireTlsOutbound?: boolean;
    /** The mail transport hostname for MX/Inline delivery -- the MX record Cloudflare delivers email to (e.g. `mx.example.com`). */
    transport?: string;
}
export type SettingsDomainsBatchRequestPostsList = Array<SettingsDomainsBatchRequestPostsItem>;
export type SettingsDomainsBatchRequestPutsItemAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type SettingsDomainsBatchRequestPutsItemAllowedDeliveryModesList = Array<SettingsDomainsBatchRequestPutsItemAllowedDeliveryModesItem | (string & {})>;
export type SettingsDomainsBatchRequestPutsItemDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type SettingsDomainsBatchRequestPutsItemDropDispositionsList = Array<SettingsDomainsBatchRequestPutsItemDropDispositionsItem | (string & {})>;
export type SettingsDomainsBatchRequestPutsItemIpRestrictionsList = Array<string>;
export type SettingsDomainsBatchRequestPutsItemRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type SettingsDomainsBatchRequestPutsItemRegionsList = Array<SettingsDomainsBatchRequestPutsItemRegionsItem | (string & {})>;
export type SettingsDomainsBatchRequestPutsItemFolder = "AllItems" | "Inbox";
export interface SettingsDomainsBatchRequestPutsItem {
    /** Domain identifier. */
    id: string;
    /** Delivery modes to onboard the domain through. */
    allowedDeliveryModes: SettingsDomainsBatchRequestPutsItemAllowedDeliveryModesList;
    /** Dispositions to drop instead of delivering, e.g. `["MALICIOUS", "SPAM"]`. */
    dropDispositions: SettingsDomainsBatchRequestPutsItemDropDispositionsList;
    /** Source IP ranges mail is accepted from. Any other source is rejected. */
    ipRestrictions: SettingsDomainsBatchRequestPutsItemIpRestrictionsList;
    /** Regions that process messages for this domain, e.g. `["GLOBAL"]` or `["US"]`. */
    regions: SettingsDomainsBatchRequestPutsItemRegionsList;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: SettingsDomainsBatchRequestPutsItemFolder | (string & {});
    /** Identifier of the CASB integration that authorizes this domain. The integration also enables API scanning, post-delivery actions, and directory sync. */
    integrationId?: string;
    /** Number of hops to trace back through received headers when reconstructing the original message (1-20). */
    lookbackHops?: number;
    /** Require TLS on inbound connections. */
    requireTlsInbound?: boolean;
    /** Require TLS on outbound connections. */
    requireTlsOutbound?: boolean;
    /** The mail transport hostname for MX/Inline delivery -- the MX record Cloudflare delivers email to (e.g. `mx.example.com`). */
    transport?: string;
}
export type SettingsDomainsBatchRequestPutsList = Array<SettingsDomainsBatchRequestPutsItem>;
export interface SettingsDomainsBatchRequest {
    /** Identifier. */
    accountId: string;
    /** IDs of the domains to remove protection from. */
    deletes: SettingsDomainsBatchRequestDeletesList;
    /** Partial updates to apply -- each entry carries the domain's ID and only the fields to change. */
    patches: SettingsDomainsBatchRequestPatchesList;
    /** Domains to add protection for. */
    posts: SettingsDomainsBatchRequestPostsList;
    /** Full replacements to apply -- each entry carries the domain's ID and every field of its new value. */
    puts: SettingsDomainsBatchRequestPutsList;
}
export type SettingsDomainsBatchResponseDeletesItem = SettingsDomainsBatchRequestDeletesItem;
export type SettingsDomainsBatchResponseDeletesList = Array<SettingsDomainsBatchRequestDeletesItem>;
export type SettingsDomainsBatchResponsePatchesItemAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type SettingsDomainsBatchResponsePatchesItemAllowedDeliveryModesList = Array<SettingsDomainsBatchResponsePatchesItemAllowedDeliveryModesItem>;
export type SettingsDomainsBatchResponsePatchesItemAuthorization = CreateSettingsDomainResponseAuthorization;
export type SettingsDomainsBatchResponsePatchesItemDmarcStatus = "none" | "good" | "invalid";
export type SettingsDomainsBatchResponsePatchesItemDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type SettingsDomainsBatchResponsePatchesItemDropDispositionsList = Array<SettingsDomainsBatchResponsePatchesItemDropDispositionsItem>;
export type SettingsDomainsBatchResponsePatchesItemEmailsProcessed = CreateSettingsDomainResponseEmailsProcessed;
export type SettingsDomainsBatchResponsePatchesItemFolder = "AllItems" | "Inbox";
export type SettingsDomainsBatchResponsePatchesItemInboxProvider = "Microsoft" | "Google";
export type SettingsDomainsBatchResponsePatchesItemIpRestrictionsList = Array<string>;
export type SettingsDomainsBatchResponsePatchesItemRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type SettingsDomainsBatchResponsePatchesItemRegionsList = Array<SettingsDomainsBatchResponsePatchesItemRegionsItem>;
export type SettingsDomainsBatchResponsePatchesItemSpfStatus = "none" | "good" | "neutral" | "open" | "invalid";
export type SettingsDomainsBatchResponsePatchesItemStatus = "PENDING" | "ACTIVE" | "FAILED" | "TIMEOUT";
export interface SettingsDomainsBatchResponsePatchesItem {
    /** Domain identifier. */
    id?: string | null;
    allowedDeliveryModes?: SettingsDomainsBatchResponsePatchesItemAllowedDeliveryModesList | null;
    authorization?: CreateSettingsDomainResponseAuthorization | null;
    createdAt?: string | null;
    dmarcStatus?: SettingsDomainsBatchResponsePatchesItemDmarcStatus | null;
    domain?: string | null;
    dropDispositions?: SettingsDomainsBatchResponsePatchesItemDropDispositionsList | null;
    emailsProcessed?: CreateSettingsDomainResponseEmailsProcessed | null;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: SettingsDomainsBatchResponsePatchesItemFolder | null;
    inboxProvider?: SettingsDomainsBatchResponsePatchesItemInboxProvider | null;
    integrationId?: string | null;
    ipRestrictions?: SettingsDomainsBatchResponsePatchesItemIpRestrictionsList | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    lookbackHops?: number | null;
    modifiedAt?: string | null;
    o365TenantId?: string | null;
    regions?: SettingsDomainsBatchResponsePatchesItemRegionsList | null;
    requireTlsInbound?: boolean | null;
    requireTlsOutbound?: boolean | null;
    spfStatus?: SettingsDomainsBatchResponsePatchesItemSpfStatus | null;
    status?: SettingsDomainsBatchResponsePatchesItemStatus | null;
    transport?: string | null;
}
export type SettingsDomainsBatchResponsePatchesList = Array<SettingsDomainsBatchResponsePatchesItem>;
export type SettingsDomainsBatchResponsePostsItemAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type SettingsDomainsBatchResponsePostsItemAllowedDeliveryModesList = Array<SettingsDomainsBatchResponsePostsItemAllowedDeliveryModesItem>;
export type SettingsDomainsBatchResponsePostsItemAuthorization = CreateSettingsDomainResponseAuthorization;
export type SettingsDomainsBatchResponsePostsItemDmarcStatus = "none" | "good" | "invalid";
export type SettingsDomainsBatchResponsePostsItemDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type SettingsDomainsBatchResponsePostsItemDropDispositionsList = Array<SettingsDomainsBatchResponsePostsItemDropDispositionsItem>;
export type SettingsDomainsBatchResponsePostsItemEmailsProcessed = CreateSettingsDomainResponseEmailsProcessed;
export type SettingsDomainsBatchResponsePostsItemFolder = "AllItems" | "Inbox";
export type SettingsDomainsBatchResponsePostsItemInboxProvider = "Microsoft" | "Google";
export type SettingsDomainsBatchResponsePostsItemIpRestrictionsList = Array<string>;
export type SettingsDomainsBatchResponsePostsItemRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type SettingsDomainsBatchResponsePostsItemRegionsList = Array<SettingsDomainsBatchResponsePostsItemRegionsItem>;
export type SettingsDomainsBatchResponsePostsItemSpfStatus = "none" | "good" | "neutral" | "open" | "invalid";
export type SettingsDomainsBatchResponsePostsItemStatus = "PENDING" | "ACTIVE" | "FAILED" | "TIMEOUT";
export interface SettingsDomainsBatchResponsePostsItem {
    /** Domain identifier. */
    id?: string | null;
    allowedDeliveryModes?: SettingsDomainsBatchResponsePostsItemAllowedDeliveryModesList | null;
    authorization?: CreateSettingsDomainResponseAuthorization | null;
    createdAt?: string | null;
    dmarcStatus?: SettingsDomainsBatchResponsePostsItemDmarcStatus | null;
    domain?: string | null;
    dropDispositions?: SettingsDomainsBatchResponsePostsItemDropDispositionsList | null;
    emailsProcessed?: CreateSettingsDomainResponseEmailsProcessed | null;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: SettingsDomainsBatchResponsePostsItemFolder | null;
    inboxProvider?: SettingsDomainsBatchResponsePostsItemInboxProvider | null;
    integrationId?: string | null;
    ipRestrictions?: SettingsDomainsBatchResponsePostsItemIpRestrictionsList | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    lookbackHops?: number | null;
    modifiedAt?: string | null;
    o365TenantId?: string | null;
    regions?: SettingsDomainsBatchResponsePostsItemRegionsList | null;
    requireTlsInbound?: boolean | null;
    requireTlsOutbound?: boolean | null;
    spfStatus?: SettingsDomainsBatchResponsePostsItemSpfStatus | null;
    status?: SettingsDomainsBatchResponsePostsItemStatus | null;
    transport?: string | null;
}
export type SettingsDomainsBatchResponsePostsList = Array<SettingsDomainsBatchResponsePostsItem>;
export type SettingsDomainsBatchResponsePutsItemAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type SettingsDomainsBatchResponsePutsItemAllowedDeliveryModesList = Array<SettingsDomainsBatchResponsePutsItemAllowedDeliveryModesItem>;
export type SettingsDomainsBatchResponsePutsItemAuthorization = CreateSettingsDomainResponseAuthorization;
export type SettingsDomainsBatchResponsePutsItemDmarcStatus = "none" | "good" | "invalid";
export type SettingsDomainsBatchResponsePutsItemDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type SettingsDomainsBatchResponsePutsItemDropDispositionsList = Array<SettingsDomainsBatchResponsePutsItemDropDispositionsItem>;
export type SettingsDomainsBatchResponsePutsItemEmailsProcessed = CreateSettingsDomainResponseEmailsProcessed;
export type SettingsDomainsBatchResponsePutsItemFolder = "AllItems" | "Inbox";
export type SettingsDomainsBatchResponsePutsItemInboxProvider = "Microsoft" | "Google";
export type SettingsDomainsBatchResponsePutsItemIpRestrictionsList = Array<string>;
export type SettingsDomainsBatchResponsePutsItemRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type SettingsDomainsBatchResponsePutsItemRegionsList = Array<SettingsDomainsBatchResponsePutsItemRegionsItem>;
export type SettingsDomainsBatchResponsePutsItemSpfStatus = "none" | "good" | "neutral" | "open" | "invalid";
export type SettingsDomainsBatchResponsePutsItemStatus = "PENDING" | "ACTIVE" | "FAILED" | "TIMEOUT";
export interface SettingsDomainsBatchResponsePutsItem {
    /** Domain identifier. */
    id?: string | null;
    allowedDeliveryModes?: SettingsDomainsBatchResponsePutsItemAllowedDeliveryModesList | null;
    authorization?: CreateSettingsDomainResponseAuthorization | null;
    createdAt?: string | null;
    dmarcStatus?: SettingsDomainsBatchResponsePutsItemDmarcStatus | null;
    domain?: string | null;
    dropDispositions?: SettingsDomainsBatchResponsePutsItemDropDispositionsList | null;
    emailsProcessed?: CreateSettingsDomainResponseEmailsProcessed | null;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: SettingsDomainsBatchResponsePutsItemFolder | null;
    inboxProvider?: SettingsDomainsBatchResponsePutsItemInboxProvider | null;
    integrationId?: string | null;
    ipRestrictions?: SettingsDomainsBatchResponsePutsItemIpRestrictionsList | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    lookbackHops?: number | null;
    modifiedAt?: string | null;
    o365TenantId?: string | null;
    regions?: SettingsDomainsBatchResponsePutsItemRegionsList | null;
    requireTlsInbound?: boolean | null;
    requireTlsOutbound?: boolean | null;
    spfStatus?: SettingsDomainsBatchResponsePutsItemSpfStatus | null;
    status?: SettingsDomainsBatchResponsePutsItemStatus | null;
    transport?: string | null;
}
export type SettingsDomainsBatchResponsePutsList = Array<SettingsDomainsBatchResponsePutsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SettingsDomainsBatchResponse {
    deletes: SettingsDomainsBatchResponseDeletesList;
    patches: SettingsDomainsBatchResponsePatchesList;
    posts: SettingsDomainsBatchResponsePostsList;
    puts: SettingsDomainsBatchResponsePutsList;
}
export interface SettingsDomainsBulkDeleteRequest {
    /** Identifier. */
    accountId: string;
}
export type SettingsDomainsBulkDeleteResultItem = SettingsDomainsBatchRequestDeletesItem;
export type SettingsDomainsBulkDeleteResultList = Array<SettingsDomainsBatchRequestDeletesItem>;
export type SettingsDomainsBulkDeleteResponse = SettingsDomainsBulkDeleteResultList;
export interface SettingsTrustedDomainsBatchRequestDeletesItem {
    /** Trusted domain identifier. */
    id: string;
}
export type SettingsTrustedDomainsBatchRequestDeletesList = Array<SettingsTrustedDomainsBatchRequestDeletesItem>;
export interface SettingsTrustedDomainsBatchRequestPatchesItem {
    /** Trusted domain identifier. */
    id: string;
    comments?: string;
    createdAt?: string;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent?: boolean;
    /** Whether `pattern` is a regular expression instead of a literal domain. */
    isRegex?: boolean;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity?: boolean;
    /** Use `modified_at` instead. */
    lastModified?: string;
    modifiedAt?: string;
    /** The domain pattern to trust, e.g. `example.com`. */
    pattern?: string;
}
export type SettingsTrustedDomainsBatchRequestPatchesList = Array<SettingsTrustedDomainsBatchRequestPatchesItem>;
export interface SettingsTrustedDomainsBatchRequestPostsItem {
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent: boolean;
    /** Whether `pattern` is a regular expression instead of a literal domain. */
    isRegex: boolean;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity: boolean;
    /** The domain pattern to trust, e.g. `example.com`. */
    pattern: string;
    /** Trusted domain identifier. */
    id?: string;
    comments?: string;
    createdAt?: string;
    /** Use `modified_at` instead. */
    lastModified?: string;
    modifiedAt?: string;
}
export type SettingsTrustedDomainsBatchRequestPostsList = Array<SettingsTrustedDomainsBatchRequestPostsItem>;
export interface SettingsTrustedDomainsBatchRequestPutsItem {
    /** Trusted domain identifier. */
    id: string;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent: boolean;
    /** Whether `pattern` is a regular expression instead of a literal domain. */
    isRegex: boolean;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity: boolean;
    /** The domain pattern to trust, e.g. `example.com`. */
    pattern: string;
    comments?: string;
    createdAt?: string;
    /** Use `modified_at` instead. */
    lastModified?: string;
    modifiedAt?: string;
}
export type SettingsTrustedDomainsBatchRequestPutsList = Array<SettingsTrustedDomainsBatchRequestPutsItem>;
export interface SettingsTrustedDomainsBatchRequest {
    /** Identifier. */
    accountId: string;
    /** IDs of the trusted domain patterns to delete. */
    deletes: SettingsTrustedDomainsBatchRequestDeletesList;
    /** Partial updates to apply -- each entry carries the pattern's ID and only the fields to change. */
    patches: SettingsTrustedDomainsBatchRequestPatchesList;
    /** Trusted domain patterns to create. */
    posts: SettingsTrustedDomainsBatchRequestPostsList;
    /** Full replacements to apply -- each entry carries the pattern's ID and every field of its new value. */
    puts: SettingsTrustedDomainsBatchRequestPutsList;
}
export type SettingsTrustedDomainsBatchResponseDeletesItem = SettingsTrustedDomainsBatchRequestDeletesItem;
export type SettingsTrustedDomainsBatchResponseDeletesList = Array<SettingsTrustedDomainsBatchRequestDeletesItem>;
export type SettingsTrustedDomainsBatchResponsePatchesItem = SettingsTrustedDomainsListResultItem;
export type SettingsTrustedDomainsBatchResponsePatchesList = Array<SettingsTrustedDomainsListResultItem>;
export type SettingsTrustedDomainsBatchResponsePostsItem = SettingsTrustedDomainsListResultItem;
export type SettingsTrustedDomainsBatchResponsePostsList = Array<SettingsTrustedDomainsListResultItem>;
export type SettingsTrustedDomainsBatchResponsePutsItem = SettingsTrustedDomainsListResultItem;
export type SettingsTrustedDomainsBatchResponsePutsList = Array<SettingsTrustedDomainsListResultItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SettingsTrustedDomainsBatchResponse {
    deletes?: SettingsTrustedDomainsBatchResponseDeletesList | null;
    patches?: SettingsTrustedDomainsBatchResponsePatchesList | null;
    posts?: SettingsTrustedDomainsBatchResponsePostsList | null;
    puts?: SettingsTrustedDomainsBatchResponsePutsList | null;
}
export type UpdateSettingsDomainRequestAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type UpdateSettingsDomainRequestAllowedDeliveryModesList = Array<UpdateSettingsDomainRequestAllowedDeliveryModesItem | (string & {})>;
export type UpdateSettingsDomainRequestDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type UpdateSettingsDomainRequestDropDispositionsList = Array<UpdateSettingsDomainRequestDropDispositionsItem | (string & {})>;
export type UpdateSettingsDomainRequestIpRestrictionsList = Array<string>;
export type UpdateSettingsDomainRequestRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type UpdateSettingsDomainRequestRegionsList = Array<UpdateSettingsDomainRequestRegionsItem | (string & {})>;
export type UpdateSettingsDomainRequestFolder = "AllItems" | "Inbox";
export interface UpdateSettingsDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Domain identifier. */
    domainId: string;
    /** Delivery modes to onboard the domain through. */
    allowedDeliveryModes: UpdateSettingsDomainRequestAllowedDeliveryModesList;
    /** Dispositions to drop instead of delivering, e.g. `["MALICIOUS", "SPAM"]`. */
    dropDispositions: UpdateSettingsDomainRequestDropDispositionsList;
    /** Source IP ranges mail is accepted from. Any other source is rejected. */
    ipRestrictions: UpdateSettingsDomainRequestIpRestrictionsList;
    /** Regions that process messages for this domain, e.g. `["GLOBAL"]` or `["US"]`. */
    regions: UpdateSettingsDomainRequestRegionsList;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: UpdateSettingsDomainRequestFolder | (string & {});
    /** Identifier of the CASB integration that authorizes this domain. The integration also enables API scanning, post-delivery actions, and directory sync. */
    integrationId?: string;
    /** Number of hops to trace back through received headers when reconstructing the original message (1-20). */
    lookbackHops?: number;
    /** Require TLS on inbound connections. */
    requireTlsInbound?: boolean;
    /** Require TLS on outbound connections. */
    requireTlsOutbound?: boolean;
    /** The mail transport hostname for MX/Inline delivery -- the MX record Cloudflare delivers email to (e.g. `mx.example.com`). */
    transport?: string;
}
export type UpdateSettingsDomainResponseAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export type UpdateSettingsDomainResponseAllowedDeliveryModesList = Array<UpdateSettingsDomainResponseAllowedDeliveryModesItem>;
export type UpdateSettingsDomainResponseAuthorization = CreateSettingsDomainResponseAuthorization;
export type UpdateSettingsDomainResponseDmarcStatus = "none" | "good" | "invalid";
export type UpdateSettingsDomainResponseDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export type UpdateSettingsDomainResponseDropDispositionsList = Array<UpdateSettingsDomainResponseDropDispositionsItem>;
export type UpdateSettingsDomainResponseEmailsProcessed = CreateSettingsDomainResponseEmailsProcessed;
export type UpdateSettingsDomainResponseFolder = "AllItems" | "Inbox";
export type UpdateSettingsDomainResponseInboxProvider = "Microsoft" | "Google";
export type UpdateSettingsDomainResponseIpRestrictionsList = Array<string>;
export type UpdateSettingsDomainResponseRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export type UpdateSettingsDomainResponseRegionsList = Array<UpdateSettingsDomainResponseRegionsItem>;
export type UpdateSettingsDomainResponseSpfStatus = "none" | "good" | "neutral" | "open" | "invalid";
export type UpdateSettingsDomainResponseStatus = "PENDING" | "ACTIVE" | "FAILED" | "TIMEOUT";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSettingsDomainResponse {
    /** Domain identifier. */
    id?: string | null;
    allowedDeliveryModes?: UpdateSettingsDomainResponseAllowedDeliveryModesList | null;
    authorization?: CreateSettingsDomainResponseAuthorization | null;
    createdAt?: string | null;
    dmarcStatus?: UpdateSettingsDomainResponseDmarcStatus | null;
    domain?: string | null;
    dropDispositions?: UpdateSettingsDomainResponseDropDispositionsList | null;
    emailsProcessed?: CreateSettingsDomainResponseEmailsProcessed | null;
    /** The mailbox folder to scan, for API-scanning domains. */
    folder?: UpdateSettingsDomainResponseFolder | null;
    inboxProvider?: UpdateSettingsDomainResponseInboxProvider | null;
    integrationId?: string | null;
    ipRestrictions?: UpdateSettingsDomainResponseIpRestrictionsList | null;
    /** Use `modified_at` instead. */
    lastModified?: string | null;
    lookbackHops?: number | null;
    modifiedAt?: string | null;
    o365TenantId?: string | null;
    regions?: UpdateSettingsDomainResponseRegionsList | null;
    requireTlsInbound?: boolean | null;
    requireTlsOutbound?: boolean | null;
    spfStatus?: UpdateSettingsDomainResponseSpfStatus | null;
    status?: UpdateSettingsDomainResponseStatus | null;
    transport?: string | null;
}
export type BulkInvestigateMoveError = CloudflareOpError;
/** Moves one or more messages to a specified mailbox folder (Inbox, JunkEmail, DeletedItems, RecoverableItemsDeletions, or RecoverableItemsPurges). Requires active integration. Operates on an explicit list of messages; to move all messages matching a search, create a bulk action job instead. */
export declare const bulkInvestigateMove: API.PaginatedOperationMethod<BulkInvestigateMoveRequest, BulkInvestigateMoveResponse, BulkInvestigateMoveError, CloudflareOpContext, InvestigateMoveBulkResultItem>;
export type BulkInvestigateReleaseError = CloudflareOpError;
/** Delivers one or more quarantined messages to their intended recipients, for cases where a message was incorrectly quarantined. Operates on an explicit list of messages; to release all messages matching a search, create a bulk action job instead. The response includes delivery status for each recipient. */
export declare const bulkInvestigateRelease: API.PaginatedOperationMethod<BulkInvestigateReleaseRequest, BulkInvestigateReleaseResponse, BulkInvestigateReleaseError, CloudflareOpContext, InvestigateReleaseBulkResultItem>;
export type CreateInvestigateBulkError = CloudflareOpError;
/** Creates a new bulk action job to move or release messages that match the provided search parameters. To move or release an explicit list of known messages instead of a search, use the move or release endpoints. */
export declare const createInvestigateBulk: API.OperationMethod<CreateInvestigateBulkRequest, CreateInvestigateBulkResponse, CreateInvestigateBulkError, CloudflareOpContext>;
export type CreateInvestigateBulkCancelError = CloudflareOpError;
/** Cancels the job, marking it as cancelled and stopping any pending message processing. The job record remains visible in list and detail endpoints. */
export declare const createInvestigateBulkCancel: API.OperationMethod<CreateInvestigateBulkCancelRequest, CreateInvestigateBulkCancelResponse, CreateInvestigateBulkCancelError, CloudflareOpContext>;
export type CreateInvestigateMoveError = CloudflareOpError;
/** Moves a single message to a specified mailbox folder (Inbox, JunkEmail, DeletedItems, RecoverableItemsDeletions, or RecoverableItemsPurges). Requires active integration. */
export declare const createInvestigateMove: API.PaginatedOperationMethod<CreateInvestigateMoveRequest, CreateInvestigateMoveResponse, CreateInvestigateMoveError, CloudflareOpContext, InvestigateMoveBulkResultItem>;
export type CreateInvestigatePreviewError = CloudflareOpError;
/** Generates a preview image for a message that was not flagged as a detection. The message is rendered from the copy in the recipient's mailbox, so this requires an active integration and only works while the message is still in the recipient's inbox. Returns a base64-encoded PNG screenshot of the email body. For messages with a detection, use the detection preview endpoint instead. */
export declare const createInvestigatePreview: API.OperationMethod<CreateInvestigatePreviewRequest, CreateInvestigatePreviewResponse, CreateInvestigatePreviewError, CloudflareOpContext>;
export type CreateInvestigateReclassifyError = CloudflareOpError;
/** Submits a request to reclassify an email's disposition. Use for reporting false positives or false negatives. Optionally provide the raw EML content for reanalysis. The reclassification is processed asynchronously. Deprecated; use the create submissions endpoint instead. */
export declare const createInvestigateReclassify: API.OperationMethod<CreateInvestigateReclassifyRequest, CreateInvestigateReclassifyResponse, CreateInvestigateReclassifyError, CloudflareOpContext>;
export type CreateSettingAllowPolicyError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Creates a new allow policy that exempts matching emails from security detections. Use with caution as this bypasses email security scanning. Policies can match on sender patterns and apply to specific detections or all detections. */
export declare const createSettingAllowPolicy: API.OperationMethod<CreateSettingAllowPolicyRequest, CreateSettingAllowPolicyResponse, CreateSettingAllowPolicyError, CloudflareOpContext>;
export type CreateSettingBlockSenderError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Creates a new blocked sender pattern. Emails matching this pattern will be blocked from delivery. Patterns can be email addresses, domains, or IP addresses, and support regular expressions. */
export declare const createSettingBlockSender: API.OperationMethod<CreateSettingBlockSenderRequest, CreateSettingBlockSenderResponse, CreateSettingBlockSenderError, CloudflareOpContext>;
export type CreateSettingImpersonationRegistryError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Creates a new entry in the impersonation registry to protect against impersonation. Emails attempting to impersonate this identity will be flagged. Supports regex patterns for flexible email matching. */
export declare const createSettingImpersonationRegistry: API.OperationMethod<CreateSettingImpersonationRegistryRequest, CreateSettingImpersonationRegistryResponse, CreateSettingImpersonationRegistryError, CloudflareOpContext>;
export type CreateSettingsContentPolicyError = CloudflareOpError;
/** Creates a new content policy. Emails whose subject or body matches the pattern will be subject to the configured action. */
export declare const createSettingsContentPolicy: API.OperationMethod<CreateSettingsContentPolicyRequest, CreateSettingsContentPolicyResponse, CreateSettingsContentPolicyError, CloudflareOpContext>;
export type CreateSettingsDomainError = CloudflareOpError;
/** Protects a new email domain by adding it to Email Security. Accepts a flat configuration object covering all delivery modes. Returns the newly created domain configuration. */
export declare const createSettingsDomain: API.OperationMethod<CreateSettingsDomainRequest, CreateSettingsDomainResponse, CreateSettingsDomainError, CloudflareOpContext>;
export type CreateSettingSendingDomainRestrictionError = CloudflareOpError;
/** Creates a new sending domain restriction to enforce TLS requirements for a domain. Emails without TLS from this domain will be dropped unless the subdomain is in the exclude list. */
export declare const createSettingSendingDomainRestriction: API.OperationMethod<CreateSettingSendingDomainRestrictionRequest, CreateSettingSendingDomainRestrictionResponse, CreateSettingSendingDomainRestrictionError, CloudflareOpContext>;
export type CreateSettingTrustedDomainError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Creates a new trusted domain pattern. Use for partner domains or approved senders that should bypass recent domain registration and similarity checks. Configure whether it prevents recent domain or spoof dispositions. */
export declare const createSettingTrustedDomain: API.OperationMethod<CreateSettingTrustedDomainRequest, CreateSettingTrustedDomainResponse, CreateSettingTrustedDomainError, CloudflareOpContext>;
export type CreateSettingUrlIgnorePatternError = CloudflareOpError;
/** Creates a new URL rewrite ignore pattern. URLs matching this pattern will not be rewritten. */
export declare const createSettingUrlIgnorePattern: API.OperationMethod<CreateSettingUrlIgnorePatternRequest, CreateSettingUrlIgnorePatternResponse, CreateSettingUrlIgnorePatternError, CloudflareOpContext>;
export type DeleteInvestigateBulkError = CloudflareOpError;
/** Deletes the job, removing it from all list and detail endpoints. Only jobs in a terminal state (`COMPLETED`, `CANCELLED`, or `FAILED`) can be deleted. To stop an in-progress job without removing it, use the cancel endpoint instead. */
export declare const deleteInvestigateBulk: API.OperationMethod<DeleteInvestigateBulkRequest, DeleteInvestigateBulkResponse, DeleteInvestigateBulkError, CloudflareOpContext>;
export type DeleteSettingAllowPolicyError = AllowPolicyNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Removes an allow policy. After deletion, emails matching this pattern will be subject to normal security scanning and disposition actions. */
export declare const deleteSettingAllowPolicy: API.OperationMethod<DeleteSettingAllowPolicyRequest, DeleteSettingAllowPolicyResponse, DeleteSettingAllowPolicyError, CloudflareOpContext>;
export type DeleteSettingBlockSenderError = BlockSenderNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Removes a blocked sender pattern. After deletion, emails from this sender will no longer be automatically blocked based on this rule. */
export declare const deleteSettingBlockSender: API.OperationMethod<DeleteSettingBlockSenderRequest, DeleteSettingBlockSenderResponse, DeleteSettingBlockSenderError, CloudflareOpContext>;
export type DeleteSettingDomainError = EmailSecurityDomainNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Removes email security protection from a domain. After deletion, emails for this domain will no longer be processed by Email Security. This action cannot be undone. */
export declare const deleteSettingDomain: API.OperationMethod<DeleteSettingDomainRequest, DeleteSettingDomainResponse, DeleteSettingDomainError, CloudflareOpContext>;
export type DeleteSettingImpersonationRegistryError = ImpersonationRegistryEntryNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Removes an entry from the impersonation registry. After deletion, this identity will no longer be protected from impersonation. */
export declare const deleteSettingImpersonationRegistry: API.OperationMethod<DeleteSettingImpersonationRegistryRequest, DeleteSettingImpersonationRegistryResponse, DeleteSettingImpersonationRegistryError, CloudflareOpContext>;
export type DeleteSettingsContentPolicyError = CloudflareOpError;
/** Removes a content policy. After deletion, emails will no longer be evaluated against this pattern. */
export declare const deleteSettingsContentPolicy: API.OperationMethod<DeleteSettingsContentPolicyRequest, DeleteSettingsContentPolicyResponse, DeleteSettingsContentPolicyError, CloudflareOpContext>;
export type DeleteSettingSendingDomainRestrictionError = CloudflareOpError;
/** Removes a sending domain restriction. After deletion, TLS will no longer be enforced for emails from this domain. */
export declare const deleteSettingSendingDomainRestriction: API.OperationMethod<DeleteSettingSendingDomainRestrictionRequest, DeleteSettingSendingDomainRestrictionResponse, DeleteSettingSendingDomainRestrictionError, CloudflareOpContext>;
export type DeleteSettingTrustedDomainError = TrustedDomainNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Removes a trusted domain pattern. After deletion, emails from this domain will be subject to normal recent domain and similarity checks. */
export declare const deleteSettingTrustedDomain: API.OperationMethod<DeleteSettingTrustedDomainRequest, DeleteSettingTrustedDomainResponse, DeleteSettingTrustedDomainError, CloudflareOpContext>;
export type DeleteSettingUrlIgnorePatternError = CloudflareOpError;
/** Removes a URL rewrite ignore pattern. After deletion, URLs matching this pattern will be rewritten again. */
export declare const deleteSettingUrlIgnorePattern: API.OperationMethod<DeleteSettingUrlIgnorePatternRequest, DeleteSettingUrlIgnorePatternResponse, DeleteSettingUrlIgnorePatternError, CloudflareOpContext>;
export type EditSettingsContentPolicyError = CloudflareOpError;
/** Updates an existing content policy. Only provided fields will be modified. */
export declare const editSettingsContentPolicy: API.OperationMethod<EditSettingsContentPolicyRequest, EditSettingsContentPolicyResponse, EditSettingsContentPolicyError, CloudflareOpContext>;
export type GetInvestigateError = CloudflareOpError;
/** Retrieves comprehensive details for a specific email message including headers, recipients, sender information, and current quarantine status. Use the investigate_id from search results to fetch detailed information. */
export declare const getInvestigate: API.OperationMethod<GetInvestigateRequest, GetInvestigateResponse, GetInvestigateError, CloudflareOpContext>;
export type GetInvestigateBulkError = CloudflareOpError;
/** Returns the status and details of a specific bulk action job. */
export declare const getInvestigateBulk: API.OperationMethod<GetInvestigateBulkRequest, GetInvestigateBulkResponse, GetInvestigateBulkError, CloudflareOpContext>;
export type GetInvestigateDetectionError = CloudflareOpError;
/** Returns detection details such as threat categories and sender information for messages with a detection. */
export declare const getInvestigateDetection: API.OperationMethod<GetInvestigateDetectionRequest, GetInvestigateDetectionResponse, GetInvestigateDetectionError, CloudflareOpContext>;
export type GetInvestigatePreviewError = CloudflareOpError;
/** Returns a preview of the message body as a base64-encoded PNG image for any message with a detection. For messages without a detection, use the non-detection preview endpoint instead. */
export declare const getInvestigatePreview: API.OperationMethod<GetInvestigatePreviewRequest, GetInvestigatePreviewResponse, GetInvestigatePreviewError, CloudflareOpContext>;
export type GetInvestigateRawError = CloudflareOpError;
/** Returns the raw EML content of any message with a detection. */
export declare const getInvestigateRaw: API.OperationMethod<GetInvestigateRawRequest, GetInvestigateRawResponse, GetInvestigateRawError, CloudflareOpContext>;
export type GetInvestigateTraceError = CloudflareOpError;
/** Retrieves delivery and processing trace information for an email message. Shows the delivery path, retraction history, and move operations performed on the message. Useful for debugging delivery issues. */
export declare const getInvestigateTrace: API.OperationMethod<GetInvestigateTraceRequest, GetInvestigateTraceResponse, GetInvestigateTraceError, CloudflareOpContext>;
export type GetSettingAllowPolicyError = AllowPolicyNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Retrieves details for a specific allow policy including its pattern, dispositions that are exempted, and whether it applies to all detections. */
export declare const getSettingAllowPolicy: API.OperationMethod<GetSettingAllowPolicyRequest, GetSettingAllowPolicyResponse, GetSettingAllowPolicyError, CloudflareOpContext>;
export type GetSettingBlockSenderError = BlockSenderNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Retrieves details for a specific blocked sender pattern including its pattern type, value, and metadata. */
export declare const getSettingBlockSender: API.OperationMethod<GetSettingBlockSenderRequest, GetSettingBlockSenderResponse, GetSettingBlockSenderError, CloudflareOpContext>;
export type GetSettingDomainError = EmailSecurityDomainNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Retrieves detailed information for a specific protected email domain including its delivery configuration, SPF/DMARC status, and authorization state. */
export declare const getSettingDomain: API.OperationMethod<GetSettingDomainRequest, GetSettingDomainResponse, GetSettingDomainError, CloudflareOpContext>;
export type GetSettingImpersonationRegistryError = ImpersonationRegistryEntryNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Retrieves details for a specific impersonation registry entry including the protected identity, email pattern, and synchronization source if directory-synced. */
export declare const getSettingImpersonationRegistry: API.OperationMethod<GetSettingImpersonationRegistryRequest, GetSettingImpersonationRegistryResponse, GetSettingImpersonationRegistryError, CloudflareOpContext>;
export type GetSettingsContentPolicyError = CloudflareOpError;
/** Retrieves details for a specific content policy including its pattern, targets, and metadata. */
export declare const getSettingsContentPolicy: API.OperationMethod<GetSettingsContentPolicyRequest, GetSettingsContentPolicyResponse, GetSettingsContentPolicyError, CloudflareOpContext>;
export type GetSettingSendingDomainRestrictionError = CloudflareOpError;
/** Retrieves details for a specific sending domain restriction including the domain requiring TLS and any excluded subdomains exempt from the TLS requirement. */
export declare const getSettingSendingDomainRestriction: API.OperationMethod<GetSettingSendingDomainRestrictionRequest, GetSettingSendingDomainRestrictionResponse, GetSettingSendingDomainRestrictionError, CloudflareOpContext>;
export type GetSettingTrustedDomainError = TrustedDomainNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Retrieves details for a specific trusted domain pattern including its pattern value, whether it uses regex matching, and which detection types it affects. */
export declare const getSettingTrustedDomain: API.OperationMethod<GetSettingTrustedDomainRequest, GetSettingTrustedDomainResponse, GetSettingTrustedDomainError, CloudflareOpContext>;
export type GetSettingUrlIgnorePatternError = CloudflareOpError;
/** Returns a single URL rewrite ignore pattern by its identifier. */
export declare const getSettingUrlIgnorePattern: API.OperationMethod<GetSettingUrlIgnorePatternRequest, GetSettingUrlIgnorePatternResponse, GetSettingUrlIgnorePatternError, CloudflareOpContext>;
export type ListInvestigateBulkMessagesError = CloudflareOpError;
/** Returns the individual messages associated with a bulk action job, including their processing status. */
export declare const listInvestigateBulkMessages: API.PaginatedOperationMethod<ListInvestigateBulkMessagesRequest, ListInvestigateBulkMessagesResponse, ListInvestigateBulkMessagesError, CloudflareOpContext, InvestigateBulkMessagesListResultItem>;
export type ListInvestigateBulksError = CloudflareOpError;
/** Returns a paginated list of bulk action jobs for the account. */
export declare const listInvestigateBulks: API.PaginatedOperationMethod<ListInvestigateBulksRequest, ListInvestigateBulksResponse, ListInvestigateBulksError, CloudflareOpContext, InvestigateBulkListResultItem>;
export type ListInvestigatesError = CloudflareOpError;
/** Returns information for each email that matches the provided search parameters. */
export declare const listInvestigates: API.PaginatedOperationMethod<ListInvestigatesRequest, ListInvestigatesResponse, ListInvestigatesError, CloudflareOpContext, InvestigateListResultItem>;
export type ListPhishguardReportsError = CloudflareOpError;
/** Retrieves PhishGuard security alert reports for a specified date range. Reports include detected threats, dispositions, and contextual information. Use for security monitoring and threat analysis. */
export declare const listPhishguardReports: API.PaginatedOperationMethod<ListPhishguardReportsRequest, ListPhishguardReportsResponse, ListPhishguardReportsError, CloudflareOpContext, PhishguardReportsListResultItem>;
export type ListSettingAllowPoliciesError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Returns a paginated list of email allow policies. These policies exempt matching emails from security detection, allowing them to bypass disposition actions. Supports filtering by pattern type and policy attributes. */
export declare const listSettingAllowPolicies: API.PaginatedOperationMethod<ListSettingAllowPoliciesRequest, ListSettingAllowPoliciesResponse, ListSettingAllowPoliciesError, CloudflareOpContext, SettingsAllowPoliciesListResultItem>;
export type ListSettingBlockSendersError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Returns a paginated list of blocked email sender patterns. These patterns prevent emails from matching senders from being delivered. Supports filtering by pattern type and searching across patterns. */
export declare const listSettingBlockSenders: API.PaginatedOperationMethod<ListSettingBlockSendersRequest, ListSettingBlockSendersResponse, ListSettingBlockSendersError, CloudflareOpContext, SettingsBlockSendersListResultItem>;
export type ListSettingDomainsError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Returns a paginated list of email domains protected by Email Security. Includes domain configuration, delivery modes, and authorization status. Supports filtering by delivery mode and integration ID. */
export declare const listSettingDomains: API.PaginatedOperationMethod<ListSettingDomainsRequest, ListSettingDomainsResponse, ListSettingDomainsError, CloudflareOpContext, SettingsDomainsListResultItem>;
export type ListSettingImpersonationRegistriesError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Returns a paginated list of protected identities in the impersonation registry. These entries define identities and email addresses to protect from impersonation attacks. Can be manually added or automatically synced from directory integrations. */
export declare const listSettingImpersonationRegistries: API.PaginatedOperationMethod<ListSettingImpersonationRegistriesRequest, ListSettingImpersonationRegistriesResponse, ListSettingImpersonationRegistriesError, CloudflareOpContext, SettingsImpersonationRegistryListResultItem>;
export type ListSettingsContentPoliciesError = CloudflareOpError;
/** Returns a paginated list of content policies. These policies match against the subject or body of emails using a pattern. Supports filtering by name or enabled status, and searching across name and pattern fields. */
export declare const listSettingsContentPolicies: API.OperationMethod<ListSettingsContentPoliciesRequest, ListSettingsContentPoliciesResponse, ListSettingsContentPoliciesError, CloudflareOpContext>;
export type ListSettingSendingDomainRestrictionsError = CloudflareOpError;
/** Returns a paginated list of sending domain restrictions. These restrictions enforce TLS requirements for emails from specific domains. Mail without TLS from restricted domains will be dropped unless the subdomain is in the exclude list. Supports sorting and searching. */
export declare const listSettingSendingDomainRestrictions: API.PaginatedOperationMethod<ListSettingSendingDomainRestrictionsRequest, ListSettingSendingDomainRestrictionsResponse, ListSettingSendingDomainRestrictionsError, CloudflareOpContext, SettingsSendingDomainRestrictionsListResultItem>;
export type ListSettingTrustedDomainsError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Returns a paginated list of trusted domain patterns. Trusted domains prevent false positives for recently registered domains and lookalike domain detections. Patterns can use regular expressions for flexible matching. */
export declare const listSettingTrustedDomains: API.PaginatedOperationMethod<ListSettingTrustedDomainsRequest, ListSettingTrustedDomainsResponse, ListSettingTrustedDomainsError, CloudflareOpContext, SettingsTrustedDomainsListResultItem>;
export type ListSettingUrlIgnorePatternsError = CloudflareOpError;
/** Returns a paginated list of URL rewrite ignore patterns for the account. URLs matching these patterns will not be rewritten. */
export declare const listSettingUrlIgnorePatterns: API.PaginatedOperationMethod<ListSettingUrlIgnorePatternsRequest, ListSettingUrlIgnorePatternsResponse, ListSettingUrlIgnorePatternsError, CloudflareOpContext, SettingsUrlIgnorePatternsListResultItem>;
export type ListSubmissionsError = CloudflareOpError;
/** Returns information for submissions made to reclassify emails. Shows the status, outcome, and disposition changes for reclassification requests made by users or the security team. Useful for tracking false positive/negative reports. */
export declare const listSubmissions: API.PaginatedOperationMethod<ListSubmissionsRequest, ListSubmissionsResponse, ListSubmissionsError, CloudflareOpContext, SubmissionsListResultItem>;
export type PatchSettingAllowPolicyError = AllowPolicyNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Updates an existing allow policy. Only provided fields will be modified. Changes take effect for new emails matching the pattern. */
export declare const patchSettingAllowPolicy: API.OperationMethod<PatchSettingAllowPolicyRequest, PatchSettingAllowPolicyResponse, PatchSettingAllowPolicyError, CloudflareOpContext>;
export type PatchSettingBlockSenderError = BlockSenderNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Updates an existing blocked sender pattern. Only provided fields will be modified. The pattern will continue blocking emails until deleted. */
export declare const patchSettingBlockSender: API.OperationMethod<PatchSettingBlockSenderRequest, PatchSettingBlockSenderResponse, PatchSettingBlockSenderError, CloudflareOpContext>;
export type PatchSettingDomainError = EmailSecurityDomainNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Updates configuration for a protected email domain. Only provided fields will be modified. Changes affect delivery mode, security settings, and regional processing. */
export declare const patchSettingDomain: API.OperationMethod<PatchSettingDomainRequest, PatchSettingDomainResponse, PatchSettingDomainError, CloudflareOpContext>;
export type PatchSettingImpersonationRegistryError = ImpersonationRegistryEntryNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Updates an existing impersonation registry entry. Only provided fields will be modified. Directory-synced entries can't be updated. */
export declare const patchSettingImpersonationRegistry: API.OperationMethod<PatchSettingImpersonationRegistryRequest, PatchSettingImpersonationRegistryResponse, PatchSettingImpersonationRegistryError, CloudflareOpContext>;
export type PatchSettingSendingDomainRestrictionError = CloudflareOpError;
/** Updates an existing sending domain restriction. Only provided fields will be modified. Changes affect which domains require TLS and which subdomains are excluded. */
export declare const patchSettingSendingDomainRestriction: API.OperationMethod<PatchSettingSendingDomainRestrictionRequest, PatchSettingSendingDomainRestrictionResponse, PatchSettingSendingDomainRestrictionError, CloudflareOpContext>;
export type PatchSettingTrustedDomainError = TrustedDomainNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Updates an existing trusted domain pattern. Only provided fields will be modified. Changes take effect for new emails matching the pattern. */
export declare const patchSettingTrustedDomain: API.OperationMethod<PatchSettingTrustedDomainRequest, PatchSettingTrustedDomainResponse, PatchSettingTrustedDomainError, CloudflareOpContext>;
export type PatchSettingUrlIgnorePatternError = CloudflareOpError;
/** Updates an existing URL rewrite ignore pattern. Only provided fields will be modified. */
export declare const patchSettingUrlIgnorePattern: API.OperationMethod<PatchSettingUrlIgnorePatternRequest, PatchSettingUrlIgnorePatternResponse, PatchSettingUrlIgnorePatternError, CloudflareOpContext>;
export type SettingsAllowPoliciesBatchError = CloudflareOpError;
/** Executes multiple allow policy operations atomically: delete, partially update, replace, and create allow policies in a single request. All four operation arrays (deletes, patches, puts, posts) are required and executed in order. Send empty arrays for unused operations. */
export declare const settingsAllowPoliciesBatch: API.OperationMethod<SettingsAllowPoliciesBatchRequest, SettingsAllowPoliciesBatchResponse, SettingsAllowPoliciesBatchError, CloudflareOpContext>;
export type SettingsBlockSendersBatchError = CloudflareOpError;
/** Executes multiple blocked sender operations atomically: delete, partially update, replace, and create blocked sender patterns in a single request. All four operation arrays (deletes, patches, puts, posts) are required and executed in order. Send empty arrays for unused operations. */
export declare const settingsBlockSendersBatch: API.OperationMethod<SettingsBlockSendersBatchRequest, SettingsBlockSendersBatchResponse, SettingsBlockSendersBatchError, CloudflareOpContext>;
export type SettingsContentPoliciesBatchError = CloudflareOpError;
/** Executes multiple content policy operations atomically: delete, partially update, replace, and create content policies in a single request. All four operation arrays (deletes, patches, puts, posts) are required and executed in order. Send empty arrays for unused operations. */
export declare const settingsContentPoliciesBatch: API.OperationMethod<SettingsContentPoliciesBatchRequest, SettingsContentPoliciesBatchResponse, SettingsContentPoliciesBatchError, CloudflareOpContext>;
export type SettingsDomainsBatchError = CloudflareOpError;
/** Executes multiple domain operations in a single request. All four operation arrays (deletes, patches, puts, posts) are required and executed in order. Send empty arrays for unused operations. */
export declare const settingsDomainsBatch: API.OperationMethod<SettingsDomainsBatchRequest, SettingsDomainsBatchResponse, SettingsDomainsBatchError, CloudflareOpContext>;
export type SettingsDomainsBulkDeleteError = CloudflareOpError;
/** Removes protection from multiple email domains. Deprecated; use the batch endpoint instead. */
export declare const settingsDomainsBulkDelete: API.OperationMethod<SettingsDomainsBulkDeleteRequest, SettingsDomainsBulkDeleteResponse, SettingsDomainsBulkDeleteError, CloudflareOpContext>;
export type SettingsTrustedDomainsBatchError = CloudflareOpError;
/** Executes multiple trusted domain operations atomically: delete, partially update, replace, and create trusted domain patterns in a single request. All four operation arrays (deletes, patches, puts, posts) are required and executed in order. Send empty arrays for unused operations. */
export declare const settingsTrustedDomainsBatch: API.OperationMethod<SettingsTrustedDomainsBatchRequest, SettingsTrustedDomainsBatchResponse, SettingsTrustedDomainsBatchError, CloudflareOpContext>;
export type UpdateSettingsDomainError = CloudflareOpError;
/** Replaces all mutable fields of a protected email domain in a single atomic operation. Unlike PATCH, all non-computed fields are required. */
export declare const updateSettingsDomain: API.OperationMethod<UpdateSettingsDomainRequest, UpdateSettingsDomainResponse, UpdateSettingsDomainError, CloudflareOpContext>;
//# sourceMappingURL=email_security.d.ts.map