import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface GetDmarcReportRequest {
    /** Identifier. */
    zoneId: string;
}
export type DmarcReportsGetResponseApprovedSourcesItemIpsList = Array<string>;
export interface DmarcReportsGetResponseApprovedSourcesItem {
    /** Use `created_at` instead. */
    created?: string | null;
    /** Creation timestamp */
    createdAt?: string | null;
    /** The source domain */
    domain?: string | null;
    /** Resolved IP addresses from SPF */
    ips?: DmarcReportsGetResponseApprovedSourcesItemIpsList | null;
    /** Use `modified_at` instead. */
    modified?: string | null;
    /** Last modification timestamp */
    modifiedAt?: string | null;
    /** Source name (typically same as domain) */
    name?: string | null;
    /** URL-friendly identifier */
    slug?: string | null;
    /** Source UUID */
    tag?: string | null;
}
export type DmarcReportsGetResponseApprovedSourcesList = Array<DmarcReportsGetResponseApprovedSourcesItem>;
export type DmarcReportsGetResponseRecordsBimiRecordsItemResolvedList = Array<string>;
export interface DmarcReportsGetResponseRecordsBimiRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsGetResponseRecordsBimiRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsGetResponseRecordsBimiRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsGetResponseRecordsCnameDkimRecordsItemResolvedList = Array<string>;
export interface DmarcReportsGetResponseRecordsCnameDkimRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsGetResponseRecordsCnameDkimRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsGetResponseRecordsCnameDkimRecordsList = Array<DmarcReportsGetResponseRecordsCnameDkimRecordsItem>;
export type DmarcReportsGetResponseRecordsCnameDmarcRecordsItemResolvedList = Array<string>;
export interface DmarcReportsGetResponseRecordsCnameDmarcRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsGetResponseRecordsCnameDmarcRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsGetResponseRecordsCnameDmarcRecordsList = Array<DmarcReportsGetResponseRecordsCnameDmarcRecordsItem>;
export type DmarcReportsGetResponseRecordsCnameSpfRecordsItemResolvedList = Array<string>;
export interface DmarcReportsGetResponseRecordsCnameSpfRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsGetResponseRecordsCnameSpfRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsGetResponseRecordsCnameSpfRecordsList = Array<DmarcReportsGetResponseRecordsCnameSpfRecordsItem>;
export type DmarcReportsGetResponseRecordsDkimRecordsItemResolvedList = Array<string>;
export interface DmarcReportsGetResponseRecordsDkimRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsGetResponseRecordsDkimRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsGetResponseRecordsDkimRecordsList = Array<DmarcReportsGetResponseRecordsDkimRecordsItem>;
export type DmarcReportsGetResponseRecordsDmarcRecordsItemResolvedList = Array<string>;
export interface DmarcReportsGetResponseRecordsDmarcRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsGetResponseRecordsDmarcRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsGetResponseRecordsDmarcRecordsList = Array<DmarcReportsGetResponseRecordsDmarcRecordsItem>;
export interface DmarcReportsGetResponseRecordsResolvedDmarcRecordsItem {
    /** The TXT record value. The API joins all character-strings into a single string. */
    content?: string | null;
    /** The name the API queried. */
    name?: string | null;
}
export type DmarcReportsGetResponseRecordsResolvedDmarcRecordsList = Array<DmarcReportsGetResponseRecordsResolvedDmarcRecordsItem>;
export type DmarcReportsGetResponseRecordsSpfRecordsItemResolvedList = Array<string>;
export interface DmarcReportsGetResponseRecordsSpfRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsGetResponseRecordsSpfRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsGetResponseRecordsSpfRecordsList = Array<DmarcReportsGetResponseRecordsSpfRecordsItem>;
export interface DmarcReportsGetResponseRecords {
    /** BIMI TXT records */
    bimiRecords?: DmarcReportsGetResponseRecordsBimiRecordsList | null;
    /** CNAME records for DKIM selectors. Each selector is resolved independently; when a selector's CNAME resolves to a DKIM TXT record, the API returns that record's content in the `resolved` field of the corresponding entry. */
    cnameDkimRecords?: DmarcReportsGetResponseRecordsCnameDkimRecordsList | null;
    /** CNAME records at _dmarc. When such a CNAME resolves to a DMARC TXT record, the API returns that record's content in the `resolved` field of the corresponding entry. */
    cnameDmarcRecords?: DmarcReportsGetResponseRecordsCnameDmarcRecordsList | null;
    /** CNAME records at the zone apex. When such a CNAME resolves to an SPF TXT record, the API returns that record's content in the `resolved` field of the corresponding entry. */
    cnameSpfRecords?: DmarcReportsGetResponseRecordsCnameSpfRecordsList | null;
    /** DKIM TXT records */
    dkimRecords?: DmarcReportsGetResponseRecordsDkimRecordsList | null;
    /** DMARC TXT records */
    dmarcRecords?: DmarcReportsGetResponseRecordsDmarcRecordsList | null;
    /** Use the `resolved` field on the corresponding entry in cname_dmarc_records instead. */
    resolvedDmarcRecords?: DmarcReportsGetResponseRecordsResolvedDmarcRecordsList | null;
    /** SPF TXT records */
    spfRecords?: DmarcReportsGetResponseRecordsSpfRecordsList | null;
}
export type DmarcReportsGetResponseStatus = "missing-dmarc-report" | "multiple-dmarc-reports" | "missing-dmarc-rua" | "cname-on-dmarc-record" | "unauthorized-reporting-domain";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDmarcReportResponse {
    /** List of approved sending sources (omitted when empty) */
    approvedSources?: DmarcReportsGetResponseApprovedSourcesList | null;
    /** Use `created_at` instead. */
    created?: string | null;
    /** Creation timestamp */
    createdAt?: string | null;
    /** Whether DMARC reports are enabled */
    enabled?: boolean | null;
    /** Use `modified_at` instead. */
    modified?: string | null;
    /** Last modification timestamp */
    modifiedAt?: string | null;
    /** Live DNS records for the zone, grouped by type */
    records?: DmarcReportsGetResponseRecords | null;
    /** Prefix for DMARC RUA addresses (32-char hex string) */
    ruaPrefix?: string | null;
    /** Whether to skip the setup wizard */
    skipWizard?: boolean | null;
    /** DMARC configuration status. The API omits this field when DMARC is correctly configured. If the zone lacks a DMARC TXT record of its own, the API resolves _dmarc.{zone} recursively and evaluates whatever that lookup returns. A CNAME at _dmarc.{zone} that points to a valid DMARC record is therefore healthy; the cname-on-dmarc-record value means the CNAME resolves to no DMARC record at all. */
    status?: DmarcReportsGetResponseStatus | null;
    /** Use `zone_id` instead. */
    tag?: string | null;
    /** Zone identifier */
    zoneId?: string | null;
}
export interface GetSpfInspectRequest {
    /** Identifier. */
    zoneId: string;
    /** DNS record ID (rec_tag) to inspect */
    id: string;
}
export type SpfInspectGetResponseComponentsList = Array<unknown>;
export interface SpfInspectGetResponseErrorsItem {
    /** Error code. Known values: */
    code: string;
    /** Domain where the error occurred */
    domain: string;
    /** Human-readable error message */
    message: string;
    /** Additional error-specific details (optional). */
    details?: string | null;
}
export type SpfInspectGetResponseErrorsList = Array<SpfInspectGetResponseErrorsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSpfInspectResponse {
    /** Parsed SPF components (mechanisms) */
    components: SpfInspectGetResponseComponentsList;
    /** Domain being inspected */
    domain: string;
    /** Raw SPF record content */
    record: string;
    /** Total number of DNS lookups performed across all includes */
    totalLookups: number;
    /** All errors encountered during inspection, collected from the entire tree. This includes errors from nested includes at any depth, providing a quick overview of all issues without needing to traverse the nested structure. Each error includes a `domain` field to identify where it occurred. Empty array if no errors (omitted from JSON when empty). */
    errors?: SpfInspectGetResponseErrorsList | null;
}
export interface PatchDmarcReportRequest {
    /** Identifier. */
    zoneId: string;
    /** Enable or disable DMARC reports for this zone */
    enabled?: boolean;
    /** Skip the DMARC setup wizard */
    skipWizard?: boolean;
}
export type DmarcReportsEditResponseApprovedSourcesItemIpsList = Array<string>;
export interface DmarcReportsEditResponseApprovedSourcesItem {
    /** Use `created_at` instead. */
    created?: string | null;
    /** Creation timestamp */
    createdAt?: string | null;
    /** The source domain */
    domain?: string | null;
    /** Resolved IP addresses from SPF */
    ips?: DmarcReportsEditResponseApprovedSourcesItemIpsList | null;
    /** Use `modified_at` instead. */
    modified?: string | null;
    /** Last modification timestamp */
    modifiedAt?: string | null;
    /** Source name (typically same as domain) */
    name?: string | null;
    /** URL-friendly identifier */
    slug?: string | null;
    /** Source UUID */
    tag?: string | null;
}
export type DmarcReportsEditResponseApprovedSourcesList = Array<DmarcReportsEditResponseApprovedSourcesItem>;
export type DmarcReportsEditResponseRecordsBimiRecordsItemResolvedList = Array<string>;
export interface DmarcReportsEditResponseRecordsBimiRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsEditResponseRecordsBimiRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsEditResponseRecordsBimiRecordsList = Array<DmarcReportsEditResponseRecordsBimiRecordsItem>;
export type DmarcReportsEditResponseRecordsCnameDkimRecordsItemResolvedList = Array<string>;
export interface DmarcReportsEditResponseRecordsCnameDkimRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsEditResponseRecordsCnameDkimRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsEditResponseRecordsCnameDkimRecordsList = Array<DmarcReportsEditResponseRecordsCnameDkimRecordsItem>;
export type DmarcReportsEditResponseRecordsCnameDmarcRecordsItemResolvedList = Array<string>;
export interface DmarcReportsEditResponseRecordsCnameDmarcRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsEditResponseRecordsCnameDmarcRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsEditResponseRecordsCnameDmarcRecordsList = Array<DmarcReportsEditResponseRecordsCnameDmarcRecordsItem>;
export type DmarcReportsEditResponseRecordsCnameSpfRecordsItemResolvedList = Array<string>;
export interface DmarcReportsEditResponseRecordsCnameSpfRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsEditResponseRecordsCnameSpfRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsEditResponseRecordsCnameSpfRecordsList = Array<DmarcReportsEditResponseRecordsCnameSpfRecordsItem>;
export type DmarcReportsEditResponseRecordsDkimRecordsItemResolvedList = Array<string>;
export interface DmarcReportsEditResponseRecordsDkimRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsEditResponseRecordsDkimRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsEditResponseRecordsDkimRecordsList = Array<DmarcReportsEditResponseRecordsDkimRecordsItem>;
export type DmarcReportsEditResponseRecordsDmarcRecordsItemResolvedList = Array<string>;
export interface DmarcReportsEditResponseRecordsDmarcRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsEditResponseRecordsDmarcRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsEditResponseRecordsDmarcRecordsList = Array<DmarcReportsEditResponseRecordsDmarcRecordsItem>;
export type DmarcReportsEditResponseRecordsResolvedDmarcRecordsItem = DmarcReportsGetResponseRecordsResolvedDmarcRecordsItem;
export type DmarcReportsEditResponseRecordsResolvedDmarcRecordsList = Array<DmarcReportsGetResponseRecordsResolvedDmarcRecordsItem>;
export type DmarcReportsEditResponseRecordsSpfRecordsItemResolvedList = Array<string>;
export interface DmarcReportsEditResponseRecordsSpfRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** For a CNAME record, the TXT content(s) found by following the CNAME chain to its target. An empty array means the chain was resolved but nothing usable was found there; omitted/null means resolution was not attempted for this record (always the case for non-CNAME entries). A CNAME chain that terminates in more than one TXT value at the target yields multiple entries. Populated on entries in cname_dmarc_records, cname_spf_records, and cname_dkim_records. */
    resolved?: DmarcReportsEditResponseRecordsSpfRecordsItemResolvedList | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export type DmarcReportsEditResponseRecordsSpfRecordsList = Array<DmarcReportsEditResponseRecordsSpfRecordsItem>;
export interface DmarcReportsEditResponseRecords {
    /** BIMI TXT records */
    bimiRecords?: DmarcReportsEditResponseRecordsBimiRecordsList | null;
    /** CNAME records for DKIM selectors. Each selector is resolved independently; when a selector's CNAME resolves to a DKIM TXT record, the API returns that record's content in the `resolved` field of the corresponding entry. */
    cnameDkimRecords?: DmarcReportsEditResponseRecordsCnameDkimRecordsList | null;
    /** CNAME records at _dmarc. When such a CNAME resolves to a DMARC TXT record, the API returns that record's content in the `resolved` field of the corresponding entry. */
    cnameDmarcRecords?: DmarcReportsEditResponseRecordsCnameDmarcRecordsList | null;
    /** CNAME records at the zone apex. When such a CNAME resolves to an SPF TXT record, the API returns that record's content in the `resolved` field of the corresponding entry. */
    cnameSpfRecords?: DmarcReportsEditResponseRecordsCnameSpfRecordsList | null;
    /** DKIM TXT records */
    dkimRecords?: DmarcReportsEditResponseRecordsDkimRecordsList | null;
    /** DMARC TXT records */
    dmarcRecords?: DmarcReportsEditResponseRecordsDmarcRecordsList | null;
    /** Use the `resolved` field on the corresponding entry in cname_dmarc_records instead. */
    resolvedDmarcRecords?: DmarcReportsEditResponseRecordsResolvedDmarcRecordsList | null;
    /** SPF TXT records */
    spfRecords?: DmarcReportsEditResponseRecordsSpfRecordsList | null;
}
export type DmarcReportsEditResponseStatus = "missing-dmarc-report" | "multiple-dmarc-reports" | "missing-dmarc-rua" | "cname-on-dmarc-record" | "unauthorized-reporting-domain";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchDmarcReportResponse {
    /** List of approved sending sources (omitted when empty) */
    approvedSources?: DmarcReportsEditResponseApprovedSourcesList | null;
    /** Use `created_at` instead. */
    created?: string | null;
    /** Creation timestamp */
    createdAt?: string | null;
    /** Whether DMARC reports are enabled */
    enabled?: boolean | null;
    /** Use `modified_at` instead. */
    modified?: string | null;
    /** Last modification timestamp */
    modifiedAt?: string | null;
    /** Live DNS records for the zone, grouped by type */
    records?: DmarcReportsEditResponseRecords | null;
    /** Prefix for DMARC RUA addresses (32-char hex string) */
    ruaPrefix?: string | null;
    /** Whether to skip the setup wizard */
    skipWizard?: boolean | null;
    /** DMARC configuration status. The API omits this field when DMARC is correctly configured. If the zone lacks a DMARC TXT record of its own, the API resolves _dmarc.{zone} recursively and evaluates whatever that lookup returns. A CNAME at _dmarc.{zone} that points to a valid DMARC record is therefore healthy; the cname-on-dmarc-record value means the CNAME resolves to no DMARC record at all. */
    status?: DmarcReportsEditResponseStatus | null;
    /** Use `zone_id` instead. */
    tag?: string | null;
    /** Zone identifier */
    zoneId?: string | null;
}
export type GetDmarcReportError = CloudflareOpError;
/** Retrieves the current DMARC report configuration and status for a zone. Returns the RUA prefix, enabled status, approved sources, and DNS records. */
export declare const getDmarcReport: API.OperationMethod<GetDmarcReportRequest, GetDmarcReportResponse, GetDmarcReportError, CloudflareOpContext>;
export type GetSpfInspectError = CloudflareOpError;
/** Inspects a specific SPF TXT record and returns a parsed tree structure in the spflimit-worker format. The record ID must be provided via the `id` query parameter. Returns a recursive tree showing: - Parsed components with their qualifiers and types - Nested includes recursively resolved within components - Per-component and total lookup counts - Detailed error information with context */
export declare const getSpfInspect: API.OperationMethod<GetSpfInspectRequest, GetSpfInspectResponse, GetSpfInspectError, CloudflareOpContext>;
export type PatchDmarcReportError = CloudflareOpError;
/** Updates the DMARC report configuration for a zone. At least one of `enabled` or `skip_wizard` must be provided. When enabling, the handler will ensure the DMARC RUA record exists in DNS. */
export declare const patchDmarcReport: API.OperationMethod<PatchDmarcReportRequest, PatchDmarcReportResponse, PatchDmarcReportError, CloudflareOpContext>;
//# sourceMappingURL=email_auth.d.ts.map