import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const LoadBalancerNotFound_base: S.TaggedErrorClass<"LoadBalancerNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class LoadBalancerNotFound extends /*@__PURE__*/ LoadBalancerNotFound_base {
}
declare const LoadBalancingNotEnabledForZone_base: S.TaggedErrorClass<"LoadBalancingNotEnabledForZone", {
    readonly code: any;
    readonly message: any;
}>;
export declare class LoadBalancingNotEnabledForZone extends /*@__PURE__*/ LoadBalancingNotEnabledForZone_base {
}
declare const MonitorGroupInUse_base: S.TaggedErrorClass<"MonitorGroupInUse", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MonitorGroupInUse extends /*@__PURE__*/ MonitorGroupInUse_base {
}
declare const MonitorGroupNotFound_base: S.TaggedErrorClass<"MonitorGroupNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MonitorGroupNotFound extends /*@__PURE__*/ MonitorGroupNotFound_base {
}
declare const MonitorGroupsNotEnabled_base: S.TaggedErrorClass<"MonitorGroupsNotEnabled", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MonitorGroupsNotEnabled extends /*@__PURE__*/ MonitorGroupsNotEnabled_base {
}
declare const MonitorIntervalOutOfRange_base: S.TaggedErrorClass<"MonitorIntervalOutOfRange", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MonitorIntervalOutOfRange extends /*@__PURE__*/ MonitorIntervalOutOfRange_base {
}
declare const MonitorInUse_base: S.TaggedErrorClass<"MonitorInUse", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MonitorInUse extends /*@__PURE__*/ MonitorInUse_base {
}
declare const MonitorNotFound_base: S.TaggedErrorClass<"MonitorNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class MonitorNotFound extends /*@__PURE__*/ MonitorNotFound_base {
}
declare const PoolAccessFailed_base: S.TaggedErrorClass<"PoolAccessFailed", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PoolAccessFailed extends /*@__PURE__*/ PoolAccessFailed_base {
}
declare const PoolInUse_base: S.TaggedErrorClass<"PoolInUse", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PoolInUse extends /*@__PURE__*/ PoolInUse_base {
}
declare const PoolNotFound_base: S.TaggedErrorClass<"PoolNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class PoolNotFound extends /*@__PURE__*/ PoolNotFound_base {
}
export type PoolsBulkEditRequestNotificationEmail = "";
export interface BulkPatchPoolsRequest {
    /** Identifier. */
    accountId: string;
    /** The email address to send health status notifications to. This field is now deprecated in favor of Cloudflare Notifications for Load Balancing, so only resetting this field with an empty string `""` is accepted. */
    notificationEmail?: PoolsBulkEditRequestNotificationEmail | (string & {});
}
export type PoolsBulkEditResultItemCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "CHINA" | "ALL_REGIONS";
export type PoolsBulkEditResultItemCheckRegionsList = Array<PoolsBulkEditResultItemCheckRegionsItem>;
export type PoolsBulkEditResultItemHealthSourcesItem = "local" | "regional" | "global";
export type PoolsBulkEditResultItemHealthSourcesList = Array<PoolsBulkEditResultItemHealthSourcesItem>;
export type PoolsBulkEditResultItemLoadSheddingDefaultPolicy = "random" | "hash";
export type PoolsBulkEditResultItemLoadSheddingSessionPolicy = "hash";
export interface PoolsBulkEditResultItemLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number | null;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsBulkEditResultItemLoadSheddingDefaultPolicy | null;
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number | null;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsBulkEditResultItemLoadSheddingSessionPolicy | null;
}
export type PoolsBulkEditResultItemNetworksList = Array<string>;
export interface PoolsBulkEditResultItemNotificationFilterOrigin {
    /** If set true, disable notifications for this type of resource (pool or origin). */
    disable?: boolean | null;
    /** If present, send notifications only for this health status (e.g. false for only DOWN events). Use null to reset (all events). */
    healthy?: boolean | null;
}
export type PoolsBulkEditResultItemNotificationFilterPool = PoolsBulkEditResultItemNotificationFilterOrigin;
export interface PoolsBulkEditResultItemNotificationFilter {
    /** Filter options for a particular resource type (pool or origin). Use null to reset. */
    origin?: PoolsBulkEditResultItemNotificationFilterOrigin | null;
    /** Filter options for a particular resource type (pool or origin). Use null to reset. */
    pool?: PoolsBulkEditResultItemNotificationFilterOrigin | null;
}
export type PoolsBulkEditResultItemOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export interface PoolsBulkEditResultItemOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsBulkEditResultItemOriginSteeringPolicy | null;
}
export type PoolsBulkEditResultItemOriginsItemHeaderHostList = Array<string>;
export interface PoolsBulkEditResultItemOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsBulkEditResultItemOriginsItemHeaderHostList | null;
}
export interface PoolsBulkEditResultItemOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string | null;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string | null;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean | null;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean | null;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsBulkEditResultItemOriginsItemHeader | null;
    /** A human-identifiable name for the origin. */
    name?: string | null;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number | null;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string | null;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number | null;
}
export type PoolsBulkEditResultItemOriginsList = Array<PoolsBulkEditResultItemOriginsItem>;
export interface PoolsBulkEditResultItem {
    id?: string | null;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsBulkEditResultItemCheckRegionsList | null;
    createdOn?: string | null;
    /** A human-readable description of the pool. */
    description?: string | null;
    /** This field shows up only if the pool is disabled. This field is set with the time the pool was disabled at. */
    disabledAt?: string | null;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean | null;
    /** A list of health sources, ordered from highest to lowest priority, used to evaluate individual origin health and overall pool health. The load balancer uses the first source that has data and falls back to the next. Currently accepted values are null or the exact array ["regional", "global"]; any other combination is rejected. Null (the default) behaves like ["local", "global"]. ["regional", "global"] makes each region steer on its own health, falling back to the global decision when a region has no fresh data. Setting regional requires at least one region in check_regions. */
    healthSources?: PoolsBulkEditResultItemHealthSourcesList | null;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number | null;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsBulkEditResultItemLoadShedding | null;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number | null;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number | null;
    modifiedOn?: string | null;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string | null;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string | null;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: PoolsBulkEditResultItemNetworksList | null;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string | null;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsBulkEditResultItemNotificationFilter | null;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsBulkEditResultItemOriginSteering | null;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsBulkEditResultItemOriginsList | null;
}
export type PoolsBulkEditResultList = Array<PoolsBulkEditResultItem>;
export interface BulkPatchPoolsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PoolsBulkEditResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type CreateRequestDefaultPoolsList = Array<string>;
export interface CreateRequestAdaptiveRouting {
    /** Extends zero-downtime failover of requests to healthy origins from alternate pools, when no healthy alternate exists in the same pool, according to the failover order defined by traffic and origin steering. When set false (the default) zero-downtime failover will only occur between origins within the same pool. See `session_affinity_attributes` for control over when sessions are broken or reassigned. */
    failoverAcrossPools?: boolean;
}
export type CreateRequestCountryPoolsValueList = Array<string>;
export type CreateRequestCountryPoolsMap = {
    [key: string]: CreateRequestCountryPoolsValueList | undefined;
};
export type CreateRequestLocationStrategyMode = "pop" | "resolver_ip";
export type CreateRequestLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface CreateRequestLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: CreateRequestLocationStrategyMode | (string & {});
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: CreateRequestLocationStrategyPreferEcs | (string & {});
}
export type CreateRequestNetworksList = Array<string>;
export type CreateRequestPopPoolsValueList = Array<string>;
export type CreateRequestPopPoolsMap = {
    [key: string]: CreateRequestPopPoolsValueList | undefined;
};
export type CreateRequestRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface CreateRequestRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: CreateRequestRandomSteeringPoolWeightsMap;
}
export type CreateRequestRegionPoolsValueList = Array<string>;
export type CreateRequestRegionPoolsMap = {
    [key: string]: CreateRequestRegionPoolsValueList | undefined;
};
export interface CreateRequestRulesItemFixedResponse {
    /** The http 'Content-Type' header to include in the response. */
    contentType?: string;
    /** The http 'Location' header to include in the response. */
    location?: string;
    /** Text to include as the http body. */
    messageBody?: string;
    /** The http status code to respond with. */
    statusCode?: number;
}
export type CreateRequestRulesItemOverridesAdaptiveRouting = CreateRequestAdaptiveRouting;
export type CreateRequestRulesItemOverridesCountryPoolsValueList = Array<string>;
export type CreateRequestRulesItemOverridesCountryPoolsMap = {
    [key: string]: CreateRequestRulesItemOverridesCountryPoolsValueList | undefined;
};
export type CreateRequestRulesItemOverridesDefaultPoolsList = Array<string>;
export type CreateRequestRulesItemOverridesLocationStrategyMode = "pop" | "resolver_ip";
export type CreateRequestRulesItemOverridesLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface CreateRequestRulesItemOverridesLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: CreateRequestRulesItemOverridesLocationStrategyMode | (string & {});
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: CreateRequestRulesItemOverridesLocationStrategyPreferEcs | (string & {});
}
export type CreateRequestRulesItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type CreateRequestRulesItemOverridesPoolsList = Array<string>;
export type CreateRequestRulesItemOverridesPopPoolsValueList = Array<string>;
export type CreateRequestRulesItemOverridesPopPoolsMap = {
    [key: string]: CreateRequestRulesItemOverridesPopPoolsValueList | undefined;
};
export type CreateRequestRulesItemOverridesRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface CreateRequestRulesItemOverridesRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: CreateRequestRulesItemOverridesRandomSteeringPoolWeightsMap;
}
export type CreateRequestRulesItemOverridesRegionPoolsValueList = Array<string>;
export type CreateRequestRulesItemOverridesRegionPoolsMap = {
    [key: string]: CreateRequestRulesItemOverridesRegionPoolsValueList | undefined;
};
export type CreateRequestRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type CreateRequestRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export type CreateRequestRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type CreateRequestRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type CreateRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface CreateRequestRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: CreateRequestRulesItemOverridesSessionAffinityAttributesHeadersList;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: CreateRequestRulesItemOverridesSessionAffinityAttributesSamesite | (string & {});
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: CreateRequestRulesItemOverridesSessionAffinityAttributesSecure | (string & {});
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: CreateRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | (string & {});
}
export type CreateRequestRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface CreateRequestRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateRequestAdaptiveRouting;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: CreateRequestRulesItemOverridesCountryPoolsMap;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: CreateRequestRulesItemOverridesDefaultPoolsList;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: CreateRequestRulesItemOverridesLocationStrategy;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: CreateRequestRulesItemOverridesPoolWeightsMap;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: CreateRequestRulesItemOverridesPoolsList;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: CreateRequestRulesItemOverridesPopPoolsMap;
    /** Configures pool weights. */
    randomSteering?: CreateRequestRulesItemOverridesRandomSteering;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: CreateRequestRulesItemOverridesRegionPoolsMap;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: CreateRequestRulesItemOverridesSessionAffinity | (string & {});
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: CreateRequestRulesItemOverridesSessionAffinityAttributes;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: CreateRequestRulesItemOverridesSteeringPolicy | (string & {});
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number;
}
export interface CreateRequestRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateRequestRulesItemFixedResponse;
    /** Name of this rule. Only used for human readability. */
    name?: string;
    /** A collection of overrides to apply when this rule's condition (or a pool set's `match`) is true. All fields are optional. */
    overrides?: CreateRequestRulesItemOverrides;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean;
}
export type CreateRequestRulesList = Array<CreateRequestRulesItem>;
export type CreateRequestSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type CreateRequestSessionAffinityAttributesHeadersList = Array<string>;
export type CreateRequestSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type CreateRequestSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type CreateRequestSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface CreateRequestSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: CreateRequestSessionAffinityAttributesHeadersList;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: CreateRequestSessionAffinityAttributesSamesite | (string & {});
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: CreateRequestSessionAffinityAttributesSecure | (string & {});
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: CreateRequestSessionAffinityAttributesZeroDowntimeFailover | (string & {});
}
export type CreateRequestSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface CreateLoadBalancerRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools: CreateRequestDefaultPoolsList;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool: string;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name: string;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateRequestAdaptiveRouting;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: CreateRequestCountryPoolsMap;
    /** Object description. */
    description?: string;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: CreateRequestLocationStrategy;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: CreateRequestNetworksList;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: CreateRequestPopPoolsMap;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean;
    /** Configures pool weights. */
    randomSteering?: CreateRequestRandomSteering;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: CreateRequestRegionPoolsMap;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: CreateRequestRulesList;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: CreateRequestSessionAffinity | (string & {});
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: CreateRequestSessionAffinityAttributes;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: CreateRequestSteeringPolicy | (string & {});
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number;
}
export interface CreateResponseAdaptiveRouting {
    /** Extends zero-downtime failover of requests to healthy origins from alternate pools, when no healthy alternate exists in the same pool, according to the failover order defined by traffic and origin steering. When set false (the default) zero-downtime failover will only occur between origins within the same pool. See `session_affinity_attributes` for control over when sessions are broken or reassigned. */
    failoverAcrossPools?: boolean | null;
}
export type CreateResponseCountryPoolsValueList = Array<string>;
export type CreateResponseCountryPoolsMap = {
    [key: string]: CreateResponseCountryPoolsValueList | undefined;
};
export type CreateResponseDefaultPoolsList = Array<string>;
export type CreateResponseLocationStrategyMode = "pop" | "resolver_ip";
export type CreateResponseLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface CreateResponseLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: CreateResponseLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: CreateResponseLocationStrategyPreferEcs | null;
}
export type CreateResponseNetworksList = Array<string>;
export interface CreateResponsePoolSetsItemFixedResponse {
    /** The http 'Content-Type' header to include in the response. */
    contentType?: string | null;
    /** The http 'Location' header to include in the response. */
    location?: string | null;
    /** Text to include as the http body. */
    messageBody?: string | null;
    /** The http status code to respond with. */
    statusCode?: number | null;
}
export type CreateResponsePoolSetsItemMatchTopologyCountriesList = Array<string>;
export type CreateResponsePoolSetsItemMatchTopologyPopsList = Array<string>;
export type CreateResponsePoolSetsItemMatchTopologyRegionsList = Array<string>;
export interface CreateResponsePoolSetsItemMatchTopology {
    /** A list of ISO 3166-1 alpha-2 country codes. Matches when the request's country is in this list. */
    countries?: CreateResponsePoolSetsItemMatchTopologyCountriesList | null;
    /** A list of Cloudflare PoP codes. Matches when the request's PoP is in this list. */
    pops?: CreateResponsePoolSetsItemMatchTopologyPopsList | null;
    /** A list of Cloudflare region codes (e.g. `WNAM`, `ENAM`, `WEU`). Matches when the request's region is in this list. */
    regions?: CreateResponsePoolSetsItemMatchTopologyRegionsList | null;
}
export interface CreateResponsePoolSetsItemMatch {
    /** When true, matches every request. Cannot be combined with `topology`. */
    default?: boolean | null;
    /** Matches requests by location. Set any combination of `pops`, `countries`, and `regions` (at least one is required); a request matches when its value appears in any populated list (e.g. `regions: ["WNAM"]` with `countries: ["US"]` matches a request in either WNAM or the US). */
    topology?: CreateResponsePoolSetsItemMatchTopology | null;
}
export type CreateResponsePoolSetsItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type CreateResponsePoolSetsItemOverridesPoolsList = Array<string>;
export type CreateResponsePoolSetsItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface CreateResponsePoolSetsItemOverrides {
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: CreateResponsePoolSetsItemOverridesPoolWeightsMap | null;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: CreateResponsePoolSetsItemOverridesPoolsList | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: CreateResponsePoolSetsItemOverridesSteeringPolicy | null;
}
export interface CreateResponsePoolSetsItem {
    /** Disable this specific pool set. It will no longer be evaluated. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateResponsePoolSetsItemFixedResponse | null;
    /** Determines which requests a pool set applies to. Set `topology` to match by location or `default: true` to match all requests; the two are mutually exclusive. A pool set with no `match` matches all requests. */
    match?: CreateResponsePoolSetsItemMatch | null;
    /** A human-readable name for this pool set. */
    name?: string | null;
    /** The behavior a pool set applies when its `match` succeeds. A strict subset of a rule's `overrides`: a pool set replaces the topology wholesale with a flat pool list (`pools`), so only the declarative pool-routing fields plus `fallback_pool` and `steering_policy` are settable. All fields are optional. */
    overrides?: CreateResponsePoolSetsItemOverrides | null;
}
export type CreateResponsePoolSetsList = Array<CreateResponsePoolSetsItem>;
export type CreateResponsePopPoolsValueList = Array<string>;
export type CreateResponsePopPoolsMap = {
    [key: string]: CreateResponsePopPoolsValueList | undefined;
};
export type CreateResponseRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface CreateResponseRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: CreateResponseRandomSteeringPoolWeightsMap | null;
}
export type CreateResponseRegionPoolsValueList = Array<string>;
export type CreateResponseRegionPoolsMap = {
    [key: string]: CreateResponseRegionPoolsValueList | undefined;
};
export type CreateResponseRulesItemFixedResponse = CreateResponsePoolSetsItemFixedResponse;
export type CreateResponseRulesItemOverridesAdaptiveRouting = CreateResponseAdaptiveRouting;
export type CreateResponseRulesItemOverridesCountryPoolsValueList = Array<string>;
export type CreateResponseRulesItemOverridesCountryPoolsMap = {
    [key: string]: CreateResponseRulesItemOverridesCountryPoolsValueList | undefined;
};
export type CreateResponseRulesItemOverridesDefaultPoolsList = Array<string>;
export type CreateResponseRulesItemOverridesLocationStrategyMode = "pop" | "resolver_ip";
export type CreateResponseRulesItemOverridesLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface CreateResponseRulesItemOverridesLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: CreateResponseRulesItemOverridesLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: CreateResponseRulesItemOverridesLocationStrategyPreferEcs | null;
}
export type CreateResponseRulesItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type CreateResponseRulesItemOverridesPoolsList = Array<string>;
export type CreateResponseRulesItemOverridesPopPoolsValueList = Array<string>;
export type CreateResponseRulesItemOverridesPopPoolsMap = {
    [key: string]: CreateResponseRulesItemOverridesPopPoolsValueList | undefined;
};
export type CreateResponseRulesItemOverridesRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface CreateResponseRulesItemOverridesRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: CreateResponseRulesItemOverridesRandomSteeringPoolWeightsMap | null;
}
export type CreateResponseRulesItemOverridesRegionPoolsValueList = Array<string>;
export type CreateResponseRulesItemOverridesRegionPoolsMap = {
    [key: string]: CreateResponseRulesItemOverridesRegionPoolsValueList | undefined;
};
export type CreateResponseRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type CreateResponseRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export type CreateResponseRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type CreateResponseRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type CreateResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface CreateResponseRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: CreateResponseRulesItemOverridesSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: CreateResponseRulesItemOverridesSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: CreateResponseRulesItemOverridesSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: CreateResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | null;
}
export type CreateResponseRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface CreateResponseRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: CreateResponseRulesItemOverridesCountryPoolsMap | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: CreateResponseRulesItemOverridesDefaultPoolsList | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: CreateResponseRulesItemOverridesLocationStrategy | null;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: CreateResponseRulesItemOverridesPoolWeightsMap | null;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: CreateResponseRulesItemOverridesPoolsList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: CreateResponseRulesItemOverridesPopPoolsMap | null;
    /** Configures pool weights. */
    randomSteering?: CreateResponseRulesItemOverridesRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: CreateResponseRulesItemOverridesRegionPoolsMap | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: CreateResponseRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: CreateResponseRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: CreateResponseRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
}
export interface CreateResponseRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string | null;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateResponsePoolSetsItemFixedResponse | null;
    /** Name of this rule. Only used for human readability. */
    name?: string | null;
    /** A collection of overrides to apply when this rule's condition (or a pool set's `match`) is true. All fields are optional. */
    overrides?: CreateResponseRulesItemOverrides | null;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number | null;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean | null;
}
export type CreateResponseRulesList = Array<CreateResponseRulesItem>;
export type CreateResponseSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type CreateResponseSessionAffinityAttributesHeadersList = Array<string>;
export type CreateResponseSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type CreateResponseSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type CreateResponseSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface CreateResponseSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: CreateResponseSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: CreateResponseSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: CreateResponseSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: CreateResponseSessionAffinityAttributesZeroDowntimeFailover | null;
}
export type CreateResponseSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLoadBalancerResponse {
    id?: string | null;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: CreateResponseCountryPoolsMap | null;
    createdOn?: string | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: CreateResponseDefaultPoolsList | null;
    /** Object description. */
    description?: string | null;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: CreateResponseLocationStrategy | null;
    modifiedOn?: string | null;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: CreateResponseNetworksList | null;
    /** An optional list of pool sets, evaluated in array order with first match wins. Pool sets are independent from the standard steering fields (`region_pools` / `country_pools` / `pop_pools` / `default_pools` / `steering_policy` / `random_steering` / `fallback_pool` / `rules`). On a PATCH, an empty array (`pool_sets: []`) clears all pool sets, while omitting the field leaves existing pool sets unchanged. */
    poolSets?: CreateResponsePoolSetsList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: CreateResponsePopPoolsMap | null;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean | null;
    /** Configures pool weights. */
    randomSteering?: CreateResponseRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: CreateResponseRegionPoolsMap | null;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: CreateResponseRulesList | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: CreateResponseSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: CreateResponseSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: CreateResponseSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
    zoneName?: string | null;
}
export type MonitorsCreateRequestHeaderValueList = Array<string>;
export type MonitorsCreateRequestHeaderMap = {
    [key: string]: MonitorsCreateRequestHeaderValueList | undefined;
};
export type MonitorsCreateRequestType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export interface CreateMonitorRequest {
    /** Identifier. */
    accountId: string;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number;
    /** Object description. */
    description?: string;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsCreateRequestHeaderMap;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsCreateRequestType | (string & {});
}
export type MonitorsCreateResponseHeaderValueList = Array<string>;
export type MonitorsCreateResponseHeaderMap = {
    [key: string]: MonitorsCreateResponseHeaderValueList | undefined;
};
export type MonitorsCreateResponseType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMonitorResponse {
    id?: string | null;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean | null;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number | null;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number | null;
    createdOn?: string | null;
    /** Object description. */
    description?: string | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string | null;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string | null;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsCreateResponseHeaderMap | null;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number | null;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string | null;
    modifiedOn?: string | null;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string | null;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number | null;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsCreateResponseType | null;
}
export interface MonitorGroupsCreateRequestMembersItem {
    /** Whether this monitor is enabled in the group */
    enabled: boolean;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitorId: string;
    /** Whether this monitor is used for monitoring only (does not affect pool health) */
    monitoringOnly: boolean;
    /** Whether this monitor must be healthy for the pool to be considered healthy */
    mustBeHealthy: boolean;
    /** The timestamp of when the monitor was added to the group */
    createdAt?: string;
    /** The timestamp of when the monitor group member was last updated */
    updatedAt?: string;
}
export type MonitorGroupsCreateRequestMembersList = Array<MonitorGroupsCreateRequestMembersItem>;
export interface CreateMonitorGroupRequest {
    /** Identifier. */
    accountId: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsCreateRequestMembersList;
}
export interface MonitorGroupsCreateResponseMembersItem {
    /** Whether this monitor is enabled in the group */
    enabled: boolean;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitorId: string;
    /** Whether this monitor is used for monitoring only (does not affect pool health) */
    monitoringOnly: boolean;
    /** Whether this monitor must be healthy for the pool to be considered healthy */
    mustBeHealthy: boolean;
    /** The timestamp of when the monitor was added to the group */
    createdAt?: string | null;
    /** The timestamp of when the monitor group member was last updated */
    updatedAt?: string | null;
}
export type MonitorGroupsCreateResponseMembersList = Array<MonitorGroupsCreateResponseMembersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMonitorGroupResponse {
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    id: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsCreateResponseMembersList;
    /** The timestamp of when the monitor group was created */
    createdOn?: string | null;
    /** The timestamp of when the monitor group was last updated */
    modifiedOn?: string | null;
}
export type MonitorsPreviewsCreateRequestHeaderValueList = Array<string>;
export type MonitorsPreviewsCreateRequestHeaderMap = {
    [key: string]: MonitorsPreviewsCreateRequestHeaderValueList | undefined;
};
export type MonitorsPreviewsCreateRequestType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export interface CreateMonitorPreviewRequest {
    /** Identifier. */
    accountId: string;
    monitorId: string;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number;
    /** Object description. */
    description?: string;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsPreviewsCreateRequestHeaderMap;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsPreviewsCreateRequestType | (string & {});
}
export type MonitorsPreviewsCreateResponsePoolsMap = {
    [key: string]: string | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMonitorPreviewResponse {
    /** Monitored pool IDs mapped to their respective names. */
    pools?: MonitorsPreviewsCreateResponsePoolsMap | null;
    previewId?: string | null;
}
export type PoolsCreateRequestOriginsItemHeaderHostList = Array<string>;
export interface PoolsCreateRequestOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsCreateRequestOriginsItemHeaderHostList;
}
export interface PoolsCreateRequestOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsCreateRequestOriginsItemHeader;
    /** A human-identifiable name for the origin. */
    name?: string;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number;
}
export type PoolsCreateRequestOriginsList = Array<PoolsCreateRequestOriginsItem>;
export type PoolsCreateRequestLoadSheddingDefaultPolicy = "random" | "hash";
export type PoolsCreateRequestLoadSheddingSessionPolicy = "hash";
export interface PoolsCreateRequestLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsCreateRequestLoadSheddingDefaultPolicy | (string & {});
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsCreateRequestLoadSheddingSessionPolicy | (string & {});
}
export interface PoolsCreateRequestNotificationFilterOrigin {
    /** If set true, disable notifications for this type of resource (pool or origin). */
    disable?: boolean;
    /** If present, send notifications only for this health status (e.g. false for only DOWN events). Use null to reset (all events). */
    healthy?: boolean;
}
export type PoolsCreateRequestNotificationFilterPool = PoolsCreateRequestNotificationFilterOrigin;
export interface PoolsCreateRequestNotificationFilter {
    /** Filter options for a particular resource type (pool or origin). Use null to reset. */
    origin?: PoolsCreateRequestNotificationFilterOrigin;
    /** Filter options for a particular resource type (pool or origin). Use null to reset. */
    pool?: PoolsCreateRequestNotificationFilterOrigin;
}
export type PoolsCreateRequestOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export interface PoolsCreateRequestOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsCreateRequestOriginSteeringPolicy | (string & {});
}
export interface CreatePoolRequest {
    /** Identifier. */
    accountId: string;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name: string;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins: PoolsCreateRequestOriginsList;
    /** A human-readable description of the pool. */
    description?: string;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsCreateRequestLoadShedding;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsCreateRequestNotificationFilter;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsCreateRequestOriginSteering;
}
export type PoolsCreateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "CHINA" | "ALL_REGIONS";
export type PoolsCreateResponseCheckRegionsList = Array<PoolsCreateResponseCheckRegionsItem>;
export type PoolsCreateResponseHealthSourcesItem = "local" | "regional" | "global";
export type PoolsCreateResponseHealthSourcesList = Array<PoolsCreateResponseHealthSourcesItem>;
export type PoolsCreateResponseLoadSheddingDefaultPolicy = "random" | "hash";
export type PoolsCreateResponseLoadSheddingSessionPolicy = "hash";
export interface PoolsCreateResponseLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number | null;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsCreateResponseLoadSheddingDefaultPolicy | null;
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number | null;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsCreateResponseLoadSheddingSessionPolicy | null;
}
export type PoolsCreateResponseNetworksList = Array<string>;
export type PoolsCreateResponseNotificationFilterOrigin = PoolsBulkEditResultItemNotificationFilterOrigin;
export type PoolsCreateResponseNotificationFilterPool = PoolsBulkEditResultItemNotificationFilterOrigin;
export type PoolsCreateResponseNotificationFilter = PoolsBulkEditResultItemNotificationFilter;
export type PoolsCreateResponseOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export interface PoolsCreateResponseOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsCreateResponseOriginSteeringPolicy | null;
}
export type PoolsCreateResponseOriginsItemHeaderHostList = Array<string>;
export interface PoolsCreateResponseOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsCreateResponseOriginsItemHeaderHostList | null;
}
export interface PoolsCreateResponseOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string | null;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string | null;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean | null;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean | null;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsCreateResponseOriginsItemHeader | null;
    /** A human-identifiable name for the origin. */
    name?: string | null;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number | null;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string | null;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number | null;
}
export type PoolsCreateResponseOriginsList = Array<PoolsCreateResponseOriginsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePoolResponse {
    id?: string | null;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsCreateResponseCheckRegionsList | null;
    createdOn?: string | null;
    /** A human-readable description of the pool. */
    description?: string | null;
    /** This field shows up only if the pool is disabled. This field is set with the time the pool was disabled at. */
    disabledAt?: string | null;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean | null;
    /** A list of health sources, ordered from highest to lowest priority, used to evaluate individual origin health and overall pool health. The load balancer uses the first source that has data and falls back to the next. Currently accepted values are null or the exact array ["regional", "global"]; any other combination is rejected. Null (the default) behaves like ["local", "global"]. ["regional", "global"] makes each region steer on its own health, falling back to the global decision when a region has no fresh data. Setting regional requires at least one region in check_regions. */
    healthSources?: PoolsCreateResponseHealthSourcesList | null;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number | null;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsCreateResponseLoadShedding | null;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number | null;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number | null;
    modifiedOn?: string | null;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string | null;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string | null;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: PoolsCreateResponseNetworksList | null;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string | null;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsBulkEditResultItemNotificationFilter | null;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsCreateResponseOriginSteering | null;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsCreateResponseOriginsList | null;
}
export type PoolsHealthCreateRequestHeaderValueList = Array<string>;
export type PoolsHealthCreateRequestHeaderMap = {
    [key: string]: PoolsHealthCreateRequestHeaderValueList | undefined;
};
export type PoolsHealthCreateRequestType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export interface CreatePoolHealthRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number;
    /** Object description. */
    description?: string;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: PoolsHealthCreateRequestHeaderMap;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: PoolsHealthCreateRequestType | (string & {});
}
export type PoolsHealthCreateResponsePoolsMap = {
    [key: string]: string | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePoolHealthResponse {
    /** Monitored pool IDs mapped to their respective names. */
    pools?: PoolsHealthCreateResponsePoolsMap | null;
    previewId?: string | null;
}
export interface DeleteLoadBalancerRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    loadBalancerId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteLoadBalancerResponse {
    id?: string | null;
}
export interface DeleteMonitorRequest {
    /** Identifier. */
    accountId: string;
    monitorId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMonitorResponse {
    id?: string | null;
}
export interface DeleteMonitorGroupRequest {
    /** Identifier. */
    accountId: string;
    monitorGroupId: string;
}
export type MonitorGroupsDeleteResponseMembersItem = MonitorGroupsCreateResponseMembersItem;
export type MonitorGroupsDeleteResponseMembersList = Array<MonitorGroupsCreateResponseMembersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMonitorGroupResponse {
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    id: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsDeleteResponseMembersList;
    /** The timestamp of when the monitor group was created */
    createdOn?: string | null;
    /** The timestamp of when the monitor group was last updated */
    modifiedOn?: string | null;
}
export interface DeletePoolRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeletePoolResponse {
    id?: string | null;
}
export interface GetLoadBalancerRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    loadBalancerId: string;
}
export type GetResponseAdaptiveRouting = CreateResponseAdaptiveRouting;
export type GetResponseCountryPoolsValueList = Array<string>;
export type GetResponseCountryPoolsMap = {
    [key: string]: GetResponseCountryPoolsValueList | undefined;
};
export type GetResponseDefaultPoolsList = Array<string>;
export type GetResponseLocationStrategyMode = "pop" | "resolver_ip";
export type GetResponseLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface GetResponseLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: GetResponseLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: GetResponseLocationStrategyPreferEcs | null;
}
export type GetResponseNetworksList = Array<string>;
export type GetResponsePoolSetsItemFixedResponse = CreateResponsePoolSetsItemFixedResponse;
export type GetResponsePoolSetsItemMatchTopologyCountriesList = Array<string>;
export type GetResponsePoolSetsItemMatchTopologyPopsList = Array<string>;
export type GetResponsePoolSetsItemMatchTopologyRegionsList = Array<string>;
export interface GetResponsePoolSetsItemMatchTopology {
    /** A list of ISO 3166-1 alpha-2 country codes. Matches when the request's country is in this list. */
    countries?: GetResponsePoolSetsItemMatchTopologyCountriesList | null;
    /** A list of Cloudflare PoP codes. Matches when the request's PoP is in this list. */
    pops?: GetResponsePoolSetsItemMatchTopologyPopsList | null;
    /** A list of Cloudflare region codes (e.g. `WNAM`, `ENAM`, `WEU`). Matches when the request's region is in this list. */
    regions?: GetResponsePoolSetsItemMatchTopologyRegionsList | null;
}
export interface GetResponsePoolSetsItemMatch {
    /** When true, matches every request. Cannot be combined with `topology`. */
    default?: boolean | null;
    /** Matches requests by location. Set any combination of `pops`, `countries`, and `regions` (at least one is required); a request matches when its value appears in any populated list (e.g. `regions: ["WNAM"]` with `countries: ["US"]` matches a request in either WNAM or the US). */
    topology?: GetResponsePoolSetsItemMatchTopology | null;
}
export type GetResponsePoolSetsItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type GetResponsePoolSetsItemOverridesPoolsList = Array<string>;
export type GetResponsePoolSetsItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface GetResponsePoolSetsItemOverrides {
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: GetResponsePoolSetsItemOverridesPoolWeightsMap | null;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: GetResponsePoolSetsItemOverridesPoolsList | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: GetResponsePoolSetsItemOverridesSteeringPolicy | null;
}
export interface GetResponsePoolSetsItem {
    /** Disable this specific pool set. It will no longer be evaluated. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateResponsePoolSetsItemFixedResponse | null;
    /** Determines which requests a pool set applies to. Set `topology` to match by location or `default: true` to match all requests; the two are mutually exclusive. A pool set with no `match` matches all requests. */
    match?: GetResponsePoolSetsItemMatch | null;
    /** A human-readable name for this pool set. */
    name?: string | null;
    /** The behavior a pool set applies when its `match` succeeds. A strict subset of a rule's `overrides`: a pool set replaces the topology wholesale with a flat pool list (`pools`), so only the declarative pool-routing fields plus `fallback_pool` and `steering_policy` are settable. All fields are optional. */
    overrides?: GetResponsePoolSetsItemOverrides | null;
}
export type GetResponsePoolSetsList = Array<GetResponsePoolSetsItem>;
export type GetResponsePopPoolsValueList = Array<string>;
export type GetResponsePopPoolsMap = {
    [key: string]: GetResponsePopPoolsValueList | undefined;
};
export type GetResponseRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface GetResponseRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: GetResponseRandomSteeringPoolWeightsMap | null;
}
export type GetResponseRegionPoolsValueList = Array<string>;
export type GetResponseRegionPoolsMap = {
    [key: string]: GetResponseRegionPoolsValueList | undefined;
};
export type GetResponseRulesItemFixedResponse = CreateResponsePoolSetsItemFixedResponse;
export type GetResponseRulesItemOverridesAdaptiveRouting = CreateResponseAdaptiveRouting;
export type GetResponseRulesItemOverridesCountryPoolsValueList = Array<string>;
export type GetResponseRulesItemOverridesCountryPoolsMap = {
    [key: string]: GetResponseRulesItemOverridesCountryPoolsValueList | undefined;
};
export type GetResponseRulesItemOverridesDefaultPoolsList = Array<string>;
export type GetResponseRulesItemOverridesLocationStrategyMode = "pop" | "resolver_ip";
export type GetResponseRulesItemOverridesLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface GetResponseRulesItemOverridesLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: GetResponseRulesItemOverridesLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: GetResponseRulesItemOverridesLocationStrategyPreferEcs | null;
}
export type GetResponseRulesItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type GetResponseRulesItemOverridesPoolsList = Array<string>;
export type GetResponseRulesItemOverridesPopPoolsValueList = Array<string>;
export type GetResponseRulesItemOverridesPopPoolsMap = {
    [key: string]: GetResponseRulesItemOverridesPopPoolsValueList | undefined;
};
export type GetResponseRulesItemOverridesRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface GetResponseRulesItemOverridesRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: GetResponseRulesItemOverridesRandomSteeringPoolWeightsMap | null;
}
export type GetResponseRulesItemOverridesRegionPoolsValueList = Array<string>;
export type GetResponseRulesItemOverridesRegionPoolsMap = {
    [key: string]: GetResponseRulesItemOverridesRegionPoolsValueList | undefined;
};
export type GetResponseRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type GetResponseRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export type GetResponseRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type GetResponseRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type GetResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface GetResponseRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: GetResponseRulesItemOverridesSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: GetResponseRulesItemOverridesSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: GetResponseRulesItemOverridesSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: GetResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | null;
}
export type GetResponseRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface GetResponseRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: GetResponseRulesItemOverridesCountryPoolsMap | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: GetResponseRulesItemOverridesDefaultPoolsList | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: GetResponseRulesItemOverridesLocationStrategy | null;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: GetResponseRulesItemOverridesPoolWeightsMap | null;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: GetResponseRulesItemOverridesPoolsList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: GetResponseRulesItemOverridesPopPoolsMap | null;
    /** Configures pool weights. */
    randomSteering?: GetResponseRulesItemOverridesRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: GetResponseRulesItemOverridesRegionPoolsMap | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: GetResponseRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: GetResponseRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: GetResponseRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
}
export interface GetResponseRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string | null;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateResponsePoolSetsItemFixedResponse | null;
    /** Name of this rule. Only used for human readability. */
    name?: string | null;
    /** A collection of overrides to apply when this rule's condition (or a pool set's `match`) is true. All fields are optional. */
    overrides?: GetResponseRulesItemOverrides | null;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number | null;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean | null;
}
export type GetResponseRulesList = Array<GetResponseRulesItem>;
export type GetResponseSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type GetResponseSessionAffinityAttributesHeadersList = Array<string>;
export type GetResponseSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type GetResponseSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type GetResponseSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface GetResponseSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: GetResponseSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: GetResponseSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: GetResponseSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: GetResponseSessionAffinityAttributesZeroDowntimeFailover | null;
}
export type GetResponseSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLoadBalancerResponse {
    id?: string | null;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: GetResponseCountryPoolsMap | null;
    createdOn?: string | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: GetResponseDefaultPoolsList | null;
    /** Object description. */
    description?: string | null;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: GetResponseLocationStrategy | null;
    modifiedOn?: string | null;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: GetResponseNetworksList | null;
    /** An optional list of pool sets, evaluated in array order with first match wins. Pool sets are independent from the standard steering fields (`region_pools` / `country_pools` / `pop_pools` / `default_pools` / `steering_policy` / `random_steering` / `fallback_pool` / `rules`). On a PATCH, an empty array (`pool_sets: []`) clears all pool sets, while omitting the field leaves existing pool sets unchanged. */
    poolSets?: GetResponsePoolSetsList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: GetResponsePopPoolsMap | null;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean | null;
    /** Configures pool weights. */
    randomSteering?: GetResponseRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: GetResponseRegionPoolsMap | null;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: GetResponseRulesList | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: GetResponseSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: GetResponseSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: GetResponseSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
    zoneName?: string | null;
}
export interface GetMonitorRequest {
    /** Identifier. */
    accountId: string;
    monitorId: string;
}
export type MonitorsGetResponseHeaderValueList = Array<string>;
export type MonitorsGetResponseHeaderMap = {
    [key: string]: MonitorsGetResponseHeaderValueList | undefined;
};
export type MonitorsGetResponseType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMonitorResponse {
    id?: string | null;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean | null;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number | null;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number | null;
    createdOn?: string | null;
    /** Object description. */
    description?: string | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string | null;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string | null;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsGetResponseHeaderMap | null;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number | null;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string | null;
    modifiedOn?: string | null;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string | null;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number | null;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsGetResponseType | null;
}
export interface GetMonitorGroupRequest {
    /** Identifier. */
    accountId: string;
    monitorGroupId: string;
}
export type MonitorGroupsGetResponseMembersItem = MonitorGroupsCreateResponseMembersItem;
export type MonitorGroupsGetResponseMembersList = Array<MonitorGroupsCreateResponseMembersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMonitorGroupResponse {
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    id: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsGetResponseMembersList;
    /** The timestamp of when the monitor group was created */
    createdOn?: string | null;
    /** The timestamp of when the monitor group was last updated */
    modifiedOn?: string | null;
}
export interface GetMonitorGroupReferenceRequest {
    /** Identifier. */
    accountId: string;
    monitorGroupId: string;
}
export type MonitorGroupsReferencesGetResultItemReferenceType = "*" | "referral" | "referrer";
export interface MonitorGroupsReferencesGetResultItem {
    referenceType?: MonitorGroupsReferencesGetResultItemReferenceType | null;
    resourceId?: string | null;
    resourceName?: string | null;
    resourceType?: string | null;
}
export type MonitorGroupsReferencesGetResultList = Array<MonitorGroupsReferencesGetResultItem>;
export interface GetMonitorGroupReferenceResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MonitorGroupsReferencesGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetMonitorReferenceRequest {
    /** Identifier. */
    accountId: string;
    monitorId: string;
}
export type MonitorsReferencesGetResultItemReferenceType = "*" | "referral" | "referrer";
export interface MonitorsReferencesGetResultItem {
    referenceType?: MonitorsReferencesGetResultItemReferenceType | null;
    resourceId?: string | null;
    resourceName?: string | null;
    resourceType?: string | null;
}
export type MonitorsReferencesGetResultList = Array<MonitorsReferencesGetResultItem>;
export interface GetMonitorReferenceResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MonitorsReferencesGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetPoolRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
}
export type PoolsGetResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "CHINA" | "ALL_REGIONS";
export type PoolsGetResponseCheckRegionsList = Array<PoolsGetResponseCheckRegionsItem>;
export type PoolsGetResponseHealthSourcesItem = "local" | "regional" | "global";
export type PoolsGetResponseHealthSourcesList = Array<PoolsGetResponseHealthSourcesItem>;
export type PoolsGetResponseLoadSheddingDefaultPolicy = "random" | "hash";
export type PoolsGetResponseLoadSheddingSessionPolicy = "hash";
export interface PoolsGetResponseLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number | null;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsGetResponseLoadSheddingDefaultPolicy | null;
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number | null;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsGetResponseLoadSheddingSessionPolicy | null;
}
export type PoolsGetResponseNetworksList = Array<string>;
export type PoolsGetResponseNotificationFilterOrigin = PoolsBulkEditResultItemNotificationFilterOrigin;
export type PoolsGetResponseNotificationFilterPool = PoolsBulkEditResultItemNotificationFilterOrigin;
export type PoolsGetResponseNotificationFilter = PoolsBulkEditResultItemNotificationFilter;
export type PoolsGetResponseOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export interface PoolsGetResponseOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsGetResponseOriginSteeringPolicy | null;
}
export type PoolsGetResponseOriginsItemHeaderHostList = Array<string>;
export interface PoolsGetResponseOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsGetResponseOriginsItemHeaderHostList | null;
}
export interface PoolsGetResponseOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string | null;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string | null;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean | null;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean | null;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsGetResponseOriginsItemHeader | null;
    /** A human-identifiable name for the origin. */
    name?: string | null;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number | null;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string | null;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number | null;
}
export type PoolsGetResponseOriginsList = Array<PoolsGetResponseOriginsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPoolResponse {
    id?: string | null;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsGetResponseCheckRegionsList | null;
    createdOn?: string | null;
    /** A human-readable description of the pool. */
    description?: string | null;
    /** This field shows up only if the pool is disabled. This field is set with the time the pool was disabled at. */
    disabledAt?: string | null;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean | null;
    /** A list of health sources, ordered from highest to lowest priority, used to evaluate individual origin health and overall pool health. The load balancer uses the first source that has data and falls back to the next. Currently accepted values are null or the exact array ["regional", "global"]; any other combination is rejected. Null (the default) behaves like ["local", "global"]. ["regional", "global"] makes each region steer on its own health, falling back to the global decision when a region has no fresh data. Setting regional requires at least one region in check_regions. */
    healthSources?: PoolsGetResponseHealthSourcesList | null;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number | null;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsGetResponseLoadShedding | null;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number | null;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number | null;
    modifiedOn?: string | null;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string | null;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string | null;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: PoolsGetResponseNetworksList | null;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string | null;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsBulkEditResultItemNotificationFilter | null;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsGetResponseOriginSteering | null;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsGetResponseOriginsList | null;
}
export interface GetPoolHealthRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
}
export interface PoolsHealthGetResponsePopHealthOriginsItemIp {
    /** Failure reason. */
    failureReason?: string | null;
    /** Origin health status. */
    healthy?: boolean | null;
    /** Response code from origin health check. */
    responseCode?: number | null;
    /** Origin RTT (Round Trip Time) response. */
    rtt?: string | null;
}
export interface PoolsHealthGetResponsePopHealthOriginsItem {
    ip?: PoolsHealthGetResponsePopHealthOriginsItemIp | null;
}
export type PoolsHealthGetResponsePopHealthOriginsList = Array<PoolsHealthGetResponsePopHealthOriginsItem>;
export interface PoolsHealthGetResponsePopHealth {
    /** Whether health check in region is healthy. */
    healthy?: boolean | null;
    origins?: PoolsHealthGetResponsePopHealthOriginsList | null;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPoolHealthResponse {
    /** Pool ID. */
    poolId?: string | null;
    /** List of regions and associated health status. */
    popHealth?: PoolsHealthGetResponsePopHealth | null;
}
export interface GetPoolReferenceRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
}
export type PoolsReferencesGetResultItemReferenceType = "*" | "referral" | "referrer";
export interface PoolsReferencesGetResultItem {
    referenceType?: PoolsReferencesGetResultItemReferenceType | null;
    resourceId?: string | null;
    resourceName?: string | null;
    resourceType?: string | null;
}
export type PoolsReferencesGetResultList = Array<PoolsReferencesGetResultItem>;
export interface GetPoolReferenceResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PoolsReferencesGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface GetPreviewRequest {
    /** Identifier. */
    accountId: string;
    previewId: string;
}
export interface PreviewsGetResultValueOriginsItemValue {
    failureReason?: string | null;
    healthy?: boolean | null;
    responseCode?: number | null;
    rtt?: string | null;
}
export type PreviewsGetResultValueOriginsItemMap = {
    [key: string]: PreviewsGetResultValueOriginsItemValue | undefined;
};
export type PreviewsGetResultValueOriginsList = Array<PreviewsGetResultValueOriginsItemMap>;
export interface PreviewsGetResultValue {
    healthy?: boolean | null;
    origins?: PreviewsGetResultValueOriginsList | null;
}
export type PreviewsGetResultMap = {
    [key: string]: PreviewsGetResultValue | undefined;
};
export type GetPreviewResponse = PreviewsGetResultMap;
export type RegionsGetRequestRegionId = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS";
export interface GetRegionRequest {
    /** Identifier. */
    accountId: string;
    /** A list of Cloudflare regions. WNAM: Western North America, ENAM: Eastern North America, WEU: Western Europe, EEU: Eastern Europe, NSAM: Northern South America, SSAM: Southern South America, OC: Oceania, ME: Middle East, NAF: North Africa, SAF: South Africa, SAS: Southern Asia, SEAS: South East Asia, NEAS: North East Asia). */
    regionId: RegionsGetRequestRegionId | (string & {});
}
export type GetRegionResponse = unknown;
export interface ListLoadBalancersRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
}
export type ListResultItemAdaptiveRouting = CreateResponseAdaptiveRouting;
export type ListResultItemCountryPoolsValueList = Array<string>;
export type ListResultItemCountryPoolsMap = {
    [key: string]: ListResultItemCountryPoolsValueList | undefined;
};
export type ListResultItemDefaultPoolsList = Array<string>;
export type ListResultItemLocationStrategyMode = "pop" | "resolver_ip";
export type ListResultItemLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface ListResultItemLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: ListResultItemLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: ListResultItemLocationStrategyPreferEcs | null;
}
export type ListResultItemNetworksList = Array<string>;
export type ListResultItemPoolSetsItemFixedResponse = CreateResponsePoolSetsItemFixedResponse;
export type ListResultItemPoolSetsItemMatchTopologyCountriesList = Array<string>;
export type ListResultItemPoolSetsItemMatchTopologyPopsList = Array<string>;
export type ListResultItemPoolSetsItemMatchTopologyRegionsList = Array<string>;
export interface ListResultItemPoolSetsItemMatchTopology {
    /** A list of ISO 3166-1 alpha-2 country codes. Matches when the request's country is in this list. */
    countries?: ListResultItemPoolSetsItemMatchTopologyCountriesList | null;
    /** A list of Cloudflare PoP codes. Matches when the request's PoP is in this list. */
    pops?: ListResultItemPoolSetsItemMatchTopologyPopsList | null;
    /** A list of Cloudflare region codes (e.g. `WNAM`, `ENAM`, `WEU`). Matches when the request's region is in this list. */
    regions?: ListResultItemPoolSetsItemMatchTopologyRegionsList | null;
}
export interface ListResultItemPoolSetsItemMatch {
    /** When true, matches every request. Cannot be combined with `topology`. */
    default?: boolean | null;
    /** Matches requests by location. Set any combination of `pops`, `countries`, and `regions` (at least one is required); a request matches when its value appears in any populated list (e.g. `regions: ["WNAM"]` with `countries: ["US"]` matches a request in either WNAM or the US). */
    topology?: ListResultItemPoolSetsItemMatchTopology | null;
}
export type ListResultItemPoolSetsItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type ListResultItemPoolSetsItemOverridesPoolsList = Array<string>;
export type ListResultItemPoolSetsItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface ListResultItemPoolSetsItemOverrides {
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: ListResultItemPoolSetsItemOverridesPoolWeightsMap | null;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: ListResultItemPoolSetsItemOverridesPoolsList | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: ListResultItemPoolSetsItemOverridesSteeringPolicy | null;
}
export interface ListResultItemPoolSetsItem {
    /** Disable this specific pool set. It will no longer be evaluated. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateResponsePoolSetsItemFixedResponse | null;
    /** Determines which requests a pool set applies to. Set `topology` to match by location or `default: true` to match all requests; the two are mutually exclusive. A pool set with no `match` matches all requests. */
    match?: ListResultItemPoolSetsItemMatch | null;
    /** A human-readable name for this pool set. */
    name?: string | null;
    /** The behavior a pool set applies when its `match` succeeds. A strict subset of a rule's `overrides`: a pool set replaces the topology wholesale with a flat pool list (`pools`), so only the declarative pool-routing fields plus `fallback_pool` and `steering_policy` are settable. All fields are optional. */
    overrides?: ListResultItemPoolSetsItemOverrides | null;
}
export type ListResultItemPoolSetsList = Array<ListResultItemPoolSetsItem>;
export type ListResultItemPopPoolsValueList = Array<string>;
export type ListResultItemPopPoolsMap = {
    [key: string]: ListResultItemPopPoolsValueList | undefined;
};
export type ListResultItemRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface ListResultItemRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: ListResultItemRandomSteeringPoolWeightsMap | null;
}
export type ListResultItemRegionPoolsValueList = Array<string>;
export type ListResultItemRegionPoolsMap = {
    [key: string]: ListResultItemRegionPoolsValueList | undefined;
};
export type ListResultItemRulesItemFixedResponse = CreateResponsePoolSetsItemFixedResponse;
export type ListResultItemRulesItemOverridesAdaptiveRouting = CreateResponseAdaptiveRouting;
export type ListResultItemRulesItemOverridesCountryPoolsValueList = Array<string>;
export type ListResultItemRulesItemOverridesCountryPoolsMap = {
    [key: string]: ListResultItemRulesItemOverridesCountryPoolsValueList | undefined;
};
export type ListResultItemRulesItemOverridesDefaultPoolsList = Array<string>;
export type ListResultItemRulesItemOverridesLocationStrategyMode = "pop" | "resolver_ip";
export type ListResultItemRulesItemOverridesLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface ListResultItemRulesItemOverridesLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: ListResultItemRulesItemOverridesLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: ListResultItemRulesItemOverridesLocationStrategyPreferEcs | null;
}
export type ListResultItemRulesItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type ListResultItemRulesItemOverridesPoolsList = Array<string>;
export type ListResultItemRulesItemOverridesPopPoolsValueList = Array<string>;
export type ListResultItemRulesItemOverridesPopPoolsMap = {
    [key: string]: ListResultItemRulesItemOverridesPopPoolsValueList | undefined;
};
export type ListResultItemRulesItemOverridesRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface ListResultItemRulesItemOverridesRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: ListResultItemRulesItemOverridesRandomSteeringPoolWeightsMap | null;
}
export type ListResultItemRulesItemOverridesRegionPoolsValueList = Array<string>;
export type ListResultItemRulesItemOverridesRegionPoolsMap = {
    [key: string]: ListResultItemRulesItemOverridesRegionPoolsValueList | undefined;
};
export type ListResultItemRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type ListResultItemRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export type ListResultItemRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type ListResultItemRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type ListResultItemRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface ListResultItemRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: ListResultItemRulesItemOverridesSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: ListResultItemRulesItemOverridesSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: ListResultItemRulesItemOverridesSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: ListResultItemRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | null;
}
export type ListResultItemRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface ListResultItemRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: ListResultItemRulesItemOverridesCountryPoolsMap | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: ListResultItemRulesItemOverridesDefaultPoolsList | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: ListResultItemRulesItemOverridesLocationStrategy | null;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: ListResultItemRulesItemOverridesPoolWeightsMap | null;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: ListResultItemRulesItemOverridesPoolsList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: ListResultItemRulesItemOverridesPopPoolsMap | null;
    /** Configures pool weights. */
    randomSteering?: ListResultItemRulesItemOverridesRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: ListResultItemRulesItemOverridesRegionPoolsMap | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: ListResultItemRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: ListResultItemRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: ListResultItemRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
}
export interface ListResultItemRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string | null;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateResponsePoolSetsItemFixedResponse | null;
    /** Name of this rule. Only used for human readability. */
    name?: string | null;
    /** A collection of overrides to apply when this rule's condition (or a pool set's `match`) is true. All fields are optional. */
    overrides?: ListResultItemRulesItemOverrides | null;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number | null;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean | null;
}
export type ListResultItemRulesList = Array<ListResultItemRulesItem>;
export type ListResultItemSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type ListResultItemSessionAffinityAttributesHeadersList = Array<string>;
export type ListResultItemSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type ListResultItemSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type ListResultItemSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface ListResultItemSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: ListResultItemSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: ListResultItemSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: ListResultItemSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: ListResultItemSessionAffinityAttributesZeroDowntimeFailover | null;
}
export type ListResultItemSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface ListResultItem {
    id?: string | null;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: ListResultItemCountryPoolsMap | null;
    createdOn?: string | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: ListResultItemDefaultPoolsList | null;
    /** Object description. */
    description?: string | null;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: ListResultItemLocationStrategy | null;
    modifiedOn?: string | null;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: ListResultItemNetworksList | null;
    /** An optional list of pool sets, evaluated in array order with first match wins. Pool sets are independent from the standard steering fields (`region_pools` / `country_pools` / `pop_pools` / `default_pools` / `steering_policy` / `random_steering` / `fallback_pool` / `rules`). On a PATCH, an empty array (`pool_sets: []`) clears all pool sets, while omitting the field leaves existing pool sets unchanged. */
    poolSets?: ListResultItemPoolSetsList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: ListResultItemPopPoolsMap | null;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean | null;
    /** Configures pool weights. */
    randomSteering?: ListResultItemRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: ListResultItemRegionPoolsMap | null;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: ListResultItemRulesList | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: ListResultItemSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: ListResultItemSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: ListResultItemSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
    zoneName?: string | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListLoadBalancersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListMonitorGroupsRequest {
    /** Identifier. */
    accountId: string;
}
export type MonitorGroupsListResultItemMembersItem = MonitorGroupsCreateResponseMembersItem;
export type MonitorGroupsListResultItemMembersList = Array<MonitorGroupsCreateResponseMembersItem>;
export interface MonitorGroupsListResultItem {
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    id: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsListResultItemMembersList;
    /** The timestamp of when the monitor group was created */
    createdOn?: string | null;
    /** The timestamp of when the monitor group was last updated */
    modifiedOn?: string | null;
}
export type MonitorGroupsListResultList = Array<MonitorGroupsListResultItem>;
export interface ListMonitorGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MonitorGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListMonitorsRequest {
    /** Identifier. */
    accountId: string;
}
export type MonitorsListResultItemHeaderValueList = Array<string>;
export type MonitorsListResultItemHeaderMap = {
    [key: string]: MonitorsListResultItemHeaderValueList | undefined;
};
export type MonitorsListResultItemType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export interface MonitorsListResultItem {
    id?: string | null;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean | null;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number | null;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number | null;
    createdOn?: string | null;
    /** Object description. */
    description?: string | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string | null;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string | null;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsListResultItemHeaderMap | null;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number | null;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string | null;
    modifiedOn?: string | null;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string | null;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number | null;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsListResultItemType | null;
}
export type MonitorsListResultList = Array<MonitorsListResultItem>;
export interface ListMonitorsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MonitorsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListPoolsRequest {
    /** Identifier. */
    accountId: string;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string;
}
export type PoolsListResultItemCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "CHINA" | "ALL_REGIONS";
export type PoolsListResultItemCheckRegionsList = Array<PoolsListResultItemCheckRegionsItem>;
export type PoolsListResultItemHealthSourcesItem = "local" | "regional" | "global";
export type PoolsListResultItemHealthSourcesList = Array<PoolsListResultItemHealthSourcesItem>;
export type PoolsListResultItemLoadSheddingDefaultPolicy = "random" | "hash";
export type PoolsListResultItemLoadSheddingSessionPolicy = "hash";
export interface PoolsListResultItemLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number | null;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsListResultItemLoadSheddingDefaultPolicy | null;
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number | null;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsListResultItemLoadSheddingSessionPolicy | null;
}
export type PoolsListResultItemNetworksList = Array<string>;
export type PoolsListResultItemNotificationFilterOrigin = PoolsBulkEditResultItemNotificationFilterOrigin;
export type PoolsListResultItemNotificationFilterPool = PoolsBulkEditResultItemNotificationFilterOrigin;
export type PoolsListResultItemNotificationFilter = PoolsBulkEditResultItemNotificationFilter;
export type PoolsListResultItemOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export interface PoolsListResultItemOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsListResultItemOriginSteeringPolicy | null;
}
export type PoolsListResultItemOriginsItemHeaderHostList = Array<string>;
export interface PoolsListResultItemOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsListResultItemOriginsItemHeaderHostList | null;
}
export interface PoolsListResultItemOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string | null;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string | null;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean | null;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean | null;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsListResultItemOriginsItemHeader | null;
    /** A human-identifiable name for the origin. */
    name?: string | null;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number | null;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string | null;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number | null;
}
export type PoolsListResultItemOriginsList = Array<PoolsListResultItemOriginsItem>;
export interface PoolsListResultItem {
    id?: string | null;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsListResultItemCheckRegionsList | null;
    createdOn?: string | null;
    /** A human-readable description of the pool. */
    description?: string | null;
    /** This field shows up only if the pool is disabled. This field is set with the time the pool was disabled at. */
    disabledAt?: string | null;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean | null;
    /** A list of health sources, ordered from highest to lowest priority, used to evaluate individual origin health and overall pool health. The load balancer uses the first source that has data and falls back to the next. Currently accepted values are null or the exact array ["regional", "global"]; any other combination is rejected. Null (the default) behaves like ["local", "global"]. ["regional", "global"] makes each region steer on its own health, falling back to the global decision when a region has no fresh data. Setting regional requires at least one region in check_regions. */
    healthSources?: PoolsListResultItemHealthSourcesList | null;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number | null;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsListResultItemLoadShedding | null;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number | null;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number | null;
    modifiedOn?: string | null;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string | null;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string | null;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: PoolsListResultItemNetworksList | null;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string | null;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsBulkEditResultItemNotificationFilter | null;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsListResultItemOriginSteering | null;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsListResultItemOriginsList | null;
}
export type PoolsListResultList = Array<PoolsListResultItem>;
export interface ListPoolsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PoolsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export interface ListRegionsRequest {
    /** Identifier. */
    accountId: string;
    /** Two-letter alpha-2 country code followed in ISO 3166-1. */
    countryCodeA2?: string;
    /** Two-letter subdivision code followed in ISO 3166-2. */
    subdivisionCode?: string;
    /** Two-letter subdivision code followed in ISO 3166-2. */
    subdivisionCodeA2?: string;
}
export type ListRegionsResponse = unknown;
export type SearchesListRequestReferences = "" | "*" | "referral" | "referrer";
export interface ListSearchesRequest {
    /** Identifier. */
    accountId: string;
    page?: number;
    perPage?: number;
    /** Search query term. */
    query?: string;
    /** The type of references to include. "*" to include both referral and referrer references. "" to not include any reference information. */
    references?: SearchesListRequestReferences | (string & {});
}
export type SearchesListResponseResourcesItemReferenceType = "referral" | "referrer";
export type SearchesListResponseResourcesItemReferencesList = Array<unknown>;
export type SearchesListResponseResourcesItemResourceType = "load_balancer" | "monitor" | "pool";
export interface SearchesListResponseResourcesItem {
    /** When listed as a reference, the type (direction) of the reference. */
    referenceType?: SearchesListResponseResourcesItemReferenceType | null;
    /** A list of references to (referrer) or from (referral) this resource. */
    references?: SearchesListResponseResourcesItemReferencesList | null;
    resourceId?: string | null;
    /** The human-identifiable name of the resource. */
    resourceName?: string | null;
    /** The type of the resource. */
    resourceType?: SearchesListResponseResourcesItemResourceType | null;
}
export type SearchesListResponseResourcesList = Array<SearchesListResponseResourcesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListSearchesResponse {
    /** A list of resources matching the search query. */
    resources?: SearchesListResponseResourcesList | null;
}
export type EditRequestAdaptiveRouting = CreateRequestAdaptiveRouting;
export type EditRequestCountryPoolsValueList = Array<string>;
export type EditRequestCountryPoolsMap = {
    [key: string]: EditRequestCountryPoolsValueList | undefined;
};
export type EditRequestDefaultPoolsList = Array<string>;
export type EditRequestLocationStrategyMode = "pop" | "resolver_ip";
export type EditRequestLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface EditRequestLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: EditRequestLocationStrategyMode | (string & {});
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: EditRequestLocationStrategyPreferEcs | (string & {});
}
export type EditRequestNetworksList = Array<string>;
export type EditRequestPopPoolsValueList = Array<string>;
export type EditRequestPopPoolsMap = {
    [key: string]: EditRequestPopPoolsValueList | undefined;
};
export type EditRequestRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface EditRequestRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: EditRequestRandomSteeringPoolWeightsMap;
}
export type EditRequestRegionPoolsValueList = Array<string>;
export type EditRequestRegionPoolsMap = {
    [key: string]: EditRequestRegionPoolsValueList | undefined;
};
export type EditRequestRulesItemFixedResponse = CreateRequestRulesItemFixedResponse;
export type EditRequestRulesItemOverridesAdaptiveRouting = CreateRequestAdaptiveRouting;
export type EditRequestRulesItemOverridesCountryPoolsValueList = Array<string>;
export type EditRequestRulesItemOverridesCountryPoolsMap = {
    [key: string]: EditRequestRulesItemOverridesCountryPoolsValueList | undefined;
};
export type EditRequestRulesItemOverridesDefaultPoolsList = Array<string>;
export type EditRequestRulesItemOverridesLocationStrategyMode = "pop" | "resolver_ip";
export type EditRequestRulesItemOverridesLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface EditRequestRulesItemOverridesLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: EditRequestRulesItemOverridesLocationStrategyMode | (string & {});
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: EditRequestRulesItemOverridesLocationStrategyPreferEcs | (string & {});
}
export type EditRequestRulesItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type EditRequestRulesItemOverridesPoolsList = Array<string>;
export type EditRequestRulesItemOverridesPopPoolsValueList = Array<string>;
export type EditRequestRulesItemOverridesPopPoolsMap = {
    [key: string]: EditRequestRulesItemOverridesPopPoolsValueList | undefined;
};
export type EditRequestRulesItemOverridesRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface EditRequestRulesItemOverridesRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: EditRequestRulesItemOverridesRandomSteeringPoolWeightsMap;
}
export type EditRequestRulesItemOverridesRegionPoolsValueList = Array<string>;
export type EditRequestRulesItemOverridesRegionPoolsMap = {
    [key: string]: EditRequestRulesItemOverridesRegionPoolsValueList | undefined;
};
export type EditRequestRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type EditRequestRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export type EditRequestRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type EditRequestRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type EditRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface EditRequestRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: EditRequestRulesItemOverridesSessionAffinityAttributesHeadersList;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: EditRequestRulesItemOverridesSessionAffinityAttributesSamesite | (string & {});
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: EditRequestRulesItemOverridesSessionAffinityAttributesSecure | (string & {});
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: EditRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | (string & {});
}
export type EditRequestRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface EditRequestRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateRequestAdaptiveRouting;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: EditRequestRulesItemOverridesCountryPoolsMap;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: EditRequestRulesItemOverridesDefaultPoolsList;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: EditRequestRulesItemOverridesLocationStrategy;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: EditRequestRulesItemOverridesPoolWeightsMap;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: EditRequestRulesItemOverridesPoolsList;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: EditRequestRulesItemOverridesPopPoolsMap;
    /** Configures pool weights. */
    randomSteering?: EditRequestRulesItemOverridesRandomSteering;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: EditRequestRulesItemOverridesRegionPoolsMap;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: EditRequestRulesItemOverridesSessionAffinity | (string & {});
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: EditRequestRulesItemOverridesSessionAffinityAttributes;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: EditRequestRulesItemOverridesSteeringPolicy | (string & {});
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number;
}
export interface EditRequestRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateRequestRulesItemFixedResponse;
    /** Name of this rule. Only used for human readability. */
    name?: string;
    /** A collection of overrides to apply when this rule's condition (or a pool set's `match`) is true. All fields are optional. */
    overrides?: EditRequestRulesItemOverrides;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean;
}
export type EditRequestRulesList = Array<EditRequestRulesItem>;
export type EditRequestSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type EditRequestSessionAffinityAttributesHeadersList = Array<string>;
export type EditRequestSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type EditRequestSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type EditRequestSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface EditRequestSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: EditRequestSessionAffinityAttributesHeadersList;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: EditRequestSessionAffinityAttributesSamesite | (string & {});
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: EditRequestSessionAffinityAttributesSecure | (string & {});
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: EditRequestSessionAffinityAttributesZeroDowntimeFailover | (string & {});
}
export type EditRequestSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface PatchLoadBalancerRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    loadBalancerId: string;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateRequestAdaptiveRouting;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: EditRequestCountryPoolsMap;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: EditRequestDefaultPoolsList;
    /** Object description. */
    description?: string;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: EditRequestLocationStrategy;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name?: string;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: EditRequestNetworksList;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: EditRequestPopPoolsMap;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean;
    /** Configures pool weights. */
    randomSteering?: EditRequestRandomSteering;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: EditRequestRegionPoolsMap;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: EditRequestRulesList;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: EditRequestSessionAffinity | (string & {});
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: EditRequestSessionAffinityAttributes;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: EditRequestSteeringPolicy | (string & {});
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number;
}
export type EditResponseAdaptiveRouting = CreateResponseAdaptiveRouting;
export type EditResponseCountryPoolsValueList = Array<string>;
export type EditResponseCountryPoolsMap = {
    [key: string]: EditResponseCountryPoolsValueList | undefined;
};
export type EditResponseDefaultPoolsList = Array<string>;
export type EditResponseLocationStrategyMode = "pop" | "resolver_ip";
export type EditResponseLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface EditResponseLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: EditResponseLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: EditResponseLocationStrategyPreferEcs | null;
}
export type EditResponseNetworksList = Array<string>;
export type EditResponsePoolSetsItemFixedResponse = CreateResponsePoolSetsItemFixedResponse;
export type EditResponsePoolSetsItemMatchTopologyCountriesList = Array<string>;
export type EditResponsePoolSetsItemMatchTopologyPopsList = Array<string>;
export type EditResponsePoolSetsItemMatchTopologyRegionsList = Array<string>;
export interface EditResponsePoolSetsItemMatchTopology {
    /** A list of ISO 3166-1 alpha-2 country codes. Matches when the request's country is in this list. */
    countries?: EditResponsePoolSetsItemMatchTopologyCountriesList | null;
    /** A list of Cloudflare PoP codes. Matches when the request's PoP is in this list. */
    pops?: EditResponsePoolSetsItemMatchTopologyPopsList | null;
    /** A list of Cloudflare region codes (e.g. `WNAM`, `ENAM`, `WEU`). Matches when the request's region is in this list. */
    regions?: EditResponsePoolSetsItemMatchTopologyRegionsList | null;
}
export interface EditResponsePoolSetsItemMatch {
    /** When true, matches every request. Cannot be combined with `topology`. */
    default?: boolean | null;
    /** Matches requests by location. Set any combination of `pops`, `countries`, and `regions` (at least one is required); a request matches when its value appears in any populated list (e.g. `regions: ["WNAM"]` with `countries: ["US"]` matches a request in either WNAM or the US). */
    topology?: EditResponsePoolSetsItemMatchTopology | null;
}
export type EditResponsePoolSetsItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type EditResponsePoolSetsItemOverridesPoolsList = Array<string>;
export type EditResponsePoolSetsItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface EditResponsePoolSetsItemOverrides {
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: EditResponsePoolSetsItemOverridesPoolWeightsMap | null;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: EditResponsePoolSetsItemOverridesPoolsList | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: EditResponsePoolSetsItemOverridesSteeringPolicy | null;
}
export interface EditResponsePoolSetsItem {
    /** Disable this specific pool set. It will no longer be evaluated. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateResponsePoolSetsItemFixedResponse | null;
    /** Determines which requests a pool set applies to. Set `topology` to match by location or `default: true` to match all requests; the two are mutually exclusive. A pool set with no `match` matches all requests. */
    match?: EditResponsePoolSetsItemMatch | null;
    /** A human-readable name for this pool set. */
    name?: string | null;
    /** The behavior a pool set applies when its `match` succeeds. A strict subset of a rule's `overrides`: a pool set replaces the topology wholesale with a flat pool list (`pools`), so only the declarative pool-routing fields plus `fallback_pool` and `steering_policy` are settable. All fields are optional. */
    overrides?: EditResponsePoolSetsItemOverrides | null;
}
export type EditResponsePoolSetsList = Array<EditResponsePoolSetsItem>;
export type EditResponsePopPoolsValueList = Array<string>;
export type EditResponsePopPoolsMap = {
    [key: string]: EditResponsePopPoolsValueList | undefined;
};
export type EditResponseRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface EditResponseRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: EditResponseRandomSteeringPoolWeightsMap | null;
}
export type EditResponseRegionPoolsValueList = Array<string>;
export type EditResponseRegionPoolsMap = {
    [key: string]: EditResponseRegionPoolsValueList | undefined;
};
export type EditResponseRulesItemFixedResponse = CreateResponsePoolSetsItemFixedResponse;
export type EditResponseRulesItemOverridesAdaptiveRouting = CreateResponseAdaptiveRouting;
export type EditResponseRulesItemOverridesCountryPoolsValueList = Array<string>;
export type EditResponseRulesItemOverridesCountryPoolsMap = {
    [key: string]: EditResponseRulesItemOverridesCountryPoolsValueList | undefined;
};
export type EditResponseRulesItemOverridesDefaultPoolsList = Array<string>;
export type EditResponseRulesItemOverridesLocationStrategyMode = "pop" | "resolver_ip";
export type EditResponseRulesItemOverridesLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface EditResponseRulesItemOverridesLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: EditResponseRulesItemOverridesLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: EditResponseRulesItemOverridesLocationStrategyPreferEcs | null;
}
export type EditResponseRulesItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type EditResponseRulesItemOverridesPoolsList = Array<string>;
export type EditResponseRulesItemOverridesPopPoolsValueList = Array<string>;
export type EditResponseRulesItemOverridesPopPoolsMap = {
    [key: string]: EditResponseRulesItemOverridesPopPoolsValueList | undefined;
};
export type EditResponseRulesItemOverridesRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface EditResponseRulesItemOverridesRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: EditResponseRulesItemOverridesRandomSteeringPoolWeightsMap | null;
}
export type EditResponseRulesItemOverridesRegionPoolsValueList = Array<string>;
export type EditResponseRulesItemOverridesRegionPoolsMap = {
    [key: string]: EditResponseRulesItemOverridesRegionPoolsValueList | undefined;
};
export type EditResponseRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type EditResponseRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export type EditResponseRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type EditResponseRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type EditResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface EditResponseRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: EditResponseRulesItemOverridesSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: EditResponseRulesItemOverridesSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: EditResponseRulesItemOverridesSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: EditResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | null;
}
export type EditResponseRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface EditResponseRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: EditResponseRulesItemOverridesCountryPoolsMap | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: EditResponseRulesItemOverridesDefaultPoolsList | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: EditResponseRulesItemOverridesLocationStrategy | null;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: EditResponseRulesItemOverridesPoolWeightsMap | null;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: EditResponseRulesItemOverridesPoolsList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: EditResponseRulesItemOverridesPopPoolsMap | null;
    /** Configures pool weights. */
    randomSteering?: EditResponseRulesItemOverridesRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: EditResponseRulesItemOverridesRegionPoolsMap | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: EditResponseRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: EditResponseRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: EditResponseRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
}
export interface EditResponseRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string | null;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateResponsePoolSetsItemFixedResponse | null;
    /** Name of this rule. Only used for human readability. */
    name?: string | null;
    /** A collection of overrides to apply when this rule's condition (or a pool set's `match`) is true. All fields are optional. */
    overrides?: EditResponseRulesItemOverrides | null;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number | null;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean | null;
}
export type EditResponseRulesList = Array<EditResponseRulesItem>;
export type EditResponseSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type EditResponseSessionAffinityAttributesHeadersList = Array<string>;
export type EditResponseSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type EditResponseSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type EditResponseSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface EditResponseSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: EditResponseSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: EditResponseSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: EditResponseSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: EditResponseSessionAffinityAttributesZeroDowntimeFailover | null;
}
export type EditResponseSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchLoadBalancerResponse {
    id?: string | null;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: EditResponseCountryPoolsMap | null;
    createdOn?: string | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: EditResponseDefaultPoolsList | null;
    /** Object description. */
    description?: string | null;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: EditResponseLocationStrategy | null;
    modifiedOn?: string | null;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: EditResponseNetworksList | null;
    /** An optional list of pool sets, evaluated in array order with first match wins. Pool sets are independent from the standard steering fields (`region_pools` / `country_pools` / `pop_pools` / `default_pools` / `steering_policy` / `random_steering` / `fallback_pool` / `rules`). On a PATCH, an empty array (`pool_sets: []`) clears all pool sets, while omitting the field leaves existing pool sets unchanged. */
    poolSets?: EditResponsePoolSetsList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: EditResponsePopPoolsMap | null;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean | null;
    /** Configures pool weights. */
    randomSteering?: EditResponseRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: EditResponseRegionPoolsMap | null;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: EditResponseRulesList | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: EditResponseSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: EditResponseSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: EditResponseSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
    zoneName?: string | null;
}
export type MonitorsEditRequestHeaderValueList = Array<string>;
export type MonitorsEditRequestHeaderMap = {
    [key: string]: MonitorsEditRequestHeaderValueList | undefined;
};
export type MonitorsEditRequestType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export interface PatchMonitorRequest {
    /** Identifier. */
    accountId: string;
    monitorId: string;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number;
    /** Object description. */
    description?: string;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsEditRequestHeaderMap;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsEditRequestType | (string & {});
}
export type MonitorsEditResponseHeaderValueList = Array<string>;
export type MonitorsEditResponseHeaderMap = {
    [key: string]: MonitorsEditResponseHeaderValueList | undefined;
};
export type MonitorsEditResponseType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchMonitorResponse {
    id?: string | null;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean | null;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number | null;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number | null;
    createdOn?: string | null;
    /** Object description. */
    description?: string | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string | null;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string | null;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsEditResponseHeaderMap | null;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number | null;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string | null;
    modifiedOn?: string | null;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string | null;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number | null;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsEditResponseType | null;
}
export type MonitorGroupsEditRequestMembersItem = MonitorGroupsCreateRequestMembersItem;
export type MonitorGroupsEditRequestMembersList = Array<MonitorGroupsCreateRequestMembersItem>;
export interface PatchMonitorGroupRequest {
    /** Identifier. */
    accountId: string;
    monitorGroupId: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsEditRequestMembersList;
}
export type MonitorGroupsEditResponseMembersItem = MonitorGroupsCreateResponseMembersItem;
export type MonitorGroupsEditResponseMembersList = Array<MonitorGroupsCreateResponseMembersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchMonitorGroupResponse {
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    id: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsEditResponseMembersList;
    /** The timestamp of when the monitor group was created */
    createdOn?: string | null;
    /** The timestamp of when the monitor group was last updated */
    modifiedOn?: string | null;
}
export type PoolsEditRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "CHINA" | "ALL_REGIONS";
export type PoolsEditRequestCheckRegionsList = Array<PoolsEditRequestCheckRegionsItem | (string & {})>;
export type PoolsEditRequestHealthSourcesItem = "local" | "regional" | "global";
export type PoolsEditRequestHealthSourcesList = Array<PoolsEditRequestHealthSourcesItem | (string & {})>;
export type PoolsEditRequestLoadSheddingDefaultPolicy = "random" | "hash";
export type PoolsEditRequestLoadSheddingSessionPolicy = "hash";
export interface PoolsEditRequestLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsEditRequestLoadSheddingDefaultPolicy | (string & {});
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsEditRequestLoadSheddingSessionPolicy | (string & {});
}
export type PoolsEditRequestNotificationFilterOrigin = PoolsCreateRequestNotificationFilterOrigin;
export type PoolsEditRequestNotificationFilterPool = PoolsCreateRequestNotificationFilterOrigin;
export type PoolsEditRequestNotificationFilter = PoolsCreateRequestNotificationFilter;
export type PoolsEditRequestOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export interface PoolsEditRequestOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsEditRequestOriginSteeringPolicy | (string & {});
}
export type PoolsEditRequestOriginsItemHeaderHostList = Array<string>;
export interface PoolsEditRequestOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsEditRequestOriginsItemHeaderHostList;
}
export interface PoolsEditRequestOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsEditRequestOriginsItemHeader;
    /** A human-identifiable name for the origin. */
    name?: string;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number;
}
export type PoolsEditRequestOriginsList = Array<PoolsEditRequestOriginsItem>;
export interface PatchPoolRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsEditRequestCheckRegionsList;
    /** A human-readable description of the pool. */
    description?: string;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean;
    /** A list of health sources, ordered from highest to lowest priority, used to evaluate individual origin health and overall pool health. The load balancer uses the first source that has data and falls back to the next. Currently accepted values are null or the exact array ["regional", "global"]; any other combination is rejected. Null (the default) behaves like ["local", "global"]. ["regional", "global"] makes each region steer on its own health, falling back to the global decision when a region has no fresh data. Setting regional requires at least one region in check_regions. */
    healthSources?: PoolsEditRequestHealthSourcesList;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsEditRequestLoadShedding;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsCreateRequestNotificationFilter;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsEditRequestOriginSteering;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsEditRequestOriginsList;
}
export type PoolsEditResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "CHINA" | "ALL_REGIONS";
export type PoolsEditResponseCheckRegionsList = Array<PoolsEditResponseCheckRegionsItem>;
export type PoolsEditResponseHealthSourcesItem = "local" | "regional" | "global";
export type PoolsEditResponseHealthSourcesList = Array<PoolsEditResponseHealthSourcesItem>;
export type PoolsEditResponseLoadSheddingDefaultPolicy = "random" | "hash";
export type PoolsEditResponseLoadSheddingSessionPolicy = "hash";
export interface PoolsEditResponseLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number | null;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsEditResponseLoadSheddingDefaultPolicy | null;
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number | null;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsEditResponseLoadSheddingSessionPolicy | null;
}
export type PoolsEditResponseNetworksList = Array<string>;
export type PoolsEditResponseNotificationFilterOrigin = PoolsBulkEditResultItemNotificationFilterOrigin;
export type PoolsEditResponseNotificationFilterPool = PoolsBulkEditResultItemNotificationFilterOrigin;
export type PoolsEditResponseNotificationFilter = PoolsBulkEditResultItemNotificationFilter;
export type PoolsEditResponseOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export interface PoolsEditResponseOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsEditResponseOriginSteeringPolicy | null;
}
export type PoolsEditResponseOriginsItemHeaderHostList = Array<string>;
export interface PoolsEditResponseOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsEditResponseOriginsItemHeaderHostList | null;
}
export interface PoolsEditResponseOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string | null;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string | null;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean | null;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean | null;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsEditResponseOriginsItemHeader | null;
    /** A human-identifiable name for the origin. */
    name?: string | null;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number | null;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string | null;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number | null;
}
export type PoolsEditResponseOriginsList = Array<PoolsEditResponseOriginsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchPoolResponse {
    id?: string | null;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsEditResponseCheckRegionsList | null;
    createdOn?: string | null;
    /** A human-readable description of the pool. */
    description?: string | null;
    /** This field shows up only if the pool is disabled. This field is set with the time the pool was disabled at. */
    disabledAt?: string | null;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean | null;
    /** A list of health sources, ordered from highest to lowest priority, used to evaluate individual origin health and overall pool health. The load balancer uses the first source that has data and falls back to the next. Currently accepted values are null or the exact array ["regional", "global"]; any other combination is rejected. Null (the default) behaves like ["local", "global"]. ["regional", "global"] makes each region steer on its own health, falling back to the global decision when a region has no fresh data. Setting regional requires at least one region in check_regions. */
    healthSources?: PoolsEditResponseHealthSourcesList | null;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number | null;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsEditResponseLoadShedding | null;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number | null;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number | null;
    modifiedOn?: string | null;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string | null;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string | null;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: PoolsEditResponseNetworksList | null;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string | null;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsBulkEditResultItemNotificationFilter | null;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsEditResponseOriginSteering | null;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsEditResponseOriginsList | null;
}
export type UpdateRequestDefaultPoolsList = Array<string>;
export type UpdateRequestAdaptiveRouting = CreateRequestAdaptiveRouting;
export type UpdateRequestCountryPoolsValueList = Array<string>;
export type UpdateRequestCountryPoolsMap = {
    [key: string]: UpdateRequestCountryPoolsValueList | undefined;
};
export type UpdateRequestLocationStrategyMode = "pop" | "resolver_ip";
export type UpdateRequestLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface UpdateRequestLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: UpdateRequestLocationStrategyMode | (string & {});
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: UpdateRequestLocationStrategyPreferEcs | (string & {});
}
export type UpdateRequestNetworksList = Array<string>;
export type UpdateRequestPopPoolsValueList = Array<string>;
export type UpdateRequestPopPoolsMap = {
    [key: string]: UpdateRequestPopPoolsValueList | undefined;
};
export type UpdateRequestRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface UpdateRequestRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: UpdateRequestRandomSteeringPoolWeightsMap;
}
export type UpdateRequestRegionPoolsValueList = Array<string>;
export type UpdateRequestRegionPoolsMap = {
    [key: string]: UpdateRequestRegionPoolsValueList | undefined;
};
export type UpdateRequestRulesItemFixedResponse = CreateRequestRulesItemFixedResponse;
export type UpdateRequestRulesItemOverridesAdaptiveRouting = CreateRequestAdaptiveRouting;
export type UpdateRequestRulesItemOverridesCountryPoolsValueList = Array<string>;
export type UpdateRequestRulesItemOverridesCountryPoolsMap = {
    [key: string]: UpdateRequestRulesItemOverridesCountryPoolsValueList | undefined;
};
export type UpdateRequestRulesItemOverridesDefaultPoolsList = Array<string>;
export type UpdateRequestRulesItemOverridesLocationStrategyMode = "pop" | "resolver_ip";
export type UpdateRequestRulesItemOverridesLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface UpdateRequestRulesItemOverridesLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: UpdateRequestRulesItemOverridesLocationStrategyMode | (string & {});
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: UpdateRequestRulesItemOverridesLocationStrategyPreferEcs | (string & {});
}
export type UpdateRequestRulesItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type UpdateRequestRulesItemOverridesPoolsList = Array<string>;
export type UpdateRequestRulesItemOverridesPopPoolsValueList = Array<string>;
export type UpdateRequestRulesItemOverridesPopPoolsMap = {
    [key: string]: UpdateRequestRulesItemOverridesPopPoolsValueList | undefined;
};
export type UpdateRequestRulesItemOverridesRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface UpdateRequestRulesItemOverridesRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: UpdateRequestRulesItemOverridesRandomSteeringPoolWeightsMap;
}
export type UpdateRequestRulesItemOverridesRegionPoolsValueList = Array<string>;
export type UpdateRequestRulesItemOverridesRegionPoolsMap = {
    [key: string]: UpdateRequestRulesItemOverridesRegionPoolsValueList | undefined;
};
export type UpdateRequestRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type UpdateRequestRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export type UpdateRequestRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type UpdateRequestRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type UpdateRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface UpdateRequestRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: UpdateRequestRulesItemOverridesSessionAffinityAttributesHeadersList;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: UpdateRequestRulesItemOverridesSessionAffinityAttributesSamesite | (string & {});
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: UpdateRequestRulesItemOverridesSessionAffinityAttributesSecure | (string & {});
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: UpdateRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | (string & {});
}
export type UpdateRequestRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface UpdateRequestRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateRequestAdaptiveRouting;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: UpdateRequestRulesItemOverridesCountryPoolsMap;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: UpdateRequestRulesItemOverridesDefaultPoolsList;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: UpdateRequestRulesItemOverridesLocationStrategy;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: UpdateRequestRulesItemOverridesPoolWeightsMap;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: UpdateRequestRulesItemOverridesPoolsList;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: UpdateRequestRulesItemOverridesPopPoolsMap;
    /** Configures pool weights. */
    randomSteering?: UpdateRequestRulesItemOverridesRandomSteering;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: UpdateRequestRulesItemOverridesRegionPoolsMap;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: UpdateRequestRulesItemOverridesSessionAffinity | (string & {});
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: UpdateRequestRulesItemOverridesSessionAffinityAttributes;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: UpdateRequestRulesItemOverridesSteeringPolicy | (string & {});
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number;
}
export interface UpdateRequestRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateRequestRulesItemFixedResponse;
    /** Name of this rule. Only used for human readability. */
    name?: string;
    /** A collection of overrides to apply when this rule's condition (or a pool set's `match`) is true. All fields are optional. */
    overrides?: UpdateRequestRulesItemOverrides;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean;
}
export type UpdateRequestRulesList = Array<UpdateRequestRulesItem>;
export type UpdateRequestSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type UpdateRequestSessionAffinityAttributesHeadersList = Array<string>;
export type UpdateRequestSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type UpdateRequestSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type UpdateRequestSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface UpdateRequestSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: UpdateRequestSessionAffinityAttributesHeadersList;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: UpdateRequestSessionAffinityAttributesSamesite | (string & {});
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: UpdateRequestSessionAffinityAttributesSecure | (string & {});
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: UpdateRequestSessionAffinityAttributesZeroDowntimeFailover | (string & {});
}
export type UpdateRequestSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface UpdateLoadBalancerRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    loadBalancerId: string;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools: UpdateRequestDefaultPoolsList;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool: string;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name: string;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateRequestAdaptiveRouting;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: UpdateRequestCountryPoolsMap;
    /** Object description. */
    description?: string;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: UpdateRequestLocationStrategy;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: UpdateRequestNetworksList;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: UpdateRequestPopPoolsMap;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean;
    /** Configures pool weights. */
    randomSteering?: UpdateRequestRandomSteering;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: UpdateRequestRegionPoolsMap;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: UpdateRequestRulesList;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: UpdateRequestSessionAffinity | (string & {});
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: UpdateRequestSessionAffinityAttributes;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: UpdateRequestSteeringPolicy | (string & {});
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number;
}
export type UpdateResponseAdaptiveRouting = CreateResponseAdaptiveRouting;
export type UpdateResponseCountryPoolsValueList = Array<string>;
export type UpdateResponseCountryPoolsMap = {
    [key: string]: UpdateResponseCountryPoolsValueList | undefined;
};
export type UpdateResponseDefaultPoolsList = Array<string>;
export type UpdateResponseLocationStrategyMode = "pop" | "resolver_ip";
export type UpdateResponseLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface UpdateResponseLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: UpdateResponseLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: UpdateResponseLocationStrategyPreferEcs | null;
}
export type UpdateResponseNetworksList = Array<string>;
export type UpdateResponsePoolSetsItemFixedResponse = CreateResponsePoolSetsItemFixedResponse;
export type UpdateResponsePoolSetsItemMatchTopologyCountriesList = Array<string>;
export type UpdateResponsePoolSetsItemMatchTopologyPopsList = Array<string>;
export type UpdateResponsePoolSetsItemMatchTopologyRegionsList = Array<string>;
export interface UpdateResponsePoolSetsItemMatchTopology {
    /** A list of ISO 3166-1 alpha-2 country codes. Matches when the request's country is in this list. */
    countries?: UpdateResponsePoolSetsItemMatchTopologyCountriesList | null;
    /** A list of Cloudflare PoP codes. Matches when the request's PoP is in this list. */
    pops?: UpdateResponsePoolSetsItemMatchTopologyPopsList | null;
    /** A list of Cloudflare region codes (e.g. `WNAM`, `ENAM`, `WEU`). Matches when the request's region is in this list. */
    regions?: UpdateResponsePoolSetsItemMatchTopologyRegionsList | null;
}
export interface UpdateResponsePoolSetsItemMatch {
    /** When true, matches every request. Cannot be combined with `topology`. */
    default?: boolean | null;
    /** Matches requests by location. Set any combination of `pops`, `countries`, and `regions` (at least one is required); a request matches when its value appears in any populated list (e.g. `regions: ["WNAM"]` with `countries: ["US"]` matches a request in either WNAM or the US). */
    topology?: UpdateResponsePoolSetsItemMatchTopology | null;
}
export type UpdateResponsePoolSetsItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type UpdateResponsePoolSetsItemOverridesPoolsList = Array<string>;
export type UpdateResponsePoolSetsItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface UpdateResponsePoolSetsItemOverrides {
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: UpdateResponsePoolSetsItemOverridesPoolWeightsMap | null;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: UpdateResponsePoolSetsItemOverridesPoolsList | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: UpdateResponsePoolSetsItemOverridesSteeringPolicy | null;
}
export interface UpdateResponsePoolSetsItem {
    /** Disable this specific pool set. It will no longer be evaluated. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateResponsePoolSetsItemFixedResponse | null;
    /** Determines which requests a pool set applies to. Set `topology` to match by location or `default: true` to match all requests; the two are mutually exclusive. A pool set with no `match` matches all requests. */
    match?: UpdateResponsePoolSetsItemMatch | null;
    /** A human-readable name for this pool set. */
    name?: string | null;
    /** The behavior a pool set applies when its `match` succeeds. A strict subset of a rule's `overrides`: a pool set replaces the topology wholesale with a flat pool list (`pools`), so only the declarative pool-routing fields plus `fallback_pool` and `steering_policy` are settable. All fields are optional. */
    overrides?: UpdateResponsePoolSetsItemOverrides | null;
}
export type UpdateResponsePoolSetsList = Array<UpdateResponsePoolSetsItem>;
export type UpdateResponsePopPoolsValueList = Array<string>;
export type UpdateResponsePopPoolsMap = {
    [key: string]: UpdateResponsePopPoolsValueList | undefined;
};
export type UpdateResponseRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface UpdateResponseRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: UpdateResponseRandomSteeringPoolWeightsMap | null;
}
export type UpdateResponseRegionPoolsValueList = Array<string>;
export type UpdateResponseRegionPoolsMap = {
    [key: string]: UpdateResponseRegionPoolsValueList | undefined;
};
export type UpdateResponseRulesItemFixedResponse = CreateResponsePoolSetsItemFixedResponse;
export type UpdateResponseRulesItemOverridesAdaptiveRouting = CreateResponseAdaptiveRouting;
export type UpdateResponseRulesItemOverridesCountryPoolsValueList = Array<string>;
export type UpdateResponseRulesItemOverridesCountryPoolsMap = {
    [key: string]: UpdateResponseRulesItemOverridesCountryPoolsValueList | undefined;
};
export type UpdateResponseRulesItemOverridesDefaultPoolsList = Array<string>;
export type UpdateResponseRulesItemOverridesLocationStrategyMode = "pop" | "resolver_ip";
export type UpdateResponseRulesItemOverridesLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export interface UpdateResponseRulesItemOverridesLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: UpdateResponseRulesItemOverridesLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: UpdateResponseRulesItemOverridesLocationStrategyPreferEcs | null;
}
export type UpdateResponseRulesItemOverridesPoolWeightsMap = {
    [key: string]: number | undefined;
};
export type UpdateResponseRulesItemOverridesPoolsList = Array<string>;
export type UpdateResponseRulesItemOverridesPopPoolsValueList = Array<string>;
export type UpdateResponseRulesItemOverridesPopPoolsMap = {
    [key: string]: UpdateResponseRulesItemOverridesPopPoolsValueList | undefined;
};
export type UpdateResponseRulesItemOverridesRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export interface UpdateResponseRulesItemOverridesRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: UpdateResponseRulesItemOverridesRandomSteeringPoolWeightsMap | null;
}
export type UpdateResponseRulesItemOverridesRegionPoolsValueList = Array<string>;
export type UpdateResponseRulesItemOverridesRegionPoolsMap = {
    [key: string]: UpdateResponseRulesItemOverridesRegionPoolsValueList | undefined;
};
export type UpdateResponseRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type UpdateResponseRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export type UpdateResponseRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type UpdateResponseRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type UpdateResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface UpdateResponseRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: UpdateResponseRulesItemOverridesSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: UpdateResponseRulesItemOverridesSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: UpdateResponseRulesItemOverridesSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: UpdateResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | null;
}
export type UpdateResponseRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export interface UpdateResponseRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: UpdateResponseRulesItemOverridesCountryPoolsMap | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: UpdateResponseRulesItemOverridesDefaultPoolsList | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: UpdateResponseRulesItemOverridesLocationStrategy | null;
    /** The default weight for pools not listed in `pool_weights`. The declarative alternative to `random_steering.default_weight`; mutually exclusive with `random_steering`. */
    poolDefaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights, relative to the other pools. The declarative alternative to `random_steering.pool_weights`; mutually exclusive with `random_steering`. */
    poolWeights?: UpdateResponseRulesItemOverridesPoolWeightsMap | null;
    /** A flat, ordered list of pool IDs to route the matched audience to. Replaces the resolved topology with exactly these pools. Mutually exclusive with `fixed_response`. */
    pools?: UpdateResponseRulesItemOverridesPoolsList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: UpdateResponseRulesItemOverridesPopPoolsMap | null;
    /** Configures pool weights. */
    randomSteering?: UpdateResponseRulesItemOverridesRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: UpdateResponseRulesItemOverridesRegionPoolsMap | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: UpdateResponseRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: UpdateResponseRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: UpdateResponseRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
}
export interface UpdateResponseRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string | null;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the client instead of routing to a pool. When supplied on a rule, that rule stops further rule evaluation. */
    fixedResponse?: CreateResponsePoolSetsItemFixedResponse | null;
    /** Name of this rule. Only used for human readability. */
    name?: string | null;
    /** A collection of overrides to apply when this rule's condition (or a pool set's `match`) is true. All fields are optional. */
    overrides?: UpdateResponseRulesItemOverrides | null;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number | null;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean | null;
}
export type UpdateResponseRulesList = Array<UpdateResponseRulesItem>;
export type UpdateResponseSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export type UpdateResponseSessionAffinityAttributesHeadersList = Array<string>;
export type UpdateResponseSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export type UpdateResponseSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export type UpdateResponseSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export interface UpdateResponseSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:&lt;cookie-name-1&gt;,&lt;cookie-name-2&gt;"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: UpdateResponseSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: UpdateResponseSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: UpdateResponseSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: UpdateResponseSessionAffinityAttributesZeroDowntimeFailover | null;
}
export type UpdateResponseSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateLoadBalancerResponse {
    id?: string | null;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: UpdateResponseCountryPoolsMap | null;
    createdOn?: string | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: UpdateResponseDefaultPoolsList | null;
    /** Object description. */
    description?: string | null;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: UpdateResponseLocationStrategy | null;
    modifiedOn?: string | null;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: UpdateResponseNetworksList | null;
    /** An optional list of pool sets, evaluated in array order with first match wins. Pool sets are independent from the standard steering fields (`region_pools` / `country_pools` / `pop_pools` / `default_pools` / `steering_policy` / `random_steering` / `fallback_pool` / `rules`). On a PATCH, an empty array (`pool_sets: []`) clears all pool sets, while omitting the field leaves existing pool sets unchanged. */
    poolSets?: UpdateResponsePoolSetsList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: UpdateResponsePopPoolsMap | null;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean | null;
    /** Configures pool weights. */
    randomSteering?: UpdateResponseRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: UpdateResponseRegionPoolsMap | null;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: UpdateResponseRulesList | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: UpdateResponseSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: UpdateResponseSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: UpdateResponseSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
    zoneName?: string | null;
}
export type MonitorsUpdateRequestHeaderValueList = Array<string>;
export type MonitorsUpdateRequestHeaderMap = {
    [key: string]: MonitorsUpdateRequestHeaderValueList | undefined;
};
export type MonitorsUpdateRequestType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export interface UpdateMonitorRequest {
    /** Identifier. */
    accountId: string;
    monitorId: string;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number;
    /** Object description. */
    description?: string;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsUpdateRequestHeaderMap;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsUpdateRequestType | (string & {});
}
export type MonitorsUpdateResponseHeaderValueList = Array<string>;
export type MonitorsUpdateResponseHeaderMap = {
    [key: string]: MonitorsUpdateResponseHeaderValueList | undefined;
};
export type MonitorsUpdateResponseType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateMonitorResponse {
    id?: string | null;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean | null;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number | null;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number | null;
    createdOn?: string | null;
    /** Object description. */
    description?: string | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string | null;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string | null;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsUpdateResponseHeaderMap | null;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number | null;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string | null;
    modifiedOn?: string | null;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string | null;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number | null;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsUpdateResponseType | null;
}
export type MonitorGroupsUpdateRequestMembersItem = MonitorGroupsCreateRequestMembersItem;
export type MonitorGroupsUpdateRequestMembersList = Array<MonitorGroupsCreateRequestMembersItem>;
export interface UpdateMonitorGroupRequest {
    /** Identifier. */
    accountId: string;
    monitorGroupId: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsUpdateRequestMembersList;
}
export type MonitorGroupsUpdateResponseMembersItem = MonitorGroupsCreateResponseMembersItem;
export type MonitorGroupsUpdateResponseMembersList = Array<MonitorGroupsCreateResponseMembersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateMonitorGroupResponse {
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    id: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsUpdateResponseMembersList;
    /** The timestamp of when the monitor group was created */
    createdOn?: string | null;
    /** The timestamp of when the monitor group was last updated */
    modifiedOn?: string | null;
}
export type PoolsUpdateRequestOriginsItemHeaderHostList = Array<string>;
export interface PoolsUpdateRequestOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsUpdateRequestOriginsItemHeaderHostList;
}
export interface PoolsUpdateRequestOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsUpdateRequestOriginsItemHeader;
    /** A human-identifiable name for the origin. */
    name?: string;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number;
}
export type PoolsUpdateRequestOriginsList = Array<PoolsUpdateRequestOriginsItem>;
export type PoolsUpdateRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "CHINA" | "ALL_REGIONS";
export type PoolsUpdateRequestCheckRegionsList = Array<PoolsUpdateRequestCheckRegionsItem | (string & {})>;
export type PoolsUpdateRequestHealthSourcesItem = "local" | "regional" | "global";
export type PoolsUpdateRequestHealthSourcesList = Array<PoolsUpdateRequestHealthSourcesItem | (string & {})>;
export type PoolsUpdateRequestLoadSheddingDefaultPolicy = "random" | "hash";
export type PoolsUpdateRequestLoadSheddingSessionPolicy = "hash";
export interface PoolsUpdateRequestLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsUpdateRequestLoadSheddingDefaultPolicy | (string & {});
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsUpdateRequestLoadSheddingSessionPolicy | (string & {});
}
export type PoolsUpdateRequestNotificationFilterOrigin = PoolsCreateRequestNotificationFilterOrigin;
export type PoolsUpdateRequestNotificationFilterPool = PoolsCreateRequestNotificationFilterOrigin;
export type PoolsUpdateRequestNotificationFilter = PoolsCreateRequestNotificationFilter;
export type PoolsUpdateRequestOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export interface PoolsUpdateRequestOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsUpdateRequestOriginSteeringPolicy | (string & {});
}
export interface UpdatePoolRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name: string;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins: PoolsUpdateRequestOriginsList;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsUpdateRequestCheckRegionsList;
    /** A human-readable description of the pool. */
    description?: string;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean;
    /** A list of health sources, ordered from highest to lowest priority, used to evaluate individual origin health and overall pool health. The load balancer uses the first source that has data and falls back to the next. Currently accepted values are null or the exact array ["regional", "global"]; any other combination is rejected. Null (the default) behaves like ["local", "global"]. ["regional", "global"] makes each region steer on its own health, falling back to the global decision when a region has no fresh data. Setting regional requires at least one region in check_regions. */
    healthSources?: PoolsUpdateRequestHealthSourcesList;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsUpdateRequestLoadShedding;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsCreateRequestNotificationFilter;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsUpdateRequestOriginSteering;
}
export type PoolsUpdateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "CHINA" | "ALL_REGIONS";
export type PoolsUpdateResponseCheckRegionsList = Array<PoolsUpdateResponseCheckRegionsItem>;
export type PoolsUpdateResponseHealthSourcesItem = "local" | "regional" | "global";
export type PoolsUpdateResponseHealthSourcesList = Array<PoolsUpdateResponseHealthSourcesItem>;
export type PoolsUpdateResponseLoadSheddingDefaultPolicy = "random" | "hash";
export type PoolsUpdateResponseLoadSheddingSessionPolicy = "hash";
export interface PoolsUpdateResponseLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number | null;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsUpdateResponseLoadSheddingDefaultPolicy | null;
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number | null;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsUpdateResponseLoadSheddingSessionPolicy | null;
}
export type PoolsUpdateResponseNetworksList = Array<string>;
export type PoolsUpdateResponseNotificationFilterOrigin = PoolsBulkEditResultItemNotificationFilterOrigin;
export type PoolsUpdateResponseNotificationFilterPool = PoolsBulkEditResultItemNotificationFilterOrigin;
export type PoolsUpdateResponseNotificationFilter = PoolsBulkEditResultItemNotificationFilter;
export type PoolsUpdateResponseOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export interface PoolsUpdateResponseOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsUpdateResponseOriginSteeringPolicy | null;
}
export type PoolsUpdateResponseOriginsItemHeaderHostList = Array<string>;
export interface PoolsUpdateResponseOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsUpdateResponseOriginsItemHeaderHostList | null;
}
export interface PoolsUpdateResponseOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string | null;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string | null;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean | null;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean | null;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsUpdateResponseOriginsItemHeader | null;
    /** A human-identifiable name for the origin. */
    name?: string | null;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number | null;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string | null;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number | null;
}
export type PoolsUpdateResponseOriginsList = Array<PoolsUpdateResponseOriginsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdatePoolResponse {
    id?: string | null;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsUpdateResponseCheckRegionsList | null;
    createdOn?: string | null;
    /** A human-readable description of the pool. */
    description?: string | null;
    /** This field shows up only if the pool is disabled. This field is set with the time the pool was disabled at. */
    disabledAt?: string | null;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean | null;
    /** A list of health sources, ordered from highest to lowest priority, used to evaluate individual origin health and overall pool health. The load balancer uses the first source that has data and falls back to the next. Currently accepted values are null or the exact array ["regional", "global"]; any other combination is rejected. Null (the default) behaves like ["local", "global"]. ["regional", "global"] makes each region steer on its own health, falling back to the global decision when a region has no fresh data. Setting regional requires at least one region in check_regions. */
    healthSources?: PoolsUpdateResponseHealthSourcesList | null;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number | null;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsUpdateResponseLoadShedding | null;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number | null;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number | null;
    modifiedOn?: string | null;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string | null;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string | null;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: PoolsUpdateResponseNetworksList | null;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string | null;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsBulkEditResultItemNotificationFilter | null;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsUpdateResponseOriginSteering | null;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsUpdateResponseOriginsList | null;
}
export type BulkPatchPoolsError = CloudflareOpError;
/** Apply changes to a number of existing pools, overwriting the supplied properties. Pools are ordered by ascending `name`. Returns the list of affected pools. Supports the standard pagination query parameters, either `limit`/`offset` or `per_page`/`page`. */
export declare const bulkPatchPools: API.PaginatedOperationMethod<BulkPatchPoolsRequest, BulkPatchPoolsResponse, BulkPatchPoolsError, CloudflareOpContext, PoolsBulkEditResultItem>;
export type CreateLoadBalancerError = LoadBalancingNotEnabledForZone | Forbidden | CloudflareOpError;
/** Create a new account or zone-scoped load balancer. */
export declare const createLoadBalancer: API.OperationMethod<CreateLoadBalancerRequest, CreateLoadBalancerResponse, CreateLoadBalancerError, CloudflareOpContext>;
export type CreateMonitorError = MonitorIntervalOutOfRange | Forbidden | CloudflareOpError;
/** Create a configured monitor. */
export declare const createMonitor: API.OperationMethod<CreateMonitorRequest, CreateMonitorResponse, CreateMonitorError, CloudflareOpContext>;
export type CreateMonitorGroupError = MonitorGroupsNotEnabled | Forbidden | CloudflareOpError;
/** Create a new monitor group. */
export declare const createMonitorGroup: API.OperationMethod<CreateMonitorGroupRequest, CreateMonitorGroupResponse, CreateMonitorGroupError, CloudflareOpContext>;
export type CreateMonitorPreviewError = CloudflareOpError;
/** Preview pools using the specified monitor with provided monitor details. The returned preview_id can be used in the preview endpoint to retrieve the results. */
export declare const createMonitorPreview: API.OperationMethod<CreateMonitorPreviewRequest, CreateMonitorPreviewResponse, CreateMonitorPreviewError, CloudflareOpContext>;
export type CreatePoolError = PoolAccessFailed | Forbidden | CloudflareOpError;
/** Create a new pool. */
export declare const createPool: API.OperationMethod<CreatePoolRequest, CreatePoolResponse, CreatePoolError, CloudflareOpContext>;
export type CreatePoolHealthError = CloudflareOpError;
/** Preview pool health using provided monitor details. The returned preview_id can be used in the preview endpoint to retrieve the results. */
export declare const createPoolHealth: API.OperationMethod<CreatePoolHealthRequest, CreatePoolHealthResponse, CreatePoolHealthError, CloudflareOpContext>;
export type DeleteLoadBalancerError = LoadBalancerNotFound | Forbidden | CloudflareOpError;
/** Delete a configured account or zone-scoped load balancer. */
export declare const deleteLoadBalancer: API.OperationMethod<DeleteLoadBalancerRequest, DeleteLoadBalancerResponse, DeleteLoadBalancerError, CloudflareOpContext>;
export type DeleteMonitorError = MonitorNotFound | MonitorInUse | Forbidden | CloudflareOpError;
/** Delete a configured monitor. */
export declare const deleteMonitor: API.OperationMethod<DeleteMonitorRequest, DeleteMonitorResponse, DeleteMonitorError, CloudflareOpContext>;
export type DeleteMonitorGroupError = MonitorGroupNotFound | MonitorGroupInUse | Forbidden | CloudflareOpError;
/** Delete a configured monitor group. */
export declare const deleteMonitorGroup: API.OperationMethod<DeleteMonitorGroupRequest, DeleteMonitorGroupResponse, DeleteMonitorGroupError, CloudflareOpContext>;
export type DeletePoolError = PoolNotFound | PoolInUse | Forbidden | CloudflareOpError;
/** Delete a configured pool. */
export declare const deletePool: API.OperationMethod<DeletePoolRequest, DeletePoolResponse, DeletePoolError, CloudflareOpContext>;
export type GetLoadBalancerError = LoadBalancerNotFound | Forbidden | CloudflareOpError;
/** Fetch a single configured account or zone-scoped load balancer. */
export declare const getLoadBalancer: API.OperationMethod<GetLoadBalancerRequest, GetLoadBalancerResponse, GetLoadBalancerError, CloudflareOpContext>;
export type GetMonitorError = MonitorNotFound | Forbidden | CloudflareOpError;
/** Fetch a single configured monitor for an account. */
export declare const getMonitor: API.OperationMethod<GetMonitorRequest, GetMonitorResponse, GetMonitorError, CloudflareOpContext>;
export type GetMonitorGroupError = MonitorGroupNotFound | Forbidden | CloudflareOpError;
/** Fetch a single configured monitor group. */
export declare const getMonitorGroup: API.OperationMethod<GetMonitorGroupRequest, GetMonitorGroupResponse, GetMonitorGroupError, CloudflareOpContext>;
export type GetMonitorGroupReferenceError = CloudflareOpError;
/** Get the list of resources that reference the provided monitor group. */
export declare const getMonitorGroupReference: API.PaginatedOperationMethod<GetMonitorGroupReferenceRequest, GetMonitorGroupReferenceResponse, GetMonitorGroupReferenceError, CloudflareOpContext, MonitorGroupsReferencesGetResultItem>;
export type GetMonitorReferenceError = CloudflareOpError;
/** Get the list of resources that reference the provided monitor. */
export declare const getMonitorReference: API.PaginatedOperationMethod<GetMonitorReferenceRequest, GetMonitorReferenceResponse, GetMonitorReferenceError, CloudflareOpContext, MonitorsReferencesGetResultItem>;
export type GetPoolError = PoolNotFound | Forbidden | CloudflareOpError;
/** Fetch a single configured pool. */
export declare const getPool: API.OperationMethod<GetPoolRequest, GetPoolResponse, GetPoolError, CloudflareOpContext>;
export type GetPoolHealthError = CloudflareOpError;
/** Fetch the latest pool health status for a single pool. */
export declare const getPoolHealth: API.OperationMethod<GetPoolHealthRequest, GetPoolHealthResponse, GetPoolHealthError, CloudflareOpContext>;
export type GetPoolReferenceError = CloudflareOpError;
/** Get the list of resources that reference the provided pool. */
export declare const getPoolReference: API.PaginatedOperationMethod<GetPoolReferenceRequest, GetPoolReferenceResponse, GetPoolReferenceError, CloudflareOpContext, PoolsReferencesGetResultItem>;
export type GetPreviewError = CloudflareOpError;
/** Get the result of a previous preview operation using the provided preview_id. */
export declare const getPreview: API.OperationMethod<GetPreviewRequest, GetPreviewResponse, GetPreviewError, CloudflareOpContext>;
export type GetRegionError = CloudflareOpError;
/** Get a single region mapping. */
export declare const getRegion: API.OperationMethod<GetRegionRequest, GetRegionResponse, GetRegionError, CloudflareOpContext>;
export type ListLoadBalancersError = CloudflareOpError;
/** List configured account or zone-scoped load balancers. */
export declare const listLoadBalancers: API.PaginatedOperationMethod<ListLoadBalancersRequest, ListLoadBalancersResponse, ListLoadBalancersError, CloudflareOpContext, ListResultItem>;
export type ListMonitorGroupsError = CloudflareOpError;
/** List configured monitor groups. */
export declare const listMonitorGroups: API.PaginatedOperationMethod<ListMonitorGroupsRequest, ListMonitorGroupsResponse, ListMonitorGroupsError, CloudflareOpContext, MonitorGroupsListResultItem>;
export type ListMonitorsError = CloudflareOpError;
/** List configured monitors for an account. */
export declare const listMonitors: API.PaginatedOperationMethod<ListMonitorsRequest, ListMonitorsResponse, ListMonitorsError, CloudflareOpContext, MonitorsListResultItem>;
export type ListPoolsError = CloudflareOpError;
/** List configured pools. */
export declare const listPools: API.PaginatedOperationMethod<ListPoolsRequest, ListPoolsResponse, ListPoolsError, CloudflareOpContext, PoolsListResultItem>;
export type ListRegionsError = CloudflareOpError;
/** List all region mappings. */
export declare const listRegions: API.OperationMethod<ListRegionsRequest, ListRegionsResponse, ListRegionsError, CloudflareOpContext>;
export type ListSearchesError = CloudflareOpError;
/** Search for Load Balancing resources. */
export declare const listSearches: API.OperationMethod<ListSearchesRequest, ListSearchesResponse, ListSearchesError, CloudflareOpContext>;
export type PatchLoadBalancerError = CloudflareOpError;
/** Apply changes to an existing account or zone-scoped load balancer, overwriting the supplied properties. */
export declare const patchLoadBalancer: API.OperationMethod<PatchLoadBalancerRequest, PatchLoadBalancerResponse, PatchLoadBalancerError, CloudflareOpContext>;
export type PatchMonitorError = CloudflareOpError;
/** Apply changes to an existing monitor, overwriting the supplied properties. */
export declare const patchMonitor: API.OperationMethod<PatchMonitorRequest, PatchMonitorResponse, PatchMonitorError, CloudflareOpContext>;
export type PatchMonitorGroupError = CloudflareOpError;
/** Apply changes to an existing monitor group, overwriting the supplied properties. */
export declare const patchMonitorGroup: API.OperationMethod<PatchMonitorGroupRequest, PatchMonitorGroupResponse, PatchMonitorGroupError, CloudflareOpContext>;
export type PatchPoolError = CloudflareOpError;
/** Apply changes to an existing pool, overwriting the supplied properties. */
export declare const patchPool: API.OperationMethod<PatchPoolRequest, PatchPoolResponse, PatchPoolError, CloudflareOpContext>;
export type UpdateLoadBalancerError = LoadBalancerNotFound | LoadBalancingNotEnabledForZone | Forbidden | CloudflareOpError;
/** Update a configured account or zone-scoped load balancer. */
export declare const updateLoadBalancer: API.OperationMethod<UpdateLoadBalancerRequest, UpdateLoadBalancerResponse, UpdateLoadBalancerError, CloudflareOpContext>;
export type UpdateMonitorError = MonitorNotFound | MonitorIntervalOutOfRange | Forbidden | CloudflareOpError;
/** Modify a configured monitor. */
export declare const updateMonitor: API.OperationMethod<UpdateMonitorRequest, UpdateMonitorResponse, UpdateMonitorError, CloudflareOpContext>;
export type UpdateMonitorGroupError = MonitorGroupNotFound | MonitorGroupsNotEnabled | Forbidden | CloudflareOpError;
/** Modify a configured monitor group. */
export declare const updateMonitorGroup: API.OperationMethod<UpdateMonitorGroupRequest, UpdateMonitorGroupResponse, UpdateMonitorGroupError, CloudflareOpContext>;
export type UpdatePoolError = PoolNotFound | PoolAccessFailed | Forbidden | CloudflareOpError;
/** Modify a configured pool. */
export declare const updatePool: API.OperationMethod<UpdatePoolRequest, UpdatePoolResponse, UpdatePoolError, CloudflareOpContext>;
//# sourceMappingURL=load_balancers.d.ts.map