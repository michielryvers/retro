import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CustomHostnameNotFound_base: S.TaggedErrorClass<"CustomHostnameNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CustomHostnameNotFound extends /*@__PURE__*/ CustomHostnameNotFound_base {
}
declare const FallbackOriginNotFound_base: S.TaggedErrorClass<"FallbackOriginNotFound", {
    readonly code: any;
    readonly message: any;
}>;
export declare class FallbackOriginNotFound extends /*@__PURE__*/ FallbackOriginNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const SaasAccessNotGranted_base: S.TaggedErrorClass<"SaasAccessNotGranted", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SaasAccessNotGranted extends /*@__PURE__*/ SaasAccessNotGranted_base {
}
declare const SaasQuotaNotAllocated_base: S.TaggedErrorClass<"SaasQuotaNotAllocated", {
    readonly code: any;
    readonly message: any;
}>;
export declare class SaasQuotaNotAllocated extends /*@__PURE__*/ SaasQuotaNotAllocated_base {
}
export type CreateRequestCustomMetadataMap = {
    [key: string]: unknown | undefined;
};
export type CreateRequestSslBundleMethod = "ubiquitous" | "optimal" | "force";
export type CreateRequestSslCertificateAuthority = "digicert" | "google" | "lets_encrypt" | "ssl_com";
export interface CreateRequestSslCustomCertBundleItem {
    /** If a custom uploaded certificate is used. */
    customCertificate: string;
    /** The key for a custom uploaded certificate. */
    customKey: string;
}
export type CreateRequestSslCustomCertBundleList = Array<CreateRequestSslCustomCertBundleItem>;
export type CreateRequestSslMethod = "http" | "txt" | "email";
export type CreateRequestSslSettingsCiphersList = Array<string>;
export type CreateRequestSslSettingsEarlyHints = "on" | "off";
export type CreateRequestSslSettingsHttp2 = "on" | "off";
export type CreateRequestSslSettingsMinTlsVersion = "1.0" | "1.1" | "1.2" | "1.3";
export type CreateRequestSslSettingsTls13 = "on" | "off";
export interface CreateRequestSslSettings {
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: CreateRequestSslSettingsCiphersList;
    /** Whether or not Early Hints is enabled. */
    earlyHints?: CreateRequestSslSettingsEarlyHints | (string & {});
    /** Whether or not HTTP2 is enabled. */
    http2?: CreateRequestSslSettingsHttp2 | (string & {});
    /** The minimum TLS version supported. */
    minTlsVersion?: CreateRequestSslSettingsMinTlsVersion | (string & {});
    /** Whether or not TLS 1.3 is enabled. */
    tls_1_3?: CreateRequestSslSettingsTls13 | (string & {});
}
export type CreateRequestSslType = "dv";
export interface CreateRequestSsl {
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: CreateRequestSslBundleMethod | (string & {});
    /** The Certificate Authority that will issue the certificate. */
    certificateAuthority?: CreateRequestSslCertificateAuthority | (string & {});
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean;
    /** Array of custom certificate and key pairs (1 or 2 pairs allowed). */
    customCertBundle?: CreateRequestSslCustomCertBundleList;
    /** If a custom uploaded certificate is used. */
    customCertificate?: string;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string;
    /** The key for a custom uploaded certificate. */
    customKey?: string;
    /** Domain control validation (DCV) method used for this hostname. */
    method?: CreateRequestSslMethod | (string & {});
    /** SSL specific settings. */
    settings?: CreateRequestSslSettings;
    /** Level of validation to be used for this hostname. Domain validation (dv) must be used. */
    type?: CreateRequestSslType | (string & {});
    /** Indicates whether the certificate covers a wildcard. */
    wildcard?: boolean;
}
export interface CreateCustomHostnameRequest {
    /** Identifier. */
    zoneId: string;
    /** The custom hostname that will point to your hostname via CNAME. */
    hostname: string;
    /** Unique key/value metadata for this hostname. These are per-hostname (customer) settings. */
    customMetadata?: CreateRequestCustomMetadataMap;
    /** a valid hostname that's been added to your DNS zone as an A, AAAA, or CNAME record. */
    customOriginServer?: string;
    /** A hostname that will be sent to your custom origin server as SNI for TLS handshake. This can be a valid subdomain of the zone or custom origin server name or the string ':request_host_header:' which will cause the host header in the request to be used as SNI. Not configurable with default/fallback origin server. */
    customOriginSni?: string;
    /** SSL properties used when creating the custom hostname. */
    ssl?: CreateRequestSsl;
}
export type CreateResponseCustomMetadataMap = {
    [key: string]: unknown | undefined;
};
export type CreateResponseOwnershipVerificationType = "txt";
export interface CreateResponseOwnershipVerification {
    /** DNS Name for record. */
    name?: string | null;
    /** DNS Record type. */
    type?: CreateResponseOwnershipVerificationType | null;
    /** Content for the record. */
    value?: string | null;
}
export interface CreateResponseOwnershipVerificationHttp {
    /** Token to be served. */
    httpBody?: string | null;
    /** The HTTP URL that will be checked during custom hostname verification and where the customer should host the token. */
    httpUrl?: string | null;
}
export type CreateResponseSslBundleMethod = "ubiquitous" | "optimal" | "force";
export type CreateResponseSslCertificateAuthority = "digicert" | "google" | "lets_encrypt" | "ssl_com";
export type CreateResponseSslDcvDelegationRecordsItemEmailsList = Array<string>;
export interface CreateResponseSslDcvDelegationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CreateResponseSslDcvDelegationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export type CreateResponseSslDcvDelegationRecordsList = Array<CreateResponseSslDcvDelegationRecordsItem>;
export type CreateResponseSslHostsList = Array<string>;
export type CreateResponseSslMethod = "http" | "txt" | "email";
export type CreateResponseSslSettingsCiphersList = Array<string>;
export type CreateResponseSslSettingsEarlyHints = "on" | "off";
export type CreateResponseSslSettingsHttp2 = "on" | "off";
export type CreateResponseSslSettingsMinTlsVersion = "1.0" | "1.1" | "1.2" | "1.3";
export type CreateResponseSslSettingsTls13 = "on" | "off";
export interface CreateResponseSslSettings {
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: CreateResponseSslSettingsCiphersList | null;
    /** Whether or not Early Hints is enabled. */
    earlyHints?: CreateResponseSslSettingsEarlyHints | null;
    /** Whether or not HTTP2 is enabled. */
    http2?: CreateResponseSslSettingsHttp2 | null;
    /** The minimum TLS version supported. */
    minTlsVersion?: CreateResponseSslSettingsMinTlsVersion | null;
    /** Whether or not TLS 1.3 is enabled. */
    tls_1_3?: CreateResponseSslSettingsTls13 | null;
}
export type CreateResponseSslStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export type CreateResponseSslType = "dv";
export interface CreateResponseSslValidationErrorsItem {
    /** A domain validation error. */
    message?: string | null;
}
export type CreateResponseSslValidationErrorsList = Array<CreateResponseSslValidationErrorsItem>;
export type CreateResponseSslValidationRecordsItemEmailsList = Array<string>;
export interface CreateResponseSslValidationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CreateResponseSslValidationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export type CreateResponseSslValidationRecordsList = Array<CreateResponseSslValidationRecordsItem>;
export interface CreateResponseSsl {
    /** Custom hostname SSL identifier tag. */
    id?: string | null;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: CreateResponseSslBundleMethod | null;
    /** The Certificate Authority that will issue the certificate. */
    certificateAuthority?: CreateResponseSslCertificateAuthority | null;
    /** If a custom uploaded certificate is used. */
    customCertificate?: string | null;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string | null;
    /** The key for a custom uploaded certificate. */
    customKey?: string | null;
    /** DCV Delegation records for domain validation. */
    dcvDelegationRecords?: CreateResponseSslDcvDelegationRecordsList | null;
    /** The time the custom certificate expires on. */
    expiresOn?: string | null;
    /** A list of Hostnames on a custom uploaded certificate. */
    hosts?: CreateResponseSslHostsList | null;
    /** The issuer on a custom uploaded certificate. */
    issuer?: string | null;
    /** Domain control validation (DCV) method used for this hostname. */
    method?: CreateResponseSslMethod | null;
    /** The serial number on a custom uploaded certificate. */
    serialNumber?: string | null;
    settings?: CreateResponseSslSettings | null;
    /** The signature on a custom uploaded certificate. */
    signature?: string | null;
    /** Status of the hostname's SSL certificates. */
    status?: CreateResponseSslStatus | null;
    /** Level of validation to be used for this hostname. Domain validation (dv) must be used. */
    type?: CreateResponseSslType | null;
    /** The time the custom certificate was uploaded. */
    uploadedOn?: string | null;
    /** Domain validation errors that have been received by the certificate authority (CA). */
    validationErrors?: CreateResponseSslValidationErrorsList | null;
    validationRecords?: CreateResponseSslValidationRecordsList | null;
    /** Indicates whether the certificate covers a wildcard. */
    wildcard?: boolean | null;
}
export type CreateResponseStatus = "active" | "pending" | "active_redeploying" | "moved" | "pending_deletion" | "deleted" | "pending_blocked" | "pending_migration" | "pending_provisioned" | "test_pending" | "test_active" | "test_active_apex" | "test_blocked" | "test_failed" | "provisioned" | "blocked";
export type CreateResponseVerificationErrorsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCustomHostnameResponse {
    /** Custom hostname identifier tag. */
    id: string;
    /** The custom hostname that will point to your hostname via CNAME. */
    hostname: string;
    /** This is the time the hostname was created. */
    createdAt?: string | null;
    /** Unique key/value metadata for this hostname. These are per-hostname (customer) settings. */
    customMetadata?: CreateResponseCustomMetadataMap | null;
    /** a valid hostname that's been added to your DNS zone as an A, AAAA, or CNAME record. */
    customOriginServer?: string | null;
    /** A hostname that will be sent to your custom origin server as SNI for TLS handshake. This can be a valid subdomain of the zone or custom origin server name or the string ':request_host_header:' which will cause the host header in the request to be used as SNI. Not configurable with default/fallback origin server. */
    customOriginSni?: string | null;
    /** This is a record which can be placed to activate a hostname. */
    ownershipVerification?: CreateResponseOwnershipVerification | null;
    /** This presents the token to be served by the given http url to activate a hostname. */
    ownershipVerificationHttp?: CreateResponseOwnershipVerificationHttp | null;
    ssl?: CreateResponseSsl | null;
    /** Status of the hostname's activation. */
    status?: CreateResponseStatus | null;
    /** These are errors that were encountered while trying to activate a hostname. */
    verificationErrors?: CreateResponseVerificationErrorsList | null;
}
export interface DeleteCertificatePackCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Custom hostname identifier tag. */
    customHostnameId: string;
    /** Custom hostname identifier tag. */
    certificatePackId: string;
    /** Custom hostname identifier tag. */
    certificateId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteCertificatePackCertificateResponse {
    /** Custom hostname identifier tag. */
    id?: string | null;
}
export interface DeleteCustomHostnameRequest {
    /** Identifier. */
    zoneId: string;
    /** Custom hostname identifier tag. */
    customHostnameId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteCustomHostnameResponse {
    /** Custom hostname identifier tag. */
    id?: string | null;
}
export interface DeleteFallbackOriginRequest {
    /** Identifier. */
    zoneId: string;
}
export type FallbackOriginDeleteResponseErrorsList = Array<string>;
export type FallbackOriginDeleteResponseStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deployment_timed_out" | "deletion_timed_out";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteFallbackOriginResponse {
    /** This is the time the fallback origin was created. */
    createdAt?: string | null;
    /** These are errors that were encountered while trying to activate a fallback origin. */
    errors?: FallbackOriginDeleteResponseErrorsList | null;
    /** Your origin hostname that requests to your custom hostnames will be sent to. */
    origin?: string | null;
    /** Status of the fallback origin's activation. */
    status?: FallbackOriginDeleteResponseStatus | null;
    /** This is the time the fallback origin was updated. */
    updatedAt?: string | null;
}
export interface GetCustomHostnameRequest {
    /** Identifier. */
    zoneId: string;
    /** Custom hostname identifier tag. */
    customHostnameId: string;
}
export type GetResponseCustomMetadataMap = {
    [key: string]: unknown | undefined;
};
export type GetResponseOwnershipVerificationType = "txt";
export interface GetResponseOwnershipVerification {
    /** DNS Name for record. */
    name?: string | null;
    /** DNS Record type. */
    type?: GetResponseOwnershipVerificationType | null;
    /** Content for the record. */
    value?: string | null;
}
export type GetResponseOwnershipVerificationHttp = CreateResponseOwnershipVerificationHttp;
export type GetResponseSslBundleMethod = "ubiquitous" | "optimal" | "force";
export type GetResponseSslCertificateAuthority = "digicert" | "google" | "lets_encrypt" | "ssl_com";
export type GetResponseSslDcvDelegationRecordsItemEmailsList = Array<string>;
export interface GetResponseSslDcvDelegationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: GetResponseSslDcvDelegationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export type GetResponseSslDcvDelegationRecordsList = Array<GetResponseSslDcvDelegationRecordsItem>;
export type GetResponseSslHostsList = Array<string>;
export type GetResponseSslMethod = "http" | "txt" | "email";
export type GetResponseSslSettingsCiphersList = Array<string>;
export type GetResponseSslSettingsEarlyHints = "on" | "off";
export type GetResponseSslSettingsHttp2 = "on" | "off";
export type GetResponseSslSettingsMinTlsVersion = "1.0" | "1.1" | "1.2" | "1.3";
export type GetResponseSslSettingsTls13 = "on" | "off";
export interface GetResponseSslSettings {
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: GetResponseSslSettingsCiphersList | null;
    /** Whether or not Early Hints is enabled. */
    earlyHints?: GetResponseSslSettingsEarlyHints | null;
    /** Whether or not HTTP2 is enabled. */
    http2?: GetResponseSslSettingsHttp2 | null;
    /** The minimum TLS version supported. */
    minTlsVersion?: GetResponseSslSettingsMinTlsVersion | null;
    /** Whether or not TLS 1.3 is enabled. */
    tls_1_3?: GetResponseSslSettingsTls13 | null;
}
export type GetResponseSslStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export type GetResponseSslType = "dv";
export type GetResponseSslValidationErrorsItem = CreateResponseSslValidationErrorsItem;
export type GetResponseSslValidationErrorsList = Array<CreateResponseSslValidationErrorsItem>;
export type GetResponseSslValidationRecordsItemEmailsList = Array<string>;
export interface GetResponseSslValidationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: GetResponseSslValidationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export type GetResponseSslValidationRecordsList = Array<GetResponseSslValidationRecordsItem>;
export interface GetResponseSsl {
    /** Custom hostname SSL identifier tag. */
    id?: string | null;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: GetResponseSslBundleMethod | null;
    /** The Certificate Authority that will issue the certificate. */
    certificateAuthority?: GetResponseSslCertificateAuthority | null;
    /** If a custom uploaded certificate is used. */
    customCertificate?: string | null;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string | null;
    /** The key for a custom uploaded certificate. */
    customKey?: string | null;
    /** DCV Delegation records for domain validation. */
    dcvDelegationRecords?: GetResponseSslDcvDelegationRecordsList | null;
    /** The time the custom certificate expires on. */
    expiresOn?: string | null;
    /** A list of Hostnames on a custom uploaded certificate. */
    hosts?: GetResponseSslHostsList | null;
    /** The issuer on a custom uploaded certificate. */
    issuer?: string | null;
    /** Domain control validation (DCV) method used for this hostname. */
    method?: GetResponseSslMethod | null;
    /** The serial number on a custom uploaded certificate. */
    serialNumber?: string | null;
    settings?: GetResponseSslSettings | null;
    /** The signature on a custom uploaded certificate. */
    signature?: string | null;
    /** Status of the hostname's SSL certificates. */
    status?: GetResponseSslStatus | null;
    /** Level of validation to be used for this hostname. Domain validation (dv) must be used. */
    type?: GetResponseSslType | null;
    /** The time the custom certificate was uploaded. */
    uploadedOn?: string | null;
    /** Domain validation errors that have been received by the certificate authority (CA). */
    validationErrors?: GetResponseSslValidationErrorsList | null;
    validationRecords?: GetResponseSslValidationRecordsList | null;
    /** Indicates whether the certificate covers a wildcard. */
    wildcard?: boolean | null;
}
export type GetResponseStatus = "active" | "pending" | "active_redeploying" | "moved" | "pending_deletion" | "deleted" | "pending_blocked" | "pending_migration" | "pending_provisioned" | "test_pending" | "test_active" | "test_active_apex" | "test_blocked" | "test_failed" | "provisioned" | "blocked";
export type GetResponseVerificationErrorsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCustomHostnameResponse {
    /** Custom hostname identifier tag. */
    id: string;
    /** The custom hostname that will point to your hostname via CNAME. */
    hostname: string;
    /** This is the time the hostname was created. */
    createdAt?: string | null;
    /** Unique key/value metadata for this hostname. These are per-hostname (customer) settings. */
    customMetadata?: GetResponseCustomMetadataMap | null;
    /** a valid hostname that's been added to your DNS zone as an A, AAAA, or CNAME record. */
    customOriginServer?: string | null;
    /** A hostname that will be sent to your custom origin server as SNI for TLS handshake. This can be a valid subdomain of the zone or custom origin server name or the string ':request_host_header:' which will cause the host header in the request to be used as SNI. Not configurable with default/fallback origin server. */
    customOriginSni?: string | null;
    /** This is a record which can be placed to activate a hostname. */
    ownershipVerification?: GetResponseOwnershipVerification | null;
    /** This presents the token to be served by the given http url to activate a hostname. */
    ownershipVerificationHttp?: CreateResponseOwnershipVerificationHttp | null;
    ssl?: GetResponseSsl | null;
    /** Status of the hostname's activation. */
    status?: GetResponseStatus | null;
    /** These are errors that were encountered while trying to activate a hostname. */
    verificationErrors?: GetResponseVerificationErrorsList | null;
}
export interface GetFallbackOriginRequest {
    /** Identifier. */
    zoneId: string;
}
export type FallbackOriginGetResponseErrorsList = Array<string>;
export type FallbackOriginGetResponseStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deployment_timed_out" | "deletion_timed_out";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetFallbackOriginResponse {
    /** This is the time the fallback origin was created. */
    createdAt?: string | null;
    /** These are errors that were encountered while trying to activate a fallback origin. */
    errors?: FallbackOriginGetResponseErrorsList | null;
    /** Your origin hostname that requests to your custom hostnames will be sent to. */
    origin?: string | null;
    /** Status of the fallback origin's activation. */
    status?: FallbackOriginGetResponseStatus | null;
    /** This is the time the fallback origin was updated. */
    updatedAt?: string | null;
}
export interface GetQuotaRequest {
    /** Identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetQuotaResponse {
    /** The allocated custom hostname quota. */
    allocated: number;
    /** Whether the current usage has exceeded the allocated quota. */
    exceeded: boolean;
    /** The maximum number of custom hostnames allowed before create requests are rejected. */
    hardCap: number;
    /** The number of custom hostnames currently in use. */
    used: number;
}
export type ListRequestCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export type ListRequestDirection = "asc" | "desc";
export interface ListRequestHostname {
    /** Filters hostnames by a substring match on the hostname value. This parameter cannot be used with the 'id', 'hostname', 'hostname.exact', or 'hostname.startsWith' parameters. */
    contain?: string;
    /** Fully qualified domain name to match against. This parameter cannot be used with the 'id', 'hostname', 'hostname.contain', or 'hostname.startsWith' parameters. */
    exact?: string;
    /** Filters hostnames by a prefix match on the hostname value. This parameter cannot be used with the 'id', 'hostname', 'hostname.exact', or 'hostname.contain' parameters. */
    startsWith?: string;
}
export type ListRequestHostnameStatus = "active" | "pending" | "active_redeploying" | "moved" | "pending_deletion" | "deleted" | "pending_blocked" | "pending_migration" | "pending_provisioned" | "test_pending" | "test_active" | "test_active_apex" | "test_blocked" | "test_failed" | "provisioned" | "blocked";
export type ListRequestOrder = "ssl" | "ssl_status";
export type ListRequestSslStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export interface ListCustomHostnamesRequest {
    /** Identifier. */
    zoneId: string;
    /** Hostname ID to match against. This ID was generated and returned during the initial custom_hostname creation. This parameter cannot be used with the 'hostname', 'hostname.exact', 'hostname.contain', or 'hostname.startsWith' parameters. */
    id?: string;
    /** Filter by the certificate authority that issued the SSL certificate. */
    certificateAuthority?: ListRequestCertificateAuthority | (string & {});
    /** Filter by custom origin server name. */
    customOriginServer?: string;
    /** Direction to order hostnames. */
    direction?: ListRequestDirection | (string & {});
    hostname?: ListRequestHostname;
    /** Filter by the hostname's activation status. */
    hostnameStatus?: ListRequestHostnameStatus | (string & {});
    /** Field to order hostnames by. */
    order?: ListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of hostnames per page. */
    perPage?: number;
    /** Whether to filter hostnames based on if they have SSL enabled. */
    ssl?: string;
    /** Filter by SSL certificate status. */
    sslStatus?: ListRequestSslStatus | (string & {});
    /** Filter by whether the custom hostname is a wildcard hostname. */
    wildcard?: boolean;
}
export type ListResultItemCustomMetadataMap = {
    [key: string]: unknown | undefined;
};
export type ListResultItemOwnershipVerificationType = "txt";
export interface ListResultItemOwnershipVerification {
    /** DNS Name for record. */
    name?: string | null;
    /** DNS Record type. */
    type?: ListResultItemOwnershipVerificationType | null;
    /** Content for the record. */
    value?: string | null;
}
export type ListResultItemOwnershipVerificationHttp = CreateResponseOwnershipVerificationHttp;
export type ListResultItemSslBundleMethod = "ubiquitous" | "optimal" | "force";
export type ListResultItemSslCertificateAuthority = "digicert" | "google" | "lets_encrypt" | "ssl_com";
export type ListResultItemSslDcvDelegationRecordsItemEmailsList = Array<string>;
export interface ListResultItemSslDcvDelegationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: ListResultItemSslDcvDelegationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export type ListResultItemSslDcvDelegationRecordsList = Array<ListResultItemSslDcvDelegationRecordsItem>;
export type ListResultItemSslHostsList = Array<string>;
export type ListResultItemSslMethod = "http" | "txt" | "email";
export type ListResultItemSslSettingsCiphersList = Array<string>;
export type ListResultItemSslSettingsEarlyHints = "on" | "off";
export type ListResultItemSslSettingsHttp2 = "on" | "off";
export type ListResultItemSslSettingsMinTlsVersion = "1.0" | "1.1" | "1.2" | "1.3";
export type ListResultItemSslSettingsTls13 = "on" | "off";
export interface ListResultItemSslSettings {
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: ListResultItemSslSettingsCiphersList | null;
    /** Whether or not Early Hints is enabled. */
    earlyHints?: ListResultItemSslSettingsEarlyHints | null;
    /** Whether or not HTTP2 is enabled. */
    http2?: ListResultItemSslSettingsHttp2 | null;
    /** The minimum TLS version supported. */
    minTlsVersion?: ListResultItemSslSettingsMinTlsVersion | null;
    /** Whether or not TLS 1.3 is enabled. */
    tls_1_3?: ListResultItemSslSettingsTls13 | null;
}
export type ListResultItemSslStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export type ListResultItemSslType = "dv";
export type ListResultItemSslValidationErrorsItem = CreateResponseSslValidationErrorsItem;
export type ListResultItemSslValidationErrorsList = Array<CreateResponseSslValidationErrorsItem>;
export type ListResultItemSslValidationRecordsItemEmailsList = Array<string>;
export interface ListResultItemSslValidationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: ListResultItemSslValidationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export type ListResultItemSslValidationRecordsList = Array<ListResultItemSslValidationRecordsItem>;
export interface ListResultItemSsl {
    /** Custom hostname SSL identifier tag. */
    id?: string | null;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: ListResultItemSslBundleMethod | null;
    /** The Certificate Authority that will issue the certificate. */
    certificateAuthority?: ListResultItemSslCertificateAuthority | null;
    /** If a custom uploaded certificate is used. */
    customCertificate?: string | null;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string | null;
    /** The key for a custom uploaded certificate. */
    customKey?: string | null;
    /** DCV Delegation records for domain validation. */
    dcvDelegationRecords?: ListResultItemSslDcvDelegationRecordsList | null;
    /** The time the custom certificate expires on. */
    expiresOn?: string | null;
    /** A list of Hostnames on a custom uploaded certificate. */
    hosts?: ListResultItemSslHostsList | null;
    /** The issuer on a custom uploaded certificate. */
    issuer?: string | null;
    /** Domain control validation (DCV) method used for this hostname. */
    method?: ListResultItemSslMethod | null;
    /** The serial number on a custom uploaded certificate. */
    serialNumber?: string | null;
    settings?: ListResultItemSslSettings | null;
    /** The signature on a custom uploaded certificate. */
    signature?: string | null;
    /** Status of the hostname's SSL certificates. */
    status?: ListResultItemSslStatus | null;
    /** Level of validation to be used for this hostname. Domain validation (dv) must be used. */
    type?: ListResultItemSslType | null;
    /** The time the custom certificate was uploaded. */
    uploadedOn?: string | null;
    /** Domain validation errors that have been received by the certificate authority (CA). */
    validationErrors?: ListResultItemSslValidationErrorsList | null;
    validationRecords?: ListResultItemSslValidationRecordsList | null;
    /** Indicates whether the certificate covers a wildcard. */
    wildcard?: boolean | null;
}
export type ListResultItemStatus = "active" | "pending" | "active_redeploying" | "moved" | "pending_deletion" | "deleted" | "pending_blocked" | "pending_migration" | "pending_provisioned" | "test_pending" | "test_active" | "test_active_apex" | "test_blocked" | "test_failed" | "provisioned" | "blocked";
export type ListResultItemVerificationErrorsList = Array<string>;
export interface ListResultItem {
    /** Custom hostname identifier tag. */
    id: string;
    /** The custom hostname that will point to your hostname via CNAME. */
    hostname: string;
    /** This is the time the hostname was created. */
    createdAt?: string | null;
    /** Unique key/value metadata for this hostname. These are per-hostname (customer) settings. */
    customMetadata?: ListResultItemCustomMetadataMap | null;
    /** a valid hostname that's been added to your DNS zone as an A, AAAA, or CNAME record. */
    customOriginServer?: string | null;
    /** A hostname that will be sent to your custom origin server as SNI for TLS handshake. This can be a valid subdomain of the zone or custom origin server name or the string ':request_host_header:' which will cause the host header in the request to be used as SNI. Not configurable with default/fallback origin server. */
    customOriginSni?: string | null;
    /** This is a record which can be placed to activate a hostname. */
    ownershipVerification?: ListResultItemOwnershipVerification | null;
    /** This presents the token to be served by the given http url to activate a hostname. */
    ownershipVerificationHttp?: CreateResponseOwnershipVerificationHttp | null;
    ssl?: ListResultItemSsl | null;
    /** Status of the hostname's activation. */
    status?: ListResultItemStatus | null;
    /** These are errors that were encountered while trying to activate a hostname. */
    verificationErrors?: ListResultItemVerificationErrorsList | null;
}
export type ListResultList = Array<ListResultItem>;
export interface ListCustomHostnamesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export type EditRequestCustomMetadataMap = {
    [key: string]: unknown | undefined;
};
export type EditRequestSslBundleMethod = "ubiquitous" | "optimal" | "force";
export type EditRequestSslCertificateAuthority = "digicert" | "google" | "lets_encrypt" | "ssl_com";
export type EditRequestSslCustomCertBundleItem = CreateRequestSslCustomCertBundleItem;
export type EditRequestSslCustomCertBundleList = Array<CreateRequestSslCustomCertBundleItem>;
export type EditRequestSslMethod = "http" | "txt" | "email";
export type EditRequestSslSettingsCiphersList = Array<string>;
export type EditRequestSslSettingsEarlyHints = "on" | "off";
export type EditRequestSslSettingsHttp2 = "on" | "off";
export type EditRequestSslSettingsMinTlsVersion = "1.0" | "1.1" | "1.2" | "1.3";
export type EditRequestSslSettingsTls13 = "on" | "off";
export interface EditRequestSslSettings {
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: EditRequestSslSettingsCiphersList;
    /** Whether or not Early Hints is enabled. */
    earlyHints?: EditRequestSslSettingsEarlyHints | (string & {});
    /** Whether or not HTTP2 is enabled. */
    http2?: EditRequestSslSettingsHttp2 | (string & {});
    /** The minimum TLS version supported. */
    minTlsVersion?: EditRequestSslSettingsMinTlsVersion | (string & {});
    /** Whether or not TLS 1.3 is enabled. */
    tls_1_3?: EditRequestSslSettingsTls13 | (string & {});
}
export type EditRequestSslType = "dv";
export interface EditRequestSsl {
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: EditRequestSslBundleMethod | (string & {});
    /** The Certificate Authority that will issue the certificate. */
    certificateAuthority?: EditRequestSslCertificateAuthority | (string & {});
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean;
    /** Array of custom certificate and key pairs (1 or 2 pairs allowed). */
    customCertBundle?: EditRequestSslCustomCertBundleList;
    /** If a custom uploaded certificate is used. */
    customCertificate?: string;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string;
    /** The key for a custom uploaded certificate. */
    customKey?: string;
    /** Domain control validation (DCV) method used for this hostname. */
    method?: EditRequestSslMethod | (string & {});
    /** SSL specific settings. */
    settings?: EditRequestSslSettings;
    /** Level of validation to be used for this hostname. Domain validation (dv) must be used. */
    type?: EditRequestSslType | (string & {});
    /** Indicates whether the certificate covers a wildcard. */
    wildcard?: boolean;
}
export interface PatchCustomHostnameRequest {
    /** Identifier. */
    zoneId: string;
    /** Custom hostname identifier tag. */
    customHostnameId: string;
    /** Unique key/value metadata for this hostname. These are per-hostname (customer) settings. */
    customMetadata?: EditRequestCustomMetadataMap;
    /** a valid hostname that's been added to your DNS zone as an A, AAAA, or CNAME record. */
    customOriginServer?: string;
    /** A hostname that will be sent to your custom origin server as SNI for TLS handshake. This can be a valid subdomain of the zone or custom origin server name or the string ':request_host_header:' which will cause the host header in the request to be used as SNI. Not configurable with default/fallback origin server. */
    customOriginSni?: string;
    /** SSL properties used when creating the custom hostname. */
    ssl?: EditRequestSsl;
}
export type EditResponseCustomMetadataMap = {
    [key: string]: unknown | undefined;
};
export type EditResponseOwnershipVerificationType = "txt";
export interface EditResponseOwnershipVerification {
    /** DNS Name for record. */
    name?: string | null;
    /** DNS Record type. */
    type?: EditResponseOwnershipVerificationType | null;
    /** Content for the record. */
    value?: string | null;
}
export type EditResponseOwnershipVerificationHttp = CreateResponseOwnershipVerificationHttp;
export type EditResponseSslBundleMethod = "ubiquitous" | "optimal" | "force";
export type EditResponseSslCertificateAuthority = "digicert" | "google" | "lets_encrypt" | "ssl_com";
export type EditResponseSslDcvDelegationRecordsItemEmailsList = Array<string>;
export interface EditResponseSslDcvDelegationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: EditResponseSslDcvDelegationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export type EditResponseSslDcvDelegationRecordsList = Array<EditResponseSslDcvDelegationRecordsItem>;
export type EditResponseSslHostsList = Array<string>;
export type EditResponseSslMethod = "http" | "txt" | "email";
export type EditResponseSslSettingsCiphersList = Array<string>;
export type EditResponseSslSettingsEarlyHints = "on" | "off";
export type EditResponseSslSettingsHttp2 = "on" | "off";
export type EditResponseSslSettingsMinTlsVersion = "1.0" | "1.1" | "1.2" | "1.3";
export type EditResponseSslSettingsTls13 = "on" | "off";
export interface EditResponseSslSettings {
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: EditResponseSslSettingsCiphersList | null;
    /** Whether or not Early Hints is enabled. */
    earlyHints?: EditResponseSslSettingsEarlyHints | null;
    /** Whether or not HTTP2 is enabled. */
    http2?: EditResponseSslSettingsHttp2 | null;
    /** The minimum TLS version supported. */
    minTlsVersion?: EditResponseSslSettingsMinTlsVersion | null;
    /** Whether or not TLS 1.3 is enabled. */
    tls_1_3?: EditResponseSslSettingsTls13 | null;
}
export type EditResponseSslStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export type EditResponseSslType = "dv";
export type EditResponseSslValidationErrorsItem = CreateResponseSslValidationErrorsItem;
export type EditResponseSslValidationErrorsList = Array<CreateResponseSslValidationErrorsItem>;
export type EditResponseSslValidationRecordsItemEmailsList = Array<string>;
export interface EditResponseSslValidationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: EditResponseSslValidationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export type EditResponseSslValidationRecordsList = Array<EditResponseSslValidationRecordsItem>;
export interface EditResponseSsl {
    /** Custom hostname SSL identifier tag. */
    id?: string | null;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: EditResponseSslBundleMethod | null;
    /** The Certificate Authority that will issue the certificate. */
    certificateAuthority?: EditResponseSslCertificateAuthority | null;
    /** If a custom uploaded certificate is used. */
    customCertificate?: string | null;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string | null;
    /** The key for a custom uploaded certificate. */
    customKey?: string | null;
    /** DCV Delegation records for domain validation. */
    dcvDelegationRecords?: EditResponseSslDcvDelegationRecordsList | null;
    /** The time the custom certificate expires on. */
    expiresOn?: string | null;
    /** A list of Hostnames on a custom uploaded certificate. */
    hosts?: EditResponseSslHostsList | null;
    /** The issuer on a custom uploaded certificate. */
    issuer?: string | null;
    /** Domain control validation (DCV) method used for this hostname. */
    method?: EditResponseSslMethod | null;
    /** The serial number on a custom uploaded certificate. */
    serialNumber?: string | null;
    settings?: EditResponseSslSettings | null;
    /** The signature on a custom uploaded certificate. */
    signature?: string | null;
    /** Status of the hostname's SSL certificates. */
    status?: EditResponseSslStatus | null;
    /** Level of validation to be used for this hostname. Domain validation (dv) must be used. */
    type?: EditResponseSslType | null;
    /** The time the custom certificate was uploaded. */
    uploadedOn?: string | null;
    /** Domain validation errors that have been received by the certificate authority (CA). */
    validationErrors?: EditResponseSslValidationErrorsList | null;
    validationRecords?: EditResponseSslValidationRecordsList | null;
    /** Indicates whether the certificate covers a wildcard. */
    wildcard?: boolean | null;
}
export type EditResponseStatus = "active" | "pending" | "active_redeploying" | "moved" | "pending_deletion" | "deleted" | "pending_blocked" | "pending_migration" | "pending_provisioned" | "test_pending" | "test_active" | "test_active_apex" | "test_blocked" | "test_failed" | "provisioned" | "blocked";
export type EditResponseVerificationErrorsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCustomHostnameResponse {
    /** Custom hostname identifier tag. */
    id: string;
    /** The custom hostname that will point to your hostname via CNAME. */
    hostname: string;
    /** This is the time the hostname was created. */
    createdAt?: string | null;
    /** Unique key/value metadata for this hostname. These are per-hostname (customer) settings. */
    customMetadata?: EditResponseCustomMetadataMap | null;
    /** a valid hostname that's been added to your DNS zone as an A, AAAA, or CNAME record. */
    customOriginServer?: string | null;
    /** A hostname that will be sent to your custom origin server as SNI for TLS handshake. This can be a valid subdomain of the zone or custom origin server name or the string ':request_host_header:' which will cause the host header in the request to be used as SNI. Not configurable with default/fallback origin server. */
    customOriginSni?: string | null;
    /** This is a record which can be placed to activate a hostname. */
    ownershipVerification?: EditResponseOwnershipVerification | null;
    /** This presents the token to be served by the given http url to activate a hostname. */
    ownershipVerificationHttp?: CreateResponseOwnershipVerificationHttp | null;
    ssl?: EditResponseSsl | null;
    /** Status of the hostname's activation. */
    status?: EditResponseStatus | null;
    /** These are errors that were encountered while trying to activate a hostname. */
    verificationErrors?: EditResponseVerificationErrorsList | null;
}
export interface PutCertificatePackCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Custom hostname identifier tag. */
    customHostnameId: string;
    /** Custom hostname identifier tag. */
    certificatePackId: string;
    /** Custom hostname identifier tag. */
    certificateId: string;
    /** If a custom uploaded certificate is used. */
    customCertificate: string;
    /** The key for a custom uploaded certificate. */
    customKey: string;
}
export type CertificatePackCertificatesUpdateResponseCustomMetadataMap = {
    [key: string]: unknown | undefined;
};
export type CertificatePackCertificatesUpdateResponseOwnershipVerificationType = "txt";
export interface CertificatePackCertificatesUpdateResponseOwnershipVerification {
    /** DNS Name for record. */
    name?: string | null;
    /** DNS Record type. */
    type?: CertificatePackCertificatesUpdateResponseOwnershipVerificationType | null;
    /** Content for the record. */
    value?: string | null;
}
export type CertificatePackCertificatesUpdateResponseOwnershipVerificationHttp = CreateResponseOwnershipVerificationHttp;
export type CertificatePackCertificatesUpdateResponseSslBundleMethod = "ubiquitous" | "optimal" | "force";
export type CertificatePackCertificatesUpdateResponseSslCertificateAuthority = "digicert" | "google" | "lets_encrypt" | "ssl_com";
export type CertificatePackCertificatesUpdateResponseSslDcvDelegationRecordsItemEmailsList = Array<string>;
export interface CertificatePackCertificatesUpdateResponseSslDcvDelegationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePackCertificatesUpdateResponseSslDcvDelegationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export type CertificatePackCertificatesUpdateResponseSslDcvDelegationRecordsList = Array<CertificatePackCertificatesUpdateResponseSslDcvDelegationRecordsItem>;
export type CertificatePackCertificatesUpdateResponseSslHostsList = Array<string>;
export type CertificatePackCertificatesUpdateResponseSslMethod = "http" | "txt" | "email";
export type CertificatePackCertificatesUpdateResponseSslSettingsCiphersList = Array<string>;
export type CertificatePackCertificatesUpdateResponseSslSettingsEarlyHints = "on" | "off";
export type CertificatePackCertificatesUpdateResponseSslSettingsHttp2 = "on" | "off";
export type CertificatePackCertificatesUpdateResponseSslSettingsMinTlsVersion = "1.0" | "1.1" | "1.2" | "1.3";
export type CertificatePackCertificatesUpdateResponseSslSettingsTls13 = "on" | "off";
export interface CertificatePackCertificatesUpdateResponseSslSettings {
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: CertificatePackCertificatesUpdateResponseSslSettingsCiphersList | null;
    /** Whether or not Early Hints is enabled. */
    earlyHints?: CertificatePackCertificatesUpdateResponseSslSettingsEarlyHints | null;
    /** Whether or not HTTP2 is enabled. */
    http2?: CertificatePackCertificatesUpdateResponseSslSettingsHttp2 | null;
    /** The minimum TLS version supported. */
    minTlsVersion?: CertificatePackCertificatesUpdateResponseSslSettingsMinTlsVersion | null;
    /** Whether or not TLS 1.3 is enabled. */
    tls_1_3?: CertificatePackCertificatesUpdateResponseSslSettingsTls13 | null;
}
export type CertificatePackCertificatesUpdateResponseSslStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export type CertificatePackCertificatesUpdateResponseSslType = "dv";
export type CertificatePackCertificatesUpdateResponseSslValidationErrorsItem = CreateResponseSslValidationErrorsItem;
export type CertificatePackCertificatesUpdateResponseSslValidationErrorsList = Array<CreateResponseSslValidationErrorsItem>;
export type CertificatePackCertificatesUpdateResponseSslValidationRecordsItemEmailsList = Array<string>;
export interface CertificatePackCertificatesUpdateResponseSslValidationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePackCertificatesUpdateResponseSslValidationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export type CertificatePackCertificatesUpdateResponseSslValidationRecordsList = Array<CertificatePackCertificatesUpdateResponseSslValidationRecordsItem>;
export interface CertificatePackCertificatesUpdateResponseSsl {
    /** Custom hostname SSL identifier tag. */
    id?: string | null;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: CertificatePackCertificatesUpdateResponseSslBundleMethod | null;
    /** The Certificate Authority that will issue the certificate. */
    certificateAuthority?: CertificatePackCertificatesUpdateResponseSslCertificateAuthority | null;
    /** If a custom uploaded certificate is used. */
    customCertificate?: string | null;
    /** The identifier for the Custom CSR that was used. */
    customCsrId?: string | null;
    /** The key for a custom uploaded certificate. */
    customKey?: string | null;
    /** DCV Delegation records for domain validation. */
    dcvDelegationRecords?: CertificatePackCertificatesUpdateResponseSslDcvDelegationRecordsList | null;
    /** The time the custom certificate expires on. */
    expiresOn?: string | null;
    /** A list of Hostnames on a custom uploaded certificate. */
    hosts?: CertificatePackCertificatesUpdateResponseSslHostsList | null;
    /** The issuer on a custom uploaded certificate. */
    issuer?: string | null;
    /** Domain control validation (DCV) method used for this hostname. */
    method?: CertificatePackCertificatesUpdateResponseSslMethod | null;
    /** The serial number on a custom uploaded certificate. */
    serialNumber?: string | null;
    settings?: CertificatePackCertificatesUpdateResponseSslSettings | null;
    /** The signature on a custom uploaded certificate. */
    signature?: string | null;
    /** Status of the hostname's SSL certificates. */
    status?: CertificatePackCertificatesUpdateResponseSslStatus | null;
    /** Level of validation to be used for this hostname. Domain validation (dv) must be used. */
    type?: CertificatePackCertificatesUpdateResponseSslType | null;
    /** The time the custom certificate was uploaded. */
    uploadedOn?: string | null;
    /** Domain validation errors that have been received by the certificate authority (CA). */
    validationErrors?: CertificatePackCertificatesUpdateResponseSslValidationErrorsList | null;
    validationRecords?: CertificatePackCertificatesUpdateResponseSslValidationRecordsList | null;
    /** Indicates whether the certificate covers a wildcard. */
    wildcard?: boolean | null;
}
export type CertificatePackCertificatesUpdateResponseStatus = "active" | "pending" | "active_redeploying" | "moved" | "pending_deletion" | "deleted" | "pending_blocked" | "pending_migration" | "pending_provisioned" | "test_pending" | "test_active" | "test_active_apex" | "test_blocked" | "test_failed" | "provisioned" | "blocked";
export type CertificatePackCertificatesUpdateResponseVerificationErrorsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutCertificatePackCertificateResponse {
    /** Custom hostname identifier tag. */
    id: string;
    /** The custom hostname that will point to your hostname via CNAME. */
    hostname: string;
    /** This is the time the hostname was created. */
    createdAt?: string | null;
    /** Unique key/value metadata for this hostname. These are per-hostname (customer) settings. */
    customMetadata?: CertificatePackCertificatesUpdateResponseCustomMetadataMap | null;
    /** a valid hostname that's been added to your DNS zone as an A, AAAA, or CNAME record. */
    customOriginServer?: string | null;
    /** A hostname that will be sent to your custom origin server as SNI for TLS handshake. This can be a valid subdomain of the zone or custom origin server name or the string ':request_host_header:' which will cause the host header in the request to be used as SNI. Not configurable with default/fallback origin server. */
    customOriginSni?: string | null;
    /** This is a record which can be placed to activate a hostname. */
    ownershipVerification?: CertificatePackCertificatesUpdateResponseOwnershipVerification | null;
    /** This presents the token to be served by the given http url to activate a hostname. */
    ownershipVerificationHttp?: CreateResponseOwnershipVerificationHttp | null;
    ssl?: CertificatePackCertificatesUpdateResponseSsl | null;
    /** Status of the hostname's activation. */
    status?: CertificatePackCertificatesUpdateResponseStatus | null;
    /** These are errors that were encountered while trying to activate a hostname. */
    verificationErrors?: CertificatePackCertificatesUpdateResponseVerificationErrorsList | null;
}
export interface PutFallbackOriginRequest {
    /** Identifier. */
    zoneId: string;
    /** Your origin hostname that requests to your custom hostnames will be sent to. */
    origin: string;
}
export type FallbackOriginUpdateResponseErrorsList = Array<string>;
export type FallbackOriginUpdateResponseStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deployment_timed_out" | "deletion_timed_out";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutFallbackOriginResponse {
    /** This is the time the fallback origin was created. */
    createdAt?: string | null;
    /** These are errors that were encountered while trying to activate a fallback origin. */
    errors?: FallbackOriginUpdateResponseErrorsList | null;
    /** Your origin hostname that requests to your custom hostnames will be sent to. */
    origin?: string | null;
    /** Status of the fallback origin's activation. */
    status?: FallbackOriginUpdateResponseStatus | null;
    /** This is the time the fallback origin was updated. */
    updatedAt?: string | null;
}
export type CreateCustomHostnameError = SaasQuotaNotAllocated | CloudflareOpError;
/** Add a new custom hostname and request that an SSL certificate be issued for it. One of three validation methods--http, txt, email--should be used, with 'http' recommended if the CNAME is already in place (or will be soon). Specifying 'email' will send an email to the WHOIS contacts on file for the base domain plus hostmaster, postmaster, webmaster, admin, administrator. If http is used and the domain is not already pointing to the Managed CNAME host, the PATCH method must be used once it is (to complete validation). Enable bundling of certificates using the custom_cert_bundle field. The bundling process requires the following condition One certificate in the bundle must use an RSA, and the other must use an ECDSA. */
export declare const createCustomHostname: API.OperationMethod<CreateCustomHostnameRequest, CreateCustomHostnameResponse, CreateCustomHostnameError, CloudflareOpContext>;
export type DeleteCertificatePackCertificateError = CloudflareOpError;
/** Delete a single custom certificate from a certificate pack that contains two bundled certificates. Deletion is subject to the following constraints. You cannot delete a certificate if it is the only remaining certificate in the pack. At least one certificate must remain in the pack. */
export declare const deleteCertificatePackCertificate: API.OperationMethod<DeleteCertificatePackCertificateRequest, DeleteCertificatePackCertificateResponse, DeleteCertificatePackCertificateError, CloudflareOpContext>;
export type DeleteCustomHostnameError = CustomHostnameNotFound | SaasQuotaNotAllocated | CloudflareOpError;
/** Permanently deletes a custom hostname and revokes any SSL certificates that were issued for it. This action cannot be undone. */
export declare const deleteCustomHostname: API.OperationMethod<DeleteCustomHostnameRequest, DeleteCustomHostnameResponse, DeleteCustomHostnameError, CloudflareOpContext>;
export type DeleteFallbackOriginError = FallbackOriginNotFound | SaasAccessNotGranted | CloudflareOpError;
/** Removes the fallback origin configuration for custom hostnames on a zone. Custom hostnames without specific origins will no longer have a fallback. */
export declare const deleteFallbackOrigin: API.OperationMethod<DeleteFallbackOriginRequest, DeleteFallbackOriginResponse, DeleteFallbackOriginError, CloudflareOpContext>;
export type GetCustomHostnameError = CustomHostnameNotFound | SaasQuotaNotAllocated | Forbidden | CloudflareOpError;
/** Retrieves detailed information about a specific custom hostname, including SSL certificate status, ownership verification, and origin configuration. */
export declare const getCustomHostname: API.OperationMethod<GetCustomHostnameRequest, GetCustomHostnameResponse, GetCustomHostnameError, CloudflareOpContext>;
export type GetFallbackOriginError = FallbackOriginNotFound | SaasAccessNotGranted | Forbidden | CloudflareOpError;
/** Retrieves the current fallback origin configuration for custom hostnames on a zone. The fallback origin handles traffic when specific custom hostname origins are unavailable. */
export declare const getFallbackOrigin: API.OperationMethod<GetFallbackOriginRequest, GetFallbackOriginResponse, GetFallbackOriginError, CloudflareOpContext>;
export type GetQuotaError = CloudflareOpError;
/** Returns custom hostname quota usage for a zone. The allocated quota is a soft limit; creating custom hostnames after usage exceeds this limit can still succeed until the hard cap is reached. Use the exceeded and hard_cap fields to track when usage is above the soft limit and when new custom hostname creation will be rejected. */
export declare const getQuota: API.OperationMethod<GetQuotaRequest, GetQuotaResponse, GetQuotaError, CloudflareOpContext>;
export type ListCustomHostnamesError = SaasQuotaNotAllocated | Forbidden | CloudflareOpError;
/** List, search, sort, and filter all of your custom hostnames. */
export declare const listCustomHostnames: API.PaginatedOperationMethod<ListCustomHostnamesRequest, ListCustomHostnamesResponse, ListCustomHostnamesError, CloudflareOpContext, ListResultItem>;
export type PatchCustomHostnameError = CustomHostnameNotFound | SaasQuotaNotAllocated | CloudflareOpError;
/** Modify SSL configuration for a custom hostname. When sent with SSL config that matches existing config, used to indicate that hostname should pass domain control validation (DCV). Can also be used to change validation type, e.g., from 'http' to 'email'. Bundle an existing certificate with another certificate by using the "custom_cert_bundle" field. The bundling process supports combining certificates as long as the following condition is met. One certificate must use the RSA algorithm, and the other must use the ECDSA algorithm. */
export declare const patchCustomHostname: API.OperationMethod<PatchCustomHostnameRequest, PatchCustomHostnameResponse, PatchCustomHostnameError, CloudflareOpContext>;
export type PutCertificatePackCertificateError = CloudflareOpError;
/** Replace a single custom certificate within a certificate pack that contains two bundled certificates. The replacement must adhere to the following constraints. You can only replace an RSA certificate with another RSA certificate or an ECDSA certificate with another ECDSA certificate. */
export declare const putCertificatePackCertificate: API.OperationMethod<PutCertificatePackCertificateRequest, PutCertificatePackCertificateResponse, PutCertificatePackCertificateError, CloudflareOpContext>;
export type PutFallbackOriginError = SaasAccessNotGranted | CloudflareOpError;
/** Updates the fallback origin configuration for custom hostnames on a zone. Sets the default origin server for custom hostname traffic. */
export declare const putFallbackOrigin: API.OperationMethod<PutFallbackOriginRequest, PutFallbackOriginResponse, PutFallbackOriginError, CloudflareOpContext>;
//# sourceMappingURL=custom_hostnames.d.ts.map