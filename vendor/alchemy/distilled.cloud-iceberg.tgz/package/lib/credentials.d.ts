/**
 * Iceberg REST Catalog credentials -- hand-written.
 *
 * The `Credentials` service resolves `{ uri, token, prefix }` per request;
 * the protocol layer builds every URL from it.
 *
 * - `uri` is the catalog's REST endpoint -- what Iceberg clients call the
 *   catalog URI (`https://catalog.cloudflarestorage.com/<account>/<bucket>`
 *   for Basin Catalog, `http://localhost:8181` for a local REST catalog).
 *   Routes are `<uri>/v1/...`.
 * - `prefix` is the per-warehouse path segment a catalog hands out from
 *   `GET /v1/config` (`overrides.prefix`). It is CLIENT configuration, not
 *   an operation input: every catalog route is `<uri>/v1/<prefix>/...`, and a
 *   catalog with no prefix serves `<uri>/v1/...`. {@link fromCatalogConfig}
 *   resolves it for you from a warehouse name.
 * - `token` is sent as `Authorization: Bearer <token>`. It is optional
 *   because some catalogs (a local REST catalog, a sidecar) take none.
 */
import { ConfigError } from "@distilled.cloud/core/errors";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
export interface Config {
    /** Catalog REST endpoint, without the `/v1` suffix. */
    readonly uri: string;
    /** Per-warehouse route prefix from `GET /v1/config` (`overrides.prefix`). */
    readonly prefix?: string;
    /** Bearer token, when the catalog requires one. */
    readonly token?: Redacted.Redacted<string>;
}
declare const Credentials_base: Context.ServiceClass<Credentials, "IcebergCredentials", Effect.Effect<Config, never, never>>;
export declare class Credentials extends /*@__PURE__*/ Credentials_base {
}
/**
 * `ICEBERG_CATALOG_URI` (required), `ICEBERG_PREFIX` and `ICEBERG_TOKEN`
 * (optional).
 */
export declare const CredentialsFromEnv: Layer.Layer<Credentials, never, never>;
/** Convenience layer from a catalog URI, optional prefix and optional token. */
export declare const credentials: (config: Config) => Layer.Layer<Credentials>;
/**
 * Resolve a warehouse to its catalog configuration once, at layer build:
 * `GET <uri>/v1/config?warehouse=<warehouse>`, then use the catalog's
 * `overrides` -- `prefix`, and `uri` when the catalog redirects clients to
 * another endpoint -- exactly as Iceberg clients do.
 *
 * @example
 * ```ts
 * const Catalog = Iceberg.fromCatalogConfig({
 *   uri: "https://catalog.cloudflarestorage.com/<account>/<bucket>",
 *   warehouse: "<account>_<bucket>",
 *   token: Redacted.make(process.env.CLOUDFLARE_API_TOKEN!),
 * });
 * ```
 */
export declare const fromCatalogConfig: (options: {
    readonly uri: string;
    readonly warehouse: string;
    readonly token?: Redacted.Redacted<string>;
}) => Layer.Layer<Credentials, ConfigError, HttpClient.HttpClient>;
export {};
//# sourceMappingURL=credentials.d.ts.map