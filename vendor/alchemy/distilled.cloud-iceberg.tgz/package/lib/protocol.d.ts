import type * as API from "@distilled.cloud/core/api";
import type { ConfigError } from "@distilled.cloud/core/errors";
import type * as HttpClient from "effect/http/HttpClient";
import type * as HttpClientError from "effect/http/HttpClientError";
import type * as Layer from "effect/Layer";
import { Credentials, type Config } from "./credentials.ts";
import { type DefaultErrors } from "./errors.ts";
/**
 * Error channel shared by every generated Iceberg operation. Generated
 * service files annotate operations with `API.OperationMethod<I, O,
 * IcebergOpError, IcebergOpContext>` explicitly so the compiler never infers
 * these back out of the schema generics.
 */
export type IcebergOpError = DefaultErrors | ConfigError | HttpClientError.HttpClientError;
/** Context (requirements) shared by every generated Iceberg operation. */
export type IcebergOpContext = Credentials | HttpClient.HttpClient;
/** `<uri>/v1` or `<uri>/v1/<prefix>` for a route. Exported for tests. */
export declare const baseUrlFor: (creds: Config, uri: string) => string;
export declare const IcebergProtocol: Layer.Layer<API.Protocol>;
//# sourceMappingURL=protocol.d.ts.map