import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type IcebergOpError, type IcebergOpContext } from "../protocol.ts";
export type { IcebergOpError, IcebergOpContext };
declare const AlreadyExistsException_base: S.TaggedErrorClass<"AlreadyExistsException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const CommitFailedException_base: S.TaggedErrorClass<"CommitFailedException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class CommitFailedException extends /*@__PURE__*/ CommitFailedException_base {
}
declare const CommitStateUnknownException_base: S.TaggedErrorClass<"CommitStateUnknownException", {
    readonly code: any;
    readonly message: any;
}>;
export declare class CommitStateUnknownException extends /*@__PURE__*/ CommitStateUnknownException_base {
}
declare const NamespaceNotEmptyException_base: S.TaggedErrorClass<"NamespaceNotEmptyException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class NamespaceNotEmptyException extends /*@__PURE__*/ NamespaceNotEmptyException_base {
}
declare const NoSuchFunctionException_base: S.TaggedErrorClass<"NoSuchFunctionException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchFunctionException extends /*@__PURE__*/ NoSuchFunctionException_base {
}
declare const NoSuchNamespaceException_base: S.TaggedErrorClass<"NoSuchNamespaceException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchNamespaceException extends /*@__PURE__*/ NoSuchNamespaceException_base {
}
declare const NoSuchPlanIdException_base: S.TaggedErrorClass<"NoSuchPlanIdException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchPlanIdException extends /*@__PURE__*/ NoSuchPlanIdException_base {
}
declare const NoSuchPlanTaskException_base: S.TaggedErrorClass<"NoSuchPlanTaskException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchPlanTaskException extends /*@__PURE__*/ NoSuchPlanTaskException_base {
}
declare const NoSuchTableException_base: S.TaggedErrorClass<"NoSuchTableException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchTableException extends /*@__PURE__*/ NoSuchTableException_base {
}
declare const NoSuchViewException_base: S.TaggedErrorClass<"NoSuchViewException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchViewException extends /*@__PURE__*/ NoSuchViewException_base {
}
declare const NoSuchWarehouseException_base: S.TaggedErrorClass<"NoSuchWarehouseException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchWarehouseException extends /*@__PURE__*/ NoSuchWarehouseException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type CancelPlanningRequestXIcebergAccessDelegationItem = "vended-credentials" | "remote-signing";
export type CancelPlanningRequestXIcebergAccessDelegationList = Array<CancelPlanningRequestXIcebergAccessDelegationItem | (string & {})>;
export interface CancelPlanningRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A table name */
    table: string;
    /** ID used to track a planning request */
    plan_id: string;
    /** Optional signal to the server that the client supports delegated access via a comma-separated list of access mechanisms. The server may choose to supply access via any or none of the requested mechanisms. Specific properties and handling for `vended-credentials` and `remote-signing` are documented in the `LoadTableResult` schema section of this spec document. */
    xIcebergAccessDelegation?: CancelPlanningRequestXIcebergAccessDelegationList;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
}
export interface CancelPlanningResponse {
}
/** Reference to one or more levels of a namespace */
export type Namespace = Array<string>;
export interface TableIdentifier {
    namespace: Namespace;
    name: string;
}
export interface TableRequirement {
    type: string;
}
export type CommitTableRequestInputRequirementsList = Array<TableRequirement>;
/** Assigning a UUID to a table/view should only be done when creating the table/view. It is not safe to re-assign the UUID if a table/view already has a UUID assigned */
export interface AssignUUIDUpdate {
    action: string;
    uuid: string;
}
export interface UpgradeFormatVersionUpdate {
    action: string;
    format_version: number;
}
export type StructTypeFieldsList = Array<StructField>;
export interface StructType {
    type: string;
    fields: StructTypeFieldsList;
}
export interface ListType {
    type: string;
    element_id: number;
    element: Type;
    element_required: boolean;
}
export interface MapType {
    type: string;
    key_id: number;
    key: Type;
    value_id: number;
    value: Type;
    value_required: boolean;
}
export type Type = string | StructType | ListType | MapType;
export type PrimitiveTypeValue = boolean | number | number | string;
export interface StructField {
    id: number;
    name: string;
    type: Type;
    required: boolean;
    doc?: string;
    initial_default?: PrimitiveTypeValue;
    write_default?: PrimitiveTypeValue;
}
export type SchemaInputFieldsList = Array<StructField>;
export type SchemaInputIdentifierFieldIdsList = Array<number>;
export interface SchemaInput {
    type: string;
    fields: SchemaInputFieldsList;
    identifier_field_ids?: SchemaInputIdentifierFieldIdsList;
}
export interface AddSchemaUpdateInput {
    action: string;
    schema: SchemaInput;
    /** This optional field is **DEPRECATED for REMOVAL** since it more safe to handle this internally, and shouldn't be exposed to the clients. The highest assigned column ID for the table. This is used to ensure columns are always assigned an unused ID when evolving schemas. When omitted, it will be computed on the server side. */
    last_column_id?: number;
}
export interface SetCurrentSchemaUpdate {
    action: string;
    /** Schema ID to set as current, or -1 to set last added schema */
    schema_id: number;
}
export interface PartitionField {
    field_id?: number;
    source_id: number;
    name: string;
    transform: string;
}
export type PartitionSpecInputFieldsList = Array<PartitionField>;
export interface PartitionSpecInput {
    fields: PartitionSpecInputFieldsList;
}
export interface AddPartitionSpecUpdateInput {
    action: string;
    spec: PartitionSpecInput;
}
export interface SetDefaultSpecUpdate {
    action: string;
    /** Partition spec ID to set as the default, or -1 to set last added spec */
    spec_id: number;
}
export type SortDirection = "asc" | "desc";
export type NullOrder = "nulls-first" | "nulls-last";
export interface SortField {
    source_id: number;
    transform: string;
    direction: SortDirection | (string & {});
    null_order: NullOrder | (string & {});
}
export type SortOrderInputFieldsList = Array<SortField>;
export interface SortOrderInput {
    fields: SortOrderInputFieldsList;
}
export interface AddSortOrderUpdateInput {
    action: string;
    sort_order: SortOrderInput;
}
export interface SetDefaultSortOrderUpdate {
    action: string;
    /** Sort order ID to set as the default, or -1 to set last added sort order */
    sort_order_id: number;
}
export type SnapshotSummaryOperation = "append" | "replace" | "overwrite" | "delete";
export interface SnapshotSummary {
    operation: SnapshotSummaryOperation | (string & {});
}
export interface Snapshot {
    snapshot_id: number;
    parent_snapshot_id?: number;
    sequence_number?: number;
    timestamp_ms: number;
    /** Location of the snapshot's manifest list file */
    manifest_list: string;
    /** The first _row_id assigned to the first row in the first data file in the first manifest */
    first_row_id?: number;
    /** The upper bound of the number of rows with assigned row IDs */
    added_rows?: number;
    summary: SnapshotSummary;
    schema_id?: number;
}
export interface AddSnapshotUpdate {
    action: string;
    snapshot: Snapshot;
}
export type SetSnapshotRefUpdateType = "tag" | "branch";
export interface SetSnapshotRefUpdate {
    action: string;
    type: SetSnapshotRefUpdateType | (string & {});
    snapshot_id: number;
    max_ref_age_ms?: number;
    max_snapshot_age_ms?: number;
    min_snapshots_to_keep?: number;
    ref_name: string;
}
export type RemoveSnapshotsUpdateSnapshotIdsList = Array<number>;
export interface RemoveSnapshotsUpdate {
    action: string;
    snapshot_ids: RemoveSnapshotsUpdateSnapshotIdsList;
}
export interface RemoveSnapshotRefUpdate {
    action: string;
    ref_name: string;
}
export interface SetLocationUpdate {
    action: string;
    location: string;
}
export type SetPropertiesUpdateUpdatesMap = {
    [key: string]: string | undefined;
};
export interface SetPropertiesUpdate {
    action: string;
    updates: SetPropertiesUpdateUpdatesMap;
}
export type RemovePropertiesUpdateRemovalsList = Array<string>;
export interface RemovePropertiesUpdate {
    action: string;
    removals: RemovePropertiesUpdateRemovalsList;
}
export type BlobMetadataFieldsList = Array<number>;
export type BlobMetadataPropertiesMap = {
    [key: string]: string | undefined;
};
export interface BlobMetadata {
    type: string;
    snapshot_id: number;
    sequence_number: number;
    fields: BlobMetadataFieldsList;
    properties?: BlobMetadataPropertiesMap;
}
export type StatisticsFileBlobMetadataList = Array<BlobMetadata>;
export interface StatisticsFile {
    snapshot_id: number;
    statistics_path: string;
    file_size_in_bytes: number;
    file_footer_size_in_bytes: number;
    blob_metadata: StatisticsFileBlobMetadataList;
}
export interface SetStatisticsUpdate {
    action: string;
    /** This optional field is **DEPRECATED for REMOVAL** since it contains redundant information. Clients should use the `statistics.snapshot-id` field instead. */
    snapshot_id?: number;
    statistics: StatisticsFile;
}
export interface RemoveStatisticsUpdate {
    action: string;
    snapshot_id: number;
}
export interface PartitionStatisticsFile {
    snapshot_id: number;
    statistics_path: string;
    file_size_in_bytes: number;
}
export interface SetPartitionStatisticsUpdate {
    action: string;
    partition_statistics: PartitionStatisticsFile;
}
export type RemovePartitionStatisticsUpdate = RemoveStatisticsUpdate;
export type RemovePartitionSpecsUpdateSpecIdsList = Array<number>;
export interface RemovePartitionSpecsUpdate {
    action: string;
    spec_ids: RemovePartitionSpecsUpdateSpecIdsList;
}
export type RemoveSchemasUpdateSchemaIdsList = Array<number>;
export interface RemoveSchemasUpdate {
    action: string;
    schema_ids: RemoveSchemasUpdateSchemaIdsList;
}
export type EncryptedKeyPropertiesMap = {
    [key: string]: string | undefined;
};
export interface EncryptedKey {
    key_id: string;
    encrypted_key_metadata: string;
    encrypted_by_id?: string;
    properties?: EncryptedKeyPropertiesMap;
}
export interface AddEncryptionKeyUpdate {
    action: string;
    encryption_key: EncryptedKey;
}
export interface RemoveEncryptionKeyUpdate {
    action: string;
    key_id: string;
}
export type TableUpdateInput = AssignUUIDUpdate | UpgradeFormatVersionUpdate | AddSchemaUpdateInput | SetCurrentSchemaUpdate | AddPartitionSpecUpdateInput | SetDefaultSpecUpdate | AddSortOrderUpdateInput | SetDefaultSortOrderUpdate | AddSnapshotUpdate | SetSnapshotRefUpdate | RemoveSnapshotsUpdate | RemoveSnapshotRefUpdate | SetLocationUpdate | SetPropertiesUpdate | RemovePropertiesUpdate | SetStatisticsUpdate | RemoveStatisticsUpdate | SetPartitionStatisticsUpdate | RemoveStatisticsUpdate | RemovePartitionSpecsUpdate | RemoveSchemasUpdate | AddEncryptionKeyUpdate | RemoveEncryptionKeyUpdate;
export type CommitTableRequestInputUpdatesList = Array<TableUpdateInput>;
export interface CommitTableRequestInput {
    /** Table identifier to update; must be present for CommitTransactionRequest */
    identifier?: TableIdentifier;
    requirements: CommitTableRequestInputRequirementsList;
    updates: CommitTableRequestInputUpdatesList;
}
export type CommitTransactionRequestTableChangesList = Array<CommitTableRequestInput>;
export interface CommitTransactionRequest {
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
    table_changes: CommitTransactionRequestTableChangesList;
}
export interface CommitTransactionResponse {
}
/** Configured string to string map of properties for the namespace */
export type CreateNamespaceRequestPropertiesMap = {
    [key: string]: string | undefined;
};
export interface CreateNamespaceRequest {
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
    namespace: Namespace;
    /** Configured string to string map of properties for the namespace */
    properties?: CreateNamespaceRequestPropertiesMap;
}
/** Properties stored on the namespace, if supported by the server. */
export type CreateNamespaceResponsePropertiesMap = {
    [key: string]: string | undefined;
};
export interface CreateNamespaceResponse {
    namespace: Namespace;
    /** Properties stored on the namespace, if supported by the server. */
    properties?: CreateNamespaceResponsePropertiesMap;
}
export type CreateTableRequestXIcebergAccessDelegationItem = "vended-credentials" | "remote-signing";
export type CreateTableRequestXIcebergAccessDelegationList = Array<CreateTableRequestXIcebergAccessDelegationItem | (string & {})>;
export type CreateTableRequestPropertiesMap = {
    [key: string]: string | undefined;
};
export interface CreateTableRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** Optional signal to the server that the client supports delegated access via a comma-separated list of access mechanisms. The server may choose to supply access via any or none of the requested mechanisms. Specific properties and handling for `vended-credentials` and `remote-signing` are documented in the `LoadTableResult` schema section of this spec document. */
    xIcebergAccessDelegation?: CreateTableRequestXIcebergAccessDelegationList;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
    name: string;
    location?: string;
    schema: SchemaInput;
    partition_spec?: PartitionSpecInput;
    write_order?: SortOrderInput;
    stage_create?: boolean;
    properties?: CreateTableRequestPropertiesMap;
}
export type TableMetadataPropertiesMap = {
    [key: string]: string | undefined;
};
export type SchemaFieldsList = Array<StructField>;
export type SchemaIdentifierFieldIdsList = Array<number>;
export interface Schema {
    type: string;
    fields: SchemaFieldsList;
    schema_id?: number;
    identifier_field_ids?: SchemaIdentifierFieldIdsList;
}
export type TableMetadataSchemasList = Array<Schema>;
export type PartitionSpecFieldsList = Array<PartitionField>;
export interface PartitionSpec {
    spec_id?: number;
    fields: PartitionSpecFieldsList;
}
export type TableMetadataPartitionSpecsList = Array<PartitionSpec>;
export type SortOrderFieldsList = Array<SortField>;
export interface SortOrder {
    order_id: number;
    fields: SortOrderFieldsList;
}
export type TableMetadataSortOrdersList = Array<SortOrder>;
export type TableMetadataEncryptionKeysList = Array<EncryptedKey>;
export type TableMetadataSnapshotsList = Array<Snapshot>;
export type SnapshotReferenceType = "tag" | "branch";
export interface SnapshotReference {
    type: SnapshotReferenceType;
    snapshot_id: number;
    max_ref_age_ms?: number;
    max_snapshot_age_ms?: number;
    min_snapshots_to_keep?: number;
}
export type SnapshotReferences = {
    [key: string]: SnapshotReference | undefined;
};
export interface SnapshotLogItem {
    snapshot_id: number;
    timestamp_ms: number;
}
export type SnapshotLog = Array<SnapshotLogItem>;
export interface MetadataLogItem {
    metadata_file: string;
    timestamp_ms: number;
}
export type MetadataLog = Array<MetadataLogItem>;
export type TableMetadataStatisticsList = Array<StatisticsFile>;
export type TableMetadataPartitionStatisticsList = Array<PartitionStatisticsFile>;
export interface TableMetadata {
    format_version: number;
    table_uuid: string;
    location?: string;
    last_updated_ms?: number;
    /** A long higher than all assigned row IDs; the next snapshot's first-row-id. */
    next_row_id?: number;
    properties?: TableMetadataPropertiesMap;
    schemas?: TableMetadataSchemasList;
    current_schema_id?: number;
    last_column_id?: number;
    partition_specs?: TableMetadataPartitionSpecsList;
    default_spec_id?: number;
    last_partition_id?: number;
    sort_orders?: TableMetadataSortOrdersList;
    default_sort_order_id?: number;
    encryption_keys?: TableMetadataEncryptionKeysList;
    snapshots?: TableMetadataSnapshotsList;
    refs?: SnapshotReferences;
    current_snapshot_id?: number;
    last_sequence_number?: number;
    snapshot_log?: SnapshotLog;
    metadata_log?: MetadataLog;
    statistics?: TableMetadataStatisticsList;
    partition_statistics?: TableMetadataPartitionStatisticsList;
}
export type LoadTableResultConfigMap = {
    [key: string]: string | undefined;
};
export type StorageCredentialConfigMap = {
    [key: string]: string | undefined;
};
export interface StorageCredential {
    /** Indicates a storage location prefix where the credential is relevant. Clients should choose the most specific prefix (by selecting the longest prefix) if several credentials of the same type are available. */
    prefix: string;
    config: StorageCredentialConfigMap;
}
export type LoadTableResultStorageCredentialsList = Array<StorageCredential>;
/** Static key-value pairs the signer client MUST pass through unchanged in the `properties` field of every `RemoteSignRequest` sent to the signing endpoint. */
export type RemoteSigningConfigPropertiesMap = {
    [key: string]: string | undefined;
};
export type MultiValuedMapValueList = Array<string>;
/** A map of string keys where each key can map to multiple string values. */
export type MultiValuedMap = {
    [key: string]: MultiValuedMapValueList | undefined;
};
/** Configuration for the remote signer client. */
export interface RemoteSigningConfig {
    /** Static key-value pairs the signer client MUST pass through unchanged in the `properties` field of every `RemoteSignRequest` sent to the signing endpoint. */
    properties?: RemoteSigningConfigPropertiesMap;
    /** Static headers the signer client MUST include unchanged in every request to the signing endpoint. */
    headers?: MultiValuedMap;
}
export interface Action {
    action: string;
    /** Field ID of the column being projected. */
    field_id: number;
}
/** A list of columns that require specific actions to be applied when reading. A server must not return an action for a column whose type is not listed in that action's "Applicable to" set. If absent or empty, no required actions apply; columns not listed are not subject to any required action. 1. For each column listed, the reader must apply the specified action before returning values for that column. 2. The reader must replace all output references to the column with the result of the action, presenting the result under the original field-id. For example, if the action for field-id `9` is mask-alphanum, the reader must return the masked value as field-id `9` in the query output. 3. A server must not return more than one projection for the same field-id in required-column-projections. If a duplicate field-id appears, the reader must fail the query. 4. A server must not return a projection that targets a map's key field-id; a reader that receives one must fail the query. Applying an action to keys can produce duplicate or null keys, which readers silently coalesce or reject, causing data loss. 5. A reader must enforce projections on the columns it is actually reading. Projections referencing columns that are not being read do not apply. 6. A server must not return projections on both a nested-typed field (struct, list, or map) and any field-id nested within it at any depth. A reader that receives such a response must fail the query. */
export type ReadRestrictionsRequiredColumnProjectionsList = Array<Action>;
/** Deprecated. Use the bare boolean literal `true` as a predicate instead. */
export type TrueExpression = TableRequirement;
/** Deprecated. Use the bare boolean literal `false` as a predicate instead. */
export type FalseExpression = TableRequirement;
export interface AndOrPredicate {
    type: string;
    left: Predicate;
    right: Predicate;
}
export interface NotPredicate {
    type: string;
    child: Predicate;
}
export interface LiteralCase1 {
    type: string;
    value: PrimitiveTypeValue;
    data_type?: string;
}
/** A literal is either a bare value, an untyped literal object, or a typed literal object. */
export type Literal = PrimitiveTypeValue | LiteralCase1;
/** A bound reference to a field by field ID. */
export interface IdReference {
    type: string;
    id: number;
}
/** An unbound reference to a field by name. */
export interface NamedReference {
    type: string;
    name: string;
}
/** A reference to a field. Either a bound reference (by field ID) or an unbound reference (by name). The context in which an expression is used determines which form is valid. */
export type Reference = IdReference | NamedReference;
/** Reference to a catalog object (for example, table, view, or namespace) as an ordered list of hierarchical levels. The object kind is determined by context (e.g. the endpoint or a companion type discriminator), not by the identifier structure alone. */
export type CatalogObjectIdentifier = Array<string>;
export interface ApplyFunctionCase2 {
    catalog?: string;
    identifier: CatalogObjectIdentifier;
}
export type ApplyFunction = string | CatalogObjectIdentifier | ApplyFunctionCase2;
export type FunctionArgument = ValueExpression | Predicate;
export type ApplyArgumentsList = Array<FunctionArgument>;
/** A function application on zero or more value expressions or predicates. */
export interface Apply {
    type: string;
    function: ApplyFunction;
    arguments: ApplyArgumentsList;
}
/** A value expression: a literal, a field reference, or a function application. */
export type ValueExpression = Literal | Reference | Apply;
/** Deprecated. Legacy transform-applied-to-a-term form. Use Apply with a Reference argument instead. */
export interface TransformTerm {
    type: string;
    transform: string;
    term: string;
}
/** Deprecated. Legacy term form used by older REST predicates. Use Reference or Apply instead. */
export type Term = string | TransformTerm;
/** A predicate that tests a single value expression. Accepts either 'child' (preferred) or 'term' (deprecated) to identify the operand. */
export interface UnaryPredicate {
    type: string;
    child?: ValueExpression;
    /** Deprecated. Use 'child' instead. */
    term?: Term;
}
/** A predicate that compares two value expressions. Accepts either 'left'/'right' (preferred) or 'term'/'value' (deprecated). */
export interface ComparisonPredicate {
    type: string;
    left?: ValueExpression;
    right?: ValueExpression;
    /** Deprecated. Use 'left' instead. */
    term?: Term;
    /** Deprecated. Use 'right' instead. */
    value?: Literal;
}
export type LiteralsCase0List = Array<Literal>;
export type LiteralsCase1ValuesList = Array<PrimitiveTypeValue>;
export interface LiteralsCase1 {
    type: string;
    values: LiteralsCase1ValuesList;
    data_type: string;
}
/** Literals is either a bare array of literals or a typed object with an explicit data-type applied to all values. */
export type Literals = LiteralsCase0List | LiteralsCase1;
/** A predicate that tests whether a value is in a set of literals. Accepts either 'child' (preferred) or 'term' (deprecated) to identify the operand. */
export interface SetPredicate {
    type: string;
    child?: ValueExpression;
    /** Deprecated. Use 'child' instead. */
    term?: Term;
    values: Literals;
}
export type Predicate = boolean | TableRequirement | TableRequirement | AndOrPredicate | NotPredicate | UnaryPredicate | ComparisonPredicate | SetPredicate;
/** Read restrictions for a table. A reader evaluates the row filter against original, untransformed column values, then applies required-column-projections to the surviving rows. Each action must produce a value of the same type as the input column. If a reader that supports read-restrictions cannot apply any returned restriction (a filter expression or an action), it must fail the query and must not silently return raw, partial, or empty results. A missing or empty ReadRestrictions object (no required-column-projections and no required-row-filter) imposes no restrictions. */
export interface ReadRestrictions {
    /** A list of columns that require specific actions to be applied when reading. A server must not return an action for a column whose type is not listed in that action's "Applicable to" set. If absent or empty, no required actions apply; columns not listed are not subject to any required action. 1. For each column listed, the reader must apply the specified action before returning values for that column. 2. The reader must replace all output references to the column with the result of the action, presenting the result under the original field-id. For example, if the action for field-id `9` is mask-alphanum, the reader must return the masked value as field-id `9` in the query output. 3. A server must not return more than one projection for the same field-id in required-column-projections. If a duplicate field-id appears, the reader must fail the query. 4. A server must not return a projection that targets a map's key field-id; a reader that receives one must fail the query. Applying an action to keys can produce duplicate or null keys, which readers silently coalesce or reject, causing data loss. 5. A reader must enforce projections on the columns it is actually reading. Projections referencing columns that are not being read do not apply. 6. A server must not return projections on both a nested-typed field (struct, list, or map) and any field-id nested within it at any depth. A reader that receives such a response must fail the query. */
    required_column_projections?: ReadRestrictionsRequiredColumnProjectionsList;
    /** An expression that limits which rows the reader may return. 1. The expression must evaluate to a boolean (TRUE or FALSE; Iceberg predicates never produce NULL). A reader must discard any row for which the filter evaluates to FALSE, and no information derived from discarded rows may be included in the query result. 2. If this property is absent, null, or always true then no mandatory filtering is required. 3. Column references within the expression must use field IDs (IdReference), not column names. This ensures the filter remains valid across column renames, consistent with required-column-projections which also reference columns by field-id. */
    required_row_filter?: Predicate;
}
/** Flat key-value labels attached to the object (table, view, ...) as a whole. */
export type CatalogObjectLabels = {
    [key: string]: string | undefined;
};
/** Flat key-value labels for this field */
export type FieldLabelsLabelsMap = {
    [key: string]: string | undefined;
};
/** Labels attached to a single field, identified by field-id. */
export interface FieldLabels {
    /** Field ID from the schema of the table or view */
    field_id: number;
    /** Flat key-value labels for this field */
    labels: FieldLabelsLabelsMap;
}
/** Field-level labels. Each entry identifies its field by field-id. */
export type LabelsFieldsList = Array<FieldLabels>;
/** Catalog-provided metadata enrichment (for example ownership, classification, or cost attribution) returned with a table or view. Labels are catalog-provided and optional; clients may ignore them, and may cache them following the response ETag. The spec does not require how a catalog produces or stores labels, nor whether they are persisted or versioned. `object-labels` carries labels for the object as a whole; `fields` carries per-field labels, each identified by field-id. */
export interface Labels {
    object_labels?: CatalogObjectLabels;
    /** Field-level labels. Each entry identifies its field by field-id. */
    fields?: LabelsFieldsList;
}
/** Result used when a table is successfully loaded. The table metadata JSON is returned in the `metadata` field. The corresponding file location of table metadata should be returned in the `metadata-location` field, unless the metadata is not yet committed. For example, a create transaction may return metadata that is staged but not committed. Clients can check whether metadata has changed by comparing metadata locations after the table has been created. The `config` map returns table-specific configuration for the table's resources, including its HTTP client and FileIO. For example, config may contain a specific FileIO implementation class for the table depending on its underlying storage. The following configurations should be respected by clients: ## General Configurations - `token`: Authorization bearer token to use for table requests if OAuth2 security is enabled - `scan-planning-mode`: Communicates to clients the supported planning mode. Clients should use this value to fail fast if the supported scanning mode is not available on the client. Valid values: - `client`: Clients MUST use client-side scan planning - `server`: Clients MUST use server-side scan planning via the `planTableScan` endpoint ## AWS Configurations The following configurations should be respected when working with tables stored in AWS S3 - `client.region`: region to configure client for making requests to AWS - `s3.access-key-id`: id for credentials that provide access to the data in S3 - `s3.secret-access-key`: secret for credentials that provide access to data in S3 - `s3.session-token`: if present, this value should be used for as the session token - `s3.remote-signing-enabled`: if `true` remote signing should be performed as described in the `RemoteSignRequest` schema section of this spec document. - `s3.cross-region-access-enabled`: if `true`, S3 Cross-Region bucket access is enabled ## Storage Credentials Credentials for ADLS / GCS / S3 / ... are provided through the `storage-credentials` field. Clients must first check whether the respective credentials exist in the `storage-credentials` field before checking the `config` for credentials. ## Remote Signing If remote signing for a specific storage provider is enabled, the server SHOULD use the `remote-signing-config` field to communicate all signer client settings. When the `remote-signing-config` field is present, clients SHOULD respect the provided configuration. For backward compatibility, the following `config` properties are still supported but **DEPRECATED** and SHOULD NOT be used by clients able to consume the remote signing configuration: - `signer.endpoint` **DEPRECATED**.: the remote signer endpoint. Can either be a relative path (to be resolved against `signer.uri`) or an absolute URI. - `signer.uri` **DEPRECATED**.: the base URI to resolve `signer.endpoint` against. Only meaningful if `signer.endpoint` is a relative path. Defaults to the catalog's base URI if not set. If any of these properties is present, clients SHOULD use them to compute the actual remote signing endpoint URI to contact. If none of these properties is present, clients SHOULD contact the default remote signing endpoint using the catalog's base URI. */
export interface LoadTableResult {
    /** May be null if the table is staged as part of a transaction */
    metadata_location?: string | null;
    metadata: TableMetadata;
    config?: LoadTableResultConfigMap;
    storage_credentials?: LoadTableResultStorageCredentialsList;
    remote_signing_config?: RemoteSigningConfig;
    read_restrictions?: ReadRestrictions;
    labels?: Labels;
}
export type ViewVersionSummaryMap = {
    [key: string]: string | undefined;
};
export interface SQLViewRepresentation {
    type: string;
    sql: string;
    dialect: string;
}
export type ViewVersionRepresentationsList = Array<SQLViewRepresentation>;
export interface ViewVersion {
    version_id: number;
    timestamp_ms: number;
    /** Schema ID to set as current, or -1 to set last added schema */
    schema_id: number;
    summary: ViewVersionSummaryMap;
    representations: ViewVersionRepresentationsList;
    default_catalog?: string;
    default_namespace: Namespace;
}
export type CreateViewRequestPropertiesMap = {
    [key: string]: string | undefined;
};
export interface CreateViewRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    name: string;
    location?: string;
    schema: SchemaInput;
    /** The view version to create, will replace the schema-id sent within the view-version with the id assigned to the provided schema */
    view_version: ViewVersion;
    properties: CreateViewRequestPropertiesMap;
}
export type ViewMetadataVersionsList = Array<ViewVersion>;
export interface ViewHistoryEntry {
    version_id: number;
    timestamp_ms: number;
}
export type ViewMetadataVersionLogList = Array<ViewHistoryEntry>;
export type ViewMetadataSchemasList = Array<Schema>;
export type ViewMetadataPropertiesMap = {
    [key: string]: string | undefined;
};
export interface ViewMetadata {
    view_uuid: string;
    format_version: number;
    location: string;
    current_version_id: number;
    versions: ViewMetadataVersionsList;
    version_log: ViewMetadataVersionLogList;
    schemas: ViewMetadataSchemasList;
    properties?: ViewMetadataPropertiesMap;
}
export type LoadViewResultConfigMap = {
    [key: string]: string | undefined;
};
/** Result used when a view is successfully loaded. The view metadata JSON is returned in the `metadata` field. The corresponding file location of view metadata is returned in the `metadata-location` field. Clients can check whether metadata has changed by comparing metadata locations after the view has been created. The `config` map returns view-specific configuration for the view's resources. The following configurations should be respected by clients: ## General Configurations - `token`: Authorization bearer token to use for view requests if OAuth2 security is enabled */
export interface LoadViewResult {
    metadata_location: string;
    metadata: ViewMetadata;
    config?: LoadViewResultConfigMap;
    labels?: Labels;
}
export interface DropNamespaceRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
}
export interface DropNamespaceResponse {
}
export interface DropTableRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A table name */
    table: string;
    /** Whether the user requested to purge the underlying table's data and metadata */
    purgeRequested?: boolean;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
}
export interface DropTableResponse {
}
export interface DropViewRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A view name */
    view: string;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
}
export interface DropViewResponse {
}
export type FetchPlanningResultRequestXIcebergAccessDelegationItem = "vended-credentials" | "remote-signing";
export type FetchPlanningResultRequestXIcebergAccessDelegationList = Array<FetchPlanningResultRequestXIcebergAccessDelegationItem | (string & {})>;
export interface FetchPlanningResultRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A table name */
    table: string;
    /** ID used to track a planning request */
    plan_id: string;
    /** Optional signal to the server that the client supports delegated access via a comma-separated list of access mechanisms. The server may choose to supply access via any or none of the requested mechanisms. Specific properties and handling for `vended-credentials` and `remote-signing` are documented in the `LoadTableResult` schema section of this spec document. */
    xIcebergAccessDelegation?: FetchPlanningResultRequestXIcebergAccessDelegationList;
}
export type FileFormat = "avro" | "orc" | "parquet" | "puffin";
/** A list of partition field values ordered based on the fields of the partition spec specified by the `spec-id` */
export type PositionDeleteFilePartitionList = Array<PrimitiveTypeValue>;
/** List of splittable offsets */
export type PositionDeleteFileSplitOffsetsList = Array<number>;
export interface FieldStatistics {
    /** Avg value size in memory (uncompressed) in bytes over non-null values to estimate memory consumption */
    avg_value_size_in_bytes?: number;
}
/** Container struct for per-field metrics structs */
export type PositionDeleteFileContentStatsMap = {
    [key: string]: FieldStatistics | undefined;
};
export interface PositionDeleteFile {
    content: string;
    file_path: string;
    file_format: FileFormat;
    spec_id: number;
    /** A list of partition field values ordered based on the fields of the partition spec specified by the `spec-id` */
    partition: PositionDeleteFilePartitionList;
    /** Total file size in bytes */
    file_size_in_bytes: number;
    /** Number of records in the file */
    record_count: number;
    /** Encryption key metadata blob */
    key_metadata?: string;
    /** List of splittable offsets */
    split_offsets?: PositionDeleteFileSplitOffsetsList;
    sort_order_id?: number;
    /** Container struct for per-field metrics structs */
    content_stats?: PositionDeleteFileContentStatsMap;
    /** Offset within the delete file of delete content */
    content_offset?: number;
    /** Length, in bytes, of the delete content; required if content-offset is present */
    content_size_in_bytes?: number;
}
/** A list of partition field values ordered based on the fields of the partition spec specified by the `spec-id` */
export type EqualityDeleteFilePartitionList = Array<PrimitiveTypeValue>;
/** List of splittable offsets */
export type EqualityDeleteFileSplitOffsetsList = Array<number>;
/** Container struct for per-field metrics structs */
export type EqualityDeleteFileContentStatsMap = {
    [key: string]: FieldStatistics | undefined;
};
/** List of equality field IDs */
export type EqualityDeleteFileEqualityIdsList = Array<number>;
export interface EqualityDeleteFile {
    content: string;
    file_path: string;
    file_format: FileFormat;
    spec_id: number;
    /** A list of partition field values ordered based on the fields of the partition spec specified by the `spec-id` */
    partition: EqualityDeleteFilePartitionList;
    /** Total file size in bytes */
    file_size_in_bytes: number;
    /** Number of records in the file */
    record_count: number;
    /** Encryption key metadata blob */
    key_metadata?: string;
    /** List of splittable offsets */
    split_offsets?: EqualityDeleteFileSplitOffsetsList;
    sort_order_id?: number;
    /** Container struct for per-field metrics structs */
    content_stats?: EqualityDeleteFileContentStatsMap;
    /** List of equality field IDs */
    equality_ids?: EqualityDeleteFileEqualityIdsList;
}
export type DeleteFile = PositionDeleteFile | EqualityDeleteFile;
/** Delete files referenced by file scan tasks */
export type CompletedPlanningResultDeleteFilesList = Array<DeleteFile>;
/** A list of partition field values ordered based on the fields of the partition spec specified by the `spec-id` */
export type DataFilePartitionList = Array<PrimitiveTypeValue>;
/** List of splittable offsets */
export type DataFileSplitOffsetsList = Array<number>;
/** Container struct for per-field metrics structs */
export type DataFileContentStatsMap = {
    [key: string]: FieldStatistics | undefined;
};
/** List of integer column ids for each corresponding value */
export type CountMapKeysList = Array<number>;
/** List of Long values, matched to 'keys' by index */
export type CountMapValuesList = Array<number>;
export interface CountMap {
    /** List of integer column ids for each corresponding value */
    keys?: CountMapKeysList;
    /** List of Long values, matched to 'keys' by index */
    values?: CountMapValuesList;
}
/** List of integer column ids for each corresponding value */
export type ValueMapKeysList = Array<number>;
/** List of primitive type values, matched to 'keys' by index */
export type ValueMapValuesList = Array<PrimitiveTypeValue>;
export interface ValueMap {
    /** List of integer column ids for each corresponding value */
    keys?: ValueMapKeysList;
    /** List of primitive type values, matched to 'keys' by index */
    values?: ValueMapValuesList;
}
export interface DataFile {
    content: string;
    file_path: string;
    file_format: FileFormat;
    spec_id: number;
    /** A list of partition field values ordered based on the fields of the partition spec specified by the `spec-id` */
    partition: DataFilePartitionList;
    /** Total file size in bytes */
    file_size_in_bytes: number;
    /** Number of records in the file */
    record_count: number;
    /** Encryption key metadata blob */
    key_metadata?: string;
    /** List of splittable offsets */
    split_offsets?: DataFileSplitOffsetsList;
    sort_order_id?: number;
    /** Container struct for per-field metrics structs */
    content_stats?: DataFileContentStatsMap;
    /** The first row ID assigned to the first row in the data file */
    first_row_id?: number;
    /** Map of column id to total count, including null and NaN */
    column_sizes?: CountMap;
    /** Map of column id to null value count */
    value_counts?: CountMap;
    /** Map of column id to null value count */
    null_value_counts?: CountMap;
    /** Map of column id to number of NaN values in the column */
    nan_value_counts?: CountMap;
    /** Map of column id to lower bound primitive type values */
    lower_bounds?: ValueMap;
    /** Map of column id to upper bound primitive type values */
    upper_bounds?: ValueMap;
}
/** A list of indices in the delete files array (0-based) */
export type FileScanTaskDeleteFileReferencesList = Array<number>;
export interface FileScanTask {
    data_file: DataFile;
    /** A list of indices in the delete files array (0-based) */
    delete_file_references?: FileScanTaskDeleteFileReferencesList;
    /** An optional filter to be applied to rows in this file scan task. If the residual is not present, the client must produce the residual or use the original filter. */
    residual_filter?: Predicate;
}
export type CompletedPlanningResultFileScanTasksList = Array<FileScanTask>;
export type CompletedPlanningResultPlanTasksList = Array<string>;
/** Status of a server-side planning operation */
export type PlanStatus = "completed" | "submitted" | "cancelled" | "failed";
/** Storage credentials for accessing the files returned in the scan result. If the server returns storage credentials as part of the completed scan planning response, the expectation is for the client to use these credentials to read the files returned in the FileScanTasks as part of the scan result. */
export type CompletedPlanningResultStorageCredentialsList = Array<StorageCredential>;
/** Completed server-side planning result */
export interface CompletedPlanningResult {
    /** Delete files referenced by file scan tasks */
    delete_files?: CompletedPlanningResultDeleteFilesList;
    file_scan_tasks?: CompletedPlanningResultFileScanTasksList;
    plan_tasks?: CompletedPlanningResultPlanTasksList;
    status: PlanStatus;
    /** Storage credentials for accessing the files returned in the scan result. If the server returns storage credentials as part of the completed scan planning response, the expectation is for the client to use these credentials to read the files returned in the FileScanTasks as part of the scan result. */
    storage_credentials?: CompletedPlanningResultStorageCredentialsList;
}
export type ErrorModelStackList = Array<string>;
/** JSON error payload returned in a response with further details on the error */
export interface ErrorModel {
    /** Human-readable error message */
    message: string;
    /** Internal type definition of the error */
    type: string;
    /** HTTP response code */
    code: number;
    stack?: ErrorModelStackList;
}
/** Failed server-side planning result */
export interface FailedPlanningResult {
    error: ErrorModel;
    status: PlanStatus;
}
/** Empty server-side planning result */
export interface EmptyPlanningResult {
    status: PlanStatus;
}
/** Result of server-side scan planning for fetchPlanningResult */
export type PlanningResult = CompletedPlanningResult | FailedPlanningResult | EmptyPlanningResult;
export type FetchPlanningResultResponse = PlanningResult;
export interface FetchScanTasksRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A table name */
    table: string;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
    plan_task: string;
}
/** Delete files referenced by file scan tasks */
export type FetchScanTasksResponseDeleteFilesList = Array<DeleteFile>;
export type FetchScanTasksResponseFileScanTasksList = Array<FileScanTask>;
export type FetchScanTasksResponsePlanTasksList = Array<string>;
export interface FetchScanTasksResponse {
    /** Delete files referenced by file scan tasks */
    delete_files?: FetchScanTasksResponseDeleteFilesList;
    file_scan_tasks?: FetchScanTasksResponseFileScanTasksList;
    plan_tasks?: FetchScanTasksResponsePlanTasksList;
}
export interface GetConfigRequest {
    /** Warehouse location or identifier to request from the service */
    warehouse?: string;
}
/** Properties that should be used to override client configuration; applied after defaults and client configuration. */
export type CatalogConfigOverridesMap = {
    [key: string]: string | undefined;
};
/** Properties that should be used as default configuration; applied before client configuration. */
export type CatalogConfigDefaultsMap = {
    [key: string]: string | undefined;
};
/** A list of endpoints that the server supports. The format of each endpoint must be "<HTTP verb> <resource path from OpenAPI REST spec>". The HTTP verb and the resource path must be separated by a space character. */
export type CatalogConfigEndpointsList = Array<string>;
/** Server-provided configuration for the catalog. */
export interface CatalogConfig {
    /** Properties that should be used to override client configuration; applied after defaults and client configuration. */
    overrides: CatalogConfigOverridesMap;
    /** Properties that should be used as default configuration; applied before client configuration. */
    defaults: CatalogConfigDefaultsMap;
    /** A list of endpoints that the server supports. The format of each endpoint must be "<HTTP verb> <resource path from OpenAPI REST spec>". The HTTP verb and the resource path must be separated by a space character. */
    endpoints?: CatalogConfigEndpointsList;
    /** Client reuse window for an Idempotency-Key (ISO-8601 duration, e.g., PT30M, PT24H). Interpreted as the maximum time from the first submission using a key to the last retry during which a client may reuse that key. Servers SHOULD accept retries for at least this duration and MAY include a grace period to account for delays/clock skew. Clients SHOULD NOT reuse an Idempotency-Key after this window elapses; they SHOULD generate a new key for any subsequent attempt. Presence of this field indicates the server supports Idempotency-Key semantics for mutation endpoints. If absent, clients MUST assume idempotency is not supported. */
    idempotency_key_lifetime?: string;
}
export interface ListFunctionsRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    pageToken?: string;
    /** For servers that support pagination, this signals an upper bound of the number of results that a client will receive. For servers that do not support pagination, clients may receive results larger than the indicated `pageSize`. */
    pageSize?: number;
}
export type ListFunctionsResponseIdentifiersList = Array<CatalogObjectIdentifier>;
export interface ListFunctionsResponse {
    next_page_token?: string | null;
    identifiers: ListFunctionsResponseIdentifiersList;
}
export interface ListNamespacesRequest {
    pageToken?: string;
    /** For servers that support pagination, this signals an upper bound of the number of results that a client will receive. For servers that do not support pagination, clients may receive results larger than the indicated `pageSize`. */
    pageSize?: number;
    /** An optional namespace, underneath which to list namespaces. If not provided, all top-level namespaces should be listed. For backward compatibility, empty string is treated as absent for now. If parent is a multipart namespace, the parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    parent?: string;
}
export type ListNamespacesResponseNamespacesList = Array<Namespace>;
export interface ListNamespacesResponse {
    next_page_token?: string | null;
    namespaces: ListNamespacesResponseNamespacesList;
}
export interface ListTablesRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    pageToken?: string;
    /** For servers that support pagination, this signals an upper bound of the number of results that a client will receive. For servers that do not support pagination, clients may receive results larger than the indicated `pageSize`. */
    pageSize?: number;
}
export type ListTablesResponseIdentifiersList = Array<TableIdentifier>;
export interface ListTablesResponse {
    next_page_token?: string | null;
    identifiers: ListTablesResponseIdentifiersList;
}
export interface ListViewsRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    pageToken?: string;
    /** For servers that support pagination, this signals an upper bound of the number of results that a client will receive. For servers that do not support pagination, clients may receive results larger than the indicated `pageSize`. */
    pageSize?: number;
}
export interface LoadCredentialsRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A table name */
    table: string;
    /** The plan ID that has been used for server-side scan planning */
    planId?: string;
    /** A comma-separated list of fully qualified view names (namespace and view name) representing the view reference chain when an entity (table or view) is loaded via a view. The list should be ordered with the outermost view first, followed by any intermediate views it references, down to the view that directly references the entity. For a simple case where a view directly references the entity, the list contains a single view identifier. For nested views (a view referencing another view which references the entity), the list contains multiple view identifiers representing the complete dependency chain. The view identifier is a composite string of the format {namespace}{separator}{viewName}. The namespace-separator (defined in /config) acts as the delimiter. When parsing, the last occurrence of this separator identifies the boundary between the namespace and the view name. Multipart namespaces must follow the encoding rules of the parent parameter in the list namespaces endpoint. Multiple view identifiers are separated by commas. Servers should split the parameter value on comma characters to parse individual view identifiers. If view names contain commas, they must be url-encoded as %2C. Example with multiple views (where prod%1Fanalytics is a nested namespace which has a quarterly_view which references to monthly_view which then references the entity being loaded) - prod%1Fanalytics%1Fquarterly_view,prod%1Fanalytics%1Fmonthly_view */
    referenced_by?: string;
}
export type LoadCredentialsResponseStorageCredentialsList = Array<StorageCredential>;
export interface LoadCredentialsResponse {
    storage_credentials: LoadCredentialsResponseStorageCredentialsList;
}
export interface LoadFunctionRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A function name */
    function: string;
}
/** UDF list type object. */
export interface FunctionListType {
    type: string;
    element: FunctionDataType;
}
/** UDF map type object. */
export interface FunctionMapType {
    type: string;
    key: FunctionDataType;
    value: FunctionDataType;
}
/** UDF struct field. */
export interface FunctionStructField {
    name: string;
    type: FunctionDataType;
}
export type FunctionStructTypeFieldsList = Array<FunctionStructField>;
/** UDF struct type object. */
export interface FunctionStructType {
    type: string;
    fields: FunctionStructTypeFieldsList;
}
/** A type for function parameters or return value. It is encoded either as a type string or as a JSON object for nested types (struct, list, map) following the UDF spec Types section. Primitive and semi-structured type strings are encoded based on the Iceberg type JSON representation (e.g., "int", "string", "timestamp", "decimal(9,2)", "variant"). Type strings must contain no spaces or quote characters. Nested types are based on the Iceberg type JSON representation, but the UDF spec only requires a subset of fields (e.g., list requires `type` and `element`; map requires `type`, `key`, and `value`; struct requires `type` and `fields`). Any other fields must be ignored. */
export type FunctionDataType = string | FunctionListType | FunctionMapType | FunctionStructType;
export interface FunctionParameter {
    type: FunctionDataType;
    name: string;
    /** Parameter documentation. */
    doc?: string;
}
/** Ordered list of function parameters. Invocation order must match this list. */
export type FunctionDefinitionParametersList = Array<FunctionParameter>;
export interface FunctionSQLRepresentation {
    type: string;
    /** SQL dialect identifier (e.g., "spark", "trino"). */
    dialect: string;
    /** SQL expression text. */
    sql: string;
}
/** UDF implementations. */
export type FunctionDefinitionVersionRepresentationsList = Array<FunctionSQLRepresentation>;
/** Defines how the UDF behaves when any input parameter is NULL. */
export type FunctionDefinitionVersionOnNullInput = "return-null" | "call";
export interface FunctionDefinitionVersion {
    /** Monotonically increasing identifier of the definition version. */
    version_id: number;
    /** UDF implementations. */
    representations: FunctionDefinitionVersionRepresentationsList;
    /** Whether the function is deterministic. */
    deterministic?: boolean;
    /** Defines how the UDF behaves when any input parameter is NULL. */
    on_null_input?: FunctionDefinitionVersionOnNullInput;
    /** Creation timestamp of this version (unix epoch millis). */
    timestamp_ms: number;
}
/** Versioned implementations of this definition. */
export type FunctionDefinitionVersionsList = Array<FunctionDefinitionVersion>;
/** Function type. When set to "udtf", "return-type" must be a struct describing the output schema. */
export type FunctionDefinitionFunctionType = "udf" | "udtf";
export interface FunctionDefinition {
    /** A canonical string derived from the parameter types, formatted as a comma-separated list with no spaces. */
    definition_id: string;
    /** A user-assignable name for this definition that must be unique among all definitions within the UDF metadata. */
    specific_name?: string;
    /** Ordered list of function parameters. Invocation order must match this list. */
    parameters: FunctionDefinitionParametersList;
    return_type: FunctionDataType;
    /** A hint to indicate whether the return value is nullable or not. */
    return_nullable?: boolean;
    /** Versioned implementations of this definition. */
    versions: FunctionDefinitionVersionsList;
    /** Identifier of the current version for this definition. */
    current_version_id: number;
    /** Function type. When set to "udtf", "return-type" must be a struct describing the output schema. */
    function_type: FunctionDefinitionFunctionType;
    /** Documentation string. */
    doc?: string;
}
/** List of function definition entities. */
export type FunctionMetadataDefinitionsList = Array<FunctionDefinition>;
export interface FunctionDefinitionVersionRef {
    definition_id: string;
    version_id: number;
}
/** Mapping of each definition to its selected version at this time. */
export type FunctionDefinitionLogEntryDefinitionVersionsList = Array<FunctionDefinitionVersionRef>;
export interface FunctionDefinitionLogEntry {
    /** Timestamp when the function was updated to use the definition versions. */
    timestamp_ms: number;
    /** Mapping of each definition to its selected version at this time. */
    definition_versions: FunctionDefinitionLogEntryDefinitionVersionsList;
}
/** History of versions within the function's definitions. */
export type FunctionMetadataDefinitionLogList = Array<FunctionDefinitionLogEntry>;
/** A string-to-string map of properties. */
export type FunctionMetadataPropertiesMap = {
    [key: string]: string | undefined;
};
/** Portable UDF metadata format. Each function is represented by a self-contained metadata file. The `format-version` field identifies the UDF metadata format. */
export interface FunctionMetadata {
    /** A UUID that identifies this UDF, generated once at creation. */
    function_uuid: string;
    /** UDF specification format version (must be 1). */
    format_version: number;
    /** List of function definition entities. */
    definitions: FunctionMetadataDefinitionsList;
    /** History of versions within the function's definitions. */
    definition_log: FunctionMetadataDefinitionLogList;
    /** The function's base location. This is used to store function metadata files. */
    location?: string;
    /** A string-to-string map of properties. */
    properties?: FunctionMetadataPropertiesMap;
    /** Whether it is a secure function. */
    secure?: boolean;
    /** Documentation string. */
    doc?: string;
}
/** Result returned when a function is loaded from the catalog. The function metadata JSON is returned in the `metadata` field. The location of the metadata file is returned in the `metadata-location` field, if available. */
export interface LoadFunctionResult {
    metadata_location?: string;
    metadata: FunctionMetadata;
}
export interface LoadNamespaceMetadataRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
}
/** Properties stored on the namespace, if supported by the server. If the server does not support namespace properties, it should return null for this field. If namespace properties are supported, but none are set, it should return an empty object. */
export type GetNamespaceResponsePropertiesMap = {
    [key: string]: string | undefined;
};
export interface GetNamespaceResponse {
    namespace: Namespace;
    /** Properties stored on the namespace, if supported by the server. If the server does not support namespace properties, it should return null for this field. If namespace properties are supported, but none are set, it should return an empty object. */
    properties?: GetNamespaceResponsePropertiesMap | null;
}
export type LoadTableRequestSnapshots = "all" | "refs";
export type LoadTableRequestXIcebergAccessDelegationItem = "vended-credentials" | "remote-signing";
export type LoadTableRequestXIcebergAccessDelegationList = Array<LoadTableRequestXIcebergAccessDelegationItem | (string & {})>;
export interface LoadTableRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A table name */
    table: string;
    /** The snapshots to return in the body of the metadata via the `snapshots` field. Setting the value to `all` would return the full set of snapshots currently valid for the table. Setting the value to `refs` would load all snapshots referenced by branches or tags. Default if no param is provided is `all`. */
    snapshots?: LoadTableRequestSnapshots | (string & {});
    /** A comma-separated list of fully qualified view names (namespace and view name) representing the view reference chain when an entity (table or view) is loaded via a view. The list should be ordered with the outermost view first, followed by any intermediate views it references, down to the view that directly references the entity. For a simple case where a view directly references the entity, the list contains a single view identifier. For nested views (a view referencing another view which references the entity), the list contains multiple view identifiers representing the complete dependency chain. The view identifier is a composite string of the format {namespace}{separator}{viewName}. The namespace-separator (defined in /config) acts as the delimiter. When parsing, the last occurrence of this separator identifies the boundary between the namespace and the view name. Multipart namespaces must follow the encoding rules of the parent parameter in the list namespaces endpoint. Multiple view identifiers are separated by commas. Servers should split the parameter value on comma characters to parse individual view identifiers. If view names contain commas, they must be url-encoded as %2C. Example with multiple views (where prod%1Fanalytics is a nested namespace which has a quarterly_view which references to monthly_view which then references the entity being loaded) - prod%1Fanalytics%1Fquarterly_view,prod%1Fanalytics%1Fmonthly_view */
    referenced_by?: string;
    /** Optional signal to the server that the client supports delegated access via a comma-separated list of access mechanisms. The server may choose to supply access via any or none of the requested mechanisms. Specific properties and handling for `vended-credentials` and `remote-signing` are documented in the `LoadTableResult` schema section of this spec document. */
    xIcebergAccessDelegation?: LoadTableRequestXIcebergAccessDelegationList;
    /** An optional header that allows the server to return 304 (Not Modified) if the metadata is current. The content is the value of the ETag received in a CreateTableResponse, LoadTableResponse or CommitTableResponse. */
    ifNoneMatch?: string;
}
export interface LoadViewRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A view name */
    view: string;
    /** A comma-separated list of fully qualified view names (namespace and view name) representing the view reference chain when an entity (table or view) is loaded via a view. The list should be ordered with the outermost view first, followed by any intermediate views it references, down to the view that directly references the entity. For a simple case where a view directly references the entity, the list contains a single view identifier. For nested views (a view referencing another view which references the entity), the list contains multiple view identifiers representing the complete dependency chain. The view identifier is a composite string of the format {namespace}{separator}{viewName}. The namespace-separator (defined in /config) acts as the delimiter. When parsing, the last occurrence of this separator identifies the boundary between the namespace and the view name. Multipart namespaces must follow the encoding rules of the parent parameter in the list namespaces endpoint. Multiple view identifiers are separated by commas. Servers should split the parameter value on comma characters to parse individual view identifiers. If view names contain commas, they must be url-encoded as %2C. Example with multiple views (where prod%1Fanalytics is a nested namespace which has a quarterly_view which references to monthly_view which then references the entity being loaded) - prod%1Fanalytics%1Fquarterly_view,prod%1Fanalytics%1Fmonthly_view */
    referenced_by?: string;
}
export interface NamespaceExistsRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
}
export interface NamespaceExistsResponse {
}
export type PlanTableScanRequestXIcebergAccessDelegationItem = "vended-credentials" | "remote-signing";
export type PlanTableScanRequestXIcebergAccessDelegationList = Array<PlanTableScanRequestXIcebergAccessDelegationItem | (string & {})>;
/** List of selected schema fields */
export type PlanTableScanRequestSelectList = Array<string>;
/** List of fields for which the service should send column stats. */
export type PlanTableScanRequestStatsFieldsList = Array<string>;
export interface PlanTableScanRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A table name */
    table: string;
    /** Optional signal to the server that the client supports delegated access via a comma-separated list of access mechanisms. The server may choose to supply access via any or none of the requested mechanisms. Specific properties and handling for `vended-credentials` and `remote-signing` are documented in the `LoadTableResult` schema section of this spec document. */
    xIcebergAccessDelegation?: PlanTableScanRequestXIcebergAccessDelegationList;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
    /** Identifier for the snapshot to scan in a point-in-time scan */
    snapshot_id?: number;
    /** List of selected schema fields */
    select?: PlanTableScanRequestSelectList;
    /** Predicate used to filter the table data */
    filter?: Predicate;
    /** The minimum number of rows requested for the scan. This is used as a hint to the server to not have to return more rows than necessary. It is not required for the server to return that many rows since the scan may not produce that many rows. The server can also return more rows than requested. */
    min_rows_requested?: number;
    /** Enables case sensitive field matching for filter and select */
    case_sensitive?: boolean;
    /** Whether to use the schema at the time the snapshot was written. When time travelling, the snapshot schema should be used (true). When scanning a branch, the table schema should be used (false). */
    use_snapshot_schema?: boolean;
    /** Starting snapshot ID for an incremental scan (exclusive) */
    start_snapshot_id?: number;
    /** Ending snapshot ID for an incremental scan (inclusive). Required when start-snapshot-id is specified. */
    end_snapshot_id?: number;
    /** List of fields for which the service should send column stats. */
    stats_fields?: PlanTableScanRequestStatsFieldsList;
}
/** Delete files referenced by file scan tasks */
export type CompletedPlanningWithIDResultDeleteFilesList = Array<DeleteFile>;
export type CompletedPlanningWithIDResultFileScanTasksList = Array<FileScanTask>;
export type CompletedPlanningWithIDResultPlanTasksList = Array<string>;
/** Storage credentials for accessing the files returned in the scan result. If the server returns storage credentials as part of the completed scan planning response, the expectation is for the client to use these credentials to read the files returned in the FileScanTasks as part of the scan result. */
export type CompletedPlanningWithIDResultStorageCredentialsList = Array<StorageCredential>;
export interface CompletedPlanningWithIDResult {
    /** Delete files referenced by file scan tasks */
    delete_files?: CompletedPlanningWithIDResultDeleteFilesList;
    file_scan_tasks?: CompletedPlanningWithIDResultFileScanTasksList;
    plan_tasks?: CompletedPlanningWithIDResultPlanTasksList;
    status: PlanStatus;
    /** Storage credentials for accessing the files returned in the scan result. If the server returns storage credentials as part of the completed scan planning response, the expectation is for the client to use these credentials to read the files returned in the FileScanTasks as part of the scan result. */
    storage_credentials?: CompletedPlanningWithIDResultStorageCredentialsList;
    /** ID used to track a planning request */
    plan_id: string;
}
export interface AsyncPlanningResult {
    status: PlanStatus;
    /** ID used to track a planning request */
    plan_id: string;
}
/** Result of server-side scan planning for planTableScan */
export type PlanTableScanResult = CompletedPlanningWithIDResult | FailedPlanningResult | AsyncPlanningResult | EmptyPlanningResult;
export type PlanTableScanResponse = PlanTableScanResult;
export type RegisterTableRequestXIcebergAccessDelegationItem = "vended-credentials" | "remote-signing";
export type RegisterTableRequestXIcebergAccessDelegationList = Array<RegisterTableRequestXIcebergAccessDelegationItem | (string & {})>;
export interface RegisterTableRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** Optional signal to the server that the client supports delegated access via a comma-separated list of access mechanisms. The server may choose to supply access via any or none of the requested mechanisms. Specific properties and handling for `vended-credentials` and `remote-signing` are documented in the `LoadTableResult` schema section of this spec document. */
    xIcebergAccessDelegation?: RegisterTableRequestXIcebergAccessDelegationList;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
    name: string;
    metadata_location: string;
    /** Whether to overwrite table metadata if the table already exists */
    overwrite?: boolean;
}
export interface RegisterViewRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
    name: string;
    metadata_location: string;
}
export interface RenameTableRequest {
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
    source: TableIdentifier;
    destination: TableIdentifier;
}
export interface RenameTableResponse {
}
export interface RenameViewRequest {
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
    source: TableIdentifier;
    destination: TableIdentifier;
}
export interface RenameViewResponse {
}
/** The view UUID must match the requirement's `uuid` */
export interface AssertViewUUID {
    type: string;
    uuid: string;
}
export type ReplaceViewRequestRequirementsList = Array<AssertViewUUID>;
export interface AddViewVersionUpdate {
    action: string;
    view_version: ViewVersion;
}
export interface SetCurrentViewVersionUpdate {
    action: string;
    /** The view version id to set as current, or -1 to set last added view version id */
    view_version_id: number;
}
export type ViewUpdateInput = AssignUUIDUpdate | UpgradeFormatVersionUpdate | AddSchemaUpdateInput | SetLocationUpdate | SetPropertiesUpdate | RemovePropertiesUpdate | AddViewVersionUpdate | SetCurrentViewVersionUpdate;
export type ReplaceViewRequestUpdatesList = Array<ViewUpdateInput>;
export interface ReplaceViewRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A view name */
    view: string;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
    /** View identifier to update */
    identifier?: TableIdentifier;
    requirements?: ReplaceViewRequestRequirementsList;
    updates: ReplaceViewRequestUpdatesList;
}
export interface ReportMetricsRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A table name */
    table: string;
    report_type: string;
}
export interface ReportMetricsResponse {
}
export type SignRequestRequestMethod = "PUT" | "GET" | "HEAD" | "POST" | "DELETE" | "PATCH" | "OPTIONS";
export type SignRequestRequestPropertiesMap = {
    [key: string]: string | undefined;
};
export interface SignRequestRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A table name */
    table: string;
    region: string;
    uri: string;
    method: SignRequestRequestMethod | (string & {});
    headers: MultiValuedMap;
    properties?: SignRequestRequestPropertiesMap;
    /** Optional body of the request to send to the signing API. This should only be populated for requests where the body of the message contains content which must be validated before a request is signed, such as the S3 DeleteObjects call. */
    body?: string;
    /** The storage provider for which the request is to be signed. The provider should correspond to the scheme used for a storage native URI. For example `s3` for AWS S3 paths. For backwards compatibility, if this is not specified, the provider is assumed to be `s3`. */
    provider?: string;
}
/** The result of a remote request signing operation. */
export interface RemoteSignResult {
    uri: string;
    headers: MultiValuedMap;
}
export interface TableExistsRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A table name */
    table: string;
}
export interface TableExistsResponse {
}
export interface UnregisterTableRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A table name */
    table: string;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
}
/** Last metadata location and the corresponding table metadata for the table that was successfully unregistered and is no longer tracked by the catalog. */
export interface UnregisterTableResult {
    /** The last metadata location for the table at the time it was unregistered. */
    metadata_location: string;
    metadata: TableMetadata;
}
export type UpdatePropertiesRequestRemovalsList = Array<string>;
export type UpdatePropertiesRequestUpdatesMap = {
    [key: string]: string | undefined;
};
export interface UpdatePropertiesRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
    removals?: UpdatePropertiesRequestRemovalsList;
    updates?: UpdatePropertiesRequestUpdatesMap;
}
/** List of property keys that were added or updated */
export type UpdateNamespacePropertiesResponseUpdatedList = Array<string>;
/** List of properties that were removed */
export type UpdateNamespacePropertiesResponseRemovedList = Array<string>;
/** List of properties requested for removal that were not found in the namespace's properties. Represents a partial success response. Server's do not need to implement this. */
export type UpdateNamespacePropertiesResponseMissingList = Array<string>;
export interface UpdateNamespacePropertiesResponse {
    /** List of property keys that were added or updated */
    updated: UpdateNamespacePropertiesResponseUpdatedList;
    /** List of properties that were removed */
    removed: UpdateNamespacePropertiesResponseRemovedList;
    /** List of properties requested for removal that were not found in the namespace's properties. Represents a partial success response. Server's do not need to implement this. */
    missing?: UpdateNamespacePropertiesResponseMissingList | null;
}
export type UpdateTableRequestRequirementsList = Array<TableRequirement>;
export type UpdateTableRequestUpdatesList = Array<TableUpdateInput>;
export interface UpdateTableRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A table name */
    table: string;
    /** Optional client-provided idempotency key for safe request retries. When present, the server ensures no additional effects for requests that carry the same Idempotency-Key. If a prior request with this key has been finalized, the server returns an equivalent final response without re-running the operation. The response body may reflect a newer state of the catalog than existed at the time of the commit. Finalization rules: - Finalize & replay: 200, 201, 204, and deterministic terminal 4xx (including 409 such as AlreadyExists, NamespaceNotEmpty, etc.) - Do not finalize (not stored/replayed): 5xx Key Requirements: - Key format: UUIDv7 in string form (RFC 9562). - The idempotency key must be globally unique (no reuse across different operations). - Catalogs SHOULD NOT expire keys before the end of the advertised token lifetime. - If Idempotency-Key is used, clients MUST reuse the same key when retrying the same logical operation and MUST generate a new key for a different operation. */
    idempotencyKey?: string;
    /** Table identifier to update; must be present for CommitTransactionRequest */
    identifier?: TableIdentifier;
    requirements: UpdateTableRequestRequirementsList;
    updates: UpdateTableRequestUpdatesList;
}
export interface CommitTableResponse {
    metadata_location: string;
    metadata: TableMetadata;
}
export interface ViewExistsRequest {
    /** A namespace identifier as a single string. Multipart namespace parts must be separated by the namespace separator as indicated via the /config override `namespace-separator`, which defaults to the unit separator `0x1F` byte (url encoded `%1F`). To be compatible with older clients, servers must use both the advertised separator and `0x1F` as valid separators when decoding namespaces. The `namespace-separator` should be provided in a url encoded form. */
    namespace: string;
    /** A view name */
    view: string;
}
export interface ViewExistsResponse {
}
export type CancelPlanningError = NoSuchNamespaceException | NoSuchPlanIdException | NoSuchTableException | IcebergOpError;
/** Cancels scan planning for a plan-id Cancels scan planning for a plan-id. This notifies the service that it can release resources held for the scan. Clients should cancel scans that are no longer needed, either while the plan-id returns a "submitted" status or while there are remaining plan tasks that have not been fetched. Cancellation is not necessary when - Scan tasks for each plan task have been fetched using fetchScanTasks - A plan-id has produced a "failed" or "cancelled" status from planTableScan or fetchPlanningResult */
export declare const cancelPlanning: API.OperationMethod<CancelPlanningRequest, CancelPlanningResponse, CancelPlanningError, IcebergOpContext>;
export type CommitTransactionError = CommitFailedException | CommitStateUnknownException | NoSuchTableException | IcebergOpError;
/** Commit updates to multiple tables in an atomic operation */
export declare const commitTransaction: API.OperationMethod<CommitTransactionRequest, CommitTransactionResponse, CommitTransactionError, IcebergOpContext>;
export type CreateNamespaceError = AlreadyExistsException | UnsupportedOperationException | IcebergOpError;
/** Create a namespace Create a namespace, with an optional set of properties. The server might also add properties, such as `last_modified_time` etc. */
export declare const createNamespace: API.OperationMethod<CreateNamespaceRequest, CreateNamespaceResponse, CreateNamespaceError, IcebergOpContext>;
export type CreateTableError = AlreadyExistsException | NoSuchNamespaceException | IcebergOpError;
/** Create a table in the given namespace Create a table or start a create transaction, like atomic CTAS. If `stage-create` is false, the table is created immediately. If `stage-create` is true, the table is not created, but table metadata is initialized and returned. The service should prepare as needed for a commit to the table commit endpoint to complete the create transaction. The client uses the returned metadata to begin a transaction. To commit the transaction, the client sends all create and subsequent changes to the table commit route. Changes from the table create operation include changes like AddSchemaUpdate and SetCurrentSchemaUpdate that set the initial table state. */
export declare const createTable: API.OperationMethod<CreateTableRequest, LoadTableResult, CreateTableError, IcebergOpContext>;
export type CreateViewError = AlreadyExistsException | NoSuchNamespaceException | IcebergOpError;
/** Create a view in the given namespace Create a view in the given namespace. */
export declare const createView: API.OperationMethod<CreateViewRequest, LoadViewResult, CreateViewError, IcebergOpContext>;
export type DropNamespaceError = NamespaceNotEmptyException | NoSuchNamespaceException | IcebergOpError;
/** Drop a namespace from the catalog. Namespace must be empty. */
export declare const dropNamespace: API.OperationMethod<DropNamespaceRequest, DropNamespaceResponse, DropNamespaceError, IcebergOpContext>;
export type DropTableError = NoSuchTableException | IcebergOpError;
/** Drop a table from the catalog Remove a table from the catalog */
export declare const dropTable: API.OperationMethod<DropTableRequest, DropTableResponse, DropTableError, IcebergOpContext>;
export type DropViewError = NoSuchViewException | IcebergOpError;
/** Drop a view from the catalog Remove a view from the catalog */
export declare const dropView: API.OperationMethod<DropViewRequest, DropViewResponse, DropViewError, IcebergOpContext>;
export type FetchPlanningResultError = NoSuchNamespaceException | NoSuchPlanIdException | NoSuchTableException | IcebergOpError;
/** Fetches the result of scan planning for a plan-id Fetches the result of scan planning for a plan-id. Responses must include a valid status - When "completed" the planning operation has produced plan-tasks and file-scan-tasks that must be returned in the response - When "submitted" the planning operation has not completed; the client should wait to call this endpoint again to fetch a completed response - When "failed" the response must be a valid error response - When "cancelled" the plan-id is invalid and should be discarded The response for a "completed" planning operation includes two types of tasks (file scan tasks and plan tasks) and both may be included in the response. Tasks must not be included for any other response status. */
export declare const fetchPlanningResult: API.OperationMethod<FetchPlanningResultRequest, FetchPlanningResultResponse, FetchPlanningResultError, IcebergOpContext>;
export type FetchScanTasksError = NoSuchNamespaceException | NoSuchPlanTaskException | NoSuchTableException | IcebergOpError;
/** Fetches result tasks for a plan task Fetches result tasks for a plan task. */
export declare const fetchScanTasks: API.OperationMethod<FetchScanTasksRequest, FetchScanTasksResponse, FetchScanTasksError, IcebergOpContext>;
export type GetConfigError = NoSuchWarehouseException | IcebergOpError;
/** List all catalog configuration settings All REST clients should first call this route to get catalog configuration properties from the server to configure the catalog and its HTTP client. Configuration from the server consists of two sets of key/value pairs. - defaults - properties that should be used as default configuration; applied before client configuration - overrides - properties that should be used to override client configuration; applied after defaults and client configuration Catalog configuration is constructed by setting the defaults, then client- provided configuration, and finally overrides. The final property set is then used to configure the catalog. For example, a default configuration property might set the size of the client pool, which can be replaced with a client-specific setting. An override might be used to set the warehouse location, which is stored on the server rather than in client configuration. Common catalog configuration settings are documented at https://iceberg.apache.org/docs/latest/catalog-properties The catalog configuration also holds an optional `endpoints` field that contains information about the endpoints supported by the server. If a server does not send the `endpoints` field, a default set of endpoints is assumed: - GET /v1/{prefix}/namespaces - POST /v1/{prefix}/namespaces - GET /v1/{prefix}/namespaces/{namespace} - DELETE /v1/{prefix}/namespaces/{namespace} - POST /v1/{prefix}/namespaces/{namespace}/properties - GET /v1/{prefix}/namespaces/{namespace}/tables - POST /v1/{prefix}/namespaces/{namespace}/tables - GET /v1/{prefix}/namespaces/{namespace}/tables/{table} - POST /v1/{prefix}/namespaces/{namespace}/tables/{table} - DELETE /v1/{prefix}/namespaces/{namespace}/tables/{table} - POST /v1/{prefix}/namespaces/{namespace}/register - POST /v1/{prefix}/namespaces/{namespace}/tables/{table}/metrics - POST /v1/{prefix}/tables/rename - POST /v1/{prefix}/transactions/commit */
export declare const getConfig: API.OperationMethod<GetConfigRequest, CatalogConfig, GetConfigError, IcebergOpContext>;
export type ListFunctionsError = NoSuchNamespaceException | IcebergOpError;
/** List all functions underneath a given namespace Return all function identifiers under this namespace */
export declare const listFunctions: API.PaginatedOperationMethod<ListFunctionsRequest, ListFunctionsResponse, ListFunctionsError, IcebergOpContext, CatalogObjectIdentifier>;
export type ListNamespacesError = NoSuchNamespaceException | IcebergOpError;
/** List namespaces, optionally providing a parent namespace to list underneath List all namespaces at a certain level, optionally starting from a given parent namespace. If table accounting.tax.paid.info exists, using 'SELECT NAMESPACE IN accounting' would translate into `GET /namespaces?parent=accounting` and must return a namespace, ["accounting", "tax"] only. Using 'SELECT NAMESPACE IN accounting.tax' would translate into `GET /namespaces?parent=accounting%1Ftax` and must return a namespace, ["accounting", "tax", "paid"]. If `parent` is not provided, all top-level namespaces should be listed. */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, IcebergOpContext, Namespace>;
export type ListTablesError = NoSuchNamespaceException | IcebergOpError;
/** List all table identifiers underneath a given namespace Return all table identifiers under this namespace */
export declare const listTables: API.PaginatedOperationMethod<ListTablesRequest, ListTablesResponse, ListTablesError, IcebergOpContext, TableIdentifier>;
export type ListViewsError = NoSuchNamespaceException | IcebergOpError;
/** List all view identifiers underneath a given namespace Return all view identifiers under this namespace */
export declare const listViews: API.PaginatedOperationMethod<ListViewsRequest, ListTablesResponse, ListViewsError, IcebergOpContext, TableIdentifier>;
export type LoadCredentialsError = NoSuchTableException | IcebergOpError;
/** Load vended credentials for a table from the catalog Load vended credentials for a table from the catalog. */
export declare const loadCredentials: API.OperationMethod<LoadCredentialsRequest, LoadCredentialsResponse, LoadCredentialsError, IcebergOpContext>;
export type LoadFunctionError = NoSuchFunctionException | NoSuchNamespaceException | IcebergOpError;
/** Load a function from the catalog Load a function from the catalog. All overloaded definitions are included in a single response. */
export declare const loadFunction: API.OperationMethod<LoadFunctionRequest, LoadFunctionResult, LoadFunctionError, IcebergOpContext>;
export type LoadNamespaceMetadataError = NoSuchNamespaceException | IcebergOpError;
/** Load the metadata properties for a namespace Return all stored metadata properties for a given namespace */
export declare const loadNamespaceMetadata: API.OperationMethod<LoadNamespaceMetadataRequest, GetNamespaceResponse, LoadNamespaceMetadataError, IcebergOpContext>;
export type LoadTableError = NoSuchTableException | IcebergOpError;
/** Load a table from the catalog Load a table from the catalog. The response contains both configuration and table metadata. The configuration, if non-empty is used as additional configuration for the table that overrides catalog configuration. For example, this configuration may change the FileIO implementation to be used for the table. The response also contains the table's full metadata, matching the table metadata JSON file. The catalog configuration may contain credentials that should be used for subsequent requests for the table. The configuration key "token" is used to pass an access token to be used as a bearer token for table requests. Otherwise, a token may be passed using a RFC 8693 token type as a configuration key. For example, "urn:ietf:params:oauth:token-type:jwt=<JWT-token>". The response may include a read-restrictions field. A reader that supports read restrictions must fail any read against the loaded table that cannot apply a returned restriction in full. This includes unrecognized action or expression types, and actions whose definition cannot be loaded, parsed, or evaluated. These restrictions apply to every read performed using this response (including subsequent planTableScan and fetchScanTasks calls), but subsequent requests or requests made from a different authentication scope may have different restrictions. The response should not be cached outside of the authenticated scope. */
export declare const loadTable: API.OperationMethod<LoadTableRequest, LoadTableResult, LoadTableError, IcebergOpContext>;
export type LoadViewError = NoSuchViewException | IcebergOpError;
/** Load a view from the catalog Load a view from the catalog. The response contains both configuration and view metadata. The configuration, if non-empty is used as additional configuration for the view that overrides catalog configuration. The response also contains the view's full metadata, matching the view metadata JSON file. The catalog configuration may contain credentials that should be used for subsequent requests for the view. The configuration key "token" is used to pass an access token to be used as a bearer token for view requests. Otherwise, a token may be passed using a RFC 8693 token type as a configuration key. For example, "urn:ietf:params:oauth:token-type:jwt=<JWT-token>". */
export declare const loadView: API.OperationMethod<LoadViewRequest, LoadViewResult, LoadViewError, IcebergOpContext>;
export type NamespaceExistsError = IcebergOpError;
/** Check if a namespace exists Check if a namespace exists. The response does not contain a body. */
export declare const namespaceExists: API.OperationMethod<NamespaceExistsRequest, NamespaceExistsResponse, NamespaceExistsError, IcebergOpContext>;
export type PlanTableScanError = NoSuchNamespaceException | NoSuchTableException | UnsupportedOperationException | IcebergOpError;
/** Submit a scan for planning Submits a scan for server-side planning. Point-in-time scans are planned by passing snapshot-id to identify the table snapshot to scan. Incremental scans are planned by passing both start-snapshot-id and end-snapshot-id. Requests that include both point in time config properties and incremental config properties are invalid. If the request does not include either incremental or point-in-time config properties, scan planning should produce a point-in-time scan of the latest snapshot in the table's main branch. Responses must include a valid status listed below. A "cancelled" status is considered invalid for this endpoint. - When "completed" the planning operation has produced plan tasks and file scan tasks that must be returned in the response (not fetched later by calling fetchPlanningResult) - When "submitted" the response must include a plan-id used to poll fetchPlanningResult to fetch the planning result when it is ready - When "failed" the response must be a valid error response The response for a "completed" planning operation includes two types of tasks (file scan tasks and plan tasks) and both may be included in the response. Tasks must not be included for any other response status. Responses that include a plan-id indicate that the service is holding state or performing work for the client. - Clients should use the plan-id to fetch results from fetchPlanningResult when the response status is "submitted" - Clients should inform the service if planning results are no longer needed by calling cancelPlanning. Cancellation is not necessary after fetchScanTasks has been used to fetch scan tasks for each plan task. */
export declare const planTableScan: API.OperationMethod<PlanTableScanRequest, PlanTableScanResponse, PlanTableScanError, IcebergOpContext>;
export type RegisterTableError = AlreadyExistsException | NoSuchNamespaceException | IcebergOpError;
/** Register a table in the given namespace using given metadata file location Register a table using given metadata file location. */
export declare const registerTable: API.OperationMethod<RegisterTableRequest, LoadTableResult, RegisterTableError, IcebergOpContext>;
export type RegisterViewError = AlreadyExistsException | NoSuchNamespaceException | IcebergOpError;
/** Register a view in the catalog Register a view in the given namespace using given metadata file location. */
export declare const registerView: API.OperationMethod<RegisterViewRequest, LoadViewResult, RegisterViewError, IcebergOpContext>;
export type RenameTableError = NoSuchNamespaceException | NoSuchTableException | UnsupportedOperationException | IcebergOpError;
/** Rename a table from its current name to a new name Rename a table from one identifier to another. It's valid to move a table across namespaces, but the server implementation is not required to support it. */
export declare const renameTable: API.OperationMethod<RenameTableRequest, RenameTableResponse, RenameTableError, IcebergOpContext>;
export type RenameViewError = NoSuchNamespaceException | NoSuchViewException | UnsupportedOperationException | IcebergOpError;
/** Rename a view from its current name to a new name Rename a view from one identifier to another. It's valid to move a view across namespaces, but the server implementation is not required to support it. */
export declare const renameView: API.OperationMethod<RenameViewRequest, RenameViewResponse, RenameViewError, IcebergOpContext>;
export type ReplaceViewError = CommitFailedException | CommitStateUnknownException | NoSuchViewException | IcebergOpError;
/** Replace a view Commit updates to a view. */
export declare const replaceView: API.OperationMethod<ReplaceViewRequest, LoadViewResult, ReplaceViewError, IcebergOpContext>;
export type ReportMetricsError = NoSuchTableException | IcebergOpError;
/** Send a metrics report to this endpoint to be processed by the backend */
export declare const reportMetrics: API.OperationMethod<ReportMetricsRequest, ReportMetricsResponse, ReportMetricsError, IcebergOpContext>;
export type SignRequestError = IcebergOpError;
/** Remotely signs requests to object storage */
export declare const signRequest: API.OperationMethod<SignRequestRequest, RemoteSignResult, SignRequestError, IcebergOpContext>;
export type TableExistsError = IcebergOpError;
/** Check if a table exists Check if a table exists within a given namespace. The response does not contain a body. */
export declare const tableExists: API.OperationMethod<TableExistsRequest, TableExistsResponse, TableExistsError, IcebergOpContext>;
export type UnregisterTableError = NoSuchTableException | IcebergOpError;
/** Unregister a table without removing its data or metadata files Unregister a table from the catalog. This is the opposite of `registerTable`. The table no longer exists in the catalog, but the underlying data and metadata files are left in place so that the table can be registered in another catalog. On success, this returns the table's last metadata location and the corresponding table metadata. This table metadata must include all commits that happened before the unregister operation. All attempted commits after the unregister operation in this catalog must fail. */
export declare const unregisterTable: API.OperationMethod<UnregisterTableRequest, UnregisterTableResult, UnregisterTableError, IcebergOpContext>;
export type UpdatePropertiesError = NoSuchNamespaceException | UnprocessableEntityException | UnsupportedOperationException | IcebergOpError;
/** Set or remove properties on a namespace Set and/or remove properties on a namespace. The request body specifies a list of properties to remove and a map of key value pairs to update. Properties that are not in the request are not modified or removed by this call. Server implementations are not required to support namespace properties. */
export declare const updateProperties: API.OperationMethod<UpdatePropertiesRequest, UpdateNamespacePropertiesResponse, UpdatePropertiesError, IcebergOpContext>;
export type UpdateTableError = CommitFailedException | CommitStateUnknownException | NoSuchTableException | IcebergOpError;
/** Commit updates to a table Commit updates to a table. Commits have two parts, requirements and updates. Requirements are assertions that will be validated before attempting to make and commit changes. For example, `assert-ref-snapshot-id` will check that a named ref's snapshot ID has a certain value. Server implementations are required to fail with a 400 status code if any unknown updates or requirements are received. Updates are changes to make to table metadata. For example, after asserting that the current main ref is at the expected snapshot, a commit may add a new child snapshot and set the ref to the new snapshot id. Create table transactions that are started by createTable with `stage-create` set to true are committed using this route. Transactions should include all changes to the table, including table initialization, like AddSchemaUpdate and SetCurrentSchemaUpdate. The `assert-create` requirement is used to ensure that the table was not created concurrently. */
export declare const updateTable: API.OperationMethod<UpdateTableRequest, CommitTableResponse, UpdateTableError, IcebergOpContext>;
export type ViewExistsError = IcebergOpError;
/** Check if a view exists Check if a view exists within a given namespace. This request does not return a response body. */
export declare const viewExists: API.OperationMethod<ViewExistsRequest, ViewExistsResponse, ViewExistsError, IcebergOpContext>;
//# sourceMappingURL=catalog.d.ts.map