export * as catalog from "./catalog.ts";
//# sourceMappingURL=index.d.ts.map