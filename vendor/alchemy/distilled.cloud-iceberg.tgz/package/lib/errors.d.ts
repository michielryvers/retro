/**
 * Iceberg REST Catalog error types.
 *
 * Every failure carries one envelope -- `{ "error": { "message", "type",
 * "code" } }` -- where `type` names the exception (`NoSuchTableException`,
 * `CommitFailedException`, ...). The exceptions an operation documents are
 * generated per operation in `services/catalog.ts` and matched on status
 * plus `error.type`; this module holds what every route shares: core's
 * HTTP status errors, the 419 the spec adds, and the unknown-error and
 * parse-error wrappers.
 */
export { BadGateway, BadRequest, Conflict, ConfigError, Forbidden, GatewayTimeout, InternalServerError, Locked, NotFound, ServiceUnavailable, TooManyRequests, Unauthorized, UnprocessableEntity, HTTP_STATUS_MAP, DEFAULT_ERRORS, API_ERRORS, } from "@distilled.cloud/core/errors";
import type { BadRequest as CoreBadRequest, Conflict as CoreConflict, DefaultErrors as CoreDefaultErrors, Forbidden as CoreForbidden, NotFound as CoreNotFound, UnprocessableEntity as CoreUnprocessableEntity } from "@distilled.cloud/core/errors";
import * as Schema from "@distilled.cloud/core/schema-lite-typed";
declare const AuthenticationTimeout_base: Schema.TaggedErrorClass<"AuthenticationTimeout", {
    readonly message: import("effect/Schema").String;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
/**
 * HTTP 419 -- `AuthenticationTimeoutException`: the token expired. The spec
 * lets a catalog send this instead of 401; refresh the token and retry.
 */
export declare class AuthenticationTimeout extends /*@__PURE__*/ AuthenticationTimeout_base {
}
declare const UnknownIcebergError_base: Schema.TaggedErrorClass<"UnknownIcebergError", {
    readonly code: import("effect/Schema").optional<import("effect/Schema").String>;
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
    readonly body: import("effect/Schema").Unknown;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
/**
 * Unknown Iceberg error -- a failed response nothing else matched. `code` is
 * the envelope's `error.code` (the HTTP status the server reported).
 */
export declare class UnknownIcebergError extends /*@__PURE__*/ UnknownIcebergError_base {
}
declare const IcebergParseError_base: Schema.TaggedErrorClass<"IcebergParseError", {
    readonly body: import("effect/Schema").Unknown;
    readonly cause: import("effect/Schema").Unknown;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ParseError: true;
    };
});
/** Schema parse error wrapper. */
export declare class IcebergParseError extends /*@__PURE__*/ IcebergParseError_base {
}
/**
 * Errors any Iceberg operation may surface in addition to the shared HTTP
 * status errors.
 */
export type ClientErrors = UnknownIcebergError | IcebergParseError | AuthenticationTimeout;
/**
 * Default Iceberg operation errors.
 *
 * Beyond core's defaults, every operation carries the 4xx statuses a
 * catalog may answer with when its `error.type` is not one the operation
 * documents (a 404 from a catalog that names it `NotFoundException`, a 409
 * from a rename): those fall back to the status classes rather than
 * pretending they cannot happen.
 */
export type DefaultErrors = CoreDefaultErrors | CoreBadRequest | CoreForbidden | CoreNotFound | CoreConflict | CoreUnprocessableEntity | ClientErrors;
//# sourceMappingURL=errors.d.ts.map