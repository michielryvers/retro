import * as Retries from "@distilled.cloud/core/retry";
/**
 * Iceberg retry surface -- a veneer over `@distilled.cloud/core/retry`.
 *
 * The `Retry` service tag is threaded into every generated operation via
 * `API.make({ retry: Retry })`, so a caller-installed policy applies to all
 * Iceberg calls below it and core's `makeDefault` is the fallback when none is
 * provided.
 *
 * @example
 * ```ts
 * import * as Iceberg from "@distilled.cloud/iceberg";
 *
 * myEffect.pipe(Iceberg.Retry.transient);
 * ```
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
export type Options = Retries.Options;
export type Factory = Retries.Factory;
export type Policy = Retries.Policy;
declare const Retry_base: Context.ServiceClass<Retry, "IcebergRetry", Retries.Policy>;
/** Context tag for configuring retry behavior of Iceberg API calls. */
export declare class Retry extends /*@__PURE__*/ Retry_base {
}
/** Provides a custom retry policy to every Iceberg API call below it. */
export declare const policy: {
    (options: Options): <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
    (factory: Factory): <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
};
/** Disables all automatic retries. */
export declare const none: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
/**
 * The default retry policy (core's): transient/throttling/retryable errors,
 * capped exponential backoff with jitter, server `retryAfter` hints honored
 * with precedence.
 */
export declare const makeDefault: Factory;
export declare const jittered: <Error, Env>(self: import("effect/Schedule").Schedule<unknown, unknown, Error, Env>) => import("effect/Schedule").Schedule<unknown, unknown, Error, Env>;
export declare const capped: (max: import("effect/Duration").Duration) => <Error, Env>(self: import("effect/Schedule").Schedule<unknown, unknown, Error, Env>) => import("effect/Schedule").Schedule<unknown, unknown, Error, Env>;
/** Retry options that retry all throttling errors indefinitely. */
export declare const throttlingOptions: Options;
/** Retries all throttling errors indefinitely (honoring server hints). */
export declare const throttling: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
/** Retry options that retry all transient errors indefinitely. */
export declare const transientOptions: Options;
/** Retries all transient errors indefinitely. */
export declare const transient: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
export {};
//# sourceMappingURL=retry.d.ts.map