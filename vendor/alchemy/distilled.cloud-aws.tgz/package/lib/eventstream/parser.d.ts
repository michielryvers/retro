/**
 * Event Stream Parser
 *
 * Converts a ReadableStream of bytes into an Effect Stream of typed events.
 * Handles message framing, CRC validation, and event parsing.
 */
import type * as Schema from "effect/Schema";
import * as Stream from "effect/Stream";
import { EventParseError, EventStreamDecodeError, type StreamEvent } from "./codec.ts";
/** Errors that can occur during event stream parsing */
export type EventStreamParseError = EventStreamDecodeError | EventParseError;
/**
 * Parse a ReadableStream of bytes into an Effect Stream of events.
 *
 * This handles:
 * - Buffering partial messages
 * - Message framing and CRC validation
 * - Event type parsing
 */
export declare const parseEventStream: (input: ReadableStream<Uint8Array>) => Stream.Stream<StreamEvent, EventStreamParseError>;
/**
 * Parsed event in tagged union format: { EventType: payload }
 */
export type ParsedEvent = Record<string, unknown>;
/**
 * Payload parser function - protocol-specific (JSON, XML, etc.)
 */
export type PayloadParser = (payload: Uint8Array) => unknown;
/**
 * Raw text payload parser - returns payload as { payload: string }
 * Useful when caller wants to handle parsing themselves
 */
export declare const rawPayloadParser: PayloadParser;
/**
 * Default JSON payload parser
 */
export declare const jsonPayloadParser: PayloadParser;
/**
 * Transform a stream of StreamEvents into typed union members.
 *
 * Converts internal event types to the Smithy union format:
 * - MessageEvent -> { eventType: parsedPayload }
 * - ExceptionEvent -> { exceptionType: parsedPayload }
 * - ErrorEvent -> { UnmodeledError: { errorCode, errorMessage } }
 *
 * @param eventStream - Stream of raw StreamEvents from parseEventStream
 * @param payloadParser - Function to parse the payload bytes (default: JSON)
 */
export declare const transformEventStreamToUnion: (eventStream: Stream.Stream<StreamEvent, EventStreamParseError>, payloadParser?: PayloadParser, eventPayloadMap?: Record<string, string>) => Stream.Stream<ParsedEvent, EventStreamParseError>;
/**
 * Decode each parsed union event through the operation's event schema (the
 * Smithy union of event types). The payload parser alone only produces plain
 * JSON/XML values -- member transformations declared on the schema never run,
 * so blob members stay base64 strings (instead of `Uint8Array` /
 * `Redacted<Uint8Array>` for sensitive blobs) and timestamps stay numbers.
 * Running the schema decode makes the runtime values match the generated
 * types (e.g. Bedrock `InvokeModelWithResponseStream`'s `chunk.bytes`).
 *
 * An event that fails to decode is passed through raw so unmodeled events
 * (`UnmodeledError`) and exception events keep flowing.
 */
export declare const decodeEventStreamUnion: (eventStream: Stream.Stream<ParsedEvent, EventStreamParseError>, eventSchema: Schema.Schema<unknown> | undefined) => Stream.Stream<ParsedEvent, EventStreamParseError>;
/**
 * Parse a ReadableStream of bytes into a Stream of typed union events.
 *
 * This is the high-level API that combines:
 * 1. parseEventStream - decode wire format to StreamEvents
 * 2. transformEventStreamToUnion - convert to typed union members
 * 3. decodeEventStreamUnion - run the event schema so runtime values match
 *    the generated types (blobs -> Uint8Array, sensitive blobs -> Redacted)
 *
 * @param input - ReadableStream of event stream bytes
 * @param payloadParser - Function to parse event payloads (default: JSON)
 * @param eventSchema - The Smithy union schema for the stream's events
 */
export declare const parseEventStreamToUnion: (input: ReadableStream<Uint8Array>, payloadParser?: PayloadParser, eventSchema?: Schema.Schema<unknown>, eventPayloadMap?: Record<string, string>) => Stream.Stream<ParsedEvent, EventStreamParseError>;
//# sourceMappingURL=parser.d.ts.map