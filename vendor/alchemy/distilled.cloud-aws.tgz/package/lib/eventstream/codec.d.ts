/**
 * Amazon Event Stream Codec
 *
 * Implements the binary message framing for event streams as specified in:
 * https://docs.aws.amazon.com/transcribe/latest/dg/streaming-format.html
 *
 * Message format:
 * - Prelude: total_length (4) + headers_length (4) + prelude_crc (4)
 * - Data: headers (variable) + payload (variable) + message_crc (4)
 *
 * Also provides the semantic event layer:
 * - Message events: normal event data (:message-type: event)
 * - Modeled error events: schema-defined errors (:message-type: exception)
 * - Unmodeled error events: unexpected errors (:message-type: error)
 */
import * as Effect from "effect/Effect";
/** Standard event stream header names */
export declare const HEADER_MESSAGE_TYPE = ":message-type";
export declare const HEADER_EVENT_TYPE = ":event-type";
export declare const HEADER_EXCEPTION_TYPE = ":exception-type";
export declare const HEADER_ERROR_CODE = ":error-code";
export declare const HEADER_ERROR_MESSAGE = ":error-message";
export declare const HEADER_CONTENT_TYPE = ":content-type";
/** Special event types for RPC protocol initial messages */
export declare const INITIAL_REQUEST_EVENT_TYPE = "initial-request";
export declare const INITIAL_RESPONSE_EVENT_TYPE = "initial-response";
declare const EventStreamDecodeError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "EventStreamDecodeError";
} & Readonly<A>;
/** Error decoding an event stream message */
export declare class EventStreamDecodeError extends /*@__PURE__*/ EventStreamDecodeError_base<{
    message: string;
}> {
}
declare const EventStreamEncodeError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "EventStreamEncodeError";
} & Readonly<A>;
/** Error encoding an event stream message */
export declare class EventStreamEncodeError extends /*@__PURE__*/ EventStreamEncodeError_base<{
    message: string;
}> {
}
declare const EventParseError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "EventParseError";
} & Readonly<A>;
/** Error parsing an event from a message */
export declare class EventParseError extends /*@__PURE__*/ EventParseError_base<{
    message: string;
}> {
}
/** Header type indicators as defined in the spec */
export declare const HeaderType: {
    readonly BoolTrue: 0;
    readonly BoolFalse: 1;
    readonly Byte: 2;
    readonly Short: 3;
    readonly Int: 4;
    readonly Long: 5;
    readonly ByteArray: 6;
    readonly String: 7;
    readonly Timestamp: 8;
    readonly Uuid: 9;
};
export type HeaderType = (typeof HeaderType)[keyof typeof HeaderType];
/** Header value type discriminated union */
export type HeaderValue = {
    type: typeof HeaderType.BoolTrue;
    value: true;
} | {
    type: typeof HeaderType.BoolFalse;
    value: false;
} | {
    type: typeof HeaderType.Byte;
    value: number;
} | {
    type: typeof HeaderType.Short;
    value: number;
} | {
    type: typeof HeaderType.Int;
    value: number;
} | {
    type: typeof HeaderType.Long;
    value: bigint;
} | {
    type: typeof HeaderType.ByteArray;
    value: Uint8Array;
} | {
    type: typeof HeaderType.String;
    value: string;
} | {
    type: typeof HeaderType.Timestamp;
    value: Date;
} | {
    type: typeof HeaderType.Uuid;
    value: Uint8Array;
};
/** Headers are a record of name to typed value */
export type Headers = Record<string, HeaderValue>;
/** A decoded event stream message */
export interface Message {
    headers: Headers;
    payload: Uint8Array;
}
/** Message type header values */
export type MessageType = "event" | "exception" | "error";
/**
 * A message event - normal event data from the stream
 */
export interface MessageEvent {
    readonly _tag: "MessageEvent";
    /** The event type name (from :event-type header) */
    readonly eventType: string;
    /** The content type (from :content-type header), e.g., "application/json" */
    readonly contentType?: string;
    /** The event payload */
    readonly payload: Uint8Array;
    /** Additional custom headers */
    readonly headers: Headers;
}
/**
 * A modeled exception event - schema-defined error from the stream
 */
export interface ExceptionEvent {
    readonly _tag: "ExceptionEvent";
    /** The exception type name (from :exception-type header) */
    readonly exceptionType: string;
    /** The content type (from :content-type header) */
    readonly contentType?: string;
    /** The exception payload (usually JSON with error details) */
    readonly payload: Uint8Array;
    /** Additional custom headers */
    readonly headers: Headers;
}
/**
 * An unmodeled error event - unexpected error from the stream
 */
export interface ErrorEvent {
    readonly _tag: "ErrorEvent";
    /** The error code (from :error-code header) */
    readonly errorCode: string;
    /** The error message (from :error-message header) */
    readonly errorMessage: string;
    /** Additional custom headers */
    readonly headers: Headers;
}
/**
 * Discriminated union of all event types
 */
export type StreamEvent = MessageEvent | ExceptionEvent | ErrorEvent;
/** Create a string header value */
export declare function stringHeader(value: string): HeaderValue;
/** Get a header value as string, or undefined if not present or wrong type */
export declare function getStringHeader(headers: Headers, name: string): string | undefined;
/**
 * Encode a message to the wire format
 */
export declare const encodeMessage: (message: Message) => Effect.Effect<Uint8Array, EventStreamEncodeError>;
/**
 * Decode a single message from bytes
 * Returns the message and the total bytes consumed
 */
export declare const decodeMessage: (data: Uint8Array) => Effect.Effect<[Message, number], EventStreamDecodeError>;
/**
 * Check if we have a complete message in the buffer
 * Returns the total message length if complete, or 0 if incomplete
 */
export declare function getMessageLength(data: Uint8Array): number;
/**
 * Parse a raw message into a typed event
 */
export declare const parseEvent: (message: Message) => Effect.Effect<StreamEvent, EventParseError>;
/**
 * Encode a StreamEvent into wire format bytes
 */
export declare const encodeEvent: (event: StreamEvent) => Effect.Effect<Uint8Array, EventStreamEncodeError>;
export {};
//# sourceMappingURL=codec.d.ts.map