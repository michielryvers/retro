/**
 * Event Stream Serializer
 *
 * Converts an Effect Stream of typed events into encoded bytes.
 * Supports both raw StreamEvent streams and typed input event streams.
 */
import type * as Schema from "effect/Schema";
import * as Stream from "effect/Stream";
import { type EventStreamEncodeError, type MessageEvent, type StreamEvent } from "./codec.ts";
/** Errors that can occur during event stream serialization */
export type EventStreamSerializeError = EventStreamEncodeError;
/**
 * Serialize an Effect Stream of events into a Stream of encoded bytes.
 */
export declare const serializeEventStream: (events: Stream.Stream<StreamEvent, EventStreamSerializeError>) => Stream.Stream<Uint8Array, EventStreamSerializeError>;
/**
 * Input event type - represents an event from a union type.
 *
 * Supports two formats:
 * 1. Tagged format: { _tag: "EventName", ...properties }
 * 2. Smithy union format: { EventName: { ...properties } }
 */
export interface InputEvent {
    readonly _tag?: string;
    [key: string]: unknown;
}
/**
 * Serialize a typed input event (from a union) into a StreamEvent.
 * Converts the event's type to the event type header and serializes
 * the payload as JSON.
 *
 * @param event - The typed event (either _tag or Smithy union format)
 * @param contentType - The content type for the payload (default: application/json)
 * @returns A MessageEvent ready for wire serialization
 */
export declare const serializeInputEvent: (event: InputEvent, contentType?: string) => MessageEvent;
/**
 * Serialize an Effect Stream of typed events into a ReadableStream of bytes.
 * This is the main entry point for input event stream serialization.
 *
 * For input event streams (like Transcribe's AudioStream), this:
 * 1. Takes each typed event from the stream
 * 2. Converts it to event stream wire format with proper headers
 * 3. Returns a ReadableStream suitable for HTTP request body
 *
 * @param events - Stream of typed events (with _tag property)
 * @param contentType - Content type for JSON payloads
 * @returns ReadableStream of encoded event stream bytes
 */
export declare const serializeInputEventStream: <E extends InputEvent>(events: Stream.Stream<E, unknown>, contentType?: string) => ReadableStream<Uint8Array>;
/**
 * Serialize an input event stream using its event union schema.
 *
 * Each event is encoded through `eventSchema` (so blob members inside JSON
 * payloads become base64 strings, as the service expects) and framed per the
 * `eventPayload` / `eventHeader` bindings derived from the event structs'
 * member annotations. An explicit `eventPayloadMap` (event type -> payload
 * member) overrides the derived payload member.
 *
 * @param events - Stream of events, in Smithy union (`{ EventName: {...} }`)
 *   or tagged (`{ _tag: "EventName", ... }`) form
 * @param eventSchema - The stream's event union schema
 * @param eventPayloadMap - Optional explicit event type -> payload member map
 */
export declare const serializeInputEventStreamWithSchema: <E extends InputEvent>(events: Stream.Stream<E, unknown>, eventSchema: Schema.Schema<unknown> | undefined, eventPayloadMap?: Record<string, string>) => ReadableStream<Uint8Array>;
/**
 * Serialize a typed input event with a specific eventPayload member.
 * Used for events that have an @eventPayload member (like AudioEvent with AudioChunk).
 *
 * @param event - The typed event (either _tag or Smithy union format)
 * @param payloadMemberName - The name of the @eventPayload member (e.g., "AudioChunk")
 * @param contentType - The content type for binary payloads (default: application/octet-stream)
 * @returns A MessageEvent ready for wire serialization
 */
export declare const serializeInputEventWithPayload: (event: InputEvent, payloadMemberName: string, contentType?: string) => MessageEvent;
/**
 * Serialize a stream of events where events may have @eventPayload members.
 * This handles the case where some event types have binary payloads (like AudioEvent)
 * while others have JSON payloads (like ConfigurationEvent).
 *
 * @param events - Stream of typed events
 * @param eventPayloadMap - Map of event type (name) to its payload member name, if any
 * @returns ReadableStream of encoded event stream bytes
 */
export declare const serializeInputEventStreamWithPayloads: <E extends InputEvent>(events: Stream.Stream<E, unknown>, eventPayloadMap: Record<string, string>) => ReadableStream<Uint8Array>;
//# sourceMappingURL=serializer.d.ts.map