import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as HttpClient from "effect/http/HttpClient";
import * as Path from "effect/Path";
import { type AwsProfileConfig } from "./auth.browser.ts";
import { type ResolvedCredentials } from "./credentials-service.ts";
export * from "./auth.browser.ts";
/**
 * Shape of `~/.aws/sso/cache/<key>.credentials.json`, the cached role
 * credentials minted from an SSO token. `sso_account_id` / `sso_role_name`
 * record which role the keys belong to; a file that does not name the
 * profile's account and role is not a cache hit.
 */
export interface CachedSsoRoleCredentials {
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken?: string;
    /** Epoch milliseconds, as returned by the SSO portal. */
    expiry: number;
    sso_account_id: string;
    sso_role_name: string;
}
/**
 * Cache file name (without extension) of the SSO access token: sha1 of the
 * `sso_session` name (modern) or the `sso_start_url` (legacy inline format).
 * Matches the AWS CLI, so one `aws sso login` serves every profile in the
 * session.
 */
export declare const ssoTokenCacheName: (ssoCacheKey: string) => string;
/**
 * Cache file name (without extension) of the role credentials for a profile:
 * sha1 of `<sso_session | sso_start_url>\n<sso_account_id>\n<sso_role_name>`.
 * The token is per session; the role credentials are per account + role.
 */
export declare const ssoRoleCredentialsCacheName: (profile: Pick<AwsProfileConfig, "sso_session" | "sso_start_url" | "sso_account_id" | "sso_role_name">) => string;
export declare const Default: Effect.Effect<{
    loadProfile: (profileName: string) => Effect.Effect<AwsProfileConfig, import("./credentials-service.ts").CredentialsError>;
    loadProfileCredentials: (profileName: string) => Effect.Effect<ResolvedCredentials, import("./credentials-service.ts").CredentialsError>;
}, never, FileSystem.FileSystem | HttpClient.HttpClient | Path.Path>;
export declare const loadProfile: (profile: string) => Effect.Effect<AwsProfileConfig, import("./credentials-service.ts").CredentialsError, FileSystem.FileSystem | HttpClient.HttpClient | Path.Path>;
export declare const loadProfileCredentials: (profile: string) => Effect.Effect<ResolvedCredentials, import("./credentials-service.ts").CredentialsError, FileSystem.FileSystem | HttpClient.HttpClient | Path.Path>;
export declare const makeAuthService: () => Effect.Effect<{
    loadProfile: (profileName: string) => Effect.Effect<AwsProfileConfig, import("./credentials-service.ts").CredentialsError>;
    loadProfileCredentials: (profileName: string) => Effect.Effect<ResolvedCredentials, import("./credentials-service.ts").CredentialsError>;
}, never, FileSystem.FileSystem | HttpClient.HttpClient | Path.Path>;
//# sourceMappingURL=auth.d.ts.map