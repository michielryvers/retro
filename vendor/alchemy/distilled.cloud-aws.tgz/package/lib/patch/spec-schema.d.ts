import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import * as S from "effect/Schema";
/**
 * Schema for service error patches discovered by the AI agent.
 * These are stored in spec/{service}.json and applied during client generation.
 */
/**
 * Schema for error category strings.
 * Uses the existing Category constants from src/category.ts.
 */
export declare const CategorySchema: S.Literals<readonly ["ThrottlingError", "RetryableError", "ServerError", "AuthError", "BadRequestError", "TimeoutError", "ConflictError", "QuotaError", "NetworkError", "AbortedError"]>;
export type CategorySchema = typeof CategorySchema.Type;
/**
 * Error alias - maps an error tag to an alternative name
 */
export declare const ErrorAlias: S.Struct<{
    /**
     * The original error tag (e.g., "NotFound")
     */
    readonly from: S.String;
    /**
     * The canonical error tag it should be aliased to (e.g., "NoSuchBucket")
     */
    readonly to: S.String;
}>;
export type ErrorAlias = typeof ErrorAlias.Type;
/**
 * Patches for a single operation
 */
export declare const OperationPatch: S.Struct<{
    /**
     * Additional error types that should be included in this operation's error union.
     * These are error shape names (not full shape IDs).
     */
    readonly errors: S.optional<S.$Array<S.String>>;
    /**
     * Error aliases - when AWS returns an error with one name that should be treated as another.
     * Useful for deduplicating errors like "Error" vs "ErrorException".
     */
    readonly aliases: S.optional<S.$Array<S.Struct<{
        /**
         * The original error tag (e.g., "NotFound")
         */
        readonly from: S.String;
        /**
         * The canonical error tag it should be aliased to (e.g., "NoSuchBucket")
         */
        readonly to: S.String;
    }>>>;
}>;
export type OperationPatch = typeof OperationPatch.Type;
/**
 * Member override - specifies that a structure member should be treated differently
 * than what the Smithy model says (e.g., making a required field optional)
 */
export declare const MemberOverride: S.Struct<{
    /**
     * Whether the field should be optional (true) or required (false).
     * If specified, overrides the Smithy model's required trait.
     */
    readonly optional: S.optional<S.Boolean>;
}>;
export type MemberOverride = typeof MemberOverride.Type;
/**
 * Enum override - specifies additional or replacement values for an enum.
 * Use this when AWS returns values not in the Smithy model, or with different casing.
 */
export declare const EnumOverride: S.Struct<{
    /**
     * Additional values to add to the enum (merged with existing values).
     * Use this when AWS returns values not documented in the Smithy model.
     */
    readonly add: S.optional<S.$Array<S.String>>;
    /**
     * Completely replace the enum values with these.
     * Use this when the Smithy model is wrong and you need full control.
     */
    readonly replace: S.optional<S.$Array<S.String>>;
}>;
export type EnumOverride = typeof EnumOverride.Type;
/**
 * Structure override - specifies member overrides for a specific structure
 */
export declare const StructureOverride: S.Struct<{
    /**
     * Map of member names to their overrides
     */
    readonly members: S.$Record<S.String, S.Struct<{
        /**
         * Whether the field should be optional (true) or required (false).
         * If specified, overrides the Smithy model's required trait.
         */
        readonly optional: S.optional<S.Boolean>;
    }>>;
}>;
export type StructureOverride = typeof StructureOverride.Type;
/**
 * Error member patch - adds a member to an error schema.
 * Use this for errors not fully documented in Smithy (e.g., PermanentRedirect).
 */
export declare const ErrorMemberPatch: S.Struct<{
    /**
     * The type of the member (e.g., "string", "boolean", "number")
     */
    readonly type: S.String;
    /**
     * Whether the field is optional (default: true)
     */
    readonly optional: S.optional<S.Boolean>;
    /**
     * HTTP header to extract this value from (e.g., "x-amz-bucket-region")
     */
    readonly httpHeader: S.optional<S.String>;
}>;
export type ErrorMemberPatch = typeof ErrorMemberPatch.Type;
/**
 * Error override - specifies members to add to an error schema
 */
export declare const ErrorOverride: S.$Record<S.String, S.Struct<{
    /**
     * The type of the member (e.g., "string", "boolean", "number")
     */
    readonly type: S.String;
    /**
     * Whether the field is optional (default: true)
     */
    readonly optional: S.optional<S.Boolean>;
    /**
     * HTTP header to extract this value from (e.g., "x-amz-bucket-region")
     */
    readonly httpHeader: S.optional<S.String>;
}>>;
export type ErrorOverride = typeof ErrorOverride.Type;
/**
 * All patches for a service
 */
export declare const ServiceSpec: S.Struct<{
    /**
     * Map of operation names to their patches
     */
    readonly operations: S.$Record<S.String, S.Struct<{
        /**
         * Additional error types that should be included in this operation's error union.
         * These are error shape names (not full shape IDs).
         */
        readonly errors: S.optional<S.$Array<S.String>>;
        /**
         * Error aliases - when AWS returns an error with one name that should be treated as another.
         * Useful for deduplicating errors like "Error" vs "ErrorException".
         */
        readonly aliases: S.optional<S.$Array<S.Struct<{
            /**
             * The original error tag (e.g., "NotFound")
             */
            readonly from: S.String;
            /**
             * The canonical error tag it should be aliased to (e.g., "NoSuchBucket")
             */
            readonly to: S.String;
        }>>>;
    }>>;
    /**
     * Map of structure names to their member overrides.
     */
    readonly structures: S.optional<S.$Record<S.String, S.Struct<{
        /**
         * Map of member names to their overrides
         */
        readonly members: S.$Record<S.String, S.Struct<{
            /**
             * Whether the field should be optional (true) or required (false).
             * If specified, overrides the Smithy model's required trait.
             */
            readonly optional: S.optional<S.Boolean>;
        }>>;
    }>>>;
    /**
     * Map of enum names to their value overrides.
     */
    readonly enums: S.optional<S.$Record<S.String, S.Struct<{
        /**
         * Additional values to add to the enum (merged with existing values).
         * Use this when AWS returns values not documented in the Smithy model.
         */
        readonly add: S.optional<S.$Array<S.String>>;
        /**
         * Completely replace the enum values with these.
         * Use this when the Smithy model is wrong and you need full control.
         */
        readonly replace: S.optional<S.$Array<S.String>>;
    }>>>;
    /**
     * Map of error names to their member patches.
     */
    readonly errors: S.optional<S.$Record<S.String, S.$Record<S.String, S.Struct<{
        /**
         * The type of the member (e.g., "string", "boolean", "number")
         */
        readonly type: S.String;
        /**
         * Whether the field is optional (default: true)
         */
        readonly optional: S.optional<S.Boolean>;
        /**
         * HTTP header to extract this value from (e.g., "x-amz-bucket-region")
         */
        readonly httpHeader: S.optional<S.String>;
    }>>>>;
    /**
     * Map of error names to their categories.
     */
    readonly errorCategories: S.optional<S.$Record<S.String, S.$Array<S.Literals<readonly ["ThrottlingError", "RetryableError", "ServerError", "AuthError", "BadRequestError", "TimeoutError", "ConflictError", "QuotaError", "NetworkError", "AbortedError"]>>>>;
}>;
export type ServiceSpec = typeof ServiceSpec.Type;
/**
 * Load spec patches for a service from spec/{service}.json
 */
export declare const loadServiceSpecPatch: (serviceSdkId: string) => Effect.Effect<{
    readonly operations: {
        readonly [x: string]: {
            readonly errors?: readonly string[] | undefined;
            readonly aliases?: readonly {
                readonly from: string;
                readonly to: string;
            }[] | undefined;
        };
    };
    readonly structures?: {
        readonly [x: string]: {
            readonly members: {
                readonly [x: string]: {
                    readonly optional?: boolean | undefined;
                };
            };
        };
    } | undefined;
    readonly enums?: {
        readonly [x: string]: {
            readonly add?: readonly string[] | undefined;
            readonly replace?: readonly string[] | undefined;
        };
    } | undefined;
    readonly errors?: {
        readonly [x: string]: {
            readonly [x: string]: {
                readonly type: string;
                readonly optional?: boolean | undefined;
                readonly httpHeader?: string | undefined;
            };
        };
    } | undefined;
    readonly errorCategories?: {
        readonly [x: string]: readonly ("AbortedError" | "AuthError" | "BadRequestError" | "ConflictError" | "NetworkError" | "QuotaError" | "RetryableError" | "ServerError" | "ThrottlingError" | "TimeoutError")[];
    } | undefined;
}, never, FileSystem.FileSystem | Path.Path>;
//# sourceMappingURL=spec-schema.d.ts.map