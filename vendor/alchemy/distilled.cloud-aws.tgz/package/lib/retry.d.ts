import * as Retries from "@distilled.cloud/core/retry";
/**
 * AWS retry surface -- a veneer over `@distilled.cloud/core/retry`.
 *
 * The `Retry` service tag is threaded into every generated operation via
 * `API.make({ retry: Retry })`, so a caller-installed policy applies to all
 * AWS calls below it and core's `makeDefault` is the fallback when none is
 * provided. Server-provided hints are honored through `error.retryAfter`
 * (a Duration), which the AWS protocol stamps from wire
 * `retryAfterSeconds` fields at decode time.
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
export type Options = Retries.Options;
export type Factory = Retries.Factory;
export type Policy = Retries.Policy;
declare const Retry_base: Context.ServiceClass<Retry, "AWS::Retry", Retries.Policy>;
/**
 * Context tag for configuring retry behavior of AWS API calls.
 */
export declare class Retry extends /*@__PURE__*/ Retry_base {
}
/**
 * Provides a custom retry policy to all AWS API calls in the effect.
 */
export declare const policy: {
    (options: Options): <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
    (factory: Factory): <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
};
/**
 * Disables all automatic retries.
 */
export declare const none: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
/**
 * The default retry policy (core's): transient/throttling/retryable errors,
 * capped exponential backoff with jitter, server `retryAfter` hints honored
 * with precedence.
 */
export declare const makeDefault: Factory;
export declare const jittered: <Error, Env>(self: import("effect/Schedule").Schedule<unknown, unknown, Error, Env>) => import("effect/Schedule").Schedule<unknown, unknown, Error, Env>;
export declare const capped: (max: import("effect/Duration").Duration) => <Error, Env>(self: import("effect/Schedule").Schedule<unknown, unknown, Error, Env>) => import("effect/Schedule").Schedule<unknown, unknown, Error, Env>;
/**
 * Retry options that retries all throttling errors indefinitely.
 */
export declare const throttlingOptions: Options;
/**
 * Retries all throttling errors indefinitely (honoring server hints).
 */
export declare const throttling: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
/**
 * Retry options that retries all transient errors indefinitely.
 */
export declare const transientOptions: Options;
/**
 * Retries all transient errors indefinitely (honoring server hints).
 */
export declare const transient: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
export {};
//# sourceMappingURL=retry.d.ts.map