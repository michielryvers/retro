/**
 * Streaming Body Middleware
 *
 * Handles streaming bodies that don't have Content-Length by buffering
 * the stream and computing the Content-Length.
 *
 * Note: While HTTP supports Transfer-Encoding: chunked, many AWS services
 * (including S3 PutObject) don't support it. Buffering ensures compatibility
 * with all services.
 *
 * @see https://smithy.io/2.0/spec/streaming.html#requireslength-trait
 */
import * as Effect from "effect/Effect";
import type * as S from "effect/Schema";
import type * as AST from "effect/SchemaAST";
import type { Request as ProtocolRequest } from "../client/request.ts";
/**
 * Info about the streaming payload in a schema.
 * Pre-computed once during middleware creation.
 */
interface StreamingPayloadInfo {
    hasStreamingPayload: boolean;
    isEventStream: boolean;
    requiresLength: boolean;
}
/**
 * Create a streaming body middleware for a given schema.
 *
 * The expensive schema analysis is done once at creation time.
 * Returns a function that processes requests.
 *
 * @param schema - The request schema with streaming annotations
 * @returns A function that applies streaming body handling to requests
 */
export declare const makeStreamingBodyMiddleware: (schema: S.Top) => (request: ProtocolRequest) => Effect.Effect<ProtocolRequest>;
/**
 * Get streaming payload info from an AST.
 * Returns whether the schema has a streaming payload, if it's an event stream,
 * and if it requires length.
 */
export declare const getStreamingPayloadInfo: (ast: AST.AST) => StreamingPayloadInfo;
export {};
//# sourceMappingURL=streaming-body.d.ts.map