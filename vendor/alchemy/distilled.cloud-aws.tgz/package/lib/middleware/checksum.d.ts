import * as Effect from "effect/Effect";
import type * as S from "effect/Schema";
import type { Request as ProtocolRequest } from "../client/request.ts";
import type { Checksum } from "../hash/checksum.ts";
export type SourceData = string | ArrayBuffer | ArrayBufferView;
export interface ChecksumConstructor {
    new (secret?: SourceData): Checksum;
}
export declare const stringHasher: (checksumAlgorithmFn: ChecksumConstructor, body: any) => Effect.Effect<Uint8Array<ArrayBufferLike>, never, never>;
/**
 * Apply checksum to a protocol Request based on schema annotations.
 * Uses the aws.protocols#httpChecksum trait to determine checksum requirements.
 *
 * For streaming bodies, uses aws-chunked encoding with trailing checksum.
 * For non-streaming bodies, computes checksum directly and adds header.
 *
 * @param schema - The request schema with checksum annotations
 * @param request - The protocol request to add checksum to
 * @returns Effect that produces the request with checksum header added
 */
export declare const applyHttpChecksum: (schema: S.Top, request: ProtocolRequest) => Effect.Effect<ProtocolRequest>;
/**
 * Create an aws-chunked encoded stream with trailing checksum.
 * Format: <chunk-size-hex>\r\n<chunk-data>\r\n...0\r\n<trailer>\r\n\r\n
 *
 * @see https://docs.aws.amazon.com/AmazonS3/latest/API/sigv4-streaming.html
 */
export declare function createAwsChunkedStream(source: ReadableStream<Uint8Array>, checksumAlgorithmFn: ChecksumConstructor, checksumLocationName: string): ReadableStream<Uint8Array>;
//# sourceMappingURL=checksum.d.ts.map