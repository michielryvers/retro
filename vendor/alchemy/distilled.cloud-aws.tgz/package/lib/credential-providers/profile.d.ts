/**
 * The shared config and credentials files (`~/.aws/config`,
 * `~/.aws/credentials`) the Node providers read.
 *
 * Profiles come from `../util/shared-config.ts`, the same loader `auth.ts`
 * uses, so both agree on which files and which profile name apply.
 */
import * as Effect from "effect/Effect";
import { type CredentialsError } from "../credentials-service.ts";
import type * as Region from "../region.ts";
import { CredentialSourceError } from "./credential-source.ts";
export type Profile = Readonly<Record<string, string | undefined>>;
export type Profiles = Readonly<Record<string, Profile | undefined>>;
export declare const ENV_PROFILE = "AWS_PROFILE";
/** `profile`, else `AWS_PROFILE`, else `default` -- as the AWS CLI. */
export declare const getProfileName: (profile?: string) => string;
export declare const loadProfiles: () => Effect.Effect<Profiles, CredentialSourceError>;
/**
 * The `[profile <name>]` section of `~/.aws/config` alone (no credentials
 * file), for settings that the config file owns such as `region` and the
 * IMDS options.
 */
export declare const loadConfigProfile: (profile?: string) => Effect.Effect<Profile | undefined, CredentialSourceError>;
/**
 * The region STS is called in for a profile: the profile's own `region`,
 * else the environment, else the default profile's `region`, else
 * `us-east-1` -- the order of the SDK's `stsRegionDefaultResolver`.
 */
export declare const profileStsRegion: (profileRegion: string | undefined, profile?: string) => Effect.Effect<Region.RegionName, CredentialSourceError>;
/**
 * The region a profile-reading provider authenticated against: the one the
 * caller named, else the environment, else the profile's own `region`.
 * The profile is only consulted when the environment is silent, so
 * `AWS_REGION` still wins for a one-off override without editing config.
 */
export declare const profileRegion: (region: string | undefined, profile?: string) => Effect.Effect<Region.RegionName, CredentialsError>;
//# sourceMappingURL=profile.d.ts.map