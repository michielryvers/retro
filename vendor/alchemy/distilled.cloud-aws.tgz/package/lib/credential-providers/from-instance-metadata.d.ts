import * as Effect from "effect/Effect";
import { type CredentialSource, CredentialSourceError } from "./credential-source.ts";
export interface FromInstanceMetadataOptions {
    readonly timeout?: number;
    readonly maxRetries?: number;
    /** Refuse to fall back to IMDSv1 when no session token can be obtained. */
    readonly ec2MetadataV1Disabled?: boolean;
    /**
     * `~/.aws/config` values for the active profile
     * (`ec2_metadata_service_endpoint`, `ec2_metadata_service_endpoint_mode`,
     * `ec2_metadata_v1_disabled`). The Node entry point reads them; the
     * environment always wins.
     */
    readonly profileConfig?: Effect.Effect<Readonly<Record<string, string | undefined>> | undefined, CredentialSourceError>;
}
/**
 * Credentials of the instance role, from IMDSv2 with a fall back to IMDSv1
 * unless `AWS_EC2_METADATA_V1_DISABLED` (or the profile) forbids it.
 *
 * Each call to `fromInstanceMetadata` owns its own state: whether v1 is in
 * use and the last credentials served, for static stability.
 */
export declare const instanceMetadataSource: (options?: FromInstanceMetadataOptions) => CredentialSource;
/** The EC2 instance role, from the instance metadata service. */
export declare const fromInstanceMetadata: (options?: FromInstanceMetadataOptions) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-instance-metadata.d.ts.map