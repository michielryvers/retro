/**
 * How the providers that call an HTTP endpoint get a client and read a
 * response.
 */
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import type * as HttpClientRequest from "effect/http/HttpClientRequest";
import { CredentialSourceError } from "./credential-source.ts";
/**
 * Run `effect` with the fiber's `HttpClient` when one is in scope (an
 * operation always has one), else with the platform `fetch` client. This
 * keeps every credentials layer free of requirements while still letting a
 * caller inject a client, e.g. in tests.
 */
export declare const withHttpClient: <A, E>(effect: Effect.Effect<A, E, HttpClient.HttpClient>) => Effect.Effect<A, E>;
interface TextResponse {
    readonly status: number;
    readonly text: string;
}
/**
 * Execute a request and read the whole body. Non-2xx statuses are returned,
 * not failed, because IMDS in particular branches on them.
 */
export declare const requestText: (request: HttpClientRequest.HttpClientRequest, timeoutMs: number) => Effect.Effect<TextResponse, CredentialSourceError>;
export {};
//# sourceMappingURL=http-client.d.ts.map