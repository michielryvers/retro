import { type CredentialSource } from "./credential-source.ts";
import { type FromIniOptions } from "./from-ini.ts";
export declare const nodeProviderChainSource: (options?: FromIniOptions) => CredentialSource;
/**
 * The default Node chain: the environment, the shared config and
 * credentials files, `credential_process`, the web identity token file,
 * then the container or instance metadata endpoints.
 */
export declare const fromChain: (options?: FromIniOptions) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
/** {@link fromChain}, under the name the AWS SDK gives it. */
export { fromChain as fromNodeProviderChain };
//# sourceMappingURL=from-node-provider-chain.d.ts.map