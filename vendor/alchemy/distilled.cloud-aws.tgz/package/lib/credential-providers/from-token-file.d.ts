import { type CredentialSource } from "./credential-source.ts";
export interface FromTokenFileOptions {
    readonly webIdentityTokenFile?: string;
    readonly roleArn?: string;
    readonly roleSessionName?: string;
    /** Region to call STS in; defaults per {@link profileStsRegion}. */
    readonly region?: string;
    readonly profile?: string;
}
/**
 * Credentials from `sts:AssumeRoleWithWebIdentity` with the token in
 * `AWS_WEB_IDENTITY_TOKEN_FILE` and the role in `AWS_ROLE_ARN` (or the
 * options).
 */
export declare const tokenFileSource: (options?: FromTokenFileOptions) => CredentialSource;
/**
 * `sts:AssumeRoleWithWebIdentity` with the token in
 * `AWS_WEB_IDENTITY_TOKEN_FILE`, as on EKS with IAM roles for service
 * accounts.
 */
export declare const fromTokenFile: (options?: FromTokenFileOptions) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-token-file.d.ts.map