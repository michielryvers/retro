import * as Effect from "effect/Effect";
import { type CredentialSource } from "./credential-source.ts";
export declare const ENV_CMDS_FULL_URI = "AWS_CONTAINER_CREDENTIALS_FULL_URI";
export declare const ENV_CMDS_RELATIVE_URI = "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI";
export declare const ENV_CMDS_AUTH_TOKEN = "AWS_CONTAINER_AUTHORIZATION_TOKEN";
export declare const DEFAULT_LINK_LOCAL_HOST = "http://169.254.170.2";
export interface FromHttpOptions {
    /**
     * Reads `AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE`. Supplied by the Node
     * entry point; without it a token file cannot be used.
     */
    readonly readFile?: (path: string) => Effect.Effect<string, unknown>;
    readonly timeout?: number;
    readonly maxRetries?: number;
}
/**
 * Credentials from the endpoint named by
 * `AWS_CONTAINER_CREDENTIALS_RELATIVE_URI` (resolved against the ECS
 * link-local host) or `AWS_CONTAINER_CREDENTIALS_FULL_URI`, optionally with
 * an `Authorization` token from `AWS_CONTAINER_AUTHORIZATION_TOKEN[_FILE]`.
 */
export declare const httpSource: (options?: FromHttpOptions) => CredentialSource;
/**
 * The endpoint named by `AWS_CONTAINER_CREDENTIALS_RELATIVE_URI` or
 * `AWS_CONTAINER_CREDENTIALS_FULL_URI` (ECS, EKS pod identity, local
 * credential agents).
 */
export declare const fromHttp: (options?: FromHttpOptions) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-http.d.ts.map