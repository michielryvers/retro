import { type CredentialSource } from "./credential-source.ts";
/**
 * The container credential endpoint (`AWS_CONTAINER_CREDENTIALS_*`). Differs
 * from `fromHttp` in accepting only the link-local or loopback hosts,
 * reading the token from the environment only, and not retrying by default.
 */
export declare const containerMetadataSource: (options?: {
    timeout?: number;
    maxRetries?: number;
}) => CredentialSource;
/** The container credential endpoint, as the ECS agent serves it. */
export declare const fromContainerMetadata: (options?: {
    timeout?: number;
    maxRetries?: number;
}) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-container-metadata.d.ts.map