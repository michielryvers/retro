import * as Effect from "effect/Effect";
/**
 * The credentials document the container, HTTP and instance metadata
 * endpoints all return, and the GET that fetches it.
 */
import type { AwsCredentialIdentity } from "../credentials-service.ts";
import { type CredentialSource, CredentialSourceError } from "./credential-source.ts";
export declare const DEFAULT_TIMEOUT_MS = 1000;
export declare const parseImdsCredentials: (text: string) => Effect.Effect<AwsCredentialIdentity, CredentialSourceError>;
/** One GET against a credential endpoint, with the response parsed. */
export declare const getHttpCredentials: (url: URL, authorization: string | undefined, timeoutMs: number) => CredentialSource;
//# sourceMappingURL=metadata-credentials.d.ts.map