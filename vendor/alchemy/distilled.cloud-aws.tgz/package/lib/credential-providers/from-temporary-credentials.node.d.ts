import type { CredentialSource } from "./credential-source.ts";
import { type FromTemporaryCredentialsOptions } from "./from-temporary-credentials.ts";
export declare const temporaryCredentialsSource: (options: FromTemporaryCredentialsOptions) => CredentialSource;
/**
 * A role assumed with another set of credentials, using the full Node
 * chain as the credentials that call `sts:AssumeRole`.
 */
export declare const fromTemporaryCredentials: (options: FromTemporaryCredentialsOptions) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-temporary-credentials.node.d.ts.map