import { type Logins } from "./cognito-identity.ts";
import type { CredentialSource } from "./credential-source.ts";
export interface FromCognitoIdentityOptions {
    readonly identityId: string;
    readonly logins?: Logins;
    readonly customRoleArn?: string;
    /** Region to call Cognito in; defaults to the identity id's prefix. */
    readonly region?: string;
}
export declare const cognitoIdentitySource: (options: FromCognitoIdentityOptions) => CredentialSource;
/** Credentials for a Cognito identity whose id the caller already has. */
export declare const fromCognitoIdentity: (options: FromCognitoIdentityOptions) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-cognito-identity.d.ts.map