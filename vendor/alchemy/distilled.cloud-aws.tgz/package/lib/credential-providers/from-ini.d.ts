import { type CredentialSource } from "./credential-source.ts";
import { type MfaCodeProvider } from "./sts.ts";
export interface FromIniOptions {
    readonly profile?: string;
    /** Answers an `mfa_serial` prompt; without one, MFA profiles fail. */
    readonly mfaCodeProvider?: MfaCodeProvider;
}
/**
 * Credentials from the shared config and credentials files: static keys,
 * `role_arn` + `source_profile` / `credential_source` (assumed through
 * STS), `web_identity_token_file`, `credential_process`, `aws login`
 * console sessions (`login_session`), and SSO profiles.
 */
export declare const iniSource: (options?: FromIniOptions) => CredentialSource;
/** The shared config and credentials files. */
export declare const fromIni: (options?: FromIniOptions) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-ini.d.ts.map