import * as Layer from "effect/Layer";
import { Auth } from "../auth.ts";
import { Credentials } from "../credentials-service.ts";
/**
 * Create a lazy, cached SSO credentials provider.
 * SSO credential resolution is deferred until the Effect is run,
 * and credentials are cached until they expire.
 */
export declare const fromSSO: (profileName?: string) => Layer.Layer<Credentials, never, Auth>;
//# sourceMappingURL=from-sso.d.ts.map