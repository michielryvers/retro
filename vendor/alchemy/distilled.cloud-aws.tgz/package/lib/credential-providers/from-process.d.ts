import { type CredentialSource } from "./credential-source.ts";
import { type Profiles } from "./profile.ts";
/** The `credential_process` of an already-loaded profile, for `fromIni`. */
export declare const resolveProcessCredentials: (profileName: string, profiles: Profiles) => CredentialSource;
export declare const processSource: (options?: {
    profile?: string;
}) => CredentialSource;
/** The profile's `credential_process` command. */
export declare const fromProcess: (options?: {
    profile?: string;
}) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-process.d.ts.map