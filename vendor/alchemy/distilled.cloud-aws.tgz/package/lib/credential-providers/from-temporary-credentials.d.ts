import type { CredentialSource } from "./credential-source.ts";
import { type AssumeRoleParams, type MfaCodeProvider } from "./sts.ts";
export interface FromTemporaryCredentialsOptions {
    /** `sts:AssumeRole` input; `RoleSessionName` is generated when omitted. */
    readonly params: Omit<AssumeRoleParams, "RoleSessionName"> & {
        RoleSessionName?: string;
    };
    /**
     * The credentials that call `sts:AssumeRole`. Defaults to the
     * environment; the Node build defaults to the full provider chain.
     */
    readonly masterCredentials?: CredentialSource;
    /** Region to call STS in; defaults per {@link stsRegion}. */
    readonly region?: string;
    readonly mfaCodeProvider?: MfaCodeProvider;
}
/**
 * Credentials for a role assumed with another set of credentials, the
 * programmatic form of a `role_arn` + `source_profile` profile.
 */
export declare const temporaryCredentialsSource: (options: FromTemporaryCredentialsOptions) => CredentialSource;
/** A role assumed with another set of credentials. */
export declare const fromTemporaryCredentials: (options: FromTemporaryCredentialsOptions) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-temporary-credentials.d.ts.map