/**
 * A minimal Node `FileSystem` -- just what the Node providers and `Auth`
 * read and write under `~/.aws`.
 */
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as PlatformError from "effect/PlatformError";
export declare const nodeFileSystem: FileSystem.FileSystem;
export declare const readFileString: (path: string) => Effect.Effect<string, PlatformError.PlatformError, never>;
//# sourceMappingURL=node-file-system.d.ts.map