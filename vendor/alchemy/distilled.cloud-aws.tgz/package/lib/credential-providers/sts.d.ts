import * as Effect from "effect/Effect";
/**
 * The STS calls the credential providers make: `sts:AssumeRole` and
 * `sts:AssumeRoleWithWebIdentity`, the region they are made in, and the MFA
 * prompt some roles require.
 *
 * Nothing here touches the file system or a child process, so these work in
 * the browser as well as in Node. The generated `sts` service is imported on
 * first use so an application that never assumes a role never pays for it.
 */
import type { AwsCredentialIdentity } from "../credentials-service.ts";
import * as Region from "../region.ts";
import type { AssumeRoleRequest, AssumeRoleWithWebIdentityRequest } from "../services/sts.ts";
import { type CredentialSource, CredentialSourceError } from "./credential-source.ts";
/**
 * The region STS is called in: the explicit one, else the environment, else
 * `fallback` (the profile's `region` in the Node build), else `us-east-1` --
 * the order of the SDK's `stsRegionDefaultResolver`.
 */
export declare const stsRegion: <E = never>(region: string | undefined, fallback?: Effect.Effect<string | undefined, E>) => Effect.Effect<Region.RegionName, E>;
export type AssumeRoleParams = AssumeRoleRequest;
/** `sts:AssumeRole`, signed with `sourceCredentials`. */
export declare const assumeRole: (sourceCredentials: AwsCredentialIdentity, params: AssumeRoleParams, region: Region.RegionName) => CredentialSource;
export type AssumeRoleWithWebIdentityParams = AssumeRoleWithWebIdentityRequest;
/**
 * `sts:AssumeRoleWithWebIdentity`. The call is unsigned, but the generated
 * operation still requires a `Credentials` service, so a placeholder
 * identity is supplied; only its region is used.
 */
export declare const assumeRoleWithWebIdentity: (params: AssumeRoleWithWebIdentityParams, region: Region.RegionName) => CredentialSource;
/** Answers an `mfa_serial` / `SerialNumber` prompt. */
export type MfaCodeProvider = (mfaSerial: string) => Effect.Effect<string, unknown>;
/**
 * The `TokenCode` for a role that requires MFA. Without a code provider the
 * failure is final: there is no other source that could answer the prompt.
 */
export declare const mfaCode: (mfaSerial: string, subject: string, mfaCodeProvider: MfaCodeProvider | undefined) => Effect.Effect<string, CredentialSourceError>;
//# sourceMappingURL=sts.d.ts.map