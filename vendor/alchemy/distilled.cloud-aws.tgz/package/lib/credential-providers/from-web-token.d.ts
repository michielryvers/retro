import { type CredentialSource, type Secret } from "./credential-source.ts";
import { type AssumeRoleWithWebIdentityParams } from "./sts.ts";
export interface FromWebTokenOptions {
    readonly roleArn: string;
    /**
     * The OIDC or OAuth token. Pass an `Effect` for a token that has to be
     * fetched or refreshed; it runs on every credential resolution.
     */
    readonly webIdentityToken: Secret;
    readonly roleSessionName?: string;
    readonly providerId?: string;
    readonly policyArns?: AssumeRoleWithWebIdentityParams["PolicyArns"];
    readonly policy?: string;
    readonly durationSeconds?: number;
    /** Region to call STS in; defaults per {@link stsRegion}. */
    readonly region?: string;
}
/**
 * Credentials for a role assumed with an OIDC or OAuth token the caller
 * already holds -- the same exchange `fromTokenFile` performs, without the
 * token having to come from a file.
 */
export declare const webTokenSource: (options: FromWebTokenOptions) => CredentialSource;
/** A role assumed with an OIDC or OAuth token the caller already holds. */
export declare const fromWebToken: (options: FromWebTokenOptions) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-web-token.d.ts.map