/**
 * Credentials for an Amazon Cognito identity pool, which mints the identity
 * id before exchanging it for credentials.
 */
import * as Effect from "effect/Effect";
import { type Logins } from "./cognito-identity.ts";
import { type CredentialSource } from "./credential-source.ts";
/**
 * Where the identity id minted for a pool is kept between resolutions.
 * `localStorage` when the runtime has it (as the SDK does in the browser),
 * else a map for the life of the process.
 */
export interface IdentityIdCache {
    readonly get: (key: string) => Effect.Effect<string | undefined>;
    readonly set: (key: string, value: string) => Effect.Effect<void>;
    readonly remove: (key: string) => Effect.Effect<void>;
}
export declare const defaultIdentityIdCache: IdentityIdCache;
export interface FromCognitoIdentityPoolOptions {
    readonly identityPoolId: string;
    readonly logins?: Logins;
    readonly customRoleArn?: string;
    /** The account that owns the pool, for `GetId`. */
    readonly accountId?: string;
    /**
     * Distinguishes cached identity ids for several users of one pool.
     * Defaults to `ANONYMOUS` when there are no logins, as the SDK does.
     */
    readonly userIdentifier?: string;
    readonly cache?: IdentityIdCache;
    /** Region to call Cognito in; defaults to the pool id's prefix. */
    readonly region?: string;
}
/**
 * Credentials for an identity pool: `GetId` for the identity id, then
 * `GetCredentialsForIdentity`. The identity id is cached, and a cached id
 * the pool no longer knows is discarded and re-fetched once.
 */
export declare const cognitoIdentityPoolSource: (options: FromCognitoIdentityPoolOptions) => CredentialSource;
/** Credentials for a Cognito identity pool, minting the identity id first. */
export declare const fromCognitoIdentityPool: (options: FromCognitoIdentityPoolOptions) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-cognito-identity-pool.d.ts.map