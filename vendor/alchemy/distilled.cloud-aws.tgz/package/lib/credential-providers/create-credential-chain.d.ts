import { type CredentialSource } from "./credential-source.ts";
/**
 * Try each source in turn, as `createCredentialChain` does: the first one
 * to resolve wins, and a source whose failure is final (an MFA prompt that
 * cannot be answered, say) stops the chain there.
 */
export declare const createCredentialChain: (...sources: ReadonlyArray<CredentialSource>) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
/** {@link createCredentialChain}, under the AWS SDK's other name for it. */
export { createCredentialChain as propertyProviderChain };
//# sourceMappingURL=create-credential-chain.d.ts.map