import * as Effect from "effect/Effect";
import * as Redacted from "effect/Redacted";
import { Credentials } from "../credentials-service.ts";
import * as Region from "../region.ts";
import { type CredentialSource, CredentialSourceError, type Secret } from "./credential-source.ts";
/**
 * A login token per provider, e.g.
 * `{ "accounts.google.com": idToken }`. An `Effect` is re-run on every
 * credential resolution, for a token that has to be refreshed.
 */
export type Logins = Readonly<Record<string, Secret>>;
export declare const resolveLogins: (logins: Logins | undefined) => Effect.Effect<Record<string, Redacted.Redacted<string>> | undefined, CredentialSourceError>;
/**
 * Identity pool ids and identity ids are both `<region>:<uuid>`, so the
 * region to call Cognito in is normally right there in the id.
 */
export declare const regionFromId: (identifier: string) => Region.RegionName | undefined;
export declare const cognitoRegion: (region: string | undefined, identifier: string) => Effect.Effect<Region.RegionName, CredentialSourceError>;
export declare const cognitoFailure: (cause: unknown) => CredentialSourceError;
export declare const unsigned: (region: Region.RegionName) => <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Credentials>>;
/** `cognito-identity:GetCredentialsForIdentity` for a known identity id. */
export declare const getCredentialsForIdentity: (identityId: string, region: Region.RegionName, options: {
    readonly logins?: Logins;
    readonly customRoleArn?: string;
}) => CredentialSource;
//# sourceMappingURL=cognito-identity.d.ts.map