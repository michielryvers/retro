import type { CredentialSource } from "./credential-source.ts";
export declare const httpSource: (options?: {
    timeout?: number;
    maxRetries?: number;
}) => CredentialSource;
/**
 * The endpoint named by `AWS_CONTAINER_CREDENTIALS_RELATIVE_URI` or
 * `AWS_CONTAINER_CREDENTIALS_FULL_URI`, plus the token file on disk.
 */
export declare const fromHttp: (options?: {
    timeout?: number;
    maxRetries?: number;
}) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-http.node.d.ts.map