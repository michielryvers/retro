import type { CredentialSource } from "./credential-source.ts";
import { type FromInstanceMetadataOptions } from "./from-instance-metadata.ts";
type Options = Omit<FromInstanceMetadataOptions, "profileConfig"> & {
    profile?: string;
};
export declare const instanceMetadataSource: (options?: Options) => CredentialSource;
/**
 * The EC2 instance role, from the instance metadata service, with the
 * profile's IMDS settings.
 */
export declare const fromInstanceMetadata: (options?: Options) => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
export {};
//# sourceMappingURL=from-instance-metadata.node.d.ts.map