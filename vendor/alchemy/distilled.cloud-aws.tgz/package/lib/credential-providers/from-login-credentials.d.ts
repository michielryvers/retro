import { Credentials } from "../credentials-service.ts";
import { type CredentialSource } from "./credential-source.ts";
export interface FromLoginCredentialsOptions {
    readonly profile?: string;
    /**
     * Region the signin service is called in. Defaults to the profile's
     * `region`, else the environment, else `us-east-1`.
     */
    readonly region?: string;
}
/**
 * Credentials from the token `aws login` cached for the profile's
 * `login_session`, renewed through the signin service when they are within
 * five minutes of expiring.
 */
export declare const loginCredentialsSource: (options?: FromLoginCredentialsOptions) => CredentialSource;
/** The token `aws login` cached for the profile's `login_session`. */
export declare const fromLoginCredentials: (options?: FromLoginCredentialsOptions) => import("effect/Layer").Layer<Credentials, never, never>;
//# sourceMappingURL=from-login-credentials.d.ts.map