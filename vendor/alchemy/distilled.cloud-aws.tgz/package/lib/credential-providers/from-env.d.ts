import { type CredentialSource } from "./credential-source.ts";
export declare const ENV_KEY = "AWS_ACCESS_KEY_ID";
export declare const ENV_SECRET = "AWS_SECRET_ACCESS_KEY";
/** `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` and friends. */
export declare const envSource: CredentialSource;
/** `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` and friends. */
export declare const fromEnv: () => import("effect/Layer").Layer<import("../credentials-service.ts").Credentials, never, never>;
//# sourceMappingURL=from-env.d.ts.map