/**
 * MD5 checksum implementation using Node.js crypto module.
 */
import type { Checksum } from "./checksum.ts";
export declare const getMd5ChecksumAlgorithmFunction: () => new () => Checksum;
//# sourceMappingURL=md5.d.ts.map