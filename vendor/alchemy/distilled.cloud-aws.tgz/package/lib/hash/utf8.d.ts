/**
 * UTF-8 and buffer conversion utilities.
 */
export declare function toUint8Array(data: string | ArrayBuffer | ArrayBufferView): Uint8Array;
export declare function fromUtf8(input: string): Uint8Array;
export declare function fromArrayBuffer(input: ArrayBuffer): Buffer;
export declare function fromString(input: string, encoding?: BufferEncoding): Buffer;
export declare function isArrayBuffer(input: unknown): input is ArrayBuffer;
//# sourceMappingURL=utf8.d.ts.map