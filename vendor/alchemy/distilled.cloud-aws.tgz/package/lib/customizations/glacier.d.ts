/**
 * Amazon Glacier Customizations
 *
 * https://smithy.io/2.0/aws/customizations/glacier-customizations.html
 *
 * 1. X-Amz-Glacier-Version header: MUST be set to the service version for all requests
 * 2. Default accountId: "-" indicates the account making the request should be used
 * 3. Checksum headers: UploadArchive and UploadMultipartPart MUST set
 *    X-Amz-Content-Sha256 and X-Amz-Sha256-Tree-Hash headers
 */
import type { Request } from "../client/request.ts";
/**
 * Apply Glacier-specific customizations to a request.
 *
 * - Sets X-Amz-Glacier-Version header to the service version
 *
 * @param request - The request to customize
 * @param serviceVersion - The Glacier service version (e.g., "2012-06-01")
 * @returns The request with Glacier customizations applied
 */
export declare function applyGlacierCustomizations(request: Request, serviceVersion: string): Request;
/**
 * Check if a service is Amazon Glacier based on its SDK ID.
 *
 * @param sdkId - The SDK ID from the aws.api#service trait
 * @returns true if the service is Glacier
 */
export declare function isGlacier(sdkId: string | undefined): boolean;
/**
 * The default accountId value for Glacier operations.
 *
 * The string "-" indicates that the account making the request should be used.
 * This is what customers usually want, so clients should use this by default.
 */
export declare const DEFAULT_GLACIER_ACCOUNT_ID = "-";
/**
 * Check if an operation requires checksum headers.
 * UploadArchive and UploadMultipartPart operations require:
 * - X-Amz-Content-Sha256
 * - X-Amz-Sha256-Tree-Hash
 *
 * @param operationName - The name of the operation
 * @returns true if the operation requires checksum headers
 */
export declare function requiresGlacierChecksums(operationName: string): boolean;
/**
 * Compute SHA256 hash of data.
 *
 * @param data - The data to hash
 * @returns Hex-encoded SHA256 hash
 */
export declare function computeSha256(data: Uint8Array | string): Promise<string>;
/**
 * Compute SHA256 tree hash for Glacier.
 *
 * The tree hash is computed by:
 * 1. Breaking the data into 1 MB chunks
 * 2. Computing SHA256 of each chunk
 * 3. Combining hashes pairwise up the tree
 *
 * See: https://docs.aws.amazon.com/amazonglacier/latest/dev/checksum-calculations.html
 *
 * @param data - The data to compute the tree hash for
 * @returns Hex-encoded SHA256 tree hash
 */
export declare function computeTreeHash(data: Uint8Array | string): Promise<string>;
/**
 * Apply Glacier checksum headers to a request.
 *
 * For UploadArchive and UploadMultipartPart operations, this computes and sets:
 * - X-Amz-Content-Sha256: SHA256 hash of the body
 * - X-Amz-Sha256-Tree-Hash: SHA256 tree hash of the body
 *
 * Note: This only works with string/Uint8Array bodies, not streams.
 * For streaming uploads, the caller must compute and provide these values.
 *
 * @param request - The request to add checksum headers to
 * @returns The request with checksum headers added
 */
export declare function applyGlacierChecksums(request: Request): Promise<Request>;
//# sourceMappingURL=glacier.d.ts.map