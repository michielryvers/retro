/**
 * Amazon API Gateway service customization.
 * Adds Accept: application/json header on all requests.
 */
import type { Request } from "../client/request.ts";
/**
 * Check if a service is API Gateway by its SDK ID.
 */
export declare const isApiGateway: (sdkId: string | undefined) => boolean;
/**
 * Apply API Gateway-specific customizations to a request.
 * Sets the Accept header to application/json.
 */
export declare const applyApiGatewayCustomizations: (request: Request) => Request;
//# sourceMappingURL=api-gateway.d.ts.map