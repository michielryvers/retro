/**
 * distilled trait - marks the member of an error shape that carries the
 * service's human-readable failure text.
 *
 * AWS spells this member inconsistently across services (`message` in most,
 * `Message` in the XML-era ones) and omits it entirely from some models --
 * every ec2 error shape declares no members at all. Without a marker the
 * response parser has to guess by spelling, and a shape that declares no
 * message member at all silently drops the text on decode, leaving callers a
 * typed error with nothing in it (distilled #160).
 *
 * The generator guarantees exactly one tagged member per error class and
 * normalizes its name to `message`, so `Error.message` is always the real
 * message and consumers never have to know which spelling a service used.
 */
export declare const errorMessageSymbol: "distilled-aws/error-message";
export declare const ErrorMessage: () => import("@distilled.cloud/core/trait").Annotation;
//# sourceMappingURL=error-message.d.ts.map