/**
 * AWS value types on lite schemas: timestamps, blobs and sensitive values.
 *
 * A generated AWS schema is a tree of lite nodes (`@distilled.cloud/core/schema-lite`).
 * Most values cross the wire unchanged. These ones do not, so their node
 * carries a {@link codecSymbol} annotation naming the conversion, and an
 * `encoding` link to the wire-side node (the shape of Effect's encoding
 * chain, which the protocol helpers in `util/ast.ts` follow to find the wire
 * type). `util/codec.ts` applies the conversions.
 *
 * Kept free of `traits.ts` imports: `sensitive.ts` and `errors.ts` use it,
 * and the protocols import those.
 */
import { type Lite } from "@distilled.cloud/core/schema-lite-impl";
/** Annotation naming how a value converts between the wire and the type. */
export declare const codecSymbol: "distilled-aws/codec";
/**
 * - `epoch-seconds`: Date <-> number of seconds
 * - `http-date`: Date <-> RFC 7231 string
 * - `date-string`: Date <-> ISO 8601 string
 * - `blob`: Uint8Array <-> base64 string
 * - `sensitive`: Redacted <-> the value of `encoding[0].to`
 */
export type CodecKind = "epoch-seconds" | "http-date" | "date-string" | "blob" | "sensitive";
export declare const isValidDate: (u: unknown) => u is Date;
/** A timestamp sent as `kind` on the wire. */
export declare const timestamp: (kind: "epoch-seconds" | "http-date" | "date-string", annotations?: Record<string, unknown>) => Lite;
/** Binary data sent as base64 (smithy blob without @streaming). */
export declare const blob: (annotations?: Record<string, unknown>) => Lite;
/**
 * A value sent as `schema` on the wire and held as `Redacted` in responses.
 * Requests accept the plain value or a `Redacted` one.
 */
export declare const sensitive: (schema: Lite, identifier: string) => Lite;
//# sourceMappingURL=lite.d.ts.map