import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type BlueprintArn = string;
export type BlueprintStage = "DEVELOPMENT" | "LIVE" | (string & {});
export type ClientToken = string;
export interface CopyBlueprintStageRequest {
    blueprintArn: string;
    sourceStage: BlueprintStage;
    targetStage: BlueprintStage;
    clientToken?: string;
}
export interface CopyBlueprintStageResponse {
}
export type BlueprintName = string | redacted.Redacted<string>;
export type Type = "DOCUMENT" | "IMAGE" | "AUDIO" | "VIDEO" | (string & {});
export type BlueprintSchema = string | redacted.Redacted<string>;
export type KmsKeyId = string;
export type EncryptionContextKey = string;
export type EncryptionContextValue = string;
export type KmsEncryptionContext = {
    [key: string]: string | undefined;
};
export interface EncryptionConfiguration {
    kmsKeyId: string;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    };
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface CreateBlueprintRequest {
    blueprintName: string | redacted.Redacted<string>;
    type: Type;
    blueprintStage?: BlueprintStage;
    schema: string | redacted.Redacted<string>;
    clientToken?: string;
    encryptionConfiguration?: EncryptionConfiguration;
    tags?: Tag[];
}
export type BlueprintVersion = string;
export type S3Uri = string;
export type S3ObjectVersion = string;
export interface S3Object {
    s3Uri: string;
    version?: string;
}
export interface BlueprintOptimizationSample {
    assetS3Object: S3Object;
    groundTruthS3Object: S3Object;
}
export type BlueprintOptimizationSamples = BlueprintOptimizationSample[];
export interface Blueprint {
    blueprintArn: string;
    schema: string | redacted.Redacted<string>;
    type: Type;
    creationTime: Date;
    lastModifiedTime: Date;
    blueprintName: string | redacted.Redacted<string>;
    blueprintVersion?: string;
    blueprintStage?: BlueprintStage;
    kmsKeyId?: string;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    };
    optimizationSamples?: BlueprintOptimizationSample[];
    optimizationTime?: Date;
}
export interface CreateBlueprintResponse {
    blueprint: Blueprint;
}
export interface CreateBlueprintVersionRequest {
    blueprintArn: string;
    clientToken?: string;
}
export interface CreateBlueprintVersionResponse {
    blueprint: Blueprint;
}
export type DataAutomationLibraryName = string | redacted.Redacted<string>;
export type DataAutomationLibraryDescription = string | redacted.Redacted<string>;
export interface CreateDataAutomationLibraryRequest {
    libraryName: string | redacted.Redacted<string>;
    libraryDescription?: string | redacted.Redacted<string>;
    clientToken?: string;
    encryptionConfiguration?: EncryptionConfiguration;
    tags?: Tag[];
}
export type DataAutomationLibraryArn = string;
export type DataAutomationLibraryStatus = "ACTIVE" | "DELETING" | (string & {});
export interface CreateDataAutomationLibraryResponse {
    libraryArn?: string;
    status?: DataAutomationLibraryStatus;
}
export type DataAutomationProjectName = string | redacted.Redacted<string>;
export type DataAutomationProjectDescription = string | redacted.Redacted<string>;
export type DataAutomationProjectStage = "DEVELOPMENT" | "LIVE" | (string & {});
export type DataAutomationProjectType = "ASYNC" | "SYNC" | (string & {});
export type DocumentExtractionGranularityType = "DOCUMENT" | "PAGE" | "ELEMENT" | "WORD" | "LINE" | (string & {});
export type DocumentExtractionGranularityTypes = DocumentExtractionGranularityType[];
export interface DocumentExtractionGranularity {
    types?: DocumentExtractionGranularityType[];
}
export type State = "ENABLED" | "DISABLED" | (string & {});
export interface DocumentBoundingBox {
    state: State;
}
export interface DocumentStandardExtraction {
    granularity: DocumentExtractionGranularity;
    boundingBox: DocumentBoundingBox;
}
export interface DocumentStandardGenerativeField {
    state: State;
}
export type DocumentOutputTextFormatType = "PLAIN_TEXT" | "MARKDOWN" | "HTML" | "CSV" | (string & {});
export type DocumentOutputTextFormatTypes = DocumentOutputTextFormatType[];
export interface DocumentOutputTextFormat {
    types?: DocumentOutputTextFormatType[];
}
export interface DocumentOutputAdditionalFileFormat {
    state: State;
}
export interface DocumentOutputFormat {
    textFormat: DocumentOutputTextFormat;
    additionalFileFormat: DocumentOutputAdditionalFileFormat;
}
export interface DocumentStandardOutputConfiguration {
    extraction?: DocumentStandardExtraction;
    generativeField?: DocumentStandardGenerativeField;
    outputFormat?: DocumentOutputFormat;
}
export type ImageExtractionCategoryType = "CONTENT_MODERATION" | "TEXT_DETECTION" | "LOGOS" | (string & {});
export type ImageExtractionCategoryTypes = ImageExtractionCategoryType[];
export interface ImageExtractionCategory {
    state: State;
    types?: ImageExtractionCategoryType[];
}
export interface ImageBoundingBox {
    state: State;
}
export interface ImageStandardExtraction {
    category: ImageExtractionCategory;
    boundingBox: ImageBoundingBox;
}
export type ImageStandardGenerativeFieldType = "IMAGE_SUMMARY" | "IAB" | (string & {});
export type ImageStandardGenerativeFieldTypes = ImageStandardGenerativeFieldType[];
export interface ImageStandardGenerativeField {
    state: State;
    types?: ImageStandardGenerativeFieldType[];
}
export interface ImageStandardOutputConfiguration {
    extraction?: ImageStandardExtraction;
    generativeField?: ImageStandardGenerativeField;
}
export type VideoExtractionCategoryType = "CONTENT_MODERATION" | "TEXT_DETECTION" | "TRANSCRIPT" | "LOGOS" | (string & {});
export type VideoExtractionCategoryTypes = VideoExtractionCategoryType[];
export interface VideoExtractionCategory {
    state: State;
    types?: VideoExtractionCategoryType[];
}
export interface VideoBoundingBox {
    state: State;
}
export interface VideoStandardExtraction {
    category: VideoExtractionCategory;
    boundingBox: VideoBoundingBox;
}
export type VideoStandardGenerativeFieldType = "VIDEO_SUMMARY" | "IAB" | "CHAPTER_SUMMARY" | (string & {});
export type VideoStandardGenerativeFieldTypes = VideoStandardGenerativeFieldType[];
export interface VideoStandardGenerativeField {
    state: State;
    types?: VideoStandardGenerativeFieldType[];
}
export interface VideoStandardOutputConfiguration {
    extraction?: VideoStandardExtraction;
    generativeField?: VideoStandardGenerativeField;
}
export type AudioExtractionCategoryType = "AUDIO_CONTENT_MODERATION" | "TRANSCRIPT" | "TOPIC_CONTENT_MODERATION" | (string & {});
export type AudioExtractionCategoryTypes = AudioExtractionCategoryType[];
export interface SpeakerLabelingConfiguration {
    state: State;
}
export interface ChannelLabelingConfiguration {
    state: State;
}
export interface TranscriptConfiguration {
    speakerLabeling?: SpeakerLabelingConfiguration;
    channelLabeling?: ChannelLabelingConfiguration;
}
export interface AudioExtractionCategoryTypeConfiguration {
    transcript?: TranscriptConfiguration;
}
export interface AudioExtractionCategory {
    state: State;
    types?: AudioExtractionCategoryType[];
    typeConfiguration?: AudioExtractionCategoryTypeConfiguration;
}
export interface AudioStandardExtraction {
    category: AudioExtractionCategory;
}
export type AudioStandardGenerativeFieldType = "AUDIO_SUMMARY" | "IAB" | "TOPIC_SUMMARY" | (string & {});
export type AudioStandardGenerativeFieldTypes = AudioStandardGenerativeFieldType[];
export interface AudioStandardGenerativeField {
    state: State;
    types?: AudioStandardGenerativeFieldType[];
}
export interface AudioStandardOutputConfiguration {
    extraction?: AudioStandardExtraction;
    generativeField?: AudioStandardGenerativeField;
}
export interface StandardOutputConfiguration {
    document?: DocumentStandardOutputConfiguration;
    image?: ImageStandardOutputConfiguration;
    video?: VideoStandardOutputConfiguration;
    audio?: AudioStandardOutputConfiguration;
}
export interface BlueprintItem {
    blueprintArn: string;
    blueprintVersion?: string;
    blueprintStage?: BlueprintStage;
}
export type BlueprintItems = BlueprintItem[];
export type FallbackBlueprintItems = BlueprintItem[];
export interface DocumentCustomOutputConfiguration {
    fallbackBlueprints?: BlueprintItem[];
}
export interface CustomOutputConfiguration {
    blueprints?: BlueprintItem[];
    document?: DocumentCustomOutputConfiguration;
}
export interface SplitterConfiguration {
    state?: State;
}
export interface ModalityProcessingConfiguration {
    state?: State;
}
export type SensitiveDataDetectionMode = "DETECTION" | "DETECTION_AND_REDACTION" | (string & {});
export type SensitiveDataDetectionScopeType = "STANDARD" | "CUSTOM" | (string & {});
export type SensitiveDataDetectionScope = SensitiveDataDetectionScopeType[];
export type PIIEntityType = "ALL" | "ADDRESS" | "AGE" | "NAME" | "EMAIL" | "PHONE" | "USERNAME" | "PASSWORD" | "DRIVER_ID" | "LICENSE_PLATE" | "VEHICLE_IDENTIFICATION_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "PIN" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "SWIFT_CODE" | "IP_ADDRESS" | "MAC_ADDRESS" | "URL" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | (string & {});
export type PIIEntityTypes = PIIEntityType[];
export type PIIRedactionMaskMode = "PII" | "ENTITY_TYPE" | (string & {});
export interface PIIEntitiesConfiguration {
    piiEntityTypes?: PIIEntityType[];
    redactionMaskMode?: PIIRedactionMaskMode;
}
export interface SensitiveDataConfiguration {
    detectionMode: SensitiveDataDetectionMode;
    detectionScope?: SensitiveDataDetectionScopeType[];
    piiEntitiesConfiguration?: PIIEntitiesConfiguration;
}
export interface DocumentOverrideConfiguration {
    splitter?: SplitterConfiguration;
    modalityProcessing?: ModalityProcessingConfiguration;
    sensitiveDataConfiguration?: SensitiveDataConfiguration;
}
export interface ImageOverrideConfiguration {
    modalityProcessing?: ModalityProcessingConfiguration;
    sensitiveDataConfiguration?: SensitiveDataConfiguration;
}
export interface VideoOverrideConfiguration {
    modalityProcessing?: ModalityProcessingConfiguration;
    sensitiveDataConfiguration?: SensitiveDataConfiguration;
}
export type Language = "EN" | "DE" | "ES" | "FR" | "IT" | "PT" | "JA" | "KO" | "CN" | "TW" | "HK" | (string & {});
export type AudioInputLanguages = Language[];
export type AudioGenerativeOutputLanguage = "DEFAULT" | "EN" | (string & {});
export interface AudioLanguageConfiguration {
    inputLanguages?: Language[];
    generativeOutputLanguage?: AudioGenerativeOutputLanguage;
    identifyMultipleLanguages?: boolean;
}
export interface AudioOverrideConfiguration {
    modalityProcessing?: ModalityProcessingConfiguration;
    languageConfiguration?: AudioLanguageConfiguration;
    sensitiveDataConfiguration?: SensitiveDataConfiguration;
}
export type DesiredModality = "IMAGE" | "DOCUMENT" | "AUDIO" | "VIDEO" | (string & {});
export interface ModalityRoutingConfiguration {
    jpeg?: DesiredModality;
    png?: DesiredModality;
    mp4?: DesiredModality;
    mov?: DesiredModality;
}
export interface OverrideConfiguration {
    document?: DocumentOverrideConfiguration;
    image?: ImageOverrideConfiguration;
    video?: VideoOverrideConfiguration;
    audio?: AudioOverrideConfiguration;
    modalityRouting?: ModalityRoutingConfiguration;
}
export interface DataAutomationLibraryItem {
    libraryArn: string;
}
export type DataAutomationLibraryItems = DataAutomationLibraryItem[];
export interface DataAutomationLibraryConfiguration {
    libraries?: DataAutomationLibraryItem[];
}
export interface CreateDataAutomationProjectRequest {
    projectName: string | redacted.Redacted<string>;
    projectDescription?: string | redacted.Redacted<string>;
    projectStage?: DataAutomationProjectStage;
    projectType?: DataAutomationProjectType;
    standardOutputConfiguration: StandardOutputConfiguration;
    customOutputConfiguration?: CustomOutputConfiguration;
    overrideConfiguration?: OverrideConfiguration;
    dataAutomationLibraryConfiguration?: DataAutomationLibraryConfiguration;
    clientToken?: string;
    encryptionConfiguration?: EncryptionConfiguration;
    tags?: Tag[];
}
export type DataAutomationProjectArn = string;
export type DataAutomationProjectStatus = "COMPLETED" | "IN_PROGRESS" | "FAILED" | (string & {});
export interface CreateDataAutomationProjectResponse {
    projectArn: string;
    projectStage?: DataAutomationProjectStage;
    status?: DataAutomationProjectStatus;
}
export interface DeleteBlueprintRequest {
    blueprintArn: string;
    blueprintVersion?: string;
}
export interface DeleteBlueprintResponse {
}
export interface DeleteDataAutomationLibraryRequest {
    libraryArn: string;
}
export interface DeleteDataAutomationLibraryResponse {
    libraryArn?: string;
    status?: DataAutomationLibraryStatus;
}
export interface DeleteDataAutomationProjectRequest {
    projectArn: string;
}
export interface DeleteDataAutomationProjectResponse {
    projectArn: string;
    status?: DataAutomationProjectStatus;
}
export interface GetBlueprintRequest {
    blueprintArn: string;
    blueprintVersion?: string;
    blueprintStage?: BlueprintStage;
}
export interface GetBlueprintResponse {
    blueprint: Blueprint;
}
export type BlueprintOptimizationInvocationArn = string;
export interface GetBlueprintOptimizationStatusRequest {
    invocationArn: string;
}
export type BlueprintOptimizationJobStatus = "Created" | "InProgress" | "Success" | "ServiceError" | "ClientError" | (string & {});
export interface BlueprintOptimizationOutputConfiguration {
    s3Object: S3Object;
}
export interface GetBlueprintOptimizationStatusResponse {
    status?: BlueprintOptimizationJobStatus;
    errorType?: string;
    errorMessage?: string;
    outputConfiguration?: BlueprintOptimizationOutputConfiguration;
}
export interface GetDataAutomationLibraryRequest {
    libraryArn: string;
}
export type EntityType = "VOCABULARY" | (string & {});
export type EntityMetadata = string;
export interface EntityTypeInfo {
    entityType: EntityType;
    entityMetadata?: string;
}
export type EntityTypeInfoList = EntityTypeInfo[];
export interface DataAutomationLibrary {
    libraryArn: string;
    creationTime: Date;
    libraryName: string | redacted.Redacted<string>;
    libraryDescription?: string | redacted.Redacted<string>;
    status: DataAutomationLibraryStatus;
    entityTypes?: EntityTypeInfo[];
    kmsKeyId?: string;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    };
}
export interface GetDataAutomationLibraryResponse {
    library?: DataAutomationLibrary;
}
export type EntityId = string;
export interface GetDataAutomationLibraryEntityRequest {
    libraryArn: string;
    entityType: EntityType;
    entityId: string;
}
export type EntityDescription = string | redacted.Redacted<string>;
export type PhraseText = string | redacted.Redacted<string>;
export type PhraseDisplayAsText = string | redacted.Redacted<string>;
export interface Phrase {
    text: string | redacted.Redacted<string>;
    displayAsText?: string | redacted.Redacted<string>;
}
export type PhraseList = Phrase[];
export interface VocabularyEntity {
    entityId?: string;
    description?: string | redacted.Redacted<string>;
    language?: Language;
    phrases?: Phrase[];
    lastModifiedTime?: Date;
}
export type EntityDetails = {
    vocabulary: VocabularyEntity;
};
export interface GetDataAutomationLibraryEntityResponse {
    entity?: EntityDetails;
}
export type DataAutomationLibraryIngestionJobArn = string;
export interface GetDataAutomationLibraryIngestionJobRequest {
    libraryArn: string;
    jobArn: string;
}
export type LibraryIngestionJobOperationType = "UPSERT" | "DELETE" | (string & {});
export type LibraryIngestionJobStatus = "IN_PROGRESS" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "FAILED" | (string & {});
export interface OutputConfiguration {
    s3Uri: string;
}
export interface DataAutomationLibraryIngestionJob {
    jobArn: string;
    creationTime: Date;
    entityType: EntityType;
    operationType: LibraryIngestionJobOperationType;
    jobStatus: LibraryIngestionJobStatus;
    outputConfiguration: OutputConfiguration;
    completionTime?: Date;
    errorMessage?: string;
    errorType?: string;
}
export interface GetDataAutomationLibraryIngestionJobResponse {
    job?: DataAutomationLibraryIngestionJob;
}
export interface GetDataAutomationProjectRequest {
    projectArn: string;
    projectStage?: DataAutomationProjectStage;
}
export interface DataAutomationProject {
    projectArn: string;
    creationTime: Date;
    lastModifiedTime: Date;
    projectName: string | redacted.Redacted<string>;
    projectStage?: DataAutomationProjectStage;
    projectType?: DataAutomationProjectType;
    projectDescription?: string | redacted.Redacted<string>;
    standardOutputConfiguration?: StandardOutputConfiguration;
    customOutputConfiguration?: CustomOutputConfiguration;
    overrideConfiguration?: OverrideConfiguration;
    dataAutomationLibraryConfiguration?: DataAutomationLibraryConfiguration;
    status: DataAutomationProjectStatus;
    kmsKeyId?: string;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    };
}
export interface GetDataAutomationProjectResponse {
    project: DataAutomationProject;
}
export interface BlueprintOptimizationObject {
    blueprintArn: string;
    stage?: BlueprintStage;
}
export type DataAutomationProfileArn = string;
export interface InvokeBlueprintOptimizationAsyncRequest {
    blueprint: BlueprintOptimizationObject;
    samples: BlueprintOptimizationSample[];
    outputConfiguration: BlueprintOptimizationOutputConfiguration;
    dataAutomationProfileArn: string;
    encryptionConfiguration?: EncryptionConfiguration;
    tags?: Tag[];
}
export interface InvokeBlueprintOptimizationAsyncResponse {
    invocationArn: string;
}
export interface VocabularyEntityInfo {
    entityId?: string;
    description?: string | redacted.Redacted<string>;
    language: Language;
    phrases: Phrase[];
}
export type UpsertEntityInfo = {
    vocabulary: VocabularyEntityInfo;
};
export type UpsertEntitiesInfo = UpsertEntityInfo[];
export type EntityIdList = string[];
export interface DeleteEntitiesInfo {
    entityIds: string[];
}
export type InlinePayload = {
    upsertEntitiesInfo: UpsertEntityInfo[];
    deleteEntitiesInfo?: never;
} | {
    upsertEntitiesInfo?: never;
    deleteEntitiesInfo: DeleteEntitiesInfo;
};
export interface InputConfiguration {
    s3Object?: S3Object;
    inlinePayload?: InlinePayload;
}
export interface EventBridgeConfiguration {
    eventBridgeEnabled: boolean;
}
export interface NotificationConfiguration {
    eventBridgeConfiguration: EventBridgeConfiguration;
}
export interface InvokeDataAutomationLibraryIngestionJobRequest {
    libraryArn: string;
    clientToken?: string;
    inputConfiguration: InputConfiguration;
    entityType: EntityType;
    operationType: LibraryIngestionJobOperationType;
    outputConfiguration: OutputConfiguration;
    notificationConfiguration?: NotificationConfiguration;
    tags?: Tag[];
}
export interface InvokeDataAutomationLibraryIngestionJobResponse {
    jobArn?: string;
}
export type ResourceOwner = "SERVICE" | "ACCOUNT" | (string & {});
export type BlueprintStageFilter = "DEVELOPMENT" | "LIVE" | "ALL" | (string & {});
export type MaxResults = number;
export type NextToken = string;
export interface DataAutomationProjectFilter {
    projectArn: string;
    projectStage?: DataAutomationProjectStage;
}
export interface ListBlueprintsRequest {
    blueprintArn?: string;
    resourceOwner?: ResourceOwner;
    blueprintStageFilter?: BlueprintStageFilter;
    maxResults?: number;
    nextToken?: string;
    projectFilter?: DataAutomationProjectFilter;
}
export interface BlueprintSummary {
    blueprintArn: string;
    blueprintVersion?: string;
    blueprintStage?: BlueprintStage;
    blueprintName?: string | redacted.Redacted<string>;
    creationTime: Date;
    lastModifiedTime?: Date;
}
export type Blueprints = BlueprintSummary[];
export interface ListBlueprintsResponse {
    blueprints: BlueprintSummary[];
    nextToken?: string;
}
export interface ListDataAutomationLibrariesRequest {
    maxResults?: number;
    nextToken?: string;
    projectFilter?: DataAutomationProjectFilter;
}
export interface DataAutomationLibrarySummary {
    libraryArn: string;
    libraryName?: string | redacted.Redacted<string>;
    creationTime: Date;
}
export type DataAutomationLibrarySummaries = DataAutomationLibrarySummary[];
export interface ListDataAutomationLibrariesResponse {
    libraries?: DataAutomationLibrarySummary[];
    nextToken?: string;
}
export interface ListDataAutomationLibraryEntitiesRequest {
    libraryArn: string;
    entityType: EntityType;
    maxResults?: number;
    nextToken?: string;
}
export interface VocabularyEntitySummary {
    entityId?: string;
    description?: string | redacted.Redacted<string>;
    language?: Language;
    numOfPhrases?: number;
    lastModifiedTime?: Date;
}
export type DataAutomationLibraryEntitySummary = {
    vocabulary: VocabularyEntitySummary;
};
export type DataAutomationLibraryEntitySummaries = DataAutomationLibraryEntitySummary[];
export interface ListDataAutomationLibraryEntitiesResponse {
    entities?: DataAutomationLibraryEntitySummary[];
    nextToken?: string;
}
export interface ListDataAutomationLibraryIngestionJobsRequest {
    libraryArn: string;
    maxResults?: number;
    nextToken?: string;
}
export interface DataAutomationLibraryIngestionJobSummary {
    jobArn: string;
    jobStatus: LibraryIngestionJobStatus;
    entityType: EntityType;
    operationType: LibraryIngestionJobOperationType;
    creationTime: Date;
    completionTime?: Date;
}
export type DataAutomationLibraryIngestionJobSummaries = DataAutomationLibraryIngestionJobSummary[];
export interface ListDataAutomationLibraryIngestionJobsResponse {
    jobs?: DataAutomationLibraryIngestionJobSummary[];
    nextToken?: string;
}
export type DataAutomationProjectStageFilter = "DEVELOPMENT" | "LIVE" | "ALL" | (string & {});
export interface BlueprintFilter {
    blueprintArn: string;
    blueprintVersion?: string;
    blueprintStage?: BlueprintStage;
}
export interface DataAutomationLibraryFilter {
    libraryArn: string;
}
export interface ListDataAutomationProjectsRequest {
    maxResults?: number;
    nextToken?: string;
    projectStageFilter?: DataAutomationProjectStageFilter;
    blueprintFilter?: BlueprintFilter;
    resourceOwner?: ResourceOwner;
    libraryFilter?: DataAutomationLibraryFilter;
}
export interface DataAutomationProjectSummary {
    projectArn: string;
    projectStage?: DataAutomationProjectStage;
    projectType?: DataAutomationProjectType;
    projectName?: string | redacted.Redacted<string>;
    creationTime: Date;
}
export type DataAutomationProjectSummaries = DataAutomationProjectSummary[];
export interface ListDataAutomationProjectsResponse {
    projects: DataAutomationProjectSummary[];
    nextToken?: string;
}
export type TaggableResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceARN: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export interface TagResourceRequest {
    resourceARN: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateBlueprintRequest {
    blueprintArn: string;
    schema: string | redacted.Redacted<string>;
    blueprintStage?: BlueprintStage;
    encryptionConfiguration?: EncryptionConfiguration;
}
export interface UpdateBlueprintResponse {
    blueprint: Blueprint;
}
export interface UpdateDataAutomationLibraryRequest {
    libraryArn: string;
    libraryDescription?: string | redacted.Redacted<string>;
    clientToken?: string;
}
export interface UpdateDataAutomationLibraryResponse {
    libraryArn?: string;
    status?: DataAutomationLibraryStatus;
}
export interface UpdateDataAutomationProjectRequest {
    projectArn: string;
    projectStage?: DataAutomationProjectStage;
    projectDescription?: string | redacted.Redacted<string>;
    standardOutputConfiguration: StandardOutputConfiguration;
    customOutputConfiguration?: CustomOutputConfiguration;
    overrideConfiguration?: OverrideConfiguration;
    dataAutomationLibraryConfiguration?: DataAutomationLibraryConfiguration;
    encryptionConfiguration?: EncryptionConfiguration;
}
export interface UpdateDataAutomationProjectResponse {
    projectArn: string;
    projectStage?: DataAutomationProjectStage;
    status?: DataAutomationProjectStatus;
}
export type NonBlankString = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CopyBlueprintStageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Copies a Blueprint from one stage to another
 */
export declare const copyBlueprintStage: API.OperationMethod<CopyBlueprintStageRequest, CopyBlueprintStageResponse, CopyBlueprintStageError, Credentials | HttpClient.HttpClient>;
export type CreateBlueprintError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Bedrock Data Automation Blueprint
 */
export declare const createBlueprint: API.OperationMethod<CreateBlueprintRequest, CreateBlueprintResponse, CreateBlueprintError, Credentials | HttpClient.HttpClient>;
export type CreateBlueprintVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new version of an existing Amazon Bedrock Data Automation Blueprint
 */
export declare const createBlueprintVersion: API.OperationMethod<CreateBlueprintVersionRequest, CreateBlueprintVersionResponse, CreateBlueprintVersionError, Credentials | HttpClient.HttpClient>;
export type CreateDataAutomationLibraryError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Bedrock Data Automation Library
 */
export declare const createDataAutomationLibrary: API.OperationMethod<CreateDataAutomationLibraryRequest, CreateDataAutomationLibraryResponse, CreateDataAutomationLibraryError, Credentials | HttpClient.HttpClient>;
export type CreateDataAutomationProjectError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Bedrock Data Automation Project
 */
export declare const createDataAutomationProject: API.OperationMethod<CreateDataAutomationProjectRequest, CreateDataAutomationProjectResponse, CreateDataAutomationProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteBlueprintError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing Amazon Bedrock Data Automation Blueprint
 */
export declare const deleteBlueprint: API.OperationMethod<DeleteBlueprintRequest, DeleteBlueprintResponse, DeleteBlueprintError, Credentials | HttpClient.HttpClient>;
export type DeleteDataAutomationLibraryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing Amazon Bedrock Data Automation Library
 */
export declare const deleteDataAutomationLibrary: API.OperationMethod<DeleteDataAutomationLibraryRequest, DeleteDataAutomationLibraryResponse, DeleteDataAutomationLibraryError, Credentials | HttpClient.HttpClient>;
export type DeleteDataAutomationProjectError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing Amazon Bedrock Data Automation Project
 */
export declare const deleteDataAutomationProject: API.OperationMethod<DeleteDataAutomationProjectRequest, DeleteDataAutomationProjectResponse, DeleteDataAutomationProjectError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an existing Amazon Bedrock Data Automation Blueprint
 */
export declare const getBlueprint: API.OperationMethod<GetBlueprintRequest, GetBlueprintResponse, GetBlueprintError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintOptimizationStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * API used to get blueprint optimization status.
 */
export declare const getBlueprintOptimizationStatus: API.OperationMethod<GetBlueprintOptimizationStatusRequest, GetBlueprintOptimizationStatusResponse, GetBlueprintOptimizationStatusError, Credentials | HttpClient.HttpClient>;
export type GetDataAutomationLibraryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an existing Amazon Bedrock Data Automation Library
 */
export declare const getDataAutomationLibrary: API.OperationMethod<GetDataAutomationLibraryRequest, GetDataAutomationLibraryResponse, GetDataAutomationLibraryError, Credentials | HttpClient.HttpClient>;
export type GetDataAutomationLibraryEntityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an existing entity based on entity type from the library
 */
export declare const getDataAutomationLibraryEntity: API.OperationMethod<GetDataAutomationLibraryEntityRequest, GetDataAutomationLibraryEntityResponse, GetDataAutomationLibraryEntityError, Credentials | HttpClient.HttpClient>;
export type GetDataAutomationLibraryIngestionJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * API used to get status of data automation library ingestion job
 */
export declare const getDataAutomationLibraryIngestionJob: API.OperationMethod<GetDataAutomationLibraryIngestionJobRequest, GetDataAutomationLibraryIngestionJobResponse, GetDataAutomationLibraryIngestionJobError, Credentials | HttpClient.HttpClient>;
export type GetDataAutomationProjectError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an existing Amazon Bedrock Data Automation Project
 */
export declare const getDataAutomationProject: API.OperationMethod<GetDataAutomationProjectRequest, GetDataAutomationProjectResponse, GetDataAutomationProjectError, Credentials | HttpClient.HttpClient>;
export type InvokeBlueprintOptimizationAsyncError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invoke an async job to perform Blueprint Optimization
 */
export declare const invokeBlueprintOptimizationAsync: API.OperationMethod<InvokeBlueprintOptimizationAsyncRequest, InvokeBlueprintOptimizationAsyncResponse, InvokeBlueprintOptimizationAsyncError, Credentials | HttpClient.HttpClient>;
export type InvokeDataAutomationLibraryIngestionJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Async API: Invoke data automation library ingestion job
 */
export declare const invokeDataAutomationLibraryIngestionJob: API.OperationMethod<InvokeDataAutomationLibraryIngestionJobRequest, InvokeDataAutomationLibraryIngestionJobResponse, InvokeDataAutomationLibraryIngestionJobError, Credentials | HttpClient.HttpClient>;
export type ListBlueprintsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all existing Amazon Bedrock Data Automation Blueprints
 */
export declare const listBlueprints: API.PaginatedOperationMethod<ListBlueprintsRequest, ListBlueprintsResponse, ListBlueprintsError, Credentials | HttpClient.HttpClient, BlueprintSummary>;
export type ListDataAutomationLibrariesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all existing Amazon Bedrock Data Automation Libraries
 */
export declare const listDataAutomationLibraries: API.PaginatedOperationMethod<ListDataAutomationLibrariesRequest, ListDataAutomationLibrariesResponse, ListDataAutomationLibrariesError, Credentials | HttpClient.HttpClient, DataAutomationLibrarySummary>;
export type ListDataAutomationLibraryEntitiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all stored entities in the library
 */
export declare const listDataAutomationLibraryEntities: API.PaginatedOperationMethod<ListDataAutomationLibraryEntitiesRequest, ListDataAutomationLibraryEntitiesResponse, ListDataAutomationLibraryEntitiesError, Credentials | HttpClient.HttpClient, DataAutomationLibraryEntitySummary>;
export type ListDataAutomationLibraryIngestionJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all data automation library ingestion jobs
 */
export declare const listDataAutomationLibraryIngestionJobs: API.PaginatedOperationMethod<ListDataAutomationLibraryIngestionJobsRequest, ListDataAutomationLibraryIngestionJobsResponse, ListDataAutomationLibraryIngestionJobsError, Credentials | HttpClient.HttpClient, DataAutomationLibraryIngestionJobSummary>;
export type ListDataAutomationProjectsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all existing Amazon Bedrock Data Automation Projects
 */
export declare const listDataAutomationProjects: API.PaginatedOperationMethod<ListDataAutomationProjectsRequest, ListDataAutomationProjectsResponse, ListDataAutomationProjectsError, Credentials | HttpClient.HttpClient, DataAutomationProjectSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List tags for an Amazon Bedrock Data Automation resource
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tag an Amazon Bedrock Data Automation resource
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untag an Amazon Bedrock Data Automation resource
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBlueprintError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Bedrock Data Automation Blueprint
 */
export declare const updateBlueprint: API.OperationMethod<UpdateBlueprintRequest, UpdateBlueprintResponse, UpdateBlueprintError, Credentials | HttpClient.HttpClient>;
export type UpdateDataAutomationLibraryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Bedrock Data Automation Library
 */
export declare const updateDataAutomationLibrary: API.OperationMethod<UpdateDataAutomationLibraryRequest, UpdateDataAutomationLibraryResponse, UpdateDataAutomationLibraryError, Credentials | HttpClient.HttpClient>;
export type UpdateDataAutomationProjectError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Bedrock Data Automation Project
 */
export declare const updateDataAutomationProject: API.OperationMethod<UpdateDataAutomationProjectRequest, UpdateDataAutomationProjectResponse, UpdateDataAutomationProjectError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-data-automation.d.ts.map