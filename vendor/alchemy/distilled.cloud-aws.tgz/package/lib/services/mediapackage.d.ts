import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export interface EgressAccessLogs {
    LogGroupName?: string;
}
export interface IngressAccessLogs {
    LogGroupName?: string;
}
export interface ConfigureLogsRequest {
    EgressAccessLogs?: EgressAccessLogs;
    Id: string;
    IngressAccessLogs?: IngressAccessLogs;
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface IngestEndpoint {
    Id?: string;
    Password?: string | redacted.Redacted<string>;
    Url?: string;
    Username?: string | redacted.Redacted<string>;
}
export type __listOfIngestEndpoint = IngestEndpoint[];
export interface HlsIngest {
    IngestEndpoints?: IngestEndpoint[];
}
export type Tags = {
    [key: string]: string | undefined;
};
export interface ConfigureLogsResponse {
    Arn?: string;
    CreatedAt?: string;
    Description?: string;
    EgressAccessLogs?: EgressAccessLogs;
    HlsIngest?: HlsIngest;
    Id?: string;
    IngressAccessLogs?: IngressAccessLogs;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateChannelRequest {
    Description?: string;
    Id?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateChannelResponse {
    Arn?: string;
    CreatedAt?: string;
    Description?: string;
    EgressAccessLogs?: EgressAccessLogs;
    HlsIngest?: HlsIngest;
    Id?: string;
    IngressAccessLogs?: IngressAccessLogs;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface S3Destination {
    BucketName?: string;
    ManifestKey?: string;
    RoleArn?: string;
}
export interface CreateHarvestJobRequest {
    EndTime?: string;
    Id?: string;
    OriginEndpointId?: string;
    S3Destination?: S3Destination;
    StartTime?: string;
}
export type Status = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export interface CreateHarvestJobResponse {
    Arn?: string;
    ChannelId?: string;
    CreatedAt?: string;
    EndTime?: string;
    Id?: string;
    OriginEndpointId?: string;
    S3Destination?: S3Destination & {
        BucketName: string;
        ManifestKey: string;
        RoleArn: string;
    };
    StartTime?: string;
    Status?: Status;
}
export interface Authorization {
    CdnIdentifierSecret?: string;
    SecretsRoleArn?: string;
}
export type CmafEncryptionMethod = "SAMPLE_AES" | "AES_CTR" | (string & {});
export type PresetSpeke20Audio = "PRESET-AUDIO-1" | "PRESET-AUDIO-2" | "PRESET-AUDIO-3" | "SHARED" | "UNENCRYPTED" | (string & {});
export type PresetSpeke20Video = "PRESET-VIDEO-1" | "PRESET-VIDEO-2" | "PRESET-VIDEO-3" | "PRESET-VIDEO-4" | "PRESET-VIDEO-5" | "PRESET-VIDEO-6" | "PRESET-VIDEO-7" | "PRESET-VIDEO-8" | "SHARED" | "UNENCRYPTED" | (string & {});
export interface EncryptionContractConfiguration {
    PresetSpeke20Audio?: PresetSpeke20Audio;
    PresetSpeke20Video?: PresetSpeke20Video;
}
export type __listOf__string = string[];
export interface SpekeKeyProvider {
    CertificateArn?: string;
    EncryptionContractConfiguration?: EncryptionContractConfiguration;
    ResourceId?: string;
    RoleArn?: string;
    SystemIds?: string[];
    Url?: string;
}
export interface CmafEncryption {
    ConstantInitializationVector?: string;
    EncryptionMethod?: CmafEncryptionMethod;
    KeyRotationIntervalSeconds?: number;
    SpekeKeyProvider?: SpekeKeyProvider;
}
export type AdMarkers = "NONE" | "SCTE35_ENHANCED" | "PASSTHROUGH" | "DATERANGE" | (string & {});
export type __AdTriggersElement = "SPLICE_INSERT" | "BREAK" | "PROVIDER_ADVERTISEMENT" | "DISTRIBUTOR_ADVERTISEMENT" | "PROVIDER_PLACEMENT_OPPORTUNITY" | "DISTRIBUTOR_PLACEMENT_OPPORTUNITY" | "PROVIDER_OVERLAY_PLACEMENT_OPPORTUNITY" | "DISTRIBUTOR_OVERLAY_PLACEMENT_OPPORTUNITY" | (string & {});
export type AdTriggers = __AdTriggersElement[];
export type AdsOnDeliveryRestrictions = "NONE" | "RESTRICTED" | "UNRESTRICTED" | "BOTH" | (string & {});
export type PlaylistType = "NONE" | "EVENT" | "VOD" | (string & {});
export interface HlsManifestCreateOrUpdateParameters {
    AdMarkers?: AdMarkers;
    AdTriggers?: __AdTriggersElement[];
    AdsOnDeliveryRestrictions?: AdsOnDeliveryRestrictions;
    Id?: string;
    IncludeIframeOnlyStream?: boolean;
    ManifestName?: string;
    PlaylistType?: PlaylistType;
    PlaylistWindowSeconds?: number;
    ProgramDateTimeIntervalSeconds?: number;
}
export type __listOfHlsManifestCreateOrUpdateParameters = HlsManifestCreateOrUpdateParameters[];
export type StreamOrder = "ORIGINAL" | "VIDEO_BITRATE_ASCENDING" | "VIDEO_BITRATE_DESCENDING" | (string & {});
export interface StreamSelection {
    MaxVideoBitsPerSecond?: number;
    MinVideoBitsPerSecond?: number;
    StreamOrder?: StreamOrder;
}
export interface CmafPackageCreateOrUpdateParameters {
    Encryption?: CmafEncryption;
    HlsManifests?: HlsManifestCreateOrUpdateParameters[];
    SegmentDurationSeconds?: number;
    SegmentPrefix?: string;
    StreamSelection?: StreamSelection;
}
export interface DashEncryption {
    KeyRotationIntervalSeconds?: number;
    SpekeKeyProvider?: SpekeKeyProvider;
}
export type ManifestLayout = "FULL" | "COMPACT" | "DRM_TOP_LEVEL_COMPACT" | (string & {});
export type __PeriodTriggersElement = "ADS" | (string & {});
export type __listOf__PeriodTriggersElement = __PeriodTriggersElement[];
export type Profile = "NONE" | "HBBTV_1_5" | "HYBRIDCAST" | "DVB_DASH_2014" | (string & {});
export type SegmentTemplateFormat = "NUMBER_WITH_TIMELINE" | "TIME_WITH_TIMELINE" | "NUMBER_WITH_DURATION" | (string & {});
export type UtcTiming = "NONE" | "HTTP-HEAD" | "HTTP-ISO" | "HTTP-XSDATE" | (string & {});
export interface DashPackage {
    AdTriggers?: __AdTriggersElement[];
    AdsOnDeliveryRestrictions?: AdsOnDeliveryRestrictions;
    Encryption?: DashEncryption;
    IncludeIframeOnlyStream?: boolean;
    ManifestLayout?: ManifestLayout;
    ManifestWindowSeconds?: number;
    MinBufferTimeSeconds?: number;
    MinUpdatePeriodSeconds?: number;
    PeriodTriggers?: __PeriodTriggersElement[];
    Profile?: Profile;
    SegmentDurationSeconds?: number;
    SegmentTemplateFormat?: SegmentTemplateFormat;
    StreamSelection?: StreamSelection;
    SuggestedPresentationDelaySeconds?: number;
    UtcTiming?: UtcTiming;
    UtcTimingUri?: string;
}
export type EncryptionMethod = "AES_128" | "SAMPLE_AES" | (string & {});
export interface HlsEncryption {
    ConstantInitializationVector?: string;
    EncryptionMethod?: EncryptionMethod;
    KeyRotationIntervalSeconds?: number;
    RepeatExtXKey?: boolean;
    SpekeKeyProvider?: SpekeKeyProvider;
}
export interface HlsPackage {
    AdMarkers?: AdMarkers;
    AdTriggers?: __AdTriggersElement[];
    AdsOnDeliveryRestrictions?: AdsOnDeliveryRestrictions;
    Encryption?: HlsEncryption;
    IncludeDvbSubtitles?: boolean;
    IncludeIframeOnlyStream?: boolean;
    PlaylistType?: PlaylistType;
    PlaylistWindowSeconds?: number;
    ProgramDateTimeIntervalSeconds?: number;
    SegmentDurationSeconds?: number;
    StreamSelection?: StreamSelection;
    UseAudioRenditionGroup?: boolean;
}
export interface MssEncryption {
    SpekeKeyProvider?: SpekeKeyProvider;
}
export interface MssPackage {
    Encryption?: MssEncryption;
    ManifestWindowSeconds?: number;
    SegmentDurationSeconds?: number;
    StreamSelection?: StreamSelection;
}
export type Origination = "ALLOW" | "DENY" | (string & {});
export interface CreateOriginEndpointRequest {
    Authorization?: Authorization;
    ChannelId?: string;
    CmafPackage?: CmafPackageCreateOrUpdateParameters;
    DashPackage?: DashPackage;
    Description?: string;
    HlsPackage?: HlsPackage;
    Id?: string;
    ManifestName?: string;
    MssPackage?: MssPackage;
    Origination?: Origination;
    StartoverWindowSeconds?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    TimeDelaySeconds?: number;
    Whitelist?: string[];
}
export interface HlsManifest {
    AdMarkers?: AdMarkers;
    Id?: string;
    IncludeIframeOnlyStream?: boolean;
    ManifestName?: string;
    PlaylistType?: PlaylistType;
    PlaylistWindowSeconds?: number;
    ProgramDateTimeIntervalSeconds?: number;
    Url?: string;
    AdTriggers?: __AdTriggersElement[];
    AdsOnDeliveryRestrictions?: AdsOnDeliveryRestrictions;
}
export type __listOfHlsManifest = HlsManifest[];
export interface CmafPackage {
    Encryption?: CmafEncryption;
    HlsManifests?: HlsManifest[];
    SegmentDurationSeconds?: number;
    SegmentPrefix?: string;
    StreamSelection?: StreamSelection;
}
export interface CreateOriginEndpointResponse {
    Arn?: string;
    Authorization?: Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    };
    ChannelId?: string;
    CmafPackage?: CmafPackage & {
        Encryption: CmafEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
        HlsManifests: (HlsManifest & {
            Id: string;
        })[];
    };
    CreatedAt?: string;
    DashPackage?: DashPackage & {
        Encryption: DashEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    Description?: string;
    HlsPackage?: HlsPackage & {
        Encryption: HlsEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    Id?: string;
    ManifestName?: string;
    MssPackage?: MssPackage & {
        Encryption: MssEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    Origination?: Origination;
    StartoverWindowSeconds?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    TimeDelaySeconds?: number;
    Url?: string;
    Whitelist?: string[];
}
export interface DeleteChannelRequest {
    Id: string;
}
export interface DeleteChannelResponse {
}
export interface DeleteOriginEndpointRequest {
    Id: string;
}
export interface DeleteOriginEndpointResponse {
}
export interface DescribeChannelRequest {
    Id: string;
}
export interface DescribeChannelResponse {
    Arn?: string;
    CreatedAt?: string;
    Description?: string;
    EgressAccessLogs?: EgressAccessLogs;
    HlsIngest?: HlsIngest;
    Id?: string;
    IngressAccessLogs?: IngressAccessLogs;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeHarvestJobRequest {
    Id: string;
}
export interface DescribeHarvestJobResponse {
    Arn?: string;
    ChannelId?: string;
    CreatedAt?: string;
    EndTime?: string;
    Id?: string;
    OriginEndpointId?: string;
    S3Destination?: S3Destination & {
        BucketName: string;
        ManifestKey: string;
        RoleArn: string;
    };
    StartTime?: string;
    Status?: Status;
}
export interface DescribeOriginEndpointRequest {
    Id: string;
}
export interface DescribeOriginEndpointResponse {
    Arn?: string;
    Authorization?: Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    };
    ChannelId?: string;
    CmafPackage?: CmafPackage & {
        Encryption: CmafEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
        HlsManifests: (HlsManifest & {
            Id: string;
        })[];
    };
    CreatedAt?: string;
    DashPackage?: DashPackage & {
        Encryption: DashEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    Description?: string;
    HlsPackage?: HlsPackage & {
        Encryption: HlsEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    Id?: string;
    ManifestName?: string;
    MssPackage?: MssPackage & {
        Encryption: MssEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    Origination?: Origination;
    StartoverWindowSeconds?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    TimeDelaySeconds?: number;
    Url?: string;
    Whitelist?: string[];
}
export type MaxResults = number;
export interface ListChannelsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface Channel {
    Arn?: string;
    CreatedAt?: string;
    Description?: string;
    EgressAccessLogs?: EgressAccessLogs;
    HlsIngest?: HlsIngest;
    Id?: string;
    IngressAccessLogs?: IngressAccessLogs;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfChannel = Channel[];
export interface ListChannelsResponse {
    Channels?: Channel[];
    NextToken?: string;
}
export interface ListHarvestJobsRequest {
    IncludeChannelId?: string;
    IncludeStatus?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface HarvestJob {
    Arn?: string;
    ChannelId?: string;
    CreatedAt?: string;
    EndTime?: string;
    Id?: string;
    OriginEndpointId?: string;
    S3Destination?: S3Destination;
    StartTime?: string;
    Status?: Status;
}
export type __listOfHarvestJob = HarvestJob[];
export interface ListHarvestJobsResponse {
    HarvestJobs?: (HarvestJob & {
        S3Destination: S3Destination & {
            BucketName: string;
            ManifestKey: string;
            RoleArn: string;
        };
    })[];
    NextToken?: string;
}
export interface ListOriginEndpointsRequest {
    ChannelId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface OriginEndpoint {
    Arn?: string;
    Authorization?: Authorization;
    ChannelId?: string;
    CmafPackage?: CmafPackage;
    CreatedAt?: string;
    DashPackage?: DashPackage;
    Description?: string;
    HlsPackage?: HlsPackage;
    Id?: string;
    ManifestName?: string;
    MssPackage?: MssPackage;
    Origination?: Origination;
    StartoverWindowSeconds?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    TimeDelaySeconds?: number;
    Url?: string;
    Whitelist?: string[];
}
export type __listOfOriginEndpoint = OriginEndpoint[];
export interface ListOriginEndpointsResponse {
    NextToken?: string;
    OriginEndpoints?: (OriginEndpoint & {
        Authorization: Authorization & {
            CdnIdentifierSecret: string;
            SecretsRoleArn: string;
        };
        CmafPackage: CmafPackage & {
            Encryption: CmafEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    ResourceId: string;
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
            HlsManifests: (HlsManifest & {
                Id: string;
            })[];
        };
        DashPackage: DashPackage & {
            Encryption: DashEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    ResourceId: string;
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
        HlsPackage: HlsPackage & {
            Encryption: HlsEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    ResourceId: string;
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
        MssPackage: MssPackage & {
            Encryption: MssEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    ResourceId: string;
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
    })[];
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface RotateChannelCredentialsRequest {
    Id: string;
}
export interface RotateChannelCredentialsResponse {
    Arn?: string;
    CreatedAt?: string;
    Description?: string;
    EgressAccessLogs?: EgressAccessLogs;
    HlsIngest?: HlsIngest;
    Id?: string;
    IngressAccessLogs?: IngressAccessLogs;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface RotateIngestEndpointCredentialsRequest {
    Id: string;
    IngestEndpointId: string;
}
export interface RotateIngestEndpointCredentialsResponse {
    Arn?: string;
    CreatedAt?: string;
    Description?: string;
    EgressAccessLogs?: EgressAccessLogs;
    HlsIngest?: HlsIngest;
    Id?: string;
    IngressAccessLogs?: IngressAccessLogs;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateChannelRequest {
    Description?: string;
    Id: string;
}
export interface UpdateChannelResponse {
    Arn?: string;
    CreatedAt?: string;
    Description?: string;
    EgressAccessLogs?: EgressAccessLogs;
    HlsIngest?: HlsIngest;
    Id?: string;
    IngressAccessLogs?: IngressAccessLogs;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateOriginEndpointRequest {
    Authorization?: Authorization;
    CmafPackage?: CmafPackageCreateOrUpdateParameters;
    DashPackage?: DashPackage;
    Description?: string;
    HlsPackage?: HlsPackage;
    Id: string;
    ManifestName?: string;
    MssPackage?: MssPackage;
    Origination?: Origination;
    StartoverWindowSeconds?: number;
    TimeDelaySeconds?: number;
    Whitelist?: string[];
}
export interface UpdateOriginEndpointResponse {
    Arn?: string;
    Authorization?: Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    };
    ChannelId?: string;
    CmafPackage?: CmafPackage & {
        Encryption: CmafEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
        HlsManifests: (HlsManifest & {
            Id: string;
        })[];
    };
    CreatedAt?: string;
    DashPackage?: DashPackage & {
        Encryption: DashEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    Description?: string;
    HlsPackage?: HlsPackage & {
        Encryption: HlsEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    Id?: string;
    ManifestName?: string;
    MssPackage?: MssPackage & {
        Encryption: MssEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    Origination?: Origination;
    StartoverWindowSeconds?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    TimeDelaySeconds?: number;
    Url?: string;
    Whitelist?: string[];
}
export type ConfigureLogsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Changes the Channel's properities to configure log subscription
 */
export declare const configureLogs: API.OperationMethod<ConfigureLogsRequest, ConfigureLogsResponse, ConfigureLogsError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new Channel.
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateHarvestJobError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new HarvestJob record.
 */
export declare const createHarvestJob: API.OperationMethod<CreateHarvestJobRequest, CreateHarvestJobResponse, CreateHarvestJobError, Credentials | HttpClient.HttpClient>;
export type CreateOriginEndpointError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new OriginEndpoint record.
 */
export declare const createOriginEndpoint: API.OperationMethod<CreateOriginEndpointRequest, CreateOriginEndpointResponse, CreateOriginEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Deletes an existing Channel.
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteOriginEndpointError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Deletes an existing OriginEndpoint.
 */
export declare const deleteOriginEndpoint: API.OperationMethod<DeleteOriginEndpointRequest, DeleteOriginEndpointResponse, DeleteOriginEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeChannelError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Gets details about a Channel.
 */
export declare const describeChannel: API.OperationMethod<DescribeChannelRequest, DescribeChannelResponse, DescribeChannelError, Credentials | HttpClient.HttpClient>;
export type DescribeHarvestJobError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Gets details about an existing HarvestJob.
 */
export declare const describeHarvestJob: API.OperationMethod<DescribeHarvestJobRequest, DescribeHarvestJobResponse, DescribeHarvestJobError, Credentials | HttpClient.HttpClient>;
export type DescribeOriginEndpointError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Gets details about an existing OriginEndpoint.
 */
export declare const describeOriginEndpoint: API.OperationMethod<DescribeOriginEndpointRequest, DescribeOriginEndpointResponse, DescribeOriginEndpointError, Credentials | HttpClient.HttpClient>;
export type ListChannelsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a collection of Channels.
 */
export declare const listChannels: API.PaginatedOperationMethod<ListChannelsRequest, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient, Channel>;
export type ListHarvestJobsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a collection of HarvestJob records.
 */
export declare const listHarvestJobs: API.PaginatedOperationMethod<ListHarvestJobsRequest, ListHarvestJobsResponse, ListHarvestJobsError, Credentials | HttpClient.HttpClient, HarvestJob>;
export type ListOriginEndpointsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a collection of OriginEndpoint records.
 */
export declare const listOriginEndpoints: API.PaginatedOperationMethod<ListOriginEndpointsRequest, ListOriginEndpointsResponse, ListOriginEndpointsError, Credentials | HttpClient.HttpClient, OriginEndpoint>;
export type ListTagsForResourceError = CommonErrors;
/**
 *
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RotateChannelCredentialsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Changes the Channel's first IngestEndpoint's username and password. WARNING - This API is deprecated. Please use RotateIngestEndpointCredentials instead
 */
export declare const rotateChannelCredentials: API.OperationMethod<RotateChannelCredentialsRequest, RotateChannelCredentialsResponse, RotateChannelCredentialsError, Credentials | HttpClient.HttpClient>;
export type RotateIngestEndpointCredentialsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Rotate the IngestEndpoint's username and password, as specified by the IngestEndpoint's id.
 */
export declare const rotateIngestEndpointCredentials: API.OperationMethod<RotateIngestEndpointCredentialsRequest, RotateIngestEndpointCredentialsResponse, RotateIngestEndpointCredentialsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 *
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 *
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Updates an existing Channel.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateOriginEndpointError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Updates an existing OriginEndpoint.
 */
export declare const updateOriginEndpoint: API.OperationMethod<UpdateOriginEndpointRequest, UpdateOriginEndpointResponse, UpdateOriginEndpointError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mediapackage.d.ts.map