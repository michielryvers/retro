import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalException_base: S.TaggedErrorClass<"InternalException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidAccessException_base: S.TaggedErrorClass<"InvalidAccessException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InvalidAccessException extends /*@__PURE__*/ InvalidAccessException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const OrganizationalUnitNotFoundException_base: S.TaggedErrorClass<"OrganizationalUnitNotFoundException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OrganizationalUnitNotFoundException extends /*@__PURE__*/ OrganizationalUnitNotFoundException_base {
}
declare const OrganizationNotFoundException_base: S.TaggedErrorClass<"OrganizationNotFoundException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OrganizationNotFoundException extends /*@__PURE__*/ OrganizationNotFoundException_base {
}
declare const ResourceConflictException_base: S.TaggedErrorClass<"ResourceConflictException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type NonEmptyString = string;
export interface AcceptAdministratorInvitationRequest {
    AdministratorId?: string;
    InvitationId?: string;
}
export interface AcceptAdministratorInvitationResponse {
}
export interface AcceptInvitationRequest {
    MasterId?: string;
    InvitationId?: string;
}
export interface AcceptInvitationResponse {
}
export type AutomationRulesArnsList = string[];
export interface BatchDeleteAutomationRulesRequest {
    AutomationRulesArns?: string[];
}
export interface UnprocessedAutomationRule {
    RuleArn?: string;
    ErrorCode?: number;
    ErrorMessage?: string;
}
export type UnprocessedAutomationRulesList = UnprocessedAutomationRule[];
export interface BatchDeleteAutomationRulesResponse {
    ProcessedAutomationRules?: string[];
    UnprocessedAutomationRules?: UnprocessedAutomationRule[];
}
export type StandardsSubscriptionArns = string[];
export interface BatchDisableStandardsRequest {
    StandardsSubscriptionArns?: string[];
}
export type StandardsInputParameterMap = {
    [key: string]: string | undefined;
};
export type StandardsStatus = "PENDING" | "READY" | "FAILED" | "DELETING" | "INCOMPLETE" | (string & {});
export type StandardsControlsUpdatable = "READY_FOR_UPDATES" | "NOT_READY_FOR_UPDATES" | (string & {});
export type StatusReasonCode = "NO_AVAILABLE_CONFIGURATION_RECORDER" | "MAXIMUM_NUMBER_OF_CONFIG_RULES_EXCEEDED" | "NO_AVAILABLE_MULTICLOUD_CONNECTOR" | "INTERNAL_ERROR" | (string & {});
export interface StandardsStatusReason {
    StatusReasonCode?: StatusReasonCode;
}
export type StandardsProvider = "AWS" | "Azure" | (string & {});
export interface StandardsSubscription {
    StandardsSubscriptionArn?: string;
    StandardsArn?: string;
    StandardsInput?: {
        [key: string]: string | undefined;
    };
    StandardsStatus?: StandardsStatus;
    StandardsControlsUpdatable?: StandardsControlsUpdatable;
    StandardsStatusReason?: StandardsStatusReason;
    Provider?: StandardsProvider;
}
export type StandardsSubscriptions = StandardsSubscription[];
export interface BatchDisableStandardsResponse {
    StandardsSubscriptions?: (StandardsSubscription & {
        StandardsSubscriptionArn: NonEmptyString;
        StandardsArn: NonEmptyString;
        StandardsInput: StandardsInputParameterMap;
        StandardsStatus: StandardsStatus;
        StandardsStatusReason: StandardsStatusReason & {
            StatusReasonCode: StatusReasonCode;
        };
    })[];
}
export interface StandardsSubscriptionRequest {
    StandardsArn?: string;
    StandardsInput?: {
        [key: string]: string | undefined;
    };
}
export type StandardsSubscriptionRequests = StandardsSubscriptionRequest[];
export interface BatchEnableStandardsRequest {
    StandardsSubscriptionRequests?: StandardsSubscriptionRequest[];
}
export interface BatchEnableStandardsResponse {
    StandardsSubscriptions?: (StandardsSubscription & {
        StandardsSubscriptionArn: NonEmptyString;
        StandardsArn: NonEmptyString;
        StandardsInput: StandardsInputParameterMap;
        StandardsStatus: StandardsStatus;
        StandardsStatusReason: StandardsStatusReason & {
            StatusReasonCode: StatusReasonCode;
        };
    })[];
}
export interface BatchGetAutomationRulesRequest {
    AutomationRulesArns?: string[];
}
export type RuleStatus = "ENABLED" | "DISABLED" | (string & {});
export type RuleOrderValue = number;
export type StringFilterComparison = "EQUALS" | "PREFIX" | "NOT_EQUALS" | "PREFIX_NOT_EQUALS" | "CONTAINS" | "NOT_CONTAINS" | "CONTAINS_WORD" | (string & {});
export interface StringFilter {
    Value?: string;
    Comparison?: StringFilterComparison;
}
export type StringFilterList = StringFilter[];
export type DateRangeUnit = "DAYS" | (string & {});
export type DateRangeComparison = "WITHIN" | "OLDER_THAN" | (string & {});
export interface DateRange {
    Value?: number;
    Unit?: DateRangeUnit;
    Comparison?: DateRangeComparison;
}
export interface DateFilter {
    Start?: string;
    End?: string;
    DateRange?: DateRange;
}
export type DateFilterList = DateFilter[];
export interface NumberFilter {
    Gte?: number;
    Lte?: number;
    Eq?: number;
    Gt?: number;
    Lt?: number;
}
export type NumberFilterList = NumberFilter[];
export type MapFilterComparison = "EQUALS" | "NOT_EQUALS" | "CONTAINS" | "NOT_CONTAINS" | (string & {});
export interface MapFilter {
    Key?: string;
    Value?: string;
    Comparison?: MapFilterComparison;
}
export type MapFilterList = MapFilter[];
export interface AutomationRulesFindingFilters {
    ProductArn?: StringFilter[];
    AwsAccountId?: StringFilter[];
    Id?: StringFilter[];
    GeneratorId?: StringFilter[];
    Type?: StringFilter[];
    FirstObservedAt?: DateFilter[];
    LastObservedAt?: DateFilter[];
    CreatedAt?: DateFilter[];
    UpdatedAt?: DateFilter[];
    Confidence?: NumberFilter[];
    Criticality?: NumberFilter[];
    Title?: StringFilter[];
    Description?: StringFilter[];
    SourceUrl?: StringFilter[];
    ProductName?: StringFilter[];
    CompanyName?: StringFilter[];
    SeverityLabel?: StringFilter[];
    ResourceType?: StringFilter[];
    ResourceId?: StringFilter[];
    ResourcePartition?: StringFilter[];
    ResourceRegion?: StringFilter[];
    ResourceTags?: MapFilter[];
    ResourceDetailsOther?: MapFilter[];
    ComplianceStatus?: StringFilter[];
    ComplianceSecurityControlId?: StringFilter[];
    ComplianceAssociatedStandardsId?: StringFilter[];
    VerificationState?: StringFilter[];
    WorkflowStatus?: StringFilter[];
    RecordState?: StringFilter[];
    RelatedFindingsProductArn?: StringFilter[];
    RelatedFindingsId?: StringFilter[];
    NoteText?: StringFilter[];
    NoteUpdatedAt?: DateFilter[];
    NoteUpdatedBy?: StringFilter[];
    UserDefinedFields?: MapFilter[];
    ResourceApplicationArn?: StringFilter[];
    ResourceApplicationName?: StringFilter[];
    AwsAccountName?: StringFilter[];
    ResourceProvider?: StringFilter[];
    ResourceOwnerAccountId?: StringFilter[];
    ResourceOwnerOrgId?: StringFilter[];
}
export type AutomationRulesActionType = "FINDING_FIELDS_UPDATE" | (string & {});
export interface NoteUpdate {
    Text?: string;
    UpdatedBy?: string;
}
export type RatioScale = number;
export type SeverityLabel = "INFORMATIONAL" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | (string & {});
export interface SeverityUpdate {
    Normalized?: number;
    Product?: number;
    Label?: SeverityLabel;
}
export type VerificationState = "UNKNOWN" | "TRUE_POSITIVE" | "FALSE_POSITIVE" | "BENIGN_POSITIVE" | (string & {});
export type TypeList = string[];
export type FieldMap = {
    [key: string]: string | undefined;
};
export type WorkflowStatus = "NEW" | "NOTIFIED" | "RESOLVED" | "SUPPRESSED" | (string & {});
export interface WorkflowUpdate {
    Status?: WorkflowStatus;
}
export interface RelatedFinding {
    ProductArn?: string;
    Id?: string;
}
export type RelatedFindingList = RelatedFinding[];
export interface AutomationRulesFindingFieldsUpdate {
    Note?: NoteUpdate;
    Severity?: SeverityUpdate;
    VerificationState?: VerificationState;
    Confidence?: number;
    Criticality?: number;
    Types?: string[];
    UserDefinedFields?: {
        [key: string]: string | undefined;
    };
    Workflow?: WorkflowUpdate;
    RelatedFindings?: RelatedFinding[];
}
export interface AutomationRulesAction {
    Type?: AutomationRulesActionType;
    FindingFieldsUpdate?: AutomationRulesFindingFieldsUpdate;
}
export type ActionList = AutomationRulesAction[];
export interface AutomationRulesConfig {
    RuleArn?: string;
    RuleStatus?: RuleStatus;
    RuleOrder?: number;
    RuleName?: string;
    Description?: string;
    IsTerminal?: boolean;
    Criteria?: AutomationRulesFindingFilters;
    Actions?: AutomationRulesAction[];
    CreatedAt?: Date;
    UpdatedAt?: Date;
    CreatedBy?: string;
}
export type AutomationRulesConfigList = AutomationRulesConfig[];
export interface BatchGetAutomationRulesResponse {
    Rules?: (AutomationRulesConfig & {
        Actions: (AutomationRulesAction & {
            FindingFieldsUpdate: AutomationRulesFindingFieldsUpdate & {
                Note: NoteUpdate & {
                    Text: NonEmptyString;
                    UpdatedBy: NonEmptyString;
                };
                RelatedFindings: (RelatedFinding & {
                    ProductArn: NonEmptyString;
                    Id: NonEmptyString;
                })[];
            };
        })[];
    })[];
    UnprocessedAutomationRules?: UnprocessedAutomationRule[];
}
export type Target = {
    AccountId: string;
    OrganizationalUnitId?: never;
    RootId?: never;
} | {
    AccountId?: never;
    OrganizationalUnitId: string;
    RootId?: never;
} | {
    AccountId?: never;
    OrganizationalUnitId?: never;
    RootId: string;
};
export interface ConfigurationPolicyAssociation {
    Target?: Target;
}
export type ConfigurationPolicyAssociationsList = ConfigurationPolicyAssociation[];
export interface BatchGetConfigurationPolicyAssociationsRequest {
    ConfigurationPolicyAssociationIdentifiers?: ConfigurationPolicyAssociation[];
}
export type TargetType = "ACCOUNT" | "ORGANIZATIONAL_UNIT" | "ROOT" | (string & {});
export type AssociationType = "INHERITED" | "APPLIED" | (string & {});
export type ConfigurationPolicyAssociationStatus = "PENDING" | "SUCCESS" | "FAILED" | (string & {});
export interface ConfigurationPolicyAssociationSummary {
    ConfigurationPolicyId?: string;
    TargetId?: string;
    TargetType?: TargetType;
    AssociationType?: AssociationType;
    UpdatedAt?: Date;
    AssociationStatus?: ConfigurationPolicyAssociationStatus;
    AssociationStatusMessage?: string;
}
export type ConfigurationPolicyAssociationList = ConfigurationPolicyAssociationSummary[];
export interface UnprocessedConfigurationPolicyAssociation {
    ConfigurationPolicyAssociationIdentifiers?: ConfigurationPolicyAssociation;
    ErrorCode?: string;
    ErrorReason?: string;
}
export type UnprocessedConfigurationPolicyAssociationList = UnprocessedConfigurationPolicyAssociation[];
export interface BatchGetConfigurationPolicyAssociationsResponse {
    ConfigurationPolicyAssociations?: ConfigurationPolicyAssociationSummary[];
    UnprocessedConfigurationPolicyAssociations?: UnprocessedConfigurationPolicyAssociation[];
}
export type StringList = string[];
export interface BatchGetSecurityControlsRequest {
    SecurityControlIds?: string[];
}
export type SeverityRating = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | (string & {});
export type ControlStatus = "ENABLED" | "DISABLED" | (string & {});
export type UpdateStatus = "READY" | "UPDATING" | (string & {});
export type ParameterValueType = "DEFAULT" | "CUSTOM" | (string & {});
export type IntegerList = number[];
export type ParameterValue = {
    Integer: number;
    IntegerList?: never;
    Double?: never;
    String?: never;
    StringList?: never;
    Boolean?: never;
    Enum?: never;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList: number[];
    Double?: never;
    String?: never;
    StringList?: never;
    Boolean?: never;
    Enum?: never;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList?: never;
    Double: number;
    String?: never;
    StringList?: never;
    Boolean?: never;
    Enum?: never;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList?: never;
    Double?: never;
    String: string;
    StringList?: never;
    Boolean?: never;
    Enum?: never;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList?: never;
    Double?: never;
    String?: never;
    StringList: string[];
    Boolean?: never;
    Enum?: never;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList?: never;
    Double?: never;
    String?: never;
    StringList?: never;
    Boolean: boolean;
    Enum?: never;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList?: never;
    Double?: never;
    String?: never;
    StringList?: never;
    Boolean?: never;
    Enum: string;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList?: never;
    Double?: never;
    String?: never;
    StringList?: never;
    Boolean?: never;
    Enum?: never;
    EnumList: string[];
};
export interface ParameterConfiguration {
    ValueType?: ParameterValueType;
    Value?: ParameterValue;
}
export type Parameters = {
    [key: string]: ParameterConfiguration | undefined;
};
export type AlphaNumericNonEmptyString = string;
export type SecurityControlsProvider = "AWS" | "Azure" | (string & {});
export interface SecurityControl {
    SecurityControlId?: string;
    SecurityControlArn?: string;
    Title?: string;
    Description?: string;
    RemediationUrl?: string;
    SeverityRating?: SeverityRating;
    SecurityControlStatus?: ControlStatus;
    UpdateStatus?: UpdateStatus;
    Parameters?: {
        [key: string]: ParameterConfiguration | undefined;
    };
    LastUpdateReason?: string;
    Provider?: SecurityControlsProvider;
}
export type SecurityControls = SecurityControl[];
export type UnprocessedErrorCode = "INVALID_INPUT" | "ACCESS_DENIED" | "NOT_FOUND" | "RESOURCE_NOT_FOUND" | "LIMIT_EXCEEDED" | (string & {});
export interface UnprocessedSecurityControl {
    SecurityControlId?: string;
    ErrorCode?: UnprocessedErrorCode;
    ErrorReason?: string;
}
export type UnprocessedSecurityControls = UnprocessedSecurityControl[];
export interface BatchGetSecurityControlsResponse {
    SecurityControls: (SecurityControl & {
        SecurityControlId: NonEmptyString;
        SecurityControlArn: NonEmptyString;
        Title: NonEmptyString;
        Description: NonEmptyString;
        RemediationUrl: NonEmptyString;
        SeverityRating: SeverityRating;
        SecurityControlStatus: ControlStatus;
        Parameters: {
            [key: string]: (ParameterConfiguration & {
                ValueType: ParameterValueType;
            }) | undefined;
        };
    })[];
    UnprocessedIds?: (UnprocessedSecurityControl & {
        SecurityControlId: NonEmptyString;
        ErrorCode: UnprocessedErrorCode;
    })[];
}
export interface StandardsControlAssociationId {
    SecurityControlId?: string;
    StandardsArn?: string;
}
export type StandardsControlAssociationIds = StandardsControlAssociationId[];
export interface BatchGetStandardsControlAssociationsRequest {
    StandardsControlAssociationIds?: StandardsControlAssociationId[];
}
export type AssociationStatus = "ENABLED" | "DISABLED" | (string & {});
export type RelatedRequirementsList = string[];
export type StandardsControlArnList = string[];
export interface StandardsControlAssociationDetail {
    StandardsArn?: string;
    SecurityControlId?: string;
    SecurityControlArn?: string;
    AssociationStatus?: AssociationStatus;
    RelatedRequirements?: string[];
    UpdatedAt?: Date;
    UpdatedReason?: string;
    StandardsControlTitle?: string;
    StandardsControlDescription?: string;
    StandardsControlArns?: string[];
}
export type StandardsControlAssociationDetails = StandardsControlAssociationDetail[];
export interface UnprocessedStandardsControlAssociation {
    StandardsControlAssociationId?: StandardsControlAssociationId;
    ErrorCode?: UnprocessedErrorCode;
    ErrorReason?: string;
}
export type UnprocessedStandardsControlAssociations = UnprocessedStandardsControlAssociation[];
export interface BatchGetStandardsControlAssociationsResponse {
    StandardsControlAssociationDetails: (StandardsControlAssociationDetail & {
        StandardsArn: NonEmptyString;
        SecurityControlId: NonEmptyString;
        SecurityControlArn: NonEmptyString;
        AssociationStatus: AssociationStatus;
    })[];
    UnprocessedAssociations?: (UnprocessedStandardsControlAssociation & {
        StandardsControlAssociationId: StandardsControlAssociationId & {
            SecurityControlId: NonEmptyString;
            StandardsArn: NonEmptyString;
        };
        ErrorCode: UnprocessedErrorCode;
    })[];
}
export interface Severity {
    Product?: number;
    Label?: SeverityLabel;
    Normalized?: number;
    Original?: string;
}
export interface Recommendation {
    Text?: string;
    Url?: string;
}
export interface Remediation {
    Recommendation?: Recommendation;
}
export type MalwareType = "ADWARE" | "BLENDED_THREAT" | "BOTNET_AGENT" | "COIN_MINER" | "EXPLOIT_KIT" | "KEYLOGGER" | "MACRO" | "POTENTIALLY_UNWANTED" | "SPYWARE" | "RANSOMWARE" | "REMOTE_ACCESS" | "ROOTKIT" | "TROJAN" | "VIRUS" | "WORM" | (string & {});
export type MalwareState = "OBSERVED" | "REMOVAL_FAILED" | "REMOVED" | (string & {});
export interface Malware {
    Name?: string;
    Type?: MalwareType;
    Path?: string;
    State?: MalwareState;
}
export type MalwareList = Malware[];
export type NetworkDirection = "IN" | "OUT" | (string & {});
export interface PortRange {
    Begin?: number;
    End?: number;
}
export interface Network {
    Direction?: NetworkDirection;
    Protocol?: string;
    OpenPortRange?: PortRange;
    SourceIpV4?: string;
    SourceIpV6?: string;
    SourcePort?: number;
    SourceDomain?: string;
    SourceMac?: string;
    DestinationIpV4?: string;
    DestinationIpV6?: string;
    DestinationPort?: number;
    DestinationDomain?: string;
}
export type PortRangeList = PortRange[];
export interface NetworkPathComponentDetails {
    Address?: string[];
    PortRanges?: PortRange[];
}
export interface NetworkHeader {
    Protocol?: string;
    Destination?: NetworkPathComponentDetails;
    Source?: NetworkPathComponentDetails;
}
export interface NetworkPathComponent {
    ComponentId?: string;
    ComponentType?: string;
    Egress?: NetworkHeader;
    Ingress?: NetworkHeader;
}
export type NetworkPathList = NetworkPathComponent[];
export interface ProcessDetails {
    Name?: string;
    Path?: string;
    Pid?: number;
    ParentPid?: number;
    LaunchedAt?: string;
    TerminatedAt?: string;
}
export interface FilePaths {
    FilePath?: string;
    FileName?: string;
    ResourceId?: string;
    Hash?: string;
}
export type FilePathList = FilePaths[];
export interface Threat {
    Name?: string;
    Severity?: string;
    ItemCount?: number;
    FilePaths?: FilePaths[];
}
export type ThreatList = Threat[];
export type ThreatIntelIndicatorType = "DOMAIN" | "EMAIL_ADDRESS" | "HASH_MD5" | "HASH_SHA1" | "HASH_SHA256" | "HASH_SHA512" | "IPV4_ADDRESS" | "IPV6_ADDRESS" | "MUTEX" | "PROCESS" | "URL" | (string & {});
export type ThreatIntelIndicatorCategory = "BACKDOOR" | "CARD_STEALER" | "COMMAND_AND_CONTROL" | "DROP_SITE" | "EXPLOIT_SITE" | "KEYLOGGER" | (string & {});
export interface ThreatIntelIndicator {
    Type?: ThreatIntelIndicatorType;
    Value?: string;
    Category?: ThreatIntelIndicatorCategory;
    LastObservedAt?: string;
    Source?: string;
    SourceUrl?: string;
}
export type ThreatIntelIndicatorList = ThreatIntelIndicator[];
export type Partition = "aws" | "aws-cn" | "aws-us-gov" | "aws-us-iso" | "aws-us-iso-b" | "AzureCloud" | (string & {});
export type CloudProviderName = "Azure" | "AWS" | (string & {});
export interface ResourceOwnerAccount {
    Id?: string;
}
export interface ResourceOwnerOrg {
    Id?: string;
}
export interface ResourceOwner {
    Account?: ResourceOwnerAccount;
    Org?: ResourceOwnerOrg;
}
export interface ClassificationStatus {
    Code?: string;
    Reason?: string;
}
export interface Range {
    Start?: number;
    End?: number;
    StartColumn?: number;
}
export type Ranges = Range[];
export interface Page {
    PageNumber?: number;
    LineRange?: Range;
    OffsetRange?: Range;
}
export type Pages = Page[];
export interface Record {
    JsonPath?: string;
    RecordIndex?: number;
}
export type Records = Record[];
export interface Cell {
    Column?: number;
    Row?: number;
    ColumnName?: string;
    CellReference?: string;
}
export type Cells = Cell[];
export interface Occurrences {
    LineRanges?: Range[];
    OffsetRanges?: Range[];
    Pages?: Page[];
    Records?: Record[];
    Cells?: Cell[];
}
export interface SensitiveDataDetections {
    Count?: number;
    Type?: string;
    Occurrences?: Occurrences;
}
export type SensitiveDataDetectionsList = SensitiveDataDetections[];
export interface SensitiveDataResult {
    Category?: string;
    Detections?: SensitiveDataDetections[];
    TotalCount?: number;
}
export type SensitiveDataResultList = SensitiveDataResult[];
export interface CustomDataIdentifiersDetections {
    Count?: number;
    Arn?: string;
    Name?: string;
    Occurrences?: Occurrences;
}
export type CustomDataIdentifiersDetectionsList = CustomDataIdentifiersDetections[];
export interface CustomDataIdentifiersResult {
    Detections?: CustomDataIdentifiersDetections[];
    TotalCount?: number;
}
export interface ClassificationResult {
    MimeType?: string;
    SizeClassified?: number;
    AdditionalOccurrences?: boolean;
    Status?: ClassificationStatus;
    SensitiveData?: SensitiveDataResult[];
    CustomDataIdentifiers?: CustomDataIdentifiersResult;
}
export interface DataClassificationDetails {
    DetailedResultsLocation?: string;
    Result?: ClassificationResult;
}
export interface AwsAutoScalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDetails {
    OnDemandAllocationStrategy?: string;
    OnDemandBaseCapacity?: number;
    OnDemandPercentageAboveBaseCapacity?: number;
    SpotAllocationStrategy?: string;
    SpotInstancePools?: number;
    SpotMaxPrice?: string;
}
export interface AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecification {
    LaunchTemplateId?: string;
    LaunchTemplateName?: string;
    Version?: string;
}
export interface AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesListDetails {
    InstanceType?: string;
    WeightedCapacity?: string;
}
export type AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesList = AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesListDetails[];
export interface AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateDetails {
    LaunchTemplateSpecification?: AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecification;
    Overrides?: AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesListDetails[];
}
export interface AwsAutoScalingAutoScalingGroupMixedInstancesPolicyDetails {
    InstancesDistribution?: AwsAutoScalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDetails;
    LaunchTemplate?: AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateDetails;
}
export interface AwsAutoScalingAutoScalingGroupAvailabilityZonesListDetails {
    Value?: string;
}
export type AwsAutoScalingAutoScalingGroupAvailabilityZonesList = AwsAutoScalingAutoScalingGroupAvailabilityZonesListDetails[];
export interface AwsAutoScalingAutoScalingGroupLaunchTemplateLaunchTemplateSpecification {
    LaunchTemplateId?: string;
    LaunchTemplateName?: string;
    Version?: string;
}
export interface AwsAutoScalingAutoScalingGroupDetails {
    LaunchConfigurationName?: string;
    LoadBalancerNames?: string[];
    HealthCheckType?: string;
    HealthCheckGracePeriod?: number;
    CreatedTime?: string;
    MixedInstancesPolicy?: AwsAutoScalingAutoScalingGroupMixedInstancesPolicyDetails;
    AvailabilityZones?: AwsAutoScalingAutoScalingGroupAvailabilityZonesListDetails[];
    LaunchTemplate?: AwsAutoScalingAutoScalingGroupLaunchTemplateLaunchTemplateSpecification;
    CapacityRebalance?: boolean;
}
export interface AwsCodeBuildProjectArtifactsDetails {
    ArtifactIdentifier?: string;
    EncryptionDisabled?: boolean;
    Location?: string;
    Name?: string;
    NamespaceType?: string;
    OverrideArtifactName?: boolean;
    Packaging?: string;
    Path?: string;
    Type?: string;
}
export type AwsCodeBuildProjectArtifactsList = AwsCodeBuildProjectArtifactsDetails[];
export interface AwsCodeBuildProjectEnvironmentEnvironmentVariablesDetails {
    Name?: string;
    Type?: string;
    Value?: string;
}
export type AwsCodeBuildProjectEnvironmentEnvironmentVariablesList = AwsCodeBuildProjectEnvironmentEnvironmentVariablesDetails[];
export interface AwsCodeBuildProjectEnvironmentRegistryCredential {
    Credential?: string;
    CredentialProvider?: string;
}
export interface AwsCodeBuildProjectEnvironment {
    Certificate?: string;
    EnvironmentVariables?: AwsCodeBuildProjectEnvironmentEnvironmentVariablesDetails[];
    PrivilegedMode?: boolean;
    ImagePullCredentialsType?: string;
    RegistryCredential?: AwsCodeBuildProjectEnvironmentRegistryCredential;
    Type?: string;
}
export interface AwsCodeBuildProjectSource {
    Type?: string;
    Location?: string;
    GitCloneDepth?: number;
    InsecureSsl?: boolean;
}
export interface AwsCodeBuildProjectLogsConfigCloudWatchLogsDetails {
    GroupName?: string;
    Status?: string;
    StreamName?: string;
}
export interface AwsCodeBuildProjectLogsConfigS3LogsDetails {
    EncryptionDisabled?: boolean;
    Location?: string;
    Status?: string;
}
export interface AwsCodeBuildProjectLogsConfigDetails {
    CloudWatchLogs?: AwsCodeBuildProjectLogsConfigCloudWatchLogsDetails;
    S3Logs?: AwsCodeBuildProjectLogsConfigS3LogsDetails;
}
export type NonEmptyStringList = string[];
export interface AwsCodeBuildProjectVpcConfig {
    VpcId?: string;
    Subnets?: string[];
    SecurityGroupIds?: string[];
}
export interface AwsCodeBuildProjectDetails {
    EncryptionKey?: string;
    Artifacts?: AwsCodeBuildProjectArtifactsDetails[];
    Environment?: AwsCodeBuildProjectEnvironment;
    Name?: string;
    Source?: AwsCodeBuildProjectSource;
    ServiceRole?: string;
    LogsConfig?: AwsCodeBuildProjectLogsConfigDetails;
    VpcConfig?: AwsCodeBuildProjectVpcConfig;
    SecondaryArtifacts?: AwsCodeBuildProjectArtifactsDetails[];
}
export interface AwsCloudFrontDistributionCacheBehavior {
    ViewerProtocolPolicy?: string;
}
export type AwsCloudFrontDistributionCacheBehaviorsItemList = AwsCloudFrontDistributionCacheBehavior[];
export interface AwsCloudFrontDistributionCacheBehaviors {
    Items?: AwsCloudFrontDistributionCacheBehavior[];
}
export interface AwsCloudFrontDistributionDefaultCacheBehavior {
    ViewerProtocolPolicy?: string;
}
export interface AwsCloudFrontDistributionLogging {
    Bucket?: string;
    Enabled?: boolean;
    IncludeCookies?: boolean;
    Prefix?: string;
}
export interface AwsCloudFrontDistributionOriginS3OriginConfig {
    OriginAccessIdentity?: string;
}
export interface AwsCloudFrontDistributionOriginSslProtocols {
    Items?: string[];
    Quantity?: number;
}
export interface AwsCloudFrontDistributionOriginCustomOriginConfig {
    HttpPort?: number;
    HttpsPort?: number;
    OriginKeepaliveTimeout?: number;
    OriginProtocolPolicy?: string;
    OriginReadTimeout?: number;
    OriginSslProtocols?: AwsCloudFrontDistributionOriginSslProtocols;
}
export interface AwsCloudFrontDistributionOriginItem {
    DomainName?: string;
    Id?: string;
    OriginPath?: string;
    S3OriginConfig?: AwsCloudFrontDistributionOriginS3OriginConfig;
    CustomOriginConfig?: AwsCloudFrontDistributionOriginCustomOriginConfig;
}
export type AwsCloudFrontDistributionOriginItemList = AwsCloudFrontDistributionOriginItem[];
export interface AwsCloudFrontDistributionOrigins {
    Items?: AwsCloudFrontDistributionOriginItem[];
}
export type AwsCloudFrontDistributionOriginGroupFailoverStatusCodesItemList = number[];
export interface AwsCloudFrontDistributionOriginGroupFailoverStatusCodes {
    Items?: number[];
    Quantity?: number;
}
export interface AwsCloudFrontDistributionOriginGroupFailover {
    StatusCodes?: AwsCloudFrontDistributionOriginGroupFailoverStatusCodes;
}
export interface AwsCloudFrontDistributionOriginGroup {
    FailoverCriteria?: AwsCloudFrontDistributionOriginGroupFailover;
}
export type AwsCloudFrontDistributionOriginGroupsItemList = AwsCloudFrontDistributionOriginGroup[];
export interface AwsCloudFrontDistributionOriginGroups {
    Items?: AwsCloudFrontDistributionOriginGroup[];
}
export interface AwsCloudFrontDistributionViewerCertificate {
    AcmCertificateArn?: string;
    Certificate?: string;
    CertificateSource?: string;
    CloudFrontDefaultCertificate?: boolean;
    IamCertificateId?: string;
    MinimumProtocolVersion?: string;
    SslSupportMethod?: string;
}
export interface AwsCloudFrontDistributionDetails {
    CacheBehaviors?: AwsCloudFrontDistributionCacheBehaviors;
    DefaultCacheBehavior?: AwsCloudFrontDistributionDefaultCacheBehavior;
    DefaultRootObject?: string;
    DomainName?: string;
    ETag?: string;
    LastModifiedTime?: string;
    Logging?: AwsCloudFrontDistributionLogging;
    Origins?: AwsCloudFrontDistributionOrigins;
    OriginGroups?: AwsCloudFrontDistributionOriginGroups;
    ViewerCertificate?: AwsCloudFrontDistributionViewerCertificate;
    Status?: string;
    WebAclId?: string;
}
export interface AwsEc2InstanceNetworkInterfacesDetails {
    NetworkInterfaceId?: string;
}
export type AwsEc2InstanceNetworkInterfacesList = AwsEc2InstanceNetworkInterfacesDetails[];
export interface AwsEc2InstanceMetadataOptions {
    HttpEndpoint?: string;
    HttpProtocolIpv6?: string;
    HttpPutResponseHopLimit?: number;
    HttpTokens?: string;
    InstanceMetadataTags?: string;
}
export interface AwsEc2InstanceMonitoringDetails {
    State?: string;
}
export interface AwsEc2InstanceDetails {
    Type?: string;
    ImageId?: string;
    IpV4Addresses?: string[];
    IpV6Addresses?: string[];
    KeyName?: string;
    IamInstanceProfileArn?: string;
    VpcId?: string;
    SubnetId?: string;
    LaunchedAt?: string;
    NetworkInterfaces?: AwsEc2InstanceNetworkInterfacesDetails[];
    VirtualizationType?: string;
    MetadataOptions?: AwsEc2InstanceMetadataOptions;
    Monitoring?: AwsEc2InstanceMonitoringDetails;
}
export interface AwsEc2NetworkInterfaceAttachment {
    AttachTime?: string;
    AttachmentId?: string;
    DeleteOnTermination?: boolean;
    DeviceIndex?: number;
    InstanceId?: string;
    InstanceOwnerId?: string;
    Status?: string;
}
export interface AwsEc2NetworkInterfaceSecurityGroup {
    GroupName?: string;
    GroupId?: string;
}
export type AwsEc2NetworkInterfaceSecurityGroupList = AwsEc2NetworkInterfaceSecurityGroup[];
export interface AwsEc2NetworkInterfaceIpV6AddressDetail {
    IpV6Address?: string;
}
export type AwsEc2NetworkInterfaceIpV6AddressList = AwsEc2NetworkInterfaceIpV6AddressDetail[];
export interface AwsEc2NetworkInterfacePrivateIpAddressDetail {
    PrivateIpAddress?: string;
    PrivateDnsName?: string;
}
export type AwsEc2NetworkInterfacePrivateIpAddressList = AwsEc2NetworkInterfacePrivateIpAddressDetail[];
export interface AwsEc2NetworkInterfaceDetails {
    Attachment?: AwsEc2NetworkInterfaceAttachment;
    NetworkInterfaceId?: string;
    SecurityGroups?: AwsEc2NetworkInterfaceSecurityGroup[];
    SourceDestCheck?: boolean;
    IpV6Addresses?: AwsEc2NetworkInterfaceIpV6AddressDetail[];
    PrivateIpAddresses?: AwsEc2NetworkInterfacePrivateIpAddressDetail[];
    PublicDnsName?: string;
    PublicIp?: string;
}
export interface AwsEc2SecurityGroupUserIdGroupPair {
    GroupId?: string;
    GroupName?: string;
    PeeringStatus?: string;
    UserId?: string;
    VpcId?: string;
    VpcPeeringConnectionId?: string;
}
export type AwsEc2SecurityGroupUserIdGroupPairList = AwsEc2SecurityGroupUserIdGroupPair[];
export interface AwsEc2SecurityGroupIpRange {
    CidrIp?: string;
}
export type AwsEc2SecurityGroupIpRangeList = AwsEc2SecurityGroupIpRange[];
export interface AwsEc2SecurityGroupIpv6Range {
    CidrIpv6?: string;
}
export type AwsEc2SecurityGroupIpv6RangeList = AwsEc2SecurityGroupIpv6Range[];
export interface AwsEc2SecurityGroupPrefixListId {
    PrefixListId?: string;
}
export type AwsEc2SecurityGroupPrefixListIdList = AwsEc2SecurityGroupPrefixListId[];
export interface AwsEc2SecurityGroupIpPermission {
    IpProtocol?: string;
    FromPort?: number;
    ToPort?: number;
    UserIdGroupPairs?: AwsEc2SecurityGroupUserIdGroupPair[];
    IpRanges?: AwsEc2SecurityGroupIpRange[];
    Ipv6Ranges?: AwsEc2SecurityGroupIpv6Range[];
    PrefixListIds?: AwsEc2SecurityGroupPrefixListId[];
}
export type AwsEc2SecurityGroupIpPermissionList = AwsEc2SecurityGroupIpPermission[];
export interface AwsEc2SecurityGroupDetails {
    GroupName?: string;
    GroupId?: string;
    OwnerId?: string;
    VpcId?: string;
    IpPermissions?: AwsEc2SecurityGroupIpPermission[];
    IpPermissionsEgress?: AwsEc2SecurityGroupIpPermission[];
}
export interface AwsEc2VolumeAttachment {
    AttachTime?: string;
    DeleteOnTermination?: boolean;
    InstanceId?: string;
    Status?: string;
}
export type AwsEc2VolumeAttachmentList = AwsEc2VolumeAttachment[];
export interface AwsEc2VolumeDetails {
    CreateTime?: string;
    DeviceName?: string;
    Encrypted?: boolean;
    Size?: number;
    SnapshotId?: string;
    Status?: string;
    KmsKeyId?: string;
    Attachments?: AwsEc2VolumeAttachment[];
    VolumeId?: string;
    VolumeType?: string;
    VolumeScanStatus?: string;
}
export interface CidrBlockAssociation {
    AssociationId?: string;
    CidrBlock?: string;
    CidrBlockState?: string;
}
export type CidrBlockAssociationList = CidrBlockAssociation[];
export interface Ipv6CidrBlockAssociation {
    AssociationId?: string;
    Ipv6CidrBlock?: string;
    CidrBlockState?: string;
}
export type Ipv6CidrBlockAssociationList = Ipv6CidrBlockAssociation[];
export interface AwsEc2VpcDetails {
    CidrBlockAssociationSet?: CidrBlockAssociation[];
    Ipv6CidrBlockAssociationSet?: Ipv6CidrBlockAssociation[];
    DhcpOptionsId?: string;
    State?: string;
}
export interface AwsEc2EipDetails {
    InstanceId?: string;
    PublicIp?: string;
    AllocationId?: string;
    AssociationId?: string;
    Domain?: string;
    PublicIpv4Pool?: string;
    NetworkBorderGroup?: string;
    NetworkInterfaceId?: string;
    NetworkInterfaceOwnerId?: string;
    PrivateIpAddress?: string;
}
export interface AwsEc2SubnetDetails {
    AssignIpv6AddressOnCreation?: boolean;
    AvailabilityZone?: string;
    AvailabilityZoneId?: string;
    AvailableIpAddressCount?: number;
    CidrBlock?: string;
    DefaultForAz?: boolean;
    MapPublicIpOnLaunch?: boolean;
    OwnerId?: string;
    State?: string;
    SubnetArn?: string;
    SubnetId?: string;
    VpcId?: string;
    Ipv6CidrBlockAssociationSet?: Ipv6CidrBlockAssociation[];
}
export interface AwsEc2NetworkAclAssociation {
    NetworkAclAssociationId?: string;
    NetworkAclId?: string;
    SubnetId?: string;
}
export type AwsEc2NetworkAclAssociationList = AwsEc2NetworkAclAssociation[];
export interface IcmpTypeCode {
    Code?: number;
    Type?: number;
}
export interface PortRangeFromTo {
    From?: number;
    To?: number;
}
export interface AwsEc2NetworkAclEntry {
    CidrBlock?: string;
    Egress?: boolean;
    IcmpTypeCode?: IcmpTypeCode;
    Ipv6CidrBlock?: string;
    PortRange?: PortRangeFromTo;
    Protocol?: string;
    RuleAction?: string;
    RuleNumber?: number;
}
export type AwsEc2NetworkAclEntryList = AwsEc2NetworkAclEntry[];
export interface AwsEc2NetworkAclDetails {
    IsDefault?: boolean;
    NetworkAclId?: string;
    OwnerId?: string;
    VpcId?: string;
    Associations?: AwsEc2NetworkAclAssociation[];
    Entries?: AwsEc2NetworkAclEntry[];
}
export interface AvailabilityZone {
    ZoneName?: string;
    SubnetId?: string;
}
export type AvailabilityZones = AvailabilityZone[];
export type SecurityGroups = string[];
export interface LoadBalancerState {
    Code?: string;
    Reason?: string;
}
export interface AwsElbv2LoadBalancerAttribute {
    Key?: string;
    Value?: string;
}
export type AwsElbv2LoadBalancerAttributes = AwsElbv2LoadBalancerAttribute[];
export interface AwsElbv2LoadBalancerDetails {
    AvailabilityZones?: AvailabilityZone[];
    CanonicalHostedZoneId?: string;
    CreatedTime?: string;
    DNSName?: string;
    IpAddressType?: string;
    Scheme?: string;
    SecurityGroups?: string[];
    State?: LoadBalancerState;
    Type?: string;
    VpcId?: string;
    LoadBalancerAttributes?: AwsElbv2LoadBalancerAttribute[];
}
export interface AwsElasticBeanstalkEnvironmentEnvironmentLink {
    EnvironmentName?: string;
    LinkName?: string;
}
export type AwsElasticBeanstalkEnvironmentEnvironmentLinks = AwsElasticBeanstalkEnvironmentEnvironmentLink[];
export interface AwsElasticBeanstalkEnvironmentOptionSetting {
    Namespace?: string;
    OptionName?: string;
    ResourceName?: string;
    Value?: string;
}
export type AwsElasticBeanstalkEnvironmentOptionSettings = AwsElasticBeanstalkEnvironmentOptionSetting[];
export interface AwsElasticBeanstalkEnvironmentTier {
    Name?: string;
    Type?: string;
    Version?: string;
}
export interface AwsElasticBeanstalkEnvironmentDetails {
    ApplicationName?: string;
    Cname?: string;
    DateCreated?: string;
    DateUpdated?: string;
    Description?: string;
    EndpointUrl?: string;
    EnvironmentArn?: string;
    EnvironmentId?: string;
    EnvironmentLinks?: AwsElasticBeanstalkEnvironmentEnvironmentLink[];
    EnvironmentName?: string;
    OptionSettings?: AwsElasticBeanstalkEnvironmentOptionSetting[];
    PlatformArn?: string;
    SolutionStackName?: string;
    Status?: string;
    Tier?: AwsElasticBeanstalkEnvironmentTier;
    VersionLabel?: string;
}
export interface AwsElasticsearchDomainDomainEndpointOptions {
    EnforceHTTPS?: boolean;
    TLSSecurityPolicy?: string;
}
export interface AwsElasticsearchDomainElasticsearchClusterConfigZoneAwarenessConfigDetails {
    AvailabilityZoneCount?: number;
}
export interface AwsElasticsearchDomainElasticsearchClusterConfigDetails {
    DedicatedMasterCount?: number;
    DedicatedMasterEnabled?: boolean;
    DedicatedMasterType?: string;
    InstanceCount?: number;
    InstanceType?: string;
    ZoneAwarenessConfig?: AwsElasticsearchDomainElasticsearchClusterConfigZoneAwarenessConfigDetails;
    ZoneAwarenessEnabled?: boolean;
}
export interface AwsElasticsearchDomainEncryptionAtRestOptions {
    Enabled?: boolean;
    KmsKeyId?: string;
}
export interface AwsElasticsearchDomainLogPublishingOptionsLogConfig {
    CloudWatchLogsLogGroupArn?: string;
    Enabled?: boolean;
}
export interface AwsElasticsearchDomainLogPublishingOptions {
    IndexSlowLogs?: AwsElasticsearchDomainLogPublishingOptionsLogConfig;
    SearchSlowLogs?: AwsElasticsearchDomainLogPublishingOptionsLogConfig;
    AuditLogs?: AwsElasticsearchDomainLogPublishingOptionsLogConfig;
}
export interface AwsElasticsearchDomainNodeToNodeEncryptionOptions {
    Enabled?: boolean;
}
export interface AwsElasticsearchDomainServiceSoftwareOptions {
    AutomatedUpdateDate?: string;
    Cancellable?: boolean;
    CurrentVersion?: string;
    Description?: string;
    NewVersion?: string;
    UpdateAvailable?: boolean;
    UpdateStatus?: string;
}
export interface AwsElasticsearchDomainVPCOptions {
    AvailabilityZones?: string[];
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    VPCId?: string;
}
export interface AwsElasticsearchDomainDetails {
    AccessPolicies?: string;
    DomainEndpointOptions?: AwsElasticsearchDomainDomainEndpointOptions;
    DomainId?: string;
    DomainName?: string;
    Endpoint?: string;
    Endpoints?: {
        [key: string]: string | undefined;
    };
    ElasticsearchVersion?: string;
    ElasticsearchClusterConfig?: AwsElasticsearchDomainElasticsearchClusterConfigDetails;
    EncryptionAtRestOptions?: AwsElasticsearchDomainEncryptionAtRestOptions;
    LogPublishingOptions?: AwsElasticsearchDomainLogPublishingOptions;
    NodeToNodeEncryptionOptions?: AwsElasticsearchDomainNodeToNodeEncryptionOptions;
    ServiceSoftwareOptions?: AwsElasticsearchDomainServiceSoftwareOptions;
    VPCOptions?: AwsElasticsearchDomainVPCOptions;
}
export interface AwsS3BucketServerSideEncryptionByDefault {
    SSEAlgorithm?: string;
    KMSMasterKeyID?: string;
}
export interface AwsS3BucketServerSideEncryptionRule {
    ApplyServerSideEncryptionByDefault?: AwsS3BucketServerSideEncryptionByDefault;
}
export type AwsS3BucketServerSideEncryptionRules = AwsS3BucketServerSideEncryptionRule[];
export interface AwsS3BucketServerSideEncryptionConfiguration {
    Rules?: AwsS3BucketServerSideEncryptionRule[];
}
export interface AwsS3BucketBucketLifecycleConfigurationRulesAbortIncompleteMultipartUploadDetails {
    DaysAfterInitiation?: number;
}
export interface AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateOperandsTagDetails {
    Key?: string;
    Value?: string;
}
export interface AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateOperandsDetails {
    Prefix?: string;
    Tag?: AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateOperandsTagDetails;
    Type?: string;
}
export type AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateOperandsList = AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateOperandsDetails[];
export interface AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateTagDetails {
    Key?: string;
    Value?: string;
}
export interface AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateDetails {
    Operands?: AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateOperandsDetails[];
    Prefix?: string;
    Tag?: AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateTagDetails;
    Type?: string;
}
export interface AwsS3BucketBucketLifecycleConfigurationRulesFilterDetails {
    Predicate?: AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateDetails;
}
export interface AwsS3BucketBucketLifecycleConfigurationRulesNoncurrentVersionTransitionsDetails {
    Days?: number;
    StorageClass?: string;
}
export type AwsS3BucketBucketLifecycleConfigurationRulesNoncurrentVersionTransitionsList = AwsS3BucketBucketLifecycleConfigurationRulesNoncurrentVersionTransitionsDetails[];
export interface AwsS3BucketBucketLifecycleConfigurationRulesTransitionsDetails {
    Date?: string;
    Days?: number;
    StorageClass?: string;
}
export type AwsS3BucketBucketLifecycleConfigurationRulesTransitionsList = AwsS3BucketBucketLifecycleConfigurationRulesTransitionsDetails[];
export interface AwsS3BucketBucketLifecycleConfigurationRulesDetails {
    AbortIncompleteMultipartUpload?: AwsS3BucketBucketLifecycleConfigurationRulesAbortIncompleteMultipartUploadDetails;
    ExpirationDate?: string;
    ExpirationInDays?: number;
    ExpiredObjectDeleteMarker?: boolean;
    Filter?: AwsS3BucketBucketLifecycleConfigurationRulesFilterDetails;
    ID?: string;
    NoncurrentVersionExpirationInDays?: number;
    NoncurrentVersionTransitions?: AwsS3BucketBucketLifecycleConfigurationRulesNoncurrentVersionTransitionsDetails[];
    Prefix?: string;
    Status?: string;
    Transitions?: AwsS3BucketBucketLifecycleConfigurationRulesTransitionsDetails[];
}
export type AwsS3BucketBucketLifecycleConfigurationRulesList = AwsS3BucketBucketLifecycleConfigurationRulesDetails[];
export interface AwsS3BucketBucketLifecycleConfigurationDetails {
    Rules?: AwsS3BucketBucketLifecycleConfigurationRulesDetails[];
}
export interface AwsS3AccountPublicAccessBlockDetails {
    BlockPublicAcls?: boolean;
    BlockPublicPolicy?: boolean;
    IgnorePublicAcls?: boolean;
    RestrictPublicBuckets?: boolean;
}
export interface AwsS3BucketLoggingConfiguration {
    DestinationBucketName?: string;
    LogFilePrefix?: string;
}
export interface AwsS3BucketWebsiteConfigurationRedirectTo {
    Hostname?: string;
    Protocol?: string;
}
export interface AwsS3BucketWebsiteConfigurationRoutingRuleCondition {
    HttpErrorCodeReturnedEquals?: string;
    KeyPrefixEquals?: string;
}
export interface AwsS3BucketWebsiteConfigurationRoutingRuleRedirect {
    Hostname?: string;
    HttpRedirectCode?: string;
    Protocol?: string;
    ReplaceKeyPrefixWith?: string;
    ReplaceKeyWith?: string;
}
export interface AwsS3BucketWebsiteConfigurationRoutingRule {
    Condition?: AwsS3BucketWebsiteConfigurationRoutingRuleCondition;
    Redirect?: AwsS3BucketWebsiteConfigurationRoutingRuleRedirect;
}
export type AwsS3BucketWebsiteConfigurationRoutingRules = AwsS3BucketWebsiteConfigurationRoutingRule[];
export interface AwsS3BucketWebsiteConfiguration {
    ErrorDocument?: string;
    IndexDocumentSuffix?: string;
    RedirectAllRequestsTo?: AwsS3BucketWebsiteConfigurationRedirectTo;
    RoutingRules?: AwsS3BucketWebsiteConfigurationRoutingRule[];
}
export type AwsS3BucketNotificationConfigurationEvents = string[];
export type AwsS3BucketNotificationConfigurationS3KeyFilterRuleName = "Prefix" | "Suffix" | (string & {});
export interface AwsS3BucketNotificationConfigurationS3KeyFilterRule {
    Name?: AwsS3BucketNotificationConfigurationS3KeyFilterRuleName;
    Value?: string;
}
export type AwsS3BucketNotificationConfigurationS3KeyFilterRules = AwsS3BucketNotificationConfigurationS3KeyFilterRule[];
export interface AwsS3BucketNotificationConfigurationS3KeyFilter {
    FilterRules?: AwsS3BucketNotificationConfigurationS3KeyFilterRule[];
}
export interface AwsS3BucketNotificationConfigurationFilter {
    S3KeyFilter?: AwsS3BucketNotificationConfigurationS3KeyFilter;
}
export interface AwsS3BucketNotificationConfigurationDetail {
    Events?: string[];
    Filter?: AwsS3BucketNotificationConfigurationFilter;
    Destination?: string;
    Type?: string;
}
export type AwsS3BucketNotificationConfigurationDetails = AwsS3BucketNotificationConfigurationDetail[];
export interface AwsS3BucketNotificationConfiguration {
    Configurations?: AwsS3BucketNotificationConfigurationDetail[];
}
export interface AwsS3BucketBucketVersioningConfiguration {
    IsMfaDeleteEnabled?: boolean;
    Status?: string;
}
export interface AwsS3BucketObjectLockConfigurationRuleDefaultRetentionDetails {
    Days?: number;
    Mode?: string;
    Years?: number;
}
export interface AwsS3BucketObjectLockConfigurationRuleDetails {
    DefaultRetention?: AwsS3BucketObjectLockConfigurationRuleDefaultRetentionDetails;
}
export interface AwsS3BucketObjectLockConfiguration {
    ObjectLockEnabled?: string;
    Rule?: AwsS3BucketObjectLockConfigurationRuleDetails;
}
export interface AwsS3BucketDetails {
    OwnerId?: string;
    OwnerName?: string;
    OwnerAccountId?: string;
    CreatedAt?: string;
    ServerSideEncryptionConfiguration?: AwsS3BucketServerSideEncryptionConfiguration;
    BucketLifecycleConfiguration?: AwsS3BucketBucketLifecycleConfigurationDetails;
    PublicAccessBlockConfiguration?: AwsS3AccountPublicAccessBlockDetails;
    AccessControlList?: string;
    BucketLoggingConfiguration?: AwsS3BucketLoggingConfiguration;
    BucketWebsiteConfiguration?: AwsS3BucketWebsiteConfiguration;
    BucketNotificationConfiguration?: AwsS3BucketNotificationConfiguration;
    BucketVersioningConfiguration?: AwsS3BucketBucketVersioningConfiguration;
    ObjectLockConfiguration?: AwsS3BucketObjectLockConfiguration;
    Name?: string;
}
export interface AwsS3ObjectDetails {
    LastModified?: string;
    ETag?: string;
    VersionId?: string;
    ContentType?: string;
    ServerSideEncryption?: string;
    SSEKMSKeyId?: string;
}
export interface AwsSecretsManagerSecretRotationRules {
    AutomaticallyAfterDays?: number;
}
export interface AwsSecretsManagerSecretDetails {
    RotationRules?: AwsSecretsManagerSecretRotationRules;
    RotationOccurredWithinFrequency?: boolean;
    KmsKeyId?: string;
    RotationEnabled?: boolean;
    RotationLambdaArn?: string;
    Deleted?: boolean;
    Name?: string;
    Description?: string;
}
export type AwsIamAccessKeyStatus = "Active" | "Inactive" | (string & {});
export interface AwsIamAccessKeySessionContextAttributes {
    MfaAuthenticated?: boolean;
    CreationDate?: string;
}
export interface AwsIamAccessKeySessionContextSessionIssuer {
    Type?: string;
    PrincipalId?: string;
    Arn?: string;
    AccountId?: string;
    UserName?: string;
}
export interface AwsIamAccessKeySessionContext {
    Attributes?: AwsIamAccessKeySessionContextAttributes;
    SessionIssuer?: AwsIamAccessKeySessionContextSessionIssuer;
}
export interface AwsIamAccessKeyDetails {
    UserName?: string;
    Status?: AwsIamAccessKeyStatus;
    CreatedAt?: string;
    PrincipalId?: string;
    PrincipalType?: string;
    PrincipalName?: string;
    AccountId?: string;
    AccessKeyId?: string;
    SessionContext?: AwsIamAccessKeySessionContext;
}
export interface AwsIamAttachedManagedPolicy {
    PolicyName?: string;
    PolicyArn?: string;
}
export type AwsIamAttachedManagedPolicyList = AwsIamAttachedManagedPolicy[];
export interface AwsIamPermissionsBoundary {
    PermissionsBoundaryArn?: string;
    PermissionsBoundaryType?: string;
}
export interface AwsIamUserPolicy {
    PolicyName?: string;
}
export type AwsIamUserPolicyList = AwsIamUserPolicy[];
export interface AwsIamUserDetails {
    AttachedManagedPolicies?: AwsIamAttachedManagedPolicy[];
    CreateDate?: string;
    GroupList?: string[];
    Path?: string;
    PermissionsBoundary?: AwsIamPermissionsBoundary;
    UserId?: string;
    UserName?: string;
    UserPolicyList?: AwsIamUserPolicy[];
}
export interface AwsIamPolicyVersion {
    VersionId?: string;
    IsDefaultVersion?: boolean;
    CreateDate?: string;
}
export type AwsIamPolicyVersionList = AwsIamPolicyVersion[];
export interface AwsIamPolicyDetails {
    AttachmentCount?: number;
    CreateDate?: string;
    DefaultVersionId?: string;
    Description?: string;
    IsAttachable?: boolean;
    Path?: string;
    PermissionsBoundaryUsageCount?: number;
    PolicyId?: string;
    PolicyName?: string;
    PolicyVersionList?: AwsIamPolicyVersion[];
    UpdateDate?: string;
}
export interface AwsApiGatewayV2RouteSettings {
    DetailedMetricsEnabled?: boolean;
    LoggingLevel?: string;
    DataTraceEnabled?: boolean;
    ThrottlingBurstLimit?: number;
    ThrottlingRateLimit?: number;
}
export interface AwsApiGatewayAccessLogSettings {
    Format?: string;
    DestinationArn?: string;
}
export interface AwsApiGatewayV2StageDetails {
    ClientCertificateId?: string;
    CreatedDate?: string;
    Description?: string;
    DefaultRouteSettings?: AwsApiGatewayV2RouteSettings;
    DeploymentId?: string;
    LastUpdatedDate?: string;
    RouteSettings?: AwsApiGatewayV2RouteSettings;
    StageName?: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
    AccessLogSettings?: AwsApiGatewayAccessLogSettings;
    AutoDeploy?: boolean;
    LastDeploymentStatusMessage?: string;
    ApiGatewayManaged?: boolean;
}
export interface AwsCorsConfiguration {
    AllowOrigins?: string[];
    AllowCredentials?: boolean;
    ExposeHeaders?: string[];
    MaxAge?: number;
    AllowMethods?: string[];
    AllowHeaders?: string[];
}
export interface AwsApiGatewayV2ApiDetails {
    ApiEndpoint?: string;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CreatedDate?: string;
    Description?: string;
    Version?: string;
    Name?: string;
    ProtocolType?: string;
    RouteSelectionExpression?: string;
    CorsConfiguration?: AwsCorsConfiguration;
}
export interface AwsDynamoDbTableAttributeDefinition {
    AttributeName?: string;
    AttributeType?: string;
}
export type AwsDynamoDbTableAttributeDefinitionList = AwsDynamoDbTableAttributeDefinition[];
export interface AwsDynamoDbTableBillingModeSummary {
    BillingMode?: string;
    LastUpdateToPayPerRequestDateTime?: string;
}
export type SizeBytes = number;
export interface AwsDynamoDbTableKeySchema {
    AttributeName?: string;
    KeyType?: string;
}
export type AwsDynamoDbTableKeySchemaList = AwsDynamoDbTableKeySchema[];
export interface AwsDynamoDbTableProjection {
    NonKeyAttributes?: string[];
    ProjectionType?: string;
}
export interface AwsDynamoDbTableProvisionedThroughput {
    LastDecreaseDateTime?: string;
    LastIncreaseDateTime?: string;
    NumberOfDecreasesToday?: number;
    ReadCapacityUnits?: number;
    WriteCapacityUnits?: number;
}
export interface AwsDynamoDbTableGlobalSecondaryIndex {
    Backfilling?: boolean;
    IndexArn?: string;
    IndexName?: string;
    IndexSizeBytes?: number;
    IndexStatus?: string;
    ItemCount?: number;
    KeySchema?: AwsDynamoDbTableKeySchema[];
    Projection?: AwsDynamoDbTableProjection;
    ProvisionedThroughput?: AwsDynamoDbTableProvisionedThroughput;
}
export type AwsDynamoDbTableGlobalSecondaryIndexList = AwsDynamoDbTableGlobalSecondaryIndex[];
export interface AwsDynamoDbTableLocalSecondaryIndex {
    IndexArn?: string;
    IndexName?: string;
    KeySchema?: AwsDynamoDbTableKeySchema[];
    Projection?: AwsDynamoDbTableProjection;
}
export type AwsDynamoDbTableLocalSecondaryIndexList = AwsDynamoDbTableLocalSecondaryIndex[];
export interface AwsDynamoDbTableProvisionedThroughputOverride {
    ReadCapacityUnits?: number;
}
export interface AwsDynamoDbTableReplicaGlobalSecondaryIndex {
    IndexName?: string;
    ProvisionedThroughputOverride?: AwsDynamoDbTableProvisionedThroughputOverride;
}
export type AwsDynamoDbTableReplicaGlobalSecondaryIndexList = AwsDynamoDbTableReplicaGlobalSecondaryIndex[];
export interface AwsDynamoDbTableReplica {
    GlobalSecondaryIndexes?: AwsDynamoDbTableReplicaGlobalSecondaryIndex[];
    KmsMasterKeyId?: string;
    ProvisionedThroughputOverride?: AwsDynamoDbTableProvisionedThroughputOverride;
    RegionName?: string;
    ReplicaStatus?: string;
    ReplicaStatusDescription?: string;
}
export type AwsDynamoDbTableReplicaList = AwsDynamoDbTableReplica[];
export interface AwsDynamoDbTableRestoreSummary {
    SourceBackupArn?: string;
    SourceTableArn?: string;
    RestoreDateTime?: string;
    RestoreInProgress?: boolean;
}
export interface AwsDynamoDbTableSseDescription {
    InaccessibleEncryptionDateTime?: string;
    Status?: string;
    SseType?: string;
    KmsMasterKeyArn?: string;
}
export interface AwsDynamoDbTableStreamSpecification {
    StreamEnabled?: boolean;
    StreamViewType?: string;
}
export interface AwsDynamoDbTableDetails {
    AttributeDefinitions?: AwsDynamoDbTableAttributeDefinition[];
    BillingModeSummary?: AwsDynamoDbTableBillingModeSummary;
    CreationDateTime?: string;
    GlobalSecondaryIndexes?: AwsDynamoDbTableGlobalSecondaryIndex[];
    GlobalTableVersion?: string;
    ItemCount?: number;
    KeySchema?: AwsDynamoDbTableKeySchema[];
    LatestStreamArn?: string;
    LatestStreamLabel?: string;
    LocalSecondaryIndexes?: AwsDynamoDbTableLocalSecondaryIndex[];
    ProvisionedThroughput?: AwsDynamoDbTableProvisionedThroughput;
    Replicas?: AwsDynamoDbTableReplica[];
    RestoreSummary?: AwsDynamoDbTableRestoreSummary;
    SseDescription?: AwsDynamoDbTableSseDescription;
    StreamSpecification?: AwsDynamoDbTableStreamSpecification;
    TableId?: string;
    TableName?: string;
    TableSizeBytes?: number;
    TableStatus?: string;
    DeletionProtectionEnabled?: boolean;
}
export interface AwsApiGatewayMethodSettings {
    MetricsEnabled?: boolean;
    LoggingLevel?: string;
    DataTraceEnabled?: boolean;
    ThrottlingBurstLimit?: number;
    ThrottlingRateLimit?: number;
    CachingEnabled?: boolean;
    CacheTtlInSeconds?: number;
    CacheDataEncrypted?: boolean;
    RequireAuthorizationForCacheControl?: boolean;
    UnauthorizedCacheControlHeaderStrategy?: string;
    HttpMethod?: string;
    ResourcePath?: string;
}
export type AwsApiGatewayMethodSettingsList = AwsApiGatewayMethodSettings[];
export interface AwsApiGatewayCanarySettings {
    PercentTraffic?: number;
    DeploymentId?: string;
    StageVariableOverrides?: {
        [key: string]: string | undefined;
    };
    UseStageCache?: boolean;
}
export interface AwsApiGatewayStageDetails {
    DeploymentId?: string;
    ClientCertificateId?: string;
    StageName?: string;
    Description?: string;
    CacheClusterEnabled?: boolean;
    CacheClusterSize?: string;
    CacheClusterStatus?: string;
    MethodSettings?: AwsApiGatewayMethodSettings[];
    Variables?: {
        [key: string]: string | undefined;
    };
    DocumentationVersion?: string;
    AccessLogSettings?: AwsApiGatewayAccessLogSettings;
    CanarySettings?: AwsApiGatewayCanarySettings;
    TracingEnabled?: boolean;
    CreatedDate?: string;
    LastUpdatedDate?: string;
    WebAclArn?: string;
}
export interface AwsApiGatewayEndpointConfiguration {
    Types?: string[];
}
export interface AwsApiGatewayRestApiDetails {
    Id?: string;
    Name?: string;
    Description?: string;
    CreatedDate?: string;
    Version?: string;
    BinaryMediaTypes?: string[];
    MinimumCompressionSize?: number;
    ApiKeySource?: string;
    EndpointConfiguration?: AwsApiGatewayEndpointConfiguration;
}
export interface AwsCloudTrailTrailDetails {
    CloudWatchLogsLogGroupArn?: string;
    CloudWatchLogsRoleArn?: string;
    HasCustomEventSelectors?: boolean;
    HomeRegion?: string;
    IncludeGlobalServiceEvents?: boolean;
    IsMultiRegionTrail?: boolean;
    IsOrganizationTrail?: boolean;
    KmsKeyId?: string;
    LogFileValidationEnabled?: boolean;
    Name?: string;
    S3BucketName?: string;
    S3KeyPrefix?: string;
    SnsTopicArn?: string;
    SnsTopicName?: string;
    TrailArn?: string;
}
export interface AwsSsmComplianceSummary {
    Status?: string;
    CompliantCriticalCount?: number;
    CompliantHighCount?: number;
    CompliantMediumCount?: number;
    ExecutionType?: string;
    NonCompliantCriticalCount?: number;
    CompliantInformationalCount?: number;
    NonCompliantInformationalCount?: number;
    CompliantUnspecifiedCount?: number;
    NonCompliantLowCount?: number;
    NonCompliantHighCount?: number;
    CompliantLowCount?: number;
    ComplianceType?: string;
    PatchBaselineId?: string;
    OverallSeverity?: string;
    NonCompliantMediumCount?: number;
    NonCompliantUnspecifiedCount?: number;
    PatchGroup?: string;
}
export interface AwsSsmPatch {
    ComplianceSummary?: AwsSsmComplianceSummary;
}
export interface AwsSsmPatchComplianceDetails {
    Patch?: AwsSsmPatch;
}
export interface AwsCertificateManagerCertificateResourceRecord {
    Name?: string;
    Type?: string;
    Value?: string;
}
export interface AwsCertificateManagerCertificateDomainValidationOption {
    DomainName?: string;
    ResourceRecord?: AwsCertificateManagerCertificateResourceRecord;
    ValidationDomain?: string;
    ValidationEmails?: string[];
    ValidationMethod?: string;
    ValidationStatus?: string;
}
export type AwsCertificateManagerCertificateDomainValidationOptions = AwsCertificateManagerCertificateDomainValidationOption[];
export interface AwsCertificateManagerCertificateExtendedKeyUsage {
    Name?: string;
    OId?: string;
}
export type AwsCertificateManagerCertificateExtendedKeyUsages = AwsCertificateManagerCertificateExtendedKeyUsage[];
export interface AwsCertificateManagerCertificateKeyUsage {
    Name?: string;
}
export type AwsCertificateManagerCertificateKeyUsages = AwsCertificateManagerCertificateKeyUsage[];
export interface AwsCertificateManagerCertificateOptions {
    CertificateTransparencyLoggingPreference?: string;
}
export interface AwsCertificateManagerCertificateRenewalSummary {
    DomainValidationOptions?: AwsCertificateManagerCertificateDomainValidationOption[];
    RenewalStatus?: string;
    RenewalStatusReason?: string;
    UpdatedAt?: string;
}
export interface AwsCertificateManagerCertificateDetails {
    CertificateAuthorityArn?: string;
    CreatedAt?: string;
    DomainName?: string;
    DomainValidationOptions?: AwsCertificateManagerCertificateDomainValidationOption[];
    ExtendedKeyUsages?: AwsCertificateManagerCertificateExtendedKeyUsage[];
    FailureReason?: string;
    ImportedAt?: string;
    InUseBy?: string[];
    IssuedAt?: string;
    Issuer?: string;
    KeyAlgorithm?: string;
    KeyUsages?: AwsCertificateManagerCertificateKeyUsage[];
    NotAfter?: string;
    NotBefore?: string;
    Options?: AwsCertificateManagerCertificateOptions;
    RenewalEligibility?: string;
    RenewalSummary?: AwsCertificateManagerCertificateRenewalSummary;
    Serial?: string;
    SignatureAlgorithm?: string;
    Status?: string;
    Subject?: string;
    SubjectAlternativeNames?: string[];
    Type?: string;
}
export interface AwsRedshiftClusterClusterNode {
    NodeRole?: string;
    PrivateIpAddress?: string;
    PublicIpAddress?: string;
}
export type AwsRedshiftClusterClusterNodes = AwsRedshiftClusterClusterNode[];
export interface AwsRedshiftClusterClusterParameterStatus {
    ParameterName?: string;
    ParameterApplyStatus?: string;
    ParameterApplyErrorDescription?: string;
}
export type AwsRedshiftClusterClusterParameterStatusList = AwsRedshiftClusterClusterParameterStatus[];
export interface AwsRedshiftClusterClusterParameterGroup {
    ClusterParameterStatusList?: AwsRedshiftClusterClusterParameterStatus[];
    ParameterApplyStatus?: string;
    ParameterGroupName?: string;
}
export type AwsRedshiftClusterClusterParameterGroups = AwsRedshiftClusterClusterParameterGroup[];
export interface AwsRedshiftClusterClusterSecurityGroup {
    ClusterSecurityGroupName?: string;
    Status?: string;
}
export type AwsRedshiftClusterClusterSecurityGroups = AwsRedshiftClusterClusterSecurityGroup[];
export interface AwsRedshiftClusterClusterSnapshotCopyStatus {
    DestinationRegion?: string;
    ManualSnapshotRetentionPeriod?: number;
    RetentionPeriod?: number;
    SnapshotCopyGrantName?: string;
}
export interface AwsRedshiftClusterDeferredMaintenanceWindow {
    DeferMaintenanceEndTime?: string;
    DeferMaintenanceIdentifier?: string;
    DeferMaintenanceStartTime?: string;
}
export type AwsRedshiftClusterDeferredMaintenanceWindows = AwsRedshiftClusterDeferredMaintenanceWindow[];
export interface AwsRedshiftClusterElasticIpStatus {
    ElasticIp?: string;
    Status?: string;
}
export interface AwsRedshiftClusterEndpoint {
    Address?: string;
    Port?: number;
}
export interface AwsRedshiftClusterHsmStatus {
    HsmClientCertificateIdentifier?: string;
    HsmConfigurationIdentifier?: string;
    Status?: string;
}
export interface AwsRedshiftClusterIamRole {
    ApplyStatus?: string;
    IamRoleArn?: string;
}
export type AwsRedshiftClusterIamRoles = AwsRedshiftClusterIamRole[];
export interface AwsRedshiftClusterPendingModifiedValues {
    AutomatedSnapshotRetentionPeriod?: number;
    ClusterIdentifier?: string;
    ClusterType?: string;
    ClusterVersion?: string;
    EncryptionType?: string;
    EnhancedVpcRouting?: boolean;
    MaintenanceTrackName?: string;
    MasterUserPassword?: string;
    NodeType?: string;
    NumberOfNodes?: number;
    PubliclyAccessible?: boolean;
}
export interface AwsRedshiftClusterResizeInfo {
    AllowCancelResize?: boolean;
    ResizeType?: string;
}
export interface AwsRedshiftClusterRestoreStatus {
    CurrentRestoreRateInMegaBytesPerSecond?: number;
    ElapsedTimeInSeconds?: number;
    EstimatedTimeToCompletionInSeconds?: number;
    ProgressInMegaBytes?: number;
    SnapshotSizeInMegaBytes?: number;
    Status?: string;
}
export interface AwsRedshiftClusterVpcSecurityGroup {
    Status?: string;
    VpcSecurityGroupId?: string;
}
export type AwsRedshiftClusterVpcSecurityGroups = AwsRedshiftClusterVpcSecurityGroup[];
export interface AwsRedshiftClusterLoggingStatus {
    BucketName?: string;
    LastFailureMessage?: string;
    LastFailureTime?: string;
    LastSuccessfulDeliveryTime?: string;
    LoggingEnabled?: boolean;
    S3KeyPrefix?: string;
}
export interface AwsRedshiftClusterDetails {
    AllowVersionUpgrade?: boolean;
    AutomatedSnapshotRetentionPeriod?: number;
    AvailabilityZone?: string;
    ClusterAvailabilityStatus?: string;
    ClusterCreateTime?: string;
    ClusterIdentifier?: string;
    ClusterNodes?: AwsRedshiftClusterClusterNode[];
    ClusterParameterGroups?: AwsRedshiftClusterClusterParameterGroup[];
    ClusterPublicKey?: string;
    ClusterRevisionNumber?: string;
    ClusterSecurityGroups?: AwsRedshiftClusterClusterSecurityGroup[];
    ClusterSnapshotCopyStatus?: AwsRedshiftClusterClusterSnapshotCopyStatus;
    ClusterStatus?: string;
    ClusterSubnetGroupName?: string;
    ClusterVersion?: string;
    DBName?: string;
    DeferredMaintenanceWindows?: AwsRedshiftClusterDeferredMaintenanceWindow[];
    ElasticIpStatus?: AwsRedshiftClusterElasticIpStatus;
    ElasticResizeNumberOfNodeOptions?: string;
    Encrypted?: boolean;
    Endpoint?: AwsRedshiftClusterEndpoint;
    EnhancedVpcRouting?: boolean;
    ExpectedNextSnapshotScheduleTime?: string;
    ExpectedNextSnapshotScheduleTimeStatus?: string;
    HsmStatus?: AwsRedshiftClusterHsmStatus;
    IamRoles?: AwsRedshiftClusterIamRole[];
    KmsKeyId?: string;
    MaintenanceTrackName?: string;
    ManualSnapshotRetentionPeriod?: number;
    MasterUsername?: string;
    NextMaintenanceWindowStartTime?: string;
    NodeType?: string;
    NumberOfNodes?: number;
    PendingActions?: string[];
    PendingModifiedValues?: AwsRedshiftClusterPendingModifiedValues;
    PreferredMaintenanceWindow?: string;
    PubliclyAccessible?: boolean;
    ResizeInfo?: AwsRedshiftClusterResizeInfo;
    RestoreStatus?: AwsRedshiftClusterRestoreStatus;
    SnapshotScheduleIdentifier?: string;
    SnapshotScheduleState?: string;
    VpcId?: string;
    VpcSecurityGroups?: AwsRedshiftClusterVpcSecurityGroup[];
    LoggingStatus?: AwsRedshiftClusterLoggingStatus;
}
export interface AwsElbLoadBalancerBackendServerDescription {
    InstancePort?: number;
    PolicyNames?: string[];
}
export type AwsElbLoadBalancerBackendServerDescriptions = AwsElbLoadBalancerBackendServerDescription[];
export interface AwsElbLoadBalancerHealthCheck {
    HealthyThreshold?: number;
    Interval?: number;
    Target?: string;
    Timeout?: number;
    UnhealthyThreshold?: number;
}
export interface AwsElbLoadBalancerInstance {
    InstanceId?: string;
}
export type AwsElbLoadBalancerInstances = AwsElbLoadBalancerInstance[];
export interface AwsElbLoadBalancerListener {
    InstancePort?: number;
    InstanceProtocol?: string;
    LoadBalancerPort?: number;
    Protocol?: string;
    SslCertificateId?: string;
}
export interface AwsElbLoadBalancerListenerDescription {
    Listener?: AwsElbLoadBalancerListener;
    PolicyNames?: string[];
}
export type AwsElbLoadBalancerListenerDescriptions = AwsElbLoadBalancerListenerDescription[];
export interface AwsElbLoadBalancerAccessLog {
    EmitInterval?: number;
    Enabled?: boolean;
    S3BucketName?: string;
    S3BucketPrefix?: string;
}
export interface AwsElbLoadBalancerConnectionDraining {
    Enabled?: boolean;
    Timeout?: number;
}
export interface AwsElbLoadBalancerConnectionSettings {
    IdleTimeout?: number;
}
export interface AwsElbLoadBalancerCrossZoneLoadBalancing {
    Enabled?: boolean;
}
export interface AwsElbLoadBalancerAdditionalAttribute {
    Key?: string;
    Value?: string;
}
export type AwsElbLoadBalancerAdditionalAttributeList = AwsElbLoadBalancerAdditionalAttribute[];
export interface AwsElbLoadBalancerAttributes {
    AccessLog?: AwsElbLoadBalancerAccessLog;
    ConnectionDraining?: AwsElbLoadBalancerConnectionDraining;
    ConnectionSettings?: AwsElbLoadBalancerConnectionSettings;
    CrossZoneLoadBalancing?: AwsElbLoadBalancerCrossZoneLoadBalancing;
    AdditionalAttributes?: AwsElbLoadBalancerAdditionalAttribute[];
}
export interface AwsElbAppCookieStickinessPolicy {
    CookieName?: string;
    PolicyName?: string;
}
export type AwsElbAppCookieStickinessPolicies = AwsElbAppCookieStickinessPolicy[];
export interface AwsElbLbCookieStickinessPolicy {
    CookieExpirationPeriod?: number;
    PolicyName?: string;
}
export type AwsElbLbCookieStickinessPolicies = AwsElbLbCookieStickinessPolicy[];
export interface AwsElbLoadBalancerPolicies {
    AppCookieStickinessPolicies?: AwsElbAppCookieStickinessPolicy[];
    LbCookieStickinessPolicies?: AwsElbLbCookieStickinessPolicy[];
    OtherPolicies?: string[];
}
export interface AwsElbLoadBalancerSourceSecurityGroup {
    GroupName?: string;
    OwnerAlias?: string;
}
export interface AwsElbLoadBalancerDetails {
    AvailabilityZones?: string[];
    BackendServerDescriptions?: AwsElbLoadBalancerBackendServerDescription[];
    CanonicalHostedZoneName?: string;
    CanonicalHostedZoneNameID?: string;
    CreatedTime?: string;
    DnsName?: string;
    HealthCheck?: AwsElbLoadBalancerHealthCheck;
    Instances?: AwsElbLoadBalancerInstance[];
    ListenerDescriptions?: AwsElbLoadBalancerListenerDescription[];
    LoadBalancerAttributes?: AwsElbLoadBalancerAttributes;
    LoadBalancerName?: string;
    Policies?: AwsElbLoadBalancerPolicies;
    Scheme?: string;
    SecurityGroups?: string[];
    SourceSecurityGroup?: AwsElbLoadBalancerSourceSecurityGroup;
    Subnets?: string[];
    VpcId?: string;
}
export interface AwsIamGroupPolicy {
    PolicyName?: string;
}
export type AwsIamGroupPolicyList = AwsIamGroupPolicy[];
export interface AwsIamGroupDetails {
    AttachedManagedPolicies?: AwsIamAttachedManagedPolicy[];
    CreateDate?: string;
    GroupId?: string;
    GroupName?: string;
    GroupPolicyList?: AwsIamGroupPolicy[];
    Path?: string;
}
export type AwsIamRoleAssumeRolePolicyDocument = string;
export interface AwsIamInstanceProfileRole {
    Arn?: string;
    AssumeRolePolicyDocument?: string;
    CreateDate?: string;
    Path?: string;
    RoleId?: string;
    RoleName?: string;
}
export type AwsIamInstanceProfileRoles = AwsIamInstanceProfileRole[];
export interface AwsIamInstanceProfile {
    Arn?: string;
    CreateDate?: string;
    InstanceProfileId?: string;
    InstanceProfileName?: string;
    Path?: string;
    Roles?: AwsIamInstanceProfileRole[];
}
export type AwsIamInstanceProfileList = AwsIamInstanceProfile[];
export interface AwsIamRolePolicy {
    PolicyName?: string;
}
export type AwsIamRolePolicyList = AwsIamRolePolicy[];
export interface AwsIamRoleDetails {
    AssumeRolePolicyDocument?: string;
    AttachedManagedPolicies?: AwsIamAttachedManagedPolicy[];
    CreateDate?: string;
    InstanceProfileList?: AwsIamInstanceProfile[];
    PermissionsBoundary?: AwsIamPermissionsBoundary;
    RoleId?: string;
    RoleName?: string;
    RolePolicyList?: AwsIamRolePolicy[];
    MaxSessionDuration?: number;
    Path?: string;
}
export interface AwsKmsKeyDetails {
    AWSAccountId?: string;
    CreationDate?: number;
    KeyId?: string;
    KeyManager?: string;
    KeyState?: string;
    Origin?: string;
    Description?: string;
    KeyRotationStatus?: boolean;
}
export interface AwsLambdaFunctionCode {
    S3Bucket?: string;
    S3Key?: string;
    S3ObjectVersion?: string;
    ZipFile?: string;
}
export interface AwsLambdaFunctionDeadLetterConfig {
    TargetArn?: string;
}
export interface AwsLambdaFunctionEnvironmentError {
    ErrorCode?: string;
    Message?: string;
}
export interface AwsLambdaFunctionEnvironment {
    Variables?: {
        [key: string]: string | undefined;
    };
    Error?: AwsLambdaFunctionEnvironmentError;
}
export interface AwsLambdaFunctionLayer {
    Arn?: string;
    CodeSize?: number;
}
export type AwsLambdaFunctionLayerList = AwsLambdaFunctionLayer[];
export interface AwsLambdaFunctionTracingConfig {
    Mode?: string;
}
export interface AwsLambdaFunctionVpcConfig {
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    VpcId?: string;
}
export interface AwsLambdaFunctionDetails {
    Code?: AwsLambdaFunctionCode;
    CodeSha256?: string;
    DeadLetterConfig?: AwsLambdaFunctionDeadLetterConfig;
    Environment?: AwsLambdaFunctionEnvironment;
    FunctionName?: string;
    Handler?: string;
    KmsKeyArn?: string;
    LastModified?: string;
    Layers?: AwsLambdaFunctionLayer[];
    MasterArn?: string;
    MemorySize?: number;
    RevisionId?: string;
    Role?: string;
    Runtime?: string;
    Timeout?: number;
    TracingConfig?: AwsLambdaFunctionTracingConfig;
    VpcConfig?: AwsLambdaFunctionVpcConfig;
    Version?: string;
    Architectures?: string[];
    PackageType?: string;
}
export type AwsLambdaLayerVersionNumber = number;
export interface AwsLambdaLayerVersionDetails {
    Version?: number;
    CompatibleRuntimes?: string[];
    CreatedDate?: string;
}
export interface AwsRdsDbInstanceAssociatedRole {
    RoleArn?: string;
    FeatureName?: string;
    Status?: string;
}
export type AwsRdsDbInstanceAssociatedRoles = AwsRdsDbInstanceAssociatedRole[];
export interface AwsRdsDbInstanceEndpoint {
    Address?: string;
    Port?: number;
    HostedZoneId?: string;
}
export interface AwsRdsDbInstanceVpcSecurityGroup {
    VpcSecurityGroupId?: string;
    Status?: string;
}
export type AwsRdsDbInstanceVpcSecurityGroups = AwsRdsDbInstanceVpcSecurityGroup[];
export interface AwsRdsDbParameterGroup {
    DbParameterGroupName?: string;
    ParameterApplyStatus?: string;
}
export type AwsRdsDbParameterGroups = AwsRdsDbParameterGroup[];
export interface AwsRdsDbSubnetGroupSubnetAvailabilityZone {
    Name?: string;
}
export interface AwsRdsDbSubnetGroupSubnet {
    SubnetIdentifier?: string;
    SubnetAvailabilityZone?: AwsRdsDbSubnetGroupSubnetAvailabilityZone;
    SubnetStatus?: string;
}
export type AwsRdsDbSubnetGroupSubnets = AwsRdsDbSubnetGroupSubnet[];
export interface AwsRdsDbSubnetGroup {
    DbSubnetGroupName?: string;
    DbSubnetGroupDescription?: string;
    VpcId?: string;
    SubnetGroupStatus?: string;
    Subnets?: AwsRdsDbSubnetGroupSubnet[];
    DbSubnetGroupArn?: string;
}
export interface AwsRdsPendingCloudWatchLogsExports {
    LogTypesToEnable?: string[];
    LogTypesToDisable?: string[];
}
export interface AwsRdsDbProcessorFeature {
    Name?: string;
    Value?: string;
}
export type AwsRdsDbProcessorFeatures = AwsRdsDbProcessorFeature[];
export interface AwsRdsDbPendingModifiedValues {
    DbInstanceClass?: string;
    AllocatedStorage?: number;
    MasterUserPassword?: string;
    Port?: number;
    BackupRetentionPeriod?: number;
    MultiAZ?: boolean;
    EngineVersion?: string;
    LicenseModel?: string;
    Iops?: number;
    DbInstanceIdentifier?: string;
    StorageType?: string;
    CaCertificateIdentifier?: string;
    DbSubnetGroupName?: string;
    PendingCloudWatchLogsExports?: AwsRdsPendingCloudWatchLogsExports;
    ProcessorFeatures?: AwsRdsDbProcessorFeature[];
}
export interface AwsRdsDbOptionGroupMembership {
    OptionGroupName?: string;
    Status?: string;
}
export type AwsRdsDbOptionGroupMemberships = AwsRdsDbOptionGroupMembership[];
export interface AwsRdsDbStatusInfo {
    StatusType?: string;
    Normal?: boolean;
    Status?: string;
    Message?: string;
}
export type AwsRdsDbStatusInfos = AwsRdsDbStatusInfo[];
export interface AwsRdsDbDomainMembership {
    Domain?: string;
    Status?: string;
    Fqdn?: string;
    IamRoleName?: string;
}
export type AwsRdsDbDomainMemberships = AwsRdsDbDomainMembership[];
export interface AwsRdsDbInstanceDetails {
    AssociatedRoles?: AwsRdsDbInstanceAssociatedRole[];
    CACertificateIdentifier?: string;
    DBClusterIdentifier?: string;
    DBInstanceIdentifier?: string;
    DBInstanceClass?: string;
    DbInstancePort?: number;
    DbiResourceId?: string;
    DBName?: string;
    DeletionProtection?: boolean;
    Endpoint?: AwsRdsDbInstanceEndpoint;
    Engine?: string;
    EngineVersion?: string;
    IAMDatabaseAuthenticationEnabled?: boolean;
    InstanceCreateTime?: string;
    KmsKeyId?: string;
    PubliclyAccessible?: boolean;
    StorageEncrypted?: boolean;
    TdeCredentialArn?: string;
    VpcSecurityGroups?: AwsRdsDbInstanceVpcSecurityGroup[];
    MultiAz?: boolean;
    EnhancedMonitoringResourceArn?: string;
    DbInstanceStatus?: string;
    MasterUsername?: string;
    AllocatedStorage?: number;
    PreferredBackupWindow?: string;
    BackupRetentionPeriod?: number;
    DbSecurityGroups?: string[];
    DbParameterGroups?: AwsRdsDbParameterGroup[];
    AvailabilityZone?: string;
    DbSubnetGroup?: AwsRdsDbSubnetGroup;
    PreferredMaintenanceWindow?: string;
    PendingModifiedValues?: AwsRdsDbPendingModifiedValues;
    LatestRestorableTime?: string;
    AutoMinorVersionUpgrade?: boolean;
    ReadReplicaSourceDBInstanceIdentifier?: string;
    ReadReplicaDBInstanceIdentifiers?: string[];
    ReadReplicaDBClusterIdentifiers?: string[];
    LicenseModel?: string;
    Iops?: number;
    OptionGroupMemberships?: AwsRdsDbOptionGroupMembership[];
    CharacterSetName?: string;
    SecondaryAvailabilityZone?: string;
    StatusInfos?: AwsRdsDbStatusInfo[];
    StorageType?: string;
    DomainMemberships?: AwsRdsDbDomainMembership[];
    CopyTagsToSnapshot?: boolean;
    MonitoringInterval?: number;
    MonitoringRoleArn?: string;
    PromotionTier?: number;
    Timezone?: string;
    PerformanceInsightsEnabled?: boolean;
    PerformanceInsightsKmsKeyId?: string;
    PerformanceInsightsRetentionPeriod?: number;
    EnabledCloudWatchLogsExports?: string[];
    ProcessorFeatures?: AwsRdsDbProcessorFeature[];
    ListenerEndpoint?: AwsRdsDbInstanceEndpoint;
    MaxAllocatedStorage?: number;
}
export interface AwsSnsTopicSubscription {
    Endpoint?: string;
    Protocol?: string;
}
export type AwsSnsTopicSubscriptionList = AwsSnsTopicSubscription[];
export interface AwsSnsTopicDetails {
    KmsMasterKeyId?: string;
    Subscription?: AwsSnsTopicSubscription[];
    TopicName?: string;
    Owner?: string;
    SqsSuccessFeedbackRoleArn?: string;
    SqsFailureFeedbackRoleArn?: string;
    ApplicationSuccessFeedbackRoleArn?: string;
    FirehoseSuccessFeedbackRoleArn?: string;
    FirehoseFailureFeedbackRoleArn?: string;
    HttpSuccessFeedbackRoleArn?: string;
    HttpFailureFeedbackRoleArn?: string;
}
export interface AwsSqsQueueDetails {
    KmsDataKeyReusePeriodSeconds?: number;
    KmsMasterKeyId?: string;
    QueueName?: string;
    DeadLetterTargetArn?: string;
}
export interface WafAction {
    Type?: string;
}
export interface WafExcludedRule {
    RuleId?: string;
}
export type WafExcludedRuleList = WafExcludedRule[];
export interface WafOverrideAction {
    Type?: string;
}
export interface AwsWafWebAclRule {
    Action?: WafAction;
    ExcludedRules?: WafExcludedRule[];
    OverrideAction?: WafOverrideAction;
    Priority?: number;
    RuleId?: string;
    Type?: string;
}
export type AwsWafWebAclRuleList = AwsWafWebAclRule[];
export interface AwsWafWebAclDetails {
    Name?: string;
    DefaultAction?: string;
    Rules?: AwsWafWebAclRule[];
    WebAclId?: string;
}
export interface AwsRdsDbSnapshotDetails {
    DbSnapshotIdentifier?: string;
    DbInstanceIdentifier?: string;
    SnapshotCreateTime?: string;
    Engine?: string;
    AllocatedStorage?: number;
    Status?: string;
    Port?: number;
    AvailabilityZone?: string;
    VpcId?: string;
    InstanceCreateTime?: string;
    MasterUsername?: string;
    EngineVersion?: string;
    LicenseModel?: string;
    SnapshotType?: string;
    Iops?: number;
    OptionGroupName?: string;
    PercentProgress?: number;
    SourceRegion?: string;
    SourceDbSnapshotIdentifier?: string;
    StorageType?: string;
    TdeCredentialArn?: string;
    Encrypted?: boolean;
    KmsKeyId?: string;
    Timezone?: string;
    IamDatabaseAuthenticationEnabled?: boolean;
    ProcessorFeatures?: AwsRdsDbProcessorFeature[];
    DbiResourceId?: string;
}
export interface AwsRdsDbClusterSnapshotDbClusterSnapshotAttribute {
    AttributeName?: string;
    AttributeValues?: string[];
}
export type AwsRdsDbClusterSnapshotDbClusterSnapshotAttributes = AwsRdsDbClusterSnapshotDbClusterSnapshotAttribute[];
export interface AwsRdsDbClusterSnapshotDetails {
    AvailabilityZones?: string[];
    SnapshotCreateTime?: string;
    Engine?: string;
    AllocatedStorage?: number;
    Status?: string;
    Port?: number;
    VpcId?: string;
    ClusterCreateTime?: string;
    MasterUsername?: string;
    EngineVersion?: string;
    LicenseModel?: string;
    SnapshotType?: string;
    PercentProgress?: number;
    StorageEncrypted?: boolean;
    KmsKeyId?: string;
    DbClusterIdentifier?: string;
    DbClusterSnapshotIdentifier?: string;
    IamDatabaseAuthenticationEnabled?: boolean;
    DbClusterSnapshotAttributes?: AwsRdsDbClusterSnapshotDbClusterSnapshotAttribute[];
}
export interface AwsRdsDbClusterAssociatedRole {
    RoleArn?: string;
    Status?: string;
}
export type AwsRdsDbClusterAssociatedRoles = AwsRdsDbClusterAssociatedRole[];
export interface AwsRdsDbClusterOptionGroupMembership {
    DbClusterOptionGroupName?: string;
    Status?: string;
}
export type AwsRdsDbClusterOptionGroupMemberships = AwsRdsDbClusterOptionGroupMembership[];
export interface AwsRdsDbClusterMember {
    IsClusterWriter?: boolean;
    PromotionTier?: number;
    DbInstanceIdentifier?: string;
    DbClusterParameterGroupStatus?: string;
}
export type AwsRdsDbClusterMembers = AwsRdsDbClusterMember[];
export interface AwsRdsDbClusterDetails {
    AllocatedStorage?: number;
    AvailabilityZones?: string[];
    BackupRetentionPeriod?: number;
    DatabaseName?: string;
    Status?: string;
    Endpoint?: string;
    ReaderEndpoint?: string;
    CustomEndpoints?: string[];
    MultiAz?: boolean;
    Engine?: string;
    EngineVersion?: string;
    Port?: number;
    MasterUsername?: string;
    PreferredBackupWindow?: string;
    PreferredMaintenanceWindow?: string;
    ReadReplicaIdentifiers?: string[];
    VpcSecurityGroups?: AwsRdsDbInstanceVpcSecurityGroup[];
    HostedZoneId?: string;
    StorageEncrypted?: boolean;
    KmsKeyId?: string;
    DbClusterResourceId?: string;
    AssociatedRoles?: AwsRdsDbClusterAssociatedRole[];
    ClusterCreateTime?: string;
    EnabledCloudWatchLogsExports?: string[];
    EngineMode?: string;
    DeletionProtection?: boolean;
    HttpEndpointEnabled?: boolean;
    ActivityStreamStatus?: string;
    CopyTagsToSnapshot?: boolean;
    CrossAccountClone?: boolean;
    DomainMemberships?: AwsRdsDbDomainMembership[];
    DbClusterParameterGroup?: string;
    DbSubnetGroup?: string;
    DbClusterOptionGroupMemberships?: AwsRdsDbClusterOptionGroupMembership[];
    DbClusterIdentifier?: string;
    DbClusterMembers?: AwsRdsDbClusterMember[];
    IamDatabaseAuthenticationEnabled?: boolean;
    AutoMinorVersionUpgrade?: boolean;
}
export interface AwsEcsClusterClusterSettingsDetails {
    Name?: string;
    Value?: string;
}
export type AwsEcsClusterClusterSettingsList = AwsEcsClusterClusterSettingsDetails[];
export interface AwsEcsClusterConfigurationExecuteCommandConfigurationLogConfigurationDetails {
    CloudWatchEncryptionEnabled?: boolean;
    CloudWatchLogGroupName?: string;
    S3BucketName?: string;
    S3EncryptionEnabled?: boolean;
    S3KeyPrefix?: string;
}
export interface AwsEcsClusterConfigurationExecuteCommandConfigurationDetails {
    KmsKeyId?: string;
    LogConfiguration?: AwsEcsClusterConfigurationExecuteCommandConfigurationLogConfigurationDetails;
    Logging?: string;
}
export interface AwsEcsClusterConfigurationDetails {
    ExecuteCommandConfiguration?: AwsEcsClusterConfigurationExecuteCommandConfigurationDetails;
}
export interface AwsEcsClusterDefaultCapacityProviderStrategyDetails {
    Base?: number;
    CapacityProvider?: string;
    Weight?: number;
}
export type AwsEcsClusterDefaultCapacityProviderStrategyList = AwsEcsClusterDefaultCapacityProviderStrategyDetails[];
export interface AwsEcsClusterDetails {
    ClusterArn?: string;
    ActiveServicesCount?: number;
    CapacityProviders?: string[];
    ClusterSettings?: AwsEcsClusterClusterSettingsDetails[];
    Configuration?: AwsEcsClusterConfigurationDetails;
    DefaultCapacityProviderStrategy?: AwsEcsClusterDefaultCapacityProviderStrategyDetails[];
    ClusterName?: string;
    RegisteredContainerInstancesCount?: number;
    RunningTasksCount?: number;
    Status?: string;
}
export interface AwsMountPoint {
    SourceVolume?: string;
    ContainerPath?: string;
}
export type AwsMountPointList = AwsMountPoint[];
export interface AwsEcsContainerDetails {
    Name?: string;
    Image?: string;
    MountPoints?: AwsMountPoint[];
    Privileged?: boolean;
}
export interface AwsEcsTaskDefinitionContainerDefinitionsDependsOnDetails {
    Condition?: string;
    ContainerName?: string;
}
export type AwsEcsTaskDefinitionContainerDefinitionsDependsOnList = AwsEcsTaskDefinitionContainerDefinitionsDependsOnDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsEnvironmentDetails {
    Name?: string;
    Value?: string;
}
export type AwsEcsTaskDefinitionContainerDefinitionsEnvironmentList = AwsEcsTaskDefinitionContainerDefinitionsEnvironmentDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsEnvironmentFilesDetails {
    Type?: string;
    Value?: string;
}
export type AwsEcsTaskDefinitionContainerDefinitionsEnvironmentFilesList = AwsEcsTaskDefinitionContainerDefinitionsEnvironmentFilesDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsExtraHostsDetails {
    Hostname?: string;
    IpAddress?: string;
}
export type AwsEcsTaskDefinitionContainerDefinitionsExtraHostsList = AwsEcsTaskDefinitionContainerDefinitionsExtraHostsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsFirelensConfigurationDetails {
    Options?: {
        [key: string]: string | undefined;
    };
    Type?: string;
}
export interface AwsEcsTaskDefinitionContainerDefinitionsHealthCheckDetails {
    Command?: string[];
    Interval?: number;
    Retries?: number;
    StartPeriod?: number;
    Timeout?: number;
}
export interface AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersCapabilitiesDetails {
    Add?: string[];
    Drop?: string[];
}
export interface AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersDevicesDetails {
    ContainerPath?: string;
    HostPath?: string;
    Permissions?: string[];
}
export type AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersDevicesList = AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersDevicesDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersTmpfsDetails {
    ContainerPath?: string;
    MountOptions?: string[];
    Size?: number;
}
export type AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersTmpfsList = AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersTmpfsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersDetails {
    Capabilities?: AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersCapabilitiesDetails;
    Devices?: AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersDevicesDetails[];
    InitProcessEnabled?: boolean;
    MaxSwap?: number;
    SharedMemorySize?: number;
    Swappiness?: number;
    Tmpfs?: AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersTmpfsDetails[];
}
export interface AwsEcsTaskDefinitionContainerDefinitionsLogConfigurationSecretOptionsDetails {
    Name?: string;
    ValueFrom?: string;
}
export type AwsEcsTaskDefinitionContainerDefinitionsLogConfigurationSecretOptionsList = AwsEcsTaskDefinitionContainerDefinitionsLogConfigurationSecretOptionsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsLogConfigurationDetails {
    LogDriver?: string;
    Options?: {
        [key: string]: string | undefined;
    };
    SecretOptions?: AwsEcsTaskDefinitionContainerDefinitionsLogConfigurationSecretOptionsDetails[];
}
export interface AwsEcsTaskDefinitionContainerDefinitionsMountPointsDetails {
    ContainerPath?: string;
    ReadOnly?: boolean;
    SourceVolume?: string;
}
export type AwsEcsTaskDefinitionContainerDefinitionsMountPointsList = AwsEcsTaskDefinitionContainerDefinitionsMountPointsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsPortMappingsDetails {
    ContainerPort?: number;
    HostPort?: number;
    Protocol?: string;
}
export type AwsEcsTaskDefinitionContainerDefinitionsPortMappingsList = AwsEcsTaskDefinitionContainerDefinitionsPortMappingsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsRepositoryCredentialsDetails {
    CredentialsParameter?: string;
}
export interface AwsEcsTaskDefinitionContainerDefinitionsResourceRequirementsDetails {
    Type?: string;
    Value?: string;
}
export type AwsEcsTaskDefinitionContainerDefinitionsResourceRequirementsList = AwsEcsTaskDefinitionContainerDefinitionsResourceRequirementsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsSecretsDetails {
    Name?: string;
    ValueFrom?: string;
}
export type AwsEcsTaskDefinitionContainerDefinitionsSecretsList = AwsEcsTaskDefinitionContainerDefinitionsSecretsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsSystemControlsDetails {
    Namespace?: string;
    Value?: string;
}
export type AwsEcsTaskDefinitionContainerDefinitionsSystemControlsList = AwsEcsTaskDefinitionContainerDefinitionsSystemControlsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsUlimitsDetails {
    HardLimit?: number;
    Name?: string;
    SoftLimit?: number;
}
export type AwsEcsTaskDefinitionContainerDefinitionsUlimitsList = AwsEcsTaskDefinitionContainerDefinitionsUlimitsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsVolumesFromDetails {
    ReadOnly?: boolean;
    SourceContainer?: string;
}
export type AwsEcsTaskDefinitionContainerDefinitionsVolumesFromList = AwsEcsTaskDefinitionContainerDefinitionsVolumesFromDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsDetails {
    Command?: string[];
    Cpu?: number;
    DependsOn?: AwsEcsTaskDefinitionContainerDefinitionsDependsOnDetails[];
    DisableNetworking?: boolean;
    DnsSearchDomains?: string[];
    DnsServers?: string[];
    DockerLabels?: {
        [key: string]: string | undefined;
    };
    DockerSecurityOptions?: string[];
    EntryPoint?: string[];
    Environment?: AwsEcsTaskDefinitionContainerDefinitionsEnvironmentDetails[];
    EnvironmentFiles?: AwsEcsTaskDefinitionContainerDefinitionsEnvironmentFilesDetails[];
    Essential?: boolean;
    ExtraHosts?: AwsEcsTaskDefinitionContainerDefinitionsExtraHostsDetails[];
    FirelensConfiguration?: AwsEcsTaskDefinitionContainerDefinitionsFirelensConfigurationDetails;
    HealthCheck?: AwsEcsTaskDefinitionContainerDefinitionsHealthCheckDetails;
    Hostname?: string;
    Image?: string;
    Interactive?: boolean;
    Links?: string[];
    LinuxParameters?: AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersDetails;
    LogConfiguration?: AwsEcsTaskDefinitionContainerDefinitionsLogConfigurationDetails;
    Memory?: number;
    MemoryReservation?: number;
    MountPoints?: AwsEcsTaskDefinitionContainerDefinitionsMountPointsDetails[];
    Name?: string;
    PortMappings?: AwsEcsTaskDefinitionContainerDefinitionsPortMappingsDetails[];
    Privileged?: boolean;
    PseudoTerminal?: boolean;
    ReadonlyRootFilesystem?: boolean;
    RepositoryCredentials?: AwsEcsTaskDefinitionContainerDefinitionsRepositoryCredentialsDetails;
    ResourceRequirements?: AwsEcsTaskDefinitionContainerDefinitionsResourceRequirementsDetails[];
    Secrets?: AwsEcsTaskDefinitionContainerDefinitionsSecretsDetails[];
    StartTimeout?: number;
    StopTimeout?: number;
    SystemControls?: AwsEcsTaskDefinitionContainerDefinitionsSystemControlsDetails[];
    Ulimits?: AwsEcsTaskDefinitionContainerDefinitionsUlimitsDetails[];
    User?: string;
    VolumesFrom?: AwsEcsTaskDefinitionContainerDefinitionsVolumesFromDetails[];
    WorkingDirectory?: string;
}
export type AwsEcsTaskDefinitionContainerDefinitionsList = AwsEcsTaskDefinitionContainerDefinitionsDetails[];
export interface AwsEcsTaskDefinitionInferenceAcceleratorsDetails {
    DeviceName?: string;
    DeviceType?: string;
}
export type AwsEcsTaskDefinitionInferenceAcceleratorsList = AwsEcsTaskDefinitionInferenceAcceleratorsDetails[];
export interface AwsEcsTaskDefinitionPlacementConstraintsDetails {
    Expression?: string;
    Type?: string;
}
export type AwsEcsTaskDefinitionPlacementConstraintsList = AwsEcsTaskDefinitionPlacementConstraintsDetails[];
export interface AwsEcsTaskDefinitionProxyConfigurationProxyConfigurationPropertiesDetails {
    Name?: string;
    Value?: string;
}
export type AwsEcsTaskDefinitionProxyConfigurationProxyConfigurationPropertiesList = AwsEcsTaskDefinitionProxyConfigurationProxyConfigurationPropertiesDetails[];
export interface AwsEcsTaskDefinitionProxyConfigurationDetails {
    ContainerName?: string;
    ProxyConfigurationProperties?: AwsEcsTaskDefinitionProxyConfigurationProxyConfigurationPropertiesDetails[];
    Type?: string;
}
export interface AwsEcsTaskDefinitionVolumesDockerVolumeConfigurationDetails {
    Autoprovision?: boolean;
    Driver?: string;
    DriverOpts?: {
        [key: string]: string | undefined;
    };
    Labels?: {
        [key: string]: string | undefined;
    };
    Scope?: string;
}
export interface AwsEcsTaskDefinitionVolumesEfsVolumeConfigurationAuthorizationConfigDetails {
    AccessPointId?: string;
    Iam?: string;
}
export interface AwsEcsTaskDefinitionVolumesEfsVolumeConfigurationDetails {
    AuthorizationConfig?: AwsEcsTaskDefinitionVolumesEfsVolumeConfigurationAuthorizationConfigDetails;
    FilesystemId?: string;
    RootDirectory?: string;
    TransitEncryption?: string;
    TransitEncryptionPort?: number;
}
export interface AwsEcsTaskDefinitionVolumesHostDetails {
    SourcePath?: string;
}
export interface AwsEcsTaskDefinitionVolumesDetails {
    DockerVolumeConfiguration?: AwsEcsTaskDefinitionVolumesDockerVolumeConfigurationDetails;
    EfsVolumeConfiguration?: AwsEcsTaskDefinitionVolumesEfsVolumeConfigurationDetails;
    Host?: AwsEcsTaskDefinitionVolumesHostDetails;
    Name?: string;
}
export type AwsEcsTaskDefinitionVolumesList = AwsEcsTaskDefinitionVolumesDetails[];
export interface AwsEcsTaskDefinitionDetails {
    ContainerDefinitions?: AwsEcsTaskDefinitionContainerDefinitionsDetails[];
    Cpu?: string;
    ExecutionRoleArn?: string;
    Family?: string;
    InferenceAccelerators?: AwsEcsTaskDefinitionInferenceAcceleratorsDetails[];
    IpcMode?: string;
    Memory?: string;
    NetworkMode?: string;
    PidMode?: string;
    PlacementConstraints?: AwsEcsTaskDefinitionPlacementConstraintsDetails[];
    ProxyConfiguration?: AwsEcsTaskDefinitionProxyConfigurationDetails;
    RequiresCompatibilities?: string[];
    TaskRoleArn?: string;
    Volumes?: AwsEcsTaskDefinitionVolumesDetails[];
    Status?: string;
}
export interface VolumeMount {
    Name?: string;
    MountPath?: string;
}
export type VolumeMountList = VolumeMount[];
export interface ContainerDetails {
    ContainerRuntime?: string;
    Name?: string;
    ImageId?: string;
    ImageName?: string;
    LaunchedAt?: string;
    VolumeMounts?: VolumeMount[];
    Privileged?: boolean;
}
export interface AwsRdsEventSubscriptionDetails {
    CustSubscriptionId?: string;
    CustomerAwsId?: string;
    Enabled?: boolean;
    EventCategoriesList?: string[];
    EventSubscriptionArn?: string;
    SnsTopicArn?: string;
    SourceIdsList?: string[];
    SourceType?: string;
    Status?: string;
    SubscriptionCreationTime?: string;
}
export interface AwsEcsServiceCapacityProviderStrategyDetails {
    Base?: number;
    CapacityProvider?: string;
    Weight?: number;
}
export type AwsEcsServiceCapacityProviderStrategyList = AwsEcsServiceCapacityProviderStrategyDetails[];
export interface AwsEcsServiceDeploymentConfigurationDeploymentCircuitBreakerDetails {
    Enable?: boolean;
    Rollback?: boolean;
}
export interface AwsEcsServiceDeploymentConfigurationDetails {
    DeploymentCircuitBreaker?: AwsEcsServiceDeploymentConfigurationDeploymentCircuitBreakerDetails;
    MaximumPercent?: number;
    MinimumHealthyPercent?: number;
}
export interface AwsEcsServiceDeploymentControllerDetails {
    Type?: string;
}
export interface AwsEcsServiceLoadBalancersDetails {
    ContainerName?: string;
    ContainerPort?: number;
    LoadBalancerName?: string;
    TargetGroupArn?: string;
}
export type AwsEcsServiceLoadBalancersList = AwsEcsServiceLoadBalancersDetails[];
export interface AwsEcsServiceNetworkConfigurationAwsVpcConfigurationDetails {
    AssignPublicIp?: string;
    SecurityGroups?: string[];
    Subnets?: string[];
}
export interface AwsEcsServiceNetworkConfigurationDetails {
    AwsVpcConfiguration?: AwsEcsServiceNetworkConfigurationAwsVpcConfigurationDetails;
}
export interface AwsEcsServicePlacementConstraintsDetails {
    Expression?: string;
    Type?: string;
}
export type AwsEcsServicePlacementConstraintsList = AwsEcsServicePlacementConstraintsDetails[];
export interface AwsEcsServicePlacementStrategiesDetails {
    Field?: string;
    Type?: string;
}
export type AwsEcsServicePlacementStrategiesList = AwsEcsServicePlacementStrategiesDetails[];
export interface AwsEcsServiceServiceRegistriesDetails {
    ContainerName?: string;
    ContainerPort?: number;
    Port?: number;
    RegistryArn?: string;
}
export type AwsEcsServiceServiceRegistriesList = AwsEcsServiceServiceRegistriesDetails[];
export interface AwsEcsServiceDetails {
    CapacityProviderStrategy?: AwsEcsServiceCapacityProviderStrategyDetails[];
    Cluster?: string;
    DeploymentConfiguration?: AwsEcsServiceDeploymentConfigurationDetails;
    DeploymentController?: AwsEcsServiceDeploymentControllerDetails;
    DesiredCount?: number;
    EnableEcsManagedTags?: boolean;
    EnableExecuteCommand?: boolean;
    HealthCheckGracePeriodSeconds?: number;
    LaunchType?: string;
    LoadBalancers?: AwsEcsServiceLoadBalancersDetails[];
    Name?: string;
    NetworkConfiguration?: AwsEcsServiceNetworkConfigurationDetails;
    PlacementConstraints?: AwsEcsServicePlacementConstraintsDetails[];
    PlacementStrategies?: AwsEcsServicePlacementStrategiesDetails[];
    PlatformVersion?: string;
    PropagateTags?: string;
    Role?: string;
    SchedulingStrategy?: string;
    ServiceArn?: string;
    ServiceName?: string;
    ServiceRegistries?: AwsEcsServiceServiceRegistriesDetails[];
    TaskDefinition?: string;
}
export interface AwsAutoScalingLaunchConfigurationBlockDeviceMappingsEbsDetails {
    DeleteOnTermination?: boolean;
    Encrypted?: boolean;
    Iops?: number;
    SnapshotId?: string;
    VolumeSize?: number;
    VolumeType?: string;
}
export interface AwsAutoScalingLaunchConfigurationBlockDeviceMappingsDetails {
    DeviceName?: string;
    Ebs?: AwsAutoScalingLaunchConfigurationBlockDeviceMappingsEbsDetails;
    NoDevice?: boolean;
    VirtualName?: string;
}
export type AwsAutoScalingLaunchConfigurationBlockDeviceMappingsList = AwsAutoScalingLaunchConfigurationBlockDeviceMappingsDetails[];
export interface AwsAutoScalingLaunchConfigurationInstanceMonitoringDetails {
    Enabled?: boolean;
}
export interface AwsAutoScalingLaunchConfigurationMetadataOptions {
    HttpEndpoint?: string;
    HttpPutResponseHopLimit?: number;
    HttpTokens?: string;
}
export interface AwsAutoScalingLaunchConfigurationDetails {
    AssociatePublicIpAddress?: boolean;
    BlockDeviceMappings?: AwsAutoScalingLaunchConfigurationBlockDeviceMappingsDetails[];
    ClassicLinkVpcId?: string;
    ClassicLinkVpcSecurityGroups?: string[];
    CreatedTime?: string;
    EbsOptimized?: boolean;
    IamInstanceProfile?: string;
    ImageId?: string;
    InstanceMonitoring?: AwsAutoScalingLaunchConfigurationInstanceMonitoringDetails;
    InstanceType?: string;
    KernelId?: string;
    KeyName?: string;
    LaunchConfigurationName?: string;
    PlacementTenancy?: string;
    RamdiskId?: string;
    SecurityGroups?: string[];
    SpotPrice?: string;
    UserData?: string;
    MetadataOptions?: AwsAutoScalingLaunchConfigurationMetadataOptions;
}
export interface AwsEc2VpnConnectionVgwTelemetryDetails {
    AcceptedRouteCount?: number;
    CertificateArn?: string;
    LastStatusChange?: string;
    OutsideIpAddress?: string;
    Status?: string;
    StatusMessage?: string;
}
export type AwsEc2VpnConnectionVgwTelemetryList = AwsEc2VpnConnectionVgwTelemetryDetails[];
export interface AwsEc2VpnConnectionOptionsTunnelOptionsDetails {
    DpdTimeoutSeconds?: number;
    IkeVersions?: string[];
    OutsideIpAddress?: string;
    Phase1DhGroupNumbers?: number[];
    Phase1EncryptionAlgorithms?: string[];
    Phase1IntegrityAlgorithms?: string[];
    Phase1LifetimeSeconds?: number;
    Phase2DhGroupNumbers?: number[];
    Phase2EncryptionAlgorithms?: string[];
    Phase2IntegrityAlgorithms?: string[];
    Phase2LifetimeSeconds?: number;
    PreSharedKey?: string;
    RekeyFuzzPercentage?: number;
    RekeyMarginTimeSeconds?: number;
    ReplayWindowSize?: number;
    TunnelInsideCidr?: string;
}
export type AwsEc2VpnConnectionOptionsTunnelOptionsList = AwsEc2VpnConnectionOptionsTunnelOptionsDetails[];
export interface AwsEc2VpnConnectionOptionsDetails {
    StaticRoutesOnly?: boolean;
    TunnelOptions?: AwsEc2VpnConnectionOptionsTunnelOptionsDetails[];
}
export interface AwsEc2VpnConnectionRoutesDetails {
    DestinationCidrBlock?: string;
    State?: string;
}
export type AwsEc2VpnConnectionRoutesList = AwsEc2VpnConnectionRoutesDetails[];
export interface AwsEc2VpnConnectionDetails {
    VpnConnectionId?: string;
    State?: string;
    CustomerGatewayId?: string;
    CustomerGatewayConfiguration?: string;
    Type?: string;
    VpnGatewayId?: string;
    Category?: string;
    VgwTelemetry?: AwsEc2VpnConnectionVgwTelemetryDetails[];
    Options?: AwsEc2VpnConnectionOptionsDetails;
    Routes?: AwsEc2VpnConnectionRoutesDetails[];
    TransitGatewayId?: string;
}
export interface AwsEcrContainerImageDetails {
    RegistryId?: string;
    RepositoryName?: string;
    Architecture?: string;
    ImageDigest?: string;
    ImageTags?: string[];
    ImagePublishedAt?: string;
}
export interface AwsOpenSearchServiceDomainEncryptionAtRestOptionsDetails {
    Enabled?: boolean;
    KmsKeyId?: string;
}
export interface AwsOpenSearchServiceDomainNodeToNodeEncryptionOptionsDetails {
    Enabled?: boolean;
}
export interface AwsOpenSearchServiceDomainServiceSoftwareOptionsDetails {
    AutomatedUpdateDate?: string;
    Cancellable?: boolean;
    CurrentVersion?: string;
    Description?: string;
    NewVersion?: string;
    UpdateAvailable?: boolean;
    UpdateStatus?: string;
    OptionalDeployment?: boolean;
}
export interface AwsOpenSearchServiceDomainClusterConfigZoneAwarenessConfigDetails {
    AvailabilityZoneCount?: number;
}
export interface AwsOpenSearchServiceDomainClusterConfigDetails {
    InstanceCount?: number;
    WarmEnabled?: boolean;
    WarmCount?: number;
    DedicatedMasterEnabled?: boolean;
    ZoneAwarenessConfig?: AwsOpenSearchServiceDomainClusterConfigZoneAwarenessConfigDetails;
    DedicatedMasterCount?: number;
    InstanceType?: string;
    WarmType?: string;
    ZoneAwarenessEnabled?: boolean;
    DedicatedMasterType?: string;
}
export interface AwsOpenSearchServiceDomainDomainEndpointOptionsDetails {
    CustomEndpointCertificateArn?: string;
    CustomEndpointEnabled?: boolean;
    EnforceHTTPS?: boolean;
    CustomEndpoint?: string;
    TLSSecurityPolicy?: string;
}
export interface AwsOpenSearchServiceDomainVpcOptionsDetails {
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
}
export interface AwsOpenSearchServiceDomainLogPublishingOption {
    CloudWatchLogsLogGroupArn?: string;
    Enabled?: boolean;
}
export interface AwsOpenSearchServiceDomainLogPublishingOptionsDetails {
    IndexSlowLogs?: AwsOpenSearchServiceDomainLogPublishingOption;
    SearchSlowLogs?: AwsOpenSearchServiceDomainLogPublishingOption;
    AuditLogs?: AwsOpenSearchServiceDomainLogPublishingOption;
}
export interface AwsOpenSearchServiceDomainMasterUserOptionsDetails {
    MasterUserArn?: string;
    MasterUserName?: string;
    MasterUserPassword?: string;
}
export interface AwsOpenSearchServiceDomainAdvancedSecurityOptionsDetails {
    Enabled?: boolean;
    InternalUserDatabaseEnabled?: boolean;
    MasterUserOptions?: AwsOpenSearchServiceDomainMasterUserOptionsDetails;
}
export interface AwsOpenSearchServiceDomainDetails {
    Arn?: string;
    AccessPolicies?: string;
    DomainName?: string;
    Id?: string;
    DomainEndpoint?: string;
    EngineVersion?: string;
    EncryptionAtRestOptions?: AwsOpenSearchServiceDomainEncryptionAtRestOptionsDetails;
    NodeToNodeEncryptionOptions?: AwsOpenSearchServiceDomainNodeToNodeEncryptionOptionsDetails;
    ServiceSoftwareOptions?: AwsOpenSearchServiceDomainServiceSoftwareOptionsDetails;
    ClusterConfig?: AwsOpenSearchServiceDomainClusterConfigDetails;
    DomainEndpointOptions?: AwsOpenSearchServiceDomainDomainEndpointOptionsDetails;
    VpcOptions?: AwsOpenSearchServiceDomainVpcOptionsDetails;
    LogPublishingOptions?: AwsOpenSearchServiceDomainLogPublishingOptionsDetails;
    DomainEndpoints?: {
        [key: string]: string | undefined;
    };
    AdvancedSecurityOptions?: AwsOpenSearchServiceDomainAdvancedSecurityOptionsDetails;
}
export interface AwsEc2VpcEndpointServiceServiceTypeDetails {
    ServiceType?: string;
}
export type AwsEc2VpcEndpointServiceServiceTypeList = AwsEc2VpcEndpointServiceServiceTypeDetails[];
export interface AwsEc2VpcEndpointServiceDetails {
    AcceptanceRequired?: boolean;
    AvailabilityZones?: string[];
    BaseEndpointDnsNames?: string[];
    ManagesVpcEndpoints?: boolean;
    GatewayLoadBalancerArns?: string[];
    NetworkLoadBalancerArns?: string[];
    PrivateDnsName?: string;
    ServiceId?: string;
    ServiceName?: string;
    ServiceState?: string;
    ServiceType?: AwsEc2VpcEndpointServiceServiceTypeDetails[];
}
export interface AwsXrayEncryptionConfigDetails {
    KeyId?: string;
    Status?: string;
    Type?: string;
}
export interface AwsWafRateBasedRuleMatchPredicate {
    DataId?: string;
    Negated?: boolean;
    Type?: string;
}
export type AwsWafRateBasedRuleMatchPredicateList = AwsWafRateBasedRuleMatchPredicate[];
export interface AwsWafRateBasedRuleDetails {
    MetricName?: string;
    Name?: string;
    RateKey?: string;
    RateLimit?: number;
    RuleId?: string;
    MatchPredicates?: AwsWafRateBasedRuleMatchPredicate[];
}
export interface AwsWafRegionalRateBasedRuleMatchPredicate {
    DataId?: string;
    Negated?: boolean;
    Type?: string;
}
export type AwsWafRegionalRateBasedRuleMatchPredicateList = AwsWafRegionalRateBasedRuleMatchPredicate[];
export interface AwsWafRegionalRateBasedRuleDetails {
    MetricName?: string;
    Name?: string;
    RateKey?: string;
    RateLimit?: number;
    RuleId?: string;
    MatchPredicates?: AwsWafRegionalRateBasedRuleMatchPredicate[];
}
export interface AwsEcrRepositoryImageScanningConfigurationDetails {
    ScanOnPush?: boolean;
}
export interface AwsEcrRepositoryLifecyclePolicyDetails {
    LifecyclePolicyText?: string;
    RegistryId?: string;
}
export interface AwsEcrRepositoryDetails {
    Arn?: string;
    ImageScanningConfiguration?: AwsEcrRepositoryImageScanningConfigurationDetails;
    ImageTagMutability?: string;
    LifecyclePolicy?: AwsEcrRepositoryLifecyclePolicyDetails;
    RepositoryName?: string;
    RepositoryPolicyText?: string;
}
export interface AwsEksClusterResourcesVpcConfigDetails {
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    EndpointPublicAccess?: boolean;
}
export interface AwsEksClusterLoggingClusterLoggingDetails {
    Enabled?: boolean;
    Types?: string[];
}
export type AwsEksClusterLoggingClusterLoggingList = AwsEksClusterLoggingClusterLoggingDetails[];
export interface AwsEksClusterLoggingDetails {
    ClusterLogging?: AwsEksClusterLoggingClusterLoggingDetails[];
}
export interface AwsEksClusterDetails {
    Arn?: string;
    CertificateAuthorityData?: string;
    ClusterStatus?: string;
    Endpoint?: string;
    Name?: string;
    ResourcesVpcConfig?: AwsEksClusterResourcesVpcConfigDetails;
    RoleArn?: string;
    Version?: string;
    Logging?: AwsEksClusterLoggingDetails;
}
export interface FirewallPolicyStatefulRuleGroupReferencesDetails {
    ResourceArn?: string;
}
export type FirewallPolicyStatefulRuleGroupReferencesList = FirewallPolicyStatefulRuleGroupReferencesDetails[];
export interface StatelessCustomPublishMetricActionDimension {
    Value?: string;
}
export type StatelessCustomPublishMetricActionDimensionsList = StatelessCustomPublishMetricActionDimension[];
export interface StatelessCustomPublishMetricAction {
    Dimensions?: StatelessCustomPublishMetricActionDimension[];
}
export interface StatelessCustomActionDefinition {
    PublishMetricAction?: StatelessCustomPublishMetricAction;
}
export interface FirewallPolicyStatelessCustomActionsDetails {
    ActionDefinition?: StatelessCustomActionDefinition;
    ActionName?: string;
}
export type FirewallPolicyStatelessCustomActionsList = FirewallPolicyStatelessCustomActionsDetails[];
export interface FirewallPolicyStatelessRuleGroupReferencesDetails {
    Priority?: number;
    ResourceArn?: string;
}
export type FirewallPolicyStatelessRuleGroupReferencesList = FirewallPolicyStatelessRuleGroupReferencesDetails[];
export interface FirewallPolicyDetails {
    StatefulRuleGroupReferences?: FirewallPolicyStatefulRuleGroupReferencesDetails[];
    StatelessCustomActions?: FirewallPolicyStatelessCustomActionsDetails[];
    StatelessDefaultActions?: string[];
    StatelessFragmentDefaultActions?: string[];
    StatelessRuleGroupReferences?: FirewallPolicyStatelessRuleGroupReferencesDetails[];
}
export interface AwsNetworkFirewallFirewallPolicyDetails {
    FirewallPolicy?: FirewallPolicyDetails;
    FirewallPolicyArn?: string;
    FirewallPolicyId?: string;
    FirewallPolicyName?: string;
    Description?: string;
}
export interface AwsNetworkFirewallFirewallSubnetMappingsDetails {
    SubnetId?: string;
}
export type AwsNetworkFirewallFirewallSubnetMappingsList = AwsNetworkFirewallFirewallSubnetMappingsDetails[];
export interface AwsNetworkFirewallFirewallDetails {
    DeleteProtection?: boolean;
    Description?: string;
    FirewallArn?: string;
    FirewallId?: string;
    FirewallName?: string;
    FirewallPolicyArn?: string;
    FirewallPolicyChangeProtection?: boolean;
    SubnetChangeProtection?: boolean;
    SubnetMappings?: AwsNetworkFirewallFirewallSubnetMappingsDetails[];
    VpcId?: string;
}
export interface RuleGroupVariablesIpSetsDetails {
    Definition?: string[];
}
export interface RuleGroupVariablesPortSetsDetails {
    Definition?: string[];
}
export interface RuleGroupVariables {
    IpSets?: RuleGroupVariablesIpSetsDetails;
    PortSets?: RuleGroupVariablesPortSetsDetails;
}
export interface RuleGroupSourceListDetails {
    GeneratedRulesType?: string;
    TargetTypes?: string[];
    Targets?: string[];
}
export interface RuleGroupSourceStatefulRulesHeaderDetails {
    Destination?: string;
    DestinationPort?: string;
    Direction?: string;
    Protocol?: string;
    Source?: string;
    SourcePort?: string;
}
export type RuleGroupSourceStatefulRulesRuleOptionsSettingsList = string[];
export interface RuleGroupSourceStatefulRulesOptionsDetails {
    Keyword?: string;
    Settings?: string[];
}
export type RuleGroupSourceStatefulRulesOptionsList = RuleGroupSourceStatefulRulesOptionsDetails[];
export interface RuleGroupSourceStatefulRulesDetails {
    Action?: string;
    Header?: RuleGroupSourceStatefulRulesHeaderDetails;
    RuleOptions?: RuleGroupSourceStatefulRulesOptionsDetails[];
}
export type RuleGroupSourceStatefulRulesList = RuleGroupSourceStatefulRulesDetails[];
export interface RuleGroupSourceCustomActionsDetails {
    ActionDefinition?: StatelessCustomActionDefinition;
    ActionName?: string;
}
export type RuleGroupSourceCustomActionsList = RuleGroupSourceCustomActionsDetails[];
export interface RuleGroupSourceStatelessRuleMatchAttributesDestinationPorts {
    FromPort?: number;
    ToPort?: number;
}
export type RuleGroupSourceStatelessRuleMatchAttributesDestinationPortsList = RuleGroupSourceStatelessRuleMatchAttributesDestinationPorts[];
export interface RuleGroupSourceStatelessRuleMatchAttributesDestinations {
    AddressDefinition?: string;
}
export type RuleGroupSourceStatelessRuleMatchAttributesDestinationsList = RuleGroupSourceStatelessRuleMatchAttributesDestinations[];
export type RuleGroupSourceStatelessRuleMatchAttributesProtocolsList = number[];
export interface RuleGroupSourceStatelessRuleMatchAttributesSourcePorts {
    FromPort?: number;
    ToPort?: number;
}
export type RuleGroupSourceStatelessRuleMatchAttributesSourcePortsList = RuleGroupSourceStatelessRuleMatchAttributesSourcePorts[];
export interface RuleGroupSourceStatelessRuleMatchAttributesSources {
    AddressDefinition?: string;
}
export type RuleGroupSourceStatelessRuleMatchAttributesSourcesList = RuleGroupSourceStatelessRuleMatchAttributesSources[];
export interface RuleGroupSourceStatelessRuleMatchAttributesTcpFlags {
    Flags?: string[];
    Masks?: string[];
}
export type RuleGroupSourceStatelessRuleMatchAttributesTcpFlagsList = RuleGroupSourceStatelessRuleMatchAttributesTcpFlags[];
export interface RuleGroupSourceStatelessRuleMatchAttributes {
    DestinationPorts?: RuleGroupSourceStatelessRuleMatchAttributesDestinationPorts[];
    Destinations?: RuleGroupSourceStatelessRuleMatchAttributesDestinations[];
    Protocols?: number[];
    SourcePorts?: RuleGroupSourceStatelessRuleMatchAttributesSourcePorts[];
    Sources?: RuleGroupSourceStatelessRuleMatchAttributesSources[];
    TcpFlags?: RuleGroupSourceStatelessRuleMatchAttributesTcpFlags[];
}
export interface RuleGroupSourceStatelessRuleDefinition {
    Actions?: string[];
    MatchAttributes?: RuleGroupSourceStatelessRuleMatchAttributes;
}
export interface RuleGroupSourceStatelessRulesDetails {
    Priority?: number;
    RuleDefinition?: RuleGroupSourceStatelessRuleDefinition;
}
export type RuleGroupSourceStatelessRulesList = RuleGroupSourceStatelessRulesDetails[];
export interface RuleGroupSourceStatelessRulesAndCustomActionsDetails {
    CustomActions?: RuleGroupSourceCustomActionsDetails[];
    StatelessRules?: RuleGroupSourceStatelessRulesDetails[];
}
export interface RuleGroupSource {
    RulesSourceList?: RuleGroupSourceListDetails;
    RulesString?: string;
    StatefulRules?: RuleGroupSourceStatefulRulesDetails[];
    StatelessRulesAndCustomActions?: RuleGroupSourceStatelessRulesAndCustomActionsDetails;
}
export interface RuleGroupDetails {
    RuleVariables?: RuleGroupVariables;
    RulesSource?: RuleGroupSource;
}
export interface AwsNetworkFirewallRuleGroupDetails {
    Capacity?: number;
    Description?: string;
    RuleGroup?: RuleGroupDetails;
    RuleGroupArn?: string;
    RuleGroupId?: string;
    RuleGroupName?: string;
    Type?: string;
}
export interface AwsRdsDbSecurityGroupEc2SecurityGroup {
    Ec2SecurityGroupId?: string;
    Ec2SecurityGroupName?: string;
    Ec2SecurityGroupOwnerId?: string;
    Status?: string;
}
export type AwsRdsDbSecurityGroupEc2SecurityGroups = AwsRdsDbSecurityGroupEc2SecurityGroup[];
export interface AwsRdsDbSecurityGroupIpRange {
    CidrIp?: string;
    Status?: string;
}
export type AwsRdsDbSecurityGroupIpRanges = AwsRdsDbSecurityGroupIpRange[];
export interface AwsRdsDbSecurityGroupDetails {
    DbSecurityGroupArn?: string;
    DbSecurityGroupDescription?: string;
    DbSecurityGroupName?: string;
    Ec2SecurityGroups?: AwsRdsDbSecurityGroupEc2SecurityGroup[];
    IpRanges?: AwsRdsDbSecurityGroupIpRange[];
    OwnerId?: string;
    VpcId?: string;
}
export interface AwsKinesisStreamStreamEncryptionDetails {
    EncryptionType?: string;
    KeyId?: string;
}
export interface AwsKinesisStreamDetails {
    Name?: string;
    Arn?: string;
    StreamEncryption?: AwsKinesisStreamStreamEncryptionDetails;
    ShardCount?: number;
    RetentionPeriodHours?: number;
}
export interface AwsEc2TransitGatewayDetails {
    Id?: string;
    Description?: string;
    DefaultRouteTablePropagation?: string;
    AutoAcceptSharedAttachments?: string;
    DefaultRouteTableAssociation?: string;
    TransitGatewayCidrBlocks?: string[];
    AssociationDefaultRouteTableId?: string;
    PropagationDefaultRouteTableId?: string;
    VpnEcmpSupport?: string;
    DnsSupport?: string;
    MulticastSupport?: string;
    AmazonSideAsn?: number;
}
export interface AwsEfsAccessPointPosixUserDetails {
    Gid?: string;
    SecondaryGids?: string[];
    Uid?: string;
}
export interface AwsEfsAccessPointRootDirectoryCreationInfoDetails {
    OwnerGid?: string;
    OwnerUid?: string;
    Permissions?: string;
}
export interface AwsEfsAccessPointRootDirectoryDetails {
    CreationInfo?: AwsEfsAccessPointRootDirectoryCreationInfoDetails;
    Path?: string;
}
export interface AwsEfsAccessPointDetails {
    AccessPointId?: string;
    Arn?: string;
    ClientToken?: string;
    FileSystemId?: string;
    PosixUser?: AwsEfsAccessPointPosixUserDetails;
    RootDirectory?: AwsEfsAccessPointRootDirectoryDetails;
}
export interface AwsCloudFormationStackDriftInformationDetails {
    StackDriftStatus?: string;
}
export interface AwsCloudFormationStackOutputsDetails {
    Description?: string;
    OutputKey?: string;
    OutputValue?: string;
}
export type AwsCloudFormationStackOutputsList = AwsCloudFormationStackOutputsDetails[];
export interface AwsCloudFormationStackDetails {
    Capabilities?: string[];
    CreationTime?: string;
    Description?: string;
    DisableRollback?: boolean;
    DriftInformation?: AwsCloudFormationStackDriftInformationDetails;
    EnableTerminationProtection?: boolean;
    LastUpdatedTime?: string;
    NotificationArns?: string[];
    Outputs?: AwsCloudFormationStackOutputsDetails[];
    RoleArn?: string;
    StackId?: string;
    StackName?: string;
    StackStatus?: string;
    StackStatusReason?: string;
    TimeoutInMinutes?: number;
}
export interface AwsCloudWatchAlarmDimensionsDetails {
    Name?: string;
    Value?: string;
}
export type AwsCloudWatchAlarmDimensionsList = AwsCloudWatchAlarmDimensionsDetails[];
export interface AwsCloudWatchAlarmDetails {
    ActionsEnabled?: boolean;
    AlarmActions?: string[];
    AlarmArn?: string;
    AlarmConfigurationUpdatedTimestamp?: string;
    AlarmDescription?: string;
    AlarmName?: string;
    ComparisonOperator?: string;
    DatapointsToAlarm?: number;
    Dimensions?: AwsCloudWatchAlarmDimensionsDetails[];
    EvaluateLowSampleCountPercentile?: string;
    EvaluationPeriods?: number;
    ExtendedStatistic?: string;
    InsufficientDataActions?: string[];
    MetricName?: string;
    Namespace?: string;
    OkActions?: string[];
    Period?: number;
    Statistic?: string;
    Threshold?: number;
    ThresholdMetricId?: string;
    TreatMissingData?: string;
    Unit?: string;
}
export interface VpcInfoCidrBlockSetDetails {
    CidrBlock?: string;
}
export type VpcInfoCidrBlockSetList = VpcInfoCidrBlockSetDetails[];
export interface VpcInfoIpv6CidrBlockSetDetails {
    Ipv6CidrBlock?: string;
}
export type VpcInfoIpv6CidrBlockSetList = VpcInfoIpv6CidrBlockSetDetails[];
export interface VpcInfoPeeringOptionsDetails {
    AllowDnsResolutionFromRemoteVpc?: boolean;
    AllowEgressFromLocalClassicLinkToRemoteVpc?: boolean;
    AllowEgressFromLocalVpcToRemoteClassicLink?: boolean;
}
export interface AwsEc2VpcPeeringConnectionVpcInfoDetails {
    CidrBlock?: string;
    CidrBlockSet?: VpcInfoCidrBlockSetDetails[];
    Ipv6CidrBlockSet?: VpcInfoIpv6CidrBlockSetDetails[];
    OwnerId?: string;
    PeeringOptions?: VpcInfoPeeringOptionsDetails;
    Region?: string;
    VpcId?: string;
}
export interface AwsEc2VpcPeeringConnectionStatusDetails {
    Code?: string;
    Message?: string;
}
export interface AwsEc2VpcPeeringConnectionDetails {
    AccepterVpcInfo?: AwsEc2VpcPeeringConnectionVpcInfoDetails;
    ExpirationTime?: string;
    RequesterVpcInfo?: AwsEc2VpcPeeringConnectionVpcInfoDetails;
    Status?: AwsEc2VpcPeeringConnectionStatusDetails;
    VpcPeeringConnectionId?: string;
}
export interface AwsWafRegionalRuleGroupRulesActionDetails {
    Type?: string;
}
export interface AwsWafRegionalRuleGroupRulesDetails {
    Action?: AwsWafRegionalRuleGroupRulesActionDetails;
    Priority?: number;
    RuleId?: string;
    Type?: string;
}
export type AwsWafRegionalRuleGroupRulesList = AwsWafRegionalRuleGroupRulesDetails[];
export interface AwsWafRegionalRuleGroupDetails {
    MetricName?: string;
    Name?: string;
    RuleGroupId?: string;
    Rules?: AwsWafRegionalRuleGroupRulesDetails[];
}
export interface AwsWafRegionalRulePredicateListDetails {
    DataId?: string;
    Negated?: boolean;
    Type?: string;
}
export type AwsWafRegionalRulePredicateList = AwsWafRegionalRulePredicateListDetails[];
export interface AwsWafRegionalRuleDetails {
    MetricName?: string;
    Name?: string;
    PredicateList?: AwsWafRegionalRulePredicateListDetails[];
    RuleId?: string;
}
export interface AwsWafRegionalWebAclRulesListActionDetails {
    Type?: string;
}
export interface AwsWafRegionalWebAclRulesListOverrideActionDetails {
    Type?: string;
}
export interface AwsWafRegionalWebAclRulesListDetails {
    Action?: AwsWafRegionalWebAclRulesListActionDetails;
    OverrideAction?: AwsWafRegionalWebAclRulesListOverrideActionDetails;
    Priority?: number;
    RuleId?: string;
    Type?: string;
}
export type AwsWafRegionalWebAclRulesList = AwsWafRegionalWebAclRulesListDetails[];
export interface AwsWafRegionalWebAclDetails {
    DefaultAction?: string;
    MetricName?: string;
    Name?: string;
    RulesList?: AwsWafRegionalWebAclRulesListDetails[];
    WebAclId?: string;
}
export interface AwsWafRulePredicateListDetails {
    DataId?: string;
    Negated?: boolean;
    Type?: string;
}
export type AwsWafRulePredicateList = AwsWafRulePredicateListDetails[];
export interface AwsWafRuleDetails {
    MetricName?: string;
    Name?: string;
    PredicateList?: AwsWafRulePredicateListDetails[];
    RuleId?: string;
}
export interface AwsWafRuleGroupRulesActionDetails {
    Type?: string;
}
export interface AwsWafRuleGroupRulesDetails {
    Action?: AwsWafRuleGroupRulesActionDetails;
    Priority?: number;
    RuleId?: string;
    Type?: string;
}
export type AwsWafRuleGroupRulesList = AwsWafRuleGroupRulesDetails[];
export interface AwsWafRuleGroupDetails {
    MetricName?: string;
    Name?: string;
    RuleGroupId?: string;
    Rules?: AwsWafRuleGroupRulesDetails[];
}
export interface AwsEcsTaskVolumeHostDetails {
    SourcePath?: string;
}
export interface AwsEcsTaskVolumeDetails {
    Name?: string;
    Host?: AwsEcsTaskVolumeHostDetails;
}
export type AwsEcsTaskVolumeDetailsList = AwsEcsTaskVolumeDetails[];
export type AwsEcsContainerDetailsList = AwsEcsContainerDetails[];
export interface AwsEcsTaskDetails {
    ClusterArn?: string;
    TaskDefinitionArn?: string;
    Version?: string;
    CreatedAt?: string;
    StartedAt?: string;
    StartedBy?: string;
    Group?: string;
    Volumes?: AwsEcsTaskVolumeDetails[];
    Containers?: AwsEcsContainerDetails[];
}
export interface AwsBackupBackupVaultNotificationsDetails {
    BackupVaultEvents?: string[];
    SnsTopicArn?: string;
}
export interface AwsBackupBackupVaultDetails {
    BackupVaultArn?: string;
    BackupVaultName?: string;
    EncryptionKeyArn?: string;
    Notifications?: AwsBackupBackupVaultNotificationsDetails;
    AccessPolicy?: string;
}
export interface AwsBackupBackupPlanAdvancedBackupSettingsDetails {
    BackupOptions?: {
        [key: string]: string | undefined;
    };
    ResourceType?: string;
}
export type AwsBackupBackupPlanAdvancedBackupSettingsList = AwsBackupBackupPlanAdvancedBackupSettingsDetails[];
export interface AwsBackupBackupPlanLifecycleDetails {
    DeleteAfterDays?: number;
    MoveToColdStorageAfterDays?: number;
}
export interface AwsBackupBackupPlanRuleCopyActionsDetails {
    DestinationBackupVaultArn?: string;
    Lifecycle?: AwsBackupBackupPlanLifecycleDetails;
}
export type AwsBackupBackupPlanRuleCopyActionsList = AwsBackupBackupPlanRuleCopyActionsDetails[];
export interface AwsBackupBackupPlanRuleDetails {
    TargetBackupVault?: string;
    StartWindowMinutes?: number;
    ScheduleExpression?: string;
    RuleName?: string;
    RuleId?: string;
    EnableContinuousBackup?: boolean;
    CompletionWindowMinutes?: number;
    CopyActions?: AwsBackupBackupPlanRuleCopyActionsDetails[];
    Lifecycle?: AwsBackupBackupPlanLifecycleDetails;
}
export type AwsBackupBackupPlanRuleList = AwsBackupBackupPlanRuleDetails[];
export interface AwsBackupBackupPlanBackupPlanDetails {
    BackupPlanName?: string;
    AdvancedBackupSettings?: AwsBackupBackupPlanAdvancedBackupSettingsDetails[];
    BackupPlanRule?: AwsBackupBackupPlanRuleDetails[];
}
export interface AwsBackupBackupPlanDetails {
    BackupPlan?: AwsBackupBackupPlanBackupPlanDetails;
    BackupPlanArn?: string;
    BackupPlanId?: string;
    VersionId?: string;
}
export interface AwsBackupRecoveryPointCalculatedLifecycleDetails {
    DeleteAt?: string;
    MoveToColdStorageAt?: string;
}
export interface AwsBackupRecoveryPointCreatedByDetails {
    BackupPlanArn?: string;
    BackupPlanId?: string;
    BackupPlanVersion?: string;
    BackupRuleId?: string;
}
export interface AwsBackupRecoveryPointLifecycleDetails {
    DeleteAfterDays?: number;
    MoveToColdStorageAfterDays?: number;
}
export interface AwsBackupRecoveryPointDetails {
    BackupSizeInBytes?: number;
    BackupVaultArn?: string;
    BackupVaultName?: string;
    CalculatedLifecycle?: AwsBackupRecoveryPointCalculatedLifecycleDetails;
    CompletionDate?: string;
    CreatedBy?: AwsBackupRecoveryPointCreatedByDetails;
    CreationDate?: string;
    EncryptionKeyArn?: string;
    IamRoleArn?: string;
    IsEncrypted?: boolean;
    LastRestoreTime?: string;
    Lifecycle?: AwsBackupRecoveryPointLifecycleDetails;
    RecoveryPointArn?: string;
    ResourceArn?: string;
    ResourceType?: string;
    SourceBackupVaultArn?: string;
    Status?: string;
    StatusMessage?: string;
    StorageClass?: string;
}
export interface AwsEc2LaunchTemplateDataBlockDeviceMappingSetEbsDetails {
    DeleteOnTermination?: boolean;
    Encrypted?: boolean;
    Iops?: number;
    KmsKeyId?: string;
    SnapshotId?: string;
    Throughput?: number;
    VolumeSize?: number;
    VolumeType?: string;
}
export interface AwsEc2LaunchTemplateDataBlockDeviceMappingSetDetails {
    DeviceName?: string;
    Ebs?: AwsEc2LaunchTemplateDataBlockDeviceMappingSetEbsDetails;
    NoDevice?: string;
    VirtualName?: string;
}
export type AwsEc2LaunchTemplateDataBlockDeviceMappingSetList = AwsEc2LaunchTemplateDataBlockDeviceMappingSetDetails[];
export interface AwsEc2LaunchTemplateDataCapacityReservationSpecificationCapacityReservationTargetDetails {
    CapacityReservationId?: string;
    CapacityReservationResourceGroupArn?: string;
}
export interface AwsEc2LaunchTemplateDataCapacityReservationSpecificationDetails {
    CapacityReservationPreference?: string;
    CapacityReservationTarget?: AwsEc2LaunchTemplateDataCapacityReservationSpecificationCapacityReservationTargetDetails;
}
export interface AwsEc2LaunchTemplateDataCpuOptionsDetails {
    CoreCount?: number;
    ThreadsPerCore?: number;
}
export interface AwsEc2LaunchTemplateDataCreditSpecificationDetails {
    CpuCredits?: string;
}
export interface AwsEc2LaunchTemplateDataElasticGpuSpecificationSetDetails {
    Type?: string;
}
export type AwsEc2LaunchTemplateDataElasticGpuSpecificationSetList = AwsEc2LaunchTemplateDataElasticGpuSpecificationSetDetails[];
export interface AwsEc2LaunchTemplateDataElasticInferenceAcceleratorSetDetails {
    Count?: number;
    Type?: string;
}
export type AwsEc2LaunchTemplateDataElasticInferenceAcceleratorSetList = AwsEc2LaunchTemplateDataElasticInferenceAcceleratorSetDetails[];
export interface AwsEc2LaunchTemplateDataEnclaveOptionsDetails {
    Enabled?: boolean;
}
export interface AwsEc2LaunchTemplateDataHibernationOptionsDetails {
    Configured?: boolean;
}
export interface AwsEc2LaunchTemplateDataIamInstanceProfileDetails {
    Arn?: string;
    Name?: string;
}
export interface AwsEc2LaunchTemplateDataInstanceMarketOptionsSpotOptionsDetails {
    BlockDurationMinutes?: number;
    InstanceInterruptionBehavior?: string;
    MaxPrice?: string;
    SpotInstanceType?: string;
    ValidUntil?: string;
}
export interface AwsEc2LaunchTemplateDataInstanceMarketOptionsDetails {
    MarketType?: string;
    SpotOptions?: AwsEc2LaunchTemplateDataInstanceMarketOptionsSpotOptionsDetails;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsAcceleratorCountDetails {
    Max?: number;
    Min?: number;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsAcceleratorTotalMemoryMiBDetails {
    Max?: number;
    Min?: number;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsBaselineEbsBandwidthMbpsDetails {
    Max?: number;
    Min?: number;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsMemoryGiBPerVCpuDetails {
    Max?: number;
    Min?: number;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsMemoryMiBDetails {
    Max?: number;
    Min?: number;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsNetworkInterfaceCountDetails {
    Max?: number;
    Min?: number;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsTotalLocalStorageGBDetails {
    Max?: number;
    Min?: number;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsVCpuCountDetails {
    Max?: number;
    Min?: number;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsDetails {
    AcceleratorCount?: AwsEc2LaunchTemplateDataInstanceRequirementsAcceleratorCountDetails;
    AcceleratorManufacturers?: string[];
    AcceleratorNames?: string[];
    AcceleratorTotalMemoryMiB?: AwsEc2LaunchTemplateDataInstanceRequirementsAcceleratorTotalMemoryMiBDetails;
    AcceleratorTypes?: string[];
    BareMetal?: string;
    BaselineEbsBandwidthMbps?: AwsEc2LaunchTemplateDataInstanceRequirementsBaselineEbsBandwidthMbpsDetails;
    BurstablePerformance?: string;
    CpuManufacturers?: string[];
    ExcludedInstanceTypes?: string[];
    InstanceGenerations?: string[];
    LocalStorage?: string;
    LocalStorageTypes?: string[];
    MemoryGiBPerVCpu?: AwsEc2LaunchTemplateDataInstanceRequirementsMemoryGiBPerVCpuDetails;
    MemoryMiB?: AwsEc2LaunchTemplateDataInstanceRequirementsMemoryMiBDetails;
    NetworkInterfaceCount?: AwsEc2LaunchTemplateDataInstanceRequirementsNetworkInterfaceCountDetails;
    OnDemandMaxPricePercentageOverLowestPrice?: number;
    RequireHibernateSupport?: boolean;
    SpotMaxPricePercentageOverLowestPrice?: number;
    TotalLocalStorageGB?: AwsEc2LaunchTemplateDataInstanceRequirementsTotalLocalStorageGBDetails;
    VCpuCount?: AwsEc2LaunchTemplateDataInstanceRequirementsVCpuCountDetails;
}
export interface AwsEc2LaunchTemplateDataLicenseSetDetails {
    LicenseConfigurationArn?: string;
}
export type AwsEc2LaunchTemplateDataLicenseSetList = AwsEc2LaunchTemplateDataLicenseSetDetails[];
export interface AwsEc2LaunchTemplateDataMaintenanceOptionsDetails {
    AutoRecovery?: string;
}
export interface AwsEc2LaunchTemplateDataMetadataOptionsDetails {
    HttpEndpoint?: string;
    HttpProtocolIpv6?: string;
    HttpTokens?: string;
    HttpPutResponseHopLimit?: number;
    InstanceMetadataTags?: string;
}
export interface AwsEc2LaunchTemplateDataMonitoringDetails {
    Enabled?: boolean;
}
export interface AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv4PrefixesDetails {
    Ipv4Prefix?: string;
}
export type AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv4PrefixesList = AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv4PrefixesDetails[];
export interface AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6AddressesDetails {
    Ipv6Address?: string;
}
export type AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6AddressesList = AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6AddressesDetails[];
export interface AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6PrefixesDetails {
    Ipv6Prefix?: string;
}
export type AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6PrefixesList = AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6PrefixesDetails[];
export interface AwsEc2LaunchTemplateDataNetworkInterfaceSetPrivateIpAddressesDetails {
    Primary?: boolean;
    PrivateIpAddress?: string;
}
export type AwsEc2LaunchTemplateDataNetworkInterfaceSetPrivateIpAddressesList = AwsEc2LaunchTemplateDataNetworkInterfaceSetPrivateIpAddressesDetails[];
export interface AwsEc2LaunchTemplateDataNetworkInterfaceSetDetails {
    AssociateCarrierIpAddress?: boolean;
    AssociatePublicIpAddress?: boolean;
    DeleteOnTermination?: boolean;
    Description?: string;
    DeviceIndex?: number;
    Groups?: string[];
    InterfaceType?: string;
    Ipv4PrefixCount?: number;
    Ipv4Prefixes?: AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv4PrefixesDetails[];
    Ipv6AddressCount?: number;
    Ipv6Addresses?: AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6AddressesDetails[];
    Ipv6PrefixCount?: number;
    Ipv6Prefixes?: AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6PrefixesDetails[];
    NetworkCardIndex?: number;
    NetworkInterfaceId?: string;
    PrivateIpAddress?: string;
    PrivateIpAddresses?: AwsEc2LaunchTemplateDataNetworkInterfaceSetPrivateIpAddressesDetails[];
    SecondaryPrivateIpAddressCount?: number;
    SubnetId?: string;
}
export type AwsEc2LaunchTemplateDataNetworkInterfaceSetList = AwsEc2LaunchTemplateDataNetworkInterfaceSetDetails[];
export interface AwsEc2LaunchTemplateDataPlacementDetails {
    Affinity?: string;
    AvailabilityZone?: string;
    GroupName?: string;
    HostId?: string;
    HostResourceGroupArn?: string;
    PartitionNumber?: number;
    SpreadDomain?: string;
    Tenancy?: string;
}
export interface AwsEc2LaunchTemplateDataPrivateDnsNameOptionsDetails {
    EnableResourceNameDnsAAAARecord?: boolean;
    EnableResourceNameDnsARecord?: boolean;
    HostnameType?: string;
}
export interface AwsEc2LaunchTemplateDataDetails {
    BlockDeviceMappingSet?: AwsEc2LaunchTemplateDataBlockDeviceMappingSetDetails[];
    CapacityReservationSpecification?: AwsEc2LaunchTemplateDataCapacityReservationSpecificationDetails;
    CpuOptions?: AwsEc2LaunchTemplateDataCpuOptionsDetails;
    CreditSpecification?: AwsEc2LaunchTemplateDataCreditSpecificationDetails;
    DisableApiStop?: boolean;
    DisableApiTermination?: boolean;
    EbsOptimized?: boolean;
    ElasticGpuSpecificationSet?: AwsEc2LaunchTemplateDataElasticGpuSpecificationSetDetails[];
    ElasticInferenceAcceleratorSet?: AwsEc2LaunchTemplateDataElasticInferenceAcceleratorSetDetails[];
    EnclaveOptions?: AwsEc2LaunchTemplateDataEnclaveOptionsDetails;
    HibernationOptions?: AwsEc2LaunchTemplateDataHibernationOptionsDetails;
    IamInstanceProfile?: AwsEc2LaunchTemplateDataIamInstanceProfileDetails;
    ImageId?: string;
    InstanceInitiatedShutdownBehavior?: string;
    InstanceMarketOptions?: AwsEc2LaunchTemplateDataInstanceMarketOptionsDetails;
    InstanceRequirements?: AwsEc2LaunchTemplateDataInstanceRequirementsDetails;
    InstanceType?: string;
    KernelId?: string;
    KeyName?: string;
    LicenseSet?: AwsEc2LaunchTemplateDataLicenseSetDetails[];
    MaintenanceOptions?: AwsEc2LaunchTemplateDataMaintenanceOptionsDetails;
    MetadataOptions?: AwsEc2LaunchTemplateDataMetadataOptionsDetails;
    Monitoring?: AwsEc2LaunchTemplateDataMonitoringDetails;
    NetworkInterfaceSet?: AwsEc2LaunchTemplateDataNetworkInterfaceSetDetails[];
    Placement?: AwsEc2LaunchTemplateDataPlacementDetails;
    PrivateDnsNameOptions?: AwsEc2LaunchTemplateDataPrivateDnsNameOptionsDetails;
    RamDiskId?: string;
    SecurityGroupIdSet?: string[];
    SecurityGroupSet?: string[];
    UserData?: string;
}
export interface AwsEc2LaunchTemplateDetails {
    LaunchTemplateName?: string;
    Id?: string;
    LaunchTemplateData?: AwsEc2LaunchTemplateDataDetails;
    DefaultVersionNumber?: number;
    LatestVersionNumber?: number;
}
export interface AwsSageMakerNotebookInstanceMetadataServiceConfigurationDetails {
    MinimumInstanceMetadataServiceVersion?: string;
}
export interface AwsSageMakerNotebookInstanceDetails {
    AcceleratorTypes?: string[];
    AdditionalCodeRepositories?: string[];
    DefaultCodeRepository?: string;
    DirectInternetAccess?: string;
    FailureReason?: string;
    InstanceMetadataServiceConfiguration?: AwsSageMakerNotebookInstanceMetadataServiceConfigurationDetails;
    InstanceType?: string;
    KmsKeyId?: string;
    NetworkInterfaceId?: string;
    NotebookInstanceArn?: string;
    NotebookInstanceLifecycleConfigName?: string;
    NotebookInstanceName?: string;
    NotebookInstanceStatus?: string;
    PlatformIdentifier?: string;
    RoleArn?: string;
    RootAccess?: string;
    SecurityGroups?: string[];
    SubnetId?: string;
    Url?: string;
    VolumeSizeInGB?: number;
}
export interface AwsWafv2WebAclCaptchaConfigImmunityTimePropertyDetails {
    ImmunityTime?: number;
}
export interface AwsWafv2WebAclCaptchaConfigDetails {
    ImmunityTimeProperty?: AwsWafv2WebAclCaptchaConfigImmunityTimePropertyDetails;
}
export interface AwsWafv2CustomHttpHeader {
    Name?: string;
    Value?: string;
}
export type AwsWafv2InsertHeadersList = AwsWafv2CustomHttpHeader[];
export interface AwsWafv2CustomRequestHandlingDetails {
    InsertHeaders?: AwsWafv2CustomHttpHeader[];
}
export interface AwsWafv2ActionAllowDetails {
    CustomRequestHandling?: AwsWafv2CustomRequestHandlingDetails;
}
export interface AwsWafv2CustomResponseDetails {
    CustomResponseBodyKey?: string;
    ResponseCode?: number;
    ResponseHeaders?: AwsWafv2CustomHttpHeader[];
}
export interface AwsWafv2ActionBlockDetails {
    CustomResponse?: AwsWafv2CustomResponseDetails;
}
export interface AwsWafv2WebAclActionDetails {
    Allow?: AwsWafv2ActionAllowDetails;
    Block?: AwsWafv2ActionBlockDetails;
}
export interface AwsWafv2RulesActionCaptchaDetails {
    CustomRequestHandling?: AwsWafv2CustomRequestHandlingDetails;
}
export interface AwsWafv2RulesActionCountDetails {
    CustomRequestHandling?: AwsWafv2CustomRequestHandlingDetails;
}
export interface AwsWafv2RulesActionDetails {
    Allow?: AwsWafv2ActionAllowDetails;
    Block?: AwsWafv2ActionBlockDetails;
    Captcha?: AwsWafv2RulesActionCaptchaDetails;
    Count?: AwsWafv2RulesActionCountDetails;
}
export interface AwsWafv2VisibilityConfigDetails {
    CloudWatchMetricsEnabled?: boolean;
    MetricName?: string;
    SampledRequestsEnabled?: boolean;
}
export interface AwsWafv2RulesDetails {
    Action?: AwsWafv2RulesActionDetails;
    Name?: string;
    OverrideAction?: string;
    Priority?: number;
    VisibilityConfig?: AwsWafv2VisibilityConfigDetails;
}
export type AwsWafv2RulesList = AwsWafv2RulesDetails[];
export interface AwsWafv2WebAclDetails {
    Name?: string;
    Arn?: string;
    ManagedbyFirewallManager?: boolean;
    Id?: string;
    Capacity?: number;
    CaptchaConfig?: AwsWafv2WebAclCaptchaConfigDetails;
    DefaultAction?: AwsWafv2WebAclActionDetails;
    Description?: string;
    Rules?: AwsWafv2RulesDetails[];
    VisibilityConfig?: AwsWafv2VisibilityConfigDetails;
}
export interface AwsWafv2RuleGroupDetails {
    Capacity?: number;
    Description?: string;
    Id?: string;
    Name?: string;
    Arn?: string;
    Rules?: AwsWafv2RulesDetails[];
    Scope?: string;
    VisibilityConfig?: AwsWafv2VisibilityConfigDetails;
}
export interface AssociationStateDetails {
    State?: string;
    StatusMessage?: string;
}
export interface AssociationSetDetails {
    AssociationState?: AssociationStateDetails;
    GatewayId?: string;
    Main?: boolean;
    RouteTableAssociationId?: string;
    RouteTableId?: string;
    SubnetId?: string;
}
export type AssociationSetList = AssociationSetDetails[];
export interface PropagatingVgwSetDetails {
    GatewayId?: string;
}
export type PropagatingVgwSetList = PropagatingVgwSetDetails[];
export interface RouteSetDetails {
    CarrierGatewayId?: string;
    CoreNetworkArn?: string;
    DestinationCidrBlock?: string;
    DestinationIpv6CidrBlock?: string;
    DestinationPrefixListId?: string;
    EgressOnlyInternetGatewayId?: string;
    GatewayId?: string;
    InstanceId?: string;
    InstanceOwnerId?: string;
    LocalGatewayId?: string;
    NatGatewayId?: string;
    NetworkInterfaceId?: string;
    Origin?: string;
    State?: string;
    TransitGatewayId?: string;
    VpcPeeringConnectionId?: string;
}
export type RouteSetList = RouteSetDetails[];
export interface AwsEc2RouteTableDetails {
    AssociationSet?: AssociationSetDetails[];
    OwnerId?: string;
    PropagatingVgwSet?: PropagatingVgwSetDetails[];
    RouteTableId?: string;
    RouteSet?: RouteSetDetails[];
    VpcId?: string;
}
export interface AwsAmazonMqBrokerEncryptionOptionsDetails {
    KmsKeyId?: string;
    UseAwsOwnedKey?: boolean;
}
export interface AwsAmazonMqBrokerLdapServerMetadataDetails {
    Hosts?: string[];
    RoleBase?: string;
    RoleName?: string;
    RoleSearchMatching?: string;
    RoleSearchSubtree?: boolean;
    ServiceAccountUsername?: string;
    UserBase?: string;
    UserRoleName?: string;
    UserSearchMatching?: string;
    UserSearchSubtree?: boolean;
}
export interface AwsAmazonMqBrokerLogsPendingDetails {
    Audit?: boolean;
    General?: boolean;
}
export interface AwsAmazonMqBrokerLogsDetails {
    Audit?: boolean;
    General?: boolean;
    AuditLogGroup?: string;
    GeneralLogGroup?: string;
    Pending?: AwsAmazonMqBrokerLogsPendingDetails;
}
export interface AwsAmazonMqBrokerMaintenanceWindowStartTimeDetails {
    DayOfWeek?: string;
    TimeOfDay?: string;
    TimeZone?: string;
}
export interface AwsAmazonMqBrokerUsersDetails {
    PendingChange?: string;
    Username?: string;
}
export type AwsAmazonMqBrokerUsersList = AwsAmazonMqBrokerUsersDetails[];
export interface AwsAmazonMqBrokerDetails {
    AuthenticationStrategy?: string;
    AutoMinorVersionUpgrade?: boolean;
    BrokerArn?: string;
    BrokerName?: string;
    DeploymentMode?: string;
    EncryptionOptions?: AwsAmazonMqBrokerEncryptionOptionsDetails;
    EngineType?: string;
    EngineVersion?: string;
    HostInstanceType?: string;
    BrokerId?: string;
    LdapServerMetadata?: AwsAmazonMqBrokerLdapServerMetadataDetails;
    Logs?: AwsAmazonMqBrokerLogsDetails;
    MaintenanceWindowStartTime?: AwsAmazonMqBrokerMaintenanceWindowStartTimeDetails;
    PubliclyAccessible?: boolean;
    SecurityGroups?: string[];
    StorageType?: string;
    SubnetIds?: string[];
    Users?: AwsAmazonMqBrokerUsersDetails[];
}
export interface AwsAppSyncGraphQlApiOpenIdConnectConfigDetails {
    AuthTtL?: number;
    ClientId?: string;
    IatTtL?: number;
    Issuer?: string;
}
export interface AwsAppSyncGraphQlApiLambdaAuthorizerConfigDetails {
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerUri?: string;
    IdentityValidationExpression?: string;
}
export interface AwsAppSyncGraphQlApiUserPoolConfigDetails {
    AppIdClientRegex?: string;
    AwsRegion?: string;
    DefaultAction?: string;
    UserPoolId?: string;
}
export interface AwsAppSyncGraphQlApiLogConfigDetails {
    CloudWatchLogsRoleArn?: string;
    ExcludeVerboseContent?: boolean;
    FieldLogLevel?: string;
}
export interface AwsAppSyncGraphQlApiAdditionalAuthenticationProvidersDetails {
    AuthenticationType?: string;
    LambdaAuthorizerConfig?: AwsAppSyncGraphQlApiLambdaAuthorizerConfigDetails;
    OpenIdConnectConfig?: AwsAppSyncGraphQlApiOpenIdConnectConfigDetails;
    UserPoolConfig?: AwsAppSyncGraphQlApiUserPoolConfigDetails;
}
export type AwsAppSyncGraphQlApiAdditionalAuthenticationProvidersList = AwsAppSyncGraphQlApiAdditionalAuthenticationProvidersDetails[];
export interface AwsAppSyncGraphQlApiDetails {
    ApiId?: string;
    Id?: string;
    OpenIdConnectConfig?: AwsAppSyncGraphQlApiOpenIdConnectConfigDetails;
    Name?: string;
    LambdaAuthorizerConfig?: AwsAppSyncGraphQlApiLambdaAuthorizerConfigDetails;
    XrayEnabled?: boolean;
    Arn?: string;
    UserPoolConfig?: AwsAppSyncGraphQlApiUserPoolConfigDetails;
    AuthenticationType?: string;
    LogConfig?: AwsAppSyncGraphQlApiLogConfigDetails;
    AdditionalAuthenticationProviders?: AwsAppSyncGraphQlApiAdditionalAuthenticationProvidersDetails[];
    WafWebAclArn?: string;
}
export interface AwsEventSchemasRegistryDetails {
    Description?: string;
    RegistryArn?: string;
    RegistryName?: string;
}
export interface AwsGuardDutyDetectorDataSourcesCloudTrailDetails {
    Status?: string;
}
export interface AwsGuardDutyDetectorDataSourcesDnsLogsDetails {
    Status?: string;
}
export interface AwsGuardDutyDetectorDataSourcesFlowLogsDetails {
    Status?: string;
}
export interface AwsGuardDutyDetectorDataSourcesKubernetesAuditLogsDetails {
    Status?: string;
}
export interface AwsGuardDutyDetectorDataSourcesKubernetesDetails {
    AuditLogs?: AwsGuardDutyDetectorDataSourcesKubernetesAuditLogsDetails;
}
export interface AwsGuardDutyDetectorDataSourcesMalwareProtectionScanEc2InstanceWithFindingsEbsVolumesDetails {
    Reason?: string;
    Status?: string;
}
export interface AwsGuardDutyDetectorDataSourcesMalwareProtectionScanEc2InstanceWithFindingsDetails {
    EbsVolumes?: AwsGuardDutyDetectorDataSourcesMalwareProtectionScanEc2InstanceWithFindingsEbsVolumesDetails;
}
export interface AwsGuardDutyDetectorDataSourcesMalwareProtectionDetails {
    ScanEc2InstanceWithFindings?: AwsGuardDutyDetectorDataSourcesMalwareProtectionScanEc2InstanceWithFindingsDetails;
    ServiceRole?: string;
}
export interface AwsGuardDutyDetectorDataSourcesS3LogsDetails {
    Status?: string;
}
export interface AwsGuardDutyDetectorDataSourcesDetails {
    CloudTrail?: AwsGuardDutyDetectorDataSourcesCloudTrailDetails;
    DnsLogs?: AwsGuardDutyDetectorDataSourcesDnsLogsDetails;
    FlowLogs?: AwsGuardDutyDetectorDataSourcesFlowLogsDetails;
    Kubernetes?: AwsGuardDutyDetectorDataSourcesKubernetesDetails;
    MalwareProtection?: AwsGuardDutyDetectorDataSourcesMalwareProtectionDetails;
    S3Logs?: AwsGuardDutyDetectorDataSourcesS3LogsDetails;
}
export interface AwsGuardDutyDetectorFeaturesDetails {
    Name?: string;
    Status?: string;
}
export type AwsGuardDutyDetectorFeaturesList = AwsGuardDutyDetectorFeaturesDetails[];
export interface AwsGuardDutyDetectorDetails {
    DataSources?: AwsGuardDutyDetectorDataSourcesDetails;
    Features?: AwsGuardDutyDetectorFeaturesDetails[];
    FindingPublishingFrequency?: string;
    ServiceRole?: string;
    Status?: string;
}
export interface AwsStepFunctionStateMachineLoggingConfigurationDestinationsCloudWatchLogsLogGroupDetails {
    LogGroupArn?: string;
}
export interface AwsStepFunctionStateMachineLoggingConfigurationDestinationsDetails {
    CloudWatchLogsLogGroup?: AwsStepFunctionStateMachineLoggingConfigurationDestinationsCloudWatchLogsLogGroupDetails;
}
export type AwsStepFunctionStateMachineLoggingConfigurationDestinationsList = AwsStepFunctionStateMachineLoggingConfigurationDestinationsDetails[];
export interface AwsStepFunctionStateMachineLoggingConfigurationDetails {
    Destinations?: AwsStepFunctionStateMachineLoggingConfigurationDestinationsDetails[];
    IncludeExecutionData?: boolean;
    Level?: string;
}
export interface AwsStepFunctionStateMachineTracingConfigurationDetails {
    Enabled?: boolean;
}
export interface AwsStepFunctionStateMachineDetails {
    Label?: string;
    LoggingConfiguration?: AwsStepFunctionStateMachineLoggingConfigurationDetails;
    Name?: string;
    RoleArn?: string;
    StateMachineArn?: string;
    Status?: string;
    TracingConfiguration?: AwsStepFunctionStateMachineTracingConfigurationDetails;
    Type?: string;
}
export interface AwsAthenaWorkGroupConfigurationResultConfigurationEncryptionConfigurationDetails {
    EncryptionOption?: string;
    KmsKey?: string;
}
export interface AwsAthenaWorkGroupConfigurationResultConfigurationDetails {
    EncryptionConfiguration?: AwsAthenaWorkGroupConfigurationResultConfigurationEncryptionConfigurationDetails;
}
export interface AwsAthenaWorkGroupConfigurationDetails {
    ResultConfiguration?: AwsAthenaWorkGroupConfigurationResultConfigurationDetails;
}
export interface AwsAthenaWorkGroupDetails {
    Name?: string;
    Description?: string;
    State?: string;
    Configuration?: AwsAthenaWorkGroupConfigurationDetails;
}
export interface AwsEventsEventbusDetails {
    Arn?: string;
    Name?: string;
    Policy?: string;
}
export interface AwsDmsEndpointDetails {
    CertificateArn?: string;
    DatabaseName?: string;
    EndpointArn?: string;
    EndpointIdentifier?: string;
    EndpointType?: string;
    EngineName?: string;
    ExternalId?: string;
    ExtraConnectionAttributes?: string;
    KmsKeyId?: string;
    Port?: number;
    ServerName?: string;
    SslMode?: string;
    Username?: string;
}
export interface AwsEventsEndpointEventBusesDetails {
    EventBusArn?: string;
}
export type AwsEventsEndpointEventBusesList = AwsEventsEndpointEventBusesDetails[];
export interface AwsEventsEndpointReplicationConfigDetails {
    State?: string;
}
export interface AwsEventsEndpointRoutingConfigFailoverConfigPrimaryDetails {
    HealthCheck?: string;
}
export interface AwsEventsEndpointRoutingConfigFailoverConfigSecondaryDetails {
    Route?: string;
}
export interface AwsEventsEndpointRoutingConfigFailoverConfigDetails {
    Primary?: AwsEventsEndpointRoutingConfigFailoverConfigPrimaryDetails;
    Secondary?: AwsEventsEndpointRoutingConfigFailoverConfigSecondaryDetails;
}
export interface AwsEventsEndpointRoutingConfigDetails {
    FailoverConfig?: AwsEventsEndpointRoutingConfigFailoverConfigDetails;
}
export interface AwsEventsEndpointDetails {
    Arn?: string;
    Description?: string;
    EndpointId?: string;
    EndpointUrl?: string;
    EventBuses?: AwsEventsEndpointEventBusesDetails[];
    Name?: string;
    ReplicationConfig?: AwsEventsEndpointReplicationConfigDetails;
    RoleArn?: string;
    RoutingConfig?: AwsEventsEndpointRoutingConfigDetails;
    State?: string;
    StateReason?: string;
}
export interface AwsDmsReplicationTaskDetails {
    CdcStartPosition?: string;
    CdcStartTime?: string;
    CdcStopPosition?: string;
    MigrationType?: string;
    Id?: string;
    ResourceIdentifier?: string;
    ReplicationInstanceArn?: string;
    ReplicationTaskIdentifier?: string;
    ReplicationTaskSettings?: string;
    SourceEndpointArn?: string;
    TableMappings?: string;
    TargetEndpointArn?: string;
    TaskData?: string;
}
export interface AwsDmsReplicationInstanceReplicationSubnetGroupDetails {
    ReplicationSubnetGroupIdentifier?: string;
}
export interface AwsDmsReplicationInstanceVpcSecurityGroupsDetails {
    VpcSecurityGroupId?: string;
}
export type AwsDmsReplicationInstanceVpcSecurityGroupsList = AwsDmsReplicationInstanceVpcSecurityGroupsDetails[];
export interface AwsDmsReplicationInstanceDetails {
    AllocatedStorage?: number;
    AutoMinorVersionUpgrade?: boolean;
    AvailabilityZone?: string;
    EngineVersion?: string;
    KmsKeyId?: string;
    MultiAZ?: boolean;
    PreferredMaintenanceWindow?: string;
    PubliclyAccessible?: boolean;
    ReplicationInstanceClass?: string;
    ReplicationInstanceIdentifier?: string;
    ReplicationSubnetGroup?: AwsDmsReplicationInstanceReplicationSubnetGroupDetails;
    VpcSecurityGroups?: AwsDmsReplicationInstanceVpcSecurityGroupsDetails[];
}
export interface AwsRoute53HostedZoneConfigDetails {
    Comment?: string;
}
export interface AwsRoute53HostedZoneObjectDetails {
    Id?: string;
    Name?: string;
    Config?: AwsRoute53HostedZoneConfigDetails;
}
export interface AwsRoute53HostedZoneVpcDetails {
    Id?: string;
    Region?: string;
}
export type AwsRoute53HostedZoneVpcsList = AwsRoute53HostedZoneVpcDetails[];
export type AwsRoute53HostedZoneNameServersList = string[];
export interface CloudWatchLogsLogGroupArnConfigDetails {
    CloudWatchLogsLogGroupArn?: string;
    HostedZoneId?: string;
    Id?: string;
}
export interface AwsRoute53QueryLoggingConfigDetails {
    CloudWatchLogsLogGroupArn?: CloudWatchLogsLogGroupArnConfigDetails;
}
export interface AwsRoute53HostedZoneDetails {
    HostedZone?: AwsRoute53HostedZoneObjectDetails;
    Vpcs?: AwsRoute53HostedZoneVpcDetails[];
    NameServers?: string[];
    QueryLoggingConfig?: AwsRoute53QueryLoggingConfigDetails;
}
export interface AwsMskClusterClusterInfoEncryptionInfoEncryptionInTransitDetails {
    InCluster?: boolean;
    ClientBroker?: string;
}
export interface AwsMskClusterClusterInfoEncryptionInfoEncryptionAtRestDetails {
    DataVolumeKMSKeyId?: string;
}
export interface AwsMskClusterClusterInfoEncryptionInfoDetails {
    EncryptionInTransit?: AwsMskClusterClusterInfoEncryptionInfoEncryptionInTransitDetails;
    EncryptionAtRest?: AwsMskClusterClusterInfoEncryptionInfoEncryptionAtRestDetails;
}
export interface AwsMskClusterClusterInfoClientAuthenticationSaslIamDetails {
    Enabled?: boolean;
}
export interface AwsMskClusterClusterInfoClientAuthenticationSaslScramDetails {
    Enabled?: boolean;
}
export interface AwsMskClusterClusterInfoClientAuthenticationSaslDetails {
    Iam?: AwsMskClusterClusterInfoClientAuthenticationSaslIamDetails;
    Scram?: AwsMskClusterClusterInfoClientAuthenticationSaslScramDetails;
}
export interface AwsMskClusterClusterInfoClientAuthenticationUnauthenticatedDetails {
    Enabled?: boolean;
}
export interface AwsMskClusterClusterInfoClientAuthenticationTlsDetails {
    CertificateAuthorityArnList?: string[];
    Enabled?: boolean;
}
export interface AwsMskClusterClusterInfoClientAuthenticationDetails {
    Sasl?: AwsMskClusterClusterInfoClientAuthenticationSaslDetails;
    Unauthenticated?: AwsMskClusterClusterInfoClientAuthenticationUnauthenticatedDetails;
    Tls?: AwsMskClusterClusterInfoClientAuthenticationTlsDetails;
}
export interface AwsMskClusterClusterInfoDetails {
    EncryptionInfo?: AwsMskClusterClusterInfoEncryptionInfoDetails;
    CurrentVersion?: string;
    NumberOfBrokerNodes?: number;
    ClusterName?: string;
    ClientAuthentication?: AwsMskClusterClusterInfoClientAuthenticationDetails;
    EnhancedMonitoring?: string;
}
export interface AwsMskClusterDetails {
    ClusterInfo?: AwsMskClusterClusterInfoDetails;
}
export interface AwsS3AccessPointVpcConfigurationDetails {
    VpcId?: string;
}
export interface AwsS3AccessPointDetails {
    AccessPointArn?: string;
    Alias?: string;
    Bucket?: string;
    BucketAccountId?: string;
    Name?: string;
    NetworkOrigin?: string;
    PublicAccessBlockConfiguration?: AwsS3AccountPublicAccessBlockDetails;
    VpcConfiguration?: AwsS3AccessPointVpcConfigurationDetails;
}
export interface AwsEc2ClientVpnEndpointAuthenticationOptionsActiveDirectoryDetails {
    DirectoryId?: string;
}
export interface AwsEc2ClientVpnEndpointAuthenticationOptionsMutualAuthenticationDetails {
    ClientRootCertificateChain?: string;
}
export interface AwsEc2ClientVpnEndpointAuthenticationOptionsFederatedAuthenticationDetails {
    SamlProviderArn?: string;
    SelfServiceSamlProviderArn?: string;
}
export interface AwsEc2ClientVpnEndpointAuthenticationOptionsDetails {
    Type?: string;
    ActiveDirectory?: AwsEc2ClientVpnEndpointAuthenticationOptionsActiveDirectoryDetails;
    MutualAuthentication?: AwsEc2ClientVpnEndpointAuthenticationOptionsMutualAuthenticationDetails;
    FederatedAuthentication?: AwsEc2ClientVpnEndpointAuthenticationOptionsFederatedAuthenticationDetails;
}
export type AwsEc2ClientVpnEndpointAuthenticationOptionsList = AwsEc2ClientVpnEndpointAuthenticationOptionsDetails[];
export interface AwsEc2ClientVpnEndpointConnectionLogOptionsDetails {
    Enabled?: boolean;
    CloudwatchLogGroup?: string;
    CloudwatchLogStream?: string;
}
export interface AwsEc2ClientVpnEndpointClientConnectOptionsStatusDetails {
    Code?: string;
    Message?: string;
}
export interface AwsEc2ClientVpnEndpointClientConnectOptionsDetails {
    Enabled?: boolean;
    LambdaFunctionArn?: string;
    Status?: AwsEc2ClientVpnEndpointClientConnectOptionsStatusDetails;
}
export interface AwsEc2ClientVpnEndpointClientLoginBannerOptionsDetails {
    Enabled?: boolean;
    BannerText?: string;
}
export interface AwsEc2ClientVpnEndpointDetails {
    ClientVpnEndpointId?: string;
    Description?: string;
    ClientCidrBlock?: string;
    DnsServer?: string[];
    SplitTunnel?: boolean;
    TransportProtocol?: string;
    VpnPort?: number;
    ServerCertificateArn?: string;
    AuthenticationOptions?: AwsEc2ClientVpnEndpointAuthenticationOptionsDetails[];
    ConnectionLogOptions?: AwsEc2ClientVpnEndpointConnectionLogOptionsDetails;
    SecurityGroupIdSet?: string[];
    VpcId?: string;
    SelfServicePortalUrl?: string;
    ClientConnectOptions?: AwsEc2ClientVpnEndpointClientConnectOptionsDetails;
    SessionTimeoutHours?: number;
    ClientLoginBannerOptions?: AwsEc2ClientVpnEndpointClientLoginBannerOptionsDetails;
}
export interface CodeRepositoryDetails {
    ProviderType?: string;
    ProjectName?: string;
    CodeSecurityIntegrationArn?: string;
}
export type AzureResourceDetails = unknown;
export interface ResourceDetails {
    AwsAutoScalingAutoScalingGroup?: AwsAutoScalingAutoScalingGroupDetails;
    AwsCodeBuildProject?: AwsCodeBuildProjectDetails;
    AwsCloudFrontDistribution?: AwsCloudFrontDistributionDetails;
    AwsEc2Instance?: AwsEc2InstanceDetails;
    AwsEc2NetworkInterface?: AwsEc2NetworkInterfaceDetails;
    AwsEc2SecurityGroup?: AwsEc2SecurityGroupDetails;
    AwsEc2Volume?: AwsEc2VolumeDetails;
    AwsEc2Vpc?: AwsEc2VpcDetails;
    AwsEc2Eip?: AwsEc2EipDetails;
    AwsEc2Subnet?: AwsEc2SubnetDetails;
    AwsEc2NetworkAcl?: AwsEc2NetworkAclDetails;
    AwsElbv2LoadBalancer?: AwsElbv2LoadBalancerDetails;
    AwsElasticBeanstalkEnvironment?: AwsElasticBeanstalkEnvironmentDetails;
    AwsElasticsearchDomain?: AwsElasticsearchDomainDetails;
    AwsS3Bucket?: AwsS3BucketDetails;
    AwsS3AccountPublicAccessBlock?: AwsS3AccountPublicAccessBlockDetails;
    AwsS3Object?: AwsS3ObjectDetails;
    AwsSecretsManagerSecret?: AwsSecretsManagerSecretDetails;
    AwsIamAccessKey?: AwsIamAccessKeyDetails;
    AwsIamUser?: AwsIamUserDetails;
    AwsIamPolicy?: AwsIamPolicyDetails;
    AwsApiGatewayV2Stage?: AwsApiGatewayV2StageDetails;
    AwsApiGatewayV2Api?: AwsApiGatewayV2ApiDetails;
    AwsDynamoDbTable?: AwsDynamoDbTableDetails;
    AwsApiGatewayStage?: AwsApiGatewayStageDetails;
    AwsApiGatewayRestApi?: AwsApiGatewayRestApiDetails;
    AwsCloudTrailTrail?: AwsCloudTrailTrailDetails;
    AwsSsmPatchCompliance?: AwsSsmPatchComplianceDetails;
    AwsCertificateManagerCertificate?: AwsCertificateManagerCertificateDetails;
    AwsRedshiftCluster?: AwsRedshiftClusterDetails;
    AwsElbLoadBalancer?: AwsElbLoadBalancerDetails;
    AwsIamGroup?: AwsIamGroupDetails;
    AwsIamRole?: AwsIamRoleDetails;
    AwsKmsKey?: AwsKmsKeyDetails;
    AwsLambdaFunction?: AwsLambdaFunctionDetails;
    AwsLambdaLayerVersion?: AwsLambdaLayerVersionDetails;
    AwsRdsDbInstance?: AwsRdsDbInstanceDetails;
    AwsSnsTopic?: AwsSnsTopicDetails;
    AwsSqsQueue?: AwsSqsQueueDetails;
    AwsWafWebAcl?: AwsWafWebAclDetails;
    AwsRdsDbSnapshot?: AwsRdsDbSnapshotDetails;
    AwsRdsDbClusterSnapshot?: AwsRdsDbClusterSnapshotDetails;
    AwsRdsDbCluster?: AwsRdsDbClusterDetails;
    AwsEcsCluster?: AwsEcsClusterDetails;
    AwsEcsContainer?: AwsEcsContainerDetails;
    AwsEcsTaskDefinition?: AwsEcsTaskDefinitionDetails;
    Container?: ContainerDetails;
    Other?: {
        [key: string]: string | undefined;
    };
    AwsRdsEventSubscription?: AwsRdsEventSubscriptionDetails;
    AwsEcsService?: AwsEcsServiceDetails;
    AwsAutoScalingLaunchConfiguration?: AwsAutoScalingLaunchConfigurationDetails;
    AwsEc2VpnConnection?: AwsEc2VpnConnectionDetails;
    AwsEcrContainerImage?: AwsEcrContainerImageDetails;
    AwsOpenSearchServiceDomain?: AwsOpenSearchServiceDomainDetails;
    AwsEc2VpcEndpointService?: AwsEc2VpcEndpointServiceDetails;
    AwsXrayEncryptionConfig?: AwsXrayEncryptionConfigDetails;
    AwsWafRateBasedRule?: AwsWafRateBasedRuleDetails;
    AwsWafRegionalRateBasedRule?: AwsWafRegionalRateBasedRuleDetails;
    AwsEcrRepository?: AwsEcrRepositoryDetails;
    AwsEksCluster?: AwsEksClusterDetails;
    AwsNetworkFirewallFirewallPolicy?: AwsNetworkFirewallFirewallPolicyDetails;
    AwsNetworkFirewallFirewall?: AwsNetworkFirewallFirewallDetails;
    AwsNetworkFirewallRuleGroup?: AwsNetworkFirewallRuleGroupDetails;
    AwsRdsDbSecurityGroup?: AwsRdsDbSecurityGroupDetails;
    AwsKinesisStream?: AwsKinesisStreamDetails;
    AwsEc2TransitGateway?: AwsEc2TransitGatewayDetails;
    AwsEfsAccessPoint?: AwsEfsAccessPointDetails;
    AwsCloudFormationStack?: AwsCloudFormationStackDetails;
    AwsCloudWatchAlarm?: AwsCloudWatchAlarmDetails;
    AwsEc2VpcPeeringConnection?: AwsEc2VpcPeeringConnectionDetails;
    AwsWafRegionalRuleGroup?: AwsWafRegionalRuleGroupDetails;
    AwsWafRegionalRule?: AwsWafRegionalRuleDetails;
    AwsWafRegionalWebAcl?: AwsWafRegionalWebAclDetails;
    AwsWafRule?: AwsWafRuleDetails;
    AwsWafRuleGroup?: AwsWafRuleGroupDetails;
    AwsEcsTask?: AwsEcsTaskDetails;
    AwsBackupBackupVault?: AwsBackupBackupVaultDetails;
    AwsBackupBackupPlan?: AwsBackupBackupPlanDetails;
    AwsBackupRecoveryPoint?: AwsBackupRecoveryPointDetails;
    AwsEc2LaunchTemplate?: AwsEc2LaunchTemplateDetails;
    AwsSageMakerNotebookInstance?: AwsSageMakerNotebookInstanceDetails;
    AwsWafv2WebAcl?: AwsWafv2WebAclDetails;
    AwsWafv2RuleGroup?: AwsWafv2RuleGroupDetails;
    AwsEc2RouteTable?: AwsEc2RouteTableDetails;
    AwsAmazonMqBroker?: AwsAmazonMqBrokerDetails;
    AwsAppSyncGraphQlApi?: AwsAppSyncGraphQlApiDetails;
    AwsEventSchemasRegistry?: AwsEventSchemasRegistryDetails;
    AwsGuardDutyDetector?: AwsGuardDutyDetectorDetails;
    AwsStepFunctionStateMachine?: AwsStepFunctionStateMachineDetails;
    AwsAthenaWorkGroup?: AwsAthenaWorkGroupDetails;
    AwsEventsEventbus?: AwsEventsEventbusDetails;
    AwsDmsEndpoint?: AwsDmsEndpointDetails;
    AwsEventsEndpoint?: AwsEventsEndpointDetails;
    AwsDmsReplicationTask?: AwsDmsReplicationTaskDetails;
    AwsDmsReplicationInstance?: AwsDmsReplicationInstanceDetails;
    AwsRoute53HostedZone?: AwsRoute53HostedZoneDetails;
    AwsMskCluster?: AwsMskClusterDetails;
    AwsS3AccessPoint?: AwsS3AccessPointDetails;
    AwsEc2ClientVpnEndpoint?: AwsEc2ClientVpnEndpointDetails;
    CodeRepository?: CodeRepositoryDetails;
    AzureResource?: any;
}
export interface Resource {
    Type?: string;
    Id?: string;
    Partition?: Partition;
    Region?: string;
    Provider?: CloudProviderName;
    Owner?: ResourceOwner;
    ResourceRole?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    DataClassification?: DataClassificationDetails;
    Details?: ResourceDetails;
    ApplicationName?: string;
    ApplicationArn?: string;
}
export type ResourceList = Resource[];
export type ComplianceStatus = "PASSED" | "WARNING" | "FAILED" | "NOT_AVAILABLE" | (string & {});
export interface StatusReason {
    ReasonCode?: string;
    Description?: string;
}
export type StatusReasonsList = StatusReason[];
export interface AssociatedStandard {
    StandardsId?: string;
}
export type AssociatedStandardsList = AssociatedStandard[];
export interface SecurityControlParameter {
    Name?: string;
    Value?: string[];
}
export type SecurityControlParametersList = SecurityControlParameter[];
export interface Compliance {
    Status?: ComplianceStatus;
    RelatedRequirements?: string[];
    StatusReasons?: StatusReason[];
    SecurityControlId?: string;
    AssociatedStandards?: AssociatedStandard[];
    SecurityControlParameters?: SecurityControlParameter[];
}
export type WorkflowState = "NEW" | "ASSIGNED" | "IN_PROGRESS" | "DEFERRED" | "RESOLVED" | (string & {});
export interface Workflow {
    Status?: WorkflowStatus;
}
export type RecordState = "ACTIVE" | "ARCHIVED" | (string & {});
export interface Note {
    Text?: string;
    UpdatedBy?: string;
    UpdatedAt?: string;
}
export interface SoftwarePackage {
    Name?: string;
    Version?: string;
    Epoch?: string;
    Release?: string;
    Architecture?: string;
    PackageManager?: string;
    FilePath?: string;
    FixedInVersion?: string;
    Remediation?: string;
    SourceLayerHash?: string;
    SourceLayerArn?: string;
}
export type SoftwarePackageList = SoftwarePackage[];
export interface Adjustment {
    Metric?: string;
    Reason?: string;
}
export type AdjustmentList = Adjustment[];
export interface Cvss {
    Version?: string;
    BaseScore?: number;
    BaseVector?: string;
    Source?: string;
    Adjustments?: Adjustment[];
}
export type CvssList = Cvss[];
export interface VulnerabilityVendor {
    Name?: string;
    Url?: string;
    VendorSeverity?: string;
    VendorCreatedAt?: string;
    VendorUpdatedAt?: string;
}
export type VulnerabilityFixAvailable = "YES" | "NO" | "PARTIAL" | (string & {});
export type VulnerabilityExploitAvailable = "YES" | "NO" | (string & {});
export interface CodeVulnerabilitiesFilePath {
    EndLine?: number;
    FileName?: string;
    FilePath?: string;
    StartLine?: number;
}
export interface VulnerabilityCodeVulnerabilities {
    Cwes?: string[];
    FilePath?: CodeVulnerabilitiesFilePath;
    SourceArn?: string;
}
export type VulnerabilityCodeVulnerabilitiesList = VulnerabilityCodeVulnerabilities[];
export interface Vulnerability {
    Id?: string;
    VulnerablePackages?: SoftwarePackage[];
    Cvss?: Cvss[];
    RelatedVulnerabilities?: string[];
    Vendor?: VulnerabilityVendor;
    ReferenceUrls?: string[];
    FixAvailable?: VulnerabilityFixAvailable;
    EpssScore?: number;
    ExploitAvailable?: VulnerabilityExploitAvailable;
    LastKnownExploitAt?: string;
    CodeVulnerabilities?: VulnerabilityCodeVulnerabilities[];
}
export type VulnerabilityList = Vulnerability[];
export interface PatchSummary {
    Id?: string;
    InstalledCount?: number;
    MissingCount?: number;
    FailedCount?: number;
    InstalledOtherCount?: number;
    InstalledRejectedCount?: number;
    InstalledPendingReboot?: number;
    OperationStartTime?: string;
    OperationEndTime?: string;
    RebootOption?: string;
    Operation?: string;
}
export interface IpOrganizationDetails {
    Asn?: number;
    AsnOrg?: string;
    Isp?: string;
    Org?: string;
}
export interface Country {
    CountryCode?: string;
    CountryName?: string;
}
export interface City {
    CityName?: string;
}
export interface GeoLocation {
    Lon?: number;
    Lat?: number;
}
export interface ActionRemoteIpDetails {
    IpAddressV4?: string;
    Organization?: IpOrganizationDetails;
    Country?: Country;
    City?: City;
    GeoLocation?: GeoLocation;
}
export interface ActionRemotePortDetails {
    Port?: number;
    PortName?: string;
}
export interface ActionLocalPortDetails {
    Port?: number;
    PortName?: string;
}
export interface NetworkConnectionAction {
    ConnectionDirection?: string;
    RemoteIpDetails?: ActionRemoteIpDetails;
    RemotePortDetails?: ActionRemotePortDetails;
    LocalPortDetails?: ActionLocalPortDetails;
    Protocol?: string;
    Blocked?: boolean;
}
export interface AwsApiCallActionDomainDetails {
    Domain?: string;
}
export interface AwsApiCallAction {
    Api?: string;
    ServiceName?: string;
    CallerType?: string;
    RemoteIpDetails?: ActionRemoteIpDetails;
    DomainDetails?: AwsApiCallActionDomainDetails;
    AffectedResources?: {
        [key: string]: string | undefined;
    };
    FirstSeen?: string;
    LastSeen?: string;
}
export interface DnsRequestAction {
    Domain?: string;
    Protocol?: string;
    Blocked?: boolean;
}
export interface ActionLocalIpDetails {
    IpAddressV4?: string;
}
export interface PortProbeDetail {
    LocalPortDetails?: ActionLocalPortDetails;
    LocalIpDetails?: ActionLocalIpDetails;
    RemoteIpDetails?: ActionRemoteIpDetails;
}
export type PortProbeDetailList = PortProbeDetail[];
export interface PortProbeAction {
    PortProbeDetails?: PortProbeDetail[];
    Blocked?: boolean;
}
export interface Action {
    ActionType?: string;
    NetworkConnectionAction?: NetworkConnectionAction;
    AwsApiCallAction?: AwsApiCallAction;
    DnsRequestAction?: DnsRequestAction;
    PortProbeAction?: PortProbeAction;
}
export interface FindingProviderSeverity {
    Label?: SeverityLabel;
    Original?: string;
}
export interface FindingProviderFields {
    Confidence?: number;
    Criticality?: number;
    RelatedFindings?: RelatedFinding[];
    Severity?: FindingProviderSeverity;
    Types?: string[];
}
export interface GeneratorDetails {
    Name?: string;
    Description?: string;
    Labels?: string[];
}
export interface UserAccount {
    Uid?: string;
    Name?: string;
}
export interface ActorUser {
    Name?: string;
    Uid?: string;
    Type?: string;
    CredentialUid?: string;
    Account?: UserAccount;
}
export type ActorSessionMfaStatus = "ENABLED" | "DISABLED" | (string & {});
export interface ActorSession {
    Uid?: string;
    MfaStatus?: ActorSessionMfaStatus;
    CreatedTime?: number;
    Issuer?: string;
}
export interface Actor {
    Id?: string;
    User?: ActorUser;
    Session?: ActorSession;
}
export type ActorsList = Actor[];
export interface NetworkGeoLocation {
    City?: string;
    Country?: string;
    Lat?: number;
    Lon?: number;
}
export interface NetworkAutonomousSystem {
    Name?: string;
    Number?: number;
}
export type ConnectionDirection = "INBOUND" | "OUTBOUND" | (string & {});
export interface NetworkConnection {
    Direction?: ConnectionDirection;
}
export interface NetworkEndpoint {
    Id?: string;
    Ip?: string;
    Domain?: string;
    Port?: number;
    Location?: NetworkGeoLocation;
    AutonomousSystem?: NetworkAutonomousSystem;
    Connection?: NetworkConnection;
}
export type NetworkEndpointsList = NetworkEndpoint[];
export interface Indicator {
    Key?: string;
    Values?: string[];
    Title?: string;
    Type?: string;
}
export type IndicatorsList = Indicator[];
export interface Signal {
    Type?: string;
    Id?: string;
    Title?: string;
    ProductArn?: string;
    ResourceIds?: string[];
    SignalIndicators?: Indicator[];
    Name?: string;
    CreatedAt?: number;
    UpdatedAt?: number;
    FirstSeenAt?: number;
    LastSeenAt?: number;
    Severity?: number;
    Count?: number;
    ActorIds?: string[];
    EndpointIds?: string[];
}
export type SignalsList = Signal[];
export interface Sequence {
    Uid?: string;
    Actors?: Actor[];
    Endpoints?: NetworkEndpoint[];
    Signals?: Signal[];
    SequenceIndicators?: Indicator[];
}
export interface Detection {
    Sequence?: Sequence;
}
export interface AwsSecurityFinding {
    SchemaVersion?: string;
    Id?: string;
    ProductArn?: string;
    ProductName?: string;
    CompanyName?: string;
    Region?: string;
    GeneratorId?: string;
    AwsAccountId?: string;
    Types?: string[];
    FirstObservedAt?: string;
    LastObservedAt?: string;
    CreatedAt?: string;
    UpdatedAt?: string;
    Severity?: Severity;
    Confidence?: number;
    Criticality?: number;
    Title?: string;
    Description?: string;
    Remediation?: Remediation;
    SourceUrl?: string;
    ProductFields?: {
        [key: string]: string | undefined;
    };
    UserDefinedFields?: {
        [key: string]: string | undefined;
    };
    Malware?: Malware[];
    Network?: Network;
    NetworkPath?: NetworkPathComponent[];
    Process?: ProcessDetails;
    Threats?: Threat[];
    ThreatIntelIndicators?: ThreatIntelIndicator[];
    Resources?: Resource[];
    Compliance?: Compliance;
    VerificationState?: VerificationState;
    WorkflowState?: WorkflowState;
    Workflow?: Workflow;
    RecordState?: RecordState;
    RelatedFindings?: RelatedFinding[];
    Note?: Note;
    Vulnerabilities?: Vulnerability[];
    PatchSummary?: PatchSummary;
    Action?: Action;
    FindingProviderFields?: FindingProviderFields;
    Sample?: boolean;
    GeneratorDetails?: GeneratorDetails;
    ProcessedAt?: string;
    AwsAccountName?: string;
    Detection?: Detection;
}
export type BatchImportFindingsRequestFindingList = AwsSecurityFinding[];
export interface BatchImportFindingsRequest {
    Findings?: AwsSecurityFinding[];
}
export interface ImportFindingsError {
    Id?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export type ImportFindingsErrorList = ImportFindingsError[];
export interface BatchImportFindingsResponse {
    FailedCount: number;
    SuccessCount: number;
    FailedFindings?: (ImportFindingsError & {
        Id: NonEmptyString;
        ErrorCode: NonEmptyString;
        ErrorMessage: NonEmptyString;
    })[];
}
export interface UpdateAutomationRulesRequestItem {
    RuleArn?: string;
    RuleStatus?: RuleStatus;
    RuleOrder?: number;
    Description?: string;
    RuleName?: string;
    IsTerminal?: boolean;
    Criteria?: AutomationRulesFindingFilters;
    Actions?: AutomationRulesAction[];
}
export type UpdateAutomationRulesRequestItemsList = UpdateAutomationRulesRequestItem[];
export interface BatchUpdateAutomationRulesRequest {
    UpdateAutomationRulesRequestItems?: UpdateAutomationRulesRequestItem[];
}
export interface BatchUpdateAutomationRulesResponse {
    ProcessedAutomationRules?: string[];
    UnprocessedAutomationRules?: UnprocessedAutomationRule[];
}
export interface AwsSecurityFindingIdentifier {
    Id?: string;
    ProductArn?: string;
}
export type AwsSecurityFindingIdentifierList = AwsSecurityFindingIdentifier[];
export interface BatchUpdateFindingsRequest {
    FindingIdentifiers?: AwsSecurityFindingIdentifier[];
    Note?: NoteUpdate;
    Severity?: SeverityUpdate;
    VerificationState?: VerificationState;
    Confidence?: number;
    Criticality?: number;
    Types?: string[];
    UserDefinedFields?: {
        [key: string]: string | undefined;
    };
    Workflow?: WorkflowUpdate;
    RelatedFindings?: RelatedFinding[];
}
export interface BatchUpdateFindingsUnprocessedFinding {
    FindingIdentifier?: AwsSecurityFindingIdentifier;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export type BatchUpdateFindingsUnprocessedFindingsList = BatchUpdateFindingsUnprocessedFinding[];
export interface BatchUpdateFindingsResponse {
    ProcessedFindings: (AwsSecurityFindingIdentifier & {
        Id: NonEmptyString;
        ProductArn: NonEmptyString;
    })[];
    UnprocessedFindings: (BatchUpdateFindingsUnprocessedFinding & {
        FindingIdentifier: AwsSecurityFindingIdentifier & {
            Id: NonEmptyString;
            ProductArn: NonEmptyString;
        };
        ErrorCode: NonEmptyString;
        ErrorMessage: NonEmptyString;
    })[];
}
export type MetadataUidList = string[];
export interface OcsfFindingIdentifier {
    CloudAccountUid?: string;
    FindingInfoUid?: string;
    MetadataProductUid?: string;
}
export type OcsfFindingIdentifierList = OcsfFindingIdentifier[];
export interface BatchUpdateFindingsV2Request {
    MetadataUids?: string[];
    FindingIdentifiers?: OcsfFindingIdentifier[];
    Comment?: string;
    SeverityId?: number;
    StatusId?: number;
}
export interface BatchUpdateFindingsV2ProcessedFinding {
    FindingIdentifier?: OcsfFindingIdentifier;
    MetadataUid?: string;
}
export type BatchUpdateFindingsV2ProcessedFindingsList = BatchUpdateFindingsV2ProcessedFinding[];
export type BatchUpdateFindingsV2UnprocessedFindingErrorCode = "ResourceNotFoundException" | "ValidationException" | "InternalServerException" | "ConflictException" | (string & {});
export interface BatchUpdateFindingsV2UnprocessedFinding {
    FindingIdentifier?: OcsfFindingIdentifier;
    MetadataUid?: string;
    ErrorCode?: BatchUpdateFindingsV2UnprocessedFindingErrorCode;
    ErrorMessage?: string;
}
export type BatchUpdateFindingsV2UnprocessedFindingsList = BatchUpdateFindingsV2UnprocessedFinding[];
export interface BatchUpdateFindingsV2Response {
    ProcessedFindings: (BatchUpdateFindingsV2ProcessedFinding & {
        FindingIdentifier: OcsfFindingIdentifier & {
            CloudAccountUid: NonEmptyString;
            FindingInfoUid: NonEmptyString;
            MetadataProductUid: NonEmptyString;
        };
    })[];
    UnprocessedFindings: (BatchUpdateFindingsV2UnprocessedFinding & {
        FindingIdentifier: OcsfFindingIdentifier & {
            CloudAccountUid: NonEmptyString;
            FindingInfoUid: NonEmptyString;
            MetadataProductUid: NonEmptyString;
        };
    })[];
}
export interface StandardsControlAssociationUpdate {
    StandardsArn?: string;
    SecurityControlId?: string;
    AssociationStatus?: AssociationStatus;
    UpdatedReason?: string;
}
export type StandardsControlAssociationUpdates = StandardsControlAssociationUpdate[];
export interface BatchUpdateStandardsControlAssociationsRequest {
    StandardsControlAssociationUpdates?: StandardsControlAssociationUpdate[];
}
export interface UnprocessedStandardsControlAssociationUpdate {
    StandardsControlAssociationUpdate?: StandardsControlAssociationUpdate;
    ErrorCode?: UnprocessedErrorCode;
    ErrorReason?: string;
}
export type UnprocessedStandardsControlAssociationUpdates = UnprocessedStandardsControlAssociationUpdate[];
export interface BatchUpdateStandardsControlAssociationsResponse {
    UnprocessedAssociationUpdates?: (UnprocessedStandardsControlAssociationUpdate & {
        StandardsControlAssociationUpdate: StandardsControlAssociationUpdate & {
            StandardsArn: NonEmptyString;
            SecurityControlId: NonEmptyString;
            AssociationStatus: AssociationStatus;
        };
        ErrorCode: UnprocessedErrorCode;
    })[];
}
export interface CreateActionTargetRequest {
    Name?: string;
    Description?: string;
    Id?: string;
}
export interface CreateActionTargetResponse {
    ActionTargetArn: string;
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type ClientToken = string;
export interface CreateAggregatorV2Request {
    RegionLinkingMode?: string;
    LinkedRegions?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export interface CreateAggregatorV2Response {
    AggregatorV2Arn?: string;
    AggregationRegion?: string;
    RegionLinkingMode?: string;
    LinkedRegions?: string[];
}
export interface CreateAutomationRuleRequest {
    Tags?: {
        [key: string]: string | undefined;
    };
    RuleStatus?: RuleStatus;
    RuleOrder?: number;
    RuleName?: string;
    Description?: string;
    IsTerminal?: boolean;
    Criteria?: AutomationRulesFindingFilters;
    Actions?: AutomationRulesAction[];
}
export interface CreateAutomationRuleResponse {
    RuleArn?: string;
}
export type RuleStatusV2 = "ENABLED" | "DISABLED" | (string & {});
export type RuleOrderValueV2 = number;
export type OcsfStringField = "metadata.uid" | "activity_name" | "cloud.account.uid" | "cloud.provider" | "cloud.region" | "compliance.assessments.category" | "compliance.assessments.name" | "compliance.control" | "compliance.status" | "compliance.standards" | "finding_info.desc" | "finding_info.src_url" | "finding_info.title" | "finding_info.types" | "finding_info.uid" | "finding_info.related_events.traits.category" | "finding_info.related_events.uid" | "finding_info.related_events.product.uid" | "finding_info.related_events.title" | "metadata.product.name" | "metadata.product.uid" | "metadata.product.vendor_name" | "remediation.desc" | "remediation.references" | "resources.cloud_partition" | "resources.name" | "resources.owner.account.uid" | "resources.owner.org.uid" | "resources.owner.account.name" | "resources.provider" | "resources.region" | "resources.type" | "resources.uid" | "severity" | "status" | "comment" | "vulnerabilities.fix_coverage" | "class_name" | "databucket.encryption_details.algorithm" | "databucket.encryption_details.key_uid" | "databucket.file.data_classifications.classifier_details.type" | "evidences.actor.user.account.uid" | "evidences.api.operation" | "evidences.api.response.error_message" | "evidences.api.service.name" | "evidences.connection_info.direction" | "evidences.connection_info.protocol_name" | "evidences.dst_endpoint.autonomous_system.name" | "evidences.dst_endpoint.location.city" | "evidences.dst_endpoint.location.country" | "evidences.src_endpoint.autonomous_system.name" | "evidences.src_endpoint.hostname" | "evidences.src_endpoint.location.city" | "evidences.src_endpoint.location.country" | "finding_info.analytic.name" | "malware.name" | "malware_scan_info.uid" | "malware.severity" | "resources.cloud_function.layers.uid_alt" | "resources.cloud_function.runtime" | "resources.cloud_function.user.uid" | "resources.device.encryption_details.key_uid" | "resources.device.image.uid" | "resources.image.architecture" | "resources.image.registry_uid" | "resources.image.repository_name" | "resources.image.uid" | "resources.subnet_info.uid" | "resources.vpc_uid" | "vulnerabilities.affected_code.file.path" | "vulnerabilities.affected_packages.name" | "vulnerabilities.cve.epss.score" | "vulnerabilities.cve.uid" | "vulnerabilities.related_vulnerabilities" | "cloud.account.name" | "vendor_attributes.severity" | (string & {});
export interface OcsfStringFilter {
    FieldName?: OcsfStringField;
    Filter?: StringFilter;
}
export type OcsfStringFilterList = OcsfStringFilter[];
export type OcsfDateField = "finding_info.created_time_dt" | "finding_info.first_seen_time_dt" | "finding_info.last_seen_time_dt" | "finding_info.modified_time_dt" | "resources.image.created_time_dt" | "resources.image.last_used_time_dt" | "resources.modified_time_dt" | (string & {});
export interface OcsfDateFilter {
    FieldName?: OcsfDateField;
    Filter?: DateFilter;
}
export type OcsfDateFilterList = OcsfDateFilter[];
export type OcsfBooleanField = "compliance.assessments.meets_criteria" | "vulnerabilities.is_exploit_available" | "vulnerabilities.is_fix_available" | (string & {});
export interface BooleanFilter {
    Value?: boolean;
}
export interface OcsfBooleanFilter {
    FieldName?: OcsfBooleanField;
    Filter?: BooleanFilter;
}
export type OcsfBooleanFilterList = OcsfBooleanFilter[];
export type OcsfNumberField = "activity_id" | "compliance.status_id" | "confidence_score" | "severity_id" | "status_id" | "finding_info.related_events_count" | "evidences.api.response.code" | "evidences.dst_endpoint.autonomous_system.number" | "evidences.dst_endpoint.port" | "evidences.src_endpoint.autonomous_system.number" | "evidences.src_endpoint.port" | "resources.image.in_use_count" | "vulnerabilities.cve.cvss.base_score" | "vendor_attributes.severity_id" | (string & {});
export interface OcsfNumberFilter {
    FieldName?: OcsfNumberField;
    Filter?: NumberFilter;
}
export type OcsfNumberFilterList = OcsfNumberFilter[];
export type OcsfMapField = "resources.tags" | "compliance.control_parameters" | "databucket.tags" | "finding_info.tags" | (string & {});
export interface OcsfMapFilter {
    FieldName?: OcsfMapField;
    Filter?: MapFilter;
}
export type OcsfMapFilterList = OcsfMapFilter[];
export type OcsfIpField = "evidences.dst_endpoint.ip" | "evidences.src_endpoint.ip" | (string & {});
export interface IpFilter {
    Cidr?: string;
}
export interface OcsfIpFilter {
    FieldName?: OcsfIpField;
    Filter?: IpFilter;
}
export type OcsfIpFilterList = OcsfIpFilter[];
export type AllowedOperators = "AND" | "OR" | (string & {});
export interface CompositeFilter {
    StringFilters?: OcsfStringFilter[];
    DateFilters?: OcsfDateFilter[];
    BooleanFilters?: OcsfBooleanFilter[];
    NumberFilters?: OcsfNumberFilter[];
    MapFilters?: OcsfMapFilter[];
    IpFilters?: OcsfIpFilter[];
    NestedCompositeFilters?: CompositeFilter[];
    Operator?: AllowedOperators;
}
export type CompositeFilterList = CompositeFilter[];
export interface OcsfFindingFilters {
    CompositeFilters?: CompositeFilter[];
    CompositeOperator?: AllowedOperators;
}
export type Criteria = {
    OcsfFindingCriteria: OcsfFindingFilters;
};
export type AutomationRulesActionTypeV2 = "FINDING_FIELDS_UPDATE" | "EXTERNAL_INTEGRATION" | (string & {});
export interface AutomationRulesFindingFieldsUpdateV2 {
    SeverityId?: number;
    Comment?: string;
    StatusId?: number;
}
export interface ExternalIntegrationConfiguration {
    ConnectorArn?: string;
}
export interface AutomationRulesActionV2 {
    Type?: AutomationRulesActionTypeV2;
    FindingFieldsUpdate?: AutomationRulesFindingFieldsUpdateV2;
    ExternalIntegrationConfiguration?: ExternalIntegrationConfiguration;
}
export type AutomationRulesActionListV2 = AutomationRulesActionV2[];
export interface CreateAutomationRuleV2Request {
    RuleName?: string;
    RuleStatus?: RuleStatusV2;
    Description?: string;
    RuleOrder?: number;
    Criteria?: Criteria;
    Actions?: AutomationRulesActionV2[];
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export interface CreateAutomationRuleV2Response {
    RuleArn?: string;
    RuleId?: string;
}
export type EnabledStandardIdentifierList = string[];
export type EnabledSecurityControlIdentifierList = string[];
export type DisabledSecurityControlIdentifierList = string[];
export interface SecurityControlCustomParameter {
    SecurityControlId?: string;
    Parameters?: {
        [key: string]: ParameterConfiguration | undefined;
    };
}
export type SecurityControlCustomParametersList = SecurityControlCustomParameter[];
export interface SecurityControlsConfiguration {
    EnabledSecurityControlIdentifiers?: string[];
    DisabledSecurityControlIdentifiers?: string[];
    SecurityControlCustomParameters?: SecurityControlCustomParameter[];
}
export interface SecurityHubPolicy {
    ServiceEnabled?: boolean;
    EnabledStandardIdentifiers?: string[];
    SecurityControlsConfiguration?: SecurityControlsConfiguration;
}
export type Policy = {
    SecurityHub: SecurityHubPolicy;
};
export interface CreateConfigurationPolicyRequest {
    Name?: string;
    Description?: string;
    ConfigurationPolicy?: Policy;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateConfigurationPolicyResponse {
    Arn?: string;
    Id?: string;
    Name?: string;
    Description?: string;
    UpdatedAt?: Date;
    CreatedAt?: Date;
    ConfigurationPolicy?: Policy;
}
export type ScopeType = "TENANT" | "SUBSCRIPTION" | (string & {});
export type ScopeValueList = string[];
export interface AzureScopeConfiguration {
    ScopeType?: ScopeType;
    ScopeValues?: string[];
}
export type AzureRegionList = string[];
export interface AzureProviderConfiguration {
    AWSConfigConnectorArn?: string;
    ScopeConfiguration?: AzureScopeConfiguration;
    AzureRegions?: string[];
}
export type CspmProviderConfiguration = {
    Azure: AzureProviderConfiguration;
};
export interface CreateConnectorRequest {
    Name?: string;
    Description?: string;
    Provider?: CspmProviderConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export type CspmConnectorStatus = "CONNECTED" | "DEGRADED" | "FAILED_TO_CONNECT" | "UNKNOWN" | (string & {});
export type CspmEnablementStatus = "ENABLED" | "PENDING_ENABLEMENT" | "PENDING_UPDATE" | "PENDING_DELETION" | (string & {});
export interface CreateConnectorResponse {
    ConnectorArn: string;
    ConnectorId: string;
    ConnectorStatus?: CspmConnectorStatus;
    EnablementStatus?: CspmEnablementStatus;
}
export interface JiraCloudProviderConfiguration {
    ProjectKey?: string;
}
export interface ServiceNowProviderConfiguration {
    InstanceName?: string;
    SecretArn?: string;
}
export type ProviderConfiguration = {
    JiraCloud: JiraCloudProviderConfiguration;
    ServiceNow?: never;
    Azure?: never;
} | {
    JiraCloud?: never;
    ServiceNow: ServiceNowProviderConfiguration;
    Azure?: never;
} | {
    JiraCloud?: never;
    ServiceNow?: never;
    Azure: AzureProviderConfiguration;
};
export interface CreateConnectorV2Request {
    Name?: string;
    Description?: string;
    Provider?: ProviderConfiguration;
    KmsKeyArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export type ConnectorStatus = "CONNECTED" | "DEGRADED" | "FAILED_TO_CONNECT" | "PENDING_AUTHORIZATION" | "PENDING_CONFIGURATION" | "UNKNOWN" | (string & {});
export type EnablementStatus = "ENABLED" | "PENDING_ENABLEMENT" | "FAILED_TO_ENABLE" | "PENDING_UPDATE" | "FAILED_TO_UPDATE" | "PENDING_DELETION" | "FAILED_TO_DELETE" | (string & {});
export interface CreateConnectorV2Response {
    ConnectorArn: string;
    ConnectorId: string;
    AuthUrl?: string;
    ConnectorStatus?: ConnectorStatus;
    EnablementStatus?: EnablementStatus;
}
export interface CreateFindingAggregatorRequest {
    RegionLinkingMode?: string;
    Regions?: string[];
}
export interface CreateFindingAggregatorResponse {
    FindingAggregatorArn?: string;
    FindingAggregationRegion?: string;
    RegionLinkingMode?: string;
    Regions?: string[];
}
export type IpFilterList = IpFilter[];
export interface KeywordFilter {
    Value?: string;
}
export type KeywordFilterList = KeywordFilter[];
export type BooleanFilterList = BooleanFilter[];
export interface AwsSecurityFindingFilters {
    ProductArn?: StringFilter[];
    AwsAccountId?: StringFilter[];
    Id?: StringFilter[];
    GeneratorId?: StringFilter[];
    Region?: StringFilter[];
    Type?: StringFilter[];
    FirstObservedAt?: DateFilter[];
    LastObservedAt?: DateFilter[];
    CreatedAt?: DateFilter[];
    UpdatedAt?: DateFilter[];
    SeverityProduct?: NumberFilter[];
    SeverityNormalized?: NumberFilter[];
    SeverityLabel?: StringFilter[];
    Confidence?: NumberFilter[];
    Criticality?: NumberFilter[];
    Title?: StringFilter[];
    Description?: StringFilter[];
    RecommendationText?: StringFilter[];
    SourceUrl?: StringFilter[];
    ProductFields?: MapFilter[];
    ProductName?: StringFilter[];
    CompanyName?: StringFilter[];
    UserDefinedFields?: MapFilter[];
    MalwareName?: StringFilter[];
    MalwareType?: StringFilter[];
    MalwarePath?: StringFilter[];
    MalwareState?: StringFilter[];
    NetworkDirection?: StringFilter[];
    NetworkProtocol?: StringFilter[];
    NetworkSourceIpV4?: IpFilter[];
    NetworkSourceIpV6?: IpFilter[];
    NetworkSourcePort?: NumberFilter[];
    NetworkSourceDomain?: StringFilter[];
    NetworkSourceMac?: StringFilter[];
    NetworkDestinationIpV4?: IpFilter[];
    NetworkDestinationIpV6?: IpFilter[];
    NetworkDestinationPort?: NumberFilter[];
    NetworkDestinationDomain?: StringFilter[];
    ProcessName?: StringFilter[];
    ProcessPath?: StringFilter[];
    ProcessPid?: NumberFilter[];
    ProcessParentPid?: NumberFilter[];
    ProcessLaunchedAt?: DateFilter[];
    ProcessTerminatedAt?: DateFilter[];
    ThreatIntelIndicatorType?: StringFilter[];
    ThreatIntelIndicatorValue?: StringFilter[];
    ThreatIntelIndicatorCategory?: StringFilter[];
    ThreatIntelIndicatorLastObservedAt?: DateFilter[];
    ThreatIntelIndicatorSource?: StringFilter[];
    ThreatIntelIndicatorSourceUrl?: StringFilter[];
    ResourceType?: StringFilter[];
    ResourceId?: StringFilter[];
    ResourcePartition?: StringFilter[];
    ResourceRegion?: StringFilter[];
    ResourceTags?: MapFilter[];
    ResourceAwsEc2InstanceType?: StringFilter[];
    ResourceAwsEc2InstanceImageId?: StringFilter[];
    ResourceAwsEc2InstanceIpV4Addresses?: IpFilter[];
    ResourceAwsEc2InstanceIpV6Addresses?: IpFilter[];
    ResourceAwsEc2InstanceKeyName?: StringFilter[];
    ResourceAwsEc2InstanceIamInstanceProfileArn?: StringFilter[];
    ResourceAwsEc2InstanceVpcId?: StringFilter[];
    ResourceAwsEc2InstanceSubnetId?: StringFilter[];
    ResourceAwsEc2InstanceLaunchedAt?: DateFilter[];
    ResourceAwsS3BucketOwnerId?: StringFilter[];
    ResourceAwsS3BucketOwnerName?: StringFilter[];
    ResourceAwsIamAccessKeyUserName?: StringFilter[];
    ResourceAwsIamAccessKeyPrincipalName?: StringFilter[];
    ResourceAwsIamAccessKeyStatus?: StringFilter[];
    ResourceAwsIamAccessKeyCreatedAt?: DateFilter[];
    ResourceAwsIamUserUserName?: StringFilter[];
    ResourceContainerName?: StringFilter[];
    ResourceContainerImageId?: StringFilter[];
    ResourceContainerImageName?: StringFilter[];
    ResourceContainerLaunchedAt?: DateFilter[];
    ResourceDetailsOther?: MapFilter[];
    ComplianceStatus?: StringFilter[];
    VerificationState?: StringFilter[];
    WorkflowState?: StringFilter[];
    WorkflowStatus?: StringFilter[];
    RecordState?: StringFilter[];
    RelatedFindingsProductArn?: StringFilter[];
    RelatedFindingsId?: StringFilter[];
    NoteText?: StringFilter[];
    NoteUpdatedAt?: DateFilter[];
    NoteUpdatedBy?: StringFilter[];
    Keyword?: KeywordFilter[];
    FindingProviderFieldsConfidence?: NumberFilter[];
    FindingProviderFieldsCriticality?: NumberFilter[];
    FindingProviderFieldsRelatedFindingsId?: StringFilter[];
    FindingProviderFieldsRelatedFindingsProductArn?: StringFilter[];
    FindingProviderFieldsSeverityLabel?: StringFilter[];
    FindingProviderFieldsSeverityOriginal?: StringFilter[];
    FindingProviderFieldsTypes?: StringFilter[];
    Sample?: BooleanFilter[];
    ComplianceSecurityControlId?: StringFilter[];
    ComplianceAssociatedStandardsId?: StringFilter[];
    VulnerabilitiesExploitAvailable?: StringFilter[];
    VulnerabilitiesFixAvailable?: StringFilter[];
    ComplianceSecurityControlParametersName?: StringFilter[];
    ComplianceSecurityControlParametersValue?: StringFilter[];
    AwsAccountName?: StringFilter[];
    ResourceApplicationName?: StringFilter[];
    ResourceApplicationArn?: StringFilter[];
    ResourceOwnerAccountId?: StringFilter[];
    ResourceOwnerOrgId?: StringFilter[];
    ResourceProvider?: StringFilter[];
}
export interface CreateInsightRequest {
    Name?: string;
    Filters?: AwsSecurityFindingFilters;
    GroupByAttribute?: string;
}
export interface CreateInsightResponse {
    InsightArn: string;
}
export type AccountId = string;
export interface AccountDetails {
    AccountId?: string;
    Email?: string;
}
export type AccountDetailsList = AccountDetails[];
export interface CreateMembersRequest {
    AccountDetails?: AccountDetails[];
}
export interface Result {
    AccountId?: string;
    ProcessingResult?: string;
}
export type ResultList = Result[];
export interface CreateMembersResponse {
    UnprocessedAccounts?: Result[];
}
export type TicketCreationMode = "DRYRUN" | (string & {});
export interface CreateTicketV2Request {
    ConnectorId?: string;
    FindingMetadataUid?: string;
    ClientToken?: string;
    Mode?: TicketCreationMode;
}
export interface CreateTicketV2Response {
    TicketId: string;
    TicketSrcUrl?: string;
}
export type AccountIdList = string[];
export interface DeclineInvitationsRequest {
    AccountIds?: string[];
}
export interface DeclineInvitationsResponse {
    UnprocessedAccounts?: Result[];
}
export interface DeleteActionTargetRequest {
    ActionTargetArn: string;
}
export interface DeleteActionTargetResponse {
    ActionTargetArn: string;
}
export interface DeleteAggregatorV2Request {
    AggregatorV2Arn: string;
}
export interface DeleteAggregatorV2Response {
}
export interface DeleteAutomationRuleV2Request {
    Identifier: string;
}
export interface DeleteAutomationRuleV2Response {
}
export interface DeleteConfigurationPolicyRequest {
    Identifier: string;
}
export interface DeleteConfigurationPolicyResponse {
}
export interface DeleteConnectorRequest {
    ConnectorId: string;
}
export interface DeleteConnectorResponse {
    EnablementStatus?: CspmEnablementStatus;
}
export interface DeleteConnectorV2Request {
    ConnectorId: string;
}
export interface DeleteConnectorV2Response {
    EnablementStatus?: EnablementStatus;
}
export interface DeleteFindingAggregatorRequest {
    FindingAggregatorArn: string;
}
export interface DeleteFindingAggregatorResponse {
}
export interface DeleteInsightRequest {
    InsightArn: string;
}
export interface DeleteInsightResponse {
    InsightArn: string;
}
export interface DeleteInvitationsRequest {
    AccountIds?: string[];
}
export interface DeleteInvitationsResponse {
    UnprocessedAccounts?: Result[];
}
export interface DeleteMembersRequest {
    AccountIds?: string[];
}
export interface DeleteMembersResponse {
    UnprocessedAccounts?: Result[];
}
export type ArnList = string[];
export type NextToken = string;
export type MaxResults = number;
export interface DescribeActionTargetsRequest {
    ActionTargetArns?: string[];
    NextToken?: string;
    MaxResults?: number;
}
export interface ActionTarget {
    ActionTargetArn?: string;
    Name?: string;
    Description?: string;
}
export type ActionTargetList = ActionTarget[];
export interface DescribeActionTargetsResponse {
    ActionTargets: (ActionTarget & {
        ActionTargetArn: NonEmptyString;
        Name: NonEmptyString;
        Description: NonEmptyString;
    })[];
    NextToken?: string;
}
export interface DescribeHubRequest {
    HubArn?: string;
}
export type ControlFindingGenerator = "STANDARD_CONTROL" | "SECURITY_CONTROL" | (string & {});
export interface DescribeHubResponse {
    HubArn?: string;
    SubscribedAt?: string;
    AutoEnableControls?: boolean;
    ControlFindingGenerator?: ControlFindingGenerator;
}
export interface DescribeOrganizationConfigurationRequest {
}
export type AutoEnableStandards = "NONE" | "DEFAULT" | (string & {});
export type OrganizationConfigurationConfigurationType = "CENTRAL" | "LOCAL" | (string & {});
export type OrganizationConfigurationStatus = "PENDING" | "ENABLED" | "FAILED" | (string & {});
export interface OrganizationConfiguration {
    ConfigurationType?: OrganizationConfigurationConfigurationType;
    Status?: OrganizationConfigurationStatus;
    StatusMessage?: string;
}
export interface DescribeOrganizationConfigurationResponse {
    AutoEnable?: boolean;
    MemberAccountLimitReached?: boolean;
    AutoEnableStandards?: AutoEnableStandards;
    OrganizationConfiguration?: OrganizationConfiguration;
}
export interface DescribeProductsRequest {
    NextToken?: string;
    MaxResults?: number;
    ProductArn?: string;
}
export type CategoryList = string[];
export type IntegrationType = "SEND_FINDINGS_TO_SECURITY_HUB" | "RECEIVE_FINDINGS_FROM_SECURITY_HUB" | "UPDATE_FINDINGS_IN_SECURITY_HUB" | (string & {});
export type IntegrationTypeList = IntegrationType[];
export interface Product {
    ProductArn?: string;
    ProductName?: string;
    CompanyName?: string;
    Description?: string;
    Categories?: string[];
    IntegrationTypes?: IntegrationType[];
    MarketplaceUrl?: string;
    ActivationUrl?: string;
    ProductSubscriptionResourcePolicy?: string;
}
export type ProductsList = Product[];
export interface DescribeProductsResponse {
    Products: (Product & {
        ProductArn: NonEmptyString;
    })[];
    NextToken?: string;
}
export interface DescribeProductsV2Request {
    NextToken?: string;
    MaxResults?: number;
}
export type IntegrationV2Type = "SEND_FINDINGS_TO_SECURITY_HUB" | "RECEIVE_FINDINGS_FROM_SECURITY_HUB" | "UPDATE_FINDINGS_IN_SECURITY_HUB" | "EXTENDED_PLAN" | (string & {});
export type IntegrationV2TypeList = IntegrationV2Type[];
export interface ProductV2 {
    ProductV2Name?: string;
    CompanyName?: string;
    Description?: string;
    Categories?: string[];
    IntegrationV2Types?: IntegrationV2Type[];
    MarketplaceUrl?: string;
    ActivationUrl?: string;
    MarketplaceProductId?: string;
}
export type ProductsV2List = ProductV2[];
export interface DescribeProductsV2Response {
    ProductsV2: ProductV2[];
    NextToken?: string;
}
export interface DescribeSecurityHubV2Request {
}
export type IsoString = string;
export type FeatureNameKey = string;
export type FeatureStatus = "ENABLED" | "DISABLED" | (string & {});
export interface FeatureDetail {
    FeatureStatus?: FeatureStatus;
    UpdatedAt?: Date;
}
export type Features = {
    [key: string]: FeatureDetail | undefined;
};
export interface DescribeSecurityHubV2Response {
    HubV2Arn?: string;
    SubscribedAt?: string;
    Features?: {
        [key: string]: FeatureDetail | undefined;
    };
}
export type StandardsProviders = StandardsProvider[];
export interface DescribeStandardsRequest {
    NextToken?: string;
    MaxResults?: number;
    Providers?: StandardsProvider[];
}
export interface StandardsManagedBy {
    Company?: string;
    Product?: string;
}
export interface Standard {
    StandardsArn?: string;
    Name?: string;
    Description?: string;
    EnabledByDefault?: boolean;
    Provider?: StandardsProvider;
    StandardsManagedBy?: StandardsManagedBy;
}
export type Standards = Standard[];
export interface DescribeStandardsResponse {
    Standards?: Standard[];
    NextToken?: string;
}
export interface DescribeStandardsControlsRequest {
    StandardsSubscriptionArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface StandardsControl {
    StandardsControlArn?: string;
    ControlStatus?: ControlStatus;
    DisabledReason?: string;
    ControlStatusUpdatedAt?: Date;
    ControlId?: string;
    Title?: string;
    Description?: string;
    RemediationUrl?: string;
    SeverityRating?: SeverityRating;
    RelatedRequirements?: string[];
}
export type StandardsControls = StandardsControl[];
export interface DescribeStandardsControlsResponse {
    Controls?: StandardsControl[];
    NextToken?: string;
}
export interface DisableImportFindingsForProductRequest {
    ProductSubscriptionArn: string;
}
export interface DisableImportFindingsForProductResponse {
}
export type SecurityHubFeature = "SecurityHub" | "SecurityHubV2" | (string & {});
export interface DisableOrganizationAdminAccountRequest {
    AdminAccountId?: string;
    Feature?: SecurityHubFeature;
}
export interface DisableOrganizationAdminAccountResponse {
}
export interface DisableSecurityHubRequest {
}
export interface DisableSecurityHubResponse {
}
export type FeatureName = "NETWORK_SCANNING" | (string & {});
export interface DisableSecurityHubFeatureV2Request {
    FeatureName: FeatureName;
}
export interface DisableSecurityHubFeatureV2Response {
}
export interface DisableSecurityHubV2Request {
}
export interface DisableSecurityHubV2Response {
}
export interface DisassociateFromAdministratorAccountRequest {
}
export interface DisassociateFromAdministratorAccountResponse {
}
export interface DisassociateFromMasterAccountRequest {
}
export interface DisassociateFromMasterAccountResponse {
}
export interface DisassociateMembersRequest {
    AccountIds?: string[];
}
export interface DisassociateMembersResponse {
}
export interface EnableImportFindingsForProductRequest {
    ProductArn?: string;
}
export interface EnableImportFindingsForProductResponse {
    ProductSubscriptionArn?: string;
}
export interface EnableOrganizationAdminAccountRequest {
    AdminAccountId?: string;
    Feature?: SecurityHubFeature;
}
export interface EnableOrganizationAdminAccountResponse {
    AdminAccountId?: string;
    Feature?: SecurityHubFeature;
}
export interface EnableSecurityHubRequest {
    Tags?: {
        [key: string]: string | undefined;
    };
    EnableDefaultStandards?: boolean;
    ControlFindingGenerator?: ControlFindingGenerator;
}
export interface EnableSecurityHubResponse {
}
export interface EnableSecurityHubFeatureV2Request {
    FeatureName: FeatureName;
}
export interface EnableSecurityHubFeatureV2Response {
}
export interface EnableSecurityHubV2Request {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface EnableSecurityHubV2Response {
    HubV2Arn?: string;
}
export interface GenerateRecommendedPolicyV2Request {
    MetadataUid: string;
}
export interface GenerateRecommendedPolicyV2Response {
}
export interface GetAdministratorAccountRequest {
}
export interface Invitation {
    AccountId?: string;
    InvitationId?: string;
    InvitedAt?: Date;
    MemberStatus?: string;
}
export interface GetAdministratorAccountResponse {
    Administrator?: Invitation;
}
export interface GetAggregatorV2Request {
    AggregatorV2Arn: string;
}
export interface GetAggregatorV2Response {
    AggregatorV2Arn?: string;
    AggregationRegion?: string;
    RegionLinkingMode?: string;
    LinkedRegions?: string[];
}
export interface GetAutomationRuleV2Request {
    Identifier: string;
}
export interface GetAutomationRuleV2Response {
    RuleArn?: string;
    RuleId?: string;
    RuleOrder?: number;
    RuleName?: string;
    RuleStatus?: RuleStatusV2;
    Description?: string;
    Criteria?: Criteria;
    Actions?: (AutomationRulesActionV2 & {
        Type: AutomationRulesActionTypeV2;
    })[];
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export interface GetConfigurationPolicyRequest {
    Identifier: string;
}
export interface GetConfigurationPolicyResponse {
    Arn?: string;
    Id?: string;
    Name?: string;
    Description?: string;
    UpdatedAt?: Date;
    CreatedAt?: Date;
    ConfigurationPolicy?: Policy;
}
export interface GetConfigurationPolicyAssociationRequest {
    Target?: Target;
}
export interface GetConfigurationPolicyAssociationResponse {
    ConfigurationPolicyId?: string;
    TargetId?: string;
    TargetType?: TargetType;
    AssociationType?: AssociationType;
    UpdatedAt?: Date;
    AssociationStatus?: ConfigurationPolicyAssociationStatus;
    AssociationStatusMessage?: string;
}
export interface GetConnectorRequest {
    ConnectorId: string;
}
export type HealthIssueCode = "AUTHENTICATION_FAILURE" | "STREAM_AUTHORIZATION_FAILURE" | "DISCOVERY_FAILURE" | "STREAM_LIMIT_EXCEEDED" | "STREAM_DISCONNECTED" | "RECORDING_FAILURE" | "NO_HEALTH_DATA" | (string & {});
export interface HealthIssue {
    Code?: HealthIssueCode;
    Message?: string;
}
export type HealthIssueList = HealthIssue[];
export interface CspmHealthCheck {
    ConnectorStatus?: CspmConnectorStatus;
    Message?: string;
    LastCheckedAt?: Date;
    Issues?: HealthIssue[];
}
export interface AzureDetail {
    AWSConfigConnectorArn?: string;
    ScopeConfiguration?: AzureScopeConfiguration;
    AzureRegions?: string[];
}
export type CspmProviderDetail = {
    Azure: AzureDetail;
};
export interface GetConnectorResponse {
    ConnectorArn?: string;
    ConnectorId: string;
    Name: string;
    Description?: string;
    CreatedAt: Date;
    LastUpdatedAt: Date;
    Health: CspmHealthCheck & {
        ConnectorStatus: CspmConnectorStatus;
        LastCheckedAt: Date;
        Issues: (HealthIssue & {
            Code: HealthIssueCode;
            Message: NonEmptyString;
        })[];
    };
    ProviderDetail: CspmProviderDetail;
    CreatedBy?: string;
    EnablementStatus?: CspmEnablementStatus;
}
export interface GetConnectorV2Request {
    ConnectorId: string;
}
export interface HealthCheck {
    ConnectorStatus?: ConnectorStatus;
    Message?: string;
    LastCheckedAt?: Date;
    Issues?: HealthIssue[];
}
export type ConnectorAuthStatus = "ACTIVE" | "FAILED" | (string & {});
export interface JiraCloudDetail {
    CloudId?: string;
    ProjectKey?: string;
    Domain?: string;
    AuthUrl?: string;
    AuthStatus?: ConnectorAuthStatus;
}
export interface ServiceNowDetail {
    InstanceName?: string;
    SecretArn?: string;
    AuthStatus?: ConnectorAuthStatus;
}
export type ProviderDetail = {
    JiraCloud: JiraCloudDetail;
    ServiceNow?: never;
    Azure?: never;
} | {
    JiraCloud?: never;
    ServiceNow: ServiceNowDetail;
    Azure?: never;
} | {
    JiraCloud?: never;
    ServiceNow?: never;
    Azure: AzureDetail;
};
export interface GetConnectorV2Response {
    ConnectorArn?: string;
    ConnectorId: string;
    Name: string;
    Description?: string;
    KmsKeyArn?: string;
    CreatedAt: Date;
    LastUpdatedAt: Date;
    Health: HealthCheck & {
        ConnectorStatus: ConnectorStatus;
        LastCheckedAt: Date;
        Issues: (HealthIssue & {
            Code: HealthIssueCode;
            Message: NonEmptyString;
        })[];
    };
    ProviderDetail: ProviderDetail;
    EnablementStatus?: EnablementStatus;
    EnablementStatusReason?: string;
}
export interface GetEnabledStandardsRequest {
    StandardsSubscriptionArns?: string[];
    NextToken?: string;
    MaxResults?: number;
    Providers?: StandardsProvider[];
}
export interface GetEnabledStandardsResponse {
    StandardsSubscriptions?: (StandardsSubscription & {
        StandardsSubscriptionArn: NonEmptyString;
        StandardsArn: NonEmptyString;
        StandardsInput: StandardsInputParameterMap;
        StandardsStatus: StandardsStatus;
        StandardsStatusReason: StandardsStatusReason & {
            StatusReasonCode: StatusReasonCode;
        };
    })[];
    NextToken?: string;
}
export interface GetFindingAggregatorRequest {
    FindingAggregatorArn: string;
}
export interface GetFindingAggregatorResponse {
    FindingAggregatorArn?: string;
    FindingAggregationRegion?: string;
    RegionLinkingMode?: string;
    Regions?: string[];
}
export interface GetFindingHistoryRequest {
    FindingIdentifier?: AwsSecurityFindingIdentifier;
    StartTime?: Date;
    EndTime?: Date;
    NextToken?: string;
    MaxResults?: number;
}
export type FindingHistoryUpdateSourceType = "BATCH_UPDATE_FINDINGS" | "BATCH_IMPORT_FINDINGS" | (string & {});
export interface FindingHistoryUpdateSource {
    Type?: FindingHistoryUpdateSourceType;
    Identity?: string;
}
export interface FindingHistoryUpdate {
    UpdatedField?: string;
    OldValue?: string;
    NewValue?: string;
}
export type FindingHistoryUpdatesList = FindingHistoryUpdate[];
export interface FindingHistoryRecord {
    FindingIdentifier?: AwsSecurityFindingIdentifier;
    UpdateTime?: Date;
    FindingCreated?: boolean;
    UpdateSource?: FindingHistoryUpdateSource;
    Updates?: FindingHistoryUpdate[];
    NextToken?: string;
}
export type FindingHistoryRecordList = FindingHistoryRecord[];
export interface GetFindingHistoryResponse {
    Records?: (FindingHistoryRecord & {
        FindingIdentifier: AwsSecurityFindingIdentifier & {
            Id: NonEmptyString;
            ProductArn: NonEmptyString;
        };
    })[];
    NextToken?: string;
}
export type SortOrder = "asc" | "desc" | (string & {});
export interface SortCriterion {
    Field?: string;
    SortOrder?: SortOrder;
}
export type SortCriteria = SortCriterion[];
export interface GetFindingsRequest {
    Filters?: AwsSecurityFindingFilters;
    SortCriteria?: SortCriterion[];
    NextToken?: string;
    MaxResults?: number;
}
export type AwsSecurityFindingList = AwsSecurityFinding[];
export interface GetFindingsResponse {
    Findings: (AwsSecurityFinding & {
        SchemaVersion: NonEmptyString;
        Id: NonEmptyString;
        ProductArn: NonEmptyString;
        GeneratorId: NonEmptyString;
        AwsAccountId: NonEmptyString;
        CreatedAt: NonEmptyString;
        UpdatedAt: NonEmptyString;
        Title: NonEmptyString;
        Description: NonEmptyString;
        Resources: (Resource & {
            Type: NonEmptyString;
            Id: NonEmptyString;
        })[];
        Malware: (Malware & {
            Name: NonEmptyString;
        })[];
        Compliance: Compliance & {
            StatusReasons: (StatusReason & {
                ReasonCode: NonEmptyString;
            })[];
        };
        RelatedFindings: (RelatedFinding & {
            ProductArn: NonEmptyString;
            Id: NonEmptyString;
        })[];
        Note: Note & {
            Text: NonEmptyString;
            UpdatedBy: NonEmptyString;
            UpdatedAt: NonEmptyString;
        };
        Vulnerabilities: (Vulnerability & {
            Id: NonEmptyString;
            Vendor: VulnerabilityVendor & {
                Name: NonEmptyString;
            };
        })[];
        PatchSummary: PatchSummary & {
            Id: NonEmptyString;
        };
        FindingProviderFields: FindingProviderFields & {
            RelatedFindings: (RelatedFinding & {
                ProductArn: NonEmptyString;
                Id: NonEmptyString;
            })[];
        };
    })[];
    NextToken?: string;
}
export type GroupByField = "activity_name" | "cloud.account.uid" | "cloud.provider" | "cloud.region" | "compliance.assessments.name" | "compliance.status" | "compliance.control" | "finding_info.title" | "finding_info.related_events.traits.category" | "finding_info.types" | "metadata.product.name" | "metadata.product.uid" | "resources.type" | "resources.cloud_partition" | "resources.name" | "resources.owner.account.uid" | "resources.owner.org.uid" | "resources.owner.account.name" | "resources.provider" | "resources.region" | "resources.uid" | "severity" | "status" | "vulnerabilities.fix_coverage" | "class_name" | "vulnerabilities.affected_packages.name" | "finding_info.analytic.name" | "compliance.standards" | "cloud.account.name" | "vendor_attributes.severity" | "metadata.product.vendor_name" | (string & {});
export interface GroupByRule {
    Filters?: OcsfFindingFilters;
    GroupByField?: GroupByField;
}
export type GroupByRules = GroupByRule[];
export interface AwsOrganizationScope {
    OrganizationId?: string;
    OrganizationalUnitId?: string;
}
export type AwsOrganizationScopeList = AwsOrganizationScope[];
export interface FindingScopes {
    AwsOrganizations?: AwsOrganizationScope[];
}
export type MaxStatisticResults = number;
export interface GetFindingStatisticsV2Request {
    GroupByRules?: GroupByRule[];
    Scopes?: FindingScopes;
    SortOrder?: SortOrder;
    MaxStatisticResults?: number;
}
export interface GroupByValue {
    FieldValue?: string;
    Count?: number;
}
export type GroupByValues = GroupByValue[];
export interface GroupByResult {
    GroupByField?: string;
    GroupByValues?: GroupByValue[];
}
export type GroupByResults = GroupByResult[];
export interface GetFindingStatisticsV2Response {
    GroupByResults?: GroupByResult[];
}
export type FindingsTrendsStringField = "account_id" | "region" | "finding_types" | "finding_status" | "finding_cve_ids" | "finding_compliance_status" | "finding_control_id" | "finding_class_name" | "finding_provider" | "finding_activity_name" | "resource_cloud_providers" | "resource_regions" | "resource_owner_ids" | "resource_owner_organization_ids" | (string & {});
export interface FindingsTrendsStringFilter {
    FieldName?: FindingsTrendsStringField;
    Filter?: StringFilter;
}
export type FindingsTrendsStringFilterList = FindingsTrendsStringFilter[];
export interface FindingsTrendsCompositeFilter {
    StringFilters?: FindingsTrendsStringFilter[];
    NestedCompositeFilters?: FindingsTrendsCompositeFilter[];
    Operator?: AllowedOperators;
}
export type FindingsTrendsCompositeFilterList = FindingsTrendsCompositeFilter[];
export interface FindingsTrendsFilters {
    CompositeFilters?: FindingsTrendsCompositeFilter[];
    CompositeOperator?: AllowedOperators;
}
export interface GetFindingsTrendsV2Request {
    Filters?: FindingsTrendsFilters;
    StartTime?: Date;
    EndTime?: Date;
    NextToken?: string;
    MaxResults?: number;
}
export type GranularityField = "Daily" | "Weekly" | "Monthly" | (string & {});
export type TrendsValueCount = number;
export interface SeverityTrendsCount {
    Unknown?: number;
    Informational?: number;
    Low?: number;
    Medium?: number;
    High?: number;
    Critical?: number;
    Fatal?: number;
    Other?: number;
}
export interface TrendsValues {
    SeverityTrends?: SeverityTrendsCount;
}
export interface TrendsMetricsResult {
    Timestamp?: Date;
    TrendsValues?: TrendsValues;
}
export type TrendsMetrics = TrendsMetricsResult[];
export interface GetFindingsTrendsV2Response {
    Granularity: GranularityField;
    TrendsMetrics: (TrendsMetricsResult & {
        Timestamp: Date;
        TrendsValues: TrendsValues & {
            SeverityTrends: SeverityTrendsCount & {
                Unknown: TrendsValueCount;
                Informational: TrendsValueCount;
                Low: TrendsValueCount;
                Medium: TrendsValueCount;
                High: TrendsValueCount;
                Critical: TrendsValueCount;
                Fatal: TrendsValueCount;
                Other: TrendsValueCount;
            };
        };
    })[];
    NextToken?: string;
}
export interface GetFindingsV2Request {
    Filters?: OcsfFindingFilters;
    Scopes?: FindingScopes;
    SortCriteria?: SortCriterion[];
    NextToken?: string;
    MaxResults?: number;
}
export type OcsfFinding = unknown;
export type OcsfFindingsList = any[];
export interface GetFindingsV2Response {
    Findings?: any[];
    NextToken?: string;
}
export interface GetInsightResultsRequest {
    InsightArn: string;
}
export interface InsightResultValue {
    GroupByAttributeValue?: string;
    Count?: number;
}
export type InsightResultValueList = InsightResultValue[];
export interface InsightResults {
    InsightArn?: string;
    GroupByAttribute?: string;
    ResultValues?: InsightResultValue[];
}
export interface GetInsightResultsResponse {
    InsightResults: InsightResults & {
        InsightArn: NonEmptyString;
        GroupByAttribute: NonEmptyString;
        ResultValues: (InsightResultValue & {
            GroupByAttributeValue: NonEmptyString;
            Count: number;
        })[];
    };
}
export interface GetInsightsRequest {
    InsightArns?: string[];
    NextToken?: string;
    MaxResults?: number;
}
export interface Insight {
    InsightArn?: string;
    Name?: string;
    Filters?: AwsSecurityFindingFilters;
    GroupByAttribute?: string;
}
export type InsightList = Insight[];
export interface GetInsightsResponse {
    Insights: (Insight & {
        InsightArn: NonEmptyString;
        Name: NonEmptyString;
        Filters: AwsSecurityFindingFilters;
        GroupByAttribute: NonEmptyString;
    })[];
    NextToken?: string;
}
export interface GetInvitationsCountRequest {
}
export interface GetInvitationsCountResponse {
    InvitationsCount?: number;
}
export interface GetMasterAccountRequest {
}
export interface GetMasterAccountResponse {
    Master?: Invitation;
}
export interface GetMembersRequest {
    AccountIds?: string[];
}
export interface Member {
    AccountId?: string;
    Email?: string;
    MasterId?: string;
    AdministratorId?: string;
    MemberStatus?: string;
    InvitedAt?: Date;
    UpdatedAt?: Date;
}
export type MemberList = Member[];
export interface GetMembersResponse {
    Members?: Member[];
    UnprocessedAccounts?: Result[];
}
export interface GetRecommendedPolicyV2Request {
    MetadataUid: string;
    NextToken?: string;
    MaxResults?: number;
}
export type RecommendationType = "UNUSED_PERMISSION_RECOMMENDATION" | (string & {});
export interface UnusedPermissionsRecommendationStep {
    RecommendedAction?: string;
    ExistingPolicy?: string;
    ExistingPolicyId?: string;
    PolicyUpdatedAt?: Date;
    RecommendedPolicy?: string;
}
export type RecommendationStep = {
    UnusedPermissions: UnusedPermissionsRecommendationStep;
};
export type RecommendationSteps = RecommendationStep[];
export interface RecommendationError {
    Code?: string;
    Message?: string;
}
export type RecommendationStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export interface GetRecommendedPolicyV2Response {
    NextToken?: string;
    RecommendationType?: RecommendationType;
    RecommendationSteps?: RecommendationStep[];
    Error?: RecommendationError;
    Status?: RecommendationStatus;
    ResourceArn?: string;
}
export type RemediationStringUid = string;
export type RemediationStringField = "Resource.Type" | "Priority" | "Status" | "Resource.Id" | "Resource.ResourceOwnerAccountId" | "Resource.CloudProvider" | (string & {});
export interface RemediationStringFilterCondition {
    Value?: string;
}
export interface RemediationStringFilter {
    FieldName?: RemediationStringField;
    Filter?: RemediationStringFilterCondition;
}
export type RemediationStringFilterList = RemediationStringFilter[];
export interface RemediationCompositeFilter {
    StringFilters?: RemediationStringFilter[];
}
export type RemediationCompositeFilterList = RemediationCompositeFilter[];
export interface RemediationFilters {
    CompositeFilters?: RemediationCompositeFilter[];
}
export type GuidanceFormat = "All" | "AwsCli" | "Cli" | "Python" | "Terraform" | "Cdk" | "CloudFormation" | "IaC" | "Template" | (string & {});
export interface GetRemediationsV2Request {
    TargetUid?: string;
    MetadataUid?: string;
    Filters?: RemediationFilters;
    ShowGuidance?: boolean;
    GuidanceFormat?: GuidanceFormat;
    MaxResults?: number;
    NextToken?: string;
}
export interface RemediationOutcome {
    ResolvedFindingsCount?: number;
    SeverityReductionFindingsCount?: number;
    SeverityUnchangedCount?: number;
}
export type RemediationPriority = "Critical" | "High" | "Medium" | "Low" | (string & {});
export type RemediationStringList = string[];
export interface KbArticle {
    Title?: string;
    Url?: string;
}
export type KbArticleList = KbArticle[];
export interface RemediationSummaryDetail {
    Action?: string;
    Description?: string;
    IsImmediate?: boolean;
    PostRemediationSteps?: string[];
    KbArticles?: KbArticle[];
}
export interface RemediationResource {
    AccountId?: string;
    Region?: string;
    ResourceOwnerAccountId?: string;
    ResourceOwnerOrgId?: string;
    Type?: string;
    Name?: string;
    Id?: string;
    ResourceGuid?: string;
    ResourceRegion?: string;
    CloudProvider?: CloudProviderName;
}
export type RemediationStatus = "New" | "Updated" | "Resolved" | (string & {});
export interface RemediationTrait {
    Type?: string;
    Title?: string;
}
export interface RemediationGuidanceContext {
    ProblemStatement?: string;
    RiskAssessment?: string;
    AffectedScope?: string;
    Prerequisites?: string[];
}
export interface RemediationParameter {
    Name?: string;
    Type?: string;
    Description?: string;
    Required?: boolean;
}
export type RemediationParameterList = RemediationParameter[];
export interface RemediationStep {
    Phase?: string;
    Description?: string;
    Service?: string;
    Action?: string;
    Logic?: string;
    Inverse?: string;
    VerifyAfter?: string;
}
export type RemediationStepList = RemediationStep[];
export interface RemediationGuidanceSpecification {
    Parameters?: RemediationParameter[];
    Steps?: RemediationStep[];
    ExpectedEndState?: string;
    RequiredPermissions?: string[];
}
export interface RemediationGuidanceExamples {
    AwsCli?: string;
    Cli?: string;
    Python?: string;
    Terraform?: string;
    Cdk?: string;
    CloudFormation?: string;
    IaC?: string;
    Template?: string;
}
export interface RemediationGuidanceMetadata {
    ResourceType?: string;
    ExposureType?: string;
    TraitTitles?: string[];
    Reversibility?: string;
    FixEffect?: string;
    RiskLevel?: string;
    AutomationLevel?: string;
    HumanReviewRequired?: boolean;
    GeneratedAt?: Date;
    VerificationStatus?: string;
}
export interface RemediationGuidance {
    TargetTypeName?: string;
    Pattern?: string;
    Version?: string;
    Context?: RemediationGuidanceContext;
    Specification?: RemediationGuidanceSpecification;
    Examples?: RemediationGuidanceExamples;
    Metadata?: RemediationGuidanceMetadata;
}
export interface RemediationV2Item {
    TargetUid?: string;
    Outcome?: RemediationOutcome;
    Priority?: RemediationPriority;
    RemediationSummary?: RemediationSummaryDetail;
    Resource?: RemediationResource;
    Status?: RemediationStatus;
    Trait?: RemediationTrait;
    Guidance?: RemediationGuidance;
    UpdatedAt?: Date;
}
export type RemediationV2ItemList = RemediationV2Item[];
export interface GetRemediationsV2Response {
    Items: (RemediationV2Item & {
        TargetUid: NonEmptyString;
        Outcome: RemediationOutcome & {
            ResolvedFindingsCount: number;
            SeverityReductionFindingsCount: number;
            SeverityUnchangedCount: number;
        };
        Priority: RemediationPriority;
        RemediationSummary: RemediationSummaryDetail & {
            Action: NonEmptyString;
            IsImmediate: boolean;
            KbArticles: (KbArticle & {
                Title: NonEmptyString;
                Url: NonEmptyString;
            })[];
        };
        Resource: RemediationResource & {
            AccountId: NonEmptyString;
            Region: NonEmptyString;
            Type: NonEmptyString;
            Id: NonEmptyString;
            ResourceRegion: NonEmptyString;
            CloudProvider: CloudProviderName;
        };
        Status: RemediationStatus;
        Trait: RemediationTrait & {
            Type: NonEmptyString;
            Title: NonEmptyString;
        };
        Guidance: RemediationGuidance & {
            TargetTypeName: NonEmptyString;
            Pattern: NonEmptyString;
            Version: NonEmptyString;
            Context: RemediationGuidanceContext;
            Specification: RemediationGuidanceSpecification & {
                Parameters: (RemediationParameter & {
                    Name: NonEmptyString;
                    Type: NonEmptyString;
                    Description: NonEmptyString;
                })[];
                Steps: (RemediationStep & {
                    Phase: NonEmptyString;
                    Description: NonEmptyString;
                    Service: NonEmptyString;
                    Action: NonEmptyString;
                })[];
            };
            Examples: RemediationGuidanceExamples;
            Metadata: RemediationGuidanceMetadata & {
                ResourceType: NonEmptyString;
                ExposureType: NonEmptyString;
                TraitTitles: RemediationStringList;
                Reversibility: NonEmptyString;
                FixEffect: NonEmptyString;
                RiskLevel: NonEmptyString;
            };
        };
    })[];
    NextToken?: string;
}
export type ResourceGroupByField = "AccountId" | "AccountName" | "Region" | "ResourceProvider" | "ResourceOwnerAccountId" | "ResourceOwnerOrgId" | "ResourceCloudPartition" | "ResourceRegion" | "ResourceCategory" | "ResourceType" | "ResourceName" | "FindingsSummary.FindingType" | "ResourceSubCategory" | "DiscoveryType" | "ResourceInfo.AIDetails.HostResourceType" | "ResourceInfo.AIDetails.CanonicalId" | (string & {});
export type ResourcesStringField = "ResourceGuid" | "ResourceId" | "AccountId" | "AccountName" | "Region" | "ResourceProvider" | "ResourceOwnerAccountId" | "ResourceOwnerOrgId" | "ResourceCloudPartition" | "ResourceRegion" | "ResourceCategory" | "ResourceType" | "ResourceName" | "FindingsSummary.FindingType" | "FindingsSummary.ProductName" | "ResourceSubCategory" | "DiscoveryType" | "ResourceInfo.AIDetails.HostResourceGuid" | "ResourceInfo.AIDetails.HostResourceType" | "ResourceInfo.AIDetails.CanonicalId" | (string & {});
export interface ResourcesStringFilter {
    FieldName?: ResourcesStringField;
    Filter?: StringFilter;
}
export type ResourcesStringFilterList = ResourcesStringFilter[];
export type ResourcesDateField = "ResourceDetailCaptureTime" | "ResourceCreationTime" | (string & {});
export interface ResourcesDateFilter {
    FieldName?: ResourcesDateField;
    Filter?: DateFilter;
}
export type ResourcesDateFilterList = ResourcesDateFilter[];
export type ResourcesNumberField = "FindingsSummary.TotalFindings" | "FindingsSummary.Severities.Other" | "FindingsSummary.Severities.Fatal" | "FindingsSummary.Severities.Critical" | "FindingsSummary.Severities.High" | "FindingsSummary.Severities.Medium" | "FindingsSummary.Severities.Low" | "FindingsSummary.Severities.Informational" | "FindingsSummary.Severities.Unknown" | "ResourceInfo.AIDetails.SelfHostedAIModelResourceCount" | "ResourceInfo.AIDetails.SelfHostedAIAgentResourceCount" | "ResourceInfo.AIDetails.SelfHostedAIModelServingResourceCount" | "ResourceInfo.AIDetails.SelfHostedAIExternalEndpointResourceCount" | "ResourceInfo.AIDetails.SelfHostedAIDevelopmentResourceCount" | "ResourceInfo.AIDetails.SelfHostedAIAgentFrameworkResourceCount" | "ResourceInfo.AIDetails.SelfHostedAIAgentToolsAndIdentityResourceCount" | "ResourceInfo.AIDetails.SelfHostedTotalAIResourceCount" | (string & {});
export interface ResourcesNumberFilter {
    FieldName?: ResourcesNumberField;
    Filter?: NumberFilter;
}
export type ResourcesNumberFilterList = ResourcesNumberFilter[];
export type ResourcesMapField = "ResourceTags" | (string & {});
export interface ResourcesMapFilter {
    FieldName?: ResourcesMapField;
    Filter?: MapFilter;
}
export type ResourcesMapFilterList = ResourcesMapFilter[];
export interface ResourcesCompositeFilter {
    StringFilters?: ResourcesStringFilter[];
    DateFilters?: ResourcesDateFilter[];
    NumberFilters?: ResourcesNumberFilter[];
    MapFilters?: ResourcesMapFilter[];
    NestedCompositeFilters?: ResourcesCompositeFilter[];
    Operator?: AllowedOperators;
}
export type ResourcesCompositeFilterList = ResourcesCompositeFilter[];
export interface ResourcesFilters {
    CompositeFilters?: ResourcesCompositeFilter[];
    CompositeOperator?: AllowedOperators;
}
export interface ResourceGroupByRule {
    GroupByField?: ResourceGroupByField;
    Filters?: ResourcesFilters;
}
export type ResourceGroupByRules = ResourceGroupByRule[];
export interface ResourceScopes {
    AwsOrganizations?: AwsOrganizationScope[];
}
export interface GetResourcesStatisticsV2Request {
    GroupByRules?: ResourceGroupByRule[];
    Scopes?: ResourceScopes;
    SortOrder?: SortOrder;
    MaxStatisticResults?: number;
}
export interface GetResourcesStatisticsV2Response {
    GroupByResults: GroupByResult[];
}
export type ResourcesTrendsStringField = "account_id" | "region" | "resource_type" | "resource_category" | "resource_cloud_provider" | "resource_region" | "resource_owner_id" | "resource_owner_organization_id" | (string & {});
export interface ResourcesTrendsStringFilter {
    FieldName?: ResourcesTrendsStringField;
    Filter?: StringFilter;
}
export type ResourcesTrendsStringFilterList = ResourcesTrendsStringFilter[];
export interface ResourcesTrendsCompositeFilter {
    StringFilters?: ResourcesTrendsStringFilter[];
    NestedCompositeFilters?: ResourcesTrendsCompositeFilter[];
    Operator?: AllowedOperators;
}
export type ResourcesTrendsCompositeFilterList = ResourcesTrendsCompositeFilter[];
export interface ResourcesTrendsFilters {
    CompositeFilters?: ResourcesTrendsCompositeFilter[];
    CompositeOperator?: AllowedOperators;
}
export interface GetResourcesTrendsV2Request {
    Filters?: ResourcesTrendsFilters;
    StartTime?: Date;
    EndTime?: Date;
    NextToken?: string;
    MaxResults?: number;
}
export interface ResourcesCount {
    AllResources?: number;
}
export interface ResourcesTrendsValues {
    ResourcesCount?: ResourcesCount;
}
export interface ResourcesTrendsMetricsResult {
    Timestamp?: Date;
    TrendsValues?: ResourcesTrendsValues;
}
export type ResourcesTrendsMetrics = ResourcesTrendsMetricsResult[];
export interface GetResourcesTrendsV2Response {
    Granularity: GranularityField;
    TrendsMetrics: (ResourcesTrendsMetricsResult & {
        Timestamp: Date;
        TrendsValues: ResourcesTrendsValues & {
            ResourcesCount: ResourcesCount & {
                AllResources: TrendsValueCount;
            };
        };
    })[];
    NextToken?: string;
}
export interface GetResourcesV2Request {
    Filters?: ResourcesFilters;
    Scopes?: ResourceScopes;
    SortCriteria?: SortCriterion[];
    NextToken?: string;
    MaxResults?: number;
}
export type ResourceCategory = "Compute" | "Database" | "Storage" | "Code" | "AI/ML" | "Identity" | "Network" | "Messaging" | "Other" | (string & {});
export interface ResourceSeverityBreakdown {
    Other?: number;
    Fatal?: number;
    Critical?: number;
    High?: number;
    Medium?: number;
    Low?: number;
    Informational?: number;
    Unknown?: number;
}
export interface ResourceFindingsSummary {
    FindingType?: string;
    ProductName?: string;
    TotalFindings?: number;
    Severities?: ResourceSeverityBreakdown;
}
export type ResourceFindingsSummaryList = ResourceFindingsSummary[];
export interface ResourceTag {
    Key?: string;
    Value?: string;
}
export type ResourceTagList = ResourceTag[];
export type ResourceConfig = unknown;
export type ResourceSubCategory = "Model" | "ModelServing" | "Agent" | "AgentFramework" | "AgentToolsAndIdentity" | "SafetyAndGuardrail" | "KnowledgeAndData" | "OrchestrationAndPipeline" | "ExternalEndpoint" | "Development" | "Other" | (string & {});
export type DiscoveryType = "Managed" | "SelfHosted" | (string & {});
export interface AIDetails {
    HostResourceGuid?: string;
    HostResourceType?: string;
    CanonicalId?: string;
    SelfHostedAIModelResourceCount?: number;
    SelfHostedAIAgentResourceCount?: number;
    SelfHostedAIModelServingResourceCount?: number;
    SelfHostedAIExternalEndpointResourceCount?: number;
    SelfHostedAIDevelopmentResourceCount?: number;
    SelfHostedAIAgentFrameworkResourceCount?: number;
    SelfHostedAIAgentToolsAndIdentityResourceCount?: number;
    SelfHostedTotalAIResourceCount?: number;
}
export interface ResourceInfo {
    AIDetails?: AIDetails;
}
export interface ResourceResult {
    ResourceGuid?: string;
    ResourceId?: string;
    AccountId?: string;
    AccountName?: string;
    Region?: string;
    ResourceProvider?: string;
    ResourceOwnerAccountId?: string;
    ResourceOwnerOrgId?: string;
    ResourceCloudPartition?: string;
    ResourceRegion?: string;
    ResourceCategory?: ResourceCategory;
    ResourceType?: string;
    ResourceName?: string;
    ResourceCreationTimeDt?: string;
    ResourceDetailCaptureTimeDt?: string;
    FindingsSummary?: ResourceFindingsSummary[];
    ResourceTags?: ResourceTag[];
    ResourceConfig?: any;
    ResourceSubCategory?: ResourceSubCategory;
    DiscoveryType?: DiscoveryType;
    ResourceInfo?: ResourceInfo;
}
export type Resources = ResourceResult[];
export interface GetResourcesV2Response {
    Resources: (ResourceResult & {
        ResourceId: NonEmptyString;
        AccountId: NonEmptyString;
        Region: NonEmptyString;
        ResourceType: NonEmptyString;
        ResourceDetailCaptureTimeDt: NonEmptyString;
        ResourceConfig: ResourceConfig;
        FindingsSummary: (ResourceFindingsSummary & {
            FindingType: NonEmptyString;
            ProductName: NonEmptyString;
            TotalFindings: number;
        })[];
        ResourceTags: (ResourceTag & {
            Key: NonEmptyString;
            Value: NonEmptyString;
        })[];
    })[];
    NextToken?: string;
}
export interface GetSecurityControlDefinitionRequest {
    SecurityControlId?: string;
}
export type RegionAvailabilityStatus = "AVAILABLE" | "UNAVAILABLE" | (string & {});
export type SecurityControlProperty = "Parameters" | (string & {});
export type CustomizableProperties = SecurityControlProperty[];
export interface IntegerConfigurationOptions {
    DefaultValue?: number;
    Min?: number;
    Max?: number;
}
export interface IntegerListConfigurationOptions {
    DefaultValue?: number[];
    Min?: number;
    Max?: number;
    MaxItems?: number;
}
export interface DoubleConfigurationOptions {
    DefaultValue?: number;
    Min?: number;
    Max?: number;
}
export interface StringConfigurationOptions {
    DefaultValue?: string;
    Re2Expression?: string;
    ExpressionDescription?: string;
}
export interface StringListConfigurationOptions {
    DefaultValue?: string[];
    Re2Expression?: string;
    MaxItems?: number;
    ExpressionDescription?: string;
}
export interface BooleanConfigurationOptions {
    DefaultValue?: boolean;
}
export interface EnumConfigurationOptions {
    DefaultValue?: string;
    AllowedValues?: string[];
}
export interface EnumListConfigurationOptions {
    DefaultValue?: string[];
    MaxItems?: number;
    AllowedValues?: string[];
}
export type ConfigurationOptions = {
    Integer: IntegerConfigurationOptions;
    IntegerList?: never;
    Double?: never;
    String?: never;
    StringList?: never;
    Boolean?: never;
    Enum?: never;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList: IntegerListConfigurationOptions;
    Double?: never;
    String?: never;
    StringList?: never;
    Boolean?: never;
    Enum?: never;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList?: never;
    Double: DoubleConfigurationOptions;
    String?: never;
    StringList?: never;
    Boolean?: never;
    Enum?: never;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList?: never;
    Double?: never;
    String: StringConfigurationOptions;
    StringList?: never;
    Boolean?: never;
    Enum?: never;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList?: never;
    Double?: never;
    String?: never;
    StringList: StringListConfigurationOptions;
    Boolean?: never;
    Enum?: never;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList?: never;
    Double?: never;
    String?: never;
    StringList?: never;
    Boolean: BooleanConfigurationOptions;
    Enum?: never;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList?: never;
    Double?: never;
    String?: never;
    StringList?: never;
    Boolean?: never;
    Enum: EnumConfigurationOptions;
    EnumList?: never;
} | {
    Integer?: never;
    IntegerList?: never;
    Double?: never;
    String?: never;
    StringList?: never;
    Boolean?: never;
    Enum?: never;
    EnumList: EnumListConfigurationOptions;
};
export interface ParameterDefinition {
    Description?: string;
    ConfigurationOptions?: ConfigurationOptions;
}
export type ParameterDefinitions = {
    [key: string]: ParameterDefinition | undefined;
};
export interface SecurityControlDefinition {
    SecurityControlId?: string;
    Title?: string;
    Description?: string;
    RemediationUrl?: string;
    SeverityRating?: SeverityRating;
    CurrentRegionAvailability?: RegionAvailabilityStatus;
    CustomizableProperties?: SecurityControlProperty[];
    ParameterDefinitions?: {
        [key: string]: ParameterDefinition | undefined;
    };
    Provider?: SecurityControlsProvider;
}
export interface GetSecurityControlDefinitionResponse {
    SecurityControlDefinition: SecurityControlDefinition & {
        SecurityControlId: NonEmptyString;
        Title: NonEmptyString;
        Description: NonEmptyString;
        RemediationUrl: NonEmptyString;
        SeverityRating: SeverityRating;
        CurrentRegionAvailability: RegionAvailabilityStatus;
        ParameterDefinitions: {
            [key: string]: (ParameterDefinition & {
                Description: NonEmptyString;
                ConfigurationOptions: ConfigurationOptions;
            }) | undefined;
        };
    };
}
export interface InviteMembersRequest {
    AccountIds?: string[];
}
export interface InviteMembersResponse {
    UnprocessedAccounts?: Result[];
}
export interface ListAggregatorsV2Request {
    NextToken?: string;
    MaxResults?: number;
}
export interface AggregatorV2 {
    AggregatorV2Arn?: string;
}
export type AggregatorV2List = AggregatorV2[];
export interface ListAggregatorsV2Response {
    AggregatorsV2?: AggregatorV2[];
    NextToken?: string;
}
export interface ListAutomationRulesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface AutomationRulesMetadata {
    RuleArn?: string;
    RuleStatus?: RuleStatus;
    RuleOrder?: number;
    RuleName?: string;
    Description?: string;
    IsTerminal?: boolean;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    CreatedBy?: string;
}
export type AutomationRulesMetadataList = AutomationRulesMetadata[];
export interface ListAutomationRulesResponse {
    AutomationRulesMetadata?: AutomationRulesMetadata[];
    NextToken?: string;
}
export interface ListAutomationRulesV2Request {
    NextToken?: string;
    MaxResults?: number;
}
export interface AutomationRulesActionTypeObjectV2 {
    Type?: AutomationRulesActionTypeV2;
}
export type AutomationRulesActionTypeListV2 = AutomationRulesActionTypeObjectV2[];
export interface AutomationRulesMetadataV2 {
    RuleArn?: string;
    RuleId?: string;
    RuleOrder?: number;
    RuleName?: string;
    RuleStatus?: RuleStatusV2;
    Description?: string;
    Actions?: AutomationRulesActionTypeObjectV2[];
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type AutomationRulesMetadataListV2 = AutomationRulesMetadataV2[];
export interface ListAutomationRulesV2Response {
    Rules?: AutomationRulesMetadataV2[];
    NextToken?: string;
}
export interface ListConfigurationPoliciesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface ConfigurationPolicySummary {
    Arn?: string;
    Id?: string;
    Name?: string;
    Description?: string;
    UpdatedAt?: Date;
    ServiceEnabled?: boolean;
}
export type ConfigurationPolicySummaryList = ConfigurationPolicySummary[];
export interface ListConfigurationPoliciesResponse {
    ConfigurationPolicySummaries?: ConfigurationPolicySummary[];
    NextToken?: string;
}
export interface AssociationFilters {
    ConfigurationPolicyId?: string;
    AssociationType?: AssociationType;
    AssociationStatus?: ConfigurationPolicyAssociationStatus;
}
export interface ListConfigurationPolicyAssociationsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: AssociationFilters;
}
export type ConfigurationPolicyAssociationSummaryList = ConfigurationPolicyAssociationSummary[];
export interface ListConfigurationPolicyAssociationsResponse {
    ConfigurationPolicyAssociationSummaries?: ConfigurationPolicyAssociationSummary[];
    NextToken?: string;
}
export type CspmConnectorProviderName = "AZURE" | (string & {});
export interface ListConnectorsRequest {
    NextToken?: string;
    MaxResults?: number;
    ProviderName?: CspmConnectorProviderName;
    ConnectorStatus?: CspmConnectorStatus;
    EnablementStatus?: CspmEnablementStatus;
}
export interface CspmProviderSummary {
    ProviderName?: CspmConnectorProviderName;
    ConnectorStatus?: CspmConnectorStatus;
    ProviderConfiguration?: CspmProviderDetail;
}
export interface CspmConnectorSummary {
    ConnectorArn?: string;
    ConnectorId?: string;
    Name?: string;
    Description?: string;
    ProviderSummary?: CspmProviderSummary;
    CreatedAt?: Date;
    CreatedBy?: string;
    EnablementStatus?: CspmEnablementStatus;
}
export type CspmConnectorSummaryList = CspmConnectorSummary[];
export interface ListConnectorsResponse {
    NextToken?: string;
    Connectors: CspmConnectorSummary[];
}
export type ConnectorProviderName = "JIRA_CLOUD" | "SERVICENOW" | "AZURE" | (string & {});
export interface ListConnectorsV2Request {
    NextToken?: string;
    MaxResults?: number;
    ProviderName?: ConnectorProviderName;
    ConnectorStatus?: ConnectorStatus;
    EnablementStatus?: EnablementStatus;
}
export interface ProviderSummary {
    ProviderName?: ConnectorProviderName;
    ConnectorStatus?: ConnectorStatus;
    ProviderConfiguration?: ProviderDetail;
}
export interface ConnectorSummary {
    ConnectorArn?: string;
    ConnectorId?: string;
    Name?: string;
    Description?: string;
    ProviderSummary?: ProviderSummary;
    CreatedAt?: Date;
    EnablementStatus?: EnablementStatus;
    EnablementStatusReason?: string;
}
export type ConnectorSummaryList = ConnectorSummary[];
export interface ListConnectorsV2Response {
    NextToken?: string;
    Connectors: (ConnectorSummary & {
        ConnectorId: NonEmptyString;
        Name: NonEmptyString;
        ProviderSummary: ProviderSummary;
        CreatedAt: Date;
    })[];
}
export interface ListEnabledProductsForImportRequest {
    NextToken?: string;
    MaxResults?: number;
}
export type ProductSubscriptionArnList = string[];
export interface ListEnabledProductsForImportResponse {
    ProductSubscriptions?: string[];
    NextToken?: string;
}
export interface ListExposuresByRemediationV2Request {
    TargetUid?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ExposureSeverity = "Informational" | "Low" | "Medium" | "High" | "Critical" | (string & {});
export type ExposureImpact = "Reduces" | "Resolves" | "Unchanged" | (string & {});
export interface ExposureFinding {
    MetadataUid?: string;
    Title?: string;
    PreviousSeverity?: ExposureSeverity;
    ProjectedSeverity?: ExposureSeverity;
    Impact?: ExposureImpact;
}
export type ExposureFindingItemsList = ExposureFinding[];
export interface ListExposuresByRemediationV2Response {
    Items: (ExposureFinding & {
        MetadataUid: NonEmptyString;
        Title: NonEmptyString;
        PreviousSeverity: ExposureSeverity;
        ProjectedSeverity: ExposureSeverity;
        Impact: ExposureImpact;
    })[];
    TargetUid: string;
    Resource: RemediationResource & {
        AccountId: NonEmptyString;
        Region: NonEmptyString;
        Type: NonEmptyString;
        Id: NonEmptyString;
        ResourceRegion: NonEmptyString;
        CloudProvider: CloudProviderName;
    };
    TotalCount: number;
    Trait: RemediationTrait & {
        Type: NonEmptyString;
        Title: NonEmptyString;
    };
    NextToken?: string;
}
export interface ListFindingAggregatorsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface FindingAggregator {
    FindingAggregatorArn?: string;
}
export type FindingAggregatorList = FindingAggregator[];
export interface ListFindingAggregatorsResponse {
    FindingAggregators?: FindingAggregator[];
    NextToken?: string;
}
export type FreeTrialAccountId = string;
export type FreeTrialAccountIdList = string[];
export type FreeTrialStatusValue = "ACTIVE" | "INACTIVE" | (string & {});
export type FreeTrialStatusValueList = FreeTrialStatusValue[];
export interface ListFreeTrialStatusesV2Request {
    AccountIds?: string[];
    Statuses?: FreeTrialStatusValue[];
    MaxResults?: number;
    NextToken?: string;
}
export type FreeTrialType = "SECURITY_HUB_V2" | "SECURITY_HUB_V2_MULTI_CLOUD_AZURE" | (string & {});
export interface FreeTrialStatus {
    FeatureType?: FreeTrialType;
    Status?: FreeTrialStatusValue;
    StartedAt?: Date;
    ExpiresAt?: Date;
}
export type FreeTrialStatusList = FreeTrialStatus[];
export interface AccountFreeTrialStatus {
    AccountId?: string;
    EvaluatedAt?: Date;
    FreeTrialStatuses?: FreeTrialStatus[];
}
export type AccountFreeTrialStatusList = AccountFreeTrialStatus[];
export interface ListFreeTrialStatusesV2Response {
    AccountFreeTrialStatuses: (AccountFreeTrialStatus & {
        AccountId: FreeTrialAccountId;
        EvaluatedAt: Date;
        FreeTrialStatuses: (FreeTrialStatus & {
            FeatureType: FreeTrialType;
            Status: FreeTrialStatusValue;
            StartedAt: Date;
            ExpiresAt: Date;
        })[];
    })[];
    NextToken?: string;
}
export type CrossAccountMaxResults = number;
export interface ListInvitationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type InvitationList = Invitation[];
export interface ListInvitationsResponse {
    Invitations?: Invitation[];
    NextToken?: string;
}
export interface ListMembersRequest {
    OnlyAssociated?: boolean;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListMembersResponse {
    Members?: Member[];
    NextToken?: string;
}
export type AdminsMaxResults = number;
export interface ListOrganizationAdminAccountsRequest {
    MaxResults?: number;
    NextToken?: string;
    Feature?: SecurityHubFeature;
}
export type AdminStatus = "ENABLED" | "DISABLE_IN_PROGRESS" | (string & {});
export interface AdminAccount {
    AccountId?: string;
    Status?: AdminStatus;
}
export type AdminAccounts = AdminAccount[];
export interface ListOrganizationAdminAccountsResponse {
    AdminAccounts?: AdminAccount[];
    NextToken?: string;
    Feature?: SecurityHubFeature;
}
export type SecurityControlsProviders = SecurityControlsProvider[];
export interface ListSecurityControlDefinitionsRequest {
    StandardsArn?: string;
    NextToken?: string;
    MaxResults?: number;
    Providers?: SecurityControlsProvider[];
}
export type SecurityControlDefinitions = SecurityControlDefinition[];
export interface ListSecurityControlDefinitionsResponse {
    SecurityControlDefinitions: (SecurityControlDefinition & {
        SecurityControlId: NonEmptyString;
        Title: NonEmptyString;
        Description: NonEmptyString;
        RemediationUrl: NonEmptyString;
        SeverityRating: SeverityRating;
        CurrentRegionAvailability: RegionAvailabilityStatus;
        ParameterDefinitions: {
            [key: string]: (ParameterDefinition & {
                Description: NonEmptyString;
                ConfigurationOptions: ConfigurationOptions;
            }) | undefined;
        };
    })[];
    NextToken?: string;
}
export interface ListStandardsControlAssociationsRequest {
    SecurityControlId?: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface StandardsControlAssociationSummary {
    StandardsArn?: string;
    SecurityControlId?: string;
    SecurityControlArn?: string;
    AssociationStatus?: AssociationStatus;
    RelatedRequirements?: string[];
    UpdatedAt?: Date;
    UpdatedReason?: string;
    StandardsControlTitle?: string;
    StandardsControlDescription?: string;
}
export type StandardsControlAssociationSummaries = StandardsControlAssociationSummary[];
export interface ListStandardsControlAssociationsResponse {
    StandardsControlAssociationSummaries: (StandardsControlAssociationSummary & {
        StandardsArn: NonEmptyString;
        SecurityControlId: NonEmptyString;
        SecurityControlArn: NonEmptyString;
        AssociationStatus: AssociationStatus;
    })[];
    NextToken?: string;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface RegisterConnectorV2Request {
    AuthCode?: string;
    AuthState?: string;
}
export interface RegisterConnectorV2Response {
    ConnectorArn?: string;
    ConnectorId: string;
}
export interface StartConfigurationPolicyAssociationRequest {
    ConfigurationPolicyIdentifier?: string;
    Target?: Target;
}
export interface StartConfigurationPolicyAssociationResponse {
    ConfigurationPolicyId?: string;
    TargetId?: string;
    TargetType?: TargetType;
    AssociationType?: AssociationType;
    UpdatedAt?: Date;
    AssociationStatus?: ConfigurationPolicyAssociationStatus;
    AssociationStatusMessage?: string;
}
export interface StartConfigurationPolicyDisassociationRequest {
    Target?: Target;
    ConfigurationPolicyIdentifier?: string;
}
export interface StartConfigurationPolicyDisassociationResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateActionTargetRequest {
    ActionTargetArn: string;
    Name?: string;
    Description?: string;
}
export interface UpdateActionTargetResponse {
}
export interface UpdateAggregatorV2Request {
    AggregatorV2Arn: string;
    RegionLinkingMode?: string;
    LinkedRegions?: string[];
}
export interface UpdateAggregatorV2Response {
    AggregatorV2Arn?: string;
    AggregationRegion?: string;
    RegionLinkingMode?: string;
    LinkedRegions?: string[];
}
export interface UpdateAutomationRuleV2Request {
    Identifier: string;
    RuleStatus?: RuleStatusV2;
    RuleOrder?: number;
    Description?: string;
    RuleName?: string;
    Criteria?: Criteria;
    Actions?: AutomationRulesActionV2[];
}
export interface UpdateAutomationRuleV2Response {
}
export interface UpdateConfigurationPolicyRequest {
    Identifier: string;
    Name?: string;
    Description?: string;
    UpdatedReason?: string;
    ConfigurationPolicy?: Policy;
}
export interface UpdateConfigurationPolicyResponse {
    Arn?: string;
    Id?: string;
    Name?: string;
    Description?: string;
    UpdatedAt?: Date;
    CreatedAt?: Date;
    ConfigurationPolicy?: Policy;
}
export interface AzureUpdateConfiguration {
    ScopeConfiguration?: AzureScopeConfiguration;
    AzureRegions?: string[];
}
export type CspmProviderUpdateConfiguration = {
    Azure: AzureUpdateConfiguration;
};
export interface UpdateConnectorRequest {
    ConnectorId: string;
    Description?: string;
    Provider?: CspmProviderUpdateConfiguration;
}
export interface UpdateConnectorResponse {
    ConnectorStatus?: CspmConnectorStatus;
    EnablementStatus?: CspmEnablementStatus;
}
export interface JiraCloudUpdateConfiguration {
    ProjectKey?: string;
}
export interface ServiceNowUpdateConfiguration {
    SecretArn?: string;
}
export type ProviderUpdateConfiguration = {
    JiraCloud: JiraCloudUpdateConfiguration;
    ServiceNow?: never;
    Azure?: never;
} | {
    JiraCloud?: never;
    ServiceNow: ServiceNowUpdateConfiguration;
    Azure?: never;
} | {
    JiraCloud?: never;
    ServiceNow?: never;
    Azure: AzureUpdateConfiguration;
};
export interface UpdateConnectorV2Request {
    ConnectorId: string;
    Description?: string;
    Provider?: ProviderUpdateConfiguration;
}
export interface UpdateConnectorV2Response {
    ConnectorStatus?: ConnectorStatus;
    EnablementStatus?: EnablementStatus;
}
export interface UpdateFindingAggregatorRequest {
    FindingAggregatorArn?: string;
    RegionLinkingMode?: string;
    Regions?: string[];
}
export interface UpdateFindingAggregatorResponse {
    FindingAggregatorArn?: string;
    FindingAggregationRegion?: string;
    RegionLinkingMode?: string;
    Regions?: string[];
}
export interface UpdateFindingsRequest {
    Filters?: AwsSecurityFindingFilters;
    Note?: NoteUpdate;
    RecordState?: RecordState;
}
export interface UpdateFindingsResponse {
}
export interface UpdateInsightRequest {
    InsightArn: string;
    Name?: string;
    Filters?: AwsSecurityFindingFilters;
    GroupByAttribute?: string;
}
export interface UpdateInsightResponse {
}
export interface UpdateOrganizationConfigurationRequest {
    AutoEnable?: boolean;
    AutoEnableStandards?: AutoEnableStandards;
    OrganizationConfiguration?: OrganizationConfiguration;
}
export interface UpdateOrganizationConfigurationResponse {
}
export interface UpdateSecurityControlRequest {
    SecurityControlId?: string;
    Parameters?: {
        [key: string]: ParameterConfiguration | undefined;
    };
    LastUpdateReason?: string;
}
export interface UpdateSecurityControlResponse {
}
export interface UpdateSecurityHubConfigurationRequest {
    AutoEnableControls?: boolean;
    ControlFindingGenerator?: ControlFindingGenerator;
}
export interface UpdateSecurityHubConfigurationResponse {
}
export interface UpdateStandardsControlRequest {
    StandardsControlArn: string;
    ControlStatus?: ControlStatus;
    DisabledReason?: string;
}
export interface UpdateStandardsControlResponse {
}
export type AcceptAdministratorInvitationError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * We recommend using Organizations instead of Security Hub CSPM invitations to manage your member accounts.
 * For information, see Managing Security Hub CSPM administrator and member accounts with Organizations
 * in the *Security Hub CSPM User Guide*.
 *
 * Accepts the invitation to be a member account and be monitored by the Security Hub CSPM administrator
 * account that the invitation was sent from.
 *
 * This operation is only used by member accounts that are not added through
 * Organizations.
 *
 * When the member account accepts the invitation, permission is granted to the administrator
 * account to view findings generated in the member account.
 */
export declare const acceptAdministratorInvitation: API.OperationMethod<AcceptAdministratorInvitationRequest, AcceptAdministratorInvitationResponse, AcceptAdministratorInvitationError, Credentials | HttpClient.HttpClient>;
export type AcceptInvitationError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * This method is deprecated. Instead, use `AcceptAdministratorInvitation`.
 *
 * The Security Hub CSPM console continues to use `AcceptInvitation`. It will eventually change to use `AcceptAdministratorInvitation`. Any IAM policies that specifically control access to this function must continue to use `AcceptInvitation`. You should also add `AcceptAdministratorInvitation` to your policies to ensure that the correct permissions are in place after the console begins to use `AcceptAdministratorInvitation`.
 *
 * Accepts the invitation to be a member account and be monitored by the Security Hub CSPM administrator
 * account that the invitation was sent from.
 *
 * This operation is only used by member accounts that are not added through
 * Organizations.
 *
 * When the member account accepts the invitation, permission is granted to the administrator
 * account to view findings generated in the member account.
 */
export declare const acceptInvitation: API.OperationMethod<AcceptInvitationRequest, AcceptInvitationResponse, AcceptInvitationError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteAutomationRulesError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes one or more automation rules.
 */
export declare const batchDeleteAutomationRules: API.OperationMethod<BatchDeleteAutomationRulesRequest, BatchDeleteAutomationRulesResponse, BatchDeleteAutomationRulesError, Credentials | HttpClient.HttpClient>;
export type BatchDisableStandardsError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Disables the standards specified by the provided
 * `StandardsSubscriptionArns`.
 *
 * For more information, see Security Standards section of the Security Hub CSPM User
 * Guide.
 */
export declare const batchDisableStandards: API.OperationMethod<BatchDisableStandardsRequest, BatchDisableStandardsResponse, BatchDisableStandardsError, Credentials | HttpClient.HttpClient>;
export type BatchEnableStandardsError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Enables the standards specified by the provided `StandardsArn`. To obtain the
 * ARN for a standard, use the `DescribeStandards`
 * operation.
 *
 * For more information, see the Security Standards
 * section of the *Security Hub CSPM User Guide*.
 */
export declare const batchEnableStandards: API.OperationMethod<BatchEnableStandardsRequest, BatchEnableStandardsResponse, BatchEnableStandardsError, Credentials | HttpClient.HttpClient>;
export type BatchGetAutomationRulesError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list of details for automation rules based on rule Amazon Resource Names
 * (ARNs).
 */
export declare const batchGetAutomationRules: API.OperationMethod<BatchGetAutomationRulesRequest, BatchGetAutomationRulesResponse, BatchGetAutomationRulesError, Credentials | HttpClient.HttpClient>;
export type BatchGetConfigurationPolicyAssociationsError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns associations between an Security Hub CSPM configuration and a batch of target accounts, organizational units, or the root.
 * Only the Security Hub CSPM delegated administrator can invoke this operation from the home Region. A configuration
 * can refer to a configuration policy or to a self-managed configuration.
 */
export declare const batchGetConfigurationPolicyAssociations: API.OperationMethod<BatchGetConfigurationPolicyAssociationsRequest, BatchGetConfigurationPolicyAssociationsResponse, BatchGetConfigurationPolicyAssociationsError, Credentials | HttpClient.HttpClient>;
export type BatchGetSecurityControlsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Provides details about a batch of security controls for the current Amazon Web Services account and Amazon Web Services Region.
 */
export declare const batchGetSecurityControls: API.OperationMethod<BatchGetSecurityControlsRequest, BatchGetSecurityControlsResponse, BatchGetSecurityControlsError, Credentials | HttpClient.HttpClient>;
export type BatchGetStandardsControlAssociationsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * For a batch of security controls and standards, identifies whether each control is currently enabled or disabled in a standard.
 *
 * Calls to this operation return a `RESOURCE_NOT_FOUND_EXCEPTION` error when the standard subscription for the association has a `NOT_READY_FOR_UPDATES` value for `StandardsControlsUpdatable`.
 */
export declare const batchGetStandardsControlAssociations: API.OperationMethod<BatchGetStandardsControlAssociationsRequest, BatchGetStandardsControlAssociationsResponse, BatchGetStandardsControlAssociationsError, Credentials | HttpClient.HttpClient>;
export type BatchImportFindingsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Imports security findings generated by a finding provider into Security Hub CSPM.
 * This action is requested by the finding provider to import its findings into
 * Security Hub CSPM.
 *
 * `BatchImportFindings` must be called by one of the following:
 *
 * - The Amazon Web Services account that is associated with a finding if you are using
 * the default product ARN
 * or are a partner sending findings from within a customer's Amazon Web Services account.
 * In these cases, the identifier of the account that you are calling `BatchImportFindings`
 * from needs to be the same as the `AwsAccountId` attribute for the finding.
 *
 * - An Amazon Web Services account that Security Hub CSPM has allow-listed for an official partner
 * integration. In this case, you can call `BatchImportFindings` from the allow-listed
 * account and send findings from different customer accounts in the same batch.
 *
 * The maximum allowed size for a finding is 240 Kb. An error is returned for any finding
 * larger than 240 Kb.
 *
 * After a finding is created, `BatchImportFindings` cannot be used to update
 * the following finding fields and objects, which Security Hub CSPM customers use to manage their
 * investigation workflow.
 *
 * - `Note`
 *
 * - `UserDefinedFields`
 *
 * - `VerificationState`
 *
 * - `Workflow`
 *
 * Finding providers also should not use `BatchImportFindings` to update the following attributes.
 *
 * - `Confidence`
 *
 * - `Criticality`
 *
 * - `RelatedFindings`
 *
 * - `Severity`
 *
 * - `Types`
 *
 * Instead, finding providers use `FindingProviderFields` to provide values for these attributes.
 */
export declare const batchImportFindings: API.OperationMethod<BatchImportFindingsRequest, BatchImportFindingsResponse, BatchImportFindingsError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateAutomationRulesError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates one or more automation rules based on rule Amazon Resource Names (ARNs)
 * and input parameters.
 */
export declare const batchUpdateAutomationRules: API.OperationMethod<BatchUpdateAutomationRulesRequest, BatchUpdateAutomationRulesResponse, BatchUpdateAutomationRulesError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateFindingsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Used by Security Hub CSPM customers to update information about their investigation into one or more findings.
 * Requested by administrator accounts or member accounts.
 * Administrator accounts can update findings for their account and their member accounts.
 * A member account can update findings only for their own account.
 * Administrator and member accounts can use this operation to update the following fields and objects for one or more findings:
 *
 * - `Confidence`
 *
 * - `Criticality`
 *
 * - `Note`
 *
 * - `RelatedFindings`
 *
 * - `Severity`
 *
 * - `Types`
 *
 * - `UserDefinedFields`
 *
 * - `VerificationState`
 *
 * - `Workflow`
 *
 * If you use this operation to update a finding, your updates don't affect the value for the `UpdatedAt` field of the finding.
 * Also note that it can take several minutes for Security Hub CSPM to process your request and update each finding specified in the request.
 *
 * You can configure IAM policies to restrict access to fields and field values.
 * For example, you might not want member accounts to be able to suppress findings or change the finding severity.
 * For more information see Configuring access to BatchUpdateFindings in the *Security Hub CSPM User Guide*.
 */
export declare const batchUpdateFindings: API.OperationMethod<BatchUpdateFindingsRequest, BatchUpdateFindingsResponse, BatchUpdateFindingsError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateFindingsV2Error = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates information about a customer's investigation into a finding. Delegated administrator accounts can update findings for their account and their member accounts. Member accounts can update findings for their own account.
 *
 * `BatchUpdateFindings` and `BatchUpdateFindingsV2` both use `securityhub:BatchUpdateFindings` in the `Action` element of an IAM policy statement.
 * You must have permission to perform the `securityhub:BatchUpdateFindings` action.
 * You can configure IAM policies to restrict access to specific finding fields or field values by using the `securityhub:OCSFSyntaxPath/` condition key, where `` is one of the following supported fields: `SeverityId`, `StatusId`, or `Comment`.
 *
 * To prevent a user from updating a specific field, use a `Null` condition with `securityhub:OCSFSyntaxPath/` set to `"false"`.
 * To prevent a user from setting a field to a specific value, use a `StringEquals` condition with `securityhub:OCSFSyntaxPath/` set to the disallowed value or list of values.
 *
 * Updates from `BatchUpdateFindingsV2` don't affect the value of `finding_info.modified_time`, `finding_info.modified_time_dt`, `time`, or `time_dt` for a finding.
 */
export declare const batchUpdateFindingsV2: API.OperationMethod<BatchUpdateFindingsV2Request, BatchUpdateFindingsV2Response, BatchUpdateFindingsV2Error, Credentials | HttpClient.HttpClient>;
export type BatchUpdateStandardsControlAssociationsError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * For a batch of security controls and standards, this operation updates the enablement status of a control in a standard.
 */
export declare const batchUpdateStandardsControlAssociations: API.OperationMethod<BatchUpdateStandardsControlAssociationsRequest, BatchUpdateStandardsControlAssociationsResponse, BatchUpdateStandardsControlAssociationsError, Credentials | HttpClient.HttpClient>;
export type CreateActionTargetError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | CommonErrors;
/**
 * Creates a custom action target in Security Hub CSPM.
 *
 * You can use custom actions on findings and insights in Security Hub CSPM to trigger target actions
 * in Amazon CloudWatch Events.
 */
export declare const createActionTarget: API.OperationMethod<CreateActionTargetRequest, CreateActionTargetResponse, CreateActionTargetError, Credentials | HttpClient.HttpClient>;
export type CreateAggregatorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables aggregation across Amazon Web Services Regions.
 */
export declare const createAggregatorV2: API.OperationMethod<CreateAggregatorV2Request, CreateAggregatorV2Response, CreateAggregatorV2Error, Credentials | HttpClient.HttpClient>;
export type CreateAutomationRuleError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Creates an automation rule based on input parameters.
 */
export declare const createAutomationRule: API.OperationMethod<CreateAutomationRuleRequest, CreateAutomationRuleResponse, CreateAutomationRuleError, Credentials | HttpClient.HttpClient>;
export type CreateAutomationRuleV2Error = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a V2 automation rule.
 */
export declare const createAutomationRuleV2: API.OperationMethod<CreateAutomationRuleV2Request, CreateAutomationRuleV2Response, CreateAutomationRuleV2Error, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationPolicyError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | CommonErrors;
/**
 * Creates a configuration policy with the defined configuration. Only the Security Hub CSPM delegated administrator
 * can invoke this operation from the home Region.
 */
export declare const createConfigurationPolicy: API.OperationMethod<CreateConfigurationPolicyRequest, CreateConfigurationPolicyResponse, CreateConfigurationPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorError = AccessDeniedException | ConflictException | InternalServerException | InvalidAccessException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a connector to a third-party cloud provider in Security Hub CSPM. A connector establishes a connection between Security Hub CSPM and a third-party cloud provider, enabling Security Hub CSPM to ingest security findings and resource data from the connected environment.
 */
export declare const createConnector: API.OperationMethod<CreateConnectorRequest, CreateConnectorResponse, CreateConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to create a connectorV2 based on input parameters.
 */
export declare const createConnectorV2: API.OperationMethod<CreateConnectorV2Request, CreateConnectorV2Response, CreateConnectorV2Error, Credentials | HttpClient.HttpClient>;
export type CreateFindingAggregatorError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * The *aggregation Region* is now called the *home Region*.
 *
 * Used to enable cross-Region aggregation. This operation can be invoked from the home Region only.
 *
 * For information about how cross-Region aggregation works, see Understanding cross-Region aggregation in Security Hub CSPM in the *Security Hub CSPM User Guide*.
 */
export declare const createFindingAggregator: API.OperationMethod<CreateFindingAggregatorRequest, CreateFindingAggregatorResponse, CreateFindingAggregatorError, Credentials | HttpClient.HttpClient>;
export type CreateInsightError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | CommonErrors;
/**
 * Creates a custom insight in Security Hub CSPM. An insight is a consolidation of findings that relate
 * to a security issue that requires attention or remediation.
 *
 * To group the related findings in the insight, use the
 * `GroupByAttribute`.
 */
export declare const createInsight: API.OperationMethod<CreateInsightRequest, CreateInsightResponse, CreateInsightError, Credentials | HttpClient.HttpClient>;
export type CreateMembersError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | CommonErrors;
/**
 * Creates a member association in Security Hub CSPM between the specified accounts and the account
 * used to make the request, which is the administrator account. If you are integrated with
 * Organizations, then the administrator account is designated by the organization management account.
 *
 * `CreateMembers` is always used to add accounts that are not organization
 * members.
 *
 * For accounts that are managed using Organizations, `CreateMembers` is only used
 * in the following cases:
 *
 * - Security Hub CSPM is not configured to automatically add new organization accounts.
 *
 * - The account was disassociated or deleted in Security Hub CSPM.
 *
 * This action can only be used by an account that has Security Hub CSPM enabled. To enable Security Hub CSPM, you
 * can use the `EnableSecurityHub` operation.
 *
 * For accounts that are not organization members, you create the account association and
 * then send an invitation to the member account. To send the invitation, you use the
 * `InviteMembers` operation. If the account owner accepts
 * the invitation, the account becomes a member account in Security Hub CSPM.
 *
 * Accounts that are managed using Organizations don't receive an invitation. They
 * automatically become a member account in Security Hub CSPM.
 *
 * - If the organization account does not have Security Hub CSPM enabled, then Security Hub CSPM and the default standards are automatically enabled. Note that Security Hub CSPM cannot be enabled automatically for the organization management account. The organization management account must enable Security Hub CSPM before the administrator account enables it as a member account.
 *
 * - For organization accounts that already have Security Hub CSPM enabled, Security Hub CSPM does not make any other changes to those accounts. It does not change their enabled standards or controls.
 *
 * A permissions policy is added that permits the administrator account to view the findings
 * generated in the member account.
 *
 * To remove the association between the administrator and member accounts, use the `DisassociateFromMasterAccount` or `DisassociateMembers` operation.
 */
export declare const createMembers: API.OperationMethod<CreateMembersRequest, CreateMembersResponse, CreateMembersError, Credentials | HttpClient.HttpClient>;
export type CreateTicketV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to create a ticket in the chosen ITSM based on finding information for the provided finding metadata UID.
 */
export declare const createTicketV2: API.OperationMethod<CreateTicketV2Request, CreateTicketV2Response, CreateTicketV2Error, Credentials | HttpClient.HttpClient>;
export type DeclineInvitationsError = InternalException | InvalidAccessException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * We recommend using Organizations instead of Security Hub CSPM invitations to manage your member accounts.
 * For information, see Managing Security Hub CSPM administrator and member accounts with Organizations
 * in the *Security Hub CSPM User Guide*.
 *
 * Declines invitations to become a Security Hub CSPM member account.
 *
 * A prospective member account uses this operation to decline an invitation to become a member.
 *
 * Only member accounts that aren't part of an Amazon Web Services organization should use this operation.
 * Organization accounts don't receive invitations.
 */
export declare const declineInvitations: API.OperationMethod<DeclineInvitationsRequest, DeclineInvitationsResponse, DeclineInvitationsError, Credentials | HttpClient.HttpClient>;
export type DeleteActionTargetError = InternalException | InvalidAccessException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a custom action target from Security Hub CSPM.
 *
 * Deleting a custom action target does not affect any findings or insights that were
 * already sent to Amazon CloudWatch Events using the custom action.
 */
export declare const deleteActionTarget: API.OperationMethod<DeleteActionTargetRequest, DeleteActionTargetResponse, DeleteActionTargetError, Credentials | HttpClient.HttpClient>;
export type DeleteAggregatorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the Aggregator V2.
 */
export declare const deleteAggregatorV2: API.OperationMethod<DeleteAggregatorV2Request, DeleteAggregatorV2Response, DeleteAggregatorV2Error, Credentials | HttpClient.HttpClient>;
export type DeleteAutomationRuleV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a V2 automation rule.
 */
export declare const deleteAutomationRuleV2: API.OperationMethod<DeleteAutomationRuleV2Request, DeleteAutomationRuleV2Response, DeleteAutomationRuleV2Error, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationPolicyError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a configuration policy. Only the Security Hub CSPM delegated administrator can invoke this operation
 * from the home Region. For the deletion to succeed, you must first disassociate a configuration policy from target accounts,
 * organizational units, or the root by invoking the `StartConfigurationPolicyDisassociation` operation.
 */
export declare const deleteConfigurationPolicy: API.OperationMethod<DeleteConfigurationPolicyRequest, DeleteConfigurationPolicyResponse, DeleteConfigurationPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorError = AccessDeniedException | ConflictException | InternalServerException | InvalidAccessException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a CSPM connector. When you delete a connector, Security Hub CSPM stops ingesting findings and resource data from the connected cloud provider environment.
 */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest, DeleteConnectorResponse, DeleteConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to delete a connectorV2.
 */
export declare const deleteConnectorV2: API.OperationMethod<DeleteConnectorV2Request, DeleteConnectorV2Response, DeleteConnectorV2Error, Credentials | HttpClient.HttpClient>;
export type DeleteFindingAggregatorError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * The *aggregation Region* is now called the *home Region*.
 *
 * Deletes a finding aggregator. When you delete the finding aggregator, you stop cross-Region aggregation. Finding replication stops
 * occurring from the linked Regions to the home Region.
 *
 * When you stop cross-Region aggregation, findings that were already replicated and sent to the home Region are still visible from
 * the home Region. However, new findings and finding updates are no longer replicated and sent to the home Region.
 */
export declare const deleteFindingAggregator: API.OperationMethod<DeleteFindingAggregatorRequest, DeleteFindingAggregatorResponse, DeleteFindingAggregatorError, Credentials | HttpClient.HttpClient>;
export type DeleteInsightError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the insight specified by the `InsightArn`.
 */
export declare const deleteInsight: API.OperationMethod<DeleteInsightRequest, DeleteInsightResponse, DeleteInsightError, Credentials | HttpClient.HttpClient>;
export type DeleteInvitationsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * We recommend using Organizations instead of Security Hub CSPM invitations to manage your member accounts.
 * For information, see Managing Security Hub CSPM administrator and member accounts with Organizations
 * in the *Security Hub CSPM User Guide*.
 *
 * Deletes invitations to become a Security Hub CSPM member account.
 *
 * A Security Hub CSPM administrator account can use this operation to delete invitations sent to one or more prospective member accounts.
 *
 * This operation is only used to delete invitations that are sent to prospective member accounts that aren't part of an Amazon Web Services organization.
 * Organization accounts don't receive invitations.
 */
export declare const deleteInvitations: API.OperationMethod<DeleteInvitationsRequest, DeleteInvitationsResponse, DeleteInvitationsError, Credentials | HttpClient.HttpClient>;
export type DeleteMembersError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified member accounts from Security Hub CSPM.
 *
 * You can invoke this API only to delete accounts that became members through invitation. You can't invoke this
 * API to delete accounts that belong to an Organizations organization.
 */
export declare const deleteMembers: API.OperationMethod<DeleteMembersRequest, DeleteMembersResponse, DeleteMembersError, Credentials | HttpClient.HttpClient>;
export type DescribeActionTargetsError = InternalException | InvalidAccessException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of the custom action targets in Security Hub CSPM in your account.
 */
export declare const describeActionTargets: API.PaginatedOperationMethod<DescribeActionTargetsRequest, DescribeActionTargetsResponse, DescribeActionTargetsError, Credentials | HttpClient.HttpClient, ActionTarget>;
export type DescribeHubError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns details about the Hub resource in your account, including the
 * `HubArn` and the time when you enabled Security Hub CSPM.
 */
export declare const describeHub: API.OperationMethod<DescribeHubRequest, DescribeHubResponse, DescribeHubError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationConfigurationError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Returns information about the way your organization is configured in Security Hub CSPM. Only the
 * Security Hub CSPM administrator account can invoke this operation.
 */
export declare const describeOrganizationConfiguration: API.OperationMethod<DescribeOrganizationConfigurationRequest, DescribeOrganizationConfigurationResponse, DescribeOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeProductsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Returns information about product integrations in Security Hub CSPM.
 *
 * You can optionally provide an integration ARN. If you provide an integration ARN, then
 * the results only include that integration.
 *
 * If you don't provide an integration ARN, then the results include all of the available
 * product integrations.
 */
export declare const describeProducts: API.PaginatedOperationMethod<DescribeProductsRequest, DescribeProductsResponse, DescribeProductsError, Credentials | HttpClient.HttpClient, Product>;
export type DescribeProductsV2Error = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about the product integration.
 */
export declare const describeProductsV2: API.PaginatedOperationMethod<DescribeProductsV2Request, DescribeProductsV2Response, DescribeProductsV2Error, Credentials | HttpClient.HttpClient, ProductV2>;
export type DescribeSecurityHubV2Error = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about the service resource in your account.
 */
export declare const describeSecurityHubV2: API.OperationMethod<DescribeSecurityHubV2Request, DescribeSecurityHubV2Response, DescribeSecurityHubV2Error, Credentials | HttpClient.HttpClient>;
export type DescribeStandardsError = InternalException | InvalidAccessException | InvalidInputException | CommonErrors;
/**
 * Returns a list of the available standards in Security Hub CSPM.
 *
 * For each standard, the results include the standard ARN, the name, and a description.
 */
export declare const describeStandards: API.PaginatedOperationMethod<DescribeStandardsRequest, DescribeStandardsResponse, DescribeStandardsError, Credentials | HttpClient.HttpClient, Standard>;
export type DescribeStandardsControlsError = InternalException | InvalidAccessException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of security standards controls.
 *
 * For each control, the results include information about whether it is currently enabled,
 * the severity, and a link to remediation information.
 *
 * This operation returns an empty list for standard subscriptions where `StandardsControlsUpdatable` has value `NOT_READY_FOR_UPDATES`.
 */
export declare const describeStandardsControls: API.PaginatedOperationMethod<DescribeStandardsControlsRequest, DescribeStandardsControlsResponse, DescribeStandardsControlsError, Credentials | HttpClient.HttpClient, StandardsControl>;
export type DisableImportFindingsForProductError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Disables the integration of the specified product with Security Hub CSPM. After the integration is
 * disabled, findings from that product are no longer sent to Security Hub CSPM.
 */
export declare const disableImportFindingsForProduct: API.OperationMethod<DisableImportFindingsForProductRequest, DisableImportFindingsForProductResponse, DisableImportFindingsForProductError, Credentials | HttpClient.HttpClient>;
export type DisableOrganizationAdminAccountError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Disables a Security Hub CSPM administrator account. Can only be called by the organization
 * management account.
 */
export declare const disableOrganizationAdminAccount: API.OperationMethod<DisableOrganizationAdminAccountRequest, DisableOrganizationAdminAccountResponse, DisableOrganizationAdminAccountError, Credentials | HttpClient.HttpClient>;
export type DisableSecurityHubError = AccessDeniedException | InternalException | InvalidAccessException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Disables Security Hub CSPM in your account only in the current Amazon Web Services Region. To disable Security Hub CSPM in all
 * Regions, you must submit one request per Region where you have enabled Security Hub CSPM.
 *
 * You can't disable Security Hub CSPM in an account that is currently the Security Hub CSPM administrator.
 *
 * When you disable Security Hub CSPM, your existing findings and insights and any Security Hub CSPM configuration
 * settings are deleted after 90 days and cannot be recovered. Any standards that were enabled
 * are disabled, and your administrator and member account associations are removed.
 *
 * If you want to save your existing findings, you must export them before you disable
 * Security Hub CSPM.
 */
export declare const disableSecurityHub: API.OperationMethod<DisableSecurityHubRequest, DisableSecurityHubResponse, DisableSecurityHubError, Credentials | HttpClient.HttpClient>;
export type DisableSecurityHubFeatureV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disables an opt-in feature for the calling account in the current Amazon Web Services Region. The operation is idempotent. If the feature is already disabled, no changes are made. You cannot disable a feature that is managed by an organization policy.
 */
export declare const disableSecurityHubFeatureV2: API.OperationMethod<DisableSecurityHubFeatureV2Request, DisableSecurityHubFeatureV2Response, DisableSecurityHubFeatureV2Error, Credentials | HttpClient.HttpClient>;
export type DisableSecurityHubV2Error = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disable the service for the current Amazon Web Services Region or specified Amazon Web Services Region. Disabling the service also disables all opt-in features that are currently enabled in that Region.
 */
export declare const disableSecurityHubV2: API.OperationMethod<DisableSecurityHubV2Request, DisableSecurityHubV2Response, DisableSecurityHubV2Error, Credentials | HttpClient.HttpClient>;
export type DisassociateFromAdministratorAccountError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates the current Security Hub CSPM member account from the associated administrator
 * account.
 *
 * This operation is only used by accounts that are not part of an organization. For
 * organization accounts, only the administrator account can
 * disassociate a member account.
 */
export declare const disassociateFromAdministratorAccount: API.OperationMethod<DisassociateFromAdministratorAccountRequest, DisassociateFromAdministratorAccountResponse, DisassociateFromAdministratorAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateFromMasterAccountError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * This method is deprecated. Instead, use `DisassociateFromAdministratorAccount`.
 *
 * The Security Hub CSPM console continues to use `DisassociateFromMasterAccount`. It will eventually change to use `DisassociateFromAdministratorAccount`. Any IAM policies that specifically control access to this function must continue to use `DisassociateFromMasterAccount`. You should also add `DisassociateFromAdministratorAccount` to your policies to ensure that the correct permissions are in place after the console begins to use `DisassociateFromAdministratorAccount`.
 *
 * Disassociates the current Security Hub CSPM member account from the associated administrator
 * account.
 *
 * This operation is only used by accounts that are not part of an organization. For
 * organization accounts, only the administrator account can
 * disassociate a member account.
 */
export declare const disassociateFromMasterAccount: API.OperationMethod<DisassociateFromMasterAccountRequest, DisassociateFromMasterAccountResponse, DisassociateFromMasterAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateMembersError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates the specified member accounts from the associated administrator account.
 *
 * Can be used to disassociate both accounts that are managed using Organizations and accounts that
 * were invited manually.
 */
export declare const disassociateMembers: API.OperationMethod<DisassociateMembersRequest, DisassociateMembersResponse, DisassociateMembersError, Credentials | HttpClient.HttpClient>;
export type EnableImportFindingsForProductError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | CommonErrors;
/**
 * Enables the integration of a partner product with Security Hub CSPM. Integrated products send
 * findings to Security Hub CSPM.
 *
 * When you enable a product integration, a permissions policy that grants permission for
 * the product to send findings to Security Hub CSPM is applied.
 */
export declare const enableImportFindingsForProduct: API.OperationMethod<EnableImportFindingsForProductRequest, EnableImportFindingsForProductResponse, EnableImportFindingsForProductError, Credentials | HttpClient.HttpClient>;
export type EnableOrganizationAdminAccountError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Designates the Security Hub CSPM administrator account for an organization. Can only be called by
 * the organization management account.
 */
export declare const enableOrganizationAdminAccount: API.OperationMethod<EnableOrganizationAdminAccountRequest, EnableOrganizationAdminAccountResponse, EnableOrganizationAdminAccountError, Credentials | HttpClient.HttpClient>;
export type EnableSecurityHubError = AccessDeniedException | InternalException | InvalidAccessException | LimitExceededException | ResourceConflictException | CommonErrors;
/**
 * Enables Security Hub CSPM for your account in the current Region or the Region you specify in the
 * request.
 *
 * When you enable Security Hub CSPM, you grant to Security Hub CSPM the permissions necessary to gather findings
 * from other services that are integrated with Security Hub CSPM.
 *
 * When you use the `EnableSecurityHub` operation to enable Security Hub CSPM, you also
 * automatically enable the following standards:
 *
 * - Center for Internet Security (CIS) Amazon Web Services Foundations Benchmark v1.2.0
 *
 * - Amazon Web Services Foundational Security Best Practices
 *
 * Other standards are not automatically enabled.
 *
 * To opt out of automatically enabled standards, set
 * `EnableDefaultStandards` to `false`.
 *
 * After you enable Security Hub CSPM, to enable a standard, use the `BatchEnableStandards` operation. To disable a standard, use the
 * `BatchDisableStandards` operation.
 *
 * To learn more, see the setup information in the *Security Hub CSPM User Guide*.
 */
export declare const enableSecurityHub: API.OperationMethod<EnableSecurityHubRequest, EnableSecurityHubResponse, EnableSecurityHubError, Credentials | HttpClient.HttpClient>;
export type EnableSecurityHubFeatureV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables an opt-in feature for the calling account in the current Amazon Web Services Region. The service must be enabled before you can enable a feature. The operation is idempotent. If the feature is already enabled, no changes are made. You cannot enable a feature that is managed by an organization policy.
 */
export declare const enableSecurityHubFeatureV2: API.OperationMethod<EnableSecurityHubFeatureV2Request, EnableSecurityHubFeatureV2Response, EnableSecurityHubFeatureV2Error, Credentials | HttpClient.HttpClient>;
export type EnableSecurityHubV2Error = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables the service in account for the current Amazon Web Services Region or specified Amazon Web Services Region.
 */
export declare const enableSecurityHubV2: API.OperationMethod<EnableSecurityHubV2Request, EnableSecurityHubV2Response, EnableSecurityHubV2Error, Credentials | HttpClient.HttpClient>;
export type GenerateRecommendedPolicyV2Error = AccessDeniedException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Begins the recommended policy generation to remediate a Security Hub finding.
 * `GenerateRecommendedPolicyV2` only supports findings for unused permissions.
 */
export declare const generateRecommendedPolicyV2: API.OperationMethod<GenerateRecommendedPolicyV2Request, GenerateRecommendedPolicyV2Response, GenerateRecommendedPolicyV2Error, Credentials | HttpClient.HttpClient>;
export type GetAdministratorAccountError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Provides the details for the Security Hub CSPM administrator account for the current member account.
 *
 * Can be used by both member accounts that are managed using Organizations and accounts that were
 * invited manually.
 */
export declare const getAdministratorAccount: API.OperationMethod<GetAdministratorAccountRequest, GetAdministratorAccountResponse, GetAdministratorAccountError, Credentials | HttpClient.HttpClient>;
export type GetAggregatorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the configuration of the specified Aggregator V2.
 */
export declare const getAggregatorV2: API.OperationMethod<GetAggregatorV2Request, GetAggregatorV2Response, GetAggregatorV2Error, Credentials | HttpClient.HttpClient>;
export type GetAutomationRuleV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an automation rule for the V2 service.
 */
export declare const getAutomationRuleV2: API.OperationMethod<GetAutomationRuleV2Request, GetAutomationRuleV2Response, GetAutomationRuleV2Error, Credentials | HttpClient.HttpClient>;
export type GetConfigurationPolicyError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Provides information about a configuration policy. Only the Security Hub CSPM delegated administrator can invoke
 * this operation from the home Region.
 */
export declare const getConfigurationPolicy: API.OperationMethod<GetConfigurationPolicyRequest, GetConfigurationPolicyResponse, GetConfigurationPolicyError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationPolicyAssociationError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the association between a configuration and a target account, organizational unit, or the root. The
 * configuration can be a configuration policy or self-managed behavior. Only the Security Hub CSPM delegated administrator can
 * invoke this operation from the home Region.
 */
export declare const getConfigurationPolicyAssociation: API.OperationMethod<GetConfigurationPolicyAssociationRequest, GetConfigurationPolicyAssociationResponse, GetConfigurationPolicyAssociationError, Credentials | HttpClient.HttpClient>;
export type GetConnectorError = AccessDeniedException | ConflictException | InternalServerException | InvalidAccessException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details for a CSPM connector based on the connector ID.
 */
export declare const getConnector: API.OperationMethod<GetConnectorRequest, GetConnectorResponse, GetConnectorError, Credentials | HttpClient.HttpClient>;
export type GetConnectorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to retrieve details for a connectorV2 based on connector id.
 */
export declare const getConnectorV2: API.OperationMethod<GetConnectorV2Request, GetConnectorV2Response, GetConnectorV2Error, Credentials | HttpClient.HttpClient>;
export type GetEnabledStandardsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Returns a list of the standards that are currently enabled.
 */
export declare const getEnabledStandards: API.PaginatedOperationMethod<GetEnabledStandardsRequest, GetEnabledStandardsResponse, GetEnabledStandardsError, Credentials | HttpClient.HttpClient, StandardsSubscription>;
export type GetFindingAggregatorError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * The *aggregation Region* is now called the *home Region*.
 *
 * Returns the current configuration in the calling account for cross-Region aggregation. A finding aggregator is a resource that establishes
 * the home Region and any linked Regions.
 */
export declare const getFindingAggregator: API.OperationMethod<GetFindingAggregatorRequest, GetFindingAggregatorResponse, GetFindingAggregatorError, Credentials | HttpClient.HttpClient>;
export type GetFindingHistoryError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Returns the history of a Security Hub CSPM finding. The history includes changes made to any fields in
 * the Amazon Web Services Security Finding Format (ASFF) except top-level timestamp fields, such as the `CreatedAt` and
 * `UpdatedAt` fields.
 *
 * This operation might return fewer results than the maximum number of results (`MaxResults`) specified in a request, even
 * when more results are available. If this occurs, the response includes a `NextToken` value, which you should use to retrieve
 * the next set of results in the response. The presence of a `NextToken` value in a response doesn't necessarily indicate
 * that the results are incomplete. However, you should continue to specify a `NextToken` value until you receive a
 * response that doesn't include this value.
 */
export declare const getFindingHistory: API.PaginatedOperationMethod<GetFindingHistoryRequest, GetFindingHistoryResponse, GetFindingHistoryError, Credentials | HttpClient.HttpClient, FindingHistoryRecord>;
export type GetFindingsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Returns a list of findings that match the specified criteria.
 *
 * If cross-Region aggregation is enabled, then when you call `GetFindings` from the home Region, the results include all of the matching findings from both the home Region and linked Regions.
 */
export declare const getFindings: API.PaginatedOperationMethod<GetFindingsRequest, GetFindingsResponse, GetFindingsError, Credentials | HttpClient.HttpClient, AwsSecurityFinding>;
export type GetFindingStatisticsV2Error = AccessDeniedException | ConflictException | InternalServerException | OrganizationalUnitNotFoundException | OrganizationNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns aggregated statistical data about findings.
 *
 * You can use the `Scopes` parameter to define the data boundary for the query. Currently, `Scopes` supports `AwsOrganizations`, which lets you aggregate findings from your entire organization or from specific organizational units. Only the delegated administrator account can use `Scopes`.
 *
 * `GetFindingStatisticsV2` uses `securityhub:GetAdhocInsightResults` in the `Action` element of an IAM policy statement.
 * You must have permission to perform the `securityhub:GetAdhocInsightResults` action.
 */
export declare const getFindingStatisticsV2: API.OperationMethod<GetFindingStatisticsV2Request, GetFindingStatisticsV2Response, GetFindingStatisticsV2Error, Credentials | HttpClient.HttpClient>;
export type GetFindingsTrendsV2Error = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns findings trend data based on the specified criteria. This operation helps you analyze patterns and changes in findings over time.
 */
export declare const getFindingsTrendsV2: API.PaginatedOperationMethod<GetFindingsTrendsV2Request, GetFindingsTrendsV2Response, GetFindingsTrendsV2Error, Credentials | HttpClient.HttpClient, TrendsMetricsResult>;
export type GetFindingsV2Error = AccessDeniedException | ConflictException | InternalServerException | OrganizationalUnitNotFoundException | OrganizationNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of findings that match the specified criteria.
 *
 * You can use the `Scopes` parameter to define the data boundary for the query. Currently, `Scopes` supports `AwsOrganizations`, which lets you retrieve findings from your entire organization or from specific organizational units. Only the delegated administrator account can use `Scopes`.
 *
 * You can use the `Filters` parameter to refine results based on finding attributes. You can use `Scopes` and `Filters` independently or together. When both are provided, `Scopes` narrows the data set first, and then `Filters` refines results within that scoped data set.
 *
 * `GetFindings` and `GetFindingsV2` both use `securityhub:GetFindings` in the `Action` element of an IAM policy statement.
 * You must have permission to perform the `securityhub:GetFindings` action.
 */
export declare const getFindingsV2: API.PaginatedOperationMethod<GetFindingsV2Request, GetFindingsV2Response, GetFindingsV2Error, Credentials | HttpClient.HttpClient, unknown>;
export type GetInsightResultsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the results of the Security Hub CSPM insight specified by the insight ARN.
 */
export declare const getInsightResults: API.OperationMethod<GetInsightResultsRequest, GetInsightResultsResponse, GetInsightResultsError, Credentials | HttpClient.HttpClient>;
export type GetInsightsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Lists and describes insights for the specified insight ARNs.
 */
export declare const getInsights: API.PaginatedOperationMethod<GetInsightsRequest, GetInsightsResponse, GetInsightsError, Credentials | HttpClient.HttpClient, Insight>;
export type GetInvitationsCountError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * We recommend using Organizations instead of Security Hub CSPM invitations to manage your member accounts.
 * For information, see Managing Security Hub CSPM administrator and member accounts with Organizations
 * in the *Security Hub CSPM User Guide*.
 *
 * Returns the count of all Security Hub CSPM membership invitations that were sent to the
 * calling member account, not including the currently accepted invitation.
 */
export declare const getInvitationsCount: API.OperationMethod<GetInvitationsCountRequest, GetInvitationsCountResponse, GetInvitationsCountError, Credentials | HttpClient.HttpClient>;
export type GetMasterAccountError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * This method is deprecated. Instead, use `GetAdministratorAccount`.
 *
 * The Security Hub CSPM console continues to use `GetMasterAccount`. It will eventually change to use `GetAdministratorAccount`. Any IAM policies that specifically control access to this function must continue to use `GetMasterAccount`. You should also add `GetAdministratorAccount` to your policies to ensure that the correct permissions are in place after the console begins to use `GetAdministratorAccount`.
 *
 * Provides the details for the Security Hub CSPM administrator account for the current member account.
 *
 * Can be used by both member accounts that are managed using Organizations and accounts that were
 * invited manually.
 */
export declare const getMasterAccount: API.OperationMethod<GetMasterAccountRequest, GetMasterAccountResponse, GetMasterAccountError, Credentials | HttpClient.HttpClient>;
export type GetMembersError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the details for the Security Hub CSPM member accounts for the specified account IDs.
 *
 * An administrator account can be either the delegated Security Hub CSPM administrator account for an
 * organization or an administrator account that enabled Security Hub CSPM manually.
 *
 * The results include both member accounts that are managed using Organizations and accounts that
 * were invited manually.
 */
export declare const getMembers: API.OperationMethod<GetMembersRequest, GetMembersResponse, GetMembersError, Credentials | HttpClient.HttpClient>;
export type GetRecommendedPolicyV2Error = AccessDeniedException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the recommended policy to remediate a Security Hub finding.
 * `GetRecommendedPolicyV2` only supports findings for unused permissions.
 */
export declare const getRecommendedPolicyV2: API.PaginatedOperationMethod<GetRecommendedPolicyV2Request, GetRecommendedPolicyV2Response, GetRecommendedPolicyV2Error, Credentials | HttpClient.HttpClient, RecommendationStep>;
export type GetRemediationsV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves remediation targets for the account, or for all member accounts if the caller is
 * the delegated administrator. Results are sorted by priority, highest first, and are paginated.
 * Use `TargetUid` or `MetadataUid` to scope the request to a single target
 * or finding.
 */
export declare const getRemediationsV2: API.PaginatedOperationMethod<GetRemediationsV2Request, GetRemediationsV2Response, GetRemediationsV2Error, Credentials | HttpClient.HttpClient, RemediationV2Item>;
export type GetResourcesStatisticsV2Error = AccessDeniedException | ConflictException | InternalServerException | OrganizationalUnitNotFoundException | OrganizationNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves statistical information about Amazon Web Services resources and their associated security findings.
 *
 * You can use the `Scopes` parameter to define the data boundary for the query. Currently, `Scopes` supports `AwsOrganizations`, which lets you aggregate resources from your entire organization or from specific organizational units. Only the delegated administrator account can use `Scopes`.
 *
 * If you set `GroupByField` to `ResourceSubCategory`, `ResourceInfo.AIDetails.HostResourceType`, or `ResourceInfo.AIDetails.CanonicalId`, you must include a `ResourceCategory` string filter with comparison set to `EQUALS` and value `AI/ML` in the corresponding `ResourceGroupByRule`.
 */
export declare const getResourcesStatisticsV2: API.OperationMethod<GetResourcesStatisticsV2Request, GetResourcesStatisticsV2Response, GetResourcesStatisticsV2Error, Credentials | HttpClient.HttpClient>;
export type GetResourcesTrendsV2Error = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns resource trend data based on the specified criteria. This operation helps you analyze patterns and changes in resource compliance over time.
 */
export declare const getResourcesTrendsV2: API.PaginatedOperationMethod<GetResourcesTrendsV2Request, GetResourcesTrendsV2Response, GetResourcesTrendsV2Error, Credentials | HttpClient.HttpClient, ResourcesTrendsMetricsResult>;
export type GetResourcesV2Error = AccessDeniedException | ConflictException | InternalServerException | OrganizationalUnitNotFoundException | OrganizationNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of resources.
 *
 * You can use the `Scopes` parameter to define the data boundary for the query. Currently, `Scopes` supports `AwsOrganizations`, which lets you retrieve resources from your entire organization or from specific organizational units. Only the delegated administrator account can use `Scopes`.
 *
 * You can use the `Filters` parameter to refine results based on resource attributes. You can use `Scopes` and `Filters` independently or together. When both are provided, `Scopes` narrows the data set first, and then `Filters` refines results within that scoped data set.
 *
 * For AI/ML resources, the response includes the `ResourceSubCategory` field. For self-hosted AI resources and their host resources, the response also includes `ResourceInfo` with AI-specific details. Self-hosted AI resources use a `ResourceType` with the `SelfHosted::AI::` prefix, such as `SelfHosted::AI::Model`, `SelfHosted::AI::Agent`, `SelfHosted::AI::InferenceEndpoint`, and `SelfHosted::AI::ExternalEndpoint`.
 *
 * If you filter by `ResourceSubCategory`, you must also include a `ResourceCategory` string filter with comparison set to `EQUALS` and value `AI/ML` in the same request.
 */
export declare const getResourcesV2: API.PaginatedOperationMethod<GetResourcesV2Request, GetResourcesV2Response, GetResourcesV2Error, Credentials | HttpClient.HttpClient, ResourceResult>;
export type GetSecurityControlDefinitionError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the definition of a security control. The definition includes the control title, description, Region availability, parameter definitions, and other details.
 */
export declare const getSecurityControlDefinition: API.OperationMethod<GetSecurityControlDefinitionRequest, GetSecurityControlDefinitionResponse, GetSecurityControlDefinitionError, Credentials | HttpClient.HttpClient>;
export type InviteMembersError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * We recommend using Organizations instead of Security Hub CSPM invitations to manage your member accounts.
 * For information, see Managing Security Hub CSPM administrator and member accounts with Organizations
 * in the *Security Hub CSPM User Guide*.
 *
 * Invites other Amazon Web Services accounts to become member accounts for the Security Hub CSPM administrator account that
 * the invitation is sent from.
 *
 * This operation is only used to invite accounts that don't belong to an Amazon Web Services organization.
 * Organization accounts don't receive invitations.
 *
 * Before you can use this action to invite a member, you must first use the `CreateMembers` action to create the member account in Security Hub CSPM.
 *
 * When the account owner enables Security Hub CSPM and accepts the invitation to become a member
 * account, the administrator account can view the findings generated in the member account.
 */
export declare const inviteMembers: API.OperationMethod<InviteMembersRequest, InviteMembersResponse, InviteMembersError, Credentials | HttpClient.HttpClient>;
export type ListAggregatorsV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of V2 aggregators.
 */
export declare const listAggregatorsV2: API.PaginatedOperationMethod<ListAggregatorsV2Request, ListAggregatorsV2Response, ListAggregatorsV2Error, Credentials | HttpClient.HttpClient, AggregatorV2>;
export type ListAutomationRulesError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * A list of automation rules and their metadata for the calling account.
 */
export declare const listAutomationRules: API.OperationMethod<ListAutomationRulesRequest, ListAutomationRulesResponse, ListAutomationRulesError, Credentials | HttpClient.HttpClient>;
export type ListAutomationRulesV2Error = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of automation rules and metadata for the calling account.
 */
export declare const listAutomationRulesV2: API.OperationMethod<ListAutomationRulesV2Request, ListAutomationRulesV2Response, ListAutomationRulesV2Error, Credentials | HttpClient.HttpClient>;
export type ListConfigurationPoliciesError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Lists the configuration policies that the Security Hub CSPM delegated administrator has created for your
 * organization. Only the delegated administrator can invoke this operation from the home Region.
 */
export declare const listConfigurationPolicies: API.PaginatedOperationMethod<ListConfigurationPoliciesRequest, ListConfigurationPoliciesResponse, ListConfigurationPoliciesError, Credentials | HttpClient.HttpClient, ConfigurationPolicySummary>;
export type ListConfigurationPolicyAssociationsError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Provides information about the associations for your configuration policies and self-managed behavior. Only the
 * Security Hub CSPM delegated administrator can invoke this operation from the home Region.
 */
export declare const listConfigurationPolicyAssociations: API.PaginatedOperationMethod<ListConfigurationPolicyAssociationsRequest, ListConfigurationPolicyAssociationsResponse, ListConfigurationPolicyAssociationsError, Credentials | HttpClient.HttpClient, ConfigurationPolicyAssociationSummary>;
export type ListConnectorsError = AccessDeniedException | ConflictException | InternalServerException | InvalidAccessException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the CSPM connectors and their metadata for the calling account.
 */
export declare const listConnectors: API.OperationMethod<ListConnectorsRequest, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient>;
export type ListConnectorsV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to retrieve a list of connectorsV2 and their metadata for the calling account.
 */
export declare const listConnectorsV2: API.OperationMethod<ListConnectorsV2Request, ListConnectorsV2Response, ListConnectorsV2Error, Credentials | HttpClient.HttpClient>;
export type ListEnabledProductsForImportError = InternalException | InvalidAccessException | LimitExceededException | CommonErrors;
/**
 * Lists all findings-generating solutions (products) that you are subscribed to receive
 * findings from in Security Hub CSPM.
 */
export declare const listEnabledProductsForImport: API.PaginatedOperationMethod<ListEnabledProductsForImportRequest, ListEnabledProductsForImportResponse, ListEnabledProductsForImportError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListExposuresByRemediationV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the exposure findings tied to a specific remediation target. Results are sorted by
 * previous severity, highest first, and are paginated.
 */
export declare const listExposuresByRemediationV2: API.PaginatedOperationMethod<ListExposuresByRemediationV2Request, ListExposuresByRemediationV2Response, ListExposuresByRemediationV2Error, Credentials | HttpClient.HttpClient, ExposureFinding>;
export type ListFindingAggregatorsError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * If cross-Region aggregation is enabled, then `ListFindingAggregators` returns the Amazon Resource Name (ARN)
 * of the finding aggregator. You can run this operation from any Amazon Web Services Region.
 */
export declare const listFindingAggregators: API.PaginatedOperationMethod<ListFindingAggregatorsRequest, ListFindingAggregatorsResponse, ListFindingAggregatorsError, Credentials | HttpClient.HttpClient, FindingAggregator>;
export type ListFreeTrialStatusesV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the free trial status of Security Hub features. A delegated Security Hub administrator can list the status for accounts in its organization. Any other account can list the status only for itself. Free trial status remains available after a feature is disabled.
 */
export declare const listFreeTrialStatusesV2: API.PaginatedOperationMethod<ListFreeTrialStatusesV2Request, ListFreeTrialStatusesV2Response, ListFreeTrialStatusesV2Error, Credentials | HttpClient.HttpClient, AccountFreeTrialStatus>;
export type ListInvitationsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * We recommend using Organizations instead of Security Hub CSPM invitations to manage your member accounts.
 * For information, see Managing Security Hub CSPM administrator and member accounts with Organizations
 * in the *Security Hub CSPM User Guide*.
 *
 * Lists all Security Hub CSPM membership invitations that were sent to the calling account.
 *
 * Only accounts that are managed by invitation can use this operation.
 * Accounts that are managed using the integration with Organizations don't receive invitations.
 */
export declare const listInvitations: API.PaginatedOperationMethod<ListInvitationsRequest, ListInvitationsResponse, ListInvitationsError, Credentials | HttpClient.HttpClient, Invitation>;
export type ListMembersError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Lists details about all member accounts for the current Security Hub CSPM administrator
 * account.
 *
 * The results include both member accounts that belong to an organization and member
 * accounts that were invited manually.
 */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersRequest, ListMembersResponse, ListMembersError, Credentials | HttpClient.HttpClient, Member>;
export type ListOrganizationAdminAccountsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Lists the Security Hub CSPM administrator accounts. Can only be called by the organization
 * management account.
 */
export declare const listOrganizationAdminAccounts: API.PaginatedOperationMethod<ListOrganizationAdminAccountsRequest, ListOrganizationAdminAccountsResponse, ListOrganizationAdminAccountsError, Credentials | HttpClient.HttpClient, AdminAccount>;
export type ListSecurityControlDefinitionsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Lists all of the security controls that apply to a specified standard.
 */
export declare const listSecurityControlDefinitions: API.PaginatedOperationMethod<ListSecurityControlDefinitionsRequest, ListSecurityControlDefinitionsResponse, ListSecurityControlDefinitionsError, Credentials | HttpClient.HttpClient, SecurityControlDefinition>;
export type ListStandardsControlAssociationsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Specifies whether a control is currently enabled or disabled in each enabled standard in the calling account.
 *
 * This operation omits standards control associations for standard subscriptions where `StandardsControlsUpdatable` has value `NOT_READY_FOR_UPDATES`.
 */
export declare const listStandardsControlAssociations: API.PaginatedOperationMethod<ListStandardsControlAssociationsRequest, ListStandardsControlAssociationsResponse, ListStandardsControlAssociationsError, Credentials | HttpClient.HttpClient, StandardsControlAssociationSummary>;
export type ListTagsForResourceError = InternalException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of tags associated with a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterConnectorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to complete the authorization based on input parameters.
 */
export declare const registerConnectorV2: API.OperationMethod<RegisterConnectorV2Request, RegisterConnectorV2Response, RegisterConnectorV2Error, Credentials | HttpClient.HttpClient>;
export type StartConfigurationPolicyAssociationError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Associates a target account, organizational unit, or the root with a specified configuration. The target can be
 * associated with a configuration policy or self-managed behavior. Only the Security Hub CSPM delegated administrator can
 * invoke this operation from the home Region.
 */
export declare const startConfigurationPolicyAssociation: API.OperationMethod<StartConfigurationPolicyAssociationRequest, StartConfigurationPolicyAssociationResponse, StartConfigurationPolicyAssociationError, Credentials | HttpClient.HttpClient>;
export type StartConfigurationPolicyDisassociationError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates a target account, organizational unit, or the root from a specified configuration. When you
 * disassociate a configuration from its target, the target inherits the configuration of the closest parent. If there's no
 * configuration to inherit, the target retains its settings but becomes a self-managed account. A target can be disassociated from
 * a configuration policy or self-managed behavior. Only the Security Hub CSPM delegated administrator can invoke this
 * operation from the home Region.
 */
export declare const startConfigurationPolicyDisassociation: API.OperationMethod<StartConfigurationPolicyDisassociationRequest, StartConfigurationPolicyDisassociationResponse, StartConfigurationPolicyDisassociationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Adds one or more tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateActionTargetError = InternalException | InvalidAccessException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the name and description of a custom action target in Security Hub CSPM.
 */
export declare const updateActionTarget: API.OperationMethod<UpdateActionTargetRequest, UpdateActionTargetResponse, UpdateActionTargetError, Credentials | HttpClient.HttpClient>;
export type UpdateAggregatorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Udpates the configuration for the Aggregator V2.
 */
export declare const updateAggregatorV2: API.OperationMethod<UpdateAggregatorV2Request, UpdateAggregatorV2Response, UpdateAggregatorV2Error, Credentials | HttpClient.HttpClient>;
export type UpdateAutomationRuleV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a V2 automation rule.
 */
export declare const updateAutomationRuleV2: API.OperationMethod<UpdateAutomationRuleV2Request, UpdateAutomationRuleV2Response, UpdateAutomationRuleV2Error, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationPolicyError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a configuration policy. Only the Security Hub CSPM delegated
 * administrator can invoke this operation from the home Region.
 */
export declare const updateConfigurationPolicy: API.OperationMethod<UpdateConfigurationPolicyRequest, UpdateConfigurationPolicyResponse, UpdateConfigurationPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorError = AccessDeniedException | ConflictException | InternalServerException | InvalidAccessException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a CSPM connector's configuration, such as the scope or regions for the connected cloud provider.
 */
export declare const updateConnector: API.OperationMethod<UpdateConnectorRequest, UpdateConnectorResponse, UpdateConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to update a connectorV2 based on its id and input parameters.
 */
export declare const updateConnectorV2: API.OperationMethod<UpdateConnectorV2Request, UpdateConnectorV2Response, UpdateConnectorV2Error, Credentials | HttpClient.HttpClient>;
export type UpdateFindingAggregatorError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * The *aggregation Region* is now called the *home Region*.
 *
 * Updates cross-Region aggregation settings. You can use this operation to update the Region linking mode and the list
 * of included or excluded Amazon Web Services Regions. However, you can't use this operation to change the home Region.
 *
 * You can invoke this operation from the current home Region only.
 */
export declare const updateFindingAggregator: API.OperationMethod<UpdateFindingAggregatorRequest, UpdateFindingAggregatorResponse, UpdateFindingAggregatorError, Credentials | HttpClient.HttpClient>;
export type UpdateFindingsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * `UpdateFindings` is a deprecated operation. Instead of `UpdateFindings`, use
 * the `BatchUpdateFindings` operation.
 *
 * The `UpdateFindings` operation updates the `Note` and `RecordState` of the Security Hub CSPM aggregated
 * findings that the filter attributes specify. Any member account that can view the finding
 * can also see the update to the finding.
 *
 * Finding updates made with `UpdateFindings` aren't persisted if the same finding is later updated by the
 * finding provider through the `BatchImportFindings` operation. In addition, Security Hub CSPM doesn't
 * record updates made with `UpdateFindings` in the finding history.
 */
export declare const updateFindings: API.OperationMethod<UpdateFindingsRequest, UpdateFindingsResponse, UpdateFindingsError, Credentials | HttpClient.HttpClient>;
export type UpdateInsightError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the Security Hub CSPM insight identified by the specified insight ARN.
 */
export declare const updateInsight: API.OperationMethod<UpdateInsightRequest, UpdateInsightResponse, UpdateInsightError, Credentials | HttpClient.HttpClient>;
export type UpdateOrganizationConfigurationError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the configuration of your organization in Security Hub CSPM. Only the
 * Security Hub CSPM administrator account can invoke this operation.
 */
export declare const updateOrganizationConfiguration: API.OperationMethod<UpdateOrganizationConfigurationRequest, UpdateOrganizationConfigurationResponse, UpdateOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityControlError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the properties of a security control.
 */
export declare const updateSecurityControl: API.OperationMethod<UpdateSecurityControlRequest, UpdateSecurityControlResponse, UpdateSecurityControlError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityHubConfigurationError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates configuration options for Security Hub CSPM.
 */
export declare const updateSecurityHubConfiguration: API.OperationMethod<UpdateSecurityHubConfigurationRequest, UpdateSecurityHubConfigurationResponse, UpdateSecurityHubConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateStandardsControlError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Used to control whether an individual security standard control is enabled or
 * disabled.
 *
 * Calls to this operation return a `RESOURCE_NOT_FOUND_EXCEPTION` error when the standard subscription for the control has `StandardsControlsUpdatable` value `NOT_READY_FOR_UPDATES`.
 */
export declare const updateStandardsControl: API.OperationMethod<UpdateStandardsControlRequest, UpdateStandardsControlResponse, UpdateStandardsControlError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=securityhub.d.ts.map