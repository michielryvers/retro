import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly resourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SubscriptionArn = string;
export type IdempotencyToken = string;
export interface ApprovePaidSubscriptionInput {
    arn: string;
    ifMatch: string;
    clientToken?: string;
}
export type ScheduledChangeType = "DOWNGRADE" | "CANCELLATION" | (string & {});
export interface ScheduledChange {
    changeType: ScheduledChangeType;
    effectiveDate?: Date;
    planTier?: string;
    usageLevel?: string;
}
export type Status = "PENDING_APPROVAL" | "ACTIVE" | "SYNC_IN_PROGRESS" | "FAILED" | (string & {});
export type ResourceArns = string[];
export interface Subscription {
    arn: string;
    planFamily: string;
    planTier: string;
    usageLevel?: string;
    scheduledChange?: ScheduledChange;
    status: Status;
    statusReason?: string;
    resourceArns: string[];
    createdAt: Date;
    updatedAt: Date;
}
export interface ApprovePaidSubscriptionOutput {
    subscription: Subscription;
    eTag: string;
}
export interface AssociateResourcesToSubscriptionInput {
    arn: string;
    resourceArns: string[];
    ifMatch: string;
    clientToken?: string;
}
export interface AssociateResourcesToSubscriptionOutput {
    subscription: Subscription;
    eTag: string;
}
export interface CancelSubscriptionInput {
    arn: string;
    ifMatch: string;
    clientToken?: string;
}
export interface CancelSubscriptionOutput {
    subscription: Subscription;
    eTag: string;
}
export interface CancelSubscriptionChangeInput {
    arn: string;
    ifMatch: string;
    clientToken?: string;
}
export interface CancelSubscriptionChangeOutput {
    subscription: Subscription;
    eTag: string;
}
export type ApprovalMode = "MANUAL" | "IMMEDIATE" | (string & {});
export interface CreateSubscriptionInput {
    planFamily: string;
    planTier: string;
    usageLevel?: string;
    resourceArns: string[];
    approvalMode?: ApprovalMode;
    clientToken?: string;
}
export interface CreateSubscriptionOutput {
    subscription: Subscription;
    eTag: string;
}
export interface DisassociateResourcesFromSubscriptionInput {
    arn: string;
    resourceArns: string[];
    ifMatch: string;
    clientToken?: string;
}
export interface DisassociateResourcesFromSubscriptionOutput {
    subscription: Subscription;
    eTag: string;
}
export interface GetSubscriptionInput {
    arn: string;
}
export interface GetSubscriptionOutput {
    subscription: Subscription;
    eTag: string;
}
export interface ListSubscriptionsInput {
    nextToken?: string;
}
export interface SubscriptionSummary {
    arn: string;
    planFamily: string;
    planTier: string;
    usageLevel?: string;
    scheduledChange?: ScheduledChange;
    status: Status;
    statusReason?: string;
    resourceArns: string[];
    createdAt: Date;
    updatedAt: Date;
    eTag: string;
}
export type SubscriptionSummaryList = SubscriptionSummary[];
export interface ListSubscriptionsOutput {
    subscriptionSummaries: SubscriptionSummary[];
    nextToken?: string;
}
export interface UpdateSubscriptionInput {
    arn: string;
    planTier: string;
    usageLevel?: string;
    ifMatch: string;
    clientToken?: string;
}
export interface UpdateSubscriptionOutput {
    subscription: Subscription;
    eTag: string;
}
export type ApprovePaidSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Approves a subscription that is in `PENDING_APPROVAL` status, activating it and starting billing.
 *
 * This operation requires the current `ETag` value for concurrency control. Retrieve it from a previous `GetSubscription` or `ListSubscriptions` response.
 */
export declare const approvePaidSubscription: API.OperationMethod<ApprovePaidSubscriptionInput, ApprovePaidSubscriptionOutput, ApprovePaidSubscriptionError, Credentials | HttpClient.HttpClient>;
export type AssociateResourcesToSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds one or more resources to an existing subscription. The subscription must be in an active state that is not pending other changes.
 *
 * For subscriptions in the CloudFront plan family, the associated resources must include exactly one Amazon CloudFront distribution and one WAF web ACL. You can also include other supported resources, such as Amazon Route 53 hosted zones, and CloudFront KeyValueStores.
 */
export declare const associateResourcesToSubscription: API.OperationMethod<AssociateResourcesToSubscriptionInput, AssociateResourcesToSubscriptionOutput, AssociateResourcesToSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CancelSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a flat-rate pricing subscription.
 *
 * For active subscriptions, the cancellation is scheduled to take effect at the end of the current billing period. The subscription remains active until that date. To revert a pending cancellation, use `CancelSubscriptionChange`.
 *
 * For subscriptions in `PENDING_APPROVAL` status, the subscription is deleted immediately without scheduling.
 */
export declare const cancelSubscription: API.OperationMethod<CancelSubscriptionInput, CancelSubscriptionOutput, CancelSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CancelSubscriptionChangeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a pending scheduled change on a subscription, such as a pending downgrade or cancellation. The subscription returns to its state before the change was scheduled.
 *
 * You cannot cancel a scheduled change close to its effective date. If the change is within the processing window, this operation returns an error.
 */
export declare const cancelSubscriptionChange: API.OperationMethod<CancelSubscriptionChangeInput, CancelSubscriptionChangeOutput, CancelSubscriptionChangeError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a flat-rate pricing subscription for the specified resources.
 *
 * When `approvalMode` is set to `MANUAL`, paid-tier subscriptions are created in `PENDING_APPROVAL` status and require a separate `ApprovePaidSubscription` call before billing starts. Free-tier subscriptions are always activated immediately regardless of approval mode.
 *
 * When `approvalMode` is set to `IMMEDIATE` or is not specified, the subscription is activated immediately.
 */
export declare const createSubscription: API.OperationMethod<CreateSubscriptionInput, CreateSubscriptionOutput, CreateSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DisassociateResourcesFromSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more resources from an existing subscription.
 *
 * For subscriptions in the CloudFront plan family, the associated resources must always include exactly one Amazon CloudFront distribution and exactly one WAF web ACL. You cannot remove these required resources.
 */
export declare const disassociateResourcesFromSubscription: API.OperationMethod<DisassociateResourcesFromSubscriptionInput, DisassociateResourcesFromSubscriptionOutput, DisassociateResourcesFromSubscriptionError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details of a flat-rate pricing subscription, including its current status, associated resources, and any pending scheduled changes.
 */
export declare const getSubscription: API.OperationMethod<GetSubscriptionInput, GetSubscriptionOutput, GetSubscriptionError, Credentials | HttpClient.HttpClient>;
export type ListSubscriptionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a summary of all flat-rate pricing subscriptions in the calling account.
 */
export declare const listSubscriptions: API.PaginatedOperationMethod<ListSubscriptionsInput, ListSubscriptionsOutput, ListSubscriptionsError, Credentials | HttpClient.HttpClient, SubscriptionSummary>;
export type UpdateSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Changes the plan tier of an existing subscription.
 *
 * Upgrades take effect immediately. Downgrades are scheduled and the current tier remains unchanged until the end of the billing cycle (calendar month). You cannot update a subscription while a scheduled change is pending. To make a new change, first cancel the pending change using `CancelSubscriptionChange`.
 *
 * This operation replaces the plan tier value. If you omit the optional `usageLevel` field, it is reset to the default.
 */
export declare const updateSubscription: API.OperationMethod<UpdateSubscriptionInput, UpdateSubscriptionOutput, UpdateSubscriptionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=pricing-plan-manager.d.ts.map