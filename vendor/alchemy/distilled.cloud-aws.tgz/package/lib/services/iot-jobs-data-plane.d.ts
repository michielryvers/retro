import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const CertificateValidationException_base: S.TaggedErrorClass<"CertificateValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CertificateValidationException extends /*@__PURE__*/ CertificateValidationException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidStateTransitionException_base: S.TaggedErrorClass<"InvalidStateTransitionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidStateTransitionException extends /*@__PURE__*/ InvalidStateTransitionException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TerminalStateException_base: S.TaggedErrorClass<"TerminalStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TerminalStateException extends /*@__PURE__*/ TerminalStateException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly payload: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DescribeJobExecutionJobId = string;
export type ThingName = string;
export type IncludeJobDocument = boolean;
export type ExecutionNumber = number;
export interface DescribeJobExecutionRequest {
    jobId: string;
    thingName: string;
    includeJobDocument?: boolean;
    executionNumber?: number;
}
export type JobId = string;
export type JobExecutionStatus = "QUEUED" | "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | "TIMED_OUT" | "REJECTED" | "REMOVED" | "CANCELED" | (string & {});
export type DetailsKey = string;
export type DetailsValue = string;
export type DetailsMap = {
    [key: string]: string | undefined;
};
export type QueuedAt = number;
export type StartedAt = number;
export type LastUpdatedAt = number;
export type ApproximateSecondsBeforeTimedOut = number;
export type VersionNumber = number;
export type JobDocument = string;
export interface JobExecution {
    jobId?: string;
    thingName?: string;
    status?: JobExecutionStatus;
    statusDetails?: {
        [key: string]: string | undefined;
    };
    queuedAt?: number;
    startedAt?: number;
    lastUpdatedAt?: number;
    approximateSecondsBeforeTimedOut?: number;
    versionNumber?: number;
    executionNumber?: number;
    jobDocument?: string;
}
export interface DescribeJobExecutionResponse {
    execution?: JobExecution;
}
export interface GetPendingJobExecutionsRequest {
    thingName: string;
}
export interface JobExecutionSummary {
    jobId?: string;
    queuedAt?: number;
    startedAt?: number;
    lastUpdatedAt?: number;
    versionNumber?: number;
    executionNumber?: number;
}
export type JobExecutionSummaryList = JobExecutionSummary[];
export interface GetPendingJobExecutionsResponse {
    inProgressJobs?: JobExecutionSummary[];
    queuedJobs?: JobExecutionSummary[];
}
export type TargetArn = string;
export type CommandArn = string;
export type CommandParameterName = string;
export type StringParameterValue = string;
export type BooleanParameterValue = boolean;
export type IntegerParameterValue = number;
export type LongParameterValue = number;
export type DoubleParameterValue = number;
export type BinaryParameterValue = Uint8Array;
export type UnsignedLongParameterValue = string;
export interface CommandParameterValue {
    S?: string;
    B?: boolean;
    I?: number;
    L?: number;
    D?: number;
    BIN?: Uint8Array;
    UL?: string;
}
export type CommandExecutionParameterMap = {
    [key: string]: CommandParameterValue | undefined;
};
export type CommandExecutionTimeoutInSeconds = number;
export type ClientRequestTokenV2 = string;
export interface StartCommandExecutionRequest {
    targetArn: string;
    commandArn: string;
    parameters?: {
        [key: string]: CommandParameterValue | undefined;
    };
    executionTimeoutSeconds?: number;
    clientToken?: string;
}
export type CommandExecutionId = string;
export interface StartCommandExecutionResponse {
    executionId?: string;
}
export type StepTimeoutInMinutes = number;
export interface StartNextPendingJobExecutionRequest {
    thingName: string;
    statusDetails?: {
        [key: string]: string | undefined;
    };
    stepTimeoutInMinutes?: number;
}
export interface StartNextPendingJobExecutionResponse {
    execution?: JobExecution;
}
export type ExpectedVersion = number;
export type IncludeExecutionState = boolean;
export interface UpdateJobExecutionRequest {
    jobId: string;
    thingName: string;
    status: JobExecutionStatus;
    statusDetails?: {
        [key: string]: string | undefined;
    };
    stepTimeoutInMinutes?: number;
    expectedVersion?: number;
    includeJobExecutionState?: boolean;
    includeJobDocument?: boolean;
    executionNumber?: number;
}
export interface JobExecutionState {
    status?: JobExecutionStatus;
    statusDetails?: {
        [key: string]: string | undefined;
    };
    versionNumber?: number;
}
export interface UpdateJobExecutionResponse {
    executionState?: JobExecutionState;
    jobDocument?: string;
}
export type ErrorMessage = string;
export type BinaryBlob = Uint8Array;
export type ResourceId = string;
export type DescribeJobExecutionError = CertificateValidationException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | TerminalStateException | ThrottlingException | CommonErrors;
/**
 * Gets details of a job execution.
 *
 * Requires permission to access the DescribeJobExecution action.
 */
export declare const describeJobExecution: API.OperationMethod<DescribeJobExecutionRequest, DescribeJobExecutionResponse, DescribeJobExecutionError, Credentials | HttpClient.HttpClient>;
export type GetPendingJobExecutionsError = CertificateValidationException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets the list of all jobs for a thing that are not in a terminal status.
 *
 * Requires permission to access the GetPendingJobExecutions action.
 */
export declare const getPendingJobExecutions: API.OperationMethod<GetPendingJobExecutionsRequest, GetPendingJobExecutionsResponse, GetPendingJobExecutionsError, Credentials | HttpClient.HttpClient>;
export type StartCommandExecutionError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Using the command created with the `CreateCommand` API, start a command
 * execution on a specific device.
 */
export declare const startCommandExecution: API.OperationMethod<StartCommandExecutionRequest, StartCommandExecutionResponse, StartCommandExecutionError, Credentials | HttpClient.HttpClient>;
export type StartNextPendingJobExecutionError = CertificateValidationException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets and starts the next pending (status IN_PROGRESS or QUEUED) job execution for a
 * thing.
 *
 * Requires permission to access the StartNextPendingJobExecution action.
 */
export declare const startNextPendingJobExecution: API.OperationMethod<StartNextPendingJobExecutionRequest, StartNextPendingJobExecutionResponse, StartNextPendingJobExecutionError, Credentials | HttpClient.HttpClient>;
export type UpdateJobExecutionError = CertificateValidationException | InvalidRequestException | InvalidStateTransitionException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates the status of a job execution.
 *
 * Requires permission to access the UpdateJobExecution action.
 */
export declare const updateJobExecution: API.OperationMethod<UpdateJobExecutionRequest, UpdateJobExecutionResponse, UpdateJobExecutionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iot-jobs-data-plane.d.ts.map