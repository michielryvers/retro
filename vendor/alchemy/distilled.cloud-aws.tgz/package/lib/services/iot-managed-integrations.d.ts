import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ClientToken = string;
export type ConnectorDestinationId = string;
export type AccountAssociationName = string;
export type AccountAssociationDescription = string;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export type AuthMaterialName = string;
export interface GeneralAuthorizationName {
    AuthMaterialName?: string;
}
export interface CreateAccountAssociationRequest {
    ClientToken?: string;
    ConnectorDestinationId: string;
    Name?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    GeneralAuthorization?: GeneralAuthorizationName;
}
export type OAuthAuthorizationUrlOutput = string | redacted.Redacted<string>;
export type AccountAssociationId = string;
export type AssociationState = "ASSOCIATION_IN_PROGRESS" | "ASSOCIATION_FAILED" | "ASSOCIATION_SUCCEEDED" | "ASSOCIATION_DELETING" | "REFRESH_TOKEN_EXPIRED" | (string & {});
export type AccountAssociationArn = string;
export interface CreateAccountAssociationResponse {
    OAuthAuthorizationUrl: string | redacted.Redacted<string>;
    AccountAssociationId: string;
    AssociationState: AssociationState;
    Arn?: string;
}
export type DisplayName = string;
export type LambdaArn = string;
export interface LambdaConfig {
    arn: string;
}
export interface EndpointConfig {
    lambda?: LambdaConfig;
}
export type CloudConnectorDescription = string;
export type EndpointType = "LAMBDA" | (string & {});
export interface CreateCloudConnectorRequest {
    Name: string;
    EndpointConfig: EndpointConfig;
    Description?: string;
    EndpointType?: EndpointType;
    ClientToken?: string;
}
export type CloudConnectorId = string;
export interface CreateCloudConnectorResponse {
    Id?: string;
}
export type ConnectorDestinationName = string;
export type ConnectorDestinationDescription = string;
export type AuthType = "OAUTH" | (string & {});
export type AuthUrl = string;
export type TokenUrl = string;
export type TokenEndpointAuthenticationScheme = "HTTP_BASIC" | "REQUEST_BODY_CREDENTIALS" | (string & {});
export interface ProactiveRefreshTokenRenewal {
    enabled?: boolean;
    DaysBeforeRenewal?: number;
}
export interface OAuthConfig {
    authUrl: string;
    tokenUrl: string;
    scope?: string;
    tokenEndpointAuthenticationScheme: TokenEndpointAuthenticationScheme;
    oAuthCompleteRedirectUrl?: string;
    proactiveRefreshTokenRenewal?: ProactiveRefreshTokenRenewal;
}
export type SecretsManagerArn = string;
export type SecretsManagerVersionId = string;
export interface SecretsManager {
    arn: string;
    versionId: string;
}
export interface AuthMaterial {
    SecretsManager: SecretsManager;
    AuthMaterialName: string;
}
export type AuthMaterials = AuthMaterial[];
export interface AuthConfig {
    oAuth?: OAuthConfig;
    GeneralAuthorization?: AuthMaterial[];
}
export interface CreateConnectorDestinationRequest {
    Name?: string;
    Description?: string;
    CloudConnectorId: string;
    AuthType?: AuthType;
    AuthConfig: AuthConfig;
    SecretsManager?: SecretsManager;
    ClientToken?: string;
}
export interface CreateConnectorDestinationResponse {
    Id?: string;
}
export type CredentialLockerName = string | redacted.Redacted<string>;
export interface CreateCredentialLockerRequest {
    Name?: string | redacted.Redacted<string>;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type CredentialLockerId = string;
export type CredentialLockerArn = string;
export type CredentialLockerCreatedAt = Date;
export interface CreateCredentialLockerResponse {
    Id?: string;
    Arn?: string;
    CreatedAt?: Date;
}
export type DeliveryDestinationArn = string;
export type DeliveryDestinationType = "KINESIS" | (string & {});
export type DestinationName = string;
export type DeliveryDestinationRoleArn = string;
export type DestinationDescription = string;
export interface CreateDestinationRequest {
    DeliveryDestinationArn: string;
    DeliveryDestinationType: DeliveryDestinationType;
    Name: string;
    RoleArn: string;
    ClientToken?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateDestinationResponse {
    Name?: string;
}
export type SmartHomeResourceType = string;
export type SmartHomeResourceId = string;
export type LogLevel = "DEBUG" | "ERROR" | "INFO" | "WARN" | (string & {});
export interface CreateEventLogConfigurationRequest {
    ResourceType: string;
    ResourceId?: string;
    EventLogLevel: LogLevel;
    ClientToken?: string;
}
export type LogConfigurationId = string;
export interface CreateEventLogConfigurationResponse {
    Id?: string;
}
export type Role = "CONTROLLER" | "DEVICE" | (string & {});
export type Owner = string | redacted.Redacted<string>;
export type AuthMaterialString = string | redacted.Redacted<string>;
export type AuthMaterialType = "CUSTOM_PROTOCOL_QR_BAR_CODE" | "WIFI_SETUP_QR_BAR_CODE" | "ZWAVE_QR_BAR_CODE" | "ZIGBEE_QR_BAR_CODE" | "DISCOVERED_DEVICE" | "PRE_ONBOARDED_CLOUD" | (string & {});
export type EnableAsProvisioner = boolean;
export type EnableAsProvisionee = boolean;
export type TimeoutInMinutes = number;
export interface WiFiSimpleSetupConfiguration {
    EnableAsProvisioner?: boolean;
    EnableAsProvisionee?: boolean;
    TimeoutInMinutes?: number;
}
export type SerialNumber = string | redacted.Redacted<string>;
export type Brand = string | redacted.Redacted<string>;
export type Model = string | redacted.Redacted<string>;
export type Name = string;
export type CapabilityReportVersion = string;
export type NodeId = string;
export type EndpointId = string;
export type DeviceType = string;
export type DeviceTypes = string[];
export type SchemaVersionedId = string;
export type CapabilityName = string;
export type CapabilityVersion = string;
export type PropertyName = string;
export type CapabilityReportProperties = string[];
export type ActionName = string;
export type CapabilityReportActions = string[];
export type EventName = string;
export type CapabilityReportEvents = string[];
export interface CapabilityReportCapability {
    id: string;
    name: string;
    version: string;
    properties: string[];
    actions: string[];
    events: string[];
}
export type CapabilityReportCapabilities = CapabilityReportCapability[];
export interface CapabilityReportEndpoint {
    id: string;
    deviceTypes: string[];
    capabilities: CapabilityReportCapability[];
}
export type CapabilityReportEndpoints = CapabilityReportEndpoint[];
export interface CapabilityReport {
    version: string;
    nodeId?: string;
    endpoints: CapabilityReportEndpoint[];
}
export type SchemaVersionFormat = "AWS" | "ZCL" | "CONNECTOR" | (string & {});
export type ExtrinsicSchemaId = string;
export type MatterCapabilityReportClusterRevisionId = number;
export type ValidationSchema = unknown;
export interface CapabilitySchemaItem {
    Format: SchemaVersionFormat;
    CapabilityId: string;
    ExtrinsicId: string;
    ExtrinsicVersion: number;
    Schema: any;
}
export type CapabilitySchemas = CapabilitySchemaItem[];
export type Capabilities = string;
export type Classification = string | redacted.Redacted<string>;
export type AttributeName = string;
export type AttributeValue = string;
export type MetaData = {
    [key: string]: string | undefined;
};
export interface CreateManagedThingRequest {
    Role: Role;
    Owner?: string | redacted.Redacted<string>;
    CredentialLockerId?: string;
    AuthenticationMaterial: string | redacted.Redacted<string>;
    AuthenticationMaterialType: AuthMaterialType;
    WiFiSimpleSetupConfiguration?: WiFiSimpleSetupConfiguration;
    SerialNumber?: string | redacted.Redacted<string>;
    Brand?: string | redacted.Redacted<string>;
    Model?: string | redacted.Redacted<string>;
    Name?: string;
    CapabilityReport?: CapabilityReport;
    CapabilitySchemas?: CapabilitySchemaItem[];
    Capabilities?: string;
    ClientToken?: string;
    Classification?: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    };
    MetaData?: {
        [key: string]: string | undefined;
    };
}
export type ManagedThingId = string;
export type ManagedThingArn = string;
export type CreatedAt = Date;
export interface CreateManagedThingResponse {
    Id?: string;
    Arn?: string;
    CreatedAt?: Date;
}
export type EventType = "DEVICE_COMMAND" | "DEVICE_COMMAND_REQUEST" | "DEVICE_DISCOVERY_STATUS" | "DEVICE_EVENT" | "DEVICE_LIFE_CYCLE" | "DEVICE_STATE" | "DEVICE_OTA" | "DEVICE_WSS" | "CONNECTOR_ASSOCIATION" | "ACCOUNT_ASSOCIATION" | "CONNECTOR_ERROR_REPORT" | (string & {});
export interface CreateNotificationConfigurationRequest {
    EventType: EventType;
    DestinationName: string;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateNotificationConfigurationResponse {
    EventType?: EventType;
}
export type OtaDescription = string;
export type S3Url = string;
export type OtaProtocol = "HTTP" | (string & {});
export type Target = string[];
export type OtaTaskConfigurationId = string;
export type OtaMechanism = "PUSH" | (string & {});
export type OtaType = "ONE_TIME" | "CONTINUOUS" | (string & {});
export type OtaTargetQueryString = string;
export type SchedulingConfigEndBehavior = "STOP_ROLLOUT" | "CANCEL" | "FORCE_CANCEL" | (string & {});
export type EndTime = string;
export type DurationInMinutes = number;
export type StartTime = string;
export interface ScheduleMaintenanceWindow {
    DurationInMinutes?: number;
    StartTime?: string;
}
export type ScheduleMaintenanceWindowList = ScheduleMaintenanceWindow[];
export type ScheduleStartTime = string;
export interface OtaTaskSchedulingConfig {
    EndBehavior?: SchedulingConfigEndBehavior;
    EndTime?: string;
    MaintenanceWindows?: ScheduleMaintenanceWindow[];
    StartTime?: string;
}
export type RetryCriteriaFailureType = "FAILED" | "TIMED_OUT" | "ALL" | (string & {});
export type MinNumberOfRetries = number;
export interface RetryConfigCriteria {
    FailureType?: RetryCriteriaFailureType;
    MinNumberOfRetries?: number;
}
export type RetryConfigCriteriaList = RetryConfigCriteria[];
export interface OtaTaskExecutionRetryConfig {
    RetryConfigCriteria?: RetryConfigCriteria[];
}
export interface CreateOtaTaskRequest {
    Description?: string;
    S3Url: string;
    Protocol?: OtaProtocol;
    Target?: string[];
    TaskConfigurationId?: string;
    OtaMechanism?: OtaMechanism;
    OtaType: OtaType;
    OtaTargetQueryString?: string;
    ClientToken?: string;
    OtaSchedulingConfig?: OtaTaskSchedulingConfig;
    OtaTaskExecutionRetryConfig?: OtaTaskExecutionRetryConfig;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type OtaTaskId = string;
export type OtaTaskArn = string;
export interface CreateOtaTaskResponse {
    TaskId?: string;
    TaskArn?: string;
    Description?: string;
}
export type OtaTaskConfigurationName = string | redacted.Redacted<string>;
export type AbortCriteriaAction = "CANCEL" | (string & {});
export type AbortCriteriaFailureType = "FAILED" | "REJECTED" | "TIMED_OUT" | "ALL" | (string & {});
export type MinNumberOfExecutedThings = number;
export type ThresholdPercentage = number;
export interface AbortConfigCriteria {
    Action?: AbortCriteriaAction;
    FailureType?: AbortCriteriaFailureType;
    MinNumberOfExecutedThings?: number;
    ThresholdPercentage?: number;
}
export type AbortConfigCriteriaList = AbortConfigCriteria[];
export interface OtaTaskAbortConfig {
    AbortConfigCriteriaList?: AbortConfigCriteria[];
}
export type BaseRatePerMinute = number;
export type IncrementFactor = number;
export type NumberOfNotifiedThings = number;
export type NumberOfSucceededThings = number;
export interface RolloutRateIncreaseCriteria {
    numberOfNotifiedThings?: number;
    numberOfSucceededThings?: number;
}
export interface ExponentialRolloutRate {
    BaseRatePerMinute?: number;
    IncrementFactor?: number;
    RateIncreaseCriteria?: RolloutRateIncreaseCriteria;
}
export type MaximumPerMinute = number;
export interface OtaTaskExecutionRolloutConfig {
    ExponentialRolloutRate?: ExponentialRolloutRate;
    MaximumPerMinute?: number;
}
export type InProgressTimeoutInMinutes = number;
export interface OtaTaskTimeoutConfig {
    InProgressTimeoutInMinutes?: number;
}
export interface PushConfig {
    AbortConfig?: OtaTaskAbortConfig;
    RolloutConfig?: OtaTaskExecutionRolloutConfig;
    TimeoutConfig?: OtaTaskTimeoutConfig;
}
export interface CreateOtaTaskConfigurationRequest {
    Description?: string;
    Name?: string | redacted.Redacted<string>;
    PushConfig?: PushConfig;
    ClientToken?: string;
}
export interface CreateOtaTaskConfigurationResponse {
    TaskConfigurationId?: string;
}
export type ProvisioningType = "FLEET_PROVISIONING" | "JITR" | (string & {});
export type CaCertificate = string | redacted.Redacted<string>;
export type ClaimCertificate = string | redacted.Redacted<string>;
export type ProvisioningProfileName = string;
export interface CreateProvisioningProfileRequest {
    ProvisioningType: ProvisioningType;
    CaCertificate?: string | redacted.Redacted<string>;
    ClaimCertificate?: string | redacted.Redacted<string>;
    Name?: string;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ProvisioningProfileArn = string;
export type ProvisioningProfileId = string;
export type ProvisioningProfileStatus = "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "CREATED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export type ClaimCertificatePrivateKey = string | redacted.Redacted<string>;
export interface CreateProvisioningProfileResponse {
    Arn?: string;
    Name?: string;
    ProvisioningType?: ProvisioningType;
    Id?: string;
    Status?: ProvisioningProfileStatus;
    ClaimCertificate?: string | redacted.Redacted<string>;
    ClaimCertificatePrivateKey?: string | redacted.Redacted<string>;
}
export interface DeleteAccountAssociationRequest {
    AccountAssociationId: string;
}
export interface DeleteAccountAssociationResponse {
}
export interface DeleteCloudConnectorRequest {
    Identifier: string;
}
export interface DeleteCloudConnectorResponse {
}
export interface DeleteConnectorDestinationRequest {
    Identifier: string;
}
export interface DeleteConnectorDestinationResponse {
}
export interface DeleteCredentialLockerRequest {
    Identifier: string;
}
export interface DeleteCredentialLockerResponse {
}
export interface DeleteDestinationRequest {
    Name: string;
}
export interface DeleteDestinationResponse {
}
export interface DeleteEventLogConfigurationRequest {
    Id: string;
}
export interface DeleteEventLogConfigurationResponse {
}
export interface DeleteManagedThingRequest {
    Identifier: string;
    Force?: boolean;
}
export interface DeleteManagedThingResponse {
}
export interface DeleteNotificationConfigurationRequest {
    EventType: EventType;
}
export interface DeleteNotificationConfigurationResponse {
}
export interface DeleteOtaTaskRequest {
    Identifier: string;
}
export interface DeleteOtaTaskResponse {
}
export interface DeleteOtaTaskConfigurationRequest {
    Identifier: string;
}
export interface DeleteOtaTaskConfigurationResponse {
}
export interface DeleteProvisioningProfileRequest {
    Identifier: string;
}
export interface DeleteProvisioningProfileResponse {
}
export interface DeregisterAccountAssociationRequest {
    ManagedThingId: string;
    AccountAssociationId: string;
}
export interface DeregisterAccountAssociationResponse {
}
export interface GetAccountAssociationRequest {
    AccountAssociationId: string;
}
export type AccountAssociationErrorMessage = string;
export interface GetAccountAssociationResponse {
    AccountAssociationId: string;
    AssociationState: AssociationState;
    ErrorMessage?: string;
    ConnectorDestinationId?: string;
    Name?: string;
    Description?: string;
    Arn?: string;
    OAuthAuthorizationUrl: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    };
    GeneralAuthorization?: GeneralAuthorizationName;
}
export interface GetCloudConnectorRequest {
    Identifier: string;
}
export type CloudConnectorType = "LISTED" | "UNLISTED" | (string & {});
export interface GetCloudConnectorResponse {
    Name: string;
    EndpointConfig: EndpointConfig;
    Description?: string;
    EndpointType?: EndpointType;
    Id?: string;
    Type?: CloudConnectorType;
}
export interface GetConnectorDestinationRequest {
    Identifier: string;
}
export type OAuthCompleteRedirectUrl = string;
export interface GetConnectorDestinationResponse {
    Name?: string;
    Description?: string;
    CloudConnectorId?: string;
    Id?: string;
    AuthType?: AuthType;
    AuthConfig?: AuthConfig;
    SecretsManager?: SecretsManager;
    OAuthCompleteRedirectUrl?: string;
}
export interface GetCredentialLockerRequest {
    Identifier: string;
}
export interface GetCredentialLockerResponse {
    Id?: string;
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetCustomEndpointRequest {
}
export type EndpointAddress = string;
export interface GetCustomEndpointResponse {
    EndpointAddress: string;
}
export interface GetDefaultEncryptionConfigurationRequest {
}
export type ConfigurationErrorCode = string;
export type ConfigurationErrorMessage = string;
export interface ConfigurationError {
    code?: string;
    message?: string;
}
export type ConfigurationState = "ENABLED" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | (string & {});
export interface ConfigurationStatus {
    error?: ConfigurationError;
    state: ConfigurationState;
}
export type EncryptionType = "MANAGED_INTEGRATIONS_DEFAULT_ENCRYPTION" | "CUSTOMER_KEY_ENCRYPTION" | (string & {});
export type KmsKeyArn = string;
export interface GetDefaultEncryptionConfigurationResponse {
    configurationStatus: ConfigurationStatus;
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
}
export interface GetDestinationRequest {
    Name: string;
}
export type DestinationCreatedAt = Date;
export type DestinationUpdatedAt = Date;
export interface GetDestinationResponse {
    Description?: string;
    DeliveryDestinationArn?: string;
    DeliveryDestinationType?: DeliveryDestinationType;
    Name?: string;
    RoleArn?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type DeviceDiscoveryId = string;
export interface GetDeviceDiscoveryRequest {
    Identifier: string;
}
export type DeviceDiscoveryArn = string;
export type DiscoveryType = "ZWAVE" | "ZIGBEE" | "CLOUD" | "CUSTOM" | "CONTROLLER_CAPABILITY_REDISCOVERY" | (string & {});
export type DeviceDiscoveryStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | "TIMED_OUT" | (string & {});
export type DiscoveryStartedAt = Date;
export type ConnectorAssociationId = string;
export type DiscoveryFinishedAt = Date;
export interface GetDeviceDiscoveryResponse {
    Id: string;
    Arn: string;
    DiscoveryType: DiscoveryType;
    Status: DeviceDiscoveryStatus;
    StartedAt: Date;
    ControllerId?: string;
    ConnectorAssociationId?: string;
    AccountAssociationId?: string;
    FinishedAt?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetEventLogConfigurationRequest {
    Id: string;
}
export interface GetEventLogConfigurationResponse {
    Id?: string;
    ResourceType?: string;
    ResourceId?: string;
    EventLogLevel?: LogLevel;
}
export interface GetHubConfigurationRequest {
}
export type HubTokenTimerExpirySettingInSeconds = number;
export type HubConfigurationUpdatedAt = Date;
export interface GetHubConfigurationResponse {
    HubTokenTimerExpirySettingInSeconds?: number;
    UpdatedAt?: Date;
}
export interface GetManagedThingRequest {
    Identifier: string;
}
export type AdvertisedProductId = string;
export type ProvisioningStatus = "UNASSOCIATED" | "PRE_ASSOCIATED" | "DISCOVERED" | "ACTIVATED" | "DELETION_FAILED" | "DELETE_IN_PROGRESS" | "ISOLATED" | "DELETED" | (string & {});
export type UniversalProductCode = string | redacted.Redacted<string>;
export type InternationalArticleNumber = string | redacted.Redacted<string>;
export type ConnectorPolicyId = string;
export type ConnectorDeviceId = string | redacted.Redacted<string>;
export type DeviceSpecificKey = string | redacted.Redacted<string>;
export type MacAddress = string | redacted.Redacted<string>;
export type ParentControllerId = string;
export type UpdatedAt = Date;
export type SetupAt = Date;
export type HubNetworkMode = "STANDARD" | "NETWORK_WIDE_EXCLUSION" | (string & {});
export interface GetManagedThingResponse {
    Id?: string;
    Arn?: string;
    Owner?: string | redacted.Redacted<string>;
    CredentialLockerId?: string;
    AdvertisedProductId?: string;
    Role?: Role;
    ProvisioningStatus?: ProvisioningStatus;
    Name?: string;
    Model?: string | redacted.Redacted<string>;
    Brand?: string | redacted.Redacted<string>;
    SerialNumber?: string | redacted.Redacted<string>;
    UniversalProductCode?: string | redacted.Redacted<string>;
    InternationalArticleNumber?: string | redacted.Redacted<string>;
    ConnectorPolicyId?: string;
    ConnectorDestinationId?: string;
    ConnectorDeviceId?: string | redacted.Redacted<string>;
    DeviceSpecificKey?: string | redacted.Redacted<string>;
    MacAddress?: string | redacted.Redacted<string>;
    ParentControllerId?: string;
    Classification?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ActivatedAt?: Date;
    HubNetworkMode?: HubNetworkMode;
    MetaData?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
    WiFiSimpleSetupConfiguration?: WiFiSimpleSetupConfiguration;
}
export interface GetManagedThingCapabilitiesRequest {
    Identifier: string;
}
export interface GetManagedThingCapabilitiesResponse {
    ManagedThingId?: string;
    Capabilities?: string;
    CapabilityReport?: CapabilityReport;
}
export interface GetManagedThingCertificateRequest {
    Identifier: string;
}
export type CertificatePem = string;
export interface GetManagedThingCertificateResponse {
    ManagedThingId?: string;
    CertificatePem?: string;
}
export interface GetManagedThingConnectivityDataRequest {
    Identifier: string;
}
export type ConnectivityStatus = boolean;
export type ConnectivityTimestamp = Date;
export type DisconnectReasonValue = "AUTH_ERROR" | "CLIENT_INITIATED_DISCONNECT" | "CLIENT_ERROR" | "CONNECTION_LOST" | "DUPLICATE_CLIENTID" | "FORBIDDEN_ACCESS" | "MQTT_KEEP_ALIVE_TIMEOUT" | "SERVER_ERROR" | "SERVER_INITIATED_DISCONNECT" | "THROTTLED" | "WEBSOCKET_TTL_EXPIRATION" | "CUSTOMAUTH_TTL_EXPIRATION" | "UNKNOWN" | "NONE" | (string & {});
export interface GetManagedThingConnectivityDataResponse {
    ManagedThingId?: string;
    Connected?: boolean;
    Timestamp?: Date;
    DisconnectReason?: DisconnectReasonValue;
}
export interface GetManagedThingMetaDataRequest {
    Identifier: string;
}
export interface GetManagedThingMetaDataResponse {
    ManagedThingId?: string;
    MetaData?: {
        [key: string]: string | undefined;
    };
}
export interface GetManagedThingStateRequest {
    ManagedThingId: string;
}
export type CapabilityProperties = unknown;
export interface StateCapability {
    id: string;
    name: string;
    version: string;
    properties?: any;
}
export type StateCapabilities = StateCapability[];
export interface StateEndpoint {
    endpointId: string;
    capabilities: StateCapability[];
}
export type StateEndpoints = StateEndpoint[];
export interface GetManagedThingStateResponse {
    Endpoints: StateEndpoint[];
}
export interface GetNotificationConfigurationRequest {
    EventType: EventType;
}
export type NotificationConfigurationCreatedAt = Date;
export type NotificationConfigurationUpdatedAt = Date;
export interface GetNotificationConfigurationResponse {
    EventType?: EventType;
    DestinationName?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetOtaTaskRequest {
    Identifier: string;
}
export type LastUpdatedAt = Date;
export interface TaskProcessingDetails {
    NumberOfCanceledThings?: number;
    NumberOfFailedThings?: number;
    NumberOfInProgressThings?: number;
    numberOfQueuedThings?: number;
    numberOfRejectedThings?: number;
    numberOfRemovedThings?: number;
    numberOfSucceededThings?: number;
    numberOfTimedOutThings?: number;
    processingTargets?: string[];
}
export type OtaStatus = "IN_PROGRESS" | "CANCELED" | "COMPLETED" | "DELETION_IN_PROGRESS" | "SCHEDULED" | (string & {});
export interface GetOtaTaskResponse {
    TaskId?: string;
    TaskArn?: string;
    Description?: string;
    S3Url?: string;
    Protocol?: OtaProtocol;
    OtaType?: OtaType;
    OtaTargetQueryString?: string;
    OtaMechanism?: OtaMechanism;
    Target?: string[];
    CreatedAt?: Date;
    LastUpdatedAt?: Date;
    TaskConfigurationId?: string;
    TaskProcessingDetails?: TaskProcessingDetails;
    OtaSchedulingConfig?: OtaTaskSchedulingConfig;
    OtaTaskExecutionRetryConfig?: OtaTaskExecutionRetryConfig;
    Status?: OtaStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetOtaTaskConfigurationRequest {
    Identifier: string;
}
export interface GetOtaTaskConfigurationResponse {
    TaskConfigurationId?: string;
    Name?: string | redacted.Redacted<string>;
    PushConfig?: PushConfig;
    Description?: string;
    CreatedAt?: Date;
}
export interface GetProvisioningProfileRequest {
    Identifier: string;
}
export interface GetProvisioningProfileResponse {
    Arn?: string;
    Name?: string;
    ProvisioningType?: ProvisioningType;
    Id?: string;
    Status?: ProvisioningProfileStatus;
    ClaimCertificate?: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetRuntimeLogConfigurationRequest {
    ManagedThingId: string;
}
export type LocalStoreLocation = string;
export type LocalStoreFileRotationMaxFiles = number;
export type LocalStoreFileRotationMaxBytes = number;
export type UploadLog = boolean;
export type UploadPeriodMinutes = number;
export type DeleteLocalStoreAfterUpload = boolean;
export interface RuntimeLogConfigurations {
    LogLevel?: LogLevel;
    LogFlushLevel?: LogLevel;
    LocalStoreLocation?: string;
    LocalStoreFileRotationMaxFiles?: number;
    LocalStoreFileRotationMaxBytes?: number;
    UploadLog?: boolean;
    UploadPeriodMinutes?: number;
    DeleteLocalStoreAfterUpload?: boolean;
}
export interface GetRuntimeLogConfigurationResponse {
    ManagedThingId?: string;
    RuntimeLogConfigurations?: RuntimeLogConfigurations;
}
export type SchemaVersionType = "capability" | "definition" | (string & {});
export interface GetSchemaVersionRequest {
    Type: SchemaVersionType;
    SchemaVersionedId: string;
    Format?: SchemaVersionFormat;
}
export type SchemaId = string;
export type SchemaVersionDescription = string;
export type SchemaVersionNamespaceName = string;
export type SchemaVersionVersion = string;
export type SchemaVersionVisibility = "PUBLIC" | "PRIVATE" | (string & {});
export type SchemaVersionSchema = unknown;
export interface GetSchemaVersionResponse {
    SchemaId?: string;
    Type?: SchemaVersionType;
    Description?: string;
    Namespace?: string;
    SemanticVersion?: string;
    Visibility?: SchemaVersionVisibility;
    Schema?: any;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListAccountAssociationsRequest {
    ConnectorDestinationId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface AccountAssociationItem {
    AccountAssociationId: string;
    AssociationState: AssociationState;
    ErrorMessage?: string;
    ConnectorDestinationId?: string;
    Name?: string;
    Description?: string;
    Arn?: string;
}
export type AccountAssociationListDefinition = AccountAssociationItem[];
export interface ListAccountAssociationsResponse {
    Items?: AccountAssociationItem[];
    NextToken?: string;
}
export interface ListCloudConnectorsRequest {
    Type?: CloudConnectorType;
    LambdaArn?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ConnectorItem {
    Name: string;
    EndpointConfig: EndpointConfig;
    Description?: string;
    EndpointType?: EndpointType;
    Id?: string;
    Type?: CloudConnectorType;
}
export type ConnectorList = ConnectorItem[];
export interface ListCloudConnectorsResponse {
    Items?: ConnectorItem[];
    NextToken?: string;
}
export interface ListConnectorDestinationsRequest {
    CloudConnectorId?: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ConnectorDestinationSummary {
    Name?: string;
    Description?: string;
    CloudConnectorId?: string;
    Id?: string;
}
export type ConnectorDestinationListDefinition = ConnectorDestinationSummary[];
export interface ListConnectorDestinationsResponse {
    ConnectorDestinationList?: ConnectorDestinationSummary[];
    NextToken?: string;
}
export interface ListCredentialLockersRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface CredentialLockerSummary {
    Id?: string;
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
}
export type CredentialLockerListDefinition = CredentialLockerSummary[];
export interface ListCredentialLockersResponse {
    Items?: CredentialLockerSummary[];
    NextToken?: string;
}
export interface ListDestinationsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface DestinationSummary {
    Description?: string;
    DeliveryDestinationArn?: string;
    DeliveryDestinationType?: DeliveryDestinationType;
    Name?: string;
    RoleArn?: string;
}
export type DestinationListDefinition = DestinationSummary[];
export interface ListDestinationsResponse {
    DestinationList?: DestinationSummary[];
    NextToken?: string;
}
export interface ListDeviceDiscoveriesRequest {
    NextToken?: string;
    MaxResults?: number;
    TypeFilter?: DiscoveryType;
    StatusFilter?: DeviceDiscoveryStatus;
}
export interface DeviceDiscoverySummary {
    Id?: string;
    DiscoveryType?: DiscoveryType;
    Status?: DeviceDiscoveryStatus;
}
export type DeviceDiscoveryListDefinition = DeviceDiscoverySummary[];
export interface ListDeviceDiscoveriesResponse {
    Items?: DeviceDiscoverySummary[];
    NextToken?: string;
}
export interface ListDiscoveredDevicesRequest {
    Identifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export type ConnectorDeviceName = string;
export type DeviceTypeList = string[];
export type DiscoveryModification = "DISCOVERED" | "UPDATED" | "NO_CHANGE" | (string & {});
export type DiscoveredAt = Date;
export interface DiscoveredDeviceSummary {
    ConnectorDeviceId?: string | redacted.Redacted<string>;
    ConnectorDeviceName?: string;
    DeviceTypes?: string[];
    ManagedThingId?: string;
    Modification?: DiscoveryModification;
    DiscoveredAt?: Date;
    Brand?: string | redacted.Redacted<string>;
    Model?: string | redacted.Redacted<string>;
    AuthenticationMaterial?: string | redacted.Redacted<string>;
}
export type DiscoveredDeviceListDefinition = DiscoveredDeviceSummary[];
export interface ListDiscoveredDevicesResponse {
    Items?: DiscoveredDeviceSummary[];
    NextToken?: string;
}
export interface ListEventLogConfigurationsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface EventLogConfigurationSummary {
    Id?: string;
    ResourceType?: string;
    ResourceId?: string;
    EventLogLevel?: LogLevel;
}
export type EventLogConfigurationListDefinition = EventLogConfigurationSummary[];
export interface ListEventLogConfigurationsResponse {
    EventLogConfigurationList?: EventLogConfigurationSummary[];
    NextToken?: string;
}
export interface ListManagedThingAccountAssociationsRequest {
    ManagedThingId?: string;
    AccountAssociationId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ManagedThingAssociationStatus = "PRE_ASSOCIATED" | "ASSOCIATED" | (string & {});
export interface ManagedThingAssociation {
    ManagedThingId?: string;
    AccountAssociationId?: string;
    ManagedThingAssociationStatus?: ManagedThingAssociationStatus;
}
export type ManagedThingAssociationList = ManagedThingAssociation[];
export interface ListManagedThingAccountAssociationsResponse {
    Items?: ManagedThingAssociation[];
    NextToken?: string;
}
export interface ListManagedThingsRequest {
    OwnerFilter?: string | redacted.Redacted<string>;
    CredentialLockerFilter?: string;
    RoleFilter?: Role;
    ParentControllerIdentifierFilter?: string;
    ConnectorPolicyIdFilter?: string;
    ConnectorDestinationIdFilter?: string;
    ConnectorDeviceIdFilter?: string | redacted.Redacted<string>;
    SerialNumberFilter?: string | redacted.Redacted<string>;
    ProvisioningStatusFilter?: ProvisioningStatus;
    NextToken?: string;
    MaxResults?: number;
}
export interface ManagedThingSummary {
    Id?: string;
    Arn?: string;
    AdvertisedProductId?: string;
    Brand?: string | redacted.Redacted<string>;
    Classification?: string | redacted.Redacted<string>;
    ConnectorDeviceId?: string | redacted.Redacted<string>;
    ConnectorPolicyId?: string;
    ConnectorDestinationId?: string;
    Model?: string | redacted.Redacted<string>;
    Name?: string;
    Owner?: string | redacted.Redacted<string>;
    CredentialLockerId?: string;
    ParentControllerId?: string;
    ProvisioningStatus?: ProvisioningStatus;
    Role?: Role;
    SerialNumber?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ActivatedAt?: Date;
}
export type ManagedThingListDefinition = ManagedThingSummary[];
export interface ListManagedThingsResponse {
    Items?: ManagedThingSummary[];
    NextToken?: string;
}
export type CapabilityId = string;
export interface ListManagedThingSchemasRequest {
    Identifier: string;
    EndpointIdFilter?: string;
    CapabilityIdFilter?: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ManagedThingSchemaListItem {
    EndpointId?: string;
    CapabilityId?: string;
    Schema?: any;
}
export type ManagedThingSchemaListDefinition = ManagedThingSchemaListItem[];
export interface ListManagedThingSchemasResponse {
    Items?: ManagedThingSchemaListItem[];
    NextToken?: string;
}
export interface ListNotificationConfigurationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface NotificationConfigurationSummary {
    EventType?: EventType;
    DestinationName?: string;
}
export type NotificationConfigurationListDefinition = NotificationConfigurationSummary[];
export interface ListNotificationConfigurationsResponse {
    NotificationConfigurationList?: NotificationConfigurationSummary[];
    NextToken?: string;
}
export interface ListOtaTaskConfigurationsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface OtaTaskConfigurationSummary {
    TaskConfigurationId?: string;
    Name?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
}
export type OtaTaskConfigurationListDefinition = OtaTaskConfigurationSummary[];
export interface ListOtaTaskConfigurationsResponse {
    Items?: OtaTaskConfigurationSummary[];
    NextToken?: string;
}
export type OtaNextToken = string;
export interface ListOtaTaskExecutionsRequest {
    Identifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export type ExecutionNumber = number;
export type QueuedAt = Date;
export type RetryAttempt = number;
export type StartedAt = Date;
export type OtaTaskExecutionStatus = "QUEUED" | "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | "TIMED_OUT" | "REJECTED" | "REMOVED" | "CANCELED" | (string & {});
export interface OtaTaskExecutionSummary {
    ExecutionNumber?: number;
    LastUpdatedAt?: Date;
    QueuedAt?: Date;
    RetryAttempt?: number;
    StartedAt?: Date;
    Status?: OtaTaskExecutionStatus;
}
export interface OtaTaskExecutionSummaries {
    TaskExecutionSummary?: OtaTaskExecutionSummary;
    ManagedThingId?: string;
}
export type OtaTaskExecutionSummariesListDefinition = OtaTaskExecutionSummaries[];
export interface ListOtaTaskExecutionsResponse {
    ExecutionSummaries?: OtaTaskExecutionSummaries[];
    NextToken?: string;
}
export interface ListOtaTasksRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface OtaTaskSummary {
    TaskId?: string;
    TaskArn?: string;
    CreatedAt?: Date;
    LastUpdatedAt?: Date;
    TaskConfigurationId?: string;
    Status?: OtaStatus;
}
export type OtaTaskListDefinition = OtaTaskSummary[];
export interface ListOtaTasksResponse {
    Tasks?: OtaTaskSummary[];
    NextToken?: string;
}
export interface ListProvisioningProfilesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface ProvisioningProfileSummary {
    Name?: string;
    Id?: string;
    Arn?: string;
    ProvisioningType?: ProvisioningType;
    Status?: ProvisioningProfileStatus;
}
export type ProvisioningProfileListDefinition = ProvisioningProfileSummary[];
export interface ListProvisioningProfilesResponse {
    Items?: ProvisioningProfileSummary[];
    NextToken?: string;
}
export interface ListSchemaVersionsRequest {
    Type: SchemaVersionType;
    MaxResults?: number;
    NextToken?: string;
    SchemaId?: string;
    Namespace?: string;
    Visibility?: SchemaVersionVisibility;
    SemanticVersion?: string;
}
export interface SchemaVersionListItem {
    SchemaId?: string;
    Type?: SchemaVersionType;
    Description?: string;
    Namespace?: string;
    SemanticVersion?: string;
    Visibility?: SchemaVersionVisibility;
}
export type SchemaVersionList = SchemaVersionListItem[];
export interface ListSchemaVersionsResponse {
    Items?: SchemaVersionListItem[];
    NextToken?: string;
}
export type IoTManagedIntegrationsResourceARN = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface PutDefaultEncryptionConfigurationRequest {
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
}
export interface PutDefaultEncryptionConfigurationResponse {
    configurationStatus: ConfigurationStatus;
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
}
export interface PutHubConfigurationRequest {
    HubTokenTimerExpirySettingInSeconds: number;
}
export interface PutHubConfigurationResponse {
    HubTokenTimerExpirySettingInSeconds?: number;
}
export interface PutRuntimeLogConfigurationRequest {
    ManagedThingId: string;
    RuntimeLogConfigurations: RuntimeLogConfigurations;
}
export interface PutRuntimeLogConfigurationResponse {
}
export interface RegisterAccountAssociationRequest {
    ManagedThingId: string;
    AccountAssociationId: string;
    DeviceDiscoveryId: string;
}
export interface RegisterAccountAssociationResponse {
    AccountAssociationId?: string;
    DeviceDiscoveryId?: string;
    ManagedThingId?: string;
}
export interface RegisterCustomEndpointRequest {
}
export interface RegisterCustomEndpointResponse {
    EndpointAddress: string;
}
export interface ResetRuntimeLogConfigurationRequest {
    ManagedThingId: string;
}
export interface ResetRuntimeLogConfigurationResponse {
}
export type ConnectorId = string;
export type ThirdPartyUserId = string | redacted.Redacted<string>;
export type ConnectorEventOperation = "DEVICE_COMMAND_RESPONSE" | "DEVICE_DISCOVERY" | "DEVICE_EVENT" | "DEVICE_COMMAND_REQUEST" | (string & {});
export type ConnectorEventOperationVersion = string;
export type ConnectorEventStatusCode = number;
export type ConnectorEventMessage = string | redacted.Redacted<string>;
export type TraceId = string;
export type ClusterId = string;
export type SpecVersion = string;
export type MatterAttributeId = string;
export type MatterCapabilityReportAttributeValue = unknown;
export interface MatterCapabilityReportAttribute {
    id?: string;
    name?: string;
    value?: any;
}
export type MatterCapabilityReportAttributes = MatterCapabilityReportAttribute[];
export type MatterCommandId = string;
export type MatterCapabilityReportCommands = string[];
export type MatterEventId = string;
export type MatterCapabilityReportEvents = string[];
export type MatterCapabilityReportFeatureMap = number;
export type MatterCapabilityReportGeneratedCommands = string[];
export type MatterCapabilityReportFabricIndex = number;
export interface MatterCapabilityReportCluster {
    id: string;
    revision: number;
    publicId?: string;
    name?: string;
    specVersion?: string;
    attributes?: MatterCapabilityReportAttribute[];
    commands?: string[];
    events?: string[];
    featureMap?: number;
    generatedCommands?: string[];
    fabricIndex?: number;
}
export type MatterCapabilityReportClusters = MatterCapabilityReportCluster[];
export type MatterCapabilityReportEndpointParts = string[];
export type EndpointSemanticTag = string;
export type MatterCapabilityReportEndpointSemanticTags = string[];
export type MatterCapabilityReportEndpointClientClusters = string[];
export interface MatterCapabilityReportEndpoint {
    id: string;
    deviceTypes: string[];
    clusters: MatterCapabilityReportCluster[];
    parts?: string[];
    semanticTags?: string[];
    clientClusters?: string[];
}
export type MatterCapabilityReportEndpoints = MatterCapabilityReportEndpoint[];
export interface MatterCapabilityReport {
    version: string;
    nodeId?: string;
    endpoints: MatterCapabilityReportEndpoint[];
}
export type DeviceMetadata = unknown;
export interface Device {
    ConnectorDeviceId: string | redacted.Redacted<string>;
    ConnectorDeviceName?: string;
    CapabilityReport: MatterCapabilityReport;
    CapabilitySchemas?: CapabilitySchemaItem[];
    DeviceMetadata?: any;
}
export type Devices = Device[];
export type MatterAttributes = unknown;
export type MatterFields = unknown;
export type MatterCommands = {
    [key: string]: any | undefined;
};
export type MatterEvents = {
    [key: string]: any | undefined;
};
export interface MatterCluster {
    id?: string;
    attributes?: any;
    commands?: {
        [key: string]: any | undefined;
    };
    events?: {
        [key: string]: any | undefined;
    };
}
export type MatterClusters = MatterCluster[];
export interface MatterEndpoint {
    id?: string;
    clusters?: MatterCluster[];
}
export interface SendConnectorEventRequest {
    ConnectorId: string;
    UserId?: string | redacted.Redacted<string>;
    Operation: ConnectorEventOperation;
    OperationVersion?: string;
    StatusCode?: number;
    Message?: string | redacted.Redacted<string>;
    DeviceDiscoveryId?: string;
    ConnectorDeviceId?: string | redacted.Redacted<string>;
    TraceId?: string;
    Devices?: Device[];
    MatterEndpoint?: MatterEndpoint;
}
export interface SendConnectorEventResponse {
    ConnectorId: string;
}
export type CapabilityActionName = string;
export type ActionReference = string;
export type ActionTraceId = string;
export interface CapabilityAction {
    name: string;
    ref?: string;
    actionTraceId?: string;
    parameters?: any;
}
export type CapabilityActions = CapabilityAction[];
export interface CommandCapability {
    id: string;
    name: string;
    version: string;
    actions: CapabilityAction[];
}
export type CommandCapabilities = CommandCapability[];
export interface CommandEndpoint {
    endpointId: string;
    capabilities: CommandCapability[];
}
export type CommandEndpoints = CommandEndpoint[];
export interface SendManagedThingCommandRequest {
    ManagedThingId: string;
    Endpoints: CommandEndpoint[];
    ConnectorAssociationId?: string;
    AccountAssociationId?: string;
}
export interface SendManagedThingCommandResponse {
    TraceId?: string;
}
export interface StartAccountAssociationRefreshRequest {
    AccountAssociationId: string;
}
export interface StartAccountAssociationRefreshResponse {
    OAuthAuthorizationUrl: string | redacted.Redacted<string>;
}
export type CustomProtocolDetailKey = string;
export type CustomProtocolDetailValue = string;
export type CustomProtocolDetail = {
    [key: string]: string | undefined;
};
export type DiscoveryAuthMaterialString = string | redacted.Redacted<string>;
export type DiscoveryAuthMaterialType = "ZWAVE_INSTALL_CODE" | (string & {});
export type ConnectorDeviceIdList = (string | redacted.Redacted<string>)[];
export type ProtocolType = "ZWAVE" | "ZIGBEE" | "CUSTOM" | (string & {});
export interface StartDeviceDiscoveryRequest {
    DiscoveryType: DiscoveryType;
    CustomProtocolDetail?: {
        [key: string]: string | undefined;
    };
    ControllerIdentifier?: string;
    ConnectorAssociationIdentifier?: string;
    AccountAssociationId?: string;
    AuthenticationMaterial?: string | redacted.Redacted<string>;
    AuthenticationMaterialType?: DiscoveryAuthMaterialType;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ConnectorDeviceIdList?: (string | redacted.Redacted<string>)[];
    Protocol?: ProtocolType;
    EndDeviceIdentifier?: string;
}
export interface StartDeviceDiscoveryResponse {
    Id?: string;
    StartedAt?: Date;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAccountAssociationRequest {
    AccountAssociationId: string;
    Name?: string;
    Description?: string;
}
export interface UpdateAccountAssociationResponse {
}
export interface UpdateCloudConnectorRequest {
    Identifier: string;
    Name?: string;
    Description?: string;
}
export interface UpdateCloudConnectorResponse {
}
export interface OAuthUpdate {
    oAuthCompleteRedirectUrl?: string;
    proactiveRefreshTokenRenewal?: ProactiveRefreshTokenRenewal;
}
export interface GeneralAuthorizationUpdate {
    AuthMaterialsToAdd?: AuthMaterial[];
    AuthMaterialsToUpdate?: AuthMaterial[];
}
export interface AuthConfigUpdate {
    oAuthUpdate?: OAuthUpdate;
    GeneralAuthorizationUpdate?: GeneralAuthorizationUpdate;
}
export interface UpdateConnectorDestinationRequest {
    Identifier: string;
    Description?: string;
    Name?: string;
    AuthType?: AuthType;
    AuthConfig?: AuthConfigUpdate;
    SecretsManager?: SecretsManager;
}
export interface UpdateConnectorDestinationResponse {
}
export interface UpdateDestinationRequest {
    Name: string;
    DeliveryDestinationArn?: string;
    DeliveryDestinationType?: DeliveryDestinationType;
    RoleArn?: string;
    Description?: string;
}
export interface UpdateDestinationResponse {
}
export interface UpdateEventLogConfigurationRequest {
    Id: string;
    EventLogLevel: LogLevel;
}
export interface UpdateEventLogConfigurationResponse {
}
export interface UpdateManagedThingRequest {
    Identifier: string;
    Owner?: string | redacted.Redacted<string>;
    CredentialLockerId?: string;
    SerialNumber?: string | redacted.Redacted<string>;
    WiFiSimpleSetupConfiguration?: WiFiSimpleSetupConfiguration;
    Brand?: string | redacted.Redacted<string>;
    Model?: string | redacted.Redacted<string>;
    Name?: string;
    CapabilityReport?: CapabilityReport;
    CapabilitySchemas?: CapabilitySchemaItem[];
    Capabilities?: string;
    Classification?: string | redacted.Redacted<string>;
    HubNetworkMode?: HubNetworkMode;
    MetaData?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateManagedThingResponse {
}
export interface UpdateNotificationConfigurationRequest {
    EventType: EventType;
    DestinationName: string;
}
export interface UpdateNotificationConfigurationResponse {
}
export interface UpdateOtaTaskRequest {
    Identifier: string;
    Description?: string;
    TaskConfigurationId?: string;
}
export interface UpdateOtaTaskResponse {
}
export type ErrorMessage = string;
export type ErrorResourceId = string;
export type ErrorResourceType = string;
export type CreateAccountAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a new account association via the destination id.
 */
export declare const createAccountAssociation: API.OperationMethod<CreateAccountAssociationRequest, CreateAccountAssociationResponse, CreateAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateCloudConnectorError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a C2C (cloud-to-cloud) connector.
 */
export declare const createCloudConnector: API.OperationMethod<CreateCloudConnectorRequest, CreateCloudConnectorResponse, CreateCloudConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorDestinationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Create a connector destination for connecting a cloud-to-cloud (C2C) connector to the customer's Amazon Web Services account.
 */
export declare const createConnectorDestination: API.OperationMethod<CreateConnectorDestinationRequest, CreateConnectorDestinationResponse, CreateConnectorDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateCredentialLockerError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a credential locker.
 *
 * This operation will not trigger the creation of all the manufacturing resources.
 */
export declare const createCredentialLocker: API.OperationMethod<CreateCredentialLockerRequest, CreateCredentialLockerResponse, CreateCredentialLockerError, Credentials | HttpClient.HttpClient>;
export type CreateDestinationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a notification destination such as Kinesis Data Streams that receive events and notifications from Managed integrations. Managed integrations uses the destination to determine where to deliver notifications.
 */
export declare const createDestination: API.OperationMethod<CreateDestinationRequest, CreateDestinationResponse, CreateDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateEventLogConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Set the event log configuration for the account, resource type, or specific resource.
 */
export declare const createEventLogConfiguration: API.OperationMethod<CreateEventLogConfigurationRequest, CreateEventLogConfigurationResponse, CreateEventLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateManagedThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a managed thing. A managed thing contains the device identifier, protocol supported, and capabilities of the device in a data model format defined by Managed integrations.
 */
export declare const createManagedThing: API.OperationMethod<CreateManagedThingRequest, CreateManagedThingResponse, CreateManagedThingError, Credentials | HttpClient.HttpClient>;
export type CreateNotificationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a notification configuration. A configuration is a connection between an event type and a destination that you have already created.
 */
export declare const createNotificationConfiguration: API.OperationMethod<CreateNotificationConfigurationRequest, CreateNotificationConfigurationResponse, CreateNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateOtaTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Create an over-the-air (OTA) task to target a device.
 */
export declare const createOtaTask: API.OperationMethod<CreateOtaTaskRequest, CreateOtaTaskResponse, CreateOtaTaskError, Credentials | HttpClient.HttpClient>;
export type CreateOtaTaskConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a configuraiton for the over-the-air (OTA) task.
 */
export declare const createOtaTaskConfiguration: API.OperationMethod<CreateOtaTaskConfigurationRequest, CreateOtaTaskConfigurationResponse, CreateOtaTaskConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateProvisioningProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Create a provisioning profile for executing device provisioning flows. The provisioning profile is a document that defines the set of resources and policies applied to a device during the provisioning process.
 */
export declare const createProvisioningProfile: API.OperationMethod<CreateProvisioningProfileRequest, CreateProvisioningProfileResponse, CreateProvisioningProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove a third-party account association for an end user.
 *
 * You must first call the `DeregisterAccountAssociation` to remove the connection between the managed thing and the third-party account before calling the `DeleteAccountAssociation` API.
 */
export declare const deleteAccountAssociation: API.OperationMethod<DeleteAccountAssociationRequest, DeleteAccountAssociationResponse, DeleteAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudConnectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Delete a cloud connector.
 */
export declare const deleteCloudConnector: API.OperationMethod<DeleteCloudConnectorRequest, DeleteCloudConnectorResponse, DeleteCloudConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a connector destination linked to a cloud-to-cloud (C2C) connector.
 *
 * Deletion can't be done if the account association has used this connector destination.
 */
export declare const deleteConnectorDestination: API.OperationMethod<DeleteConnectorDestinationRequest, DeleteConnectorDestinationResponse, DeleteConnectorDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteCredentialLockerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a credential locker.
 *
 * This operation can't be undone and any existing device won't be able to use IoT managed integrations.
 */
export declare const deleteCredentialLocker: API.OperationMethod<DeleteCredentialLockerRequest, DeleteCredentialLockerResponse, DeleteCredentialLockerError, Credentials | HttpClient.HttpClient>;
export type DeleteDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a notification destination specified by name.
 */
export declare const deleteDestination: API.OperationMethod<DeleteDestinationRequest, DeleteDestinationResponse, DeleteDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteEventLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an event log configuration.
 */
export declare const deleteEventLogConfiguration: API.OperationMethod<DeleteEventLogConfigurationRequest, DeleteEventLogConfigurationResponse, DeleteEventLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteManagedThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Delete a managed thing. For direct-connected and hub-connected devices connecting with Managed integrations via a controller, all of the devices connected to it will have their status changed to `PENDING`. It is not possible to remove a cloud-to-cloud device.
 */
export declare const deleteManagedThing: API.OperationMethod<DeleteManagedThingRequest, DeleteManagedThingResponse, DeleteManagedThingError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a notification configuration.
 */
export declare const deleteNotificationConfiguration: API.OperationMethod<DeleteNotificationConfigurationRequest, DeleteNotificationConfigurationResponse, DeleteNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteOtaTaskError = AccessDeniedException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the over-the-air (OTA) task.
 */
export declare const deleteOtaTask: API.OperationMethod<DeleteOtaTaskRequest, DeleteOtaTaskResponse, DeleteOtaTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteOtaTaskConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the over-the-air (OTA) task configuration.
 */
export declare const deleteOtaTaskConfiguration: API.OperationMethod<DeleteOtaTaskConfigurationRequest, DeleteOtaTaskConfigurationResponse, DeleteOtaTaskConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteProvisioningProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Delete a provisioning profile.
 */
export declare const deleteProvisioningProfile: API.OperationMethod<DeleteProvisioningProfileRequest, DeleteProvisioningProfileResponse, DeleteProvisioningProfileError, Credentials | HttpClient.HttpClient>;
export type DeregisterAccountAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregister an account association from a managed thing.
 */
export declare const deregisterAccountAssociation: API.OperationMethod<DeregisterAccountAssociationRequest, DeregisterAccountAssociationResponse, DeregisterAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type GetAccountAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get an account association for an Amazon Web Services account linked to a customer-managed destination.
 */
export declare const getAccountAssociation: API.OperationMethod<GetAccountAssociationRequest, GetAccountAssociationResponse, GetAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type GetCloudConnectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get configuration details for a cloud connector.
 */
export declare const getCloudConnector: API.OperationMethod<GetCloudConnectorRequest, GetCloudConnectorResponse, GetCloudConnectorError, Credentials | HttpClient.HttpClient>;
export type GetConnectorDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get connector destination details linked to a cloud-to-cloud (C2C) connector.
 */
export declare const getConnectorDestination: API.OperationMethod<GetConnectorDestinationRequest, GetConnectorDestinationResponse, GetConnectorDestinationError, Credentials | HttpClient.HttpClient>;
export type GetCredentialLockerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get information on an existing credential locker
 */
export declare const getCredentialLocker: API.OperationMethod<GetCredentialLockerRequest, GetCredentialLockerResponse, GetCredentialLockerError, Credentials | HttpClient.HttpClient>;
export type GetCustomEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Returns the IoT managed integrations custom endpoint.
 */
export declare const getCustomEndpoint: API.OperationMethod<GetCustomEndpointRequest, GetCustomEndpointResponse, GetCustomEndpointError, Credentials | HttpClient.HttpClient>;
export type GetDefaultEncryptionConfigurationError = AccessDeniedException | InternalFailureException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves information about the default encryption configuration for the Amazon Web Services account in the default or specified region. For more information, see Key management in the *AWS IoT SiteWise User Guide*.
 */
export declare const getDefaultEncryptionConfiguration: API.OperationMethod<GetDefaultEncryptionConfigurationRequest, GetDefaultEncryptionConfigurationResponse, GetDefaultEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a destination by name.
 */
export declare const getDestination: API.OperationMethod<GetDestinationRequest, GetDestinationResponse, GetDestinationError, Credentials | HttpClient.HttpClient>;
export type GetDeviceDiscoveryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get the current state of a device discovery.
 */
export declare const getDeviceDiscovery: API.OperationMethod<GetDeviceDiscoveryRequest, GetDeviceDiscoveryResponse, GetDeviceDiscoveryError, Credentials | HttpClient.HttpClient>;
export type GetEventLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get an event log configuration.
 */
export declare const getEventLogConfiguration: API.OperationMethod<GetEventLogConfigurationRequest, GetEventLogConfigurationResponse, GetEventLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetHubConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a hub configuration.
 */
export declare const getHubConfiguration: API.OperationMethod<GetHubConfigurationRequest, GetHubConfigurationResponse, GetHubConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get details of a managed thing including its attributes and capabilities.
 */
export declare const getManagedThing: API.OperationMethod<GetManagedThingRequest, GetManagedThingResponse, GetManagedThingError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingCapabilitiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get the capabilities for a managed thing using the device ID.
 */
export declare const getManagedThingCapabilities: API.OperationMethod<GetManagedThingCapabilitiesRequest, GetManagedThingCapabilitiesResponse, GetManagedThingCapabilitiesError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingCertificateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves the certificate PEM for a managed IoT thing.
 */
export declare const getManagedThingCertificate: API.OperationMethod<GetManagedThingCertificateRequest, GetManagedThingCertificateResponse, GetManagedThingCertificateError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingConnectivityDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get the connectivity status of a managed thing.
 */
export declare const getManagedThingConnectivityData: API.OperationMethod<GetManagedThingConnectivityDataRequest, GetManagedThingConnectivityDataResponse, GetManagedThingConnectivityDataError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingMetaDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get the metadata information for a managed thing.
 *
 * The `managedThing` `metadata` parameter is used for associating attributes with a `managedThing` that can be used for grouping over-the-air (OTA) tasks. Name value pairs in `metadata` can be used in the `OtaTargetQueryString` parameter for the `CreateOtaTask` API operation.
 */
export declare const getManagedThingMetaData: API.OperationMethod<GetManagedThingMetaDataRequest, GetManagedThingMetaDataResponse, GetManagedThingMetaDataError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingStateError = AccessDeniedException | InternalFailureException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Returns the managed thing state for the given device Id.
 */
export declare const getManagedThingState: API.OperationMethod<GetManagedThingStateRequest, GetManagedThingStateResponse, GetManagedThingStateError, Credentials | HttpClient.HttpClient>;
export type GetNotificationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a notification configuration for a specified event type.
 */
export declare const getNotificationConfiguration: API.OperationMethod<GetNotificationConfigurationRequest, GetNotificationConfigurationResponse, GetNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetOtaTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get details of the over-the-air (OTA) task by its task id.
 */
export declare const getOtaTask: API.OperationMethod<GetOtaTaskRequest, GetOtaTaskResponse, GetOtaTaskError, Credentials | HttpClient.HttpClient>;
export type GetOtaTaskConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a configuraiton for the over-the-air (OTA) task.
 */
export declare const getOtaTaskConfiguration: API.OperationMethod<GetOtaTaskConfigurationRequest, GetOtaTaskConfigurationResponse, GetOtaTaskConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetProvisioningProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get details of a provisioning profile.
 */
export declare const getProvisioningProfile: API.OperationMethod<GetProvisioningProfileRequest, GetProvisioningProfileResponse, GetProvisioningProfileError, Credentials | HttpClient.HttpClient>;
export type GetRuntimeLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the runtime log configuration for a specific managed thing.
 */
export declare const getRuntimeLogConfiguration: API.OperationMethod<GetRuntimeLogConfigurationRequest, GetRuntimeLogConfigurationResponse, GetRuntimeLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetSchemaVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a schema version with the provided information.
 */
export declare const getSchemaVersion: API.OperationMethod<GetSchemaVersionRequest, GetSchemaVersionResponse, GetSchemaVersionError, Credentials | HttpClient.HttpClient>;
export type ListAccountAssociationsError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all account associations, with optional filtering by connector destination ID.
 */
export declare const listAccountAssociations: API.PaginatedOperationMethod<ListAccountAssociationsRequest, ListAccountAssociationsResponse, ListAccountAssociationsError, Credentials | HttpClient.HttpClient, AccountAssociationItem>;
export type ListCloudConnectorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of connectors filtered by its Lambda Amazon Resource Name (ARN) and `type`.
 */
export declare const listCloudConnectors: API.PaginatedOperationMethod<ListCloudConnectorsRequest, ListCloudConnectorsResponse, ListCloudConnectorsError, Credentials | HttpClient.HttpClient, ConnectorItem>;
export type ListConnectorDestinationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all connector destinations, with optional filtering by cloud connector ID.
 */
export declare const listConnectorDestinations: API.PaginatedOperationMethod<ListConnectorDestinationsRequest, ListConnectorDestinationsResponse, ListConnectorDestinationsError, Credentials | HttpClient.HttpClient, ConnectorDestinationSummary>;
export type ListCredentialLockersError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List information on an existing credential locker.
 */
export declare const listCredentialLockers: API.PaginatedOperationMethod<ListCredentialLockersRequest, ListCredentialLockersResponse, ListCredentialLockersError, Credentials | HttpClient.HttpClient, CredentialLockerSummary>;
export type ListDestinationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all notification destinations.
 */
export declare const listDestinations: API.PaginatedOperationMethod<ListDestinationsRequest, ListDestinationsResponse, ListDestinationsError, Credentials | HttpClient.HttpClient, DestinationSummary>;
export type ListDeviceDiscoveriesError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all device discovery tasks, with optional filtering by type and status.
 */
export declare const listDeviceDiscoveries: API.PaginatedOperationMethod<ListDeviceDiscoveriesRequest, ListDeviceDiscoveriesResponse, ListDeviceDiscoveriesError, Credentials | HttpClient.HttpClient, DeviceDiscoverySummary>;
export type ListDiscoveredDevicesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all devices discovered during a specific device discovery task.
 */
export declare const listDiscoveredDevices: API.PaginatedOperationMethod<ListDiscoveredDevicesRequest, ListDiscoveredDevicesResponse, ListDiscoveredDevicesError, Credentials | HttpClient.HttpClient, DiscoveredDeviceSummary>;
export type ListEventLogConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all event log configurations for an account.
 */
export declare const listEventLogConfigurations: API.PaginatedOperationMethod<ListEventLogConfigurationsRequest, ListEventLogConfigurationsResponse, ListEventLogConfigurationsError, Credentials | HttpClient.HttpClient, EventLogConfigurationSummary>;
export type ListManagedThingAccountAssociationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all account associations for a specific managed thing.
 */
export declare const listManagedThingAccountAssociations: API.PaginatedOperationMethod<ListManagedThingAccountAssociationsRequest, ListManagedThingAccountAssociationsResponse, ListManagedThingAccountAssociationsError, Credentials | HttpClient.HttpClient, ManagedThingAssociation>;
export type ListManagedThingsError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Listing all managed things with provision for filters.
 */
export declare const listManagedThings: API.PaginatedOperationMethod<ListManagedThingsRequest, ListManagedThingsResponse, ListManagedThingsError, Credentials | HttpClient.HttpClient, ManagedThingSummary>;
export type ListManagedThingSchemasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * List schemas associated with a managed thing.
 */
export declare const listManagedThingSchemas: API.PaginatedOperationMethod<ListManagedThingSchemasRequest, ListManagedThingSchemasResponse, ListManagedThingSchemasError, Credentials | HttpClient.HttpClient, ManagedThingSchemaListItem>;
export type ListNotificationConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all notification configurations.
 */
export declare const listNotificationConfigurations: API.PaginatedOperationMethod<ListNotificationConfigurationsRequest, ListNotificationConfigurationsResponse, ListNotificationConfigurationsError, Credentials | HttpClient.HttpClient, NotificationConfigurationSummary>;
export type ListOtaTaskConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all of the over-the-air (OTA) task configurations.
 */
export declare const listOtaTaskConfigurations: API.PaginatedOperationMethod<ListOtaTaskConfigurationsRequest, ListOtaTaskConfigurationsResponse, ListOtaTaskConfigurationsError, Credentials | HttpClient.HttpClient, OtaTaskConfigurationSummary>;
export type ListOtaTaskExecutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all of the over-the-air (OTA) task executions.
 */
export declare const listOtaTaskExecutions: API.PaginatedOperationMethod<ListOtaTaskExecutionsRequest, ListOtaTaskExecutionsResponse, ListOtaTaskExecutionsError, Credentials | HttpClient.HttpClient, OtaTaskExecutionSummaries>;
export type ListOtaTasksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all of the over-the-air (OTA) tasks.
 */
export declare const listOtaTasks: API.PaginatedOperationMethod<ListOtaTasksRequest, ListOtaTasksResponse, ListOtaTasksError, Credentials | HttpClient.HttpClient, OtaTaskSummary>;
export type ListProvisioningProfilesError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * List the provisioning profiles within the Amazon Web Services account.
 */
export declare const listProvisioningProfiles: API.PaginatedOperationMethod<ListProvisioningProfilesRequest, ListProvisioningProfilesResponse, ListProvisioningProfilesError, Credentials | HttpClient.HttpClient, ProvisioningProfileSummary>;
export type ListSchemaVersionsError = AccessDeniedException | ConflictException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists schema versions with the provided information.
 */
export declare const listSchemaVersions: API.PaginatedOperationMethod<ListSchemaVersionsRequest, ListSchemaVersionsResponse, ListSchemaVersionsError, Credentials | HttpClient.HttpClient, SchemaVersionListItem>;
export type ListTagsForResourceError = InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Lists the tags for a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutDefaultEncryptionConfigurationError = AccessDeniedException | InternalFailureException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Sets the default encryption configuration for the Amazon Web Services account. For more information, see Key management in the AWS IoT SiteWise User Guide.
 */
export declare const putDefaultEncryptionConfiguration: API.OperationMethod<PutDefaultEncryptionConfigurationRequest, PutDefaultEncryptionConfigurationResponse, PutDefaultEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutHubConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a hub configuration.
 */
export declare const putHubConfiguration: API.OperationMethod<PutHubConfigurationRequest, PutHubConfigurationResponse, PutHubConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutRuntimeLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Set the runtime log configuration for a specific managed thing.
 */
export declare const putRuntimeLogConfiguration: API.OperationMethod<PutRuntimeLogConfigurationRequest, PutRuntimeLogConfigurationResponse, PutRuntimeLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type RegisterAccountAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers an account association with a managed thing, establishing a connection between a device and a third-party account.
 */
export declare const registerAccountAssociation: API.OperationMethod<RegisterAccountAssociationRequest, RegisterAccountAssociationResponse, RegisterAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type RegisterCustomEndpointError = AccessDeniedException | ConflictException | InternalServerException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Customers can request IoT managed integrations to manage the server trust for them or bring their own external server trusts for the custom domain. Returns an IoT managed integrations endpoint.
 */
export declare const registerCustomEndpoint: API.OperationMethod<RegisterCustomEndpointRequest, RegisterCustomEndpointResponse, RegisterCustomEndpointError, Credentials | HttpClient.HttpClient>;
export type ResetRuntimeLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reset a runtime log configuration for a specific managed thing.
 */
export declare const resetRuntimeLogConfiguration: API.OperationMethod<ResetRuntimeLogConfigurationRequest, ResetRuntimeLogConfigurationResponse, ResetRuntimeLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type SendConnectorEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Relays third-party device events for a connector such as a new device or a device state change event.
 */
export declare const sendConnectorEvent: API.OperationMethod<SendConnectorEventRequest, SendConnectorEventResponse, SendConnectorEventError, Credentials | HttpClient.HttpClient>;
export type SendManagedThingCommandError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Send the command to the device represented by the managed thing.
 */
export declare const sendManagedThingCommand: API.OperationMethod<SendManagedThingCommandRequest, SendManagedThingCommandResponse, SendManagedThingCommandError, Credentials | HttpClient.HttpClient>;
export type StartAccountAssociationRefreshError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates a refresh of an existing account association to update its authorization and connection status.
 */
export declare const startAccountAssociationRefresh: API.OperationMethod<StartAccountAssociationRefreshRequest, StartAccountAssociationRefreshResponse, StartAccountAssociationRefreshError, Credentials | HttpClient.HttpClient>;
export type StartDeviceDiscoveryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * This API is used to start device discovery for hub-connected and third-party-connected devices. The authentication material (install code) is delivered as a message to the controller instructing it to start the discovery.
 */
export declare const startDeviceDiscovery: API.OperationMethod<StartDeviceDiscoveryRequest, StartDeviceDiscoveryResponse, StartDeviceDiscoveryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConflictException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Adds tags to a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Removes tags from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an existing account association.
 */
export declare const updateAccountAssociation: API.OperationMethod<UpdateAccountAssociationRequest, UpdateAccountAssociationResponse, UpdateAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudConnectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Update an existing cloud connector.
 */
export declare const updateCloudConnector: API.OperationMethod<UpdateCloudConnectorRequest, UpdateCloudConnectorResponse, UpdateCloudConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an existing connector destination.
 */
export declare const updateConnectorDestination: API.OperationMethod<UpdateConnectorDestinationRequest, UpdateConnectorDestinationResponse, UpdateConnectorDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a destination specified by name.
 */
export declare const updateDestination: API.OperationMethod<UpdateDestinationRequest, UpdateDestinationResponse, UpdateDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateEventLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an event log configuration by log configuration ID.
 */
export declare const updateEventLogConfiguration: API.OperationMethod<UpdateEventLogConfigurationRequest, UpdateEventLogConfigurationResponse, UpdateEventLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateManagedThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Update the attributes and capabilities associated with a managed thing.
 */
export declare const updateManagedThing: API.OperationMethod<UpdateManagedThingRequest, UpdateManagedThingResponse, UpdateManagedThingError, Credentials | HttpClient.HttpClient>;
export type UpdateNotificationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a notification configuration.
 */
export declare const updateNotificationConfiguration: API.OperationMethod<UpdateNotificationConfigurationRequest, UpdateNotificationConfigurationResponse, UpdateNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateOtaTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an over-the-air (OTA) task.
 */
export declare const updateOtaTask: API.OperationMethod<UpdateOtaTaskRequest, UpdateOtaTaskResponse, UpdateOtaTaskError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iot-managed-integrations.d.ts.map