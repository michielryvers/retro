import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessToClusterDeniedFault_base: S.TaggedErrorClass<"AccessToClusterDeniedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccessToClusterDeniedFault extends /*@__PURE__*/ AccessToClusterDeniedFault_base {
}
declare const AccessToSnapshotDeniedFault_base: S.TaggedErrorClass<"AccessToSnapshotDeniedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccessToSnapshotDeniedFault extends /*@__PURE__*/ AccessToSnapshotDeniedFault_base {
}
declare const AuthenticationProfileAlreadyExistsFault_base: S.TaggedErrorClass<"AuthenticationProfileAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AuthenticationProfileAlreadyExistsFault extends /*@__PURE__*/ AuthenticationProfileAlreadyExistsFault_base {
}
declare const AuthenticationProfileNotFoundFault_base: S.TaggedErrorClass<"AuthenticationProfileNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthenticationProfileNotFoundFault extends /*@__PURE__*/ AuthenticationProfileNotFoundFault_base {
}
declare const AuthenticationProfileQuotaExceededFault_base: S.TaggedErrorClass<"AuthenticationProfileQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthenticationProfileQuotaExceededFault extends /*@__PURE__*/ AuthenticationProfileQuotaExceededFault_base {
}
declare const AuthorizationAlreadyExistsFault_base: S.TaggedErrorClass<"AuthorizationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AuthorizationAlreadyExistsFault extends /*@__PURE__*/ AuthorizationAlreadyExistsFault_base {
}
declare const AuthorizationNotFoundFault_base: S.TaggedErrorClass<"AuthorizationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthorizationNotFoundFault extends /*@__PURE__*/ AuthorizationNotFoundFault_base {
}
declare const AuthorizationQuotaExceededFault_base: S.TaggedErrorClass<"AuthorizationQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthorizationQuotaExceededFault extends /*@__PURE__*/ AuthorizationQuotaExceededFault_base {
}
declare const BatchDeleteRequestSizeExceededFault_base: S.TaggedErrorClass<"BatchDeleteRequestSizeExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BatchDeleteRequestSizeExceededFault extends /*@__PURE__*/ BatchDeleteRequestSizeExceededFault_base {
}
declare const BatchModifyClusterSnapshotsLimitExceededFault_base: S.TaggedErrorClass<"BatchModifyClusterSnapshotsLimitExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BatchModifyClusterSnapshotsLimitExceededFault extends /*@__PURE__*/ BatchModifyClusterSnapshotsLimitExceededFault_base {
}
declare const BucketNotFoundFault_base: S.TaggedErrorClass<"BucketNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BucketNotFoundFault extends /*@__PURE__*/ BucketNotFoundFault_base {
}
declare const ClusterAlreadyExistsFault_base: S.TaggedErrorClass<"ClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ClusterAlreadyExistsFault extends /*@__PURE__*/ ClusterAlreadyExistsFault_base {
}
declare const ClusterNotFoundFault_base: S.TaggedErrorClass<"ClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterNotFoundFault extends /*@__PURE__*/ ClusterNotFoundFault_base {
}
declare const ClusterOnLatestRevisionFault_base: S.TaggedErrorClass<"ClusterOnLatestRevisionFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterOnLatestRevisionFault extends /*@__PURE__*/ ClusterOnLatestRevisionFault_base {
}
declare const ClusterParameterGroupAlreadyExistsFault_base: S.TaggedErrorClass<"ClusterParameterGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ClusterParameterGroupAlreadyExistsFault extends /*@__PURE__*/ ClusterParameterGroupAlreadyExistsFault_base {
}
declare const ClusterParameterGroupNotFoundFault_base: S.TaggedErrorClass<"ClusterParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterParameterGroupNotFoundFault extends /*@__PURE__*/ ClusterParameterGroupNotFoundFault_base {
}
declare const ClusterParameterGroupQuotaExceededFault_base: S.TaggedErrorClass<"ClusterParameterGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterParameterGroupQuotaExceededFault extends /*@__PURE__*/ ClusterParameterGroupQuotaExceededFault_base {
}
declare const ClusterQuotaExceededFault_base: S.TaggedErrorClass<"ClusterQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterQuotaExceededFault extends /*@__PURE__*/ ClusterQuotaExceededFault_base {
}
declare const ClusterSecurityGroupAlreadyExistsFault_base: S.TaggedErrorClass<"ClusterSecurityGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ClusterSecurityGroupAlreadyExistsFault extends /*@__PURE__*/ ClusterSecurityGroupAlreadyExistsFault_base {
}
declare const ClusterSecurityGroupNotFoundFault_base: S.TaggedErrorClass<"ClusterSecurityGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterSecurityGroupNotFoundFault extends /*@__PURE__*/ ClusterSecurityGroupNotFoundFault_base {
}
declare const ClusterSecurityGroupQuotaExceededFault_base: S.TaggedErrorClass<"ClusterSecurityGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterSecurityGroupQuotaExceededFault extends /*@__PURE__*/ ClusterSecurityGroupQuotaExceededFault_base {
}
declare const ClusterSnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"ClusterSnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ClusterSnapshotAlreadyExistsFault extends /*@__PURE__*/ ClusterSnapshotAlreadyExistsFault_base {
}
declare const ClusterSnapshotNotFoundFault_base: S.TaggedErrorClass<"ClusterSnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterSnapshotNotFoundFault extends /*@__PURE__*/ ClusterSnapshotNotFoundFault_base {
}
declare const ClusterSnapshotQuotaExceededFault_base: S.TaggedErrorClass<"ClusterSnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterSnapshotQuotaExceededFault extends /*@__PURE__*/ ClusterSnapshotQuotaExceededFault_base {
}
declare const ClusterSubnetGroupAlreadyExistsFault_base: S.TaggedErrorClass<"ClusterSubnetGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ClusterSubnetGroupAlreadyExistsFault extends /*@__PURE__*/ ClusterSubnetGroupAlreadyExistsFault_base {
}
declare const ClusterSubnetGroupNotFoundFault_base: S.TaggedErrorClass<"ClusterSubnetGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterSubnetGroupNotFoundFault extends /*@__PURE__*/ ClusterSubnetGroupNotFoundFault_base {
}
declare const ClusterSubnetGroupQuotaExceededFault_base: S.TaggedErrorClass<"ClusterSubnetGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterSubnetGroupQuotaExceededFault extends /*@__PURE__*/ ClusterSubnetGroupQuotaExceededFault_base {
}
declare const ClusterSubnetQuotaExceededFault_base: S.TaggedErrorClass<"ClusterSubnetQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterSubnetQuotaExceededFault extends /*@__PURE__*/ ClusterSubnetQuotaExceededFault_base {
}
declare const ConflictPolicyUpdateFault_base: S.TaggedErrorClass<"ConflictPolicyUpdateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictPolicyUpdateFault extends /*@__PURE__*/ ConflictPolicyUpdateFault_base {
}
declare const CopyToRegionDisabledFault_base: S.TaggedErrorClass<"CopyToRegionDisabledFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CopyToRegionDisabledFault extends /*@__PURE__*/ CopyToRegionDisabledFault_base {
}
declare const CustomCnameAssociationFault_base: S.TaggedErrorClass<"CustomCnameAssociationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CustomCnameAssociationFault extends /*@__PURE__*/ CustomCnameAssociationFault_base {
}
declare const CustomDomainAssociationNotFoundFault_base: S.TaggedErrorClass<"CustomDomainAssociationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CustomDomainAssociationNotFoundFault extends /*@__PURE__*/ CustomDomainAssociationNotFoundFault_base {
}
declare const DependentServiceAccessDeniedFault_base: S.TaggedErrorClass<"DependentServiceAccessDeniedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class DependentServiceAccessDeniedFault extends /*@__PURE__*/ DependentServiceAccessDeniedFault_base {
}
declare const DependentServiceRequestThrottlingFault_base: S.TaggedErrorClass<"DependentServiceRequestThrottlingFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DependentServiceRequestThrottlingFault extends /*@__PURE__*/ DependentServiceRequestThrottlingFault_base {
}
declare const DependentServiceUnavailableFault_base: S.TaggedErrorClass<"DependentServiceUnavailableFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DependentServiceUnavailableFault extends /*@__PURE__*/ DependentServiceUnavailableFault_base {
}
declare const EndpointAlreadyExistsFault_base: S.TaggedErrorClass<"EndpointAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EndpointAlreadyExistsFault extends /*@__PURE__*/ EndpointAlreadyExistsFault_base {
}
declare const EndpointAuthorizationAlreadyExistsFault_base: S.TaggedErrorClass<"EndpointAuthorizationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EndpointAuthorizationAlreadyExistsFault extends /*@__PURE__*/ EndpointAuthorizationAlreadyExistsFault_base {
}
declare const EndpointAuthorizationNotFoundFault_base: S.TaggedErrorClass<"EndpointAuthorizationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EndpointAuthorizationNotFoundFault extends /*@__PURE__*/ EndpointAuthorizationNotFoundFault_base {
}
declare const EndpointAuthorizationsPerClusterLimitExceededFault_base: S.TaggedErrorClass<"EndpointAuthorizationsPerClusterLimitExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EndpointAuthorizationsPerClusterLimitExceededFault extends /*@__PURE__*/ EndpointAuthorizationsPerClusterLimitExceededFault_base {
}
declare const EndpointNotFoundFault_base: S.TaggedErrorClass<"EndpointNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EndpointNotFoundFault extends /*@__PURE__*/ EndpointNotFoundFault_base {
}
declare const EndpointsPerAuthorizationLimitExceededFault_base: S.TaggedErrorClass<"EndpointsPerAuthorizationLimitExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EndpointsPerAuthorizationLimitExceededFault extends /*@__PURE__*/ EndpointsPerAuthorizationLimitExceededFault_base {
}
declare const EndpointsPerClusterLimitExceededFault_base: S.TaggedErrorClass<"EndpointsPerClusterLimitExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EndpointsPerClusterLimitExceededFault extends /*@__PURE__*/ EndpointsPerClusterLimitExceededFault_base {
}
declare const EventSubscriptionQuotaExceededFault_base: S.TaggedErrorClass<"EventSubscriptionQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventSubscriptionQuotaExceededFault extends /*@__PURE__*/ EventSubscriptionQuotaExceededFault_base {
}
declare const HsmClientCertificateAlreadyExistsFault_base: S.TaggedErrorClass<"HsmClientCertificateAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class HsmClientCertificateAlreadyExistsFault extends /*@__PURE__*/ HsmClientCertificateAlreadyExistsFault_base {
}
declare const HsmClientCertificateNotFoundFault_base: S.TaggedErrorClass<"HsmClientCertificateNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class HsmClientCertificateNotFoundFault extends /*@__PURE__*/ HsmClientCertificateNotFoundFault_base {
}
declare const HsmClientCertificateQuotaExceededFault_base: S.TaggedErrorClass<"HsmClientCertificateQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class HsmClientCertificateQuotaExceededFault extends /*@__PURE__*/ HsmClientCertificateQuotaExceededFault_base {
}
declare const HsmConfigurationAlreadyExistsFault_base: S.TaggedErrorClass<"HsmConfigurationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class HsmConfigurationAlreadyExistsFault extends /*@__PURE__*/ HsmConfigurationAlreadyExistsFault_base {
}
declare const HsmConfigurationNotFoundFault_base: S.TaggedErrorClass<"HsmConfigurationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class HsmConfigurationNotFoundFault extends /*@__PURE__*/ HsmConfigurationNotFoundFault_base {
}
declare const HsmConfigurationQuotaExceededFault_base: S.TaggedErrorClass<"HsmConfigurationQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class HsmConfigurationQuotaExceededFault extends /*@__PURE__*/ HsmConfigurationQuotaExceededFault_base {
}
declare const IncompatibleOrderableOptions_base: S.TaggedErrorClass<"IncompatibleOrderableOptions", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IncompatibleOrderableOptions extends /*@__PURE__*/ IncompatibleOrderableOptions_base {
}
declare const InProgressTableRestoreQuotaExceededFault_base: S.TaggedErrorClass<"InProgressTableRestoreQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InProgressTableRestoreQuotaExceededFault extends /*@__PURE__*/ InProgressTableRestoreQuotaExceededFault_base {
}
declare const InsufficientClusterCapacityFault_base: S.TaggedErrorClass<"InsufficientClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientClusterCapacityFault extends /*@__PURE__*/ InsufficientClusterCapacityFault_base {
}
declare const InsufficientS3BucketPolicyFault_base: S.TaggedErrorClass<"InsufficientS3BucketPolicyFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientS3BucketPolicyFault extends /*@__PURE__*/ InsufficientS3BucketPolicyFault_base {
}
declare const IntegrationAlreadyExistsFault_base: S.TaggedErrorClass<"IntegrationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class IntegrationAlreadyExistsFault extends /*@__PURE__*/ IntegrationAlreadyExistsFault_base {
}
declare const IntegrationConflictOperationFault_base: S.TaggedErrorClass<"IntegrationConflictOperationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationConflictOperationFault extends /*@__PURE__*/ IntegrationConflictOperationFault_base {
}
declare const IntegrationConflictStateFault_base: S.TaggedErrorClass<"IntegrationConflictStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationConflictStateFault extends /*@__PURE__*/ IntegrationConflictStateFault_base {
}
declare const IntegrationNotFoundFault_base: S.TaggedErrorClass<"IntegrationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationNotFoundFault extends /*@__PURE__*/ IntegrationNotFoundFault_base {
}
declare const IntegrationQuotaExceededFault_base: S.TaggedErrorClass<"IntegrationQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationQuotaExceededFault extends /*@__PURE__*/ IntegrationQuotaExceededFault_base {
}
declare const IntegrationSourceNotFoundFault_base: S.TaggedErrorClass<"IntegrationSourceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationSourceNotFoundFault extends /*@__PURE__*/ IntegrationSourceNotFoundFault_base {
}
declare const IntegrationTargetNotFoundFault_base: S.TaggedErrorClass<"IntegrationTargetNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationTargetNotFoundFault extends /*@__PURE__*/ IntegrationTargetNotFoundFault_base {
}
declare const InvalidAuthenticationProfileRequestFault_base: S.TaggedErrorClass<"InvalidAuthenticationProfileRequestFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidAuthenticationProfileRequestFault extends /*@__PURE__*/ InvalidAuthenticationProfileRequestFault_base {
}
declare const InvalidAuthorizationStateFault_base: S.TaggedErrorClass<"InvalidAuthorizationStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidAuthorizationStateFault extends /*@__PURE__*/ InvalidAuthorizationStateFault_base {
}
declare const InvalidClusterParameterGroupStateFault_base: S.TaggedErrorClass<"InvalidClusterParameterGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClusterParameterGroupStateFault extends /*@__PURE__*/ InvalidClusterParameterGroupStateFault_base {
}
declare const InvalidClusterSecurityGroupStateFault_base: S.TaggedErrorClass<"InvalidClusterSecurityGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClusterSecurityGroupStateFault extends /*@__PURE__*/ InvalidClusterSecurityGroupStateFault_base {
}
declare const InvalidClusterSnapshotScheduleStateFault_base: S.TaggedErrorClass<"InvalidClusterSnapshotScheduleStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClusterSnapshotScheduleStateFault extends /*@__PURE__*/ InvalidClusterSnapshotScheduleStateFault_base {
}
declare const InvalidClusterSnapshotStateFault_base: S.TaggedErrorClass<"InvalidClusterSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClusterSnapshotStateFault extends /*@__PURE__*/ InvalidClusterSnapshotStateFault_base {
}
declare const InvalidClusterStateFault_base: S.TaggedErrorClass<"InvalidClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClusterStateFault extends /*@__PURE__*/ InvalidClusterStateFault_base {
}
declare const InvalidClusterSubnetGroupStateFault_base: S.TaggedErrorClass<"InvalidClusterSubnetGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClusterSubnetGroupStateFault extends /*@__PURE__*/ InvalidClusterSubnetGroupStateFault_base {
}
declare const InvalidClusterSubnetStateFault_base: S.TaggedErrorClass<"InvalidClusterSubnetStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClusterSubnetStateFault extends /*@__PURE__*/ InvalidClusterSubnetStateFault_base {
}
declare const InvalidClusterTrackFault_base: S.TaggedErrorClass<"InvalidClusterTrackFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClusterTrackFault extends /*@__PURE__*/ InvalidClusterTrackFault_base {
}
declare const InvalidDataShareFault_base: S.TaggedErrorClass<"InvalidDataShareFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDataShareFault extends /*@__PURE__*/ InvalidDataShareFault_base {
}
declare const InvalidElasticIpFault_base: S.TaggedErrorClass<"InvalidElasticIpFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidElasticIpFault extends /*@__PURE__*/ InvalidElasticIpFault_base {
}
declare const InvalidEndpointStateFault_base: S.TaggedErrorClass<"InvalidEndpointStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEndpointStateFault extends /*@__PURE__*/ InvalidEndpointStateFault_base {
}
declare const InvalidHsmClientCertificateStateFault_base: S.TaggedErrorClass<"InvalidHsmClientCertificateStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidHsmClientCertificateStateFault extends /*@__PURE__*/ InvalidHsmClientCertificateStateFault_base {
}
declare const InvalidHsmConfigurationStateFault_base: S.TaggedErrorClass<"InvalidHsmConfigurationStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidHsmConfigurationStateFault extends /*@__PURE__*/ InvalidHsmConfigurationStateFault_base {
}
declare const InvalidNamespaceFault_base: S.TaggedErrorClass<"InvalidNamespaceFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNamespaceFault extends /*@__PURE__*/ InvalidNamespaceFault_base {
}
declare const InvalidPolicyFault_base: S.TaggedErrorClass<"InvalidPolicyFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPolicyFault extends /*@__PURE__*/ InvalidPolicyFault_base {
}
declare const InvalidReservedNodeStateFault_base: S.TaggedErrorClass<"InvalidReservedNodeStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidReservedNodeStateFault extends /*@__PURE__*/ InvalidReservedNodeStateFault_base {
}
declare const InvalidRestoreFault_base: S.TaggedErrorClass<"InvalidRestoreFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRestoreFault extends /*@__PURE__*/ InvalidRestoreFault_base {
}
declare const InvalidRetentionPeriodFault_base: S.TaggedErrorClass<"InvalidRetentionPeriodFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRetentionPeriodFault extends /*@__PURE__*/ InvalidRetentionPeriodFault_base {
}
declare const InvalidS3BucketNameFault_base: S.TaggedErrorClass<"InvalidS3BucketNameFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidS3BucketNameFault extends /*@__PURE__*/ InvalidS3BucketNameFault_base {
}
declare const InvalidS3KeyPrefixFault_base: S.TaggedErrorClass<"InvalidS3KeyPrefixFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidS3KeyPrefixFault extends /*@__PURE__*/ InvalidS3KeyPrefixFault_base {
}
declare const InvalidScheduledActionFault_base: S.TaggedErrorClass<"InvalidScheduledActionFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidScheduledActionFault extends /*@__PURE__*/ InvalidScheduledActionFault_base {
}
declare const InvalidScheduleFault_base: S.TaggedErrorClass<"InvalidScheduleFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidScheduleFault extends /*@__PURE__*/ InvalidScheduleFault_base {
}
declare const InvalidSnapshotCopyGrantStateFault_base: S.TaggedErrorClass<"InvalidSnapshotCopyGrantStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSnapshotCopyGrantStateFault extends /*@__PURE__*/ InvalidSnapshotCopyGrantStateFault_base {
}
declare const InvalidSubnet_base: S.TaggedErrorClass<"InvalidSubnet", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnet extends /*@__PURE__*/ InvalidSubnet_base {
}
declare const InvalidSubscriptionStateFault_base: S.TaggedErrorClass<"InvalidSubscriptionStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubscriptionStateFault extends /*@__PURE__*/ InvalidSubscriptionStateFault_base {
}
declare const InvalidTableRestoreArgumentFault_base: S.TaggedErrorClass<"InvalidTableRestoreArgumentFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTableRestoreArgumentFault extends /*@__PURE__*/ InvalidTableRestoreArgumentFault_base {
}
declare const InvalidTagFault_base: S.TaggedErrorClass<"InvalidTagFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTagFault extends /*@__PURE__*/ InvalidTagFault_base {
}
declare const InvalidUsageLimitFault_base: S.TaggedErrorClass<"InvalidUsageLimitFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidUsageLimitFault extends /*@__PURE__*/ InvalidUsageLimitFault_base {
}
declare const InvalidVPCNetworkStateFault_base: S.TaggedErrorClass<"InvalidVPCNetworkStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVPCNetworkStateFault extends /*@__PURE__*/ InvalidVPCNetworkStateFault_base {
}
declare const Ipv6CidrBlockNotFoundFault_base: S.TaggedErrorClass<"Ipv6CidrBlockNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class Ipv6CidrBlockNotFoundFault extends /*@__PURE__*/ Ipv6CidrBlockNotFoundFault_base {
}
declare const LimitExceededFault_base: S.TaggedErrorClass<"LimitExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededFault extends /*@__PURE__*/ LimitExceededFault_base {
}
declare const NumberOfNodesPerClusterLimitExceededFault_base: S.TaggedErrorClass<"NumberOfNodesPerClusterLimitExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NumberOfNodesPerClusterLimitExceededFault extends /*@__PURE__*/ NumberOfNodesPerClusterLimitExceededFault_base {
}
declare const NumberOfNodesQuotaExceededFault_base: S.TaggedErrorClass<"NumberOfNodesQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NumberOfNodesQuotaExceededFault extends /*@__PURE__*/ NumberOfNodesQuotaExceededFault_base {
}
declare const PartnerNotFoundFault_base: S.TaggedErrorClass<"PartnerNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PartnerNotFoundFault extends /*@__PURE__*/ PartnerNotFoundFault_base {
}
declare const Qev2IdcApplicationAlreadyExistsFault_base: S.TaggedErrorClass<"Qev2IdcApplicationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class Qev2IdcApplicationAlreadyExistsFault extends /*@__PURE__*/ Qev2IdcApplicationAlreadyExistsFault_base {
}
declare const Qev2IdcApplicationNotExistsFault_base: S.TaggedErrorClass<"Qev2IdcApplicationNotExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class Qev2IdcApplicationNotExistsFault extends /*@__PURE__*/ Qev2IdcApplicationNotExistsFault_base {
}
declare const RedshiftIdcApplicationAlreadyExistsFault_base: S.TaggedErrorClass<"RedshiftIdcApplicationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class RedshiftIdcApplicationAlreadyExistsFault extends /*@__PURE__*/ RedshiftIdcApplicationAlreadyExistsFault_base {
}
declare const RedshiftIdcApplicationNotExistsFault_base: S.TaggedErrorClass<"RedshiftIdcApplicationNotExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RedshiftIdcApplicationNotExistsFault extends /*@__PURE__*/ RedshiftIdcApplicationNotExistsFault_base {
}
declare const RedshiftIdcApplicationQuotaExceededFault_base: S.TaggedErrorClass<"RedshiftIdcApplicationQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RedshiftIdcApplicationQuotaExceededFault extends /*@__PURE__*/ RedshiftIdcApplicationQuotaExceededFault_base {
}
declare const RedshiftInvalidParameterFault_base: S.TaggedErrorClass<"RedshiftInvalidParameterFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RedshiftInvalidParameterFault extends /*@__PURE__*/ RedshiftInvalidParameterFault_base {
}
declare const ReservedNodeAlreadyExistsFault_base: S.TaggedErrorClass<"ReservedNodeAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReservedNodeAlreadyExistsFault extends /*@__PURE__*/ ReservedNodeAlreadyExistsFault_base {
}
declare const ReservedNodeAlreadyMigratedFault_base: S.TaggedErrorClass<"ReservedNodeAlreadyMigratedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedNodeAlreadyMigratedFault extends /*@__PURE__*/ ReservedNodeAlreadyMigratedFault_base {
}
declare const ReservedNodeExchangeNotFoundFault_base: S.TaggedErrorClass<"ReservedNodeExchangeNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedNodeExchangeNotFoundFault extends /*@__PURE__*/ ReservedNodeExchangeNotFoundFault_base {
}
declare const ReservedNodeNotFoundFault_base: S.TaggedErrorClass<"ReservedNodeNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedNodeNotFoundFault extends /*@__PURE__*/ ReservedNodeNotFoundFault_base {
}
declare const ReservedNodeOfferingNotFoundFault_base: S.TaggedErrorClass<"ReservedNodeOfferingNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedNodeOfferingNotFoundFault extends /*@__PURE__*/ ReservedNodeOfferingNotFoundFault_base {
}
declare const ReservedNodeQuotaExceededFault_base: S.TaggedErrorClass<"ReservedNodeQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedNodeQuotaExceededFault extends /*@__PURE__*/ ReservedNodeQuotaExceededFault_base {
}
declare const ResizeNotFoundFault_base: S.TaggedErrorClass<"ResizeNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResizeNotFoundFault extends /*@__PURE__*/ ResizeNotFoundFault_base {
}
declare const ResourceNotFoundFault_base: S.TaggedErrorClass<"ResourceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundFault extends /*@__PURE__*/ ResourceNotFoundFault_base {
}
declare const ScheduledActionAlreadyExistsFault_base: S.TaggedErrorClass<"ScheduledActionAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ScheduledActionAlreadyExistsFault extends /*@__PURE__*/ ScheduledActionAlreadyExistsFault_base {
}
declare const ScheduledActionNotFoundFault_base: S.TaggedErrorClass<"ScheduledActionNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ScheduledActionNotFoundFault extends /*@__PURE__*/ ScheduledActionNotFoundFault_base {
}
declare const ScheduledActionQuotaExceededFault_base: S.TaggedErrorClass<"ScheduledActionQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ScheduledActionQuotaExceededFault extends /*@__PURE__*/ ScheduledActionQuotaExceededFault_base {
}
declare const ScheduledActionTypeUnsupportedFault_base: S.TaggedErrorClass<"ScheduledActionTypeUnsupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ScheduledActionTypeUnsupportedFault extends /*@__PURE__*/ ScheduledActionTypeUnsupportedFault_base {
}
declare const ScheduleDefinitionTypeUnsupportedFault_base: S.TaggedErrorClass<"ScheduleDefinitionTypeUnsupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ScheduleDefinitionTypeUnsupportedFault extends /*@__PURE__*/ ScheduleDefinitionTypeUnsupportedFault_base {
}
declare const SnapshotCopyAlreadyDisabledFault_base: S.TaggedErrorClass<"SnapshotCopyAlreadyDisabledFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotCopyAlreadyDisabledFault extends /*@__PURE__*/ SnapshotCopyAlreadyDisabledFault_base {
}
declare const SnapshotCopyAlreadyEnabledFault_base: S.TaggedErrorClass<"SnapshotCopyAlreadyEnabledFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotCopyAlreadyEnabledFault extends /*@__PURE__*/ SnapshotCopyAlreadyEnabledFault_base {
}
declare const SnapshotCopyDisabledFault_base: S.TaggedErrorClass<"SnapshotCopyDisabledFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotCopyDisabledFault extends /*@__PURE__*/ SnapshotCopyDisabledFault_base {
}
declare const SnapshotCopyGrantAlreadyExistsFault_base: S.TaggedErrorClass<"SnapshotCopyGrantAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class SnapshotCopyGrantAlreadyExistsFault extends /*@__PURE__*/ SnapshotCopyGrantAlreadyExistsFault_base {
}
declare const SnapshotCopyGrantNotFoundFault_base: S.TaggedErrorClass<"SnapshotCopyGrantNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotCopyGrantNotFoundFault extends /*@__PURE__*/ SnapshotCopyGrantNotFoundFault_base {
}
declare const SnapshotCopyGrantQuotaExceededFault_base: S.TaggedErrorClass<"SnapshotCopyGrantQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotCopyGrantQuotaExceededFault extends /*@__PURE__*/ SnapshotCopyGrantQuotaExceededFault_base {
}
declare const SnapshotScheduleAlreadyExistsFault_base: S.TaggedErrorClass<"SnapshotScheduleAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class SnapshotScheduleAlreadyExistsFault extends /*@__PURE__*/ SnapshotScheduleAlreadyExistsFault_base {
}
declare const SnapshotScheduleNotFoundFault_base: S.TaggedErrorClass<"SnapshotScheduleNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotScheduleNotFoundFault extends /*@__PURE__*/ SnapshotScheduleNotFoundFault_base {
}
declare const SnapshotScheduleQuotaExceededFault_base: S.TaggedErrorClass<"SnapshotScheduleQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotScheduleQuotaExceededFault extends /*@__PURE__*/ SnapshotScheduleQuotaExceededFault_base {
}
declare const SnapshotScheduleUpdateInProgressFault_base: S.TaggedErrorClass<"SnapshotScheduleUpdateInProgressFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotScheduleUpdateInProgressFault extends /*@__PURE__*/ SnapshotScheduleUpdateInProgressFault_base {
}
declare const SNSInvalidTopicFault_base: S.TaggedErrorClass<"SNSInvalidTopicFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSInvalidTopicFault extends /*@__PURE__*/ SNSInvalidTopicFault_base {
}
declare const SNSNoAuthorizationFault_base: S.TaggedErrorClass<"SNSNoAuthorizationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSNoAuthorizationFault extends /*@__PURE__*/ SNSNoAuthorizationFault_base {
}
declare const SNSTopicArnNotFoundFault_base: S.TaggedErrorClass<"SNSTopicArnNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSTopicArnNotFoundFault extends /*@__PURE__*/ SNSTopicArnNotFoundFault_base {
}
declare const SourceNotFoundFault_base: S.TaggedErrorClass<"SourceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SourceNotFoundFault extends /*@__PURE__*/ SourceNotFoundFault_base {
}
declare const SubnetAlreadyInUse_base: S.TaggedErrorClass<"SubnetAlreadyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class SubnetAlreadyInUse extends /*@__PURE__*/ SubnetAlreadyInUse_base {
}
declare const SubscriptionAlreadyExistFault_base: S.TaggedErrorClass<"SubscriptionAlreadyExistFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionAlreadyExistFault extends /*@__PURE__*/ SubscriptionAlreadyExistFault_base {
}
declare const SubscriptionCategoryNotFoundFault_base: S.TaggedErrorClass<"SubscriptionCategoryNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionCategoryNotFoundFault extends /*@__PURE__*/ SubscriptionCategoryNotFoundFault_base {
}
declare const SubscriptionEventIdNotFoundFault_base: S.TaggedErrorClass<"SubscriptionEventIdNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionEventIdNotFoundFault extends /*@__PURE__*/ SubscriptionEventIdNotFoundFault_base {
}
declare const SubscriptionNotFoundFault_base: S.TaggedErrorClass<"SubscriptionNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionNotFoundFault extends /*@__PURE__*/ SubscriptionNotFoundFault_base {
}
declare const SubscriptionSeverityNotFoundFault_base: S.TaggedErrorClass<"SubscriptionSeverityNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionSeverityNotFoundFault extends /*@__PURE__*/ SubscriptionSeverityNotFoundFault_base {
}
declare const TableLimitExceededFault_base: S.TaggedErrorClass<"TableLimitExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TableLimitExceededFault extends /*@__PURE__*/ TableLimitExceededFault_base {
}
declare const TableRestoreNotFoundFault_base: S.TaggedErrorClass<"TableRestoreNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TableRestoreNotFoundFault extends /*@__PURE__*/ TableRestoreNotFoundFault_base {
}
declare const TagLimitExceededFault_base: S.TaggedErrorClass<"TagLimitExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagLimitExceededFault extends /*@__PURE__*/ TagLimitExceededFault_base {
}
declare const UnauthorizedOperation_base: S.TaggedErrorClass<"UnauthorizedOperation", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedOperation extends /*@__PURE__*/ UnauthorizedOperation_base {
}
declare const UnauthorizedPartnerIntegrationFault_base: S.TaggedErrorClass<"UnauthorizedPartnerIntegrationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedPartnerIntegrationFault extends /*@__PURE__*/ UnauthorizedPartnerIntegrationFault_base {
}
declare const UnknownSnapshotCopyRegionFault_base: S.TaggedErrorClass<"UnknownSnapshotCopyRegionFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnknownSnapshotCopyRegionFault extends /*@__PURE__*/ UnknownSnapshotCopyRegionFault_base {
}
declare const UnsupportedOperationFault_base: S.TaggedErrorClass<"UnsupportedOperationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationFault extends /*@__PURE__*/ UnsupportedOperationFault_base {
}
declare const UnsupportedOptionFault_base: S.TaggedErrorClass<"UnsupportedOptionFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOptionFault extends /*@__PURE__*/ UnsupportedOptionFault_base {
}
declare const UsageLimitAlreadyExistsFault_base: S.TaggedErrorClass<"UsageLimitAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class UsageLimitAlreadyExistsFault extends /*@__PURE__*/ UsageLimitAlreadyExistsFault_base {
}
declare const UsageLimitNotFoundFault_base: S.TaggedErrorClass<"UsageLimitNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UsageLimitNotFoundFault extends /*@__PURE__*/ UsageLimitNotFoundFault_base {
}
export interface AcceptReservedNodeExchangeInputMessage {
    ReservedNodeId?: string;
    TargetReservedNodeOfferingId?: string;
}
export interface RecurringCharge {
    RecurringChargeAmount?: number;
    RecurringChargeFrequency?: string;
}
export type RecurringChargeList = RecurringCharge[];
export type ReservedNodeOfferingType = "Regular" | "Upgradable" | (string & {});
export interface ReservedNode {
    ReservedNodeId?: string;
    ReservedNodeOfferingId?: string;
    NodeType?: string;
    StartTime?: Date;
    Duration?: number;
    FixedPrice?: number;
    UsagePrice?: number;
    CurrencyCode?: string;
    NodeCount?: number;
    State?: string;
    OfferingType?: string;
    RecurringCharges?: RecurringCharge[];
    ReservedNodeOfferingType?: ReservedNodeOfferingType;
}
export interface AcceptReservedNodeExchangeOutputMessage {
    ExchangedReservedNode?: ReservedNode;
}
export type PartnerIntegrationAccountId = string;
export type PartnerIntegrationClusterIdentifier = string;
export type PartnerIntegrationDatabaseName = string;
export type PartnerIntegrationPartnerName = string;
export interface PartnerIntegrationInputMessage {
    AccountId?: string;
    ClusterIdentifier?: string;
    DatabaseName?: string;
    PartnerName?: string;
}
export interface PartnerIntegrationOutputMessage {
    DatabaseName?: string;
    PartnerName?: string;
}
export interface AssociateDataShareConsumerMessage {
    DataShareArn?: string;
    AssociateEntireAccount?: boolean;
    ConsumerArn?: string;
    ConsumerRegion?: string;
    AllowWrites?: boolean;
}
export type DataShareStatus = "ACTIVE" | "PENDING_AUTHORIZATION" | "AUTHORIZED" | "DEAUTHORIZED" | "REJECTED" | "AVAILABLE" | (string & {});
export interface DataShareAssociation {
    ConsumerIdentifier?: string;
    Status?: DataShareStatus;
    ConsumerRegion?: string;
    CreatedDate?: Date;
    StatusChangeDate?: Date;
    ProducerAllowedWrites?: boolean;
    ConsumerAcceptedWrites?: boolean;
}
export type DataShareAssociationList = DataShareAssociation[];
export type DataShareType = "INTERNAL" | (string & {});
export interface DataShare {
    DataShareArn?: string;
    ProducerArn?: string;
    AllowPubliclyAccessibleConsumers?: boolean;
    DataShareAssociations?: DataShareAssociation[];
    ManagedBy?: string;
    DataShareType?: DataShareType;
}
export interface AuthorizeClusterSecurityGroupIngressMessage {
    ClusterSecurityGroupName?: string;
    CIDRIP?: string;
    EC2SecurityGroupName?: string;
    EC2SecurityGroupOwnerId?: string;
}
export interface Tag {
    Key?: string;
    Value?: string;
}
export type TagList = Tag[];
export interface EC2SecurityGroup {
    Status?: string;
    EC2SecurityGroupName?: string;
    EC2SecurityGroupOwnerId?: string;
    Tags?: Tag[];
}
export type EC2SecurityGroupList = EC2SecurityGroup[];
export interface IPRange {
    Status?: string;
    CIDRIP?: string;
    Tags?: Tag[];
}
export type IPRangeList = IPRange[];
export interface ClusterSecurityGroup {
    ClusterSecurityGroupName?: string;
    Description?: string;
    EC2SecurityGroups?: EC2SecurityGroup[];
    IPRanges?: IPRange[];
    Tags?: Tag[];
}
export interface AuthorizeClusterSecurityGroupIngressResult {
    ClusterSecurityGroup?: ClusterSecurityGroup;
}
export interface AuthorizeDataShareMessage {
    DataShareArn?: string;
    ConsumerIdentifier?: string;
    AllowWrites?: boolean;
}
export type VpcIdentifierList = string[];
export interface AuthorizeEndpointAccessMessage {
    ClusterIdentifier?: string;
    Account?: string;
    VpcIds?: string[];
}
export type AuthorizationStatus = "Authorized" | "Revoking" | (string & {});
export interface EndpointAuthorization {
    Grantor?: string;
    Grantee?: string;
    ClusterIdentifier?: string;
    AuthorizeTime?: Date;
    ClusterStatus?: string;
    Status?: AuthorizationStatus;
    AllowedAllVPCs?: boolean;
    AllowedVPCs?: string[];
    EndpointCount?: number;
}
export interface AuthorizeSnapshotAccessMessage {
    SnapshotIdentifier?: string;
    SnapshotArn?: string;
    SnapshotClusterIdentifier?: string;
    AccountWithRestoreAccess?: string;
}
export interface AccountWithRestoreAccess {
    AccountId?: string;
    AccountAlias?: string;
}
export type AccountsWithRestoreAccessList = AccountWithRestoreAccess[];
export type RestorableNodeTypeList = string[];
export interface Snapshot {
    SnapshotIdentifier?: string;
    ClusterIdentifier?: string;
    SnapshotCreateTime?: Date;
    Status?: string;
    Port?: number;
    AvailabilityZone?: string;
    ClusterCreateTime?: Date;
    MasterUsername?: string;
    ClusterVersion?: string;
    EngineFullVersion?: string;
    SnapshotType?: string;
    NodeType?: string;
    NumberOfNodes?: number;
    DBName?: string;
    VpcId?: string;
    Encrypted?: boolean;
    KmsKeyId?: string;
    EncryptedWithHSM?: boolean;
    AccountsWithRestoreAccess?: AccountWithRestoreAccess[];
    OwnerAccount?: string;
    TotalBackupSizeInMegaBytes?: number;
    ActualIncrementalBackupSizeInMegaBytes?: number;
    BackupProgressInMegaBytes?: number;
    CurrentBackupRateInMegaBytesPerSecond?: number;
    EstimatedSecondsToCompletion?: number;
    ElapsedTimeInSeconds?: number;
    SourceRegion?: string;
    Tags?: Tag[];
    RestorableNodeTypes?: string[];
    EnhancedVpcRouting?: boolean;
    MaintenanceTrackName?: string;
    ManualSnapshotRetentionPeriod?: number;
    ManualSnapshotRemainingDays?: number;
    SnapshotRetentionStartTime?: Date;
    MasterPasswordSecretArn?: string;
    MasterPasswordSecretKmsKeyId?: string;
    SnapshotArn?: string;
}
export interface AuthorizeSnapshotAccessResult {
    Snapshot?: Snapshot;
}
export interface DeleteClusterSnapshotMessage {
    SnapshotIdentifier?: string;
    SnapshotClusterIdentifier?: string;
}
export type DeleteClusterSnapshotMessageList = DeleteClusterSnapshotMessage[];
export interface BatchDeleteClusterSnapshotsRequest {
    Identifiers?: DeleteClusterSnapshotMessage[];
}
export type SnapshotIdentifierList = string[];
export interface SnapshotErrorMessage {
    SnapshotIdentifier?: string;
    SnapshotClusterIdentifier?: string;
    FailureCode?: string;
    FailureReason?: string;
}
export type BatchSnapshotOperationErrorList = SnapshotErrorMessage[];
export interface BatchDeleteClusterSnapshotsResult {
    Resources?: string[];
    Errors?: SnapshotErrorMessage[];
}
export interface BatchModifyClusterSnapshotsMessage {
    SnapshotIdentifierList?: string[];
    ManualSnapshotRetentionPeriod?: number;
    Force?: boolean;
}
export type BatchSnapshotOperationErrors = SnapshotErrorMessage[];
export interface BatchModifyClusterSnapshotsOutputMessage {
    Resources?: string[];
    Errors?: SnapshotErrorMessage[];
}
export interface CancelResizeMessage {
    ClusterIdentifier?: string;
}
export type ImportTablesCompleted = string[];
export type ImportTablesInProgress = string[];
export type ImportTablesNotStarted = string[];
export interface ResizeProgressMessage {
    TargetNodeType?: string;
    TargetNumberOfNodes?: number;
    TargetClusterType?: string;
    Status?: string;
    ImportTablesCompleted?: string[];
    ImportTablesInProgress?: string[];
    ImportTablesNotStarted?: string[];
    AvgResizeRateInMegaBytesPerSecond?: number;
    TotalResizeDataInMegaBytes?: number;
    ProgressInMegaBytes?: number;
    ElapsedTimeInSeconds?: number;
    EstimatedTimeToCompletionInSeconds?: number;
    ResizeType?: string;
    Message?: string;
    TargetEncryptionType?: string;
    DataTransferProgressPercent?: number;
}
export interface CopyClusterSnapshotMessage {
    SourceSnapshotIdentifier?: string;
    SourceSnapshotClusterIdentifier?: string;
    TargetSnapshotIdentifier?: string;
    ManualSnapshotRetentionPeriod?: number;
}
export interface CopyClusterSnapshotResult {
    Snapshot?: Snapshot;
}
export type AuthenticationProfileNameString = string;
export interface CreateAuthenticationProfileMessage {
    AuthenticationProfileName?: string;
    AuthenticationProfileContent?: string;
}
export interface CreateAuthenticationProfileResult {
    AuthenticationProfileName?: string;
    AuthenticationProfileContent?: string;
}
export type SensitiveString = string | redacted.Redacted<string>;
export type ClusterSecurityGroupNameList = string[];
export type VpcSecurityGroupIdList = string[];
export type IamRoleArnList = string[];
export type AquaConfigurationStatus = "enabled" | "disabled" | "auto" | (string & {});
export type CatalogNameString = string;
export interface CreateClusterMessage {
    DBName?: string;
    ClusterIdentifier?: string;
    ClusterType?: string;
    NodeType?: string;
    MasterUsername?: string;
    MasterUserPassword?: string | redacted.Redacted<string>;
    ClusterSecurityGroups?: string[];
    VpcSecurityGroupIds?: string[];
    ClusterSubnetGroupName?: string;
    AvailabilityZone?: string;
    PreferredMaintenanceWindow?: string;
    ClusterParameterGroupName?: string;
    AutomatedSnapshotRetentionPeriod?: number;
    ManualSnapshotRetentionPeriod?: number;
    Port?: number;
    ClusterVersion?: string;
    AllowVersionUpgrade?: boolean;
    NumberOfNodes?: number;
    PubliclyAccessible?: boolean;
    Encrypted?: boolean;
    HsmClientCertificateIdentifier?: string;
    HsmConfigurationIdentifier?: string;
    ElasticIp?: string;
    Tags?: Tag[];
    KmsKeyId?: string;
    EnhancedVpcRouting?: boolean;
    AdditionalInfo?: string;
    IamRoles?: string[];
    MaintenanceTrackName?: string;
    SnapshotScheduleIdentifier?: string;
    AvailabilityZoneRelocation?: boolean;
    AquaConfigurationStatus?: AquaConfigurationStatus;
    DefaultIamRoleArn?: string;
    LoadSampleData?: string;
    ManageMasterPassword?: boolean;
    MasterPasswordSecretKmsKeyId?: string;
    IpAddressType?: string;
    MultiAZ?: boolean;
    RedshiftIdcApplicationArn?: string;
    CatalogName?: string;
    ExtraComputeForAutomaticOptimization?: boolean;
}
export interface NetworkInterface {
    NetworkInterfaceId?: string;
    SubnetId?: string;
    PrivateIpAddress?: string;
    AvailabilityZone?: string;
    Ipv6Address?: string;
}
export type NetworkInterfaceList = NetworkInterface[];
export interface VpcEndpoint {
    VpcEndpointId?: string;
    VpcId?: string;
    NetworkInterfaces?: NetworkInterface[];
}
export type VpcEndpointsList = VpcEndpoint[];
export interface Endpoint {
    Address?: string;
    Port?: number;
    VpcEndpoints?: VpcEndpoint[];
}
export interface ClusterSecurityGroupMembership {
    ClusterSecurityGroupName?: string;
    Status?: string;
}
export type ClusterSecurityGroupMembershipList = ClusterSecurityGroupMembership[];
export interface VpcSecurityGroupMembership {
    VpcSecurityGroupId?: string;
    Status?: string;
}
export type VpcSecurityGroupMembershipList = VpcSecurityGroupMembership[];
export interface ClusterParameterStatus {
    ParameterName?: string;
    ParameterApplyStatus?: string;
    ParameterApplyErrorDescription?: string;
}
export type ClusterParameterStatusList = ClusterParameterStatus[];
export interface ClusterParameterGroupStatus {
    ParameterGroupName?: string;
    ParameterApplyStatus?: string;
    ClusterParameterStatusList?: ClusterParameterStatus[];
}
export type ClusterParameterGroupStatusList = ClusterParameterGroupStatus[];
export interface PendingModifiedValues {
    MasterUserPassword?: string | redacted.Redacted<string>;
    NodeType?: string;
    NumberOfNodes?: number;
    ClusterType?: string;
    ClusterVersion?: string;
    AutomatedSnapshotRetentionPeriod?: number;
    ClusterIdentifier?: string;
    PubliclyAccessible?: boolean;
    EnhancedVpcRouting?: boolean;
    MaintenanceTrackName?: string;
    EncryptionType?: string;
}
export interface RestoreStatus {
    Status?: string;
    CurrentRestoreRateInMegaBytesPerSecond?: number;
    SnapshotSizeInMegaBytes?: number;
    ProgressInMegaBytes?: number;
    ElapsedTimeInSeconds?: number;
    EstimatedTimeToCompletionInSeconds?: number;
}
export interface DataTransferProgress {
    Status?: string;
    CurrentRateInMegaBytesPerSecond?: number;
    TotalDataInMegaBytes?: number;
    DataTransferredInMegaBytes?: number;
    EstimatedTimeToCompletionInSeconds?: number;
    ElapsedTimeInSeconds?: number;
}
export interface HsmStatus {
    HsmClientCertificateIdentifier?: string;
    HsmConfigurationIdentifier?: string;
    Status?: string;
}
export interface ClusterSnapshotCopyStatus {
    DestinationRegion?: string;
    RetentionPeriod?: number;
    ManualSnapshotRetentionPeriod?: number;
    SnapshotCopyGrantName?: string;
}
export interface ClusterNode {
    NodeRole?: string;
    PrivateIPAddress?: string;
    PublicIPAddress?: string;
}
export type ClusterNodesList = ClusterNode[];
export interface ElasticIpStatus {
    ElasticIp?: string;
    Status?: string;
}
export interface ClusterIamRole {
    IamRoleArn?: string;
    ApplyStatus?: string;
}
export type ClusterIamRoleList = ClusterIamRole[];
export type PendingActionsList = string[];
export interface DeferredMaintenanceWindow {
    DeferMaintenanceIdentifier?: string;
    DeferMaintenanceStartTime?: Date;
    DeferMaintenanceEndTime?: Date;
}
export type DeferredMaintenanceWindowsList = DeferredMaintenanceWindow[];
export type ScheduleState = "MODIFYING" | "ACTIVE" | "FAILED" | (string & {});
export interface ResizeInfo {
    ResizeType?: string;
    AllowCancelResize?: boolean;
}
export type AquaStatus = "enabled" | "disabled" | "applying" | (string & {});
export interface AquaConfiguration {
    AquaStatus?: AquaStatus;
    AquaConfigurationStatus?: AquaConfigurationStatus;
}
export type ReservedNodeExchangeStatusType = "REQUESTED" | "PENDING" | "IN_PROGRESS" | "RETRYING" | "SUCCEEDED" | "FAILED" | (string & {});
export interface ReservedNodeExchangeStatus {
    ReservedNodeExchangeRequestId?: string;
    Status?: ReservedNodeExchangeStatusType;
    RequestTime?: Date;
    SourceReservedNodeId?: string;
    SourceReservedNodeType?: string;
    SourceReservedNodeCount?: number;
    TargetReservedNodeOfferingId?: string;
    TargetReservedNodeType?: string;
    TargetReservedNodeCount?: number;
}
export interface SecondaryClusterInfo {
    AvailabilityZone?: string;
    ClusterNodes?: ClusterNode[];
}
export type LogTypeList = string[];
export type S3TableLastIngestionTimeMap = {
    [key: string]: string | undefined;
};
export interface S3TablePublishStatus {
    S3Tables?: string[];
    S3TableNamespace?: string;
    S3TableGranularity?: string;
    EnabledAll?: boolean;
    LastIngestionTimes?: {
        [key: string]: string | undefined;
    };
}
export interface LoggingPublishStatus {
    S3Tables?: S3TablePublishStatus;
}
export interface Cluster {
    ClusterIdentifier?: string;
    NodeType?: string;
    ClusterStatus?: string;
    ClusterAvailabilityStatus?: string;
    ModifyStatus?: string;
    MasterUsername?: string;
    DBName?: string;
    Endpoint?: Endpoint;
    ClusterCreateTime?: Date;
    AutomatedSnapshotRetentionPeriod?: number;
    ManualSnapshotRetentionPeriod?: number;
    ClusterSecurityGroups?: ClusterSecurityGroupMembership[];
    VpcSecurityGroups?: VpcSecurityGroupMembership[];
    ClusterParameterGroups?: ClusterParameterGroupStatus[];
    ClusterSubnetGroupName?: string;
    VpcId?: string;
    AvailabilityZone?: string;
    PreferredMaintenanceWindow?: string;
    PendingModifiedValues?: PendingModifiedValues;
    ClusterVersion?: string;
    AllowVersionUpgrade?: boolean;
    NumberOfNodes?: number;
    PubliclyAccessible?: boolean;
    Encrypted?: boolean;
    RestoreStatus?: RestoreStatus;
    DataTransferProgress?: DataTransferProgress;
    HsmStatus?: HsmStatus;
    ClusterSnapshotCopyStatus?: ClusterSnapshotCopyStatus;
    ClusterPublicKey?: string;
    ClusterNodes?: ClusterNode[];
    ElasticIpStatus?: ElasticIpStatus;
    ClusterRevisionNumber?: string;
    Tags?: Tag[];
    KmsKeyId?: string;
    EnhancedVpcRouting?: boolean;
    IamRoles?: ClusterIamRole[];
    PendingActions?: string[];
    MaintenanceTrackName?: string;
    ElasticResizeNumberOfNodeOptions?: string;
    DeferredMaintenanceWindows?: DeferredMaintenanceWindow[];
    SnapshotScheduleIdentifier?: string;
    SnapshotScheduleState?: ScheduleState;
    ExpectedNextSnapshotScheduleTime?: Date;
    ExpectedNextSnapshotScheduleTimeStatus?: string;
    NextMaintenanceWindowStartTime?: Date;
    ResizeInfo?: ResizeInfo;
    AvailabilityZoneRelocationStatus?: string;
    ClusterNamespaceArn?: string;
    TotalStorageCapacityInMegaBytes?: number;
    AquaConfiguration?: AquaConfiguration;
    DefaultIamRoleArn?: string;
    ReservedNodeExchangeStatus?: ReservedNodeExchangeStatus;
    CustomDomainName?: string;
    CustomDomainCertificateArn?: string;
    CustomDomainCertificateExpiryDate?: Date;
    MasterPasswordSecretArn?: string;
    MasterPasswordSecretKmsKeyId?: string;
    IpAddressType?: string;
    MultiAZ?: string;
    MultiAZSecondary?: SecondaryClusterInfo;
    LakehouseRegistrationStatus?: string;
    CatalogArn?: string;
    ExtraComputeForAutomaticOptimization?: string;
    LoggingPublishStatus?: LoggingPublishStatus;
}
export interface CreateClusterResult {
    Cluster?: Cluster;
}
export interface CreateClusterParameterGroupMessage {
    ParameterGroupName?: string;
    ParameterGroupFamily?: string;
    Description?: string;
    Tags?: Tag[];
}
export interface ClusterParameterGroup {
    ParameterGroupName?: string;
    ParameterGroupFamily?: string;
    Description?: string;
    Tags?: Tag[];
}
export interface CreateClusterParameterGroupResult {
    ClusterParameterGroup?: ClusterParameterGroup;
}
export interface CreateClusterSecurityGroupMessage {
    ClusterSecurityGroupName?: string;
    Description?: string;
    Tags?: Tag[];
}
export interface CreateClusterSecurityGroupResult {
    ClusterSecurityGroup?: ClusterSecurityGroup;
}
export interface CreateClusterSnapshotMessage {
    SnapshotIdentifier?: string;
    ClusterIdentifier?: string;
    ManualSnapshotRetentionPeriod?: number;
    Tags?: Tag[];
}
export interface CreateClusterSnapshotResult {
    Snapshot?: Snapshot;
}
export type SubnetIdentifierList = string[];
export interface CreateClusterSubnetGroupMessage {
    ClusterSubnetGroupName?: string;
    Description?: string;
    SubnetIds?: string[];
    Tags?: Tag[];
}
export interface SupportedPlatform {
    Name?: string;
}
export type SupportedPlatformsList = SupportedPlatform[];
export interface AvailabilityZone {
    Name?: string;
    SupportedPlatforms?: SupportedPlatform[];
}
export interface Subnet {
    SubnetIdentifier?: string;
    SubnetAvailabilityZone?: AvailabilityZone;
    SubnetStatus?: string;
}
export type SubnetList = Subnet[];
export type ValueStringList = string[];
export interface ClusterSubnetGroup {
    ClusterSubnetGroupName?: string;
    Description?: string;
    VpcId?: string;
    SubnetGroupStatus?: string;
    Subnets?: Subnet[];
    Tags?: Tag[];
    SupportedClusterIpAddressTypes?: string[];
}
export interface CreateClusterSubnetGroupResult {
    ClusterSubnetGroup?: ClusterSubnetGroup;
}
export type CustomDomainNameString = string;
export type CustomDomainCertificateArnString = string;
export interface CreateCustomDomainAssociationMessage {
    CustomDomainName?: string;
    CustomDomainCertificateArn?: string;
    ClusterIdentifier?: string;
}
export interface CreateCustomDomainAssociationResult {
    CustomDomainName?: string;
    CustomDomainCertificateArn?: string;
    ClusterIdentifier?: string;
    CustomDomainCertExpiryTime?: string;
}
export interface CreateEndpointAccessMessage {
    ClusterIdentifier?: string;
    ResourceOwner?: string;
    EndpointName?: string;
    SubnetGroupName?: string;
    VpcSecurityGroupIds?: string[];
}
export interface EndpointAccess {
    ClusterIdentifier?: string;
    ResourceOwner?: string;
    SubnetGroupName?: string;
    EndpointStatus?: string;
    EndpointName?: string;
    EndpointCreateTime?: Date;
    Port?: number;
    Address?: string;
    VpcSecurityGroups?: VpcSecurityGroupMembership[];
    VpcEndpoint?: VpcEndpoint;
}
export type SourceIdsList = string[];
export type EventCategoriesList = string[];
export interface CreateEventSubscriptionMessage {
    SubscriptionName?: string;
    SnsTopicArn?: string;
    SourceType?: string;
    SourceIds?: string[];
    EventCategories?: string[];
    Severity?: string;
    Enabled?: boolean;
    Tags?: Tag[];
}
export interface EventSubscription {
    CustomerAwsId?: string;
    CustSubscriptionId?: string;
    SnsTopicArn?: string;
    Status?: string;
    SubscriptionCreationTime?: Date;
    SourceType?: string;
    SourceIdsList?: string[];
    EventCategoriesList?: string[];
    Severity?: string;
    Enabled?: boolean;
    Tags?: Tag[];
}
export interface CreateEventSubscriptionResult {
    EventSubscription?: EventSubscription;
}
export interface CreateHsmClientCertificateMessage {
    HsmClientCertificateIdentifier?: string;
    Tags?: Tag[];
}
export interface HsmClientCertificate {
    HsmClientCertificateIdentifier?: string;
    HsmClientCertificatePublicKey?: string;
    Tags?: Tag[];
}
export interface CreateHsmClientCertificateResult {
    HsmClientCertificate?: HsmClientCertificate;
}
export interface CreateHsmConfigurationMessage {
    HsmConfigurationIdentifier?: string;
    Description?: string;
    HsmIpAddress?: string;
    HsmPartitionName?: string;
    HsmPartitionPassword?: string;
    HsmServerPublicCertificate?: string;
    Tags?: Tag[];
}
export interface HsmConfiguration {
    HsmConfigurationIdentifier?: string;
    Description?: string;
    HsmIpAddress?: string;
    HsmPartitionName?: string;
    Tags?: Tag[];
}
export interface CreateHsmConfigurationResult {
    HsmConfiguration?: HsmConfiguration;
}
export type SourceArn = string;
export type TargetArn = string;
export type IntegrationName = string;
export type EncryptionContextMap = {
    [key: string]: string | undefined;
};
export type IntegrationDescription = string;
export interface CreateIntegrationMessage {
    SourceArn?: string;
    TargetArn?: string;
    IntegrationName?: string;
    KMSKeyId?: string;
    TagList?: Tag[];
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    };
    Description?: string;
}
export type IntegrationArn = string;
export type ZeroETLIntegrationStatus = "creating" | "active" | "modifying" | "failed" | "deleting" | "syncing" | "needs_attention" | (string & {});
export interface IntegrationError {
    ErrorCode?: string;
    ErrorMessage?: string;
}
export type IntegrationErrorList = IntegrationError[];
export type Description = string;
export interface Integration {
    IntegrationArn?: string;
    IntegrationName?: string;
    SourceArn?: string;
    TargetArn?: string;
    Status?: ZeroETLIntegrationStatus;
    Errors?: (IntegrationError & {
        ErrorCode: string;
    })[];
    CreateTime?: Date;
    Description?: string;
    KMSKeyId?: string;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    };
    Tags?: Tag[];
}
export type Qev2IdcApplicationName = string;
export type IdcDisplayNameString = string;
export interface CreateQev2IdcApplicationMessage {
    IdcInstanceArn?: string;
    Qev2IdcApplicationName?: string;
    IdcDisplayName?: string;
    Tags?: Tag[];
}
export interface Qev2IdcApplication {
    IdcInstanceArn?: string;
    Qev2IdcApplicationName?: string;
    Qev2IdcApplicationArn?: string;
    IdcManagedApplicationArn?: string;
    IdcOnboardStatus?: string;
    IdcDisplayName?: string;
    Tags?: Tag[];
}
export interface CreateQev2IdcApplicationResult {
    Qev2IdcApplication?: Qev2IdcApplication;
}
export type RedshiftIdcApplicationName = string;
export type IdentityNamespaceString = string;
export type AuthorizedAudienceList = string[];
export interface AuthorizedTokenIssuer {
    TrustedTokenIssuerArn?: string;
    AuthorizedAudiencesList?: string[];
}
export type AuthorizedTokenIssuerList = AuthorizedTokenIssuer[];
export type ServiceAuthorization = "Enabled" | "Disabled" | (string & {});
export interface LakeFormationQuery {
    Authorization?: ServiceAuthorization;
}
export type LakeFormationScopeUnion = {
    LakeFormationQuery: LakeFormationQuery;
};
export type LakeFormationServiceIntegrations = LakeFormationScopeUnion[];
export interface ReadWriteAccess {
    Authorization?: ServiceAuthorization;
}
export type S3AccessGrantsScopeUnion = {
    ReadWriteAccess: ReadWriteAccess;
};
export type S3AccessGrantsServiceIntegrations = S3AccessGrantsScopeUnion[];
export interface Connect {
    Authorization?: ServiceAuthorization;
}
export type RedshiftScopeUnion = {
    Connect: Connect;
};
export type RedshiftServiceIntegrations = RedshiftScopeUnion[];
export type ServiceIntegrationsUnion = {
    LakeFormation: LakeFormationScopeUnion[];
    S3AccessGrants?: never;
    Redshift?: never;
} | {
    LakeFormation?: never;
    S3AccessGrants: S3AccessGrantsScopeUnion[];
    Redshift?: never;
} | {
    LakeFormation?: never;
    S3AccessGrants?: never;
    Redshift: RedshiftScopeUnion[];
};
export type ServiceIntegrationList = ServiceIntegrationsUnion[];
export type ApplicationType = "None" | "Lakehouse" | (string & {});
export type TagKeyList = string[];
export interface CreateRedshiftIdcApplicationMessage {
    IdcInstanceArn?: string;
    RedshiftIdcApplicationName?: string;
    IdentityNamespace?: string;
    IdcDisplayName?: string;
    IamRoleArn?: string;
    AuthorizedTokenIssuerList?: AuthorizedTokenIssuer[];
    ServiceIntegrations?: ServiceIntegrationsUnion[];
    ApplicationType?: ApplicationType;
    Tags?: Tag[];
    SsoTagKeys?: string[];
}
export interface RedshiftIdcApplication {
    IdcInstanceArn?: string;
    RedshiftIdcApplicationName?: string;
    RedshiftIdcApplicationArn?: string;
    IdentityNamespace?: string;
    IdcDisplayName?: string;
    IamRoleArn?: string;
    IdcManagedApplicationArn?: string;
    IdcOnboardStatus?: string;
    AuthorizedTokenIssuerList?: AuthorizedTokenIssuer[];
    ServiceIntegrations?: ServiceIntegrationsUnion[];
    ApplicationType?: ApplicationType;
    Tags?: Tag[];
    SsoTagKeys?: string[];
}
export interface CreateRedshiftIdcApplicationResult {
    RedshiftIdcApplication?: RedshiftIdcApplication;
}
export interface ResizeClusterMessage {
    ClusterIdentifier?: string;
    ClusterType?: string;
    NodeType?: string;
    NumberOfNodes?: number;
    Classic?: boolean;
    ReservedNodeId?: string;
    TargetReservedNodeOfferingId?: string;
}
export interface PauseClusterMessage {
    ClusterIdentifier?: string;
}
export interface ResumeClusterMessage {
    ClusterIdentifier?: string;
}
export interface ScheduledActionType {
    ResizeCluster?: ResizeClusterMessage;
    PauseCluster?: PauseClusterMessage;
    ResumeCluster?: ResumeClusterMessage;
}
export interface CreateScheduledActionMessage {
    ScheduledActionName?: string;
    TargetAction?: ScheduledActionType;
    Schedule?: string;
    IamRole?: string;
    ScheduledActionDescription?: string;
    StartTime?: Date;
    EndTime?: Date;
    Enable?: boolean;
}
export type ScheduledActionState = "ACTIVE" | "DISABLED" | (string & {});
export type ScheduledActionTimeList = Date[];
export interface ScheduledAction {
    ScheduledActionName?: string;
    TargetAction?: ScheduledActionType & {
        ResizeCluster: ResizeClusterMessage & {
            ClusterIdentifier: string;
        };
        PauseCluster: PauseClusterMessage & {
            ClusterIdentifier: string;
        };
        ResumeCluster: ResumeClusterMessage & {
            ClusterIdentifier: string;
        };
    };
    Schedule?: string;
    IamRole?: string;
    ScheduledActionDescription?: string;
    State?: ScheduledActionState;
    NextInvocations?: Date[];
    StartTime?: Date;
    EndTime?: Date;
}
export interface CreateSnapshotCopyGrantMessage {
    SnapshotCopyGrantName?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
}
export interface SnapshotCopyGrant {
    SnapshotCopyGrantName?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
}
export interface CreateSnapshotCopyGrantResult {
    SnapshotCopyGrant?: SnapshotCopyGrant;
}
export type ScheduleDefinitionList = string[];
export interface CreateSnapshotScheduleMessage {
    ScheduleDefinitions?: string[];
    ScheduleIdentifier?: string;
    ScheduleDescription?: string;
    Tags?: Tag[];
    DryRun?: boolean;
    NextInvocations?: number;
}
export type ScheduledSnapshotTimeList = Date[];
export interface ClusterAssociatedToSchedule {
    ClusterIdentifier?: string;
    ScheduleAssociationState?: ScheduleState;
}
export type AssociatedClusterList = ClusterAssociatedToSchedule[];
export interface SnapshotSchedule {
    ScheduleDefinitions?: string[];
    ScheduleIdentifier?: string;
    ScheduleDescription?: string;
    Tags?: Tag[];
    NextInvocations?: Date[];
    AssociatedClusterCount?: number;
    AssociatedClusters?: ClusterAssociatedToSchedule[];
}
export interface CreateTagsMessage {
    ResourceName?: string;
    Tags?: Tag[];
}
export interface CreateTagsResponse {
}
export type UsageLimitFeatureType = "spectrum" | "concurrency-scaling" | "cross-region-datasharing" | "extra-compute-for-automatic-optimization" | (string & {});
export type UsageLimitLimitType = "time" | "data-scanned" | (string & {});
export type UsageLimitPeriod = "daily" | "weekly" | "monthly" | (string & {});
export type UsageLimitBreachAction = "log" | "emit-metric" | "disable" | (string & {});
export interface CreateUsageLimitMessage {
    ClusterIdentifier?: string;
    FeatureType?: UsageLimitFeatureType;
    LimitType?: UsageLimitLimitType;
    Amount?: number;
    Period?: UsageLimitPeriod;
    BreachAction?: UsageLimitBreachAction;
    Tags?: Tag[];
}
export interface UsageLimit {
    UsageLimitId?: string;
    ClusterIdentifier?: string;
    FeatureType?: UsageLimitFeatureType;
    LimitType?: UsageLimitLimitType;
    Amount?: number;
    Period?: UsageLimitPeriod;
    BreachAction?: UsageLimitBreachAction;
    Tags?: Tag[];
}
export interface DeauthorizeDataShareMessage {
    DataShareArn?: string;
    ConsumerIdentifier?: string;
}
export interface DeleteAuthenticationProfileMessage {
    AuthenticationProfileName?: string;
}
export interface DeleteAuthenticationProfileResult {
    AuthenticationProfileName?: string;
}
export interface DeleteClusterMessage {
    ClusterIdentifier?: string;
    SkipFinalClusterSnapshot?: boolean;
    FinalClusterSnapshotIdentifier?: string;
    FinalClusterSnapshotRetentionPeriod?: number;
}
export interface DeleteClusterResult {
    Cluster?: Cluster;
}
export interface DeleteClusterParameterGroupMessage {
    ParameterGroupName?: string;
}
export interface DeleteClusterParameterGroupResponse {
}
export interface DeleteClusterSecurityGroupMessage {
    ClusterSecurityGroupName?: string;
}
export interface DeleteClusterSecurityGroupResponse {
}
export interface DeleteClusterSnapshotResult {
    Snapshot?: Snapshot;
}
export interface DeleteClusterSubnetGroupMessage {
    ClusterSubnetGroupName?: string;
}
export interface DeleteClusterSubnetGroupResponse {
}
export interface DeleteCustomDomainAssociationMessage {
    ClusterIdentifier?: string;
    CustomDomainName?: string;
}
export interface DeleteCustomDomainAssociationResponse {
}
export interface DeleteEndpointAccessMessage {
    EndpointName?: string;
}
export interface DeleteEventSubscriptionMessage {
    SubscriptionName?: string;
}
export interface DeleteEventSubscriptionResponse {
}
export interface DeleteHsmClientCertificateMessage {
    HsmClientCertificateIdentifier?: string;
}
export interface DeleteHsmClientCertificateResponse {
}
export interface DeleteHsmConfigurationMessage {
    HsmConfigurationIdentifier?: string;
}
export interface DeleteHsmConfigurationResponse {
}
export interface DeleteIntegrationMessage {
    IntegrationArn?: string;
}
export interface DeleteQev2IdcApplicationMessage {
    Qev2IdcApplicationArn?: string;
}
export interface DeleteQev2IdcApplicationResponse {
}
export interface DeleteRedshiftIdcApplicationMessage {
    RedshiftIdcApplicationArn?: string;
}
export interface DeleteRedshiftIdcApplicationResponse {
}
export interface DeleteResourcePolicyMessage {
    ResourceArn?: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteScheduledActionMessage {
    ScheduledActionName?: string;
}
export interface DeleteScheduledActionResponse {
}
export interface DeleteSnapshotCopyGrantMessage {
    SnapshotCopyGrantName?: string;
}
export interface DeleteSnapshotCopyGrantResponse {
}
export interface DeleteSnapshotScheduleMessage {
    ScheduleIdentifier?: string;
}
export interface DeleteSnapshotScheduleResponse {
}
export interface DeleteTagsMessage {
    ResourceName?: string;
    TagKeys?: string[];
}
export interface DeleteTagsResponse {
}
export interface DeleteUsageLimitMessage {
    UsageLimitId?: string;
}
export interface DeleteUsageLimitResponse {
}
export interface ServerlessIdentifier {
    NamespaceIdentifier?: string;
    WorkgroupIdentifier?: string;
}
export interface ProvisionedIdentifier {
    ClusterIdentifier?: string;
}
export type NamespaceIdentifierUnion = {
    ServerlessIdentifier: ServerlessIdentifier;
    ProvisionedIdentifier?: never;
} | {
    ServerlessIdentifier?: never;
    ProvisionedIdentifier: ProvisionedIdentifier;
};
export type ConsumerIdentifierList = string[];
export interface DeregisterNamespaceInputMessage {
    NamespaceIdentifier?: NamespaceIdentifierUnion;
    ConsumerIdentifiers?: string[];
}
export type NamespaceRegistrationStatus = "Registering" | "Deregistering" | (string & {});
export interface DeregisterNamespaceOutputMessage {
    Status?: NamespaceRegistrationStatus;
}
export type AttributeNameList = string[];
export interface DescribeAccountAttributesMessage {
    AttributeNames?: string[];
}
export interface AttributeValueTarget {
    AttributeValue?: string;
}
export type AttributeValueList = AttributeValueTarget[];
export interface AccountAttribute {
    AttributeName?: string;
    AttributeValues?: AttributeValueTarget[];
}
export type AttributeList = AccountAttribute[];
export interface AccountAttributeList {
    AccountAttributes?: AccountAttribute[];
}
export interface DescribeAuthenticationProfilesMessage {
    AuthenticationProfileName?: string;
}
export interface AuthenticationProfile {
    AuthenticationProfileName?: string;
    AuthenticationProfileContent?: string;
}
export type AuthenticationProfileList = AuthenticationProfile[];
export interface DescribeAuthenticationProfilesResult {
    AuthenticationProfiles?: AuthenticationProfile[];
}
export interface DescribeClusterDbRevisionsMessage {
    ClusterIdentifier?: string;
    MaxRecords?: number;
    Marker?: string;
}
export interface RevisionTarget {
    DatabaseRevision?: string;
    Description?: string;
    DatabaseRevisionReleaseDate?: Date;
}
export type RevisionTargetsList = RevisionTarget[];
export interface ClusterDbRevision {
    ClusterIdentifier?: string;
    CurrentDatabaseRevision?: string;
    DatabaseRevisionReleaseDate?: Date;
    RevisionTargets?: RevisionTarget[];
}
export type ClusterDbRevisionsList = ClusterDbRevision[];
export interface ClusterDbRevisionsMessage {
    Marker?: string;
    ClusterDbRevisions?: ClusterDbRevision[];
}
export type TagValueList = string[];
export interface DescribeClusterParameterGroupsMessage {
    ParameterGroupName?: string;
    MaxRecords?: number;
    Marker?: string;
    TagKeys?: string[];
    TagValues?: string[];
}
export type ParameterGroupList = ClusterParameterGroup[];
export interface ClusterParameterGroupsMessage {
    Marker?: string;
    ParameterGroups?: ClusterParameterGroup[];
}
export interface DescribeClusterParametersMessage {
    ParameterGroupName?: string;
    Source?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type ParameterApplyType = "static" | "dynamic" | (string & {});
export interface Parameter {
    ParameterName?: string;
    ParameterValue?: string;
    Description?: string;
    Source?: string;
    DataType?: string;
    AllowedValues?: string;
    ApplyType?: ParameterApplyType;
    IsModifiable?: boolean;
    MinimumEngineVersion?: string;
}
export type ParametersList = Parameter[];
export interface ClusterParameterGroupDetails {
    Parameters?: Parameter[];
    Marker?: string;
}
export interface DescribeClustersMessage {
    ClusterIdentifier?: string;
    MaxRecords?: number;
    Marker?: string;
    TagKeys?: string[];
    TagValues?: string[];
}
export type ClusterList = Cluster[];
export interface ClustersMessage {
    Marker?: string;
    Clusters?: Cluster[];
}
export interface DescribeClusterSecurityGroupsMessage {
    ClusterSecurityGroupName?: string;
    MaxRecords?: number;
    Marker?: string;
    TagKeys?: string[];
    TagValues?: string[];
}
export type ClusterSecurityGroups = ClusterSecurityGroup[];
export interface ClusterSecurityGroupMessage {
    Marker?: string;
    ClusterSecurityGroups?: ClusterSecurityGroup[];
}
export type SnapshotAttributeToSortBy = "SOURCE_TYPE" | "TOTAL_SIZE" | "CREATE_TIME" | (string & {});
export type SortByOrder = "ASC" | "DESC" | (string & {});
export interface SnapshotSortingEntity {
    Attribute?: SnapshotAttributeToSortBy;
    SortOrder?: SortByOrder;
}
export type SnapshotSortingEntityList = SnapshotSortingEntity[];
export interface DescribeClusterSnapshotsMessage {
    ClusterIdentifier?: string;
    SnapshotIdentifier?: string;
    SnapshotArn?: string;
    SnapshotType?: string;
    StartTime?: Date;
    EndTime?: Date;
    MaxRecords?: number;
    Marker?: string;
    OwnerAccount?: string;
    TagKeys?: string[];
    TagValues?: string[];
    ClusterExists?: boolean;
    SortingEntities?: SnapshotSortingEntity[];
}
export type SnapshotList = Snapshot[];
export interface SnapshotMessage {
    Marker?: string;
    Snapshots?: Snapshot[];
}
export interface DescribeClusterSubnetGroupsMessage {
    ClusterSubnetGroupName?: string;
    MaxRecords?: number;
    Marker?: string;
    TagKeys?: string[];
    TagValues?: string[];
}
export type ClusterSubnetGroups = ClusterSubnetGroup[];
export interface ClusterSubnetGroupMessage {
    Marker?: string;
    ClusterSubnetGroups?: ClusterSubnetGroup[];
}
export interface DescribeClusterTracksMessage {
    MaintenanceTrackName?: string;
    MaxRecords?: number;
    Marker?: string;
}
export interface SupportedOperation {
    OperationName?: string;
}
export type SupportedOperationList = SupportedOperation[];
export interface UpdateTarget {
    MaintenanceTrackName?: string;
    DatabaseVersion?: string;
    SupportedOperations?: SupportedOperation[];
}
export type EligibleTracksToUpdateList = UpdateTarget[];
export interface MaintenanceTrack {
    MaintenanceTrackName?: string;
    DatabaseVersion?: string;
    UpdateTargets?: UpdateTarget[];
}
export type TrackList = MaintenanceTrack[];
export interface TrackListMessage {
    MaintenanceTracks?: MaintenanceTrack[];
    Marker?: string;
}
export interface DescribeClusterVersionsMessage {
    ClusterVersion?: string;
    ClusterParameterGroupFamily?: string;
    MaxRecords?: number;
    Marker?: string;
}
export interface ClusterVersion {
    ClusterVersion?: string;
    ClusterParameterGroupFamily?: string;
    Description?: string;
}
export type ClusterVersionList = ClusterVersion[];
export interface ClusterVersionsMessage {
    Marker?: string;
    ClusterVersions?: ClusterVersion[];
}
export interface DescribeCustomDomainAssociationsMessage {
    CustomDomainName?: string;
    CustomDomainCertificateArn?: string;
    MaxRecords?: number;
    Marker?: string;
}
export interface CertificateAssociation {
    CustomDomainName?: string;
    ClusterIdentifier?: string;
}
export type CertificateAssociationList = CertificateAssociation[];
export interface Association {
    CustomDomainCertificateArn?: string;
    CustomDomainCertificateExpiryDate?: Date;
    CertificateAssociations?: CertificateAssociation[];
}
export type AssociationList = Association[];
export interface CustomDomainAssociationsMessage {
    Marker?: string;
    Associations?: Association[];
}
export interface DescribeDataSharesMessage {
    DataShareArn?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type DataShareList = DataShare[];
export interface DescribeDataSharesResult {
    DataShares?: DataShare[];
    Marker?: string;
}
export type DataShareStatusForConsumer = "ACTIVE" | "AVAILABLE" | (string & {});
export interface DescribeDataSharesForConsumerMessage {
    ConsumerArn?: string;
    Status?: DataShareStatusForConsumer;
    MaxRecords?: number;
    Marker?: string;
}
export interface DescribeDataSharesForConsumerResult {
    DataShares?: DataShare[];
    Marker?: string;
}
export type DataShareStatusForProducer = "ACTIVE" | "AUTHORIZED" | "PENDING_AUTHORIZATION" | "DEAUTHORIZED" | "REJECTED" | (string & {});
export interface DescribeDataSharesForProducerMessage {
    ProducerArn?: string;
    Status?: DataShareStatusForProducer;
    MaxRecords?: number;
    Marker?: string;
}
export interface DescribeDataSharesForProducerResult {
    DataShares?: DataShare[];
    Marker?: string;
}
export interface DescribeDefaultClusterParametersMessage {
    ParameterGroupFamily?: string;
    MaxRecords?: number;
    Marker?: string;
}
export interface DefaultClusterParameters {
    ParameterGroupFamily?: string;
    Marker?: string;
    Parameters?: Parameter[];
}
export interface DescribeDefaultClusterParametersResult {
    DefaultClusterParameters?: DefaultClusterParameters;
}
export interface DescribeEndpointAccessMessage {
    ClusterIdentifier?: string;
    ResourceOwner?: string;
    EndpointName?: string;
    VpcId?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type EndpointAccesses = EndpointAccess[];
export interface EndpointAccessList {
    EndpointAccessList?: EndpointAccess[];
    Marker?: string;
}
export interface DescribeEndpointAuthorizationMessage {
    ClusterIdentifier?: string;
    Account?: string;
    Grantee?: boolean;
    MaxRecords?: number;
    Marker?: string;
}
export type EndpointAuthorizations = EndpointAuthorization[];
export interface EndpointAuthorizationList {
    EndpointAuthorizationList?: EndpointAuthorization[];
    Marker?: string;
}
export interface DescribeEventCategoriesMessage {
    SourceType?: string;
}
export interface EventInfoMap {
    EventId?: string;
    EventCategories?: string[];
    EventDescription?: string;
    Severity?: string;
}
export type EventInfoMapList = EventInfoMap[];
export interface EventCategoriesMap {
    SourceType?: string;
    Events?: EventInfoMap[];
}
export type EventCategoriesMapList = EventCategoriesMap[];
export interface EventCategoriesMessage {
    EventCategoriesMapList?: EventCategoriesMap[];
}
export type SourceType = "cluster" | "cluster-parameter-group" | "cluster-security-group" | "cluster-snapshot" | "scheduled-action" | (string & {});
export interface DescribeEventsMessage {
    SourceIdentifier?: string;
    SourceType?: SourceType;
    StartTime?: Date;
    EndTime?: Date;
    Duration?: number;
    MaxRecords?: number;
    Marker?: string;
}
export interface Event {
    SourceIdentifier?: string;
    SourceType?: SourceType;
    Message?: string;
    EventCategories?: string[];
    Severity?: string;
    Date?: Date;
    EventId?: string;
}
export type EventList = Event[];
export interface EventsMessage {
    Marker?: string;
    Events?: Event[];
}
export interface DescribeEventSubscriptionsMessage {
    SubscriptionName?: string;
    MaxRecords?: number;
    Marker?: string;
    TagKeys?: string[];
    TagValues?: string[];
}
export type EventSubscriptionsList = EventSubscription[];
export interface EventSubscriptionsMessage {
    Marker?: string;
    EventSubscriptionsList?: EventSubscription[];
}
export interface DescribeHsmClientCertificatesMessage {
    HsmClientCertificateIdentifier?: string;
    MaxRecords?: number;
    Marker?: string;
    TagKeys?: string[];
    TagValues?: string[];
}
export type HsmClientCertificateList = HsmClientCertificate[];
export interface HsmClientCertificateMessage {
    Marker?: string;
    HsmClientCertificates?: HsmClientCertificate[];
}
export interface DescribeHsmConfigurationsMessage {
    HsmConfigurationIdentifier?: string;
    MaxRecords?: number;
    Marker?: string;
    TagKeys?: string[];
    TagValues?: string[];
}
export type HsmConfigurationList = HsmConfiguration[];
export interface HsmConfigurationMessage {
    Marker?: string;
    HsmConfigurations?: HsmConfiguration[];
}
export type InboundIntegrationArn = string;
export interface DescribeInboundIntegrationsMessage {
    IntegrationArn?: string;
    TargetArn?: string;
    MaxRecords?: number;
    Marker?: string;
}
export interface InboundIntegration {
    IntegrationArn?: string;
    SourceArn?: string;
    TargetArn?: string;
    Status?: ZeroETLIntegrationStatus;
    Errors?: IntegrationError[];
    CreateTime?: Date;
}
export type InboundIntegrationList = InboundIntegration[];
export interface InboundIntegrationsMessage {
    Marker?: string;
    InboundIntegrations?: (InboundIntegration & {
        Errors: (IntegrationError & {
            ErrorCode: string;
        })[];
    })[];
}
export type DescribeIntegrationsFilterName = "integration-arn" | "source-arn" | "source-types" | "status" | (string & {});
export type DescribeIntegrationsFilterValueList = string[];
export interface DescribeIntegrationsFilter {
    Name?: DescribeIntegrationsFilterName;
    Values?: string[];
}
export type DescribeIntegrationsFilterList = DescribeIntegrationsFilter[];
export interface DescribeIntegrationsMessage {
    IntegrationArn?: string;
    MaxRecords?: number;
    Marker?: string;
    Filters?: DescribeIntegrationsFilter[];
}
export type IntegrationList = Integration[];
export interface IntegrationsMessage {
    Marker?: string;
    Integrations?: (Integration & {
        Errors: (IntegrationError & {
            ErrorCode: string;
        })[];
    })[];
}
export interface DescribeLoggingStatusMessage {
    ClusterIdentifier?: string;
}
export type S3KeyPrefixValue = string;
export type LogDestinationType = "s3" | "cloudwatch" | "s3table" | (string & {});
export interface LoggingStatus {
    LoggingEnabled?: boolean;
    BucketName?: string;
    S3KeyPrefix?: string;
    LastSuccessfulDeliveryTime?: Date;
    LastFailureTime?: Date;
    LastFailureMessage?: string;
    LogDestinationType?: LogDestinationType;
    LogExports?: string[];
    S3Tables?: S3TablePublishStatus;
}
export type ActionType = "restore-cluster" | "recommend-node-config" | "resize-cluster" | (string & {});
export type NodeConfigurationOptionsFilterName = "NodeType" | "NumberOfNodes" | "EstimatedDiskUtilizationPercent" | "Mode" | (string & {});
export type OperatorType = "eq" | "lt" | "gt" | "le" | "ge" | "in" | "between" | (string & {});
export interface NodeConfigurationOptionsFilter {
    Name?: NodeConfigurationOptionsFilterName;
    Operator?: OperatorType;
    Values?: string[];
}
export type NodeConfigurationOptionsFilterList = NodeConfigurationOptionsFilter[];
export interface DescribeNodeConfigurationOptionsMessage {
    ActionType?: ActionType;
    ClusterIdentifier?: string;
    SnapshotIdentifier?: string;
    SnapshotArn?: string;
    OwnerAccount?: string;
    Filters?: NodeConfigurationOptionsFilter[];
    Marker?: string;
    MaxRecords?: number;
}
export type Mode = "standard" | "high-performance" | (string & {});
export interface NodeConfigurationOption {
    NodeType?: string;
    NumberOfNodes?: number;
    EstimatedDiskUtilizationPercent?: number;
    Mode?: Mode;
}
export type NodeConfigurationOptionList = NodeConfigurationOption[];
export interface NodeConfigurationOptionsMessage {
    NodeConfigurationOptionList?: NodeConfigurationOption[];
    Marker?: string;
}
export interface DescribeOrderableClusterOptionsMessage {
    ClusterVersion?: string;
    NodeType?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type AvailabilityZoneList = AvailabilityZone[];
export interface OrderableClusterOption {
    ClusterVersion?: string;
    ClusterType?: string;
    NodeType?: string;
    AvailabilityZones?: AvailabilityZone[];
}
export type OrderableClusterOptionsList = OrderableClusterOption[];
export interface OrderableClusterOptionsMessage {
    OrderableClusterOptions?: OrderableClusterOption[];
    Marker?: string;
}
export interface DescribePartnersInputMessage {
    AccountId?: string;
    ClusterIdentifier?: string;
    DatabaseName?: string;
    PartnerName?: string;
}
export type PartnerIntegrationStatus = "Active" | "Inactive" | "RuntimeFailure" | "ConnectionFailure" | (string & {});
export type PartnerIntegrationStatusMessage = string;
export interface PartnerIntegrationInfo {
    DatabaseName?: string;
    PartnerName?: string;
    Status?: PartnerIntegrationStatus;
    StatusMessage?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type PartnerIntegrationInfoList = PartnerIntegrationInfo[];
export interface DescribePartnersOutputMessage {
    PartnerIntegrationInfoList?: PartnerIntegrationInfo[];
}
export interface DescribeQev2IdcApplicationsMessage {
    Qev2IdcApplicationArn?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type Qev2IdcApplicationList = Qev2IdcApplication[];
export interface DescribeQev2IdcApplicationsResult {
    Qev2IdcApplications?: Qev2IdcApplication[];
    Marker?: string;
}
export interface DescribeRedshiftIdcApplicationsMessage {
    RedshiftIdcApplicationArn?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type RedshiftIdcApplicationList = RedshiftIdcApplication[];
export interface DescribeRedshiftIdcApplicationsResult {
    RedshiftIdcApplications?: RedshiftIdcApplication[];
    Marker?: string;
}
export interface DescribeReservedNodeExchangeStatusInputMessage {
    ReservedNodeId?: string;
    ReservedNodeExchangeRequestId?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type ReservedNodeExchangeStatusList = ReservedNodeExchangeStatus[];
export interface DescribeReservedNodeExchangeStatusOutputMessage {
    ReservedNodeExchangeStatusDetails?: ReservedNodeExchangeStatus[];
    Marker?: string;
}
export interface DescribeReservedNodeOfferingsMessage {
    ReservedNodeOfferingId?: string;
    MaxRecords?: number;
    Marker?: string;
}
export interface ReservedNodeOffering {
    ReservedNodeOfferingId?: string;
    NodeType?: string;
    Duration?: number;
    FixedPrice?: number;
    UsagePrice?: number;
    CurrencyCode?: string;
    OfferingType?: string;
    RecurringCharges?: RecurringCharge[];
    ReservedNodeOfferingType?: ReservedNodeOfferingType;
}
export type ReservedNodeOfferingList = ReservedNodeOffering[];
export interface ReservedNodeOfferingsMessage {
    Marker?: string;
    ReservedNodeOfferings?: ReservedNodeOffering[];
}
export interface DescribeReservedNodesMessage {
    ReservedNodeId?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type ReservedNodeList = ReservedNode[];
export interface ReservedNodesMessage {
    Marker?: string;
    ReservedNodes?: ReservedNode[];
}
export interface DescribeResizeMessage {
    ClusterIdentifier?: string;
}
export type ScheduledActionTypeValues = "ResizeCluster" | "PauseCluster" | "ResumeCluster" | (string & {});
export type ScheduledActionFilterName = "cluster-identifier" | "iam-role" | (string & {});
export interface ScheduledActionFilter {
    Name?: ScheduledActionFilterName;
    Values?: string[];
}
export type ScheduledActionFilterList = ScheduledActionFilter[];
export interface DescribeScheduledActionsMessage {
    ScheduledActionName?: string;
    TargetActionType?: ScheduledActionTypeValues;
    StartTime?: Date;
    EndTime?: Date;
    Active?: boolean;
    Filters?: ScheduledActionFilter[];
    Marker?: string;
    MaxRecords?: number;
}
export type ScheduledActionList = ScheduledAction[];
export interface ScheduledActionsMessage {
    Marker?: string;
    ScheduledActions?: (ScheduledAction & {
        TargetAction: ScheduledActionType & {
            ResizeCluster: ResizeClusterMessage & {
                ClusterIdentifier: string;
            };
            PauseCluster: PauseClusterMessage & {
                ClusterIdentifier: string;
            };
            ResumeCluster: ResumeClusterMessage & {
                ClusterIdentifier: string;
            };
        };
    })[];
}
export interface DescribeSnapshotCopyGrantsMessage {
    SnapshotCopyGrantName?: string;
    MaxRecords?: number;
    Marker?: string;
    TagKeys?: string[];
    TagValues?: string[];
}
export type SnapshotCopyGrantList = SnapshotCopyGrant[];
export interface SnapshotCopyGrantMessage {
    Marker?: string;
    SnapshotCopyGrants?: SnapshotCopyGrant[];
}
export interface DescribeSnapshotSchedulesMessage {
    ClusterIdentifier?: string;
    ScheduleIdentifier?: string;
    TagKeys?: string[];
    TagValues?: string[];
    Marker?: string;
    MaxRecords?: number;
}
export type SnapshotScheduleList = SnapshotSchedule[];
export interface DescribeSnapshotSchedulesOutputMessage {
    SnapshotSchedules?: SnapshotSchedule[];
    Marker?: string;
}
export interface DescribeStorageRequest {
}
export interface CustomerStorageMessage {
    TotalBackupSizeInMegaBytes?: number;
    TotalProvisionedStorageInMegaBytes?: number;
}
export interface DescribeTableRestoreStatusMessage {
    ClusterIdentifier?: string;
    TableRestoreRequestId?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type TableRestoreStatusType = "PENDING" | "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | "CANCELED" | (string & {});
export interface TableRestoreStatus {
    TableRestoreRequestId?: string;
    Status?: TableRestoreStatusType;
    Message?: string;
    RequestTime?: Date;
    ProgressInMegaBytes?: number;
    TotalDataInMegaBytes?: number;
    ClusterIdentifier?: string;
    SnapshotIdentifier?: string;
    SourceDatabaseName?: string;
    SourceSchemaName?: string;
    SourceTableName?: string;
    TargetDatabaseName?: string;
    TargetSchemaName?: string;
    NewTableName?: string;
}
export type TableRestoreStatusList = TableRestoreStatus[];
export interface TableRestoreStatusMessage {
    TableRestoreStatusDetails?: TableRestoreStatus[];
    Marker?: string;
}
export interface DescribeTagsMessage {
    ResourceName?: string;
    ResourceType?: string;
    MaxRecords?: number;
    Marker?: string;
    TagKeys?: string[];
    TagValues?: string[];
}
export interface TaggedResource {
    Tag?: Tag;
    ResourceName?: string;
    ResourceType?: string;
}
export type TaggedResourceList = TaggedResource[];
export interface TaggedResourceListMessage {
    TaggedResources?: TaggedResource[];
    Marker?: string;
}
export interface DescribeUsageLimitsMessage {
    UsageLimitId?: string;
    ClusterIdentifier?: string;
    FeatureType?: UsageLimitFeatureType;
    MaxRecords?: number;
    Marker?: string;
    TagKeys?: string[];
    TagValues?: string[];
}
export type UsageLimits = UsageLimit[];
export interface UsageLimitList {
    UsageLimits?: UsageLimit[];
    Marker?: string;
}
export interface DisableLoggingMessage {
    ClusterIdentifier?: string;
    LogDestinationType?: LogDestinationType;
    LogExports?: string[];
}
export interface DisableSnapshotCopyMessage {
    ClusterIdentifier?: string;
}
export interface DisableSnapshotCopyResult {
    Cluster?: Cluster;
}
export interface DisassociateDataShareConsumerMessage {
    DataShareArn?: string;
    DisassociateEntireAccount?: boolean;
    ConsumerArn?: string;
    ConsumerRegion?: string;
}
export interface EnableLoggingMessage {
    ClusterIdentifier?: string;
    BucketName?: string;
    S3KeyPrefix?: string;
    LogDestinationType?: LogDestinationType;
    LogExports?: string[];
    S3TableKmsKeyId?: string;
    S3TableGranularity?: string;
}
export interface EnableSnapshotCopyMessage {
    ClusterIdentifier?: string;
    DestinationRegion?: string;
    RetentionPeriod?: number;
    SnapshotCopyGrantName?: string;
    ManualSnapshotRetentionPeriod?: number;
}
export interface EnableSnapshotCopyResult {
    Cluster?: Cluster;
}
export interface FailoverPrimaryComputeInputMessage {
    ClusterIdentifier?: string;
}
export interface FailoverPrimaryComputeResult {
    Cluster?: Cluster;
}
export type DbGroupList = string[];
export interface GetClusterCredentialsMessage {
    DbUser?: string;
    DbName?: string;
    ClusterIdentifier?: string;
    DurationSeconds?: number;
    AutoCreate?: boolean;
    DbGroups?: string[];
    CustomDomainName?: string;
}
export interface ClusterCredentials {
    DbUser?: string;
    DbPassword?: string | redacted.Redacted<string>;
    Expiration?: Date;
}
export interface GetClusterCredentialsWithIAMMessage {
    DbName?: string;
    ClusterIdentifier?: string;
    DurationSeconds?: number;
    CustomDomainName?: string;
}
export interface ClusterExtendedCredentials {
    DbUser?: string;
    DbPassword?: string | redacted.Redacted<string>;
    Expiration?: Date;
    NextRefreshTime?: Date;
}
export type ClusterIdentifierList = string[];
export interface GetIdentityCenterAuthTokenRequest {
    ClusterIds?: string[];
}
export interface GetIdentityCenterAuthTokenResponse {
    Token?: string | redacted.Redacted<string>;
    ExpirationTime?: Date;
}
export type ReservedNodeExchangeActionType = "restore-cluster" | "resize-cluster" | (string & {});
export interface GetReservedNodeExchangeConfigurationOptionsInputMessage {
    ActionType?: ReservedNodeExchangeActionType;
    ClusterIdentifier?: string;
    SnapshotIdentifier?: string;
    MaxRecords?: number;
    Marker?: string;
}
export interface ReservedNodeConfigurationOption {
    SourceReservedNode?: ReservedNode;
    TargetReservedNodeCount?: number;
    TargetReservedNodeOffering?: ReservedNodeOffering;
}
export type ReservedNodeConfigurationOptionList = ReservedNodeConfigurationOption[];
export interface GetReservedNodeExchangeConfigurationOptionsOutputMessage {
    Marker?: string;
    ReservedNodeConfigurationOptionList?: ReservedNodeConfigurationOption[];
}
export interface GetReservedNodeExchangeOfferingsInputMessage {
    ReservedNodeId?: string;
    MaxRecords?: number;
    Marker?: string;
}
export interface GetReservedNodeExchangeOfferingsOutputMessage {
    Marker?: string;
    ReservedNodeOfferings?: ReservedNodeOffering[];
}
export interface GetResourcePolicyMessage {
    ResourceArn?: string;
}
export interface ResourcePolicy {
    ResourceArn?: string;
    Policy?: string;
}
export interface GetResourcePolicyResult {
    ResourcePolicy?: ResourcePolicy;
}
export interface ListRecommendationsMessage {
    ClusterIdentifier?: string;
    NamespaceArn?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type ImpactRankingType = "HIGH" | "MEDIUM" | "LOW" | (string & {});
export type RecommendedActionType = "SQL" | "CLI" | (string & {});
export interface RecommendedAction {
    Text?: string;
    Database?: string;
    Command?: string;
    Type?: RecommendedActionType;
}
export type RecommendedActionList = RecommendedAction[];
export interface ReferenceLink {
    Text?: string;
    Link?: string;
}
export type ReferenceLinkList = ReferenceLink[];
export interface Recommendation {
    Id?: string;
    ClusterIdentifier?: string;
    NamespaceArn?: string;
    CreatedAt?: Date;
    RecommendationType?: string;
    Title?: string;
    Description?: string;
    Observation?: string;
    ImpactRanking?: ImpactRankingType;
    RecommendationText?: string;
    RecommendedActions?: RecommendedAction[];
    ReferenceLinks?: ReferenceLink[];
}
export type RecommendationList = Recommendation[];
export interface ListRecommendationsResult {
    Recommendations?: Recommendation[];
    Marker?: string;
}
export interface ModifyAquaInputMessage {
    ClusterIdentifier?: string;
    AquaConfigurationStatus?: AquaConfigurationStatus;
}
export interface ModifyAquaOutputMessage {
    AquaConfiguration?: AquaConfiguration;
}
export interface ModifyAuthenticationProfileMessage {
    AuthenticationProfileName?: string;
    AuthenticationProfileContent?: string;
}
export interface ModifyAuthenticationProfileResult {
    AuthenticationProfileName?: string;
    AuthenticationProfileContent?: string;
}
export interface ModifyClusterMessage {
    ClusterIdentifier?: string;
    ClusterType?: string;
    NodeType?: string;
    NumberOfNodes?: number;
    ClusterSecurityGroups?: string[];
    VpcSecurityGroupIds?: string[];
    MasterUserPassword?: string | redacted.Redacted<string>;
    ClusterParameterGroupName?: string;
    AutomatedSnapshotRetentionPeriod?: number;
    ManualSnapshotRetentionPeriod?: number;
    PreferredMaintenanceWindow?: string;
    ClusterVersion?: string;
    AllowVersionUpgrade?: boolean;
    HsmClientCertificateIdentifier?: string;
    HsmConfigurationIdentifier?: string;
    NewClusterIdentifier?: string;
    PubliclyAccessible?: boolean;
    ElasticIp?: string;
    EnhancedVpcRouting?: boolean;
    MaintenanceTrackName?: string;
    Encrypted?: boolean;
    KmsKeyId?: string;
    AvailabilityZoneRelocation?: boolean;
    AvailabilityZone?: string;
    Port?: number;
    ManageMasterPassword?: boolean;
    MasterPasswordSecretKmsKeyId?: string;
    IpAddressType?: string;
    MultiAZ?: boolean;
    ExtraComputeForAutomaticOptimization?: boolean;
}
export interface ModifyClusterResult {
    Cluster?: Cluster;
}
export interface ModifyClusterDbRevisionMessage {
    ClusterIdentifier?: string;
    RevisionTarget?: string;
}
export interface ModifyClusterDbRevisionResult {
    Cluster?: Cluster;
}
export interface ModifyClusterIamRolesMessage {
    ClusterIdentifier?: string;
    AddIamRoles?: string[];
    RemoveIamRoles?: string[];
    DefaultIamRoleArn?: string;
}
export interface ModifyClusterIamRolesResult {
    Cluster?: Cluster;
}
export interface ModifyClusterMaintenanceMessage {
    ClusterIdentifier?: string;
    DeferMaintenance?: boolean;
    DeferMaintenanceIdentifier?: string;
    DeferMaintenanceStartTime?: Date;
    DeferMaintenanceEndTime?: Date;
    DeferMaintenanceDuration?: number;
}
export interface ModifyClusterMaintenanceResult {
    Cluster?: Cluster;
}
export interface ModifyClusterParameterGroupMessage {
    ParameterGroupName?: string;
    Parameters?: Parameter[];
}
export interface ClusterParameterGroupNameMessage {
    ParameterGroupName?: string;
    ParameterGroupStatus?: string;
}
export interface ModifyClusterSnapshotMessage {
    SnapshotIdentifier?: string;
    ManualSnapshotRetentionPeriod?: number;
    Force?: boolean;
}
export interface ModifyClusterSnapshotResult {
    Snapshot?: Snapshot;
}
export interface ModifyClusterSnapshotScheduleMessage {
    ClusterIdentifier?: string;
    ScheduleIdentifier?: string;
    DisassociateSchedule?: boolean;
}
export interface ModifyClusterSnapshotScheduleResponse {
}
export interface ModifyClusterSubnetGroupMessage {
    ClusterSubnetGroupName?: string;
    Description?: string;
    SubnetIds?: string[];
}
export interface ModifyClusterSubnetGroupResult {
    ClusterSubnetGroup?: ClusterSubnetGroup;
}
export interface ModifyCustomDomainAssociationMessage {
    CustomDomainName?: string;
    CustomDomainCertificateArn?: string;
    ClusterIdentifier?: string;
}
export interface ModifyCustomDomainAssociationResult {
    CustomDomainName?: string;
    CustomDomainCertificateArn?: string;
    ClusterIdentifier?: string;
    CustomDomainCertExpiryTime?: string;
}
export interface ModifyEndpointAccessMessage {
    EndpointName?: string;
    VpcSecurityGroupIds?: string[];
}
export interface ModifyEventSubscriptionMessage {
    SubscriptionName?: string;
    SnsTopicArn?: string;
    SourceType?: string;
    SourceIds?: string[];
    EventCategories?: string[];
    Severity?: string;
    Enabled?: boolean;
}
export interface ModifyEventSubscriptionResult {
    EventSubscription?: EventSubscription;
}
export interface ModifyIntegrationMessage {
    IntegrationArn?: string;
    Description?: string;
    IntegrationName?: string;
}
export type LakehouseRegistration = "Register" | "Deregister" | (string & {});
export type LakehouseIdcRegistration = "Associate" | "Disassociate" | (string & {});
export interface ModifyLakehouseConfigurationMessage {
    ClusterIdentifier?: string;
    LakehouseRegistration?: LakehouseRegistration;
    CatalogName?: string;
    LakehouseIdcRegistration?: LakehouseIdcRegistration;
    LakehouseIdcApplicationArn?: string;
    DryRun?: boolean;
}
export interface LakehouseConfiguration {
    ClusterIdentifier?: string;
    LakehouseIdcApplicationArn?: string;
    LakehouseRegistrationStatus?: string;
    CatalogArn?: string;
}
export interface ModifyQev2IdcApplicationMessage {
    Qev2IdcApplicationArn?: string;
    IdcDisplayName?: string;
}
export interface ModifyQev2IdcApplicationResult {
    Qev2IdcApplication?: Qev2IdcApplication;
}
export interface ModifyRedshiftIdcApplicationMessage {
    RedshiftIdcApplicationArn?: string;
    IdentityNamespace?: string;
    IamRoleArn?: string;
    IdcDisplayName?: string;
    AuthorizedTokenIssuerList?: AuthorizedTokenIssuer[];
    ServiceIntegrations?: ServiceIntegrationsUnion[];
}
export interface ModifyRedshiftIdcApplicationResult {
    RedshiftIdcApplication?: RedshiftIdcApplication;
}
export interface ModifyScheduledActionMessage {
    ScheduledActionName?: string;
    TargetAction?: ScheduledActionType;
    Schedule?: string;
    IamRole?: string;
    ScheduledActionDescription?: string;
    StartTime?: Date;
    EndTime?: Date;
    Enable?: boolean;
}
export interface ModifySnapshotCopyRetentionPeriodMessage {
    ClusterIdentifier?: string;
    RetentionPeriod?: number;
    Manual?: boolean;
}
export interface ModifySnapshotCopyRetentionPeriodResult {
    Cluster?: Cluster;
}
export interface ModifySnapshotScheduleMessage {
    ScheduleIdentifier?: string;
    ScheduleDefinitions?: string[];
}
export interface ModifyUsageLimitMessage {
    UsageLimitId?: string;
    Amount?: number;
    BreachAction?: UsageLimitBreachAction;
}
export interface PauseClusterResult {
    Cluster?: Cluster;
}
export interface PurchaseReservedNodeOfferingMessage {
    ReservedNodeOfferingId?: string;
    NodeCount?: number;
}
export interface PurchaseReservedNodeOfferingResult {
    ReservedNode?: ReservedNode;
}
export interface PutResourcePolicyMessage {
    ResourceArn?: string;
    Policy?: string;
}
export interface PutResourcePolicyResult {
    ResourcePolicy?: ResourcePolicy;
}
export interface RebootClusterMessage {
    ClusterIdentifier?: string;
}
export interface RebootClusterResult {
    Cluster?: Cluster;
}
export interface RegisterNamespaceInputMessage {
    NamespaceIdentifier?: NamespaceIdentifierUnion;
    ConsumerIdentifiers?: string[];
}
export interface RegisterNamespaceOutputMessage {
    Status?: NamespaceRegistrationStatus;
}
export interface RejectDataShareMessage {
    DataShareArn?: string;
}
export interface ResetClusterParameterGroupMessage {
    ParameterGroupName?: string;
    ResetAllParameters?: boolean;
    Parameters?: Parameter[];
}
export interface ResizeClusterResult {
    Cluster?: Cluster;
}
export interface RestoreFromClusterSnapshotMessage {
    ClusterIdentifier?: string;
    SnapshotIdentifier?: string;
    SnapshotArn?: string;
    SnapshotClusterIdentifier?: string;
    Port?: number;
    AvailabilityZone?: string;
    AllowVersionUpgrade?: boolean;
    ClusterSubnetGroupName?: string;
    PubliclyAccessible?: boolean;
    OwnerAccount?: string;
    HsmClientCertificateIdentifier?: string;
    HsmConfigurationIdentifier?: string;
    ElasticIp?: string;
    ClusterParameterGroupName?: string;
    ClusterSecurityGroups?: string[];
    VpcSecurityGroupIds?: string[];
    PreferredMaintenanceWindow?: string;
    AutomatedSnapshotRetentionPeriod?: number;
    ManualSnapshotRetentionPeriod?: number;
    KmsKeyId?: string;
    NodeType?: string;
    EnhancedVpcRouting?: boolean;
    AdditionalInfo?: string;
    IamRoles?: string[];
    MaintenanceTrackName?: string;
    SnapshotScheduleIdentifier?: string;
    NumberOfNodes?: number;
    AvailabilityZoneRelocation?: boolean;
    AquaConfigurationStatus?: AquaConfigurationStatus;
    DefaultIamRoleArn?: string;
    ReservedNodeId?: string;
    TargetReservedNodeOfferingId?: string;
    Encrypted?: boolean;
    ManageMasterPassword?: boolean;
    MasterPasswordSecretKmsKeyId?: string;
    IpAddressType?: string;
    MultiAZ?: boolean;
    CatalogName?: string;
    RedshiftIdcApplicationArn?: string;
}
export interface RestoreFromClusterSnapshotResult {
    Cluster?: Cluster;
}
export interface RestoreTableFromClusterSnapshotMessage {
    ClusterIdentifier?: string;
    SnapshotIdentifier?: string;
    SourceDatabaseName?: string;
    SourceSchemaName?: string;
    SourceTableName?: string;
    TargetDatabaseName?: string;
    TargetSchemaName?: string;
    NewTableName?: string;
    EnableCaseSensitiveIdentifier?: boolean;
}
export interface RestoreTableFromClusterSnapshotResult {
    TableRestoreStatus?: TableRestoreStatus;
}
export interface ResumeClusterResult {
    Cluster?: Cluster;
}
export interface RevokeClusterSecurityGroupIngressMessage {
    ClusterSecurityGroupName?: string;
    CIDRIP?: string;
    EC2SecurityGroupName?: string;
    EC2SecurityGroupOwnerId?: string;
}
export interface RevokeClusterSecurityGroupIngressResult {
    ClusterSecurityGroup?: ClusterSecurityGroup;
}
export interface RevokeEndpointAccessMessage {
    ClusterIdentifier?: string;
    Account?: string;
    VpcIds?: string[];
    Force?: boolean;
}
export interface RevokeSnapshotAccessMessage {
    SnapshotIdentifier?: string;
    SnapshotArn?: string;
    SnapshotClusterIdentifier?: string;
    AccountWithRestoreAccess?: string;
}
export interface RevokeSnapshotAccessResult {
    Snapshot?: Snapshot;
}
export interface RotateEncryptionKeyMessage {
    ClusterIdentifier?: string;
}
export interface RotateEncryptionKeyResult {
    Cluster?: Cluster;
}
export interface UpdatePartnerStatusInputMessage {
    AccountId?: string;
    ClusterIdentifier?: string;
    DatabaseName?: string;
    PartnerName?: string;
    Status?: PartnerIntegrationStatus;
    StatusMessage?: string;
}
export type ExceptionMessage = string;
export type AcceptReservedNodeExchangeError = DependentServiceUnavailableFault | InvalidReservedNodeStateFault | ReservedNodeAlreadyExistsFault | ReservedNodeAlreadyMigratedFault | ReservedNodeNotFoundFault | ReservedNodeOfferingNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Exchanges a DC1 Reserved Node for a DC2 Reserved Node with no changes to the
 * configuration (term, payment type, or number of nodes) and no additional costs.
 */
export declare const acceptReservedNodeExchange: API.OperationMethod<AcceptReservedNodeExchangeInputMessage, AcceptReservedNodeExchangeOutputMessage, AcceptReservedNodeExchangeError, Credentials | HttpClient.HttpClient>;
export type AddPartnerError = ClusterNotFoundFault | PartnerNotFoundFault | UnauthorizedPartnerIntegrationFault | UnsupportedOperationFault | CommonErrors;
/**
 * Adds a partner integration to a cluster.
 * This operation authorizes a partner to push status updates for the specified database.
 * To complete the integration, you also set up the integration on the partner website.
 */
export declare const addPartner: API.OperationMethod<PartnerIntegrationInputMessage, PartnerIntegrationOutputMessage, AddPartnerError, Credentials | HttpClient.HttpClient>;
export type AssociateDataShareConsumerError = InvalidDataShareFault | InvalidNamespaceFault | CommonErrors;
/**
 * From a datashare consumer account, associates a datashare with the
 * account (AssociateEntireAccount) or the specified namespace (ConsumerArn). If you make this association, the consumer
 * can consume the datashare.
 */
export declare const associateDataShareConsumer: API.OperationMethod<AssociateDataShareConsumerMessage, DataShare, AssociateDataShareConsumerError, Credentials | HttpClient.HttpClient>;
export type AuthorizeClusterSecurityGroupIngressError = AuthorizationAlreadyExistsFault | AuthorizationQuotaExceededFault | ClusterSecurityGroupNotFoundFault | InvalidClusterSecurityGroupStateFault | CommonErrors;
/**
 * Adds an inbound (ingress) rule to an Amazon Redshift security group. Depending on whether
 * the application accessing your cluster is running on the Internet or an Amazon EC2
 * instance, you can authorize inbound access to either a Classless Interdomain Routing
 * (CIDR)/Internet Protocol (IP) range or to an Amazon EC2 security group. You can add as
 * many as 20 ingress rules to an Amazon Redshift security group.
 *
 * If you authorize access to an Amazon EC2 security group, specify
 * *EC2SecurityGroupName* and
 * *EC2SecurityGroupOwnerId*. The Amazon EC2 security group and
 * Amazon Redshift cluster must be in the same Amazon Web Services Region.
 *
 * If you authorize access to a CIDR/IP address range, specify
 * *CIDRIP*. For an overview of CIDR blocks, see the Wikipedia
 * article on Classless Inter-Domain Routing.
 *
 * You must also associate the security group with a cluster so that clients running
 * on these IP addresses or the EC2 instance are authorized to connect to the cluster. For
 * information about managing security groups, go to Working with Security
 * Groups in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const authorizeClusterSecurityGroupIngress: API.OperationMethod<AuthorizeClusterSecurityGroupIngressMessage, AuthorizeClusterSecurityGroupIngressResult, AuthorizeClusterSecurityGroupIngressError, Credentials | HttpClient.HttpClient>;
export type AuthorizeDataShareError = InvalidDataShareFault | CommonErrors;
/**
 * From a data producer account, authorizes the sharing of a datashare with one or more
 * consumer accounts or managing entities. To authorize a datashare for a data consumer,
 * the producer account must have the correct access permissions.
 */
export declare const authorizeDataShare: API.OperationMethod<AuthorizeDataShareMessage, DataShare, AuthorizeDataShareError, Credentials | HttpClient.HttpClient>;
export type AuthorizeEndpointAccessError = ClusterNotFoundFault | EndpointAuthorizationAlreadyExistsFault | EndpointAuthorizationsPerClusterLimitExceededFault | InvalidAuthorizationStateFault | InvalidClusterStateFault | UnsupportedOperationFault | CommonErrors;
/**
 * Grants access to a cluster.
 */
export declare const authorizeEndpointAccess: API.OperationMethod<AuthorizeEndpointAccessMessage, EndpointAuthorization, AuthorizeEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type AuthorizeSnapshotAccessError = AuthorizationAlreadyExistsFault | AuthorizationQuotaExceededFault | ClusterSnapshotNotFoundFault | DependentServiceRequestThrottlingFault | InvalidClusterSnapshotStateFault | LimitExceededFault | UnsupportedOperationFault | CommonErrors;
/**
 * Authorizes the specified Amazon Web Services account to restore the specified
 * snapshot.
 *
 * For more information about working with snapshots, go to
 * Amazon Redshift Snapshots
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const authorizeSnapshotAccess: API.OperationMethod<AuthorizeSnapshotAccessMessage, AuthorizeSnapshotAccessResult, AuthorizeSnapshotAccessError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteClusterSnapshotsError = BatchDeleteRequestSizeExceededFault | CommonErrors;
/**
 * Deletes a set of cluster snapshots.
 */
export declare const batchDeleteClusterSnapshots: API.OperationMethod<BatchDeleteClusterSnapshotsRequest, BatchDeleteClusterSnapshotsResult, BatchDeleteClusterSnapshotsError, Credentials | HttpClient.HttpClient>;
export type BatchModifyClusterSnapshotsError = BatchModifyClusterSnapshotsLimitExceededFault | InvalidRetentionPeriodFault | CommonErrors;
/**
 * Modifies the settings for a set of cluster snapshots.
 */
export declare const batchModifyClusterSnapshots: API.OperationMethod<BatchModifyClusterSnapshotsMessage, BatchModifyClusterSnapshotsOutputMessage, BatchModifyClusterSnapshotsError, Credentials | HttpClient.HttpClient>;
export type CancelResizeError = ClusterNotFoundFault | InvalidClusterStateFault | ResizeNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Cancels a resize operation for a cluster.
 */
export declare const cancelResize: API.OperationMethod<CancelResizeMessage, ResizeProgressMessage, CancelResizeError, Credentials | HttpClient.HttpClient>;
export type CopyClusterSnapshotError = ClusterNotFoundFault | ClusterSnapshotAlreadyExistsFault | ClusterSnapshotNotFoundFault | ClusterSnapshotQuotaExceededFault | InvalidClusterSnapshotStateFault | InvalidRetentionPeriodFault | CommonErrors;
/**
 * Copies the specified automated cluster snapshot to a new manual cluster snapshot.
 * The source must be an automated snapshot and it must be in the available
 * state.
 *
 * When you delete a cluster, Amazon Redshift deletes any automated snapshots of the
 * cluster. Also, when the retention period of the snapshot expires, Amazon Redshift
 * automatically deletes it. If you want to keep an automated snapshot for a longer period,
 * you can make a manual copy of the snapshot. Manual snapshots are retained until you
 * delete them.
 *
 * For more information about working with snapshots, go to
 * Amazon Redshift Snapshots
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const copyClusterSnapshot: API.OperationMethod<CopyClusterSnapshotMessage, CopyClusterSnapshotResult, CopyClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateAuthenticationProfileError = AuthenticationProfileAlreadyExistsFault | AuthenticationProfileQuotaExceededFault | InvalidAuthenticationProfileRequestFault | CommonErrors;
/**
 * Creates an authentication profile with the specified parameters.
 */
export declare const createAuthenticationProfile: API.OperationMethod<CreateAuthenticationProfileMessage, CreateAuthenticationProfileResult, CreateAuthenticationProfileError, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = ClusterAlreadyExistsFault | ClusterParameterGroupNotFoundFault | ClusterQuotaExceededFault | ClusterSecurityGroupNotFoundFault | ClusterSubnetGroupNotFoundFault | DependentServiceAccessDeniedFault | DependentServiceRequestThrottlingFault | DependentServiceUnavailableFault | HsmClientCertificateNotFoundFault | HsmConfigurationNotFoundFault | InsufficientClusterCapacityFault | InvalidClusterSubnetGroupStateFault | InvalidClusterTrackFault | InvalidElasticIpFault | InvalidRetentionPeriodFault | InvalidSubnet | InvalidTagFault | InvalidVPCNetworkStateFault | Ipv6CidrBlockNotFoundFault | LimitExceededFault | NumberOfNodesPerClusterLimitExceededFault | NumberOfNodesQuotaExceededFault | RedshiftIdcApplicationNotExistsFault | SnapshotScheduleNotFoundFault | TagLimitExceededFault | UnauthorizedOperation | UnsupportedOperationFault | CommonErrors;
/**
 * Creates a new cluster with the specified parameters.
 *
 * To create a cluster in Virtual Private Cloud (VPC), you must provide a cluster
 * subnet group name. The cluster subnet group identifies the subnets of your VPC that
 * Amazon Redshift uses when creating the cluster.
 * For more information about managing clusters, go to
 * Amazon Redshift Clusters
 * in the *Amazon Redshift Cluster Management Guide*.
 *
 * VPC Block Public Access (BPA) enables you to block resources in VPCs and subnets that
 * you own in a Region from reaching or being reached from the internet through internet
 * gateways and egress-only internet gateways. If a subnet group for a
 * provisioned cluster is in an account with VPC BPA turned on, the following capabilities
 * are blocked:
 *
 * - Creating a public cluster
 *
 * - Restoring a public cluster
 *
 * - Modifying a private cluster to be public
 *
 * - Adding a subnet with VPC BPA turned on to the subnet group when there's at
 * least one public cluster within the group
 *
 * For more information about VPC BPA, see Block public access to VPCs and
 * subnets in the *Amazon VPC User Guide*.
 */
export declare const createCluster: API.OperationMethod<CreateClusterMessage, CreateClusterResult, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateClusterParameterGroupError = ClusterParameterGroupAlreadyExistsFault | ClusterParameterGroupQuotaExceededFault | InvalidTagFault | TagLimitExceededFault | CommonErrors;
/**
 * Creates an Amazon Redshift parameter group.
 *
 * Creating parameter groups is independent of creating clusters. You can associate a
 * cluster with a parameter group when you create the cluster. You can also associate an
 * existing cluster with a parameter group after the cluster is created by using ModifyCluster.
 *
 * Parameters in the parameter group define specific behavior that applies to the
 * databases you create on the cluster.
 * For more information about parameters and parameter groups, go to
 * Amazon Redshift Parameter Groups
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const createClusterParameterGroup: API.OperationMethod<CreateClusterParameterGroupMessage, CreateClusterParameterGroupResult, CreateClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CreateClusterSecurityGroupError = ClusterSecurityGroupAlreadyExistsFault | ClusterSecurityGroupQuotaExceededFault | InvalidTagFault | TagLimitExceededFault | CommonErrors;
/**
 * Creates a new Amazon Redshift security group. You use security groups to control access
 * to non-VPC clusters.
 *
 * For information about managing security groups, go to
 * Amazon Redshift Cluster Security Groups in the
 * *Amazon Redshift Cluster Management Guide*.
 */
export declare const createClusterSecurityGroup: API.OperationMethod<CreateClusterSecurityGroupMessage, CreateClusterSecurityGroupResult, CreateClusterSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type CreateClusterSnapshotError = ClusterNotFoundFault | ClusterSnapshotAlreadyExistsFault | ClusterSnapshotQuotaExceededFault | InvalidClusterStateFault | InvalidRetentionPeriodFault | InvalidTagFault | TagLimitExceededFault | CommonErrors;
/**
 * Creates a manual snapshot of the specified cluster. The cluster must be in the
 * `available` state.
 *
 * For more information about working with snapshots, go to
 * Amazon Redshift Snapshots
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const createClusterSnapshot: API.OperationMethod<CreateClusterSnapshotMessage, CreateClusterSnapshotResult, CreateClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateClusterSubnetGroupError = ClusterSubnetGroupAlreadyExistsFault | ClusterSubnetGroupQuotaExceededFault | ClusterSubnetQuotaExceededFault | DependentServiceRequestThrottlingFault | InvalidSubnet | InvalidTagFault | TagLimitExceededFault | UnauthorizedOperation | CommonErrors;
/**
 * Creates a new Amazon Redshift subnet group. You must provide a list of one or more
 * subnets in your existing Amazon Virtual Private Cloud (Amazon VPC) when creating
 * Amazon Redshift subnet group.
 *
 * For information about subnet groups, go to
 * Amazon Redshift Cluster Subnet Groups in the
 * *Amazon Redshift Cluster Management Guide*.
 */
export declare const createClusterSubnetGroup: API.OperationMethod<CreateClusterSubnetGroupMessage, CreateClusterSubnetGroupResult, CreateClusterSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateCustomDomainAssociationError = ClusterNotFoundFault | CustomCnameAssociationFault | UnsupportedOperationFault | CommonErrors;
/**
 * Used to create a custom domain name for a cluster. Properties include the custom domain name, the
 * cluster the custom domain is associated with, and the certificate Amazon Resource Name (ARN).
 */
export declare const createCustomDomainAssociation: API.OperationMethod<CreateCustomDomainAssociationMessage, CreateCustomDomainAssociationResult, CreateCustomDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateEndpointAccessError = AccessToClusterDeniedFault | ClusterNotFoundFault | ClusterSubnetGroupNotFoundFault | EndpointAlreadyExistsFault | EndpointsPerAuthorizationLimitExceededFault | EndpointsPerClusterLimitExceededFault | InvalidClusterSecurityGroupStateFault | InvalidClusterStateFault | UnauthorizedOperation | UnsupportedOperationFault | CommonErrors;
/**
 * Creates a Redshift-managed VPC endpoint.
 */
export declare const createEndpointAccess: API.OperationMethod<CreateEndpointAccessMessage, EndpointAccess, CreateEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type CreateEventSubscriptionError = EventSubscriptionQuotaExceededFault | InvalidTagFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | SNSTopicArnNotFoundFault | SourceNotFoundFault | SubscriptionAlreadyExistFault | SubscriptionCategoryNotFoundFault | SubscriptionEventIdNotFoundFault | SubscriptionSeverityNotFoundFault | TagLimitExceededFault | CommonErrors;
/**
 * Creates an Amazon Redshift event notification subscription. This action requires an ARN
 * (Amazon Resource Name) of an Amazon SNS topic created by either the Amazon Redshift console,
 * the Amazon SNS console, or the Amazon SNS API. To obtain an ARN with Amazon SNS, you
 * must create a topic in Amazon SNS and subscribe to the topic. The ARN is displayed in
 * the SNS console.
 *
 * You can specify the source type, and lists of Amazon Redshift source IDs, event
 * categories, and event severities. Notifications will be sent for all events you want
 * that match those criteria. For example, you can specify source type = cluster, source ID
 * = my-cluster-1 and mycluster2, event categories = Availability, Backup, and severity =
 * ERROR. The subscription will only send notifications for those ERROR events in the
 * Availability and Backup categories for the specified clusters.
 *
 * If you specify both the source type and source IDs, such as source type = cluster
 * and source identifier = my-cluster-1, notifications will be sent for all the cluster
 * events for my-cluster-1. If you specify a source type but do not specify a source
 * identifier, you will receive notice of the events for the objects of that type in your
 * Amazon Web Services account. If you do not specify either the SourceType nor the SourceIdentifier, you
 * will be notified of events generated from all Amazon Redshift sources belonging to your Amazon Web Services account. You must specify a source type if you specify a source ID.
 */
export declare const createEventSubscription: API.OperationMethod<CreateEventSubscriptionMessage, CreateEventSubscriptionResult, CreateEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateHsmClientCertificateError = HsmClientCertificateAlreadyExistsFault | HsmClientCertificateQuotaExceededFault | InvalidTagFault | TagLimitExceededFault | CommonErrors;
/**
 * Creates an HSM client certificate that an Amazon Redshift cluster will use to connect to
 * the client's HSM in order to store and retrieve the keys used to encrypt the cluster
 * databases.
 *
 * The command returns a public key, which you must store in the HSM. In addition to
 * creating the HSM certificate, you must create an Amazon Redshift HSM configuration that
 * provides a cluster the information needed to store and use encryption keys in the HSM.
 * For more information, go to Hardware Security Modules
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const createHsmClientCertificate: API.OperationMethod<CreateHsmClientCertificateMessage, CreateHsmClientCertificateResult, CreateHsmClientCertificateError, Credentials | HttpClient.HttpClient>;
export type CreateHsmConfigurationError = HsmConfigurationAlreadyExistsFault | HsmConfigurationQuotaExceededFault | InvalidTagFault | TagLimitExceededFault | CommonErrors;
/**
 * Creates an HSM configuration that contains the information required by an Amazon Redshift
 * cluster to store and use database encryption keys in a Hardware Security Module (HSM).
 * After creating the HSM configuration, you can specify it as a parameter when creating a
 * cluster. The cluster will then store its encryption keys in the HSM.
 *
 * In addition to creating an HSM configuration, you must also create an HSM client
 * certificate. For more information, go to Hardware Security Modules
 * in the Amazon Redshift Cluster Management Guide.
 */
export declare const createHsmConfiguration: API.OperationMethod<CreateHsmConfigurationMessage, CreateHsmConfigurationResult, CreateHsmConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationError = IntegrationAlreadyExistsFault | IntegrationConflictOperationFault | IntegrationQuotaExceededFault | IntegrationSourceNotFoundFault | IntegrationTargetNotFoundFault | InvalidClusterStateFault | InvalidTagFault | TagLimitExceededFault | UnsupportedOperationFault | CommonErrors;
/**
 * Creates a zero-ETL integration or S3 event integration with Amazon Redshift.
 */
export declare const createIntegration: API.OperationMethod<CreateIntegrationMessage, Integration, CreateIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateQev2IdcApplicationError = DependentServiceAccessDeniedFault | DependentServiceUnavailableFault | Qev2IdcApplicationAlreadyExistsFault | UnsupportedOperationFault | CommonErrors;
/**
 * Creates an Amazon Redshift Query Editor (QEV2) IAM Identity Center application.
 */
export declare const createQev2IdcApplication: API.OperationMethod<CreateQev2IdcApplicationMessage, CreateQev2IdcApplicationResult, CreateQev2IdcApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateRedshiftIdcApplicationError = DependentServiceAccessDeniedFault | DependentServiceUnavailableFault | InvalidTagFault | RedshiftIdcApplicationAlreadyExistsFault | RedshiftIdcApplicationQuotaExceededFault | TagLimitExceededFault | UnsupportedOperationFault | CommonErrors;
/**
 * Creates an Amazon Redshift application for use with IAM Identity Center.
 */
export declare const createRedshiftIdcApplication: API.OperationMethod<CreateRedshiftIdcApplicationMessage, CreateRedshiftIdcApplicationResult, CreateRedshiftIdcApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateScheduledActionError = ClusterNotFoundFault | InvalidScheduledActionFault | InvalidScheduleFault | ScheduledActionAlreadyExistsFault | ScheduledActionQuotaExceededFault | ScheduledActionTypeUnsupportedFault | UnauthorizedOperation | UnsupportedOperationFault | CommonErrors;
/**
 * Creates a scheduled action. A scheduled action contains a schedule and an Amazon Redshift API action.
 * For example, you can create a schedule of when to run the `ResizeCluster` API operation.
 */
export declare const createScheduledAction: API.OperationMethod<CreateScheduledActionMessage, ScheduledAction, CreateScheduledActionError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotCopyGrantError = DependentServiceRequestThrottlingFault | InvalidTagFault | LimitExceededFault | SnapshotCopyGrantAlreadyExistsFault | SnapshotCopyGrantQuotaExceededFault | TagLimitExceededFault | CommonErrors;
/**
 * Creates a snapshot copy grant that permits Amazon Redshift to use an encrypted symmetric key
 * from Key Management Service (KMS) to encrypt copied snapshots in a
 * destination region.
 *
 * For more information about managing snapshot copy grants, go to
 * Amazon Redshift Database Encryption
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const createSnapshotCopyGrant: API.OperationMethod<CreateSnapshotCopyGrantMessage, CreateSnapshotCopyGrantResult, CreateSnapshotCopyGrantError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotScheduleError = InvalidScheduleFault | InvalidTagFault | ScheduleDefinitionTypeUnsupportedFault | SnapshotScheduleAlreadyExistsFault | SnapshotScheduleQuotaExceededFault | TagLimitExceededFault | CommonErrors;
/**
 * Create a snapshot schedule that can be associated to a cluster and which overrides the default system backup schedule.
 */
export declare const createSnapshotSchedule: API.OperationMethod<CreateSnapshotScheduleMessage, SnapshotSchedule, CreateSnapshotScheduleError, Credentials | HttpClient.HttpClient>;
export type CreateTagsError = InvalidClusterStateFault | InvalidTagFault | ResourceNotFoundFault | TagLimitExceededFault | CommonErrors;
/**
 * Adds tags to a cluster.
 *
 * A resource can have up to 50 tags. If you try to create more than 50 tags for a
 * resource, you will receive an error and the attempt will fail.
 *
 * If you specify a key that already exists for the resource, the value for that key
 * will be updated with the new value.
 */
export declare const createTags: API.OperationMethod<CreateTagsMessage, CreateTagsResponse, CreateTagsError, Credentials | HttpClient.HttpClient>;
export type CreateUsageLimitError = ClusterNotFoundFault | InvalidClusterStateFault | InvalidUsageLimitFault | LimitExceededFault | TagLimitExceededFault | UnsupportedOperationFault | UsageLimitAlreadyExistsFault | CommonErrors;
/**
 * Creates a usage limit for a specified Amazon Redshift feature on a cluster.
 * The usage limit is identified by the returned usage limit identifier.
 */
export declare const createUsageLimit: API.OperationMethod<CreateUsageLimitMessage, UsageLimit, CreateUsageLimitError, Credentials | HttpClient.HttpClient>;
export type DeauthorizeDataShareError = InvalidDataShareFault | CommonErrors;
/**
 * From a datashare producer account, removes authorization from the specified datashare.
 */
export declare const deauthorizeDataShare: API.OperationMethod<DeauthorizeDataShareMessage, DataShare, DeauthorizeDataShareError, Credentials | HttpClient.HttpClient>;
export type DeleteAuthenticationProfileError = AuthenticationProfileNotFoundFault | InvalidAuthenticationProfileRequestFault | CommonErrors;
/**
 * Deletes an authentication profile.
 */
export declare const deleteAuthenticationProfile: API.OperationMethod<DeleteAuthenticationProfileMessage, DeleteAuthenticationProfileResult, DeleteAuthenticationProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = ClusterNotFoundFault | ClusterSnapshotAlreadyExistsFault | ClusterSnapshotQuotaExceededFault | InvalidClusterStateFault | InvalidRetentionPeriodFault | CommonErrors;
/**
 * Deletes a previously provisioned cluster without its final snapshot being created. A successful response from the web
 * service indicates that the request was received correctly. Use DescribeClusters to monitor the status of the deletion. The delete
 * operation cannot be canceled or reverted once submitted.
 * For more information about managing clusters, go to
 * Amazon Redshift Clusters
 * in the *Amazon Redshift Cluster Management Guide*.
 *
 * If you want to shut down the cluster and retain it for future use, set
 * *SkipFinalClusterSnapshot* to `false` and specify a
 * name for *FinalClusterSnapshotIdentifier*. You can later restore this
 * snapshot to resume using the cluster. If a final cluster snapshot is requested, the
 * status of the cluster will be "final-snapshot" while the snapshot is being taken, then
 * it's "deleting" once Amazon Redshift begins deleting the cluster.
 *
 * For more information about managing clusters, go to
 * Amazon Redshift Clusters
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterMessage, DeleteClusterResult, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterParameterGroupError = ClusterParameterGroupNotFoundFault | InvalidClusterParameterGroupStateFault | CommonErrors;
/**
 * Deletes a specified Amazon Redshift parameter group.
 *
 * You cannot delete a parameter group if it is associated with a
 * cluster.
 */
export declare const deleteClusterParameterGroup: API.OperationMethod<DeleteClusterParameterGroupMessage, DeleteClusterParameterGroupResponse, DeleteClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterSecurityGroupError = ClusterSecurityGroupNotFoundFault | InvalidClusterSecurityGroupStateFault | CommonErrors;
/**
 * Deletes an Amazon Redshift security group.
 *
 * You cannot delete a security group that is associated with any clusters. You
 * cannot delete the default security group.
 *
 * For information about managing security groups, go to
 * Amazon Redshift Cluster Security Groups in the
 * *Amazon Redshift Cluster Management Guide*.
 */
export declare const deleteClusterSecurityGroup: API.OperationMethod<DeleteClusterSecurityGroupMessage, DeleteClusterSecurityGroupResponse, DeleteClusterSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterSnapshotError = ClusterSnapshotNotFoundFault | InvalidClusterSnapshotStateFault | CommonErrors;
/**
 * Deletes the specified manual snapshot. The snapshot must be in the
 * `available` state, with no other users authorized to access the snapshot.
 *
 * Unlike automated snapshots, manual snapshots are retained even after you delete
 * your cluster. Amazon Redshift does not delete your manual snapshots. You must delete manual
 * snapshot explicitly to avoid getting charged. If other accounts are authorized to access
 * the snapshot, you must revoke all of the authorizations before you can delete the
 * snapshot.
 */
export declare const deleteClusterSnapshot: API.OperationMethod<DeleteClusterSnapshotMessage, DeleteClusterSnapshotResult, DeleteClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterSubnetGroupError = ClusterSubnetGroupNotFoundFault | InvalidClusterSubnetGroupStateFault | InvalidClusterSubnetStateFault | CommonErrors;
/**
 * Deletes the specified cluster subnet group.
 */
export declare const deleteClusterSubnetGroup: API.OperationMethod<DeleteClusterSubnetGroupMessage, DeleteClusterSubnetGroupResponse, DeleteClusterSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomDomainAssociationError = ClusterNotFoundFault | CustomCnameAssociationFault | CustomDomainAssociationNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Contains information about deleting a custom domain association for a cluster.
 */
export declare const deleteCustomDomainAssociation: API.OperationMethod<DeleteCustomDomainAssociationMessage, DeleteCustomDomainAssociationResponse, DeleteCustomDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointAccessError = ClusterNotFoundFault | EndpointNotFoundFault | InvalidClusterSecurityGroupStateFault | InvalidClusterStateFault | InvalidEndpointStateFault | CommonErrors;
/**
 * Deletes a Redshift-managed VPC endpoint.
 */
export declare const deleteEndpointAccess: API.OperationMethod<DeleteEndpointAccessMessage, EndpointAccess, DeleteEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type DeleteEventSubscriptionError = InvalidSubscriptionStateFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Deletes an Amazon Redshift event notification subscription.
 */
export declare const deleteEventSubscription: API.OperationMethod<DeleteEventSubscriptionMessage, DeleteEventSubscriptionResponse, DeleteEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteHsmClientCertificateError = HsmClientCertificateNotFoundFault | InvalidHsmClientCertificateStateFault | CommonErrors;
/**
 * Deletes the specified HSM client certificate.
 */
export declare const deleteHsmClientCertificate: API.OperationMethod<DeleteHsmClientCertificateMessage, DeleteHsmClientCertificateResponse, DeleteHsmClientCertificateError, Credentials | HttpClient.HttpClient>;
export type DeleteHsmConfigurationError = HsmConfigurationNotFoundFault | InvalidHsmConfigurationStateFault | CommonErrors;
/**
 * Deletes the specified Amazon Redshift HSM configuration.
 */
export declare const deleteHsmConfiguration: API.OperationMethod<DeleteHsmConfigurationMessage, DeleteHsmConfigurationResponse, DeleteHsmConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = IntegrationConflictOperationFault | IntegrationConflictStateFault | IntegrationNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Deletes a zero-ETL integration or S3 event integration with Amazon Redshift.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationMessage, Integration, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeletePartnerError = ClusterNotFoundFault | PartnerNotFoundFault | UnauthorizedPartnerIntegrationFault | UnsupportedOperationFault | CommonErrors;
/**
 * Deletes a partner integration from a cluster. Data can still flow to the cluster until the integration is deleted at the partner's website.
 */
export declare const deletePartner: API.OperationMethod<PartnerIntegrationInputMessage, PartnerIntegrationOutputMessage, DeletePartnerError, Credentials | HttpClient.HttpClient>;
export type DeleteQev2IdcApplicationError = DependentServiceAccessDeniedFault | DependentServiceUnavailableFault | Qev2IdcApplicationNotExistsFault | UnsupportedOperationFault | CommonErrors;
/**
 * Deletes an Amazon Redshift Query Editor (QEV2) IAM Identity Center application.
 */
export declare const deleteQev2IdcApplication: API.OperationMethod<DeleteQev2IdcApplicationMessage, DeleteQev2IdcApplicationResponse, DeleteQev2IdcApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteRedshiftIdcApplicationError = DependentServiceAccessDeniedFault | DependentServiceUnavailableFault | RedshiftIdcApplicationNotExistsFault | UnsupportedOperationFault | CommonErrors;
/**
 * Deletes an Amazon Redshift IAM Identity Center application.
 */
export declare const deleteRedshiftIdcApplication: API.OperationMethod<DeleteRedshiftIdcApplicationMessage, DeleteRedshiftIdcApplicationResponse, DeleteRedshiftIdcApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = ResourceNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Deletes the resource policy for a specified resource.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyMessage, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduledActionError = ScheduledActionNotFoundFault | UnauthorizedOperation | CommonErrors;
/**
 * Deletes a scheduled action.
 */
export declare const deleteScheduledAction: API.OperationMethod<DeleteScheduledActionMessage, DeleteScheduledActionResponse, DeleteScheduledActionError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotCopyGrantError = InvalidSnapshotCopyGrantStateFault | SnapshotCopyGrantNotFoundFault | CommonErrors;
/**
 * Deletes the specified snapshot copy grant.
 */
export declare const deleteSnapshotCopyGrant: API.OperationMethod<DeleteSnapshotCopyGrantMessage, DeleteSnapshotCopyGrantResponse, DeleteSnapshotCopyGrantError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotScheduleError = InvalidClusterSnapshotScheduleStateFault | SnapshotScheduleNotFoundFault | CommonErrors;
/**
 * Deletes a snapshot schedule.
 */
export declare const deleteSnapshotSchedule: API.OperationMethod<DeleteSnapshotScheduleMessage, DeleteSnapshotScheduleResponse, DeleteSnapshotScheduleError, Credentials | HttpClient.HttpClient>;
export type DeleteTagsError = InvalidTagFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes tags from a resource. You must provide the ARN of the resource
 * from which you want to delete the tag or tags.
 */
export declare const deleteTags: API.OperationMethod<DeleteTagsMessage, DeleteTagsResponse, DeleteTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteUsageLimitError = UnsupportedOperationFault | UsageLimitNotFoundFault | CommonErrors;
/**
 * Deletes a usage limit from a cluster.
 */
export declare const deleteUsageLimit: API.OperationMethod<DeleteUsageLimitMessage, DeleteUsageLimitResponse, DeleteUsageLimitError, Credentials | HttpClient.HttpClient>;
export type DeregisterNamespaceError = ClusterNotFoundFault | InvalidClusterStateFault | InvalidNamespaceFault | CommonErrors;
/**
 * Deregisters a cluster or serverless namespace from the Amazon Web Services Glue Data Catalog.
 */
export declare const deregisterNamespace: API.OperationMethod<DeregisterNamespaceInputMessage, DeregisterNamespaceOutputMessage, DeregisterNamespaceError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountAttributesError = CommonErrors;
/**
 * Returns a list of attributes attached to an account
 */
export declare const describeAccountAttributes: API.OperationMethod<DescribeAccountAttributesMessage, AccountAttributeList, DescribeAccountAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeAuthenticationProfilesError = AuthenticationProfileNotFoundFault | InvalidAuthenticationProfileRequestFault | CommonErrors;
/**
 * Describes an authentication profile.
 */
export declare const describeAuthenticationProfiles: API.OperationMethod<DescribeAuthenticationProfilesMessage, DescribeAuthenticationProfilesResult, DescribeAuthenticationProfilesError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterDbRevisionsError = ClusterNotFoundFault | InvalidClusterStateFault | CommonErrors;
/**
 * Returns an array of `ClusterDbRevision` objects.
 */
export declare const describeClusterDbRevisions: API.PaginatedOperationMethod<DescribeClusterDbRevisionsMessage, ClusterDbRevisionsMessage, DescribeClusterDbRevisionsError, Credentials | HttpClient.HttpClient, ClusterDbRevision>;
export type DescribeClusterParameterGroupsError = ClusterParameterGroupNotFoundFault | InvalidTagFault | CommonErrors;
/**
 * Returns a list of Amazon Redshift parameter groups, including parameter groups you
 * created and the default parameter group. For each parameter group, the response includes
 * the parameter group name, description, and parameter group family name. You can
 * optionally specify a name to retrieve the description of a specific parameter
 * group.
 *
 * For more information about parameters and parameter groups, go to
 * Amazon Redshift Parameter Groups
 * in the *Amazon Redshift Cluster Management Guide*.
 *
 * If you specify both tag keys and tag values in the same request, Amazon Redshift returns
 * all parameter groups that match any combination of the specified keys and values. For
 * example, if you have `owner` and `environment` for tag keys, and
 * `admin` and `test` for tag values, all parameter groups that
 * have any combination of those values are returned.
 *
 * If both tag keys and values are omitted from the request, parameter groups are
 * returned regardless of whether they have tag keys or values associated with
 * them.
 */
export declare const describeClusterParameterGroups: API.PaginatedOperationMethod<DescribeClusterParameterGroupsMessage, ClusterParameterGroupsMessage, DescribeClusterParameterGroupsError, Credentials | HttpClient.HttpClient, ClusterParameterGroup>;
export type DescribeClusterParametersError = ClusterParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns a detailed list of parameters contained within the specified Amazon Redshift
 * parameter group. For each parameter the response includes information such as parameter
 * name, description, data type, value, whether the parameter value is modifiable, and so
 * on.
 *
 * You can specify *source* filter to retrieve parameters of only
 * specific type. For example, to retrieve parameters that were modified by a user action
 * such as from ModifyClusterParameterGroup, you can specify
 * *source* equal to *user*.
 *
 * For more information about parameters and parameter groups, go to
 * Amazon Redshift Parameter Groups
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const describeClusterParameters: API.PaginatedOperationMethod<DescribeClusterParametersMessage, ClusterParameterGroupDetails, DescribeClusterParametersError, Credentials | HttpClient.HttpClient, Parameter>;
export type DescribeClustersError = ClusterNotFoundFault | InvalidTagFault | CommonErrors;
/**
 * Returns properties of provisioned clusters including general cluster properties,
 * cluster database properties, maintenance and backup properties, and security and access
 * properties. This operation supports pagination.
 * For more information about managing clusters, go to
 * Amazon Redshift Clusters
 * in the *Amazon Redshift Cluster Management Guide*.
 *
 * If you specify both tag keys and tag values in the same request, Amazon Redshift returns
 * all clusters that match any combination of the specified keys and values. For example,
 * if you have `owner` and `environment` for tag keys, and
 * `admin` and `test` for tag values, all clusters that have any
 * combination of those values are returned.
 *
 * If both tag keys and values are omitted from the request, clusters are returned
 * regardless of whether they have tag keys or values associated with them.
 */
export declare const describeClusters: API.PaginatedOperationMethod<DescribeClustersMessage, ClustersMessage, DescribeClustersError, Credentials | HttpClient.HttpClient, Cluster>;
export type DescribeClusterSecurityGroupsError = ClusterSecurityGroupNotFoundFault | InvalidTagFault | CommonErrors;
/**
 * Returns information about Amazon Redshift security groups. If the name of a security
 * group is specified, the response will contain only information about only that security
 * group.
 *
 * For information about managing security groups, go to
 * Amazon Redshift Cluster Security Groups in the
 * *Amazon Redshift Cluster Management Guide*.
 *
 * If you specify both tag keys and tag values in the same request, Amazon Redshift returns
 * all security groups that match any combination of the specified keys and values. For
 * example, if you have `owner` and `environment` for tag keys, and
 * `admin` and `test` for tag values, all security groups that
 * have any combination of those values are returned.
 *
 * If both tag keys and values are omitted from the request, security groups are
 * returned regardless of whether they have tag keys or values associated with
 * them.
 */
export declare const describeClusterSecurityGroups: API.PaginatedOperationMethod<DescribeClusterSecurityGroupsMessage, ClusterSecurityGroupMessage, DescribeClusterSecurityGroupsError, Credentials | HttpClient.HttpClient, ClusterSecurityGroup>;
export type DescribeClusterSnapshotsError = ClusterNotFoundFault | ClusterSnapshotNotFoundFault | InvalidTagFault | UnsupportedOperationFault | CommonErrors;
/**
 * Returns one or more snapshot objects, which contain metadata about your cluster
 * snapshots. By default, this operation returns information about all snapshots of all
 * clusters that are owned by your Amazon Web Services account. No information is returned for
 * snapshots owned by inactive Amazon Web Services accounts.
 *
 * If you specify both tag keys and tag values in the same request, Amazon Redshift returns
 * all snapshots that match any combination of the specified keys and values. For example,
 * if you have `owner` and `environment` for tag keys, and
 * `admin` and `test` for tag values, all snapshots that have any
 * combination of those values are returned. Only snapshots that you own are returned in
 * the response; shared snapshots are not returned with the tag key and tag value request
 * parameters.
 *
 * If both tag keys and values are omitted from the request, snapshots are returned
 * regardless of whether they have tag keys or values associated with them.
 */
export declare const describeClusterSnapshots: API.PaginatedOperationMethod<DescribeClusterSnapshotsMessage, SnapshotMessage, DescribeClusterSnapshotsError, Credentials | HttpClient.HttpClient, Snapshot>;
export type DescribeClusterSubnetGroupsError = ClusterSubnetGroupNotFoundFault | InvalidTagFault | CommonErrors;
/**
 * Returns one or more cluster subnet group objects, which contain metadata about your
 * cluster subnet groups. By default, this operation returns information about all cluster
 * subnet groups that are defined in your Amazon Web Services account.
 *
 * If you specify both tag keys and tag values in the same request, Amazon Redshift returns
 * all subnet groups that match any combination of the specified keys and values. For
 * example, if you have `owner` and `environment` for tag keys, and
 * `admin` and `test` for tag values, all subnet groups that have
 * any combination of those values are returned.
 *
 * If both tag keys and values are omitted from the request, subnet groups are
 * returned regardless of whether they have tag keys or values associated with
 * them.
 */
export declare const describeClusterSubnetGroups: API.PaginatedOperationMethod<DescribeClusterSubnetGroupsMessage, ClusterSubnetGroupMessage, DescribeClusterSubnetGroupsError, Credentials | HttpClient.HttpClient, ClusterSubnetGroup>;
export type DescribeClusterTracksError = InvalidClusterTrackFault | UnauthorizedOperation | CommonErrors;
/**
 * Returns a list of all the available maintenance tracks.
 */
export declare const describeClusterTracks: API.PaginatedOperationMethod<DescribeClusterTracksMessage, TrackListMessage, DescribeClusterTracksError, Credentials | HttpClient.HttpClient, MaintenanceTrack>;
export type DescribeClusterVersionsError = CommonErrors;
/**
 * Returns descriptions of the available Amazon Redshift cluster versions. You can call this
 * operation even before creating any clusters to learn more about the Amazon Redshift versions.
 *
 * For more information about managing clusters, go to
 * Amazon Redshift Clusters
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const describeClusterVersions: API.PaginatedOperationMethod<DescribeClusterVersionsMessage, ClusterVersionsMessage, DescribeClusterVersionsError, Credentials | HttpClient.HttpClient, ClusterVersion>;
export type DescribeCustomDomainAssociationsError = CustomDomainAssociationNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Contains information about custom domain associations for a cluster.
 */
export declare const describeCustomDomainAssociations: API.PaginatedOperationMethod<DescribeCustomDomainAssociationsMessage, CustomDomainAssociationsMessage, DescribeCustomDomainAssociationsError, Credentials | HttpClient.HttpClient, Association>;
export type DescribeDataSharesError = InvalidDataShareFault | CommonErrors;
/**
 * Shows the status of any inbound or outbound datashares available in the specified
 * account.
 */
export declare const describeDataShares: API.PaginatedOperationMethod<DescribeDataSharesMessage, DescribeDataSharesResult, DescribeDataSharesError, Credentials | HttpClient.HttpClient, DataShare>;
export type DescribeDataSharesForConsumerError = InvalidNamespaceFault | CommonErrors;
/**
 * Returns a list of datashares where the account identifier being called is a consumer account identifier.
 */
export declare const describeDataSharesForConsumer: API.PaginatedOperationMethod<DescribeDataSharesForConsumerMessage, DescribeDataSharesForConsumerResult, DescribeDataSharesForConsumerError, Credentials | HttpClient.HttpClient, DataShare>;
export type DescribeDataSharesForProducerError = InvalidNamespaceFault | CommonErrors;
/**
 * Returns a list of datashares when the account identifier being called is a producer account identifier.
 */
export declare const describeDataSharesForProducer: API.PaginatedOperationMethod<DescribeDataSharesForProducerMessage, DescribeDataSharesForProducerResult, DescribeDataSharesForProducerError, Credentials | HttpClient.HttpClient, DataShare>;
export type DescribeDefaultClusterParametersError = CommonErrors;
/**
 * Returns a list of parameter settings for the specified parameter group
 * family.
 *
 * For more information about parameters and parameter groups, go to
 * Amazon Redshift Parameter Groups
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const describeDefaultClusterParameters: API.PaginatedOperationMethod<DescribeDefaultClusterParametersMessage, DescribeDefaultClusterParametersResult, DescribeDefaultClusterParametersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEndpointAccessError = ClusterNotFoundFault | EndpointNotFoundFault | InvalidClusterStateFault | CommonErrors;
/**
 * Describes a Redshift-managed VPC endpoint.
 */
export declare const describeEndpointAccess: API.PaginatedOperationMethod<DescribeEndpointAccessMessage, EndpointAccessList, DescribeEndpointAccessError, Credentials | HttpClient.HttpClient, EndpointAccess>;
export type DescribeEndpointAuthorizationError = ClusterNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Describes an endpoint authorization.
 */
export declare const describeEndpointAuthorization: API.PaginatedOperationMethod<DescribeEndpointAuthorizationMessage, EndpointAuthorizationList, DescribeEndpointAuthorizationError, Credentials | HttpClient.HttpClient, EndpointAuthorization>;
export type DescribeEventCategoriesError = CommonErrors;
/**
 * Displays a list of event categories for all event source types, or for a specified
 * source type. For a list of the event categories and source types, go to Amazon Redshift Event
 * Notifications.
 */
export declare const describeEventCategories: API.OperationMethod<DescribeEventCategoriesMessage, EventCategoriesMessage, DescribeEventCategoriesError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = CommonErrors;
/**
 * Returns events related to clusters, security groups, snapshots, and parameter
 * groups for the past 14 days. Events specific to a particular cluster, security group,
 * snapshot or parameter group can be obtained by providing the name as a parameter. By
 * default, the past hour of events are returned.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsMessage, EventsMessage, DescribeEventsError, Credentials | HttpClient.HttpClient, Event>;
export type DescribeEventSubscriptionsError = InvalidTagFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Lists descriptions of all the Amazon Redshift event notification subscriptions for a
 * customer account. If you specify a subscription name, lists the description for that
 * subscription.
 *
 * If you specify both tag keys and tag values in the same request, Amazon Redshift returns
 * all event notification subscriptions that match any combination of the specified keys
 * and values. For example, if you have `owner` and `environment` for
 * tag keys, and `admin` and `test` for tag values, all subscriptions
 * that have any combination of those values are returned.
 *
 * If both tag keys and values are omitted from the request, subscriptions are
 * returned regardless of whether they have tag keys or values associated with
 * them.
 */
export declare const describeEventSubscriptions: API.PaginatedOperationMethod<DescribeEventSubscriptionsMessage, EventSubscriptionsMessage, DescribeEventSubscriptionsError, Credentials | HttpClient.HttpClient, EventSubscription>;
export type DescribeHsmClientCertificatesError = HsmClientCertificateNotFoundFault | InvalidTagFault | CommonErrors;
/**
 * Returns information about the specified HSM client certificate. If no certificate
 * ID is specified, returns information about all the HSM certificates owned by your Amazon Web Services account.
 *
 * If you specify both tag keys and tag values in the same request, Amazon Redshift returns
 * all HSM client certificates that match any combination of the specified keys and values.
 * For example, if you have `owner` and `environment` for tag keys,
 * and `admin` and `test` for tag values, all HSM client certificates
 * that have any combination of those values are returned.
 *
 * If both tag keys and values are omitted from the request, HSM client certificates
 * are returned regardless of whether they have tag keys or values associated with
 * them.
 */
export declare const describeHsmClientCertificates: API.PaginatedOperationMethod<DescribeHsmClientCertificatesMessage, HsmClientCertificateMessage, DescribeHsmClientCertificatesError, Credentials | HttpClient.HttpClient, HsmClientCertificate>;
export type DescribeHsmConfigurationsError = HsmConfigurationNotFoundFault | InvalidTagFault | CommonErrors;
/**
 * Returns information about the specified Amazon Redshift HSM configuration. If no
 * configuration ID is specified, returns information about all the HSM configurations
 * owned by your Amazon Web Services account.
 *
 * If you specify both tag keys and tag values in the same request, Amazon Redshift returns
 * all HSM connections that match any combination of the specified keys and values. For
 * example, if you have `owner` and `environment` for tag keys, and
 * `admin` and `test` for tag values, all HSM connections that
 * have any combination of those values are returned.
 *
 * If both tag keys and values are omitted from the request, HSM connections are
 * returned regardless of whether they have tag keys or values associated with
 * them.
 */
export declare const describeHsmConfigurations: API.PaginatedOperationMethod<DescribeHsmConfigurationsMessage, HsmConfigurationMessage, DescribeHsmConfigurationsError, Credentials | HttpClient.HttpClient, HsmConfiguration>;
export type DescribeInboundIntegrationsError = IntegrationNotFoundFault | InvalidNamespaceFault | UnsupportedOperationFault | CommonErrors;
/**
 * Returns a list of inbound integrations.
 */
export declare const describeInboundIntegrations: API.PaginatedOperationMethod<DescribeInboundIntegrationsMessage, InboundIntegrationsMessage, DescribeInboundIntegrationsError, Credentials | HttpClient.HttpClient, InboundIntegration>;
export type DescribeIntegrationsError = IntegrationNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Describes one or more zero-ETL or S3 event integrations with Amazon Redshift.
 */
export declare const describeIntegrations: API.PaginatedOperationMethod<DescribeIntegrationsMessage, IntegrationsMessage, DescribeIntegrationsError, Credentials | HttpClient.HttpClient, Integration>;
export type DescribeLoggingStatusError = ClusterNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Describes whether information, such as queries and connection attempts, is being
 * logged for the specified Amazon Redshift cluster.
 */
export declare const describeLoggingStatus: API.OperationMethod<DescribeLoggingStatusMessage, LoggingStatus, DescribeLoggingStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeNodeConfigurationOptionsError = AccessToSnapshotDeniedFault | ClusterNotFoundFault | ClusterSnapshotNotFoundFault | InvalidClusterSnapshotStateFault | UnsupportedOperationFault | CommonErrors;
/**
 * Returns properties of possible node configurations such as node type, number of nodes, and
 * disk usage for the specified action type.
 */
export declare const describeNodeConfigurationOptions: API.PaginatedOperationMethod<DescribeNodeConfigurationOptionsMessage, NodeConfigurationOptionsMessage, DescribeNodeConfigurationOptionsError, Credentials | HttpClient.HttpClient, NodeConfigurationOption>;
export type DescribeOrderableClusterOptionsError = CommonErrors;
/**
 * Returns a list of orderable cluster options. Before you create a new cluster you
 * can use this operation to find what options are available, such as the EC2 Availability
 * Zones (AZ) in the specific Amazon Web Services Region that you can specify, and the node types you can
 * request. The node types differ by available storage, memory, CPU and price. With the
 * cost involved you might want to obtain a list of cluster options in the specific region
 * and specify values when creating a cluster.
 * For more information about managing clusters, go to
 * Amazon Redshift Clusters
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const describeOrderableClusterOptions: API.PaginatedOperationMethod<DescribeOrderableClusterOptionsMessage, OrderableClusterOptionsMessage, DescribeOrderableClusterOptionsError, Credentials | HttpClient.HttpClient, OrderableClusterOption>;
export type DescribePartnersError = ClusterNotFoundFault | UnauthorizedPartnerIntegrationFault | UnsupportedOperationFault | CommonErrors;
/**
 * Returns information about the partner integrations defined for a cluster.
 */
export declare const describePartners: API.OperationMethod<DescribePartnersInputMessage, DescribePartnersOutputMessage, DescribePartnersError, Credentials | HttpClient.HttpClient>;
export type DescribeQev2IdcApplicationsError = DependentServiceAccessDeniedFault | DependentServiceUnavailableFault | Qev2IdcApplicationNotExistsFault | UnsupportedOperationFault | CommonErrors;
/**
 * Lists the Amazon Redshift Query Editor (QEV2) IAM Identity Center applications. To retrieve additional results, use the MaxRecords and Marker parameters.
 */
export declare const describeQev2IdcApplications: API.PaginatedOperationMethod<DescribeQev2IdcApplicationsMessage, DescribeQev2IdcApplicationsResult, DescribeQev2IdcApplicationsError, Credentials | HttpClient.HttpClient, Qev2IdcApplication>;
export type DescribeRedshiftIdcApplicationsError = DependentServiceAccessDeniedFault | DependentServiceUnavailableFault | RedshiftIdcApplicationNotExistsFault | UnsupportedOperationFault | CommonErrors;
/**
 * Lists the Amazon Redshift IAM Identity Center applications.
 */
export declare const describeRedshiftIdcApplications: API.PaginatedOperationMethod<DescribeRedshiftIdcApplicationsMessage, DescribeRedshiftIdcApplicationsResult, DescribeRedshiftIdcApplicationsError, Credentials | HttpClient.HttpClient, RedshiftIdcApplication>;
export type DescribeReservedNodeExchangeStatusError = ReservedNodeExchangeNotFoundFault | ReservedNodeNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Returns exchange status details and associated metadata for a reserved-node
 * exchange. Statuses include such values as in progress and requested.
 */
export declare const describeReservedNodeExchangeStatus: API.PaginatedOperationMethod<DescribeReservedNodeExchangeStatusInputMessage, DescribeReservedNodeExchangeStatusOutputMessage, DescribeReservedNodeExchangeStatusError, Credentials | HttpClient.HttpClient, ReservedNodeExchangeStatus>;
export type DescribeReservedNodeOfferingsError = DependentServiceUnavailableFault | ReservedNodeOfferingNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Returns a list of the available reserved node offerings by Amazon Redshift with their
 * descriptions including the node type, the fixed and recurring costs of reserving the
 * node and duration the node will be reserved for you. These descriptions help you
 * determine which reserve node offering you want to purchase. You then use the unique
 * offering ID in you call to PurchaseReservedNodeOffering to reserve one
 * or more nodes for your Amazon Redshift cluster.
 *
 * For more information about reserved node offerings, go to
 * Purchasing Reserved Nodes
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const describeReservedNodeOfferings: API.PaginatedOperationMethod<DescribeReservedNodeOfferingsMessage, ReservedNodeOfferingsMessage, DescribeReservedNodeOfferingsError, Credentials | HttpClient.HttpClient, ReservedNodeOffering>;
export type DescribeReservedNodesError = DependentServiceUnavailableFault | ReservedNodeNotFoundFault | CommonErrors;
/**
 * Returns the descriptions of the reserved nodes.
 */
export declare const describeReservedNodes: API.PaginatedOperationMethod<DescribeReservedNodesMessage, ReservedNodesMessage, DescribeReservedNodesError, Credentials | HttpClient.HttpClient, ReservedNode>;
export type DescribeResizeError = ClusterNotFoundFault | ResizeNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Returns information about the last resize operation for the specified cluster. If
 * no resize operation has ever been initiated for the specified cluster, a HTTP
 * 404 error is returned. If a resize operation was initiated and completed, the
 * status of the resize remains as `SUCCEEDED` until the next resize.
 *
 * A resize operation can be requested using ModifyCluster and
 * specifying a different number or type of nodes for the cluster.
 */
export declare const describeResize: API.OperationMethod<DescribeResizeMessage, ResizeProgressMessage, DescribeResizeError, Credentials | HttpClient.HttpClient>;
export type DescribeScheduledActionsError = ScheduledActionNotFoundFault | UnauthorizedOperation | CommonErrors;
/**
 * Describes properties of scheduled actions.
 */
export declare const describeScheduledActions: API.PaginatedOperationMethod<DescribeScheduledActionsMessage, ScheduledActionsMessage, DescribeScheduledActionsError, Credentials | HttpClient.HttpClient, ScheduledAction>;
export type DescribeSnapshotCopyGrantsError = InvalidTagFault | SnapshotCopyGrantNotFoundFault | CommonErrors;
/**
 * Returns a list of snapshot copy grants owned by the Amazon Web Services account in the destination
 * region.
 *
 * For more information about managing snapshot copy grants, go to
 * Amazon Redshift Database Encryption
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const describeSnapshotCopyGrants: API.PaginatedOperationMethod<DescribeSnapshotCopyGrantsMessage, SnapshotCopyGrantMessage, DescribeSnapshotCopyGrantsError, Credentials | HttpClient.HttpClient, SnapshotCopyGrant>;
export type DescribeSnapshotSchedulesError = CommonErrors;
/**
 * Returns a list of snapshot schedules.
 */
export declare const describeSnapshotSchedules: API.PaginatedOperationMethod<DescribeSnapshotSchedulesMessage, DescribeSnapshotSchedulesOutputMessage, DescribeSnapshotSchedulesError, Credentials | HttpClient.HttpClient, SnapshotSchedule>;
export type DescribeStorageError = CommonErrors;
/**
 * Returns account level backups storage size and provisional storage.
 */
export declare const describeStorage: API.OperationMethod<DescribeStorageRequest, CustomerStorageMessage, DescribeStorageError, Credentials | HttpClient.HttpClient>;
export type DescribeTableRestoreStatusError = ClusterNotFoundFault | TableRestoreNotFoundFault | CommonErrors;
/**
 * Lists the status of one or more table restore requests made using the RestoreTableFromClusterSnapshot API action. If you don't specify a value
 * for the `TableRestoreRequestId` parameter, then
 * `DescribeTableRestoreStatus` returns the status of all table restore
 * requests ordered by the date and time of the request in ascending order. Otherwise
 * `DescribeTableRestoreStatus` returns the status of the table specified by
 * `TableRestoreRequestId`.
 */
export declare const describeTableRestoreStatus: API.PaginatedOperationMethod<DescribeTableRestoreStatusMessage, TableRestoreStatusMessage, DescribeTableRestoreStatusError, Credentials | HttpClient.HttpClient, TableRestoreStatus>;
export type DescribeTagsError = InvalidTagFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns a list of tags. You can return tags from a specific resource by specifying
 * an ARN, or you can return all tags for a given type of resource, such as clusters,
 * snapshots, and so on.
 *
 * The following are limitations for `DescribeTags`:
 *
 * - You cannot specify an ARN and a resource-type value together in the same
 * request.
 *
 * - You cannot use the `MaxRecords` and `Marker`
 * parameters together with the ARN parameter.
 *
 * - The `MaxRecords` parameter can be a range from 10 to 50 results
 * to return in a request.
 *
 * If you specify both tag keys and tag values in the same request, Amazon Redshift returns
 * all resources that match any combination of the specified keys and values. For example,
 * if you have `owner` and `environment` for tag keys, and
 * `admin` and `test` for tag values, all resources that have any
 * combination of those values are returned.
 *
 * If both tag keys and values are omitted from the request, resources are returned
 * regardless of whether they have tag keys or values associated with them.
 */
export declare const describeTags: API.PaginatedOperationMethod<DescribeTagsMessage, TaggedResourceListMessage, DescribeTagsError, Credentials | HttpClient.HttpClient, TaggedResource>;
export type DescribeUsageLimitsError = ClusterNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Shows usage limits on a cluster.
 * Results are filtered based on the combination of input usage limit identifier, cluster identifier, and feature type parameters:
 *
 * - If usage limit identifier, cluster identifier, and feature type are not provided,
 * then all usage limit objects for the current account in the current region are returned.
 *
 * - If usage limit identifier is provided,
 * then the corresponding usage limit object is returned.
 *
 * - If cluster identifier is provided,
 * then all usage limit objects for the specified cluster are returned.
 *
 * - If cluster identifier and feature type are provided,
 * then all usage limit objects for the combination of cluster and feature are returned.
 */
export declare const describeUsageLimits: API.PaginatedOperationMethod<DescribeUsageLimitsMessage, UsageLimitList, DescribeUsageLimitsError, Credentials | HttpClient.HttpClient, UsageLimit>;
export type DisableLoggingError = ClusterNotFoundFault | InvalidClusterStateFault | UnsupportedOperationFault | CommonErrors;
/**
 * Stops logging information, such as queries and connection attempts, for the
 * specified Amazon Redshift cluster.
 */
export declare const disableLogging: API.OperationMethod<DisableLoggingMessage, LoggingStatus, DisableLoggingError, Credentials | HttpClient.HttpClient>;
export type DisableSnapshotCopyError = ClusterNotFoundFault | InvalidClusterStateFault | SnapshotCopyAlreadyDisabledFault | UnauthorizedOperation | UnsupportedOperationFault | CommonErrors;
/**
 * Disables the automatic copying of snapshots from one region to another region for a
 * specified cluster.
 *
 * If your cluster and its snapshots are encrypted using an encrypted symmetric key
 * from Key Management Service, use DeleteSnapshotCopyGrant to delete the grant that
 * grants Amazon Redshift permission to the key in the destination region.
 */
export declare const disableSnapshotCopy: API.OperationMethod<DisableSnapshotCopyMessage, DisableSnapshotCopyResult, DisableSnapshotCopyError, Credentials | HttpClient.HttpClient>;
export type DisassociateDataShareConsumerError = InvalidDataShareFault | InvalidNamespaceFault | CommonErrors;
/**
 * From a datashare consumer account, remove association for the specified datashare.
 */
export declare const disassociateDataShareConsumer: API.OperationMethod<DisassociateDataShareConsumerMessage, DataShare, DisassociateDataShareConsumerError, Credentials | HttpClient.HttpClient>;
export type EnableLoggingError = BucketNotFoundFault | ClusterNotFoundFault | InsufficientS3BucketPolicyFault | InvalidClusterStateFault | InvalidS3BucketNameFault | InvalidS3KeyPrefixFault | UnsupportedOperationFault | CommonErrors;
/**
 * Starts logging information, such as queries and connection attempts, for the
 * specified Amazon Redshift cluster.
 */
export declare const enableLogging: API.OperationMethod<EnableLoggingMessage, LoggingStatus, EnableLoggingError, Credentials | HttpClient.HttpClient>;
export type EnableSnapshotCopyError = ClusterNotFoundFault | CopyToRegionDisabledFault | DependentServiceRequestThrottlingFault | IncompatibleOrderableOptions | InvalidClusterStateFault | InvalidRetentionPeriodFault | LimitExceededFault | SnapshotCopyAlreadyEnabledFault | SnapshotCopyGrantNotFoundFault | UnauthorizedOperation | UnknownSnapshotCopyRegionFault | CommonErrors;
/**
 * Enables the automatic copy of snapshots from one region to another region for a
 * specified cluster.
 */
export declare const enableSnapshotCopy: API.OperationMethod<EnableSnapshotCopyMessage, EnableSnapshotCopyResult, EnableSnapshotCopyError, Credentials | HttpClient.HttpClient>;
export type FailoverPrimaryComputeError = ClusterNotFoundFault | InvalidClusterStateFault | UnauthorizedOperation | UnsupportedOperationFault | CommonErrors;
/**
 * Fails over the primary compute unit of the specified Multi-AZ cluster to another Availability Zone.
 */
export declare const failoverPrimaryCompute: API.OperationMethod<FailoverPrimaryComputeInputMessage, FailoverPrimaryComputeResult, FailoverPrimaryComputeError, Credentials | HttpClient.HttpClient>;
export type GetClusterCredentialsError = ClusterNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Returns a database user name and temporary password with temporary authorization to
 * log on to an Amazon Redshift database. The action returns the database user name
 * prefixed with `IAM:` if `AutoCreate` is `False` or
 * `IAMA:` if `AutoCreate` is `True`. You can
 * optionally specify one or more database user groups that the user will join at log on.
 * By default, the temporary credentials expire in 900 seconds. You can optionally specify
 * a duration between 900 seconds (15 minutes) and 3600 seconds (60 minutes). For more
 * information, see Using IAM Authentication
 * to Generate Database User Credentials in the Amazon Redshift Cluster Management Guide.
 *
 * The Identity and Access Management (IAM) user or role that runs
 * GetClusterCredentials must have an IAM policy attached that allows access to all
 * necessary actions and resources. For more information about permissions, see Resource Policies for GetClusterCredentials in the
 * Amazon Redshift Cluster Management Guide.
 *
 * If the `DbGroups` parameter is specified, the IAM policy must allow the
 * `redshift:JoinGroup` action with access to the listed
 * `dbgroups`.
 *
 * In addition, if the `AutoCreate` parameter is set to `True`,
 * then the policy must include the `redshift:CreateClusterUser`
 * permission.
 *
 * If the `DbName` parameter is specified, the IAM policy must allow access
 * to the resource `dbname` for the specified database name.
 */
export declare const getClusterCredentials: API.OperationMethod<GetClusterCredentialsMessage, ClusterCredentials, GetClusterCredentialsError, Credentials | HttpClient.HttpClient>;
export type GetClusterCredentialsWithIAMError = ClusterNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Returns a database user name and temporary password with temporary authorization to
 * log in to an Amazon Redshift database.
 * The database user is mapped 1:1 to the source Identity and Access Management (IAM) identity.
 * For more information about IAM identities, see IAM Identities (users, user groups, and roles) in the
 * Amazon Web Services Identity and Access Management User Guide.
 *
 * The Identity and Access Management (IAM) identity that runs
 * this operation must have an IAM policy attached that allows access to all
 * necessary actions and resources.
 * For more information about permissions, see Using identity-based policies (IAM policies) in the
 * Amazon Redshift Cluster Management Guide.
 */
export declare const getClusterCredentialsWithIAM: API.OperationMethod<GetClusterCredentialsWithIAMMessage, ClusterExtendedCredentials, GetClusterCredentialsWithIAMError, Credentials | HttpClient.HttpClient>;
export type GetIdentityCenterAuthTokenError = ClusterNotFoundFault | InvalidClusterStateFault | RedshiftInvalidParameterFault | UnsupportedOperationFault | CommonErrors;
/**
 * Generates an encrypted authentication token that propagates the caller's
 * Amazon Web Services IAM Identity Center identity to Amazon Redshift clusters. This API extracts the
 * Amazon Web Services IAM Identity Center identity from enhanced credentials and creates a secure token
 * that Amazon Redshift drivers can use for authentication.
 *
 * The token is encrypted using Key Management Service (KMS) and can only be
 * decrypted by the specified Amazon Redshift clusters. The token contains the caller's
 * Amazon Web Services IAM Identity Center identity information and is valid for a limited time period.
 *
 * This API is exclusively for use with Amazon Web Services IAM Identity Center enhanced credentials. If the
 * caller is not using enhanced credentials with embedded Amazon Web Services IAM Identity Center identity, the API will
 * return an error.
 */
export declare const getIdentityCenterAuthToken: API.OperationMethod<GetIdentityCenterAuthTokenRequest, GetIdentityCenterAuthTokenResponse, GetIdentityCenterAuthTokenError, Credentials | HttpClient.HttpClient>;
export type GetReservedNodeExchangeConfigurationOptionsError = ClusterNotFoundFault | ClusterSnapshotNotFoundFault | DependentServiceUnavailableFault | InvalidReservedNodeStateFault | ReservedNodeAlreadyMigratedFault | ReservedNodeNotFoundFault | ReservedNodeOfferingNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Gets the configuration options for the reserved-node exchange. These options
 * include information about the source reserved node and target reserved node offering.
 * Details include the node type, the price, the node count, and the offering type.
 */
export declare const getReservedNodeExchangeConfigurationOptions: API.PaginatedOperationMethod<GetReservedNodeExchangeConfigurationOptionsInputMessage, GetReservedNodeExchangeConfigurationOptionsOutputMessage, GetReservedNodeExchangeConfigurationOptionsError, Credentials | HttpClient.HttpClient, ReservedNodeConfigurationOption>;
export type GetReservedNodeExchangeOfferingsError = DependentServiceUnavailableFault | InvalidReservedNodeStateFault | ReservedNodeAlreadyMigratedFault | ReservedNodeNotFoundFault | ReservedNodeOfferingNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Returns an array of DC2 ReservedNodeOfferings that matches the payment type, term,
 * and usage price of the given DC1 reserved node.
 */
export declare const getReservedNodeExchangeOfferings: API.PaginatedOperationMethod<GetReservedNodeExchangeOfferingsInputMessage, GetReservedNodeExchangeOfferingsOutputMessage, GetReservedNodeExchangeOfferingsError, Credentials | HttpClient.HttpClient, ReservedNodeOffering>;
export type GetResourcePolicyError = InvalidPolicyFault | ResourceNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Get the resource policy for a specified resource.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyMessage, GetResourcePolicyResult, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ListRecommendationsError = ClusterNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * List the Amazon Redshift Advisor recommendations for one or multiple Amazon Redshift clusters in an Amazon Web Services account.
 */
export declare const listRecommendations: API.PaginatedOperationMethod<ListRecommendationsMessage, ListRecommendationsResult, ListRecommendationsError, Credentials | HttpClient.HttpClient, Recommendation>;
export type ModifyAquaConfigurationError = ClusterNotFoundFault | InvalidClusterStateFault | UnsupportedOperationFault | CommonErrors;
/**
 * This operation is retired. Calling this operation does not change AQUA configuration. Amazon Redshift automatically determines whether to use AQUA (Advanced Query Accelerator).
 */
export declare const modifyAquaConfiguration: API.OperationMethod<ModifyAquaInputMessage, ModifyAquaOutputMessage, ModifyAquaConfigurationError, Credentials | HttpClient.HttpClient>;
export type ModifyAuthenticationProfileError = AuthenticationProfileNotFoundFault | AuthenticationProfileQuotaExceededFault | InvalidAuthenticationProfileRequestFault | CommonErrors;
/**
 * Modifies an authentication profile.
 */
export declare const modifyAuthenticationProfile: API.OperationMethod<ModifyAuthenticationProfileMessage, ModifyAuthenticationProfileResult, ModifyAuthenticationProfileError, Credentials | HttpClient.HttpClient>;
export type ModifyClusterError = ClusterAlreadyExistsFault | ClusterNotFoundFault | ClusterParameterGroupNotFoundFault | ClusterSecurityGroupNotFoundFault | CustomCnameAssociationFault | DependentServiceRequestThrottlingFault | HsmClientCertificateNotFoundFault | HsmConfigurationNotFoundFault | InsufficientClusterCapacityFault | InvalidClusterSecurityGroupStateFault | InvalidClusterStateFault | InvalidClusterTrackFault | InvalidElasticIpFault | InvalidRetentionPeriodFault | Ipv6CidrBlockNotFoundFault | LimitExceededFault | NumberOfNodesPerClusterLimitExceededFault | NumberOfNodesQuotaExceededFault | TableLimitExceededFault | UnauthorizedOperation | UnsupportedOperationFault | UnsupportedOptionFault | CommonErrors;
/**
 * Modifies the settings for a cluster.
 *
 * You can also change node type and the number of nodes to scale up or down the
 * cluster. When resizing a cluster, you must specify both the number of nodes and the node
 * type even if one of the parameters does not change.
 *
 * You can add another security or
 * parameter group, or change the admin user password. Resetting a cluster password or modifying the security groups associated with a cluster do not need a reboot. However, modifying a parameter group requires a reboot for parameters to take effect.
 * For more information about managing clusters, go to
 * Amazon Redshift Clusters
 * in the *Amazon Redshift Cluster Management Guide*.
 *
 * VPC Block Public Access (BPA) enables you to block resources in VPCs and subnets that
 * you own in a Region from reaching or being reached from the internet through internet
 * gateways and egress-only internet gateways. If a subnet group for a
 * provisioned cluster is in an account with VPC BPA turned on, the following capabilities
 * are blocked:
 *
 * - Creating a public cluster
 *
 * - Restoring a public cluster
 *
 * - Modifying a private cluster to be public
 *
 * - Adding a subnet with VPC BPA turned on to the subnet group when there's at
 * least one public cluster within the group
 *
 * For more information about VPC BPA, see Block public access to VPCs and
 * subnets in the *Amazon VPC User Guide*.
 */
export declare const modifyCluster: API.OperationMethod<ModifyClusterMessage, ModifyClusterResult, ModifyClusterError, Credentials | HttpClient.HttpClient>;
export type ModifyClusterDbRevisionError = ClusterNotFoundFault | ClusterOnLatestRevisionFault | InvalidClusterStateFault | UnsupportedOperationFault | CommonErrors;
/**
 * Modifies the database revision of a cluster. The database revision is a unique
 * revision of the database running in a cluster.
 */
export declare const modifyClusterDbRevision: API.OperationMethod<ModifyClusterDbRevisionMessage, ModifyClusterDbRevisionResult, ModifyClusterDbRevisionError, Credentials | HttpClient.HttpClient>;
export type ModifyClusterIamRolesError = ClusterNotFoundFault | InvalidClusterStateFault | CommonErrors;
/**
 * Modifies the list of Identity and Access Management (IAM) roles that can be
 * used by the cluster to access other Amazon Web Services services.
 *
 * The maximum number of IAM roles that you can associate is subject to a quota.
 * For more information, go to Quotas and limits
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const modifyClusterIamRoles: API.OperationMethod<ModifyClusterIamRolesMessage, ModifyClusterIamRolesResult, ModifyClusterIamRolesError, Credentials | HttpClient.HttpClient>;
export type ModifyClusterMaintenanceError = ClusterNotFoundFault | InvalidClusterStateFault | CommonErrors;
/**
 * Modifies the maintenance settings of a cluster.
 */
export declare const modifyClusterMaintenance: API.OperationMethod<ModifyClusterMaintenanceMessage, ModifyClusterMaintenanceResult, ModifyClusterMaintenanceError, Credentials | HttpClient.HttpClient>;
export type ModifyClusterParameterGroupError = ClusterParameterGroupNotFoundFault | InvalidClusterParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a parameter group. For the parameters parameter, it can't contain ASCII characters.
 *
 * For more information about parameters and parameter groups, go to
 * Amazon Redshift Parameter Groups
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const modifyClusterParameterGroup: API.OperationMethod<ModifyClusterParameterGroupMessage, ClusterParameterGroupNameMessage, ModifyClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyClusterSnapshotError = ClusterSnapshotNotFoundFault | InvalidClusterSnapshotStateFault | InvalidRetentionPeriodFault | CommonErrors;
/**
 * Modifies the settings for a snapshot.
 *
 * This exanmple modifies the manual retention period setting for a cluster snapshot.
 */
export declare const modifyClusterSnapshot: API.OperationMethod<ModifyClusterSnapshotMessage, ModifyClusterSnapshotResult, ModifyClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type ModifyClusterSnapshotScheduleError = ClusterNotFoundFault | InvalidClusterSnapshotScheduleStateFault | SnapshotScheduleNotFoundFault | CommonErrors;
/**
 * Modifies a snapshot schedule for a cluster.
 */
export declare const modifyClusterSnapshotSchedule: API.OperationMethod<ModifyClusterSnapshotScheduleMessage, ModifyClusterSnapshotScheduleResponse, ModifyClusterSnapshotScheduleError, Credentials | HttpClient.HttpClient>;
export type ModifyClusterSubnetGroupError = ClusterSubnetGroupNotFoundFault | ClusterSubnetQuotaExceededFault | DependentServiceRequestThrottlingFault | InvalidSubnet | SubnetAlreadyInUse | UnauthorizedOperation | CommonErrors;
/**
 * Modifies a cluster subnet group to include the specified list of VPC subnets. The
 * operation replaces the existing list of subnets with the new list of subnets.
 *
 * VPC Block Public Access (BPA) enables you to block resources in VPCs and subnets that
 * you own in a Region from reaching or being reached from the internet through internet
 * gateways and egress-only internet gateways. If a subnet group for a
 * provisioned cluster is in an account with VPC BPA turned on, the following capabilities
 * are blocked:
 *
 * - Creating a public cluster
 *
 * - Restoring a public cluster
 *
 * - Modifying a private cluster to be public
 *
 * - Adding a subnet with VPC BPA turned on to the subnet group when there's at
 * least one public cluster within the group
 *
 * For more information about VPC BPA, see Block public access to VPCs and
 * subnets in the *Amazon VPC User Guide*.
 */
export declare const modifyClusterSubnetGroup: API.OperationMethod<ModifyClusterSubnetGroupMessage, ModifyClusterSubnetGroupResult, ModifyClusterSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyCustomDomainAssociationError = ClusterNotFoundFault | CustomCnameAssociationFault | CustomDomainAssociationNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Contains information for changing a custom domain association.
 */
export declare const modifyCustomDomainAssociation: API.OperationMethod<ModifyCustomDomainAssociationMessage, ModifyCustomDomainAssociationResult, ModifyCustomDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type ModifyEndpointAccessError = ClusterNotFoundFault | EndpointNotFoundFault | InvalidClusterSecurityGroupStateFault | InvalidClusterStateFault | InvalidEndpointStateFault | UnauthorizedOperation | CommonErrors;
/**
 * Modifies a Redshift-managed VPC endpoint.
 */
export declare const modifyEndpointAccess: API.OperationMethod<ModifyEndpointAccessMessage, EndpointAccess, ModifyEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type ModifyEventSubscriptionError = InvalidSubscriptionStateFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | SNSTopicArnNotFoundFault | SourceNotFoundFault | SubscriptionCategoryNotFoundFault | SubscriptionEventIdNotFoundFault | SubscriptionNotFoundFault | SubscriptionSeverityNotFoundFault | CommonErrors;
/**
 * Modifies an existing Amazon Redshift event notification subscription.
 */
export declare const modifyEventSubscription: API.OperationMethod<ModifyEventSubscriptionMessage, ModifyEventSubscriptionResult, ModifyEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type ModifyIntegrationError = IntegrationAlreadyExistsFault | IntegrationConflictOperationFault | IntegrationConflictStateFault | IntegrationNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Modifies a zero-ETL integration or S3 event integration with Amazon Redshift.
 */
export declare const modifyIntegration: API.OperationMethod<ModifyIntegrationMessage, Integration, ModifyIntegrationError, Credentials | HttpClient.HttpClient>;
export type ModifyLakehouseConfigurationError = ClusterNotFoundFault | DependentServiceAccessDeniedFault | DependentServiceUnavailableFault | InvalidClusterStateFault | RedshiftIdcApplicationNotExistsFault | UnauthorizedOperation | UnsupportedOperationFault | CommonErrors;
/**
 * Modifies the lakehouse configuration for a cluster. This operation allows you to manage Amazon Redshift federated permissions and Amazon Web Services IAM Identity Center trusted identity propagation.
 */
export declare const modifyLakehouseConfiguration: API.OperationMethod<ModifyLakehouseConfigurationMessage, LakehouseConfiguration, ModifyLakehouseConfigurationError, Credentials | HttpClient.HttpClient>;
export type ModifyQev2IdcApplicationError = DependentServiceAccessDeniedFault | DependentServiceUnavailableFault | Qev2IdcApplicationNotExistsFault | UnsupportedOperationFault | CommonErrors;
/**
 * Modifies an Amazon Redshift Query Editor (QEV2) IAM Identity Center application.
 */
export declare const modifyQev2IdcApplication: API.OperationMethod<ModifyQev2IdcApplicationMessage, ModifyQev2IdcApplicationResult, ModifyQev2IdcApplicationError, Credentials | HttpClient.HttpClient>;
export type ModifyRedshiftIdcApplicationError = DependentServiceAccessDeniedFault | DependentServiceUnavailableFault | RedshiftIdcApplicationNotExistsFault | UnsupportedOperationFault | CommonErrors;
/**
 * Changes an existing Amazon Redshift IAM Identity Center application.
 */
export declare const modifyRedshiftIdcApplication: API.OperationMethod<ModifyRedshiftIdcApplicationMessage, ModifyRedshiftIdcApplicationResult, ModifyRedshiftIdcApplicationError, Credentials | HttpClient.HttpClient>;
export type ModifyScheduledActionError = ClusterNotFoundFault | InvalidScheduledActionFault | InvalidScheduleFault | ScheduledActionNotFoundFault | ScheduledActionTypeUnsupportedFault | UnauthorizedOperation | UnsupportedOperationFault | CommonErrors;
/**
 * Modifies a scheduled action.
 */
export declare const modifyScheduledAction: API.OperationMethod<ModifyScheduledActionMessage, ScheduledAction, ModifyScheduledActionError, Credentials | HttpClient.HttpClient>;
export type ModifySnapshotCopyRetentionPeriodError = ClusterNotFoundFault | InvalidClusterStateFault | InvalidRetentionPeriodFault | SnapshotCopyDisabledFault | UnauthorizedOperation | CommonErrors;
/**
 * Modifies the number of days to retain snapshots in the destination Amazon Web Services Region after
 * they are copied from the source Amazon Web Services Region. By default, this operation only changes the
 * retention period of copied automated snapshots. The retention periods for both new and
 * existing copied automated snapshots are updated with the new retention period. You can
 * set the manual option to change only the retention periods of copied manual snapshots.
 * If you set this option, only newly copied manual snapshots have the new retention
 * period.
 */
export declare const modifySnapshotCopyRetentionPeriod: API.OperationMethod<ModifySnapshotCopyRetentionPeriodMessage, ModifySnapshotCopyRetentionPeriodResult, ModifySnapshotCopyRetentionPeriodError, Credentials | HttpClient.HttpClient>;
export type ModifySnapshotScheduleError = InvalidScheduleFault | SnapshotScheduleNotFoundFault | SnapshotScheduleUpdateInProgressFault | CommonErrors;
/**
 * Modifies a snapshot schedule. Any schedule associated with a cluster is modified
 * asynchronously.
 */
export declare const modifySnapshotSchedule: API.OperationMethod<ModifySnapshotScheduleMessage, SnapshotSchedule, ModifySnapshotScheduleError, Credentials | HttpClient.HttpClient>;
export type ModifyUsageLimitError = InvalidUsageLimitFault | UnsupportedOperationFault | UsageLimitNotFoundFault | CommonErrors;
/**
 * Modifies a usage limit in a cluster.
 * You can't modify the feature type or period of a usage limit.
 */
export declare const modifyUsageLimit: API.OperationMethod<ModifyUsageLimitMessage, UsageLimit, ModifyUsageLimitError, Credentials | HttpClient.HttpClient>;
export type PauseClusterError = ClusterNotFoundFault | InvalidClusterStateFault | UnsupportedOperationFault | CommonErrors;
/**
 * Pauses a cluster.
 */
export declare const pauseCluster: API.OperationMethod<PauseClusterMessage, PauseClusterResult, PauseClusterError, Credentials | HttpClient.HttpClient>;
export type PurchaseReservedNodeOfferingError = ReservedNodeAlreadyExistsFault | ReservedNodeOfferingNotFoundFault | ReservedNodeQuotaExceededFault | UnsupportedOperationFault | CommonErrors;
/**
 * Allows you to purchase reserved nodes. Amazon Redshift offers a predefined set of
 * reserved node offerings. You can purchase one or more of the offerings. You can call the
 * DescribeReservedNodeOfferings API to obtain the available reserved
 * node offerings. You can call this API by providing a specific reserved node offering and
 * the number of nodes you want to reserve.
 *
 * For more information about reserved node offerings, go to
 * Purchasing Reserved Nodes
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const purchaseReservedNodeOffering: API.OperationMethod<PurchaseReservedNodeOfferingMessage, PurchaseReservedNodeOfferingResult, PurchaseReservedNodeOfferingError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = ConflictPolicyUpdateFault | InvalidPolicyFault | ResourceNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Updates the resource policy for a specified resource.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyMessage, PutResourcePolicyResult, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type RebootClusterError = ClusterNotFoundFault | InvalidClusterStateFault | CommonErrors;
/**
 * Reboots a cluster. This action is taken as soon as possible. It results in a
 * momentary outage to the cluster, during which the cluster status is set to
 * `rebooting`. A cluster event is created when the reboot is completed. Any
 * pending cluster modifications (see ModifyCluster) are applied at this
 * reboot.
 * For more information about managing clusters, go to
 * Amazon Redshift Clusters
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const rebootCluster: API.OperationMethod<RebootClusterMessage, RebootClusterResult, RebootClusterError, Credentials | HttpClient.HttpClient>;
export type RegisterNamespaceError = ClusterNotFoundFault | InvalidClusterStateFault | InvalidNamespaceFault | CommonErrors;
/**
 * Registers a cluster or serverless namespace to the Amazon Web Services Glue Data Catalog.
 */
export declare const registerNamespace: API.OperationMethod<RegisterNamespaceInputMessage, RegisterNamespaceOutputMessage, RegisterNamespaceError, Credentials | HttpClient.HttpClient>;
export type RejectDataShareError = InvalidDataShareFault | CommonErrors;
/**
 * From a datashare consumer account, rejects the specified datashare.
 */
export declare const rejectDataShare: API.OperationMethod<RejectDataShareMessage, DataShare, RejectDataShareError, Credentials | HttpClient.HttpClient>;
export type ResetClusterParameterGroupError = ClusterParameterGroupNotFoundFault | InvalidClusterParameterGroupStateFault | CommonErrors;
/**
 * Sets one or more parameters of the specified parameter group to their default
 * values and sets the source values of the parameters to "engine-default". To reset the
 * entire parameter group specify the *ResetAllParameters* parameter.
 * For parameter changes to take effect you must reboot any associated clusters.
 */
export declare const resetClusterParameterGroup: API.OperationMethod<ResetClusterParameterGroupMessage, ClusterParameterGroupNameMessage, ResetClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ResizeClusterError = ClusterNotFoundFault | DependentServiceUnavailableFault | InsufficientClusterCapacityFault | InvalidClusterStateFault | InvalidReservedNodeStateFault | LimitExceededFault | NumberOfNodesPerClusterLimitExceededFault | NumberOfNodesQuotaExceededFault | ReservedNodeAlreadyExistsFault | ReservedNodeAlreadyMigratedFault | ReservedNodeNotFoundFault | ReservedNodeOfferingNotFoundFault | UnauthorizedOperation | UnsupportedOperationFault | UnsupportedOptionFault | CommonErrors;
/**
 * Changes the size of the cluster. You can change the cluster's type, or change the
 * number or type of nodes. The default behavior is to use the elastic resize method. With
 * an elastic resize, your cluster is available for read and write operations more quickly
 * than with the classic resize method.
 *
 * Elastic resize operations have the following restrictions:
 *
 * - You can only resize clusters of the following types:
 *
 * - dc2.large
 *
 * - dc2.8xlarge
 *
 * - rg.large
 *
 * - rg.xlarge
 *
 * - rg.4xlarge
 *
 * - rg.12xlarge
 *
 * - ra3.large
 *
 * - ra3.xlplus
 *
 * - ra3.4xlarge
 *
 * - ra3.16xlarge
 *
 * - The type of nodes that you add must match the node type for the
 * cluster.
 */
export declare const resizeCluster: API.OperationMethod<ResizeClusterMessage, ResizeClusterResult, ResizeClusterError, Credentials | HttpClient.HttpClient>;
export type RestoreFromClusterSnapshotError = AccessToSnapshotDeniedFault | ClusterAlreadyExistsFault | ClusterParameterGroupNotFoundFault | ClusterQuotaExceededFault | ClusterSecurityGroupNotFoundFault | ClusterSnapshotNotFoundFault | ClusterSubnetGroupNotFoundFault | DependentServiceAccessDeniedFault | DependentServiceRequestThrottlingFault | DependentServiceUnavailableFault | HsmClientCertificateNotFoundFault | HsmConfigurationNotFoundFault | InsufficientClusterCapacityFault | InvalidClusterSnapshotStateFault | InvalidClusterSubnetGroupStateFault | InvalidClusterTrackFault | InvalidElasticIpFault | InvalidReservedNodeStateFault | InvalidRestoreFault | InvalidSubnet | InvalidTagFault | InvalidVPCNetworkStateFault | Ipv6CidrBlockNotFoundFault | LimitExceededFault | NumberOfNodesPerClusterLimitExceededFault | NumberOfNodesQuotaExceededFault | RedshiftIdcApplicationNotExistsFault | ReservedNodeAlreadyExistsFault | ReservedNodeAlreadyMigratedFault | ReservedNodeNotFoundFault | ReservedNodeOfferingNotFoundFault | SnapshotScheduleNotFoundFault | TagLimitExceededFault | UnauthorizedOperation | UnsupportedOperationFault | CommonErrors;
/**
 * Creates a new cluster from a snapshot. By default, Amazon Redshift creates the resulting
 * cluster with the same configuration as the original cluster from which the snapshot was
 * created, except that the new cluster is created with the default cluster security and
 * parameter groups. After Amazon Redshift creates the cluster, you can use the ModifyCluster API to associate a different security group and different
 * parameter group with the restored cluster. If you are using a DS node type, you can also
 * choose to change to another DS node type of the same size during restore.
 *
 * If you restore a cluster into a VPC, you must provide a cluster subnet group where
 * you want the cluster restored.
 *
 * VPC Block Public Access (BPA) enables you to block resources in VPCs and subnets that
 * you own in a Region from reaching or being reached from the internet through internet
 * gateways and egress-only internet gateways. If a subnet group for a
 * provisioned cluster is in an account with VPC BPA turned on, the following capabilities
 * are blocked:
 *
 * - Creating a public cluster
 *
 * - Restoring a public cluster
 *
 * - Modifying a private cluster to be public
 *
 * - Adding a subnet with VPC BPA turned on to the subnet group when there's at
 * least one public cluster within the group
 *
 * For more information about VPC BPA, see Block public access to VPCs and
 * subnets in the *Amazon VPC User Guide*.
 *
 * For more information about working with snapshots, go to
 * Amazon Redshift Snapshots
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const restoreFromClusterSnapshot: API.OperationMethod<RestoreFromClusterSnapshotMessage, RestoreFromClusterSnapshotResult, RestoreFromClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type RestoreTableFromClusterSnapshotError = ClusterNotFoundFault | ClusterSnapshotNotFoundFault | InProgressTableRestoreQuotaExceededFault | InvalidClusterSnapshotStateFault | InvalidClusterStateFault | InvalidTableRestoreArgumentFault | UnsupportedOperationFault | CommonErrors;
/**
 * Creates a new table from a table in an Amazon Redshift cluster snapshot. You must
 * create the new table within the Amazon Redshift cluster that the snapshot was taken
 * from.
 *
 * You cannot use `RestoreTableFromClusterSnapshot` to restore a table with
 * the same name as an existing table in an Amazon Redshift cluster. That is, you cannot
 * overwrite an existing table in a cluster with a restored table. If you want to replace
 * your original table with a new, restored table, then rename or drop your original table
 * before you call `RestoreTableFromClusterSnapshot`. When you have renamed your
 * original table, then you can pass the original name of the table as the
 * `NewTableName` parameter value in the call to
 * `RestoreTableFromClusterSnapshot`. This way, you can replace the original
 * table with the table created from the snapshot.
 *
 * You can't use this operation to restore tables with
 * interleaved sort keys.
 */
export declare const restoreTableFromClusterSnapshot: API.OperationMethod<RestoreTableFromClusterSnapshotMessage, RestoreTableFromClusterSnapshotResult, RestoreTableFromClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type ResumeClusterError = ClusterNotFoundFault | InsufficientClusterCapacityFault | InvalidClusterStateFault | UnsupportedOperationFault | CommonErrors;
/**
 * Resumes a paused cluster.
 */
export declare const resumeCluster: API.OperationMethod<ResumeClusterMessage, ResumeClusterResult, ResumeClusterError, Credentials | HttpClient.HttpClient>;
export type RevokeClusterSecurityGroupIngressError = AuthorizationNotFoundFault | ClusterSecurityGroupNotFoundFault | InvalidClusterSecurityGroupStateFault | CommonErrors;
/**
 * Revokes an ingress rule in an Amazon Redshift security group for a previously authorized
 * IP range or Amazon EC2 security group. To add an ingress rule, see AuthorizeClusterSecurityGroupIngress.
 * For information about managing security groups, go to
 * Amazon Redshift Cluster Security Groups in the
 * *Amazon Redshift Cluster Management Guide*.
 */
export declare const revokeClusterSecurityGroupIngress: API.OperationMethod<RevokeClusterSecurityGroupIngressMessage, RevokeClusterSecurityGroupIngressResult, RevokeClusterSecurityGroupIngressError, Credentials | HttpClient.HttpClient>;
export type RevokeEndpointAccessError = ClusterNotFoundFault | EndpointAuthorizationNotFoundFault | EndpointNotFoundFault | InvalidAuthorizationStateFault | InvalidClusterSecurityGroupStateFault | InvalidClusterStateFault | InvalidEndpointStateFault | CommonErrors;
/**
 * Revokes access to a cluster.
 */
export declare const revokeEndpointAccess: API.OperationMethod<RevokeEndpointAccessMessage, EndpointAuthorization, RevokeEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type RevokeSnapshotAccessError = AccessToSnapshotDeniedFault | AuthorizationNotFoundFault | ClusterSnapshotNotFoundFault | UnsupportedOperationFault | CommonErrors;
/**
 * Removes the ability of the specified Amazon Web Services account to restore the specified
 * snapshot. If the account is currently restoring the snapshot, the restore will run to
 * completion.
 *
 * For more information about working with snapshots, go to
 * Amazon Redshift Snapshots
 * in the *Amazon Redshift Cluster Management Guide*.
 */
export declare const revokeSnapshotAccess: API.OperationMethod<RevokeSnapshotAccessMessage, RevokeSnapshotAccessResult, RevokeSnapshotAccessError, Credentials | HttpClient.HttpClient>;
export type RotateEncryptionKeyError = ClusterNotFoundFault | DependentServiceRequestThrottlingFault | InvalidClusterStateFault | UnsupportedOperationFault | CommonErrors;
/**
 * Rotates the encryption keys for a cluster.
 */
export declare const rotateEncryptionKey: API.OperationMethod<RotateEncryptionKeyMessage, RotateEncryptionKeyResult, RotateEncryptionKeyError, Credentials | HttpClient.HttpClient>;
export type UpdatePartnerStatusError = ClusterNotFoundFault | PartnerNotFoundFault | UnauthorizedPartnerIntegrationFault | UnsupportedOperationFault | CommonErrors;
/**
 * Updates the status of a partner integration.
 */
export declare const updatePartnerStatus: API.OperationMethod<UpdatePartnerStatusInputMessage, PartnerIntegrationOutputMessage, UpdatePartnerStatusError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=redshift.d.ts.map