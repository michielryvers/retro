import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema";
import * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalFailureException_base: S.Class<InternalFailureException, S.TaggedStruct<"InternalFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type RequestId = string;
export type AlarmModelName = string;
export type KeyValue = string;
export type Note = string;
export interface AcknowledgeAlarmActionRequest {
    requestId: string;
    alarmModelName: string;
    keyValue?: string;
    note?: string;
}
export type AcknowledgeAlarmActionRequests = AcknowledgeAlarmActionRequest[];
export interface BatchAcknowledgeAlarmRequest {
    acknowledgeActionRequests: AcknowledgeAlarmActionRequest[];
}
export type ErrorCode = "ResourceNotFoundException" | "InvalidRequestException" | "InternalFailureException" | "ServiceUnavailableException" | "ThrottlingException" | (string & {});
export type ErrorMessage = string;
export interface BatchAlarmActionErrorEntry {
    requestId?: string;
    errorCode?: ErrorCode;
    errorMessage?: string;
}
export type BatchAlarmActionErrorEntries = BatchAlarmActionErrorEntry[];
export interface BatchAcknowledgeAlarmResponse {
    errorEntries?: BatchAlarmActionErrorEntry[];
}
export type MessageId = string;
export type DetectorModelName = string;
export interface DeleteDetectorRequest {
    messageId: string;
    detectorModelName: string;
    keyValue?: string;
}
export type DeleteDetectorRequests = DeleteDetectorRequest[];
export interface BatchDeleteDetectorRequest {
    detectors: DeleteDetectorRequest[];
}
export interface BatchDeleteDetectorErrorEntry {
    messageId?: string;
    errorCode?: ErrorCode;
    errorMessage?: string;
}
export type BatchDeleteDetectorErrorEntries = BatchDeleteDetectorErrorEntry[];
export interface BatchDeleteDetectorResponse {
    batchDeleteDetectorErrorEntries?: BatchDeleteDetectorErrorEntry[];
}
export interface DisableAlarmActionRequest {
    requestId: string;
    alarmModelName: string;
    keyValue?: string;
    note?: string;
}
export type DisableAlarmActionRequests = DisableAlarmActionRequest[];
export interface BatchDisableAlarmRequest {
    disableActionRequests: DisableAlarmActionRequest[];
}
export interface BatchDisableAlarmResponse {
    errorEntries?: BatchAlarmActionErrorEntry[];
}
export interface EnableAlarmActionRequest {
    requestId: string;
    alarmModelName: string;
    keyValue?: string;
    note?: string;
}
export type EnableAlarmActionRequests = EnableAlarmActionRequest[];
export interface BatchEnableAlarmRequest {
    enableActionRequests: EnableAlarmActionRequest[];
}
export interface BatchEnableAlarmResponse {
    errorEntries?: BatchAlarmActionErrorEntry[];
}
export type EphemeralInputName = string;
export type Payload = Uint8Array;
export type EpochMilliTimestamp = number;
export interface TimestampValue {
    timeInMillis?: number;
}
export interface Message {
    messageId: string;
    inputName: string;
    payload: Uint8Array;
    timestamp?: TimestampValue;
}
export type Messages = Message[];
export interface BatchPutMessageRequest {
    messages: Message[];
}
export interface BatchPutMessageErrorEntry {
    messageId?: string;
    errorCode?: ErrorCode;
    errorMessage?: string;
}
export type BatchPutMessageErrorEntries = BatchPutMessageErrorEntry[];
export interface BatchPutMessageResponse {
    BatchPutMessageErrorEntries?: BatchPutMessageErrorEntry[];
}
export interface ResetAlarmActionRequest {
    requestId: string;
    alarmModelName: string;
    keyValue?: string;
    note?: string;
}
export type ResetAlarmActionRequests = ResetAlarmActionRequest[];
export interface BatchResetAlarmRequest {
    resetActionRequests: ResetAlarmActionRequest[];
}
export interface BatchResetAlarmResponse {
    errorEntries?: BatchAlarmActionErrorEntry[];
}
export type SnoozeDuration = number;
export interface SnoozeAlarmActionRequest {
    requestId: string;
    alarmModelName: string;
    keyValue?: string;
    note?: string;
    snoozeDuration: number;
}
export type SnoozeAlarmActionRequests = SnoozeAlarmActionRequest[];
export interface BatchSnoozeAlarmRequest {
    snoozeActionRequests: SnoozeAlarmActionRequest[];
}
export interface BatchSnoozeAlarmResponse {
    errorEntries?: BatchAlarmActionErrorEntry[];
}
export type StateName = string;
export type VariableName = string;
export type VariableValue = string;
export interface VariableDefinition {
    name: string;
    value: string;
}
export type VariableDefinitions = VariableDefinition[];
export type TimerName = string;
export type Seconds = number;
export interface TimerDefinition {
    name: string;
    seconds: number;
}
export type TimerDefinitions = TimerDefinition[];
export interface DetectorStateDefinition {
    stateName: string;
    variables: VariableDefinition[];
    timers: TimerDefinition[];
}
export interface UpdateDetectorRequest {
    messageId: string;
    detectorModelName: string;
    keyValue?: string;
    state: DetectorStateDefinition;
}
export type UpdateDetectorRequests = UpdateDetectorRequest[];
export interface BatchUpdateDetectorRequest {
    detectors: UpdateDetectorRequest[];
}
export interface BatchUpdateDetectorErrorEntry {
    messageId?: string;
    errorCode?: ErrorCode;
    errorMessage?: string;
}
export type BatchUpdateDetectorErrorEntries = BatchUpdateDetectorErrorEntry[];
export interface BatchUpdateDetectorResponse {
    batchUpdateDetectorErrorEntries?: BatchUpdateDetectorErrorEntry[];
}
export interface DescribeAlarmRequest {
    alarmModelName: string;
    keyValue?: string;
}
export type AlarmModelVersion = string;
export type AlarmStateName = "DISABLED" | "NORMAL" | "ACTIVE" | "ACKNOWLEDGED" | "SNOOZE_DISABLED" | "LATCHED" | (string & {});
export type InputPropertyValue = string;
export type ComparisonOperator = "GREATER" | "GREATER_OR_EQUAL" | "LESS" | "LESS_OR_EQUAL" | "EQUAL" | "NOT_EQUAL" | (string & {});
export type ThresholdValue = string;
export interface SimpleRuleEvaluation {
    inputPropertyValue?: string;
    operator?: ComparisonOperator;
    thresholdValue?: string;
}
export interface RuleEvaluation {
    simpleRuleEvaluation?: SimpleRuleEvaluation;
}
export type CustomerActionName = "SNOOZE" | "ENABLE" | "DISABLE" | "ACKNOWLEDGE" | "RESET" | (string & {});
export interface SnoozeActionConfiguration {
    snoozeDuration?: number;
    note?: string;
}
export interface EnableActionConfiguration {
    note?: string;
}
export interface DisableActionConfiguration {
    note?: string;
}
export interface AcknowledgeActionConfiguration {
    note?: string;
}
export interface ResetActionConfiguration {
    note?: string;
}
export interface CustomerAction {
    actionName?: CustomerActionName;
    snoozeActionConfiguration?: SnoozeActionConfiguration;
    enableActionConfiguration?: EnableActionConfiguration;
    disableActionConfiguration?: DisableActionConfiguration;
    acknowledgeActionConfiguration?: AcknowledgeActionConfiguration;
    resetActionConfiguration?: ResetActionConfiguration;
}
export type EventType = "STATE_CHANGE" | (string & {});
export type TriggerType = "SNOOZE_TIMEOUT" | (string & {});
export interface StateChangeConfiguration {
    triggerType?: TriggerType;
}
export interface SystemEvent {
    eventType?: EventType;
    stateChangeConfiguration?: StateChangeConfiguration;
}
export interface AlarmState {
    stateName?: AlarmStateName;
    ruleEvaluation?: RuleEvaluation;
    customerAction?: CustomerAction;
    systemEvent?: SystemEvent;
}
export type Severity = number;
export interface Alarm {
    alarmModelName?: string;
    alarmModelVersion?: string;
    keyValue?: string;
    alarmState?: AlarmState;
    severity?: number;
    creationTime?: Date;
    lastUpdateTime?: Date;
}
export interface DescribeAlarmResponse {
    alarm?: Alarm;
}
export interface DescribeDetectorRequest {
    detectorModelName: string;
    keyValue?: string;
}
export type DetectorModelVersion = string;
export interface Variable {
    name: string;
    value: string;
}
export type Variables = Variable[];
export interface Timer {
    name: string;
    timestamp: Date;
}
export type Timers = Timer[];
export interface DetectorState {
    stateName: string;
    variables: Variable[];
    timers: Timer[];
}
export interface Detector {
    detectorModelName?: string;
    keyValue?: string;
    detectorModelVersion?: string;
    state?: DetectorState;
    creationTime?: Date;
    lastUpdateTime?: Date;
}
export interface DescribeDetectorResponse {
    detector?: Detector;
}
export type NextToken = string;
export type MaxResults = number;
export interface ListAlarmsRequest {
    alarmModelName: string;
    nextToken?: string;
    maxResults?: number;
}
export interface AlarmSummary {
    alarmModelName?: string;
    alarmModelVersion?: string;
    keyValue?: string;
    stateName?: AlarmStateName;
    creationTime?: Date;
    lastUpdateTime?: Date;
}
export type AlarmSummaries = AlarmSummary[];
export interface ListAlarmsResponse {
    alarmSummaries?: AlarmSummary[];
    nextToken?: string;
}
export interface ListDetectorsRequest {
    detectorModelName: string;
    stateName?: string;
    nextToken?: string;
    maxResults?: number;
}
export interface DetectorStateSummary {
    stateName?: string;
}
export interface DetectorSummary {
    detectorModelName?: string;
    keyValue?: string;
    detectorModelVersion?: string;
    state?: DetectorStateSummary;
    creationTime?: Date;
    lastUpdateTime?: Date;
}
export type DetectorSummaries = DetectorSummary[];
export interface ListDetectorsResponse {
    detectorSummaries?: DetectorSummary[];
    nextToken?: string;
}
export type BatchAcknowledgeAlarmError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Acknowledges one or more alarms. The alarms change to the `ACKNOWLEDGED` state
 * after you acknowledge them.
 */
export declare const batchAcknowledgeAlarm: API.OperationMethod<BatchAcknowledgeAlarmRequest, BatchAcknowledgeAlarmResponse, BatchAcknowledgeAlarmError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteDetectorError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes one or more detectors that were created. When a detector is deleted, its state will be cleared and the detector will be removed from the list of detectors. The deleted detector will no longer appear if referenced in the ListDetectors API call.
 */
export declare const batchDeleteDetector: API.OperationMethod<BatchDeleteDetectorRequest, BatchDeleteDetectorResponse, BatchDeleteDetectorError, Credentials | HttpClient.HttpClient>;
export type BatchDisableAlarmError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Disables one or more alarms. The alarms change to the `DISABLED` state after
 * you disable them.
 */
export declare const batchDisableAlarm: API.OperationMethod<BatchDisableAlarmRequest, BatchDisableAlarmResponse, BatchDisableAlarmError, Credentials | HttpClient.HttpClient>;
export type BatchEnableAlarmError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Enables one or more alarms. The alarms change to the `NORMAL` state after you
 * enable them.
 */
export declare const batchEnableAlarm: API.OperationMethod<BatchEnableAlarmRequest, BatchEnableAlarmResponse, BatchEnableAlarmError, Credentials | HttpClient.HttpClient>;
export type BatchPutMessageError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Sends a set of messages to the IoT Events system. Each message payload is transformed into
 * the input you specify (`"inputName"`) and ingested into any detectors that monitor
 * that input. If multiple messages are sent, the order in which the messages are processed isn't
 * guaranteed. To guarantee ordering, you must send messages one at a time and wait for a
 * successful response.
 */
export declare const batchPutMessage: API.OperationMethod<BatchPutMessageRequest, BatchPutMessageResponse, BatchPutMessageError, Credentials | HttpClient.HttpClient>;
export type BatchResetAlarmError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Resets one or more alarms. The alarms return to the `NORMAL` state after you
 * reset them.
 */
export declare const batchResetAlarm: API.OperationMethod<BatchResetAlarmRequest, BatchResetAlarmResponse, BatchResetAlarmError, Credentials | HttpClient.HttpClient>;
export type BatchSnoozeAlarmError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Changes one or more alarms to the snooze mode. The alarms change to the
 * `SNOOZE_DISABLED` state after you set them to the snooze mode.
 */
export declare const batchSnoozeAlarm: API.OperationMethod<BatchSnoozeAlarmRequest, BatchSnoozeAlarmResponse, BatchSnoozeAlarmError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateDetectorError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates the state, variable values, and timer settings of one or more detectors
 * (instances) of a specified detector model.
 */
export declare const batchUpdateDetector: API.OperationMethod<BatchUpdateDetectorRequest, BatchUpdateDetectorResponse, BatchUpdateDetectorError, Credentials | HttpClient.HttpClient>;
export type DescribeAlarmError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an alarm.
 */
export declare const describeAlarm: API.OperationMethod<DescribeAlarmRequest, DescribeAlarmResponse, DescribeAlarmError, Credentials | HttpClient.HttpClient>;
export type DescribeDetectorError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns information about the specified detector (instance).
 */
export declare const describeDetector: API.OperationMethod<DescribeDetectorRequest, DescribeDetectorResponse, DescribeDetectorError, Credentials | HttpClient.HttpClient>;
export type ListAlarmsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists one or more alarms. The operation returns only the metadata associated with each
 * alarm.
 */
export declare const listAlarms: API.OperationMethod<ListAlarmsRequest, ListAlarmsResponse, ListAlarmsError, Credentials | HttpClient.HttpClient>;
export type ListDetectorsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists detectors (the instances of a detector model).
 */
export declare const listDetectors: API.OperationMethod<ListDetectorsRequest, ListDetectorsResponse, ListDetectorsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iot-events-data.d.ts.map