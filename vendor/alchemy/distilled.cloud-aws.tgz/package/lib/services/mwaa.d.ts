import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const MwaaExecutionRoleNotAssumable_base: S.TaggedErrorClass<"MwaaExecutionRoleNotAssumable", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class MwaaExecutionRoleNotAssumable extends /*@__PURE__*/ MwaaExecutionRoleNotAssumable_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const RestApiClientException_base: S.TaggedErrorClass<"RestApiClientException", {
    readonly RestApiStatusCode: any;
    readonly RestApiResponse: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RestApiClientException extends /*@__PURE__*/ RestApiClientException_base {
}
declare const RestApiServerException_base: S.TaggedErrorClass<"RestApiServerException", {
    readonly RestApiStatusCode: any;
    readonly RestApiResponse: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RestApiServerException extends /*@__PURE__*/ RestApiServerException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type EnvironmentName = string;
export interface CreateCliTokenRequest {
    Name: string;
}
export type Token = string | redacted.Redacted<string>;
export type Hostname = string;
export interface CreateCliTokenResponse {
    CliToken?: string | redacted.Redacted<string>;
    WebServerHostname?: string;
}
export type IamRoleArn = string;
export type S3BucketArn = string;
export type RelativePath = string;
export type SubnetId = string;
export type SubnetList = string[];
export type SecurityGroupId = string;
export type SecurityGroupList = string[];
export interface NetworkConfiguration {
    SubnetIds?: string[];
    SecurityGroupIds?: string[];
}
export type S3ObjectVersion = string;
export type ConfigKey = string;
export type ConfigValue = string | redacted.Redacted<string>;
export type AirflowConfigurationOptions = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type EnvironmentClass = string;
export type MaxWorkers = number;
export type KmsKey = string;
export type AirflowVersion = string;
export type LoggingEnabled = boolean;
export type LoggingLevel = string;
export interface ModuleLoggingConfigurationInput {
    Enabled: boolean;
    LogLevel: string;
}
export interface LoggingConfigurationInput {
    DagProcessingLogs?: ModuleLoggingConfigurationInput;
    SchedulerLogs?: ModuleLoggingConfigurationInput;
    WebserverLogs?: ModuleLoggingConfigurationInput;
    WorkerLogs?: ModuleLoggingConfigurationInput;
    TaskLogs?: ModuleLoggingConfigurationInput;
}
export type WeeklyMaintenanceWindowStart = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type WebserverAccessMode = string;
export type MinWorkers = number;
export type Schedulers = number;
export type EndpointManagement = string;
export type MinWebservers = number;
export type MaxWebservers = number;
export interface CreateEnvironmentInput {
    Name: string;
    ExecutionRoleArn: string;
    SourceBucketArn: string;
    DagS3Path: string;
    NetworkConfiguration: NetworkConfiguration;
    PluginsS3Path?: string;
    PluginsS3ObjectVersion?: string;
    RequirementsS3Path?: string;
    RequirementsS3ObjectVersion?: string;
    StartupScriptS3Path?: string;
    StartupScriptS3ObjectVersion?: string;
    AirflowConfigurationOptions?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    EnvironmentClass?: string;
    MaxWorkers?: number;
    KmsKey?: string;
    AirflowVersion?: string;
    LoggingConfiguration?: LoggingConfigurationInput;
    WeeklyMaintenanceWindowStart?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    WebserverAccessMode?: string;
    MinWorkers?: number;
    Schedulers?: number;
    EndpointManagement?: string;
    MinWebservers?: number;
    MaxWebservers?: number;
}
export type EnvironmentArn = string;
export interface CreateEnvironmentOutput {
    Arn?: string;
}
export interface CreateWebLoginTokenRequest {
    Name: string;
}
export type IamIdentity = string;
export type AirflowIdentity = string;
export interface CreateWebLoginTokenResponse {
    WebToken?: string | redacted.Redacted<string>;
    WebServerHostname?: string;
    IamIdentity?: string;
    AirflowIdentity?: string;
}
export interface DeleteEnvironmentInput {
    Name: string;
}
export interface DeleteEnvironmentOutput {
}
export interface GetEnvironmentInput {
    Name: string;
}
export type EnvironmentStatus = string;
export type CreatedAt = Date;
export type WebserverUrl = string;
export type CloudWatchLogGroupArn = string;
export interface ModuleLoggingConfiguration {
    Enabled?: boolean;
    LogLevel?: string;
    CloudWatchLogGroupArn?: string;
}
export interface LoggingConfiguration {
    DagProcessingLogs?: ModuleLoggingConfiguration;
    SchedulerLogs?: ModuleLoggingConfiguration;
    WebserverLogs?: ModuleLoggingConfiguration;
    WorkerLogs?: ModuleLoggingConfiguration;
    TaskLogs?: ModuleLoggingConfiguration;
}
export type UpdateStatus = string;
export type UpdateCreatedAt = Date;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface UpdateError {
    ErrorCode?: string;
    ErrorMessage?: string;
}
export type UpdateSource = string;
export type WorkerReplacementStrategy = string;
export interface LastUpdate {
    Status?: string;
    CreatedAt?: Date;
    Error?: UpdateError;
    Source?: string;
    WorkerReplacementStrategy?: string;
}
export type VpcEndpointServiceName = string;
export type CeleryExecutorQueue = string;
export interface Environment {
    Name?: string;
    Status?: string;
    Arn?: string;
    CreatedAt?: Date;
    WebserverUrl?: string;
    ExecutionRoleArn?: string;
    ServiceRoleArn?: string;
    KmsKey?: string;
    AirflowVersion?: string;
    SourceBucketArn?: string;
    DagS3Path?: string;
    PluginsS3Path?: string;
    PluginsS3ObjectVersion?: string;
    RequirementsS3Path?: string;
    RequirementsS3ObjectVersion?: string;
    StartupScriptS3Path?: string;
    StartupScriptS3ObjectVersion?: string;
    AirflowConfigurationOptions?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    EnvironmentClass?: string;
    MaxWorkers?: number;
    NetworkConfiguration?: NetworkConfiguration;
    LoggingConfiguration?: LoggingConfiguration;
    LastUpdate?: LastUpdate;
    WeeklyMaintenanceWindowStart?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    WebserverAccessMode?: string;
    MinWorkers?: number;
    Schedulers?: number;
    WebserverVpcEndpointService?: string;
    DatabaseVpcEndpointService?: string;
    CeleryExecutorQueue?: string;
    EndpointManagement?: string;
    MinWebservers?: number;
    MaxWebservers?: number;
}
export interface GetEnvironmentOutput {
    Environment?: Environment;
}
export type RestApiPath = string;
export type RestApiMethod = string;
export type RestApiRequestBody = unknown;
export interface InvokeRestApiRequest {
    Name: string;
    Path: string;
    Method: string;
    QueryParameters?: any;
    Body?: any;
}
export type RestApiResponse = unknown;
export interface InvokeRestApiResponse {
    RestApiStatusCode?: number;
    RestApiResponse?: any;
}
export type NextToken = string;
export interface ListEnvironmentsInput {
    NextToken?: string;
    MaxResults?: number;
}
export type EnvironmentList = string[];
export interface ListEnvironmentsOutput {
    Environments: string[];
    NextToken?: string;
}
export interface ListTagsForResourceInput {
    ResourceArn: string;
}
export interface ListTagsForResourceOutput {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface Dimension {
    Name: string;
    Value: string;
}
export type Dimensions = Dimension[];
export type Unit = string;
export interface StatisticSet {
    SampleCount?: number;
    Sum?: number;
    Minimum?: number;
    Maximum?: number;
}
export interface MetricDatum {
    MetricName: string;
    Timestamp: Date;
    Dimensions?: Dimension[];
    Value?: number;
    Unit?: string;
    StatisticValues?: StatisticSet;
}
export type MetricData = MetricDatum[];
export interface PublishMetricsInput {
    EnvironmentName: string;
    MetricData: MetricDatum[];
}
export interface PublishMetricsOutput {
}
export interface TagResourceInput {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    ResourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateNetworkConfigurationInput {
    SecurityGroupIds: string[];
}
export interface UpdateEnvironmentInput {
    Name: string;
    ExecutionRoleArn?: string;
    AirflowConfigurationOptions?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    AirflowVersion?: string;
    DagS3Path?: string;
    EnvironmentClass?: string;
    LoggingConfiguration?: LoggingConfigurationInput;
    MaxWorkers?: number;
    MinWorkers?: number;
    MaxWebservers?: number;
    MinWebservers?: number;
    WorkerReplacementStrategy?: string;
    NetworkConfiguration?: UpdateNetworkConfigurationInput;
    PluginsS3Path?: string;
    PluginsS3ObjectVersion?: string;
    RequirementsS3Path?: string;
    RequirementsS3ObjectVersion?: string;
    Schedulers?: number;
    SourceBucketArn?: string;
    StartupScriptS3Path?: string;
    StartupScriptS3ObjectVersion?: string;
    WebserverAccessMode?: string;
    WeeklyMaintenanceWindowStart?: string;
}
export interface UpdateEnvironmentOutput {
    Arn?: string;
}
export type CreateCliTokenError = ResourceNotFoundException | CommonErrors;
/**
 * Creates a CLI token for the Airflow CLI. To learn more, see Creating an Apache Airflow CLI token.
 */
export declare const createCliToken: API.OperationMethod<CreateCliTokenRequest, CreateCliTokenResponse, CreateCliTokenError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = InternalServerException | ServiceUnavailableException | ValidationException | MwaaExecutionRoleNotAssumable | CommonErrors;
/**
 * Creates an Amazon Managed Workflows for Apache Airflow (Amazon MWAA) environment.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentInput, CreateEnvironmentOutput, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateWebLoginTokenError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a web login token for the Airflow Web UI. To learn more, see Creating an Apache Airflow web login token.
 */
export declare const createWebLoginToken: API.OperationMethod<CreateWebLoginTokenRequest, CreateWebLoginTokenResponse, CreateWebLoginTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Managed Workflows for Apache Airflow (Amazon MWAA) environment.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentInput, DeleteEnvironmentOutput, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes an Amazon Managed Workflows for Apache Airflow (MWAA) environment.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentInput, GetEnvironmentOutput, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type InvokeRestApiError = AccessDeniedException | InternalServerException | ResourceNotFoundException | RestApiClientException | RestApiServerException | ValidationException | CommonErrors;
/**
 * Invokes the Apache Airflow REST API on the webserver with the specified inputs. To learn more, see Using the Apache Airflow REST API
 */
export declare const invokeRestApi: API.OperationMethod<InvokeRestApiRequest, InvokeRestApiResponse, InvokeRestApiError, Credentials | HttpClient.HttpClient>;
export type ListEnvironmentsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the Amazon Managed Workflows for Apache Airflow (MWAA) environments.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsInput, ListEnvironmentsOutput, ListEnvironmentsError, Credentials | HttpClient.HttpClient, EnvironmentName>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the key-value tag pairs associated to the Amazon Managed Workflows for Apache Airflow (MWAA) environment. For example, `"Environment": "Staging"`.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PublishMetricsError = InternalServerException | ValidationException | CommonErrors;
/**
 * **Internal only**. Publishes environment health metrics to Amazon CloudWatch.
 */
export declare const publishMetrics: API.OperationMethod<PublishMetricsInput, PublishMetricsOutput, PublishMetricsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Associates key-value tag pairs to your Amazon Managed Workflows for Apache Airflow (MWAA) environment.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes key-value tag pairs associated to your Amazon Managed Workflows for Apache Airflow (MWAA) environment. For example, `"Environment": "Staging"`.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Managed Workflows for Apache Airflow (MWAA) environment.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentInput, UpdateEnvironmentOutput, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mwaa.d.ts.map