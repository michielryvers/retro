import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const MethodNotAllowedException_base: S.TaggedErrorClass<"MethodNotAllowedException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MethodNotAllowedException extends /*@__PURE__*/ MethodNotAllowedException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const PayloadTooLargeException_base: S.TaggedErrorClass<"PayloadTooLargeException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PayloadTooLargeException extends /*@__PURE__*/ PayloadTooLargeException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type MapOf__string = {
    [key: string]: string | undefined;
};
export interface CreateApplicationRequest {
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateAppRequest {
    CreateApplicationRequest?: CreateApplicationRequest;
}
export interface ApplicationResponse {
    Arn?: string;
    Id?: string;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    CreationDate?: string;
}
export interface CreateAppResponse {
    ApplicationResponse: ApplicationResponse & {
        Arn: string;
        Id: string;
        Name: string;
    };
}
export type __EndpointTypesElement = "PUSH" | "GCM" | "APNS" | "APNS_SANDBOX" | "APNS_VOIP" | "APNS_VOIP_SANDBOX" | "ADM" | "SMS" | "VOICE" | "EMAIL" | "BAIDU" | "CUSTOM" | "IN_APP" | (string & {});
export type ListOf__EndpointTypesElement = __EndpointTypesElement[];
export interface CustomDeliveryConfiguration {
    DeliveryUri?: string;
    EndpointTypes?: __EndpointTypesElement[];
}
export type Action = "OPEN_APP" | "DEEP_LINK" | "URL" | (string & {});
export interface Message {
    Action?: Action;
    Body?: string;
    ImageIconUrl?: string;
    ImageSmallIconUrl?: string;
    ImageUrl?: string;
    JsonBody?: string;
    MediaUrl?: string;
    RawContent?: string;
    SilentPush?: boolean;
    TimeToLive?: number;
    Title?: string;
    Url?: string;
}
export interface CampaignCustomMessage {
    Data?: string;
}
export interface MessageHeader {
    Name?: string;
    Value?: string;
}
export type ListOfMessageHeader = MessageHeader[];
export interface CampaignEmailMessage {
    Body?: string;
    FromAddress?: string;
    Headers?: MessageHeader[];
    HtmlBody?: string;
    Title?: string;
}
export type MessageType = "TRANSACTIONAL" | "PROMOTIONAL" | (string & {});
export interface CampaignSmsMessage {
    Body?: string;
    MessageType?: MessageType;
    OriginationNumber?: string;
    SenderId?: string;
    EntityId?: string;
    TemplateId?: string;
}
export type Alignment = "LEFT" | "CENTER" | "RIGHT" | (string & {});
export interface InAppMessageBodyConfig {
    Alignment?: Alignment;
    Body?: string;
    TextColor?: string;
}
export interface InAppMessageHeaderConfig {
    Alignment?: Alignment;
    Header?: string;
    TextColor?: string;
}
export type ButtonAction = "LINK" | "DEEP_LINK" | "CLOSE" | (string & {});
export interface OverrideButtonConfiguration {
    ButtonAction?: ButtonAction;
    Link?: string;
}
export interface DefaultButtonConfiguration {
    BackgroundColor?: string;
    BorderRadius?: number;
    ButtonAction?: ButtonAction;
    Link?: string;
    Text?: string;
    TextColor?: string;
}
export interface InAppMessageButton {
    Android?: OverrideButtonConfiguration;
    DefaultConfig?: DefaultButtonConfiguration;
    IOS?: OverrideButtonConfiguration;
    Web?: OverrideButtonConfiguration;
}
export interface InAppMessageContent {
    BackgroundColor?: string;
    BodyConfig?: InAppMessageBodyConfig;
    HeaderConfig?: InAppMessageHeaderConfig;
    ImageUrl?: string;
    PrimaryBtn?: InAppMessageButton;
    SecondaryBtn?: InAppMessageButton;
}
export type ListOfInAppMessageContent = InAppMessageContent[];
export type Layout = "BOTTOM_BANNER" | "TOP_BANNER" | "OVERLAYS" | "MOBILE_FEED" | "MIDDLE_BANNER" | "CAROUSEL" | (string & {});
export interface CampaignInAppMessage {
    Body?: string;
    Content?: InAppMessageContent[];
    CustomConfig?: {
        [key: string]: string | undefined;
    };
    Layout?: Layout;
}
export interface MessageConfiguration {
    ADMMessage?: Message;
    APNSMessage?: Message;
    BaiduMessage?: Message;
    CustomMessage?: CampaignCustomMessage;
    DefaultMessage?: Message;
    EmailMessage?: CampaignEmailMessage;
    GCMMessage?: Message;
    SMSMessage?: CampaignSmsMessage;
    InAppMessage?: CampaignInAppMessage;
}
export type AttributeType = "INCLUSIVE" | "EXCLUSIVE" | "CONTAINS" | "BEFORE" | "AFTER" | "ON" | "BETWEEN" | (string & {});
export type ListOf__string = string[];
export interface AttributeDimension {
    AttributeType?: AttributeType;
    Values?: string[];
}
export type MapOfAttributeDimension = {
    [key: string]: AttributeDimension | undefined;
};
export type DimensionType = "INCLUSIVE" | "EXCLUSIVE" | (string & {});
export interface SetDimension {
    DimensionType?: DimensionType;
    Values?: string[];
}
export interface MetricDimension {
    ComparisonOperator?: string;
    Value?: number;
}
export type MapOfMetricDimension = {
    [key: string]: MetricDimension | undefined;
};
export interface EventDimensions {
    Attributes?: {
        [key: string]: AttributeDimension | undefined;
    };
    EventType?: SetDimension;
    Metrics?: {
        [key: string]: MetricDimension | undefined;
    };
}
export type FilterType = "SYSTEM" | "ENDPOINT" | (string & {});
export interface CampaignEventFilter {
    Dimensions?: EventDimensions;
    FilterType?: FilterType;
}
export type Frequency = "ONCE" | "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY" | "EVENT" | "IN_APP_EVENT" | (string & {});
export interface QuietTime {
    End?: string;
    Start?: string;
}
export interface Schedule {
    EndTime?: string;
    EventFilter?: CampaignEventFilter;
    Frequency?: Frequency;
    IsLocalTime?: boolean;
    QuietTime?: QuietTime;
    StartTime?: string;
    Timezone?: string;
}
export interface Template {
    Name?: string;
    Version?: string;
}
export interface TemplateConfiguration {
    EmailTemplate?: Template;
    PushTemplate?: Template;
    SMSTemplate?: Template;
    VoiceTemplate?: Template;
    InAppTemplate?: Template;
}
export interface WriteTreatmentResource {
    CustomDeliveryConfiguration?: CustomDeliveryConfiguration;
    MessageConfiguration?: MessageConfiguration;
    Schedule?: Schedule;
    SizePercent?: number;
    TemplateConfiguration?: TemplateConfiguration;
    TreatmentDescription?: string;
    TreatmentName?: string;
}
export type ListOfWriteTreatmentResource = WriteTreatmentResource[];
export type Mode = "DELIVERY" | "FILTER" | (string & {});
export interface CampaignHook {
    LambdaFunctionName?: string;
    Mode?: Mode;
    WebUrl?: string;
}
export interface CampaignLimits {
    Daily?: number;
    MaximumDuration?: number;
    MessagesPerSecond?: number;
    Total?: number;
    Session?: number;
}
export interface WriteCampaignRequest {
    AdditionalTreatments?: WriteTreatmentResource[];
    CustomDeliveryConfiguration?: CustomDeliveryConfiguration;
    Description?: string;
    HoldoutPercent?: number;
    Hook?: CampaignHook;
    IsPaused?: boolean;
    Limits?: CampaignLimits;
    MessageConfiguration?: MessageConfiguration;
    Name?: string;
    Schedule?: Schedule;
    SegmentId?: string;
    SegmentVersion?: number;
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateConfiguration?: TemplateConfiguration;
    TreatmentDescription?: string;
    TreatmentName?: string;
    Priority?: number;
}
export interface CreateCampaignRequest {
    ApplicationId: string;
    WriteCampaignRequest?: WriteCampaignRequest;
}
export type CampaignStatus = "SCHEDULED" | "EXECUTING" | "PENDING_NEXT_RUN" | "COMPLETED" | "PAUSED" | "DELETED" | "INVALID" | (string & {});
export interface CampaignState {
    CampaignStatus?: CampaignStatus;
}
export interface TreatmentResource {
    CustomDeliveryConfiguration?: CustomDeliveryConfiguration;
    Id?: string;
    MessageConfiguration?: MessageConfiguration;
    Schedule?: Schedule;
    SizePercent?: number;
    State?: CampaignState;
    TemplateConfiguration?: TemplateConfiguration;
    TreatmentDescription?: string;
    TreatmentName?: string;
}
export type ListOfTreatmentResource = TreatmentResource[];
export interface CampaignResponse {
    AdditionalTreatments?: TreatmentResource[];
    ApplicationId?: string;
    Arn?: string;
    CreationDate?: string;
    CustomDeliveryConfiguration?: CustomDeliveryConfiguration;
    DefaultState?: CampaignState;
    Description?: string;
    HoldoutPercent?: number;
    Hook?: CampaignHook;
    Id?: string;
    IsPaused?: boolean;
    LastModifiedDate?: string;
    Limits?: CampaignLimits;
    MessageConfiguration?: MessageConfiguration;
    Name?: string;
    Schedule?: Schedule;
    SegmentId?: string;
    SegmentVersion?: number;
    State?: CampaignState;
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateConfiguration?: TemplateConfiguration;
    TreatmentDescription?: string;
    TreatmentName?: string;
    Version?: number;
    Priority?: number;
}
export interface CreateCampaignResponse {
    CampaignResponse: CampaignResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        SegmentId: string;
        SegmentVersion: number;
        AdditionalTreatments: (TreatmentResource & {
            Id: string;
            SizePercent: number;
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
        CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
            DeliveryUri: string;
        };
        MessageConfiguration: MessageConfiguration & {
            InAppMessage: CampaignInAppMessage & {
                Content: (InAppMessageContent & {
                    BodyConfig: InAppMessageBodyConfig & {
                        Alignment: Alignment;
                        Body: string;
                        TextColor: string;
                    };
                    HeaderConfig: InAppMessageHeaderConfig & {
                        Alignment: Alignment;
                        Header: string;
                        TextColor: string;
                    };
                    PrimaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                    SecondaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                })[];
            };
        };
        Schedule: Schedule & {
            StartTime: string;
            EventFilter: CampaignEventFilter & {
                Dimensions: EventDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    EventType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                };
                FilterType: FilterType;
            };
        };
    };
}
export interface EmailTemplateRequest {
    DefaultSubstitutions?: string;
    HtmlPart?: string;
    RecommenderId?: string;
    Subject?: string;
    Headers?: MessageHeader[];
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateDescription?: string;
    TextPart?: string;
}
export interface CreateEmailTemplateRequest {
    EmailTemplateRequest?: EmailTemplateRequest;
    TemplateName: string;
}
export interface CreateTemplateMessageBody {
    Arn?: string;
    Message?: string;
    RequestID?: string;
}
export interface CreateEmailTemplateResponse {
    CreateTemplateMessageBody: CreateTemplateMessageBody;
}
export interface ExportJobRequest {
    RoleArn?: string;
    S3UrlPrefix?: string;
    SegmentId?: string;
    SegmentVersion?: number;
}
export interface CreateExportJobRequest {
    ApplicationId: string;
    ExportJobRequest?: ExportJobRequest;
}
export interface ExportJobResource {
    RoleArn?: string;
    S3UrlPrefix?: string;
    SegmentId?: string;
    SegmentVersion?: number;
}
export type JobStatus = "CREATED" | "PREPARING_FOR_INITIALIZATION" | "INITIALIZING" | "PROCESSING" | "PENDING_JOB" | "COMPLETING" | "COMPLETED" | "FAILING" | "FAILED" | (string & {});
export interface ExportJobResponse {
    ApplicationId?: string;
    CompletedPieces?: number;
    CompletionDate?: string;
    CreationDate?: string;
    Definition?: ExportJobResource;
    FailedPieces?: number;
    Failures?: string[];
    Id?: string;
    JobStatus?: JobStatus;
    TotalFailures?: number;
    TotalPieces?: number;
    TotalProcessed?: number;
    Type?: string;
}
export interface CreateExportJobResponse {
    ExportJobResponse: ExportJobResponse & {
        ApplicationId: string;
        CreationDate: string;
        Definition: ExportJobResource & {
            RoleArn: string;
            S3UrlPrefix: string;
        };
        Id: string;
        JobStatus: JobStatus;
        Type: string;
    };
}
export type Format = "CSV" | "JSON" | (string & {});
export interface ImportJobRequest {
    DefineSegment?: boolean;
    ExternalId?: string;
    Format?: Format;
    RegisterEndpoints?: boolean;
    RoleArn?: string;
    S3Url?: string;
    SegmentId?: string;
    SegmentName?: string;
}
export interface CreateImportJobRequest {
    ApplicationId: string;
    ImportJobRequest?: ImportJobRequest;
}
export interface ImportJobResource {
    DefineSegment?: boolean;
    ExternalId?: string;
    Format?: Format;
    RegisterEndpoints?: boolean;
    RoleArn?: string;
    S3Url?: string;
    SegmentId?: string;
    SegmentName?: string;
}
export interface ImportJobResponse {
    ApplicationId?: string;
    CompletedPieces?: number;
    CompletionDate?: string;
    CreationDate?: string;
    Definition?: ImportJobResource;
    FailedPieces?: number;
    Failures?: string[];
    Id?: string;
    JobStatus?: JobStatus;
    TotalFailures?: number;
    TotalPieces?: number;
    TotalProcessed?: number;
    Type?: string;
}
export interface CreateImportJobResponse {
    ImportJobResponse: ImportJobResponse & {
        ApplicationId: string;
        CreationDate: string;
        Definition: ImportJobResource & {
            Format: Format;
            RoleArn: string;
            S3Url: string;
        };
        Id: string;
        JobStatus: JobStatus;
        Type: string;
    };
}
export interface InAppTemplateRequest {
    Content?: InAppMessageContent[];
    CustomConfig?: {
        [key: string]: string | undefined;
    };
    Layout?: Layout;
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateDescription?: string;
}
export interface CreateInAppTemplateRequest {
    InAppTemplateRequest?: InAppTemplateRequest;
    TemplateName: string;
}
export interface TemplateCreateMessageBody {
    Arn?: string;
    Message?: string;
    RequestID?: string;
}
export interface CreateInAppTemplateResponse {
    TemplateCreateMessageBody: TemplateCreateMessageBody;
}
export interface JourneyCustomMessage {
    Data?: string;
}
export interface CustomMessageActivity {
    DeliveryUri?: string;
    EndpointTypes?: __EndpointTypesElement[];
    MessageConfig?: JourneyCustomMessage;
    NextActivity?: string;
    TemplateName?: string;
    TemplateVersion?: string;
}
export interface EventCondition {
    Dimensions?: EventDimensions;
    MessageActivity?: string;
}
export interface SegmentCondition {
    SegmentId?: string;
}
export type Duration = "HR_24" | "DAY_7" | "DAY_14" | "DAY_30" | (string & {});
export type RecencyType = "ACTIVE" | "INACTIVE" | (string & {});
export interface RecencyDimension {
    Duration?: Duration;
    RecencyType?: RecencyType;
}
export interface SegmentBehaviors {
    Recency?: RecencyDimension;
}
export interface SegmentDemographics {
    AppVersion?: SetDimension;
    Channel?: SetDimension;
    DeviceType?: SetDimension;
    Make?: SetDimension;
    Model?: SetDimension;
    Platform?: SetDimension;
}
export interface GPSCoordinates {
    Latitude?: number;
    Longitude?: number;
}
export interface GPSPointDimension {
    Coordinates?: GPSCoordinates;
    RangeInKilometers?: number;
}
export interface SegmentLocation {
    Country?: SetDimension;
    GPSPoint?: GPSPointDimension;
}
export interface SegmentDimensions {
    Attributes?: {
        [key: string]: AttributeDimension | undefined;
    };
    Behavior?: SegmentBehaviors;
    Demographic?: SegmentDemographics;
    Location?: SegmentLocation;
    Metrics?: {
        [key: string]: MetricDimension | undefined;
    };
    UserAttributes?: {
        [key: string]: AttributeDimension | undefined;
    };
}
export interface SimpleCondition {
    EventCondition?: EventCondition;
    SegmentCondition?: SegmentCondition;
    SegmentDimensions?: SegmentDimensions;
}
export type ListOfSimpleCondition = SimpleCondition[];
export type Operator = "ALL" | "ANY" | (string & {});
export interface Condition {
    Conditions?: SimpleCondition[];
    Operator?: Operator;
}
export interface WaitTime {
    WaitFor?: string;
    WaitUntil?: string;
}
export interface ConditionalSplitActivity {
    Condition?: Condition;
    EvaluationWaitTime?: WaitTime;
    FalseActivity?: string;
    TrueActivity?: string;
}
export interface JourneyEmailMessage {
    FromAddress?: string;
}
export interface EmailMessageActivity {
    MessageConfig?: JourneyEmailMessage;
    NextActivity?: string;
    TemplateName?: string;
    TemplateVersion?: string;
}
export interface HoldoutActivity {
    NextActivity?: string;
    Percentage?: number;
}
export interface MultiConditionalBranch {
    Condition?: SimpleCondition;
    NextActivity?: string;
}
export type ListOfMultiConditionalBranch = MultiConditionalBranch[];
export interface MultiConditionalSplitActivity {
    Branches?: MultiConditionalBranch[];
    DefaultActivity?: string;
    EvaluationWaitTime?: WaitTime;
}
export interface JourneyPushMessage {
    TimeToLive?: string;
}
export interface PushMessageActivity {
    MessageConfig?: JourneyPushMessage;
    NextActivity?: string;
    TemplateName?: string;
    TemplateVersion?: string;
}
export interface RandomSplitEntry {
    NextActivity?: string;
    Percentage?: number;
}
export type ListOfRandomSplitEntry = RandomSplitEntry[];
export interface RandomSplitActivity {
    Branches?: RandomSplitEntry[];
}
export interface JourneySMSMessage {
    MessageType?: MessageType;
    OriginationNumber?: string;
    SenderId?: string;
    EntityId?: string;
    TemplateId?: string;
}
export interface SMSMessageActivity {
    MessageConfig?: JourneySMSMessage;
    NextActivity?: string;
    TemplateName?: string;
    TemplateVersion?: string;
}
export interface WaitActivity {
    NextActivity?: string;
    WaitTime?: WaitTime;
}
export interface ContactCenterActivity {
    NextActivity?: string;
}
export interface Activity {
    CUSTOM?: CustomMessageActivity;
    ConditionalSplit?: ConditionalSplitActivity;
    Description?: string;
    EMAIL?: EmailMessageActivity;
    Holdout?: HoldoutActivity;
    MultiCondition?: MultiConditionalSplitActivity;
    PUSH?: PushMessageActivity;
    RandomSplit?: RandomSplitActivity;
    SMS?: SMSMessageActivity;
    Wait?: WaitActivity;
    ContactCenter?: ContactCenterActivity;
}
export type MapOfActivity = {
    [key: string]: Activity | undefined;
};
export interface JourneyTimeframeCap {
    Cap?: number;
    Days?: number;
}
export interface JourneyLimits {
    DailyCap?: number;
    EndpointReentryCap?: number;
    MessagesPerSecond?: number;
    EndpointReentryInterval?: string;
    TimeframeCap?: JourneyTimeframeCap;
    TotalCap?: number;
}
export type __timestampIso8601 = Date;
export interface JourneySchedule {
    EndTime?: Date;
    StartTime?: Date;
    Timezone?: string;
}
export interface EventFilter {
    Dimensions?: EventDimensions;
    FilterType?: FilterType;
}
export interface EventStartCondition {
    EventFilter?: EventFilter;
    SegmentId?: string;
}
export interface StartCondition {
    Description?: string;
    EventStartCondition?: EventStartCondition;
    SegmentStartCondition?: SegmentCondition;
}
export type State = "DRAFT" | "ACTIVE" | "COMPLETED" | "CANCELLED" | "CLOSED" | "PAUSED" | (string & {});
export interface JourneyChannelSettings {
    ConnectCampaignArn?: string;
    ConnectCampaignExecutionRoleArn?: string;
}
export type DayOfWeek = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export interface OpenHoursRule {
    StartTime?: string;
    EndTime?: string;
}
export type ListOfOpenHoursRules = OpenHoursRule[];
export type MapOfListOfOpenHoursRules = {
    [key in DayOfWeek]?: OpenHoursRule[];
};
export interface OpenHours {
    EMAIL?: {
        [key: string]: OpenHoursRule[] | undefined;
    };
    SMS?: {
        [key: string]: OpenHoursRule[] | undefined;
    };
    PUSH?: {
        [key: string]: OpenHoursRule[] | undefined;
    };
    VOICE?: {
        [key: string]: OpenHoursRule[] | undefined;
    };
    CUSTOM?: {
        [key: string]: OpenHoursRule[] | undefined;
    };
}
export interface ClosedDaysRule {
    Name?: string;
    StartDateTime?: string;
    EndDateTime?: string;
}
export type ListOfClosedDaysRules = ClosedDaysRule[];
export interface ClosedDays {
    EMAIL?: ClosedDaysRule[];
    SMS?: ClosedDaysRule[];
    PUSH?: ClosedDaysRule[];
    VOICE?: ClosedDaysRule[];
    CUSTOM?: ClosedDaysRule[];
}
export type __TimezoneEstimationMethodsElement = "PHONE_NUMBER" | "POSTAL_CODE" | (string & {});
export type ListOf__TimezoneEstimationMethodsElement = __TimezoneEstimationMethodsElement[];
export interface WriteJourneyRequest {
    Activities?: {
        [key: string]: Activity | undefined;
    };
    CreationDate?: string;
    LastModifiedDate?: string;
    Limits?: JourneyLimits;
    LocalTime?: boolean;
    Name?: string;
    QuietTime?: QuietTime;
    RefreshFrequency?: string;
    Schedule?: JourneySchedule;
    StartActivity?: string;
    StartCondition?: StartCondition;
    State?: State;
    WaitForQuietTime?: boolean;
    RefreshOnSegmentUpdate?: boolean;
    JourneyChannelSettings?: JourneyChannelSettings;
    SendingSchedule?: boolean;
    OpenHours?: OpenHours;
    ClosedDays?: ClosedDays;
    TimezoneEstimationMethods?: __TimezoneEstimationMethodsElement[];
}
export interface CreateJourneyRequest {
    ApplicationId: string;
    WriteJourneyRequest?: WriteJourneyRequest;
}
export interface JourneyResponse {
    Activities?: {
        [key: string]: Activity | undefined;
    };
    ApplicationId?: string;
    CreationDate?: string;
    Id?: string;
    LastModifiedDate?: string;
    Limits?: JourneyLimits;
    LocalTime?: boolean;
    Name?: string;
    QuietTime?: QuietTime;
    RefreshFrequency?: string;
    Schedule?: JourneySchedule;
    StartActivity?: string;
    StartCondition?: StartCondition;
    State?: State;
    tags?: {
        [key: string]: string | undefined;
    };
    WaitForQuietTime?: boolean;
    RefreshOnSegmentUpdate?: boolean;
    JourneyChannelSettings?: JourneyChannelSettings;
    SendingSchedule?: boolean;
    OpenHours?: OpenHours;
    ClosedDays?: ClosedDays;
    TimezoneEstimationMethods?: __TimezoneEstimationMethodsElement[];
}
export interface CreateJourneyResponse {
    JourneyResponse: JourneyResponse & {
        ApplicationId: string;
        Id: string;
        Name: string;
        Activities: {
            [key: string]: (Activity & {
                ConditionalSplit: ConditionalSplitActivity & {
                    Condition: Condition & {
                        Conditions: (SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        })[];
                    };
                };
                Holdout: HoldoutActivity & {
                    Percentage: number;
                };
                MultiCondition: MultiConditionalSplitActivity & {
                    Branches: (MultiConditionalBranch & {
                        Condition: SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        };
                    })[];
                };
            }) | undefined;
        };
        StartCondition: StartCondition & {
            EventStartCondition: EventStartCondition & {
                EventFilter: EventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
            SegmentStartCondition: SegmentCondition & {
                SegmentId: string;
            };
        };
    };
}
export interface AndroidPushNotificationTemplate {
    Action?: Action;
    Body?: string;
    ImageIconUrl?: string;
    ImageUrl?: string;
    RawContent?: string;
    SmallImageIconUrl?: string;
    Sound?: string;
    Title?: string;
    Url?: string;
}
export interface APNSPushNotificationTemplate {
    Action?: Action;
    Body?: string;
    MediaUrl?: string;
    RawContent?: string;
    Sound?: string;
    Title?: string;
    Url?: string;
}
export interface DefaultPushNotificationTemplate {
    Action?: Action;
    Body?: string;
    Sound?: string;
    Title?: string;
    Url?: string;
}
export interface PushNotificationTemplateRequest {
    ADM?: AndroidPushNotificationTemplate;
    APNS?: APNSPushNotificationTemplate;
    Baidu?: AndroidPushNotificationTemplate;
    Default?: DefaultPushNotificationTemplate;
    DefaultSubstitutions?: string;
    GCM?: AndroidPushNotificationTemplate;
    RecommenderId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateDescription?: string;
}
export interface CreatePushTemplateRequest {
    PushNotificationTemplateRequest?: PushNotificationTemplateRequest;
    TemplateName: string;
}
export interface CreatePushTemplateResponse {
    CreateTemplateMessageBody: CreateTemplateMessageBody;
}
export interface CreateRecommenderConfigurationShape {
    Attributes?: {
        [key: string]: string | undefined;
    };
    Description?: string;
    Name?: string;
    RecommendationProviderIdType?: string;
    RecommendationProviderRoleArn?: string;
    RecommendationProviderUri?: string;
    RecommendationTransformerUri?: string;
    RecommendationsDisplayName?: string;
    RecommendationsPerMessage?: number;
}
export interface CreateRecommenderConfigurationRequest {
    CreateRecommenderConfiguration?: CreateRecommenderConfigurationShape;
}
export interface RecommenderConfigurationResponse {
    Attributes?: {
        [key: string]: string | undefined;
    };
    CreationDate?: string;
    Description?: string;
    Id?: string;
    LastModifiedDate?: string;
    Name?: string;
    RecommendationProviderIdType?: string;
    RecommendationProviderRoleArn?: string;
    RecommendationProviderUri?: string;
    RecommendationTransformerUri?: string;
    RecommendationsDisplayName?: string;
    RecommendationsPerMessage?: number;
}
export interface CreateRecommenderConfigurationResponse {
    RecommenderConfigurationResponse: RecommenderConfigurationResponse & {
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        RecommendationProviderRoleArn: string;
        RecommendationProviderUri: string;
    };
}
export type ListOfSegmentDimensions = SegmentDimensions[];
export interface SegmentReference {
    Id?: string;
    Version?: number;
}
export type ListOfSegmentReference = SegmentReference[];
export type SourceType = "ALL" | "ANY" | "NONE" | (string & {});
export type Type = "ALL" | "ANY" | "NONE" | (string & {});
export interface SegmentGroup {
    Dimensions?: SegmentDimensions[];
    SourceSegments?: SegmentReference[];
    SourceType?: SourceType;
    Type?: Type;
}
export type ListOfSegmentGroup = SegmentGroup[];
export type Include = "ALL" | "ANY" | "NONE" | (string & {});
export interface SegmentGroupList {
    Groups?: SegmentGroup[];
    Include?: Include;
}
export interface WriteSegmentRequest {
    Dimensions?: SegmentDimensions;
    Name?: string;
    SegmentGroups?: SegmentGroupList;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateSegmentRequest {
    ApplicationId: string;
    WriteSegmentRequest?: WriteSegmentRequest;
}
export type MapOf__integer = {
    [key: string]: number | undefined;
};
export interface SegmentImportResource {
    ChannelCounts?: {
        [key: string]: number | undefined;
    };
    ExternalId?: string;
    Format?: Format;
    RoleArn?: string;
    S3Url?: string;
    Size?: number;
}
export type SegmentType = "DIMENSIONAL" | "IMPORT" | (string & {});
export interface SegmentResponse {
    ApplicationId?: string;
    Arn?: string;
    CreationDate?: string;
    Dimensions?: SegmentDimensions;
    Id?: string;
    ImportDefinition?: SegmentImportResource;
    LastModifiedDate?: string;
    Name?: string;
    SegmentGroups?: SegmentGroupList;
    SegmentType?: SegmentType;
    tags?: {
        [key: string]: string | undefined;
    };
    Version?: number;
}
export interface CreateSegmentResponse {
    SegmentResponse: SegmentResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        SegmentType: SegmentType;
        Dimensions: SegmentDimensions & {
            Attributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
            Behavior: SegmentBehaviors & {
                Recency: RecencyDimension & {
                    Duration: Duration;
                    RecencyType: RecencyType;
                };
            };
            Demographic: SegmentDemographics & {
                AppVersion: SetDimension & {
                    Values: ListOf__string;
                };
                Channel: SetDimension & {
                    Values: ListOf__string;
                };
                DeviceType: SetDimension & {
                    Values: ListOf__string;
                };
                Make: SetDimension & {
                    Values: ListOf__string;
                };
                Model: SetDimension & {
                    Values: ListOf__string;
                };
                Platform: SetDimension & {
                    Values: ListOf__string;
                };
            };
            Location: SegmentLocation & {
                Country: SetDimension & {
                    Values: ListOf__string;
                };
                GPSPoint: GPSPointDimension & {
                    Coordinates: GPSCoordinates & {
                        Latitude: number;
                        Longitude: number;
                    };
                };
            };
            Metrics: {
                [key: string]: (MetricDimension & {
                    ComparisonOperator: string;
                    Value: number;
                }) | undefined;
            };
            UserAttributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
        };
        ImportDefinition: SegmentImportResource & {
            ExternalId: string;
            Format: Format;
            RoleArn: string;
            S3Url: string;
            Size: number;
        };
        SegmentGroups: SegmentGroupList & {
            Groups: (SegmentGroup & {
                Dimensions: (SegmentDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    Behavior: SegmentBehaviors & {
                        Recency: RecencyDimension & {
                            Duration: Duration;
                            RecencyType: RecencyType;
                        };
                    };
                    Demographic: SegmentDemographics & {
                        AppVersion: SetDimension & {
                            Values: ListOf__string;
                        };
                        Channel: SetDimension & {
                            Values: ListOf__string;
                        };
                        DeviceType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Make: SetDimension & {
                            Values: ListOf__string;
                        };
                        Model: SetDimension & {
                            Values: ListOf__string;
                        };
                        Platform: SetDimension & {
                            Values: ListOf__string;
                        };
                    };
                    Location: SegmentLocation & {
                        Country: SetDimension & {
                            Values: ListOf__string;
                        };
                        GPSPoint: GPSPointDimension & {
                            Coordinates: GPSCoordinates & {
                                Latitude: number;
                                Longitude: number;
                            };
                        };
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                    UserAttributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                })[];
                SourceSegments: (SegmentReference & {
                    Id: string;
                })[];
            })[];
        };
    };
}
export interface SMSTemplateRequest {
    Body?: string;
    DefaultSubstitutions?: string;
    RecommenderId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateDescription?: string;
}
export interface CreateSmsTemplateRequest {
    SMSTemplateRequest?: SMSTemplateRequest;
    TemplateName: string;
}
export interface CreateSmsTemplateResponse {
    CreateTemplateMessageBody: CreateTemplateMessageBody;
}
export interface VoiceTemplateRequest {
    Body?: string;
    DefaultSubstitutions?: string;
    LanguageCode?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateDescription?: string;
    VoiceId?: string;
}
export interface CreateVoiceTemplateRequest {
    TemplateName: string;
    VoiceTemplateRequest?: VoiceTemplateRequest;
}
export interface CreateVoiceTemplateResponse {
    CreateTemplateMessageBody: CreateTemplateMessageBody;
}
export interface DeleteAdmChannelRequest {
    ApplicationId: string;
}
export interface ADMChannelResponse {
    ApplicationId?: string;
    CreationDate?: string;
    Enabled?: boolean;
    HasCredential?: boolean;
    Id?: string;
    IsArchived?: boolean;
    LastModifiedBy?: string;
    LastModifiedDate?: string;
    Platform?: string;
    Version?: number;
}
export interface DeleteAdmChannelResponse {
    ADMChannelResponse: ADMChannelResponse & {
        Platform: string;
    };
}
export interface DeleteApnsChannelRequest {
    ApplicationId: string;
}
export interface APNSChannelResponse {
    ApplicationId?: string;
    CreationDate?: string;
    DefaultAuthenticationMethod?: string;
    Enabled?: boolean;
    HasCredential?: boolean;
    HasTokenKey?: boolean;
    Id?: string;
    IsArchived?: boolean;
    LastModifiedBy?: string;
    LastModifiedDate?: string;
    Platform?: string;
    Version?: number;
}
export interface DeleteApnsChannelResponse {
    APNSChannelResponse: APNSChannelResponse & {
        Platform: string;
    };
}
export interface DeleteApnsSandboxChannelRequest {
    ApplicationId: string;
}
export interface APNSSandboxChannelResponse {
    ApplicationId?: string;
    CreationDate?: string;
    DefaultAuthenticationMethod?: string;
    Enabled?: boolean;
    HasCredential?: boolean;
    HasTokenKey?: boolean;
    Id?: string;
    IsArchived?: boolean;
    LastModifiedBy?: string;
    LastModifiedDate?: string;
    Platform?: string;
    Version?: number;
}
export interface DeleteApnsSandboxChannelResponse {
    APNSSandboxChannelResponse: APNSSandboxChannelResponse & {
        Platform: string;
    };
}
export interface DeleteApnsVoipChannelRequest {
    ApplicationId: string;
}
export interface APNSVoipChannelResponse {
    ApplicationId?: string;
    CreationDate?: string;
    DefaultAuthenticationMethod?: string;
    Enabled?: boolean;
    HasCredential?: boolean;
    HasTokenKey?: boolean;
    Id?: string;
    IsArchived?: boolean;
    LastModifiedBy?: string;
    LastModifiedDate?: string;
    Platform?: string;
    Version?: number;
}
export interface DeleteApnsVoipChannelResponse {
    APNSVoipChannelResponse: APNSVoipChannelResponse & {
        Platform: string;
    };
}
export interface DeleteApnsVoipSandboxChannelRequest {
    ApplicationId: string;
}
export interface APNSVoipSandboxChannelResponse {
    ApplicationId?: string;
    CreationDate?: string;
    DefaultAuthenticationMethod?: string;
    Enabled?: boolean;
    HasCredential?: boolean;
    HasTokenKey?: boolean;
    Id?: string;
    IsArchived?: boolean;
    LastModifiedBy?: string;
    LastModifiedDate?: string;
    Platform?: string;
    Version?: number;
}
export interface DeleteApnsVoipSandboxChannelResponse {
    APNSVoipSandboxChannelResponse: APNSVoipSandboxChannelResponse & {
        Platform: string;
    };
}
export interface DeleteAppRequest {
    ApplicationId: string;
}
export interface DeleteAppResponse {
    ApplicationResponse: ApplicationResponse & {
        Arn: string;
        Id: string;
        Name: string;
    };
}
export interface DeleteBaiduChannelRequest {
    ApplicationId: string;
}
export interface BaiduChannelResponse {
    ApplicationId?: string;
    CreationDate?: string;
    Credential?: string;
    Enabled?: boolean;
    HasCredential?: boolean;
    Id?: string;
    IsArchived?: boolean;
    LastModifiedBy?: string;
    LastModifiedDate?: string;
    Platform?: string;
    Version?: number;
}
export interface DeleteBaiduChannelResponse {
    BaiduChannelResponse: BaiduChannelResponse & {
        Credential: string;
        Platform: string;
    };
}
export interface DeleteCampaignRequest {
    ApplicationId: string;
    CampaignId: string;
}
export interface DeleteCampaignResponse {
    CampaignResponse: CampaignResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        SegmentId: string;
        SegmentVersion: number;
        AdditionalTreatments: (TreatmentResource & {
            Id: string;
            SizePercent: number;
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
        CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
            DeliveryUri: string;
        };
        MessageConfiguration: MessageConfiguration & {
            InAppMessage: CampaignInAppMessage & {
                Content: (InAppMessageContent & {
                    BodyConfig: InAppMessageBodyConfig & {
                        Alignment: Alignment;
                        Body: string;
                        TextColor: string;
                    };
                    HeaderConfig: InAppMessageHeaderConfig & {
                        Alignment: Alignment;
                        Header: string;
                        TextColor: string;
                    };
                    PrimaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                    SecondaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                })[];
            };
        };
        Schedule: Schedule & {
            StartTime: string;
            EventFilter: CampaignEventFilter & {
                Dimensions: EventDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    EventType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                };
                FilterType: FilterType;
            };
        };
    };
}
export interface DeleteEmailChannelRequest {
    ApplicationId: string;
}
export interface EmailChannelResponse {
    ApplicationId?: string;
    ConfigurationSet?: string;
    CreationDate?: string;
    Enabled?: boolean;
    FromAddress?: string;
    HasCredential?: boolean;
    Id?: string;
    Identity?: string;
    IsArchived?: boolean;
    LastModifiedBy?: string;
    LastModifiedDate?: string;
    MessagesPerSecond?: number;
    Platform?: string;
    RoleArn?: string;
    OrchestrationSendingRoleArn?: string;
    Version?: number;
}
export interface DeleteEmailChannelResponse {
    EmailChannelResponse: EmailChannelResponse & {
        Platform: string;
    };
}
export interface DeleteEmailTemplateRequest {
    TemplateName: string;
    Version?: string;
}
export interface MessageBody {
    Message?: string;
    RequestID?: string;
}
export interface DeleteEmailTemplateResponse {
    MessageBody: MessageBody;
}
export interface DeleteEndpointRequest {
    ApplicationId: string;
    EndpointId: string;
}
export type MapOfListOf__string = {
    [key: string]: string[] | undefined;
};
export type ChannelType = "PUSH" | "GCM" | "APNS" | "APNS_SANDBOX" | "APNS_VOIP" | "APNS_VOIP_SANDBOX" | "ADM" | "SMS" | "VOICE" | "EMAIL" | "BAIDU" | "CUSTOM" | "IN_APP" | (string & {});
export interface EndpointDemographic {
    AppVersion?: string;
    Locale?: string;
    Make?: string;
    Model?: string;
    ModelVersion?: string;
    Platform?: string;
    PlatformVersion?: string;
    Timezone?: string;
}
export interface EndpointLocation {
    City?: string;
    Country?: string;
    Latitude?: number;
    Longitude?: number;
    PostalCode?: string;
    Region?: string;
}
export type MapOf__double = {
    [key: string]: number | undefined;
};
export interface EndpointUser {
    UserAttributes?: {
        [key: string]: string[] | undefined;
    };
    UserId?: string;
}
export interface EndpointResponse {
    Address?: string;
    ApplicationId?: string;
    Attributes?: {
        [key: string]: string[] | undefined;
    };
    ChannelType?: ChannelType;
    CohortId?: string;
    CreationDate?: string;
    Demographic?: EndpointDemographic;
    EffectiveDate?: string;
    EndpointStatus?: string;
    Id?: string;
    Location?: EndpointLocation;
    Metrics?: {
        [key: string]: number | undefined;
    };
    OptOut?: string;
    RequestId?: string;
    User?: EndpointUser;
}
export interface DeleteEndpointResponse {
    EndpointResponse: EndpointResponse;
}
export interface DeleteEventStreamRequest {
    ApplicationId: string;
}
export interface EventStream {
    ApplicationId?: string;
    DestinationStreamArn?: string;
    ExternalId?: string;
    LastModifiedDate?: string;
    LastUpdatedBy?: string;
    RoleArn?: string;
}
export interface DeleteEventStreamResponse {
    EventStream: EventStream & {
        ApplicationId: string;
        DestinationStreamArn: string;
        RoleArn: string;
    };
}
export interface DeleteGcmChannelRequest {
    ApplicationId: string;
}
export interface GCMChannelResponse {
    ApplicationId?: string;
    CreationDate?: string;
    Credential?: string;
    DefaultAuthenticationMethod?: string;
    Enabled?: boolean;
    HasCredential?: boolean;
    HasFcmServiceCredentials?: boolean;
    Id?: string;
    IsArchived?: boolean;
    LastModifiedBy?: string;
    LastModifiedDate?: string;
    Platform?: string;
    Version?: number;
}
export interface DeleteGcmChannelResponse {
    GCMChannelResponse: GCMChannelResponse & {
        Platform: string;
    };
}
export interface DeleteInAppTemplateRequest {
    TemplateName: string;
    Version?: string;
}
export interface DeleteInAppTemplateResponse {
    MessageBody: MessageBody;
}
export interface DeleteJourneyRequest {
    ApplicationId: string;
    JourneyId: string;
}
export interface DeleteJourneyResponse {
    JourneyResponse: JourneyResponse & {
        ApplicationId: string;
        Id: string;
        Name: string;
        Activities: {
            [key: string]: (Activity & {
                ConditionalSplit: ConditionalSplitActivity & {
                    Condition: Condition & {
                        Conditions: (SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        })[];
                    };
                };
                Holdout: HoldoutActivity & {
                    Percentage: number;
                };
                MultiCondition: MultiConditionalSplitActivity & {
                    Branches: (MultiConditionalBranch & {
                        Condition: SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        };
                    })[];
                };
            }) | undefined;
        };
        StartCondition: StartCondition & {
            EventStartCondition: EventStartCondition & {
                EventFilter: EventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
            SegmentStartCondition: SegmentCondition & {
                SegmentId: string;
            };
        };
    };
}
export interface DeletePushTemplateRequest {
    TemplateName: string;
    Version?: string;
}
export interface DeletePushTemplateResponse {
    MessageBody: MessageBody;
}
export interface DeleteRecommenderConfigurationRequest {
    RecommenderId: string;
}
export interface DeleteRecommenderConfigurationResponse {
    RecommenderConfigurationResponse: RecommenderConfigurationResponse & {
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        RecommendationProviderRoleArn: string;
        RecommendationProviderUri: string;
    };
}
export interface DeleteSegmentRequest {
    ApplicationId: string;
    SegmentId: string;
}
export interface DeleteSegmentResponse {
    SegmentResponse: SegmentResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        SegmentType: SegmentType;
        Dimensions: SegmentDimensions & {
            Attributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
            Behavior: SegmentBehaviors & {
                Recency: RecencyDimension & {
                    Duration: Duration;
                    RecencyType: RecencyType;
                };
            };
            Demographic: SegmentDemographics & {
                AppVersion: SetDimension & {
                    Values: ListOf__string;
                };
                Channel: SetDimension & {
                    Values: ListOf__string;
                };
                DeviceType: SetDimension & {
                    Values: ListOf__string;
                };
                Make: SetDimension & {
                    Values: ListOf__string;
                };
                Model: SetDimension & {
                    Values: ListOf__string;
                };
                Platform: SetDimension & {
                    Values: ListOf__string;
                };
            };
            Location: SegmentLocation & {
                Country: SetDimension & {
                    Values: ListOf__string;
                };
                GPSPoint: GPSPointDimension & {
                    Coordinates: GPSCoordinates & {
                        Latitude: number;
                        Longitude: number;
                    };
                };
            };
            Metrics: {
                [key: string]: (MetricDimension & {
                    ComparisonOperator: string;
                    Value: number;
                }) | undefined;
            };
            UserAttributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
        };
        ImportDefinition: SegmentImportResource & {
            ExternalId: string;
            Format: Format;
            RoleArn: string;
            S3Url: string;
            Size: number;
        };
        SegmentGroups: SegmentGroupList & {
            Groups: (SegmentGroup & {
                Dimensions: (SegmentDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    Behavior: SegmentBehaviors & {
                        Recency: RecencyDimension & {
                            Duration: Duration;
                            RecencyType: RecencyType;
                        };
                    };
                    Demographic: SegmentDemographics & {
                        AppVersion: SetDimension & {
                            Values: ListOf__string;
                        };
                        Channel: SetDimension & {
                            Values: ListOf__string;
                        };
                        DeviceType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Make: SetDimension & {
                            Values: ListOf__string;
                        };
                        Model: SetDimension & {
                            Values: ListOf__string;
                        };
                        Platform: SetDimension & {
                            Values: ListOf__string;
                        };
                    };
                    Location: SegmentLocation & {
                        Country: SetDimension & {
                            Values: ListOf__string;
                        };
                        GPSPoint: GPSPointDimension & {
                            Coordinates: GPSCoordinates & {
                                Latitude: number;
                                Longitude: number;
                            };
                        };
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                    UserAttributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                })[];
                SourceSegments: (SegmentReference & {
                    Id: string;
                })[];
            })[];
        };
    };
}
export interface DeleteSmsChannelRequest {
    ApplicationId: string;
}
export interface SMSChannelResponse {
    ApplicationId?: string;
    CreationDate?: string;
    Enabled?: boolean;
    HasCredential?: boolean;
    Id?: string;
    IsArchived?: boolean;
    LastModifiedBy?: string;
    LastModifiedDate?: string;
    Platform?: string;
    PromotionalMessagesPerSecond?: number;
    SenderId?: string;
    ShortCode?: string;
    TransactionalMessagesPerSecond?: number;
    Version?: number;
}
export interface DeleteSmsChannelResponse {
    SMSChannelResponse: SMSChannelResponse & {
        Platform: string;
    };
}
export interface DeleteSmsTemplateRequest {
    TemplateName: string;
    Version?: string;
}
export interface DeleteSmsTemplateResponse {
    MessageBody: MessageBody;
}
export interface DeleteUserEndpointsRequest {
    ApplicationId: string;
    UserId: string;
}
export type ListOfEndpointResponse = EndpointResponse[];
export interface EndpointsResponse {
    Item?: EndpointResponse[];
}
export interface DeleteUserEndpointsResponse {
    EndpointsResponse: EndpointsResponse & {
        Item: ListOfEndpointResponse;
    };
}
export interface DeleteVoiceChannelRequest {
    ApplicationId: string;
}
export interface VoiceChannelResponse {
    ApplicationId?: string;
    CreationDate?: string;
    Enabled?: boolean;
    HasCredential?: boolean;
    Id?: string;
    IsArchived?: boolean;
    LastModifiedBy?: string;
    LastModifiedDate?: string;
    Platform?: string;
    Version?: number;
}
export interface DeleteVoiceChannelResponse {
    VoiceChannelResponse: VoiceChannelResponse & {
        Platform: string;
    };
}
export interface DeleteVoiceTemplateRequest {
    TemplateName: string;
    Version?: string;
}
export interface DeleteVoiceTemplateResponse {
    MessageBody: MessageBody;
}
export interface GetAdmChannelRequest {
    ApplicationId: string;
}
export interface GetAdmChannelResponse {
    ADMChannelResponse: ADMChannelResponse & {
        Platform: string;
    };
}
export interface GetApnsChannelRequest {
    ApplicationId: string;
}
export interface GetApnsChannelResponse {
    APNSChannelResponse: APNSChannelResponse & {
        Platform: string;
    };
}
export interface GetApnsSandboxChannelRequest {
    ApplicationId: string;
}
export interface GetApnsSandboxChannelResponse {
    APNSSandboxChannelResponse: APNSSandboxChannelResponse & {
        Platform: string;
    };
}
export interface GetApnsVoipChannelRequest {
    ApplicationId: string;
}
export interface GetApnsVoipChannelResponse {
    APNSVoipChannelResponse: APNSVoipChannelResponse & {
        Platform: string;
    };
}
export interface GetApnsVoipSandboxChannelRequest {
    ApplicationId: string;
}
export interface GetApnsVoipSandboxChannelResponse {
    APNSVoipSandboxChannelResponse: APNSVoipSandboxChannelResponse & {
        Platform: string;
    };
}
export interface GetAppRequest {
    ApplicationId: string;
}
export interface GetAppResponse {
    ApplicationResponse: ApplicationResponse & {
        Arn: string;
        Id: string;
        Name: string;
    };
}
export interface GetApplicationDateRangeKpiRequest {
    ApplicationId: string;
    EndTime?: Date;
    KpiName: string;
    NextToken?: string;
    PageSize?: string;
    StartTime?: Date;
}
export interface ResultRowValue {
    Key?: string;
    Type?: string;
    Value?: string;
}
export type ListOfResultRowValue = ResultRowValue[];
export interface ResultRow {
    GroupedBys?: ResultRowValue[];
    Values?: ResultRowValue[];
}
export type ListOfResultRow = ResultRow[];
export interface BaseKpiResult {
    Rows?: ResultRow[];
}
export interface ApplicationDateRangeKpiResponse {
    ApplicationId?: string;
    EndTime?: Date;
    KpiName?: string;
    KpiResult?: BaseKpiResult;
    NextToken?: string;
    StartTime?: Date;
}
export interface GetApplicationDateRangeKpiResponse {
    ApplicationDateRangeKpiResponse: ApplicationDateRangeKpiResponse & {
        ApplicationId: string;
        EndTime: __timestampIso8601;
        KpiName: string;
        KpiResult: BaseKpiResult & {
            Rows: (ResultRow & {
                GroupedBys: (ResultRowValue & {
                    Key: string;
                    Type: string;
                    Value: string;
                })[];
                Values: (ResultRowValue & {
                    Key: string;
                    Type: string;
                    Value: string;
                })[];
            })[];
        };
        StartTime: __timestampIso8601;
    };
}
export interface GetApplicationSettingsRequest {
    ApplicationId: string;
}
export interface ApplicationSettingsJourneyLimits {
    DailyCap?: number;
    TimeframeCap?: JourneyTimeframeCap;
    TotalCap?: number;
}
export interface ApplicationSettingsResource {
    ApplicationId?: string;
    CampaignHook?: CampaignHook;
    LastModifiedDate?: string;
    Limits?: CampaignLimits;
    QuietTime?: QuietTime;
    JourneyLimits?: ApplicationSettingsJourneyLimits;
}
export interface GetApplicationSettingsResponse {
    ApplicationSettingsResource: ApplicationSettingsResource & {
        ApplicationId: string;
    };
}
export interface GetAppsRequest {
    PageSize?: string;
    Token?: string;
}
export type ListOfApplicationResponse = ApplicationResponse[];
export interface ApplicationsResponse {
    Item?: ApplicationResponse[];
    NextToken?: string;
}
export interface GetAppsResponse {
    ApplicationsResponse: ApplicationsResponse & {
        Item: (ApplicationResponse & {
            Arn: string;
            Id: string;
            Name: string;
        })[];
    };
}
export interface GetBaiduChannelRequest {
    ApplicationId: string;
}
export interface GetBaiduChannelResponse {
    BaiduChannelResponse: BaiduChannelResponse & {
        Credential: string;
        Platform: string;
    };
}
export interface GetCampaignRequest {
    ApplicationId: string;
    CampaignId: string;
}
export interface GetCampaignResponse {
    CampaignResponse: CampaignResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        SegmentId: string;
        SegmentVersion: number;
        AdditionalTreatments: (TreatmentResource & {
            Id: string;
            SizePercent: number;
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
        CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
            DeliveryUri: string;
        };
        MessageConfiguration: MessageConfiguration & {
            InAppMessage: CampaignInAppMessage & {
                Content: (InAppMessageContent & {
                    BodyConfig: InAppMessageBodyConfig & {
                        Alignment: Alignment;
                        Body: string;
                        TextColor: string;
                    };
                    HeaderConfig: InAppMessageHeaderConfig & {
                        Alignment: Alignment;
                        Header: string;
                        TextColor: string;
                    };
                    PrimaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                    SecondaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                })[];
            };
        };
        Schedule: Schedule & {
            StartTime: string;
            EventFilter: CampaignEventFilter & {
                Dimensions: EventDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    EventType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                };
                FilterType: FilterType;
            };
        };
    };
}
export interface GetCampaignActivitiesRequest {
    ApplicationId: string;
    CampaignId: string;
    PageSize?: string;
    Token?: string;
}
export interface ActivityResponse {
    ApplicationId?: string;
    CampaignId?: string;
    End?: string;
    Id?: string;
    Result?: string;
    ScheduledStart?: string;
    Start?: string;
    State?: string;
    SuccessfulEndpointCount?: number;
    TimezonesCompletedCount?: number;
    TimezonesTotalCount?: number;
    TotalEndpointCount?: number;
    TreatmentId?: string;
    ExecutionMetrics?: {
        [key: string]: string | undefined;
    };
}
export type ListOfActivityResponse = ActivityResponse[];
export interface ActivitiesResponse {
    Item?: ActivityResponse[];
    NextToken?: string;
}
export interface GetCampaignActivitiesResponse {
    ActivitiesResponse: ActivitiesResponse & {
        Item: (ActivityResponse & {
            ApplicationId: string;
            CampaignId: string;
            Id: string;
        })[];
    };
}
export interface GetCampaignDateRangeKpiRequest {
    ApplicationId: string;
    CampaignId: string;
    EndTime?: Date;
    KpiName: string;
    NextToken?: string;
    PageSize?: string;
    StartTime?: Date;
}
export interface CampaignDateRangeKpiResponse {
    ApplicationId?: string;
    CampaignId?: string;
    EndTime?: Date;
    KpiName?: string;
    KpiResult?: BaseKpiResult;
    NextToken?: string;
    StartTime?: Date;
}
export interface GetCampaignDateRangeKpiResponse {
    CampaignDateRangeKpiResponse: CampaignDateRangeKpiResponse & {
        ApplicationId: string;
        CampaignId: string;
        EndTime: __timestampIso8601;
        KpiName: string;
        KpiResult: BaseKpiResult & {
            Rows: (ResultRow & {
                GroupedBys: (ResultRowValue & {
                    Key: string;
                    Type: string;
                    Value: string;
                })[];
                Values: (ResultRowValue & {
                    Key: string;
                    Type: string;
                    Value: string;
                })[];
            })[];
        };
        StartTime: __timestampIso8601;
    };
}
export interface GetCampaignsRequest {
    ApplicationId: string;
    PageSize?: string;
    Token?: string;
}
export type ListOfCampaignResponse = CampaignResponse[];
export interface CampaignsResponse {
    Item?: CampaignResponse[];
    NextToken?: string;
}
export interface GetCampaignsResponse {
    CampaignsResponse: CampaignsResponse & {
        Item: (CampaignResponse & {
            ApplicationId: string;
            Arn: string;
            CreationDate: string;
            Id: string;
            LastModifiedDate: string;
            SegmentId: string;
            SegmentVersion: number;
            AdditionalTreatments: (TreatmentResource & {
                Id: string;
                SizePercent: number;
                CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                    DeliveryUri: string;
                };
                MessageConfiguration: MessageConfiguration & {
                    InAppMessage: CampaignInAppMessage & {
                        Content: (InAppMessageContent & {
                            BodyConfig: InAppMessageBodyConfig & {
                                Alignment: Alignment;
                                Body: string;
                                TextColor: string;
                            };
                            HeaderConfig: InAppMessageHeaderConfig & {
                                Alignment: Alignment;
                                Header: string;
                                TextColor: string;
                            };
                            PrimaryBtn: InAppMessageButton & {
                                Android: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                DefaultConfig: DefaultButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                    Text: string;
                                };
                                IOS: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                Web: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                            };
                            SecondaryBtn: InAppMessageButton & {
                                Android: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                DefaultConfig: DefaultButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                    Text: string;
                                };
                                IOS: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                Web: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                            };
                        })[];
                    };
                };
                Schedule: Schedule & {
                    StartTime: string;
                    EventFilter: CampaignEventFilter & {
                        Dimensions: EventDimensions & {
                            Attributes: {
                                [key: string]: (AttributeDimension & {
                                    Values: ListOf__string;
                                }) | undefined;
                            };
                            EventType: SetDimension & {
                                Values: ListOf__string;
                            };
                            Metrics: {
                                [key: string]: (MetricDimension & {
                                    ComparisonOperator: string;
                                    Value: number;
                                }) | undefined;
                            };
                        };
                        FilterType: FilterType;
                    };
                };
            })[];
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
    };
}
export interface GetCampaignVersionRequest {
    ApplicationId: string;
    CampaignId: string;
    Version: string;
}
export interface GetCampaignVersionResponse {
    CampaignResponse: CampaignResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        SegmentId: string;
        SegmentVersion: number;
        AdditionalTreatments: (TreatmentResource & {
            Id: string;
            SizePercent: number;
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
        CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
            DeliveryUri: string;
        };
        MessageConfiguration: MessageConfiguration & {
            InAppMessage: CampaignInAppMessage & {
                Content: (InAppMessageContent & {
                    BodyConfig: InAppMessageBodyConfig & {
                        Alignment: Alignment;
                        Body: string;
                        TextColor: string;
                    };
                    HeaderConfig: InAppMessageHeaderConfig & {
                        Alignment: Alignment;
                        Header: string;
                        TextColor: string;
                    };
                    PrimaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                    SecondaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                })[];
            };
        };
        Schedule: Schedule & {
            StartTime: string;
            EventFilter: CampaignEventFilter & {
                Dimensions: EventDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    EventType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                };
                FilterType: FilterType;
            };
        };
    };
}
export interface GetCampaignVersionsRequest {
    ApplicationId: string;
    CampaignId: string;
    PageSize?: string;
    Token?: string;
}
export interface GetCampaignVersionsResponse {
    CampaignsResponse: CampaignsResponse & {
        Item: (CampaignResponse & {
            ApplicationId: string;
            Arn: string;
            CreationDate: string;
            Id: string;
            LastModifiedDate: string;
            SegmentId: string;
            SegmentVersion: number;
            AdditionalTreatments: (TreatmentResource & {
                Id: string;
                SizePercent: number;
                CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                    DeliveryUri: string;
                };
                MessageConfiguration: MessageConfiguration & {
                    InAppMessage: CampaignInAppMessage & {
                        Content: (InAppMessageContent & {
                            BodyConfig: InAppMessageBodyConfig & {
                                Alignment: Alignment;
                                Body: string;
                                TextColor: string;
                            };
                            HeaderConfig: InAppMessageHeaderConfig & {
                                Alignment: Alignment;
                                Header: string;
                                TextColor: string;
                            };
                            PrimaryBtn: InAppMessageButton & {
                                Android: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                DefaultConfig: DefaultButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                    Text: string;
                                };
                                IOS: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                Web: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                            };
                            SecondaryBtn: InAppMessageButton & {
                                Android: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                DefaultConfig: DefaultButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                    Text: string;
                                };
                                IOS: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                Web: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                            };
                        })[];
                    };
                };
                Schedule: Schedule & {
                    StartTime: string;
                    EventFilter: CampaignEventFilter & {
                        Dimensions: EventDimensions & {
                            Attributes: {
                                [key: string]: (AttributeDimension & {
                                    Values: ListOf__string;
                                }) | undefined;
                            };
                            EventType: SetDimension & {
                                Values: ListOf__string;
                            };
                            Metrics: {
                                [key: string]: (MetricDimension & {
                                    ComparisonOperator: string;
                                    Value: number;
                                }) | undefined;
                            };
                        };
                        FilterType: FilterType;
                    };
                };
            })[];
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
    };
}
export interface GetChannelsRequest {
    ApplicationId: string;
}
export interface ChannelResponse {
    ApplicationId?: string;
    CreationDate?: string;
    Enabled?: boolean;
    HasCredential?: boolean;
    Id?: string;
    IsArchived?: boolean;
    LastModifiedBy?: string;
    LastModifiedDate?: string;
    Version?: number;
}
export type MapOfChannelResponse = {
    [key: string]: ChannelResponse | undefined;
};
export interface ChannelsResponse {
    Channels?: {
        [key: string]: ChannelResponse | undefined;
    };
}
export interface GetChannelsResponse {
    ChannelsResponse: ChannelsResponse & {
        Channels: MapOfChannelResponse;
    };
}
export interface GetEmailChannelRequest {
    ApplicationId: string;
}
export interface GetEmailChannelResponse {
    EmailChannelResponse: EmailChannelResponse & {
        Platform: string;
    };
}
export interface GetEmailTemplateRequest {
    TemplateName: string;
    Version?: string;
}
export type TemplateType = "EMAIL" | "SMS" | "VOICE" | "PUSH" | "INAPP" | (string & {});
export interface EmailTemplateResponse {
    Arn?: string;
    CreationDate?: string;
    DefaultSubstitutions?: string;
    HtmlPart?: string;
    LastModifiedDate?: string;
    RecommenderId?: string;
    Subject?: string;
    Headers?: MessageHeader[];
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateDescription?: string;
    TemplateName?: string;
    TemplateType?: TemplateType;
    TextPart?: string;
    Version?: string;
}
export interface GetEmailTemplateResponse {
    EmailTemplateResponse: EmailTemplateResponse & {
        CreationDate: string;
        LastModifiedDate: string;
        TemplateName: string;
        TemplateType: TemplateType;
    };
}
export interface GetEndpointRequest {
    ApplicationId: string;
    EndpointId: string;
}
export interface GetEndpointResponse {
    EndpointResponse: EndpointResponse;
}
export interface GetEventStreamRequest {
    ApplicationId: string;
}
export interface GetEventStreamResponse {
    EventStream: EventStream & {
        ApplicationId: string;
        DestinationStreamArn: string;
        RoleArn: string;
    };
}
export interface GetExportJobRequest {
    ApplicationId: string;
    JobId: string;
}
export interface GetExportJobResponse {
    ExportJobResponse: ExportJobResponse & {
        ApplicationId: string;
        CreationDate: string;
        Definition: ExportJobResource & {
            RoleArn: string;
            S3UrlPrefix: string;
        };
        Id: string;
        JobStatus: JobStatus;
        Type: string;
    };
}
export interface GetExportJobsRequest {
    ApplicationId: string;
    PageSize?: string;
    Token?: string;
}
export type ListOfExportJobResponse = ExportJobResponse[];
export interface ExportJobsResponse {
    Item?: ExportJobResponse[];
    NextToken?: string;
}
export interface GetExportJobsResponse {
    ExportJobsResponse: ExportJobsResponse & {
        Item: (ExportJobResponse & {
            ApplicationId: string;
            CreationDate: string;
            Definition: ExportJobResource & {
                RoleArn: string;
                S3UrlPrefix: string;
            };
            Id: string;
            JobStatus: JobStatus;
            Type: string;
        })[];
    };
}
export interface GetGcmChannelRequest {
    ApplicationId: string;
}
export interface GetGcmChannelResponse {
    GCMChannelResponse: GCMChannelResponse & {
        Platform: string;
    };
}
export interface GetImportJobRequest {
    ApplicationId: string;
    JobId: string;
}
export interface GetImportJobResponse {
    ImportJobResponse: ImportJobResponse & {
        ApplicationId: string;
        CreationDate: string;
        Definition: ImportJobResource & {
            Format: Format;
            RoleArn: string;
            S3Url: string;
        };
        Id: string;
        JobStatus: JobStatus;
        Type: string;
    };
}
export interface GetImportJobsRequest {
    ApplicationId: string;
    PageSize?: string;
    Token?: string;
}
export type ListOfImportJobResponse = ImportJobResponse[];
export interface ImportJobsResponse {
    Item?: ImportJobResponse[];
    NextToken?: string;
}
export interface GetImportJobsResponse {
    ImportJobsResponse: ImportJobsResponse & {
        Item: (ImportJobResponse & {
            ApplicationId: string;
            CreationDate: string;
            Definition: ImportJobResource & {
                Format: Format;
                RoleArn: string;
                S3Url: string;
            };
            Id: string;
            JobStatus: JobStatus;
            Type: string;
        })[];
    };
}
export interface GetInAppMessagesRequest {
    ApplicationId: string;
    EndpointId: string;
}
export interface InAppMessage {
    Content?: InAppMessageContent[];
    CustomConfig?: {
        [key: string]: string | undefined;
    };
    Layout?: Layout;
}
export interface InAppCampaignSchedule {
    EndDate?: string;
    EventFilter?: CampaignEventFilter;
    QuietTime?: QuietTime;
}
export interface InAppMessageCampaign {
    CampaignId?: string;
    DailyCap?: number;
    InAppMessage?: InAppMessage;
    Priority?: number;
    Schedule?: InAppCampaignSchedule;
    SessionCap?: number;
    TotalCap?: number;
    TreatmentId?: string;
}
export type ListOfInAppMessageCampaign = InAppMessageCampaign[];
export interface InAppMessagesResponse {
    InAppMessageCampaigns?: InAppMessageCampaign[];
}
export interface GetInAppMessagesResponse {
    InAppMessagesResponse: InAppMessagesResponse & {
        InAppMessageCampaigns: (InAppMessageCampaign & {
            InAppMessage: InAppMessage & {
                Content: (InAppMessageContent & {
                    BodyConfig: InAppMessageBodyConfig & {
                        Alignment: Alignment;
                        Body: string;
                        TextColor: string;
                    };
                    HeaderConfig: InAppMessageHeaderConfig & {
                        Alignment: Alignment;
                        Header: string;
                        TextColor: string;
                    };
                    PrimaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                    SecondaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                })[];
            };
            Schedule: InAppCampaignSchedule & {
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
    };
}
export interface GetInAppTemplateRequest {
    TemplateName: string;
    Version?: string;
}
export interface InAppTemplateResponse {
    Arn?: string;
    Content?: InAppMessageContent[];
    CreationDate?: string;
    CustomConfig?: {
        [key: string]: string | undefined;
    };
    LastModifiedDate?: string;
    Layout?: Layout;
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateDescription?: string;
    TemplateName?: string;
    TemplateType?: TemplateType;
    Version?: string;
}
export interface GetInAppTemplateResponse {
    InAppTemplateResponse: InAppTemplateResponse & {
        CreationDate: string;
        LastModifiedDate: string;
        TemplateName: string;
        TemplateType: TemplateType;
        Content: (InAppMessageContent & {
            BodyConfig: InAppMessageBodyConfig & {
                Alignment: Alignment;
                Body: string;
                TextColor: string;
            };
            HeaderConfig: InAppMessageHeaderConfig & {
                Alignment: Alignment;
                Header: string;
                TextColor: string;
            };
            PrimaryBtn: InAppMessageButton & {
                Android: OverrideButtonConfiguration & {
                    ButtonAction: ButtonAction;
                };
                DefaultConfig: DefaultButtonConfiguration & {
                    ButtonAction: ButtonAction;
                    Text: string;
                };
                IOS: OverrideButtonConfiguration & {
                    ButtonAction: ButtonAction;
                };
                Web: OverrideButtonConfiguration & {
                    ButtonAction: ButtonAction;
                };
            };
            SecondaryBtn: InAppMessageButton & {
                Android: OverrideButtonConfiguration & {
                    ButtonAction: ButtonAction;
                };
                DefaultConfig: DefaultButtonConfiguration & {
                    ButtonAction: ButtonAction;
                    Text: string;
                };
                IOS: OverrideButtonConfiguration & {
                    ButtonAction: ButtonAction;
                };
                Web: OverrideButtonConfiguration & {
                    ButtonAction: ButtonAction;
                };
            };
        })[];
    };
}
export interface GetJourneyRequest {
    ApplicationId: string;
    JourneyId: string;
}
export interface GetJourneyResponse {
    JourneyResponse: JourneyResponse & {
        ApplicationId: string;
        Id: string;
        Name: string;
        Activities: {
            [key: string]: (Activity & {
                ConditionalSplit: ConditionalSplitActivity & {
                    Condition: Condition & {
                        Conditions: (SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        })[];
                    };
                };
                Holdout: HoldoutActivity & {
                    Percentage: number;
                };
                MultiCondition: MultiConditionalSplitActivity & {
                    Branches: (MultiConditionalBranch & {
                        Condition: SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        };
                    })[];
                };
            }) | undefined;
        };
        StartCondition: StartCondition & {
            EventStartCondition: EventStartCondition & {
                EventFilter: EventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
            SegmentStartCondition: SegmentCondition & {
                SegmentId: string;
            };
        };
    };
}
export interface GetJourneyDateRangeKpiRequest {
    ApplicationId: string;
    EndTime?: Date;
    JourneyId: string;
    KpiName: string;
    NextToken?: string;
    PageSize?: string;
    StartTime?: Date;
}
export interface JourneyDateRangeKpiResponse {
    ApplicationId?: string;
    EndTime?: Date;
    JourneyId?: string;
    KpiName?: string;
    KpiResult?: BaseKpiResult;
    NextToken?: string;
    StartTime?: Date;
}
export interface GetJourneyDateRangeKpiResponse {
    JourneyDateRangeKpiResponse: JourneyDateRangeKpiResponse & {
        ApplicationId: string;
        EndTime: __timestampIso8601;
        JourneyId: string;
        KpiName: string;
        KpiResult: BaseKpiResult & {
            Rows: (ResultRow & {
                GroupedBys: (ResultRowValue & {
                    Key: string;
                    Type: string;
                    Value: string;
                })[];
                Values: (ResultRowValue & {
                    Key: string;
                    Type: string;
                    Value: string;
                })[];
            })[];
        };
        StartTime: __timestampIso8601;
    };
}
export interface GetJourneyExecutionActivityMetricsRequest {
    ApplicationId: string;
    JourneyActivityId: string;
    JourneyId: string;
    NextToken?: string;
    PageSize?: string;
}
export interface JourneyExecutionActivityMetricsResponse {
    ActivityType?: string;
    ApplicationId?: string;
    JourneyActivityId?: string;
    JourneyId?: string;
    LastEvaluatedTime?: string;
    Metrics?: {
        [key: string]: string | undefined;
    };
}
export interface GetJourneyExecutionActivityMetricsResponse {
    JourneyExecutionActivityMetricsResponse: JourneyExecutionActivityMetricsResponse & {
        ActivityType: string;
        ApplicationId: string;
        JourneyActivityId: string;
        JourneyId: string;
        LastEvaluatedTime: string;
        Metrics: MapOf__string;
    };
}
export interface GetJourneyExecutionMetricsRequest {
    ApplicationId: string;
    JourneyId: string;
    NextToken?: string;
    PageSize?: string;
}
export interface JourneyExecutionMetricsResponse {
    ApplicationId?: string;
    JourneyId?: string;
    LastEvaluatedTime?: string;
    Metrics?: {
        [key: string]: string | undefined;
    };
}
export interface GetJourneyExecutionMetricsResponse {
    JourneyExecutionMetricsResponse: JourneyExecutionMetricsResponse & {
        ApplicationId: string;
        JourneyId: string;
        LastEvaluatedTime: string;
        Metrics: MapOf__string;
    };
}
export interface GetJourneyRunExecutionActivityMetricsRequest {
    ApplicationId: string;
    JourneyActivityId: string;
    JourneyId: string;
    NextToken?: string;
    PageSize?: string;
    RunId: string;
}
export interface JourneyRunExecutionActivityMetricsResponse {
    ActivityType?: string;
    ApplicationId?: string;
    JourneyActivityId?: string;
    JourneyId?: string;
    LastEvaluatedTime?: string;
    Metrics?: {
        [key: string]: string | undefined;
    };
    RunId?: string;
}
export interface GetJourneyRunExecutionActivityMetricsResponse {
    JourneyRunExecutionActivityMetricsResponse: JourneyRunExecutionActivityMetricsResponse & {
        ActivityType: string;
        ApplicationId: string;
        JourneyActivityId: string;
        JourneyId: string;
        LastEvaluatedTime: string;
        Metrics: MapOf__string;
        RunId: string;
    };
}
export interface GetJourneyRunExecutionMetricsRequest {
    ApplicationId: string;
    JourneyId: string;
    NextToken?: string;
    PageSize?: string;
    RunId: string;
}
export interface JourneyRunExecutionMetricsResponse {
    ApplicationId?: string;
    JourneyId?: string;
    LastEvaluatedTime?: string;
    Metrics?: {
        [key: string]: string | undefined;
    };
    RunId?: string;
}
export interface GetJourneyRunExecutionMetricsResponse {
    JourneyRunExecutionMetricsResponse: JourneyRunExecutionMetricsResponse & {
        ApplicationId: string;
        JourneyId: string;
        LastEvaluatedTime: string;
        Metrics: MapOf__string;
        RunId: string;
    };
}
export interface GetJourneyRunsRequest {
    ApplicationId: string;
    JourneyId: string;
    PageSize?: string;
    Token?: string;
}
export type JourneyRunStatus = "SCHEDULED" | "RUNNING" | "COMPLETED" | "CANCELLED" | (string & {});
export interface JourneyRunResponse {
    CreationTime?: string;
    LastUpdateTime?: string;
    RunId?: string;
    Status?: JourneyRunStatus;
}
export type ListOfJourneyRunResponse = JourneyRunResponse[];
export interface JourneyRunsResponse {
    Item?: JourneyRunResponse[];
    NextToken?: string;
}
export interface GetJourneyRunsResponse {
    JourneyRunsResponse: JourneyRunsResponse & {
        Item: (JourneyRunResponse & {
            CreationTime: string;
            LastUpdateTime: string;
            RunId: string;
            Status: JourneyRunStatus;
        })[];
    };
}
export interface GetPushTemplateRequest {
    TemplateName: string;
    Version?: string;
}
export interface PushNotificationTemplateResponse {
    ADM?: AndroidPushNotificationTemplate;
    APNS?: APNSPushNotificationTemplate;
    Arn?: string;
    Baidu?: AndroidPushNotificationTemplate;
    CreationDate?: string;
    Default?: DefaultPushNotificationTemplate;
    DefaultSubstitutions?: string;
    GCM?: AndroidPushNotificationTemplate;
    LastModifiedDate?: string;
    RecommenderId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateDescription?: string;
    TemplateName?: string;
    TemplateType?: TemplateType;
    Version?: string;
}
export interface GetPushTemplateResponse {
    PushNotificationTemplateResponse: PushNotificationTemplateResponse & {
        CreationDate: string;
        LastModifiedDate: string;
        TemplateName: string;
        TemplateType: TemplateType;
    };
}
export interface GetRecommenderConfigurationRequest {
    RecommenderId: string;
}
export interface GetRecommenderConfigurationResponse {
    RecommenderConfigurationResponse: RecommenderConfigurationResponse & {
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        RecommendationProviderRoleArn: string;
        RecommendationProviderUri: string;
    };
}
export interface GetRecommenderConfigurationsRequest {
    PageSize?: string;
    Token?: string;
}
export type ListOfRecommenderConfigurationResponse = RecommenderConfigurationResponse[];
export interface ListRecommenderConfigurationsResponse {
    Item?: RecommenderConfigurationResponse[];
    NextToken?: string;
}
export interface GetRecommenderConfigurationsResponse {
    ListRecommenderConfigurationsResponse: ListRecommenderConfigurationsResponse & {
        Item: (RecommenderConfigurationResponse & {
            CreationDate: string;
            Id: string;
            LastModifiedDate: string;
            RecommendationProviderRoleArn: string;
            RecommendationProviderUri: string;
        })[];
    };
}
export interface GetSegmentRequest {
    ApplicationId: string;
    SegmentId: string;
}
export interface GetSegmentResponse {
    SegmentResponse: SegmentResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        SegmentType: SegmentType;
        Dimensions: SegmentDimensions & {
            Attributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
            Behavior: SegmentBehaviors & {
                Recency: RecencyDimension & {
                    Duration: Duration;
                    RecencyType: RecencyType;
                };
            };
            Demographic: SegmentDemographics & {
                AppVersion: SetDimension & {
                    Values: ListOf__string;
                };
                Channel: SetDimension & {
                    Values: ListOf__string;
                };
                DeviceType: SetDimension & {
                    Values: ListOf__string;
                };
                Make: SetDimension & {
                    Values: ListOf__string;
                };
                Model: SetDimension & {
                    Values: ListOf__string;
                };
                Platform: SetDimension & {
                    Values: ListOf__string;
                };
            };
            Location: SegmentLocation & {
                Country: SetDimension & {
                    Values: ListOf__string;
                };
                GPSPoint: GPSPointDimension & {
                    Coordinates: GPSCoordinates & {
                        Latitude: number;
                        Longitude: number;
                    };
                };
            };
            Metrics: {
                [key: string]: (MetricDimension & {
                    ComparisonOperator: string;
                    Value: number;
                }) | undefined;
            };
            UserAttributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
        };
        ImportDefinition: SegmentImportResource & {
            ExternalId: string;
            Format: Format;
            RoleArn: string;
            S3Url: string;
            Size: number;
        };
        SegmentGroups: SegmentGroupList & {
            Groups: (SegmentGroup & {
                Dimensions: (SegmentDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    Behavior: SegmentBehaviors & {
                        Recency: RecencyDimension & {
                            Duration: Duration;
                            RecencyType: RecencyType;
                        };
                    };
                    Demographic: SegmentDemographics & {
                        AppVersion: SetDimension & {
                            Values: ListOf__string;
                        };
                        Channel: SetDimension & {
                            Values: ListOf__string;
                        };
                        DeviceType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Make: SetDimension & {
                            Values: ListOf__string;
                        };
                        Model: SetDimension & {
                            Values: ListOf__string;
                        };
                        Platform: SetDimension & {
                            Values: ListOf__string;
                        };
                    };
                    Location: SegmentLocation & {
                        Country: SetDimension & {
                            Values: ListOf__string;
                        };
                        GPSPoint: GPSPointDimension & {
                            Coordinates: GPSCoordinates & {
                                Latitude: number;
                                Longitude: number;
                            };
                        };
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                    UserAttributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                })[];
                SourceSegments: (SegmentReference & {
                    Id: string;
                })[];
            })[];
        };
    };
}
export interface GetSegmentExportJobsRequest {
    ApplicationId: string;
    PageSize?: string;
    SegmentId: string;
    Token?: string;
}
export interface GetSegmentExportJobsResponse {
    ExportJobsResponse: ExportJobsResponse & {
        Item: (ExportJobResponse & {
            ApplicationId: string;
            CreationDate: string;
            Definition: ExportJobResource & {
                RoleArn: string;
                S3UrlPrefix: string;
            };
            Id: string;
            JobStatus: JobStatus;
            Type: string;
        })[];
    };
}
export interface GetSegmentImportJobsRequest {
    ApplicationId: string;
    PageSize?: string;
    SegmentId: string;
    Token?: string;
}
export interface GetSegmentImportJobsResponse {
    ImportJobsResponse: ImportJobsResponse & {
        Item: (ImportJobResponse & {
            ApplicationId: string;
            CreationDate: string;
            Definition: ImportJobResource & {
                Format: Format;
                RoleArn: string;
                S3Url: string;
            };
            Id: string;
            JobStatus: JobStatus;
            Type: string;
        })[];
    };
}
export interface GetSegmentsRequest {
    ApplicationId: string;
    PageSize?: string;
    Token?: string;
}
export type ListOfSegmentResponse = SegmentResponse[];
export interface SegmentsResponse {
    Item?: SegmentResponse[];
    NextToken?: string;
}
export interface GetSegmentsResponse {
    SegmentsResponse: SegmentsResponse & {
        Item: (SegmentResponse & {
            ApplicationId: string;
            Arn: string;
            CreationDate: string;
            Id: string;
            SegmentType: SegmentType;
            Dimensions: SegmentDimensions & {
                Attributes: {
                    [key: string]: (AttributeDimension & {
                        Values: ListOf__string;
                    }) | undefined;
                };
                Behavior: SegmentBehaviors & {
                    Recency: RecencyDimension & {
                        Duration: Duration;
                        RecencyType: RecencyType;
                    };
                };
                Demographic: SegmentDemographics & {
                    AppVersion: SetDimension & {
                        Values: ListOf__string;
                    };
                    Channel: SetDimension & {
                        Values: ListOf__string;
                    };
                    DeviceType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Make: SetDimension & {
                        Values: ListOf__string;
                    };
                    Model: SetDimension & {
                        Values: ListOf__string;
                    };
                    Platform: SetDimension & {
                        Values: ListOf__string;
                    };
                };
                Location: SegmentLocation & {
                    Country: SetDimension & {
                        Values: ListOf__string;
                    };
                    GPSPoint: GPSPointDimension & {
                        Coordinates: GPSCoordinates & {
                            Latitude: number;
                            Longitude: number;
                        };
                    };
                };
                Metrics: {
                    [key: string]: (MetricDimension & {
                        ComparisonOperator: string;
                        Value: number;
                    }) | undefined;
                };
                UserAttributes: {
                    [key: string]: (AttributeDimension & {
                        Values: ListOf__string;
                    }) | undefined;
                };
            };
            ImportDefinition: SegmentImportResource & {
                ExternalId: string;
                Format: Format;
                RoleArn: string;
                S3Url: string;
                Size: number;
            };
            SegmentGroups: SegmentGroupList & {
                Groups: (SegmentGroup & {
                    Dimensions: (SegmentDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        Behavior: SegmentBehaviors & {
                            Recency: RecencyDimension & {
                                Duration: Duration;
                                RecencyType: RecencyType;
                            };
                        };
                        Demographic: SegmentDemographics & {
                            AppVersion: SetDimension & {
                                Values: ListOf__string;
                            };
                            Channel: SetDimension & {
                                Values: ListOf__string;
                            };
                            DeviceType: SetDimension & {
                                Values: ListOf__string;
                            };
                            Make: SetDimension & {
                                Values: ListOf__string;
                            };
                            Model: SetDimension & {
                                Values: ListOf__string;
                            };
                            Platform: SetDimension & {
                                Values: ListOf__string;
                            };
                        };
                        Location: SegmentLocation & {
                            Country: SetDimension & {
                                Values: ListOf__string;
                            };
                            GPSPoint: GPSPointDimension & {
                                Coordinates: GPSCoordinates & {
                                    Latitude: number;
                                    Longitude: number;
                                };
                            };
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                        UserAttributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                    })[];
                    SourceSegments: (SegmentReference & {
                        Id: string;
                    })[];
                })[];
            };
        })[];
    };
}
export interface GetSegmentVersionRequest {
    ApplicationId: string;
    SegmentId: string;
    Version: string;
}
export interface GetSegmentVersionResponse {
    SegmentResponse: SegmentResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        SegmentType: SegmentType;
        Dimensions: SegmentDimensions & {
            Attributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
            Behavior: SegmentBehaviors & {
                Recency: RecencyDimension & {
                    Duration: Duration;
                    RecencyType: RecencyType;
                };
            };
            Demographic: SegmentDemographics & {
                AppVersion: SetDimension & {
                    Values: ListOf__string;
                };
                Channel: SetDimension & {
                    Values: ListOf__string;
                };
                DeviceType: SetDimension & {
                    Values: ListOf__string;
                };
                Make: SetDimension & {
                    Values: ListOf__string;
                };
                Model: SetDimension & {
                    Values: ListOf__string;
                };
                Platform: SetDimension & {
                    Values: ListOf__string;
                };
            };
            Location: SegmentLocation & {
                Country: SetDimension & {
                    Values: ListOf__string;
                };
                GPSPoint: GPSPointDimension & {
                    Coordinates: GPSCoordinates & {
                        Latitude: number;
                        Longitude: number;
                    };
                };
            };
            Metrics: {
                [key: string]: (MetricDimension & {
                    ComparisonOperator: string;
                    Value: number;
                }) | undefined;
            };
            UserAttributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
        };
        ImportDefinition: SegmentImportResource & {
            ExternalId: string;
            Format: Format;
            RoleArn: string;
            S3Url: string;
            Size: number;
        };
        SegmentGroups: SegmentGroupList & {
            Groups: (SegmentGroup & {
                Dimensions: (SegmentDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    Behavior: SegmentBehaviors & {
                        Recency: RecencyDimension & {
                            Duration: Duration;
                            RecencyType: RecencyType;
                        };
                    };
                    Demographic: SegmentDemographics & {
                        AppVersion: SetDimension & {
                            Values: ListOf__string;
                        };
                        Channel: SetDimension & {
                            Values: ListOf__string;
                        };
                        DeviceType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Make: SetDimension & {
                            Values: ListOf__string;
                        };
                        Model: SetDimension & {
                            Values: ListOf__string;
                        };
                        Platform: SetDimension & {
                            Values: ListOf__string;
                        };
                    };
                    Location: SegmentLocation & {
                        Country: SetDimension & {
                            Values: ListOf__string;
                        };
                        GPSPoint: GPSPointDimension & {
                            Coordinates: GPSCoordinates & {
                                Latitude: number;
                                Longitude: number;
                            };
                        };
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                    UserAttributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                })[];
                SourceSegments: (SegmentReference & {
                    Id: string;
                })[];
            })[];
        };
    };
}
export interface GetSegmentVersionsRequest {
    ApplicationId: string;
    PageSize?: string;
    SegmentId: string;
    Token?: string;
}
export interface GetSegmentVersionsResponse {
    SegmentsResponse: SegmentsResponse & {
        Item: (SegmentResponse & {
            ApplicationId: string;
            Arn: string;
            CreationDate: string;
            Id: string;
            SegmentType: SegmentType;
            Dimensions: SegmentDimensions & {
                Attributes: {
                    [key: string]: (AttributeDimension & {
                        Values: ListOf__string;
                    }) | undefined;
                };
                Behavior: SegmentBehaviors & {
                    Recency: RecencyDimension & {
                        Duration: Duration;
                        RecencyType: RecencyType;
                    };
                };
                Demographic: SegmentDemographics & {
                    AppVersion: SetDimension & {
                        Values: ListOf__string;
                    };
                    Channel: SetDimension & {
                        Values: ListOf__string;
                    };
                    DeviceType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Make: SetDimension & {
                        Values: ListOf__string;
                    };
                    Model: SetDimension & {
                        Values: ListOf__string;
                    };
                    Platform: SetDimension & {
                        Values: ListOf__string;
                    };
                };
                Location: SegmentLocation & {
                    Country: SetDimension & {
                        Values: ListOf__string;
                    };
                    GPSPoint: GPSPointDimension & {
                        Coordinates: GPSCoordinates & {
                            Latitude: number;
                            Longitude: number;
                        };
                    };
                };
                Metrics: {
                    [key: string]: (MetricDimension & {
                        ComparisonOperator: string;
                        Value: number;
                    }) | undefined;
                };
                UserAttributes: {
                    [key: string]: (AttributeDimension & {
                        Values: ListOf__string;
                    }) | undefined;
                };
            };
            ImportDefinition: SegmentImportResource & {
                ExternalId: string;
                Format: Format;
                RoleArn: string;
                S3Url: string;
                Size: number;
            };
            SegmentGroups: SegmentGroupList & {
                Groups: (SegmentGroup & {
                    Dimensions: (SegmentDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        Behavior: SegmentBehaviors & {
                            Recency: RecencyDimension & {
                                Duration: Duration;
                                RecencyType: RecencyType;
                            };
                        };
                        Demographic: SegmentDemographics & {
                            AppVersion: SetDimension & {
                                Values: ListOf__string;
                            };
                            Channel: SetDimension & {
                                Values: ListOf__string;
                            };
                            DeviceType: SetDimension & {
                                Values: ListOf__string;
                            };
                            Make: SetDimension & {
                                Values: ListOf__string;
                            };
                            Model: SetDimension & {
                                Values: ListOf__string;
                            };
                            Platform: SetDimension & {
                                Values: ListOf__string;
                            };
                        };
                        Location: SegmentLocation & {
                            Country: SetDimension & {
                                Values: ListOf__string;
                            };
                            GPSPoint: GPSPointDimension & {
                                Coordinates: GPSCoordinates & {
                                    Latitude: number;
                                    Longitude: number;
                                };
                            };
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                        UserAttributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                    })[];
                    SourceSegments: (SegmentReference & {
                        Id: string;
                    })[];
                })[];
            };
        })[];
    };
}
export interface GetSmsChannelRequest {
    ApplicationId: string;
}
export interface GetSmsChannelResponse {
    SMSChannelResponse: SMSChannelResponse & {
        Platform: string;
    };
}
export interface GetSmsTemplateRequest {
    TemplateName: string;
    Version?: string;
}
export interface SMSTemplateResponse {
    Arn?: string;
    Body?: string;
    CreationDate?: string;
    DefaultSubstitutions?: string;
    LastModifiedDate?: string;
    RecommenderId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateDescription?: string;
    TemplateName?: string;
    TemplateType?: TemplateType;
    Version?: string;
}
export interface GetSmsTemplateResponse {
    SMSTemplateResponse: SMSTemplateResponse & {
        CreationDate: string;
        LastModifiedDate: string;
        TemplateName: string;
        TemplateType: TemplateType;
    };
}
export interface GetUserEndpointsRequest {
    ApplicationId: string;
    UserId: string;
}
export interface GetUserEndpointsResponse {
    EndpointsResponse: EndpointsResponse & {
        Item: ListOfEndpointResponse;
    };
}
export interface GetVoiceChannelRequest {
    ApplicationId: string;
}
export interface GetVoiceChannelResponse {
    VoiceChannelResponse: VoiceChannelResponse & {
        Platform: string;
    };
}
export interface GetVoiceTemplateRequest {
    TemplateName: string;
    Version?: string;
}
export interface VoiceTemplateResponse {
    Arn?: string;
    Body?: string;
    CreationDate?: string;
    DefaultSubstitutions?: string;
    LanguageCode?: string;
    LastModifiedDate?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateDescription?: string;
    TemplateName?: string;
    TemplateType?: TemplateType;
    Version?: string;
    VoiceId?: string;
}
export interface GetVoiceTemplateResponse {
    VoiceTemplateResponse: VoiceTemplateResponse & {
        CreationDate: string;
        LastModifiedDate: string;
        TemplateName: string;
        TemplateType: TemplateType;
    };
}
export interface ListJourneysRequest {
    ApplicationId: string;
    PageSize?: string;
    Token?: string;
}
export type ListOfJourneyResponse = JourneyResponse[];
export interface JourneysResponse {
    Item?: JourneyResponse[];
    NextToken?: string;
}
export interface ListJourneysResponse {
    JourneysResponse: JourneysResponse & {
        Item: (JourneyResponse & {
            ApplicationId: string;
            Id: string;
            Name: string;
            Activities: {
                [key: string]: (Activity & {
                    ConditionalSplit: ConditionalSplitActivity & {
                        Condition: Condition & {
                            Conditions: (SimpleCondition & {
                                EventCondition: EventCondition & {
                                    Dimensions: EventDimensions & {
                                        Attributes: {
                                            [key: string]: (AttributeDimension & {
                                                Values: ListOf__string;
                                            }) | undefined;
                                        };
                                        EventType: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Metrics: {
                                            [key: string]: (MetricDimension & {
                                                ComparisonOperator: string;
                                                Value: number;
                                            }) | undefined;
                                        };
                                    };
                                };
                                SegmentCondition: SegmentCondition & {
                                    SegmentId: string;
                                };
                                SegmentDimensions: SegmentDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    Behavior: SegmentBehaviors & {
                                        Recency: RecencyDimension & {
                                            Duration: Duration;
                                            RecencyType: RecencyType;
                                        };
                                    };
                                    Demographic: SegmentDemographics & {
                                        AppVersion: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Channel: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        DeviceType: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Make: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Model: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Platform: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                    };
                                    Location: SegmentLocation & {
                                        Country: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        GPSPoint: GPSPointDimension & {
                                            Coordinates: GPSCoordinates & {
                                                Latitude: number;
                                                Longitude: number;
                                            };
                                        };
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                    UserAttributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                };
                            })[];
                        };
                    };
                    Holdout: HoldoutActivity & {
                        Percentage: number;
                    };
                    MultiCondition: MultiConditionalSplitActivity & {
                        Branches: (MultiConditionalBranch & {
                            Condition: SimpleCondition & {
                                EventCondition: EventCondition & {
                                    Dimensions: EventDimensions & {
                                        Attributes: {
                                            [key: string]: (AttributeDimension & {
                                                Values: ListOf__string;
                                            }) | undefined;
                                        };
                                        EventType: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Metrics: {
                                            [key: string]: (MetricDimension & {
                                                ComparisonOperator: string;
                                                Value: number;
                                            }) | undefined;
                                        };
                                    };
                                };
                                SegmentCondition: SegmentCondition & {
                                    SegmentId: string;
                                };
                                SegmentDimensions: SegmentDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    Behavior: SegmentBehaviors & {
                                        Recency: RecencyDimension & {
                                            Duration: Duration;
                                            RecencyType: RecencyType;
                                        };
                                    };
                                    Demographic: SegmentDemographics & {
                                        AppVersion: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Channel: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        DeviceType: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Make: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Model: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Platform: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                    };
                                    Location: SegmentLocation & {
                                        Country: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        GPSPoint: GPSPointDimension & {
                                            Coordinates: GPSCoordinates & {
                                                Latitude: number;
                                                Longitude: number;
                                            };
                                        };
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                    UserAttributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                };
                            };
                        })[];
                    };
                }) | undefined;
            };
            StartCondition: StartCondition & {
                EventStartCondition: EventStartCondition & {
                    EventFilter: EventFilter & {
                        Dimensions: EventDimensions & {
                            Attributes: {
                                [key: string]: (AttributeDimension & {
                                    Values: ListOf__string;
                                }) | undefined;
                            };
                            EventType: SetDimension & {
                                Values: ListOf__string;
                            };
                            Metrics: {
                                [key: string]: (MetricDimension & {
                                    ComparisonOperator: string;
                                    Value: number;
                                }) | undefined;
                            };
                        };
                        FilterType: FilterType;
                    };
                };
                SegmentStartCondition: SegmentCondition & {
                    SegmentId: string;
                };
            };
        })[];
    };
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface TagsModel {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListTagsForResourceResponse {
    TagsModel: TagsModel & {
        tags: MapOf__string;
    };
}
export interface ListTemplatesRequest {
    NextToken?: string;
    PageSize?: string;
    Prefix?: string;
    TemplateType?: string;
}
export interface TemplateResponse {
    Arn?: string;
    CreationDate?: string;
    DefaultSubstitutions?: string;
    LastModifiedDate?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    TemplateDescription?: string;
    TemplateName?: string;
    TemplateType?: TemplateType;
    Version?: string;
}
export type ListOfTemplateResponse = TemplateResponse[];
export interface TemplatesResponse {
    Item?: TemplateResponse[];
    NextToken?: string;
}
export interface ListTemplatesResponse {
    TemplatesResponse: TemplatesResponse & {
        Item: (TemplateResponse & {
            CreationDate: string;
            LastModifiedDate: string;
            TemplateName: string;
            TemplateType: TemplateType;
        })[];
    };
}
export interface ListTemplateVersionsRequest {
    NextToken?: string;
    PageSize?: string;
    TemplateName: string;
    TemplateType: string;
}
export interface TemplateVersionResponse {
    CreationDate?: string;
    DefaultSubstitutions?: string;
    LastModifiedDate?: string;
    TemplateDescription?: string;
    TemplateName?: string;
    TemplateType?: string;
    Version?: string;
}
export type ListOfTemplateVersionResponse = TemplateVersionResponse[];
export interface TemplateVersionsResponse {
    Item?: TemplateVersionResponse[];
    Message?: string;
    NextToken?: string;
    RequestID?: string;
}
export interface ListTemplateVersionsResponse {
    TemplateVersionsResponse: TemplateVersionsResponse & {
        Item: (TemplateVersionResponse & {
            CreationDate: string;
            LastModifiedDate: string;
            TemplateName: string;
            TemplateType: string;
        })[];
    };
}
export interface NumberValidateRequest {
    IsoCountryCode?: string;
    PhoneNumber?: string;
}
export interface PhoneNumberValidateRequest {
    NumberValidateRequest?: NumberValidateRequest;
}
export interface NumberValidateResponse {
    Carrier?: string;
    City?: string;
    CleansedPhoneNumberE164?: string;
    CleansedPhoneNumberNational?: string;
    Country?: string;
    CountryCodeIso2?: string;
    CountryCodeNumeric?: string;
    County?: string;
    OriginalCountryCodeIso2?: string;
    OriginalPhoneNumber?: string;
    PhoneType?: string;
    PhoneTypeCode?: number;
    Timezone?: string;
    ZipCode?: string;
}
export interface PhoneNumberValidateResponse {
    NumberValidateResponse: NumberValidateResponse;
}
export interface PublicEndpoint {
    Address?: string;
    Attributes?: {
        [key: string]: string[] | undefined;
    };
    ChannelType?: ChannelType;
    Demographic?: EndpointDemographic;
    EffectiveDate?: string;
    EndpointStatus?: string;
    Location?: EndpointLocation;
    Metrics?: {
        [key: string]: number | undefined;
    };
    OptOut?: string;
    RequestId?: string;
    User?: EndpointUser;
}
export interface Session {
    Duration?: number;
    Id?: string;
    StartTimestamp?: string;
    StopTimestamp?: string;
}
export interface Event {
    AppPackageName?: string;
    AppTitle?: string;
    AppVersionCode?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    ClientSdkVersion?: string;
    EventType?: string;
    Metrics?: {
        [key: string]: number | undefined;
    };
    SdkName?: string;
    Session?: Session;
    Timestamp?: string;
}
export type MapOfEvent = {
    [key: string]: Event | undefined;
};
export interface EventsBatch {
    Endpoint?: PublicEndpoint;
    Events?: {
        [key: string]: Event | undefined;
    };
}
export type MapOfEventsBatch = {
    [key: string]: EventsBatch | undefined;
};
export interface EventsRequest {
    BatchItem?: {
        [key: string]: EventsBatch | undefined;
    };
}
export interface PutEventsRequest {
    ApplicationId: string;
    EventsRequest?: EventsRequest;
}
export interface EndpointItemResponse {
    Message?: string;
    StatusCode?: number;
}
export interface EventItemResponse {
    Message?: string;
    StatusCode?: number;
}
export type MapOfEventItemResponse = {
    [key: string]: EventItemResponse | undefined;
};
export interface ItemResponse {
    EndpointItemResponse?: EndpointItemResponse;
    EventsItemResponse?: {
        [key: string]: EventItemResponse | undefined;
    };
}
export type MapOfItemResponse = {
    [key: string]: ItemResponse | undefined;
};
export interface EventsResponse {
    Results?: {
        [key: string]: ItemResponse | undefined;
    };
}
export interface PutEventsResponse {
    EventsResponse: EventsResponse;
}
export interface WriteEventStream {
    DestinationStreamArn?: string;
    RoleArn?: string;
}
export interface PutEventStreamRequest {
    ApplicationId: string;
    WriteEventStream?: WriteEventStream;
}
export interface PutEventStreamResponse {
    EventStream: EventStream & {
        ApplicationId: string;
        DestinationStreamArn: string;
        RoleArn: string;
    };
}
export interface UpdateAttributesRequest {
    Blacklist?: string[];
}
export interface RemoveAttributesRequest {
    ApplicationId: string;
    AttributeType: string;
    UpdateAttributesRequest?: UpdateAttributesRequest;
}
export interface AttributesResource {
    ApplicationId?: string;
    AttributeType?: string;
    Attributes?: string[];
}
export interface RemoveAttributesResponse {
    AttributesResource: AttributesResource & {
        ApplicationId: string;
        AttributeType: string;
    };
}
export interface AddressConfiguration {
    BodyOverride?: string;
    ChannelType?: ChannelType;
    Context?: {
        [key: string]: string | undefined;
    };
    RawContent?: string;
    Substitutions?: {
        [key: string]: string[] | undefined;
    };
    TitleOverride?: string;
}
export type MapOfAddressConfiguration = {
    [key: string]: AddressConfiguration | undefined;
};
export interface EndpointSendConfiguration {
    BodyOverride?: string;
    Context?: {
        [key: string]: string | undefined;
    };
    RawContent?: string;
    Substitutions?: {
        [key: string]: string[] | undefined;
    };
    TitleOverride?: string;
}
export type MapOfEndpointSendConfiguration = {
    [key: string]: EndpointSendConfiguration | undefined;
};
export interface ADMMessage {
    Action?: Action;
    Body?: string;
    ConsolidationKey?: string;
    Data?: {
        [key: string]: string | undefined;
    };
    ExpiresAfter?: string;
    IconReference?: string;
    ImageIconUrl?: string;
    ImageUrl?: string;
    MD5?: string;
    RawContent?: string;
    SilentPush?: boolean;
    SmallImageIconUrl?: string;
    Sound?: string;
    Substitutions?: {
        [key: string]: string[] | undefined;
    };
    Title?: string;
    Url?: string;
}
export interface APNSMessage {
    APNSPushType?: string;
    Action?: Action;
    Badge?: number;
    Body?: string;
    Category?: string;
    CollapseId?: string;
    Data?: {
        [key: string]: string | undefined;
    };
    MediaUrl?: string;
    PreferredAuthenticationMethod?: string;
    Priority?: string;
    RawContent?: string;
    SilentPush?: boolean;
    Sound?: string;
    Substitutions?: {
        [key: string]: string[] | undefined;
    };
    ThreadId?: string;
    TimeToLive?: number;
    Title?: string;
    Url?: string;
}
export interface BaiduMessage {
    Action?: Action;
    Body?: string;
    Data?: {
        [key: string]: string | undefined;
    };
    IconReference?: string;
    ImageIconUrl?: string;
    ImageUrl?: string;
    RawContent?: string;
    SilentPush?: boolean;
    SmallImageIconUrl?: string;
    Sound?: string;
    Substitutions?: {
        [key: string]: string[] | undefined;
    };
    TimeToLive?: number;
    Title?: string;
    Url?: string;
}
export interface DefaultMessage {
    Body?: string;
    Substitutions?: {
        [key: string]: string[] | undefined;
    };
}
export interface DefaultPushNotificationMessage {
    Action?: Action;
    Body?: string;
    Data?: {
        [key: string]: string | undefined;
    };
    SilentPush?: boolean;
    Substitutions?: {
        [key: string]: string[] | undefined;
    };
    Title?: string;
    Url?: string;
}
export type __blob = Uint8Array;
export interface RawEmail {
    Data?: Uint8Array;
}
export interface SimpleEmailPart {
    Charset?: string;
    Data?: string;
}
export interface SimpleEmail {
    HtmlPart?: SimpleEmailPart;
    Subject?: SimpleEmailPart;
    TextPart?: SimpleEmailPart;
    Headers?: MessageHeader[];
}
export interface EmailMessage {
    Body?: string;
    FeedbackForwardingAddress?: string;
    FromAddress?: string;
    RawEmail?: RawEmail;
    ReplyToAddresses?: string[];
    SimpleEmail?: SimpleEmail;
    Substitutions?: {
        [key: string]: string[] | undefined;
    };
}
export interface GCMMessage {
    Action?: Action;
    Body?: string;
    CollapseKey?: string;
    Data?: {
        [key: string]: string | undefined;
    };
    IconReference?: string;
    ImageIconUrl?: string;
    ImageUrl?: string;
    PreferredAuthenticationMethod?: string;
    Priority?: string;
    RawContent?: string;
    RestrictedPackageName?: string;
    SilentPush?: boolean;
    SmallImageIconUrl?: string;
    Sound?: string;
    Substitutions?: {
        [key: string]: string[] | undefined;
    };
    TimeToLive?: number;
    Title?: string;
    Url?: string;
}
export interface SMSMessage {
    Body?: string;
    Keyword?: string;
    MediaUrl?: string;
    MessageType?: MessageType;
    OriginationNumber?: string;
    SenderId?: string;
    Substitutions?: {
        [key: string]: string[] | undefined;
    };
    EntityId?: string;
    TemplateId?: string;
}
export interface VoiceMessage {
    Body?: string;
    LanguageCode?: string;
    OriginationNumber?: string;
    Substitutions?: {
        [key: string]: string[] | undefined;
    };
    VoiceId?: string;
}
export interface DirectMessageConfiguration {
    ADMMessage?: ADMMessage;
    APNSMessage?: APNSMessage;
    BaiduMessage?: BaiduMessage;
    DefaultMessage?: DefaultMessage;
    DefaultPushNotificationMessage?: DefaultPushNotificationMessage;
    EmailMessage?: EmailMessage;
    GCMMessage?: GCMMessage;
    SMSMessage?: SMSMessage;
    VoiceMessage?: VoiceMessage;
}
export interface MessageRequest {
    Addresses?: {
        [key: string]: AddressConfiguration | undefined;
    };
    Context?: {
        [key: string]: string | undefined;
    };
    Endpoints?: {
        [key: string]: EndpointSendConfiguration | undefined;
    };
    MessageConfiguration?: DirectMessageConfiguration;
    TemplateConfiguration?: TemplateConfiguration;
    TraceId?: string;
}
export interface SendMessagesRequest {
    ApplicationId: string;
    MessageRequest?: MessageRequest;
}
export type DeliveryStatus = "SUCCESSFUL" | "THROTTLED" | "TEMPORARY_FAILURE" | "PERMANENT_FAILURE" | "UNKNOWN_FAILURE" | "OPT_OUT" | "DUPLICATE" | (string & {});
export interface EndpointMessageResult {
    Address?: string;
    DeliveryStatus?: DeliveryStatus;
    MessageId?: string;
    StatusCode?: number;
    StatusMessage?: string;
    UpdatedToken?: string;
}
export type MapOfEndpointMessageResult = {
    [key: string]: EndpointMessageResult | undefined;
};
export interface MessageResult {
    DeliveryStatus?: DeliveryStatus;
    MessageId?: string;
    StatusCode?: number;
    StatusMessage?: string;
    UpdatedToken?: string;
}
export type MapOfMessageResult = {
    [key: string]: MessageResult | undefined;
};
export interface MessageResponse {
    ApplicationId?: string;
    EndpointResult?: {
        [key: string]: EndpointMessageResult | undefined;
    };
    RequestId?: string;
    Result?: {
        [key: string]: MessageResult | undefined;
    };
}
export interface SendMessagesResponse {
    MessageResponse: MessageResponse & {
        ApplicationId: string;
        EndpointResult: {
            [key: string]: (EndpointMessageResult & {
                DeliveryStatus: DeliveryStatus;
                StatusCode: number;
            }) | undefined;
        };
        Result: {
            [key: string]: (MessageResult & {
                DeliveryStatus: DeliveryStatus;
                StatusCode: number;
            }) | undefined;
        };
    };
}
export interface SendOTPMessageRequestParameters {
    AllowedAttempts?: number;
    BrandName?: string;
    Channel?: string;
    CodeLength?: number;
    DestinationIdentity?: string;
    EntityId?: string;
    Language?: string;
    OriginationIdentity?: string;
    ReferenceId?: string;
    TemplateId?: string;
    ValidityPeriod?: number;
}
export interface SendOTPMessageRequest {
    ApplicationId: string;
    SendOTPMessageRequestParameters?: SendOTPMessageRequestParameters;
}
export interface SendOTPMessageResponse {
    MessageResponse: MessageResponse & {
        ApplicationId: string;
        EndpointResult: {
            [key: string]: (EndpointMessageResult & {
                DeliveryStatus: DeliveryStatus;
                StatusCode: number;
            }) | undefined;
        };
        Result: {
            [key: string]: (MessageResult & {
                DeliveryStatus: DeliveryStatus;
                StatusCode: number;
            }) | undefined;
        };
    };
}
export interface SendUsersMessageRequest {
    Context?: {
        [key: string]: string | undefined;
    };
    MessageConfiguration?: DirectMessageConfiguration;
    TemplateConfiguration?: TemplateConfiguration;
    TraceId?: string;
    Users?: {
        [key: string]: EndpointSendConfiguration | undefined;
    };
}
export interface SendUsersMessagesRequest {
    ApplicationId: string;
    SendUsersMessageRequest?: SendUsersMessageRequest;
}
export type MapOfMapOfEndpointMessageResult = {
    [key: string]: {
        [key: string]: EndpointMessageResult | undefined;
    } | undefined;
};
export interface SendUsersMessageResponse {
    ApplicationId?: string;
    RequestId?: string;
    Result?: {
        [key: string]: {
            [key: string]: EndpointMessageResult | undefined;
        } | undefined;
    };
}
export interface SendUsersMessagesResponse {
    SendUsersMessageResponse: SendUsersMessageResponse & {
        ApplicationId: string;
        Result: {
            [key: string]: {
                [key: string]: (EndpointMessageResult & {
                    DeliveryStatus: DeliveryStatus;
                    StatusCode: number;
                }) | undefined;
            } | undefined;
        };
    };
}
export interface TagResourceRequest {
    ResourceArn: string;
    TagsModel?: TagsModel;
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface UntagResourceResponse {
}
export interface ADMChannelRequest {
    ClientId?: string;
    ClientSecret?: string;
    Enabled?: boolean;
}
export interface UpdateAdmChannelRequest {
    ADMChannelRequest?: ADMChannelRequest;
    ApplicationId: string;
}
export interface UpdateAdmChannelResponse {
    ADMChannelResponse: ADMChannelResponse & {
        Platform: string;
    };
}
export interface APNSChannelRequest {
    BundleId?: string;
    Certificate?: string;
    DefaultAuthenticationMethod?: string;
    Enabled?: boolean;
    PrivateKey?: string;
    TeamId?: string;
    TokenKey?: string;
    TokenKeyId?: string;
}
export interface UpdateApnsChannelRequest {
    APNSChannelRequest?: APNSChannelRequest;
    ApplicationId: string;
}
export interface UpdateApnsChannelResponse {
    APNSChannelResponse: APNSChannelResponse & {
        Platform: string;
    };
}
export interface APNSSandboxChannelRequest {
    BundleId?: string;
    Certificate?: string;
    DefaultAuthenticationMethod?: string;
    Enabled?: boolean;
    PrivateKey?: string;
    TeamId?: string;
    TokenKey?: string;
    TokenKeyId?: string;
}
export interface UpdateApnsSandboxChannelRequest {
    APNSSandboxChannelRequest?: APNSSandboxChannelRequest;
    ApplicationId: string;
}
export interface UpdateApnsSandboxChannelResponse {
    APNSSandboxChannelResponse: APNSSandboxChannelResponse & {
        Platform: string;
    };
}
export interface APNSVoipChannelRequest {
    BundleId?: string;
    Certificate?: string;
    DefaultAuthenticationMethod?: string;
    Enabled?: boolean;
    PrivateKey?: string;
    TeamId?: string;
    TokenKey?: string;
    TokenKeyId?: string;
}
export interface UpdateApnsVoipChannelRequest {
    APNSVoipChannelRequest?: APNSVoipChannelRequest;
    ApplicationId: string;
}
export interface UpdateApnsVoipChannelResponse {
    APNSVoipChannelResponse: APNSVoipChannelResponse & {
        Platform: string;
    };
}
export interface APNSVoipSandboxChannelRequest {
    BundleId?: string;
    Certificate?: string;
    DefaultAuthenticationMethod?: string;
    Enabled?: boolean;
    PrivateKey?: string;
    TeamId?: string;
    TokenKey?: string;
    TokenKeyId?: string;
}
export interface UpdateApnsVoipSandboxChannelRequest {
    APNSVoipSandboxChannelRequest?: APNSVoipSandboxChannelRequest;
    ApplicationId: string;
}
export interface UpdateApnsVoipSandboxChannelResponse {
    APNSVoipSandboxChannelResponse: APNSVoipSandboxChannelResponse & {
        Platform: string;
    };
}
export interface WriteApplicationSettingsRequest {
    CampaignHook?: CampaignHook;
    CloudWatchMetricsEnabled?: boolean;
    EventTaggingEnabled?: boolean;
    Limits?: CampaignLimits;
    QuietTime?: QuietTime;
    JourneyLimits?: ApplicationSettingsJourneyLimits;
}
export interface UpdateApplicationSettingsRequest {
    ApplicationId: string;
    WriteApplicationSettingsRequest?: WriteApplicationSettingsRequest;
}
export interface UpdateApplicationSettingsResponse {
    ApplicationSettingsResource: ApplicationSettingsResource & {
        ApplicationId: string;
    };
}
export interface BaiduChannelRequest {
    ApiKey?: string;
    Enabled?: boolean;
    SecretKey?: string;
}
export interface UpdateBaiduChannelRequest {
    ApplicationId: string;
    BaiduChannelRequest?: BaiduChannelRequest;
}
export interface UpdateBaiduChannelResponse {
    BaiduChannelResponse: BaiduChannelResponse & {
        Credential: string;
        Platform: string;
    };
}
export interface UpdateCampaignRequest {
    ApplicationId: string;
    CampaignId: string;
    WriteCampaignRequest?: WriteCampaignRequest;
}
export interface UpdateCampaignResponse {
    CampaignResponse: CampaignResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        SegmentId: string;
        SegmentVersion: number;
        AdditionalTreatments: (TreatmentResource & {
            Id: string;
            SizePercent: number;
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
        CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
            DeliveryUri: string;
        };
        MessageConfiguration: MessageConfiguration & {
            InAppMessage: CampaignInAppMessage & {
                Content: (InAppMessageContent & {
                    BodyConfig: InAppMessageBodyConfig & {
                        Alignment: Alignment;
                        Body: string;
                        TextColor: string;
                    };
                    HeaderConfig: InAppMessageHeaderConfig & {
                        Alignment: Alignment;
                        Header: string;
                        TextColor: string;
                    };
                    PrimaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                    SecondaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                })[];
            };
        };
        Schedule: Schedule & {
            StartTime: string;
            EventFilter: CampaignEventFilter & {
                Dimensions: EventDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    EventType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                };
                FilterType: FilterType;
            };
        };
    };
}
export interface EmailChannelRequest {
    ConfigurationSet?: string;
    Enabled?: boolean;
    FromAddress?: string;
    Identity?: string;
    RoleArn?: string;
    OrchestrationSendingRoleArn?: string;
}
export interface UpdateEmailChannelRequest {
    ApplicationId: string;
    EmailChannelRequest?: EmailChannelRequest;
}
export interface UpdateEmailChannelResponse {
    EmailChannelResponse: EmailChannelResponse & {
        Platform: string;
    };
}
export interface UpdateEmailTemplateRequest {
    CreateNewVersion?: boolean;
    EmailTemplateRequest?: EmailTemplateRequest;
    TemplateName: string;
    Version?: string;
}
export interface UpdateEmailTemplateResponse {
    MessageBody: MessageBody;
}
export interface EndpointRequest {
    Address?: string;
    Attributes?: {
        [key: string]: string[] | undefined;
    };
    ChannelType?: ChannelType;
    Demographic?: EndpointDemographic;
    EffectiveDate?: string;
    EndpointStatus?: string;
    Location?: EndpointLocation;
    Metrics?: {
        [key: string]: number | undefined;
    };
    OptOut?: string;
    RequestId?: string;
    User?: EndpointUser;
}
export interface UpdateEndpointRequest {
    ApplicationId: string;
    EndpointId: string;
    EndpointRequest?: EndpointRequest;
}
export interface UpdateEndpointResponse {
    MessageBody: MessageBody;
}
export interface EndpointBatchItem {
    Address?: string;
    Attributes?: {
        [key: string]: string[] | undefined;
    };
    ChannelType?: ChannelType;
    Demographic?: EndpointDemographic;
    EffectiveDate?: string;
    EndpointStatus?: string;
    Id?: string;
    Location?: EndpointLocation;
    Metrics?: {
        [key: string]: number | undefined;
    };
    OptOut?: string;
    RequestId?: string;
    User?: EndpointUser;
}
export type ListOfEndpointBatchItem = EndpointBatchItem[];
export interface EndpointBatchRequest {
    Item?: EndpointBatchItem[];
}
export interface UpdateEndpointsBatchRequest {
    ApplicationId: string;
    EndpointBatchRequest?: EndpointBatchRequest;
}
export interface UpdateEndpointsBatchResponse {
    MessageBody: MessageBody;
}
export interface GCMChannelRequest {
    ApiKey?: string;
    DefaultAuthenticationMethod?: string;
    Enabled?: boolean;
    ServiceJson?: string;
}
export interface UpdateGcmChannelRequest {
    ApplicationId: string;
    GCMChannelRequest?: GCMChannelRequest;
}
export interface UpdateGcmChannelResponse {
    GCMChannelResponse: GCMChannelResponse & {
        Platform: string;
    };
}
export interface UpdateInAppTemplateRequest {
    CreateNewVersion?: boolean;
    InAppTemplateRequest?: InAppTemplateRequest;
    TemplateName: string;
    Version?: string;
}
export interface UpdateInAppTemplateResponse {
    MessageBody: MessageBody;
}
export interface UpdateJourneyRequest {
    ApplicationId: string;
    JourneyId: string;
    WriteJourneyRequest?: WriteJourneyRequest;
}
export interface UpdateJourneyResponse {
    JourneyResponse: JourneyResponse & {
        ApplicationId: string;
        Id: string;
        Name: string;
        Activities: {
            [key: string]: (Activity & {
                ConditionalSplit: ConditionalSplitActivity & {
                    Condition: Condition & {
                        Conditions: (SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        })[];
                    };
                };
                Holdout: HoldoutActivity & {
                    Percentage: number;
                };
                MultiCondition: MultiConditionalSplitActivity & {
                    Branches: (MultiConditionalBranch & {
                        Condition: SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        };
                    })[];
                };
            }) | undefined;
        };
        StartCondition: StartCondition & {
            EventStartCondition: EventStartCondition & {
                EventFilter: EventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
            SegmentStartCondition: SegmentCondition & {
                SegmentId: string;
            };
        };
    };
}
export interface JourneyStateRequest {
    State?: State;
}
export interface UpdateJourneyStateRequest {
    ApplicationId: string;
    JourneyId: string;
    JourneyStateRequest?: JourneyStateRequest;
}
export interface UpdateJourneyStateResponse {
    JourneyResponse: JourneyResponse & {
        ApplicationId: string;
        Id: string;
        Name: string;
        Activities: {
            [key: string]: (Activity & {
                ConditionalSplit: ConditionalSplitActivity & {
                    Condition: Condition & {
                        Conditions: (SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        })[];
                    };
                };
                Holdout: HoldoutActivity & {
                    Percentage: number;
                };
                MultiCondition: MultiConditionalSplitActivity & {
                    Branches: (MultiConditionalBranch & {
                        Condition: SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        };
                    })[];
                };
            }) | undefined;
        };
        StartCondition: StartCondition & {
            EventStartCondition: EventStartCondition & {
                EventFilter: EventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
            SegmentStartCondition: SegmentCondition & {
                SegmentId: string;
            };
        };
    };
}
export interface UpdatePushTemplateRequest {
    CreateNewVersion?: boolean;
    PushNotificationTemplateRequest?: PushNotificationTemplateRequest;
    TemplateName: string;
    Version?: string;
}
export interface UpdatePushTemplateResponse {
    MessageBody: MessageBody;
}
export interface UpdateRecommenderConfigurationShape {
    Attributes?: {
        [key: string]: string | undefined;
    };
    Description?: string;
    Name?: string;
    RecommendationProviderIdType?: string;
    RecommendationProviderRoleArn?: string;
    RecommendationProviderUri?: string;
    RecommendationTransformerUri?: string;
    RecommendationsDisplayName?: string;
    RecommendationsPerMessage?: number;
}
export interface UpdateRecommenderConfigurationRequest {
    RecommenderId: string;
    UpdateRecommenderConfiguration?: UpdateRecommenderConfigurationShape;
}
export interface UpdateRecommenderConfigurationResponse {
    RecommenderConfigurationResponse: RecommenderConfigurationResponse & {
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        RecommendationProviderRoleArn: string;
        RecommendationProviderUri: string;
    };
}
export interface UpdateSegmentRequest {
    ApplicationId: string;
    SegmentId: string;
    WriteSegmentRequest?: WriteSegmentRequest;
}
export interface UpdateSegmentResponse {
    SegmentResponse: SegmentResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        SegmentType: SegmentType;
        Dimensions: SegmentDimensions & {
            Attributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
            Behavior: SegmentBehaviors & {
                Recency: RecencyDimension & {
                    Duration: Duration;
                    RecencyType: RecencyType;
                };
            };
            Demographic: SegmentDemographics & {
                AppVersion: SetDimension & {
                    Values: ListOf__string;
                };
                Channel: SetDimension & {
                    Values: ListOf__string;
                };
                DeviceType: SetDimension & {
                    Values: ListOf__string;
                };
                Make: SetDimension & {
                    Values: ListOf__string;
                };
                Model: SetDimension & {
                    Values: ListOf__string;
                };
                Platform: SetDimension & {
                    Values: ListOf__string;
                };
            };
            Location: SegmentLocation & {
                Country: SetDimension & {
                    Values: ListOf__string;
                };
                GPSPoint: GPSPointDimension & {
                    Coordinates: GPSCoordinates & {
                        Latitude: number;
                        Longitude: number;
                    };
                };
            };
            Metrics: {
                [key: string]: (MetricDimension & {
                    ComparisonOperator: string;
                    Value: number;
                }) | undefined;
            };
            UserAttributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
        };
        ImportDefinition: SegmentImportResource & {
            ExternalId: string;
            Format: Format;
            RoleArn: string;
            S3Url: string;
            Size: number;
        };
        SegmentGroups: SegmentGroupList & {
            Groups: (SegmentGroup & {
                Dimensions: (SegmentDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    Behavior: SegmentBehaviors & {
                        Recency: RecencyDimension & {
                            Duration: Duration;
                            RecencyType: RecencyType;
                        };
                    };
                    Demographic: SegmentDemographics & {
                        AppVersion: SetDimension & {
                            Values: ListOf__string;
                        };
                        Channel: SetDimension & {
                            Values: ListOf__string;
                        };
                        DeviceType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Make: SetDimension & {
                            Values: ListOf__string;
                        };
                        Model: SetDimension & {
                            Values: ListOf__string;
                        };
                        Platform: SetDimension & {
                            Values: ListOf__string;
                        };
                    };
                    Location: SegmentLocation & {
                        Country: SetDimension & {
                            Values: ListOf__string;
                        };
                        GPSPoint: GPSPointDimension & {
                            Coordinates: GPSCoordinates & {
                                Latitude: number;
                                Longitude: number;
                            };
                        };
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                    UserAttributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                })[];
                SourceSegments: (SegmentReference & {
                    Id: string;
                })[];
            })[];
        };
    };
}
export interface SMSChannelRequest {
    Enabled?: boolean;
    SenderId?: string;
    ShortCode?: string;
}
export interface UpdateSmsChannelRequest {
    ApplicationId: string;
    SMSChannelRequest?: SMSChannelRequest;
}
export interface UpdateSmsChannelResponse {
    SMSChannelResponse: SMSChannelResponse & {
        Platform: string;
    };
}
export interface UpdateSmsTemplateRequest {
    CreateNewVersion?: boolean;
    SMSTemplateRequest?: SMSTemplateRequest;
    TemplateName: string;
    Version?: string;
}
export interface UpdateSmsTemplateResponse {
    MessageBody: MessageBody;
}
export interface TemplateActiveVersionRequest {
    Version?: string;
}
export interface UpdateTemplateActiveVersionRequest {
    TemplateActiveVersionRequest?: TemplateActiveVersionRequest;
    TemplateName: string;
    TemplateType: string;
}
export interface UpdateTemplateActiveVersionResponse {
    MessageBody: MessageBody;
}
export interface VoiceChannelRequest {
    Enabled?: boolean;
}
export interface UpdateVoiceChannelRequest {
    ApplicationId: string;
    VoiceChannelRequest?: VoiceChannelRequest;
}
export interface UpdateVoiceChannelResponse {
    VoiceChannelResponse: VoiceChannelResponse & {
        Platform: string;
    };
}
export interface UpdateVoiceTemplateRequest {
    CreateNewVersion?: boolean;
    TemplateName: string;
    Version?: string;
    VoiceTemplateRequest?: VoiceTemplateRequest;
}
export interface UpdateVoiceTemplateResponse {
    MessageBody: MessageBody;
}
export interface VerifyOTPMessageRequestParameters {
    DestinationIdentity?: string;
    Otp?: string;
    ReferenceId?: string;
}
export interface VerifyOTPMessageRequest {
    ApplicationId: string;
    VerifyOTPMessageRequestParameters?: VerifyOTPMessageRequestParameters;
}
export interface VerificationResponse {
    Valid?: boolean;
}
export interface VerifyOTPMessageResponse {
    VerificationResponse: VerificationResponse;
}
export type CreateAppError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates an application.
 */
export declare const createApp: API.OperationMethod<CreateAppRequest, CreateAppResponse, CreateAppError, Credentials | HttpClient.HttpClient>;
export type CreateCampaignError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new campaign for an application or updates the settings of an existing campaign for an application.
 */
export declare const createCampaign: API.OperationMethod<CreateCampaignRequest, CreateCampaignResponse, CreateCampaignError, Credentials | HttpClient.HttpClient>;
export type CreateEmailTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Creates a message template for messages that are sent through the email channel.
 */
export declare const createEmailTemplate: API.OperationMethod<CreateEmailTemplateRequest, CreateEmailTemplateResponse, CreateEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateExportJobError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates an export job for an application.
 */
export declare const createExportJob: API.OperationMethod<CreateExportJobRequest, CreateExportJobResponse, CreateExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateImportJobError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates an import job for an application.
 */
export declare const createImportJob: API.OperationMethod<CreateImportJobRequest, CreateImportJobResponse, CreateImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateInAppTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new message template for messages using the in-app message channel.
 */
export declare const createInAppTemplate: API.OperationMethod<CreateInAppTemplateRequest, CreateInAppTemplateResponse, CreateInAppTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateJourneyError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a journey for an application.
 */
export declare const createJourney: API.OperationMethod<CreateJourneyRequest, CreateJourneyResponse, CreateJourneyError, Credentials | HttpClient.HttpClient>;
export type CreatePushTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Creates a message template for messages that are sent through a push notification channel.
 */
export declare const createPushTemplate: API.OperationMethod<CreatePushTemplateRequest, CreatePushTemplateResponse, CreatePushTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateRecommenderConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Amazon Pinpoint configuration for a recommender model.
 */
export declare const createRecommenderConfiguration: API.OperationMethod<CreateRecommenderConfigurationRequest, CreateRecommenderConfigurationResponse, CreateRecommenderConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateSegmentError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new segment for an application or updates the configuration, dimension, and other settings for an existing segment that's associated with an application.
 */
export declare const createSegment: API.OperationMethod<CreateSegmentRequest, CreateSegmentResponse, CreateSegmentError, Credentials | HttpClient.HttpClient>;
export type CreateSmsTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Creates a message template for messages that are sent through the SMS channel.
 */
export declare const createSmsTemplate: API.OperationMethod<CreateSmsTemplateRequest, CreateSmsTemplateResponse, CreateSmsTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Creates a message template for messages that are sent through the voice channel.
 */
export declare const createVoiceTemplate: API.OperationMethod<CreateVoiceTemplateRequest, CreateVoiceTemplateResponse, CreateVoiceTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteAdmChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the ADM channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteAdmChannel: API.OperationMethod<DeleteAdmChannelRequest, DeleteAdmChannelResponse, DeleteAdmChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteApnsChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the APNs channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteApnsChannel: API.OperationMethod<DeleteApnsChannelRequest, DeleteApnsChannelResponse, DeleteApnsChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteApnsSandboxChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the APNs sandbox channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteApnsSandboxChannel: API.OperationMethod<DeleteApnsSandboxChannelRequest, DeleteApnsSandboxChannelResponse, DeleteApnsSandboxChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteApnsVoipChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the APNs VoIP channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteApnsVoipChannel: API.OperationMethod<DeleteApnsVoipChannelRequest, DeleteApnsVoipChannelResponse, DeleteApnsVoipChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteApnsVoipSandboxChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the APNs VoIP sandbox channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteApnsVoipSandboxChannel: API.OperationMethod<DeleteApnsVoipSandboxChannelRequest, DeleteApnsVoipSandboxChannelResponse, DeleteApnsVoipSandboxChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteAppError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an application.
 */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest, DeleteAppResponse, DeleteAppError, Credentials | HttpClient.HttpClient>;
export type DeleteBaiduChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the Baidu channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteBaiduChannel: API.OperationMethod<DeleteBaiduChannelRequest, DeleteBaiduChannelResponse, DeleteBaiduChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a campaign from an application.
 */
export declare const deleteCampaign: API.OperationMethod<DeleteCampaignRequest, DeleteCampaignResponse, DeleteCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteEmailChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the email channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteEmailChannel: API.OperationMethod<DeleteEmailChannelRequest, DeleteEmailChannelResponse, DeleteEmailChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteEmailTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a message template for messages that were sent through the email channel.
 */
export declare const deleteEmailTemplate: API.OperationMethod<DeleteEmailTemplateRequest, DeleteEmailTemplateResponse, DeleteEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an endpoint from an application.
 */
export declare const deleteEndpoint: API.OperationMethod<DeleteEndpointRequest, DeleteEndpointResponse, DeleteEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteEventStreamError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the event stream for an application.
 */
export declare const deleteEventStream: API.OperationMethod<DeleteEventStreamRequest, DeleteEventStreamResponse, DeleteEventStreamError, Credentials | HttpClient.HttpClient>;
export type DeleteGcmChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the GCM channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteGcmChannel: API.OperationMethod<DeleteGcmChannelRequest, DeleteGcmChannelResponse, DeleteGcmChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteInAppTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a message template for messages sent using the in-app message channel.
 */
export declare const deleteInAppTemplate: API.OperationMethod<DeleteInAppTemplateRequest, DeleteInAppTemplateResponse, DeleteInAppTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteJourneyError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a journey from an application.
 */
export declare const deleteJourney: API.OperationMethod<DeleteJourneyRequest, DeleteJourneyResponse, DeleteJourneyError, Credentials | HttpClient.HttpClient>;
export type DeletePushTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a message template for messages that were sent through a push notification channel.
 */
export declare const deletePushTemplate: API.OperationMethod<DeletePushTemplateRequest, DeletePushTemplateResponse, DeletePushTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteRecommenderConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Amazon Pinpoint configuration for a recommender model.
 */
export declare const deleteRecommenderConfiguration: API.OperationMethod<DeleteRecommenderConfigurationRequest, DeleteRecommenderConfigurationResponse, DeleteRecommenderConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteSegmentError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a segment from an application.
 */
export declare const deleteSegment: API.OperationMethod<DeleteSegmentRequest, DeleteSegmentResponse, DeleteSegmentError, Credentials | HttpClient.HttpClient>;
export type DeleteSmsChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the SMS channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteSmsChannel: API.OperationMethod<DeleteSmsChannelRequest, DeleteSmsChannelResponse, DeleteSmsChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteSmsTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a message template for messages that were sent through the SMS channel.
 */
export declare const deleteSmsTemplate: API.OperationMethod<DeleteSmsTemplateRequest, DeleteSmsTemplateResponse, DeleteSmsTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteUserEndpointsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes all the endpoints that are associated with a specific user ID.
 */
export declare const deleteUserEndpoints: API.OperationMethod<DeleteUserEndpointsRequest, DeleteUserEndpointsResponse, DeleteUserEndpointsError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the voice channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteVoiceChannel: API.OperationMethod<DeleteVoiceChannelRequest, DeleteVoiceChannelResponse, DeleteVoiceChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a message template for messages that were sent through the voice channel.
 */
export declare const deleteVoiceTemplate: API.OperationMethod<DeleteVoiceTemplateRequest, DeleteVoiceTemplateResponse, DeleteVoiceTemplateError, Credentials | HttpClient.HttpClient>;
export type GetAdmChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the ADM channel for an application.
 */
export declare const getAdmChannel: API.OperationMethod<GetAdmChannelRequest, GetAdmChannelResponse, GetAdmChannelError, Credentials | HttpClient.HttpClient>;
export type GetApnsChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the APNs channel for an application.
 */
export declare const getApnsChannel: API.OperationMethod<GetApnsChannelRequest, GetApnsChannelResponse, GetApnsChannelError, Credentials | HttpClient.HttpClient>;
export type GetApnsSandboxChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the APNs sandbox channel for an application.
 */
export declare const getApnsSandboxChannel: API.OperationMethod<GetApnsSandboxChannelRequest, GetApnsSandboxChannelResponse, GetApnsSandboxChannelError, Credentials | HttpClient.HttpClient>;
export type GetApnsVoipChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the APNs VoIP channel for an application.
 */
export declare const getApnsVoipChannel: API.OperationMethod<GetApnsVoipChannelRequest, GetApnsVoipChannelResponse, GetApnsVoipChannelError, Credentials | HttpClient.HttpClient>;
export type GetApnsVoipSandboxChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the APNs VoIP sandbox channel for an application.
 */
export declare const getApnsVoipSandboxChannel: API.OperationMethod<GetApnsVoipSandboxChannelRequest, GetApnsVoipSandboxChannelResponse, GetApnsVoipSandboxChannelError, Credentials | HttpClient.HttpClient>;
export type GetAppError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about an application.
 */
export declare const getApp: API.OperationMethod<GetAppRequest, GetAppResponse, GetAppError, Credentials | HttpClient.HttpClient>;
export type GetApplicationDateRangeKpiError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard metric that applies to an application.
 */
export declare const getApplicationDateRangeKpi: API.OperationMethod<GetApplicationDateRangeKpiRequest, GetApplicationDateRangeKpiResponse, GetApplicationDateRangeKpiError, Credentials | HttpClient.HttpClient>;
export type GetApplicationSettingsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the settings for an application.
 */
export declare const getApplicationSettings: API.OperationMethod<GetApplicationSettingsRequest, GetApplicationSettingsResponse, GetApplicationSettingsError, Credentials | HttpClient.HttpClient>;
export type GetAppsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about all the applications that are associated with your Amazon Pinpoint account.
 */
export declare const getApps: API.OperationMethod<GetAppsRequest, GetAppsResponse, GetAppsError, Credentials | HttpClient.HttpClient>;
export type GetBaiduChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the Baidu channel for an application.
 */
export declare const getBaiduChannel: API.OperationMethod<GetBaiduChannelRequest, GetBaiduChannelResponse, GetBaiduChannelError, Credentials | HttpClient.HttpClient>;
export type GetCampaignError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status, configuration, and other settings for a campaign.
 */
export declare const getCampaign: API.OperationMethod<GetCampaignRequest, GetCampaignResponse, GetCampaignError, Credentials | HttpClient.HttpClient>;
export type GetCampaignActivitiesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about all the activities for a campaign.
 */
export declare const getCampaignActivities: API.OperationMethod<GetCampaignActivitiesRequest, GetCampaignActivitiesResponse, GetCampaignActivitiesError, Credentials | HttpClient.HttpClient>;
export type GetCampaignDateRangeKpiError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard metric that applies to a campaign.
 */
export declare const getCampaignDateRangeKpi: API.OperationMethod<GetCampaignDateRangeKpiRequest, GetCampaignDateRangeKpiResponse, GetCampaignDateRangeKpiError, Credentials | HttpClient.HttpClient>;
export type GetCampaignsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status, configuration, and other settings for all the campaigns that are associated with an application.
 */
export declare const getCampaigns: API.OperationMethod<GetCampaignsRequest, GetCampaignsResponse, GetCampaignsError, Credentials | HttpClient.HttpClient>;
export type GetCampaignVersionError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status, configuration, and other settings for a specific version of a campaign.
 */
export declare const getCampaignVersion: API.OperationMethod<GetCampaignVersionRequest, GetCampaignVersionResponse, GetCampaignVersionError, Credentials | HttpClient.HttpClient>;
export type GetCampaignVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status, configuration, and other settings for all versions of a campaign.
 */
export declare const getCampaignVersions: API.OperationMethod<GetCampaignVersionsRequest, GetCampaignVersionsResponse, GetCampaignVersionsError, Credentials | HttpClient.HttpClient>;
export type GetChannelsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the history and status of each channel for an application.
 */
export declare const getChannels: API.OperationMethod<GetChannelsRequest, GetChannelsResponse, GetChannelsError, Credentials | HttpClient.HttpClient>;
export type GetEmailChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the email channel for an application.
 */
export declare const getEmailChannel: API.OperationMethod<GetEmailChannelRequest, GetEmailChannelResponse, GetEmailChannelError, Credentials | HttpClient.HttpClient>;
export type GetEmailTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the content and settings of a message template for messages that are sent through the email channel.
 */
export declare const getEmailTemplate: API.OperationMethod<GetEmailTemplateRequest, GetEmailTemplateResponse, GetEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type GetEndpointError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the settings and attributes of a specific endpoint for an application.
 */
export declare const getEndpoint: API.OperationMethod<GetEndpointRequest, GetEndpointResponse, GetEndpointError, Credentials | HttpClient.HttpClient>;
export type GetEventStreamError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the event stream settings for an application.
 */
export declare const getEventStream: API.OperationMethod<GetEventStreamRequest, GetEventStreamResponse, GetEventStreamError, Credentials | HttpClient.HttpClient>;
export type GetExportJobError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of a specific export job for an application.
 */
export declare const getExportJob: API.OperationMethod<GetExportJobRequest, GetExportJobResponse, GetExportJobError, Credentials | HttpClient.HttpClient>;
export type GetExportJobsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of all the export jobs for an application.
 */
export declare const getExportJobs: API.OperationMethod<GetExportJobsRequest, GetExportJobsResponse, GetExportJobsError, Credentials | HttpClient.HttpClient>;
export type GetGcmChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the GCM channel for an application.
 */
export declare const getGcmChannel: API.OperationMethod<GetGcmChannelRequest, GetGcmChannelResponse, GetGcmChannelError, Credentials | HttpClient.HttpClient>;
export type GetImportJobError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of a specific import job for an application.
 */
export declare const getImportJob: API.OperationMethod<GetImportJobRequest, GetImportJobResponse, GetImportJobError, Credentials | HttpClient.HttpClient>;
export type GetImportJobsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of all the import jobs for an application.
 */
export declare const getImportJobs: API.OperationMethod<GetImportJobsRequest, GetImportJobsResponse, GetImportJobsError, Credentials | HttpClient.HttpClient>;
export type GetInAppMessagesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the in-app messages targeted for the provided endpoint ID.
 */
export declare const getInAppMessages: API.OperationMethod<GetInAppMessagesRequest, GetInAppMessagesResponse, GetInAppMessagesError, Credentials | HttpClient.HttpClient>;
export type GetInAppTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the content and settings of a message template for messages sent through the in-app channel.
 */
export declare const getInAppTemplate: API.OperationMethod<GetInAppTemplateRequest, GetInAppTemplateResponse, GetInAppTemplateError, Credentials | HttpClient.HttpClient>;
export type GetJourneyError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status, configuration, and other settings for a journey.
 */
export declare const getJourney: API.OperationMethod<GetJourneyRequest, GetJourneyResponse, GetJourneyError, Credentials | HttpClient.HttpClient>;
export type GetJourneyDateRangeKpiError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard engagement metric that applies to a journey.
 */
export declare const getJourneyDateRangeKpi: API.OperationMethod<GetJourneyDateRangeKpiRequest, GetJourneyDateRangeKpiResponse, GetJourneyDateRangeKpiError, Credentials | HttpClient.HttpClient>;
export type GetJourneyExecutionActivityMetricsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard execution metric that applies to a journey activity.
 */
export declare const getJourneyExecutionActivityMetrics: API.OperationMethod<GetJourneyExecutionActivityMetricsRequest, GetJourneyExecutionActivityMetricsResponse, GetJourneyExecutionActivityMetricsError, Credentials | HttpClient.HttpClient>;
export type GetJourneyExecutionMetricsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard execution metric that applies to a journey.
 */
export declare const getJourneyExecutionMetrics: API.OperationMethod<GetJourneyExecutionMetricsRequest, GetJourneyExecutionMetricsResponse, GetJourneyExecutionMetricsError, Credentials | HttpClient.HttpClient>;
export type GetJourneyRunExecutionActivityMetricsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard run execution metric that applies to a journey activity.
 */
export declare const getJourneyRunExecutionActivityMetrics: API.OperationMethod<GetJourneyRunExecutionActivityMetricsRequest, GetJourneyRunExecutionActivityMetricsResponse, GetJourneyRunExecutionActivityMetricsError, Credentials | HttpClient.HttpClient>;
export type GetJourneyRunExecutionMetricsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard run execution metric that applies to a journey.
 */
export declare const getJourneyRunExecutionMetrics: API.OperationMethod<GetJourneyRunExecutionMetricsRequest, GetJourneyRunExecutionMetricsResponse, GetJourneyRunExecutionMetricsError, Credentials | HttpClient.HttpClient>;
export type GetJourneyRunsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Provides information about the runs of a journey.
 */
export declare const getJourneyRuns: API.OperationMethod<GetJourneyRunsRequest, GetJourneyRunsResponse, GetJourneyRunsError, Credentials | HttpClient.HttpClient>;
export type GetPushTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the content and settings of a message template for messages that are sent through a push notification channel.
 */
export declare const getPushTemplate: API.OperationMethod<GetPushTemplateRequest, GetPushTemplateResponse, GetPushTemplateError, Credentials | HttpClient.HttpClient>;
export type GetRecommenderConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about an Amazon Pinpoint configuration for a recommender model.
 */
export declare const getRecommenderConfiguration: API.OperationMethod<GetRecommenderConfigurationRequest, GetRecommenderConfigurationResponse, GetRecommenderConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetRecommenderConfigurationsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about all the recommender model configurations that are associated with your Amazon Pinpoint account.
 */
export declare const getRecommenderConfigurations: API.OperationMethod<GetRecommenderConfigurationsRequest, GetRecommenderConfigurationsResponse, GetRecommenderConfigurationsError, Credentials | HttpClient.HttpClient>;
export type GetSegmentError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the configuration, dimension, and other settings for a specific segment that's associated with an application.
 */
export declare const getSegment: API.OperationMethod<GetSegmentRequest, GetSegmentResponse, GetSegmentError, Credentials | HttpClient.HttpClient>;
export type GetSegmentExportJobsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the export jobs for a segment.
 */
export declare const getSegmentExportJobs: API.OperationMethod<GetSegmentExportJobsRequest, GetSegmentExportJobsResponse, GetSegmentExportJobsError, Credentials | HttpClient.HttpClient>;
export type GetSegmentImportJobsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the import jobs for a segment.
 */
export declare const getSegmentImportJobs: API.OperationMethod<GetSegmentImportJobsRequest, GetSegmentImportJobsResponse, GetSegmentImportJobsError, Credentials | HttpClient.HttpClient>;
export type GetSegmentsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the configuration, dimension, and other settings for all the segments that are associated with an application.
 */
export declare const getSegments: API.OperationMethod<GetSegmentsRequest, GetSegmentsResponse, GetSegmentsError, Credentials | HttpClient.HttpClient>;
export type GetSegmentVersionError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the configuration, dimension, and other settings for a specific version of a segment that's associated with an application.
 */
export declare const getSegmentVersion: API.OperationMethod<GetSegmentVersionRequest, GetSegmentVersionResponse, GetSegmentVersionError, Credentials | HttpClient.HttpClient>;
export type GetSegmentVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the configuration, dimension, and other settings for all the versions of a specific segment that's associated with an application.
 */
export declare const getSegmentVersions: API.OperationMethod<GetSegmentVersionsRequest, GetSegmentVersionsResponse, GetSegmentVersionsError, Credentials | HttpClient.HttpClient>;
export type GetSmsChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the SMS channel for an application.
 */
export declare const getSmsChannel: API.OperationMethod<GetSmsChannelRequest, GetSmsChannelResponse, GetSmsChannelError, Credentials | HttpClient.HttpClient>;
export type GetSmsTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the content and settings of a message template for messages that are sent through the SMS channel.
 */
export declare const getSmsTemplate: API.OperationMethod<GetSmsTemplateRequest, GetSmsTemplateResponse, GetSmsTemplateError, Credentials | HttpClient.HttpClient>;
export type GetUserEndpointsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about all the endpoints that are associated with a specific user ID.
 */
export declare const getUserEndpoints: API.OperationMethod<GetUserEndpointsRequest, GetUserEndpointsResponse, GetUserEndpointsError, Credentials | HttpClient.HttpClient>;
export type GetVoiceChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the voice channel for an application.
 */
export declare const getVoiceChannel: API.OperationMethod<GetVoiceChannelRequest, GetVoiceChannelResponse, GetVoiceChannelError, Credentials | HttpClient.HttpClient>;
export type GetVoiceTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the content and settings of a message template for messages that are sent through the voice channel.
 */
export declare const getVoiceTemplate: API.OperationMethod<GetVoiceTemplateRequest, GetVoiceTemplateResponse, GetVoiceTemplateError, Credentials | HttpClient.HttpClient>;
export type ListJourneysError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status, configuration, and other settings for all the journeys that are associated with an application.
 */
export declare const listJourneys: API.OperationMethod<ListJourneysRequest, ListJourneysResponse, ListJourneysError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = CommonErrors;
/**
 * Retrieves all the tags (keys and values) that are associated with an application, campaign, message template, or segment.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTemplatesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about all the message templates that are associated with your Amazon Pinpoint account.
 */
export declare const listTemplates: API.OperationMethod<ListTemplatesRequest, ListTemplatesResponse, ListTemplatesError, Credentials | HttpClient.HttpClient>;
export type ListTemplateVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about all the versions of a specific message template.
 */
export declare const listTemplateVersions: API.OperationMethod<ListTemplateVersionsRequest, ListTemplateVersionsResponse, ListTemplateVersionsError, Credentials | HttpClient.HttpClient>;
export type PhoneNumberValidateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about a phone number.
 */
export declare const phoneNumberValidate: API.OperationMethod<PhoneNumberValidateRequest, PhoneNumberValidateResponse, PhoneNumberValidateError, Credentials | HttpClient.HttpClient>;
export type PutEventsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new event to record for endpoints, or creates or updates endpoint data that existing events are associated with.
 */
export declare const putEvents: API.OperationMethod<PutEventsRequest, PutEventsResponse, PutEventsError, Credentials | HttpClient.HttpClient>;
export type PutEventStreamError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new event stream for an application or updates the settings of an existing event stream for an application.
 */
export declare const putEventStream: API.OperationMethod<PutEventStreamRequest, PutEventStreamResponse, PutEventStreamError, Credentials | HttpClient.HttpClient>;
export type RemoveAttributesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Removes one or more custom attributes, of the same attribute type, from the application. Existing endpoints still have the attributes but Amazon Pinpoint will stop capturing new or changed values for these attributes.
 */
export declare const removeAttributes: API.OperationMethod<RemoveAttributesRequest, RemoveAttributesResponse, RemoveAttributesError, Credentials | HttpClient.HttpClient>;
export type SendMessagesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates and sends a direct message.
 */
export declare const sendMessages: API.OperationMethod<SendMessagesRequest, SendMessagesResponse, SendMessagesError, Credentials | HttpClient.HttpClient>;
export type SendOTPMessageError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Send an OTP message
 */
export declare const sendOTPMessage: API.OperationMethod<SendOTPMessageRequest, SendOTPMessageResponse, SendOTPMessageError, Credentials | HttpClient.HttpClient>;
export type SendUsersMessagesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates and sends a message to a list of users.
 */
export declare const sendUsersMessages: API.OperationMethod<SendUsersMessagesRequest, SendUsersMessagesResponse, SendUsersMessagesError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * Adds one or more tags (keys and values) to an application, campaign, message template, or segment.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * Removes one or more tags (keys and values) from an application, campaign, message template, or segment.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAdmChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the ADM channel for an application or updates the status and settings of the ADM channel for an application.
 */
export declare const updateAdmChannel: API.OperationMethod<UpdateAdmChannelRequest, UpdateAdmChannelResponse, UpdateAdmChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateApnsChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the APNs channel for an application or updates the status and settings of the APNs channel for an application.
 */
export declare const updateApnsChannel: API.OperationMethod<UpdateApnsChannelRequest, UpdateApnsChannelResponse, UpdateApnsChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateApnsSandboxChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the APNs sandbox channel for an application or updates the status and settings of the APNs sandbox channel for an application.
 */
export declare const updateApnsSandboxChannel: API.OperationMethod<UpdateApnsSandboxChannelRequest, UpdateApnsSandboxChannelResponse, UpdateApnsSandboxChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateApnsVoipChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the APNs VoIP channel for an application or updates the status and settings of the APNs VoIP channel for an application.
 */
export declare const updateApnsVoipChannel: API.OperationMethod<UpdateApnsVoipChannelRequest, UpdateApnsVoipChannelResponse, UpdateApnsVoipChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateApnsVoipSandboxChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the APNs VoIP sandbox channel for an application or updates the status and settings of the APNs VoIP sandbox channel for an application.
 */
export declare const updateApnsVoipSandboxChannel: API.OperationMethod<UpdateApnsVoipSandboxChannelRequest, UpdateApnsVoipSandboxChannelResponse, UpdateApnsVoipSandboxChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationSettingsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates the settings for an application.
 */
export declare const updateApplicationSettings: API.OperationMethod<UpdateApplicationSettingsRequest, UpdateApplicationSettingsResponse, UpdateApplicationSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateBaiduChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the Baidu channel for an application or updates the status and settings of the Baidu channel for an application.
 */
export declare const updateBaiduChannel: API.OperationMethod<UpdateBaiduChannelRequest, UpdateBaiduChannelResponse, UpdateBaiduChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration and other settings for a campaign.
 */
export declare const updateCampaign: API.OperationMethod<UpdateCampaignRequest, UpdateCampaignResponse, UpdateCampaignError, Credentials | HttpClient.HttpClient>;
export type UpdateEmailChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the email channel for an application or updates the status and settings of the email channel for an application.
 */
export declare const updateEmailChannel: API.OperationMethod<UpdateEmailChannelRequest, UpdateEmailChannelResponse, UpdateEmailChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateEmailTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing message template for messages that are sent through the email channel.
 */
export declare const updateEmailTemplate: API.OperationMethod<UpdateEmailTemplateRequest, UpdateEmailTemplateResponse, UpdateEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateEndpointError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new endpoint for an application or updates the settings and attributes of an existing endpoint for an application. You can also use this operation to define custom attributes for an endpoint. If an update includes one or more values for a custom attribute, Amazon Pinpoint replaces (overwrites) any existing values with the new values.
 */
export declare const updateEndpoint: API.OperationMethod<UpdateEndpointRequest, UpdateEndpointResponse, UpdateEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateEndpointsBatchError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new batch of endpoints for an application or updates the settings and attributes of a batch of existing endpoints for an application. You can also use this operation to define custom attributes for a batch of endpoints. If an update includes one or more values for a custom attribute, Amazon Pinpoint replaces (overwrites) any existing values with the new values.
 */
export declare const updateEndpointsBatch: API.OperationMethod<UpdateEndpointsBatchRequest, UpdateEndpointsBatchResponse, UpdateEndpointsBatchError, Credentials | HttpClient.HttpClient>;
export type UpdateGcmChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the GCM channel for an application or updates the status and settings of the GCM channel for an application.
 */
export declare const updateGcmChannel: API.OperationMethod<UpdateGcmChannelRequest, UpdateGcmChannelResponse, UpdateGcmChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateInAppTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing message template for messages sent through the in-app message channel.
 */
export declare const updateInAppTemplate: API.OperationMethod<UpdateInAppTemplateRequest, UpdateInAppTemplateResponse, UpdateInAppTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateJourneyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration and other settings for a journey.
 */
export declare const updateJourney: API.OperationMethod<UpdateJourneyRequest, UpdateJourneyResponse, UpdateJourneyError, Credentials | HttpClient.HttpClient>;
export type UpdateJourneyStateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Cancels (stops) an active journey.
 */
export declare const updateJourneyState: API.OperationMethod<UpdateJourneyStateRequest, UpdateJourneyStateResponse, UpdateJourneyStateError, Credentials | HttpClient.HttpClient>;
export type UpdatePushTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing message template for messages that are sent through a push notification channel.
 */
export declare const updatePushTemplate: API.OperationMethod<UpdatePushTemplateRequest, UpdatePushTemplateResponse, UpdatePushTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateRecommenderConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates an Amazon Pinpoint configuration for a recommender model.
 */
export declare const updateRecommenderConfiguration: API.OperationMethod<UpdateRecommenderConfigurationRequest, UpdateRecommenderConfigurationResponse, UpdateRecommenderConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateSegmentError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new segment for an application or updates the configuration, dimension, and other settings for an existing segment that's associated with an application.
 */
export declare const updateSegment: API.OperationMethod<UpdateSegmentRequest, UpdateSegmentResponse, UpdateSegmentError, Credentials | HttpClient.HttpClient>;
export type UpdateSmsChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the SMS channel for an application or updates the status and settings of the SMS channel for an application.
 */
export declare const updateSmsChannel: API.OperationMethod<UpdateSmsChannelRequest, UpdateSmsChannelResponse, UpdateSmsChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateSmsTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing message template for messages that are sent through the SMS channel.
 */
export declare const updateSmsTemplate: API.OperationMethod<UpdateSmsTemplateRequest, UpdateSmsTemplateResponse, UpdateSmsTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplateActiveVersionError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Changes the status of a specific version of a message template to *active*.
 */
export declare const updateTemplateActiveVersion: API.OperationMethod<UpdateTemplateActiveVersionRequest, UpdateTemplateActiveVersionResponse, UpdateTemplateActiveVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the voice channel for an application or updates the status and settings of the voice channel for an application.
 */
export declare const updateVoiceChannel: API.OperationMethod<UpdateVoiceChannelRequest, UpdateVoiceChannelResponse, UpdateVoiceChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing message template for messages that are sent through the voice channel.
 */
export declare const updateVoiceTemplate: API.OperationMethod<UpdateVoiceTemplateRequest, UpdateVoiceTemplateResponse, UpdateVoiceTemplateError, Credentials | HttpClient.HttpClient>;
export type VerifyOTPMessageError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Verify an OTP
 */
export declare const verifyOTPMessage: API.OperationMethod<VerifyOTPMessageRequest, VerifyOTPMessageResponse, VerifyOTPMessageError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=pinpoint.d.ts.map