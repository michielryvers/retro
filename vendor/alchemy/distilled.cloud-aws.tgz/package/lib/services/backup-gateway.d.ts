import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type GatewayArn = string;
export type ServerArn = string;
export interface AssociateGatewayToServerInput {
    GatewayArn: string;
    ServerArn: string;
}
export interface AssociateGatewayToServerOutput {
    GatewayArn?: string;
}
export type ActivationKey = string;
export type Name = string;
export type GatewayType = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type Tags = Tag[];
export interface CreateGatewayInput {
    ActivationKey: string;
    GatewayDisplayName: string;
    GatewayType: string;
    Tags?: Tag[];
}
export interface CreateGatewayOutput {
    GatewayArn?: string;
}
export interface DeleteGatewayInput {
    GatewayArn: string;
}
export interface DeleteGatewayOutput {
    GatewayArn?: string;
}
export interface DeleteHypervisorInput {
    HypervisorArn: string;
}
export interface DeleteHypervisorOutput {
    HypervisorArn?: string;
}
export interface DisassociateGatewayFromServerInput {
    GatewayArn: string;
}
export interface DisassociateGatewayFromServerOutput {
    GatewayArn?: string;
}
export interface GetBandwidthRateLimitScheduleInput {
    GatewayArn: string;
}
export type AverageUploadRateLimit = number;
export type HourOfDay = number;
export type MinuteOfHour = number;
export type DayOfWeek = number;
export type DaysOfWeek = number[];
export interface BandwidthRateLimitInterval {
    AverageUploadRateLimitInBitsPerSec?: number;
    StartHourOfDay: number;
    EndHourOfDay: number;
    StartMinuteOfHour: number;
    EndMinuteOfHour: number;
    DaysOfWeek: number[];
}
export type BandwidthRateLimitIntervals = BandwidthRateLimitInterval[];
export interface GetBandwidthRateLimitScheduleOutput {
    GatewayArn?: string;
    BandwidthRateLimitIntervals?: BandwidthRateLimitInterval[];
}
export interface GetGatewayInput {
    GatewayArn: string;
}
export type HypervisorId = string;
export type DayOfMonth = number;
export interface MaintenanceStartTime {
    DayOfMonth?: number;
    DayOfWeek?: number;
    HourOfDay: number;
    MinuteOfHour: number;
}
export type VpcEndpoint = string;
export interface GatewayDetails {
    GatewayArn?: string;
    GatewayDisplayName?: string;
    GatewayType?: string;
    HypervisorId?: string;
    LastSeenTime?: Date;
    MaintenanceStartTime?: MaintenanceStartTime;
    NextUpdateAvailabilityTime?: Date;
    VpcEndpoint?: string;
    DeprecationDate?: Date;
    SoftwareVersion?: string;
}
export interface GetGatewayOutput {
    Gateway?: GatewayDetails;
}
export interface GetHypervisorInput {
    HypervisorArn: string;
}
export type Host = string;
export type KmsKeyArn = string;
export type LogGroupArn = string;
export type HypervisorState = string;
export type SyncMetadataStatus = string;
export interface HypervisorDetails {
    Host?: string;
    HypervisorArn?: string;
    KmsKeyArn?: string;
    Name?: string;
    LogGroupArn?: string;
    State?: string;
    LastSuccessfulMetadataSyncTime?: Date;
    LatestMetadataSyncStatusMessage?: string;
    LatestMetadataSyncStatus?: string;
}
export interface GetHypervisorOutput {
    Hypervisor?: HypervisorDetails;
}
export interface GetHypervisorPropertyMappingsInput {
    HypervisorArn: string;
}
export type VmwareCategory = string;
export type VmwareTagName = string;
export interface VmwareToAwsTagMapping {
    VmwareCategory: string;
    VmwareTagName: string;
    AwsTagKey: string;
    AwsTagValue: string;
}
export type VmwareToAwsTagMappings = VmwareToAwsTagMapping[];
export type IamRoleArn = string;
export interface GetHypervisorPropertyMappingsOutput {
    HypervisorArn?: string;
    VmwareToAwsTagMappings?: VmwareToAwsTagMapping[];
    IamRoleArn?: string;
}
export type ResourceArn = string;
export interface GetVirtualMachineInput {
    ResourceArn: string;
}
export type Path = string;
export interface VmwareTag {
    VmwareCategory?: string;
    VmwareTagName?: string;
    VmwareTagDescription?: string;
}
export type VmwareTags = VmwareTag[];
export interface VirtualMachineDetails {
    HostName?: string;
    HypervisorId?: string;
    Name?: string;
    Path?: string;
    ResourceArn?: string;
    LastBackupDate?: Date;
    VmwareTags?: VmwareTag[];
}
export interface GetVirtualMachineOutput {
    VirtualMachine?: VirtualMachineDetails;
}
export type Username = string | redacted.Redacted<string>;
export type Password = string | redacted.Redacted<string>;
export interface ImportHypervisorConfigurationInput {
    Name: string;
    Host: string;
    Username?: string | redacted.Redacted<string>;
    Password?: string | redacted.Redacted<string>;
    KmsKeyArn?: string;
    Tags?: Tag[];
}
export interface ImportHypervisorConfigurationOutput {
    HypervisorArn?: string;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListGatewaysInput {
    MaxResults?: number;
    NextToken?: string;
}
export interface Gateway {
    GatewayArn?: string;
    GatewayDisplayName?: string;
    GatewayType?: string;
    HypervisorId?: string;
    LastSeenTime?: Date;
}
export type Gateways = Gateway[];
export interface ListGatewaysOutput {
    Gateways?: Gateway[];
    NextToken?: string;
}
export interface ListHypervisorsInput {
    MaxResults?: number;
    NextToken?: string;
}
export interface Hypervisor {
    Host?: string;
    HypervisorArn?: string;
    KmsKeyArn?: string;
    Name?: string;
    State?: string;
}
export type Hypervisors = Hypervisor[];
export interface ListHypervisorsOutput {
    Hypervisors?: Hypervisor[];
    NextToken?: string;
}
export interface ListTagsForResourceInput {
    ResourceArn: string;
}
export interface ListTagsForResourceOutput {
    ResourceArn?: string;
    Tags?: Tag[];
}
export interface ListVirtualMachinesInput {
    HypervisorArn?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface VirtualMachine {
    HostName?: string;
    HypervisorId?: string;
    Name?: string;
    Path?: string;
    ResourceArn?: string;
    LastBackupDate?: Date;
}
export type VirtualMachines = VirtualMachine[];
export interface ListVirtualMachinesOutput {
    VirtualMachines?: VirtualMachine[];
    NextToken?: string;
}
export interface PutBandwidthRateLimitScheduleInput {
    GatewayArn: string;
    BandwidthRateLimitIntervals: BandwidthRateLimitInterval[];
}
export interface PutBandwidthRateLimitScheduleOutput {
    GatewayArn?: string;
}
export interface PutHypervisorPropertyMappingsInput {
    HypervisorArn: string;
    VmwareToAwsTagMappings: VmwareToAwsTagMapping[];
    IamRoleArn: string;
}
export interface PutHypervisorPropertyMappingsOutput {
    HypervisorArn?: string;
}
export interface PutMaintenanceStartTimeInput {
    GatewayArn: string;
    HourOfDay: number;
    MinuteOfHour: number;
    DayOfWeek?: number;
    DayOfMonth?: number;
}
export interface PutMaintenanceStartTimeOutput {
    GatewayArn?: string;
}
export interface StartVirtualMachinesMetadataSyncInput {
    HypervisorArn: string;
}
export interface StartVirtualMachinesMetadataSyncOutput {
    HypervisorArn?: string;
}
export interface TagResourceInput {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceOutput {
    ResourceARN?: string;
}
export interface TestHypervisorConfigurationInput {
    GatewayArn: string;
    Host: string;
    Username?: string | redacted.Redacted<string>;
    Password?: string | redacted.Redacted<string>;
}
export interface TestHypervisorConfigurationOutput {
}
export type TagKeys = string[];
export interface UntagResourceInput {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceOutput {
    ResourceARN?: string;
}
export interface UpdateGatewayInformationInput {
    GatewayArn: string;
    GatewayDisplayName?: string;
}
export interface UpdateGatewayInformationOutput {
    GatewayArn?: string;
}
export interface UpdateGatewaySoftwareNowInput {
    GatewayArn: string;
}
export interface UpdateGatewaySoftwareNowOutput {
    GatewayArn?: string;
}
export interface UpdateHypervisorInput {
    HypervisorArn: string;
    Host?: string;
    Username?: string | redacted.Redacted<string>;
    Password?: string | redacted.Redacted<string>;
    Name?: string;
    LogGroupArn?: string;
}
export interface UpdateHypervisorOutput {
    HypervisorArn?: string;
}
export type AssociateGatewayToServerError = ConflictException | CommonErrors;
/**
 * Associates a backup gateway with your server. After you complete the association process, you can back up and restore your VMs through the gateway.
 */
export declare const associateGatewayToServer: API.OperationMethod<AssociateGatewayToServerInput, AssociateGatewayToServerOutput, AssociateGatewayToServerError, Credentials | HttpClient.HttpClient>;
export type CreateGatewayError = CommonErrors;
/**
 * Creates a backup gateway. After you create a gateway, you can associate it with a server using the `AssociateGatewayToServer` operation.
 */
export declare const createGateway: API.OperationMethod<CreateGatewayInput, CreateGatewayOutput, CreateGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayError = ResourceNotFoundException | CommonErrors;
/**
 * Deletes a backup gateway.
 */
export declare const deleteGateway: API.OperationMethod<DeleteGatewayInput, DeleteGatewayOutput, DeleteGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteHypervisorError = AccessDeniedException | ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a hypervisor.
 */
export declare const deleteHypervisor: API.OperationMethod<DeleteHypervisorInput, DeleteHypervisorOutput, DeleteHypervisorError, Credentials | HttpClient.HttpClient>;
export type DisassociateGatewayFromServerError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates a backup gateway from the specified server. After the disassociation process finishes, the gateway can no longer access the virtual machines on the server.
 */
export declare const disassociateGatewayFromServer: API.OperationMethod<DisassociateGatewayFromServerInput, DisassociateGatewayFromServerOutput, DisassociateGatewayFromServerError, Credentials | HttpClient.HttpClient>;
export type GetBandwidthRateLimitScheduleError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the bandwidth rate limit schedule for a specified gateway. By default, gateways do not have bandwidth rate limit schedules, which means no bandwidth rate limiting is in effect. Use this to get a gateway's bandwidth rate limit schedule.
 */
export declare const getBandwidthRateLimitSchedule: API.OperationMethod<GetBandwidthRateLimitScheduleInput, GetBandwidthRateLimitScheduleOutput, GetBandwidthRateLimitScheduleError, Credentials | HttpClient.HttpClient>;
export type GetGatewayError = ResourceNotFoundException | CommonErrors;
/**
 * By providing the ARN (Amazon Resource Name), this API returns the gateway.
 */
export declare const getGateway: API.OperationMethod<GetGatewayInput, GetGatewayOutput, GetGatewayError, Credentials | HttpClient.HttpClient>;
export type GetHypervisorError = ResourceNotFoundException | CommonErrors;
/**
 * This action requests information about the specified hypervisor to which the gateway will connect. A hypervisor is hardware, software, or firmware that creates and manages virtual machines, and allocates resources to them.
 */
export declare const getHypervisor: API.OperationMethod<GetHypervisorInput, GetHypervisorOutput, GetHypervisorError, Credentials | HttpClient.HttpClient>;
export type GetHypervisorPropertyMappingsError = ResourceNotFoundException | CommonErrors;
/**
 * This action retrieves the property mappings for the specified hypervisor. A hypervisor property mapping displays the relationship of entity properties available from the hypervisor to the properties available in Amazon Web Services.
 */
export declare const getHypervisorPropertyMappings: API.OperationMethod<GetHypervisorPropertyMappingsInput, GetHypervisorPropertyMappingsOutput, GetHypervisorPropertyMappingsError, Credentials | HttpClient.HttpClient>;
export type GetVirtualMachineError = ResourceNotFoundException | CommonErrors;
/**
 * By providing the ARN (Amazon Resource Name), this API returns the virtual machine.
 */
export declare const getVirtualMachine: API.OperationMethod<GetVirtualMachineInput, GetVirtualMachineOutput, GetVirtualMachineError, Credentials | HttpClient.HttpClient>;
export type ImportHypervisorConfigurationError = AccessDeniedException | ConflictException | CommonErrors;
/**
 * Connect to a hypervisor by importing its configuration.
 */
export declare const importHypervisorConfiguration: API.OperationMethod<ImportHypervisorConfigurationInput, ImportHypervisorConfigurationOutput, ImportHypervisorConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListGatewaysError = CommonErrors;
/**
 * Lists backup gateways owned by an Amazon Web Services account in an Amazon Web Services Region. The returned list is ordered by gateway Amazon Resource Name (ARN).
 */
export declare const listGateways: API.PaginatedOperationMethod<ListGatewaysInput, ListGatewaysOutput, ListGatewaysError, Credentials | HttpClient.HttpClient, Gateway>;
export type ListHypervisorsError = CommonErrors;
/**
 * Lists your hypervisors.
 */
export declare const listHypervisors: API.PaginatedOperationMethod<ListHypervisorsInput, ListHypervisorsOutput, ListHypervisorsError, Credentials | HttpClient.HttpClient, Hypervisor>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags applied to the resource identified by its Amazon Resource Name (ARN).
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVirtualMachinesError = CommonErrors;
/**
 * Lists your virtual machines.
 */
export declare const listVirtualMachines: API.PaginatedOperationMethod<ListVirtualMachinesInput, ListVirtualMachinesOutput, ListVirtualMachinesError, Credentials | HttpClient.HttpClient, VirtualMachine>;
export type PutBandwidthRateLimitScheduleError = ResourceNotFoundException | CommonErrors;
/**
 * This action sets the bandwidth rate limit schedule for a specified gateway. By default, gateways do not have a bandwidth rate limit schedule, which means no bandwidth rate limiting is in effect. Use this to initiate a gateway's bandwidth rate limit schedule.
 */
export declare const putBandwidthRateLimitSchedule: API.OperationMethod<PutBandwidthRateLimitScheduleInput, PutBandwidthRateLimitScheduleOutput, PutBandwidthRateLimitScheduleError, Credentials | HttpClient.HttpClient>;
export type PutHypervisorPropertyMappingsError = AccessDeniedException | ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * This action sets the property mappings for the specified hypervisor. A hypervisor property mapping displays the relationship of entity properties available from the hypervisor to the properties available in Amazon Web Services.
 */
export declare const putHypervisorPropertyMappings: API.OperationMethod<PutHypervisorPropertyMappingsInput, PutHypervisorPropertyMappingsOutput, PutHypervisorPropertyMappingsError, Credentials | HttpClient.HttpClient>;
export type PutMaintenanceStartTimeError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Set the maintenance start time for a gateway.
 */
export declare const putMaintenanceStartTime: API.OperationMethod<PutMaintenanceStartTimeInput, PutMaintenanceStartTimeOutput, PutMaintenanceStartTimeError, Credentials | HttpClient.HttpClient>;
export type StartVirtualMachinesMetadataSyncError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * This action sends a request to sync metadata across the specified virtual machines.
 */
export declare const startVirtualMachinesMetadataSync: API.OperationMethod<StartVirtualMachinesMetadataSyncInput, StartVirtualMachinesMetadataSyncOutput, StartVirtualMachinesMetadataSyncError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Tag the resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestHypervisorConfigurationError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Tests your hypervisor configuration to validate that backup gateway can connect with the hypervisor and its resources.
 */
export declare const testHypervisorConfiguration: API.OperationMethod<TestHypervisorConfigurationInput, TestHypervisorConfigurationOutput, TestHypervisorConfigurationError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes tags from the resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayInformationError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a gateway's name. Specify which gateway to update using the Amazon Resource Name (ARN) of the gateway in your request.
 */
export declare const updateGatewayInformation: API.OperationMethod<UpdateGatewayInformationInput, UpdateGatewayInformationOutput, UpdateGatewayInformationError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewaySoftwareNowError = ResourceNotFoundException | CommonErrors;
/**
 * Updates the gateway virtual machine (VM) software. The request immediately triggers the software update.
 *
 * When you make this request, you get a `200 OK` success response immediately. However, it might take some time for the update to complete.
 */
export declare const updateGatewaySoftwareNow: API.OperationMethod<UpdateGatewaySoftwareNowInput, UpdateGatewaySoftwareNowOutput, UpdateGatewaySoftwareNowError, Credentials | HttpClient.HttpClient>;
export type UpdateHypervisorError = AccessDeniedException | ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a hypervisor metadata, including its host, username, and password. Specify which hypervisor to update using the Amazon Resource Name (ARN) of the hypervisor in your request.
 */
export declare const updateHypervisor: API.OperationMethod<UpdateHypervisorInput, UpdateHypervisorOutput, UpdateHypervisorError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=backup-gateway.d.ts.map