import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ACLAlreadyExistsFault_base: S.TaggedErrorClass<"ACLAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ACLAlreadyExistsFault extends /*@__PURE__*/ ACLAlreadyExistsFault_base {
}
declare const ACLNotFoundFault_base: S.TaggedErrorClass<"ACLNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ACLNotFoundFault extends /*@__PURE__*/ ACLNotFoundFault_base {
}
declare const ACLQuotaExceededFault_base: S.TaggedErrorClass<"ACLQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ACLQuotaExceededFault extends /*@__PURE__*/ ACLQuotaExceededFault_base {
}
declare const APICallRateForCustomerExceededFault_base: S.TaggedErrorClass<"APICallRateForCustomerExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class APICallRateForCustomerExceededFault extends /*@__PURE__*/ APICallRateForCustomerExceededFault_base {
}
declare const ClusterAlreadyExistsFault_base: S.TaggedErrorClass<"ClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ClusterAlreadyExistsFault extends /*@__PURE__*/ ClusterAlreadyExistsFault_base {
}
declare const ClusterNotFoundFault_base: S.TaggedErrorClass<"ClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterNotFoundFault extends /*@__PURE__*/ ClusterNotFoundFault_base {
}
declare const ClusterQuotaForCustomerExceededFault_base: S.TaggedErrorClass<"ClusterQuotaForCustomerExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterQuotaForCustomerExceededFault extends /*@__PURE__*/ ClusterQuotaForCustomerExceededFault_base {
}
declare const DefaultUserRequired_base: S.TaggedErrorClass<"DefaultUserRequired", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DefaultUserRequired extends /*@__PURE__*/ DefaultUserRequired_base {
}
declare const DuplicateUserNameFault_base: S.TaggedErrorClass<"DuplicateUserNameFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateUserNameFault extends /*@__PURE__*/ DuplicateUserNameFault_base {
}
declare const InsufficientClusterCapacityFault_base: S.TaggedErrorClass<"InsufficientClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientClusterCapacityFault extends /*@__PURE__*/ InsufficientClusterCapacityFault_base {
}
declare const InvalidACLStateFault_base: S.TaggedErrorClass<"InvalidACLStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidACLStateFault extends /*@__PURE__*/ InvalidACLStateFault_base {
}
declare const InvalidARNFault_base: S.TaggedErrorClass<"InvalidARNFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidARNFault extends /*@__PURE__*/ InvalidARNFault_base {
}
declare const InvalidClusterStateFault_base: S.TaggedErrorClass<"InvalidClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClusterStateFault extends /*@__PURE__*/ InvalidClusterStateFault_base {
}
declare const InvalidCredentialsException_base: S.TaggedErrorClass<"InvalidCredentialsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class InvalidCredentialsException extends /*@__PURE__*/ InvalidCredentialsException_base {
}
declare const InvalidKMSKeyFault_base: S.TaggedErrorClass<"InvalidKMSKeyFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidKMSKeyFault extends /*@__PURE__*/ InvalidKMSKeyFault_base {
}
declare const InvalidMultiRegionClusterStateFault_base: S.TaggedErrorClass<"InvalidMultiRegionClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidMultiRegionClusterStateFault extends /*@__PURE__*/ InvalidMultiRegionClusterStateFault_base {
}
declare const InvalidNodeStateFault_base: S.TaggedErrorClass<"InvalidNodeStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNodeStateFault extends /*@__PURE__*/ InvalidNodeStateFault_base {
}
declare const InvalidParameterCombinationException_base: S.TaggedErrorClass<"InvalidParameterCombinationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterGroupStateFault_base: S.TaggedErrorClass<"InvalidParameterGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterGroupStateFault extends /*@__PURE__*/ InvalidParameterGroupStateFault_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidSnapshotStateFault_base: S.TaggedErrorClass<"InvalidSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSnapshotStateFault extends /*@__PURE__*/ InvalidSnapshotStateFault_base {
}
declare const InvalidSubnet_base: S.TaggedErrorClass<"InvalidSubnet", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnet extends /*@__PURE__*/ InvalidSubnet_base {
}
declare const InvalidUserStateFault_base: S.TaggedErrorClass<"InvalidUserStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidUserStateFault extends /*@__PURE__*/ InvalidUserStateFault_base {
}
declare const InvalidVPCNetworkStateFault_base: S.TaggedErrorClass<"InvalidVPCNetworkStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVPCNetworkStateFault extends /*@__PURE__*/ InvalidVPCNetworkStateFault_base {
}
declare const MultiRegionClusterAlreadyExistsFault_base: S.TaggedErrorClass<"MultiRegionClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class MultiRegionClusterAlreadyExistsFault extends /*@__PURE__*/ MultiRegionClusterAlreadyExistsFault_base {
}
declare const MultiRegionClusterNotFoundFault_base: S.TaggedErrorClass<"MultiRegionClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MultiRegionClusterNotFoundFault extends /*@__PURE__*/ MultiRegionClusterNotFoundFault_base {
}
declare const MultiRegionParameterGroupNotFoundFault_base: S.TaggedErrorClass<"MultiRegionParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MultiRegionParameterGroupNotFoundFault extends /*@__PURE__*/ MultiRegionParameterGroupNotFoundFault_base {
}
declare const NodeQuotaForClusterExceededFault_base: S.TaggedErrorClass<"NodeQuotaForClusterExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeQuotaForClusterExceededFault extends /*@__PURE__*/ NodeQuotaForClusterExceededFault_base {
}
declare const NodeQuotaForCustomerExceededFault_base: S.TaggedErrorClass<"NodeQuotaForCustomerExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeQuotaForCustomerExceededFault extends /*@__PURE__*/ NodeQuotaForCustomerExceededFault_base {
}
declare const NoOperationFault_base: S.TaggedErrorClass<"NoOperationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoOperationFault extends /*@__PURE__*/ NoOperationFault_base {
}
declare const ParameterGroupAlreadyExistsFault_base: S.TaggedErrorClass<"ParameterGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ParameterGroupAlreadyExistsFault extends /*@__PURE__*/ ParameterGroupAlreadyExistsFault_base {
}
declare const ParameterGroupNotFoundFault_base: S.TaggedErrorClass<"ParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ParameterGroupNotFoundFault extends /*@__PURE__*/ ParameterGroupNotFoundFault_base {
}
declare const ParameterGroupQuotaExceededFault_base: S.TaggedErrorClass<"ParameterGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ParameterGroupQuotaExceededFault extends /*@__PURE__*/ ParameterGroupQuotaExceededFault_base {
}
declare const ReservedNodeAlreadyExistsFault_base: S.TaggedErrorClass<"ReservedNodeAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReservedNodeAlreadyExistsFault extends /*@__PURE__*/ ReservedNodeAlreadyExistsFault_base {
}
declare const ReservedNodeNotFoundFault_base: S.TaggedErrorClass<"ReservedNodeNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedNodeNotFoundFault extends /*@__PURE__*/ ReservedNodeNotFoundFault_base {
}
declare const ReservedNodeQuotaExceededFault_base: S.TaggedErrorClass<"ReservedNodeQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedNodeQuotaExceededFault extends /*@__PURE__*/ ReservedNodeQuotaExceededFault_base {
}
declare const ReservedNodesOfferingNotFoundFault_base: S.TaggedErrorClass<"ReservedNodesOfferingNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedNodesOfferingNotFoundFault extends /*@__PURE__*/ ReservedNodesOfferingNotFoundFault_base {
}
declare const ServiceLinkedRoleNotFoundFault_base: S.TaggedErrorClass<"ServiceLinkedRoleNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceLinkedRoleNotFoundFault extends /*@__PURE__*/ ServiceLinkedRoleNotFoundFault_base {
}
declare const ServiceUpdateNotFoundFault_base: S.TaggedErrorClass<"ServiceUpdateNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceUpdateNotFoundFault extends /*@__PURE__*/ ServiceUpdateNotFoundFault_base {
}
declare const ShardNotFoundFault_base: S.TaggedErrorClass<"ShardNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ShardNotFoundFault extends /*@__PURE__*/ ShardNotFoundFault_base {
}
declare const ShardsPerClusterQuotaExceededFault_base: S.TaggedErrorClass<"ShardsPerClusterQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ShardsPerClusterQuotaExceededFault extends /*@__PURE__*/ ShardsPerClusterQuotaExceededFault_base {
}
declare const SnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"SnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class SnapshotAlreadyExistsFault extends /*@__PURE__*/ SnapshotAlreadyExistsFault_base {
}
declare const SnapshotNotFoundFault_base: S.TaggedErrorClass<"SnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotNotFoundFault extends /*@__PURE__*/ SnapshotNotFoundFault_base {
}
declare const SnapshotQuotaExceededFault_base: S.TaggedErrorClass<"SnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotQuotaExceededFault extends /*@__PURE__*/ SnapshotQuotaExceededFault_base {
}
declare const SubnetGroupAlreadyExistsFault_base: S.TaggedErrorClass<"SubnetGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class SubnetGroupAlreadyExistsFault extends /*@__PURE__*/ SubnetGroupAlreadyExistsFault_base {
}
declare const SubnetGroupInUseFault_base: S.TaggedErrorClass<"SubnetGroupInUseFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetGroupInUseFault extends /*@__PURE__*/ SubnetGroupInUseFault_base {
}
declare const SubnetGroupNotFoundFault_base: S.TaggedErrorClass<"SubnetGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetGroupNotFoundFault extends /*@__PURE__*/ SubnetGroupNotFoundFault_base {
}
declare const SubnetGroupQuotaExceededFault_base: S.TaggedErrorClass<"SubnetGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetGroupQuotaExceededFault extends /*@__PURE__*/ SubnetGroupQuotaExceededFault_base {
}
declare const SubnetInUse_base: S.TaggedErrorClass<"SubnetInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class SubnetInUse extends /*@__PURE__*/ SubnetInUse_base {
}
declare const SubnetNotAllowedFault_base: S.TaggedErrorClass<"SubnetNotAllowedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetNotAllowedFault extends /*@__PURE__*/ SubnetNotAllowedFault_base {
}
declare const SubnetQuotaExceededFault_base: S.TaggedErrorClass<"SubnetQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetQuotaExceededFault extends /*@__PURE__*/ SubnetQuotaExceededFault_base {
}
declare const TagNotFoundFault_base: S.TaggedErrorClass<"TagNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagNotFoundFault extends /*@__PURE__*/ TagNotFoundFault_base {
}
declare const TagQuotaPerResourceExceeded_base: S.TaggedErrorClass<"TagQuotaPerResourceExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagQuotaPerResourceExceeded extends /*@__PURE__*/ TagQuotaPerResourceExceeded_base {
}
declare const TestFailoverNotAvailableFault_base: S.TaggedErrorClass<"TestFailoverNotAvailableFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TestFailoverNotAvailableFault extends /*@__PURE__*/ TestFailoverNotAvailableFault_base {
}
declare const UserAlreadyExistsFault_base: S.TaggedErrorClass<"UserAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class UserAlreadyExistsFault extends /*@__PURE__*/ UserAlreadyExistsFault_base {
}
declare const UserNotFoundFault_base: S.TaggedErrorClass<"UserNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserNotFoundFault extends /*@__PURE__*/ UserNotFoundFault_base {
}
declare const UserQuotaExceededFault_base: S.TaggedErrorClass<"UserQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserQuotaExceededFault extends /*@__PURE__*/ UserQuotaExceededFault_base {
}
export type ClusterNameList = string[];
export interface ServiceUpdateRequest {
    ServiceUpdateNameToApply?: string;
}
export interface BatchUpdateClusterRequest {
    ClusterNames: string[];
    ServiceUpdate?: ServiceUpdateRequest;
}
export interface SlotMigration {
    ProgressPercentage?: number;
}
export interface ReshardingStatus {
    SlotMigration?: SlotMigration;
}
export type ACLName = string;
export interface ACLsUpdateStatus {
    ACLToApply?: string;
}
export type ServiceUpdateStatus = "available" | "in-progress" | "complete" | "scheduled" | (string & {});
export interface PendingModifiedServiceUpdate {
    ServiceUpdateName?: string;
    Status?: ServiceUpdateStatus;
}
export type PendingModifiedServiceUpdateList = PendingModifiedServiceUpdate[];
export interface ClusterPendingUpdates {
    Resharding?: ReshardingStatus;
    ACLs?: ACLsUpdateStatus;
    ServiceUpdates?: PendingModifiedServiceUpdate[];
}
export interface Endpoint {
    Address?: string;
    Port?: number;
}
export interface Node {
    Name?: string;
    Status?: string;
    AvailabilityZone?: string;
    CreateTime?: Date;
    Endpoint?: Endpoint;
}
export type NodeList = Node[];
export interface Shard {
    Name?: string;
    Status?: string;
    Slots?: string;
    Nodes?: Node[];
    NumberOfNodes?: number;
}
export type ShardList = Shard[];
export type AZStatus = "singleaz" | "multiaz" | (string & {});
export interface SecurityGroupMembership {
    SecurityGroupId?: string;
    Status?: string;
}
export type SecurityGroupMembershipList = SecurityGroupMembership[];
export type DataTieringStatus = "true" | "false" | (string & {});
export type NetworkType = "ipv4" | "ipv6" | "dual_stack" | (string & {});
export type IpDiscovery = "ipv4" | "ipv6" | (string & {});
export interface Cluster {
    Name?: string;
    Description?: string;
    Status?: string;
    PendingUpdates?: ClusterPendingUpdates;
    MultiRegionClusterName?: string;
    NumberOfShards?: number;
    Shards?: Shard[];
    AvailabilityMode?: AZStatus;
    ClusterEndpoint?: Endpoint;
    NodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    EnginePatchVersion?: string;
    ParameterGroupName?: string;
    ParameterGroupStatus?: string;
    SecurityGroups?: SecurityGroupMembership[];
    SubnetGroupName?: string;
    TLSEnabled?: boolean;
    KmsKeyId?: string;
    ARN?: string;
    SnsTopicArn?: string;
    SnsTopicStatus?: string;
    SnapshotRetentionLimit?: number;
    MaintenanceWindow?: string;
    SnapshotWindow?: string;
    ACLName?: string;
    AutoMinorVersionUpgrade?: boolean;
    DataTiering?: DataTieringStatus;
    NetworkType?: NetworkType;
    IpDiscovery?: IpDiscovery;
}
export type ClusterList = Cluster[];
export interface UnprocessedCluster {
    ClusterName?: string;
    ErrorType?: string;
    ErrorMessage?: string;
}
export type UnprocessedClusterList = UnprocessedCluster[];
export interface BatchUpdateClusterResponse {
    ProcessedClusters?: Cluster[];
    UnprocessedClusters?: UnprocessedCluster[];
}
export type TargetBucket = string;
export type KmsKeyId = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export type TagList = Tag[];
export interface CopySnapshotRequest {
    SourceSnapshotName: string;
    TargetSnapshotName: string;
    TargetBucket?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
}
export interface ShardConfiguration {
    Slots?: string;
    ReplicaCount?: number;
}
export interface ShardDetail {
    Name?: string;
    Configuration?: ShardConfiguration;
    Size?: string;
    SnapshotCreationTime?: Date;
}
export type ShardDetails = ShardDetail[];
export interface ClusterConfiguration {
    Name?: string;
    Description?: string;
    NodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    MaintenanceWindow?: string;
    TopicArn?: string;
    Port?: number;
    ParameterGroupName?: string;
    SubnetGroupName?: string;
    VpcId?: string;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    NumShards?: number;
    Shards?: ShardDetail[];
    MultiRegionParameterGroupName?: string;
    MultiRegionClusterName?: string;
}
export interface Snapshot {
    Name?: string;
    Status?: string;
    Source?: string;
    KmsKeyId?: string;
    ARN?: string;
    ClusterConfiguration?: ClusterConfiguration;
    DataTiering?: DataTieringStatus;
}
export interface CopySnapshotResponse {
    Snapshot?: Snapshot;
}
export type UserName = string;
export type UserNameListInput = string[];
export interface CreateACLRequest {
    ACLName: string;
    UserNames?: string[];
    Tags?: Tag[];
}
export type UserNameList = string[];
export interface ACLPendingChanges {
    UserNamesToRemove?: string[];
    UserNamesToAdd?: string[];
}
export type ACLClusterNameList = string[];
export interface ACL {
    Name?: string;
    Status?: string;
    UserNames?: string[];
    MinimumEngineVersion?: string;
    PendingChanges?: ACLPendingChanges;
    Clusters?: string[];
    ARN?: string;
}
export interface CreateACLResponse {
    ACL?: ACL;
}
export type SecurityGroupIdsList = string[];
export type SnapshotArnsList = string[];
export interface CreateClusterRequest {
    ClusterName: string;
    NodeType: string;
    MultiRegionClusterName?: string;
    ParameterGroupName?: string;
    Description?: string;
    NumShards?: number;
    NumReplicasPerShard?: number;
    SubnetGroupName?: string;
    SecurityGroupIds?: string[];
    MaintenanceWindow?: string;
    Port?: number;
    SnsTopicArn?: string;
    TLSEnabled?: boolean;
    KmsKeyId?: string;
    SnapshotArns?: string[];
    SnapshotName?: string;
    SnapshotRetentionLimit?: number;
    Tags?: Tag[];
    SnapshotWindow?: string;
    ACLName: string;
    Engine?: string;
    EngineVersion?: string;
    AutoMinorVersionUpgrade?: boolean;
    DataTiering?: boolean;
    NetworkType?: NetworkType;
    IpDiscovery?: IpDiscovery;
}
export interface CreateClusterResponse {
    Cluster?: Cluster;
}
export interface CreateMultiRegionClusterRequest {
    MultiRegionClusterNameSuffix: string;
    Description?: string;
    Engine?: string;
    EngineVersion?: string;
    NodeType: string;
    MultiRegionParameterGroupName?: string;
    NumShards?: number;
    TLSEnabled?: boolean;
    Tags?: Tag[];
}
export interface RegionalCluster {
    ClusterName?: string;
    Region?: string;
    Status?: string;
    ARN?: string;
}
export type RegionalClusterList = RegionalCluster[];
export interface MultiRegionCluster {
    MultiRegionClusterName?: string;
    Description?: string;
    Status?: string;
    NodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    NumberOfShards?: number;
    Clusters?: RegionalCluster[];
    MultiRegionParameterGroupName?: string;
    TLSEnabled?: boolean;
    ARN?: string;
}
export interface CreateMultiRegionClusterResponse {
    MultiRegionCluster?: MultiRegionCluster;
}
export interface CreateParameterGroupRequest {
    ParameterGroupName: string;
    Family: string;
    Description?: string;
    Tags?: Tag[];
}
export interface ParameterGroup {
    Name?: string;
    Family?: string;
    Description?: string;
    ARN?: string;
}
export interface CreateParameterGroupResponse {
    ParameterGroup?: ParameterGroup;
}
export interface CreateSnapshotRequest {
    ClusterName: string;
    SnapshotName: string;
    KmsKeyId?: string;
    Tags?: Tag[];
}
export interface CreateSnapshotResponse {
    Snapshot?: Snapshot;
}
export type SubnetIdentifierList = string[];
export interface CreateSubnetGroupRequest {
    SubnetGroupName: string;
    Description?: string;
    SubnetIds: string[];
    Tags?: Tag[];
}
export interface AvailabilityZone {
    Name?: string;
}
export type NetworkTypeList = NetworkType[];
export interface Subnet {
    Identifier?: string;
    AvailabilityZone?: AvailabilityZone;
    SupportedNetworkTypes?: NetworkType[];
}
export type SubnetList = Subnet[];
export interface SubnetGroup {
    Name?: string;
    Description?: string;
    VpcId?: string;
    Subnets?: Subnet[];
    ARN?: string;
    SupportedNetworkTypes?: NetworkType[];
}
export interface CreateSubnetGroupResponse {
    SubnetGroup?: SubnetGroup;
}
export type InputAuthenticationType = "password" | "iam" | (string & {});
export type PasswordListInput = string[];
export interface AuthenticationMode {
    Type?: InputAuthenticationType;
    Passwords?: Array<string | redacted.Redacted<string>>;
}
export type AccessString = string;
export interface CreateUserRequest {
    UserName: string;
    AuthenticationMode: AuthenticationMode;
    AccessString: string;
    Tags?: Tag[];
}
export type ACLNameList = string[];
export type AuthenticationType = "password" | "no-password" | "iam" | (string & {});
export interface Authentication {
    Type?: AuthenticationType;
    PasswordCount?: number;
}
export interface User {
    Name?: string;
    Status?: string;
    AccessString?: string;
    ACLNames?: string[];
    MinimumEngineVersion?: string;
    Authentication?: Authentication;
    ARN?: string;
}
export interface CreateUserResponse {
    User?: User;
}
export interface DeleteACLRequest {
    ACLName: string;
}
export interface DeleteACLResponse {
    ACL?: ACL;
}
export interface DeleteClusterRequest {
    ClusterName: string;
    MultiRegionClusterName?: string;
    FinalSnapshotName?: string;
}
export interface DeleteClusterResponse {
    Cluster?: Cluster;
}
export interface DeleteMultiRegionClusterRequest {
    MultiRegionClusterName: string;
}
export interface DeleteMultiRegionClusterResponse {
    MultiRegionCluster?: MultiRegionCluster;
}
export interface DeleteParameterGroupRequest {
    ParameterGroupName: string;
}
export interface DeleteParameterGroupResponse {
    ParameterGroup?: ParameterGroup;
}
export interface DeleteSnapshotRequest {
    SnapshotName: string;
}
export interface DeleteSnapshotResponse {
    Snapshot?: Snapshot;
}
export interface DeleteSubnetGroupRequest {
    SubnetGroupName: string;
}
export interface DeleteSubnetGroupResponse {
    SubnetGroup?: SubnetGroup;
}
export interface DeleteUserRequest {
    UserName: string;
}
export interface DeleteUserResponse {
    User?: User;
}
export interface DescribeACLsRequest {
    ACLName?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ACLList = ACL[];
export interface DescribeACLsResponse {
    ACLs?: ACL[];
    NextToken?: string;
}
export interface DescribeClustersRequest {
    ClusterName?: string;
    MaxResults?: number;
    NextToken?: string;
    ShowShardDetails?: boolean;
}
export interface DescribeClustersResponse {
    NextToken?: string;
    Clusters?: Cluster[];
}
export interface DescribeEngineVersionsRequest {
    Engine?: string;
    EngineVersion?: string;
    ParameterGroupFamily?: string;
    MaxResults?: number;
    NextToken?: string;
    DefaultOnly?: boolean;
}
export interface EngineVersionInfo {
    Engine?: string;
    EngineVersion?: string;
    EnginePatchVersion?: string;
    ParameterGroupFamily?: string;
}
export type EngineVersionInfoList = EngineVersionInfo[];
export interface DescribeEngineVersionsResponse {
    NextToken?: string;
    EngineVersions?: EngineVersionInfo[];
}
export type SourceType = "node" | "parameter-group" | "subnet-group" | "cluster" | "user" | "acl" | (string & {});
export interface DescribeEventsRequest {
    SourceName?: string;
    SourceType?: SourceType;
    StartTime?: Date;
    EndTime?: Date;
    Duration?: number;
    MaxResults?: number;
    NextToken?: string;
}
export interface Event {
    SourceName?: string;
    SourceType?: SourceType;
    Message?: string;
    Date?: Date;
}
export type EventList = Event[];
export interface DescribeEventsResponse {
    NextToken?: string;
    Events?: Event[];
}
export interface DescribeMultiRegionClustersRequest {
    MultiRegionClusterName?: string;
    MaxResults?: number;
    NextToken?: string;
    ShowClusterDetails?: boolean;
}
export type MultiRegionClusterList = MultiRegionCluster[];
export interface DescribeMultiRegionClustersResponse {
    NextToken?: string;
    MultiRegionClusters?: MultiRegionCluster[];
}
export interface DescribeMultiRegionParameterGroupsRequest {
    MultiRegionParameterGroupName?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface MultiRegionParameterGroup {
    Name?: string;
    Family?: string;
    Description?: string;
    ARN?: string;
}
export type MultiRegionParameterGroupList = MultiRegionParameterGroup[];
export interface DescribeMultiRegionParameterGroupsResponse {
    NextToken?: string;
    MultiRegionParameterGroups?: MultiRegionParameterGroup[];
}
export interface DescribeMultiRegionParametersRequest {
    MultiRegionParameterGroupName: string;
    Source?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface MultiRegionParameter {
    Name?: string;
    Value?: string;
    Description?: string;
    Source?: string;
    DataType?: string;
    AllowedValues?: string;
    MinimumEngineVersion?: string;
}
export type MultiRegionParametersList = MultiRegionParameter[];
export interface DescribeMultiRegionParametersResponse {
    NextToken?: string;
    MultiRegionParameters?: MultiRegionParameter[];
}
export interface DescribeParameterGroupsRequest {
    ParameterGroupName?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ParameterGroupList = ParameterGroup[];
export interface DescribeParameterGroupsResponse {
    NextToken?: string;
    ParameterGroups?: ParameterGroup[];
}
export interface DescribeParametersRequest {
    ParameterGroupName: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface Parameter {
    Name?: string;
    Value?: string;
    Description?: string;
    DataType?: string;
    AllowedValues?: string;
    MinimumEngineVersion?: string;
}
export type ParametersList = Parameter[];
export interface DescribeParametersResponse {
    NextToken?: string;
    Parameters?: Parameter[];
}
export interface DescribeReservedNodesRequest {
    ReservationId?: string;
    ReservedNodesOfferingId?: string;
    NodeType?: string;
    Duration?: string;
    OfferingType?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface RecurringCharge {
    RecurringChargeAmount?: number;
    RecurringChargeFrequency?: string;
}
export type RecurringChargeList = RecurringCharge[];
export interface ReservedNode {
    ReservationId?: string;
    ReservedNodesOfferingId?: string;
    NodeType?: string;
    StartTime?: Date;
    Duration?: number;
    FixedPrice?: number;
    NodeCount?: number;
    OfferingType?: string;
    State?: string;
    RecurringCharges?: RecurringCharge[];
    ARN?: string;
}
export type ReservedNodeList = ReservedNode[];
export interface DescribeReservedNodesResponse {
    NextToken?: string;
    ReservedNodes?: ReservedNode[];
}
export interface DescribeReservedNodesOfferingsRequest {
    ReservedNodesOfferingId?: string;
    NodeType?: string;
    Duration?: string;
    OfferingType?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ReservedNodesOffering {
    ReservedNodesOfferingId?: string;
    NodeType?: string;
    Duration?: number;
    FixedPrice?: number;
    OfferingType?: string;
    RecurringCharges?: RecurringCharge[];
}
export type ReservedNodesOfferingList = ReservedNodesOffering[];
export interface DescribeReservedNodesOfferingsResponse {
    NextToken?: string;
    ReservedNodesOfferings?: ReservedNodesOffering[];
}
export type ServiceUpdateStatusList = ServiceUpdateStatus[];
export interface DescribeServiceUpdatesRequest {
    ServiceUpdateName?: string;
    ClusterNames?: string[];
    Status?: ServiceUpdateStatus[];
    MaxResults?: number;
    NextToken?: string;
}
export type ServiceUpdateType = "security-update" | (string & {});
export interface ServiceUpdate {
    ClusterName?: string;
    ServiceUpdateName?: string;
    ReleaseDate?: Date;
    Description?: string;
    Status?: ServiceUpdateStatus;
    Type?: ServiceUpdateType;
    Engine?: string;
    NodesUpdated?: string;
    AutoUpdateStartDate?: Date;
}
export type ServiceUpdateList = ServiceUpdate[];
export interface DescribeServiceUpdatesResponse {
    NextToken?: string;
    ServiceUpdates?: ServiceUpdate[];
}
export interface DescribeSnapshotsRequest {
    ClusterName?: string;
    SnapshotName?: string;
    Source?: string;
    NextToken?: string;
    MaxResults?: number;
    ShowDetail?: boolean;
}
export type SnapshotList = Snapshot[];
export interface DescribeSnapshotsResponse {
    NextToken?: string;
    Snapshots?: Snapshot[];
}
export interface DescribeSubnetGroupsRequest {
    SubnetGroupName?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type SubnetGroupList = SubnetGroup[];
export interface DescribeSubnetGroupsResponse {
    NextToken?: string;
    SubnetGroups?: SubnetGroup[];
}
export type FilterName = string;
export type FilterValue = string;
export type FilterValueList = string[];
export interface Filter {
    Name: string;
    Values: string[];
}
export type FilterList = Filter[];
export interface DescribeUsersRequest {
    UserName?: string;
    Filters?: Filter[];
    MaxResults?: number;
    NextToken?: string;
}
export type UserList = User[];
export interface DescribeUsersResponse {
    Users?: User[];
    NextToken?: string;
}
export interface FailoverShardRequest {
    ClusterName: string;
    ShardName: string;
}
export interface FailoverShardResponse {
    Cluster?: Cluster;
}
export interface ListAllowedMultiRegionClusterUpdatesRequest {
    MultiRegionClusterName: string;
}
export type NodeTypeList = string[];
export interface ListAllowedMultiRegionClusterUpdatesResponse {
    ScaleUpNodeTypes?: string[];
    ScaleDownNodeTypes?: string[];
}
export interface ListAllowedNodeTypeUpdatesRequest {
    ClusterName: string;
}
export interface ListAllowedNodeTypeUpdatesResponse {
    ScaleUpNodeTypes?: string[];
    ScaleDownNodeTypes?: string[];
}
export interface ListTagsRequest {
    ResourceArn: string;
}
export interface ListTagsResponse {
    TagList?: Tag[];
}
export interface PurchaseReservedNodesOfferingRequest {
    ReservedNodesOfferingId: string;
    ReservationId?: string;
    NodeCount?: number;
    Tags?: Tag[];
}
export interface PurchaseReservedNodesOfferingResponse {
    ReservedNode?: ReservedNode;
}
export type ParameterNameList = string[];
export interface ResetParameterGroupRequest {
    ParameterGroupName: string;
    AllParameters?: boolean;
    ParameterNames?: string[];
}
export interface ResetParameterGroupResponse {
    ParameterGroup?: ParameterGroup;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
    TagList?: Tag[];
}
export type KeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
    TagList?: Tag[];
}
export interface UpdateACLRequest {
    ACLName: string;
    UserNamesToAdd?: string[];
    UserNamesToRemove?: string[];
}
export interface UpdateACLResponse {
    ACL?: ACL;
}
export interface ReplicaConfigurationRequest {
    ReplicaCount?: number;
}
export interface ShardConfigurationRequest {
    ShardCount?: number;
}
export interface UpdateClusterRequest {
    ClusterName: string;
    Description?: string;
    SecurityGroupIds?: string[];
    MaintenanceWindow?: string;
    SnsTopicArn?: string;
    SnsTopicStatus?: string;
    ParameterGroupName?: string;
    SnapshotWindow?: string;
    SnapshotRetentionLimit?: number;
    NodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    ReplicaConfiguration?: ReplicaConfigurationRequest;
    ShardConfiguration?: ShardConfigurationRequest;
    ACLName?: string;
    IpDiscovery?: IpDiscovery;
}
export interface UpdateClusterResponse {
    Cluster?: Cluster;
}
export type UpdateStrategy = "coordinated" | "uncoordinated" | (string & {});
export interface UpdateMultiRegionClusterRequest {
    MultiRegionClusterName: string;
    NodeType?: string;
    Description?: string;
    EngineVersion?: string;
    ShardConfiguration?: ShardConfigurationRequest;
    MultiRegionParameterGroupName?: string;
    UpdateStrategy?: UpdateStrategy;
}
export interface UpdateMultiRegionClusterResponse {
    MultiRegionCluster?: MultiRegionCluster;
}
export interface ParameterNameValue {
    ParameterName?: string;
    ParameterValue?: string;
}
export type ParameterNameValueList = ParameterNameValue[];
export interface UpdateParameterGroupRequest {
    ParameterGroupName: string;
    ParameterNameValues: ParameterNameValue[];
}
export interface UpdateParameterGroupResponse {
    ParameterGroup?: ParameterGroup;
}
export interface UpdateSubnetGroupRequest {
    SubnetGroupName: string;
    Description?: string;
    SubnetIds?: string[];
}
export interface UpdateSubnetGroupResponse {
    SubnetGroup?: SubnetGroup;
}
export interface UpdateUserRequest {
    UserName: string;
    AuthenticationMode?: AuthenticationMode;
    AccessString?: string;
}
export interface UpdateUserResponse {
    User?: User;
}
export type AwsQueryErrorMessage = string;
export type ExceptionMessage = string;
export type BatchUpdateClusterError = InvalidParameterValueException | ServiceUpdateNotFoundFault | InvalidParameterCombinationException | CommonErrors;
/**
 * Apply the service update to a list of clusters supplied. For more information on service updates and applying them, see Applying the service updates.
 */
export declare const batchUpdateCluster: API.OperationMethod<BatchUpdateClusterRequest, BatchUpdateClusterResponse, BatchUpdateClusterError, Credentials | HttpClient.HttpClient>;
export type CopySnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidSnapshotStateFault | ServiceLinkedRoleNotFoundFault | SnapshotAlreadyExistsFault | SnapshotNotFoundFault | SnapshotQuotaExceededFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Makes a copy of an existing snapshot.
 */
export declare const copySnapshot: API.OperationMethod<CopySnapshotRequest, CopySnapshotResponse, CopySnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateACLError = ACLAlreadyExistsFault | ACLQuotaExceededFault | DefaultUserRequired | DuplicateUserNameFault | InvalidParameterValueException | TagQuotaPerResourceExceeded | UserNotFoundFault | CommonErrors;
/**
 * Creates an Access Control List. For more information, see Authenticating users with Access Contol Lists (ACLs).
 */
export declare const createACL: API.OperationMethod<CreateACLRequest, CreateACLResponse, CreateACLError, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = ACLNotFoundFault | ClusterAlreadyExistsFault | ClusterQuotaForCustomerExceededFault | InsufficientClusterCapacityFault | InvalidACLStateFault | InvalidCredentialsException | InvalidMultiRegionClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidVPCNetworkStateFault | MultiRegionClusterNotFoundFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | ShardsPerClusterQuotaExceededFault | SubnetGroupNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a cluster. All nodes in the cluster run the same protocol-compliant engine software.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest, CreateClusterResponse, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateMultiRegionClusterError = ClusterQuotaForCustomerExceededFault | InvalidParameterCombinationException | InvalidParameterValueException | MultiRegionClusterAlreadyExistsFault | MultiRegionParameterGroupNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a new multi-Region cluster.
 */
export declare const createMultiRegionCluster: API.OperationMethod<CreateMultiRegionClusterRequest, CreateMultiRegionClusterResponse, CreateMultiRegionClusterError, Credentials | HttpClient.HttpClient>;
export type CreateParameterGroupError = InvalidParameterCombinationException | InvalidParameterGroupStateFault | InvalidParameterValueException | ParameterGroupAlreadyExistsFault | ParameterGroupQuotaExceededFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a new MemoryDB parameter group. A parameter group is a collection of parameters and their values that are applied to all of the nodes in any cluster. For
 * more information, see Configuring engine parameters using parameter groups.
 */
export declare const createParameterGroup: API.OperationMethod<CreateParameterGroupRequest, CreateParameterGroupResponse, CreateParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotError = ClusterNotFoundFault | InvalidClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | SnapshotAlreadyExistsFault | SnapshotQuotaExceededFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a copy of an entire cluster at a specific moment in time.
 */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotRequest, CreateSnapshotResponse, CreateSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateSubnetGroupError = InvalidSubnet | ServiceLinkedRoleNotFoundFault | SubnetGroupAlreadyExistsFault | SubnetGroupQuotaExceededFault | SubnetNotAllowedFault | SubnetQuotaExceededFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a subnet group. A subnet group is a collection of subnets (typically private) that you can designate for your clusters running in an Amazon Virtual Private Cloud (VPC) environment.
 *
 * When you create a cluster in an Amazon VPC, you must specify a subnet group. MemoryDB uses that subnet group to choose a subnet and IP addresses within that subnet to associate with your nodes.
 * For more information, see Subnets and subnet groups.
 */
export declare const createSubnetGroup: API.OperationMethod<CreateSubnetGroupRequest, CreateSubnetGroupResponse, CreateSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = DuplicateUserNameFault | InvalidParameterCombinationException | InvalidParameterValueException | TagQuotaPerResourceExceeded | UserAlreadyExistsFault | UserQuotaExceededFault | CommonErrors;
/**
 * Creates a MemoryDB user. For more information, see Authenticating users with Access Contol Lists (ACLs).
 */
export declare const createUser: API.OperationMethod<CreateUserRequest, CreateUserResponse, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteACLError = ACLNotFoundFault | InvalidACLStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Deletes an Access Control List. The ACL must first be disassociated from the cluster before it can be deleted. For more information, see Authenticating users with Access Contol Lists (ACLs).
 */
export declare const deleteACL: API.OperationMethod<DeleteACLRequest, DeleteACLResponse, DeleteACLError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = ClusterNotFoundFault | InvalidClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | SnapshotAlreadyExistsFault | CommonErrors;
/**
 * Deletes a cluster. It also deletes all associated nodes and node endpoints.
 *
 * `CreateSnapshot` permission is required to create a final snapshot.
 * Without this permission, the API call will fail with an `Access Denied` exception.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterRequest, DeleteClusterResponse, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteMultiRegionClusterError = InvalidMultiRegionClusterStateFault | InvalidParameterValueException | MultiRegionClusterNotFoundFault | CommonErrors;
/**
 * Deletes an existing multi-Region cluster.
 */
export declare const deleteMultiRegionCluster: API.OperationMethod<DeleteMultiRegionClusterRequest, DeleteMultiRegionClusterResponse, DeleteMultiRegionClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteParameterGroupError = InvalidParameterCombinationException | InvalidParameterGroupStateFault | InvalidParameterValueException | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Deletes the specified parameter group. You cannot delete a parameter group if it is associated with any clusters.
 * You cannot delete the default parameter groups in your account.
 */
export declare const deleteParameterGroup: API.OperationMethod<DeleteParameterGroupRequest, DeleteParameterGroupResponse, DeleteParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidSnapshotStateFault | ServiceLinkedRoleNotFoundFault | SnapshotNotFoundFault | CommonErrors;
/**
 * Deletes an existing snapshot. When you receive a successful response from this operation, MemoryDB immediately begins deleting the snapshot; you cannot cancel or revert this operation.
 */
export declare const deleteSnapshot: API.OperationMethod<DeleteSnapshotRequest, DeleteSnapshotResponse, DeleteSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteSubnetGroupError = ServiceLinkedRoleNotFoundFault | SubnetGroupInUseFault | SubnetGroupNotFoundFault | CommonErrors;
/**
 * Deletes a subnet group. You cannot delete a default subnet group or one that is associated with any clusters.
 */
export declare const deleteSubnetGroup: API.OperationMethod<DeleteSubnetGroupRequest, DeleteSubnetGroupResponse, DeleteSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = InvalidParameterValueException | InvalidUserStateFault | UserNotFoundFault | CommonErrors;
/**
 * Deletes a user. The user will be removed from all ACLs and in turn removed from all clusters.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DescribeACLsError = ACLNotFoundFault | InvalidParameterCombinationException | CommonErrors;
/**
 * Returns a list of ACLs.
 */
export declare const describeACLs: API.PaginatedOperationMethod<DescribeACLsRequest, DescribeACLsResponse, DescribeACLsError, Credentials | HttpClient.HttpClient, ACL>;
export type DescribeClustersError = ClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns information about all provisioned clusters if no cluster identifier is specified, or about a specific cluster if a cluster name is supplied.
 */
export declare const describeClusters: API.PaginatedOperationMethod<DescribeClustersRequest, DescribeClustersResponse, DescribeClustersError, Credentials | HttpClient.HttpClient, Cluster>;
export type DescribeEngineVersionsError = InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns a list of the available Redis OSS engine versions.
 */
export declare const describeEngineVersions: API.PaginatedOperationMethod<DescribeEngineVersionsRequest, DescribeEngineVersionsResponse, DescribeEngineVersionsError, Credentials | HttpClient.HttpClient, EngineVersionInfo>;
export type DescribeEventsError = InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns events related to clusters, security groups, and parameter groups. You can obtain events specific to a particular cluster, security group, or parameter group by providing the name as a parameter.
 *
 * By default, only the events occurring within the last hour are returned; however, you can retrieve up to 14 days' worth of events if necessary.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsRequest, DescribeEventsResponse, DescribeEventsError, Credentials | HttpClient.HttpClient, Event>;
export type DescribeMultiRegionClustersError = ClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | MultiRegionClusterNotFoundFault | CommonErrors;
/**
 * Returns details about one or more multi-Region clusters.
 */
export declare const describeMultiRegionClusters: API.PaginatedOperationMethod<DescribeMultiRegionClustersRequest, DescribeMultiRegionClustersResponse, DescribeMultiRegionClustersError, Credentials | HttpClient.HttpClient, MultiRegionCluster>;
export type DescribeMultiRegionParameterGroupsError = InvalidParameterCombinationException | InvalidParameterValueException | MultiRegionParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns a list of multi-region parameter groups.
 */
export declare const describeMultiRegionParameterGroups: API.OperationMethod<DescribeMultiRegionParameterGroupsRequest, DescribeMultiRegionParameterGroupsResponse, DescribeMultiRegionParameterGroupsError, Credentials | HttpClient.HttpClient>;
export type DescribeMultiRegionParametersError = InvalidParameterCombinationException | InvalidParameterValueException | MultiRegionParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns the detailed parameter list for a particular multi-region parameter group.
 */
export declare const describeMultiRegionParameters: API.OperationMethod<DescribeMultiRegionParametersRequest, DescribeMultiRegionParametersResponse, DescribeMultiRegionParametersError, Credentials | HttpClient.HttpClient>;
export type DescribeParameterGroupsError = InvalidParameterCombinationException | InvalidParameterValueException | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns a list of parameter group descriptions. If a parameter group name is specified, the list contains only the descriptions for that group.
 */
export declare const describeParameterGroups: API.PaginatedOperationMethod<DescribeParameterGroupsRequest, DescribeParameterGroupsResponse, DescribeParameterGroupsError, Credentials | HttpClient.HttpClient, ParameterGroup>;
export type DescribeParametersError = InvalidParameterCombinationException | InvalidParameterValueException | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns the detailed parameter list for a particular parameter group.
 */
export declare const describeParameters: API.PaginatedOperationMethod<DescribeParametersRequest, DescribeParametersResponse, DescribeParametersError, Credentials | HttpClient.HttpClient, Parameter>;
export type DescribeReservedNodesError = InvalidParameterCombinationException | InvalidParameterValueException | ReservedNodeNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns information about reserved nodes for this account, or about a specified reserved node.
 */
export declare const describeReservedNodes: API.PaginatedOperationMethod<DescribeReservedNodesRequest, DescribeReservedNodesResponse, DescribeReservedNodesError, Credentials | HttpClient.HttpClient, ReservedNode>;
export type DescribeReservedNodesOfferingsError = InvalidParameterCombinationException | InvalidParameterValueException | ReservedNodesOfferingNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Lists available reserved node offerings.
 */
export declare const describeReservedNodesOfferings: API.PaginatedOperationMethod<DescribeReservedNodesOfferingsRequest, DescribeReservedNodesOfferingsResponse, DescribeReservedNodesOfferingsError, Credentials | HttpClient.HttpClient, ReservedNodesOffering>;
export type DescribeServiceUpdatesError = InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns details of the service updates.
 */
export declare const describeServiceUpdates: API.PaginatedOperationMethod<DescribeServiceUpdatesRequest, DescribeServiceUpdatesResponse, DescribeServiceUpdatesError, Credentials | HttpClient.HttpClient, ServiceUpdate>;
export type DescribeSnapshotsError = InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | SnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about cluster snapshots. By default, DescribeSnapshots lists all of your snapshots; it can optionally describe a single snapshot,
 * or just the snapshots associated with a particular cluster.
 */
export declare const describeSnapshots: API.PaginatedOperationMethod<DescribeSnapshotsRequest, DescribeSnapshotsResponse, DescribeSnapshotsError, Credentials | HttpClient.HttpClient, Snapshot>;
export type DescribeSubnetGroupsError = ServiceLinkedRoleNotFoundFault | SubnetGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of subnet group descriptions. If a subnet group name is specified, the list contains only the description of that group.
 */
export declare const describeSubnetGroups: API.PaginatedOperationMethod<DescribeSubnetGroupsRequest, DescribeSubnetGroupsResponse, DescribeSubnetGroupsError, Credentials | HttpClient.HttpClient, SubnetGroup>;
export type DescribeUsersError = InvalidParameterCombinationException | UserNotFoundFault | CommonErrors;
/**
 * Returns a list of users.
 */
export declare const describeUsers: API.PaginatedOperationMethod<DescribeUsersRequest, DescribeUsersResponse, DescribeUsersError, Credentials | HttpClient.HttpClient, User>;
export type FailoverShardError = APICallRateForCustomerExceededFault | ClusterNotFoundFault | InvalidClusterStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | ShardNotFoundFault | TestFailoverNotAvailableFault | CommonErrors;
/**
 * Used to failover a shard. This API is designed for testing the behavior of your application in case of MemoryDB failover. It is not designed to be used as a production-level tool for initiating
 * a failover to overcome a problem you may have with the cluster. Moreover, in certain conditions such as large scale operational events, Amazon may block this API.
 */
export declare const failoverShard: API.OperationMethod<FailoverShardRequest, FailoverShardResponse, FailoverShardError, Credentials | HttpClient.HttpClient>;
export type ListAllowedMultiRegionClusterUpdatesError = InvalidParameterCombinationException | InvalidParameterValueException | MultiRegionClusterNotFoundFault | CommonErrors;
/**
 * Lists the allowed updates for a multi-Region cluster.
 */
export declare const listAllowedMultiRegionClusterUpdates: API.OperationMethod<ListAllowedMultiRegionClusterUpdatesRequest, ListAllowedMultiRegionClusterUpdatesResponse, ListAllowedMultiRegionClusterUpdatesError, Credentials | HttpClient.HttpClient>;
export type ListAllowedNodeTypeUpdatesError = ClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Lists all available node types that you can scale to from your cluster's current node type.
 *
 * When you use the UpdateCluster operation to scale your cluster, the value of the NodeType parameter must be one of the node types returned by this operation.
 */
export declare const listAllowedNodeTypeUpdates: API.OperationMethod<ListAllowedNodeTypeUpdatesRequest, ListAllowedNodeTypeUpdatesResponse, ListAllowedNodeTypeUpdatesError, Credentials | HttpClient.HttpClient>;
export type ListTagsError = ACLNotFoundFault | ClusterNotFoundFault | InvalidARNFault | InvalidClusterStateFault | MultiRegionClusterNotFoundFault | MultiRegionParameterGroupNotFoundFault | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | SnapshotNotFoundFault | SubnetGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Lists all tags currently on a named resource. A tag is a key-value pair where the key and value are case-sensitive. You can use tags to categorize and track your MemoryDB resources. For more information, see Tagging your MemoryDB resources.
 *
 * When you add or remove tags from multi region clusters, you might not immediately see the latest effective tags in the ListTags API response due to it being eventually consistent specifically for multi region clusters. For more information, see Tagging your MemoryDB resources.
 */
export declare const listTags: API.OperationMethod<ListTagsRequest, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient>;
export type PurchaseReservedNodesOfferingError = InvalidParameterCombinationException | InvalidParameterValueException | ReservedNodeAlreadyExistsFault | ReservedNodeQuotaExceededFault | ReservedNodesOfferingNotFoundFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Allows you to purchase a reserved node offering. Reserved nodes are not eligible for cancellation and are non-refundable.
 */
export declare const purchaseReservedNodesOffering: API.OperationMethod<PurchaseReservedNodesOfferingRequest, PurchaseReservedNodesOfferingResponse, PurchaseReservedNodesOfferingError, Credentials | HttpClient.HttpClient>;
export type ResetParameterGroupError = InvalidParameterCombinationException | InvalidParameterGroupStateFault | InvalidParameterValueException | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Modifies the parameters of a parameter group to the engine or system default value. You can reset specific parameters by submitting a list of parameter names. To reset the entire parameter group, specify the AllParameters and ParameterGroupName parameters.
 */
export declare const resetParameterGroup: API.OperationMethod<ResetParameterGroupRequest, ResetParameterGroupResponse, ResetParameterGroupError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ACLNotFoundFault | ClusterNotFoundFault | InvalidARNFault | InvalidClusterStateFault | InvalidParameterValueException | MultiRegionClusterNotFoundFault | MultiRegionParameterGroupNotFoundFault | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | SnapshotNotFoundFault | SubnetGroupNotFoundFault | TagQuotaPerResourceExceeded | UserNotFoundFault | CommonErrors;
/**
 * Use this operation to add tags to a resource. A tag is a key-value pair where the key and value are case-sensitive. You can use tags to categorize and track all your MemoryDB resources. For more information, see Tagging your MemoryDB resources.
 *
 * When you add tags to multi region clusters, you might not immediately see the latest effective tags in the ListTags API response due to it being eventually consistent specifically for multi region clusters. For more information, see Tagging your MemoryDB resources.
 *
 * You can specify cost-allocation tags for your MemoryDB resources, Amazon generates a cost allocation report as a comma-separated value
 * (CSV) file with your usage and costs aggregated by your tags. You can apply tags that represent business categories
 * (such as cost centers, application names, or owners) to organize your costs across multiple services.
 *
 * For more information, see Using Cost Allocation Tags.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ACLNotFoundFault | ClusterNotFoundFault | InvalidARNFault | InvalidClusterStateFault | InvalidParameterValueException | MultiRegionClusterNotFoundFault | MultiRegionParameterGroupNotFoundFault | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | SnapshotNotFoundFault | SubnetGroupNotFoundFault | TagNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Use this operation to remove tags on a resource. A tag is a key-value pair where the key and value are case-sensitive. You can use tags to categorize and track all your MemoryDB resources. For more information, see Tagging your MemoryDB resources.
 *
 * When you remove tags from multi region clusters, you might not immediately see the latest effective tags in the ListTags API response due to it being eventually consistent specifically for multi region clusters. For more information, see Tagging your MemoryDB resources.
 *
 * You can specify cost-allocation tags for your MemoryDB resources, Amazon generates a cost allocation report as a comma-separated value
 * (CSV) file with your usage and costs aggregated by your tags. You can apply tags that represent business categories
 * (such as cost centers, application names, or owners) to organize your costs across multiple services.
 *
 * For more information, see Using Cost Allocation Tags.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateACLError = ACLNotFoundFault | DefaultUserRequired | DuplicateUserNameFault | InvalidACLStateFault | InvalidParameterCombinationException | InvalidParameterValueException | UserNotFoundFault | CommonErrors;
/**
 * Changes the list of users that belong to the Access Control List.
 */
export declare const updateACL: API.OperationMethod<UpdateACLRequest, UpdateACLResponse, UpdateACLError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterError = ACLNotFoundFault | ClusterNotFoundFault | ClusterQuotaForCustomerExceededFault | InvalidACLStateFault | InvalidClusterStateFault | InvalidKMSKeyFault | InvalidNodeStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidVPCNetworkStateFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | NoOperationFault | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | ShardsPerClusterQuotaExceededFault | CommonErrors;
/**
 * Modifies the settings for a cluster. You can use this operation to change one or more cluster configuration settings by specifying the settings and the new values.
 */
export declare const updateCluster: API.OperationMethod<UpdateClusterRequest, UpdateClusterResponse, UpdateClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateMultiRegionClusterError = InvalidMultiRegionClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | MultiRegionClusterNotFoundFault | MultiRegionParameterGroupNotFoundFault | CommonErrors;
/**
 * Updates the configuration of an existing multi-Region cluster.
 */
export declare const updateMultiRegionCluster: API.OperationMethod<UpdateMultiRegionClusterRequest, UpdateMultiRegionClusterResponse, UpdateMultiRegionClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateParameterGroupError = InvalidParameterCombinationException | InvalidParameterGroupStateFault | InvalidParameterValueException | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Updates the parameters of a parameter group. You can modify up to 20 parameters in a single request by submitting a list parameter name and value pairs.
 */
export declare const updateParameterGroup: API.OperationMethod<UpdateParameterGroupRequest, UpdateParameterGroupResponse, UpdateParameterGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateSubnetGroupError = InvalidSubnet | ServiceLinkedRoleNotFoundFault | SubnetGroupNotFoundFault | SubnetInUse | SubnetNotAllowedFault | SubnetQuotaExceededFault | CommonErrors;
/**
 * Updates a subnet group. For more information, see Updating a subnet group
 */
export declare const updateSubnetGroup: API.OperationMethod<UpdateSubnetGroupRequest, UpdateSubnetGroupResponse, UpdateSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidUserStateFault | UserNotFoundFault | CommonErrors;
/**
 * Changes user password(s) and/or access string.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=memorydb.d.ts.map