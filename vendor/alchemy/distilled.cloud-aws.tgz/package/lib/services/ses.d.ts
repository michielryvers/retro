import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccountSendingPausedException_base: S.TaggedErrorClass<"AccountSendingPausedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountSendingPausedException extends /*@__PURE__*/ AccountSendingPausedException_base {
}
declare const AlreadyExistsException_base: S.TaggedErrorClass<"AlreadyExistsException", {
    readonly Name: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const CannotDeleteException_base: S.TaggedErrorClass<"CannotDeleteException", {
    readonly Name: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CannotDeleteException extends /*@__PURE__*/ CannotDeleteException_base {
}
declare const ConfigurationSetAlreadyExistsException_base: S.TaggedErrorClass<"ConfigurationSetAlreadyExistsException", {
    readonly ConfigurationSetName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ConfigurationSetAlreadyExistsException extends /*@__PURE__*/ ConfigurationSetAlreadyExistsException_base {
}
declare const ConfigurationSetDoesNotExistException_base: S.TaggedErrorClass<"ConfigurationSetDoesNotExistException", {
    readonly ConfigurationSetName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConfigurationSetDoesNotExistException extends /*@__PURE__*/ ConfigurationSetDoesNotExistException_base {
}
declare const ConfigurationSetSendingPausedException_base: S.TaggedErrorClass<"ConfigurationSetSendingPausedException", {
    readonly ConfigurationSetName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConfigurationSetSendingPausedException extends /*@__PURE__*/ ConfigurationSetSendingPausedException_base {
}
declare const CustomVerificationEmailInvalidContentException_base: S.TaggedErrorClass<"CustomVerificationEmailInvalidContentException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CustomVerificationEmailInvalidContentException extends /*@__PURE__*/ CustomVerificationEmailInvalidContentException_base {
}
declare const CustomVerificationEmailTemplateAlreadyExistsException_base: S.TaggedErrorClass<"CustomVerificationEmailTemplateAlreadyExistsException", {
    readonly CustomVerificationEmailTemplateName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CustomVerificationEmailTemplateAlreadyExistsException extends /*@__PURE__*/ CustomVerificationEmailTemplateAlreadyExistsException_base {
}
declare const CustomVerificationEmailTemplateDoesNotExistException_base: S.TaggedErrorClass<"CustomVerificationEmailTemplateDoesNotExistException", {
    readonly CustomVerificationEmailTemplateName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CustomVerificationEmailTemplateDoesNotExistException extends /*@__PURE__*/ CustomVerificationEmailTemplateDoesNotExistException_base {
}
declare const EventDestinationAlreadyExistsException_base: S.TaggedErrorClass<"EventDestinationAlreadyExistsException", {
    readonly ConfigurationSetName: any;
    readonly EventDestinationName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EventDestinationAlreadyExistsException extends /*@__PURE__*/ EventDestinationAlreadyExistsException_base {
}
declare const EventDestinationDoesNotExistException_base: S.TaggedErrorClass<"EventDestinationDoesNotExistException", {
    readonly ConfigurationSetName: any;
    readonly EventDestinationName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDestinationDoesNotExistException extends /*@__PURE__*/ EventDestinationDoesNotExistException_base {
}
declare const FromEmailAddressNotVerifiedException_base: S.TaggedErrorClass<"FromEmailAddressNotVerifiedException", {
    readonly FromEmailAddress: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FromEmailAddressNotVerifiedException extends /*@__PURE__*/ FromEmailAddressNotVerifiedException_base {
}
declare const IdentityNotVerified_base: S.TaggedErrorClass<"IdentityNotVerified", {
    readonly message: any;
}>;
export declare class IdentityNotVerified extends /*@__PURE__*/ IdentityNotVerified_base {
}
declare const InvalidCloudWatchDestinationException_base: S.TaggedErrorClass<"InvalidCloudWatchDestinationException", {
    readonly ConfigurationSetName: any;
    readonly EventDestinationName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCloudWatchDestinationException extends /*@__PURE__*/ InvalidCloudWatchDestinationException_base {
}
declare const InvalidConfigurationSetException_base: S.TaggedErrorClass<"InvalidConfigurationSetException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidConfigurationSetException extends /*@__PURE__*/ InvalidConfigurationSetException_base {
}
declare const InvalidDeliveryOptionsException_base: S.TaggedErrorClass<"InvalidDeliveryOptionsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDeliveryOptionsException extends /*@__PURE__*/ InvalidDeliveryOptionsException_base {
}
declare const InvalidFirehoseDestinationException_base: S.TaggedErrorClass<"InvalidFirehoseDestinationException", {
    readonly ConfigurationSetName: any;
    readonly EventDestinationName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidFirehoseDestinationException extends /*@__PURE__*/ InvalidFirehoseDestinationException_base {
}
declare const InvalidLambdaFunctionException_base: S.TaggedErrorClass<"InvalidLambdaFunctionException", {
    readonly FunctionArn: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidLambdaFunctionException extends /*@__PURE__*/ InvalidLambdaFunctionException_base {
}
declare const InvalidParameterValue_base: S.TaggedErrorClass<"InvalidParameterValue", {
    readonly message: any;
}>;
export declare class InvalidParameterValue extends /*@__PURE__*/ InvalidParameterValue_base {
}
declare const InvalidPolicyException_base: S.TaggedErrorClass<"InvalidPolicyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPolicyException extends /*@__PURE__*/ InvalidPolicyException_base {
}
declare const InvalidRenderingParameterException_base: S.TaggedErrorClass<"InvalidRenderingParameterException", {
    readonly TemplateName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRenderingParameterException extends /*@__PURE__*/ InvalidRenderingParameterException_base {
}
declare const InvalidS3ConfigurationException_base: S.TaggedErrorClass<"InvalidS3ConfigurationException", {
    readonly Bucket: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidS3ConfigurationException extends /*@__PURE__*/ InvalidS3ConfigurationException_base {
}
declare const InvalidSNSDestinationException_base: S.TaggedErrorClass<"InvalidSNSDestinationException", {
    readonly ConfigurationSetName: any;
    readonly EventDestinationName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSNSDestinationException extends /*@__PURE__*/ InvalidSNSDestinationException_base {
}
declare const InvalidSnsTopicException_base: S.TaggedErrorClass<"InvalidSnsTopicException", {
    readonly Topic: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSnsTopicException extends /*@__PURE__*/ InvalidSnsTopicException_base {
}
declare const InvalidTemplateException_base: S.TaggedErrorClass<"InvalidTemplateException", {
    readonly TemplateName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTemplateException extends /*@__PURE__*/ InvalidTemplateException_base {
}
declare const InvalidTrackingOptionsException_base: S.TaggedErrorClass<"InvalidTrackingOptionsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTrackingOptionsException extends /*@__PURE__*/ InvalidTrackingOptionsException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MailFromDomainNotVerifiedException_base: S.TaggedErrorClass<"MailFromDomainNotVerifiedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MailFromDomainNotVerifiedException extends /*@__PURE__*/ MailFromDomainNotVerifiedException_base {
}
declare const MessageRejected_base: S.TaggedErrorClass<"MessageRejected", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MessageRejected extends /*@__PURE__*/ MessageRejected_base {
}
declare const MissingRenderingAttributeException_base: S.TaggedErrorClass<"MissingRenderingAttributeException", {
    readonly TemplateName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MissingRenderingAttributeException extends /*@__PURE__*/ MissingRenderingAttributeException_base {
}
declare const ProductionAccessNotGrantedException_base: S.TaggedErrorClass<"ProductionAccessNotGrantedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ProductionAccessNotGrantedException extends /*@__PURE__*/ ProductionAccessNotGrantedException_base {
}
declare const ReceiptRuleRoleNotAssumable_base: S.TaggedErrorClass<"ReceiptRuleRoleNotAssumable", {
    readonly message: any;
}>;
export declare class ReceiptRuleRoleNotAssumable extends /*@__PURE__*/ ReceiptRuleRoleNotAssumable_base {
}
declare const RuleDoesNotExistException_base: S.TaggedErrorClass<"RuleDoesNotExistException", {
    readonly Name: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RuleDoesNotExistException extends /*@__PURE__*/ RuleDoesNotExistException_base {
}
declare const RuleSetDoesNotExistException_base: S.TaggedErrorClass<"RuleSetDoesNotExistException", {
    readonly Name: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RuleSetDoesNotExistException extends /*@__PURE__*/ RuleSetDoesNotExistException_base {
}
declare const TemplateDoesNotExistException_base: S.TaggedErrorClass<"TemplateDoesNotExistException", {
    readonly TemplateName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TemplateDoesNotExistException extends /*@__PURE__*/ TemplateDoesNotExistException_base {
}
declare const TrackingOptionsAlreadyExistsException_base: S.TaggedErrorClass<"TrackingOptionsAlreadyExistsException", {
    readonly ConfigurationSetName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TrackingOptionsAlreadyExistsException extends /*@__PURE__*/ TrackingOptionsAlreadyExistsException_base {
}
declare const TrackingOptionsDoesNotExistException_base: S.TaggedErrorClass<"TrackingOptionsDoesNotExistException", {
    readonly ConfigurationSetName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrackingOptionsDoesNotExistException extends /*@__PURE__*/ TrackingOptionsDoesNotExistException_base {
}
export type ReceiptRuleSetName = string;
export interface CloneReceiptRuleSetRequest {
    RuleSetName: string;
    OriginalRuleSetName: string;
}
export interface CloneReceiptRuleSetResponse {
}
export type ConfigurationSetName = string;
export interface ConfigurationSet {
    Name: string;
}
export interface CreateConfigurationSetRequest {
    ConfigurationSet: ConfigurationSet;
}
export interface CreateConfigurationSetResponse {
}
export type EventDestinationName = string;
export type Enabled = boolean;
export type EventType = "send" | "reject" | "bounce" | "complaint" | "delivery" | "open" | "click" | "renderingFailure" | (string & {});
export type EventTypes = EventType[];
export type AmazonResourceName = string;
export interface KinesisFirehoseDestination {
    IAMRoleARN: string;
    DeliveryStreamARN: string;
}
export type DimensionName = string;
export type DimensionValueSource = "messageTag" | "emailHeader" | "linkTag" | (string & {});
export type DefaultDimensionValue = string;
export interface CloudWatchDimensionConfiguration {
    DimensionName: string;
    DimensionValueSource: DimensionValueSource;
    DefaultDimensionValue: string;
}
export type CloudWatchDimensionConfigurations = CloudWatchDimensionConfiguration[];
export interface CloudWatchDestination {
    DimensionConfigurations: CloudWatchDimensionConfiguration[];
}
export interface SNSDestination {
    TopicARN: string;
}
export interface EventDestination {
    Name: string;
    Enabled?: boolean;
    MatchingEventTypes: EventType[];
    KinesisFirehoseDestination?: KinesisFirehoseDestination;
    CloudWatchDestination?: CloudWatchDestination;
    SNSDestination?: SNSDestination;
}
export interface CreateConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestination: EventDestination;
}
export interface CreateConfigurationSetEventDestinationResponse {
}
export type CustomRedirectDomain = string;
export interface TrackingOptions {
    CustomRedirectDomain?: string;
}
export interface CreateConfigurationSetTrackingOptionsRequest {
    ConfigurationSetName: string;
    TrackingOptions: TrackingOptions;
}
export interface CreateConfigurationSetTrackingOptionsResponse {
}
export type TemplateName = string;
export type FromAddress = string;
export type Subject = string;
export type TemplateContent = string;
export type SuccessRedirectionURL = string;
export type FailureRedirectionURL = string;
export interface CreateCustomVerificationEmailTemplateRequest {
    TemplateName: string;
    FromEmailAddress: string;
    TemplateSubject: string;
    TemplateContent: string;
    SuccessRedirectionURL: string;
    FailureRedirectionURL: string;
}
export interface CreateCustomVerificationEmailTemplateResponse {
}
export type ReceiptFilterName = string;
export type ReceiptFilterPolicy = "Block" | "Allow" | (string & {});
export type Cidr = string;
export interface ReceiptIpFilter {
    Policy: ReceiptFilterPolicy;
    Cidr: string;
}
export interface ReceiptFilter {
    Name: string;
    IpFilter: ReceiptIpFilter;
}
export interface CreateReceiptFilterRequest {
    Filter: ReceiptFilter;
}
export interface CreateReceiptFilterResponse {
}
export type ReceiptRuleName = string;
export type TlsPolicy = "Require" | "Optional" | (string & {});
export type Recipient = string;
export type RecipientsList = string[];
export type S3BucketName = string;
export type S3KeyPrefix = string;
export type IAMRoleARN = string;
export interface S3Action {
    TopicArn?: string;
    BucketName: string;
    ObjectKeyPrefix?: string;
    KmsKeyArn?: string;
    IamRoleArn?: string;
}
export type BounceSmtpReplyCode = string;
export type BounceStatusCode = string;
export type BounceMessage = string;
export type Address = string;
export interface BounceAction {
    TopicArn?: string;
    SmtpReplyCode: string;
    StatusCode?: string;
    Message: string;
    Sender: string;
}
export interface WorkmailAction {
    TopicArn?: string;
    OrganizationArn: string;
}
export type InvocationType = "Event" | "RequestResponse" | (string & {});
export interface LambdaAction {
    TopicArn?: string;
    FunctionArn: string;
    InvocationType?: InvocationType;
}
export type StopScope = "RuleSet" | (string & {});
export interface StopAction {
    Scope: StopScope;
    TopicArn?: string;
}
export type HeaderName = string;
export type HeaderValue = string;
export interface AddHeaderAction {
    HeaderName: string;
    HeaderValue: string;
}
export type SNSActionEncoding = "UTF-8" | "Base64" | (string & {});
export interface SNSAction {
    TopicArn: string;
    Encoding?: SNSActionEncoding;
}
export type ConnectInstanceArn = string;
export interface ConnectAction {
    InstanceARN: string;
    IAMRoleARN: string;
}
export interface ReceiptAction {
    S3Action?: S3Action;
    BounceAction?: BounceAction;
    WorkmailAction?: WorkmailAction;
    LambdaAction?: LambdaAction;
    StopAction?: StopAction;
    AddHeaderAction?: AddHeaderAction;
    SNSAction?: SNSAction;
    ConnectAction?: ConnectAction;
}
export type ReceiptActionsList = ReceiptAction[];
export interface ReceiptRule {
    Name: string;
    Enabled?: boolean;
    TlsPolicy?: TlsPolicy;
    Recipients?: string[];
    Actions?: ReceiptAction[];
    ScanEnabled?: boolean;
}
export interface CreateReceiptRuleRequest {
    RuleSetName: string;
    After?: string;
    Rule: ReceiptRule;
}
export interface CreateReceiptRuleResponse {
}
export interface CreateReceiptRuleSetRequest {
    RuleSetName: string;
}
export interface CreateReceiptRuleSetResponse {
}
export type SubjectPart = string;
export type TextPart = string;
export type HtmlPart = string;
export interface Template {
    TemplateName: string;
    SubjectPart?: string;
    TextPart?: string;
    HtmlPart?: string;
}
export interface CreateTemplateRequest {
    Template: Template;
}
export interface CreateTemplateResponse {
}
export interface DeleteConfigurationSetRequest {
    ConfigurationSetName: string;
}
export interface DeleteConfigurationSetResponse {
}
export interface DeleteConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestinationName: string;
}
export interface DeleteConfigurationSetEventDestinationResponse {
}
export interface DeleteConfigurationSetTrackingOptionsRequest {
    ConfigurationSetName: string;
}
export interface DeleteConfigurationSetTrackingOptionsResponse {
}
export interface DeleteCustomVerificationEmailTemplateRequest {
    TemplateName: string;
}
export interface DeleteCustomVerificationEmailTemplateResponse {
}
export type Identity = string;
export interface DeleteIdentityRequest {
    Identity: string;
}
export interface DeleteIdentityResponse {
}
export type PolicyName = string;
export interface DeleteIdentityPolicyRequest {
    Identity: string;
    PolicyName: string;
}
export interface DeleteIdentityPolicyResponse {
}
export interface DeleteReceiptFilterRequest {
    FilterName: string;
}
export interface DeleteReceiptFilterResponse {
}
export interface DeleteReceiptRuleRequest {
    RuleSetName: string;
    RuleName: string;
}
export interface DeleteReceiptRuleResponse {
}
export interface DeleteReceiptRuleSetRequest {
    RuleSetName: string;
}
export interface DeleteReceiptRuleSetResponse {
}
export interface DeleteTemplateRequest {
    TemplateName: string;
}
export interface DeleteTemplateResponse {
}
export interface DeleteVerifiedEmailAddressRequest {
    EmailAddress: string;
}
export interface DeleteVerifiedEmailAddressResponse {
}
export interface DescribeActiveReceiptRuleSetRequest {
}
export interface ReceiptRuleSetMetadata {
    Name?: string;
    CreatedTimestamp?: Date;
}
export type ReceiptRulesList = ReceiptRule[];
export interface DescribeActiveReceiptRuleSetResponse {
    Metadata?: ReceiptRuleSetMetadata;
    Rules?: ReceiptRule[];
}
export type ConfigurationSetAttribute = "eventDestinations" | "trackingOptions" | "deliveryOptions" | "reputationOptions" | (string & {});
export type ConfigurationSetAttributeList = ConfigurationSetAttribute[];
export interface DescribeConfigurationSetRequest {
    ConfigurationSetName: string;
    ConfigurationSetAttributeNames?: ConfigurationSetAttribute[];
}
export type EventDestinations = EventDestination[];
export interface DeliveryOptions {
    TlsPolicy?: TlsPolicy;
}
export type LastFreshStart = Date;
export interface ReputationOptions {
    SendingEnabled?: boolean;
    ReputationMetricsEnabled?: boolean;
    LastFreshStart?: Date;
}
export interface DescribeConfigurationSetResponse {
    ConfigurationSet?: ConfigurationSet;
    EventDestinations?: EventDestination[];
    TrackingOptions?: TrackingOptions;
    DeliveryOptions?: DeliveryOptions;
    ReputationOptions?: ReputationOptions;
}
export interface DescribeReceiptRuleRequest {
    RuleSetName: string;
    RuleName: string;
}
export interface DescribeReceiptRuleResponse {
    Rule?: ReceiptRule;
}
export interface DescribeReceiptRuleSetRequest {
    RuleSetName: string;
}
export interface DescribeReceiptRuleSetResponse {
    Metadata?: ReceiptRuleSetMetadata;
    Rules?: ReceiptRule[];
}
export interface GetAccountSendingEnabledRequest {
}
export interface GetAccountSendingEnabledResponse {
    Enabled?: boolean;
}
export interface GetCustomVerificationEmailTemplateRequest {
    TemplateName: string;
}
export interface GetCustomVerificationEmailTemplateResponse {
    TemplateName?: string;
    FromEmailAddress?: string;
    TemplateSubject?: string;
    TemplateContent?: string;
    SuccessRedirectionURL?: string;
    FailureRedirectionURL?: string;
}
export type IdentityList = string[];
export interface GetIdentityDkimAttributesRequest {
    Identities: string[];
}
export type VerificationStatus = "Pending" | "Success" | "Failed" | "TemporaryFailure" | "NotStarted" | (string & {});
export type VerificationToken = string;
export type VerificationTokenList = string[];
export interface IdentityDkimAttributes {
    DkimEnabled: boolean;
    DkimVerificationStatus: VerificationStatus;
    DkimTokens?: string[];
}
export type DkimAttributes = {
    [key: string]: IdentityDkimAttributes | undefined;
};
export interface GetIdentityDkimAttributesResponse {
    DkimAttributes: {
        [key: string]: IdentityDkimAttributes | undefined;
    };
}
export interface GetIdentityMailFromDomainAttributesRequest {
    Identities: string[];
}
export type MailFromDomainName = string;
export type CustomMailFromStatus = "Pending" | "Success" | "Failed" | "TemporaryFailure" | (string & {});
export type BehaviorOnMXFailure = "UseDefaultValue" | "RejectMessage" | (string & {});
export interface IdentityMailFromDomainAttributes {
    MailFromDomain: string;
    MailFromDomainStatus: CustomMailFromStatus;
    BehaviorOnMXFailure: BehaviorOnMXFailure;
}
export type MailFromDomainAttributes = {
    [key: string]: IdentityMailFromDomainAttributes | undefined;
};
export interface GetIdentityMailFromDomainAttributesResponse {
    MailFromDomainAttributes: {
        [key: string]: IdentityMailFromDomainAttributes | undefined;
    };
}
export interface GetIdentityNotificationAttributesRequest {
    Identities: string[];
}
export type NotificationTopic = string;
export interface IdentityNotificationAttributes {
    BounceTopic: string;
    ComplaintTopic: string;
    DeliveryTopic: string;
    ForwardingEnabled: boolean;
    HeadersInBounceNotificationsEnabled?: boolean;
    HeadersInComplaintNotificationsEnabled?: boolean;
    HeadersInDeliveryNotificationsEnabled?: boolean;
}
export type NotificationAttributes = {
    [key: string]: IdentityNotificationAttributes | undefined;
};
export interface GetIdentityNotificationAttributesResponse {
    NotificationAttributes: {
        [key: string]: IdentityNotificationAttributes | undefined;
    };
}
export type PolicyNameList = string[];
export interface GetIdentityPoliciesRequest {
    Identity: string;
    PolicyNames: string[];
}
export type Policy = string;
export type PolicyMap = {
    [key: string]: string | undefined;
};
export interface GetIdentityPoliciesResponse {
    Policies: {
        [key: string]: string | undefined;
    };
}
export interface GetIdentityVerificationAttributesRequest {
    Identities: string[];
}
export interface IdentityVerificationAttributes {
    VerificationStatus: VerificationStatus;
    VerificationToken?: string;
}
export type VerificationAttributes = {
    [key: string]: IdentityVerificationAttributes | undefined;
};
export interface GetIdentityVerificationAttributesResponse {
    VerificationAttributes: {
        [key: string]: IdentityVerificationAttributes | undefined;
    };
}
export interface GetSendQuotaRequest {
}
export type Max24HourSend = number;
export type MaxSendRate = number;
export type SentLast24Hours = number;
export interface GetSendQuotaResponse {
    Max24HourSend?: number;
    MaxSendRate?: number;
    SentLast24Hours?: number;
}
export interface GetSendStatisticsRequest {
}
export type Counter = number;
export interface SendDataPoint {
    Timestamp?: Date;
    DeliveryAttempts?: number;
    Bounces?: number;
    Complaints?: number;
    Rejects?: number;
}
export type SendDataPointList = SendDataPoint[];
export interface GetSendStatisticsResponse {
    SendDataPoints?: SendDataPoint[];
}
export interface GetTemplateRequest {
    TemplateName: string;
}
export interface GetTemplateResponse {
    Template?: Template;
}
export type NextToken = string;
export type MaxItems = number;
export interface ListConfigurationSetsRequest {
    NextToken?: string;
    MaxItems?: number;
}
export type ConfigurationSets = ConfigurationSet[];
export interface ListConfigurationSetsResponse {
    ConfigurationSets?: ConfigurationSet[];
    NextToken?: string;
}
export type MaxResults = number;
export interface ListCustomVerificationEmailTemplatesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface CustomVerificationEmailTemplate {
    TemplateName?: string;
    FromEmailAddress?: string;
    TemplateSubject?: string;
    SuccessRedirectionURL?: string;
    FailureRedirectionURL?: string;
}
export type CustomVerificationEmailTemplates = CustomVerificationEmailTemplate[];
export interface ListCustomVerificationEmailTemplatesResponse {
    CustomVerificationEmailTemplates?: CustomVerificationEmailTemplate[];
    NextToken?: string;
}
export type IdentityType = "EmailAddress" | "Domain" | (string & {});
export interface ListIdentitiesRequest {
    IdentityType?: IdentityType;
    NextToken?: string;
    MaxItems?: number;
}
export interface ListIdentitiesResponse {
    Identities: string[];
    NextToken?: string;
}
export interface ListIdentityPoliciesRequest {
    Identity: string;
}
export interface ListIdentityPoliciesResponse {
    PolicyNames: string[];
}
export interface ListReceiptFiltersRequest {
}
export type ReceiptFilterList = ReceiptFilter[];
export interface ListReceiptFiltersResponse {
    Filters?: ReceiptFilter[];
}
export interface ListReceiptRuleSetsRequest {
    NextToken?: string;
}
export type ReceiptRuleSetsLists = ReceiptRuleSetMetadata[];
export interface ListReceiptRuleSetsResponse {
    RuleSets?: ReceiptRuleSetMetadata[];
    NextToken?: string;
}
export interface ListTemplatesRequest {
    NextToken?: string;
    MaxItems?: number;
}
export interface TemplateMetadata {
    Name?: string;
    CreatedTimestamp?: Date;
}
export type TemplateMetadataList = TemplateMetadata[];
export interface ListTemplatesResponse {
    TemplatesMetadata?: TemplateMetadata[];
    NextToken?: string;
}
export interface ListVerifiedEmailAddressesRequest {
}
export type AddressList = string[];
export interface ListVerifiedEmailAddressesResponse {
    VerifiedEmailAddresses?: string[];
}
export interface PutConfigurationSetDeliveryOptionsRequest {
    ConfigurationSetName: string;
    DeliveryOptions?: DeliveryOptions;
}
export interface PutConfigurationSetDeliveryOptionsResponse {
}
export interface PutIdentityPolicyRequest {
    Identity: string;
    PolicyName: string;
    Policy: string;
}
export interface PutIdentityPolicyResponse {
}
export type ReceiptRuleNamesList = string[];
export interface ReorderReceiptRuleSetRequest {
    RuleSetName: string;
    RuleNames: string[];
}
export interface ReorderReceiptRuleSetResponse {
}
export type MessageId = string;
export type Explanation = string;
export type ReportingMta = string;
export type ArrivalDate = Date;
export type ExtensionFieldName = string;
export type ExtensionFieldValue = string;
export interface ExtensionField {
    Name: string;
    Value: string;
}
export type ExtensionFieldList = ExtensionField[];
export interface MessageDsn {
    ReportingMta: string;
    ArrivalDate?: Date;
    ExtensionFields?: ExtensionField[];
}
export type BounceType = "DoesNotExist" | "MessageTooLarge" | "ExceededQuota" | "ContentRejected" | "Undefined" | "TemporaryFailure" | (string & {});
export type DsnAction = "failed" | "delayed" | "delivered" | "relayed" | "expanded" | (string & {});
export type RemoteMta = string;
export type DsnStatus = string;
export type DiagnosticCode = string;
export type LastAttemptDate = Date;
export interface RecipientDsnFields {
    FinalRecipient?: string;
    Action: DsnAction;
    RemoteMta?: string;
    Status: string;
    DiagnosticCode?: string;
    LastAttemptDate?: Date;
    ExtensionFields?: ExtensionField[];
}
export interface BouncedRecipientInfo {
    Recipient: string;
    RecipientArn?: string;
    BounceType?: BounceType;
    RecipientDsnFields?: RecipientDsnFields;
}
export type BouncedRecipientInfoList = BouncedRecipientInfo[];
export interface SendBounceRequest {
    OriginalMessageId: string;
    BounceSender: string;
    Explanation?: string;
    MessageDsn?: MessageDsn;
    BouncedRecipientInfoList: BouncedRecipientInfo[];
    BounceSenderArn?: string;
}
export interface SendBounceResponse {
    MessageId?: string;
}
export type MessageTagName = string;
export type MessageTagValue = string;
export interface MessageTag {
    Name: string;
    Value: string;
}
export type MessageTagList = MessageTag[];
export type TemplateData = string;
export interface Destination {
    ToAddresses?: string[];
    CcAddresses?: string[];
    BccAddresses?: string[];
}
export interface BulkEmailDestination {
    Destination: Destination;
    ReplacementTags?: MessageTag[];
    ReplacementTemplateData?: string;
}
export type BulkEmailDestinationList = BulkEmailDestination[];
export interface SendBulkTemplatedEmailRequest {
    Source: string;
    SourceArn?: string;
    ReplyToAddresses?: string[];
    ReturnPath?: string;
    ReturnPathArn?: string;
    ConfigurationSetName?: string;
    DefaultTags?: MessageTag[];
    Template: string;
    TemplateArn?: string;
    DefaultTemplateData: string;
    Destinations: BulkEmailDestination[];
}
export type BulkEmailStatus = "Success" | "MessageRejected" | "MailFromDomainNotVerified" | "ConfigurationSetDoesNotExist" | "TemplateDoesNotExist" | "AccountSuspended" | "AccountThrottled" | "AccountDailyQuotaExceeded" | "InvalidSendingPoolName" | "AccountSendingPaused" | "ConfigurationSetSendingPaused" | "InvalidParameterValue" | "TransientFailure" | "Failed" | (string & {});
export interface BulkEmailDestinationStatus {
    Status?: BulkEmailStatus;
    Error?: string;
    MessageId?: string;
}
export type BulkEmailDestinationStatusList = BulkEmailDestinationStatus[];
export interface SendBulkTemplatedEmailResponse {
    Status: BulkEmailDestinationStatus[];
}
export interface SendCustomVerificationEmailRequest {
    EmailAddress: string;
    TemplateName: string;
    ConfigurationSetName?: string;
}
export interface SendCustomVerificationEmailResponse {
    MessageId?: string;
}
export type MessageData = string;
export type Charset = string;
export interface Content {
    Data: string;
    Charset?: string;
}
export interface Body {
    Text?: Content;
    Html?: Content;
}
export interface Message {
    Subject: Content;
    Body: Body;
}
export interface SendEmailRequest {
    Source: string;
    Destination: Destination;
    Message: Message;
    ReplyToAddresses?: string[];
    ReturnPath?: string;
    SourceArn?: string;
    ReturnPathArn?: string;
    Tags?: MessageTag[];
    ConfigurationSetName?: string;
}
export interface SendEmailResponse {
    MessageId: string;
}
export type RawMessageData = Uint8Array;
export interface RawMessage {
    Data: Uint8Array;
}
export interface SendRawEmailRequest {
    Source?: string;
    Destinations?: string[];
    RawMessage: RawMessage;
    FromArn?: string;
    SourceArn?: string;
    ReturnPathArn?: string;
    Tags?: MessageTag[];
    ConfigurationSetName?: string;
}
export interface SendRawEmailResponse {
    MessageId: string;
}
export interface SendTemplatedEmailRequest {
    Source: string;
    Destination: Destination;
    ReplyToAddresses?: string[];
    ReturnPath?: string;
    SourceArn?: string;
    ReturnPathArn?: string;
    Tags?: MessageTag[];
    ConfigurationSetName?: string;
    Template: string;
    TemplateArn?: string;
    TemplateData: string;
}
export interface SendTemplatedEmailResponse {
    MessageId: string;
}
export interface SetActiveReceiptRuleSetRequest {
    RuleSetName?: string;
}
export interface SetActiveReceiptRuleSetResponse {
}
export interface SetIdentityDkimEnabledRequest {
    Identity: string;
    DkimEnabled: boolean;
}
export interface SetIdentityDkimEnabledResponse {
}
export interface SetIdentityFeedbackForwardingEnabledRequest {
    Identity: string;
    ForwardingEnabled: boolean;
}
export interface SetIdentityFeedbackForwardingEnabledResponse {
}
export type NotificationType = "Bounce" | "Complaint" | "Delivery" | (string & {});
export interface SetIdentityHeadersInNotificationsEnabledRequest {
    Identity: string;
    NotificationType: NotificationType;
    Enabled: boolean;
}
export interface SetIdentityHeadersInNotificationsEnabledResponse {
}
export interface SetIdentityMailFromDomainRequest {
    Identity: string;
    MailFromDomain?: string;
    BehaviorOnMXFailure?: BehaviorOnMXFailure;
}
export interface SetIdentityMailFromDomainResponse {
}
export interface SetIdentityNotificationTopicRequest {
    Identity: string;
    NotificationType: NotificationType;
    SnsTopic?: string;
}
export interface SetIdentityNotificationTopicResponse {
}
export interface SetReceiptRulePositionRequest {
    RuleSetName: string;
    RuleName: string;
    After?: string;
}
export interface SetReceiptRulePositionResponse {
}
export interface TestRenderTemplateRequest {
    TemplateName: string;
    TemplateData: string;
}
export type RenderedTemplate = string;
export interface TestRenderTemplateResponse {
    RenderedTemplate?: string;
}
export interface UpdateAccountSendingEnabledRequest {
    Enabled?: boolean;
}
export interface UpdateAccountSendingEnabledResponse {
}
export interface UpdateConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestination: EventDestination;
}
export interface UpdateConfigurationSetEventDestinationResponse {
}
export interface UpdateConfigurationSetReputationMetricsEnabledRequest {
    ConfigurationSetName: string;
    Enabled: boolean;
}
export interface UpdateConfigurationSetReputationMetricsEnabledResponse {
}
export interface UpdateConfigurationSetSendingEnabledRequest {
    ConfigurationSetName: string;
    Enabled: boolean;
}
export interface UpdateConfigurationSetSendingEnabledResponse {
}
export interface UpdateConfigurationSetTrackingOptionsRequest {
    ConfigurationSetName: string;
    TrackingOptions: TrackingOptions;
}
export interface UpdateConfigurationSetTrackingOptionsResponse {
}
export interface UpdateCustomVerificationEmailTemplateRequest {
    TemplateName: string;
    FromEmailAddress?: string;
    TemplateSubject?: string;
    TemplateContent?: string;
    SuccessRedirectionURL?: string;
    FailureRedirectionURL?: string;
}
export interface UpdateCustomVerificationEmailTemplateResponse {
}
export interface UpdateReceiptRuleRequest {
    RuleSetName: string;
    Rule: ReceiptRule;
}
export interface UpdateReceiptRuleResponse {
}
export interface UpdateTemplateRequest {
    Template: Template;
}
export interface UpdateTemplateResponse {
}
export type Domain = string;
export interface VerifyDomainDkimRequest {
    Domain: string;
}
export interface VerifyDomainDkimResponse {
    DkimTokens: string[];
}
export interface VerifyDomainIdentityRequest {
    Domain: string;
}
export interface VerifyDomainIdentityResponse {
    VerificationToken: string;
}
export interface VerifyEmailAddressRequest {
    EmailAddress: string;
}
export interface VerifyEmailAddressResponse {
}
export interface VerifyEmailIdentityRequest {
    EmailAddress: string;
}
export interface VerifyEmailIdentityResponse {
}
export type RuleOrRuleSetName = string;
export type ErrorMessage = string;
export type CloneReceiptRuleSetError = AlreadyExistsException | LimitExceededException | RuleSetDoesNotExistException | CommonErrors;
/**
 * Creates a receipt rule set by cloning an existing one. All receipt rules and
 * configurations are copied to the new receipt rule set and are completely independent of
 * the source rule set.
 *
 * For information about setting up rule sets, see the Amazon SES Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const cloneReceiptRuleSet: API.OperationMethod<CloneReceiptRuleSetRequest, CloneReceiptRuleSetResponse, CloneReceiptRuleSetError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationSetError = ConfigurationSetAlreadyExistsException | InvalidConfigurationSetException | LimitExceededException | CommonErrors;
/**
 * Creates a configuration set.
 *
 * Configuration sets enable you to publish email sending events. For information about
 * using configuration sets, see the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const createConfigurationSet: API.OperationMethod<CreateConfigurationSetRequest, CreateConfigurationSetResponse, CreateConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationSetEventDestinationError = ConfigurationSetDoesNotExistException | EventDestinationAlreadyExistsException | InvalidCloudWatchDestinationException | InvalidFirehoseDestinationException | InvalidSNSDestinationException | LimitExceededException | CommonErrors;
/**
 * Creates a configuration set event destination.
 *
 * When you create or update an event destination, you must provide one, and only
 * one, destination. The destination can be CloudWatch, Amazon Kinesis Firehose, or Amazon Simple Notification Service (Amazon SNS).
 *
 * An event destination is the Amazon Web Services service to which Amazon SES publishes the email sending
 * events associated with a configuration set. For information about using configuration
 * sets, see the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const createConfigurationSetEventDestination: API.OperationMethod<CreateConfigurationSetEventDestinationRequest, CreateConfigurationSetEventDestinationResponse, CreateConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationSetTrackingOptionsError = ConfigurationSetDoesNotExistException | InvalidTrackingOptionsException | TrackingOptionsAlreadyExistsException | CommonErrors;
/**
 * Creates an association between a configuration set and a custom domain for open and
 * click event tracking.
 *
 * By default, images and links used for tracking open and click events are hosted on
 * domains operated by Amazon SES. You can configure a subdomain of your own to handle these
 * events. For information about using custom domains, see the Amazon SES Developer Guide.
 */
export declare const createConfigurationSetTrackingOptions: API.OperationMethod<CreateConfigurationSetTrackingOptionsRequest, CreateConfigurationSetTrackingOptionsResponse, CreateConfigurationSetTrackingOptionsError, Credentials | HttpClient.HttpClient>;
export type CreateCustomVerificationEmailTemplateError = CustomVerificationEmailInvalidContentException | CustomVerificationEmailTemplateAlreadyExistsException | FromEmailAddressNotVerifiedException | LimitExceededException | CommonErrors;
/**
 * Creates a new custom verification email template.
 *
 * For more information about custom verification email templates, see Using
 * Custom Verification Email Templates in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const createCustomVerificationEmailTemplate: API.OperationMethod<CreateCustomVerificationEmailTemplateRequest, CreateCustomVerificationEmailTemplateResponse, CreateCustomVerificationEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateReceiptFilterError = AlreadyExistsException | LimitExceededException | CommonErrors;
/**
 * Creates a new IP address filter.
 *
 * For information about setting up IP address filters, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const createReceiptFilter: API.OperationMethod<CreateReceiptFilterRequest, CreateReceiptFilterResponse, CreateReceiptFilterError, Credentials | HttpClient.HttpClient>;
export type CreateReceiptRuleError = AlreadyExistsException | InvalidLambdaFunctionException | InvalidS3ConfigurationException | InvalidSnsTopicException | LimitExceededException | RuleDoesNotExistException | RuleSetDoesNotExistException | InvalidParameterValue | IdentityNotVerified | ReceiptRuleRoleNotAssumable | CommonErrors;
/**
 * Creates a receipt rule.
 *
 * For information about setting up receipt rules, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const createReceiptRule: API.OperationMethod<CreateReceiptRuleRequest, CreateReceiptRuleResponse, CreateReceiptRuleError, Credentials | HttpClient.HttpClient>;
export type CreateReceiptRuleSetError = AlreadyExistsException | LimitExceededException | CommonErrors;
/**
 * Creates an empty receipt rule set.
 *
 * For information about setting up receipt rule sets, see the Amazon SES Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const createReceiptRuleSet: API.OperationMethod<CreateReceiptRuleSetRequest, CreateReceiptRuleSetResponse, CreateReceiptRuleSetError, Credentials | HttpClient.HttpClient>;
export type CreateTemplateError = AlreadyExistsException | InvalidTemplateException | LimitExceededException | CommonErrors;
/**
 * Creates an email template. Email templates enable you to send personalized email to
 * one or more destinations in a single operation. For more information, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const createTemplate: API.OperationMethod<CreateTemplateRequest, CreateTemplateResponse, CreateTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationSetError = ConfigurationSetDoesNotExistException | CommonErrors;
/**
 * Deletes a configuration set. Configuration sets enable you to publish email sending
 * events. For information about using configuration sets, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const deleteConfigurationSet: API.OperationMethod<DeleteConfigurationSetRequest, DeleteConfigurationSetResponse, DeleteConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationSetEventDestinationError = ConfigurationSetDoesNotExistException | EventDestinationDoesNotExistException | CommonErrors;
/**
 * Deletes a configuration set event destination. Configuration set event destinations
 * are associated with configuration sets, which enable you to publish email sending
 * events. For information about using configuration sets, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const deleteConfigurationSetEventDestination: API.OperationMethod<DeleteConfigurationSetEventDestinationRequest, DeleteConfigurationSetEventDestinationResponse, DeleteConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationSetTrackingOptionsError = ConfigurationSetDoesNotExistException | TrackingOptionsDoesNotExistException | CommonErrors;
/**
 * Deletes an association between a configuration set and a custom domain for open and
 * click event tracking.
 *
 * By default, images and links used for tracking open and click events are hosted on
 * domains operated by Amazon SES. You can configure a subdomain of your own to handle these
 * events. For information about using custom domains, see the Amazon SES Developer Guide.
 *
 * Deleting this kind of association results in emails sent using the specified
 * configuration set to capture open and click events using the standard,
 * Amazon SES-operated domains.
 */
export declare const deleteConfigurationSetTrackingOptions: API.OperationMethod<DeleteConfigurationSetTrackingOptionsRequest, DeleteConfigurationSetTrackingOptionsResponse, DeleteConfigurationSetTrackingOptionsError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomVerificationEmailTemplateError = CommonErrors;
/**
 * Deletes an existing custom verification email template.
 *
 * For more information about custom verification email templates, see Using
 * Custom Verification Email Templates in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const deleteCustomVerificationEmailTemplate: API.OperationMethod<DeleteCustomVerificationEmailTemplateRequest, DeleteCustomVerificationEmailTemplateResponse, DeleteCustomVerificationEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteIdentityError = CommonErrors;
/**
 * Deletes the specified identity (an email address or a domain) from the list of
 * verified identities.
 *
 * You can execute this operation no more than once per second.
 */
export declare const deleteIdentity: API.OperationMethod<DeleteIdentityRequest, DeleteIdentityResponse, DeleteIdentityError, Credentials | HttpClient.HttpClient>;
export type DeleteIdentityPolicyError = CommonErrors;
/**
 * Deletes the specified sending authorization policy for the given identity (an email
 * address or a domain). This operation returns successfully even if a policy with the
 * specified name does not exist.
 *
 * This operation is for the identity owner only. If you have not verified the
 * identity, it returns an error.
 *
 * Sending authorization is a feature that enables an identity owner to authorize other
 * senders to use its identities. For information about using sending authorization, see
 * the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const deleteIdentityPolicy: API.OperationMethod<DeleteIdentityPolicyRequest, DeleteIdentityPolicyResponse, DeleteIdentityPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteReceiptFilterError = CommonErrors;
/**
 * Deletes the specified IP address filter.
 *
 * For information about managing IP address filters, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const deleteReceiptFilter: API.OperationMethod<DeleteReceiptFilterRequest, DeleteReceiptFilterResponse, DeleteReceiptFilterError, Credentials | HttpClient.HttpClient>;
export type DeleteReceiptRuleError = RuleSetDoesNotExistException | CommonErrors;
/**
 * Deletes the specified receipt rule.
 *
 * For information about managing receipt rules, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const deleteReceiptRule: API.OperationMethod<DeleteReceiptRuleRequest, DeleteReceiptRuleResponse, DeleteReceiptRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteReceiptRuleSetError = CannotDeleteException | CommonErrors;
/**
 * Deletes the specified receipt rule set and all of the receipt rules it
 * contains.
 *
 * The currently active rule set cannot be deleted.
 *
 * For information about managing receipt rule sets, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const deleteReceiptRuleSet: API.OperationMethod<DeleteReceiptRuleSetRequest, DeleteReceiptRuleSetResponse, DeleteReceiptRuleSetError, Credentials | HttpClient.HttpClient>;
export type DeleteTemplateError = CommonErrors;
/**
 * Deletes an email template.
 *
 * You can execute this operation no more than once per second.
 */
export declare const deleteTemplate: API.OperationMethod<DeleteTemplateRequest, DeleteTemplateResponse, DeleteTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteVerifiedEmailAddressError = CommonErrors;
/**
 * Deprecated. Use the `DeleteIdentity` operation to delete email addresses
 * and domains.
 */
export declare const deleteVerifiedEmailAddress: API.OperationMethod<DeleteVerifiedEmailAddressRequest, DeleteVerifiedEmailAddressResponse, DeleteVerifiedEmailAddressError, Credentials | HttpClient.HttpClient>;
export type DescribeActiveReceiptRuleSetError = CommonErrors;
/**
 * Returns the metadata and receipt rules for the receipt rule set that is currently
 * active.
 *
 * For information about setting up receipt rule sets, see the Amazon SES Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const describeActiveReceiptRuleSet: API.OperationMethod<DescribeActiveReceiptRuleSetRequest, DescribeActiveReceiptRuleSetResponse, DescribeActiveReceiptRuleSetError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationSetError = ConfigurationSetDoesNotExistException | CommonErrors;
/**
 * Returns the details of the specified configuration set. For information about using
 * configuration sets, see the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const describeConfigurationSet: API.OperationMethod<DescribeConfigurationSetRequest, DescribeConfigurationSetResponse, DescribeConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type DescribeReceiptRuleError = RuleDoesNotExistException | RuleSetDoesNotExistException | CommonErrors;
/**
 * Returns the details of the specified receipt rule.
 *
 * For information about setting up receipt rules, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const describeReceiptRule: API.OperationMethod<DescribeReceiptRuleRequest, DescribeReceiptRuleResponse, DescribeReceiptRuleError, Credentials | HttpClient.HttpClient>;
export type DescribeReceiptRuleSetError = RuleSetDoesNotExistException | CommonErrors;
/**
 * Returns the details of the specified receipt rule set.
 *
 * For information about managing receipt rule sets, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const describeReceiptRuleSet: API.OperationMethod<DescribeReceiptRuleSetRequest, DescribeReceiptRuleSetResponse, DescribeReceiptRuleSetError, Credentials | HttpClient.HttpClient>;
export type GetAccountSendingEnabledError = CommonErrors;
/**
 * Returns the email sending status of the Amazon SES account for the current Region.
 *
 * You can execute this operation no more than once per second.
 */
export declare const getAccountSendingEnabled: API.OperationMethod<GetAccountSendingEnabledRequest, GetAccountSendingEnabledResponse, GetAccountSendingEnabledError, Credentials | HttpClient.HttpClient>;
export type GetCustomVerificationEmailTemplateError = CustomVerificationEmailTemplateDoesNotExistException | CommonErrors;
/**
 * Returns the custom email verification template for the template name you
 * specify.
 *
 * For more information about custom verification email templates, see Using
 * Custom Verification Email Templates in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const getCustomVerificationEmailTemplate: API.OperationMethod<GetCustomVerificationEmailTemplateRequest, GetCustomVerificationEmailTemplateResponse, GetCustomVerificationEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type GetIdentityDkimAttributesError = CommonErrors;
/**
 * Returns the current status of Easy DKIM signing for an entity. For domain name
 * identities, this operation also returns the DKIM tokens that are required for Easy DKIM
 * signing, and whether Amazon SES has successfully verified that these tokens have been
 * published.
 *
 * This operation takes a list of identities as input and returns the following
 * information for each:
 *
 * - Whether Easy DKIM signing is enabled or disabled.
 *
 * - A set of DKIM tokens that represent the identity. If the identity is an email
 * address, the tokens represent the domain of that address.
 *
 * - Whether Amazon SES has successfully verified the DKIM tokens published in the
 * domain's DNS. This information is only returned for domain name identities, not
 * for email addresses.
 *
 * This operation is throttled at one request per second and can only get DKIM attributes
 * for up to 100 identities at a time.
 *
 * For more information about creating DNS records using DKIM tokens, go to the Amazon SES
 * Developer Guide.
 */
export declare const getIdentityDkimAttributes: API.OperationMethod<GetIdentityDkimAttributesRequest, GetIdentityDkimAttributesResponse, GetIdentityDkimAttributesError, Credentials | HttpClient.HttpClient>;
export type GetIdentityMailFromDomainAttributesError = CommonErrors;
/**
 * Returns the custom MAIL FROM attributes for a list of identities (email addresses :
 * domains).
 *
 * This operation is throttled at one request per second and can only get custom MAIL
 * FROM attributes for up to 100 identities at a time.
 */
export declare const getIdentityMailFromDomainAttributes: API.OperationMethod<GetIdentityMailFromDomainAttributesRequest, GetIdentityMailFromDomainAttributesResponse, GetIdentityMailFromDomainAttributesError, Credentials | HttpClient.HttpClient>;
export type GetIdentityNotificationAttributesError = CommonErrors;
/**
 * Given a list of verified identities (email addresses and/or domains), returns a
 * structure describing identity notification attributes.
 *
 * This operation is throttled at one request per second and can only get notification
 * attributes for up to 100 identities at a time.
 *
 * For more information about using notifications with Amazon SES, see the Amazon SES
 * Developer Guide.
 */
export declare const getIdentityNotificationAttributes: API.OperationMethod<GetIdentityNotificationAttributesRequest, GetIdentityNotificationAttributesResponse, GetIdentityNotificationAttributesError, Credentials | HttpClient.HttpClient>;
export type GetIdentityPoliciesError = CommonErrors;
/**
 * Returns the requested sending authorization policies for the given identity (an email
 * address or a domain). The policies are returned as a map of policy names to policy
 * contents. You can retrieve a maximum of 20 policies at a time.
 *
 * This operation is for the identity owner only. If you have not verified the
 * identity, it returns an error.
 *
 * Sending authorization is a feature that enables an identity owner to authorize other
 * senders to use its identities. For information about using sending authorization, see
 * the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const getIdentityPolicies: API.OperationMethod<GetIdentityPoliciesRequest, GetIdentityPoliciesResponse, GetIdentityPoliciesError, Credentials | HttpClient.HttpClient>;
export type GetIdentityVerificationAttributesError = CommonErrors;
/**
 * Given a list of identities (email addresses and/or domains), returns the verification
 * status and (for domain identities) the verification token for each identity.
 *
 * The verification status of an email address is "Pending" until the email address owner
 * clicks the link within the verification email that Amazon SES sent to that address. If the
 * email address owner clicks the link within 24 hours, the verification status of the
 * email address changes to "Success". If the link is not clicked within 24 hours, the
 * verification status changes to "Failed." In that case, to verify the email address, you
 * must restart the verification process from the beginning.
 *
 * For domain identities, the domain's verification status is "Pending" as Amazon SES searches
 * for the required TXT record in the DNS settings of the domain. When Amazon SES detects the
 * record, the domain's verification status changes to "Success". If Amazon SES is unable to
 * detect the record within 72 hours, the domain's verification status changes to "Failed."
 * In that case, to verify the domain, you must restart the verification process from the
 * beginning.
 *
 * This operation is throttled at one request per second and can only get verification
 * attributes for up to 100 identities at a time.
 */
export declare const getIdentityVerificationAttributes: API.OperationMethod<GetIdentityVerificationAttributesRequest, GetIdentityVerificationAttributesResponse, GetIdentityVerificationAttributesError, Credentials | HttpClient.HttpClient>;
export type GetSendQuotaError = CommonErrors;
/**
 * Provides the sending limits for the Amazon SES account.
 *
 * You can execute this operation no more than once per second.
 */
export declare const getSendQuota: API.OperationMethod<GetSendQuotaRequest, GetSendQuotaResponse, GetSendQuotaError, Credentials | HttpClient.HttpClient>;
export type GetSendStatisticsError = CommonErrors;
/**
 * Provides sending statistics for the current Amazon Web Services Region. The result is a list of data
 * points, representing the last two weeks of sending activity. Each data point in the list
 * contains statistics for a 15-minute period of time.
 *
 * You can execute this operation no more than once per second.
 */
export declare const getSendStatistics: API.OperationMethod<GetSendStatisticsRequest, GetSendStatisticsResponse, GetSendStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetTemplateError = TemplateDoesNotExistException | CommonErrors;
/**
 * Displays the template object (which includes the Subject line, HTML part and text
 * part) for the template you specify.
 *
 * You can execute this operation no more than once per second.
 */
export declare const getTemplate: API.OperationMethod<GetTemplateRequest, GetTemplateResponse, GetTemplateError, Credentials | HttpClient.HttpClient>;
export type ListConfigurationSetsError = CommonErrors;
/**
 * Provides a list of the configuration sets associated with your Amazon SES account in the
 * current Amazon Web Services Region. For information about using configuration sets, see Monitoring
 * Your Amazon SES Sending Activity in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second. This operation returns up
 * to 1,000 configuration sets each time it is run. If your Amazon SES account has more than
 * 1,000 configuration sets, this operation also returns `NextToken`. You can
 * then execute the `ListConfigurationSets` operation again, passing the
 * `NextToken` parameter and the value of the NextToken element to retrieve
 * additional results.
 */
export declare const listConfigurationSets: API.OperationMethod<ListConfigurationSetsRequest, ListConfigurationSetsResponse, ListConfigurationSetsError, Credentials | HttpClient.HttpClient>;
export type ListCustomVerificationEmailTemplatesError = CommonErrors;
/**
 * Lists the existing custom verification email templates for your account in the current
 * Amazon Web Services Region.
 *
 * For more information about custom verification email templates, see Using
 * Custom Verification Email Templates in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const listCustomVerificationEmailTemplates: API.PaginatedOperationMethod<ListCustomVerificationEmailTemplatesRequest, ListCustomVerificationEmailTemplatesResponse, ListCustomVerificationEmailTemplatesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListIdentitiesError = CommonErrors;
/**
 * Returns a list containing all of the identities (email addresses and domains) for your
 * Amazon Web Services account in the current Amazon Web Services Region, regardless of verification status.
 *
 * You can execute this operation no more than once per second.
 *
 * It's recommended that for successive pagination calls of this API, you continue to
 * the use the same parameter/value pairs as used in the original call, e.g., if you
 * used `IdentityType=Domain` in the the original call and received a
 * `NextToken` in the response, you should continue providing the
 * `IdentityType=Domain` parameter for further `NextToken`
 * calls; however, if you didn't provide the `IdentityType` parameter in the
 * original call, then continue to not provide it for successive pagination calls.
 * Using this protocol will ensure consistent results.
 */
export declare const listIdentities: API.PaginatedOperationMethod<ListIdentitiesRequest, ListIdentitiesResponse, ListIdentitiesError, Credentials | HttpClient.HttpClient, Identity>;
export type ListIdentityPoliciesError = CommonErrors;
/**
 * Returns a list of sending authorization policies that are attached to the given
 * identity (an email address or a domain). This operation returns only a list. To get the
 * actual policy content, use `GetIdentityPolicies`.
 *
 * This operation is for the identity owner only. If you have not verified the
 * identity, it returns an error.
 *
 * Sending authorization is a feature that enables an identity owner to authorize other
 * senders to use its identities. For information about using sending authorization, see
 * the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const listIdentityPolicies: API.OperationMethod<ListIdentityPoliciesRequest, ListIdentityPoliciesResponse, ListIdentityPoliciesError, Credentials | HttpClient.HttpClient>;
export type ListReceiptFiltersError = CommonErrors;
/**
 * Lists the IP address filters associated with your Amazon Web Services account in the current
 * Amazon Web Services Region.
 *
 * For information about managing IP address filters, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const listReceiptFilters: API.OperationMethod<ListReceiptFiltersRequest, ListReceiptFiltersResponse, ListReceiptFiltersError, Credentials | HttpClient.HttpClient>;
export type ListReceiptRuleSetsError = CommonErrors;
/**
 * Lists the receipt rule sets that exist under your Amazon Web Services account in the current
 * Amazon Web Services Region. If there are additional receipt rule sets to be retrieved, you receive a
 * `NextToken` that you can provide to the next call to
 * `ListReceiptRuleSets` to retrieve the additional entries.
 *
 * For information about managing receipt rule sets, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const listReceiptRuleSets: API.OperationMethod<ListReceiptRuleSetsRequest, ListReceiptRuleSetsResponse, ListReceiptRuleSetsError, Credentials | HttpClient.HttpClient>;
export type ListTemplatesError = CommonErrors;
/**
 * Lists the email templates present in your Amazon SES account in the current
 * Amazon Web Services Region.
 *
 * You can execute this operation no more than once per second.
 */
export declare const listTemplates: API.OperationMethod<ListTemplatesRequest, ListTemplatesResponse, ListTemplatesError, Credentials | HttpClient.HttpClient>;
export type ListVerifiedEmailAddressesError = CommonErrors;
/**
 * Deprecated. Use the `ListIdentities` operation to list the email addresses
 * and domains associated with your account.
 */
export declare const listVerifiedEmailAddresses: API.OperationMethod<ListVerifiedEmailAddressesRequest, ListVerifiedEmailAddressesResponse, ListVerifiedEmailAddressesError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationSetDeliveryOptionsError = ConfigurationSetDoesNotExistException | InvalidDeliveryOptionsException | CommonErrors;
/**
 * Adds or updates the delivery options for a configuration set.
 */
export declare const putConfigurationSetDeliveryOptions: API.OperationMethod<PutConfigurationSetDeliveryOptionsRequest, PutConfigurationSetDeliveryOptionsResponse, PutConfigurationSetDeliveryOptionsError, Credentials | HttpClient.HttpClient>;
export type PutIdentityPolicyError = InvalidPolicyException | CommonErrors;
/**
 * Adds or updates a sending authorization policy for the specified identity (an email
 * address or a domain).
 *
 * This operation is for the identity owner only. If you have not verified the
 * identity, it returns an error.
 *
 * Sending authorization is a feature that enables an identity owner to authorize other
 * senders to use its identities. For information about using sending authorization, see
 * the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const putIdentityPolicy: API.OperationMethod<PutIdentityPolicyRequest, PutIdentityPolicyResponse, PutIdentityPolicyError, Credentials | HttpClient.HttpClient>;
export type ReorderReceiptRuleSetError = RuleDoesNotExistException | RuleSetDoesNotExistException | CommonErrors;
/**
 * Reorders the receipt rules within a receipt rule set.
 *
 * All of the rules in the rule set must be represented in this request. That is, it
 * is error if the reorder request doesn't explicitly position all of the rules.
 *
 * For information about managing receipt rule sets, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const reorderReceiptRuleSet: API.OperationMethod<ReorderReceiptRuleSetRequest, ReorderReceiptRuleSetResponse, ReorderReceiptRuleSetError, Credentials | HttpClient.HttpClient>;
export type SendBounceError = MessageRejected | CommonErrors;
/**
 * Generates and sends a bounce message to the sender of an email you received through
 * Amazon SES. You can only use this operation on an email up to 24 hours after you receive
 * it.
 *
 * You cannot use this operation to send generic bounces for mail that was not
 * received by Amazon SES.
 *
 * For information about receiving email through Amazon SES, see the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const sendBounce: API.OperationMethod<SendBounceRequest, SendBounceResponse, SendBounceError, Credentials | HttpClient.HttpClient>;
export type SendBulkTemplatedEmailError = AccountSendingPausedException | ConfigurationSetDoesNotExistException | ConfigurationSetSendingPausedException | MailFromDomainNotVerifiedException | MessageRejected | TemplateDoesNotExistException | CommonErrors;
/**
 * Composes an email message to multiple destinations. The message body is created using
 * an email template.
 *
 * To send email using this operation, your call must meet the following
 * requirements:
 *
 * - The call must refer to an existing email template. You can create email
 * templates using CreateTemplate.
 *
 * - The message must be sent from a verified email address or domain.
 *
 * - If your account is still in the Amazon SES sandbox, you may send only to verified
 * addresses or domains, or to email addresses associated with the Amazon SES Mailbox
 * Simulator. For more information, see Verifying Email
 * Addresses and Domains in the Amazon SES Developer
 * Guide.
 *
 * - The maximum message size is 10 MB.
 *
 * - Each `Destination` parameter must include at least one recipient
 * email address. The recipient address can be a To: address, a CC: address, or a
 * BCC: address. If a recipient email address is invalid (that is, it is not in the
 * format *UserName@[SubDomain.]Domain.TopLevelDomain*), the
 * entire message is rejected, even if the message contains other recipients that
 * are valid.
 *
 * - The message may not include more than 50 recipients, across the To:, CC: and
 * BCC: fields. If you need to send an email message to a larger audience, you can
 * divide your recipient list into groups of 50 or fewer, and then call the
 * `SendBulkTemplatedEmail` operation several times to send the
 * message to each group.
 *
 * - The number of destinations you can contact in a single call can be limited by
 * your account's maximum sending rate.
 */
export declare const sendBulkTemplatedEmail: API.OperationMethod<SendBulkTemplatedEmailRequest, SendBulkTemplatedEmailResponse, SendBulkTemplatedEmailError, Credentials | HttpClient.HttpClient>;
export type SendCustomVerificationEmailError = ConfigurationSetDoesNotExistException | CustomVerificationEmailTemplateDoesNotExistException | FromEmailAddressNotVerifiedException | MessageRejected | ProductionAccessNotGrantedException | CommonErrors;
/**
 * Adds an email address to the list of identities for your Amazon SES account in the current
 * Amazon Web Services Region and attempts to verify it. As a result of executing this operation, a
 * customized verification email is sent to the specified address.
 *
 * To use this operation, you must first create a custom verification email template. For
 * more information about creating and using custom verification email templates, see
 * Using
 * Custom Verification Email Templates in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const sendCustomVerificationEmail: API.OperationMethod<SendCustomVerificationEmailRequest, SendCustomVerificationEmailResponse, SendCustomVerificationEmailError, Credentials | HttpClient.HttpClient>;
export type SendEmailError = AccountSendingPausedException | ConfigurationSetDoesNotExistException | ConfigurationSetSendingPausedException | MailFromDomainNotVerifiedException | MessageRejected | CommonErrors;
/**
 * Composes an email message and immediately queues it for sending. To send email using
 * this operation, your message must meet the following requirements:
 *
 * - The message must be sent from a verified email address or domain. If you
 * attempt to send email using a non-verified address or domain, the operation
 * results in an "Email address not verified" error.
 *
 * - If your account is still in the Amazon SES sandbox, you may only send to verified
 * addresses or domains, or to email addresses associated with the Amazon SES Mailbox
 * Simulator. For more information, see Verifying Email
 * Addresses and Domains in the Amazon SES Developer
 * Guide.
 *
 * - The maximum message size is 10 MB.
 *
 * - The message must include at least one recipient email address. The recipient
 * address can be a To: address, a CC: address, or a BCC: address. If a recipient
 * email address is invalid (that is, it is not in the format
 * *UserName@[SubDomain.]Domain.TopLevelDomain*), the entire
 * message is rejected, even if the message contains other recipients that are
 * valid.
 *
 * - The message may not include more than 50 recipients, across the To:, CC: and
 * BCC: fields. If you need to send an email message to a larger audience, you can
 * divide your recipient list into groups of 50 or fewer, and then call the
 * `SendEmail` operation several times to send the message to each
 * group.
 *
 * For every message that you send, the total number of recipients (including each
 * recipient in the To:, CC: and BCC: fields) is counted against the maximum number of
 * emails you can send in a 24-hour period (your *sending quota*).
 * For more information about sending quotas in Amazon SES, see Managing Your Amazon SES Sending
 * Limits in the *Amazon SES Developer Guide.*
 */
export declare const sendEmail: API.OperationMethod<SendEmailRequest, SendEmailResponse, SendEmailError, Credentials | HttpClient.HttpClient>;
export type SendRawEmailError = AccountSendingPausedException | ConfigurationSetDoesNotExistException | ConfigurationSetSendingPausedException | MailFromDomainNotVerifiedException | MessageRejected | CommonErrors;
/**
 * Composes an email message and immediately queues it for sending.
 *
 * This operation is more flexible than the `SendEmail` operation. When you
 * use the `SendRawEmail` operation, you can specify the headers of the message
 * as well as its content. This flexibility is useful, for example, when you need to send a
 * multipart MIME email (such a message that contains both a text and an HTML version). You
 * can also use this operation to send messages that include attachments.
 *
 * The `SendRawEmail` operation has the following requirements:
 *
 * - You can only send email from verified email addresses or domains. If you try to send email from
 * an address that isn't verified, the operation results in an "Email address not
 * verified" error.
 *
 * - If your account is still in the Amazon SES sandbox, you can only send email to other verified addresses
 * in your account, or to addresses that are associated with the Amazon SES mailbox simulator.
 *
 * - The maximum message size, including attachments, is 10 MB.
 *
 * - Each message has to include at least one recipient address. A recipient
 * address includes any address on the To:, CC:, or BCC: lines.
 *
 * - If you send a single message to more than one recipient address, and one of
 * the recipient addresses isn't in a valid format (that is, it's not in the format
 * *UserName@[SubDomain.]Domain.TopLevelDomain*), Amazon SES
 * rejects the entire message, even if the other addresses are valid.
 *
 * - Each message can include up to 50 recipient addresses across the To:, CC:, or
 * BCC: lines. If you need to send a single message to more than 50 recipients, you
 * have to split the list of recipient addresses into groups of less than 50
 * recipients, and send separate messages to each group.
 *
 * - Amazon SES allows you to specify 8-bit Content-Transfer-Encoding for MIME message
 * parts. However, if Amazon SES has to modify the contents of your message (for
 * example, if you use open and click tracking), 8-bit content isn't preserved. For
 * this reason, we highly recommend that you encode all content that isn't 7-bit
 * ASCII. For more information, see MIME Encoding in the Amazon SES Developer
 * Guide.
 *
 * Additionally, keep the following considerations in mind when using the
 * `SendRawEmail` operation:
 *
 * - Although you can customize the message headers when using the
 * `SendRawEmail` operation, Amazon SES automatically applies its own
 * `Message-ID` and `Date` headers; if you passed these
 * headers when creating the message, they are overwritten by the values that Amazon SES
 * provides.
 *
 * - If you are using sending authorization to send on behalf of another user,
 * `SendRawEmail` enables you to specify the cross-account identity
 * for the email's Source, From, and Return-Path parameters in one of two ways: you
 * can pass optional parameters `SourceArn`, `FromArn`,
 * and/or `ReturnPathArn`, or you can include the following X-headers in
 * the header of your raw email:
 *
 * - `X-SES-SOURCE-ARN`
 *
 * - `X-SES-FROM-ARN`
 *
 * - `X-SES-RETURN-PATH-ARN`
 *
 * Don't include these X-headers in the DKIM signature. Amazon SES removes these
 * before it sends the email.
 *
 * If you only specify the `SourceIdentityArn` parameter, Amazon SES sets
 * the From and Return-Path addresses to the same identity that you
 * specified.
 *
 * For more information about sending authorization, see the Using
 * Sending Authorization with Amazon SES in the Amazon SES Developer
 * Guide.
 *
 * - For every message that you send, the total number of recipients (including
 * each recipient in the To:, CC: and BCC: fields) is counted against the maximum
 * number of emails you can send in a 24-hour period (your sending
 * quota). For more information about sending quotas in Amazon SES, see
 * Managing Your Amazon SES Sending Limits in the Amazon SES Developer
 * Guide.
 */
export declare const sendRawEmail: API.OperationMethod<SendRawEmailRequest, SendRawEmailResponse, SendRawEmailError, Credentials | HttpClient.HttpClient>;
export type SendTemplatedEmailError = AccountSendingPausedException | ConfigurationSetDoesNotExistException | ConfigurationSetSendingPausedException | MailFromDomainNotVerifiedException | MessageRejected | TemplateDoesNotExistException | CommonErrors;
/**
 * Composes an email message using an email template and immediately queues it for
 * sending.
 *
 * To send email using this operation, your call must meet the following
 * requirements:
 *
 * - The call must refer to an existing email template. You can create email
 * templates using the CreateTemplate operation.
 *
 * - The message must be sent from a verified email address or domain.
 *
 * - If your account is still in the Amazon SES sandbox, you may only send to verified
 * addresses or domains, or to email addresses associated with the Amazon SES Mailbox
 * Simulator. For more information, see Verifying Email
 * Addresses and Domains in the Amazon SES Developer
 * Guide.
 *
 * - The maximum message size is 10 MB.
 *
 * - Calls to the `SendTemplatedEmail` operation may only include one
 * `Destination` parameter. A destination is a set of recipients
 * that receives the same version of the email. The `Destination`
 * parameter can include up to 50 recipients, across the To:, CC: and BCC:
 * fields.
 *
 * - The `Destination` parameter must include at least one recipient
 * email address. The recipient address can be a To: address, a CC: address, or a
 * BCC: address. If a recipient email address is invalid (that is, it is not in the
 * format *UserName@[SubDomain.]Domain.TopLevelDomain*), the
 * entire message is rejected, even if the message contains other recipients that
 * are valid.
 *
 * If your call to the `SendTemplatedEmail` operation includes all of the
 * required parameters, Amazon SES accepts it and returns a Message ID. However, if Amazon SES
 * can't render the email because the template contains errors, it doesn't send the
 * email. Additionally, because it already accepted the message, Amazon SES doesn't return a
 * message stating that it was unable to send the email.
 *
 * For these reasons, we highly recommend that you set up Amazon SES to send you
 * notifications when Rendering Failure events occur. For more information, see Sending Personalized Email Using the Amazon SES API in the
 * *Amazon Simple Email Service Developer Guide*.
 */
export declare const sendTemplatedEmail: API.OperationMethod<SendTemplatedEmailRequest, SendTemplatedEmailResponse, SendTemplatedEmailError, Credentials | HttpClient.HttpClient>;
export type SetActiveReceiptRuleSetError = RuleSetDoesNotExistException | CommonErrors;
/**
 * Sets the specified receipt rule set as the active receipt rule set.
 *
 * To disable your email-receiving through Amazon SES completely, you can call this
 * operation with `RuleSetName` set to null.
 *
 * For information about managing receipt rule sets, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const setActiveReceiptRuleSet: API.OperationMethod<SetActiveReceiptRuleSetRequest, SetActiveReceiptRuleSetResponse, SetActiveReceiptRuleSetError, Credentials | HttpClient.HttpClient>;
export type SetIdentityDkimEnabledError = CommonErrors;
/**
 * Enables or disables Easy DKIM signing of email sent from an identity. If Easy DKIM
 * signing is enabled for a domain, then Amazon SES uses DKIM to sign all email that it sends
 * from addresses on that domain. If Easy DKIM signing is enabled for an email address,
 * then Amazon SES uses DKIM to sign all email it sends from that address.
 *
 * For email addresses (for example, `user@example.com`), you can only
 * enable DKIM signing if the corresponding domain (in this case,
 * `example.com`) has been set up to use Easy DKIM.
 *
 * You can enable DKIM signing for an identity at any time after you start the
 * verification process for the identity, even if the verification process isn't complete.
 *
 * You can execute this operation no more than once per second.
 *
 * For more information about Easy DKIM signing, go to the Amazon SES Developer
 * Guide.
 */
export declare const setIdentityDkimEnabled: API.OperationMethod<SetIdentityDkimEnabledRequest, SetIdentityDkimEnabledResponse, SetIdentityDkimEnabledError, Credentials | HttpClient.HttpClient>;
export type SetIdentityFeedbackForwardingEnabledError = CommonErrors;
/**
 * Given an identity (an email address or a domain), enables or disables whether Amazon SES
 * forwards bounce and complaint notifications as email. Feedback forwarding can only be
 * disabled when Amazon Simple Notification Service (Amazon SNS) topics are specified for both bounces and
 * complaints.
 *
 * Feedback forwarding does not apply to delivery notifications. Delivery
 * notifications are only available through Amazon SNS.
 *
 * You can execute this operation no more than once per second.
 *
 * For more information about using notifications with Amazon SES, see the Amazon SES
 * Developer Guide.
 */
export declare const setIdentityFeedbackForwardingEnabled: API.OperationMethod<SetIdentityFeedbackForwardingEnabledRequest, SetIdentityFeedbackForwardingEnabledResponse, SetIdentityFeedbackForwardingEnabledError, Credentials | HttpClient.HttpClient>;
export type SetIdentityHeadersInNotificationsEnabledError = CommonErrors;
/**
 * Given an identity (an email address or a domain), sets whether Amazon SES includes the
 * original email headers in the Amazon Simple Notification Service (Amazon SNS) notifications of a specified
 * type.
 *
 * You can execute this operation no more than once per second.
 *
 * For more information about using notifications with Amazon SES, see the Amazon SES
 * Developer Guide.
 */
export declare const setIdentityHeadersInNotificationsEnabled: API.OperationMethod<SetIdentityHeadersInNotificationsEnabledRequest, SetIdentityHeadersInNotificationsEnabledResponse, SetIdentityHeadersInNotificationsEnabledError, Credentials | HttpClient.HttpClient>;
export type SetIdentityMailFromDomainError = CommonErrors;
/**
 * Enables or disables the custom MAIL FROM domain setup for a verified identity (an
 * email address or a domain).
 *
 * To send emails using the specified MAIL FROM domain, you must add an MX record to
 * your MAIL FROM domain's DNS settings. To ensure that your emails pass Sender Policy
 * Framework (SPF) checks, you must also add or update an SPF record. For more
 * information, see the Amazon SES Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const setIdentityMailFromDomain: API.OperationMethod<SetIdentityMailFromDomainRequest, SetIdentityMailFromDomainResponse, SetIdentityMailFromDomainError, Credentials | HttpClient.HttpClient>;
export type SetIdentityNotificationTopicError = CommonErrors;
/**
 * Sets an Amazon Simple Notification Service (Amazon SNS) topic to use when delivering notifications. When you use
 * this operation, you specify a verified identity, such as an email address or domain.
 * When you send an email that uses the chosen identity in the Source field, Amazon SES sends
 * notifications to the topic you specified. You can send bounce, complaint, or delivery
 * notifications (or any combination of the three) to the Amazon SNS topic that you
 * specify.
 *
 * You can execute this operation no more than once per second.
 *
 * For more information about feedback notification, see the Amazon SES
 * Developer Guide.
 */
export declare const setIdentityNotificationTopic: API.OperationMethod<SetIdentityNotificationTopicRequest, SetIdentityNotificationTopicResponse, SetIdentityNotificationTopicError, Credentials | HttpClient.HttpClient>;
export type SetReceiptRulePositionError = RuleDoesNotExistException | RuleSetDoesNotExistException | CommonErrors;
/**
 * Sets the position of the specified receipt rule in the receipt rule set.
 *
 * For information about managing receipt rules, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const setReceiptRulePosition: API.OperationMethod<SetReceiptRulePositionRequest, SetReceiptRulePositionResponse, SetReceiptRulePositionError, Credentials | HttpClient.HttpClient>;
export type TestRenderTemplateError = InvalidRenderingParameterException | MissingRenderingAttributeException | TemplateDoesNotExistException | CommonErrors;
/**
 * Creates a preview of the MIME content of an email when provided with a template and a
 * set of replacement data.
 *
 * You can execute this operation no more than once per second.
 */
export declare const testRenderTemplate: API.OperationMethod<TestRenderTemplateRequest, TestRenderTemplateResponse, TestRenderTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountSendingEnabledError = CommonErrors;
/**
 * Enables or disables email sending across your entire Amazon SES account in the current
 * Amazon Web Services Region. You can use this operation in conjunction with Amazon CloudWatch alarms to
 * temporarily pause email sending across your Amazon SES account in a given Amazon Web Services Region when
 * reputation metrics (such as your bounce or complaint rates) reach certain
 * thresholds.
 *
 * You can execute this operation no more than once per second.
 */
export declare const updateAccountSendingEnabled: API.OperationMethod<UpdateAccountSendingEnabledRequest, UpdateAccountSendingEnabledResponse, UpdateAccountSendingEnabledError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationSetEventDestinationError = ConfigurationSetDoesNotExistException | EventDestinationDoesNotExistException | InvalidCloudWatchDestinationException | InvalidFirehoseDestinationException | InvalidSNSDestinationException | CommonErrors;
/**
 * Updates the event destination of a configuration set. Event destinations are
 * associated with configuration sets, which enable you to publish email sending events to
 * Amazon CloudWatch, Amazon Kinesis Firehose, or Amazon Simple Notification Service (Amazon SNS). For information about using configuration sets,
 * see Monitoring Your Amazon SES Sending Activity in the Amazon SES Developer
 * Guide.
 *
 * When you create or update an event destination, you must provide one, and only
 * one, destination. The destination can be Amazon CloudWatch, Amazon Kinesis Firehose, or Amazon Simple Notification Service
 * (Amazon SNS).
 *
 * You can execute this operation no more than once per second.
 */
export declare const updateConfigurationSetEventDestination: API.OperationMethod<UpdateConfigurationSetEventDestinationRequest, UpdateConfigurationSetEventDestinationResponse, UpdateConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationSetReputationMetricsEnabledError = ConfigurationSetDoesNotExistException | CommonErrors;
/**
 * Enables or disables the publishing of reputation metrics for emails sent using a
 * specific configuration set in a given Amazon Web Services Region. Reputation metrics include bounce
 * and complaint rates. These metrics are published to Amazon CloudWatch. By using CloudWatch, you can
 * create alarms when bounce or complaint rates exceed certain thresholds.
 *
 * You can execute this operation no more than once per second.
 */
export declare const updateConfigurationSetReputationMetricsEnabled: API.OperationMethod<UpdateConfigurationSetReputationMetricsEnabledRequest, UpdateConfigurationSetReputationMetricsEnabledResponse, UpdateConfigurationSetReputationMetricsEnabledError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationSetSendingEnabledError = ConfigurationSetDoesNotExistException | CommonErrors;
/**
 * Enables or disables email sending for messages sent using a specific configuration set
 * in a given Amazon Web Services Region. You can use this operation in conjunction with Amazon CloudWatch alarms
 * to temporarily pause email sending for a configuration set when the reputation metrics
 * for that configuration set (such as your bounce on complaint rate) exceed certain
 * thresholds.
 *
 * You can execute this operation no more than once per second.
 */
export declare const updateConfigurationSetSendingEnabled: API.OperationMethod<UpdateConfigurationSetSendingEnabledRequest, UpdateConfigurationSetSendingEnabledResponse, UpdateConfigurationSetSendingEnabledError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationSetTrackingOptionsError = ConfigurationSetDoesNotExistException | InvalidTrackingOptionsException | TrackingOptionsDoesNotExistException | CommonErrors;
/**
 * Modifies an association between a configuration set and a custom domain for open and
 * click event tracking.
 *
 * By default, images and links used for tracking open and click events are hosted on
 * domains operated by Amazon SES. You can configure a subdomain of your own to handle these
 * events. For information about using custom domains, see the Amazon SES Developer Guide.
 */
export declare const updateConfigurationSetTrackingOptions: API.OperationMethod<UpdateConfigurationSetTrackingOptionsRequest, UpdateConfigurationSetTrackingOptionsResponse, UpdateConfigurationSetTrackingOptionsError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomVerificationEmailTemplateError = CustomVerificationEmailInvalidContentException | CustomVerificationEmailTemplateDoesNotExistException | FromEmailAddressNotVerifiedException | CommonErrors;
/**
 * Updates an existing custom verification email template.
 *
 * For more information about custom verification email templates, see Using
 * Custom Verification Email Templates in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const updateCustomVerificationEmailTemplate: API.OperationMethod<UpdateCustomVerificationEmailTemplateRequest, UpdateCustomVerificationEmailTemplateResponse, UpdateCustomVerificationEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateReceiptRuleError = InvalidLambdaFunctionException | InvalidS3ConfigurationException | InvalidSnsTopicException | LimitExceededException | RuleDoesNotExistException | RuleSetDoesNotExistException | InvalidParameterValue | IdentityNotVerified | ReceiptRuleRoleNotAssumable | CommonErrors;
/**
 * Updates a receipt rule.
 *
 * For information about managing receipt rules, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const updateReceiptRule: API.OperationMethod<UpdateReceiptRuleRequest, UpdateReceiptRuleResponse, UpdateReceiptRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplateError = InvalidTemplateException | TemplateDoesNotExistException | CommonErrors;
/**
 * Updates an email template. Email templates enable you to send personalized email to
 * one or more destinations in a single operation. For more information, see the Amazon SES
 * Developer Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const updateTemplate: API.OperationMethod<UpdateTemplateRequest, UpdateTemplateResponse, UpdateTemplateError, Credentials | HttpClient.HttpClient>;
export type VerifyDomainDkimError = CommonErrors;
/**
 * Returns a set of DKIM tokens for a domain identity.
 *
 * When you execute the `VerifyDomainDkim` operation, the domain that you
 * specify is added to the list of identities that are associated with your account.
 * This is true even if you haven't already associated the domain with your account by
 * using the `VerifyDomainIdentity` operation. However, you can't send email
 * from the domain until you either successfully verify
 * it or you successfully set up DKIM for
 * it.
 *
 * You use the tokens that are generated by this operation to create CNAME records. When
 * Amazon SES detects that you've added these records to the DNS configuration for a domain, you
 * can start sending email from that domain. You can start sending email even if you
 * haven't added the TXT record provided by the VerifyDomainIdentity operation to the DNS
 * configuration for your domain. All email that you send from the domain is authenticated
 * using DKIM.
 *
 * To create the CNAME records for DKIM authentication, use the following values:
 *
 * - **Name**:
 * *token*._domainkey.*example.com*
 *
 * - **Type**: CNAME
 *
 * - **Value**:
 * *token*.dkim.amazonses.com
 *
 * In the preceding example, replace *token* with one of the tokens
 * that are generated when you execute this operation. Replace
 * *example.com* with your domain. Repeat this process for each
 * token that's generated by this operation.
 *
 * You can execute this operation no more than once per second.
 */
export declare const verifyDomainDkim: API.OperationMethod<VerifyDomainDkimRequest, VerifyDomainDkimResponse, VerifyDomainDkimError, Credentials | HttpClient.HttpClient>;
export type VerifyDomainIdentityError = CommonErrors;
/**
 * Adds a domain to the list of identities for your Amazon SES account in the current
 * Amazon Web Services Region and attempts to verify it. For more information about verifying domains,
 * see Verifying Email Addresses and Domains in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const verifyDomainIdentity: API.OperationMethod<VerifyDomainIdentityRequest, VerifyDomainIdentityResponse, VerifyDomainIdentityError, Credentials | HttpClient.HttpClient>;
export type VerifyEmailAddressError = CommonErrors;
/**
 * Deprecated. Use the `VerifyEmailIdentity` operation to verify a new email
 * address.
 */
export declare const verifyEmailAddress: API.OperationMethod<VerifyEmailAddressRequest, VerifyEmailAddressResponse, VerifyEmailAddressError, Credentials | HttpClient.HttpClient>;
export type VerifyEmailIdentityError = CommonErrors;
/**
 * Adds an email address to the list of identities for your Amazon SES account in the current
 * Amazon Web Services Region and attempts to verify it. As a result of executing this operation, a
 * verification email is sent to the specified address.
 *
 * You can execute this operation no more than once per second.
 */
export declare const verifyEmailIdentity: API.OperationMethod<VerifyEmailIdentityRequest, VerifyEmailIdentityResponse, VerifyEmailIdentityError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ses.d.ts.map