import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DependencyException_base: S.TaggedErrorClass<"DependencyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DependencyException extends /*@__PURE__*/ DependencyException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceLinkedRoleLockClientException_base: S.TaggedErrorClass<"ServiceLinkedRoleLockClientException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceLinkedRoleLockClientException extends /*@__PURE__*/ ServiceLinkedRoleLockClientException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ApplicationComponentId = string;
export interface GetApplicationComponentDetailsRequest {
    applicationComponentId: string;
}
export type ResourceId = string;
export type ResourceName = string;
export type TransformationToolName = string;
export type TranformationToolDescription = string;
export type TranformationToolInstallationLink = string;
export interface TransformationTool {
    name?: string;
    description?: string;
    tranformationToolInstallationLink?: string;
}
export type TargetDestination = string;
export type Strategy = string;
export interface RecommendationSet {
    transformationTool?: TransformationTool;
    targetDestination?: string;
    strategy?: string;
}
export type SrcCodeOrDbAnalysisStatus = string;
export type StatusMessage = string;
export type Severity = string;
export interface AntipatternSeveritySummary {
    severity?: string;
    count?: number;
}
export type ListAntipatternSeveritySummary = AntipatternSeveritySummary[];
export interface DatabaseConfigDetail {
    secretName?: string;
}
export interface SourceCodeRepository {
    repository?: string;
    branch?: string;
    versionControlType?: string;
    projectName?: string;
}
export type SourceCodeRepositories = SourceCodeRepository[];
export type AppType = string;
export type ResourceSubType = string;
export type InclusionStatus = string;
export type S3Bucket = string;
export type S3Key = string;
export interface S3Object {
    s3Bucket?: string;
    s3key?: string;
}
export type AntipatternReportStatus = string;
export type ServerId = string;
export type RuntimeAnalysisStatus = string;
export type AppUnitErrorCategory = string;
export interface AppUnitError {
    appUnitErrorCategory?: string;
}
export type AnalysisType = string;
export type AnalysisStatusUnion = {
    runtimeAnalysisStatus: string;
    srcCodeOrDbAnalysisStatus?: never;
} | {
    runtimeAnalysisStatus?: never;
    srcCodeOrDbAnalysisStatus: string;
};
export type BinaryAnalyzerName = string;
export type RunTimeAnalyzerName = string;
export type SourceCodeAnalyzerName = string;
export type AnalyzerNameUnion = {
    binaryAnalyzerName: string;
    runTimeAnalyzerName?: never;
    sourceCodeAnalyzerName?: never;
} | {
    binaryAnalyzerName?: never;
    runTimeAnalyzerName: string;
    sourceCodeAnalyzerName?: never;
} | {
    binaryAnalyzerName?: never;
    runTimeAnalyzerName?: never;
    sourceCodeAnalyzerName: string;
};
export interface AntipatternReportResult {
    analyzerName?: AnalyzerNameUnion;
    antiPatternReportS3Object?: S3Object;
    antipatternReportStatus?: string;
    antipatternReportStatusMessage?: string;
}
export type AntipatternReportResultList = AntipatternReportResult[];
export interface Result {
    analysisType?: string;
    analysisStatus?: AnalysisStatusUnion;
    statusMessage?: string;
    antipatternReportResultList?: AntipatternReportResult[];
}
export type ResultList = Result[];
export interface ApplicationComponentDetail {
    id?: string;
    name?: string;
    recommendationSet?: RecommendationSet;
    analysisStatus?: string;
    statusMessage?: string;
    listAntipatternSeveritySummary?: AntipatternSeveritySummary[];
    databaseConfigDetail?: DatabaseConfigDetail;
    sourceCodeRepositories?: SourceCodeRepository[];
    appType?: string;
    resourceSubType?: string;
    inclusionStatus?: string;
    antipatternReportS3Object?: S3Object;
    antipatternReportStatus?: string;
    antipatternReportStatusMessage?: string;
    osVersion?: string;
    osDriver?: string;
    lastAnalyzedTimestamp?: Date;
    associatedServerId?: string;
    moreServerAssociationExists?: boolean;
    runtimeStatus?: string;
    runtimeStatusMessage?: string;
    appUnitError?: AppUnitError;
    resultList?: Result[];
}
export interface AssociatedApplication {
    name?: string;
    id?: string;
}
export type AssociatedApplications = AssociatedApplication[];
export type AssociatedServerIDs = string[];
export interface GetApplicationComponentDetailsResponse {
    applicationComponentDetail?: ApplicationComponentDetail;
    associatedApplications?: AssociatedApplication[];
    moreApplicationResource?: boolean;
    associatedServerIds?: string[];
}
export interface GetApplicationComponentStrategiesRequest {
    applicationComponentId: string;
}
export type StrategyRecommendation = string;
export interface ApplicationComponentStrategy {
    recommendation?: RecommendationSet;
    status?: string;
    isPreferred?: boolean;
}
export type ApplicationComponentStrategies = ApplicationComponentStrategy[];
export interface GetApplicationComponentStrategiesResponse {
    applicationComponentStrategies?: ApplicationComponentStrategy[];
}
export type AsyncTaskId = string;
export interface GetAssessmentRequest {
    id: string;
}
export type AssessmentStatus = string;
export type AssessmentStatusMessage = string;
export interface DataCollectionDetails {
    status?: string;
    servers?: number;
    failed?: number;
    success?: number;
    inProgress?: number;
    startTime?: Date;
    completionTime?: Date;
    statusMessage?: string;
}
export type Condition = string;
export type AssessmentTargetValues = string[];
export interface AssessmentTarget {
    condition: string;
    name: string;
    values: string[];
}
export type AssessmentTargets = AssessmentTarget[];
export interface GetAssessmentResponse {
    id?: string;
    dataCollectionDetails?: DataCollectionDetails;
    assessmentTargets?: AssessmentTarget[];
}
export interface GetImportFileTaskRequest {
    id: string;
}
export type ImportFileTaskStatus = string;
export type ImportS3Bucket = string;
export type ImportS3Key = string;
export interface GetImportFileTaskResponse {
    id?: string;
    status?: string;
    startTime?: Date;
    inputS3Bucket?: string;
    inputS3Key?: string;
    statusReportS3Bucket?: string;
    statusReportS3Key?: string;
    completionTime?: Date;
    numberOfRecordsSuccess?: number;
    numberOfRecordsFailed?: number;
    importName?: string;
}
export interface GetLatestAssessmentIdRequest {
}
export interface GetLatestAssessmentIdResponse {
    id?: string;
}
export interface GetPortfolioPreferencesRequest {
}
export type BusinessGoalsInteger = number;
export interface BusinessGoals {
    speedOfMigration?: number;
    reduceOperationalOverheadWithManagedServices?: number;
    modernizeInfrastructureWithCloudNativeTechnologies?: number;
    licenseCostReduction?: number;
}
export interface PrioritizeBusinessGoals {
    businessGoals?: BusinessGoals;
}
export type AwsManagedTargetDestination = string;
export type AwsManagedTargetDestinations = string[];
export interface AwsManagedResources {
    targetDestination: string[];
}
export type SelfManageTargetDestination = string;
export type SelfManageTargetDestinations = string[];
export interface SelfManageResources {
    targetDestination: string[];
}
export type NoPreferenceTargetDestination = string;
export type NoPreferenceTargetDestinations = string[];
export interface NoManagementPreference {
    targetDestination: string[];
}
export type ManagementPreference = {
    awsManagedResources: AwsManagedResources;
    selfManageResources?: never;
    noPreference?: never;
} | {
    awsManagedResources?: never;
    selfManageResources: SelfManageResources;
    noPreference?: never;
} | {
    awsManagedResources?: never;
    selfManageResources?: never;
    noPreference: NoManagementPreference;
};
export interface ApplicationPreferences {
    managementPreference?: ManagementPreference;
}
export type DatabaseManagementPreference = string;
export type HeterogeneousTargetDatabaseEngine = string;
export type HeterogeneousTargetDatabaseEngines = string[];
export interface Heterogeneous {
    targetDatabaseEngine: string[];
}
export type HomogeneousTargetDatabaseEngine = string;
export type HomogeneousTargetDatabaseEngines = string[];
export interface Homogeneous {
    targetDatabaseEngine?: string[];
}
export type TargetDatabaseEngine = string;
export type TargetDatabaseEngines = string[];
export interface NoDatabaseMigrationPreference {
    targetDatabaseEngine: string[];
}
export type DatabaseMigrationPreference = {
    heterogeneous: Heterogeneous;
    homogeneous?: never;
    noPreference?: never;
} | {
    heterogeneous?: never;
    homogeneous: Homogeneous;
    noPreference?: never;
} | {
    heterogeneous?: never;
    homogeneous?: never;
    noPreference: NoDatabaseMigrationPreference;
};
export interface DatabasePreferences {
    databaseManagementPreference?: string;
    databaseMigrationPreference?: DatabaseMigrationPreference;
}
export type ApplicationMode = string;
export interface GetPortfolioPreferencesResponse {
    prioritizeBusinessGoals?: PrioritizeBusinessGoals;
    applicationPreferences?: ApplicationPreferences;
    databasePreferences?: DatabasePreferences;
    applicationMode?: string;
}
export interface GetPortfolioSummaryRequest {
}
export interface StrategySummary {
    strategy?: string;
    count?: number;
}
export type ListStrategySummary = StrategySummary[];
export interface ApplicationComponentSummary {
    appType?: string;
    count?: number;
}
export type ListApplicationComponentSummary = ApplicationComponentSummary[];
export type ServerOsType = string;
export interface ServerSummary {
    ServerOsType?: string;
    count?: number;
}
export type ListServerSummary = ServerSummary[];
export interface ApplicationComponentStatusSummary {
    srcCodeOrDbAnalysisStatus?: string;
    count?: number;
}
export type ListApplicationComponentStatusSummary = ApplicationComponentStatusSummary[];
export type RunTimeAssessmentStatus = string;
export interface ServerStatusSummary {
    runTimeAssessmentStatus?: string;
    count?: number;
}
export type ListServerStatusSummary = ServerStatusSummary[];
export interface AssessmentSummary {
    listServerStrategySummary?: StrategySummary[];
    listApplicationComponentStrategySummary?: StrategySummary[];
    listAntipatternSeveritySummary?: AntipatternSeveritySummary[];
    listApplicationComponentSummary?: ApplicationComponentSummary[];
    listServerSummary?: ServerSummary[];
    antipatternReportS3Object?: S3Object;
    antipatternReportStatus?: string;
    antipatternReportStatusMessage?: string;
    lastAnalyzedTimestamp?: Date;
    listApplicationComponentStatusSummary?: ApplicationComponentStatusSummary[];
    listServerStatusSummary?: ServerStatusSummary[];
}
export interface GetPortfolioSummaryResponse {
    assessmentSummary?: AssessmentSummary;
}
export type RecommendationTaskId = string;
export interface GetRecommendationReportDetailsRequest {
    id: string;
}
export type RecommendationReportStatus = string;
export type RecommendationReportStatusMessage = string;
export type RecommendationReportTimeStamp = Date;
export type S3Keys = string[];
export interface RecommendationReportDetails {
    status?: string;
    statusMessage?: string;
    startTime?: Date;
    completionTime?: Date;
    s3Bucket?: string;
    s3Keys?: string[];
}
export interface GetRecommendationReportDetailsResponse {
    id?: string;
    recommendationReportDetails?: RecommendationReportDetails;
}
export type NextToken = string;
export type MaxResult = number;
export interface GetServerDetailsRequest {
    serverId: string;
    nextToken?: string;
    maxResults?: number;
}
export type OSType = string;
export type OSVersion = string;
export interface OSInfo {
    type?: string;
    version?: string;
}
export type InterfaceName = string;
export type IPAddress = string;
export type MacAddress = string;
export type NetMask = string;
export interface NetworkInfo {
    interfaceName: string;
    ipAddress: string;
    macAddress: string;
    netMask: string;
}
export type NetworkInfoList = NetworkInfo[];
export interface SystemInfo {
    osInfo?: OSInfo;
    fileSystemType?: string;
    networkInfoList?: NetworkInfo[];
    cpuArchitecture?: string;
}
export type ServerErrorCategory = string;
export interface ServerError {
    serverErrorCategory?: string;
}
export interface ServerDetail {
    id?: string;
    name?: string;
    recommendationSet?: RecommendationSet;
    dataCollectionStatus?: string;
    statusMessage?: string;
    listAntipatternSeveritySummary?: AntipatternSeveritySummary[];
    systemInfo?: SystemInfo;
    applicationComponentStrategySummary?: StrategySummary[];
    antipatternReportS3Object?: S3Object;
    antipatternReportStatus?: string;
    antipatternReportStatusMessage?: string;
    serverType?: string;
    lastAnalyzedTimestamp?: Date;
    serverError?: ServerError;
}
export interface GetServerDetailsResponse {
    nextToken?: string;
    serverDetail?: ServerDetail;
    associatedApplications?: AssociatedApplication[];
}
export interface GetServerStrategiesRequest {
    serverId: string;
}
export interface ServerStrategy {
    recommendation?: RecommendationSet;
    status?: string;
    numberOfApplicationComponents?: number;
    isPreferred?: boolean;
}
export type ServerStrategies = ServerStrategy[];
export interface GetServerStrategiesResponse {
    serverStrategies?: ServerStrategy[];
}
export type SortOrder = string;
export interface ListAnalyzableServersRequest {
    sort?: string;
    nextToken?: string;
    maxResults?: number;
}
export interface AnalyzableServerSummary {
    hostname?: string;
    ipAddress?: string;
    source?: string;
    vmId?: string;
}
export type AnalyzableServerSummaryList = AnalyzableServerSummary[];
export interface ListAnalyzableServersResponse {
    analyzableServers?: AnalyzableServerSummary[];
    nextToken?: string;
}
export type ApplicationComponentCriteria = string;
export type GroupName = string;
export interface Group {
    name?: string;
    value?: string;
}
export type GroupIds = Group[];
export interface ListApplicationComponentsRequest {
    applicationComponentCriteria?: string;
    filterValue?: string;
    sort?: string;
    groupIdFilter?: Group[];
    nextToken?: string;
    maxResults?: number;
}
export type ApplicationComponentDetails = ApplicationComponentDetail[];
export interface ListApplicationComponentsResponse {
    applicationComponentInfos?: ApplicationComponentDetail[];
    nextToken?: string;
}
export interface ListCollectorsRequest {
    nextToken?: string;
    maxResults?: number;
}
export type CollectorHealth = string;
export interface VcenterBasedRemoteInfo {
    vcenterConfigurationTimeStamp?: string;
    osType?: string;
}
export type VcenterBasedRemoteInfoList = VcenterBasedRemoteInfo[];
export type AuthType = string;
export interface IPAddressBasedRemoteInfo {
    ipAddressConfigurationTimeStamp?: string;
    authType?: string;
    osType?: string;
}
export type IPAddressBasedRemoteInfoList = IPAddressBasedRemoteInfo[];
export type VersionControlType = string;
export interface VersionControlInfo {
    versionControlType?: string;
    versionControlConfigurationTimeStamp?: string;
}
export type VersionControlInfoList = VersionControlInfo[];
export type PipelineType = string;
export interface PipelineInfo {
    pipelineType?: string;
    pipelineConfigurationTimeStamp?: string;
}
export type PipelineInfoList = PipelineInfo[];
export interface RemoteSourceCodeAnalysisServerInfo {
    remoteSourceCodeAnalysisServerConfigurationTimestamp?: string;
}
export interface ConfigurationSummary {
    vcenterBasedRemoteInfoList?: VcenterBasedRemoteInfo[];
    ipAddressBasedRemoteInfoList?: IPAddressBasedRemoteInfo[];
    versionControlInfoList?: VersionControlInfo[];
    pipelineInfoList?: PipelineInfo[];
    remoteSourceCodeAnalysisServerInfo?: RemoteSourceCodeAnalysisServerInfo;
}
export interface Collector {
    collectorId?: string;
    ipAddress?: string;
    hostName?: string;
    collectorHealth?: string;
    collectorVersion?: string;
    registeredTimeStamp?: string;
    lastActivityTimeStamp?: string;
    configurationSummary?: ConfigurationSummary;
}
export type Collectors = Collector[];
export interface ListCollectorsResponse {
    Collectors?: Collector[];
    nextToken?: string;
}
export interface ListImportFileTaskRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface ImportFileTaskInformation {
    id?: string;
    status?: string;
    startTime?: Date;
    inputS3Bucket?: string;
    inputS3Key?: string;
    statusReportS3Bucket?: string;
    statusReportS3Key?: string;
    completionTime?: Date;
    numberOfRecordsSuccess?: number;
    numberOfRecordsFailed?: number;
    importName?: string;
}
export type ListImportFileTaskInformation = ImportFileTaskInformation[];
export interface ListImportFileTaskResponse {
    taskInfos?: ImportFileTaskInformation[];
    nextToken?: string;
}
export type ServerCriteria = string;
export interface ListServersRequest {
    serverCriteria?: string;
    filterValue?: string;
    sort?: string;
    groupIdFilter?: Group[];
    nextToken?: string;
    maxResults?: number;
}
export type ServerDetails = ServerDetail[];
export interface ListServersResponse {
    serverInfos?: ServerDetail[];
    nextToken?: string;
}
export interface PutPortfolioPreferencesRequest {
    prioritizeBusinessGoals?: PrioritizeBusinessGoals;
    applicationPreferences?: ApplicationPreferences;
    databasePreferences?: DatabasePreferences;
    applicationMode?: string;
}
export interface PutPortfolioPreferencesResponse {
}
export type AssessmentDataSourceType = string;
export interface StartAssessmentRequest {
    s3bucketForAnalysisData?: string;
    s3bucketForReportData?: string;
    assessmentTargets?: AssessmentTarget[];
    assessmentDataSourceType?: string;
}
export interface StartAssessmentResponse {
    assessmentId?: string;
}
export type DataSourceType = string;
export interface StartImportFileTaskRequest {
    name: string;
    S3Bucket: string;
    s3key: string;
    dataSourceType?: string;
    groupId?: Group[];
    s3bucketForReportData?: string;
}
export interface StartImportFileTaskResponse {
    id?: string;
}
export type OutputFormat = string;
export interface StartRecommendationReportGenerationRequest {
    outputFormat?: string;
    groupIdFilter?: Group[];
}
export interface StartRecommendationReportGenerationResponse {
    id?: string;
}
export interface StopAssessmentRequest {
    assessmentId: string;
}
export interface StopAssessmentResponse {
}
export interface StrategyOption {
    strategy?: string;
    toolName?: string;
    targetDestination?: string;
    isPreferred?: boolean;
}
export type VersionControl = string;
export type SourceVersion = string;
export type Location = string;
export type ProjectName = string;
export interface SourceCode {
    versionControl?: string;
    sourceVersion?: string;
    location?: string;
    projectName?: string;
}
export type SourceCodeList = SourceCode[];
export type SecretsManagerKey = string | redacted.Redacted<string>;
export interface UpdateApplicationComponentConfigRequest {
    applicationComponentId: string;
    inclusionStatus?: string;
    strategyOption?: StrategyOption;
    sourceCodeList?: SourceCode[];
    secretsManagerKey?: string | redacted.Redacted<string>;
    configureOnly?: boolean;
    appType?: string;
}
export interface UpdateApplicationComponentConfigResponse {
}
export interface UpdateServerConfigRequest {
    serverId: string;
    strategyOption?: StrategyOption;
}
export interface UpdateServerConfigResponse {
}
export type ErrorMessage = string;
export type GetApplicationComponentDetailsError = InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves details about an application component.
 */
export declare const getApplicationComponentDetails: API.OperationMethod<GetApplicationComponentDetailsRequest, GetApplicationComponentDetailsResponse, GetApplicationComponentDetailsError, Credentials | HttpClient.HttpClient>;
export type GetApplicationComponentStrategiesError = InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a list of all the recommended strategies and tools for an application component
 * running on a server.
 */
export declare const getApplicationComponentStrategies: API.OperationMethod<GetApplicationComponentStrategiesRequest, GetApplicationComponentStrategiesResponse, GetApplicationComponentStrategiesError, Credentials | HttpClient.HttpClient>;
export type GetAssessmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the status of an on-going assessment.
 */
export declare const getAssessment: API.OperationMethod<GetAssessmentRequest, GetAssessmentResponse, GetAssessmentError, Credentials | HttpClient.HttpClient>;
export type GetImportFileTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details about a specific import task.
 */
export declare const getImportFileTask: API.OperationMethod<GetImportFileTaskRequest, GetImportFileTaskResponse, GetImportFileTaskError, Credentials | HttpClient.HttpClient>;
export type GetLatestAssessmentIdError = AccessDeniedException | DependencyException | InternalServerException | ValidationException | CommonErrors;
/**
 * Retrieve the latest ID of a specific assessment task.
 */
export declare const getLatestAssessmentId: API.OperationMethod<GetLatestAssessmentIdRequest, GetLatestAssessmentIdResponse, GetLatestAssessmentIdError, Credentials | HttpClient.HttpClient>;
export type GetPortfolioPreferencesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves your migration and modernization preferences.
 */
export declare const getPortfolioPreferences: API.OperationMethod<GetPortfolioPreferencesRequest, GetPortfolioPreferencesResponse, GetPortfolioPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetPortfolioSummaryError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Retrieves overall summary including the number of servers to rehost and the overall
 * number of anti-patterns.
 */
export declare const getPortfolioSummary: API.OperationMethod<GetPortfolioSummaryRequest, GetPortfolioSummaryResponse, GetPortfolioSummaryError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationReportDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about the specified recommendation report.
 */
export declare const getRecommendationReportDetails: API.OperationMethod<GetRecommendationReportDetailsRequest, GetRecommendationReportDetailsResponse, GetRecommendationReportDetailsError, Credentials | HttpClient.HttpClient>;
export type GetServerDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specified server.
 */
export declare const getServerDetails: API.PaginatedOperationMethod<GetServerDetailsRequest, GetServerDetailsResponse, GetServerDetailsError, Credentials | HttpClient.HttpClient, AssociatedApplication>;
export type GetServerStrategiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves recommended strategies and tools for the specified server.
 */
export declare const getServerStrategies: API.OperationMethod<GetServerStrategiesRequest, GetServerStrategiesResponse, GetServerStrategiesError, Credentials | HttpClient.HttpClient>;
export type ListAnalyzableServersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all the servers fetched from customer vCenter using Strategy Recommendation Collector.
 */
export declare const listAnalyzableServers: API.PaginatedOperationMethod<ListAnalyzableServersRequest, ListAnalyzableServersResponse, ListAnalyzableServersError, Credentials | HttpClient.HttpClient, AnalyzableServerSummary>;
export type ListApplicationComponentsError = AccessDeniedException | InternalServerException | ServiceLinkedRoleLockClientException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all the application components (processes).
 */
export declare const listApplicationComponents: API.PaginatedOperationMethod<ListApplicationComponentsRequest, ListApplicationComponentsResponse, ListApplicationComponentsError, Credentials | HttpClient.HttpClient, ApplicationComponentDetail>;
export type ListCollectorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all the installed collectors.
 */
export declare const listCollectors: API.PaginatedOperationMethod<ListCollectorsRequest, ListCollectorsResponse, ListCollectorsError, Credentials | HttpClient.HttpClient, Collector>;
export type ListImportFileTaskError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all the imports performed.
 */
export declare const listImportFileTask: API.PaginatedOperationMethod<ListImportFileTaskRequest, ListImportFileTaskResponse, ListImportFileTaskError, Credentials | HttpClient.HttpClient, ImportFileTaskInformation>;
export type ListServersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the servers.
 */
export declare const listServers: API.PaginatedOperationMethod<ListServersRequest, ListServersResponse, ListServersError, Credentials | HttpClient.HttpClient, ServerDetail>;
export type PutPortfolioPreferencesError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Saves the specified migration and modernization preferences.
 */
export declare const putPortfolioPreferences: API.OperationMethod<PutPortfolioPreferencesRequest, PutPortfolioPreferencesResponse, PutPortfolioPreferencesError, Credentials | HttpClient.HttpClient>;
export type StartAssessmentError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Starts the assessment of an on-premises environment.
 */
export declare const startAssessment: API.OperationMethod<StartAssessmentRequest, StartAssessmentResponse, StartAssessmentError, Credentials | HttpClient.HttpClient>;
export type StartImportFileTaskError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a file import.
 */
export declare const startImportFileTask: API.OperationMethod<StartImportFileTaskRequest, StartImportFileTaskResponse, StartImportFileTaskError, Credentials | HttpClient.HttpClient>;
export type StartRecommendationReportGenerationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts generating a recommendation report.
 */
export declare const startRecommendationReportGeneration: API.OperationMethod<StartRecommendationReportGenerationRequest, StartRecommendationReportGenerationResponse, StartRecommendationReportGenerationError, Credentials | HttpClient.HttpClient>;
export type StopAssessmentError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops the assessment of an on-premises environment.
 */
export declare const stopAssessment: API.OperationMethod<StopAssessmentRequest, StopAssessmentResponse, StopAssessmentError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationComponentConfigError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an application component.
 */
export declare const updateApplicationComponentConfig: API.OperationMethod<UpdateApplicationComponentConfigRequest, UpdateApplicationComponentConfigResponse, UpdateApplicationComponentConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateServerConfigError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of the specified server.
 */
export declare const updateServerConfig: API.OperationMethod<UpdateServerConfigRequest, UpdateServerConfigResponse, UpdateServerConfigError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=migrationhubstrategy.d.ts.map