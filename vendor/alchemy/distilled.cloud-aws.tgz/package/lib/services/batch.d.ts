import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ClientException_base: S.TaggedErrorClass<"ClientException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClientException extends /*@__PURE__*/ ClientException_base {
}
declare const ComputeEnvironmentBeingModified_base: S.TaggedErrorClass<"ComputeEnvironmentBeingModified", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ComputeEnvironmentBeingModified extends /*@__PURE__*/ ComputeEnvironmentBeingModified_base {
}
declare const ComputeEnvironmentInUse_base: S.TaggedErrorClass<"ComputeEnvironmentInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ComputeEnvironmentInUse extends /*@__PURE__*/ ComputeEnvironmentInUse_base {
}
declare const ComputeEnvironmentNotFound_base: S.TaggedErrorClass<"ComputeEnvironmentNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ComputeEnvironmentNotFound extends /*@__PURE__*/ ComputeEnvironmentNotFound_base {
}
declare const ComputeEnvironmentNotValid_base: S.TaggedErrorClass<"ComputeEnvironmentNotValid", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ComputeEnvironmentNotValid extends /*@__PURE__*/ ComputeEnvironmentNotValid_base {
}
declare const JobQueueAlreadyExists_base: S.TaggedErrorClass<"JobQueueAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class JobQueueAlreadyExists extends /*@__PURE__*/ JobQueueAlreadyExists_base {
}
declare const JobQueueBeingModified_base: S.TaggedErrorClass<"JobQueueBeingModified", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class JobQueueBeingModified extends /*@__PURE__*/ JobQueueBeingModified_base {
}
declare const JobQueueNotFound_base: S.TaggedErrorClass<"JobQueueNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class JobQueueNotFound extends /*@__PURE__*/ JobQueueNotFound_base {
}
declare const ServerException_base: S.TaggedErrorClass<"ServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServerException extends /*@__PURE__*/ ServerException_base {
}
export interface CancelJobRequest {
    jobId?: string;
    reason?: string;
}
export interface CancelJobResponse {
}
export type StringList = string[];
export interface CancelJobsRequest {
    jobs?: string[];
    reason?: string;
}
export interface CancelJobsErrorDetail {
    job?: string;
    code?: string;
    message?: string;
}
export type CancelJobsErrorDetailList = CancelJobsErrorDetail[];
export interface CancelJobsResponse {
    successful: string[];
    errors: (CancelJobsErrorDetail & {
        job: string;
        code: string;
        message: string;
    })[];
}
export type CEType = "MANAGED" | "UNMANAGED" | (string & {});
export type CEState = "ENABLED" | "DISABLED" | (string & {});
export type CRType = "EC2" | "SPOT" | "FARGATE" | "FARGATE_SPOT" | "ECS_MANAGED_INSTANCES" | (string & {});
export type CRAllocationStrategy = "BEST_FIT" | "BEST_FIT_PROGRESSIVE" | "BEST_FIT_PROGRESSIVE_ORDERED" | "SPOT_CAPACITY_OPTIMIZED" | "SPOT_PRICE_CAPACITY_OPTIMIZED" | "SPOT_CAPACITY_OPTIMIZED_PRIORITIZED" | (string & {});
export type TagsMap = {
    [key: string]: string | undefined;
};
export type UserdataType = "EKS_BOOTSTRAP_SH" | "EKS_NODEADM" | (string & {});
export interface LaunchTemplateSpecificationOverride {
    launchTemplateId?: string;
    launchTemplateName?: string;
    version?: string;
    targetInstanceTypes?: string[];
    userdataType?: UserdataType;
}
export type LaunchTemplateSpecificationOverrideList = LaunchTemplateSpecificationOverride[];
export interface LaunchTemplateSpecification {
    launchTemplateId?: string;
    launchTemplateName?: string;
    version?: string;
    overrides?: LaunchTemplateSpecificationOverride[];
    userdataType?: UserdataType;
}
export type ImageType = string;
export type ImageIdOverride = string;
export type KubernetesVersion = string;
export interface Ec2Configuration {
    imageType?: string;
    imageIdOverride?: string;
    batchImageStatus?: string;
    imageKubernetesVersion?: string;
}
export type Ec2ConfigurationList = Ec2Configuration[];
export interface ComputeScalingPolicy {
    minScaleDownDelayMinutes?: number;
}
export interface ManagedInstancesNetworkConfiguration {
    subnets?: string[];
    securityGroups?: string[];
}
export interface InstanceRequirementsRequest {
    allowedInstanceTypes?: string[];
}
export interface ManagedInstancesStorageConfiguration {
    storageSizeGiB?: number;
}
export interface CapacityReservationRequest {
    reservationGroupArn?: string;
    reservationPreference?: string;
}
export interface ManagedInstancesLocalStorageConfiguration {
    useLocalStorage?: boolean;
}
export interface InstanceLaunchTemplate {
    ec2InstanceProfileArn?: string;
    networkConfiguration?: ManagedInstancesNetworkConfiguration;
    instanceRequirements?: InstanceRequirementsRequest;
    capacityOptionType?: string;
    storageConfiguration?: ManagedInstancesStorageConfiguration;
    monitoring?: string;
    fipsEnabled?: boolean;
    capacityReservations?: CapacityReservationRequest;
    instanceMetadataTagsPropagation?: boolean;
    localStorageConfiguration?: ManagedInstancesLocalStorageConfiguration;
}
export interface InfrastructureOptimization {
    scaleInAfter?: number;
}
export interface ManagedInstancesProvider {
    propagateTags?: string;
    infrastructureRoleArn?: string;
    instanceLaunchTemplate?: InstanceLaunchTemplate;
    infrastructureOptimization?: InfrastructureOptimization;
}
export type TagKey = string;
export type TagValue = string;
export type TagrisTagsMap = {
    [key: string]: string | undefined;
};
export interface ComputeResource {
    type?: CRType;
    allocationStrategy?: CRAllocationStrategy;
    minvCpus?: number;
    maxvCpus?: number;
    desiredvCpus?: number;
    instanceTypes?: string[];
    imageId?: string;
    subnets?: string[];
    securityGroupIds?: string[];
    ec2KeyPair?: string;
    instanceRole?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    placementGroup?: string;
    bidPercentage?: number;
    spotIamFleetRole?: string;
    launchTemplate?: LaunchTemplateSpecification;
    ec2Configuration?: Ec2Configuration[];
    scalingPolicy?: ComputeScalingPolicy;
    managedInstancesProvider?: ManagedInstancesProvider;
    capacityTags?: {
        [key: string]: string | undefined;
    };
}
export type EksAccessEntryDesiredState = "ENABLED" | "DISABLED" | "INHERIT_FROM_CLUSTER" | (string & {});
export type EksAccessEntryStatus = "ACTIVE" | "INACTIVE" | (string & {});
export interface EksAccessEntry {
    desiredState?: EksAccessEntryDesiredState;
    status?: EksAccessEntryStatus;
}
export interface EksConfiguration {
    eksClusterArn?: string;
    kubernetesNamespace?: string;
    accessEntry?: EksAccessEntry;
}
export type ContainerInsights = "ENABLED" | "ENHANCED" | "DISABLED" | (string & {});
export interface EcsSettings {
    containerInsights?: ContainerInsights;
}
export interface CreateComputeEnvironmentRequest {
    computeEnvironmentName?: string;
    type?: CEType;
    state?: CEState;
    unmanagedvCpus?: number;
    computeResources?: ComputeResource;
    serviceRole?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    eksConfiguration?: EksConfiguration;
    context?: string;
    ecsSettings?: EcsSettings;
}
export interface CreateComputeEnvironmentResponse {
    computeEnvironmentName?: string;
    computeEnvironmentArn?: string;
}
export interface CreateConsumableResourceRequest {
    consumableResourceName?: string;
    totalQuantity?: number;
    resourceType?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateConsumableResourceResponse {
    consumableResourceName: string;
    consumableResourceArn: string;
}
export type JQState = "ENABLED" | "DISABLED" | (string & {});
export interface ComputeEnvironmentOrder {
    order?: number;
    computeEnvironment?: string;
}
export type ComputeEnvironmentOrders = ComputeEnvironmentOrder[];
export interface ServiceEnvironmentOrder {
    order?: number;
    serviceEnvironment?: string;
}
export type ServiceEnvironmentOrders = ServiceEnvironmentOrder[];
export type JobQueueType = "EKS" | "ECS" | "ECS_FARGATE" | "SAGEMAKER_TRAINING" | "ECS_MANAGED_INSTANCES" | (string & {});
export type JobStateTimeLimitActionsState = "RUNNABLE" | (string & {});
export type JobStateTimeLimitActionsAction = "CANCEL" | "TERMINATE" | (string & {});
export interface JobStateTimeLimitAction {
    reason?: string;
    state?: JobStateTimeLimitActionsState;
    maxTimeSeconds?: number;
    action?: JobStateTimeLimitActionsAction;
}
export type JobStateTimeLimitActions = JobStateTimeLimitAction[];
export interface CreateJobQueueRequest {
    jobQueueName?: string;
    state?: JQState;
    schedulingPolicyArn?: string;
    priority?: number;
    computeEnvironmentOrder?: ComputeEnvironmentOrder[];
    serviceEnvironmentOrder?: ServiceEnvironmentOrder[];
    jobQueueType?: JobQueueType;
    tags?: {
        [key: string]: string | undefined;
    };
    jobStateTimeLimitActions?: JobStateTimeLimitAction[];
}
export interface CreateJobQueueResponse {
    jobQueueName: string;
    jobQueueArn: string;
}
export interface QuotaShareCapacityLimit {
    maxCapacity?: number;
    capacityUnit?: string;
}
export type QuotaShareCapacityLimits = QuotaShareCapacityLimit[];
export type QuotaShareResourceSharingStrategy = "RESERVE" | "LEND" | "LEND_AND_BORROW" | (string & {});
export interface QuotaShareResourceSharingConfiguration {
    strategy?: QuotaShareResourceSharingStrategy;
    borrowLimit?: number;
}
export type QuotaShareInSharePreemptionState = "ENABLED" | "DISABLED" | (string & {});
export interface QuotaSharePreemptionConfiguration {
    inSharePreemption?: QuotaShareInSharePreemptionState;
}
export type QuotaShareState = "ENABLED" | "DISABLED" | (string & {});
export interface CreateQuotaShareRequest {
    quotaShareName?: string;
    jobQueue?: string;
    capacityLimits?: QuotaShareCapacityLimit[];
    resourceSharingConfiguration?: QuotaShareResourceSharingConfiguration;
    preemptionConfiguration?: QuotaSharePreemptionConfiguration;
    state?: QuotaShareState;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateQuotaShareResponse {
    quotaShareName?: string;
    quotaShareArn?: string;
}
export type QuotaShareIdleResourceAssignmentStrategy = "FIFO" | (string & {});
export interface QuotaSharePolicy {
    idleResourceAssignmentStrategy?: QuotaShareIdleResourceAssignmentStrategy;
}
export interface ShareAttributes {
    shareIdentifier?: string;
    weightFactor?: number;
}
export type ShareAttributesList = ShareAttributes[];
export interface FairsharePolicy {
    shareDecaySeconds?: number;
    computeReservation?: number;
    shareDistribution?: ShareAttributes[];
}
export interface CreateSchedulingPolicyRequest {
    name?: string;
    quotaSharePolicy?: QuotaSharePolicy;
    fairsharePolicy?: FairsharePolicy;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateSchedulingPolicyResponse {
    name: string;
    arn: string;
}
export type ServiceEnvironmentType = "SAGEMAKER_TRAINING" | (string & {});
export type ServiceEnvironmentState = "ENABLED" | "DISABLED" | (string & {});
export interface CapacityLimit {
    maxCapacity?: number;
    capacityUnit?: string;
}
export type CapacityLimits = CapacityLimit[];
export interface CreateServiceEnvironmentRequest {
    serviceEnvironmentName?: string;
    serviceEnvironmentType?: ServiceEnvironmentType;
    state?: ServiceEnvironmentState;
    capacityLimits?: CapacityLimit[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateServiceEnvironmentResponse {
    serviceEnvironmentName: string;
    serviceEnvironmentArn: string;
}
export interface DeleteComputeEnvironmentRequest {
    computeEnvironment?: string;
}
export interface DeleteComputeEnvironmentResponse {
}
export interface DeleteConsumableResourceRequest {
    consumableResource?: string;
}
export interface DeleteConsumableResourceResponse {
}
export interface DeleteJobQueueRequest {
    jobQueue?: string;
}
export interface DeleteJobQueueResponse {
}
export interface DeleteQuotaShareRequest {
    quotaShareArn?: string;
}
export interface DeleteQuotaShareResponse {
}
export interface DeleteSchedulingPolicyRequest {
    arn?: string;
}
export interface DeleteSchedulingPolicyResponse {
}
export interface DeleteServiceEnvironmentRequest {
    serviceEnvironment?: string;
}
export interface DeleteServiceEnvironmentResponse {
}
export interface DeregisterJobDefinitionRequest {
    jobDefinition?: string;
}
export interface DeregisterJobDefinitionResponse {
}
export interface DescribeComputeEnvironmentsRequest {
    computeEnvironments?: string[];
    maxResults?: number;
    nextToken?: string;
}
export type CEStatus = "CREATING" | "UPDATING" | "DELETING" | "DELETED" | "VALID" | "INVALID" | (string & {});
export type JobExecutionTimeoutMinutes = number;
export interface UpdatePolicy {
    terminateJobsOnUpdate?: boolean;
    jobExecutionTimeoutMinutes?: number;
}
export type OrchestrationType = "ECS" | "EKS" | (string & {});
export interface ComputeEnvironmentDetail {
    computeEnvironmentName?: string;
    computeEnvironmentArn?: string;
    unmanagedvCpus?: number;
    ecsClusterArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    type?: CEType;
    state?: CEState;
    status?: CEStatus;
    statusReason?: string;
    computeResources?: ComputeResource;
    serviceRole?: string;
    updatePolicy?: UpdatePolicy;
    eksConfiguration?: EksConfiguration;
    containerOrchestrationType?: OrchestrationType;
    uuid?: string;
    context?: string;
    ecsSettings?: EcsSettings;
}
export type ComputeEnvironmentDetailList = ComputeEnvironmentDetail[];
export interface DescribeComputeEnvironmentsResponse {
    computeEnvironments?: (ComputeEnvironmentDetail & {
        computeEnvironmentName: string;
        computeEnvironmentArn: string;
        computeResources: ComputeResource & {
            type: CRType;
            maxvCpus: number;
            ec2Configuration: (Ec2Configuration & {
                imageType: ImageType;
            })[];
            managedInstancesProvider: ManagedInstancesProvider & {
                infrastructureRoleArn: string;
                instanceLaunchTemplate: InstanceLaunchTemplate & {
                    ec2InstanceProfileArn: string;
                    networkConfiguration: ManagedInstancesNetworkConfiguration & {
                        subnets: StringList;
                        securityGroups: StringList;
                    };
                };
            };
        };
        eksConfiguration: EksConfiguration & {
            eksClusterArn: string;
            kubernetesNamespace: string;
            accessEntry: EksAccessEntry & {
                desiredState: EksAccessEntryDesiredState;
            };
        };
    })[];
    nextToken?: string;
}
export interface DescribeConsumableResourceRequest {
    consumableResource?: string;
}
export interface DescribeConsumableResourceResponse {
    consumableResourceName: string;
    consumableResourceArn: string;
    totalQuantity?: number;
    inUseQuantity?: number;
    availableQuantity?: number;
    resourceType?: string;
    createdAt?: number;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeJobDefinitionsRequest {
    jobDefinitions?: string[];
    maxResults?: number;
    jobDefinitionName?: string;
    status?: string;
    nextToken?: string;
}
export type ParametersMap = {
    [key: string]: string | undefined;
};
export type RetryAction = "RETRY" | "EXIT" | (string & {});
export interface EvaluateOnExit {
    onStatusReason?: string;
    onReason?: string;
    onExitCode?: string;
    action?: RetryAction;
}
export type EvaluateOnExitList = EvaluateOnExit[];
export interface RetryStrategy {
    attempts?: number;
    evaluateOnExit?: EvaluateOnExit[];
}
export interface Host {
    sourcePath?: string;
}
export type EFSTransitEncryption = "ENABLED" | "DISABLED" | (string & {});
export type EFSAuthorizationConfigIAM = "ENABLED" | "DISABLED" | (string & {});
export interface EFSAuthorizationConfig {
    accessPointId?: string;
    iam?: EFSAuthorizationConfigIAM;
}
export interface EFSVolumeConfiguration {
    fileSystemId?: string;
    rootDirectory?: string;
    transitEncryption?: EFSTransitEncryption;
    transitEncryptionPort?: number;
    authorizationConfig?: EFSAuthorizationConfig;
}
export interface S3FilesVolumeConfiguration {
    fileSystemArn?: string;
    rootDirectory?: string;
    transitEncryptionPort?: number;
    accessPointArn?: string;
}
export interface Volume {
    host?: Host;
    name?: string;
    efsVolumeConfiguration?: EFSVolumeConfiguration;
    s3filesVolumeConfiguration?: S3FilesVolumeConfiguration;
}
export type Volumes = Volume[];
export interface KeyValuePair {
    name?: string;
    value?: string;
}
export type EnvironmentVariables = KeyValuePair[];
export interface MountPoint {
    containerPath?: string;
    readOnly?: boolean;
    sourceVolume?: string;
}
export type MountPoints = MountPoint[];
export interface Ulimit {
    hardLimit?: number;
    name?: string;
    softLimit?: number;
}
export type Ulimits = Ulimit[];
export type ResourceType = "GPU" | "VCPU" | "MEMORY" | (string & {});
export interface ResourceRequirement {
    value?: string;
    type?: ResourceType;
}
export type ResourceRequirements = ResourceRequirement[];
export type DeviceCgroupPermission = "READ" | "WRITE" | "MKNOD" | (string & {});
export type DeviceCgroupPermissions = DeviceCgroupPermission[];
export interface Device {
    hostPath?: string;
    containerPath?: string;
    permissions?: DeviceCgroupPermission[];
}
export type DevicesList = Device[];
export interface Tmpfs {
    containerPath?: string;
    size?: number;
    mountOptions?: string[];
}
export type TmpfsList = Tmpfs[];
export interface LinuxParameters {
    devices?: Device[];
    initProcessEnabled?: boolean;
    sharedMemorySize?: number;
    tmpfs?: Tmpfs[];
    maxSwap?: number;
    swappiness?: number;
}
export type LogDriver = "json-file" | "syslog" | "journald" | "gelf" | "fluentd" | "awslogs" | "splunk" | "awsfirelens" | (string & {});
export type LogConfigurationOptionsMap = {
    [key: string]: string | undefined;
};
export interface Secret {
    name?: string;
    valueFrom?: string;
}
export type SecretList = Secret[];
export interface LogConfiguration {
    logDriver?: LogDriver;
    options?: {
        [key: string]: string | undefined;
    };
    secretOptions?: Secret[];
}
export type AssignPublicIp = "ENABLED" | "DISABLED" | (string & {});
export interface NetworkConfiguration {
    assignPublicIp?: AssignPublicIp;
}
export interface FargatePlatformConfiguration {
    platformVersion?: string;
}
export interface EphemeralStorage {
    sizeInGiB?: number;
}
export interface RuntimePlatform {
    operatingSystemFamily?: string;
    cpuArchitecture?: string;
}
export interface RepositoryCredentials {
    credentialsParameter?: string;
}
export interface ContainerProperties {
    image?: string;
    vcpus?: number;
    memory?: number;
    command?: string[];
    jobRoleArn?: string;
    executionRoleArn?: string;
    volumes?: Volume[];
    environment?: KeyValuePair[];
    mountPoints?: MountPoint[];
    readonlyRootFilesystem?: boolean;
    privileged?: boolean;
    ulimits?: Ulimit[];
    user?: string;
    instanceType?: string;
    resourceRequirements?: ResourceRequirement[];
    linuxParameters?: LinuxParameters;
    logConfiguration?: LogConfiguration;
    secrets?: Secret[];
    networkConfiguration?: NetworkConfiguration;
    fargatePlatformConfiguration?: FargatePlatformConfiguration;
    enableExecuteCommand?: boolean;
    ephemeralStorage?: EphemeralStorage;
    runtimePlatform?: RuntimePlatform;
    repositoryCredentials?: RepositoryCredentials;
}
export interface JobTimeout {
    attemptDurationSeconds?: number;
}
export interface TaskContainerDependency {
    containerName?: string;
    condition?: string;
}
export type TaskContainerDependencyList = TaskContainerDependency[];
export type FirelensConfigurationType = "fluentd" | "fluentbit" | (string & {});
export type FirelensConfigurationOptionsMap = {
    [key: string]: string | undefined;
};
export interface FirelensConfiguration {
    type?: FirelensConfigurationType;
    options?: {
        [key: string]: string | undefined;
    };
}
export interface TaskContainerProperties {
    command?: string[];
    dependsOn?: TaskContainerDependency[];
    environment?: KeyValuePair[];
    essential?: boolean;
    firelensConfiguration?: FirelensConfiguration;
    image?: string;
    linuxParameters?: LinuxParameters;
    logConfiguration?: LogConfiguration;
    mountPoints?: MountPoint[];
    name?: string;
    privileged?: boolean;
    readonlyRootFilesystem?: boolean;
    repositoryCredentials?: RepositoryCredentials;
    resourceRequirements?: ResourceRequirement[];
    secrets?: Secret[];
    ulimits?: Ulimit[];
    user?: string;
    startTimeout?: number;
    stopTimeout?: number;
}
export type ListTaskContainerProperties = TaskContainerProperties[];
export interface EcsTaskProperties {
    containers?: TaskContainerProperties[];
    ephemeralStorage?: EphemeralStorage;
    executionRoleArn?: string;
    platformVersion?: string;
    ipcMode?: string;
    taskRoleArn?: string;
    pidMode?: string;
    networkConfiguration?: NetworkConfiguration;
    runtimePlatform?: RuntimePlatform;
    volumes?: Volume[];
    enableExecuteCommand?: boolean;
    networkMode?: string;
}
export type ListEcsTaskProperties = EcsTaskProperties[];
export interface EcsProperties {
    taskProperties?: EcsTaskProperties[];
}
export interface ImagePullSecret {
    name?: string;
}
export type ImagePullSecrets = ImagePullSecret[];
export interface EksContainerEnvironmentVariable {
    name?: string;
    value?: string;
}
export type EksContainerEnvironmentVariables = EksContainerEnvironmentVariable[];
export type Quantity = string;
export type EksLimits = {
    [key: string]: string | undefined;
};
export type EksRequests = {
    [key: string]: string | undefined;
};
export interface EksContainerResourceRequirements {
    limits?: {
        [key: string]: string | undefined;
    };
    requests?: {
        [key: string]: string | undefined;
    };
}
export interface EksContainerVolumeMount {
    name?: string;
    mountPath?: string;
    subPath?: string;
    readOnly?: boolean;
}
export type EksContainerVolumeMounts = EksContainerVolumeMount[];
export interface EksContainerSecurityContext {
    runAsUser?: number;
    runAsGroup?: number;
    privileged?: boolean;
    allowPrivilegeEscalation?: boolean;
    readOnlyRootFilesystem?: boolean;
    runAsNonRoot?: boolean;
}
export interface EksContainer {
    name?: string;
    image?: string;
    imagePullPolicy?: string;
    command?: string[];
    args?: string[];
    env?: EksContainerEnvironmentVariable[];
    resources?: EksContainerResourceRequirements;
    volumeMounts?: EksContainerVolumeMount[];
    securityContext?: EksContainerSecurityContext;
}
export type EksContainers = EksContainer[];
export interface EksHostPath {
    path?: string;
}
export interface EksEmptyDir {
    medium?: string;
    sizeLimit?: string;
}
export interface EksSecret {
    secretName?: string;
    optional?: boolean;
}
export interface EksPersistentVolumeClaim {
    claimName?: string;
    readOnly?: boolean;
}
export interface EksVolume {
    name?: string;
    hostPath?: EksHostPath;
    emptyDir?: EksEmptyDir;
    secret?: EksSecret;
    persistentVolumeClaim?: EksPersistentVolumeClaim;
}
export type EksVolumes = EksVolume[];
export type EksLabelsMap = {
    [key: string]: string | undefined;
};
export type EksAnnotationsMap = {
    [key: string]: string | undefined;
};
export interface EksMetadata {
    labels?: {
        [key: string]: string | undefined;
    };
    annotations?: {
        [key: string]: string | undefined;
    };
    namespace?: string;
}
export interface EksPodProperties {
    serviceAccountName?: string;
    hostNetwork?: boolean;
    dnsPolicy?: string;
    imagePullSecrets?: ImagePullSecret[];
    containers?: EksContainer[];
    initContainers?: EksContainer[];
    volumes?: EksVolume[];
    metadata?: EksMetadata;
    shareProcessNamespace?: boolean;
}
export interface EksProperties {
    podProperties?: EksPodProperties;
}
export interface ConsumableResourceRequirement {
    consumableResource?: string;
    quantity?: number;
}
export type ConsumableResourceList = ConsumableResourceRequirement[];
export interface ConsumableResourceProperties {
    consumableResourceList?: ConsumableResourceRequirement[];
}
export interface NodeRangeProperty {
    targetNodes?: string;
    container?: ContainerProperties;
    instanceTypes?: string[];
    ecsProperties?: EcsProperties;
    eksProperties?: EksProperties;
    consumableResourceProperties?: ConsumableResourceProperties;
}
export type NodeRangeProperties = NodeRangeProperty[];
export interface NodeProperties {
    numNodes?: number;
    mainNode?: number;
    nodeRangeProperties?: NodeRangeProperty[];
}
export type PlatformCapability = "EC2" | "FARGATE" | "MANAGED_INSTANCES" | (string & {});
export type PlatformCapabilityList = PlatformCapability[];
export interface JobDefinition {
    jobDefinitionName?: string;
    jobDefinitionArn?: string;
    revision?: number;
    status?: string;
    type?: string;
    schedulingPriority?: number;
    parameters?: {
        [key: string]: string | undefined;
    };
    retryStrategy?: RetryStrategy;
    containerProperties?: ContainerProperties;
    timeout?: JobTimeout;
    nodeProperties?: NodeProperties;
    tags?: {
        [key: string]: string | undefined;
    };
    propagateTags?: boolean;
    platformCapabilities?: PlatformCapability[];
    ecsProperties?: EcsProperties;
    eksProperties?: EksProperties;
    containerOrchestrationType?: OrchestrationType;
    consumableResourceProperties?: ConsumableResourceProperties;
}
export type JobDefinitionList = JobDefinition[];
export interface DescribeJobDefinitionsResponse {
    jobDefinitions?: (JobDefinition & {
        jobDefinitionName: string;
        jobDefinitionArn: string;
        revision: number;
        type: string;
        retryStrategy: RetryStrategy & {
            evaluateOnExit: (EvaluateOnExit & {
                action: RetryAction;
            })[];
        };
        containerProperties: ContainerProperties & {
            volumes: (Volume & {
                efsVolumeConfiguration: EFSVolumeConfiguration & {
                    fileSystemId: string;
                };
                s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                    fileSystemArn: string;
                };
            })[];
            ulimits: (Ulimit & {
                hardLimit: number;
                name: string;
                softLimit: number;
            })[];
            resourceRequirements: (ResourceRequirement & {
                value: string;
                type: ResourceType;
            })[];
            linuxParameters: LinuxParameters & {
                devices: (Device & {
                    hostPath: string;
                })[];
                tmpfs: (Tmpfs & {
                    containerPath: string;
                    size: number;
                })[];
            };
            logConfiguration: LogConfiguration & {
                logDriver: LogDriver;
                secretOptions: (Secret & {
                    name: string;
                    valueFrom: string;
                })[];
            };
            secrets: (Secret & {
                name: string;
                valueFrom: string;
            })[];
            ephemeralStorage: EphemeralStorage & {
                sizeInGiB: number;
            };
            repositoryCredentials: RepositoryCredentials & {
                credentialsParameter: string;
            };
        };
        nodeProperties: NodeProperties & {
            numNodes: number;
            mainNode: number;
            nodeRangeProperties: (NodeRangeProperty & {
                targetNodes: string;
                container: ContainerProperties & {
                    volumes: (Volume & {
                        efsVolumeConfiguration: EFSVolumeConfiguration & {
                            fileSystemId: string;
                        };
                        s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                            fileSystemArn: string;
                        };
                    })[];
                    ulimits: (Ulimit & {
                        hardLimit: number;
                        name: string;
                        softLimit: number;
                    })[];
                    resourceRequirements: (ResourceRequirement & {
                        value: string;
                        type: ResourceType;
                    })[];
                    linuxParameters: LinuxParameters & {
                        devices: (Device & {
                            hostPath: string;
                        })[];
                        tmpfs: (Tmpfs & {
                            containerPath: string;
                            size: number;
                        })[];
                    };
                    logConfiguration: LogConfiguration & {
                        logDriver: LogDriver;
                        secretOptions: (Secret & {
                            name: string;
                            valueFrom: string;
                        })[];
                    };
                    secrets: (Secret & {
                        name: string;
                        valueFrom: string;
                    })[];
                    ephemeralStorage: EphemeralStorage & {
                        sizeInGiB: number;
                    };
                    repositoryCredentials: RepositoryCredentials & {
                        credentialsParameter: string;
                    };
                };
                ecsProperties: EcsProperties & {
                    taskProperties: (EcsTaskProperties & {
                        containers: (TaskContainerProperties & {
                            image: string;
                            firelensConfiguration: FirelensConfiguration & {
                                type: FirelensConfigurationType;
                            };
                            linuxParameters: LinuxParameters & {
                                devices: (Device & {
                                    hostPath: string;
                                })[];
                                tmpfs: (Tmpfs & {
                                    containerPath: string;
                                    size: number;
                                })[];
                            };
                            logConfiguration: LogConfiguration & {
                                logDriver: LogDriver;
                                secretOptions: (Secret & {
                                    name: string;
                                    valueFrom: string;
                                })[];
                            };
                            repositoryCredentials: RepositoryCredentials & {
                                credentialsParameter: string;
                            };
                            resourceRequirements: (ResourceRequirement & {
                                value: string;
                                type: ResourceType;
                            })[];
                            secrets: (Secret & {
                                name: string;
                                valueFrom: string;
                            })[];
                            ulimits: (Ulimit & {
                                hardLimit: number;
                                name: string;
                                softLimit: number;
                            })[];
                        })[];
                        ephemeralStorage: EphemeralStorage & {
                            sizeInGiB: number;
                        };
                        volumes: (Volume & {
                            efsVolumeConfiguration: EFSVolumeConfiguration & {
                                fileSystemId: string;
                            };
                            s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                                fileSystemArn: string;
                            };
                        })[];
                    })[];
                };
                eksProperties: EksProperties & {
                    podProperties: EksPodProperties & {
                        imagePullSecrets: (ImagePullSecret & {
                            name: string;
                        })[];
                        containers: (EksContainer & {
                            image: string;
                            env: (EksContainerEnvironmentVariable & {
                                name: string;
                            })[];
                        })[];
                        initContainers: (EksContainer & {
                            image: string;
                            env: (EksContainerEnvironmentVariable & {
                                name: string;
                            })[];
                        })[];
                        volumes: (EksVolume & {
                            name: string;
                            secret: EksSecret & {
                                secretName: string;
                            };
                            persistentVolumeClaim: EksPersistentVolumeClaim & {
                                claimName: string;
                            };
                        })[];
                    };
                };
            })[];
        };
        ecsProperties: EcsProperties & {
            taskProperties: (EcsTaskProperties & {
                containers: (TaskContainerProperties & {
                    image: string;
                    firelensConfiguration: FirelensConfiguration & {
                        type: FirelensConfigurationType;
                    };
                    linuxParameters: LinuxParameters & {
                        devices: (Device & {
                            hostPath: string;
                        })[];
                        tmpfs: (Tmpfs & {
                            containerPath: string;
                            size: number;
                        })[];
                    };
                    logConfiguration: LogConfiguration & {
                        logDriver: LogDriver;
                        secretOptions: (Secret & {
                            name: string;
                            valueFrom: string;
                        })[];
                    };
                    repositoryCredentials: RepositoryCredentials & {
                        credentialsParameter: string;
                    };
                    resourceRequirements: (ResourceRequirement & {
                        value: string;
                        type: ResourceType;
                    })[];
                    secrets: (Secret & {
                        name: string;
                        valueFrom: string;
                    })[];
                    ulimits: (Ulimit & {
                        hardLimit: number;
                        name: string;
                        softLimit: number;
                    })[];
                })[];
                ephemeralStorage: EphemeralStorage & {
                    sizeInGiB: number;
                };
                volumes: (Volume & {
                    efsVolumeConfiguration: EFSVolumeConfiguration & {
                        fileSystemId: string;
                    };
                    s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                        fileSystemArn: string;
                    };
                })[];
            })[];
        };
        eksProperties: EksProperties & {
            podProperties: EksPodProperties & {
                imagePullSecrets: (ImagePullSecret & {
                    name: string;
                })[];
                containers: (EksContainer & {
                    image: string;
                    env: (EksContainerEnvironmentVariable & {
                        name: string;
                    })[];
                })[];
                initContainers: (EksContainer & {
                    image: string;
                    env: (EksContainerEnvironmentVariable & {
                        name: string;
                    })[];
                })[];
                volumes: (EksVolume & {
                    name: string;
                    secret: EksSecret & {
                        secretName: string;
                    };
                    persistentVolumeClaim: EksPersistentVolumeClaim & {
                        claimName: string;
                    };
                })[];
            };
        };
    })[];
    nextToken?: string;
}
export interface DescribeJobQueuesRequest {
    jobQueues?: string[];
    maxResults?: number;
    nextToken?: string;
}
export type JQStatus = "CREATING" | "UPDATING" | "DELETING" | "DELETED" | "VALID" | "INVALID" | (string & {});
export interface JobQueueDetail {
    jobQueueName?: string;
    jobQueueArn?: string;
    state?: JQState;
    schedulingPolicyArn?: string;
    status?: JQStatus;
    statusReason?: string;
    priority?: number;
    computeEnvironmentOrder?: ComputeEnvironmentOrder[];
    serviceEnvironmentOrder?: ServiceEnvironmentOrder[];
    jobQueueType?: JobQueueType;
    tags?: {
        [key: string]: string | undefined;
    };
    jobStateTimeLimitActions?: JobStateTimeLimitAction[];
}
export type JobQueueDetailList = JobQueueDetail[];
export interface DescribeJobQueuesResponse {
    jobQueues?: (JobQueueDetail & {
        jobQueueName: string;
        jobQueueArn: string;
        state: JQState;
        priority: number;
        computeEnvironmentOrder: (ComputeEnvironmentOrder & {
            order: number;
            computeEnvironment: string;
        })[];
        serviceEnvironmentOrder: (ServiceEnvironmentOrder & {
            order: number;
            serviceEnvironment: string;
        })[];
        jobStateTimeLimitActions: (JobStateTimeLimitAction & {
            reason: string;
            state: JobStateTimeLimitActionsState;
            maxTimeSeconds: number;
            action: JobStateTimeLimitActionsAction;
        })[];
    })[];
    nextToken?: string;
}
export interface DescribeJobsRequest {
    jobs?: string[];
}
export type JobStatus = "SUBMITTED" | "PENDING" | "RUNNABLE" | "STARTING" | "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export interface NetworkInterface {
    attachmentId?: string;
    ipv6Address?: string;
    privateIpv4Address?: string;
}
export type NetworkInterfaceList = NetworkInterface[];
export interface AttemptContainerDetail {
    containerInstanceArn?: string;
    taskArn?: string;
    exitCode?: number;
    reason?: string;
    logStreamName?: string;
    networkInterfaces?: NetworkInterface[];
}
export interface AttemptTaskContainerDetails {
    exitCode?: number;
    name?: string;
    reason?: string;
    logStreamName?: string;
    networkInterfaces?: NetworkInterface[];
}
export type ListAttemptTaskContainerDetails = AttemptTaskContainerDetails[];
export interface AttemptEcsTaskDetails {
    containerInstanceArn?: string;
    taskArn?: string;
    containers?: AttemptTaskContainerDetails[];
}
export type ListAttemptEcsTaskDetails = AttemptEcsTaskDetails[];
export interface AttemptDetail {
    container?: AttemptContainerDetail;
    startedAt?: number;
    stoppedAt?: number;
    statusReason?: string;
    taskProperties?: AttemptEcsTaskDetails[];
}
export type AttemptDetails = AttemptDetail[];
export type ArrayJobDependency = "N_TO_N" | "SEQUENTIAL" | (string & {});
export interface JobDependency {
    jobId?: string;
    type?: ArrayJobDependency;
}
export type JobDependencyList = JobDependency[];
export interface ContainerDetail {
    image?: string;
    vcpus?: number;
    memory?: number;
    command?: string[];
    jobRoleArn?: string;
    executionRoleArn?: string;
    volumes?: Volume[];
    environment?: KeyValuePair[];
    mountPoints?: MountPoint[];
    readonlyRootFilesystem?: boolean;
    ulimits?: Ulimit[];
    privileged?: boolean;
    user?: string;
    exitCode?: number;
    reason?: string;
    containerInstanceArn?: string;
    taskArn?: string;
    logStreamName?: string;
    instanceType?: string;
    networkInterfaces?: NetworkInterface[];
    resourceRequirements?: ResourceRequirement[];
    linuxParameters?: LinuxParameters;
    logConfiguration?: LogConfiguration;
    secrets?: Secret[];
    networkConfiguration?: NetworkConfiguration;
    fargatePlatformConfiguration?: FargatePlatformConfiguration;
    ephemeralStorage?: EphemeralStorage;
    runtimePlatform?: RuntimePlatform;
    repositoryCredentials?: RepositoryCredentials;
    enableExecuteCommand?: boolean;
}
export interface NodeDetails {
    nodeIndex?: number;
    isMainNode?: boolean;
}
export type ArrayJobStatusSummary = {
    [key: string]: number | undefined;
};
export interface ArrayPropertiesDetail {
    statusSummary?: {
        [key: string]: number | undefined;
    };
    statusSummaryLastUpdatedAt?: number;
    size?: number;
    index?: number;
}
export interface EksContainerDetail {
    name?: string;
    image?: string;
    imagePullPolicy?: string;
    command?: string[];
    args?: string[];
    env?: EksContainerEnvironmentVariable[];
    resources?: EksContainerResourceRequirements;
    exitCode?: number;
    reason?: string;
    volumeMounts?: EksContainerVolumeMount[];
    securityContext?: EksContainerSecurityContext;
}
export type EksContainerDetails = EksContainerDetail[];
export interface EksPodPropertiesDetail {
    serviceAccountName?: string;
    hostNetwork?: boolean;
    dnsPolicy?: string;
    imagePullSecrets?: ImagePullSecret[];
    containers?: EksContainerDetail[];
    initContainers?: EksContainerDetail[];
    volumes?: EksVolume[];
    podName?: string;
    nodeName?: string;
    metadata?: EksMetadata;
    shareProcessNamespace?: boolean;
}
export interface EksPropertiesDetail {
    podProperties?: EksPodPropertiesDetail;
}
export interface EksAttemptContainerDetail {
    name?: string;
    containerID?: string;
    exitCode?: number;
    reason?: string;
}
export type EksAttemptContainerDetails = EksAttemptContainerDetail[];
export interface EksAttemptDetail {
    containers?: EksAttemptContainerDetail[];
    initContainers?: EksAttemptContainerDetail[];
    eksClusterArn?: string;
    podName?: string;
    podNamespace?: string;
    nodeName?: string;
    startedAt?: number;
    stoppedAt?: number;
    statusReason?: string;
}
export type EksAttemptDetails = EksAttemptDetail[];
export interface TaskContainerDetails {
    command?: string[];
    dependsOn?: TaskContainerDependency[];
    environment?: KeyValuePair[];
    essential?: boolean;
    firelensConfiguration?: FirelensConfiguration;
    image?: string;
    linuxParameters?: LinuxParameters;
    logConfiguration?: LogConfiguration;
    mountPoints?: MountPoint[];
    name?: string;
    privileged?: boolean;
    readonlyRootFilesystem?: boolean;
    repositoryCredentials?: RepositoryCredentials;
    resourceRequirements?: ResourceRequirement[];
    secrets?: Secret[];
    ulimits?: Ulimit[];
    user?: string;
    startTimeout?: number;
    stopTimeout?: number;
    exitCode?: number;
    reason?: string;
    logStreamName?: string;
    networkInterfaces?: NetworkInterface[];
}
export type ListTaskContainerDetails = TaskContainerDetails[];
export interface EcsTaskDetails {
    containers?: TaskContainerDetails[];
    containerInstanceArn?: string;
    taskArn?: string;
    ephemeralStorage?: EphemeralStorage;
    executionRoleArn?: string;
    platformVersion?: string;
    ipcMode?: string;
    taskRoleArn?: string;
    pidMode?: string;
    networkConfiguration?: NetworkConfiguration;
    runtimePlatform?: RuntimePlatform;
    volumes?: Volume[];
    enableExecuteCommand?: boolean;
    networkMode?: string;
}
export type ListEcsTaskDetails = EcsTaskDetails[];
export interface EcsPropertiesDetail {
    taskProperties?: EcsTaskDetails[];
}
export interface JobDetail {
    jobArn?: string;
    jobName?: string;
    jobId?: string;
    jobQueue?: string;
    status?: JobStatus;
    shareIdentifier?: string;
    schedulingPriority?: number;
    attempts?: AttemptDetail[];
    statusReason?: string;
    createdAt?: number;
    retryStrategy?: RetryStrategy;
    startedAt?: number;
    stoppedAt?: number;
    dependsOn?: JobDependency[];
    jobDefinition?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
    container?: ContainerDetail;
    nodeDetails?: NodeDetails;
    nodeProperties?: NodeProperties;
    arrayProperties?: ArrayPropertiesDetail;
    timeout?: JobTimeout;
    tags?: {
        [key: string]: string | undefined;
    };
    propagateTags?: boolean;
    platformCapabilities?: PlatformCapability[];
    eksProperties?: EksPropertiesDetail;
    eksAttempts?: EksAttemptDetail[];
    ecsProperties?: EcsPropertiesDetail;
    isCancelled?: boolean;
    isTerminated?: boolean;
    consumableResourceProperties?: ConsumableResourceProperties;
}
export type JobDetailList = JobDetail[];
export interface DescribeJobsResponse {
    jobs?: (JobDetail & {
        jobName: string;
        jobId: string;
        jobQueue: string;
        status: JobStatus;
        startedAt: number;
        jobDefinition: string;
        retryStrategy: RetryStrategy & {
            evaluateOnExit: (EvaluateOnExit & {
                action: RetryAction;
            })[];
        };
        container: ContainerDetail & {
            volumes: (Volume & {
                efsVolumeConfiguration: EFSVolumeConfiguration & {
                    fileSystemId: string;
                };
                s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                    fileSystemArn: string;
                };
            })[];
            ulimits: (Ulimit & {
                hardLimit: number;
                name: string;
                softLimit: number;
            })[];
            resourceRequirements: (ResourceRequirement & {
                value: string;
                type: ResourceType;
            })[];
            linuxParameters: LinuxParameters & {
                devices: (Device & {
                    hostPath: string;
                })[];
                tmpfs: (Tmpfs & {
                    containerPath: string;
                    size: number;
                })[];
            };
            logConfiguration: LogConfiguration & {
                logDriver: LogDriver;
                secretOptions: (Secret & {
                    name: string;
                    valueFrom: string;
                })[];
            };
            secrets: (Secret & {
                name: string;
                valueFrom: string;
            })[];
            ephemeralStorage: EphemeralStorage & {
                sizeInGiB: number;
            };
            repositoryCredentials: RepositoryCredentials & {
                credentialsParameter: string;
            };
        };
        nodeProperties: NodeProperties & {
            numNodes: number;
            mainNode: number;
            nodeRangeProperties: (NodeRangeProperty & {
                targetNodes: string;
                container: ContainerProperties & {
                    volumes: (Volume & {
                        efsVolumeConfiguration: EFSVolumeConfiguration & {
                            fileSystemId: string;
                        };
                        s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                            fileSystemArn: string;
                        };
                    })[];
                    ulimits: (Ulimit & {
                        hardLimit: number;
                        name: string;
                        softLimit: number;
                    })[];
                    resourceRequirements: (ResourceRequirement & {
                        value: string;
                        type: ResourceType;
                    })[];
                    linuxParameters: LinuxParameters & {
                        devices: (Device & {
                            hostPath: string;
                        })[];
                        tmpfs: (Tmpfs & {
                            containerPath: string;
                            size: number;
                        })[];
                    };
                    logConfiguration: LogConfiguration & {
                        logDriver: LogDriver;
                        secretOptions: (Secret & {
                            name: string;
                            valueFrom: string;
                        })[];
                    };
                    secrets: (Secret & {
                        name: string;
                        valueFrom: string;
                    })[];
                    ephemeralStorage: EphemeralStorage & {
                        sizeInGiB: number;
                    };
                    repositoryCredentials: RepositoryCredentials & {
                        credentialsParameter: string;
                    };
                };
                ecsProperties: EcsProperties & {
                    taskProperties: (EcsTaskProperties & {
                        containers: (TaskContainerProperties & {
                            image: string;
                            firelensConfiguration: FirelensConfiguration & {
                                type: FirelensConfigurationType;
                            };
                            linuxParameters: LinuxParameters & {
                                devices: (Device & {
                                    hostPath: string;
                                })[];
                                tmpfs: (Tmpfs & {
                                    containerPath: string;
                                    size: number;
                                })[];
                            };
                            logConfiguration: LogConfiguration & {
                                logDriver: LogDriver;
                                secretOptions: (Secret & {
                                    name: string;
                                    valueFrom: string;
                                })[];
                            };
                            repositoryCredentials: RepositoryCredentials & {
                                credentialsParameter: string;
                            };
                            resourceRequirements: (ResourceRequirement & {
                                value: string;
                                type: ResourceType;
                            })[];
                            secrets: (Secret & {
                                name: string;
                                valueFrom: string;
                            })[];
                            ulimits: (Ulimit & {
                                hardLimit: number;
                                name: string;
                                softLimit: number;
                            })[];
                        })[];
                        ephemeralStorage: EphemeralStorage & {
                            sizeInGiB: number;
                        };
                        volumes: (Volume & {
                            efsVolumeConfiguration: EFSVolumeConfiguration & {
                                fileSystemId: string;
                            };
                            s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                                fileSystemArn: string;
                            };
                        })[];
                    })[];
                };
                eksProperties: EksProperties & {
                    podProperties: EksPodProperties & {
                        imagePullSecrets: (ImagePullSecret & {
                            name: string;
                        })[];
                        containers: (EksContainer & {
                            image: string;
                            env: (EksContainerEnvironmentVariable & {
                                name: string;
                            })[];
                        })[];
                        initContainers: (EksContainer & {
                            image: string;
                            env: (EksContainerEnvironmentVariable & {
                                name: string;
                            })[];
                        })[];
                        volumes: (EksVolume & {
                            name: string;
                            secret: EksSecret & {
                                secretName: string;
                            };
                            persistentVolumeClaim: EksPersistentVolumeClaim & {
                                claimName: string;
                            };
                        })[];
                    };
                };
            })[];
        };
        eksProperties: EksPropertiesDetail & {
            podProperties: EksPodPropertiesDetail & {
                imagePullSecrets: (ImagePullSecret & {
                    name: string;
                })[];
                containers: (EksContainerDetail & {
                    env: (EksContainerEnvironmentVariable & {
                        name: string;
                    })[];
                })[];
                initContainers: (EksContainerDetail & {
                    env: (EksContainerEnvironmentVariable & {
                        name: string;
                    })[];
                })[];
                volumes: (EksVolume & {
                    name: string;
                    secret: EksSecret & {
                        secretName: string;
                    };
                    persistentVolumeClaim: EksPersistentVolumeClaim & {
                        claimName: string;
                    };
                })[];
            };
        };
        ecsProperties: EcsPropertiesDetail & {
            taskProperties: (EcsTaskDetails & {
                containers: (TaskContainerDetails & {
                    firelensConfiguration: FirelensConfiguration & {
                        type: FirelensConfigurationType;
                    };
                    linuxParameters: LinuxParameters & {
                        devices: (Device & {
                            hostPath: string;
                        })[];
                        tmpfs: (Tmpfs & {
                            containerPath: string;
                            size: number;
                        })[];
                    };
                    logConfiguration: LogConfiguration & {
                        logDriver: LogDriver;
                        secretOptions: (Secret & {
                            name: string;
                            valueFrom: string;
                        })[];
                    };
                    repositoryCredentials: RepositoryCredentials & {
                        credentialsParameter: string;
                    };
                    resourceRequirements: (ResourceRequirement & {
                        value: string;
                        type: ResourceType;
                    })[];
                    secrets: (Secret & {
                        name: string;
                        valueFrom: string;
                    })[];
                    ulimits: (Ulimit & {
                        hardLimit: number;
                        name: string;
                        softLimit: number;
                    })[];
                })[];
                ephemeralStorage: EphemeralStorage & {
                    sizeInGiB: number;
                };
                volumes: (Volume & {
                    efsVolumeConfiguration: EFSVolumeConfiguration & {
                        fileSystemId: string;
                    };
                    s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                        fileSystemArn: string;
                    };
                })[];
            })[];
        };
    })[];
}
export interface DescribeQuotaShareRequest {
    quotaShareArn?: string;
}
export type QuotaShareStatus = "CREATING" | "VALID" | "INVALID" | "UPDATING" | "DELETING" | (string & {});
export interface DescribeQuotaShareResponse {
    quotaShareName?: string;
    quotaShareArn?: string;
    jobQueueArn?: string;
    capacityLimits?: (QuotaShareCapacityLimit & {
        maxCapacity: number;
        capacityUnit: string;
    })[];
    resourceSharingConfiguration?: QuotaShareResourceSharingConfiguration & {
        strategy: QuotaShareResourceSharingStrategy;
    };
    preemptionConfiguration?: QuotaSharePreemptionConfiguration & {
        inSharePreemption: QuotaShareInSharePreemptionState;
    };
    state?: QuotaShareState;
    status?: QuotaShareStatus;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeSchedulingPoliciesRequest {
    arns?: string[];
}
export interface SchedulingPolicyDetail {
    name?: string;
    arn?: string;
    quotaSharePolicy?: QuotaSharePolicy;
    fairsharePolicy?: FairsharePolicy;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type SchedulingPolicyDetailList = SchedulingPolicyDetail[];
export interface DescribeSchedulingPoliciesResponse {
    schedulingPolicies?: (SchedulingPolicyDetail & {
        name: string;
        arn: string;
        quotaSharePolicy: QuotaSharePolicy & {
            idleResourceAssignmentStrategy: QuotaShareIdleResourceAssignmentStrategy;
        };
        fairsharePolicy: FairsharePolicy & {
            shareDistribution: (ShareAttributes & {
                shareIdentifier: string;
            })[];
        };
    })[];
}
export interface DescribeServiceEnvironmentsRequest {
    serviceEnvironments?: string[];
    maxResults?: number;
    nextToken?: string;
}
export type ServiceEnvironmentStatus = "CREATING" | "UPDATING" | "DELETING" | "DELETED" | "VALID" | "INVALID" | (string & {});
export interface ServiceEnvironmentDetail {
    serviceEnvironmentName?: string;
    serviceEnvironmentArn?: string;
    serviceEnvironmentType?: ServiceEnvironmentType;
    state?: ServiceEnvironmentState;
    status?: ServiceEnvironmentStatus;
    capacityLimits?: CapacityLimit[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ServiceEnvironmentDetailList = ServiceEnvironmentDetail[];
export interface DescribeServiceEnvironmentsResponse {
    serviceEnvironments?: (ServiceEnvironmentDetail & {
        serviceEnvironmentName: string;
        serviceEnvironmentArn: string;
        serviceEnvironmentType: ServiceEnvironmentType;
        capacityLimits: CapacityLimits;
    })[];
    nextToken?: string;
}
export interface DescribeServiceJobRequest {
    jobId?: string;
}
export type ServiceResourceIdName = "TrainingJobArn" | (string & {});
export interface ServiceResourceId {
    name?: ServiceResourceIdName;
    value?: string;
}
export interface ServiceJobAttemptDetail {
    serviceResourceId?: ServiceResourceId;
    startedAt?: number;
    stoppedAt?: number;
    statusReason?: string;
}
export type ServiceJobAttemptDetails = ServiceJobAttemptDetail[];
export interface ServiceJobCapacityUsageDetail {
    capacityUnit?: string;
    quantity?: number;
}
export type ServiceJobCapacityUsageDetailList = ServiceJobCapacityUsageDetail[];
export interface LatestServiceJobAttempt {
    serviceResourceId?: ServiceResourceId;
}
export type ServiceJobRetryAction = "RETRY" | "EXIT" | (string & {});
export interface ServiceJobEvaluateOnExit {
    action?: ServiceJobRetryAction;
    onStatusReason?: string;
}
export type ServiceJobEvaluateOnExitList = ServiceJobEvaluateOnExit[];
export interface ServiceJobRetryStrategy {
    attempts?: number;
    evaluateOnExit?: ServiceJobEvaluateOnExit[];
}
export type ServiceJobType = "SAGEMAKER_TRAINING" | (string & {});
export interface ServiceJobPreemptionConfiguration {
    preemptionRetriesBeforeTermination?: number;
}
export interface ServiceJobPreemptedAttempt {
    serviceResourceId?: ServiceResourceId;
    startedAt?: number;
    stoppedAt?: number;
    statusReason?: string;
}
export type ServiceJobRecentPreemptedAttemptList = ServiceJobPreemptedAttempt[];
export interface ServiceJobPreemptionSummary {
    preemptedAttemptCount?: number;
    recentPreemptedAttempts?: ServiceJobPreemptedAttempt[];
}
export type ServiceJobStatus = "SUBMITTED" | "PENDING" | "RUNNABLE" | "SCHEDULED" | "STARTING" | "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export interface ServiceJobTimeout {
    attemptDurationSeconds?: number;
}
export interface DescribeServiceJobResponse {
    attempts?: (ServiceJobAttemptDetail & {
        serviceResourceId: ServiceResourceId & {
            name: ServiceResourceIdName;
            value: string;
        };
    })[];
    capacityUsage?: ServiceJobCapacityUsageDetail[];
    createdAt?: number;
    isTerminated?: boolean;
    jobArn?: string;
    jobId: string;
    jobName: string;
    jobQueue: string;
    latestAttempt?: LatestServiceJobAttempt & {
        serviceResourceId: ServiceResourceId & {
            name: ServiceResourceIdName;
            value: string;
        };
    };
    retryStrategy?: ServiceJobRetryStrategy & {
        attempts: number;
    };
    scheduledAt?: number;
    schedulingPriority?: number;
    serviceRequestPayload?: string;
    serviceJobType: ServiceJobType;
    shareIdentifier?: string;
    quotaShareName?: string;
    preemptionConfiguration?: ServiceJobPreemptionConfiguration;
    preemptionSummary?: ServiceJobPreemptionSummary & {
        recentPreemptedAttempts: (ServiceJobPreemptedAttempt & {
            serviceResourceId: ServiceResourceId & {
                name: ServiceResourceIdName;
                value: string;
            };
        })[];
    };
    startedAt: number;
    status: ServiceJobStatus;
    statusReason?: string;
    stoppedAt?: number;
    tags?: {
        [key: string]: string | undefined;
    };
    timeoutConfig?: ServiceJobTimeout;
}
export interface GetJobQueueSnapshotRequest {
    jobQueue?: string;
}
export interface FrontOfQueueJobSummary {
    jobArn?: string;
    earliestTimeAtPosition?: number;
}
export type FrontOfQueueJobSummaryList = FrontOfQueueJobSummary[];
export interface FrontOfQueueDetail {
    jobs?: FrontOfQueueJobSummary[];
    lastUpdatedAt?: number;
}
export interface FrontOfQuotaShareJobSummary {
    jobArn?: string;
    earliestTimeAtPosition?: number;
}
export type FrontOfQuotaShareJobSummaryList = FrontOfQuotaShareJobSummary[];
export type FrontOfQuotaSharesJobSummaryMap = {
    [key: string]: FrontOfQuotaShareJobSummary[] | undefined;
};
export interface FrontOfQuotaSharesDetail {
    quotaShares?: {
        [key: string]: FrontOfQuotaShareJobSummary[] | undefined;
    };
    lastUpdatedAt?: number;
}
export interface QueueSnapshotCapacityUsage {
    capacityUnit?: string;
    quantity?: number;
}
export type QueueSnapshotCapacityUsageList = QueueSnapshotCapacityUsage[];
export interface FairshareCapacityUsage {
    capacityUnit?: string;
    quantity?: number;
}
export type FairshareCapacityUsageList = FairshareCapacityUsage[];
export interface FairshareCapacityUtilization {
    shareIdentifier?: string;
    capacityUsage?: FairshareCapacityUsage[];
}
export type FairshareCapacityUtilizationList = FairshareCapacityUtilization[];
export interface FairshareUtilizationDetail {
    activeShareCount?: number;
    topCapacityUtilization?: FairshareCapacityUtilization[];
}
export interface QuotaShareCapacityUsage {
    capacityUnit?: string;
    quantity?: number;
}
export type QuotaShareCapacityUsageList = QuotaShareCapacityUsage[];
export interface QuotaShareCapacityUtilization {
    quotaShareName?: string;
    capacityUsage?: QuotaShareCapacityUsage[];
}
export type QuotaShareCapacityUtilizationList = QuotaShareCapacityUtilization[];
export interface QuotaShareUtilizationDetail {
    topCapacityUtilization?: QuotaShareCapacityUtilization[];
}
export interface QueueSnapshotUtilizationDetail {
    totalCapacityUsage?: QueueSnapshotCapacityUsage[];
    fairshareUtilization?: FairshareUtilizationDetail;
    quotaShareUtilization?: QuotaShareUtilizationDetail;
    lastUpdatedAt?: number;
}
export interface GetJobQueueSnapshotResponse {
    frontOfQueue?: FrontOfQueueDetail;
    frontOfQuotaShares?: FrontOfQuotaSharesDetail;
    queueUtilization?: QueueSnapshotUtilizationDetail;
}
export interface KeyValuesPair {
    name?: string;
    values?: string[];
}
export type ListConsumableResourcesFilterList = KeyValuesPair[];
export interface ListConsumableResourcesRequest {
    filters?: KeyValuesPair[];
    maxResults?: number;
    nextToken?: string;
}
export interface ConsumableResourceSummary {
    consumableResourceArn?: string;
    consumableResourceName?: string;
    totalQuantity?: number;
    inUseQuantity?: number;
    resourceType?: string;
}
export type ConsumableResourceSummaryList = ConsumableResourceSummary[];
export interface ListConsumableResourcesResponse {
    consumableResources: (ConsumableResourceSummary & {
        consumableResourceArn: string;
        consumableResourceName: string;
    })[];
    nextToken?: string;
}
export type ListJobsFilterList = KeyValuesPair[];
export interface ListJobsRequest {
    jobQueue?: string;
    arrayJobId?: string;
    multiNodeJobId?: string;
    jobStatus?: JobStatus;
    maxResults?: number;
    nextToken?: string;
    filters?: KeyValuesPair[];
}
export interface JobCapacityUsageSummary {
    capacityUnit?: string;
    quantity?: number;
}
export type JobCapacityUsageSummaryList = JobCapacityUsageSummary[];
export interface ContainerSummary {
    exitCode?: number;
    reason?: string;
}
export interface ArrayPropertiesSummary {
    size?: number;
    index?: number;
    statusSummary?: {
        [key: string]: number | undefined;
    };
    statusSummaryLastUpdatedAt?: number;
}
export interface NodePropertiesSummary {
    isMainNode?: boolean;
    numNodes?: number;
    nodeIndex?: number;
}
export interface JobSummary {
    jobArn?: string;
    jobId?: string;
    jobName?: string;
    capacityUsage?: JobCapacityUsageSummary[];
    createdAt?: number;
    scheduledAt?: number;
    shareIdentifier?: string;
    status?: JobStatus;
    statusReason?: string;
    startedAt?: number;
    stoppedAt?: number;
    container?: ContainerSummary;
    arrayProperties?: ArrayPropertiesSummary;
    nodeProperties?: NodePropertiesSummary;
    jobDefinition?: string;
    isCancelled?: boolean;
    isTerminated?: boolean;
}
export type JobSummaryList = JobSummary[];
export interface ListJobsResponse {
    jobSummaryList: (JobSummary & {
        jobId: string;
        jobName: string;
    })[];
    nextToken?: string;
}
export type ListJobsByConsumableResourceFilterList = KeyValuesPair[];
export interface ListJobsByConsumableResourceRequest {
    consumableResource?: string;
    filters?: KeyValuesPair[];
    maxResults?: number;
    nextToken?: string;
}
export interface ListJobsByConsumableResourceSummary {
    jobArn?: string;
    jobQueueArn?: string;
    jobName?: string;
    jobDefinitionArn?: string;
    shareIdentifier?: string;
    jobStatus?: string;
    quantity?: number;
    statusReason?: string;
    startedAt?: number;
    createdAt?: number;
    consumableResourceProperties?: ConsumableResourceProperties;
}
export type ListJobsByConsumableResourceSummaryList = ListJobsByConsumableResourceSummary[];
export interface ListJobsByConsumableResourceResponse {
    jobs: (ListJobsByConsumableResourceSummary & {
        jobArn: string;
        jobQueueArn: string;
        jobName: string;
        jobStatus: string;
        quantity: number;
        createdAt: number;
        consumableResourceProperties: ConsumableResourceProperties;
    })[];
    nextToken?: string;
}
export interface ListQuotaSharesRequest {
    jobQueue?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface QuotaShareDetail {
    quotaShareName?: string;
    quotaShareArn?: string;
    jobQueueArn?: string;
    capacityLimits?: QuotaShareCapacityLimit[];
    resourceSharingConfiguration?: QuotaShareResourceSharingConfiguration;
    preemptionConfiguration?: QuotaSharePreemptionConfiguration;
    state?: QuotaShareState;
    status?: QuotaShareStatus;
}
export type QuotaShareList = QuotaShareDetail[];
export interface ListQuotaSharesResponse {
    quotaShares?: (QuotaShareDetail & {
        capacityLimits: (QuotaShareCapacityLimit & {
            maxCapacity: number;
            capacityUnit: string;
        })[];
        resourceSharingConfiguration: QuotaShareResourceSharingConfiguration & {
            strategy: QuotaShareResourceSharingStrategy;
        };
        preemptionConfiguration: QuotaSharePreemptionConfiguration & {
            inSharePreemption: QuotaShareInSharePreemptionState;
        };
    })[];
    nextToken?: string;
}
export interface ListSchedulingPoliciesRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface SchedulingPolicyListingDetail {
    arn?: string;
}
export type SchedulingPolicyListingDetailList = SchedulingPolicyListingDetail[];
export interface ListSchedulingPoliciesResponse {
    schedulingPolicies?: (SchedulingPolicyListingDetail & {
        arn: string;
    })[];
    nextToken?: string;
}
export interface ListServiceJobsRequest {
    jobQueue?: string;
    jobStatus?: ServiceJobStatus;
    maxResults?: number;
    nextToken?: string;
    filters?: KeyValuesPair[];
}
export interface ServiceJobCapacityUsageSummary {
    capacityUnit?: string;
    quantity?: number;
}
export type ServiceJobCapacityUsageSummaryList = ServiceJobCapacityUsageSummary[];
export interface ServiceJobSummary {
    latestAttempt?: LatestServiceJobAttempt;
    capacityUsage?: ServiceJobCapacityUsageSummary[];
    createdAt?: number;
    jobArn?: string;
    jobId?: string;
    jobName?: string;
    scheduledAt?: number;
    serviceJobType?: ServiceJobType;
    shareIdentifier?: string;
    quotaShareName?: string;
    status?: ServiceJobStatus;
    statusReason?: string;
    startedAt?: number;
    stoppedAt?: number;
    isTerminated?: boolean;
}
export type ServiceJobSummaryList = ServiceJobSummary[];
export interface ListServiceJobsResponse {
    jobSummaryList: (ServiceJobSummary & {
        jobId: string;
        jobName: string;
        serviceJobType: ServiceJobType;
        latestAttempt: LatestServiceJobAttempt & {
            serviceResourceId: ServiceResourceId & {
                name: ServiceResourceIdName;
                value: string;
            };
        };
    })[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export type JobDefinitionType = "container" | "multinode" | (string & {});
export interface RegisterJobDefinitionRequest {
    jobDefinitionName?: string;
    type?: JobDefinitionType;
    parameters?: {
        [key: string]: string | undefined;
    };
    schedulingPriority?: number;
    containerProperties?: ContainerProperties;
    nodeProperties?: NodeProperties;
    retryStrategy?: RetryStrategy;
    propagateTags?: boolean;
    timeout?: JobTimeout;
    tags?: {
        [key: string]: string | undefined;
    };
    platformCapabilities?: PlatformCapability[];
    eksProperties?: EksProperties;
    ecsProperties?: EcsProperties;
    consumableResourceProperties?: ConsumableResourceProperties;
}
export interface RegisterJobDefinitionResponse {
    jobDefinitionName: string;
    jobDefinitionArn: string;
    revision: number;
}
export interface ArrayProperties {
    size?: number;
}
export interface ContainerOverrides {
    vcpus?: number;
    memory?: number;
    command?: string[];
    instanceType?: string;
    environment?: KeyValuePair[];
    resourceRequirements?: ResourceRequirement[];
}
export interface TaskContainerOverrides {
    command?: string[];
    environment?: KeyValuePair[];
    name?: string;
    resourceRequirements?: ResourceRequirement[];
}
export type ListTaskContainerOverrides = TaskContainerOverrides[];
export interface TaskPropertiesOverride {
    containers?: TaskContainerOverrides[];
}
export type ListTaskPropertiesOverride = TaskPropertiesOverride[];
export interface EcsPropertiesOverride {
    taskProperties?: TaskPropertiesOverride[];
}
export interface EksContainerOverride {
    name?: string;
    image?: string;
    command?: string[];
    args?: string[];
    env?: EksContainerEnvironmentVariable[];
    resources?: EksContainerResourceRequirements;
}
export type EksContainerOverrideList = EksContainerOverride[];
export interface EksPodPropertiesOverride {
    containers?: EksContainerOverride[];
    initContainers?: EksContainerOverride[];
    metadata?: EksMetadata;
}
export interface EksPropertiesOverride {
    podProperties?: EksPodPropertiesOverride;
}
export interface NodePropertyOverride {
    targetNodes?: string;
    containerOverrides?: ContainerOverrides;
    ecsPropertiesOverride?: EcsPropertiesOverride;
    instanceTypes?: string[];
    eksPropertiesOverride?: EksPropertiesOverride;
    consumableResourcePropertiesOverride?: ConsumableResourceProperties;
}
export type NodePropertyOverrides = NodePropertyOverride[];
export interface NodeOverrides {
    numNodes?: number;
    nodePropertyOverrides?: NodePropertyOverride[];
}
export interface SubmitJobRequest {
    jobName?: string;
    jobQueue?: string;
    shareIdentifier?: string;
    schedulingPriorityOverride?: number;
    arrayProperties?: ArrayProperties;
    dependsOn?: JobDependency[];
    jobDefinition?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
    containerOverrides?: ContainerOverrides;
    nodeOverrides?: NodeOverrides;
    retryStrategy?: RetryStrategy;
    propagateTags?: boolean;
    timeout?: JobTimeout;
    tags?: {
        [key: string]: string | undefined;
    };
    eksPropertiesOverride?: EksPropertiesOverride;
    ecsPropertiesOverride?: EcsPropertiesOverride;
    consumableResourcePropertiesOverride?: ConsumableResourceProperties;
}
export interface SubmitJobResponse {
    jobArn?: string;
    jobName: string;
    jobId: string;
}
export type ClientRequestToken = string;
export interface SubmitServiceJobRequest {
    jobName?: string;
    jobQueue?: string;
    retryStrategy?: ServiceJobRetryStrategy;
    schedulingPriority?: number;
    serviceRequestPayload?: string;
    serviceJobType?: ServiceJobType;
    shareIdentifier?: string;
    quotaShareName?: string;
    preemptionConfiguration?: ServiceJobPreemptionConfiguration;
    timeoutConfig?: ServiceJobTimeout;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export interface SubmitServiceJobResponse {
    jobArn?: string;
    jobName: string;
    jobId: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface TerminateJobRequest {
    jobId?: string;
    reason?: string;
}
export interface TerminateJobResponse {
}
export interface TerminateJobsRequest {
    jobs?: string[];
    reason?: string;
}
export interface TerminateJobsErrorDetail {
    job?: string;
    code?: string;
    message?: string;
}
export type TerminateJobsErrorDetailList = TerminateJobsErrorDetail[];
export interface TerminateJobsResponse {
    successful: string[];
    errors: (TerminateJobsErrorDetail & {
        job: string;
        code: string;
        message: string;
    })[];
}
export interface TerminateServiceJobRequest {
    jobId?: string;
    reason?: string;
}
export interface TerminateServiceJobResponse {
}
export interface TerminateServiceJobsRequest {
    jobs?: string[];
    reason?: string;
}
export interface TerminateServiceJobsErrorDetail {
    job?: string;
    code?: string;
    message?: string;
}
export type TerminateServiceJobsErrorDetailList = TerminateServiceJobsErrorDetail[];
export interface TerminateServiceJobsResponse {
    successful: string[];
    errors: (TerminateServiceJobsErrorDetail & {
        job: string;
        code: string;
        message: string;
    })[];
}
export type TagKeysList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys?: string[];
}
export interface UntagResourceResponse {
}
export type CRUpdateAllocationStrategy = "BEST_FIT_PROGRESSIVE" | "BEST_FIT_PROGRESSIVE_ORDERED" | "SPOT_CAPACITY_OPTIMIZED" | "SPOT_PRICE_CAPACITY_OPTIMIZED" | "SPOT_CAPACITY_OPTIMIZED_PRIORITIZED" | (string & {});
export interface InstanceLaunchTemplateUpdate {
    ec2InstanceProfileArn?: string;
    networkConfiguration?: ManagedInstancesNetworkConfiguration;
    instanceRequirements?: InstanceRequirementsRequest;
    storageConfiguration?: ManagedInstancesStorageConfiguration;
    monitoring?: string;
    capacityReservations?: CapacityReservationRequest;
    instanceMetadataTagsPropagation?: boolean;
    localStorageConfiguration?: ManagedInstancesLocalStorageConfiguration;
}
export interface UpdateManagedInstancesProviderConfiguration {
    propagateTags?: string;
    infrastructureRoleArn?: string;
    instanceLaunchTemplate?: InstanceLaunchTemplateUpdate;
    infrastructureOptimization?: InfrastructureOptimization;
}
export interface ComputeResourceUpdate {
    minvCpus?: number;
    maxvCpus?: number;
    desiredvCpus?: number;
    subnets?: string[];
    securityGroupIds?: string[];
    allocationStrategy?: CRUpdateAllocationStrategy;
    instanceTypes?: string[];
    ec2KeyPair?: string;
    instanceRole?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    placementGroup?: string;
    bidPercentage?: number;
    launchTemplate?: LaunchTemplateSpecification;
    ec2Configuration?: Ec2Configuration[];
    updateToLatestImageVersion?: boolean;
    type?: CRType;
    imageId?: string;
    scalingPolicy?: ComputeScalingPolicy;
    managedInstancesProvider?: UpdateManagedInstancesProviderConfiguration;
    capacityTags?: {
        [key: string]: string | undefined;
    };
}
export interface EksConfigurationUpdate {
    accessEntry?: EksAccessEntry;
}
export interface UpdateComputeEnvironmentRequest {
    computeEnvironment?: string;
    state?: CEState;
    unmanagedvCpus?: number;
    computeResources?: ComputeResourceUpdate;
    serviceRole?: string;
    updatePolicy?: UpdatePolicy;
    context?: string;
    ecsSettings?: EcsSettings;
    eksConfiguration?: EksConfigurationUpdate;
}
export interface UpdateComputeEnvironmentResponse {
    computeEnvironmentName?: string;
    computeEnvironmentArn?: string;
}
export interface UpdateConsumableResourceRequest {
    consumableResource?: string;
    operation?: string;
    quantity?: number;
    clientToken?: string;
}
export interface UpdateConsumableResourceResponse {
    consumableResourceName: string;
    consumableResourceArn: string;
    totalQuantity?: number;
}
export interface UpdateJobQueueRequest {
    jobQueue?: string;
    state?: JQState;
    schedulingPolicyArn?: string;
    priority?: number;
    computeEnvironmentOrder?: ComputeEnvironmentOrder[];
    serviceEnvironmentOrder?: ServiceEnvironmentOrder[];
    jobStateTimeLimitActions?: JobStateTimeLimitAction[];
}
export interface UpdateJobQueueResponse {
    jobQueueName?: string;
    jobQueueArn?: string;
}
export interface UpdateQuotaShareRequest {
    quotaShareArn?: string;
    capacityLimits?: QuotaShareCapacityLimit[];
    resourceSharingConfiguration?: QuotaShareResourceSharingConfiguration;
    preemptionConfiguration?: QuotaSharePreemptionConfiguration;
    state?: QuotaShareState;
}
export interface UpdateQuotaShareResponse {
    quotaShareName?: string;
    quotaShareArn?: string;
}
export interface UpdateSchedulingPolicyRequest {
    arn?: string;
    quotaSharePolicy?: QuotaSharePolicy;
    fairsharePolicy?: FairsharePolicy;
}
export interface UpdateSchedulingPolicyResponse {
}
export interface UpdateServiceEnvironmentRequest {
    serviceEnvironment?: string;
    state?: ServiceEnvironmentState;
    capacityLimits?: CapacityLimit[];
}
export interface UpdateServiceEnvironmentResponse {
    serviceEnvironmentName: string;
    serviceEnvironmentArn: string;
}
export interface UpdateServiceJobRequest {
    jobId?: string;
    schedulingPriority?: number;
}
export interface UpdateServiceJobResponse {
    jobArn?: string;
    jobName?: string;
    jobId?: string;
}
export type CancelJobError = ClientException | ServerException | CommonErrors;
/**
 * Cancels a job in an Batch job queue. Jobs that are in a `SUBMITTED`, `PENDING`, or `RUNNABLE` state are cancelled and the job status is updated to `FAILED`.
 *
 * A `PENDING` job is cancelled after all dependency jobs are completed.
 * Therefore, it might take longer than expected to cancel a job in `PENDING`
 * status.
 *
 * When you try to cancel an array parent job in `PENDING`, Batch attempts to
 * cancel all child jobs. The array parent job is cancelled when all child jobs are
 * completed.
 *
 * Jobs that progressed to the `STARTING` or
 * `RUNNING` state aren't cancelled. However, the API operation still succeeds, even
 * if no job is cancelled. These jobs must be terminated with the TerminateJob or
 * TerminateJobs operation.
 */
export declare const cancelJob: API.OperationMethod<CancelJobRequest, CancelJobResponse, CancelJobError, Credentials | HttpClient.HttpClient>;
export type CancelJobsError = ClientException | ServerException | CommonErrors;
/**
 * Cancels up to 50 jobs in an Batch job queue. This is a bulk version of CancelJob. Jobs that are in a
 * `SUBMITTED`, `PENDING`, or `RUNNABLE` state are cancelled
 * and the job status is updated to `FAILED`.
 *
 * A `PENDING` job is cancelled after all dependency jobs are completed.
 * Therefore, it might take longer than expected to cancel a job in `PENDING`
 * status.
 *
 * When you try to cancel an array parent job in `PENDING`, Batch attempts to
 * cancel all child jobs. The array parent job is cancelled when all child jobs are
 * completed.
 *
 * Jobs that progressed to the `STARTING` or `RUNNING` state aren't
 * cancelled. These jobs must be terminated with the TerminateJob or
 * TerminateJobs operation.
 *
 * Batch reports the result for each job individually in the response. Jobs that
 * were processed successfully are reported in the `successful` list. Jobs that
 * encountered errors are reported in the `errors` list. The response returns an
 * HTTP status code of `200` even when some jobs encountered errors, so check the
 * `errors` list. Jobs that can't be found are treated as successfully
 * processed.
 *
 * This operation requires `batch:CancelJob` permission for each job in the
 * request. There is no separate `batch:CancelJobs` IAM action. If a caller's IAM
 * policy grants `batch:CancelJob`, they can use both the singular
 * CancelJob and bulk `CancelJobs` operations.
 */
export declare const cancelJobs: API.OperationMethod<CancelJobsRequest, CancelJobsResponse, CancelJobsError, Credentials | HttpClient.HttpClient>;
export type CreateComputeEnvironmentError = ClientException | ServerException | CommonErrors;
/**
 * Creates an Batch compute environment. You can create `MANAGED` or
 * `UNMANAGED` compute environments. `MANAGED` compute environments can
 * use Amazon EC2 or Fargate resources. `UNMANAGED` compute environments can only use
 * EC2 resources.
 *
 * In a managed compute environment, Batch manages the capacity and instance types of the
 * compute resources within the environment. This is based on the compute resource specification
 * that you define or the launch template that you
 * specify when you create the compute environment. Either, you can choose to use EC2 On-Demand
 * Instances and EC2 Spot Instances. Or, you can use Fargate and Fargate Spot capacity in
 * your managed compute environment. You can optionally set a maximum price so that Spot
 * Instances only launch when the Spot Instance price is less than a specified percentage of the
 * On-Demand price.
 *
 * In an unmanaged compute environment, you can manage your own EC2 compute resources and
 * have flexibility with how you configure your compute resources. For example, you can use
 * custom AMIs. However, you must verify that each of your AMIs meet the Amazon ECS container instance
 * AMI specification. For more information, see container instance AMIs in the
 * *Amazon Elastic Container Service Developer Guide*. After you created your unmanaged compute environment,
 * you can use the DescribeComputeEnvironments operation to find the Amazon ECS
 * cluster that's associated with it. Then, launch your container instances into that Amazon ECS
 * cluster. For more information, see Launching an Amazon ECS container
 * instance in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Batch doesn't automatically upgrade the AMIs in a compute environment after it's
 * created. For more information on how to update a compute environment's AMI, see Updating compute environments in the *Batch User Guide*.
 */
export declare const createComputeEnvironment: API.OperationMethod<CreateComputeEnvironmentRequest, CreateComputeEnvironmentResponse, CreateComputeEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Creates an Batch consumable resource.
 */
export declare const createConsumableResource: API.OperationMethod<CreateConsumableResourceRequest, CreateConsumableResourceResponse, CreateConsumableResourceError, Credentials | HttpClient.HttpClient>;
export type CreateJobQueueError = ClientException | ServerException | ComputeEnvironmentNotValid | JobQueueAlreadyExists | CommonErrors;
/**
 * Creates an Batch job queue. When you create a job queue, you associate one or more
 * compute environments to the queue and assign an order of preference for the compute
 * environments.
 *
 * You also set a priority to the job queue that determines the order that the Batch
 * scheduler places jobs onto its associated compute environments. For example, if a compute
 * environment is associated with more than one job queue, the job queue with a higher priority
 * is given preference for scheduling jobs to that compute environment.
 */
export declare const createJobQueue: API.OperationMethod<CreateJobQueueRequest, CreateJobQueueResponse, CreateJobQueueError, Credentials | HttpClient.HttpClient>;
export type CreateQuotaShareError = ClientException | ServerException | CommonErrors;
/**
 * Creates an Batch quota share. Each quota share operates as a virtual queue with a configured compute capacity, resource sharing strategy, and borrow limits.
 */
export declare const createQuotaShare: API.OperationMethod<CreateQuotaShareRequest, CreateQuotaShareResponse, CreateQuotaShareError, Credentials | HttpClient.HttpClient>;
export type CreateSchedulingPolicyError = ClientException | ServerException | CommonErrors;
/**
 * Creates an Batch scheduling policy.
 */
export declare const createSchedulingPolicy: API.OperationMethod<CreateSchedulingPolicyRequest, CreateSchedulingPolicyResponse, CreateSchedulingPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateServiceEnvironmentError = ClientException | ServerException | CommonErrors;
/**
 * Creates a service environment for running service jobs. Service environments define capacity limits for specific service types such as SageMaker Training jobs.
 */
export declare const createServiceEnvironment: API.OperationMethod<CreateServiceEnvironmentRequest, CreateServiceEnvironmentResponse, CreateServiceEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteComputeEnvironmentError = ClientException | ServerException | ComputeEnvironmentNotFound | ComputeEnvironmentInUse | ComputeEnvironmentBeingModified | CommonErrors;
/**
 * Deletes an Batch compute environment.
 *
 * Before you can delete a compute environment, you must set its state to
 * `DISABLED` with the UpdateComputeEnvironment API operation and
 * disassociate it from any job queues with the UpdateJobQueue API operation.
 * Compute environments that use Fargate resources must terminate all active jobs on that
 * compute environment before deleting the compute environment. If this isn't done, the compute
 * environment enters an invalid state.
 */
export declare const deleteComputeEnvironment: API.OperationMethod<DeleteComputeEnvironmentRequest, DeleteComputeEnvironmentResponse, DeleteComputeEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Deletes the specified consumable resource.
 */
export declare const deleteConsumableResource: API.OperationMethod<DeleteConsumableResourceRequest, DeleteConsumableResourceResponse, DeleteConsumableResourceError, Credentials | HttpClient.HttpClient>;
export type DeleteJobQueueError = ClientException | ServerException | JobQueueNotFound | JobQueueBeingModified | CommonErrors;
/**
 * Deletes the specified job queue. You must first disable submissions for a queue with the
 * UpdateJobQueue operation. All jobs in the queue are eventually terminated
 * when you delete a job queue.
 *
 * It's not necessary to disassociate compute environments from a queue before submitting a
 * `DeleteJobQueue` request.
 */
export declare const deleteJobQueue: API.OperationMethod<DeleteJobQueueRequest, DeleteJobQueueResponse, DeleteJobQueueError, Credentials | HttpClient.HttpClient>;
export type DeleteQuotaShareError = ClientException | ServerException | CommonErrors;
/**
 * Deletes the specified quota share. You must first disable submissions for the share by
 * updating the state to `DISABLED` using the UpdateQuotaShare operation.
 * All jobs in the share are eventually terminated when you delete a quota share.
 */
export declare const deleteQuotaShare: API.OperationMethod<DeleteQuotaShareRequest, DeleteQuotaShareResponse, DeleteQuotaShareError, Credentials | HttpClient.HttpClient>;
export type DeleteSchedulingPolicyError = ClientException | ServerException | CommonErrors;
/**
 * Deletes the specified scheduling policy.
 *
 * You can't delete a scheduling policy that's used in any job queues.
 */
export declare const deleteSchedulingPolicy: API.OperationMethod<DeleteSchedulingPolicyRequest, DeleteSchedulingPolicyResponse, DeleteSchedulingPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceEnvironmentError = ClientException | ServerException | CommonErrors;
/**
 * Deletes a Service environment. Before you can delete a service environment, you must first set its state to `DISABLED` with the `UpdateServiceEnvironment` API operation and disassociate it from any job queues with the `UpdateJobQueue` API operation.
 */
export declare const deleteServiceEnvironment: API.OperationMethod<DeleteServiceEnvironmentRequest, DeleteServiceEnvironmentResponse, DeleteServiceEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeregisterJobDefinitionError = ClientException | ServerException | CommonErrors;
/**
 * Deregisters an Batch job definition. Job definitions are permanently deleted after 180
 * days.
 */
export declare const deregisterJobDefinition: API.OperationMethod<DeregisterJobDefinitionRequest, DeregisterJobDefinitionResponse, DeregisterJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeComputeEnvironmentsError = ClientException | ServerException | CommonErrors;
/**
 * Describes one or more of your compute environments.
 *
 * If you're using an unmanaged compute environment, you can use the
 * `DescribeComputeEnvironment` operation to determine the
 * `ecsClusterArn` that you launch your Amazon ECS container instances into.
 */
export declare const describeComputeEnvironments: API.PaginatedOperationMethod<DescribeComputeEnvironmentsRequest, DescribeComputeEnvironmentsResponse, DescribeComputeEnvironmentsError, Credentials | HttpClient.HttpClient, ComputeEnvironmentDetail>;
export type DescribeConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Returns a description of the specified consumable resource.
 */
export declare const describeConsumableResource: API.OperationMethod<DescribeConsumableResourceRequest, DescribeConsumableResourceResponse, DescribeConsumableResourceError, Credentials | HttpClient.HttpClient>;
export type DescribeJobDefinitionsError = ClientException | ServerException | CommonErrors;
/**
 * Describes a list of job definitions. You can specify a `status` (such as
 * `ACTIVE`) to only return job definitions that match that status.
 */
export declare const describeJobDefinitions: API.PaginatedOperationMethod<DescribeJobDefinitionsRequest, DescribeJobDefinitionsResponse, DescribeJobDefinitionsError, Credentials | HttpClient.HttpClient, JobDefinition>;
export type DescribeJobQueuesError = ClientException | ServerException | CommonErrors;
/**
 * Describes one or more of your job queues.
 */
export declare const describeJobQueues: API.PaginatedOperationMethod<DescribeJobQueuesRequest, DescribeJobQueuesResponse, DescribeJobQueuesError, Credentials | HttpClient.HttpClient, JobQueueDetail>;
export type DescribeJobsError = ClientException | ServerException | CommonErrors;
/**
 * Describes a list of Batch jobs.
 */
export declare const describeJobs: API.OperationMethod<DescribeJobsRequest, DescribeJobsResponse, DescribeJobsError, Credentials | HttpClient.HttpClient>;
export type DescribeQuotaShareError = ClientException | ServerException | CommonErrors;
/**
 * Returns a description of the specified quota share.
 */
export declare const describeQuotaShare: API.OperationMethod<DescribeQuotaShareRequest, DescribeQuotaShareResponse, DescribeQuotaShareError, Credentials | HttpClient.HttpClient>;
export type DescribeSchedulingPoliciesError = ClientException | ServerException | CommonErrors;
/**
 * Describes one or more of your scheduling policies.
 */
export declare const describeSchedulingPolicies: API.OperationMethod<DescribeSchedulingPoliciesRequest, DescribeSchedulingPoliciesResponse, DescribeSchedulingPoliciesError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceEnvironmentsError = ClientException | ServerException | CommonErrors;
/**
 * Describes one or more of your service environments.
 */
export declare const describeServiceEnvironments: API.PaginatedOperationMethod<DescribeServiceEnvironmentsRequest, DescribeServiceEnvironmentsResponse, DescribeServiceEnvironmentsError, Credentials | HttpClient.HttpClient, ServiceEnvironmentDetail>;
export type DescribeServiceJobError = ClientException | ServerException | CommonErrors;
/**
 * The details of a service job.
 */
export declare const describeServiceJob: API.OperationMethod<DescribeServiceJobRequest, DescribeServiceJobResponse, DescribeServiceJobError, Credentials | HttpClient.HttpClient>;
export type GetJobQueueSnapshotError = ClientException | ServerException | CommonErrors;
/**
 * Provides a snapshot of job queue state, including ordering of `RUNNABLE` jobs, as well as capacity utilization for already dispatched jobs.
 * The first 100 `RUNNABLE` jobs in the job queue are listed in order of dispatch. For job queues with an attached
 * quota-share policy, the first `RUNNABLE` job in each quota share is also listed. Capacity utilization for the job queue is provided, as well as
 * break downs by share for job queues with attached fair-share or quota-share scheduling policies.
 */
export declare const getJobQueueSnapshot: API.OperationMethod<GetJobQueueSnapshotRequest, GetJobQueueSnapshotResponse, GetJobQueueSnapshotError, Credentials | HttpClient.HttpClient>;
export type ListConsumableResourcesError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch consumable resources.
 */
export declare const listConsumableResources: API.PaginatedOperationMethod<ListConsumableResourcesRequest, ListConsumableResourcesResponse, ListConsumableResourcesError, Credentials | HttpClient.HttpClient, ConsumableResourceSummary>;
export type ListJobsError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch jobs.
 *
 * You must specify only one of the following items:
 *
 * - A job queue ID to return a list of jobs in that job queue
 *
 * - A multi-node parallel job ID to return a list of nodes for that job
 *
 * - An array job ID to return a list of the children for that job
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListJobsByConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch jobs that require a specific consumable resource.
 */
export declare const listJobsByConsumableResource: API.PaginatedOperationMethod<ListJobsByConsumableResourceRequest, ListJobsByConsumableResourceResponse, ListJobsByConsumableResourceError, Credentials | HttpClient.HttpClient, ListJobsByConsumableResourceSummary>;
export type ListQuotaSharesError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch quota shares associated with a job queue.
 */
export declare const listQuotaShares: API.PaginatedOperationMethod<ListQuotaSharesRequest, ListQuotaSharesResponse, ListQuotaSharesError, Credentials | HttpClient.HttpClient, QuotaShareDetail>;
export type ListSchedulingPoliciesError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch scheduling policies.
 */
export declare const listSchedulingPolicies: API.PaginatedOperationMethod<ListSchedulingPoliciesRequest, ListSchedulingPoliciesResponse, ListSchedulingPoliciesError, Credentials | HttpClient.HttpClient, SchedulingPolicyListingDetail>;
export type ListServiceJobsError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of service jobs for a specified job queue.
 */
export declare const listServiceJobs: API.PaginatedOperationMethod<ListServiceJobsRequest, ListServiceJobsResponse, ListServiceJobsError, Credentials | HttpClient.HttpClient, ServiceJobSummary>;
export type ListTagsForResourceError = ClientException | ServerException | CommonErrors;
/**
 * Lists the tags for an Batch resource. Batch resources that support tags are compute environments, jobs, job definitions, job queues,
 * and scheduling policies. ARNs for child jobs of array and multi-node parallel (MNP) jobs aren't supported.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterJobDefinitionError = ClientException | ServerException | CommonErrors;
/**
 * Registers an Batch job definition.
 */
export declare const registerJobDefinition: API.OperationMethod<RegisterJobDefinitionRequest, RegisterJobDefinitionResponse, RegisterJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type SubmitJobError = ClientException | ServerException | CommonErrors;
/**
 * Submits an Batch job from a job definition. Parameters that are specified during SubmitJob override parameters defined in the job definition. vCPU and memory
 * requirements that are specified in the `resourceRequirements` objects in the job
 * definition are the exception. They can't be overridden this way using the `memory`
 * and `vcpus` parameters. Rather, you must specify updates to job definition
 * parameters in a `resourceRequirements` object that's included in the
 * `containerOverrides` parameter.
 *
 * Job queues with a scheduling policy are limited to 500 active share identifiers at
 * a time.
 *
 * Jobs that run on Fargate resources can't be guaranteed to run for more than 14 days.
 * This is because, after 14 days, Fargate resources might become unavailable and job might be
 * terminated.
 */
export declare const submitJob: API.OperationMethod<SubmitJobRequest, SubmitJobResponse, SubmitJobError, Credentials | HttpClient.HttpClient>;
export type SubmitServiceJobError = ClientException | ServerException | CommonErrors;
/**
 * Submits a service job to a specified job queue to run on SageMaker AI. A service job is a unit of work that you submit to Batch for execution on SageMaker AI.
 */
export declare const submitServiceJob: API.OperationMethod<SubmitServiceJobRequest, SubmitServiceJobResponse, SubmitServiceJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ClientException | ServerException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn`.
 * If existing tags on a resource aren't specified in the request parameters, they aren't
 * changed. When a resource is deleted, the tags that are associated with that resource are
 * deleted as well. Batch resources that support tags are compute environments, jobs, job definitions, job queues,
 * and scheduling policies. ARNs for child jobs of array and multi-node parallel (MNP) jobs aren't supported.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateJobError = ClientException | ServerException | CommonErrors;
/**
 * Terminates a job in a job queue. Jobs that are in the `STARTING` or
 * `RUNNING` state are terminated, which causes them to transition to
 * `FAILED`. Jobs that have not progressed to the `STARTING` state are
 * cancelled.
 */
export declare const terminateJob: API.OperationMethod<TerminateJobRequest, TerminateJobResponse, TerminateJobError, Credentials | HttpClient.HttpClient>;
export type TerminateJobsError = ClientException | ServerException | CommonErrors;
/**
 * Terminates up to 50 jobs in a job queue. This is a bulk version of TerminateJob. Jobs that are in the `STARTING` or
 * `RUNNING` state are terminated, which causes them to transition to
 * `FAILED`. Jobs that have not progressed to the `STARTING` state are
 * cancelled.
 *
 * Batch reports the result for each job individually in the response. Jobs that
 * were processed successfully are reported in the `successful` list. Jobs that
 * encountered errors are reported in the `errors` list. The response returns an
 * HTTP status code of `200` even when some jobs encountered errors, so check the
 * `errors` list. Jobs that can't be found are treated as successfully
 * processed.
 *
 * This operation requires `batch:TerminateJob` permission for each job in the
 * request. There is no separate `batch:TerminateJobs` IAM action. If a caller's IAM
 * policy grants `batch:TerminateJob`, they can use both the singular
 * TerminateJob and bulk `TerminateJobs` operations.
 */
export declare const terminateJobs: API.OperationMethod<TerminateJobsRequest, TerminateJobsResponse, TerminateJobsError, Credentials | HttpClient.HttpClient>;
export type TerminateServiceJobError = ClientException | ServerException | CommonErrors;
/**
 * Terminates a service job in a job queue.
 */
export declare const terminateServiceJob: API.OperationMethod<TerminateServiceJobRequest, TerminateServiceJobResponse, TerminateServiceJobError, Credentials | HttpClient.HttpClient>;
export type TerminateServiceJobsError = ClientException | ServerException | CommonErrors;
/**
 * Terminates up to 50 service jobs in a job queue. This is a bulk version of TerminateServiceJob.
 *
 * Batch reports the result for each service job individually in the response. Service jobs that were processed successfully are reported in the `successful` list. Service jobs that encountered errors are reported in the `errors` list. The response returns an HTTP status code of `200` even when some service jobs encountered errors, so check the `errors` list. Service jobs that can't be found are treated as successfully processed.
 *
 * This operation requires `batch:TerminateServiceJob` permission for each service job in the
 * request. There is no separate `batch:TerminateServiceJobs` IAM action. If a caller's IAM
 * policy grants `batch:TerminateServiceJob`, they can use both the singular
 * `TerminateServiceJob` and bulk `TerminateServiceJobs` operations.
 */
export declare const terminateServiceJobs: API.OperationMethod<TerminateServiceJobsRequest, TerminateServiceJobsResponse, TerminateServiceJobsError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ClientException | ServerException | CommonErrors;
/**
 * Deletes specified tags from an Batch resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateComputeEnvironmentError = ClientException | ServerException | ComputeEnvironmentNotFound | ComputeEnvironmentBeingModified | CommonErrors;
/**
 * Updates an Batch compute environment.
 */
export declare const updateComputeEnvironment: API.OperationMethod<UpdateComputeEnvironmentRequest, UpdateComputeEnvironmentResponse, UpdateComputeEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Updates a consumable resource.
 */
export declare const updateConsumableResource: API.OperationMethod<UpdateConsumableResourceRequest, UpdateConsumableResourceResponse, UpdateConsumableResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateJobQueueError = ClientException | ServerException | JobQueueNotFound | JobQueueBeingModified | CommonErrors;
/**
 * Updates a job queue.
 */
export declare const updateJobQueue: API.OperationMethod<UpdateJobQueueRequest, UpdateJobQueueResponse, UpdateJobQueueError, Credentials | HttpClient.HttpClient>;
export type UpdateQuotaShareError = ClientException | ServerException | CommonErrors;
/**
 * Updates a quota share.
 */
export declare const updateQuotaShare: API.OperationMethod<UpdateQuotaShareRequest, UpdateQuotaShareResponse, UpdateQuotaShareError, Credentials | HttpClient.HttpClient>;
export type UpdateSchedulingPolicyError = ClientException | ServerException | CommonErrors;
/**
 * Updates a scheduling policy.
 */
export declare const updateSchedulingPolicy: API.OperationMethod<UpdateSchedulingPolicyRequest, UpdateSchedulingPolicyResponse, UpdateSchedulingPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceEnvironmentError = ClientException | ServerException | CommonErrors;
/**
 * Updates a service environment. You can update the state of a service environment from `ENABLED` to `DISABLED` to prevent new service jobs from being placed in the service environment.
 */
export declare const updateServiceEnvironment: API.OperationMethod<UpdateServiceEnvironmentRequest, UpdateServiceEnvironmentResponse, UpdateServiceEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceJobError = ClientException | ServerException | CommonErrors;
/**
 * Updates the priority of a specified service job in an Batch job queue.
 */
export declare const updateServiceJob: API.OperationMethod<UpdateServiceJobRequest, UpdateServiceJobResponse, UpdateServiceJobError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=batch.d.ts.map