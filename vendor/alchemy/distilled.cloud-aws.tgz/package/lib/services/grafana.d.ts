import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type WorkspaceId = string;
export type LicenseType = string;
export type GrafanaToken = string;
export interface AssociateLicenseRequest {
    workspaceId: string;
    licenseType: string;
    grafanaToken?: string;
}
export type AccountAccessType = string;
export type DataSourceType = string;
export type DataSourceTypesList = string[];
export type Description = string | redacted.Redacted<string>;
export type Endpoint = string;
export type GrafanaVersion = string;
export type WorkspaceName = string | redacted.Redacted<string>;
export type OrganizationRoleName = string | redacted.Redacted<string>;
export type NotificationDestinationType = string;
export type NotificationDestinationsList = string[];
export type OrganizationalUnit = string;
export type OrganizationalUnitList = string[];
export type PermissionType = string;
export type StackSetName = string;
export type WorkspaceStatus = string;
export type IamRoleArn = string | redacted.Redacted<string>;
export type AuthenticationProviderTypes = string;
export type AuthenticationProviders = string[];
export type SamlConfigurationStatus = string;
export interface AuthenticationSummary {
    providers: string[];
    samlConfigurationStatus?: string;
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export type SubnetId = string;
export type SubnetIds = string[];
export interface VpcConfiguration {
    securityGroupIds: string[];
    subnetIds: string[];
}
export type PrefixListId = string;
export type PrefixListIds = string[];
export type VpceId = string;
export type VpceIds = string[];
export interface NetworkAccessConfiguration {
    prefixListIds: string[];
    vpceIds: string[];
}
export type IPAddressType = string;
export type KmsKeyId = string;
export type DegradedWorkspaceReason = string;
export interface WorkspaceDescription {
    accountAccessType?: string;
    created: Date;
    dataSources: string[];
    description?: string | redacted.Redacted<string>;
    endpoint: string;
    grafanaVersion: string;
    id: string;
    modified: Date;
    name?: string | redacted.Redacted<string>;
    organizationRoleName?: string | redacted.Redacted<string>;
    notificationDestinations?: string[];
    organizationalUnits?: string[];
    permissionType?: string;
    stackSetName?: string;
    status: string;
    workspaceRoleArn?: string | redacted.Redacted<string>;
    licenseType?: string;
    freeTrialConsumed?: boolean;
    licenseExpiration?: Date;
    freeTrialExpiration?: Date;
    authentication: AuthenticationSummary;
    tags?: {
        [key: string]: string | undefined;
    };
    vpcConfiguration?: VpcConfiguration;
    networkAccessControl?: NetworkAccessConfiguration;
    grafanaToken?: string;
    ipAddressType?: string;
    kmsKeyId?: string;
    degradedWorkspaceReason?: string;
}
export interface AssociateLicenseResponse {
    workspace: WorkspaceDescription;
}
export type ClientToken = string;
export type OverridableConfigurationJson = string;
export interface CreateWorkspaceRequest {
    accountAccessType: string;
    clientToken?: string;
    organizationRoleName?: string | redacted.Redacted<string>;
    permissionType: string;
    stackSetName?: string;
    workspaceDataSources?: string[];
    workspaceDescription?: string | redacted.Redacted<string>;
    workspaceName?: string | redacted.Redacted<string>;
    workspaceNotificationDestinations?: string[];
    workspaceOrganizationalUnits?: string[];
    workspaceRoleArn?: string | redacted.Redacted<string>;
    authenticationProviders: string[];
    tags?: {
        [key: string]: string | undefined;
    };
    vpcConfiguration?: VpcConfiguration;
    configuration?: string;
    networkAccessControl?: NetworkAccessConfiguration;
    grafanaVersion?: string;
    ipAddressType?: string;
    kmsKeyId?: string;
}
export interface CreateWorkspaceResponse {
    workspace: WorkspaceDescription;
}
export type ApiKeyName = string;
export interface CreateWorkspaceApiKeyRequest {
    keyName: string;
    keyRole: string;
    secondsToLive: number;
    workspaceId: string;
}
export type ApiKeyToken = string | redacted.Redacted<string>;
export interface CreateWorkspaceApiKeyResponse {
    keyName: string;
    key: string | redacted.Redacted<string>;
    workspaceId: string;
}
export type ServiceAccountName = string;
export type Role = string;
export interface CreateWorkspaceServiceAccountRequest {
    name: string;
    grafanaRole: string;
    workspaceId: string;
}
export interface CreateWorkspaceServiceAccountResponse {
    id: string;
    name: string;
    grafanaRole: string;
    workspaceId: string;
}
export type ServiceAccountTokenName = string;
export interface CreateWorkspaceServiceAccountTokenRequest {
    name: string;
    secondsToLive: number;
    serviceAccountId: string;
    workspaceId: string;
}
export type ServiceAccountTokenKey = string | redacted.Redacted<string>;
export interface ServiceAccountTokenSummaryWithKey {
    id: string;
    name: string;
    key: string | redacted.Redacted<string>;
}
export interface CreateWorkspaceServiceAccountTokenResponse {
    serviceAccountToken: ServiceAccountTokenSummaryWithKey;
    serviceAccountId: string;
    workspaceId: string;
}
export interface DeleteWorkspaceRequest {
    workspaceId: string;
}
export interface DeleteWorkspaceResponse {
    workspace: WorkspaceDescription;
}
export interface DeleteWorkspaceApiKeyRequest {
    keyName: string;
    workspaceId: string;
}
export interface DeleteWorkspaceApiKeyResponse {
    keyName: string;
    workspaceId: string;
}
export interface DeleteWorkspaceServiceAccountRequest {
    serviceAccountId: string;
    workspaceId: string;
}
export interface DeleteWorkspaceServiceAccountResponse {
    serviceAccountId: string;
    workspaceId: string;
}
export interface DeleteWorkspaceServiceAccountTokenRequest {
    tokenId: string;
    serviceAccountId: string;
    workspaceId: string;
}
export interface DeleteWorkspaceServiceAccountTokenResponse {
    tokenId: string;
    serviceAccountId: string;
    workspaceId: string;
}
export interface DescribeWorkspaceRequest {
    workspaceId: string;
}
export interface DescribeWorkspaceResponse {
    workspace: WorkspaceDescription;
}
export interface DescribeWorkspaceAuthenticationRequest {
    workspaceId: string;
}
export type IdpMetadataUrl = string;
export type IdpMetadata = {
    url: string;
    xml?: never;
} | {
    url?: never;
    xml: string;
};
export type AssertionAttribute = string;
export interface AssertionAttributes {
    name?: string;
    login?: string;
    email?: string;
    groups?: string;
    role?: string;
    org?: string;
}
export type RoleValue = string;
export type RoleValueList = string[];
export interface RoleValues {
    editor?: string[];
    admin?: string[];
}
export type AllowedOrganization = string;
export type AllowedOrganizations = string[];
export type LoginValidityDuration = number;
export interface SamlConfiguration {
    idpMetadata: IdpMetadata;
    assertionAttributes?: AssertionAttributes;
    roleValues?: RoleValues;
    allowedOrganizations?: string[];
    loginValidityDuration?: number;
}
export interface SamlAuthentication {
    status: string;
    configuration?: SamlConfiguration;
}
export type SSOClientId = string;
export interface AwsSsoAuthentication {
    ssoClientId?: string;
}
export interface AuthenticationDescription {
    providers: string[];
    saml?: SamlAuthentication;
    awsSso?: AwsSsoAuthentication;
}
export interface DescribeWorkspaceAuthenticationResponse {
    authentication: AuthenticationDescription;
}
export interface DescribeWorkspaceConfigurationRequest {
    workspaceId: string;
}
export interface DescribeWorkspaceConfigurationResponse {
    configuration: string;
    grafanaVersion?: string;
}
export interface DisassociateLicenseRequest {
    workspaceId: string;
    licenseType: string;
}
export interface DisassociateLicenseResponse {
    workspace: WorkspaceDescription;
}
export type PaginationToken = string;
export type UserType = string;
export type SsoId = string;
export interface ListPermissionsRequest {
    maxResults?: number;
    nextToken?: string;
    userType?: string;
    userId?: string;
    groupId?: string;
    workspaceId: string;
}
export interface User {
    id: string;
    type: string;
}
export interface PermissionEntry {
    user: User;
    role: string;
}
export type PermissionEntryList = PermissionEntry[];
export interface ListPermissionsResponse {
    nextToken?: string;
    permissions: PermissionEntry[];
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListVersionsRequest {
    maxResults?: number;
    nextToken?: string;
    workspaceId?: string;
}
export type GrafanaVersionList = string[];
export interface ListVersionsResponse {
    nextToken?: string;
    grafanaVersions?: string[];
}
export interface ListWorkspacesRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface WorkspaceSummary {
    created: Date;
    description?: string | redacted.Redacted<string>;
    endpoint: string;
    grafanaVersion: string;
    id: string;
    modified: Date;
    name?: string | redacted.Redacted<string>;
    notificationDestinations?: string[];
    status: string;
    authentication: AuthenticationSummary;
    tags?: {
        [key: string]: string | undefined;
    };
    licenseType?: string;
    grafanaToken?: string;
}
export type WorkspaceList = WorkspaceSummary[];
export interface ListWorkspacesResponse {
    workspaces: WorkspaceSummary[];
    nextToken?: string;
}
export interface ListWorkspaceServiceAccountsRequest {
    maxResults?: number;
    nextToken?: string;
    workspaceId: string;
}
export interface ServiceAccountSummary {
    id: string;
    name: string;
    isDisabled: string;
    grafanaRole: string;
}
export type ServiceAccountList = ServiceAccountSummary[];
export interface ListWorkspaceServiceAccountsResponse {
    nextToken?: string;
    serviceAccounts: ServiceAccountSummary[];
    workspaceId: string;
}
export interface ListWorkspaceServiceAccountTokensRequest {
    maxResults?: number;
    nextToken?: string;
    serviceAccountId: string;
    workspaceId: string;
}
export interface ServiceAccountTokenSummary {
    id: string;
    name: string;
    createdAt: Date;
    expiresAt: Date;
    lastUsedAt?: Date;
}
export type ServiceAccountTokenList = ServiceAccountTokenSummary[];
export interface ListWorkspaceServiceAccountTokensResponse {
    nextToken?: string;
    serviceAccountTokens: ServiceAccountTokenSummary[];
    serviceAccountId: string;
    workspaceId: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type UpdateAction = string;
export type UserList = User[];
export interface UpdateInstruction {
    action: string;
    role: string;
    users: User[];
}
export type UpdateInstructionBatch = UpdateInstruction[];
export interface UpdatePermissionsRequest {
    updateInstructionBatch: UpdateInstruction[];
    workspaceId: string;
}
export interface UpdateError {
    code: number;
    message: string;
    causedBy: UpdateInstruction;
}
export type UpdateErrorList = UpdateError[];
export interface UpdatePermissionsResponse {
    errors: UpdateError[];
}
export interface UpdateWorkspaceRequest {
    accountAccessType?: string;
    organizationRoleName?: string | redacted.Redacted<string>;
    permissionType?: string;
    stackSetName?: string;
    workspaceDataSources?: string[];
    workspaceDescription?: string | redacted.Redacted<string>;
    workspaceId: string;
    workspaceName?: string | redacted.Redacted<string>;
    workspaceNotificationDestinations?: string[];
    workspaceOrganizationalUnits?: string[];
    workspaceRoleArn?: string | redacted.Redacted<string>;
    vpcConfiguration?: VpcConfiguration;
    removeVpcConfiguration?: boolean;
    networkAccessControl?: NetworkAccessConfiguration;
    removeNetworkAccessConfiguration?: boolean;
    ipAddressType?: string;
}
export interface UpdateWorkspaceResponse {
    workspace: WorkspaceDescription;
}
export interface UpdateWorkspaceAuthenticationRequest {
    workspaceId: string;
    authenticationProviders: string[];
    samlConfiguration?: SamlConfiguration;
}
export interface UpdateWorkspaceAuthenticationResponse {
    authentication: AuthenticationDescription;
}
export interface UpdateWorkspaceConfigurationRequest {
    configuration: string;
    workspaceId: string;
    grafanaVersion?: string;
}
export interface UpdateWorkspaceConfigurationResponse {
}
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateLicenseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns a Grafana Enterprise license to a workspace. To upgrade, you must use `ENTERPRISE` for the `licenseType`, and pass in a valid Grafana Labs token for the `grafanaToken`. Upgrading to Grafana Enterprise incurs additional fees. For more information, see Upgrade a workspace to Grafana Enterprise.
 */
export declare const associateLicense: API.OperationMethod<AssociateLicenseRequest, AssociateLicenseResponse, AssociateLicenseError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a *workspace*. In a workspace, you can create Grafana dashboards and visualizations to analyze your metrics, logs, and traces. You don't have to build, package, or deploy any hardware to run the Grafana server.
 *
 * Don't use `CreateWorkspace` to modify an existing workspace. Instead, use UpdateWorkspace.
 */
export declare const createWorkspace: API.OperationMethod<CreateWorkspaceRequest, CreateWorkspaceResponse, CreateWorkspaceError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceApiKeyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Grafana API key for the workspace. This key can be used to authenticate requests sent to the workspace's HTTP API. See https://docs.aws.amazon.com/grafana/latest/userguide/Using-Grafana-APIs.html for available APIs and example requests.
 *
 * In workspaces compatible with Grafana version 9 or above, use workspace service accounts instead of API keys. API keys will be removed in a future release.
 */
export declare const createWorkspaceApiKey: API.OperationMethod<CreateWorkspaceApiKeyRequest, CreateWorkspaceApiKeyResponse, CreateWorkspaceApiKeyError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceServiceAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a service account for the workspace. A service account can be used to call Grafana HTTP APIs, and run automated workloads. After creating the service account with the correct `GrafanaRole` for your use case, use `CreateWorkspaceServiceAccountToken` to create a token that can be used to authenticate and authorize Grafana HTTP API calls.
 *
 * You can only create service accounts for workspaces that are compatible with Grafana version 9 and above.
 *
 * For more information about service accounts, see Service accounts in the *Amazon Managed Grafana User Guide*.
 *
 * For more information about the Grafana HTTP APIs, see Using Grafana HTTP APIs in the *Amazon Managed Grafana User Guide*.
 */
export declare const createWorkspaceServiceAccount: API.OperationMethod<CreateWorkspaceServiceAccountRequest, CreateWorkspaceServiceAccountResponse, CreateWorkspaceServiceAccountError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceServiceAccountTokenError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a token that can be used to authenticate and authorize Grafana HTTP API operations for the given workspace service account. The service account acts as a user for the API operations, and defines the permissions that are used by the API.
 *
 * When you create the service account token, you will receive a key that is used when calling Grafana APIs. Do not lose this key, as it will not be retrievable again.
 *
 * If you do lose the key, you can delete the token and recreate it to receive a new key. This will disable the initial key.
 *
 * Service accounts are only available for workspaces that are compatible with Grafana version 9 and above.
 */
export declare const createWorkspaceServiceAccountToken: API.OperationMethod<CreateWorkspaceServiceAccountTokenRequest, CreateWorkspaceServiceAccountTokenResponse, CreateWorkspaceServiceAccountTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Managed Grafana workspace.
 */
export declare const deleteWorkspace: API.OperationMethod<DeleteWorkspaceRequest, DeleteWorkspaceResponse, DeleteWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceApiKeyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Grafana API key for the workspace.
 *
 * In workspaces compatible with Grafana version 9 or above, use workspace service accounts instead of API keys. API keys will be removed in a future release.
 */
export declare const deleteWorkspaceApiKey: API.OperationMethod<DeleteWorkspaceApiKeyRequest, DeleteWorkspaceApiKeyResponse, DeleteWorkspaceApiKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceServiceAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a workspace service account from the workspace.
 *
 * This will delete any tokens created for the service account, as well. If the tokens are currently in use, the will fail to authenticate / authorize after they are deleted.
 *
 * Service accounts are only available for workspaces that are compatible with Grafana version 9 and above.
 */
export declare const deleteWorkspaceServiceAccount: API.OperationMethod<DeleteWorkspaceServiceAccountRequest, DeleteWorkspaceServiceAccountResponse, DeleteWorkspaceServiceAccountError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceServiceAccountTokenError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a token for the workspace service account.
 *
 * This will disable the key associated with the token. If any automation is currently using the key, it will no longer be authenticated or authorized to perform actions with the Grafana HTTP APIs.
 *
 * Service accounts are only available for workspaces that are compatible with Grafana version 9 and above.
 */
export declare const deleteWorkspaceServiceAccountToken: API.OperationMethod<DeleteWorkspaceServiceAccountTokenRequest, DeleteWorkspaceServiceAccountTokenResponse, DeleteWorkspaceServiceAccountTokenError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Displays information about one Amazon Managed Grafana workspace.
 */
export declare const describeWorkspace: API.OperationMethod<DescribeWorkspaceRequest, DescribeWorkspaceResponse, DescribeWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspaceAuthenticationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Displays information about the authentication methods used in one Amazon Managed Grafana workspace.
 */
export declare const describeWorkspaceAuthentication: API.OperationMethod<DescribeWorkspaceAuthenticationRequest, DescribeWorkspaceAuthenticationResponse, DescribeWorkspaceAuthenticationError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspaceConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the current configuration string for the given workspace.
 */
export declare const describeWorkspaceConfiguration: API.OperationMethod<DescribeWorkspaceConfigurationRequest, DescribeWorkspaceConfigurationResponse, DescribeWorkspaceConfigurationError, Credentials | HttpClient.HttpClient>;
export type DisassociateLicenseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the Grafana Enterprise license from a workspace.
 */
export declare const disassociateLicense: API.OperationMethod<DisassociateLicenseRequest, DisassociateLicenseResponse, DisassociateLicenseError, Credentials | HttpClient.HttpClient>;
export type ListPermissionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the users and groups who have the Grafana `Admin` and `Editor` roles in this workspace. If you use this operation without specifying `userId` or `groupId`, the operation returns the roles of all users and groups. If you specify a `userId` or a `groupId`, only the roles for that user or group are returned. If you do this, you can specify only one `userId` or one `groupId`.
 */
export declare const listPermissions: API.PaginatedOperationMethod<ListPermissionsRequest, ListPermissionsResponse, ListPermissionsError, Credentials | HttpClient.HttpClient, PermissionEntry>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The `ListTagsForResource` operation returns the tags that are associated with the Amazon Managed Service for Grafana resource specified by the `resourceArn`. Currently, the only resource that can be tagged is a workspace.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists available versions of Grafana. These are available when calling `CreateWorkspace`. Optionally, include a workspace to list the versions to which it can be upgraded.
 */
export declare const listVersions: API.PaginatedOperationMethod<ListVersionsRequest, ListVersionsResponse, ListVersionsError, Credentials | HttpClient.HttpClient, GrafanaVersion>;
export type ListWorkspacesError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Returns a list of Amazon Managed Grafana workspaces in the account, with some information about each workspace. For more complete information about one workspace, use DescribeWorkspace.
 */
export declare const listWorkspaces: API.PaginatedOperationMethod<ListWorkspacesRequest, ListWorkspacesResponse, ListWorkspacesError, Credentials | HttpClient.HttpClient, WorkspaceSummary>;
export type ListWorkspaceServiceAccountsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of service accounts for a workspace.
 *
 * Service accounts are only available for workspaces that are compatible with Grafana version 9 and above.
 */
export declare const listWorkspaceServiceAccounts: API.PaginatedOperationMethod<ListWorkspaceServiceAccountsRequest, ListWorkspaceServiceAccountsResponse, ListWorkspaceServiceAccountsError, Credentials | HttpClient.HttpClient, ServiceAccountSummary>;
export type ListWorkspaceServiceAccountTokensError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of tokens for a workspace service account.
 *
 * This does not return the key for each token. You cannot access keys after they are created. To create a new key, delete the token and recreate it.
 *
 * Service accounts are only available for workspaces that are compatible with Grafana version 9 and above.
 */
export declare const listWorkspaceServiceAccountTokens: API.PaginatedOperationMethod<ListWorkspaceServiceAccountTokensRequest, ListWorkspaceServiceAccountTokensResponse, ListWorkspaceServiceAccountTokensError, Credentials | HttpClient.HttpClient, ServiceAccountTokenSummary>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The `TagResource` operation associates tags with an Amazon Managed Grafana resource. Currently, the only resource that can be tagged is workspaces.
 *
 * If you specify a new tag key for the resource, this tag is appended to the list of tags associated with the resource. If you specify a tag key that is already associated with the resource, the new tag value that you specify replaces the previous value for that tag.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The `UntagResource` operation removes the association of the tag with the Amazon Managed Grafana resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdatePermissionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates which users in a workspace have the Grafana `Admin` or `Editor` roles.
 */
export declare const updatePermissions: API.OperationMethod<UpdatePermissionsRequest, UpdatePermissionsResponse, UpdatePermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspaceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies an existing Amazon Managed Grafana workspace. If you use this operation and omit any optional parameters, the existing values of those parameters are not changed.
 *
 * To modify the user authentication methods that the workspace uses, such as SAML or IAM Identity Center, use UpdateWorkspaceAuthentication.
 *
 * To modify which users in the workspace have the `Admin` and `Editor` Grafana roles, use UpdatePermissions.
 */
export declare const updateWorkspace: API.OperationMethod<UpdateWorkspaceRequest, UpdateWorkspaceResponse, UpdateWorkspaceError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspaceAuthenticationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to define the identity provider (IdP) that this workspace authenticates users from, using SAML. You can also map SAML assertion attributes to workspace user information and define which groups in the assertion attribute are to have the `Admin` and `Editor` roles in the workspace.
 *
 * Changes to the authentication method for a workspace may take a few minutes to take effect.
 */
export declare const updateWorkspaceAuthentication: API.OperationMethod<UpdateWorkspaceAuthenticationRequest, UpdateWorkspaceAuthenticationResponse, UpdateWorkspaceAuthenticationError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspaceConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration string for the given workspace
 */
export declare const updateWorkspaceConfiguration: API.OperationMethod<UpdateWorkspaceConfigurationRequest, UpdateWorkspaceConfigurationResponse, UpdateWorkspaceConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=grafana.d.ts.map